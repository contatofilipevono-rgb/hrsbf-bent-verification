import H12CloudChart2Data227

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound57537 : H12AffineFastState.Bounded env57537 := by
  intro p hp
  have h : env57537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57536_57537 : H12AffineEnvironment.transform 16 74863 env57536 = env57537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 74863 env57536 == env57537) = true)

def env57538 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,524288,32769,4096,61649,91183,123164,533640,614526,385202,90414,545089,96347,25885,618622,256,25880,1344,525825]

theorem envBound57538 : H12AffineFastState.Bounded env57538 := by
  intro p hp
  have h : env57538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57537_57538 : H12AffineEnvironment.transform 23 123164 env57537 = env57538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123164 env57537 == env57538) = true)

def env57539 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21584,32769,4096,61649,91183,123164,28888,78894,385202,90414,1297,96347,25885,74798,256,25880,1344,21073]

theorem envBound57539 : H12AffineFastState.Bounded env57539 := by
  intro p hp
  have h : env57539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57538_57539 : H12AffineEnvironment.transform 18 21584 env57538 = env57539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env57538 == env57539) = true)

theorem identity57539 : scanCanonicalize (H12AffineFastState.compose env57539 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound57539 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env57540 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13340,65536,74863,262144,21584,13341,4096,17613,91183,87296,28888,78894,349358,90414,1297,96347,25885,74798,256,25880,1344,21073]

theorem envBound57540 : H12AffineFastState.Bounded env57540 := by
  intro p hp
  have h : env57540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57539_57540 : H12AffineEnvironment.transform 14 13340 env57539 = env57540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env57539 == env57540) = true)

def env57541 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74863,262144,4416,13341,4096,477,74047,69648,13768,78894,332222,74814,1297,81227,8205,74798,256,8200,1344,5953]

theorem envBound57541 : H12AffineFastState.Bounded env57541 := by
  intro p hp
  have h : env57541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57540_57541 : H12AffineEnvironment.transform 13 1296 env57540 = env57541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env57540 == env57541) = true)

def env57542 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74863,65664,4416,13341,4096,477,74047,69648,13768,78894,4414,74814,1297,81227,8205,74798,256,8200,1344,5953]

theorem envBound57542 : H12AffineFastState.Bounded env57542 := by
  intro p hp
  have h : env57542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57541_57542 : H12AffineEnvironment.transform 17 65664 env57541 = env57542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env57541 == env57542) = true)

theorem identity57542 : scanCanonicalize (H12AffineFastState.compose env57542 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound57542 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57543 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,24,1296,5124,65536,66679,65664,4416,5125,4096,477,65831,69648,5584,70710,4414,66598,1297,73043,21,66614,256,16,1344,5953]

theorem envBound57543 : H12AffineFastState.Bounded env57543 := by
  intro p hp
  have h : env57543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57542_57543 : H12AffineEnvironment.transform 12 24 env57542 = env57543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env57542 == env57543) = true)

def env57544 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,4096,24,1296,5124,65536,66679,65664,4416,5125,4096,477,65831,69648,5584,70710,4414,66598,1297,73043,21,66614,256,16,1344,5141]

theorem envBound57544 : H12AffineFastState.Bounded env57544 := by
  intro p hp
  have h : env57544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57543_57544 : H12AffineEnvironment.transform 8 340 env57543 = env57544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env57543 == env57544) = true)

def env57545 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,1280,24,1296,260,65536,66679,65664,1088,261,1280,477,65831,66832,208,65846,1086,66598,1297,67667,21,66614,256,16,1344,277]

theorem envBound57545 : H12AffineFastState.Bounded env57545 := by
  intro p hp
  have h : env57545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57544_57545 : H12AffineEnvironment.transform 11 1280 env57544 = env57545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env57544 == env57545) = true)

theorem identity57545 : scanCanonicalize (H12AffineFastState.compose env57545 (packedSelected [1,8,28] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound57545 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env57546 : List Nat := [2,4,8,16,32,13,128,256,281,1024,2048,1280,24,1296,260,65536,66618,65664,1037,261,1280,400,65831,66832,157,65846,1086,66598,1297,67614,21,66614,256,16,1293,277]

theorem envBound57546 : H12AffineFastState.Bounded env57546 := by
  intro p hp
  have h : env57546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57545_57546 : H12AffineEnvironment.transform 5 13 env57545 = env57546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env57545 == env57546) = true)

def env57547 : List Nat := [2,4,4,16,32,1,128,256,277,1024,2048,1280,20,1296,260,65536,66614,65664,1025,261,1280,400,65831,66832,145,65846,1074,66598,1297,67602,21,66614,256,16,1281,277]

theorem envBound57547 : H12AffineFastState.Bounded env57547 := by
  intro p hp
  have h : env57547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57546_57547 : H12AffineEnvironment.transform 2 4 env57546 = env57547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env57546 == env57547) = true)

theorem identity57547 : scanCanonicalize (H12AffineFastState.compose env57547 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 51) := by decide +kernel

theorem selectedBound57547 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env57548 : List Nat := [2,4,4,16,32,1,128,256,277,1024,2048,1280,20,1296,260,51,1029,179,1025,261,1280,400,276,1315,145,261,1074,1045,1297,2081,21,1029,256,16,1281,277]

theorem envBound57548 : H12AffineFastState.Bounded env57548 := by
  intro p hp
  have h : env57548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57547_57548 : H12AffineEnvironment.transform 15 51 env57547 = env57548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 51 env57547 == env57548) = true)

theorem identity57548 : scanCanonicalize (H12AffineFastState.compose env57548 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound57548 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env57549 : List Nat := [2,4,4,16,32,1,128,21,0,1024,2048,1045,20,1029,17,51,1029,179,1025,16,1045,133,1,1078,145,16,1074,1045,1028,2081,21,1029,21,16,1044,0]

theorem envBound57549 : H12AffineFastState.Bounded env57549 := by
  intro p hp
  have h : env57549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57548_57549 : H12AffineEnvironment.transform 7 21 env57548 = env57549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env57548 == env57549) = true)

theorem identity57549 : scanCanonicalize (H12AffineFastState.compose env57549 (packedSelected [0,3,7,8,10,11,12,15] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound57549 : packedSelected [0,3,7,8,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env57550 : List Nat := [2,4,4,16,6,1,128,21,0,1024,2048,1045,20,1029,17,21,1029,149,1025,16,1045,133,1,1040,145,16,1044,1045,1028,2055,21,1029,21,16,1044,0]

theorem envBound57550 : H12AffineFastState.Bounded env57550 := by
  intro p hp
  have h : env57550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57549_57550 : H12AffineEnvironment.transform 4 6 env57549 = env57550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env57549 == env57550) = true)

theorem identity57550 : scanCanonicalize (H12AffineFastState.compose env57550 (packedSelected [2,8] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound57550 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env57551 : List Nat := [2,3,3,16,1,1,128,18,0,1024,2048,1042,19,1026,17,18,1026,146,1025,16,1042,130,1,1040,145,16,1043,1042,1027,2048,18,1026,18,16,1043,0]

theorem envBound57551 : H12AffineFastState.Bounded env57551 := by
  intro p hp
  have h : env57551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57550_57551 : H12AffineEnvironment.transform 1 3 env57550 = env57551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env57550 == env57551) = true)

def env57552 : List Nat := [2,4,5,16,32,0,128,256,276,1024,2048,1280,21,1296,260,65536,66615,65664,1024,261,1280,400,65831,66832,144,65846,1075,66598,1297,67603,21,66614,256,16,1280,277]

theorem envBound57552 : H12AffineFastState.Bounded env57552 := by
  intro p hp
  have h : env57552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57546_57552 : H12AffineEnvironment.transform 2 5 env57546 = env57552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env57546 == env57552) = true)

theorem identity57552 : scanCanonicalize (H12AffineFastState.compose env57552 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound57552 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env57553 : List Nat := [2,4,5,16,32,0,128,20,0,1024,2048,1044,21,1028,16,65536,66615,65664,1024,17,1044,132,65587,66564,144,65570,1075,66598,1029,67603,21,66614,20,16,1044,1]

theorem envBound57553 : H12AffineFastState.Bounded env57553 := by
  intro p hp
  have h : env57553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57552_57553 : H12AffineEnvironment.transform 7 20 env57552 = env57553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env57552 == env57553) = true)

theorem identity57553 : scanCanonicalize (H12AffineFastState.compose env57553 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 1079) := by decide +kernel

theorem selectedBound57553 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env57554 : List Nat := [2,4,5,16,32,0,128,20,0,1024,2048,1044,21,1028,16,1079,0,1207,1024,17,1044,132,1028,51,144,1045,1075,17,1029,3108,21,1,20,16,1044,1]

theorem envBound57554 : H12AffineFastState.Bounded env57554 := by
  intro p hp
  have h : env57554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57553_57554 : H12AffineEnvironment.transform 15 1079 env57553 = env57554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1079 env57553 == env57554) = true)

theorem identity57554 : scanCanonicalize (H12AffineFastState.compose env57554 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound57554 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env57555 : List Nat := [2,4,5,16,32,0,128,20,0,21,2048,1,21,17,16,34,0,162,21,17,1,132,17,51,144,0,38,17,16,2097,21,1,20,16,1,1]

theorem envBound57555 : H12AffineFastState.Bounded env57555 := by
  intro p hp
  have h : env57555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57554_57555 : H12AffineEnvironment.transform 9 21 env57554 = env57555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env57554 == env57555) = true)

theorem identity57555 : scanCanonicalize (H12AffineFastState.compose env57555 (packedSelected [2,5,8] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound57555 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env57556 : List Nat := [2,2,3,16,32,0,128,18,0,19,2048,1,19,17,16,34,0,162,19,17,1,130,17,51,144,0,32,17,16,2097,19,1,18,16,1,1]

theorem envBound57556 : H12AffineFastState.Bounded env57556 := by
  intro p hp
  have h : env57556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57555_57556 : H12AffineEnvironment.transform 1 2 env57555 = env57556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env57555 == env57556) = true)

theorem identity57556 : scanCanonicalize (H12AffineFastState.compose env57556 (packedSelected [1,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound57556 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env57557 : List Nat := [2,2,3,16,0,0,128,18,0,19,2048,1,19,17,16,2,0,130,19,17,1,130,17,19,144,0,0,17,16,2065,19,1,18,16,1,1]

theorem envBound57557 : H12AffineFastState.Bounded env57557 := by
  intro p hp
  have h : env57557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57556_57557 : H12AffineEnvironment.transform 4 0 env57556 = env57557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env57556 == env57557) = true)

theorem identity57557 : scanCanonicalize (H12AffineFastState.compose env57557 (packedSelected [0,1,3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound57557 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env57558 : List Nat := [1,1,0,16,0,0,128,17,0,16,2048,1,16,17,16,1,0,129,16,17,1,129,17,16,144,0,0,17,16,2065,16,1,17,16,1,1]

theorem envBound57558 : H12AffineFastState.Bounded env57558 := by
  intro p hp
  have h : env57558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57557_57558 : H12AffineEnvironment.transform 0 1 env57557 = env57558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env57557 == env57558) = true)

def env57559 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,1281,24,1296,261,65536,66679,65664,1089,260,1281,477,65831,66833,209,65847,1087,66598,1297,67666,21,66614,256,16,1344,276]

theorem envBound57559 : H12AffineFastState.Bounded env57559 := by
  intro p hp
  have h : env57559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57544_57559 : H12AffineEnvironment.transform 11 1281 env57544 = env57559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env57544 == env57559) = true)

theorem identity57559 : scanCanonicalize (H12AffineFastState.compose env57559 (packedSelected [1,8,28] rootPS)) = affineNative (2^(9+1) ^^^ 349) := by decide +kernel

theorem selectedBound57559 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env57560 : List Nat := [2,4,8,16,32,64,128,256,340,349,2048,92,24,77,261,65536,65834,65664,284,260,92,477,65831,65612,209,65847,354,65915,76,67666,21,65899,256,16,29,276]

theorem envBound57560 : H12AffineFastState.Bounded env57560 := by
  intro p hp
  have h : env57560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57559_57560 : H12AffineEnvironment.transform 9 349 env57559 = env57560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 349 env57559 == env57560) = true)

def env57561 : List Nat := [2,4,8,16,32,0,128,256,276,285,2048,28,24,13,261,65536,65834,65664,284,260,28,413,65831,65548,145,65847,290,65851,12,67602,21,65835,256,16,29,276]

theorem envBound57561 : H12AffineFastState.Bounded env57561 := by
  intro p hp
  have h : env57561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57560_57561 : H12AffineEnvironment.transform 5 0 env57560 = env57561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env57560 == env57561) = true)

theorem identity57561 : scanCanonicalize (H12AffineFastState.compose env57561 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 50) := by decide +kernel

theorem selectedBound57561 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env57562 : List Nat := [2,4,8,16,32,0,128,256,276,285,2048,28,24,13,261,50,280,178,284,260,28,413,277,62,145,261,290,265,12,2080,21,281,256,16,29,276]

theorem envBound57562 : H12AffineFastState.Bounded env57562 := by
  intro p hp
  have h : env57562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57561_57562 : H12AffineEnvironment.transform 15 50 env57561 = env57562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50 env57561 == env57562) = true)

theorem identity57562 : scanCanonicalize (H12AffineFastState.compose env57562 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound57562 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env57563 : List Nat := [2,4,8,16,32,0,128,21,1,8,2048,28,24,13,16,50,13,178,9,17,28,136,0,62,145,16,55,28,12,2080,21,12,21,16,29,1]

theorem envBound57563 : H12AffineFastState.Bounded env57563 := by
  intro p hp
  have h : env57563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57562_57563 : H12AffineEnvironment.transform 7 21 env57562 = env57563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env57562 == env57563) = true)

theorem identity57563 : scanCanonicalize (H12AffineFastState.compose env57563 (packedSelected [0,3,7,8,10,11,12,15] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound57563 : packedSelected [0,3,7,8,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env57564 : List Nat := [2,4,8,16,27,0,128,21,1,8,2048,28,24,13,16,9,13,137,9,17,28,136,0,5,145,16,12,28,12,2075,21,12,21,16,29,1]

theorem envBound57564 : H12AffineFastState.Bounded env57564 := by
  intro p hp
  have h : env57564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57563_57564 : H12AffineEnvironment.transform 4 27 env57563 = env57564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env57563 == env57564) = true)

theorem identity57564 : scanCanonicalize (H12AffineFastState.compose env57564 (packedSelected [2,8] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound57564 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env57565 : List Nat := [2,4,3,16,16,0,128,21,1,3,2048,23,19,6,16,2,6,130,2,17,23,131,0,5,145,16,7,23,7,2064,21,7,21,16,22,1]

theorem envBound57565 : H12AffineFastState.Bounded env57565 := by
  intro p hp
  have h : env57565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57564_57565 : H12AffineEnvironment.transform 2 3 env57564 = env57565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env57564 == env57565) = true)

theorem identity57565 : scanCanonicalize (H12AffineFastState.compose env57565 (packedSelected [1,2,3,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound57565 : packedSelected [1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env57566 : List Nat := [2,4,3,0,0,0,128,5,1,3,2048,7,3,6,0,2,6,130,2,1,7,131,0,5,129,0,7,7,7,2048,5,7,5,0,6,1]

theorem envBound57566 : H12AffineFastState.Bounded env57566 := by
  intro p hp
  have h : env57566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57565_57566 : H12AffineEnvironment.transform 3 0 env57565 = env57566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env57565 == env57566) = true)

theorem identity57566 : scanCanonicalize (H12AffineFastState.compose env57566 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 130) := by decide +kernel

theorem selectedBound57566 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57567 : List Nat := [2,4,3,0,0,0,128,5,1,3,130,7,3,6,0,2,6,130,2,1,7,131,0,5,129,0,7,7,7,130,5,7,5,0,6,1]

theorem envBound57567 : H12AffineFastState.Bounded env57567 := by
  intro p hp
  have h : env57567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57566_57567 : H12AffineEnvironment.transform 10 130 env57566 = env57567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 130 env57566 == env57567) = true)

def env57568 : List Nat := [2,4,8,16,32,1,128,256,277,284,2048,29,24,12,261,65536,65834,65664,284,260,29,412,65831,65549,144,65847,291,65850,13,67603,21,65834,256,16,29,276]

theorem envBound57568 : H12AffineFastState.Bounded env57568 := by
  intro p hp
  have h : env57568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57560_57568 : H12AffineEnvironment.transform 5 1 env57560 = env57568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env57560 == env57568) = true)

theorem identity57568 : scanCanonicalize (H12AffineFastState.compose env57568 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound57568 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env57569 : List Nat := [2,4,8,16,32,1,128,20,1,8,2048,29,24,12,17,65536,65598,65664,8,16,29,136,65587,65549,144,65571,55,65582,13,67603,21,65598,20,16,29,0]

theorem envBound57569 : H12AffineFastState.Bounded env57569 := by
  intro p hp
  have h : env57569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57568_57569 : H12AffineEnvironment.transform 7 20 env57568 = env57569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env57568 == env57569) = true)

theorem identity57569 : scanCanonicalize (H12AffineFastState.compose env57569 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 62) := by decide +kernel

theorem selectedBound57569 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env57570 : List Nat := [2,4,8,16,32,1,128,20,1,8,2048,29,24,12,17,62,0,190,8,16,29,136,13,51,144,29,55,16,13,2093,21,0,20,16,29,0]

theorem envBound57570 : H12AffineFastState.Bounded env57570 := by
  intro p hp
  have h : env57570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57569_57570 : H12AffineEnvironment.transform 15 62 env57569 = env57570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62 env57569 == env57570) = true)

theorem identity57570 : scanCanonicalize (H12AffineFastState.compose env57570 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound57570 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env57571 : List Nat := [2,4,8,13,32,1,128,9,1,8,2048,0,5,12,12,35,0,163,8,13,0,136,13,46,141,0,42,13,13,2093,8,0,9,13,0,0]

theorem envBound57571 : H12AffineFastState.Bounded env57571 := by
  intro p hp
  have h : env57571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57570_57571 : H12AffineEnvironment.transform 3 13 env57570 = env57571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env57570 == env57571) = true)

theorem identity57571 : scanCanonicalize (H12AffineFastState.compose env57571 (packedSelected [2,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 7) := by decide +kernel

theorem selectedBound57571 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env57572 : List Nat := [2,4,8,13,32,1,128,9,1,8,7,0,5,12,12,35,0,163,8,13,0,136,13,46,141,0,42,13,13,42,8,0,9,13,0,0]

theorem envBound57572 : H12AffineFastState.Bounded env57572 := by
  intro p hp
  have h : env57572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57571_57572 : H12AffineEnvironment.transform 10 7 env57571 = env57572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 7 env57571 == env57572) = true)

theorem identity57572 : scanCanonicalize (H12AffineFastState.compose env57572 (packedSelected [1,2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound57572 : packedSelected [1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env57573 : List Nat := [2,4,8,13,13,1,128,9,1,8,7,0,5,12,12,14,0,142,8,13,0,136,13,3,141,0,7,13,13,7,8,0,9,13,0,0]

theorem envBound57573 : H12AffineFastState.Bounded env57573 := by
  intro p hp
  have h : env57573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57572_57573 : H12AffineEnvironment.transform 4 13 env57572 = env57573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env57572 == env57573) = true)

theorem identity57573 : scanCanonicalize (H12AffineFastState.compose env57573 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound57573 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57574 : List Nat := [2,4,5,0,0,1,128,4,1,5,7,0,5,1,1,3,0,131,5,0,0,133,0,3,128,0,7,0,0,7,5,0,4,0,0,0]

theorem envBound57574 : H12AffineFastState.Bounded env57574 := by
  intro p hp
  have h : env57574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57573_57574 : H12AffineEnvironment.transform 2 5 env57573 = env57574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env57573 == env57574) = true)

theorem identity57574 : scanCanonicalize (H12AffineFastState.compose env57574 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound57574 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57575 : List Nat := [0,4,5,0,0,1,128,4,1,5,5,0,5,1,1,1,0,129,5,0,0,133,0,1,128,0,5,0,0,5,5,0,4,0,0,0]

theorem envBound57575 : H12AffineFastState.Bounded env57575 := by
  intro p hp
  have h : env57575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57574_57575 : H12AffineEnvironment.transform 0 0 env57574 = env57575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env57574 == env57575) = true)

theorem identity57575 : scanCanonicalize (H12AffineFastState.compose env57575 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound57575 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57576 : List Nat := [0,4,5,0,0,1,4,4,1,5,5,0,5,1,1,1,0,5,5,0,0,1,0,1,4,0,5,0,0,5,5,0,4,0,0,0]

theorem envBound57576 : H12AffineFastState.Bounded env57576 := by
  intro p hp
  have h : env57576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57575_57576 : H12AffineEnvironment.transform 6 4 env57575 = env57576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env57575 == env57576) = true)

theorem identity57576 : scanCanonicalize (H12AffineFastState.compose env57576 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound57576 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env57577 : List Nat := [0,0,1,0,0,1,0,0,1,1,1,0,1,1,1,1,0,1,1,0,0,1,0,1,0,0,1,0,0,1,1,0,0,0,0,0]

theorem envBound57577 : H12AffineFastState.Bounded env57577 := by
  intro p hp
  have h : env57577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57576_57577 : H12AffineEnvironment.transform 1 0 env57576 = env57577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env57576 == env57577) = true)

def env57578 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,4096,24,1296,5124,65536,66679,65664,4416,5125,4096,477,65831,69648,5584,70710,4414,66598,1297,73043,21,66614,256,16,1344,5140]

theorem envBound57578 : H12AffineFastState.Bounded env57578 := by
  intro p hp
  have h : env57578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57543_57578 : H12AffineEnvironment.transform 8 341 env57543 = env57578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env57543 == env57578) = true)

def env57579 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,1280,24,1296,260,65536,66679,65664,1088,261,1280,477,65831,66832,208,65846,1086,66598,1297,67667,21,66614,256,16,1344,276]

theorem envBound57579 : H12AffineFastState.Bounded env57579 := by
  intro p hp
  have h : env57579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57578_57579 : H12AffineEnvironment.transform 11 1280 env57578 = env57579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env57578 == env57579) = true)

theorem identity57579 : scanCanonicalize (H12AffineFastState.compose env57579 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 379) := by decide +kernel

theorem selectedBound57579 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env57580 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,1280,24,1296,260,379,1292,507,1088,261,1280,477,92,1131,208,77,1086,1373,1297,2344,21,1357,256,16,1344,276]

theorem envBound57580 : H12AffineFastState.Bounded env57580 := by
  intro p hp
  have h : env57580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57579_57580 : H12AffineEnvironment.transform 15 379 env57579 = env57580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 379 env57579 == env57580) = true)

def env57581 : List Nat := [2,4,8,16,32,0,128,256,277,1024,2048,1280,24,1296,260,315,1292,443,1024,261,1280,413,28,1067,144,13,1086,1309,1297,2344,21,1293,256,16,1280,276]

theorem envBound57581 : H12AffineFastState.Bounded env57581 := by
  intro p hp
  have h : env57581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57580_57581 : H12AffineEnvironment.transform 5 0 env57580 = env57581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env57580 == env57581) = true)

theorem identity57581 : scanCanonicalize (H12AffineFastState.compose env57581 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound57581 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env57582 : List Nat := [2,4,8,16,32,0,128,20,1,1024,2048,1044,24,1028,16,47,1048,175,1024,17,1044,137,28,1067,144,13,1086,1033,1029,2108,21,1049,20,16,1044,0]

theorem envBound57582 : H12AffineFastState.Bounded env57582 := by
  intro p hp
  have h : env57582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57581_57582 : H12AffineEnvironment.transform 7 20 env57581 = env57582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env57581 == env57582) = true)

theorem identity57582 : scanCanonicalize (H12AffineFastState.compose env57582 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(9+1) ^^^ 24) := by decide +kernel

theorem selectedBound57582 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env57583 : List Nat := [2,4,8,16,32,0,128,20,1,24,2048,12,24,28,16,47,0,175,24,17,12,137,28,51,144,13,38,17,29,2108,21,1,20,16,12,0]

theorem envBound57583 : H12AffineFastState.Bounded env57583 := by
  intro p hp
  have h : env57583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57582_57583 : H12AffineEnvironment.transform 9 24 env57582 = env57583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 24 env57582 == env57583) = true)

theorem identity57583 : scanCanonicalize (H12AffineFastState.compose env57583 (packedSelected [3,5,10] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound57583 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env57584 : List Nat := [2,4,5,16,32,0,128,20,1,21,2048,1,21,17,16,34,0,162,21,17,1,132,17,51,144,0,38,17,16,2097,21,1,20,16,1,0]

theorem envBound57584 : H12AffineFastState.Bounded env57584 := by
  intro p hp
  have h : env57584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57583_57584 : H12AffineEnvironment.transform 2 5 env57583 = env57584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env57583 == env57584) = true)

theorem identity57584 : scanCanonicalize (H12AffineFastState.compose env57584 (packedSelected [2,5,8] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound57584 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env57585 : List Nat := [2,3,2,16,32,0,128,19,1,18,2048,1,18,17,16,34,0,162,18,17,1,131,17,51,144,0,33,17,16,2097,18,1,19,16,1,0]

theorem envBound57585 : H12AffineFastState.Bounded env57585 := by
  intro p hp
  have h : env57585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57584_57585 : H12AffineEnvironment.transform 1 3 env57584 = env57585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env57584 == env57585) = true)

theorem identity57585 : scanCanonicalize (H12AffineFastState.compose env57585 (packedSelected [1,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound57585 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env57586 : List Nat := [2,3,2,16,16,0,128,19,1,18,2048,1,18,17,16,18,0,146,18,17,1,131,17,3,144,0,17,17,16,2049,18,1,19,16,1,0]

theorem envBound57586 : H12AffineFastState.Bounded env57586 := by
  intro p hp
  have h : env57586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57585_57586 : H12AffineEnvironment.transform 4 16 env57585 = env57586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env57585 == env57586) = true)

theorem identity57586 : scanCanonicalize (H12AffineFastState.compose env57586 (packedSelected [0,1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound57586 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env57587 : List Nat := [1,0,1,16,16,0,128,16,1,17,2048,1,17,17,16,17,0,145,17,17,1,128,17,0,144,0,17,17,16,2049,17,1,16,16,1,0]

theorem envBound57587 : H12AffineFastState.Bounded env57587 := by
  intro p hp
  have h : env57587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57586_57587 : H12AffineEnvironment.transform 0 1 env57586 = env57587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env57586 == env57587) = true)

theorem identity57587 : scanCanonicalize (H12AffineFastState.compose env57587 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound57587 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57588 : List Nat := [1,0,1,1,1,0,128,1,1,0,2048,1,0,0,1,0,0,128,0,0,1,128,0,0,129,0,0,0,1,2049,0,1,1,1,1,0]

theorem envBound57588 : H12AffineFastState.Bounded env57588 := by
  intro p hp
  have h : env57588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57587_57588 : H12AffineEnvironment.transform 3 1 env57587 = env57588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env57587 == env57588) = true)

theorem identity57588 : scanCanonicalize (H12AffineFastState.compose env57588 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound57588 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env57589 : List Nat := [1,0,1,1,1,0,128,1,1,0,0,1,0,0,1,0,0,128,0,0,1,128,0,0,129,0,0,0,1,1,0,1,1,1,1,0]

theorem envBound57589 : H12AffineFastState.Bounded env57589 := by
  intro p hp
  have h : env57589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57588_57589 : H12AffineEnvironment.transform 10 0 env57588 = env57589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env57588 == env57589) = true)

def env57590 : List Nat := [2,4,8,16,32,1,128,256,276,1024,2048,1280,24,1296,260,314,1292,442,1025,261,1280,412,29,1066,145,12,1086,1308,1297,2344,21,1292,256,16,1281,276]

theorem envBound57590 : H12AffineFastState.Bounded env57590 := by
  intro p hp
  have h : env57590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57580_57590 : H12AffineEnvironment.transform 5 1 env57580 = env57590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env57580 == env57590) = true)

theorem identity57590 : scanCanonicalize (H12AffineFastState.compose env57590 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 9) := by decide +kernel

theorem selectedBound57590 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env57591 : List Nat := [2,4,8,16,32,1,128,9,29,1024,2048,1033,24,1049,13,51,1029,179,1025,12,1033,149,29,1066,145,12,1086,1045,1048,2081,21,1029,9,16,1032,29]

theorem envBound57591 : H12AffineFastState.Bounded env57591 := by
  intro p hp
  have h : env57591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57590_57591 : H12AffineEnvironment.transform 7 9 env57590 = env57591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 9 env57590 == env57591) = true)

theorem identity57591 : scanCanonicalize (H12AffineFastState.compose env57591 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound57591 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env57592 : List Nat := [2,4,8,12,32,1,128,9,1,1024,2048,1033,4,1029,13,47,1029,175,1025,12,1033,137,1,1066,141,12,1058,1033,1028,2081,9,1029,9,12,1032,1]

theorem envBound57592 : H12AffineFastState.Bounded env57592 := by
  intro p hp
  have h : env57592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57591_57592 : H12AffineEnvironment.transform 3 12 env57591 = env57592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env57591 == env57592) = true)

theorem identity57592 : scanCanonicalize (H12AffineFastState.compose env57592 (packedSelected [0,3,7,8,10,11,12,15] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound57592 : packedSelected [0,3,7,8,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env57593 : List Nat := [2,4,8,12,6,1,128,9,1,1024,2048,1033,4,1029,13,9,1029,137,1025,12,1033,137,1,1036,141,12,1028,1033,1028,2055,9,1029,9,12,1032,1]

theorem envBound57593 : H12AffineFastState.Bounded env57593 := by
  intro p hp
  have h : env57593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57592_57593 : H12AffineEnvironment.transform 4 6 env57592 = env57593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env57592 == env57593) = true)

theorem identity57593 : scanCanonicalize (H12AffineFastState.compose env57593 (packedSelected [2,8] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound57593 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env57594 : List Nat := [2,4,2,6,6,1,128,3,1,1024,2048,1027,4,1029,7,3,1029,131,1025,6,1027,131,1,1030,135,6,1028,1027,1028,2055,3,1029,3,6,1026,1]

theorem envBound57594 : H12AffineFastState.Bounded env57594 := by
  intro p hp
  have h : env57594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57593_57594 : H12AffineEnvironment.transform 2 2 env57593 = env57594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env57593 == env57594) = true)

theorem identity57594 : scanCanonicalize (H12AffineFastState.compose env57594 (packedSelected [1,2,3,5] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound57594 : packedSelected [1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env57595 : List Nat := [2,3,2,1,1,1,128,3,1,1024,2048,1027,3,1026,0,3,1026,131,1025,1,1027,131,1,1025,128,1,1027,1027,1027,2048,3,1026,3,1,1026,1]

theorem envBound57595 : H12AffineFastState.Bounded env57595 := by
  intro p hp
  have h : env57595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57594_57595 : H12AffineEnvironment.transform 1 3 env57594 = env57595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env57594 == env57595) = true)

theorem identity57595 : scanCanonicalize (H12AffineFastState.compose env57595 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 131) := by decide +kernel

theorem selectedBound57595 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57596 : List Nat := [2,3,2,1,1,1,128,3,1,1024,131,1027,3,1026,0,3,1026,131,1025,1,1027,131,1,1025,128,1,1027,1027,1027,131,3,1026,3,1,1026,1]

theorem envBound57596 : H12AffineFastState.Bounded env57596 := by
  intro p hp
  have h : env57596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57595_57596 : H12AffineEnvironment.transform 10 131 env57595 = env57596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 131 env57595 == env57596) = true)

def env57597 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,1281,24,1296,261,65536,66679,65664,1089,260,1281,477,65831,66833,209,65847,1087,66598,1297,67666,21,66614,256,16,1344,277]

theorem envBound57597 : H12AffineFastState.Bounded env57597 := by
  intro p hp
  have h : env57597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57578_57597 : H12AffineEnvironment.transform 11 1281 env57578 = env57597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env57578 == env57597) = true)

theorem identity57597 : scanCanonicalize (H12AffineFastState.compose env57597 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 1131) := by decide +kernel

theorem selectedBound57597 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env57598 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,1281,24,1296,261,1131,28,1259,1089,260,1281,477,1356,378,209,1372,1087,77,1297,3129,21,93,256,16,1344,277]

theorem envBound57598 : H12AffineFastState.Bounded env57598 := by
  intro p hp
  have h : env57598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57597_57598 : H12AffineEnvironment.transform 15 1131 env57597 = env57598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1131 env57597 == env57598) = true)

def env57599 : List Nat := [2,4,8,16,32,64,128,256,341,272,2048,17,24,0,261,379,28,507,337,260,17,477,92,378,209,76,303,77,1,2345,21,93,256,16,80,277]

theorem envBound57599 : H12AffineFastState.Bounded env57599 := by
  intro p hp
  have h : env57599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57598_57599 : H12AffineEnvironment.transform 9 272 env57598 = env57599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env57598 == env57599) = true)

theorem identity57599 : scanCanonicalize (H12AffineFastState.compose env57599 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 73) := by decide +kernel

theorem selectedBound57599 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env57600 : List Nat := [2,4,8,16,32,64,128,73,28,89,2048,17,24,0,76,50,28,178,24,77,17,148,92,51,209,76,102,77,1,2144,21,93,73,16,80,92]

theorem envBound57600 : H12AffineFastState.Bounded env57600 := by
  intro p hp
  have h : env57600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57599_57600 : H12AffineEnvironment.transform 7 73 env57599 = env57600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 73 env57599 == env57600) = true)

theorem identity57600 : scanCanonicalize (H12AffineFastState.compose env57600 (packedSelected [1,2,3,4,9,10,12,16,17] rootPS)) = affineNative (2^(10+1) ^^^ 248) := by decide +kernel

theorem selectedBound57600 : packedSelected [1,2,3,4,9,10,12,16,17] rootPS < 2^1333 := by decide +kernel

def env57601 : List Nat := [2,4,8,16,32,64,128,73,28,89,248,17,24,0,76,50,28,178,24,77,17,148,92,51,209,76,102,77,1,152,21,93,73,16,80,92]

theorem envBound57601 : H12AffineFastState.Bounded env57601 := by
  intro p hp
  have h : env57601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57600_57601 : H12AffineEnvironment.transform 10 248 env57600 = env57601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 248 env57600 == env57601) = true)

theorem identity57601 : scanCanonicalize (H12AffineFastState.compose env57601 (packedSelected [0,1,4,5,7,9,11,12,13,15,16] rootPS)) = affineNative (2^(6+1) ^^^ 116) := by decide +kernel

theorem selectedBound57601 : packedSelected [0,1,4,5,7,9,11,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env57602 : List Nat := [2,4,8,16,32,64,116,73,28,89,12,17,24,0,76,50,28,70,24,77,17,96,92,51,37,76,102,77,1,108,21,93,73,16,80,92]

theorem envBound57602 : H12AffineFastState.Bounded env57602 := by
  intro p hp
  have h : env57602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57601_57602 : H12AffineEnvironment.transform 6 116 env57601 = env57602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 116 env57601 == env57602) = true)

theorem identity57602 : scanCanonicalize (H12AffineFastState.compose env57602 (packedSelected [4,5,9,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound57602 : packedSelected [4,5,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env57603 : List Nat := [2,4,8,16,32,49,5,56,28,40,12,17,24,0,61,50,28,55,24,60,17,17,45,51,37,61,23,60,1,29,21,44,56,16,33,45]

theorem envBound57603 : H12AffineFastState.Bounded env57603 := by
  intro p hp
  have h : env57603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57602_57603 : H12AffineEnvironment.transform 5 49 env57602 = env57603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env57602 == env57603) = true)

theorem identity57603 : scanCanonicalize (H12AffineFastState.compose env57603 (packedSelected [1,2,5,7,9] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound57603 : packedSelected [1,2,5,7,9] rootPS < 2^1333 := by decide +kernel

def env57604 : List Nat := [2,3,8,16,32,49,2,56,27,40,11,17,24,0,58,50,27,48,24,59,17,17,42,51,34,58,16,59,1,26,18,43,56,16,33,42]

theorem envBound57604 : H12AffineFastState.Bounded env57604 := by
  intro p hp
  have h : env57604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57603_57604 : H12AffineEnvironment.transform 1 3 env57603 = env57604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env57603 == env57604) = true)

theorem identity57604 : scanCanonicalize (H12AffineFastState.compose env57604 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound57604 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57605 : List Nat := [2,3,8,16,27,10,2,3,27,19,11,17,24,0,1,9,27,11,24,0,17,17,17,8,25,1,16,0,1,26,18,16,3,16,26,17]

theorem envBound57605 : H12AffineFastState.Bounded env57605 := by
  intro p hp
  have h : env57605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57604_57605 : H12AffineEnvironment.transform 4 27 env57604 = env57605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env57604 == env57605) = true)

def env57606 : List Nat := [2,4,8,16,32,64,128,256,341,273,2048,16,24,1,261,378,28,506,336,260,16,477,93,378,209,77,302,77,0,2344,21,93,256,16,81,277]

theorem envBound57606 : H12AffineFastState.Bounded env57606 := by
  intro p hp
  have h : env57606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57598_57606 : H12AffineEnvironment.transform 9 273 env57598 = env57606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env57598 == env57606) = true)

theorem identity57606 : scanCanonicalize (H12AffineFastState.compose env57606 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 8) := by decide +kernel

theorem selectedBound57606 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env57607 : List Nat := [2,4,8,16,32,64,128,8,93,25,2048,16,24,1,13,114,28,242,88,12,16,213,93,114,209,77,38,77,0,2080,21,93,8,16,81,29]

theorem envBound57607 : H12AffineFastState.Bounded env57607 := by
  intro p hp
  have h : env57607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57606_57607 : H12AffineEnvironment.transform 7 8 env57606 = env57607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 8 env57606 == env57607) = true)

theorem identity57607 : scanCanonicalize (H12AffineFastState.compose env57607 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound57607 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env57608 : List Nat := [2,4,8,16,32,0,128,8,29,25,2048,16,24,1,13,50,28,178,24,12,16,149,29,50,145,13,38,13,0,2080,21,29,8,16,17,29]

theorem envBound57608 : H12AffineFastState.Bounded env57608 := by
  intro p hp
  have h : env57608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57607_57608 : H12AffineEnvironment.transform 5 0 env57607 = env57608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env57607 == env57608) = true)

theorem identity57608 : scanCanonicalize (H12AffineFastState.compose env57608 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound57608 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env57609 : List Nat := [2,4,8,16,32,0,8,8,29,25,2048,16,24,1,13,50,28,58,24,12,16,29,29,50,25,13,38,13,0,2080,21,29,8,16,17,29]

theorem envBound57609 : H12AffineFastState.Bounded env57609 := by
  intro p hp
  have h : env57609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57608_57609 : H12AffineEnvironment.transform 6 8 env57608 = env57609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env57608 == env57609) = true)

theorem identity57609 : scanCanonicalize (H12AffineFastState.compose env57609 (packedSelected [3,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound57609 : packedSelected [3,5,7] rootPS < 2^1333 := by decide +kernel

def env57610 : List Nat := [2,4,8,16,16,0,8,8,29,25,2048,16,24,1,13,2,28,10,24,12,16,29,29,2,25,13,22,13,0,2064,21,29,8,16,17,29]

theorem envBound57610 : H12AffineFastState.Bounded env57610 := by
  intro p hp
  have h : env57610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57609_57610 : H12AffineEnvironment.transform 4 16 env57609 = env57610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env57609 == env57610) = true)

theorem identity57610 : scanCanonicalize (H12AffineFastState.compose env57610 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 13) := by decide +kernel

theorem selectedBound57610 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57611 : List Nat := [2,4,8,16,16,0,8,8,29,25,13,16,24,1,13,2,28,10,24,12,16,29,29,2,25,13,22,13,0,29,21,29,8,16,17,29]

theorem envBound57611 : H12AffineFastState.Bounded env57611 := by
  intro p hp
  have h : env57611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57610_57611 : H12AffineEnvironment.transform 10 13 env57610 = env57611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 13 env57610 == env57611) = true)

theorem identity57611 : scanCanonicalize (H12AffineFastState.compose env57611 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound57611 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57612 : List Nat := [2,4,2,16,16,0,2,2,23,19,7,16,18,1,7,2,22,0,18,6,16,23,23,2,19,7,22,7,0,23,21,23,2,16,17,23]

theorem envBound57612 : H12AffineFastState.Bounded env57612 := by
  intro p hp
  have h : env57612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57611_57612 : H12AffineEnvironment.transform 2 2 env57611 = env57612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env57611 == env57612) = true)

def env57613 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74863,65665,4416,13341,4096,477,74047,69648,13768,78894,4415,74814,1297,81227,8205,74798,256,8200,1344,5953]

theorem envBound57613 : H12AffineFastState.Bounded env57613 := by
  intro p hp
  have h : env57613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57541_57613 : H12AffineEnvironment.transform 17 65665 env57541 = env57613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env57541 == env57613) = true)

theorem identity57613 : scanCanonicalize (H12AffineFastState.compose env57613 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5464) := by decide +kernel

theorem selectedBound57613 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57614 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5464,1296,324,65536,69943,65665,4416,325,4096,477,70759,69648,144,65910,4415,69990,1297,67603,5461,70006,256,5456,1344,5953]

theorem envBound57614 : H12AffineFastState.Bounded env57614 := by
  intro p hp
  have h : env57614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57613_57614 : H12AffineEnvironment.transform 12 5464 env57613 = env57614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5464 env57613 == env57614) = true)

def env57615 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,4096,5464,1296,324,65536,69943,65665,4416,325,4096,477,70759,69648,144,65910,4415,69990,1297,67603,5461,70006,256,5456,1344,5141]

theorem envBound57615 : H12AffineFastState.Bounded env57615 := by
  intro p hp
  have h : env57615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57614_57615 : H12AffineEnvironment.transform 8 340 env57614 = env57615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env57614 == env57615) = true)

def env57616 : List Nat := [2,4,8,16,32,0,128,256,276,1024,2048,4096,5400,1296,260,65536,69943,65665,4352,261,4096,413,70695,69648,144,65846,4415,69926,1297,67603,5397,69942,256,5392,1280,5141]

theorem envBound57616 : H12AffineFastState.Bounded env57616 := by
  intro p hp
  have h : env57616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57615_57616 : H12AffineEnvironment.transform 5 0 env57615 = env57616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env57615 == env57616) = true)

theorem identity57616 : scanCanonicalize (H12AffineFastState.compose env57616 (packedSelected [1,8,28] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound57616 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env57617 : List Nat := [2,4,4,16,32,0,128,256,276,1024,2048,4096,5396,1296,260,65536,69943,65665,4352,261,4096,401,70695,69648,144,65846,4403,69926,1297,67603,5397,69942,256,5392,1280,5141]

theorem envBound57617 : H12AffineFastState.Bounded env57617 := by
  intro p hp
  have h : env57617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57616_57617 : H12AffineEnvironment.transform 2 4 env57616 = env57617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env57616 == env57617) = true)

def env57618 : List Nat := [2,4,4,16,32,0,128,256,276,1024,2048,16,1284,1296,260,65536,65831,65665,272,261,16,401,66615,65536,144,65846,291,65846,1297,67603,1285,65830,256,1280,1280,1029]

theorem envBound57618 : H12AffineFastState.Bounded env57618 := by
  intro p hp
  have h : env57618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57617_57618 : H12AffineEnvironment.transform 11 16 env57617 = env57618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env57617 == env57618) = true)

theorem identity57618 : scanCanonicalize (H12AffineFastState.compose env57618 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 1315) := by decide +kernel

theorem selectedBound57618 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env57619 : List Nat := [2,4,4,16,32,0,128,256,276,1024,2048,16,1284,1296,260,1315,1028,1442,272,261,16,401,276,1315,144,1045,291,1045,1297,3376,1285,1029,256,1280,1280,1029]

theorem envBound57619 : H12AffineFastState.Bounded env57619 := by
  intro p hp
  have h : env57619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57618_57619 : H12AffineEnvironment.transform 15 1315 env57618 = env57619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1315 env57618 == env57619) = true)

theorem identity57619 : scanCanonicalize (H12AffineFastState.compose env57619 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound57619 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env57620 : List Nat := [2,4,4,16,32,0,128,20,0,1024,2048,16,1040,1028,16,1079,1028,1206,4,17,16,133,0,1079,144,1045,55,1045,1029,3108,1041,1029,20,1044,1044,1029]

theorem envBound57620 : H12AffineFastState.Bounded env57620 := by
  intro p hp
  have h : env57620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57619_57620 : H12AffineEnvironment.transform 7 20 env57619 = env57620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env57619 == env57620) = true)

theorem identity57620 : scanCanonicalize (H12AffineFastState.compose env57620 (packedSelected [0,1,2,7,8,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound57620 : packedSelected [0,1,2,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env57621 : List Nat := [2,4,4,16,32,0,128,20,0,37,2048,16,53,33,16,18,33,147,4,17,16,133,0,18,144,48,55,48,32,2049,52,32,20,49,49,32]

theorem envBound57621 : H12AffineFastState.Bounded env57621 := by
  intro p hp
  have h : env57621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57620_57621 : H12AffineEnvironment.transform 9 37 env57620 = env57621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env57620 == env57621) = true)

theorem identity57621 : scanCanonicalize (H12AffineFastState.compose env57621 (packedSelected [1,2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound57621 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env57622 : List Nat := [2,2,2,16,32,0,128,18,0,35,2048,16,51,33,16,18,33,147,2,17,16,131,0,18,144,48,49,48,32,2049,50,32,18,49,49,32]

theorem envBound57622 : H12AffineFastState.Bounded env57622 := by
  intro p hp
  have h : env57622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57621_57622 : H12AffineEnvironment.transform 1 2 env57621 = env57622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env57621 == env57622) = true)

theorem identity57622 : scanCanonicalize (H12AffineFastState.compose env57622 (packedSelected [3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound57622 : packedSelected [3,5,8] rootPS < 2^1333 := by decide +kernel

def env57623 : List Nat := [2,2,2,16,32,0,128,18,0,35,17,16,51,33,16,18,33,147,2,17,16,131,0,18,144,48,49,48,32,16,50,32,18,49,49,32]

theorem envBound57623 : H12AffineFastState.Bounded env57623 := by
  intro p hp
  have h : env57623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57622_57623 : H12AffineEnvironment.transform 10 17 env57622 = env57623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env57622 == env57623) = true)

theorem identity57623 : scanCanonicalize (H12AffineFastState.compose env57623 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound57623 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env57624 : List Nat := [2,2,2,16,0,0,128,18,0,3,17,16,19,1,16,18,1,147,2,17,16,131,0,18,144,16,17,16,0,16,18,0,18,17,17,0]

theorem envBound57624 : H12AffineFastState.Bounded env57624 := by
  intro p hp
  have h : env57624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57623_57624 : H12AffineEnvironment.transform 4 0 env57623 = env57624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env57623 == env57624) = true)

theorem identity57624 : scanCanonicalize (H12AffineFastState.compose env57624 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound57624 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57625 : List Nat := [2,2,2,16,0,0,2,18,0,3,17,16,19,1,16,18,1,17,2,17,16,1,0,18,18,16,17,16,0,16,18,0,18,17,17,0]

theorem envBound57625 : H12AffineFastState.Bounded env57625 := by
  intro p hp
  have h : env57625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57624_57625 : H12AffineEnvironment.transform 6 2 env57624 = env57625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env57624 == env57625) = true)

def env57626 : List Nat := [2,4,4,16,32,0,128,256,276,1024,2048,17,1285,1296,260,65536,65830,65665,273,261,17,401,66614,65537,144,65846,290,65847,1297,67603,1284,65831,256,1281,1280,1028]

theorem envBound57626 : H12AffineFastState.Bounded env57626 := by
  intro p hp
  have h : env57626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57617_57626 : H12AffineEnvironment.transform 11 17 env57617 = env57626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env57617 == env57626) = true)

theorem identity57626 : scanCanonicalize (H12AffineFastState.compose env57626 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 50) := by decide +kernel

theorem selectedBound57626 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env57627 : List Nat := [2,4,4,16,32,0,128,256,276,1024,2048,17,1285,1296,260,50,276,179,273,261,17,401,1028,51,144,260,290,261,1297,2081,1284,277,256,1281,1280,1028]

theorem envBound57627 : H12AffineFastState.Bounded env57627 := by
  intro p hp
  have h : env57627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57626_57627 : H12AffineEnvironment.transform 15 50 env57626 = env57627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50 env57626 == env57627) = true)

theorem identity57627 : scanCanonicalize (H12AffineFastState.compose env57627 (packedSelected [1,2,3,4,9,10,12,16,17] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound57627 : packedSelected [1,2,3,4,9,10,12,16,17] rootPS < 2^1333 := by decide +kernel

def env57628 : List Nat := [2,4,4,16,32,0,128,4,16,1024,2048,17,1025,1044,0,50,16,179,21,1,17,149,1028,51,144,0,38,1,1045,2081,1024,17,4,1029,1028,1028]

theorem envBound57628 : H12AffineFastState.Bounded env57628 := by
  intro p hp
  have h : env57628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57627_57628 : H12AffineEnvironment.transform 7 4 env57627 = env57628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env57627 == env57628) = true)

theorem identity57628 : scanCanonicalize (H12AffineFastState.compose env57628 (packedSelected [0,1,2,5,7,8,10,11,12,13] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound57628 : packedSelected [0,1,2,5,7,8,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env57629 : List Nat := [2,4,4,6,32,0,128,4,6,1024,2048,7,1025,1026,0,36,6,165,3,1,7,131,1028,37,134,0,38,1,1027,2081,1024,7,4,1029,1028,1028]

theorem envBound57629 : H12AffineFastState.Bounded env57629 := by
  intro p hp
  have h : env57629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57628_57629 : H12AffineEnvironment.transform 3 6 env57628 = env57629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env57628 == env57629) = true)

theorem identity57629 : scanCanonicalize (H12AffineFastState.compose env57629 (packedSelected [0,2,3,5,7,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 6) := by decide +kernel

theorem selectedBound57629 : packedSelected [0,2,3,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env57630 : List Nat := [2,4,4,6,32,0,128,4,6,1024,6,7,1025,1026,0,36,6,165,3,1,7,131,1028,37,134,0,38,1,1027,39,1024,7,4,1029,1028,1028]

theorem envBound57630 : H12AffineFastState.Bounded env57630 := by
  intro p hp
  have h : env57630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57629_57630 : H12AffineEnvironment.transform 10 6 env57629 = env57630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 6 env57629 == env57630) = true)

theorem identity57630 : scanCanonicalize (H12AffineFastState.compose env57630 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 34) := by decide +kernel

theorem selectedBound57630 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env57631 : List Nat := [2,4,4,6,32,0,128,4,6,34,6,7,35,32,0,36,6,165,3,1,7,131,38,37,134,0,38,1,33,39,34,7,4,39,38,38]

theorem envBound57631 : H12AffineFastState.Bounded env57631 := by
  intro p hp
  have h : env57631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57630_57631 : H12AffineEnvironment.transform 9 34 env57630 = env57631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 34 env57630 == env57631) = true)

theorem identity57631 : scanCanonicalize (H12AffineFastState.compose env57631 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound57631 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env57632 : List Nat := [2,4,4,6,1,0,128,4,6,3,6,7,2,1,0,5,6,132,3,1,7,131,7,4,134,0,7,1,0,6,3,7,4,6,7,7]

theorem envBound57632 : H12AffineFastState.Bounded env57632 := by
  intro p hp
  have h : env57632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57631_57632 : H12AffineEnvironment.transform 4 1 env57631 = env57632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env57631 == env57632) = true)

theorem identity57632 : scanCanonicalize (H12AffineFastState.compose env57632 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 7) := by decide +kernel

theorem selectedBound57632 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57633 : List Nat := [2,4,4,6,1,0,7,4,6,3,6,7,2,1,0,5,6,3,3,1,7,4,7,4,1,0,7,1,0,6,3,7,4,6,7,7]

theorem envBound57633 : H12AffineFastState.Bounded env57633 := by
  intro p hp
  have h : env57633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57632_57633 : H12AffineEnvironment.transform 6 7 env57632 = env57633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 7 env57632 == env57633) = true)

theorem identity57633 : scanCanonicalize (H12AffineFastState.compose env57633 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound57633 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57634 : List Nat := [2,0,0,2,1,0,3,0,2,3,2,3,2,1,0,1,2,3,3,1,3,0,3,0,1,0,3,1,0,2,3,3,0,2,3,3]

theorem envBound57634 : H12AffineFastState.Bounded env57634 := by
  intro p hp
  have h : env57634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57633_57634 : H12AffineEnvironment.transform 1 0 env57633 = env57634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env57633 == env57634) = true)

theorem identity57634 : scanCanonicalize (H12AffineFastState.compose env57634 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound57634 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env57635 : List Nat := [0,0,0,0,1,0,1,0,0,1,0,1,0,1,0,1,0,1,1,1,1,0,1,0,1,0,1,1,0,0,1,1,0,0,1,1]

theorem envBound57635 : H12AffineFastState.Bounded env57635 := by
  intro p hp
  have h : env57635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57634_57635 : H12AffineEnvironment.transform 0 0 env57634 = env57635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env57634 == env57635) = true)

def env57636 : List Nat := [2,4,8,16,32,1,128,256,277,1024,2048,4096,5401,1296,261,65536,69943,65665,4353,260,4096,412,70694,69648,144,65847,4415,69927,1297,67603,5396,69943,256,5393,1281,5141]

theorem envBound57636 : H12AffineFastState.Bounded env57636 := by
  intro p hp
  have h : env57636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57615_57636 : H12AffineEnvironment.transform 5 1 env57615 = env57636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env57615 == env57636) = true)

theorem identity57636 : scanCanonicalize (H12AffineFastState.compose env57636 (packedSelected [1,8,28] rootPS)) = affineNative (2^(11+1) ^^^ 28) := by decide +kernel

theorem selectedBound57636 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env57637 : List Nat := [2,4,8,16,32,1,128,256,277,1024,2048,28,1285,1296,261,65536,65835,65665,285,260,28,412,66618,65548,144,65847,291,65851,1297,67603,1288,65835,256,1293,1281,1033]

theorem envBound57637 : H12AffineFastState.Bounded env57637 := by
  intro p hp
  have h : env57637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57636_57637 : H12AffineEnvironment.transform 11 28 env57636 = env57637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 28 env57636 == env57637) = true)

def env57638 : List Nat := [2,4,8,16,32,1,128,256,277,272,2048,28,21,0,261,65536,65835,65665,285,260,28,412,65834,65548,144,65847,291,65851,1,67603,24,65835,256,29,17,281]

theorem envBound57638 : H12AffineFastState.Bounded env57638 := by
  intro p hp
  have h : env57638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57637_57638 : H12AffineEnvironment.transform 9 272 env57637 = env57638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env57637 == env57638) = true)

theorem identity57638 : scanCanonicalize (H12AffineFastState.compose env57638 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 63) := by decide +kernel

theorem selectedBound57638 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env57639 : List Nat := [2,4,8,16,32,1,128,256,277,272,2048,28,21,0,261,63,276,190,285,260,28,412,277,51,144,264,291,260,1,2092,24,276,256,29,17,281]

theorem envBound57639 : H12AffineFastState.Bounded env57639 := by
  intro p hp
  have h : env57639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57638_57639 : H12AffineEnvironment.transform 15 63 env57638 = env57639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 63 env57638 == env57639) = true)

theorem identity57639 : scanCanonicalize (H12AffineFastState.compose env57639 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound57639 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env57640 : List Nat := [2,4,8,16,32,1,128,20,1,4,2048,28,21,0,17,63,0,190,9,16,28,136,1,51,144,28,55,16,1,2092,24,0,20,29,17,13]

theorem envBound57640 : H12AffineFastState.Bounded env57640 := by
  intro p hp
  have h : env57640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57639_57640 : H12AffineEnvironment.transform 7 20 env57639 = env57640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env57639 == env57640) = true)

theorem identity57640 : scanCanonicalize (H12AffineFastState.compose env57640 (packedSelected [10,12] rootPS)) = affineNative (2^(10+1) ^^^ 133) := by decide +kernel

theorem selectedBound57640 : packedSelected [10,12] rootPS < 2^1333 := by decide +kernel

def env57641 : List Nat := [2,4,8,16,32,1,128,20,1,4,133,28,21,0,17,63,0,190,9,16,28,136,1,51,144,28,55,16,1,169,24,0,20,29,17,13]

theorem envBound57641 : H12AffineFastState.Bounded env57641 := by
  intro p hp
  have h : env57641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57640_57641 : H12AffineEnvironment.transform 10 133 env57640 = env57641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 133 env57640 == env57641) = true)

theorem identity57641 : scanCanonicalize (H12AffineFastState.compose env57641 (packedSelected [2,3,5,8,10,13] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound57641 : packedSelected [2,3,5,8,10,13] rootPS < 2^1333 := by decide +kernel

def env57642 : List Nat := [2,3,8,16,32,1,128,19,1,3,130,27,18,0,17,56,0,185,9,16,27,136,1,51,144,27,48,16,1,169,24,0,19,26,17,10]

theorem envBound57642 : H12AffineFastState.Bounded env57642 := by
  intro p hp
  have h : env57642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57641_57642 : H12AffineEnvironment.transform 1 3 env57641 = env57642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env57641 == env57642) = true)

theorem identity57642 : scanCanonicalize (H12AffineFastState.compose env57642 (packedSelected [8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound57642 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env57643 : List Nat := [2,3,8,0,32,1,128,3,1,3,130,11,2,0,1,40,0,169,9,0,11,136,1,35,128,11,32,0,1,169,8,0,3,10,1,10]

theorem envBound57643 : H12AffineFastState.Bounded env57643 := by
  intro p hp
  have h : env57643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57642_57643 : H12AffineEnvironment.transform 3 0 env57642 = env57643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env57642 == env57643) = true)

theorem identity57643 : scanCanonicalize (H12AffineFastState.compose env57643 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound57643 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env57644 : List Nat := [2,3,8,0,32,1,41,3,1,3,43,11,2,0,1,40,0,0,9,0,11,33,1,35,41,11,32,0,1,0,8,0,3,10,1,10]

theorem envBound57644 : H12AffineFastState.Bounded env57644 := by
  intro p hp
  have h : env57644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57643_57644 : H12AffineEnvironment.transform 6 41 env57643 = env57644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env57643 == env57644) = true)

theorem identity57644 : scanCanonicalize (H12AffineFastState.compose env57644 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound57644 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57645 : List Nat := [2,3,8,0,10,1,3,3,1,3,1,11,2,0,1,2,0,0,9,0,11,11,1,9,3,11,10,0,1,0,8,0,3,10,1,10]

theorem envBound57645 : H12AffineFastState.Bounded env57645 := by
  intro p hp
  have h : env57645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57644_57645 : H12AffineEnvironment.transform 4 10 env57644 = env57645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env57644 == env57645) = true)

theorem identity57645 : scanCanonicalize (H12AffineFastState.compose env57645 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound57645 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57646 : List Nat := [2,3,2,0,0,1,3,3,1,3,1,1,2,0,1,2,0,0,3,0,1,1,1,3,3,1,0,0,1,0,2,0,3,0,1,0]

theorem envBound57646 : H12AffineFastState.Bounded env57646 := by
  intro p hp
  have h : env57646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57645_57646 : H12AffineEnvironment.transform 2 2 env57645 = env57646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env57645 == env57646) = true)

theorem identity57646 : scanCanonicalize (H12AffineFastState.compose env57646 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound57646 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57647 : List Nat := [0,1,0,0,0,1,1,1,1,1,1,1,0,0,1,0,0,0,1,0,1,1,1,1,1,1,0,0,1,0,0,0,1,0,1,0]

theorem envBound57647 : H12AffineFastState.Bounded env57647 := by
  intro p hp
  have h : env57647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57646_57647 : H12AffineEnvironment.transform 0 0 env57646 = env57647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env57646 == env57647) = true)

def env57648 : List Nat := [2,4,8,16,32,1,128,256,277,273,2048,28,20,1,261,65536,65835,65665,285,260,28,412,65835,65548,144,65847,291,65851,0,67603,25,65835,256,28,16,280]

theorem envBound57648 : H12AffineFastState.Bounded env57648 := by
  intro p hp
  have h : env57648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57637_57648 : H12AffineEnvironment.transform 9 273 env57637 = env57648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env57637 == env57648) = true)

theorem identity57648 : scanCanonicalize (H12AffineFastState.compose env57648 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 51) := by decide +kernel

theorem selectedBound57648 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env57649 : List Nat := [2,4,8,16,32,1,128,256,277,273,2048,28,20,1,261,51,280,178,285,260,28,412,280,63,144,260,291,264,0,2080,25,280,256,28,16,280]

theorem envBound57649 : H12AffineFastState.Bounded env57649 := by
  intro p hp
  have h : env57649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57648_57649 : H12AffineEnvironment.transform 15 51 env57648 = env57649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 51 env57648 == env57649) = true)

theorem identity57649 : scanCanonicalize (H12AffineFastState.compose env57649 (packedSelected [13,21] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound57649 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env57650 : List Nat := [2,4,8,0,32,1,128,256,261,257,2048,12,4,1,261,35,264,162,269,260,12,396,264,47,128,260,291,264,0,2080,9,264,256,12,0,264]

theorem envBound57650 : H12AffineFastState.Bounded env57650 := by
  intro p hp
  have h : env57650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57649_57650 : H12AffineEnvironment.transform 3 0 env57649 = env57650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env57649 == env57650) = true)

theorem identity57650 : scanCanonicalize (H12AffineFastState.compose env57650 (packedSelected [0,1,2,3,5,7,8,11,15] rootPS)) = affineNative (2^(7+1) ^^^ 160) := by decide +kernel

theorem selectedBound57650 : packedSelected [0,1,2,3,5,7,8,11,15] rootPS < 2^1333 := by decide +kernel

def env57651 : List Nat := [2,4,8,0,32,1,128,160,165,161,2048,12,4,1,165,35,168,162,173,164,12,44,168,47,128,164,131,168,0,2080,9,168,160,12,0,168]

theorem envBound57651 : H12AffineFastState.Bounded env57651 := by
  intro p hp
  have h : env57651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57650_57651 : H12AffineEnvironment.transform 7 160 env57650 = env57651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 160 env57650 == env57651) = true)

theorem identity57651 : scanCanonicalize (H12AffineFastState.compose env57651 (packedSelected [0,1,2,4,5,7,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound57651 : packedSelected [0,1,2,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env57652 : List Nat := [2,4,8,0,32,1,128,160,165,161,11,12,4,1,165,35,168,162,173,164,12,44,168,47,128,164,131,168,0,43,9,168,160,12,0,168]

theorem envBound57652 : H12AffineFastState.Bounded env57652 := by
  intro p hp
  have h : env57652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57651_57652 : H12AffineEnvironment.transform 10 11 env57651 = env57652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env57651 == env57652) = true)

theorem identity57652 : scanCanonicalize (H12AffineFastState.compose env57652 (packedSelected [0,1,3,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound57652 : packedSelected [0,1,3,5,7] rootPS < 2^1333 := by decide +kernel

def env57653 : List Nat := [2,4,8,0,32,1,15,47,42,46,11,12,4,1,42,35,39,45,34,43,12,44,39,47,15,43,12,39,0,43,9,39,47,12,0,39]

theorem envBound57653 : H12AffineFastState.Bounded env57653 := by
  intro p hp
  have h : env57653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57652_57653 : H12AffineEnvironment.transform 6 15 env57652 = env57653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env57652 == env57653) = true)

def env57654 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,4096,5464,1296,324,65536,69943,65665,4416,325,4096,477,70759,69648,144,65910,4415,69990,1297,67603,5461,70006,256,5456,1344,5140]

theorem envBound57654 : H12AffineFastState.Bounded env57654 := by
  intro p hp
  have h : env57654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57614_57654 : H12AffineEnvironment.transform 8 341 env57614 = env57654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env57614 == env57654) = true)

def env57655 : List Nat := [2,4,8,16,32,0,128,256,277,1024,2048,4096,5400,1296,260,65536,69943,65665,4352,261,4096,413,70695,69648,144,65846,4415,69926,1297,67603,5397,69942,256,5392,1280,5140]

theorem envBound57655 : H12AffineFastState.Bounded env57655 := by
  intro p hp
  have h : env57655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57654_57655 : H12AffineEnvironment.transform 5 0 env57654 = env57655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env57654 == env57655) = true)

theorem identity57655 : scanCanonicalize (H12AffineFastState.compose env57655 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 5178) := by decide +kernel

theorem selectedBound57655 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env57656 : List Nat := [2,4,8,16,32,0,128,256,277,1024,2048,4096,5400,1296,260,5178,1293,5307,4352,261,4096,413,29,1066,144,5388,4415,1308,1297,7209,5397,1292,256,5392,1280,5140]

theorem envBound57656 : H12AffineFastState.Bounded env57656 := by
  intro p hp
  have h : env57656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57655_57656 : H12AffineEnvironment.transform 15 5178 env57655 = env57656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5178 env57655 == env57656) = true)

def env57657 : List Nat := [2,4,8,16,32,0,128,256,277,1024,2048,280,1024,1296,260,1314,1293,1443,24,261,280,413,29,1066,144,1044,39,1308,1297,3377,1037,1292,256,1032,1280,1292]

theorem envBound57657 : H12AffineFastState.Bounded env57657 := by
  intro p hp
  have h : env57657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57656_57657 : H12AffineEnvironment.transform 11 280 env57656 = env57657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 280 env57656 == env57657) = true)

theorem identity57657 : scanCanonicalize (H12AffineFastState.compose env57657 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 269) := by decide +kernel

theorem selectedBound57657 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env57658 : List Nat := [2,4,8,16,32,0,128,256,277,269,2048,280,269,29,260,47,0,174,24,261,280,413,29,295,144,281,39,17,28,2108,256,1,256,261,13,1]

theorem envBound57658 : H12AffineFastState.Bounded env57658 := by
  intro p hp
  have h : env57658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57657_57658 : H12AffineEnvironment.transform 9 269 env57657 = env57658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 269 env57657 == env57658) = true)

theorem identity57658 : scanCanonicalize (H12AffineFastState.compose env57658 (packedSelected [1,8,11,12,13,16,18,23] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound57658 : packedSelected [1,8,11,12,13,16,18,23] rootPS < 2^1333 := by decide +kernel

def env57659 : List Nat := [2,4,8,16,32,0,128,140,153,129,2048,148,129,29,136,47,0,174,24,137,148,17,29,171,144,149,39,17,28,2108,140,1,140,137,13,1]

theorem envBound57659 : H12AffineFastState.Bounded env57659 := by
  intro p hp
  have h : env57659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57658_57659 : H12AffineEnvironment.transform 7 140 env57658 = env57659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env57658 == env57659) = true)

theorem identity57659 : scanCanonicalize (H12AffineFastState.compose env57659 (packedSelected [0,2,7,8,10,11,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 164) := by decide +kernel

theorem selectedBound57659 : packedSelected [0,2,7,8,10,11,15,17] rootPS < 2^1333 := by decide +kernel

def env57660 : List Nat := [2,4,8,16,32,0,128,140,153,129,164,148,129,29,136,47,0,174,24,137,148,17,29,171,144,149,39,17,28,152,140,1,140,137,13,1]

theorem envBound57660 : H12AffineFastState.Bounded env57660 := by
  intro p hp
  have h : env57660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57659_57660 : H12AffineEnvironment.transform 10 164 env57659 = env57660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 164 env57659 == env57660) = true)

theorem identity57660 : scanCanonicalize (H12AffineFastState.compose env57660 (packedSelected [0,2,3,7,12] rootPS)) = affineNative (2^(6+1) ^^^ 63) := by decide +kernel

theorem selectedBound57660 : packedSelected [0,2,3,7,12] rootPS < 2^1333 := by decide +kernel

def env57661 : List Nat := [2,4,8,16,32,0,63,51,38,62,27,43,62,29,55,47,0,17,24,54,43,17,29,20,47,42,39,17,28,39,51,1,51,54,13,1]

theorem envBound57661 : H12AffineFastState.Bounded env57661 := by
  intro p hp
  have h : env57661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57660_57661 : H12AffineEnvironment.transform 6 63 env57660 = env57661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 63 env57660 == env57661) = true)

theorem identity57661 : scanCanonicalize (H12AffineFastState.compose env57661 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound57661 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env57662 : List Nat := [2,4,8,0,32,0,47,35,38,46,11,43,46,13,39,47,0,1,8,38,43,1,13,4,47,42,39,1,12,39,35,1,35,38,13,1]

theorem envBound57662 : H12AffineFastState.Bounded env57662 := by
  intro p hp
  have h : env57662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57661_57662 : H12AffineEnvironment.transform 3 0 env57661 = env57662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env57661 == env57662) = true)

theorem identity57662 : scanCanonicalize (H12AffineFastState.compose env57662 (packedSelected [0,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound57662 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env57663 : List Nat := [2,4,8,0,1,0,14,2,7,15,11,10,15,13,6,14,0,1,8,7,10,1,13,4,14,11,6,1,12,6,2,1,2,7,13,1]

theorem envBound57663 : H12AffineFastState.Bounded env57663 := by
  intro p hp
  have h : env57663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57662_57663 : H12AffineEnvironment.transform 4 1 env57662 = env57663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env57662 == env57663) = true)

theorem identity57663 : scanCanonicalize (H12AffineFastState.compose env57663 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound57663 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57664 : List Nat := [2,2,8,0,1,0,8,2,1,9,11,10,9,11,0,8,0,1,8,1,10,1,11,2,8,11,0,1,10,0,2,1,2,1,11,1]

theorem envBound57664 : H12AffineFastState.Bounded env57664 := by
  intro p hp
  have h : env57664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57663_57664 : H12AffineEnvironment.transform 1 2 env57663 = env57664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env57663 == env57664) = true)

def env57665 : List Nat := [2,4,8,16,32,0,128,256,277,1024,2048,281,1025,1296,260,1315,1293,1442,25,261,281,413,29,1066,144,1045,38,1308,1297,3376,1036,1292,256,1033,1280,1293]

theorem envBound57665 : H12AffineFastState.Bounded env57665 := by
  intro p hp
  have h : env57665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57656_57665 : H12AffineEnvironment.transform 11 281 env57656 = env57665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 281 env57656 == env57665) = true)

theorem identity57665 : scanCanonicalize (H12AffineFastState.compose env57665 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound57665 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env57666 : List Nat := [2,4,8,16,32,0,128,256,277,256,2048,281,257,16,260,35,13,162,25,261,281,413,29,298,144,277,38,28,17,2096,268,12,256,265,0,13]

theorem envBound57666 : H12AffineFastState.Bounded env57666 := by
  intro p hp
  have h : env57666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57665_57666 : H12AffineEnvironment.transform 9 256 env57665 = env57666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env57665 == env57666) = true)

theorem identity57666 : scanCanonicalize (H12AffineFastState.compose env57666 (packedSelected [0,1,4,5,7,9,10,12,13,15,19,20,23] rootPS)) = affineNative (2^(10+1) ^^^ 407) := by decide +kernel

theorem selectedBound57666 : packedSelected [0,1,4,5,7,9,10,12,13,15,19,20,23] rootPS < 2^1333 := by decide +kernel

def env57667 : List Nat := [2,4,8,16,32,0,128,256,277,256,407,281,257,16,260,35,13,162,25,261,281,413,29,298,144,277,38,28,17,423,268,12,256,265,0,13]

theorem envBound57667 : H12AffineFastState.Bounded env57667 := by
  intro p hp
  have h : env57667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57666_57667 : H12AffineEnvironment.transform 10 407 env57666 = env57667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 407 env57666 == env57667) = true)

theorem identity57667 : scanCanonicalize (H12AffineFastState.compose env57667 (packedSelected [0,1,7,8,10,12,16] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound57667 : packedSelected [0,1,7,8,10,12,16] rootPS < 2^1333 := by decide +kernel

def env57668 : List Nat := [2,4,8,16,6,0,128,256,277,256,407,281,257,16,260,5,13,132,25,261,281,413,29,268,144,277,0,28,17,385,268,12,256,265,0,13]

theorem envBound57668 : H12AffineFastState.Bounded env57668 := by
  intro p hp
  have h : env57668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57667_57668 : H12AffineEnvironment.transform 4 6 env57667 = env57668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env57667 == env57668) = true)

theorem identity57668 : scanCanonicalize (H12AffineFastState.compose env57668 (packedSelected [0,1,3,4,5,8,11] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound57668 : packedSelected [0,1,3,4,5,8,11] rootPS < 2^1333 := by decide +kernel

def env57669 : List Nat := [2,4,8,12,6,0,128,256,265,256,395,261,257,12,260,5,13,132,5,261,261,385,1,268,140,265,0,0,13,385,268,12,256,265,0,13]

theorem envBound57669 : H12AffineFastState.Bounded env57669 := by
  intro p hp
  have h : env57669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57668_57669 : H12AffineEnvironment.transform 3 12 env57668 = env57669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env57668 == env57669) = true)

theorem identity57669 : scanCanonicalize (H12AffineFastState.compose env57669 (packedSelected [2,3,4,7] rootPS)) = affineNative (2^(7+1) ^^^ 128) := by decide +kernel

theorem selectedBound57669 : packedSelected [2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env57670 : List Nat := [2,4,8,12,6,0,128,128,137,128,11,133,129,12,132,5,13,132,5,133,133,1,1,140,140,137,0,0,13,1,140,12,128,137,0,13]

theorem envBound57670 : H12AffineFastState.Bounded env57670 := by
  intro p hp
  have h : env57670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57669_57670 : H12AffineEnvironment.transform 7 128 env57669 = env57670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 128 env57669 == env57670) = true)

theorem identity57670 : scanCanonicalize (H12AffineFastState.compose env57670 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound57670 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env57671 : List Nat := [2,4,8,12,6,0,14,14,7,14,11,11,15,12,10,5,13,10,5,11,11,1,1,2,2,7,0,0,13,1,2,12,14,7,0,13]

theorem envBound57671 : H12AffineFastState.Bounded env57671 := by
  intro p hp
  have h : env57671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57670_57671 : H12AffineEnvironment.transform 6 14 env57670 = env57671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env57670 == env57671) = true)

theorem identity57671 : scanCanonicalize (H12AffineFastState.compose env57671 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound57671 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57672 : List Nat := [2,4,3,7,6,0,5,5,7,5,0,0,4,7,1,5,6,1,5,0,0,1,1,2,2,7,0,0,6,1,2,7,5,7,0,6]

theorem envBound57672 : H12AffineFastState.Bounded env57672 := by
  intro p hp
  have h : env57672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57671_57672 : H12AffineEnvironment.transform 2 3 env57671 = env57672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env57671 == env57672) = true)

theorem identity57672 : scanCanonicalize (H12AffineFastState.compose env57672 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound57672 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57673 : List Nat := [0,4,1,5,4,0,5,5,5,5,0,0,4,5,1,5,4,1,5,0,0,1,1,0,0,5,0,0,4,1,0,5,5,5,0,4]

theorem envBound57673 : H12AffineFastState.Bounded env57673 := by
  intro p hp
  have h : env57673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57672_57673 : H12AffineEnvironment.transform 0 0 env57672 = env57673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env57672 == env57673) = true)

theorem identity57673 : scanCanonicalize (H12AffineFastState.compose env57673 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound57673 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57674 : List Nat := [0,1,1,0,1,0,0,0,0,0,0,0,1,0,1,0,1,1,0,0,0,1,1,0,0,0,0,0,1,1,0,0,0,0,0,1]

theorem envBound57674 : H12AffineFastState.Bounded env57674 := by
  intro p hp
  have h : env57674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57673_57674 : H12AffineEnvironment.transform 1 1 env57673 = env57674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env57673 == env57674) = true)

def env57675 : List Nat := [2,4,8,16,32,1,128,256,276,1024,2048,4096,5401,1296,261,65536,69943,65665,4353,260,4096,412,70694,69648,144,65847,4415,69927,1297,67603,5396,69943,256,5393,1281,5140]

theorem envBound57675 : H12AffineFastState.Bounded env57675 := by
  intro p hp
  have h : env57675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57654_57675 : H12AffineEnvironment.transform 5 1 env57654 = env57675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env57654 == env57675) = true)

theorem identity57675 : scanCanonicalize (H12AffineFastState.compose env57675 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 1067) := by decide +kernel

theorem selectedBound57675 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env57676 : List Nat := [2,4,8,16,32,1,128,256,276,1024,2048,4096,5401,1296,261,1067,5404,1194,4353,260,4096,412,4109,5179,144,1308,4415,5388,1297,3128,5396,5404,256,5393,1281,5140]

theorem envBound57676 : H12AffineFastState.Bounded env57676 := by
  intro p hp
  have h : env57676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57675_57676 : H12AffineEnvironment.transform 15 1067 env57675 = env57676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1067 env57675 == env57676) = true)

def env57677 : List Nat := [2,4,8,16,32,1,128,256,276,1024,2048,280,1025,1296,261,1067,1028,1194,25,260,280,412,277,1315,144,1308,39,1044,1297,3128,1036,1028,256,1033,1281,1292]

theorem envBound57677 : H12AffineFastState.Bounded env57677 := by
  intro p hp
  have h : env57677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57676_57677 : H12AffineEnvironment.transform 11 280 env57676 = env57677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 280 env57676 == env57677) = true)

theorem identity57677 : scanCanonicalize (H12AffineFastState.compose env57677 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound57677 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env57678 : List Nat := [2,4,8,16,32,1,128,20,0,1024,2048,12,1025,1028,17,1067,1028,1194,25,16,12,136,1,1079,144,1032,39,1044,1029,3128,1036,1028,20,1033,1045,1048]

theorem envBound57678 : H12AffineFastState.Bounded env57678 := by
  intro p hp
  have h : env57678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57677_57678 : H12AffineEnvironment.transform 7 20 env57677 = env57678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env57677 == env57678) = true)

theorem identity57678 : scanCanonicalize (H12AffineFastState.compose env57678 (packedSelected [2,3,5,11,12,15,17,18,19,24] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound57678 : packedSelected [2,3,5,11,12,15,17,18,19,24] rootPS < 2^1333 := by decide +kernel

def env57679 : List Nat := [2,4,8,16,32,1,128,20,0,53,2048,12,52,49,17,30,49,159,25,16,12,136,1,2,144,61,39,33,48,2061,57,49,20,60,32,45]

theorem envBound57679 : H12AffineFastState.Bounded env57679 := by
  intro p hp
  have h : env57679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57678_57679 : H12AffineEnvironment.transform 9 53 env57678 = env57679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env57678 == env57679) = true)

theorem identity57679 : scanCanonicalize (H12AffineFastState.compose env57679 (packedSelected [3,10,17] rootPS)) = affineNative (2^(10+1) ^^^ 58) := by decide +kernel

theorem selectedBound57679 : packedSelected [3,10,17] rootPS < 2^1333 := by decide +kernel

def env57680 : List Nat := [2,4,8,16,32,1,128,20,0,53,58,12,52,49,17,30,49,159,25,16,12,136,1,2,144,61,39,33,48,55,57,49,20,60,32,45]

theorem envBound57680 : H12AffineFastState.Bounded env57680 := by
  intro p hp
  have h : env57680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57679_57680 : H12AffineEnvironment.transform 10 58 env57679 = env57680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 58 env57679 == env57680) = true)

theorem identity57680 : scanCanonicalize (H12AffineFastState.compose env57680 (packedSelected [5,10] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound57680 : packedSelected [5,10] rootPS < 2^1333 := by decide +kernel

def env57681 : List Nat := [2,4,5,16,32,1,128,20,0,53,55,1,52,49,17,19,49,146,20,16,1,133,1,2,144,48,39,33,48,55,52,49,20,49,32,32]

theorem envBound57681 : H12AffineFastState.Bounded env57681 := by
  intro p hp
  have h : env57681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57680_57681 : H12AffineEnvironment.transform 2 5 env57680 = env57681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env57680 == env57681) = true)

theorem identity57681 : scanCanonicalize (H12AffineFastState.compose env57681 (packedSelected [2,3,4,5,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 51) := by decide +kernel

theorem selectedBound57681 : packedSelected [2,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env57682 : List Nat := [2,4,5,16,32,1,51,20,0,53,55,1,52,49,17,19,49,33,20,16,1,54,1,2,35,48,39,33,48,55,52,49,20,49,32,32]

theorem envBound57682 : H12AffineFastState.Bounded env57682 := by
  intro p hp
  have h : env57682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57681_57682 : H12AffineEnvironment.transform 6 51 env57681 = env57682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 51 env57681 == env57682) = true)

theorem identity57682 : scanCanonicalize (H12AffineFastState.compose env57682 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound57682 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env57683 : List Nat := [2,4,5,1,32,1,34,5,0,36,38,1,37,32,0,2,32,33,5,1,1,39,1,2,35,33,39,33,33,38,37,32,5,32,32,32]

theorem envBound57683 : H12AffineFastState.Bounded env57683 := by
  intro p hp
  have h : env57683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57682_57683 : H12AffineEnvironment.transform 3 1 env57682 = env57683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env57682 == env57683) = true)

theorem identity57683 : scanCanonicalize (H12AffineFastState.compose env57683 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound57683 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57684 : List Nat := [2,4,5,1,7,1,5,5,0,3,1,1,2,7,0,2,7,6,5,1,1,0,1,2,4,6,0,6,6,1,2,7,5,7,7,7]

theorem envBound57684 : H12AffineFastState.Bounded env57684 := by
  intro p hp
  have h : env57684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57683_57684 : H12AffineEnvironment.transform 4 7 env57683 = env57684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env57683 == env57684) = true)

def env57685 : List Nat := [2,4,8,16,32,1,128,256,276,1024,2048,281,1024,1296,261,1067,1029,1194,24,260,281,412,276,1314,144,1308,38,1045,1297,3128,1037,1029,256,1032,1281,1293]

theorem envBound57685 : H12AffineFastState.Bounded env57685 := by
  intro p hp
  have h : env57685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57676_57685 : H12AffineEnvironment.transform 11 281 env57676 = env57685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 281 env57676 == env57685) = true)

theorem identity57685 : scanCanonicalize (H12AffineFastState.compose env57685 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 24) := by decide +kernel

theorem selectedBound57685 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env57686 : List Nat := [2,4,8,16,32,1,128,24,12,1024,2048,1,1024,1032,29,1067,1029,1194,24,28,1,132,12,1082,144,1028,38,1045,1033,3128,1037,1029,24,1032,1049,1045]

theorem envBound57686 : H12AffineFastState.Bounded env57686 := by
  intro p hp
  have h : env57686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57685_57686 : H12AffineEnvironment.transform 7 24 env57685 = env57686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 24 env57685 == env57686) = true)

theorem identity57686 : scanCanonicalize (H12AffineFastState.compose env57686 (packedSelected [0,3,7,8,12,13,15,18] rootPS)) = affineNative (2^(9+1) ^^^ 176) := by decide +kernel

theorem selectedBound57686 : packedSelected [0,3,7,8,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env57687 : List Nat := [2,4,8,16,32,1,128,24,12,176,2048,1,176,184,29,155,181,26,24,28,1,132,12,138,144,180,38,165,185,2184,189,181,24,184,169,165]

theorem envBound57687 : H12AffineFastState.Bounded env57687 := by
  intro p hp
  have h : env57687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57686_57687 : H12AffineEnvironment.transform 9 176 env57686 = env57687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 176 env57686 == env57687) = true)

theorem identity57687 : scanCanonicalize (H12AffineFastState.compose env57687 (packedSelected [0,2,3,7,8,11,12,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 162) := by decide +kernel

theorem selectedBound57687 : packedSelected [0,2,3,7,8,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env57688 : List Nat := [2,4,8,16,32,1,128,24,12,176,162,1,176,184,29,155,181,26,24,28,1,132,12,138,144,180,38,165,185,42,189,181,24,184,169,165]

theorem envBound57688 : H12AffineFastState.Bounded env57688 := by
  intro p hp
  have h : env57688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57687_57688 : H12AffineEnvironment.transform 10 162 env57687 = env57688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 162 env57687 == env57688) = true)

theorem identity57688 : scanCanonicalize (H12AffineFastState.compose env57688 (packedSelected [0,5,7,10,11,12] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound57688 : packedSelected [0,5,7,10,11,12] rootPS < 2^1333 := by decide +kernel

def env57689 : List Nat := [2,4,8,13,32,1,128,5,12,173,162,1,173,165,0,134,168,7,5,1,1,132,12,138,141,169,38,165,164,42,160,168,5,165,169,165]

theorem envBound57689 : H12AffineFastState.Bounded env57689 := by
  intro p hp
  have h : env57689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57688_57689 : H12AffineEnvironment.transform 3 13 env57688 = env57689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env57688 == env57689) = true)

theorem identity57689 : scanCanonicalize (H12AffineFastState.compose env57689 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound57689 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env57690 : List Nat := [2,4,8,13,32,1,40,5,12,5,10,1,5,13,0,46,0,7,5,1,1,44,12,34,37,1,38,13,12,42,8,0,5,13,1,13]

theorem envBound57690 : H12AffineFastState.Bounded env57690 := by
  intro p hp
  have h : env57690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57689_57690 : H12AffineEnvironment.transform 6 40 env57689 = env57690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env57689 == env57690) = true)

theorem identity57690 : scanCanonicalize (H12AffineFastState.compose env57690 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound57690 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env57691 : List Nat := [2,4,8,13,6,1,14,5,12,5,10,1,5,13,0,8,0,7,5,1,1,10,12,4,3,1,0,13,12,12,8,0,5,13,1,13]

theorem envBound57691 : H12AffineFastState.Bounded env57691 := by
  intro p hp
  have h : env57691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57690_57691 : H12AffineEnvironment.transform 4 6 env57690 = env57691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env57690 == env57691) = true)

theorem identity57691 : scanCanonicalize (H12AffineFastState.compose env57691 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound57691 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57692 : List Nat := [2,4,5,0,6,1,3,5,1,5,7,1,5,0,0,5,0,7,5,1,1,7,1,4,3,1,0,0,1,1,5,0,5,0,1,0]

theorem envBound57692 : H12AffineFastState.Bounded env57692 := by
  intro p hp
  have h : env57692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57691_57692 : H12AffineEnvironment.transform 2 5 env57691 = env57692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env57691 == env57692) = true)

theorem identity57692 : scanCanonicalize (H12AffineFastState.compose env57692 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound57692 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57693 : List Nat := [2,1,0,0,3,1,3,0,1,0,2,1,0,0,0,0,0,2,0,1,1,2,1,1,3,1,0,0,1,1,0,0,0,0,1,0]

theorem envBound57693 : H12AffineFastState.Bounded env57693 := by
  intro p hp
  have h : env57693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57692_57693 : H12AffineEnvironment.transform 1 1 env57692 = env57693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env57692 == env57693) = true)

theorem identity57693 : scanCanonicalize (H12AffineFastState.compose env57693 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound57693 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57694 : List Nat := [0,1,0,0,1,1,1,0,1,0,0,1,0,0,0,0,0,0,0,1,1,0,1,1,1,1,0,0,1,1,0,0,0,0,1,0]

theorem envBound57694 : H12AffineFastState.Bounded env57694 := by
  intro p hp
  have h : env57694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57693_57694 : H12AffineEnvironment.transform 0 0 env57693 = env57694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env57693 == env57694) = true)

def env57695 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74863,262144,4417,13341,4096,476,74046,69649,13769,78894,332223,74815,1297,81226,8204,74798,256,8201,1344,5952]

theorem envBound57695 : H12AffineFastState.Bounded env57695 := by
  intro p hp
  have h : env57695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57540_57695 : H12AffineEnvironment.transform 13 1297 env57540 = env57695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env57540 == env57695) = true)

def env57696 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74863,65664,4417,13341,4096,476,74046,69649,13769,78894,4415,74815,1297,81226,8204,74798,256,8201,1344,5952]

theorem envBound57696 : H12AffineFastState.Bounded env57696 := by
  intro p hp
  have h : env57696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57695_57696 : H12AffineEnvironment.transform 17 65664 env57695 = env57696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env57695 == env57696) = true)

theorem identity57696 : scanCanonicalize (H12AffineFastState.compose env57696 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound57696 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57697 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1297,9293,65536,74863,65664,272,9292,81,476,74046,65600,9624,74879,366,74815,1297,77083,8204,74798,256,8201,1344,1809]

theorem envBound57697 : H12AffineFastState.Bounded env57697 := by
  intro p hp
  have h : env57697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57696_57697 : H12AffineEnvironment.transform 11 81 env57696 = env57697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env57696 == env57697) = true)

def env57698 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,81,8192,1297,9293,65536,74863,65664,272,9292,81,476,74046,65600,9624,74879,366,74815,1297,77083,8204,74798,256,8201,1344,1093]

theorem envBound57698 : H12AffineFastState.Bounded env57698 := by
  intro p hp
  have h : env57698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57697_57698 : H12AffineEnvironment.transform 8 340 env57697 = env57698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env57697 == env57698) = true)

def env57699 : List Nat := [2,4,8,16,32,0,128,256,276,1024,2048,17,8192,1297,9229,65536,74799,65664,272,9228,17,412,74046,65536,9624,74815,302,74815,1297,77083,8204,74798,256,8201,1280,1029]

theorem envBound57699 : H12AffineFastState.Bounded env57699 := by
  intro p hp
  have h : env57699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57698_57699 : H12AffineEnvironment.transform 5 0 env57698 = env57699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env57698 == env57699) = true)

theorem identity57699 : scanCanonicalize (H12AffineFastState.compose env57699 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 1176) := by decide +kernel

theorem selectedBound57699 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env57700 : List Nat := [2,4,8,16,32,0,128,256,276,1024,2048,17,1176,1297,149,65536,65719,65664,272,148,17,412,66982,65536,256,65703,302,65703,1297,67971,1172,65718,256,1169,1280,1029]

theorem envBound57700 : H12AffineFastState.Bounded env57700 := by
  intro p hp
  have h : env57700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57699_57700 : H12AffineEnvironment.transform 12 1176 env57699 = env57700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1176 env57699 == env57700) = true)

def env57701 : List Nat := [2,4,8,16,32,0,128,128,148,1024,2048,17,1176,1169,149,65536,65719,65664,144,148,17,28,66598,65536,128,65703,174,65703,1169,67587,1172,65718,128,1169,1152,1029]

theorem envBound57701 : H12AffineFastState.Bounded env57701 := by
  intro p hp
  have h : env57701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57700_57701 : H12AffineEnvironment.transform 7 128 env57700 = env57701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 128 env57700 == env57701) = true)

theorem identity57701 : scanCanonicalize (H12AffineFastState.compose env57701 (packedSelected [2,4,9,10,15,18,19,20,32] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound57701 : packedSelected [2,4,9,10,15,18,19,20,32] rootPS < 2^1333 := by decide +kernel

def env57702 : List Nat := [2,4,8,16,13,0,128,128,148,1024,2048,17,1176,1169,149,65536,65690,65664,144,148,17,28,66571,65536,128,65674,131,65674,1169,67587,1172,65691,128,1169,1152,1029]

theorem envBound57702 : H12AffineFastState.Bounded env57702 := by
  intro p hp
  have h : env57702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57701_57702 : H12AffineEnvironment.transform 4 13 env57701 = env57702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env57701 == env57702) = true)

theorem identity57702 : scanCanonicalize (H12AffineFastState.compose env57702 (packedSelected [0,3,5,7,8,10,12,13,20] rootPS)) = affineNative (2^(15+1) ^^^ 3089) := by decide +kernel

theorem selectedBound57702 : packedSelected [0,3,5,7,8,10,12,13,20] rootPS < 2^1333 := by decide +kernel

def env57703 : List Nat := [2,4,8,16,13,0,128,128,148,1024,2048,17,1176,1169,149,3089,3211,3217,144,148,17,28,2074,3089,128,3227,131,3227,1169,1042,1172,3210,128,1169,1152,1029]

theorem envBound57703 : H12AffineFastState.Bounded env57703 := by
  intro p hp
  have h : env57703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57702_57703 : H12AffineEnvironment.transform 15 3089 env57702 = env57703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3089 env57702 == env57703) = true)

theorem identity57703 : scanCanonicalize (H12AffineFastState.compose env57703 (packedSelected [1,2,3,5,8,12,16] rootPS)) = affineNative (2^(10+1) ^^^ 1164) := by decide +kernel

theorem selectedBound57703 : packedSelected [1,2,3,5,8,12,16] rootPS < 2^1333 := by decide +kernel

def env57704 : List Nat := [2,4,8,16,13,0,128,128,148,1024,1164,17,1176,1169,149,157,7,29,144,148,17,28,1174,157,128,23,131,23,1169,1042,1172,6,128,1169,1152,1029]

theorem envBound57704 : H12AffineFastState.Bounded env57704 := by
  intro p hp
  have h : env57704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57703_57704 : H12AffineEnvironment.transform 10 1164 env57703 = env57704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1164 env57703 == env57704) = true)

theorem identity57704 : scanCanonicalize (H12AffineFastState.compose env57704 (packedSelected [4,5,9] rootPS)) = affineNative (2^(9+1) ^^^ 134) := by decide +kernel

theorem selectedBound57704 : packedSelected [4,5,9] rootPS < 2^1333 := by decide +kernel

def env57705 : List Nat := [2,4,8,16,13,0,128,128,148,134,10,17,30,23,149,157,7,29,144,148,17,28,16,157,128,23,131,23,23,148,18,6,128,23,6,131]

theorem envBound57705 : H12AffineFastState.Bounded env57705 := by
  intro p hp
  have h : env57705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57704_57705 : H12AffineEnvironment.transform 9 134 env57704 = env57705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 134 env57704 == env57705) = true)

theorem identity57705 : scanCanonicalize (H12AffineFastState.compose env57705 (packedSelected [3,5] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound57705 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env57706 : List Nat := [2,4,8,12,13,0,128,128,136,134,10,13,2,11,137,129,7,1,140,136,13,0,12,129,128,11,131,11,11,136,14,6,128,11,6,131]

theorem envBound57706 : H12AffineFastState.Bounded env57706 := by
  intro p hp
  have h : env57706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57705_57706 : H12AffineEnvironment.transform 3 12 env57705 = env57706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env57705 == env57706) = true)

theorem identity57706 : scanCanonicalize (H12AffineFastState.compose env57706 (packedSelected [0,3,7] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound57706 : packedSelected [0,3,7] rootPS < 2^1333 := by decide +kernel

def env57707 : List Nat := [2,4,8,12,13,0,5,5,13,3,10,13,2,11,12,4,7,1,9,13,13,0,12,4,5,11,6,11,11,13,14,6,5,11,6,6]

theorem envBound57707 : H12AffineFastState.Bounded env57707 := by
  intro p hp
  have h : env57707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57706_57707 : H12AffineEnvironment.transform 6 5 env57706 = env57707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env57706 == env57707) = true)

theorem identity57707 : scanCanonicalize (H12AffineFastState.compose env57707 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound57707 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env57708 : List Nat := [2,4,2,6,7,0,5,5,7,3,0,7,2,1,6,4,7,1,3,7,7,0,6,4,5,1,6,1,1,7,4,6,5,1,6,6]

theorem envBound57708 : H12AffineFastState.Bounded env57708 := by
  intro p hp
  have h : env57708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57707_57708 : H12AffineEnvironment.transform 2 2 env57707 = env57708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env57707 == env57708) = true)

theorem identity57708 : scanCanonicalize (H12AffineFastState.compose env57708 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound57708 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57709 : List Nat := [2,1,2,3,2,0,0,0,2,3,0,2,2,1,3,1,2,1,3,2,2,0,3,1,0,1,3,1,1,2,1,3,0,1,3,3]

theorem envBound57709 : H12AffineFastState.Bounded env57709 := by
  intro p hp
  have h : env57709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57708_57709 : H12AffineEnvironment.transform 1 1 env57708 = env57709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env57708 == env57709) = true)

theorem identity57709 : scanCanonicalize (H12AffineFastState.compose env57709 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound57709 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57710 : List Nat := [0,1,0,1,0,0,0,0,0,1,0,0,0,1,1,1,0,1,1,0,0,0,1,1,0,1,1,1,1,0,1,1,0,1,1,1]

theorem envBound57710 : H12AffineFastState.Bounded env57710 := by
  intro p hp
  have h : env57710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57709_57710 : H12AffineEnvironment.transform 0 0 env57709 = env57710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env57709 == env57710) = true)

def env57711 : List Nat := [2,4,8,16,32,0,128,129,149,1024,2048,17,1176,1168,149,65536,65719,65664,145,148,17,29,66599,65536,129,65703,175,65703,1168,67586,1172,65718,129,1169,1153,1029]

theorem envBound57711 : H12AffineFastState.Bounded env57711 := by
  intro p hp
  have h : env57711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57700_57711 : H12AffineEnvironment.transform 7 129 env57700 = env57711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 129 env57700 == env57711) = true)

theorem identity57711 : scanCanonicalize (H12AffineFastState.compose env57711 (packedSelected [1,3,5,7,8,10,19,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 144) := by decide +kernel

theorem selectedBound57711 : packedSelected [1,3,5,7,8,10,19,20,27] rootPS < 2^1333 := by decide +kernel

def env57712 : List Nat := [2,4,8,16,32,0,128,129,149,144,2048,17,8,0,149,65536,65719,65664,145,148,17,29,65719,65536,129,65703,175,65703,0,67586,4,65718,129,1,17,149]

theorem envBound57712 : H12AffineFastState.Bounded env57712 := by
  intro p hp
  have h : env57712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57711_57712 : H12AffineEnvironment.transform 9 144 env57711 = env57712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 144 env57711 == env57712) = true)

theorem identity57712 : scanCanonicalize (H12AffineFastState.compose env57712 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 51) := by decide +kernel

theorem selectedBound57712 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env57713 : List Nat := [2,4,8,16,32,0,128,129,149,144,2048,17,8,0,149,51,132,179,145,148,17,29,132,51,129,148,175,148,0,2097,4,133,129,1,17,149]

theorem envBound57713 : H12AffineFastState.Bounded env57713 := by
  intro p hp
  have h : env57713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57712_57713 : H12AffineEnvironment.transform 15 51 env57712 = env57713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 51 env57712 == env57713) = true)

theorem identity57713 : scanCanonicalize (H12AffineFastState.compose env57713 (packedSelected [0,1,2,3,7,8,10,11,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 36) := by decide +kernel

theorem selectedBound57713 : packedSelected [0,1,2,3,7,8,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env57714 : List Nat := [2,4,8,16,32,0,36,37,49,52,2048,17,8,0,49,51,32,23,53,48,17,29,32,51,37,48,11,48,0,2097,4,33,37,1,17,49]

theorem envBound57714 : H12AffineFastState.Bounded env57714 := by
  intro p hp
  have h : env57714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57713_57714 : H12AffineEnvironment.transform 6 36 env57713 = env57714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 36 env57713 == env57714) = true)

theorem identity57714 : scanCanonicalize (H12AffineFastState.compose env57714 (packedSelected [0,3,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 61) := by decide +kernel

theorem selectedBound57714 : packedSelected [0,3,8,10] rootPS < 2^1333 := by decide +kernel

def env57715 : List Nat := [2,4,8,16,32,0,36,37,49,52,61,17,8,0,49,51,32,23,53,48,17,29,32,51,37,48,11,48,0,12,4,33,37,1,17,49]

theorem envBound57715 : H12AffineFastState.Bounded env57715 := by
  intro p hp
  have h : env57715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57714_57715 : H12AffineEnvironment.transform 10 61 env57714 = env57715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 61 env57714 == env57715) = true)

theorem identity57715 : scanCanonicalize (H12AffineFastState.compose env57715 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 29) := by decide +kernel

theorem selectedBound57715 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57716 : List Nat := [2,4,8,16,29,0,25,24,12,9,0,17,8,0,12,14,29,23,8,13,17,29,29,14,24,13,11,13,0,12,4,28,24,1,17,12]

theorem envBound57716 : H12AffineFastState.Bounded env57716 := by
  intro p hp
  have h : env57716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57715_57716 : H12AffineEnvironment.transform 4 29 env57715 = env57716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env57715 == env57716) = true)

theorem identity57716 : scanCanonicalize (H12AffineFastState.compose env57716 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound57716 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57717 : List Nat := [2,4,8,1,12,0,8,9,12,9,0,0,8,0,12,14,12,6,8,13,0,12,12,14,9,13,11,13,0,12,4,13,9,1,0,12]

theorem envBound57717 : H12AffineFastState.Bounded env57717 := by
  intro p hp
  have h : env57717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57716_57717 : H12AffineEnvironment.transform 3 1 env57716 = env57717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env57716 == env57717) = true)

def env57718 : List Nat := [2,4,8,16,32,1,128,256,277,1024,2048,16,8192,1297,9228,65536,74798,65664,272,9229,16,413,74046,65537,9624,74814,303,74815,1297,77083,8204,74798,256,8201,1281,1028]

theorem envBound57718 : H12AffineFastState.Bounded env57718 := by
  intro p hp
  have h : env57718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57698_57718 : H12AffineEnvironment.transform 5 1 env57698 = env57718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env57698 == env57718) = true)

theorem identity57718 : scanCanonicalize (H12AffineFastState.compose env57718 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 145) := by decide +kernel

theorem selectedBound57718 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env57719 : List Nat := [2,4,8,16,32,1,128,145,132,1024,2048,16,8192,1152,9228,65536,74798,65664,129,9229,16,12,73903,65537,9225,74814,190,74815,1152,76938,8204,74798,145,8201,1168,1028]

theorem envBound57719 : H12AffineFastState.Bounded env57719 := by
  intro p hp
  have h : env57719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57718_57719 : H12AffineEnvironment.transform 7 145 env57718 = env57719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 145 env57718 == env57719) = true)

def env57720 : List Nat := [2,4,8,16,32,1,128,145,132,1024,2048,16,1160,1152,132,65536,65702,65664,129,133,16,12,66599,65537,129,65718,190,65719,1152,67586,1156,65702,145,1153,1168,1028]

theorem envBound57720 : H12AffineFastState.Bounded env57720 := by
  intro p hp
  have h : env57720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57719_57720 : H12AffineEnvironment.transform 12 1160 env57719 = env57720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1160 env57719 == env57720) = true)

theorem identity57720 : scanCanonicalize (H12AffineFastState.compose env57720 (packedSelected [2,4,9,10,15,18,19,20,32] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound57720 : packedSelected [2,4,9,10,15,18,19,20,32] rootPS < 2^1333 := by decide +kernel

def env57721 : List Nat := [2,4,8,16,28,1,128,145,132,1024,2048,16,1160,1152,132,65536,65690,65664,129,133,16,12,66587,65537,129,65674,130,65675,1152,67586,1156,65690,145,1153,1168,1028]

theorem envBound57721 : H12AffineFastState.Bounded env57721 := by
  intro p hp
  have h : env57721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57720_57721 : H12AffineEnvironment.transform 4 28 env57720 = env57721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env57720 == env57721) = true)

theorem identity57721 : scanCanonicalize (H12AffineFastState.compose env57721 (packedSelected [0,3,5,7,8,10,12,13,20] rootPS)) = affineNative (2^(15+1) ^^^ 3073) := by decide +kernel

theorem selectedBound57721 : packedSelected [0,3,5,7,8,10,12,13,20] rootPS < 2^1333 := by decide +kernel

def env57722 : List Nat := [2,4,8,16,28,1,128,145,132,1024,2048,16,1160,1152,132,3073,3227,3201,129,133,16,12,2074,3072,129,3211,130,3210,1152,1027,1156,3227,145,1153,1168,1028]

theorem envBound57722 : H12AffineFastState.Bounded env57722 := by
  intro p hp
  have h : env57722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57721_57722 : H12AffineEnvironment.transform 15 3073 env57721 = env57722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3073 env57721 == env57722) = true)

theorem identity57722 : scanCanonicalize (H12AffineFastState.compose env57722 (packedSelected [1,2,3,5,8,12,16] rootPS)) = affineNative (2^(6+1) ^^^ 30) := by decide +kernel

theorem selectedBound57722 : packedSelected [1,2,3,5,8,12,16] rootPS < 2^1333 := by decide +kernel

def env57723 : List Nat := [2,4,8,16,28,1,30,15,26,1024,2048,16,1046,1054,26,3073,3077,3103,31,27,16,12,2074,3072,31,3093,28,3092,1054,1027,1050,3077,15,1055,1038,1028]

theorem envBound57723 : H12AffineFastState.Bounded env57723 := by
  intro p hp
  have h : env57723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57722_57723 : H12AffineEnvironment.transform 6 30 env57722 = env57723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 30 env57722 == env57723) = true)

theorem identity57723 : scanCanonicalize (H12AffineFastState.compose env57723 (packedSelected [2,3,7,8,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1028) := by decide +kernel

theorem selectedBound57723 : packedSelected [2,3,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env57724 : List Nat := [2,4,8,16,28,1,30,15,26,1024,1028,16,1046,1054,26,5,1,27,31,27,16,12,1054,4,31,17,28,16,1054,1027,1050,1,15,1055,1038,1028]

theorem envBound57724 : H12AffineFastState.Bounded env57724 := by
  intro p hp
  have h : env57724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57723_57724 : H12AffineEnvironment.transform 10 1028 env57723 = env57724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1028 env57723 == env57724) = true)

theorem identity57724 : scanCanonicalize (H12AffineFastState.compose env57724 (packedSelected [1,2,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound57724 : packedSelected [1,2,5,8] rootPS < 2^1333 := by decide +kernel

def env57725 : List Nat := [2,4,8,16,28,1,30,15,26,21,17,16,3,11,26,5,1,27,31,27,16,12,11,4,31,17,28,16,11,22,15,1,15,10,27,17]

theorem envBound57725 : H12AffineFastState.Bounded env57725 := by
  intro p hp
  have h : env57725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57724_57725 : H12AffineEnvironment.transform 9 21 env57724 = env57725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env57724 == env57725) = true)

theorem identity57725 : scanCanonicalize (H12AffineFastState.compose env57725 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound57725 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env57726 : List Nat := [2,4,8,0,12,1,14,15,10,5,1,0,3,11,10,5,1,11,15,11,0,12,11,4,15,1,12,0,11,6,15,1,15,10,11,1]

theorem envBound57726 : H12AffineFastState.Bounded env57726 := by
  intro p hp
  have h : env57726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57725_57726 : H12AffineEnvironment.transform 3 0 env57725 = env57726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env57725 == env57726) = true)

theorem identity57726 : scanCanonicalize (H12AffineFastState.compose env57726 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound57726 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57727 : List Nat := [2,4,3,0,7,1,5,4,1,5,1,0,3,0,1,5,1,0,4,0,0,7,0,4,4,1,7,0,0,6,4,1,4,1,0,1]

theorem envBound57727 : H12AffineFastState.Bounded env57727 := by
  intro p hp
  have h : env57727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57726_57727 : H12AffineEnvironment.transform 2 3 env57726 = env57727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env57726 == env57727) = true)

theorem identity57727 : scanCanonicalize (H12AffineFastState.compose env57727 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound57727 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57728 : List Nat := [2,3,3,0,0,1,2,3,1,2,1,0,3,0,1,2,1,0,3,0,0,0,0,3,3,1,0,0,0,1,3,1,3,1,0,1]

theorem envBound57728 : H12AffineFastState.Bounded env57728 := by
  intro p hp
  have h : env57728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57727_57728 : H12AffineEnvironment.transform 1 3 env57727 = env57728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env57727 == env57728) = true)

def env57729 : List Nat := [2,4,8,16,32,1,128,145,132,1024,2048,16,1161,1152,133,65536,65703,65664,129,132,16,12,66598,65537,128,65719,190,65718,1152,67587,1157,65703,145,1152,1168,1028]

theorem envBound57729 : H12AffineFastState.Bounded env57729 := by
  intro p hp
  have h : env57729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57719_57729 : H12AffineEnvironment.transform 12 1161 env57719 = env57729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1161 env57719 == env57729) = true)

theorem identity57729 : scanCanonicalize (H12AffineFastState.compose env57729 (packedSelected [1,3,5,7,8,10,19,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 128) := by decide +kernel

theorem selectedBound57729 : packedSelected [1,3,5,7,8,10,19,20,27] rootPS < 2^1333 := by decide +kernel

def env57730 : List Nat := [2,4,8,16,32,1,128,145,132,128,2048,16,9,0,133,65536,65703,65664,129,132,16,12,65702,65537,128,65719,190,65718,0,67587,5,65703,145,0,16,132]

theorem envBound57730 : H12AffineFastState.Bounded env57730 := by
  intro p hp
  have h : env57730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57729_57730 : H12AffineEnvironment.transform 9 128 env57729 = env57730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 128 env57729 == env57730) = true)

theorem identity57730 : scanCanonicalize (H12AffineFastState.compose env57730 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 50) := by decide +kernel

theorem selectedBound57730 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env57731 : List Nat := [2,4,8,16,32,1,128,145,132,128,2048,16,9,0,133,50,149,178,129,132,16,12,148,51,128,133,190,132,0,2097,5,149,145,0,16,132]

theorem envBound57731 : H12AffineFastState.Bounded env57731 := by
  intro p hp
  have h : env57731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57730_57731 : H12AffineEnvironment.transform 15 50 env57730 = env57731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50 env57730 == env57731) = true)

theorem identity57731 : scanCanonicalize (H12AffineFastState.compose env57731 (packedSelected [0,1,2,3,7,8,10,11,12,15] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound57731 : packedSelected [0,1,2,3,7,8,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env57732 : List Nat := [2,4,8,16,16,1,128,145,132,128,2048,16,9,0,133,2,149,130,129,132,16,12,148,3,128,133,142,132,0,2049,5,149,145,0,16,132]

theorem envBound57732 : H12AffineFastState.Bounded env57732 := by
  intro p hp
  have h : env57732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57731_57732 : H12AffineEnvironment.transform 4 16 env57731 = env57732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env57731 == env57732) = true)

theorem identity57732 : scanCanonicalize (H12AffineFastState.compose env57732 (packedSelected [1,3,7,8,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound57732 : packedSelected [1,3,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env57733 : List Nat := [2,4,8,16,16,1,19,2,23,19,2048,16,9,0,22,2,6,17,18,23,16,12,7,3,19,22,29,23,0,2049,5,6,2,0,16,23]

theorem envBound57733 : H12AffineFastState.Bounded env57733 := by
  intro p hp
  have h : env57733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57732_57733 : H12AffineEnvironment.transform 6 19 env57732 = env57733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env57732 == env57733) = true)

theorem identity57733 : scanCanonicalize (H12AffineFastState.compose env57733 (packedSelected [1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 28) := by decide +kernel

theorem selectedBound57733 : packedSelected [1,4,5] rootPS < 2^1333 := by decide +kernel

def env57734 : List Nat := [2,4,8,16,16,1,19,2,23,19,28,16,9,0,22,2,6,17,18,23,16,12,7,3,19,22,29,23,0,29,5,6,2,0,16,23]

theorem envBound57734 : H12AffineFastState.Bounded env57734 := by
  intro p hp
  have h : env57734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57733_57734 : H12AffineEnvironment.transform 10 28 env57733 = env57734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 28 env57733 == env57734) = true)

theorem identity57734 : scanCanonicalize (H12AffineFastState.compose env57734 (packedSelected [0,1,2] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound57734 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env57735 : List Nat := [2,4,8,7,7,1,4,2,0,4,11,7,9,0,1,2,6,6,5,0,7,12,7,3,4,1,10,0,0,10,5,6,2,0,7,0]

theorem envBound57735 : H12AffineFastState.Bounded env57735 := by
  intro p hp
  have h : env57735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57734_57735 : H12AffineEnvironment.transform 3 7 env57734 = env57735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env57734 == env57735) = true)

theorem identity57735 : scanCanonicalize (H12AffineFastState.compose env57735 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound57735 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57736 : List Nat := [2,4,2,7,7,1,4,2,0,4,1,7,3,0,1,2,6,6,5,0,7,6,7,3,4,1,0,0,0,0,5,6,2,0,7,0]

theorem envBound57736 : H12AffineFastState.Bounded env57736 := by
  intro p hp
  have h : env57736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57735_57736 : H12AffineEnvironment.transform 2 2 env57735 = env57736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env57735 == env57736) = true)

def env57737 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,81,8192,1297,9293,65536,74863,65664,272,9292,81,476,74046,65600,9624,74879,366,74815,1297,77083,8204,74798,256,8201,1344,1092]

theorem envBound57737 : H12AffineFastState.Bounded env57737 := by
  intro p hp
  have h : env57737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57697_57737 : H12AffineEnvironment.transform 8 341 env57697 = env57737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env57697 == env57737) = true)

def env57738 : List Nat := [2,4,8,16,32,0,128,256,277,1024,2048,17,8192,1297,9229,65536,74799,65664,272,9228,17,412,74046,65536,9624,74815,302,74815,1297,77083,8204,74798,256,8201,1280,1028]

theorem envBound57738 : H12AffineFastState.Bounded env57738 := by
  intro p hp
  have h : env57738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57737_57738 : H12AffineEnvironment.transform 5 0 env57737 = env57738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env57737 == env57738) = true)

theorem identity57738 : scanCanonicalize (H12AffineFastState.compose env57738 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 1463) := by decide +kernel

theorem selectedBound57738 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env57739 : List Nat := [2,4,8,16,32,0,128,256,277,1024,2048,17,8192,1297,9229,1463,8600,1335,272,9228,17,412,9353,1463,9624,8584,302,8584,1297,10412,8204,8601,256,8201,1280,1028]

theorem envBound57739 : H12AffineFastState.Bounded env57739 := by
  intro p hp
  have h : env57739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57738_57739 : H12AffineEnvironment.transform 15 1463 env57738 = env57739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1463 env57738 == env57739) = true)

def env57740 : List Nat := [2,4,8,16,32,0,128,256,277,1024,2048,17,1160,1297,133,1463,1296,1335,272,132,17,412,1,1463,272,1280,302,1280,1297,3108,1156,1297,256,1153,1280,1028]

theorem envBound57740 : H12AffineFastState.Bounded env57740 := by
  intro p hp
  have h : env57740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57739_57740 : H12AffineEnvironment.transform 12 1160 env57739 = env57740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1160 env57739 == env57740) = true)

theorem identity57740 : scanCanonicalize (H12AffineFastState.compose env57740 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 388) := by decide +kernel

theorem selectedBound57740 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env57741 : List Nat := [2,4,8,16,32,0,128,256,277,388,2048,17,268,149,133,51,148,179,272,132,17,412,1,51,272,132,302,132,149,2464,256,149,256,261,132,384]

theorem envBound57741 : H12AffineFastState.Bounded env57741 := by
  intro p hp
  have h : env57741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57740_57741 : H12AffineEnvironment.transform 9 388 env57740 = env57741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 388 env57740 == env57741) = true)

theorem identity57741 : scanCanonicalize (H12AffineFastState.compose env57741 (packedSelected [10,12,15,18,19,20,21] rootPS)) = affineNative (2^(10+1) ^^^ 312) := by decide +kernel

theorem selectedBound57741 : packedSelected [10,12,15,18,19,20,21] rootPS < 2^1333 := by decide +kernel

def env57742 : List Nat := [2,4,8,16,32,0,128,256,277,388,312,17,268,149,133,51,148,179,272,132,17,412,1,51,272,132,302,132,149,152,256,149,256,261,132,384]

theorem envBound57742 : H12AffineFastState.Bounded env57742 := by
  intro p hp
  have h : env57742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57741_57742 : H12AffineEnvironment.transform 10 312 env57741 = env57742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 312 env57741 == env57742) = true)

theorem identity57742 : scanCanonicalize (H12AffineFastState.compose env57742 (packedSelected [0,3,7,10,11,13,15] rootPS)) = affineNative (2^(7+1) ^^^ 171) := by decide +kernel

theorem selectedBound57742 : packedSelected [0,3,7,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env57743 : List Nat := [2,4,8,16,32,0,128,171,190,47,147,17,167,149,133,51,148,179,187,132,17,55,1,51,187,132,133,132,149,152,171,149,171,174,132,43]

theorem envBound57743 : H12AffineFastState.Bounded env57743 := by
  intro p hp
  have h : env57743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57742_57743 : H12AffineEnvironment.transform 7 171 env57742 = env57743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 171 env57742 == env57743) = true)

theorem identity57743 : scanCanonicalize (H12AffineFastState.compose env57743 (packedSelected [2,4,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound57743 : packedSelected [2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env57744 : List Nat := [2,4,8,16,0,0,128,139,158,15,147,17,135,149,133,19,148,147,155,132,17,23,1,19,155,132,133,132,149,152,139,149,139,142,132,11]

theorem envBound57744 : H12AffineFastState.Bounded env57744 := by
  intro p hp
  have h : env57744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57743_57744 : H12AffineEnvironment.transform 4 0 env57743 = env57744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env57743 == env57744) = true)

theorem identity57744 : scanCanonicalize (H12AffineFastState.compose env57744 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound57744 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env57745 : List Nat := [2,4,8,16,0,0,8,3,22,15,27,17,15,29,13,19,28,27,19,12,17,23,1,19,19,12,13,12,29,16,3,29,3,6,12,11]

theorem envBound57745 : H12AffineFastState.Bounded env57745 := by
  intro p hp
  have h : env57745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57744_57745 : H12AffineEnvironment.transform 6 8 env57744 = env57745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env57744 == env57745) = true)

theorem identity57745 : scanCanonicalize (H12AffineFastState.compose env57745 (packedSelected [1,2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound57745 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env57746 : List Nat := [2,3,8,16,0,0,8,3,17,8,27,17,8,26,10,19,27,27,19,11,17,16,1,19,19,11,10,11,26,16,3,26,3,1,11,11]

theorem envBound57746 : H12AffineFastState.Bounded env57746 := by
  intro p hp
  have h : env57746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57745_57746 : H12AffineEnvironment.transform 1 3 env57745 = env57746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env57745 == env57746) = true)

theorem identity57746 : scanCanonicalize (H12AffineFastState.compose env57746 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound57746 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57747 : List Nat := [2,3,8,1,0,0,8,3,0,8,10,0,8,11,10,2,10,10,2,11,0,1,1,2,2,11,10,11,11,1,3,11,3,1,11,11]

theorem envBound57747 : H12AffineFastState.Bounded env57747 := by
  intro p hp
  have h : env57747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57746_57747 : H12AffineEnvironment.transform 3 1 env57746 = env57747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env57746 == env57747) = true)

theorem identity57747 : scanCanonicalize (H12AffineFastState.compose env57747 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound57747 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env57748 : List Nat := [2,3,3,1,0,0,3,3,0,3,1,0,3,0,1,2,1,1,2,0,0,1,1,2,2,0,1,0,0,1,3,0,3,1,0,0]

theorem envBound57748 : H12AffineFastState.Bounded env57748 := by
  intro p hp
  have h : env57748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57747_57748 : H12AffineEnvironment.transform 2 3 env57747 = env57748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env57747 == env57748) = true)

def env57749 : List Nat := [2,4,8,16,32,0,128,256,277,1024,2048,17,1161,1297,132,1463,1297,1335,272,133,17,412,0,1463,273,1281,302,1281,1297,3109,1157,1296,256,1152,1280,1028]

theorem envBound57749 : H12AffineFastState.Bounded env57749 := by
  intro p hp
  have h : env57749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57739_57749 : H12AffineEnvironment.transform 12 1161 env57739 = env57749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1161 env57739 == env57749) = true)

theorem identity57749 : scanCanonicalize (H12AffineFastState.compose env57749 (packedSelected [4,9,16] rootPS)) = affineNative (2^(6+1) ^^^ 21) := by decide +kernel

theorem selectedBound57749 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env57750 : List Nat := [2,4,8,16,32,0,21,256,277,1024,2048,17,1052,1297,17,1314,1297,1335,272,16,17,265,0,1314,273,1281,302,1281,1297,3109,1040,1296,256,1045,1280,1028]

theorem envBound57750 : H12AffineFastState.Bounded env57750 := by
  intro p hp
  have h : env57750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57749_57750 : H12AffineEnvironment.transform 6 21 env57749 = env57750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 21 env57749 == env57750) = true)

theorem identity57750 : scanCanonicalize (H12AffineFastState.compose env57750 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound57750 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env57751 : List Nat := [2,4,8,16,32,0,21,256,277,272,2048,17,268,1,17,50,1,39,272,16,17,265,0,50,273,17,302,17,1,2357,256,0,256,261,16,276]

theorem envBound57751 : H12AffineFastState.Bounded env57751 := by
  intro p hp
  have h : env57751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57750_57751 : H12AffineEnvironment.transform 9 272 env57750 = env57751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env57750 == env57751) = true)

theorem identity57751 : scanCanonicalize (H12AffineFastState.compose env57751 (packedSelected [0,1,5,7,8,10,11,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound57751 : packedSelected [0,1,5,7,8,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env57752 : List Nat := [2,4,8,16,32,0,21,21,0,5,2048,17,25,1,17,50,1,39,5,16,17,28,0,50,4,17,59,17,1,2080,21,0,21,16,16,1]

theorem envBound57752 : H12AffineFastState.Bounded env57752 := by
  intro p hp
  have h : env57752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57751_57752 : H12AffineEnvironment.transform 7 21 env57751 = env57752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env57751 == env57752) = true)

theorem identity57752 : scanCanonicalize (H12AffineFastState.compose env57752 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound57752 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57753 : List Nat := [2,4,8,16,32,0,21,21,0,5,17,17,25,1,17,50,1,39,5,16,17,28,0,50,4,17,59,17,1,49,21,0,21,16,16,1]

theorem envBound57753 : H12AffineFastState.Bounded env57753 := by
  intro p hp
  have h : env57753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57752_57753 : H12AffineEnvironment.transform 10 17 env57752 = env57753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env57752 == env57753) = true)

theorem identity57753 : scanCanonicalize (H12AffineFastState.compose env57753 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound57753 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env57754 : List Nat := [2,4,8,16,26,0,21,21,0,5,17,17,25,1,17,8,1,29,5,16,17,28,0,8,4,17,1,17,1,11,21,0,21,16,16,1]

theorem envBound57754 : H12AffineFastState.Bounded env57754 := by
  intro p hp
  have h : env57754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57753_57754 : H12AffineEnvironment.transform 4 26 env57753 = env57754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env57753 == env57754) = true)

theorem identity57754 : scanCanonicalize (H12AffineFastState.compose env57754 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound57754 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env57755 : List Nat := [2,4,8,6,12,0,3,3,0,5,7,7,15,1,7,8,1,11,5,6,7,10,0,8,4,7,1,7,1,11,3,0,3,6,6,1]

theorem envBound57755 : H12AffineFastState.Bounded env57755 := by
  intro p hp
  have h : env57755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57754_57755 : H12AffineEnvironment.transform 3 6 env57754 = env57755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env57754 == env57755) = true)

theorem identity57755 : scanCanonicalize (H12AffineFastState.compose env57755 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound57755 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57756 : List Nat := [2,4,0,6,4,0,3,3,0,5,7,7,7,1,7,0,1,3,5,6,7,2,0,0,4,7,1,7,1,3,3,0,3,6,6,1]

theorem envBound57756 : H12AffineFastState.Bounded env57756 := by
  intro p hp
  have h : env57756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57755_57756 : H12AffineEnvironment.transform 2 0 env57755 = env57756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env57755 == env57756) = true)

theorem identity57756 : scanCanonicalize (H12AffineFastState.compose env57756 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound57756 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env57757 : List Nat := [1,4,0,5,4,0,0,0,0,5,4,4,4,1,4,0,1,0,5,5,4,1,0,0,4,4,1,4,1,0,0,0,0,5,5,1]

theorem envBound57757 : H12AffineFastState.Bounded env57757 := by
  intro p hp
  have h : env57757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57756_57757 : H12AffineEnvironment.transform 0 1 env57756 = env57757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env57756 == env57757) = true)

theorem identity57757 : scanCanonicalize (H12AffineFastState.compose env57757 (packedSelected [7] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound57757 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env57758 : List Nat := [1,0,0,1,0,0,0,0,0,1,0,0,0,1,0,0,1,0,1,1,0,1,0,0,0,0,1,0,1,0,0,0,0,1,1,1]

theorem envBound57758 : H12AffineFastState.Bounded env57758 := by
  intro p hp
  have h : env57758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57757_57758 : H12AffineEnvironment.transform 1 0 env57757 = env57758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env57757 == env57758) = true)

def env57759 : List Nat := [2,4,8,16,32,1,128,256,276,1024,2048,16,8192,1297,9228,65536,74798,65664,272,9229,16,413,74046,65537,9624,74814,303,74815,1297,77083,8204,74798,256,8201,1281,1029]

theorem envBound57759 : H12AffineFastState.Bounded env57759 := by
  intro p hp
  have h : env57759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57737_57759 : H12AffineEnvironment.transform 5 1 env57737 = env57759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env57737 == env57759) = true)

theorem identity57759 : scanCanonicalize (H12AffineFastState.compose env57759 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8382) := by decide +kernel

theorem selectedBound57759 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env57760 : List Nat := [2,4,8,16,32,1,128,256,276,1024,2048,16,8192,1297,9228,8382,1168,8254,272,9229,16,413,384,8383,9624,1152,303,1153,1297,3493,8204,1168,256,8201,1281,1029]

theorem envBound57760 : H12AffineFastState.Bounded env57760 := by
  intro p hp
  have h : env57760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57759_57760 : H12AffineEnvironment.transform 15 8382 env57759 = env57760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8382 env57759 == env57760) = true)

def env57761 : List Nat := [2,4,8,16,32,1,128,128,148,1024,2048,16,8192,1169,9228,8382,1168,8254,144,9229,16,29,0,8383,9240,1152,175,1153,1169,3109,8204,1168,128,8201,1153,1029]

theorem envBound57761 : H12AffineFastState.Bounded env57761 := by
  intro p hp
  have h : env57761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57760_57761 : H12AffineEnvironment.transform 7 128 env57760 = env57761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 128 env57760 == env57761) = true)

theorem identity57761 : scanCanonicalize (H12AffineFastState.compose env57761 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 140) := by decide +kernel

theorem selectedBound57761 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env57762 : List Nat := [2,4,8,16,32,1,128,128,148,1024,2048,16,140,1169,1152,50,1168,178,144,1153,16,29,0,51,1172,1152,175,1153,1169,3109,128,1168,128,133,1153,1029]

theorem envBound57762 : H12AffineFastState.Bounded env57762 := by
  intro p hp
  have h : env57762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57761_57762 : H12AffineEnvironment.transform 12 140 env57761 = env57762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 140 env57761 == env57762) = true)

theorem identity57762 : scanCanonicalize (H12AffineFastState.compose env57762 (packedSelected [10,12,15,18,19,20,21] rootPS)) = affineNative (2^(10+1) ^^^ 1213) := by decide +kernel

theorem selectedBound57762 : packedSelected [10,12,15,18,19,20,21] rootPS < 2^1333 := by decide +kernel

def env57763 : List Nat := [2,4,8,16,32,1,128,128,148,1024,1213,16,140,1169,1152,50,1168,178,144,1153,16,29,0,51,1172,1152,175,1153,1169,152,128,1168,128,133,1153,1029]

theorem envBound57763 : H12AffineFastState.Bounded env57763 := by
  intro p hp
  have h : env57763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57762_57763 : H12AffineEnvironment.transform 10 1213 env57762 = env57763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1213 env57762 == env57763) = true)

theorem identity57763 : scanCanonicalize (H12AffineFastState.compose env57763 (packedSelected [0,3,7,10,11,13,15] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound57763 : packedSelected [0,3,7,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env57764 : List Nat := [2,4,8,16,10,1,128,128,148,1024,1175,16,140,1169,1152,24,1168,152,144,1153,16,29,0,25,1172,1152,133,1153,1169,152,128,1168,128,133,1153,1029]

theorem envBound57764 : H12AffineFastState.Bounded env57764 := by
  intro p hp
  have h : env57764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57763_57764 : H12AffineEnvironment.transform 4 10 env57763 = env57764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env57763 == env57764) = true)

theorem identity57764 : scanCanonicalize (H12AffineFastState.compose env57764 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 150) := by decide +kernel

theorem selectedBound57764 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env57765 : List Nat := [2,4,8,16,10,1,128,128,148,150,1,16,140,7,22,24,6,152,144,23,16,29,0,25,2,22,133,23,7,152,128,6,128,133,23,147]

theorem envBound57765 : H12AffineFastState.Bounded env57765 := by
  intro p hp
  have h : env57765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57764_57765 : H12AffineEnvironment.transform 9 150 env57764 = env57765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 150 env57764 == env57765) = true)

theorem identity57765 : scanCanonicalize (H12AffineFastState.compose env57765 (packedSelected [0,2,5,7] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound57765 : packedSelected [0,2,5,7] rootPS < 2^1333 := by decide +kernel

def env57766 : List Nat := [2,2,8,16,10,1,128,128,146,144,1,16,138,1,16,24,0,152,144,17,16,27,0,25,2,16,131,17,1,152,128,0,128,131,17,147]

theorem envBound57766 : H12AffineFastState.Bounded env57766 := by
  intro p hp
  have h : env57766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57765_57766 : H12AffineEnvironment.transform 1 2 env57765 = env57766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env57765 == env57766) = true)

theorem identity57766 : scanCanonicalize (H12AffineFastState.compose env57766 (packedSelected [0,2] rootPS)) = affineNative (2^(6+1) ^^^ 16) := by decide +kernel

theorem selectedBound57766 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env57767 : List Nat := [2,2,8,16,10,1,16,16,2,0,1,16,26,1,16,24,0,8,0,17,16,27,0,25,2,16,19,17,1,8,16,0,16,19,17,3]

theorem envBound57767 : H12AffineFastState.Bounded env57767 := by
  intro p hp
  have h : env57767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57766_57767 : H12AffineEnvironment.transform 6 16 env57766 = env57767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 16 env57766 == env57767) = true)

theorem identity57767 : scanCanonicalize (H12AffineFastState.compose env57767 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound57767 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env57768 : List Nat := [2,2,8,3,10,1,3,3,2,0,1,3,9,1,3,11,0,8,0,2,3,8,0,10,2,3,0,2,1,8,3,0,3,0,2,3]

theorem envBound57768 : H12AffineFastState.Bounded env57768 := by
  intro p hp
  have h : env57768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57767_57768 : H12AffineEnvironment.transform 3 3 env57767 = env57768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env57767 == env57768) = true)

theorem identity57768 : scanCanonicalize (H12AffineFastState.compose env57768 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound57768 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env57769 : List Nat := [2,2,2,3,0,1,3,3,2,0,1,3,3,1,3,1,0,2,0,2,3,2,0,0,2,3,0,2,1,2,3,0,3,0,2,3]

theorem envBound57769 : H12AffineFastState.Bounded env57769 := by
  intro p hp
  have h : env57769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57768_57769 : H12AffineEnvironment.transform 2 2 env57768 = env57769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env57768 == env57769) = true)

def env57770 : List Nat := [2,4,8,16,32,1,128,129,149,1024,2048,16,8192,1168,9228,8382,1168,8254,145,9229,16,28,1,8383,9241,1152,174,1153,1168,3108,8204,1168,129,8201,1152,1029]

theorem envBound57770 : H12AffineFastState.Bounded env57770 := by
  intro p hp
  have h : env57770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57760_57770 : H12AffineEnvironment.transform 7 129 env57760 = env57770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 129 env57760 == env57770) = true)

theorem identity57770 : scanCanonicalize (H12AffineFastState.compose env57770 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound57770 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env57771 : List Nat := [2,4,8,16,32,1,128,129,149,1024,2048,16,1052,1168,16,1186,1168,1058,145,17,16,28,1,1187,5,1152,174,1153,1168,3108,1040,1168,129,1045,1152,1029]

theorem envBound57771 : H12AffineFastState.Bounded env57771 := by
  intro p hp
  have h : env57771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57770_57771 : H12AffineEnvironment.transform 12 1052 env57770 = env57771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env57770 == env57771) = true)

theorem identity57771 : scanCanonicalize (H12AffineFastState.compose env57771 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 145) := by decide +kernel

theorem selectedBound57771 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env57772 : List Nat := [2,4,8,16,32,1,128,129,149,145,2048,16,141,1,16,51,1,179,145,17,16,28,1,50,5,17,174,16,1,2229,129,1,129,132,17,148]

theorem envBound57772 : H12AffineFastState.Bounded env57772 := by
  intro p hp
  have h : env57772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57771_57772 : H12AffineEnvironment.transform 9 145 env57771 = env57772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 145 env57771 == env57772) = true)

theorem identity57772 : scanCanonicalize (H12AffineFastState.compose env57772 (packedSelected [0,1,5,7,8,10,11,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound57772 : packedSelected [0,1,5,7,8,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env57773 : List Nat := [2,4,8,16,32,1,4,5,17,21,2048,16,9,1,16,51,1,55,21,17,16,28,1,50,5,17,42,16,1,2097,5,1,5,0,17,16]

theorem envBound57773 : H12AffineFastState.Bounded env57773 := by
  intro p hp
  have h : env57773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57772_57773 : H12AffineEnvironment.transform 6 4 env57772 = env57773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env57772 == env57773) = true)

theorem identity57773 : scanCanonicalize (H12AffineFastState.compose env57773 (packedSelected [2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound57773 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env57774 : List Nat := [2,4,8,16,26,1,4,5,17,21,2048,16,9,1,16,9,1,13,21,17,16,28,1,8,5,17,16,16,1,2059,5,1,5,0,17,16]

theorem envBound57774 : H12AffineFastState.Bounded env57774 := by
  intro p hp
  have h : env57774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57773_57774 : H12AffineEnvironment.transform 4 26 env57773 = env57774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env57773 == env57774) = true)

theorem identity57774 : scanCanonicalize (H12AffineFastState.compose env57774 (packedSelected [7] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound57774 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env57775 : List Nat := [2,4,0,16,18,1,4,5,17,21,2048,16,1,1,16,1,1,5,21,17,16,20,1,0,5,17,16,16,1,2051,5,1,5,0,17,16]

theorem envBound57775 : H12AffineFastState.Bounded env57775 := by
  intro p hp
  have h : env57775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57774_57775 : H12AffineEnvironment.transform 2 0 env57774 = env57775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env57774 == env57775) = true)

theorem identity57775 : scanCanonicalize (H12AffineFastState.compose env57775 (packedSelected [1,8] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound57775 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env57776 : List Nat := [2,0,0,16,18,1,0,1,17,17,2048,16,1,1,16,1,1,1,17,17,16,16,1,0,1,17,16,16,1,2051,1,1,1,0,17,16]

theorem envBound57776 : H12AffineFastState.Bounded env57776 := by
  intro p hp
  have h : env57776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57775_57776 : H12AffineEnvironment.transform 1 0 env57775 = env57776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env57775 == env57776) = true)

theorem identity57776 : scanCanonicalize (H12AffineFastState.compose env57776 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound57776 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57777 : List Nat := [2,0,0,1,3,1,0,1,0,0,2048,1,1,1,1,1,1,1,0,0,1,1,1,0,1,0,1,1,1,2051,1,1,1,0,0,1]

theorem envBound57777 : H12AffineFastState.Bounded env57777 := by
  intro p hp
  have h : env57777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57776_57777 : H12AffineEnvironment.transform 3 1 env57776 = env57777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env57776 == env57777) = true)

theorem identity57777 : scanCanonicalize (H12AffineFastState.compose env57777 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 3) := by decide +kernel

theorem selectedBound57777 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env57778 : List Nat := [2,0,0,1,3,1,0,1,0,0,3,1,1,1,1,1,1,1,0,0,1,1,1,0,1,0,1,1,1,0,1,1,1,0,0,1]

theorem envBound57778 : H12AffineFastState.Bounded env57778 := by
  intro p hp
  have h : env57778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57777_57778 : H12AffineEnvironment.transform 10 3 env57777 = env57778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 3 env57777 == env57778) = true)

def env57779 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74863,65665,4417,13341,4096,476,74046,69649,13769,78894,4414,74815,1297,81226,8204,74798,256,8201,1344,5952]

theorem envBound57779 : H12AffineFastState.Bounded env57779 := by
  intro p hp
  have h : env57779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57695_57779 : H12AffineEnvironment.transform 17 65665 env57695 = env57779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env57695 == env57779) = true)

theorem identity57779 : scanCanonicalize (H12AffineFastState.compose env57779 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound57779 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env57780 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,1,12556,65536,74111,65665,4417,12557,4096,476,74046,69649,12505,78142,4414,74031,1,79962,8204,74046,256,8201,80,4688]

theorem envBound57780 : H12AffineFastState.Bounded env57780 := by
  intro p hp
  have h : env57780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57779_57780 : H12AffineEnvironment.transform 9 272 env57779 = env57780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env57779 == env57780) = true)

def env57781 : List Nat := [2,4,8,16,32,64,128,256,340,272,2048,4096,8192,1,12556,65536,74111,65665,4417,12557,4096,476,74046,69649,12505,78142,4414,74031,1,79962,8204,74046,256,8201,80,4356]

theorem envBound57781 : H12AffineFastState.Bounded env57781 := by
  intro p hp
  have h : env57781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57780_57781 : H12AffineEnvironment.transform 8 340 env57780 = env57781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env57780 == env57781) = true)

def env57782 : List Nat := [2,4,8,16,32,64,128,256,340,272,2048,16,8192,1,8476,65536,74111,65665,337,8477,16,476,74046,65537,8393,74030,302,74031,1,75850,8204,74046,256,8201,80,276]

theorem envBound57782 : H12AffineFastState.Bounded env57782 := by
  intro p hp
  have h : env57782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57781_57782 : H12AffineEnvironment.transform 11 16 env57781 = env57782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env57781 == env57782) = true)

theorem identity57782 : scanCanonicalize (H12AffineFastState.compose env57782 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 144) := by decide +kernel

theorem selectedBound57782 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env57783 : List Nat := [2,4,8,16,32,64,128,144,196,128,2048,16,8192,1,8332,65536,73967,65665,193,8333,16,76,73902,65537,8393,73918,190,73919,1,75850,8204,73902,144,8201,80,132]

theorem envBound57783 : H12AffineFastState.Bounded env57783 := by
  intro p hp
  have h : env57783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57782_57783 : H12AffineEnvironment.transform 7 144 env57782 = env57783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 144 env57782 == env57783) = true)

def env57784 : List Nat := [2,4,8,16,32,64,128,144,196,128,2048,16,24,1,148,65536,65783,65665,193,149,16,76,65718,65537,209,65702,190,65703,1,67666,20,65718,144,17,80,132]

theorem envBound57784 : H12AffineFastState.Bounded env57784 := by
  intro p hp
  have h : env57784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57783_57784 : H12AffineEnvironment.transform 12 24 env57783 = env57784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env57783 == env57784) = true)

theorem identity57784 : scanCanonicalize (H12AffineFastState.compose env57784 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound57784 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env57785 : List Nat := [2,4,8,16,32,64,128,144,196,128,2048,16,24,1,148,115,132,242,193,149,16,76,197,114,209,213,190,212,1,2081,20,197,144,17,80,132]

theorem envBound57785 : H12AffineFastState.Bounded env57785 := by
  intro p hp
  have h : env57785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57784_57785 : H12AffineEnvironment.transform 15 115 env57784 = env57785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env57784 == env57785) = true)

theorem identity57785 : scanCanonicalize (H12AffineFastState.compose env57785 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound57785 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env57786 : List Nat := [2,4,8,16,32,0,128,144,132,128,2048,16,24,1,148,51,132,178,129,149,16,12,133,50,145,149,190,148,1,2081,20,133,144,17,16,132]

theorem envBound57786 : H12AffineFastState.Bounded env57786 := by
  intro p hp
  have h : env57786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57785_57786 : H12AffineEnvironment.transform 5 0 env57785 = env57786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env57785 == env57786) = true)

theorem identity57786 : scanCanonicalize (H12AffineFastState.compose env57786 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound57786 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env57787 : List Nat := [2,4,8,16,32,0,9,25,13,9,2048,16,24,1,29,51,13,59,8,28,16,12,12,50,24,28,55,29,1,2081,20,12,25,17,16,13]

theorem envBound57787 : H12AffineFastState.Bounded env57787 := by
  intro p hp
  have h : env57787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57786_57787 : H12AffineEnvironment.transform 6 9 env57786 = env57787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env57786 == env57787) = true)

theorem identity57787 : scanCanonicalize (H12AffineFastState.compose env57787 (packedSelected [3,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound57787 : packedSelected [3,5,7] rootPS < 2^1333 := by decide +kernel

def env57788 : List Nat := [2,4,8,16,10,0,9,25,13,9,2048,16,24,1,29,25,13,17,8,28,16,12,12,24,24,28,29,29,1,2059,20,12,25,17,16,13]

theorem envBound57788 : H12AffineFastState.Bounded env57788 := by
  intro p hp
  have h : env57788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57787_57788 : H12AffineEnvironment.transform 4 10 env57787 = env57788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env57787 == env57788) = true)

theorem identity57788 : scanCanonicalize (H12AffineFastState.compose env57788 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound57788 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env57789 : List Nat := [2,4,2,16,0,0,3,19,7,3,2048,16,18,1,23,19,7,17,2,22,16,6,6,18,18,22,23,23,1,2049,20,6,19,17,16,7]

theorem envBound57789 : H12AffineFastState.Bounded env57789 := by
  intro p hp
  have h : env57789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57788_57789 : H12AffineEnvironment.transform 2 2 env57788 = env57789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env57788 == env57789) = true)

theorem identity57789 : scanCanonicalize (H12AffineFastState.compose env57789 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound57789 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env57790 : List Nat := [2,4,2,1,0,0,3,2,7,3,2048,1,3,1,6,2,7,0,2,7,1,6,6,3,3,7,6,6,1,2049,5,6,2,0,1,7]

theorem envBound57790 : H12AffineFastState.Bounded env57790 := by
  intro p hp
  have h : env57790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57789_57790 : H12AffineEnvironment.transform 3 1 env57789 = env57790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env57789 == env57790) = true)

theorem identity57790 : scanCanonicalize (H12AffineFastState.compose env57790 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 6) := by decide +kernel

theorem selectedBound57790 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env57791 : List Nat := [2,4,2,1,0,0,3,2,7,3,6,1,3,1,6,2,7,0,2,7,1,6,6,3,3,7,6,6,1,7,5,6,2,0,1,7]

theorem envBound57791 : H12AffineFastState.Bounded env57791 := by
  intro p hp
  have h : env57791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57790_57791 : H12AffineEnvironment.transform 10 6 env57790 = env57791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 6 env57790 == env57791) = true)

theorem identity57791 : scanCanonicalize (H12AffineFastState.compose env57791 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound57791 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env57792 : List Nat := [2,3,2,1,0,0,3,2,0,3,1,1,3,1,1,2,0,0,2,0,1,1,1,3,3,0,1,1,1,0,2,1,2,0,1,0]

theorem envBound57792 : H12AffineFastState.Bounded env57792 := by
  intro p hp
  have h : env57792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57791_57792 : H12AffineEnvironment.transform 1 3 env57791 = env57792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env57791 == env57792) = true)

def env57793 : List Nat := [2,4,8,16,32,64,128,144,196,128,2048,16,25,1,149,65536,65782,65665,193,148,16,76,65719,65537,208,65703,190,65702,1,67667,21,65719,144,16,80,132]

theorem envBound57793 : H12AffineFastState.Bounded env57793 := by
  intro p hp
  have h : env57793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57783_57793 : H12AffineEnvironment.transform 12 25 env57783 = env57793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env57783 == env57793) = true)

theorem identity57793 : scanCanonicalize (H12AffineFastState.compose env57793 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 51) := by decide +kernel

theorem selectedBound57793 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env57794 : List Nat := [2,4,8,16,32,64,128,144,196,128,2048,16,25,1,149,51,197,178,193,148,16,76,132,50,208,148,190,149,1,2144,21,132,144,16,80,132]

theorem envBound57794 : H12AffineFastState.Bounded env57794 := by
  intro p hp
  have h : env57794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57793_57794 : H12AffineEnvironment.transform 15 51 env57793 = env57794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 51 env57793 == env57794) = true)

theorem identity57794 : scanCanonicalize (H12AffineFastState.compose env57794 (packedSelected [1,2,3,4,9,10,12,16,17] rootPS)) = affineNative (2^(6+1) ^^^ 63) := by decide +kernel

theorem selectedBound57794 : packedSelected [1,2,3,4,9,10,12,16,17] rootPS < 2^1333 := by decide +kernel

def env57795 : List Nat := [2,4,8,16,32,64,63,47,123,63,2048,16,25,1,42,51,122,13,126,43,16,76,59,50,111,43,1,42,1,2144,21,59,47,16,80,59]

theorem envBound57795 : H12AffineFastState.Bounded env57795 := by
  intro p hp
  have h : env57795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57794_57795 : H12AffineEnvironment.transform 6 63 env57794 = env57795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 63 env57794 == env57795) = true)

theorem identity57795 : scanCanonicalize (H12AffineFastState.compose env57795 (packedSelected [0,2,3,5,7,8,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 39) := by decide +kernel

theorem selectedBound57795 : packedSelected [0,2,3,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env57796 : List Nat := [2,4,8,16,32,39,63,47,28,63,2048,16,25,1,42,51,29,13,25,43,16,43,59,50,8,43,1,42,1,2055,21,59,47,16,55,59]

theorem envBound57796 : H12AffineFastState.Bounded env57796 := by
  intro p hp
  have h : env57796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57795_57796 : H12AffineEnvironment.transform 5 39 env57795 = env57796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 39 env57795 == env57796) = true)

theorem identity57796 : scanCanonicalize (H12AffineFastState.compose env57796 (packedSelected [1,5,12,13] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound57796 : packedSelected [1,5,12,13] rootPS < 2^1333 := by decide +kernel

def env57797 : List Nat := [2,4,8,16,32,39,63,47,28,63,11,16,25,1,42,51,29,13,25,43,16,43,59,50,8,43,1,42,1,12,21,59,47,16,55,59]

theorem envBound57797 : H12AffineFastState.Bounded env57797 := by
  intro p hp
  have h : env57797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57796_57797 : H12AffineEnvironment.transform 10 11 env57796 = env57797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env57796 == env57797) = true)

theorem identity57797 : scanCanonicalize (H12AffineFastState.compose env57797 (packedSelected [0,1,3,4,8] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound57797 : packedSelected [0,1,3,4,8] rootPS < 2^1333 := by decide +kernel

def env57798 : List Nat := [2,4,8,10,32,39,37,47,6,37,11,10,3,1,42,41,7,13,3,43,10,43,33,40,8,43,1,42,1,12,15,33,47,10,45,33]

theorem envBound57798 : H12AffineFastState.Bounded env57798 := by
  intro p hp
  have h : env57798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57797_57798 : H12AffineEnvironment.transform 3 10 env57797 = env57798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env57797 == env57798) = true)

theorem identity57798 : scanCanonicalize (H12AffineFastState.compose env57798 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

end H12CloudChart2