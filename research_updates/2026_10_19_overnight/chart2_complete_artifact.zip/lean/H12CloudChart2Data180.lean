import H12CloudChart2Data179

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env45130 : List Nat := [2,4,8,0,0,10,128,2,12,141,2048,0,134,142,7,140,130,13,8,6,1,133,7,140,138,136,12,137,143,2180,139,136,3,142,132,137]

theorem envBound45130 : H12AffineFastState.Bounded env45130 := by
  intro p hp
  have h : env45130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45129_45130 : H12AffineEnvironment.transform 4 0 env45129 = env45130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env45129 == env45130) = true)

theorem identity45130 : scanCanonicalize (H12AffineFastState.compose env45130 (packedSelected [0,1,2,3,4,5,8] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound45130 : packedSelected [0,1,2,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env45131 : List Nat := [2,4,4,0,0,6,128,2,0,129,2048,0,134,130,7,128,130,1,4,6,1,133,7,128,134,132,0,133,131,2180,135,132,3,130,132,133]

theorem envBound45131 : H12AffineFastState.Bounded env45131 := by
  intro p hp
  have h : env45131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45130_45131 : H12AffineEnvironment.transform 2 4 env45130 = env45131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env45130 == env45131) = true)

theorem identity45131 : scanCanonicalize (H12AffineFastState.compose env45131 (packedSelected [2,3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound45131 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env45132 : List Nat := [2,3,3,0,0,1,128,2,0,129,2048,0,129,130,0,128,130,1,3,1,1,130,0,128,129,131,0,130,131,2179,128,131,3,130,131,130]

theorem envBound45132 : H12AffineFastState.Bounded env45132 := by
  intro p hp
  have h : env45132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45131_45132 : H12AffineEnvironment.transform 1 3 env45131 = env45132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env45131 == env45132) = true)

theorem identity45132 : scanCanonicalize (H12AffineFastState.compose env45132 (packedSelected [1,2] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound45132 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env45133 : List Nat := [2,3,3,0,0,1,3,2,0,2,2048,0,2,1,0,3,1,1,3,1,1,1,0,3,2,0,0,1,0,2048,3,0,3,1,0,1]

theorem envBound45133 : H12AffineFastState.Bounded env45133 := by
  intro p hp
  have h : env45133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45132_45133 : H12AffineEnvironment.transform 6 3 env45132 = env45133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env45132 == env45133) = true)

theorem identity45133 : scanCanonicalize (H12AffineFastState.compose env45133 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 2) := by decide +kernel

theorem selectedBound45133 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45134 : List Nat := [2,3,3,0,0,1,3,2,0,2,2,0,2,1,0,3,1,1,3,1,1,1,0,3,2,0,0,1,0,2,3,0,3,1,0,1]

theorem envBound45134 : H12AffineFastState.Bounded env45134 := by
  intro p hp
  have h : env45134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45133_45134 : H12AffineEnvironment.transform 10 2 env45133 = env45134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 2 env45133 == env45134) = true)

theorem identity45134 : scanCanonicalize (H12AffineFastState.compose env45134 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound45134 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env45135 : List Nat := [1,0,0,0,0,1,0,1,0,1,1,0,1,1,0,0,1,1,0,1,1,1,0,0,1,0,0,1,0,1,0,0,0,1,0,1]

theorem envBound45135 : H12AffineFastState.Bounded env45135 := by
  intro p hp
  have h : env45135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45134_45135 : H12AffineEnvironment.transform 0 1 env45134 = env45135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env45134 == env45135) = true)

def env45136 : List Nat := [2,4,8,0,32,64,128,256,324,453,2048,0,8192,196,8649,485,8271,356,320,8648,1,461,8394,485,8204,8207,302,8206,197,10603,8205,195,257,196,132,449]

theorem envBound45136 : H12AffineFastState.Bounded env45136 := by
  intro p hp
  have h : env45136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45125_45136 : H12AffineEnvironment.transform 15 485 env45125 = env45136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 485 env45125 == env45136) = true)

theorem identity45136 : scanCanonicalize (H12AffineFastState.compose env45136 (packedSelected [2,4,5,8,9,10,12,16,23,32,38,41] rootPS)) = affineNative (2^(7+1) ^^^ 110) := by decide +kernel

theorem selectedBound45136 : packedSelected [2,4,5,8,9,10,12,16,23,32,38,41] rootPS < 2^1333 := by decide +kernel

def env45137 : List Nat := [2,4,8,0,32,64,128,110,42,171,2048,0,8192,196,8359,139,8271,10,46,8358,1,163,8394,139,8204,8207,64,8206,197,10245,8205,195,111,196,132,175]

theorem envBound45137 : H12AffineFastState.Bounded env45137 := by
  intro p hp
  have h : env45137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45136_45137 : H12AffineEnvironment.transform 7 110 env45136 = env45137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 110 env45136 == env45137) = true)

theorem identity45137 : scanCanonicalize (H12AffineFastState.compose env45137 (packedSelected [2,4,5,8,9,10,11,15,16,18] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound45137 : packedSelected [2,4,5,8,9,10,11,15,16,18] rootPS < 2^1333 := by decide +kernel

def env45138 : List Nat := [2,4,8,0,32,64,128,110,42,171,1,0,8192,196,8359,139,8271,10,46,8358,1,163,8394,139,8204,8207,64,8206,197,8196,8205,195,111,196,132,175]

theorem envBound45138 : H12AffineFastState.Bounded env45138 := by
  intro p hp
  have h : env45138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45137_45138 : H12AffineEnvironment.transform 10 1 env45137 = env45138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env45137 == env45138) = true)

def env45139 : List Nat := [2,4,8,1,32,64,128,256,325,1024,2048,0,8192,1280,9229,65536,74863,65665,320,9228,1,460,74030,65537,9673,74799,303,74799,1281,77131,8205,65830,257,1281,1345,1029]

theorem envBound45139 : H12AffineFastState.Bounded env45139 := by
  intro p hp
  have h : env45139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45123_45139 : H12AffineEnvironment.transform 3 1 env45123 = env45139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env45123 == env45139) = true)

theorem identity45139 : scanCanonicalize (H12AffineFastState.compose env45139 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 205) := by decide +kernel

theorem selectedBound45139 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env45140 : List Nat := [2,4,8,1,32,64,128,256,325,1024,2048,0,205,1280,1216,65536,66722,65665,320,1217,1,460,66019,65537,1284,66786,303,66786,1281,68998,192,65830,257,1281,1345,1029]

theorem envBound45140 : H12AffineFastState.Bounded env45140 := by
  intro p hp
  have h : env45140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45139_45140 : H12AffineEnvironment.transform 12 205 env45139 = env45140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 205 env45139 == env45140) = true)

def env45141 : List Nat := [2,4,8,1,32,64,128,256,325,1024,2048,0,205,1280,1216,1056,130,1185,320,1217,1,460,1475,1057,1284,194,303,194,1281,2470,192,1286,257,1281,1345,1029]

theorem envBound45141 : H12AffineFastState.Bounded env45141 := by
  intro p hp
  have h : env45141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45140_45141 : H12AffineEnvironment.transform 15 1056 env45140 = env45141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1056 env45140 == env45141) = true)

theorem identity45141 : scanCanonicalize (H12AffineFastState.compose env45141 (packedSelected [2,4,5,7,8,9,10,15,16,17,20,21,23,27,32] rootPS)) = affineNative (2^(5+1) ^^^ 44) := by decide +kernel

theorem selectedBound45141 : packedSelected [2,4,5,7,8,9,10,15,16,17,20,21,23,27,32] rootPS < 2^1333 := by decide +kernel

def env45142 : List Nat := [2,4,8,1,32,44,128,256,297,1024,2048,0,161,1280,1196,1056,130,1185,300,1197,1,416,1455,1057,1284,174,303,174,1281,2470,172,1286,257,1281,1325,1029]

theorem envBound45142 : H12AffineFastState.Bounded env45142 := by
  intro p hp
  have h : env45142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45141_45142 : H12AffineEnvironment.transform 5 44 env45141 = env45142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 44 env45141 == env45142) = true)

theorem identity45142 : scanCanonicalize (H12AffineFastState.compose env45142 (packedSelected [0,2,3,4,7,8,9,11,13,15,16,18,20,21] rootPS)) = affineNative (2^(10+1) ^^^ 258) := by decide +kernel

theorem selectedBound45142 : packedSelected [0,2,3,4,7,8,9,11,13,15,16,18,20,21] rootPS < 2^1333 := by decide +kernel

def env45143 : List Nat := [2,4,8,1,32,44,128,256,297,1024,258,0,161,1280,1196,1056,130,1185,300,1197,1,416,1455,1057,1284,174,303,174,1281,164,172,1286,257,1281,1325,1029]

theorem envBound45143 : H12AffineFastState.Bounded env45143 := by
  intro p hp
  have h : env45143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45142_45143 : H12AffineEnvironment.transform 10 258 env45142 = env45143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 258 env45142 == env45143) = true)

theorem identity45143 : scanCanonicalize (H12AffineFastState.compose env45143 (packedSelected [0,1,2,7,10] rootPS)) = affineNative (2^(9+1) ^^^ 431) := by decide +kernel

theorem selectedBound45143 : packedSelected [0,1,2,7,10] rootPS < 2^1333 := by decide +kernel

def env45144 : List Nat := [2,4,8,1,32,44,128,256,297,431,258,0,161,175,259,399,130,270,300,258,1,416,0,398,171,174,303,174,174,164,172,169,257,174,130,426]

theorem envBound45144 : H12AffineFastState.Bounded env45144 := by
  intro p hp
  have h : env45144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45143_45144 : H12AffineEnvironment.transform 9 431 env45143 = env45144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 431 env45143 == env45144) = true)

theorem identity45144 : scanCanonicalize (H12AffineFastState.compose env45144 (packedSelected [1,13] rootPS)) = affineNative (2^(7+1) ^^^ 129) := by decide +kernel

theorem selectedBound45144 : packedSelected [1,13] rootPS < 2^1333 := by decide +kernel

def env45145 : List Nat := [2,4,8,1,32,44,128,129,168,46,131,0,161,175,130,14,130,143,173,131,1,33,0,15,171,174,174,174,174,164,172,169,128,174,130,43]

theorem envBound45145 : H12AffineFastState.Bounded env45145 := by
  intro p hp
  have h : env45145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45144_45145 : H12AffineEnvironment.transform 7 129 env45144 = env45145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 129 env45144 == env45145) = true)

theorem identity45145 : scanCanonicalize (H12AffineFastState.compose env45145 (packedSelected [1,3,5] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound45145 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env45146 : List Nat := [2,2,8,1,32,42,128,129,168,40,131,0,161,169,130,8,130,137,171,131,1,33,0,9,171,168,168,168,168,162,170,169,128,168,130,43]

theorem envBound45146 : H12AffineFastState.Bounded env45146 := by
  intro p hp
  have h : env45146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45145_45146 : H12AffineEnvironment.transform 1 2 env45145 = env45146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env45145 == env45146) = true)

theorem identity45146 : scanCanonicalize (H12AffineFastState.compose env45146 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound45146 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env45147 : List Nat := [2,2,3,1,32,33,128,129,163,35,131,0,161,162,130,3,130,130,160,131,1,33,0,2,160,163,163,163,163,162,161,162,128,163,130,32]

theorem envBound45147 : H12AffineFastState.Bounded env45147 := by
  intro p hp
  have h : env45147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45146_45147 : H12AffineEnvironment.transform 2 3 env45146 = env45147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env45146 == env45147) = true)

theorem identity45147 : scanCanonicalize (H12AffineFastState.compose env45147 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound45147 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45148 : List Nat := [2,2,3,1,32,33,3,2,32,35,0,0,34,33,1,3,1,1,35,0,1,33,0,2,35,32,32,32,32,33,34,33,3,32,1,32]

theorem envBound45148 : H12AffineFastState.Bounded env45148 := by
  intro p hp
  have h : env45148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45147_45148 : H12AffineEnvironment.transform 6 3 env45147 = env45148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env45147 == env45148) = true)

def env45149 : List Nat := [2,4,8,1,32,64,128,256,325,1024,2048,0,205,1280,1216,1057,131,1184,320,1217,1,460,1474,1056,1284,195,303,195,1281,2471,192,1287,257,1281,1345,1029]

theorem envBound45149 : H12AffineFastState.Bounded env45149 := by
  intro p hp
  have h : env45149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45140_45149 : H12AffineEnvironment.transform 15 1057 env45140 = env45149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1057 env45140 == env45149) = true)

theorem identity45149 : scanCanonicalize (H12AffineFastState.compose env45149 (packedSelected [2,4,5,7,8,9,10,15,16,17,20,21,23,27,32] rootPS)) = affineNative (2^(5+1) ^^^ 43) := by decide +kernel

theorem selectedBound45149 : packedSelected [2,4,5,7,8,9,10,15,16,17,20,21,23,27,32] rootPS < 2^1333 := by decide +kernel

def env45150 : List Nat := [2,4,8,1,32,43,128,256,302,1024,2048,0,166,1280,1195,1057,131,1184,299,1194,1,423,1449,1056,1284,168,303,168,1281,2471,171,1287,257,1281,1322,1029]

theorem envBound45150 : H12AffineFastState.Bounded env45150 := by
  intro p hp
  have h : env45150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45149_45150 : H12AffineEnvironment.transform 5 43 env45149 = env45150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 43 env45149 == env45150) = true)

theorem identity45150 : scanCanonicalize (H12AffineFastState.compose env45150 (packedSelected [0,1,2,4,5,7,9,11,13,16,18,20,21] rootPS)) = affineNative (2^(9+1) ^^^ 295) := by decide +kernel

theorem selectedBound45150 : packedSelected [0,1,2,4,5,7,9,11,13,16,18,20,21] rootPS < 2^1333 := by decide +kernel

def env45151 : List Nat := [2,4,8,1,32,43,128,256,302,295,2048,0,166,39,396,262,131,391,299,397,1,423,142,263,35,168,303,168,38,2471,171,32,257,38,13,290]

theorem envBound45151 : H12AffineFastState.Bounded env45151 := by
  intro p hp
  have h : env45151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45150_45151 : H12AffineEnvironment.transform 9 295 env45150 = env45151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 295 env45150 == env45151) = true)

theorem identity45151 : scanCanonicalize (H12AffineFastState.compose env45151 (packedSelected [1,2,4,5,8,9,10,13] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound45151 : packedSelected [1,2,4,5,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env45152 : List Nat := [2,4,8,1,32,43,15,256,302,295,2048,0,41,39,259,262,12,264,299,258,1,296,1,263,35,39,303,39,38,2344,36,32,257,38,13,290]

theorem envBound45152 : H12AffineFastState.Bounded env45152 := by
  intro p hp
  have h : env45152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45151_45152 : H12AffineEnvironment.transform 6 15 env45151 = env45152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env45151 == env45152) = true)

theorem identity45152 : scanCanonicalize (H12AffineFastState.compose env45152 (packedSelected [1,2,3,10] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound45152 : packedSelected [1,2,3,10] rootPS < 2^1333 := by decide +kernel

def env45153 : List Nat := [2,4,8,1,32,43,15,5,43,34,2048,0,41,39,6,3,12,13,46,7,1,45,1,2,35,39,42,39,38,2093,36,32,4,38,13,39]

theorem envBound45153 : H12AffineFastState.Bounded env45153 := by
  intro p hp
  have h : env45153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45152_45153 : H12AffineEnvironment.transform 7 5 env45152 = env45153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env45152 == env45153) = true)

theorem identity45153 : scanCanonicalize (H12AffineFastState.compose env45153 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound45153 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env45154 : List Nat := [2,4,3,1,32,32,4,5,32,34,2048,0,34,39,6,3,7,6,37,7,1,38,1,2,35,39,33,39,38,2086,36,32,4,38,6,39]

theorem envBound45154 : H12AffineFastState.Bounded env45154 := by
  intro p hp
  have h : env45154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45153_45154 : H12AffineEnvironment.transform 2 3 env45153 = env45154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env45153 == env45154) = true)

theorem identity45154 : scanCanonicalize (H12AffineFastState.compose env45154 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound45154 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env45155 : List Nat := [2,4,3,1,1,1,4,5,1,3,2048,0,3,6,6,3,7,6,4,7,1,7,1,2,2,6,0,6,7,2055,5,1,4,7,6,6]

theorem envBound45155 : H12AffineFastState.Bounded env45155 := by
  intro p hp
  have h : env45155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45154_45155 : H12AffineEnvironment.transform 4 1 env45154 = env45155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env45154 == env45155) = true)

theorem identity45155 : scanCanonicalize (H12AffineFastState.compose env45155 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 6) := by decide +kernel

theorem selectedBound45155 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env45156 : List Nat := [2,4,3,1,1,1,4,5,1,3,6,0,3,6,6,3,7,6,4,7,1,7,1,2,2,6,0,6,7,1,5,1,4,7,6,6]

theorem envBound45156 : H12AffineFastState.Bounded env45156 := by
  intro p hp
  have h : env45156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45155_45156 : H12AffineEnvironment.transform 10 6 env45155 = env45156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 6 env45155 == env45156) = true)

theorem identity45156 : scanCanonicalize (H12AffineFastState.compose env45156 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound45156 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45157 : List Nat := [2,3,3,1,1,1,3,2,1,3,1,0,3,1,1,3,0,1,3,0,1,0,1,2,2,1,0,1,0,1,2,1,3,0,1,1]

theorem envBound45157 : H12AffineFastState.Bounded env45157 := by
  intro p hp
  have h : env45157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45156_45157 : H12AffineEnvironment.transform 1 3 env45156 = env45157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env45156 == env45157) = true)

def env45158 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,0,8192,1297,9244,65536,74863,65665,320,9245,1,477,74047,65552,9673,74799,318,74814,1296,77131,8205,65830,257,1281,1345,1045]

theorem envBound45158 : H12AffineFastState.Bounded env45158 := by
  intro p hp
  have h : env45158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45122_45158 : H12AffineEnvironment.transform 8 341 env45122 = env45158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env45122 == env45158) = true)

def env45159 : List Nat := [2,4,8,0,32,64,128,256,325,1024,2048,0,8192,1281,9228,65536,74863,65665,320,9229,1,461,74031,65536,9673,74799,302,74798,1280,77131,8205,65830,257,1281,1345,1029]

theorem envBound45159 : H12AffineFastState.Bounded env45159 := by
  intro p hp
  have h : env45159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45158_45159 : H12AffineEnvironment.transform 3 0 env45158 = env45159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env45158 == env45159) = true)

theorem identity45159 : scanCanonicalize (H12AffineFastState.compose env45159 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 9451) := by decide +kernel

theorem selectedBound45159 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env45160 : List Nat := [2,4,8,0,32,64,128,256,325,1024,2048,0,8192,1281,9228,9451,132,9322,320,9229,1,461,1476,9451,9673,196,302,197,1280,2464,8205,9677,257,1281,1345,1029]

theorem envBound45160 : H12AffineFastState.Bounded env45160 := by
  intro p hp
  have h : env45160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45159_45160 : H12AffineEnvironment.transform 15 9451 env45159 = env45160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9451 env45159 == env45160) = true)

def env45161 : List Nat := [2,4,8,0,32,64,128,256,325,1024,2048,0,204,1281,1216,1063,132,1190,320,1217,1,461,1476,1063,1285,196,302,197,1280,2464,193,1281,257,1281,1345,1029]

theorem envBound45161 : H12AffineFastState.Bounded env45161 := by
  intro p hp
  have h : env45161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45160_45161 : H12AffineEnvironment.transform 12 204 env45160 = env45161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 204 env45160 == env45161) = true)

theorem identity45161 : scanCanonicalize (H12AffineFastState.compose env45161 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 389) := by decide +kernel

theorem selectedBound45161 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env45162 : List Nat := [2,4,8,0,32,64,128,256,325,389,2048,0,204,132,325,418,132,291,320,324,1,461,65,418,128,196,302,197,133,2464,193,132,257,132,196,384]

theorem envBound45162 : H12AffineFastState.Bounded env45162 := by
  intro p hp
  have h : env45162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45161_45162 : H12AffineEnvironment.transform 9 389 env45161 = env45162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 389 env45161 == env45162) = true)

theorem identity45162 : scanCanonicalize (H12AffineFastState.compose env45162 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound45162 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env45163 : List Nat := [2,4,8,0,32,64,128,68,1,193,2048,0,204,132,1,230,132,103,4,0,1,137,65,230,128,196,106,197,133,2276,193,132,69,132,196,196]

theorem envBound45163 : H12AffineFastState.Bounded env45163 := by
  intro p hp
  have h : env45163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45162_45163 : H12AffineEnvironment.transform 7 68 env45162 = env45163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env45162 == env45163) = true)

theorem identity45163 : scanCanonicalize (H12AffineFastState.compose env45163 (packedSelected [0,1,2,7,10,11,15] rootPS)) = affineNative (2^(10+1) ^^^ 233) := by decide +kernel

theorem selectedBound45163 : packedSelected [0,1,2,7,10,11,15] rootPS < 2^1333 := by decide +kernel

def env45164 : List Nat := [2,4,8,0,32,64,128,68,1,193,233,0,204,132,1,230,132,103,4,0,1,137,65,230,128,196,106,197,133,13,193,132,69,132,196,196]

theorem envBound45164 : H12AffineFastState.Bounded env45164 := by
  intro p hp
  have h : env45164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45163_45164 : H12AffineEnvironment.transform 10 233 env45163 = env45164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 233 env45163 == env45164) = true)

theorem identity45164 : scanCanonicalize (H12AffineFastState.compose env45164 (packedSelected [3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 45) := by decide +kernel

theorem selectedBound45164 : packedSelected [3,5,8] rootPS < 2^1333 := by decide +kernel

def env45165 : List Nat := [2,4,8,0,32,45,128,41,1,172,132,0,161,132,1,139,132,10,4,0,1,137,44,139,128,169,7,168,133,13,172,132,40,132,169,169]

theorem envBound45165 : H12AffineFastState.Bounded env45165 := by
  intro p hp
  have h : env45165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45164_45165 : H12AffineEnvironment.transform 5 45 env45164 = env45165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 45 env45164 == env45165) = true)

theorem identity45165 : scanCanonicalize (H12AffineFastState.compose env45165 (packedSelected [0,1,2,3,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound45165 : packedSelected [0,1,2,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env45166 : List Nat := [2,4,8,0,32,45,14,41,1,34,10,0,47,10,1,5,10,10,4,0,1,7,44,5,14,39,7,38,11,13,34,10,40,10,39,39]

theorem envBound45166 : H12AffineFastState.Bounded env45166 := by
  intro p hp
  have h : env45166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45165_45166 : H12AffineEnvironment.transform 6 14 env45165 = env45166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env45165 == env45166) = true)

theorem identity45166 : scanCanonicalize (H12AffineFastState.compose env45166 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound45166 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env45167 : List Nat := [2,2,8,0,32,43,8,41,1,34,10,0,41,10,1,3,10,10,2,0,1,1,42,3,8,33,1,32,11,11,34,10,40,10,33,33]

theorem envBound45167 : H12AffineFastState.Bounded env45167 := by
  intro p hp
  have h : env45167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45166_45167 : H12AffineEnvironment.transform 1 2 env45166 = env45167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env45166 == env45167) = true)

theorem identity45167 : scanCanonicalize (H12AffineFastState.compose env45167 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound45167 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env45168 : List Nat := [2,2,8,0,10,1,8,3,1,8,10,0,3,10,1,3,10,10,2,0,1,1,0,3,8,11,1,10,11,11,8,10,2,10,11,11]

theorem envBound45168 : H12AffineFastState.Bounded env45168 := by
  intro p hp
  have h : env45168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45167_45168 : H12AffineEnvironment.transform 4 10 env45167 = env45168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env45167 == env45168) = true)

theorem identity45168 : scanCanonicalize (H12AffineFastState.compose env45168 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound45168 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env45169 : List Nat := [2,2,3,0,1,1,3,3,1,3,1,0,3,1,1,3,1,1,2,0,1,1,0,3,3,0,1,1,0,0,3,1,2,1,0,0]

theorem envBound45169 : H12AffineFastState.Bounded env45169 := by
  intro p hp
  have h : env45169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45168_45169 : H12AffineEnvironment.transform 2 3 env45168 = env45169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env45168 == env45169) = true)

theorem identity45169 : scanCanonicalize (H12AffineFastState.compose env45169 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound45169 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45170 : List Nat := [1,1,0,0,1,1,0,0,1,0,1,0,0,1,1,0,1,1,1,0,1,1,0,0,0,0,1,1,0,0,0,1,1,1,0,0]

theorem envBound45170 : H12AffineFastState.Bounded env45170 := by
  intro p hp
  have h : env45170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45169_45170 : H12AffineEnvironment.transform 0 1 env45169 = env45170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env45169 == env45170) = true)

def env45171 : List Nat := [2,4,8,0,32,64,128,256,325,1024,2048,0,205,1281,1217,1062,132,1191,320,1216,1,461,1476,1062,1284,196,302,197,1280,2464,192,1280,257,1281,1345,1029]

theorem envBound45171 : H12AffineFastState.Bounded env45171 := by
  intro p hp
  have h : env45171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45160_45171 : H12AffineEnvironment.transform 12 205 env45160 = env45171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 205 env45160 == env45171) = true)

theorem identity45171 : scanCanonicalize (H12AffineFastState.compose env45171 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound45171 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env45172 : List Nat := [2,4,8,0,32,64,128,68,1,1024,2048,0,205,1093,1217,1062,132,1191,4,1216,1,137,1152,1062,1088,196,106,197,1092,2276,192,1092,69,1093,1029,1029]

theorem envBound45172 : H12AffineFastState.Bounded env45172 := by
  intro p hp
  have h : env45172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45171_45172 : H12AffineEnvironment.transform 7 68 env45171 = env45172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env45171 == env45172) = true)

theorem identity45172 : scanCanonicalize (H12AffineFastState.compose env45172 (packedSelected [1,3,15,17,19,21] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound45172 : packedSelected [1,3,15,17,19,21] rootPS < 2^1333 := by decide +kernel

def env45173 : List Nat := [2,4,8,0,32,64,128,68,1,100,2048,0,205,33,165,66,132,195,4,164,1,137,228,66,36,196,106,197,32,2276,192,32,69,33,97,97]

theorem envBound45173 : H12AffineFastState.Bounded env45173 := by
  intro p hp
  have h : env45173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45172_45173 : H12AffineEnvironment.transform 9 100 env45172 = env45173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env45172 == env45173) = true)

theorem identity45173 : scanCanonicalize (H12AffineFastState.compose env45173 (packedSelected [3,10,17] rootPS)) = affineNative (2^(10+1) ^^^ 227) := by decide +kernel

theorem selectedBound45173 : packedSelected [3,10,17] rootPS < 2^1333 := by decide +kernel

def env45174 : List Nat := [2,4,8,0,32,64,128,68,1,100,227,0,205,33,165,66,132,195,4,164,1,137,228,66,36,196,106,197,32,7,192,32,69,33,97,97]

theorem envBound45174 : H12AffineFastState.Bounded env45174 := by
  intro p hp
  have h : env45174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45173_45174 : H12AffineEnvironment.transform 10 227 env45173 = env45174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 227 env45173 == env45174) = true)

theorem identity45174 : scanCanonicalize (H12AffineFastState.compose env45174 (packedSelected [4,8,9,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound45174 : packedSelected [4,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env45175 : List Nat := [2,4,8,0,32,64,15,68,1,100,108,0,66,33,42,66,11,76,4,43,1,6,107,66,36,75,106,74,32,7,79,32,69,33,97,97]

theorem envBound45175 : H12AffineFastState.Bounded env45175 := by
  intro p hp
  have h : env45175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45174_45175 : H12AffineEnvironment.transform 6 15 env45174 = env45175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env45174 == env45175) = true)

theorem identity45175 : scanCanonicalize (H12AffineFastState.compose env45175 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound45175 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env45176 : List Nat := [2,4,8,0,32,12,15,8,1,40,32,0,14,33,42,14,11,0,4,43,1,6,39,14,36,7,38,6,32,7,3,32,9,33,45,45]

theorem envBound45176 : H12AffineFastState.Bounded env45176 := by
  intro p hp
  have h : env45176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45175_45176 : H12AffineEnvironment.transform 5 12 env45175 = env45176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env45175 == env45176) = true)

theorem identity45176 : scanCanonicalize (H12AffineFastState.compose env45176 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound45176 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env45177 : List Nat := [2,2,8,0,32,10,9,8,1,40,32,0,8,33,42,8,11,0,2,43,1,0,33,8,34,1,32,0,32,1,3,32,9,33,43,43]

theorem envBound45177 : H12AffineFastState.Bounded env45177 := by
  intro p hp
  have h : env45177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45176_45177 : H12AffineEnvironment.transform 1 2 env45176 = env45177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env45176 == env45177) = true)

theorem identity45177 : scanCanonicalize (H12AffineFastState.compose env45177 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound45177 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45178 : List Nat := [2,2,3,0,32,1,2,3,1,35,32,0,3,33,33,3,0,0,2,32,1,0,33,3,34,1,32,0,32,1,3,32,2,33,32,32]

theorem envBound45178 : H12AffineFastState.Bounded env45178 := by
  intro p hp
  have h : env45178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45177_45178 : H12AffineEnvironment.transform 2 3 env45177 = env45178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env45177 == env45178) = true)

def env45179 : List Nat := [2,4,8,1,32,64,128,256,324,1024,2048,0,8192,1280,9229,65536,74863,65665,320,9228,1,460,74030,65537,9673,74799,303,74799,1281,77131,8205,65830,257,1281,1345,1028]

theorem envBound45179 : H12AffineFastState.Bounded env45179 := by
  intro p hp
  have h : env45179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45158_45179 : H12AffineEnvironment.transform 3 1 env45158 = env45179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env45158 == env45179) = true)

theorem identity45179 : scanCanonicalize (H12AffineFastState.compose env45179 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 483) := by decide +kernel

theorem selectedBound45179 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env45180 : List Nat := [2,4,8,1,32,64,128,256,324,1024,2048,0,8192,1280,9229,483,9612,354,320,9228,1,460,8397,482,9673,9676,303,9676,1281,11432,8205,197,257,1281,1345,1028]

theorem envBound45180 : H12AffineFastState.Bounded env45180 := by
  intro p hp
  have h : env45180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45179_45180 : H12AffineEnvironment.transform 15 483 env45179 = env45180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 483 env45179 == env45180) = true)

def env45181 : List Nat := [2,4,8,1,32,64,128,256,324,452,2048,0,8192,196,8649,483,8264,354,320,8648,1,460,8397,482,8205,8200,303,8200,197,10604,8205,197,257,197,133,448]

theorem envBound45181 : H12AffineFastState.Bounded env45181 := by
  intro p hp
  have h : env45181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45180_45181 : H12AffineEnvironment.transform 9 452 env45180 = env45181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 452 env45180 == env45181) = true)

theorem identity45181 : scanCanonicalize (H12AffineFastState.compose env45181 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 140) := by decide +kernel

theorem selectedBound45181 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env45182 : List Nat := [2,4,8,1,32,64,128,256,324,452,2048,0,140,196,325,483,196,354,320,324,1,460,65,482,129,132,303,132,197,2528,129,197,257,197,133,448]

theorem envBound45182 : H12AffineFastState.Bounded env45182 := by
  intro p hp
  have h : env45182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45181_45182 : H12AffineEnvironment.transform 12 140 env45181 = env45182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 140 env45181 == env45182) = true)

theorem identity45182 : scanCanonicalize (H12AffineFastState.compose env45182 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound45182 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env45183 : List Nat := [2,4,8,1,32,64,128,68,0,128,2048,0,140,196,1,167,196,38,4,0,1,136,65,166,129,132,107,132,197,2212,129,197,69,197,133,132]

theorem envBound45183 : H12AffineFastState.Bounded env45183 := by
  intro p hp
  have h : env45183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45182_45183 : H12AffineEnvironment.transform 7 68 env45182 = env45183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env45182 == env45183) = true)

theorem identity45183 : scanCanonicalize (H12AffineFastState.compose env45183 (packedSelected [0,1,2,7,10,11,15] rootPS)) = affineNative (2^(10+1) ^^^ 232) := by decide +kernel

theorem selectedBound45183 : packedSelected [0,1,2,7,10,11,15] rootPS < 2^1333 := by decide +kernel

def env45184 : List Nat := [2,4,8,1,32,64,128,68,0,128,232,0,140,196,1,167,196,38,4,0,1,136,65,166,129,132,107,132,197,76,129,197,69,197,133,132]

theorem envBound45184 : H12AffineFastState.Bounded env45184 := by
  intro p hp
  have h : env45184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45183_45184 : H12AffineEnvironment.transform 10 232 env45183 = env45184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 232 env45183 == env45184) = true)

theorem identity45184 : scanCanonicalize (H12AffineFastState.compose env45184 (packedSelected [3,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound45184 : packedSelected [3,5,8] rootPS < 2^1333 := by decide +kernel

def env45185 : List Nat := [2,4,8,1,32,64,105,68,0,105,1,0,101,45,1,78,45,38,4,0,1,97,65,79,104,109,107,109,44,76,104,44,69,44,108,109]

theorem envBound45185 : H12AffineFastState.Bounded env45185 := by
  intro p hp
  have h : env45185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45184_45185 : H12AffineEnvironment.transform 6 105 env45184 = env45185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env45184 == env45185) = true)

theorem identity45185 : scanCanonicalize (H12AffineFastState.compose env45185 (packedSelected [0,1,2,3,4,5] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound45185 : packedSelected [0,1,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env45186 : List Nat := [2,4,4,1,32,64,101,68,0,101,1,0,101,33,1,66,33,38,4,0,1,97,65,67,100,97,103,97,32,64,100,32,69,32,96,97]

theorem envBound45186 : H12AffineFastState.Bounded env45186 := by
  intro p hp
  have h : env45186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45185_45186 : H12AffineEnvironment.transform 2 4 env45185 = env45186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env45185 == env45186) = true)

theorem identity45186 : scanCanonicalize (H12AffineFastState.compose env45186 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound45186 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45187 : List Nat := [2,4,4,1,1,64,68,68,0,68,1,0,68,0,1,66,0,7,4,0,1,64,65,67,69,64,70,64,1,64,69,1,69,1,65,64]

theorem envBound45187 : H12AffineFastState.Bounded env45187 := by
  intro p hp
  have h : env45187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45186_45187 : H12AffineEnvironment.transform 4 1 env45186 = env45187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env45186 == env45187) = true)

theorem identity45187 : scanCanonicalize (H12AffineFastState.compose env45187 (packedSelected [0,1,9] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound45187 : packedSelected [0,1,9] rootPS < 2^1333 := by decide +kernel

def env45188 : List Nat := [2,3,3,1,1,64,67,67,0,67,1,0,67,0,1,66,0,0,3,0,1,64,65,67,66,64,65,64,1,64,66,1,66,1,65,64]

theorem envBound45188 : H12AffineFastState.Bounded env45188 := by
  intro p hp
  have h : env45188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45187_45188 : H12AffineEnvironment.transform 1 3 env45187 = env45188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env45187 == env45188) = true)

theorem identity45188 : scanCanonicalize (H12AffineFastState.compose env45188 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound45188 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45189 : List Nat := [2,3,3,1,1,0,3,3,0,3,1,0,3,0,1,2,0,0,3,0,1,0,1,3,2,0,1,0,1,0,2,1,2,1,1,0]

theorem envBound45189 : H12AffineFastState.Bounded env45189 := by
  intro p hp
  have h : env45189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45188_45189 : H12AffineEnvironment.transform 5 0 env45188 = env45189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env45188 == env45189) = true)

def env45190 : List Nat := [2,4,8,1,32,64,128,256,324,453,2048,0,8192,197,8648,483,8265,354,320,8649,1,460,8397,482,8204,8201,303,8201,196,10605,8205,197,257,196,132,449]

theorem envBound45190 : H12AffineFastState.Bounded env45190 := by
  intro p hp
  have h : env45190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45180_45190 : H12AffineEnvironment.transform 9 453 env45180 = env45190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 453 env45180 == env45190) = true)

theorem identity45190 : scanCanonicalize (H12AffineFastState.compose env45190 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound45190 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env45191 : List Nat := [2,4,8,1,32,64,128,68,0,129,2048,0,8192,197,8332,167,8265,38,4,8333,1,136,8397,166,8204,8201,107,8201,196,10281,8205,197,69,196,132,133]

theorem envBound45191 : H12AffineFastState.Bounded env45191 := by
  intro p hp
  have h : env45191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45190_45191 : H12AffineEnvironment.transform 7 68 env45190 = env45191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env45190 == env45191) = true)

theorem identity45191 : scanCanonicalize (H12AffineFastState.compose env45191 (packedSelected [1,3,15,17,19,21] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound45191 : packedSelected [1,3,15,17,19,21] rootPS < 2^1333 := by decide +kernel

def env45192 : List Nat := [2,4,8,1,32,64,128,68,0,129,2048,0,40,197,164,167,97,38,4,165,1,136,229,166,36,33,107,33,196,2049,37,197,69,196,132,133]

theorem envBound45192 : H12AffineFastState.Bounded env45192 := by
  intro p hp
  have h : env45192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45191_45192 : H12AffineEnvironment.transform 12 40 env45191 = env45192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env45191 == env45192) = true)

theorem identity45192 : scanCanonicalize (H12AffineFastState.compose env45192 (packedSelected [1,2,4,9,10,12,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 38) := by decide +kernel

theorem selectedBound45192 : packedSelected [1,2,4,9,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env45193 : List Nat := [2,4,8,1,32,38,128,34,0,129,2048,0,40,163,164,167,7,38,4,165,1,136,131,166,36,33,13,33,162,2049,37,163,35,162,132,133]

theorem envBound45193 : H12AffineFastState.Bounded env45193 := by
  intro p hp
  have h : env45193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45192_45193 : H12AffineEnvironment.transform 5 38 env45192 = env45193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 38 env45192 == env45193) = true)

theorem identity45193 : scanCanonicalize (H12AffineFastState.compose env45193 (packedSelected [2,3,5,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 174) := by decide +kernel

theorem selectedBound45193 : packedSelected [2,3,5,8,10] rootPS < 2^1333 := by decide +kernel

def env45194 : List Nat := [2,4,8,1,32,38,128,34,0,129,174,0,40,163,164,167,7,38,4,165,1,136,131,166,36,33,13,33,162,175,37,163,35,162,132,133]

theorem envBound45194 : H12AffineFastState.Bounded env45194 := by
  intro p hp
  have h : env45194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45193_45194 : H12AffineEnvironment.transform 10 174 env45193 = env45194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 174 env45193 == env45194) = true)

theorem identity45194 : scanCanonicalize (H12AffineFastState.compose env45194 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound45194 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env45195 : List Nat := [2,4,4,1,32,38,128,34,0,129,162,0,36,163,164,167,7,38,4,165,1,132,131,166,36,33,1,33,162,163,37,163,35,162,132,133]

theorem envBound45195 : H12AffineFastState.Bounded env45195 := by
  intro p hp
  have h : env45195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45194_45195 : H12AffineEnvironment.transform 2 4 env45194 = env45195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env45194 == env45195) = true)

theorem identity45195 : scanCanonicalize (H12AffineFastState.compose env45195 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound45195 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env45196 : List Nat := [2,3,3,1,32,33,128,34,0,129,162,0,35,163,163,160,0,33,3,162,1,131,131,161,35,33,1,33,162,163,34,163,35,162,131,130]

theorem envBound45196 : H12AffineFastState.Bounded env45196 := by
  intro p hp
  have h : env45196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45195_45196 : H12AffineEnvironment.transform 1 3 env45195 = env45196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env45195 == env45196) = true)

theorem identity45196 : scanCanonicalize (H12AffineFastState.compose env45196 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound45196 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45197 : List Nat := [2,3,3,1,0,1,128,2,0,129,130,0,3,131,131,128,0,1,3,130,1,131,131,129,3,1,1,1,130,131,2,131,3,130,131,130]

theorem envBound45197 : H12AffineFastState.Bounded env45197 := by
  intro p hp
  have h : env45197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45196_45197 : H12AffineEnvironment.transform 4 0 env45196 = env45197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env45196 == env45197) = true)

theorem identity45197 : scanCanonicalize (H12AffineFastState.compose env45197 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound45197 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45198 : List Nat := [2,3,3,1,0,1,3,2,0,2,1,0,3,0,0,3,0,1,3,1,1,0,0,2,3,1,1,1,1,0,2,0,3,1,0,1]

theorem envBound45198 : H12AffineFastState.Bounded env45198 := by
  intro p hp
  have h : env45198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45197_45198 : H12AffineEnvironment.transform 6 3 env45197 = env45198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env45197 == env45198) = true)

theorem identity45198 : scanCanonicalize (H12AffineFastState.compose env45198 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound45198 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45199 : List Nat := [0,1,1,1,0,1,1,0,0,0,1,0,1,0,0,1,0,1,1,1,1,0,0,0,1,1,1,1,1,0,0,0,1,1,0,1]

theorem envBound45199 : H12AffineFastState.Bounded env45199 := by
  intro p hp
  have h : env45199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45198_45199 : H12AffineEnvironment.transform 0 0 env45198 = env45199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env45198 == env45199) = true)

def env45200 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,16777216,533641,672785,17245633,148800,545089,96346,16876545,16819499,257,545105,1344,525824]

theorem envBound45200 : H12AffineFastState.Bounded env45200 := by
  intro p hp
  have h : env45200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44512_45200 : H12AffineEnvironment.transform 26 17245633 env44512 = env45200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env44512 == env45200) = true)

theorem identity45200 : scanCanonicalize (H12AffineFastState.compose env45200 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(18+1) ^^^ 95614) := by decide +kernel

theorem selectedBound45200 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env45201 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95614,32769,4097,61648,147521,16777216,86519,209263,17245633,148800,74815,96346,16876545,16819499,257,74799,1344,95102]

theorem envBound45201 : H12AffineFastState.Bounded env45201 := by
  intro p hp
  have h : env45201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45200_45201 : H12AffineEnvironment.transform 18 95614 env45200 = env45201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 95614 env45200 == env45201) = true)

def env45202 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95614,32769,4097,61648,147521,284032,86519,209263,225345,148800,74815,96346,381313,323755,257,74799,1344,95102]

theorem envBound45202 : H12AffineFastState.Bounded env45202 := by
  intro p hp
  have h : env45202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45201_45202 : H12AffineEnvironment.transform 23 284032 env45201 = env45202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284032 env45201 == env45202) = true)

def env45203 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16464,262144,95614,32769,4097,61648,17,284032,86519,94527,77841,1296,74815,96346,381313,323755,257,74799,1344,95102]

theorem envBound45203 : H12AffineFastState.Bounded env45203 := by
  intro p hp
  have h : env45203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45202_45203 : H12AffineEnvironment.transform 16 16464 env45202 = env45203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16464 env45202 == env45203) = true)

def env45204 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1344,262144,77934,32769,4097,46528,17,266384,70887,78895,77841,1296,74815,81226,365713,308667,257,74799,1344,79470]

theorem envBound45204 : H12AffineFastState.Bounded env45204 := by
  intro p hp
  have h : env45204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45203_45204 : H12AffineEnvironment.transform 13 1296 env45203 = env45204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env45203 == env45204) = true)

theorem identity45204 : scanCanonicalize (H12AffineFastState.compose env45204 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32883) := by decide +kernel

theorem selectedBound45204 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env45205 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,32883,1344,262144,45085,32769,4097,46528,17,266384,38036,46172,45154,1296,42060,48441,267490,308667,257,42076,1344,46621]

theorem envBound45205 : H12AffineFastState.Bounded env45205 := by
  intro p hp
  have h : env45205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45204_45205 : H12AffineEnvironment.transform 15 32883 env45204 = env45205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32883 env45204 == env45205) = true)

def env45206 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32883,1344,262144,42333,32769,1345,41088,17,263632,33236,41244,42274,1296,42060,43129,262562,303355,257,42076,1344,41821]

theorem envBound45206 : H12AffineFastState.Bounded env45206 := by
  intro p hp
  have h : env45206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45205_45206 : H12AffineEnvironment.transform 11 1344 env45205 = env45206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env45205 == env45206) = true)

theorem identity45206 : scanCanonicalize (H12AffineFastState.compose env45206 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound45206 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env45207 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,8192,81,32768,32883,1,262144,40988,32769,0,41088,17,262289,33236,41244,41059,81,41229,43129,262562,303355,257,41245,1,41821]

theorem envBound45207 : H12AffineFastState.Bounded env45207 := by
  intro p hp
  have h : env45207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45206_45207 : H12AffineEnvironment.transform 9 321 env45206 = env45207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env45206 == env45207) = true)

theorem identity45207 : scanCanonicalize (H12AffineFastState.compose env45207 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound45207 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env45208 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,8192,81,8541,8494,1,262144,321,8540,0,477,17,262289,8329,65,318,81,80,2340,262562,262566,257,64,1,512]

theorem envBound45208 : H12AffineFastState.Bounded env45208 := by
  intro p hp
  have h : env45208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45207_45208 : H12AffineEnvironment.transform 14 8541 env45207 = env45208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env45207 == env45208) = true)

theorem identity45208 : scanCanonicalize (H12AffineFastState.compose env45208 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound45208 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env45209 : List Nat := [2,4,8,16,32,64,128,20,512,85,2048,1,8192,81,8265,8250,1,262144,85,8264,0,201,17,262289,8329,65,42,81,80,2096,262326,262322,21,64,1,512]

theorem envBound45209 : H12AffineFastState.Bounded env45209 := by
  intro p hp
  have h : env45209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45208_45209 : H12AffineEnvironment.transform 7 20 env45208 = env45209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env45208 == env45209) = true)

theorem identity45209 : scanCanonicalize (H12AffineFastState.compose env45209 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 657) := by decide +kernel

theorem selectedBound45209 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env45210 : List Nat := [2,4,8,16,32,64,128,20,512,85,2048,1,657,81,728,683,1,262144,85,729,0,201,17,262289,536,65,42,81,80,2096,262326,262322,21,64,1,512]

theorem envBound45210 : H12AffineFastState.Bounded env45210 := by
  intro p hp
  have h : env45210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45209_45210 : H12AffineEnvironment.transform 12 657 env45209 = env45210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 657 env45209 == env45210) = true)

theorem identity45210 : scanCanonicalize (H12AffineFastState.compose env45210 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound45210 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env45211 : List Nat := [2,4,8,16,32,17,128,20,512,4,2048,1,657,0,649,683,1,262144,4,648,0,152,17,262289,536,16,42,0,1,2096,262326,262322,21,17,1,512]

theorem envBound45211 : H12AffineFastState.Bounded env45211 := by
  intro p hp
  have h : env45211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45210_45211 : H12AffineEnvironment.transform 5 17 env45210 = env45211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45210 == env45211) = true)

theorem identity45211 : scanCanonicalize (H12AffineFastState.compose env45211 (packedSelected [1,3,13] rootPS)) = affineNative (2^(17+1) ^^^ 2097) := by decide +kernel

theorem selectedBound45211 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env45212 : List Nat := [2,4,8,16,32,17,128,20,512,4,2048,1,657,0,649,683,1,2097,4,648,0,152,17,2208,536,16,42,0,1,2096,2183,2179,21,17,1,512]

theorem envBound45212 : H12AffineFastState.Bounded env45212 := by
  intro p hp
  have h : env45212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45211_45212 : H12AffineEnvironment.transform 17 2097 env45211 = env45212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2097 env45211 == env45212) = true)

theorem identity45212 : scanCanonicalize (H12AffineFastState.compose env45212 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 146) := by decide +kernel

theorem selectedBound45212 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env45213 : List Nat := [2,4,8,16,32,17,128,20,512,4,146,1,657,0,649,683,1,163,4,648,0,152,17,50,536,16,42,0,1,162,21,17,21,17,1,512]

theorem envBound45213 : H12AffineFastState.Bounded env45213 := by
  intro p hp
  have h : env45213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45212_45213 : H12AffineEnvironment.transform 10 146 env45212 = env45213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 146 env45212 == env45213) = true)

theorem identity45213 : scanCanonicalize (H12AffineFastState.compose env45213 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 6) := by decide +kernel

theorem selectedBound45213 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45214 : List Nat := [2,4,8,16,32,17,128,20,6,4,146,1,151,0,143,173,1,163,4,142,0,152,17,50,30,16,42,0,1,162,21,17,21,17,1,6]

theorem envBound45214 : H12AffineFastState.Bounded env45214 := by
  intro p hp
  have h : env45214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45213_45214 : H12AffineEnvironment.transform 8 6 env45213 = env45214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 6 env45213 == env45214) = true)

theorem identity45214 : scanCanonicalize (H12AffineFastState.compose env45214 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound45214 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env45215 : List Nat := [2,4,8,16,32,17,8,20,6,4,26,1,31,0,7,37,1,43,4,6,0,16,17,50,30,16,42,0,1,42,21,17,21,17,1,6]

theorem envBound45215 : H12AffineFastState.Bounded env45215 := by
  intro p hp
  have h : env45215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45214_45215 : H12AffineEnvironment.transform 6 8 env45214 = env45215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env45214 == env45215) = true)

theorem identity45215 : scanCanonicalize (H12AffineFastState.compose env45215 (packedSelected [0,2,4] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound45215 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env45216 : List Nat := [2,4,8,11,32,10,8,15,6,4,1,1,4,0,7,37,1,43,4,6,0,11,10,41,5,11,42,0,1,42,14,10,14,10,1,6]

theorem envBound45216 : H12AffineFastState.Bounded env45216 := by
  intro p hp
  have h : env45216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45215_45216 : H12AffineEnvironment.transform 3 11 env45215 = env45216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env45215 == env45216) = true)

theorem identity45216 : scanCanonicalize (H12AffineFastState.compose env45216 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound45216 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45217 : List Nat := [2,4,8,11,13,10,8,15,6,4,1,1,4,0,7,8,1,6,4,6,0,11,10,4,5,11,7,0,1,7,14,10,14,10,1,6]

theorem envBound45217 : H12AffineFastState.Bounded env45217 := by
  intro p hp
  have h : env45217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45216_45217 : H12AffineEnvironment.transform 4 13 env45216 = env45217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env45216 == env45217) = true)

theorem identity45217 : scanCanonicalize (H12AffineFastState.compose env45217 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound45217 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45218 : List Nat := [2,3,8,11,10,10,8,8,1,3,1,1,3,0,0,8,1,1,3,1,0,11,10,3,2,11,0,0,1,0,9,10,9,10,1,1]

theorem envBound45218 : H12AffineFastState.Bounded env45218 := by
  intro p hp
  have h : env45218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45217_45218 : H12AffineEnvironment.transform 1 3 env45217 = env45218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env45217 == env45218) = true)

def env45219 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32883,1344,262144,42332,32769,1344,41089,17,263633,33237,41245,42275,1296,42060,43128,262563,303354,257,42076,1344,41820]

theorem envBound45219 : H12AffineFastState.Bounded env45219 := by
  intro p hp
  have h : env45219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45205_45219 : H12AffineEnvironment.transform 11 1345 env45205 = env45219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env45205 == env45219) = true)

theorem identity45219 : scanCanonicalize (H12AffineFastState.compose env45219 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 34227) := by decide +kernel

theorem selectedBound45219 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env45220 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32883,1344,34227,42332,32769,1344,41089,17,32866,33237,41245,42275,1296,42060,43128,33808,9545,257,42076,1344,41820]

theorem envBound45220 : H12AffineFastState.Bounded env45220 := by
  intro p hp
  have h : env45220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45219_45220 : H12AffineEnvironment.transform 17 34227 env45219 = env45220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 34227 env45219 == env45220) = true)

theorem identity45220 : scanCanonicalize (H12AffineFastState.compose env45220 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound45220 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env45221 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,8192,1296,32768,32883,1344,34227,42332,32769,1344,41089,17,32866,33237,41245,42275,1296,42060,43128,33808,9545,257,42076,1344,41429]

theorem envBound45221 : H12AffineFastState.Bounded env45221 := by
  intro p hp
  have h : env45221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45220_45221 : H12AffineEnvironment.transform 8 137 env45220 = env45221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env45220 == env45221) = true)

def env45222 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1345,262144,77935,32769,4097,46529,17,266385,70886,78894,77841,1296,74815,81227,365712,308666,257,74799,1344,79471]

theorem envBound45222 : H12AffineFastState.Bounded env45222 := by
  intro p hp
  have h : env45222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45203_45222 : H12AffineEnvironment.transform 13 1297 env45203 = env45222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env45203 == env45222) = true)

theorem identity45222 : scanCanonicalize (H12AffineFastState.compose env45222 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound45222 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env45223 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1345,262144,77935,13341,4097,477,17,266385,70886,78894,77841,1296,74815,81227,336012,262566,257,74799,1344,79471]

theorem envBound45223 : H12AffineFastState.Bounded env45223 := by
  intro p hp
  have h : env45223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45222_45223 : H12AffineEnvironment.transform 14 13340 env45222 = env45223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env45222 == env45223) = true)

def env45224 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1345,65664,77935,13341,4097,477,17,69649,70886,78894,77841,1296,74815,81227,8204,65830,257,74799,1344,79471]

theorem envBound45224 : H12AffineFastState.Bounded env45224 := by
  intro p hp
  have h : env45224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45223_45224 : H12AffineEnvironment.transform 17 65664 env45223 = env45224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env45223 == env45224) = true)

theorem identity45224 : scanCanonicalize (H12AffineFastState.compose env45224 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5158) := by decide +kernel

theorem selectedBound45224 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env45225 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,5158,1345,5286,9289,13341,4097,477,17,1079,192,8200,9271,1296,12313,10605,8204,5376,257,12297,1344,8777]

theorem envBound45225 : H12AffineFastState.Bounded env45225 := by
  intro p hp
  have h : env45225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45224_45225 : H12AffineEnvironment.transform 15 5158 env45224 = env45225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5158 env45224 == env45225) = true)

def env45226 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,1297,13340,5158,1297,5286,9241,13341,4097,397,17,1079,144,8200,9271,1296,12313,10557,8204,5376,257,12297,1296,8729]

theorem envBound45226 : H12AffineFastState.Bounded env45226 := by
  intro p hp
  have h : env45226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45225_45226 : H12AffineEnvironment.transform 5 16 env45225 = env45226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45225 == env45226) = true)

theorem identity45226 : scanCanonicalize (H12AffineFastState.compose env45226 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound45226 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env45227 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,1053,1297,4097,5158,1297,5286,4,4096,4097,397,17,1079,144,1045,42,1296,5124,3360,1041,5376,257,5140,1296,1540]

theorem envBound45227 : H12AffineFastState.Bounded env45227 := by
  intro p hp
  have h : env45227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45226_45227 : H12AffineEnvironment.transform 12 1053 env45226 = env45227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env45226 == env45227) = true)

theorem identity45227 : scanCanonicalize (H12AffineFastState.compose env45227 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound45227 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env45228 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,277,1053,1297,276,1331,1297,1459,4,277,276,397,17,1079,144,1045,42,1296,1297,3360,1041,1045,257,1281,1296,1540]

theorem envBound45228 : H12AffineFastState.Bounded env45228 := by
  intro p hp
  have h : env45228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45227_45228 : H12AffineEnvironment.transform 11 277 env45227 = env45228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env45227 == env45228) = true)

theorem identity45228 : scanCanonicalize (H12AffineFastState.compose env45228 (packedSelected [0,2,3,7,8,11,12,15,17] rootPS)) = affineNative (2^(9+1) ^^^ 558) := by decide +kernel

theorem selectedBound45228 : packedSelected [0,2,3,7,8,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env45229 : List Nat := [2,4,8,16,32,16,128,256,512,558,2048,277,563,831,276,797,831,925,4,277,276,397,17,537,144,571,42,830,831,2830,575,571,257,815,830,42]

theorem envBound45229 : H12AffineFastState.Bounded env45229 := by
  intro p hp
  have h : env45229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45228_45229 : H12AffineEnvironment.transform 9 558 env45228 = env45229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 558 env45228 == env45229) = true)

theorem identity45229 : scanCanonicalize (H12AffineFastState.compose env45229 (packedSelected [2,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound45229 : packedSelected [2,10,19] rootPS < 2^1333 := by decide +kernel

def env45230 : List Nat := [2,4,8,16,32,16,128,256,0,46,2048,277,51,319,276,285,319,413,4,277,276,397,17,25,144,59,42,318,319,2318,63,59,257,303,318,42]

theorem envBound45230 : H12AffineFastState.Bounded env45230 := by
  intro p hp
  have h : env45230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45229_45230 : H12AffineEnvironment.transform 8 0 env45229 = env45230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env45229 == env45230) = true)

theorem identity45230 : scanCanonicalize (H12AffineFastState.compose env45230 (packedSelected [0,1,3,7,10,11,15] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound45230 : packedSelected [0,1,3,7,10,11,15] rootPS < 2^1333 := by decide +kernel

def env45231 : List Nat := [2,4,8,16,32,16,35,256,0,46,2048,277,51,319,276,285,319,318,4,277,276,302,17,25,51,59,42,318,319,2318,63,59,257,303,318,42]

theorem envBound45231 : H12AffineFastState.Bounded env45231 := by
  intro p hp
  have h : env45231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45230_45231 : H12AffineEnvironment.transform 6 35 env45230 = env45231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env45230 == env45231) = true)

theorem identity45231 : scanCanonicalize (H12AffineFastState.compose env45231 (packedSelected [2,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound45231 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env45232 : List Nat := [2,4,8,16,32,16,35,36,0,46,2048,49,51,27,48,57,27,26,4,49,48,10,17,25,51,59,42,26,27,2090,63,59,37,11,26,42]

theorem envBound45232 : H12AffineFastState.Bounded env45232 := by
  intro p hp
  have h : env45232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45231_45232 : H12AffineEnvironment.transform 7 36 env45231 = env45232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env45231 == env45232) = true)

def env45233 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1297,13340,5158,1296,5286,9240,13341,4097,396,17,1079,145,8200,9271,1296,12313,10556,8204,5376,257,12297,1297,8728]

theorem envBound45233 : H12AffineFastState.Bounded env45233 := by
  intro p hp
  have h : env45233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45225_45233 : H12AffineEnvironment.transform 5 17 env45225 = env45233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45225 == env45233) = true)

theorem identity45233 : scanCanonicalize (H12AffineFastState.compose env45233 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound45233 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env45234 : List Nat := [2,4,8,16,32,17,128,256,512,5,2048,4096,8192,276,12313,4131,277,4259,8221,12312,4097,396,17,50,145,8200,8242,277,12313,10556,8204,4357,257,12297,276,8728]

theorem envBound45234 : H12AffineFastState.Bounded env45234 := by
  intro p hp
  have h : env45234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45233_45234 : H12AffineEnvironment.transform 9 5 env45233 = env45234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env45233 == env45234) = true)

theorem identity45234 : scanCanonicalize (H12AffineFastState.compose env45234 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound45234 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env45235 : List Nat := [2,4,8,16,32,17,128,256,512,5,2048,276,8192,276,8461,311,277,439,8221,8460,277,396,17,50,145,8200,8242,277,8461,10556,8204,17,257,8477,276,8728]

theorem envBound45235 : H12AffineFastState.Bounded env45235 := by
  intro p hp
  have h : env45235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45234_45235 : H12AffineEnvironment.transform 11 276 env45234 = env45235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env45234 == env45235) = true)

theorem identity45235 : scanCanonicalize (H12AffineFastState.compose env45235 (packedSelected [0,1,2,3,7,10,13,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 537) := by decide +kernel

theorem selectedBound45235 : packedSelected [0,1,2,3,7,10,13,18,19] rootPS < 2^1333 := by decide +kernel

def env45236 : List Nat := [2,4,8,16,32,17,128,256,512,5,2048,276,537,276,788,311,277,439,516,789,277,396,17,50,145,529,555,277,788,2853,533,17,257,772,276,1]

theorem envBound45236 : H12AffineFastState.Bounded env45236 := by
  intro p hp
  have h : env45236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45235_45236 : H12AffineEnvironment.transform 12 537 env45235 = env45236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 537 env45235 == env45236) = true)

theorem identity45236 : scanCanonicalize (H12AffineFastState.compose env45236 (packedSelected [1,5,11,12,15,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 276) := by decide +kernel

theorem selectedBound45236 : packedSelected [1,5,11,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env45237 : List Nat := [2,4,8,16,32,17,128,256,512,5,276,276,537,276,788,311,277,439,516,789,277,396,17,50,145,529,555,277,788,561,533,17,257,772,276,1]

theorem envBound45237 : H12AffineFastState.Bounded env45237 := by
  intro p hp
  have h : env45237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45236_45237 : H12AffineEnvironment.transform 10 276 env45236 = env45237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 276 env45236 == env45237) = true)

theorem identity45237 : scanCanonicalize (H12AffineFastState.compose env45237 (packedSelected [0,7,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound45237 : packedSelected [0,7,10,11,12] rootPS < 2^1333 := by decide +kernel

def env45238 : List Nat := [2,4,8,16,32,17,128,62,512,5,42,42,537,42,554,9,43,137,516,555,43,178,17,50,145,529,555,43,554,561,533,17,63,570,42,1]

theorem envBound45238 : H12AffineFastState.Bounded env45238 := by
  intro p hp
  have h : env45238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45237_45238 : H12AffineEnvironment.transform 7 62 env45237 = env45238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env45237 == env45238) = true)

theorem identity45238 : scanCanonicalize (H12AffineFastState.compose env45238 (packedSelected [0,1,2,4,7,8,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound45238 : packedSelected [0,1,2,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env45239 : List Nat := [2,4,8,16,32,17,18,62,512,5,42,42,537,42,554,9,43,27,516,555,43,32,17,50,3,529,555,43,554,561,533,17,63,570,42,1]

theorem envBound45239 : H12AffineFastState.Bounded env45239 := by
  intro p hp
  have h : env45239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45238_45239 : H12AffineEnvironment.transform 6 18 env45238 = env45239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env45238 == env45239) = true)

theorem identity45239 : scanCanonicalize (H12AffineFastState.compose env45239 (packedSelected [1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound45239 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env45240 : List Nat := [2,4,8,16,32,17,18,62,48,5,42,42,41,42,26,9,43,27,52,27,43,32,17,50,3,33,27,43,26,1,37,17,63,10,42,1]

theorem envBound45240 : H12AffineFastState.Bounded env45240 := by
  intro p hp
  have h : env45240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45239_45240 : H12AffineEnvironment.transform 8 48 env45239 = env45240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env45239 == env45240) = true)

def env45241 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1345,65665,77935,13341,4097,477,17,69648,70886,78894,77841,1296,74815,81227,8205,65831,257,74799,1344,79471]

theorem envBound45241 : H12AffineFastState.Bounded env45241 := by
  intro p hp
  have h : env45241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45223_45241 : H12AffineEnvironment.transform 17 65665 env45223 = env45241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env45223 == env45241) = true)

theorem identity45241 : scanCanonicalize (H12AffineFastState.compose env45241 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 359) := by decide +kernel

theorem selectedBound45241 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env45242 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,359,1345,486,12552,13341,4097,477,17,4471,5505,13641,12662,1296,9560,15404,8205,64,257,9544,1344,14088]

theorem envBound45242 : H12AffineFastState.Bounded env45242 := by
  intro p hp
  have h : env45242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45241_45242 : H12AffineEnvironment.transform 15 359 env45241 = env45242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 359 env45241 == env45242) = true)

def env45243 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,1297,13340,311,1297,438,12552,13341,4097,397,17,4391,5505,13593,12582,1296,9480,15404,8205,16,257,9496,1296,14088]

theorem envBound45243 : H12AffineFastState.Bounded env45243 := by
  intro p hp
  have h : env45243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45242_45243 : H12AffineEnvironment.transform 5 16 env45242 = env45243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45242 == env45243) = true)

theorem identity45243 : scanCanonicalize (H12AffineFastState.compose env45243 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 4364) := by decide +kernel

theorem selectedBound45243 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env45244 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,4364,1297,1296,311,1297,438,4,1297,4097,397,17,4391,5505,1045,42,1296,5124,3360,4353,16,257,5140,1296,1540]

theorem envBound45244 : H12AffineFastState.Bounded env45244 := by
  intro p hp
  have h : env45244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45243_45244 : H12AffineEnvironment.transform 12 4364 env45243 = env45244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4364 env45243 == env45244) = true)

theorem identity45244 : scanCanonicalize (H12AffineFastState.compose env45244 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound45244 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env45245 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,1053,1297,1296,311,1297,438,4,1297,1296,397,17,1078,144,1045,42,1296,277,3360,1040,16,257,261,1296,1540]

theorem envBound45245 : H12AffineFastState.Bounded env45245 := by
  intro p hp
  have h : env45245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45244_45245 : H12AffineEnvironment.transform 11 1297 env45244 = env45245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env45244 == env45245) = true)

theorem identity45245 : scanCanonicalize (H12AffineFastState.compose env45245 (packedSelected [0,1,3,7,10,11,13,19] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound45245 : packedSelected [0,1,3,7,10,11,13,19] rootPS < 2^1333 := by decide +kernel

def env45246 : List Nat := [2,4,8,16,32,16,128,256,49,1024,2048,1297,1053,1297,1296,311,1297,438,4,1297,1296,397,17,1078,144,1045,42,1296,277,3360,1040,16,257,261,1296,1077]

theorem envBound45246 : H12AffineFastState.Bounded env45246 := by
  intro p hp
  have h : env45246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45245_45246 : H12AffineEnvironment.transform 8 49 env45245 = env45246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env45245 == env45246) = true)

theorem identity45246 : scanCanonicalize (H12AffineFastState.compose env45246 (packedSelected [1,2,8,12,13,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 391) := by decide +kernel

theorem selectedBound45246 : packedSelected [1,2,8,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env45247 : List Nat := [2,4,8,16,32,16,128,256,49,1024,391,1297,1053,1297,1296,311,1297,438,4,1297,1296,397,17,1078,144,1045,42,1296,277,1191,1040,16,257,261,1296,1077]

theorem envBound45247 : H12AffineFastState.Bounded env45247 := by
  intro p hp
  have h : env45247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45246_45247 : H12AffineEnvironment.transform 10 391 env45246 = env45247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 391 env45246 == env45247) = true)

theorem identity45247 : scanCanonicalize (H12AffineFastState.compose env45247 (packedSelected [2,3,8] rootPS)) = affineNative (2^(9+1) ^^^ 424) := by decide +kernel

theorem selectedBound45247 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env45248 : List Nat := [2,4,8,16,32,16,128,256,49,424,391,185,437,185,184,311,185,438,4,185,184,397,17,414,144,445,42,184,277,271,440,16,257,261,184,413]

theorem envBound45248 : H12AffineFastState.Bounded env45248 := by
  intro p hp
  have h : env45248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45247_45248 : H12AffineEnvironment.transform 9 424 env45247 = env45248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 424 env45247 == env45248) = true)

theorem identity45248 : scanCanonicalize (H12AffineFastState.compose env45248 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound45248 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env45249 : List Nat := [2,4,8,16,32,16,9,256,49,289,270,48,316,48,49,311,48,319,4,48,49,260,17,279,25,308,42,49,277,271,305,16,257,261,49,276]

theorem envBound45249 : H12AffineFastState.Bounded env45249 := by
  intro p hp
  have h : env45249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45248_45249 : H12AffineEnvironment.transform 6 9 env45248 = env45249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env45248 == env45249) = true)

theorem identity45249 : scanCanonicalize (H12AffineFastState.compose env45249 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound45249 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env45250 : List Nat := [2,4,8,16,10,16,9,256,27,267,270,26,278,26,27,285,26,277,4,26,27,260,17,279,25,286,0,27,277,271,283,16,257,261,27,276]

theorem envBound45250 : H12AffineFastState.Bounded env45250 := by
  intro p hp
  have h : env45250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45249_45250 : H12AffineEnvironment.transform 4 10 env45249 = env45250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env45249 == env45250) = true)

def env45251 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1297,13340,310,1296,439,12552,13341,4097,396,17,4390,5505,13592,12583,1296,9481,15404,8205,17,257,9497,1297,14088]

theorem envBound45251 : H12AffineFastState.Bounded env45251 := by
  intro p hp
  have h : env45251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45242_45251 : H12AffineEnvironment.transform 5 17 env45242 = env45251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45242 == env45251) = true)

theorem identity45251 : scanCanonicalize (H12AffineFastState.compose env45251 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound45251 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env45252 : List Nat := [2,4,8,16,32,17,128,256,512,5,2048,4096,8192,276,12313,310,277,439,12552,12312,4097,396,17,4390,4484,12573,12583,277,8460,14377,8205,17,257,8476,276,13069]

theorem envBound45252 : H12AffineFastState.Bounded env45252 := by
  intro p hp
  have h : env45252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45251_45252 : H12AffineEnvironment.transform 9 5 env45251 = env45252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env45251 == env45252) = true)

theorem identity45252 : scanCanonicalize (H12AffineFastState.compose env45252 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound45252 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env45253 : List Nat := [2,4,8,16,32,17,128,256,512,5,2048,4096,25,276,4096,310,277,439,4369,4097,4097,396,17,4390,4484,4356,4414,277,277,6192,20,17,257,261,276,4884]

theorem envBound45253 : H12AffineFastState.Bounded env45253 := by
  intro p hp
  have h : env45253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45252_45253 : H12AffineEnvironment.transform 12 25 env45252 = env45253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env45252 == env45253) = true)

theorem identity45253 : scanCanonicalize (H12AffineFastState.compose env45253 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 941) := by decide +kernel

theorem selectedBound45253 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env45254 : List Nat := [2,4,8,16,32,17,128,256,512,5,941,4096,25,276,4096,310,277,439,4369,4097,4097,396,17,4390,4484,4356,4414,277,277,5021,20,17,257,261,276,4884]

theorem envBound45254 : H12AffineFastState.Bounded env45254 := by
  intro p hp
  have h : env45254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45253_45254 : H12AffineEnvironment.transform 10 941 env45253 = env45254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 941 env45253 == env45254) = true)

theorem identity45254 : scanCanonicalize (H12AffineFastState.compose env45254 (packedSelected [0,1,5,7,11,12,15,17] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound45254 : packedSelected [0,1,5,7,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env45255 : List Nat := [2,4,8,16,11,17,128,256,512,5,902,4096,25,276,4096,285,277,412,4369,4097,4097,396,17,4365,4484,4356,4373,277,277,5021,20,17,257,261,276,4884]

theorem envBound45255 : H12AffineFastState.Bounded env45255 := by
  intro p hp
  have h : env45255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45254_45255 : H12AffineEnvironment.transform 4 11 env45254 = env45255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env45254 == env45255) = true)

theorem identity45255 : scanCanonicalize (H12AffineFastState.compose env45255 (packedSelected [1,3,10,11,15,18] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound45255 : packedSelected [1,3,10,11,15,18] rootPS < 2^1333 := by decide +kernel

def env45256 : List Nat := [2,4,8,16,11,17,18,256,512,5,788,4096,25,276,4096,285,277,270,4369,4097,4097,286,17,4365,4374,4356,4373,277,277,4879,20,17,257,261,276,4884]

theorem envBound45256 : H12AffineFastState.Bounded env45256 := by
  intro p hp
  have h : env45256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45255_45256 : H12AffineEnvironment.transform 6 18 env45255 = env45256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env45255 == env45256) = true)

theorem identity45256 : scanCanonicalize (H12AffineFastState.compose env45256 (packedSelected [7,9] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound45256 : packedSelected [7,9] rootPS < 2^1333 := by decide +kernel

def env45257 : List Nat := [2,4,8,16,11,17,18,256,0,5,276,4096,25,276,4096,285,277,270,4369,4097,4097,286,17,4365,4374,4356,4373,277,277,4367,20,17,257,261,276,4372]

theorem envBound45257 : H12AffineFastState.Bounded env45257 := by
  intro p hp
  have h : env45257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45256_45257 : H12AffineEnvironment.transform 8 0 env45256 = env45257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env45256 == env45257) = true)

theorem identity45257 : scanCanonicalize (H12AffineFastState.compose env45257 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 27) := by decide +kernel

theorem selectedBound45257 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env45258 : List Nat := [2,4,8,16,11,17,18,256,0,5,276,27,25,276,27,285,277,270,266,26,26,286,17,278,269,287,270,277,277,276,20,17,257,261,276,271]

theorem envBound45258 : H12AffineFastState.Bounded env45258 := by
  intro p hp
  have h : env45258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45257_45258 : H12AffineEnvironment.transform 11 27 env45257 = env45258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 27 env45257 == env45258) = true)

def env45259 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16465,262144,95614,32769,4097,61648,16,284032,86519,94526,77840,1297,74815,96346,381313,323755,257,74799,1344,95102]

theorem envBound45259 : H12AffineFastState.Bounded env45259 := by
  intro p hp
  have h : env45259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45202_45259 : H12AffineEnvironment.transform 16 16465 env45202 = env45259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16465 env45202 == env45259) = true)

def env45260 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1345,262144,77934,32769,4097,46528,16,266384,70887,78894,77840,1297,74815,81226,365713,308667,257,74799,1344,79470]

theorem envBound45260 : H12AffineFastState.Bounded env45260 := by
  intro p hp
  have h : env45260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45259_45260 : H12AffineEnvironment.transform 13 1296 env45259 = env45260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env45259 == env45260) = true)

theorem identity45260 : scanCanonicalize (H12AffineFastState.compose env45260 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound45260 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env45261 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1345,262144,77934,13341,4097,476,16,266384,70887,78894,77840,1297,74815,81226,336013,262567,257,74799,1344,79470]

theorem envBound45261 : H12AffineFastState.Bounded env45261 := by
  intro p hp
  have h : env45261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45260_45261 : H12AffineEnvironment.transform 14 13340 env45260 = env45261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env45260 == env45261) = true)

def env45262 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1345,65664,77934,13341,4097,476,16,69648,70887,78894,77840,1297,74815,81226,8205,65831,257,74799,1344,79470]

theorem envBound45262 : H12AffineFastState.Bounded env45262 := by
  intro p hp
  have h : env45262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45261_45262 : H12AffineEnvironment.transform 17 65664 env45261 = env45262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env45261 == env45262) = true)

theorem identity45262 : scanCanonicalize (H12AffineFastState.compose env45262 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9327) := by decide +kernel

theorem selectedBound45262 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env45263 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,9327,1345,9455,5121,13341,4097,476,16,13439,12424,4161,5247,1297,80,6437,8205,9544,257,64,1344,4609]

theorem envBound45263 : H12AffineFastState.Bounded env45263 := by
  intro p hp
  have h : env45263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45262_45263 : H12AffineEnvironment.transform 15 9327 env45262 = env45263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9327 env45262 == env45263) = true)

def env45264 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1296,9244,9327,1345,9455,1025,9245,1,476,16,9343,8328,65,1151,1297,80,2341,8205,9544,257,64,1344,513]

theorem envBound45264 : H12AffineFastState.Bounded env45264 := by
  intro p hp
  have h : env45264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45263_45264 : H12AffineEnvironment.transform 11 0 env45263 = env45264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env45263 == env45264) = true)

theorem identity45264 : scanCanonicalize (H12AffineFastState.compose env45264 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound45264 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env45265 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,0,8192,276,8216,8299,325,8427,5,8217,1,476,16,8315,8328,65,123,277,80,2341,8205,8524,257,64,324,513]

theorem envBound45265 : H12AffineFastState.Bounded env45265 := by
  intro p hp
  have h : env45265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45264_45265 : H12AffineEnvironment.transform 9 4 env45264 = env45265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env45264 == env45265) = true)

theorem identity45265 : scanCanonicalize (H12AffineFastState.compose env45265 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound45265 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env45266 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,0,348,276,324,311,325,439,5,325,1,476,16,295,468,65,123,277,80,2341,337,16,257,64,324,513]

theorem envBound45266 : H12AffineFastState.Bounded env45266 := by
  intro p hp
  have h : env45266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45265_45266 : H12AffineEnvironment.transform 12 348 env45265 = env45266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env45265 == env45266) = true)

theorem identity45266 : scanCanonicalize (H12AffineFastState.compose env45266 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound45266 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env45267 : List Nat := [2,4,8,16,32,64,128,84,512,4,2048,0,8,64,16,99,17,227,5,17,1,136,16,115,128,65,123,65,80,2161,5,16,85,64,16,513]

theorem envBound45267 : H12AffineFastState.Bounded env45267 := by
  intro p hp
  have h : env45267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45266_45267 : H12AffineEnvironment.transform 7 84 env45266 = env45267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env45266 == env45267) = true)

theorem identity45267 : scanCanonicalize (H12AffineFastState.compose env45267 (packedSelected [1,2,3,5,15,17] rootPS)) = affineNative (2^(5+1) ^^^ 22) := by decide +kernel

theorem selectedBound45267 : packedSelected [1,2,3,5,15,17] rootPS < 2^1333 := by decide +kernel

def env45268 : List Nat := [2,4,8,16,32,22,128,2,512,4,2048,0,8,22,16,53,17,181,5,17,1,136,16,37,128,23,45,23,6,2087,5,16,3,22,16,513]

theorem envBound45268 : H12AffineFastState.Bounded env45268 := by
  intro p hp
  have h : env45268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45267_45268 : H12AffineEnvironment.transform 5 22 env45267 = env45268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 22 env45267 == env45268) = true)

theorem identity45268 : scanCanonicalize (H12AffineFastState.compose env45268 (packedSelected [2,11,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound45268 : packedSelected [2,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env45269 : List Nat := [2,4,8,16,32,22,128,2,136,4,2048,0,8,22,16,53,17,181,5,17,1,136,16,37,128,23,45,23,6,2087,5,16,3,22,16,137]

theorem envBound45269 : H12AffineFastState.Bounded env45269 := by
  intro p hp
  have h : env45269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45268_45269 : H12AffineEnvironment.transform 8 136 env45268 = env45269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env45268 == env45269) = true)

theorem identity45269 : scanCanonicalize (H12AffineFastState.compose env45269 (packedSelected [0,2,3,7,8,11,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound45269 : packedSelected [0,2,3,7,8,11,12,15] rootPS < 2^1333 := by decide +kernel

def env45270 : List Nat := [2,4,8,16,32,22,41,2,33,4,2048,0,8,22,16,53,17,28,5,17,1,33,16,37,41,23,45,23,6,2087,5,16,3,22,16,32]

theorem envBound45270 : H12AffineFastState.Bounded env45270 := by
  intro p hp
  have h : env45270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45269_45270 : H12AffineEnvironment.transform 6 41 env45269 = env45270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env45269 == env45270) = true)

theorem identity45270 : scanCanonicalize (H12AffineFastState.compose env45270 (packedSelected [1,2,4,8,9,11] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound45270 : packedSelected [1,2,4,8,9,11] rootPS < 2^1333 := by decide +kernel

def env45271 : List Nat := [2,4,8,7,32,1,41,2,33,4,2048,0,8,1,7,34,6,11,5,6,1,33,7,37,41,0,45,0,6,2087,5,7,3,1,7,32]

theorem envBound45271 : H12AffineFastState.Bounded env45271 := by
  intro p hp
  have h : env45271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45270_45271 : H12AffineEnvironment.transform 3 7 env45270 = env45271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env45270 == env45271) = true)

theorem identity45271 : scanCanonicalize (H12AffineFastState.compose env45271 (packedSelected [1,2,3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound45271 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env45272 : List Nat := [2,4,5,7,32,1,36,2,33,4,2048,0,5,1,7,34,6,6,5,6,1,33,7,37,36,0,32,0,6,2087,5,7,3,1,7,32]

theorem envBound45272 : H12AffineFastState.Bounded env45272 := by
  intro p hp
  have h : env45272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45271_45272 : H12AffineEnvironment.transform 2 5 env45271 = env45272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env45271 == env45272) = true)

theorem identity45272 : scanCanonicalize (H12AffineFastState.compose env45272 (packedSelected [1,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound45272 : packedSelected [1,2,4] rootPS < 2^1333 := by decide +kernel

def env45273 : List Nat := [2,4,5,7,3,1,7,2,2,4,2048,0,5,1,7,1,6,6,5,6,1,2,7,6,7,0,3,0,6,2052,5,7,3,1,7,3]

theorem envBound45273 : H12AffineFastState.Bounded env45273 := by
  intro p hp
  have h : env45273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45272_45273 : H12AffineEnvironment.transform 4 3 env45272 = env45273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env45272 == env45273) = true)

theorem identity45273 : scanCanonicalize (H12AffineFastState.compose env45273 (packedSelected [7] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound45273 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env45274 : List Nat := [2,3,2,0,3,1,0,2,2,3,2048,0,2,1,0,1,1,1,2,1,1,2,0,1,0,0,3,0,1,2051,2,0,3,1,0,3]

theorem envBound45274 : H12AffineFastState.Bounded env45274 := by
  intro p hp
  have h : env45274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45273_45274 : H12AffineEnvironment.transform 1 3 env45273 = env45274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env45273 == env45274) = true)

theorem identity45274 : scanCanonicalize (H12AffineFastState.compose env45274 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound45274 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45275 : List Nat := [0,1,0,0,1,1,0,0,0,1,2048,0,0,1,0,1,1,1,0,1,1,0,0,1,0,0,1,0,1,2049,0,0,1,1,0,1]

theorem envBound45275 : H12AffineFastState.Bounded env45275 := by
  intro p hp
  have h : env45275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45274_45275 : H12AffineEnvironment.transform 0 0 env45274 = env45275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env45274 == env45275) = true)

theorem identity45275 : scanCanonicalize (H12AffineFastState.compose env45275 (packedSelected [8] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound45275 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env45276 : List Nat := [0,1,0,0,1,1,0,0,0,1,0,0,0,1,0,1,1,1,0,1,1,0,0,1,0,0,1,0,1,1,0,0,1,1,0,1]

theorem envBound45276 : H12AffineFastState.Bounded env45276 := by
  intro p hp
  have h : env45276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45275_45276 : H12AffineEnvironment.transform 10 0 env45275 = env45276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env45275 == env45276) = true)

def env45277 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1296,9245,9327,1345,9455,1024,9244,0,476,16,9342,8329,64,1150,1297,80,2340,8205,9544,257,64,1344,512]

theorem envBound45277 : H12AffineFastState.Bounded env45277 := by
  intro p hp
  have h : env45277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45263_45277 : H12AffineEnvironment.transform 11 1 env45263 = env45277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env45263 == env45277) = true)

theorem identity45277 : scanCanonicalize (H12AffineFastState.compose env45277 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound45277 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env45278 : List Nat := [2,4,8,16,32,64,128,256,512,84,2048,1,8192,324,8265,8251,277,8379,84,8264,0,476,16,8234,8329,64,42,325,80,2340,8205,8476,257,64,276,512]

theorem envBound45278 : H12AffineFastState.Bounded env45278 := by
  intro p hp
  have h : env45278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45277_45278 : H12AffineEnvironment.transform 9 84 env45277 = env45278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env45277 == env45278) = true)

theorem identity45278 : scanCanonicalize (H12AffineFastState.compose env45278 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound45278 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env45279 : List Nat := [2,4,8,16,32,64,128,69,512,84,2048,1,8192,1,8265,8251,80,8379,84,8264,0,153,16,8234,8329,64,42,0,80,2145,8205,8281,68,64,81,512]

theorem envBound45279 : H12AffineFastState.Bounded env45279 := by
  intro p hp
  have h : env45279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45278_45279 : H12AffineEnvironment.transform 7 69 env45278 = env45279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env45278 == env45279) = true)

theorem identity45279 : scanCanonicalize (H12AffineFastState.compose env45279 (packedSelected [0,1,3,5,7,8,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 123) := by decide +kernel

theorem selectedBound45279 : packedSelected [0,1,3,5,7,8,13,17,18] rootPS < 2^1333 := by decide +kernel

def env45280 : List Nat := [2,4,8,16,32,64,128,69,512,84,123,1,8192,1,8265,8251,80,8379,84,8264,0,153,16,8234,8329,64,42,0,80,26,8205,8281,68,64,81,512]

theorem envBound45280 : H12AffineFastState.Bounded env45280 := by
  intro p hp
  have h : env45280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45279_45280 : H12AffineEnvironment.transform 10 123 env45279 = env45280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 123 env45279 == env45280) = true)

theorem identity45280 : scanCanonicalize (H12AffineFastState.compose env45280 (packedSelected [1,3,4,5,8,9,10,11,13] rootPS)) = affineNative (2^(8+1) ^^^ 216) := by decide +kernel

theorem selectedBound45280 : packedSelected [1,3,4,5,8,9,10,11,13] rootPS < 2^1333 := by decide +kernel

def env45281 : List Nat := [2,4,8,16,32,64,128,69,216,84,123,1,8192,1,8265,8251,80,8379,84,8264,0,153,16,8234,8329,64,42,0,80,26,8205,8281,68,64,81,216]

theorem envBound45281 : H12AffineFastState.Bounded env45281 := by
  intro p hp
  have h : env45281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45280_45281 : H12AffineEnvironment.transform 8 216 env45280 = env45281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env45280 == env45281) = true)

theorem identity45281 : scanCanonicalize (H12AffineFastState.compose env45281 (packedSelected [3,4,8,9,11] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound45281 : packedSelected [3,4,8,9,11] rootPS < 2^1333 := by decide +kernel

def env45282 : List Nat := [2,4,8,16,32,64,105,69,49,84,123,1,8192,1,8265,8251,80,8274,84,8264,0,112,16,8234,8288,64,42,0,80,26,8205,8281,68,64,81,49]

theorem envBound45282 : H12AffineFastState.Bounded env45282 := by
  intro p hp
  have h : env45282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45281_45282 : H12AffineEnvironment.transform 6 105 env45281 = env45282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env45281 == env45282) = true)

theorem identity45282 : scanCanonicalize (H12AffineFastState.compose env45282 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 51) := by decide +kernel

theorem selectedBound45282 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env45283 : List Nat := [2,4,8,16,32,64,105,69,49,84,123,1,51,1,122,8,80,97,84,123,0,112,16,25,83,64,42,0,80,26,62,106,68,64,81,49]

theorem envBound45283 : H12AffineFastState.Bounded env45283 := by
  intro p hp
  have h : env45283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45282_45283 : H12AffineEnvironment.transform 12 51 env45282 = env45283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 51 env45282 == env45283) = true)

theorem identity45283 : scanCanonicalize (H12AffineFastState.compose env45283 (packedSelected [0,1,2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound45283 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env45284 : List Nat := [2,4,8,16,10,64,67,69,27,84,81,1,25,1,80,8,80,75,84,81,0,90,16,25,83,64,0,0,80,26,20,64,68,64,81,27]

theorem envBound45284 : H12AffineFastState.Bounded env45284 := by
  intro p hp
  have h : env45284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45283_45284 : H12AffineEnvironment.transform 4 10 env45283 = env45284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env45283 == env45284) = true)

theorem identity45284 : scanCanonicalize (H12AffineFastState.compose env45284 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound45284 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45285 : List Nat := [2,4,8,7,10,64,67,69,12,67,70,1,14,1,71,8,71,75,67,70,0,77,7,14,68,64,0,0,71,13,3,64,68,64,70,12]

theorem envBound45285 : H12AffineFastState.Bounded env45285 := by
  intro p hp
  have h : env45285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45284_45285 : H12AffineEnvironment.transform 3 7 env45284 = env45285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env45284 == env45285) = true)

theorem identity45285 : scanCanonicalize (H12AffineFastState.compose env45285 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 7) := by decide +kernel

theorem selectedBound45285 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env45286 : List Nat := [2,4,8,7,10,7,4,2,12,4,1,1,14,1,0,8,0,12,4,1,0,10,7,14,3,7,0,0,0,13,3,7,3,7,1,12]

theorem envBound45286 : H12AffineFastState.Bounded env45286 := by
  intro p hp
  have h : env45286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45285_45286 : H12AffineEnvironment.transform 5 7 env45285 = env45286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 7 env45285 == env45286) = true)

theorem identity45286 : scanCanonicalize (H12AffineFastState.compose env45286 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound45286 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45287 : List Nat := [2,4,4,7,6,7,4,2,0,4,1,1,2,1,0,4,0,0,4,1,0,6,7,2,3,7,0,0,0,1,3,7,3,7,1,0]

theorem envBound45287 : H12AffineFastState.Bounded env45287 := by
  intro p hp
  have h : env45287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45286_45287 : H12AffineEnvironment.transform 2 4 env45286 = env45287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env45286 == env45287) = true)

def env45288 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1345,65665,77934,13341,4097,476,16,69649,70887,78894,77840,1297,74815,81226,8204,65830,257,74799,1344,79470]

theorem envBound45288 : H12AffineFastState.Bounded env45288 := by
  intro p hp
  have h : env45288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45261_45288 : H12AffineEnvironment.transform 17 65665 env45261 = env45288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env45261 == env45288) = true)

theorem identity45288 : scanCanonicalize (H12AffineFastState.compose env45288 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12590) := by decide +kernel

theorem selectedBound45288 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env45289 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,12590,1345,12719,320,13341,4097,476,16,8511,9673,1280,318,1297,5393,3172,8204,12296,257,5377,1344,1856]

theorem envBound45289 : H12AffineFastState.Bounded env45289 := by
  intro p hp
  have h : env45289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45288_45289 : H12AffineEnvironment.transform 15 12590 env45288 = env45289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12590 env45288 == env45289) = true)

def env45290 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,80,12636,12590,1,12719,320,12637,4097,476,16,8511,8329,64,318,81,4177,2340,8204,12296,257,4161,0,512]

theorem envBound45290 : H12AffineFastState.Bounded env45290 := by
  intro p hp
  have h : env45290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45289_45290 : H12AffineEnvironment.transform 9 320 env45289 = env45290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env45289 == env45290) = true)

theorem identity45290 : scanCanonicalize (H12AffineFastState.compose env45290 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound45290 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env45291 : List Nat := [2,4,8,16,32,64,128,20,512,84,2048,4096,8192,80,12360,12346,1,12475,84,12361,4097,200,16,8235,8329,64,42,81,4177,2096,8204,12296,21,4161,0,512]

theorem envBound45291 : H12AffineFastState.Bounded env45291 := by
  intro p hp
  have h : env45291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45290_45291 : H12AffineEnvironment.transform 7 20 env45290 = env45291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env45290 == env45291) = true)

theorem identity45291 : scanCanonicalize (H12AffineFastState.compose env45291 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound45291 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env45292 : List Nat := [2,4,8,16,32,64,128,20,512,84,2048,80,8192,80,8216,8298,1,8427,84,8217,81,200,16,8235,8329,64,42,81,1,2096,8204,8280,21,17,0,512]

theorem envBound45292 : H12AffineFastState.Bounded env45292 := by
  intro p hp
  have h : env45292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45291_45292 : H12AffineEnvironment.transform 11 80 env45291 = env45292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env45291 == env45292) = true)

theorem identity45292 : scanCanonicalize (H12AffineFastState.compose env45292 (packedSelected [0,1,3,5,7,8,10,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 194) := by decide +kernel

theorem selectedBound45292 : packedSelected [0,1,3,5,7,8,10,11,13] rootPS < 2^1333 := by decide +kernel

def env45293 : List Nat := [2,4,8,16,32,64,128,20,512,84,194,80,8192,80,8216,8298,1,8427,84,8217,81,200,16,8235,8329,64,42,81,1,242,8204,8280,21,17,0,512]

theorem envBound45293 : H12AffineFastState.Bounded env45293 := by
  intro p hp
  have h : env45293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45292_45293 : H12AffineEnvironment.transform 10 194 env45292 = env45293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 194 env45292 == env45293) = true)

theorem identity45293 : scanCanonicalize (H12AffineFastState.compose env45293 (packedSelected [2,3,5,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound45293 : packedSelected [2,3,5,12,15] rootPS < 2^1333 := by decide +kernel

def env45294 : List Nat := [2,4,8,16,32,64,105,20,512,84,43,80,8192,80,8216,8298,1,8194,84,8217,81,33,16,8235,8288,64,42,81,1,27,8204,8280,21,17,0,512]

theorem envBound45294 : H12AffineFastState.Bounded env45294 := by
  intro p hp
  have h : env45294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45293_45294 : H12AffineEnvironment.transform 6 105 env45293 = env45294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env45293 == env45294) = true)

theorem identity45294 : scanCanonicalize (H12AffineFastState.compose env45294 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(12+1) ^^^ 594) := by decide +kernel

theorem selectedBound45294 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env45295 : List Nat := [2,4,8,16,32,64,105,20,512,84,43,80,594,80,586,568,1,592,84,587,81,33,16,633,562,64,42,81,1,27,606,522,21,17,0,512]

theorem envBound45295 : H12AffineFastState.Bounded env45295 := by
  intro p hp
  have h : env45295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45294_45295 : H12AffineEnvironment.transform 12 594 env45294 = env45295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 594 env45294 == env45295) = true)

theorem identity45295 : scanCanonicalize (H12AffineFastState.compose env45295 (packedSelected [0,1,2,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound45295 : packedSelected [0,1,2,8,9] rootPS < 2^1333 := by decide +kernel

def env45296 : List Nat := [2,4,8,16,32,10,35,20,512,30,43,26,536,26,512,568,1,538,30,513,27,33,16,563,562,10,42,27,1,27,532,522,21,17,0,512]

theorem envBound45296 : H12AffineFastState.Bounded env45296 := by
  intro p hp
  have h : env45296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45295_45296 : H12AffineEnvironment.transform 5 10 env45295 = env45296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env45295 == env45296) = true)

theorem identity45296 : scanCanonicalize (H12AffineFastState.compose env45296 (packedSelected [0,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound45296 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env45297 : List Nat := [2,4,8,16,10,10,9,20,512,30,1,26,536,26,512,530,1,538,30,513,27,11,16,537,536,10,0,27,1,27,532,522,21,17,0,512]

theorem envBound45297 : H12AffineFastState.Bounded env45297 := by
  intro p hp
  have h : env45297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45296_45297 : H12AffineEnvironment.transform 4 10 env45296 = env45297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env45296 == env45297) = true)

def env45298 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,81,12637,12590,0,12719,320,12636,4097,476,16,8511,8328,65,318,80,4176,2341,8204,12296,257,4160,1,513]

theorem envBound45298 : H12AffineFastState.Bounded env45298 := by
  intro p hp
  have h : env45298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45289_45298 : H12AffineEnvironment.transform 9 321 env45289 = env45298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env45289 == env45298) = true)

theorem identity45298 : scanCanonicalize (H12AffineFastState.compose env45298 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound45298 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env45299 : List Nat := [2,4,8,16,32,64,128,69,512,4,2048,4096,8192,81,12312,12395,0,12522,5,12313,4097,153,16,8314,8328,65,123,80,4176,2144,8204,12296,68,4160,1,513]

theorem envBound45299 : H12AffineFastState.Bounded env45299 := by
  intro p hp
  have h : env45299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45298_45299 : H12AffineEnvironment.transform 7 69 env45298 = env45299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env45298 == env45299) = true)

theorem identity45299 : scanCanonicalize (H12AffineFastState.compose env45299 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound45299 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env45300 : List Nat := [2,4,8,16,32,64,128,69,512,4,2048,4096,24,81,4096,4211,0,4338,5,4097,4097,153,16,98,144,65,123,80,4176,2144,20,4112,68,4160,1,513]

theorem envBound45300 : H12AffineFastState.Bounded env45300 := by
  intro p hp
  have h : env45300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45299_45300 : H12AffineEnvironment.transform 12 24 env45299 = env45300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env45299 == env45300) = true)

theorem identity45300 : scanCanonicalize (H12AffineFastState.compose env45300 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound45300 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env45301 : List Nat := [2,4,8,16,32,64,128,69,512,4,2048,16,24,81,16,99,0,226,5,17,17,153,16,98,144,65,123,80,64,2144,20,0,68,80,1,513]

theorem envBound45301 : H12AffineFastState.Bounded env45301 := by
  intro p hp
  have h : env45301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45300_45301 : H12AffineEnvironment.transform 11 16 env45300 = env45301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env45300 == env45301) = true)

theorem identity45301 : scanCanonicalize (H12AffineFastState.compose env45301 (packedSelected [0,1,7,8,11,15] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound45301 : packedSelected [0,1,7,8,11,15] rootPS < 2^1333 := by decide +kernel

def env45302 : List Nat := [2,4,8,16,32,64,105,69,512,4,2048,16,24,81,16,99,0,11,5,17,17,112,16,98,121,65,123,80,64,2144,20,0,68,80,1,513]

theorem envBound45302 : H12AffineFastState.Bounded env45302 := by
  intro p hp
  have h : env45302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45301_45302 : H12AffineEnvironment.transform 6 105 env45301 = env45302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env45301 == env45302) = true)

theorem identity45302 : scanCanonicalize (H12AffineFastState.compose env45302 (packedSelected [0,1,2,3,4,5,7,9,12] rootPS)) = affineNative (2^(5+1) ^^^ 22) := by decide +kernel

theorem selectedBound45302 : packedSelected [0,1,2,3,4,5,7,9,12] rootPS < 2^1333 := by decide +kernel

def env45303 : List Nat := [2,4,8,16,32,22,63,19,512,4,2048,16,24,7,16,53,0,11,5,17,17,38,16,52,47,23,45,6,22,2102,20,0,18,6,1,513]

theorem envBound45303 : H12AffineFastState.Bounded env45303 := by
  intro p hp
  have h : env45303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45302_45303 : H12AffineEnvironment.transform 5 22 env45302 = env45303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 22 env45302 == env45303) = true)

theorem identity45303 : scanCanonicalize (H12AffineFastState.compose env45303 (packedSelected [13,17] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound45303 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env45304 : List Nat := [2,4,8,16,32,22,63,19,512,4,42,16,24,7,16,53,0,11,5,17,17,38,16,52,47,23,45,6,22,28,20,0,18,6,1,513]

theorem envBound45304 : H12AffineFastState.Bounded env45304 := by
  intro p hp
  have h : env45304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45303_45304 : H12AffineEnvironment.transform 10 42 env45303 = env45304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env45303 == env45304) = true)

theorem identity45304 : scanCanonicalize (H12AffineFastState.compose env45304 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 54) := by decide +kernel

theorem selectedBound45304 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env45305 : List Nat := [2,4,8,16,32,22,63,19,54,4,42,16,24,7,16,53,0,11,5,17,17,38,16,52,47,23,45,6,22,28,20,0,18,6,1,55]

theorem envBound45305 : H12AffineFastState.Bounded env45305 := by
  intro p hp
  have h : env45305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45304_45305 : H12AffineEnvironment.transform 8 54 env45304 = env45305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 54 env45304 == env45305) = true)

theorem identity45305 : scanCanonicalize (H12AffineFastState.compose env45305 (packedSelected [0,1,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound45305 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env45306 : List Nat := [2,3,8,16,32,17,56,19,49,3,42,16,24,0,16,50,0,11,2,17,17,33,16,51,40,16,42,1,17,27,19,0,18,1,1,48]

theorem envBound45306 : H12AffineFastState.Bounded env45306 := by
  intro p hp
  have h : env45306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45305_45306 : H12AffineEnvironment.transform 1 3 env45305 = env45306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env45305 == env45306) = true)

theorem identity45306 : scanCanonicalize (H12AffineFastState.compose env45306 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound45306 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45307 : List Nat := [2,3,8,16,16,17,8,19,1,3,26,16,24,0,16,2,0,11,2,17,17,17,16,3,24,16,26,1,17,27,19,0,18,1,1,0]

theorem envBound45307 : H12AffineFastState.Bounded env45307 := by
  intro p hp
  have h : env45307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45306_45307 : H12AffineEnvironment.transform 4 16 env45306 = env45307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env45306 == env45307) = true)

theorem identity45307 : scanCanonicalize (H12AffineFastState.compose env45307 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound45307 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45308 : List Nat := [1,0,8,16,16,17,8,16,1,0,25,16,24,0,16,1,0,8,1,17,17,17,16,0,24,16,25,1,17,24,16,0,17,1,1,0]

theorem envBound45308 : H12AffineFastState.Bounded env45308 := by
  intro p hp
  have h : env45308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45307_45308 : H12AffineEnvironment.transform 0 1 env45307 = env45308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env45307 == env45308) = true)

theorem identity45308 : scanCanonicalize (H12AffineFastState.compose env45308 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound45308 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env45309 : List Nat := [1,0,0,16,16,17,0,16,1,0,17,16,16,0,16,1,0,0,1,17,17,17,16,0,16,16,17,1,17,16,16,0,17,1,1,0]

theorem envBound45309 : H12AffineFastState.Bounded env45309 := by
  intro p hp
  have h : env45309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45308_45309 : H12AffineEnvironment.transform 2 0 env45308 = env45309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env45308 == env45309) = true)

def env45310 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1344,262144,77935,32769,4097,46529,16,266385,70886,78895,77840,1297,74815,81227,365712,308666,257,74799,1344,79471]

theorem envBound45310 : H12AffineFastState.Bounded env45310 := by
  intro p hp
  have h : env45310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45259_45310 : H12AffineEnvironment.transform 13 1297 env45259 = env45310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env45259 == env45310) = true)

theorem identity45310 : scanCanonicalize (H12AffineFastState.compose env45310 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32882) := by decide +kernel

theorem selectedBound45310 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env45311 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,32882,1344,262144,45085,32769,4097,46529,16,266385,38036,46173,45154,1297,42061,48441,267490,308666,257,42077,1344,46621]

theorem envBound45311 : H12AffineFastState.Bounded env45311 := by
  intro p hp
  have h : env45311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45310_45311 : H12AffineEnvironment.transform 15 32882 env45310 = env45311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32882 env45310 == env45311) = true)

def env45312 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32882,1344,262144,42333,32769,1345,41089,16,263633,33236,41245,42274,1297,42061,43129,262562,303354,257,42077,1344,41821]

theorem envBound45312 : H12AffineFastState.Bounded env45312 := by
  intro p hp
  have h : env45312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45311_45312 : H12AffineEnvironment.transform 11 1344 env45311 = env45312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env45311 == env45312) = true)

theorem identity45312 : scanCanonicalize (H12AffineFastState.compose env45312 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 277) := by decide +kernel

theorem selectedBound45312 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env45313 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,277,359,1344,262144,9288,276,1345,8596,16,263633,193,8200,9271,1297,9560,10604,262562,270831,257,9544,1344,8776]

theorem envBound45313 : H12AffineFastState.Bounded env45313 := by
  intro p hp
  have h : env45313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45312_45313 : H12AffineEnvironment.transform 14 277 env45312 = env45313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 277 env45312 == env45313) = true)

theorem identity45313 : scanCanonicalize (H12AffineFastState.compose env45313 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound45313 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env45314 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,8192,1297,277,359,1344,262144,9288,276,1345,8596,16,263633,193,8200,9271,1297,9560,10604,262562,270831,257,9544,1344,8385]

theorem envBound45314 : H12AffineFastState.Bounded env45314 := by
  intro p hp
  have h : env45314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45313_45314 : H12AffineEnvironment.transform 8 137 env45313 = env45314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env45313 == env45314) = true)

def env45315 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32882,1344,262144,42332,32769,1344,41088,16,263632,33237,41244,42275,1297,42061,43128,262563,303355,257,42077,1344,41820]

theorem envBound45315 : H12AffineFastState.Bounded env45315 := by
  intro p hp
  have h : env45315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45311_45315 : H12AffineEnvironment.transform 11 1345 env45311 = env45315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env45311 == env45315) = true)

theorem identity45315 : scanCanonicalize (H12AffineFastState.compose env45315 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 486) := by decide +kernel

theorem selectedBound45315 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env45316 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32882,1344,486,42332,32769,1344,41088,16,1078,33237,41244,42275,1297,42061,43128,69,41245,257,42077,1344,41820]

theorem envBound45316 : H12AffineFastState.Bounded env45316 := by
  intro p hp
  have h : env45316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45315_45316 : H12AffineEnvironment.transform 17 486 env45315 = env45316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 486 env45315 == env45316) = true)

theorem identity45316 : scanCanonicalize (H12AffineFastState.compose env45316 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound45316 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env45317 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,8540,8494,1344,486,1024,8541,1344,476,16,1078,8329,64,1151,1297,1297,2340,69,65,257,1281,1344,512]

theorem envBound45317 : H12AffineFastState.Bounded env45317 := by
  intro p hp
  have h : env45317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45316_45317 : H12AffineEnvironment.transform 14 8540 env45316 = env45317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env45316 == env45317) = true)

theorem identity45317 : scanCanonicalize (H12AffineFastState.compose env45317 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound45317 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env45318 : List Nat := [2,4,8,16,32,64,128,256,512,85,2048,276,8192,324,8540,8494,277,486,85,8541,277,476,16,99,8329,64,42,324,324,2340,69,65,257,340,277,512]

theorem envBound45318 : H12AffineFastState.Bounded env45318 := by
  intro p hp
  have h : env45318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45317_45318 : H12AffineEnvironment.transform 9 85 env45317 = env45318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env45317 == env45318) = true)

theorem identity45318 : scanCanonicalize (H12AffineFastState.compose env45318 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 900) := by decide +kernel

theorem selectedBound45318 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env45319 : List Nat := [2,4,8,16,32,64,128,256,512,85,2048,276,900,324,728,682,277,486,85,729,277,476,16,99,781,64,42,324,324,2340,69,65,257,340,277,512]

theorem envBound45319 : H12AffineFastState.Bounded env45319 := by
  intro p hp
  have h : env45319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45318_45319 : H12AffineEnvironment.transform 12 900 env45318 = env45319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 900 env45318 == env45319) = true)

theorem identity45319 : scanCanonicalize (H12AffineFastState.compose env45319 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound45319 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env45320 : List Nat := [2,4,8,16,32,17,128,256,512,4,2048,276,900,277,649,682,277,439,4,648,277,397,16,50,781,17,42,277,277,2340,20,16,257,261,277,512]

theorem envBound45320 : H12AffineFastState.Bounded env45320 := by
  intro p hp
  have h : env45320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45319_45320 : H12AffineEnvironment.transform 5 17 env45319 = env45320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45319 == env45320) = true)

theorem identity45320 : scanCanonicalize (H12AffineFastState.compose env45320 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 390) := by decide +kernel

theorem selectedBound45320 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env45321 : List Nat := [2,4,8,16,32,17,128,256,512,4,390,276,900,277,649,682,277,439,4,648,277,397,16,50,781,17,42,277,277,162,20,16,257,261,277,512]

theorem envBound45321 : H12AffineFastState.Bounded env45321 := by
  intro p hp
  have h : env45321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45320_45321 : H12AffineEnvironment.transform 10 390 env45320 = env45321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 390 env45320 == env45321) = true)

theorem identity45321 : scanCanonicalize (H12AffineFastState.compose env45321 (packedSelected [0,1,2,5,7,11] rootPS)) = affineNative (2^(8+1) ^^^ 439) := by decide +kernel

theorem selectedBound45321 : packedSelected [0,1,2,5,7,11] rootPS < 2^1333 := by decide +kernel

def env45322 : List Nat := [2,4,8,16,32,17,128,256,439,4,390,276,51,277,318,285,277,439,4,319,277,397,16,50,186,17,42,277,277,162,20,16,257,261,277,439]

theorem envBound45322 : H12AffineFastState.Bounded env45322 := by
  intro p hp
  have h : env45322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45321_45322 : H12AffineEnvironment.transform 8 439 env45321 = env45322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 439 env45321 == env45322) = true)

theorem identity45322 : scanCanonicalize (H12AffineFastState.compose env45322 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound45322 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env45323 : List Nat := [2,4,8,16,16,17,128,256,391,4,390,276,3,277,270,285,277,391,4,271,277,397,16,2,138,17,26,277,277,146,20,16,257,261,277,391]

theorem envBound45323 : H12AffineFastState.Bounded env45323 := by
  intro p hp
  have h : env45323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45322_45323 : H12AffineEnvironment.transform 4 16 env45322 = env45323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env45322 == env45323) = true)

theorem identity45323 : scanCanonicalize (H12AffineFastState.compose env45323 (packedSelected [3,4] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound45323 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env45324 : List Nat := [2,4,8,16,16,17,19,256,276,4,277,276,3,277,270,285,277,276,4,271,277,286,16,2,25,17,26,277,277,1,20,16,257,261,277,276]

theorem envBound45324 : H12AffineFastState.Bounded env45324 := by
  intro p hp
  have h : env45324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45323_45324 : H12AffineEnvironment.transform 6 19 env45323 = env45324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env45323 == env45324) = true)

def env45325 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95614,32769,4097,61648,147521,284033,86519,209263,225344,148800,74815,96346,381312,323754,257,74799,1344,95102]

theorem envBound45325 : H12AffineFastState.Bounded env45325 := by
  intro p hp
  have h : env45325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45201_45325 : H12AffineEnvironment.transform 23 284033 env45201 = env45325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284033 env45201 == env45325) = true)

def env45326 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16464,262144,95614,32769,4097,61648,17,284033,86519,94527,77840,1296,74815,96346,381312,323754,257,74799,1344,95102]

theorem envBound45326 : H12AffineFastState.Bounded env45326 := by
  intro p hp
  have h : env45326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45325_45326 : H12AffineEnvironment.transform 16 16464 env45325 = env45326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16464 env45325 == env45326) = true)

def env45327 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1344,262144,77934,32769,4097,46528,17,266385,70887,78895,77840,1296,74815,81226,365712,308666,257,74799,1344,79470]

theorem envBound45327 : H12AffineFastState.Bounded env45327 := by
  intro p hp
  have h : env45327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45326_45327 : H12AffineEnvironment.transform 13 1296 env45326 = env45327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env45326 == env45327) = true)

theorem identity45327 : scanCanonicalize (H12AffineFastState.compose env45327 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32883) := by decide +kernel

theorem selectedBound45327 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env45328 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,32883,1344,262144,45085,32769,4097,46528,17,266385,38036,46172,45155,1296,42060,48441,267491,308666,257,42076,1344,46621]

theorem envBound45328 : H12AffineFastState.Bounded env45328 := by
  intro p hp
  have h : env45328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45327_45328 : H12AffineEnvironment.transform 15 32883 env45327 = env45328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32883 env45327 == env45328) = true)

def env45329 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32883,1344,262144,42333,32769,1345,41088,17,263633,33236,41244,42275,1296,42060,43129,262563,303354,257,42076,1344,41821]

theorem envBound45329 : H12AffineFastState.Bounded env45329 := by
  intro p hp
  have h : env45329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45328_45329 : H12AffineEnvironment.transform 11 1344 env45328 = env45329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env45328 == env45329) = true)

theorem identity45329 : scanCanonicalize (H12AffineFastState.compose env45329 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 9245) := by decide +kernel

theorem selectedBound45329 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env45330 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,9245,9326,1344,262144,320,9244,1345,1181,17,263633,9673,1281,318,1296,81,3172,262563,263399,257,65,1344,1856]

theorem envBound45330 : H12AffineFastState.Bounded env45330 := by
  intro p hp
  have h : env45330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45329_45330 : H12AffineEnvironment.transform 14 9245 env45329 = env45330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9245 env45329 == env45330) = true)

theorem identity45330 : scanCanonicalize (H12AffineFastState.compose env45330 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound45330 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env45331 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,0,8192,80,8541,8494,0,262144,320,8540,1,477,17,262289,8329,65,318,80,81,2340,262563,262567,257,65,0,512]

theorem envBound45331 : H12AffineFastState.Bounded env45331 := by
  intro p hp
  have h : env45331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45330_45331 : H12AffineEnvironment.transform 9 320 env45330 = env45331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env45330 == env45331) = true)

theorem identity45331 : scanCanonicalize (H12AffineFastState.compose env45331 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound45331 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env45332 : List Nat := [2,4,8,16,32,64,128,21,512,85,2048,0,8192,80,8264,8251,0,262144,85,8265,1,200,17,262289,8329,65,43,80,81,2097,262326,262322,20,65,0,512]

theorem envBound45332 : H12AffineFastState.Bounded env45332 := by
  intro p hp
  have h : env45332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45331_45332 : H12AffineEnvironment.transform 7 21 env45331 = env45332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env45331 == env45332) = true)

theorem identity45332 : scanCanonicalize (H12AffineFastState.compose env45332 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 657) := by decide +kernel

theorem selectedBound45332 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env45333 : List Nat := [2,4,8,16,32,64,128,21,512,85,2048,0,657,80,729,682,0,262144,85,728,1,200,17,262289,536,65,43,80,81,2097,262326,262322,20,65,0,512]

theorem envBound45333 : H12AffineFastState.Bounded env45333 := by
  intro p hp
  have h : env45333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45332_45333 : H12AffineEnvironment.transform 12 657 env45332 = env45333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 657 env45332 == env45333) = true)

theorem identity45333 : scanCanonicalize (H12AffineFastState.compose env45333 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound45333 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env45334 : List Nat := [2,4,8,16,32,17,128,21,512,4,2048,0,657,1,648,682,0,262144,4,649,1,153,17,262289,536,16,43,1,0,2097,262326,262322,20,16,0,512]

theorem envBound45334 : H12AffineFastState.Bounded env45334 := by
  intro p hp
  have h : env45334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45333_45334 : H12AffineEnvironment.transform 5 17 env45333 = env45334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45333 == env45334) = true)

theorem identity45334 : scanCanonicalize (H12AffineFastState.compose env45334 (packedSelected [1,3,13] rootPS)) = affineNative (2^(17+1) ^^^ 2096) := by decide +kernel

theorem selectedBound45334 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env45335 : List Nat := [2,4,8,16,32,17,128,21,512,4,2048,0,657,1,648,682,0,2096,4,649,1,153,17,2209,536,16,43,1,0,2097,2182,2178,20,16,0,512]

theorem envBound45335 : H12AffineFastState.Bounded env45335 := by
  intro p hp
  have h : env45335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45334_45335 : H12AffineEnvironment.transform 17 2096 env45334 = env45335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2096 env45334 == env45335) = true)

theorem identity45335 : scanCanonicalize (H12AffineFastState.compose env45335 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 146) := by decide +kernel

theorem selectedBound45335 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env45336 : List Nat := [2,4,8,16,32,17,128,21,512,4,146,0,657,1,648,682,0,162,4,649,1,153,17,51,536,16,43,1,0,163,20,16,20,16,0,512]

theorem envBound45336 : H12AffineFastState.Bounded env45336 := by
  intro p hp
  have h : env45336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45335_45336 : H12AffineEnvironment.transform 10 146 env45335 = env45336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 146 env45335 == env45336) = true)

theorem identity45336 : scanCanonicalize (H12AffineFastState.compose env45336 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound45336 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45337 : List Nat := [2,4,8,16,32,17,128,21,7,4,146,0,150,1,143,173,0,162,4,142,1,153,17,51,31,16,43,1,0,163,20,16,20,16,0,7]

theorem envBound45337 : H12AffineFastState.Bounded env45337 := by
  intro p hp
  have h : env45337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45336_45337 : H12AffineEnvironment.transform 8 7 env45336 = env45337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env45336 == env45337) = true)

theorem identity45337 : scanCanonicalize (H12AffineFastState.compose env45337 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound45337 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env45338 : List Nat := [2,4,8,16,16,17,128,21,7,4,146,0,150,1,143,157,0,146,4,142,1,153,17,3,31,16,27,1,0,147,20,16,20,16,0,7]

theorem envBound45338 : H12AffineFastState.Bounded env45338 := by
  intro p hp
  have h : env45338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45337_45338 : H12AffineEnvironment.transform 4 16 env45337 = env45338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env45337 == env45338) = true)

theorem identity45338 : scanCanonicalize (H12AffineFastState.compose env45338 (packedSelected [0,2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound45338 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env45339 : List Nat := [2,4,8,16,16,17,8,21,7,4,26,0,30,1,7,21,0,26,4,6,1,17,17,3,31,16,27,1,0,27,20,16,20,16,0,7]

theorem envBound45339 : H12AffineFastState.Bounded env45339 := by
  intro p hp
  have h : env45339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45338_45339 : H12AffineEnvironment.transform 6 8 env45338 = env45339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env45338 == env45339) = true)

theorem identity45339 : scanCanonicalize (H12AffineFastState.compose env45339 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound45339 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45340 : List Nat := [2,4,8,12,12,13,8,9,7,4,6,0,2,1,7,9,0,6,4,6,1,13,13,3,3,12,7,1,0,7,8,12,8,12,0,7]

theorem envBound45340 : H12AffineFastState.Bounded env45340 := by
  intro p hp
  have h : env45340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45339_45340 : H12AffineEnvironment.transform 3 12 env45339 = env45340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env45339 == env45340) = true)

theorem identity45340 : scanCanonicalize (H12AffineFastState.compose env45340 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound45340 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env45341 : List Nat := [2,2,8,10,10,11,8,9,1,2,0,0,2,1,1,9,0,0,2,0,1,11,11,3,3,10,1,1,0,1,8,10,8,10,0,1]

theorem envBound45341 : H12AffineFastState.Bounded env45341 := by
  intro p hp
  have h : env45341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45340_45341 : H12AffineEnvironment.transform 1 2 env45340 = env45341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env45340 == env45341) = true)

def env45342 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32883,1344,262144,42332,32769,1344,41089,17,263632,33237,41245,42274,1296,42060,43128,262562,303355,257,42076,1344,41820]

theorem envBound45342 : H12AffineFastState.Bounded env45342 := by
  intro p hp
  have h : env45342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45328_45342 : H12AffineEnvironment.transform 11 1345 env45328 = env45342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env45328 == env45342) = true)

theorem identity45342 : scanCanonicalize (H12AffineFastState.compose env45342 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 9455) := by decide +kernel

theorem selectedBound45342 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env45343 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32883,1344,9455,42332,32769,1344,41089,17,8511,33237,41245,42274,1296,42060,43128,9549,33812,257,42076,1344,41820]

theorem envBound45343 : H12AffineFastState.Bounded env45343 := by
  intro p hp
  have h : env45343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45342_45343 : H12AffineEnvironment.transform 17 9455 env45342 = env45343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 9455 env45342 == env45343) = true)

theorem identity45343 : scanCanonicalize (H12AffineFastState.compose env45343 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound45343 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env45344 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,1345,8192,1296,32768,32883,1344,9455,42332,32769,1344,41089,17,8511,33237,41245,42274,1296,42060,43128,9549,33812,257,42076,1344,41428]

theorem envBound45344 : H12AffineFastState.Bounded env45344 := by
  intro p hp
  have h : env45344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45343_45344 : H12AffineEnvironment.transform 8 136 env45343 = env45344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env45343 == env45344) = true)

def env45345 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1345,262144,77935,32769,4097,46529,17,266384,70886,78894,77840,1296,74815,81227,365713,308667,257,74799,1344,79471]

theorem envBound45345 : H12AffineFastState.Bounded env45345 := by
  intro p hp
  have h : env45345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45326_45345 : H12AffineEnvironment.transform 13 1297 env45326 = env45345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env45326 == env45345) = true)

theorem identity45345 : scanCanonicalize (H12AffineFastState.compose env45345 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound45345 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env45346 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1345,262144,77935,13341,4097,477,17,266384,70886,78894,77840,1296,74815,81227,336013,262567,257,74799,1344,79471]

theorem envBound45346 : H12AffineFastState.Bounded env45346 := by
  intro p hp
  have h : env45346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45345_45346 : H12AffineEnvironment.transform 14 13340 env45345 = env45346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env45345 == env45346) = true)

def env45347 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1345,65664,77935,13341,4097,477,17,69648,70886,78894,77840,1296,74815,81227,8205,65831,257,74799,1344,79471]

theorem envBound45347 : H12AffineFastState.Bounded env45347 := by
  intro p hp
  have h : env45347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45346_45347 : H12AffineEnvironment.transform 17 65664 env45346 = env45347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env45346 == env45347) = true)

theorem identity45347 : scanCanonicalize (H12AffineFastState.compose env45347 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5385) := by decide +kernel

theorem selectedBound45347 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env45348 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5385,1297,277,65536,1345,65664,66918,276,4097,477,17,69648,70886,65831,66841,1296,69942,67650,5380,65831,257,69926,1344,66406]

theorem envBound45348 : H12AffineFastState.Bounded env45348 := by
  intro p hp
  have h : env45348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45347_45348 : H12AffineEnvironment.transform 12 5385 env45347 = env45348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5385 env45347 == env45348) = true)

def env45349 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5385,1297,277,65536,1297,65664,66870,276,4097,397,17,69648,70838,65831,66841,1296,69942,67602,5380,65831,257,69926,1296,66358]

theorem envBound45349 : H12AffineFastState.Bounded env45349 := by
  intro p hp
  have h : env45349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45348_45349 : H12AffineEnvironment.transform 5 16 env45348 = env45349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45348 == env45349) = true)

theorem identity45349 : scanCanonicalize (H12AffineFastState.compose env45349 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 1330) := by decide +kernel

theorem selectedBound45349 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env45350 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5385,1297,277,1330,1297,1458,4,276,4097,397,17,5410,4484,1045,43,1296,5124,3360,5380,1045,257,5140,1296,1540]

theorem envBound45350 : H12AffineFastState.Bounded env45350 := by
  intro p hp
  have h : env45350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45349_45350 : H12AffineEnvironment.transform 15 1330 env45349 = env45350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1330 env45349 == env45350) = true)

theorem identity45350 : scanCanonicalize (H12AffineFastState.compose env45350 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound45350 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env45351 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,24,1297,277,1330,1297,1458,4,276,1296,397,17,51,1173,1045,43,1296,277,3360,21,1045,257,261,1296,1540]

theorem envBound45351 : H12AffineFastState.Bounded env45351 := by
  intro p hp
  have h : env45351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45350_45351 : H12AffineEnvironment.transform 11 1297 env45350 = env45351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env45350 == env45351) = true)

theorem identity45351 : scanCanonicalize (H12AffineFastState.compose env45351 (packedSelected [0,1,3,5,7,8,11] rootPS)) = affineNative (2^(9+1) ^^^ 424) := by decide +kernel

theorem selectedBound45351 : packedSelected [0,1,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env45352 : List Nat := [2,4,8,16,32,16,128,256,512,424,2048,185,24,185,277,154,185,26,4,276,184,397,17,51,317,445,43,184,277,2184,21,445,257,261,184,940]

theorem envBound45352 : H12AffineFastState.Bounded env45352 := by
  intro p hp
  have h : env45352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45351_45352 : H12AffineEnvironment.transform 9 424 env45351 = env45352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 424 env45351 == env45352) = true)

theorem identity45352 : scanCanonicalize (H12AffineFastState.compose env45352 (packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 147) := by decide +kernel

theorem selectedBound45352 : packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env45353 : List Nat := [2,4,8,16,32,16,128,256,512,424,147,185,24,185,277,154,185,26,4,276,184,397,17,51,317,445,43,184,277,27,21,445,257,261,184,940]

theorem envBound45353 : H12AffineFastState.Bounded env45353 := by
  intro p hp
  have h : env45353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45352_45353 : H12AffineEnvironment.transform 10 147 env45352 = env45353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 147 env45352 == env45353) = true)

theorem identity45353 : scanCanonicalize (H12AffineFastState.compose env45353 (packedSelected [1,2,7,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound45353 : packedSelected [1,2,7,8,9] rootPS < 2^1333 := by decide +kernel

def env45354 : List Nat := [2,4,8,16,32,16,128,256,49,424,147,185,24,185,277,154,185,26,4,276,184,397,17,51,317,445,43,184,277,27,21,445,257,261,184,413]

theorem envBound45354 : H12AffineFastState.Bounded env45354 := by
  intro p hp
  have h : env45354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45353_45354 : H12AffineEnvironment.transform 8 49 env45353 = env45354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env45353 == env45354) = true)

def env45355 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,5385,1297,277,65536,1296,65664,66871,276,4097,396,17,69648,70839,65831,66841,1296,69942,67603,5380,65831,257,69926,1297,66359]

theorem envBound45355 : H12AffineFastState.Bounded env45355 := by
  intro p hp
  have h : env45355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45348_45355 : H12AffineEnvironment.transform 5 17 env45348 = env45355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45348 == env45355) = true)

theorem identity45355 : scanCanonicalize (H12AffineFastState.compose env45355 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound45355 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env45356 : List Nat := [2,4,8,16,32,17,128,256,512,5,2048,4096,4364,276,277,65536,277,65664,65842,276,4097,396,17,69648,69810,65831,65820,277,69942,67603,4353,65831,257,69926,276,66359]

theorem envBound45356 : H12AffineFastState.Bounded env45356 := by
  intro p hp
  have h : env45356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45355_45356 : H12AffineEnvironment.transform 9 5 env45355 = env45356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env45355 == env45356) = true)

theorem identity45356 : scanCanonicalize (H12AffineFastState.compose env45356 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 4131) := by decide +kernel

theorem selectedBound45356 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env45357 : List Nat := [2,4,8,16,32,17,128,256,512,5,2048,4096,4364,276,277,4131,277,4259,4369,276,4097,396,17,51,145,4356,4415,277,277,6192,4353,4356,257,261,276,4884]

theorem envBound45357 : H12AffineFastState.Bounded env45357 := by
  intro p hp
  have h : env45357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45356_45357 : H12AffineEnvironment.transform 15 4131 env45356 = env45357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4131 env45356 == env45357) = true)

theorem identity45357 : scanCanonicalize (H12AffineFastState.compose env45357 (packedSelected [0,2,3,7,8,10,12,15,17,18,19] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound45357 : packedSelected [0,2,3,7,8,10,12,15,17,18,19] rootPS < 2^1333 := by decide +kernel

def env45358 : List Nat := [2,4,8,16,32,17,128,256,512,5,26,4096,4364,276,277,4131,277,4259,4369,276,4097,396,17,51,145,4356,4415,277,277,4138,4353,4356,257,261,276,4884]

theorem envBound45358 : H12AffineFastState.Bounded env45358 := by
  intro p hp
  have h : env45358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45357_45358 : H12AffineEnvironment.transform 10 26 env45357 = env45358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env45357 == env45358) = true)

theorem identity45358 : scanCanonicalize (H12AffineFastState.compose env45358 (packedSelected [0,1,2,3,5,7,8,11] rootPS)) = affineNative (2^(8+1) ^^^ 391) := by decide +kernel

theorem selectedBound45358 : packedSelected [0,1,2,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env45359 : List Nat := [2,4,8,16,32,17,128,256,391,5,26,4096,4364,276,277,4131,277,4259,4369,276,4097,396,17,51,145,4356,4415,277,277,4138,4353,4356,257,261,276,4243]

theorem envBound45359 : H12AffineFastState.Bounded env45359 := by
  intro p hp
  have h : env45359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45358_45359 : H12AffineEnvironment.transform 8 391 env45358 = env45359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 391 env45358 == env45359) = true)

theorem identity45359 : scanCanonicalize (H12AffineFastState.compose env45359 (packedSelected [1,2,5,13] rootPS)) = affineNative (2^(11+1) ^^^ 27) := by decide +kernel

theorem selectedBound45359 : packedSelected [1,2,5,13] rootPS < 2^1333 := by decide +kernel

def env45360 : List Nat := [2,4,8,16,32,17,128,256,391,5,26,27,279,276,277,56,277,184,266,276,26,396,17,51,145,287,292,277,277,49,282,287,257,261,276,136]

theorem envBound45360 : H12AffineFastState.Bounded env45360 := by
  intro p hp
  have h : env45360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45359_45360 : H12AffineEnvironment.transform 11 27 env45359 = env45360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 27 env45359 == env45360) = true)

theorem identity45360 : scanCanonicalize (H12AffineFastState.compose env45360 (packedSelected [2,3,4,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound45360 : packedSelected [2,3,4,8,9] rootPS < 2^1333 := by decide +kernel

def env45361 : List Nat := [2,4,8,16,32,17,8,256,271,5,26,27,279,276,277,56,277,48,266,276,26,260,17,51,25,287,292,277,277,49,282,287,257,261,276,0]

theorem envBound45361 : H12AffineFastState.Bounded env45361 := by
  intro p hp
  have h : env45361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45360_45361 : H12AffineEnvironment.transform 6 8 env45360 = env45361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env45360 == env45361) = true)

theorem identity45361 : scanCanonicalize (H12AffineFastState.compose env45361 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound45361 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env45362 : List Nat := [2,4,8,10,32,11,8,256,271,5,0,1,269,270,271,34,271,42,266,270,0,260,11,41,3,261,292,271,271,43,256,261,257,261,270,0]

theorem envBound45362 : H12AffineFastState.Bounded env45362 := by
  intro p hp
  have h : env45362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45361_45362 : H12AffineEnvironment.transform 3 10 env45361 = env45362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env45361 == env45362) = true)

theorem identity45362 : scanCanonicalize (H12AffineFastState.compose env45362 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 2) := by decide +kernel

theorem selectedBound45362 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45363 : List Nat := [2,4,8,10,32,11,8,2,13,5,0,1,15,12,13,34,13,42,8,12,0,6,11,41,3,7,38,13,13,43,2,7,3,7,12,0]

theorem envBound45363 : H12AffineFastState.Bounded env45363 := by
  intro p hp
  have h : env45363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45362_45363 : H12AffineEnvironment.transform 7 2 env45362 = env45363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 2 env45362 == env45363) = true)

theorem identity45363 : scanCanonicalize (H12AffineFastState.compose env45363 (packedSelected [2,3] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound45363 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env45364 : List Nat := [2,4,8,10,6,11,8,2,13,5,0,1,15,12,13,4,13,12,8,12,0,6,11,15,3,7,0,13,13,13,2,7,3,7,12,0]

theorem envBound45364 : H12AffineFastState.Bounded env45364 := by
  intro p hp
  have h : env45364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45363_45364 : H12AffineEnvironment.transform 4 6 env45363 = env45364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env45363 == env45364) = true)

def env45365 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1345,65665,77935,13341,4097,477,17,69649,70886,78894,77840,1296,74815,81227,8204,65830,257,74799,1344,79471]

theorem envBound45365 : H12AffineFastState.Bounded env45365 := by
  intro p hp
  have h : env45365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45346_45365 : H12AffineEnvironment.transform 17 65665 env45346 = env45365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env45346 == env45365) = true)

theorem identity45365 : scanCanonicalize (H12AffineFastState.compose env45365 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 72) := by decide +kernel

theorem selectedBound45365 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env45366 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,72,1297,5204,65536,1345,65665,69671,5205,4097,477,17,69649,70886,70758,69720,1296,66679,72963,68,65830,257,66663,1344,71207]

theorem envBound45366 : H12AffineFastState.Bounded env45366 := by
  intro p hp
  have h : env45366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45365_45366 : H12AffineEnvironment.transform 12 72 env45365 = env45366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env45365 == env45366) = true)

def env45367 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,24,1297,5124,65536,1297,65665,69671,5125,4097,397,17,69649,70838,70710,69640,1296,66599,72963,20,65830,257,66615,1296,71207]

theorem envBound45367 : H12AffineFastState.Bounded env45367 := by
  intro p hp
  have h : env45367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45366_45367 : H12AffineEnvironment.transform 5 16 env45366 = env45367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45366 == env45367) = true)

theorem identity45367 : scanCanonicalize (H12AffineFastState.compose env45367 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 4131) := by decide +kernel

theorem selectedBound45367 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env45368 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,24,1297,5124,4131,1297,4258,4,5125,4097,397,17,50,1173,1045,43,1296,5124,3360,20,4357,257,5140,1296,1540]

theorem envBound45368 : H12AffineFastState.Bounded env45368 := by
  intro p hp
  have h : env45368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45367_45368 : H12AffineEnvironment.transform 15 4131 env45367 = env45368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4131 env45367 == env45368) = true)

theorem identity45368 : scanCanonicalize (H12AffineFastState.compose env45368 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound45368 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env45369 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,277,24,1297,1297,310,1297,439,4,1296,276,397,17,50,1173,1045,43,1296,1297,3360,20,16,257,1281,1296,1540]

theorem envBound45369 : H12AffineFastState.Bounded env45369 := by
  intro p hp
  have h : env45369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45368_45369 : H12AffineEnvironment.transform 11 277 env45368 = env45369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env45368 == env45369) = true)

theorem identity45369 : scanCanonicalize (H12AffineFastState.compose env45369 (packedSelected [0,2,3,7,8,10,12,15,17,18,19] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound45369 : packedSelected [0,2,3,7,8,10,12,15,17,18,19] rootPS < 2^1333 := by decide +kernel

def env45370 : List Nat := [2,4,8,16,32,16,128,256,27,1024,2048,277,24,1297,1297,310,1297,439,4,1296,276,397,17,50,1173,1045,43,1296,1297,3360,20,16,257,1281,1296,1055]

theorem envBound45370 : H12AffineFastState.Bounded env45370 := by
  intro p hp
  have h : env45370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45369_45370 : H12AffineEnvironment.transform 8 27 env45369 = env45370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env45369 == env45370) = true)

theorem identity45370 : scanCanonicalize (H12AffineFastState.compose env45370 (packedSelected [0,1,2,3,7,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 163) := by decide +kernel

theorem selectedBound45370 : packedSelected [0,1,2,3,7,11,13] rootPS < 2^1333 := by decide +kernel

def env45371 : List Nat := [2,4,8,16,32,16,128,256,27,1024,163,277,24,1297,1297,310,1297,439,4,1296,276,397,17,50,1173,1045,43,1296,1297,1411,20,16,257,1281,1296,1055]

theorem envBound45371 : H12AffineFastState.Bounded env45371 := by
  intro p hp
  have h : env45371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45370_45371 : H12AffineEnvironment.transform 10 163 env45370 = env45371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 163 env45370 == env45371) = true)

theorem identity45371 : scanCanonicalize (H12AffineFastState.compose env45371 (packedSelected [3,8,17] rootPS)) = affineNative (2^(9+1) ^^^ 150) := by decide +kernel

theorem selectedBound45371 : packedSelected [3,8,17] rootPS < 2^1333 := by decide +kernel

def env45372 : List Nat := [2,4,8,16,32,16,128,256,27,150,163,277,24,391,391,310,391,439,4,390,276,397,17,50,3,131,43,390,391,277,20,16,257,407,390,137]

theorem envBound45372 : H12AffineFastState.Bounded env45372 := by
  intro p hp
  have h : env45372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45371_45372 : H12AffineEnvironment.transform 9 150 env45371 = env45372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 150 env45371 == env45372) = true)

theorem identity45372 : scanCanonicalize (H12AffineFastState.compose env45372 (packedSelected [2,3,4,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound45372 : packedSelected [2,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env45373 : List Nat := [2,4,8,16,32,16,19,256,27,5,48,277,24,276,276,310,276,292,4,277,276,286,17,50,3,16,43,277,276,277,20,16,257,260,277,26]

theorem envBound45373 : H12AffineFastState.Bounded env45373 := by
  intro p hp
  have h : env45373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45372_45373 : H12AffineEnvironment.transform 6 19 env45372 = env45373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env45372 == env45373) = true)

theorem identity45373 : scanCanonicalize (H12AffineFastState.compose env45373 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound45373 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45374 : List Nat := [2,4,8,16,32,16,19,36,27,5,48,49,24,48,48,18,48,0,4,49,48,58,17,50,3,16,43,49,48,49,20,16,37,32,49,26]

theorem envBound45374 : H12AffineFastState.Bounded env45374 := by
  intro p hp
  have h : env45374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45373_45374 : H12AffineEnvironment.transform 7 36 env45373 = env45374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env45373 == env45374) = true)

theorem identity45374 : scanCanonicalize (H12AffineFastState.compose env45374 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound45374 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env45375 : List Nat := [2,4,8,2,32,2,1,36,9,5,34,35,10,34,34,0,34,0,4,35,34,40,3,32,3,2,43,35,34,35,6,2,37,32,35,8]

theorem envBound45375 : H12AffineFastState.Bounded env45375 := by
  intro p hp
  have h : env45375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45374_45375 : H12AffineEnvironment.transform 3 2 env45374 = env45375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env45374 == env45375) = true)

theorem identity45375 : scanCanonicalize (H12AffineFastState.compose env45375 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound45375 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env45376 : List Nat := [2,4,8,2,1,2,1,5,9,5,3,2,10,3,3,0,3,0,4,2,3,9,3,1,3,2,10,2,3,2,6,2,4,1,2,8]

theorem envBound45376 : H12AffineFastState.Bounded env45376 := by
  intro p hp
  have h : env45376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45375_45376 : H12AffineEnvironment.transform 4 1 env45375 = env45376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env45375 == env45376) = true)

theorem identity45376 : scanCanonicalize (H12AffineFastState.compose env45376 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound45376 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45377 : List Nat := [2,4,4,2,1,2,1,5,5,5,3,2,6,3,3,0,3,0,4,2,3,5,3,1,3,2,6,2,3,2,6,2,4,1,2,4]

theorem envBound45377 : H12AffineFastState.Bounded env45377 := by
  intro p hp
  have h : env45377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45376_45377 : H12AffineEnvironment.transform 2 4 env45376 = env45377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env45376 == env45377) = true)

theorem identity45377 : scanCanonicalize (H12AffineFastState.compose env45377 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound45377 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env45378 : List Nat := [2,1,1,2,1,2,1,0,0,0,3,2,3,3,3,0,3,0,1,2,3,0,3,1,3,2,3,2,3,2,3,2,1,1,2,1]

theorem envBound45378 : H12AffineFastState.Bounded env45378 := by
  intro p hp
  have h : env45378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45377_45378 : H12AffineEnvironment.transform 1 1 env45377 = env45378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env45377 == env45378) = true)

def env45379 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,25,1297,5125,65536,1296,65665,69671,5124,4097,396,17,69649,70839,70711,69641,1296,66598,72963,21,65830,257,66614,1297,71207]

theorem envBound45379 : H12AffineFastState.Bounded env45379 := by
  intro p hp
  have h : env45379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45366_45379 : H12AffineEnvironment.transform 5 17 env45366 = env45379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env45366 == env45379) = true)

theorem identity45379 : scanCanonicalize (H12AffineFastState.compose env45379 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound45379 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env45380 : List Nat := [2,4,8,16,32,17,128,256,512,5,2048,4096,25,276,4096,65536,277,65665,69671,4097,4097,396,17,69649,69810,69682,69641,277,65571,71942,21,65830,257,65587,276,70178]

theorem envBound45380 : H12AffineFastState.Bounded env45380 := by
  intro p hp
  have h : env45380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45379_45380 : H12AffineEnvironment.transform 9 5 env45379 = env45380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env45379 == env45380) = true)

theorem identity45380 : scanCanonicalize (H12AffineFastState.compose env45380 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound45380 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env45381 : List Nat := [2,4,8,16,32,17,128,256,512,5,2048,276,25,276,276,65536,277,65665,65843,277,277,396,17,65797,65958,65830,65821,277,65571,67602,21,65830,257,65587,276,66358]

theorem envBound45381 : H12AffineFastState.Bounded env45381 := by
  intro p hp
  have h : env45381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45380_45381 : H12AffineEnvironment.transform 11 276 env45380 = env45381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env45380 == env45381) = true)

theorem identity45381 : scanCanonicalize (H12AffineFastState.compose env45381 (packedSelected [0,1,2,3,5,7,8,18] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound45381 : packedSelected [0,1,2,3,5,7,8,18] rootPS < 2^1333 := by decide +kernel

def env45382 : List Nat := [2,4,8,16,32,17,128,256,276,5,2048,276,25,276,276,65536,277,65665,65843,277,277,396,17,65797,65958,65830,65821,277,65571,67602,21,65830,257,65587,276,65570]

theorem envBound45382 : H12AffineFastState.Bounded env45382 := by
  intro p hp
  have h : env45382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45381_45382 : H12AffineEnvironment.transform 8 276 env45381 = env45382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env45381 == env45382) = true)

theorem identity45382 : scanCanonicalize (H12AffineFastState.compose env45382 (packedSelected [2,3,8,10,12,15,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 2219) := by decide +kernel

theorem selectedBound45382 : packedSelected [2,3,8,10,12,15,17,19] rootPS < 2^1333 := by decide +kernel

def env45383 : List Nat := [2,4,8,16,32,17,128,256,276,5,2048,276,25,276,276,2219,277,2090,2456,277,277,396,17,2478,2317,2445,2486,277,2184,185,21,2445,257,2200,276,2185]

theorem envBound45383 : H12AffineFastState.Bounded env45383 := by
  intro p hp
  have h : env45383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45382_45383 : H12AffineEnvironment.transform 15 2219 env45382 = env45383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2219 env45382 == env45383) = true)

theorem identity45383 : scanCanonicalize (H12AffineFastState.compose env45383 (packedSelected [2,10,12,13] rootPS)) = affineNative (2^(10+1) ^^^ 412) := by decide +kernel

theorem selectedBound45383 : packedSelected [2,10,12,13] rootPS < 2^1333 := by decide +kernel

def env45384 : List Nat := [2,4,8,16,32,17,128,256,276,5,412,276,25,276,276,311,277,438,4,277,277,396,17,50,145,17,42,277,276,185,21,17,257,260,276,277]

theorem envBound45384 : H12AffineFastState.Bounded env45384 := by
  intro p hp
  have h : env45384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45383_45384 : H12AffineEnvironment.transform 10 412 env45383 = env45384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 412 env45383 == env45384) = true)

theorem identity45384 : scanCanonicalize (H12AffineFastState.compose env45384 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound45384 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45385 : List Nat := [2,4,8,16,32,17,128,37,49,5,185,49,25,49,49,18,48,147,4,48,48,169,17,50,145,17,42,48,49,185,21,17,36,33,49,48]

theorem envBound45385 : H12AffineFastState.Bounded env45385 := by
  intro p hp
  have h : env45385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45384_45385 : H12AffineEnvironment.transform 7 37 env45384 = env45385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env45384 == env45385) = true)

theorem identity45385 : scanCanonicalize (H12AffineFastState.compose env45385 (packedSelected [0,1,3,5] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound45385 : packedSelected [0,1,3,5] rootPS < 2^1333 := by decide +kernel

def env45386 : List Nat := [2,4,0,16,32,17,128,37,49,5,177,49,17,49,49,18,48,147,4,48,48,161,17,50,145,17,34,48,49,177,21,17,36,33,49,48]

theorem envBound45386 : H12AffineFastState.Bounded env45386 := by
  intro p hp
  have h : env45386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45385_45386 : H12AffineEnvironment.transform 2 0 env45385 = env45386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env45385 == env45386) = true)

theorem identity45386 : scanCanonicalize (H12AffineFastState.compose env45386 (packedSelected [4,7] rootPS)) = affineNative (2^(6+1) ^^^ 1) := by decide +kernel

theorem selectedBound45386 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env45387 : List Nat := [2,4,0,16,32,17,1,37,49,5,48,49,17,49,49,18,48,18,4,48,48,32,17,50,16,17,34,48,49,48,21,17,36,33,49,48]

theorem envBound45387 : H12AffineFastState.Bounded env45387 := by
  intro p hp
  have h : env45387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45386_45387 : H12AffineEnvironment.transform 6 1 env45386 = env45387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 1 env45386 == env45387) = true)

theorem identity45387 : scanCanonicalize (H12AffineFastState.compose env45387 (packedSelected [1,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound45387 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env45388 : List Nat := [2,4,0,1,32,0,1,37,32,5,33,32,0,32,32,3,33,3,4,33,33,32,0,35,1,0,34,33,32,33,4,0,36,33,32,33]

theorem envBound45388 : H12AffineFastState.Bounded env45388 := by
  intro p hp
  have h : env45388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45387_45388 : H12AffineEnvironment.transform 3 1 env45387 = env45388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env45387 == env45388) = true)

theorem identity45388 : scanCanonicalize (H12AffineFastState.compose env45388 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

end H12CloudChart2