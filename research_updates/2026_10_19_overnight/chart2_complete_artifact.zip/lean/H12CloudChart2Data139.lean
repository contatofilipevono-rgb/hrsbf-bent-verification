import H12CloudChart2Data138

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound34530 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env34531 : List Nat := [2,4,8,16,32,0,128,256,512,272,2048,773,8192,0,8476,810,8724,939,516,8477,773,648,8725,811,9117,8465,303,8709,1,10292,8204,8201,257,8724,16,276]

theorem envBound34531 : H12AffineFastState.Bounded env34531 := by
  intro p hp
  have h : env34531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34530_34531 : H12AffineEnvironment.transform 15 810 env34530 = env34531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 810 env34530 == env34531) = true)

def env34532 : List Nat := [2,4,8,16,32,0,128,256,512,272,2048,773,24,0,260,810,524,939,516,261,773,648,525,811,901,265,303,541,1,2092,20,17,257,524,16,276]

theorem envBound34532 : H12AffineFastState.Bounded env34532 := by
  intro p hp
  have h : env34532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34531_34532 : H12AffineEnvironment.transform 12 24 env34531 = env34532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env34531 == env34532) = true)

theorem identity34532 : scanCanonicalize (H12AffineFastState.compose env34532 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound34532 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env34533 : List Nat := [2,4,8,16,32,0,128,5,512,21,2048,512,24,0,1,559,524,686,516,0,512,648,525,558,640,12,42,541,1,2092,20,17,4,524,16,17]

theorem envBound34533 : H12AffineFastState.Bounded env34533 := by
  intro p hp
  have h : env34533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34532_34533 : H12AffineEnvironment.transform 7 5 env34532 = env34533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env34532 == env34533) = true)

theorem identity34533 : scanCanonicalize (H12AffineFastState.compose env34533 (packedSelected [3,11,15,18] rootPS)) = affineNative (2^(10+1) ^^^ 654) := by decide +kernel

theorem selectedBound34533 : packedSelected [3,11,15,18] rootPS < 2^1333 := by decide +kernel

def env34534 : List Nat := [2,4,8,16,32,0,128,5,512,21,654,512,24,0,1,559,524,686,516,0,512,648,525,558,640,12,42,541,1,674,20,17,4,524,16,17]

theorem envBound34534 : H12AffineFastState.Bounded env34534 := by
  intro p hp
  have h : env34534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34533_34534 : H12AffineEnvironment.transform 10 654 env34533 = env34534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 654 env34533 == env34534) = true)

theorem identity34534 : scanCanonicalize (H12AffineFastState.compose env34534 (packedSelected [2,3,5,10,12,15] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound34534 : packedSelected [2,3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env34535 : List Nat := [2,4,8,16,32,0,128,5,11,21,133,11,24,0,1,36,7,165,15,0,11,131,6,37,139,12,42,22,1,169,20,17,4,7,16,17]

theorem envBound34535 : H12AffineFastState.Bounded env34535 := by
  intro p hp
  have h : env34535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34534_34535 : H12AffineEnvironment.transform 8 11 env34534 = env34535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env34534 == env34535) = true)

theorem identity34535 : scanCanonicalize (H12AffineFastState.compose env34535 (packedSelected [0,2,3,5,7,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound34535 : packedSelected [0,2,3,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env34536 : List Nat := [2,4,8,16,32,0,8,5,11,21,13,11,24,0,1,36,7,45,15,0,11,11,6,37,3,12,42,22,1,33,20,17,4,7,16,17]

theorem envBound34536 : H12AffineFastState.Bounded env34536 := by
  intro p hp
  have h : env34536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34535_34536 : H12AffineEnvironment.transform 6 8 env34535 = env34536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env34535 == env34536) = true)

theorem identity34536 : scanCanonicalize (H12AffineFastState.compose env34536 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound34536 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env34537 : List Nat := [2,4,5,16,32,0,5,5,6,21,0,6,21,0,1,36,7,32,2,0,6,6,6,37,3,1,39,22,1,33,20,17,4,7,16,17]

theorem envBound34537 : H12AffineFastState.Bounded env34537 := by
  intro p hp
  have h : env34537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34536_34537 : H12AffineEnvironment.transform 2 5 env34536 = env34537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env34536 == env34537) = true)

theorem identity34537 : scanCanonicalize (H12AffineFastState.compose env34537 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound34537 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env34538 : List Nat := [2,4,5,16,6,0,5,5,6,21,0,6,21,0,1,2,7,6,2,0,6,6,6,3,3,1,1,22,1,7,20,17,4,7,16,17]

theorem envBound34538 : H12AffineFastState.Bounded env34538 := by
  intro p hp
  have h : env34538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34537_34538 : H12AffineEnvironment.transform 4 6 env34537 = env34538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env34537 == env34538) = true)

theorem identity34538 : scanCanonicalize (H12AffineFastState.compose env34538 (packedSelected [1,2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound34538 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env34539 : List Nat := [2,2,3,16,0,0,3,3,0,19,0,0,19,0,1,2,1,0,2,0,0,0,0,3,3,1,1,16,1,1,18,17,2,1,16,17]

theorem envBound34539 : H12AffineFastState.Bounded env34539 := by
  intro p hp
  have h : env34539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34538_34539 : H12AffineEnvironment.transform 1 2 env34538 = env34539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env34538 == env34539) = true)

theorem identity34539 : scanCanonicalize (H12AffineFastState.compose env34539 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound34539 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34540 : List Nat := [2,2,3,1,0,0,3,3,0,2,0,0,2,0,1,2,1,0,2,0,0,0,0,3,3,1,1,1,1,1,3,0,2,1,1,0]

theorem envBound34540 : H12AffineFastState.Bounded env34540 := by
  intro p hp
  have h : env34540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34539_34540 : H12AffineEnvironment.transform 3 1 env34539 = env34540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env34539 == env34540) = true)

def env34541 : List Nat := [2,4,8,16,32,0,128,256,512,272,2048,773,25,0,261,810,525,939,516,260,773,648,524,811,900,264,303,540,1,2093,21,16,257,525,16,276]

theorem envBound34541 : H12AffineFastState.Bounded env34541 := by
  intro p hp
  have h : env34541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34531_34541 : H12AffineEnvironment.transform 12 25 env34531 = env34541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env34531 == env34541) = true)

theorem identity34541 : scanCanonicalize (H12AffineFastState.compose env34541 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound34541 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env34542 : List Nat := [2,4,8,16,32,0,128,256,17,272,2048,276,25,0,261,315,28,442,21,260,276,153,29,314,405,264,303,13,1,2093,21,16,257,28,16,276]

theorem envBound34542 : H12AffineFastState.Bounded env34542 := by
  intro p hp
  have h : env34542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34541_34542 : H12AffineEnvironment.transform 8 17 env34541 = env34542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env34541 == env34542) = true)

theorem identity34542 : scanCanonicalize (H12AffineFastState.compose env34542 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound34542 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env34543 : List Nat := [2,4,5,16,32,0,128,256,17,272,2048,276,20,0,261,310,17,439,21,260,276,148,16,311,405,261,290,0,1,2080,21,16,257,17,16,276]

theorem envBound34543 : H12AffineFastState.Bounded env34543 := by
  intro p hp
  have h : env34543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34542_34543 : H12AffineEnvironment.transform 2 5 env34542 = env34543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env34542 == env34543) = true)

theorem identity34543 : scanCanonicalize (H12AffineFastState.compose env34543 (packedSelected [1,2,3,5,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 309) := by decide +kernel

theorem selectedBound34543 : packedSelected [1,2,3,5,10,12] rootPS < 2^1333 := by decide +kernel

def env34544 : List Nat := [2,4,5,16,32,0,128,256,17,272,309,276,20,0,261,310,17,439,21,260,276,148,16,311,405,261,290,0,1,277,21,16,257,17,16,276]

theorem envBound34544 : H12AffineFastState.Bounded env34544 := by
  intro p hp
  have h : env34544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34543_34544 : H12AffineEnvironment.transform 10 309 env34543 = env34544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 309 env34543 == env34544) = true)

theorem identity34544 : scanCanonicalize (H12AffineFastState.compose env34544 (packedSelected [8,13] rootPS)) = affineNative (2^(7+1) ^^^ 150) := by decide +kernel

theorem selectedBound34544 : packedSelected [8,13] rootPS < 2^1333 := by decide +kernel

def env34545 : List Nat := [2,4,5,16,32,0,128,150,17,134,163,130,20,0,147,160,17,33,21,146,130,148,16,161,3,147,180,0,1,131,21,16,151,17,16,130]

theorem envBound34545 : H12AffineFastState.Bounded env34545 := by
  intro p hp
  have h : env34545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34544_34545 : H12AffineEnvironment.transform 7 150 env34544 = env34545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 150 env34544 == env34545) = true)

theorem identity34545 : scanCanonicalize (H12AffineFastState.compose env34545 (packedSelected [2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound34545 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env34546 : List Nat := [2,4,5,16,1,0,128,150,17,134,130,130,20,0,147,129,17,0,21,146,130,148,16,128,3,147,149,0,1,131,21,16,151,17,16,130]

theorem envBound34546 : H12AffineFastState.Bounded env34546 := by
  intro p hp
  have h : env34546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34545_34546 : H12AffineEnvironment.transform 4 1 env34545 = env34546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env34545 == env34546) = true)

theorem identity34546 : scanCanonicalize (H12AffineFastState.compose env34546 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound34546 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env34547 : List Nat := [2,4,5,16,1,0,18,4,17,20,16,16,20,0,1,19,17,0,21,0,16,6,16,18,3,1,7,0,1,17,21,16,5,17,16,16]

theorem envBound34547 : H12AffineFastState.Bounded env34547 := by
  intro p hp
  have h : env34547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34546_34547 : H12AffineEnvironment.transform 6 18 env34546 = env34547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env34546 == env34547) = true)

theorem identity34547 : scanCanonicalize (H12AffineFastState.compose env34547 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound34547 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34548 : List Nat := [2,1,0,16,1,0,18,1,17,17,16,16,17,0,1,19,17,0,16,0,16,3,16,18,3,1,2,0,1,17,16,16,0,17,16,16]

theorem envBound34548 : H12AffineFastState.Bounded env34548 := by
  intro p hp
  have h : env34548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34547_34548 : H12AffineEnvironment.transform 1 1 env34547 = env34548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env34547 == env34548) = true)

theorem identity34548 : scanCanonicalize (H12AffineFastState.compose env34548 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound34548 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34549 : List Nat := [2,1,0,1,1,0,3,1,0,0,1,1,0,0,1,2,0,0,1,0,1,3,1,3,3,1,2,0,1,0,1,1,0,0,1,1]

theorem envBound34549 : H12AffineFastState.Bounded env34549 := by
  intro p hp
  have h : env34549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34548_34549 : H12AffineEnvironment.transform 3 1 env34548 = env34549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env34548 == env34549) = true)

theorem identity34549 : scanCanonicalize (H12AffineFastState.compose env34549 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound34549 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34550 : List Nat := [0,1,0,1,1,0,1,1,0,0,1,1,0,0,1,0,0,0,1,0,1,1,1,1,1,1,0,0,1,0,1,1,0,0,1,1]

theorem envBound34550 : H12AffineFastState.Bounded env34550 := by
  intro p hp
  have h : env34550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34549_34550 : H12AffineEnvironment.transform 0 0 env34549 = env34550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env34549 == env34550) = true)

def env34551 : List Nat := [2,4,8,16,32,1,128,256,512,272,2048,773,8192,0,8477,65536,74047,65665,517,8476,773,648,74047,65536,9116,74299,302,74031,1,76575,8204,8201,257,74046,17,277]

theorem envBound34551 : H12AffineFastState.Bounded env34551 := by
  intro p hp
  have h : env34551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34529_34551 : H12AffineEnvironment.transform 5 1 env34529 = env34551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env34529 == env34551) = true)

theorem identity34551 : scanCanonicalize (H12AffineFastState.compose env34551 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 9011) := by decide +kernel

theorem selectedBound34551 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env34552 : List Nat := [2,4,8,16,32,1,128,256,512,272,2048,773,8192,0,8477,9011,524,9138,517,8476,773,648,524,9011,9116,264,302,540,1,2092,8204,8201,257,525,17,277]

theorem envBound34552 : H12AffineFastState.Bounded env34552 := by
  intro p hp
  have h : env34552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34551_34552 : H12AffineEnvironment.transform 15 9011 env34551 = env34552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9011 env34551 == env34552) = true)

def env34553 : List Nat := [2,4,8,16,32,1,128,256,512,272,2048,773,24,0,261,811,524,938,517,260,773,648,524,811,900,264,302,540,1,2092,20,17,257,525,17,277]

theorem envBound34553 : H12AffineFastState.Bounded env34553 := by
  intro p hp
  have h : env34553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34552_34553 : H12AffineEnvironment.transform 12 24 env34552 = env34553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env34552 == env34553) = true)

theorem identity34553 : scanCanonicalize (H12AffineFastState.compose env34553 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound34553 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env34554 : List Nat := [2,4,8,16,32,1,128,4,512,20,2048,513,24,0,1,559,524,686,517,0,513,648,524,559,640,12,42,540,1,2092,20,17,5,525,17,17]

theorem envBound34554 : H12AffineFastState.Bounded env34554 := by
  intro p hp
  have h : env34554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34553_34554 : H12AffineEnvironment.transform 7 4 env34553 = env34554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env34553 == env34554) = true)

theorem identity34554 : scanCanonicalize (H12AffineFastState.compose env34554 (packedSelected [3,11,15,18] rootPS)) = affineNative (2^(10+1) ^^^ 146) := by decide +kernel

theorem selectedBound34554 : packedSelected [3,11,15,18] rootPS < 2^1333 := by decide +kernel

def env34555 : List Nat := [2,4,8,16,32,1,128,4,512,20,146,513,24,0,1,559,524,686,517,0,513,648,524,559,640,12,42,540,1,190,20,17,5,525,17,17]

theorem envBound34555 : H12AffineFastState.Bounded env34555 := by
  intro p hp
  have h : env34555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34554_34555 : H12AffineEnvironment.transform 10 146 env34554 = env34555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 146 env34554 == env34555) = true)

theorem identity34555 : scanCanonicalize (H12AffineFastState.compose env34555 (packedSelected [1,3,4,9,10,12,13,16,17] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound34555 : packedSelected [1,3,4,9,10,12,13,16,17] rootPS < 2^1333 := by decide +kernel

def env34556 : List Nat := [2,4,8,16,7,1,128,4,512,20,146,513,24,0,1,520,524,649,517,0,513,648,524,520,640,12,13,540,1,153,20,17,5,525,17,17]

theorem envBound34556 : H12AffineFastState.Bounded env34556 := by
  intro p hp
  have h : env34556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34555_34556 : H12AffineEnvironment.transform 4 7 env34555 = env34556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env34555 == env34556) = true)

theorem identity34556 : scanCanonicalize (H12AffineFastState.compose env34556 (packedSelected [1,5,7,8,9,10,11] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound34556 : packedSelected [1,5,7,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env34557 : List Nat := [2,4,8,16,7,1,128,4,16,20,146,17,24,0,1,24,28,153,21,0,17,152,28,24,144,12,13,12,1,153,20,17,5,29,17,17]

theorem envBound34557 : H12AffineFastState.Bounded env34557 := by
  intro p hp
  have h : env34557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34556_34557 : H12AffineEnvironment.transform 8 16 env34556 = env34557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env34556 == env34557) = true)

def env34558 : List Nat := [2,4,8,16,32,1,128,256,512,272,2048,773,25,0,260,810,524,939,517,261,773,648,524,810,901,264,302,540,1,2092,21,16,257,525,17,277]

theorem envBound34558 : H12AffineFastState.Bounded env34558 := by
  intro p hp
  have h : env34558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34552_34558 : H12AffineEnvironment.transform 12 25 env34552 = env34558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env34552 == env34558) = true)

theorem identity34558 : scanCanonicalize (H12AffineFastState.compose env34558 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound34558 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env34559 : List Nat := [2,4,8,16,32,1,128,256,17,272,2048,276,25,0,260,315,29,442,20,261,276,153,29,315,404,264,302,13,1,2092,21,16,257,28,17,277]

theorem envBound34559 : H12AffineFastState.Bounded env34559 := by
  intro p hp
  have h : env34559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34558_34559 : H12AffineEnvironment.transform 8 17 env34558 = env34559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env34558 == env34559) = true)

theorem identity34559 : scanCanonicalize (H12AffineFastState.compose env34559 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound34559 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env34560 : List Nat := [2,4,5,16,32,1,128,256,17,272,2048,276,20,0,260,310,16,439,20,261,276,148,16,310,404,261,291,0,1,2081,21,16,257,17,17,277]

theorem envBound34560 : H12AffineFastState.Bounded env34560 := by
  intro p hp
  have h : env34560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34559_34560 : H12AffineEnvironment.transform 2 5 env34559 = env34560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env34559 == env34560) = true)

theorem identity34560 : scanCanonicalize (H12AffineFastState.compose env34560 (packedSelected [1,2,3,5,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound34560 : packedSelected [1,2,3,5,10,12] rootPS < 2^1333 := by decide +kernel

def env34561 : List Nat := [2,4,5,16,32,1,128,256,17,272,48,276,20,0,260,310,16,439,20,261,276,148,16,310,404,261,291,0,1,17,21,16,257,17,17,277]

theorem envBound34561 : H12AffineFastState.Bounded env34561 := by
  intro p hp
  have h : env34561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34560_34561 : H12AffineEnvironment.transform 10 48 env34560 = env34561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env34560 == env34561) = true)

theorem identity34561 : scanCanonicalize (H12AffineFastState.compose env34561 (packedSelected [8,13] rootPS)) = affineNative (2^(7+1) ^^^ 151) := by decide +kernel

theorem selectedBound34561 : packedSelected [8,13] rootPS < 2^1333 := by decide +kernel

def env34562 : List Nat := [2,4,5,16,32,1,128,151,17,135,48,131,20,0,147,161,16,32,20,146,131,148,16,161,3,146,180,0,1,17,21,16,150,17,17,130]

theorem envBound34562 : H12AffineFastState.Bounded env34562 := by
  intro p hp
  have h : env34562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34561_34562 : H12AffineEnvironment.transform 7 151 env34561 = env34562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 151 env34561 == env34562) = true)

theorem identity34562 : scanCanonicalize (H12AffineFastState.compose env34562 (packedSelected [2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound34562 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env34563 : List Nat := [2,4,5,16,0,1,128,151,17,135,16,131,20,0,147,129,16,0,20,146,131,148,16,129,3,146,148,0,1,17,21,16,150,17,17,130]

theorem envBound34563 : H12AffineFastState.Bounded env34563 := by
  intro p hp
  have h : env34563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34562_34563 : H12AffineEnvironment.transform 4 0 env34562 = env34563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env34562 == env34563) = true)

theorem identity34563 : scanCanonicalize (H12AffineFastState.compose env34563 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound34563 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env34564 : List Nat := [2,4,5,16,0,1,19,4,17,20,16,16,20,0,0,18,16,0,20,1,16,7,16,18,3,1,7,0,1,17,21,16,5,17,17,17]

theorem envBound34564 : H12AffineFastState.Bounded env34564 := by
  intro p hp
  have h : env34564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34563_34564 : H12AffineEnvironment.transform 6 19 env34563 = env34564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env34563 == env34564) = true)

theorem identity34564 : scanCanonicalize (H12AffineFastState.compose env34564 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound34564 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34565 : List Nat := [2,4,5,6,0,1,5,4,7,2,6,6,2,0,0,4,6,0,2,1,6,7,6,4,3,1,7,0,1,7,3,6,5,7,7,7]

theorem envBound34565 : H12AffineFastState.Bounded env34565 := by
  intro p hp
  have h : env34565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34564_34565 : H12AffineEnvironment.transform 3 6 env34564 = env34565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env34564 == env34565) = true)

theorem identity34565 : scanCanonicalize (H12AffineFastState.compose env34565 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound34565 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34566 : List Nat := [2,3,2,1,0,1,2,3,0,2,1,1,2,0,0,3,1,0,2,1,1,0,1,3,3,1,0,0,1,0,3,1,2,0,0,0]

theorem envBound34566 : H12AffineFastState.Bounded env34566 := by
  intro p hp
  have h : env34566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34565_34566 : H12AffineEnvironment.transform 1 3 env34565 = env34566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env34565 == env34566) = true)

def env34567 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74862,262144,4416,8540,4096,5277,74046,66897,13769,78894,328958,74814,1297,81226,8205,8200,257,74798,1344,5952]

theorem envBound34567 : H12AffineFastState.Bounded env34567 := by
  intro p hp
  have h : env34567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34461_34567 : H12AffineEnvironment.transform 13 1297 env34461 = env34567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env34461 == env34567) = true)

def env34568 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74862,65664,4416,8540,4096,5277,74046,66897,13769,78894,1150,74814,1297,81226,8205,8200,257,74798,1344,5952]

theorem envBound34568 : H12AffineFastState.Bounded env34568 := by
  intro p hp
  have h : env34568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34567_34568 : H12AffineEnvironment.transform 17 65664 env34567 = env34568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env34567 == env34568) = true)

theorem identity34568 : scanCanonicalize (H12AffineFastState.compose env34568 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound34568 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env34569 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,24,1297,325,65536,66678,65664,4416,324,4096,5277,65830,66897,5585,70710,1150,66598,1297,73042,21,16,257,66614,1344,5952]

theorem envBound34569 : H12AffineFastState.Bounded env34569 := by
  intro p hp
  have h : env34569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34568_34569 : H12AffineEnvironment.transform 12 24 env34568 = env34569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env34568 == env34569) = true)

def env34570 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1556,24,1297,325,65536,66678,65664,1876,324,1556,649,65830,66897,965,66082,1150,66598,1297,68422,21,16,257,66614,1344,340]

theorem envBound34570 : H12AffineFastState.Bounded env34570 := by
  intro p hp
  have h : env34570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34569_34570 : H12AffineEnvironment.transform 11 1556 env34569 = env34570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env34569 == env34570) = true)

def env34571 : List Nat := [2,4,8,16,32,0,128,256,512,1024,2048,1556,24,1297,261,65536,66614,65664,1812,260,1556,649,65830,66833,901,66082,1086,66598,1297,68358,21,16,257,66614,1280,276]

theorem envBound34571 : H12AffineFastState.Bounded env34571 := by
  intro p hp
  have h : env34571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34570_34571 : H12AffineEnvironment.transform 5 0 env34570 = env34571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env34570 == env34571) = true)

theorem identity34571 : scanCanonicalize (H12AffineFastState.compose env34571 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 419) := by decide +kernel

theorem selectedBound34571 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env34572 : List Nat := [2,4,8,16,32,0,128,256,512,1024,2048,1556,24,1297,261,419,1429,291,1812,260,1556,649,133,1202,901,897,1086,1413,1297,2725,21,16,257,1429,1280,276]

theorem envBound34572 : H12AffineFastState.Bounded env34572 := by
  intro p hp
  have h : env34572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34571_34572 : H12AffineEnvironment.transform 15 419 env34571 = env34572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 419 env34571 == env34572) = true)

def env34573 : List Nat := [2,4,8,16,32,0,128,256,512,1024,1664,1556,24,1297,261,419,1429,291,1812,260,1556,649,133,1202,901,897,1086,1413,1297,1061,21,16,257,1429,1280,276]

theorem envBound34573 : H12AffineFastState.Bounded env34573 := by
  intro p hp
  have h : env34573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34572_34573 : H12AffineEnvironment.transform 10 1664 env34572 = env34573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1664 env34572 == env34573) = true)

def env34574 : List Nat := [2,4,8,16,32,0,128,256,136,1024,1032,1180,24,1297,261,419,1429,291,1436,260,1180,1,133,1202,269,265,1086,1413,1297,1061,21,16,257,1429,1280,276]

theorem envBound34574 : H12AffineFastState.Bounded env34574 := by
  intro p hp
  have h : env34574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34573_34574 : H12AffineEnvironment.transform 8 136 env34573 = env34574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env34573 == env34574) = true)

theorem identity34574 : scanCanonicalize (H12AffineFastState.compose env34574 (packedSelected [2,7,8,9,10,12,15,17,23,24] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound34574 : packedSelected [2,7,8,9,10,12,15,17,23,24] rootPS < 2^1333 := by decide +kernel

def env34575 : List Nat := [2,4,2,16,32,0,128,256,130,1024,1026,1174,18,1297,261,419,1429,291,1430,260,1174,1,133,1202,263,259,1076,1413,1297,1061,21,16,257,1429,1280,276]

theorem envBound34575 : H12AffineFastState.Bounded env34575 := by
  intro p hp
  have h : env34575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34574_34575 : H12AffineEnvironment.transform 2 2 env34574 = env34575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env34574 == env34575) = true)

theorem identity34575 : scanCanonicalize (H12AffineFastState.compose env34575 (packedSelected [4,8,9,10,11,12,17] rootPS)) = affineNative (2^(9+1) ^^^ 434) := by decide +kernel

theorem selectedBound34575 : packedSelected [4,8,9,10,11,12,17] rootPS < 2^1333 := by decide +kernel

def env34576 : List Nat := [2,4,2,16,32,0,128,256,130,434,432,292,18,163,261,419,39,291,36,260,292,1,133,256,263,259,390,55,163,407,21,16,257,39,178,276]

theorem envBound34576 : H12AffineFastState.Bounded env34576 := by
  intro p hp
  have h : env34576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34575_34576 : H12AffineEnvironment.transform 9 434 env34575 = env34576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 434 env34575 == env34576) = true)

theorem identity34576 : scanCanonicalize (H12AffineFastState.compose env34576 (packedSelected [0,3,4,7,8,9,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound34576 : packedSelected [0,3,4,7,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env34577 : List Nat := [2,4,2,16,32,0,5,256,7,311,309,292,18,38,261,294,39,291,36,260,292,1,0,256,263,259,259,55,38,274,21,16,257,39,55,276]

theorem envBound34577 : H12AffineFastState.Bounded env34577 := by
  intro p hp
  have h : env34577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34576_34577 : H12AffineEnvironment.transform 6 5 env34576 = env34577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env34576 == env34577) = true)

theorem identity34577 : scanCanonicalize (H12AffineFastState.compose env34577 (packedSelected [0,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound34577 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env34578 : List Nat := [2,4,2,16,22,0,5,256,7,257,259,274,18,16,261,272,17,277,18,260,274,1,0,256,263,259,259,1,16,274,21,16,257,17,1,276]

theorem envBound34578 : H12AffineFastState.Bounded env34578 := by
  intro p hp
  have h : env34578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34577_34578 : H12AffineEnvironment.transform 4 22 env34577 = env34578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env34577 == env34578) = true)

theorem identity34578 : scanCanonicalize (H12AffineFastState.compose env34578 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound34578 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env34579 : List Nat := [2,4,2,16,22,0,5,21,7,20,22,7,18,16,16,5,17,0,18,17,7,1,0,21,18,22,22,1,16,7,21,16,20,17,1,1]

theorem envBound34579 : H12AffineFastState.Bounded env34579 := by
  intro p hp
  have h : env34579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34578_34579 : H12AffineEnvironment.transform 7 21 env34578 = env34579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env34578 == env34579) = true)

theorem identity34579 : scanCanonicalize (H12AffineFastState.compose env34579 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound34579 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34580 : List Nat := [2,4,2,1,7,0,5,4,7,5,7,7,3,1,1,5,0,0,3,0,7,1,0,4,3,7,7,1,1,7,4,1,5,0,1,1]

theorem envBound34580 : H12AffineFastState.Bounded env34580 := by
  intro p hp
  have h : env34580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34579_34580 : H12AffineEnvironment.transform 3 1 env34579 = env34580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env34579 == env34580) = true)

theorem identity34580 : scanCanonicalize (H12AffineFastState.compose env34580 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound34580 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34581 : List Nat := [2,2,2,1,1,0,3,2,1,3,1,1,3,1,1,3,0,0,3,0,1,1,0,2,3,1,1,1,1,1,2,1,3,0,1,1]

theorem envBound34581 : H12AffineFastState.Bounded env34581 := by
  intro p hp
  have h : env34581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34580_34581 : H12AffineEnvironment.transform 1 2 env34580 = env34581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env34580 == env34581) = true)

def env34582 : List Nat := [2,4,8,16,32,0,128,256,137,1024,1033,1181,24,1297,261,419,1429,291,1437,260,1181,0,133,1202,268,264,1086,1413,1297,1061,21,16,257,1429,1280,276]

theorem envBound34582 : H12AffineFastState.Bounded env34582 := by
  intro p hp
  have h : env34582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34573_34582 : H12AffineEnvironment.transform 8 137 env34573 = env34582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env34573 == env34582) = true)

theorem identity34582 : scanCanonicalize (H12AffineFastState.compose env34582 (packedSelected [2,7,8,9,10,12,15,17,23,24] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound34582 : packedSelected [2,7,8,9,10,12,15,17,23,24] rootPS < 2^1333 := by decide +kernel

def env34583 : List Nat := [2,4,5,16,32,0,128,256,132,1024,1028,1168,21,1297,261,419,1429,291,1424,260,1168,0,133,1202,257,261,1075,1413,1297,1061,21,16,257,1429,1280,276]

theorem envBound34583 : H12AffineFastState.Bounded env34583 := by
  intro p hp
  have h : env34583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34582_34583 : H12AffineEnvironment.transform 2 5 env34582 = env34583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env34582 == env34583) = true)

theorem identity34583 : scanCanonicalize (H12AffineFastState.compose env34583 (packedSelected [0,3,9,10,12,15,16] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound34583 : packedSelected [0,3,9,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env34584 : List Nat := [2,4,5,16,32,0,19,256,23,1024,1028,1027,21,1297,261,304,1286,291,1283,260,1027,0,22,1057,257,261,1075,1302,1297,1061,21,16,257,1286,1280,276]

theorem envBound34584 : H12AffineFastState.Bounded env34584 := by
  intro p hp
  have h : env34584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34583_34584 : H12AffineEnvironment.transform 6 19 env34583 = env34584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env34583 == env34584) = true)

theorem identity34584 : scanCanonicalize (H12AffineFastState.compose env34584 (packedSelected [1,2,3,4,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 279) := by decide +kernel

theorem selectedBound34584 : packedSelected [1,2,3,4,9,10] rootPS < 2^1333 := by decide +kernel

def env34585 : List Nat := [2,4,5,16,32,0,19,256,23,279,275,276,21,6,261,304,17,291,20,260,276,0,22,310,257,261,292,1,6,306,21,16,257,17,23,276]

theorem envBound34585 : H12AffineFastState.Bounded env34585 := by
  intro p hp
  have h : env34585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34584_34585 : H12AffineEnvironment.transform 9 279 env34584 = env34585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 279 env34584 == env34585) = true)

theorem identity34585 : scanCanonicalize (H12AffineFastState.compose env34585 (packedSelected [3,4,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 34) := by decide +kernel

theorem selectedBound34585 : packedSelected [3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env34586 : List Nat := [2,4,5,16,32,0,19,34,23,53,49,54,21,6,39,18,17,1,20,38,54,0,22,20,35,39,6,1,6,16,21,16,35,17,23,54]

theorem envBound34586 : H12AffineFastState.Bounded env34586 := by
  intro p hp
  have h : env34586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34585_34586 : H12AffineEnvironment.transform 7 34 env34585 = env34586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 34 env34585 == env34586) = true)

theorem identity34586 : scanCanonicalize (H12AffineFastState.compose env34586 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound34586 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env34587 : List Nat := [2,4,5,7,32,0,4,34,0,34,38,33,2,6,39,5,6,1,3,38,33,0,1,3,35,39,6,1,6,7,2,7,35,6,0,33]

theorem envBound34587 : H12AffineFastState.Bounded env34587 := by
  intro p hp
  have h : env34587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34586_34587 : H12AffineEnvironment.transform 3 7 env34586 = env34587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env34586 == env34587) = true)

theorem identity34587 : scanCanonicalize (H12AffineFastState.compose env34587 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound34587 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34588 : List Nat := [2,4,5,7,0,0,4,2,0,2,6,1,2,6,7,5,6,1,3,6,1,0,1,3,3,7,6,1,6,7,2,7,3,6,0,1]

theorem envBound34588 : H12AffineFastState.Bounded env34588 := by
  intro p hp
  have h : env34588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34587_34588 : H12AffineEnvironment.transform 4 0 env34587 = env34588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env34587 == env34588) = true)

theorem identity34588 : scanCanonicalize (H12AffineFastState.compose env34588 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound34588 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34589 : List Nat := [2,1,0,2,0,0,1,2,0,2,3,1,2,3,2,0,3,1,3,3,1,0,1,3,3,2,3,1,3,2,2,2,3,3,0,1]

theorem envBound34589 : H12AffineFastState.Bounded env34589 := by
  intro p hp
  have h : env34589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34588_34589 : H12AffineEnvironment.transform 1 1 env34588 = env34589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env34588 == env34589) = true)

theorem identity34589 : scanCanonicalize (H12AffineFastState.compose env34589 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound34589 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34590 : List Nat := [1,1,0,1,0,0,1,1,0,1,0,1,1,0,1,0,0,1,0,0,1,0,1,0,0,1,0,1,0,1,1,1,0,0,0,1]

theorem envBound34590 : H12AffineFastState.Bounded env34590 := by
  intro p hp
  have h : env34590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34589_34590 : H12AffineEnvironment.transform 0 1 env34589 = env34590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env34589 == env34590) = true)

def env34591 : List Nat := [2,4,8,16,32,0,128,256,512,1024,1665,1556,24,1297,261,419,1429,291,1812,260,1556,649,133,1202,901,897,1086,1413,1297,1060,21,16,257,1429,1280,276]

theorem envBound34591 : H12AffineFastState.Bounded env34591 := by
  intro p hp
  have h : env34591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34572_34591 : H12AffineEnvironment.transform 10 1665 env34572 = env34591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1665 env34572 == env34591) = true)

def env34592 : List Nat := [2,4,8,16,32,0,128,256,136,1024,1033,1180,24,1297,261,419,1429,291,1436,260,1180,1,133,1202,269,265,1086,1413,1297,1060,21,16,257,1429,1280,276]

theorem envBound34592 : H12AffineFastState.Bounded env34592 := by
  intro p hp
  have h : env34592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34591_34592 : H12AffineEnvironment.transform 8 136 env34591 = env34592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env34591 == env34592) = true)

theorem identity34592 : scanCanonicalize (H12AffineFastState.compose env34592 (packedSelected [2,7,8,9,10,12,15,17,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 177) := by decide +kernel

theorem selectedBound34592 : packedSelected [2,7,8,9,10,12,15,17,23,24] rootPS < 2^1333 := by decide +kernel

def env34593 : List Nat := [2,4,8,16,32,0,128,177,136,1024,1033,1180,24,1184,180,18,1060,146,1069,181,1180,1,133,1202,188,184,1086,1076,1184,1060,21,16,176,1060,1201,165]

theorem envBound34593 : H12AffineFastState.Bounded env34593 := by
  intro p hp
  have h : env34593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34592_34593 : H12AffineEnvironment.transform 7 177 env34592 = env34593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 177 env34592 == env34593) = true)

theorem identity34593 : scanCanonicalize (H12AffineFastState.compose env34593 (packedSelected [1,4,8,9,11,12,13,15] rootPS)) = affineNative (2^(9+1) ^^^ 171) := by decide +kernel

theorem selectedBound34593 : packedSelected [1,4,8,9,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env34594 : List Nat := [2,4,8,16,32,0,128,177,136,171,162,55,24,11,180,18,143,146,134,181,55,1,133,25,188,184,149,159,11,143,21,16,176,143,26,165]

theorem envBound34594 : H12AffineFastState.Bounded env34594 := by
  intro p hp
  have h : env34594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34593_34594 : H12AffineEnvironment.transform 9 171 env34593 = env34594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 171 env34593 == env34594) = true)

theorem identity34594 : scanCanonicalize (H12AffineFastState.compose env34594 (packedSelected [0,1,3,4,7,9,10,11] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound34594 : packedSelected [0,1,3,4,7,9,10,11] rootPS < 2^1333 := by decide +kernel

def env34595 : List Nat := [2,4,8,16,13,0,128,156,136,134,143,26,24,11,153,18,143,146,134,152,26,1,133,25,145,149,149,159,11,143,21,16,157,143,26,136]

theorem envBound34595 : H12AffineFastState.Bounded env34595 := by
  intro p hp
  have h : env34595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34594_34595 : H12AffineEnvironment.transform 4 13 env34594 = env34595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env34594 == env34595) = true)

theorem identity34595 : scanCanonicalize (H12AffineFastState.compose env34595 (packedSelected [0,1,2,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound34595 : packedSelected [0,1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env34596 : List Nat := [2,4,8,16,13,0,8,20,0,14,7,26,24,11,17,18,7,26,14,16,26,1,13,25,25,29,29,23,11,7,21,16,21,7,26,0]

theorem envBound34596 : H12AffineFastState.Bounded env34596 := by
  intro p hp
  have h : env34596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34595_34596 : H12AffineEnvironment.transform 6 8 env34595 = env34596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env34595 == env34596) = true)

theorem identity34596 : scanCanonicalize (H12AffineFastState.compose env34596 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound34596 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34597 : List Nat := [2,4,8,6,13,0,8,2,0,14,7,12,14,11,7,4,7,12,14,6,12,1,13,15,15,11,11,1,11,7,3,6,3,7,12,0]

theorem envBound34597 : H12AffineFastState.Bounded env34597 := by
  intro p hp
  have h : env34597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34596_34597 : H12AffineEnvironment.transform 3 6 env34596 = env34597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env34596 == env34597) = true)

theorem identity34597 : scanCanonicalize (H12AffineFastState.compose env34597 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound34597 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34598 : List Nat := [2,2,8,0,11,0,8,2,0,8,1,10,8,11,1,2,1,10,8,0,10,1,11,9,9,11,11,1,11,1,3,0,3,1,10,0]

theorem envBound34598 : H12AffineFastState.Bounded env34598 := by
  intro p hp
  have h : env34598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34597_34598 : H12AffineEnvironment.transform 1 2 env34597 = env34598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env34597 == env34598) = true)

theorem identity34598 : scanCanonicalize (H12AffineFastState.compose env34598 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound34598 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34599 : List Nat := [2,2,2,0,1,0,2,2,0,2,1,0,2,1,1,2,1,0,2,0,0,1,1,3,3,1,1,1,1,1,3,0,3,1,0,0]

theorem envBound34599 : H12AffineFastState.Bounded env34599 := by
  intro p hp
  have h : env34599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34598_34599 : H12AffineEnvironment.transform 2 2 env34598 = env34599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env34598 == env34599) = true)

def env34600 : List Nat := [2,4,8,16,32,0,128,256,137,1024,1032,1181,24,1297,261,419,1429,291,1437,260,1181,0,133,1202,268,264,1086,1413,1297,1060,21,16,257,1429,1280,276]

theorem envBound34600 : H12AffineFastState.Bounded env34600 := by
  intro p hp
  have h : env34600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34591_34600 : H12AffineEnvironment.transform 8 137 env34591 = env34600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env34591 == env34600) = true)

theorem identity34600 : scanCanonicalize (H12AffineFastState.compose env34600 (packedSelected [2,7,8,9,10,12,15,17,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 183) := by decide +kernel

theorem selectedBound34600 : packedSelected [2,7,8,9,10,12,15,17,23,24] rootPS < 2^1333 := by decide +kernel

def env34601 : List Nat := [2,4,8,16,32,0,128,183,137,1024,1032,1181,24,1190,178,20,1058,148,1066,179,1181,0,133,1202,187,191,1086,1074,1190,1060,21,16,182,1058,1207,163]

theorem envBound34601 : H12AffineFastState.Bounded env34601 := by
  intro p hp
  have h : env34601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34600_34601 : H12AffineEnvironment.transform 7 183 env34600 = env34601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 183 env34600 == env34601) = true)

theorem identity34601 : scanCanonicalize (H12AffineFastState.compose env34601 (packedSelected [2,3,7,9,10,11,12,13,15] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound34601 : packedSelected [2,3,7,9,10,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env34602 : List Nat := [2,4,8,16,32,0,128,183,137,15,7,146,24,169,178,20,45,148,37,179,146,0,133,189,187,191,49,61,169,43,21,16,182,45,184,163]

theorem envBound34602 : H12AffineFastState.Bounded env34602 := by
  intro p hp
  have h : env34602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34601_34602 : H12AffineEnvironment.transform 9 15 env34601 = env34602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env34601 == env34602) = true)

theorem identity34602 : scanCanonicalize (H12AffineFastState.compose env34602 (packedSelected [0,1,4,5,11] rootPS)) = affineNative (2^(6+1) ^^^ 53) := by decide +kernel

theorem selectedBound34602 : packedSelected [0,1,4,5,11] rootPS < 2^1333 := by decide +kernel

def env34603 : List Nat := [2,4,8,16,32,0,53,2,60,15,7,39,24,28,7,20,45,33,37,6,39,0,48,8,14,10,49,61,28,43,21,16,3,45,13,22]

theorem envBound34603 : H12AffineFastState.Bounded env34603 := by
  intro p hp
  have h : env34603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34602_34603 : H12AffineEnvironment.transform 6 53 env34602 = env34603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 53 env34602 == env34603) = true)

theorem identity34603 : scanCanonicalize (H12AffineFastState.compose env34603 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound34603 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34604 : List Nat := [2,4,8,16,28,0,9,2,0,15,7,27,24,28,7,20,17,29,25,6,27,0,12,8,14,10,13,1,28,23,21,16,3,17,13,22]

theorem envBound34604 : H12AffineFastState.Bounded env34604 := by
  intro p hp
  have h : env34604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34603_34604 : H12AffineEnvironment.transform 4 28 env34603 = env34604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env34603 == env34604) = true)

theorem identity34604 : scanCanonicalize (H12AffineFastState.compose env34604 (packedSelected [0,1,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound34604 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env34605 : List Nat := [2,4,8,1,13,0,9,2,0,15,7,10,9,13,7,5,0,12,8,6,10,0,12,8,14,10,13,1,13,6,4,1,3,0,13,7]

theorem envBound34605 : H12AffineFastState.Bounded env34605 := by
  intro p hp
  have h : env34605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34604_34605 : H12AffineEnvironment.transform 3 1 env34604 = env34605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env34604 == env34605) = true)

theorem identity34605 : scanCanonicalize (H12AffineFastState.compose env34605 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound34605 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env34606 : List Nat := [2,4,3,1,6,0,2,2,0,4,7,1,2,6,7,5,0,7,3,6,1,0,7,3,5,1,6,1,6,6,4,1,3,0,6,7]

theorem envBound34606 : H12AffineFastState.Bounded env34606 := by
  intro p hp
  have h : env34606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34605_34606 : H12AffineEnvironment.transform 2 3 env34605 = env34606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env34605 == env34606) = true)

theorem identity34606 : scanCanonicalize (H12AffineFastState.compose env34606 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound34606 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env34607 : List Nat := [2,2,3,1,0,0,2,2,0,2,1,1,2,0,1,3,0,1,3,0,1,0,1,3,3,1,0,1,0,0,2,1,3,0,0,1]

theorem envBound34607 : H12AffineFastState.Bounded env34607 := by
  intro p hp
  have h : env34607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34606_34607 : H12AffineEnvironment.transform 1 2 env34606 = env34607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env34606 == env34607) = true)

theorem identity34607 : scanCanonicalize (H12AffineFastState.compose env34607 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound34607 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34608 : List Nat := [1,1,0,1,0,0,1,1,0,1,1,1,1,0,1,0,0,1,0,0,1,0,1,0,0,1,0,1,0,0,1,1,0,0,0,1]

theorem envBound34608 : H12AffineFastState.Bounded env34608 := by
  intro p hp
  have h : env34608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34607_34608 : H12AffineEnvironment.transform 0 1 env34607 = env34608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env34607 == env34608) = true)

def env34609 : List Nat := [2,4,8,16,32,1,128,256,512,1024,2048,1556,24,1297,260,65536,66615,65664,1813,261,1556,649,65830,66832,900,66082,1087,66598,1297,68359,21,16,257,66614,1281,277]

theorem envBound34609 : H12AffineFastState.Bounded env34609 := by
  intro p hp
  have h : env34609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34570_34609 : H12AffineEnvironment.transform 5 1 env34570 = env34609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env34570 == env34609) = true)

theorem identity34609 : scanCanonicalize (H12AffineFastState.compose env34609 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 1203) := by decide +kernel

theorem selectedBound34609 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env34610 : List Nat := [2,4,8,16,32,1,128,256,512,1024,2048,1556,24,1297,260,1203,132,1075,1813,261,1556,649,1429,419,900,1681,1087,149,1297,4020,21,16,257,133,1281,277]

theorem envBound34610 : H12AffineFastState.Bounded env34610 := by
  intro p hp
  have h : env34610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34609_34610 : H12AffineEnvironment.transform 15 1203 env34609 = env34610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1203 env34609 == env34610) = true)

def env34611 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,1540,8,1281,260,1187,132,1059,1797,261,1540,649,1413,419,900,1665,1071,133,1281,4004,5,0,257,133,1281,261]

theorem envBound34611 : H12AffineFastState.Bounded env34611 := by
  intro p hp
  have h : env34611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34610_34611 : H12AffineEnvironment.transform 3 0 env34610 = env34611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env34610 == env34611) = true)

theorem identity34611 : scanCanonicalize (H12AffineFastState.compose env34611 (packedSelected [7,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound34611 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env34612 : List Nat := [2,4,8,0,32,1,128,256,512,4,2048,512,8,261,260,167,132,39,769,261,512,649,385,419,900,645,43,133,261,2976,5,0,257,133,261,261]

theorem envBound34612 : H12AffineFastState.Bounded env34612 := by
  intro p hp
  have h : env34612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34611_34612 : H12AffineEnvironment.transform 9 4 env34611 = env34612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env34611 == env34612) = true)

theorem identity34612 : scanCanonicalize (H12AffineFastState.compose env34612 (packedSelected [0,2,3,4,5,7,8,9,11,13,16,17,19] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound34612 : packedSelected [0,2,3,4,5,7,8,9,11,13,16,17,19] rootPS < 2^1333 := by decide +kernel

def env34613 : List Nat := [2,4,8,0,32,1,128,37,512,4,2048,512,8,32,33,167,132,39,548,32,512,649,164,134,673,645,43,133,32,2693,5,0,36,133,32,32]

theorem envBound34613 : H12AffineFastState.Bounded env34613 := by
  intro p hp
  have h : env34613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34612_34613 : H12AffineEnvironment.transform 7 37 env34612 = env34613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env34612 == env34613) = true)

theorem identity34613 : scanCanonicalize (H12AffineFastState.compose env34613 (packedSelected [1,2,3,5,8,10,11,12,13,15,18] rootPS)) = affineNative (2^(10+1) ^^^ 643) := by decide +kernel

theorem selectedBound34613 : packedSelected [1,2,3,5,8,10,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env34614 : List Nat := [2,4,8,0,32,1,128,37,512,4,643,512,8,32,33,167,132,39,548,32,512,649,164,134,673,645,43,133,32,6,5,0,36,133,32,32]

theorem envBound34614 : H12AffineFastState.Bounded env34614 := by
  intro p hp
  have h : env34614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34613_34614 : H12AffineEnvironment.transform 10 643 env34613 = env34614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 643 env34613 == env34614) = true)

theorem identity34614 : scanCanonicalize (H12AffineFastState.compose env34614 (packedSelected [0,3,7,8,11] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound34614 : packedSelected [0,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env34615 : List Nat := [2,4,8,0,11,1,128,14,512,4,643,512,8,11,10,140,132,12,527,11,512,649,143,134,650,645,0,133,11,6,5,0,15,133,11,11]

theorem envBound34615 : H12AffineFastState.Bounded env34615 := by
  intro p hp
  have h : env34615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34614_34615 : H12AffineEnvironment.transform 4 11 env34614 = env34615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env34614 == env34615) = true)

theorem identity34615 : scanCanonicalize (H12AffineFastState.compose env34615 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound34615 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env34616 : List Nat := [2,4,5,0,6,1,128,3,512,4,643,512,5,6,7,129,132,1,514,6,512,644,130,134,647,645,0,133,6,6,5,0,2,133,6,6]

theorem envBound34616 : H12AffineFastState.Bounded env34616 := by
  intro p hp
  have h : env34616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34615_34616 : H12AffineEnvironment.transform 2 5 env34615 = env34616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env34615 == env34616) = true)

theorem identity34616 : scanCanonicalize (H12AffineFastState.compose env34616 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound34616 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env34617 : List Nat := [2,4,5,0,6,1,4,3,512,4,519,512,5,6,7,5,0,1,514,6,512,512,6,2,515,513,0,1,6,6,5,0,2,1,6,6]

theorem envBound34617 : H12AffineFastState.Bounded env34617 := by
  intro p hp
  have h : env34617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34616_34617 : H12AffineEnvironment.transform 6 4 env34616 = env34617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env34616 == env34617) = true)

def env34618 : List Nat := [2,4,8,1,32,1,128,256,512,1024,2048,1541,9,1280,260,1186,132,1058,1796,261,1541,649,1412,419,900,1664,1070,132,1280,4005,4,1,257,133,1281,260]

theorem envBound34618 : H12AffineFastState.Bounded env34618 := by
  intro p hp
  have h : env34618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34610_34618 : H12AffineEnvironment.transform 3 1 env34610 = env34618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env34610 == env34618) = true)

theorem identity34618 : scanCanonicalize (H12AffineFastState.compose env34618 (packedSelected [7,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 769) := by decide +kernel

theorem selectedBound34618 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env34619 : List Nat := [2,4,8,1,32,1,128,256,512,769,2048,260,9,513,260,931,132,803,5,261,260,649,645,419,900,385,815,132,513,2212,4,1,257,133,512,260]

theorem envBound34619 : H12AffineFastState.Bounded env34619 := by
  intro p hp
  have h : env34619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34618_34619 : H12AffineEnvironment.transform 9 769 env34618 = env34619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 769 env34618 == env34619) = true)

theorem identity34619 : scanCanonicalize (H12AffineFastState.compose env34619 (packedSelected [0,1,4,7,8,9,16,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 128) := by decide +kernel

theorem selectedBound34619 : packedSelected [0,1,4,7,8,9,16,19,20] rootPS < 2^1333 := by decide +kernel

def env34620 : List Nat := [2,4,8,1,32,1,128,128,512,641,2048,132,9,513,132,547,132,675,5,133,132,649,645,35,516,1,687,132,513,2212,4,1,129,133,512,132]

theorem envBound34620 : H12AffineFastState.Bounded env34620 := by
  intro p hp
  have h : env34620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34619_34620 : H12AffineEnvironment.transform 7 128 env34619 = env34620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 128 env34619 == env34620) = true)

theorem identity34620 : scanCanonicalize (H12AffineFastState.compose env34620 (packedSelected [1,8,10] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound34620 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env34621 : List Nat := [2,4,8,1,12,1,128,128,512,641,2048,132,9,513,132,527,132,655,5,133,132,649,645,15,516,1,643,132,513,2184,4,1,129,133,512,132]

theorem envBound34621 : H12AffineFastState.Bounded env34621 := by
  intro p hp
  have h : env34621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34620_34621 : H12AffineEnvironment.transform 4 12 env34620 = env34621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env34620 == env34621) = true)

theorem identity34621 : scanCanonicalize (H12AffineFastState.compose env34621 (packedSelected [1,4,5,8,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 132) := by decide +kernel

theorem selectedBound34621 : packedSelected [1,4,5,8,9,11] rootPS < 2^1333 := by decide +kernel

def env34622 : List Nat := [2,4,8,1,12,1,128,128,512,641,132,132,9,513,132,527,132,655,5,133,132,649,645,15,516,1,643,132,513,12,4,1,129,133,512,132]

theorem envBound34622 : H12AffineFastState.Bounded env34622 := by
  intro p hp
  have h : env34622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34621_34622 : H12AffineEnvironment.transform 10 132 env34621 = env34622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 132 env34621 == env34622) = true)

theorem identity34622 : scanCanonicalize (H12AffineFastState.compose env34622 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound34622 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34623 : List Nat := [2,4,8,1,12,1,4,4,512,517,0,0,9,513,0,527,0,523,5,1,0,525,513,15,516,1,519,0,513,12,4,1,5,1,512,0]

theorem envBound34623 : H12AffineFastState.Bounded env34623 := by
  intro p hp
  have h : env34623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34622_34623 : H12AffineEnvironment.transform 6 4 env34622 = env34623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env34622 == env34623) = true)

theorem identity34623 : scanCanonicalize (H12AffineFastState.compose env34623 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound34623 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env34624 : List Nat := [2,4,8,1,12,1,4,4,11,14,0,0,9,10,0,4,0,0,5,1,0,6,10,15,15,1,12,0,10,12,4,1,5,1,11,0]

theorem envBound34624 : H12AffineFastState.Bounded env34624 := by
  intro p hp
  have h : env34624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34623_34624 : H12AffineEnvironment.transform 8 11 env34623 = env34624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env34623 == env34624) = true)

theorem identity34624 : scanCanonicalize (H12AffineFastState.compose env34624 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound34624 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env34625 : List Nat := [2,4,3,1,7,1,4,4,0,5,0,0,2,1,0,4,0,0,5,1,0,6,1,4,4,1,7,0,1,7,4,1,5,1,0,0]

theorem envBound34625 : H12AffineFastState.Bounded env34625 := by
  intro p hp
  have h : env34625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34624_34625 : H12AffineEnvironment.transform 2 3 env34624 = env34625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env34624 == env34625) = true)

def env34626 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1557,24,1297,325,65536,66678,65664,1877,324,1557,648,65830,66897,964,66083,1150,66598,1297,68423,21,16,257,66614,1344,341]

theorem envBound34626 : H12AffineFastState.Bounded env34626 := by
  intro p hp
  have h : env34626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34569_34626 : H12AffineEnvironment.transform 11 1557 env34569 = env34626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env34569 == env34626) = true)

def env34627 : List Nat := [2,4,8,16,32,0,128,256,512,1024,2048,1557,24,1297,261,65536,66614,65664,1813,260,1557,648,65830,66833,900,66083,1086,66598,1297,68359,21,16,257,66614,1280,277]

theorem envBound34627 : H12AffineFastState.Bounded env34627 := by
  intro p hp
  have h : env34627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34626_34627 : H12AffineEnvironment.transform 5 0 env34626 = env34627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env34626 == env34627) = true)

theorem identity34627 : scanCanonicalize (H12AffineFastState.compose env34627 (packedSelected [1,8,28] rootPS)) = affineNative (2^(6+1) ^^^ 20) := by decide +kernel

theorem selectedBound34627 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env34628 : List Nat := [2,4,8,16,32,0,20,256,512,1024,2048,1557,24,1297,261,65536,66614,65556,1813,260,1557,540,65830,66833,784,66083,1086,66598,1297,68359,21,16,257,66614,1280,277]

theorem envBound34628 : H12AffineFastState.Bounded env34628 := by
  intro p hp
  have h : env34628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34627_34628 : H12AffineEnvironment.transform 6 20 env34627 = env34628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 20 env34627 == env34628) = true)

def env34629 : List Nat := [2,4,8,16,32,0,20,256,512,1024,2048,1557,24,1297,261,1056,22,1076,1813,260,1557,540,1286,305,784,1539,1086,6,1297,3879,21,16,257,22,1280,277]

theorem envBound34629 : H12AffineFastState.Bounded env34629 := by
  intro p hp
  have h : env34629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34628_34629 : H12AffineEnvironment.transform 15 1056 env34628 = env34629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1056 env34628 == env34629) = true)

def env34630 : List Nat := [2,4,8,16,32,0,20,256,512,1024,1060,1557,24,1297,261,1056,22,1076,1813,260,1557,540,1286,305,784,1539,1086,6,1297,771,21,16,257,22,1280,277]

theorem envBound34630 : H12AffineFastState.Bounded env34630 := by
  intro p hp
  have h : env34630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34629_34630 : H12AffineEnvironment.transform 10 1060 env34629 = env34630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1060 env34629 == env34630) = true)

theorem identity34630 : scanCanonicalize (H12AffineFastState.compose env34630 (packedSelected [3,4,5,8,9,10,12,13,16,19] rootPS)) = affineNative (2^(8+1) ^^^ 45) := by decide +kernel

theorem selectedBound34630 : packedSelected [3,4,5,8,9,10,12,13,16,19] rootPS < 2^1333 := by decide +kernel

def env34631 : List Nat := [2,4,8,16,32,0,20,256,45,1024,1060,1080,24,1297,261,1056,22,1076,1336,260,1080,49,1286,305,317,1070,1086,6,1297,302,21,16,257,22,1280,277]

theorem envBound34631 : H12AffineFastState.Bounded env34631 := by
  intro p hp
  have h : env34631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34630_34631 : H12AffineEnvironment.transform 8 45 env34630 = env34631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 45 env34630 == env34631) = true)

theorem identity34631 : scanCanonicalize (H12AffineFastState.compose env34631 (packedSelected [0,1,7,10,11,13,15,16,17,18] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound34631 : packedSelected [0,1,7,10,11,13,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env34632 : List Nat := [2,4,8,16,32,0,20,5,45,1024,1060,1080,24,1044,0,1056,22,1076,1085,1,1080,49,1027,52,56,1070,1086,6,1044,43,21,16,4,22,1029,16]

theorem envBound34632 : H12AffineFastState.Bounded env34632 := by
  intro p hp
  have h : env34632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34631_34632 : H12AffineEnvironment.transform 7 5 env34631 = env34632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env34631 == env34632) = true)

theorem identity34632 : scanCanonicalize (H12AffineFastState.compose env34632 (packedSelected [2,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound34632 : packedSelected [2,10,11] rootPS < 2^1333 := by decide +kernel

def env34633 : List Nat := [2,4,8,16,32,0,20,5,45,37,1,29,24,49,0,5,22,17,24,1,29,49,38,52,56,11,27,6,49,43,21,16,4,22,32,16]

theorem envBound34633 : H12AffineFastState.Bounded env34633 := by
  intro p hp
  have h : env34633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34632_34633 : H12AffineEnvironment.transform 9 37 env34632 = env34633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env34632 == env34633) = true)

theorem identity34633 : scanCanonicalize (H12AffineFastState.compose env34633 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound34633 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env34634 : List Nat := [2,4,8,16,0,0,20,5,13,5,1,29,24,17,0,5,22,17,24,1,29,17,6,20,24,11,27,6,17,11,21,16,4,22,0,16]

theorem envBound34634 : H12AffineFastState.Bounded env34634 := by
  intro p hp
  have h : env34634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34633_34634 : H12AffineEnvironment.transform 4 0 env34633 = env34634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env34633 == env34634) = true)

theorem identity34634 : scanCanonicalize (H12AffineFastState.compose env34634 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound34634 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34635 : List Nat := [2,4,8,1,0,0,5,5,13,5,1,12,9,0,0,5,7,0,9,1,12,0,6,5,9,11,10,6,0,11,4,1,4,7,0,1]

theorem envBound34635 : H12AffineFastState.Bounded env34635 := by
  intro p hp
  have h : env34635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34634_34635 : H12AffineEnvironment.transform 3 1 env34634 = env34635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env34634 == env34635) = true)

theorem identity34635 : scanCanonicalize (H12AffineFastState.compose env34635 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound34635 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34636 : List Nat := [2,4,2,1,0,0,5,5,7,5,1,6,3,0,0,5,7,0,3,1,6,0,6,5,3,1,0,6,0,1,4,1,4,7,0,1]

theorem envBound34636 : H12AffineFastState.Bounded env34636 := by
  intro p hp
  have h : env34636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34635_34636 : H12AffineEnvironment.transform 2 2 env34635 = env34636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env34635 == env34636) = true)

def env34637 : List Nat := [2,4,8,16,32,0,20,256,512,1024,1061,1557,24,1297,261,1056,22,1076,1813,260,1557,540,1286,305,784,1539,1086,6,1297,770,21,16,257,22,1280,277]

theorem envBound34637 : H12AffineFastState.Bounded env34637 := by
  intro p hp
  have h : env34637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34629_34637 : H12AffineEnvironment.transform 10 1061 env34629 = env34637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1061 env34629 == env34637) = true)

theorem identity34637 : scanCanonicalize (H12AffineFastState.compose env34637 (packedSelected [3,4,5,8,9,10,12,13,16,19] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound34637 : packedSelected [3,4,5,8,9,10,12,13,16,19] rootPS < 2^1333 := by decide +kernel

def env34638 : List Nat := [2,4,8,16,32,0,20,256,43,1024,1061,1086,24,1297,261,1056,22,1076,1342,260,1086,55,1286,305,315,1064,1086,6,1297,297,21,16,257,22,1280,277]

theorem envBound34638 : H12AffineFastState.Bounded env34638 := by
  intro p hp
  have h : env34638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34637_34638 : H12AffineEnvironment.transform 8 43 env34637 = env34638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env34637 == env34638) = true)

theorem identity34638 : scanCanonicalize (H12AffineFastState.compose env34638 (packedSelected [0,2,3,8,9,11,12,13,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 47) := by decide +kernel

theorem selectedBound34638 : packedSelected [0,2,3,8,9,11,12,13,16,18] rootPS < 2^1333 := by decide +kernel

def env34639 : List Nat := [2,4,8,16,32,0,20,47,43,1024,1061,1086,24,1086,42,1056,22,1076,1041,43,1086,55,1065,30,20,1064,1086,6,1086,6,21,16,46,22,1071,58]

theorem envBound34639 : H12AffineFastState.Bounded env34639 := by
  intro p hp
  have h : env34639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34638_34639 : H12AffineEnvironment.transform 7 47 env34638 = env34639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 47 env34638 == env34639) = true)

theorem identity34639 : scanCanonicalize (H12AffineFastState.compose env34639 (packedSelected [2,3,5,8,10] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound34639 : packedSelected [2,3,5,8,10] rootPS < 2^1333 := by decide +kernel

def env34640 : List Nat := [2,4,2,16,32,0,20,37,33,1024,1061,1076,18,1076,32,1056,22,1076,1041,33,1076,55,1059,20,20,1058,1076,6,1076,6,21,16,36,22,1061,48]

theorem envBound34640 : H12AffineFastState.Bounded env34640 := by
  intro p hp
  have h : env34640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34639_34640 : H12AffineEnvironment.transform 2 2 env34639 = env34640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env34639 == env34640) = true)

theorem identity34640 : scanCanonicalize (H12AffineFastState.compose env34640 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 19) := by decide +kernel

theorem selectedBound34640 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env34641 : List Nat := [2,4,2,16,32,0,20,37,33,19,54,39,18,39,32,51,22,39,2,33,39,55,48,20,20,49,39,6,39,6,21,16,36,22,54,48]

theorem envBound34641 : H12AffineFastState.Bounded env34641 := by
  intro p hp
  have h : env34641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34640_34641 : H12AffineEnvironment.transform 9 19 env34640 = env34641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 19 env34640 == env34641) = true)

theorem identity34641 : scanCanonicalize (H12AffineFastState.compose env34641 (packedSelected [0,1,4] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound34641 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env34642 : List Nat := [2,4,2,16,16,0,20,21,17,19,6,23,18,23,16,3,22,23,2,17,23,7,0,20,20,1,23,6,23,6,21,16,20,22,6,0]

theorem envBound34642 : H12AffineFastState.Bounded env34642 := by
  intro p hp
  have h : env34642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34641_34642 : H12AffineEnvironment.transform 4 16 env34641 = env34642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env34641 == env34642) = true)

theorem identity34642 : scanCanonicalize (H12AffineFastState.compose env34642 (packedSelected [1,2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound34642 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env34643 : List Nat := [2,2,2,16,16,0,18,19,17,19,0,17,18,17,16,3,16,17,2,17,17,1,0,18,18,1,17,0,17,0,19,16,18,16,0,0]

theorem envBound34643 : H12AffineFastState.Bounded env34643 := by
  intro p hp
  have h : env34643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34642_34643 : H12AffineEnvironment.transform 1 2 env34642 = env34643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env34642 == env34643) = true)

theorem identity34643 : scanCanonicalize (H12AffineFastState.compose env34643 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound34643 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34644 : List Nat := [2,2,2,1,1,0,3,2,0,2,0,0,3,0,1,3,1,0,2,0,0,1,0,3,3,1,0,0,0,0,2,1,3,1,0,0]

theorem envBound34644 : H12AffineFastState.Bounded env34644 := by
  intro p hp
  have h : env34644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34643_34644 : H12AffineEnvironment.transform 3 1 env34643 = env34644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env34643 == env34644) = true)

def env34645 : List Nat := [2,4,8,16,32,0,20,256,512,1024,2048,1557,24,1297,261,1057,23,1077,1813,260,1557,540,1287,304,784,1538,1086,7,1297,3878,21,16,257,23,1280,277]

theorem envBound34645 : H12AffineFastState.Bounded env34645 := by
  intro p hp
  have h : env34645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34628_34645 : H12AffineEnvironment.transform 15 1057 env34628 = env34645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1057 env34628 == env34645) = true)

def env34646 : List Nat := [2,4,8,16,32,0,20,256,512,1024,1060,1557,24,1297,261,1057,23,1077,1813,260,1557,540,1287,304,784,1538,1086,7,1297,770,21,16,257,23,1280,277]

theorem envBound34646 : H12AffineFastState.Bounded env34646 := by
  intro p hp
  have h : env34646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34645_34646 : H12AffineEnvironment.transform 10 1060 env34645 = env34646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1060 env34645 == env34646) = true)

theorem identity34646 : scanCanonicalize (H12AffineFastState.compose env34646 (packedSelected [3,4,5,8,9,10,12,13,16,19] rootPS)) = affineNative (2^(9+1) ^^^ 826) := by decide +kernel

theorem selectedBound34646 : packedSelected [3,4,5,8,9,10,12,13,16,19] rootPS < 2^1333 := by decide +kernel

def env34647 : List Nat := [2,4,8,16,32,0,20,256,512,826,798,303,24,555,261,795,23,783,47,260,303,540,573,304,784,312,772,7,555,770,21,16,257,23,570,277]

theorem envBound34647 : H12AffineFastState.Bounded env34647 := by
  intro p hp
  have h : env34647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34646_34647 : H12AffineEnvironment.transform 9 826 env34646 = env34647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 826 env34646 == env34647) = true)

theorem identity34647 : scanCanonicalize (H12AffineFastState.compose env34647 (packedSelected [4,5,7,8,16] rootPS)) = affineNative (2^(7+1) ^^^ 30) := by decide +kernel

theorem selectedBound34647 : packedSelected [4,5,7,8,16] rootPS < 2^1333 := by decide +kernel

def env34648 : List Nat := [2,4,8,16,32,0,20,30,512,548,512,49,24,555,27,517,23,529,47,26,49,540,573,46,526,38,538,7,555,540,21,16,31,23,570,11]

theorem envBound34648 : H12AffineFastState.Bounded env34648 := by
  intro p hp
  have h : env34648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34647_34648 : H12AffineEnvironment.transform 7 30 env34647 = env34648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 30 env34647 == env34648) = true)

theorem identity34648 : scanCanonicalize (H12AffineFastState.compose env34648 (packedSelected [1,3,5,7,8,9,12] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound34648 : packedSelected [1,3,5,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env34649 : List Nat := [2,4,8,16,32,0,20,30,26,62,26,49,24,49,27,31,23,11,47,26,49,6,39,46,20,38,0,7,49,6,21,16,31,23,32,11]

theorem envBound34649 : H12AffineFastState.Bounded env34649 := by
  intro p hp
  have h : env34649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34648_34649 : H12AffineEnvironment.transform 8 26 env34648 = env34649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env34648 == env34649) = true)

theorem identity34649 : scanCanonicalize (H12AffineFastState.compose env34649 (packedSelected [0,1,3,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound34649 : packedSelected [0,1,3,7,8] rootPS < 2^1333 := by decide +kernel

def env34650 : List Nat := [2,4,8,16,12,0,20,30,26,18,26,29,24,29,27,31,23,11,3,26,29,6,11,2,20,10,0,7,29,6,21,16,31,23,12,11]

theorem envBound34650 : H12AffineFastState.Bounded env34650 := by
  intro p hp
  have h : env34650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34649_34650 : H12AffineEnvironment.transform 4 12 env34649 = env34650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env34649 == env34650) = true)

theorem identity34650 : scanCanonicalize (H12AffineFastState.compose env34650 (packedSelected [0,2,4,5] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound34650 : packedSelected [0,2,4,5] rootPS < 2^1333 := by decide +kernel

def env34651 : List Nat := [2,2,8,16,10,0,18,24,26,18,26,27,24,27,27,25,17,11,3,26,27,0,11,2,18,10,0,1,27,0,19,16,25,17,10,11]

theorem envBound34651 : H12AffineFastState.Bounded env34651 := by
  intro p hp
  have h : env34651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34650_34651 : H12AffineEnvironment.transform 1 2 env34650 = env34651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env34650 == env34651) = true)

theorem identity34651 : scanCanonicalize (H12AffineFastState.compose env34651 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound34651 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34652 : List Nat := [2,2,8,1,10,0,3,9,11,3,11,10,9,10,10,8,0,11,3,11,10,0,11,2,3,10,0,1,10,0,2,1,8,0,10,11]

theorem envBound34652 : H12AffineFastState.Bounded env34652 := by
  intro p hp
  have h : env34652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34651_34652 : H12AffineEnvironment.transform 3 1 env34651 = env34652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env34651 == env34652) = true)

theorem identity34652 : scanCanonicalize (H12AffineFastState.compose env34652 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound34652 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34653 : List Nat := [2,2,3,1,1,0,3,2,0,3,0,1,2,1,1,3,0,0,3,0,1,0,0,2,3,1,0,1,1,0,2,1,3,0,1,0]

theorem envBound34653 : H12AffineFastState.Bounded env34653 := by
  intro p hp
  have h : env34653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34652_34653 : H12AffineEnvironment.transform 2 3 env34652 = env34653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env34652 == env34653) = true)

def env34654 : List Nat := [2,4,8,16,32,0,20,256,512,1024,1061,1557,24,1297,261,1057,23,1077,1813,260,1557,540,1287,304,784,1538,1086,7,1297,771,21,16,257,23,1280,277]

theorem envBound34654 : H12AffineFastState.Bounded env34654 := by
  intro p hp
  have h : env34654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34645_34654 : H12AffineEnvironment.transform 10 1061 env34645 = env34654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1061 env34645 == env34654) = true)

theorem identity34654 : scanCanonicalize (H12AffineFastState.compose env34654 (packedSelected [3,4,5,8,9,10,12,13,16,19] rootPS)) = affineNative (2^(9+1) ^^^ 829) := by decide +kernel

theorem selectedBound34654 : packedSelected [3,4,5,8,9,10,12,13,16,19] rootPS < 2^1333 := by decide +kernel

def env34655 : List Nat := [2,4,8,16,32,0,20,256,512,829,792,296,24,556,261,796,23,776,40,260,296,540,570,304,784,319,771,7,556,771,21,16,257,23,573,277]

theorem envBound34655 : H12AffineFastState.Bounded env34655 := by
  intro p hp
  have h : env34655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34654_34655 : H12AffineEnvironment.transform 9 829 env34654 = env34655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 829 env34654 == env34655) = true)

theorem identity34655 : scanCanonicalize (H12AffineFastState.compose env34655 (packedSelected [2,5,7,8,9,11,12,13,15,17,18] rootPS)) = affineNative (2^(8+1) ^^^ 308) := by decide +kernel

theorem selectedBound34655 : packedSelected [2,5,7,8,9,11,12,13,15,17,18] rootPS < 2^1333 := by decide +kernel

def env34656 : List Nat := [2,4,8,16,32,0,20,256,308,9,44,296,24,280,261,40,23,60,40,260,296,296,270,304,36,319,55,7,280,55,21,16,257,23,265,277]

theorem envBound34656 : H12AffineFastState.Bounded env34656 := by
  intro p hp
  have h : env34656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34655_34656 : H12AffineEnvironment.transform 8 308 env34655 = env34656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env34655 == env34656) = true)

theorem identity34656 : scanCanonicalize (H12AffineFastState.compose env34656 (packedSelected [5,7,8,9,10] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound34656 : packedSelected [5,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env34657 : List Nat := [2,4,8,16,16,0,20,256,260,9,28,280,24,280,261,24,23,12,24,260,280,280,270,256,20,271,7,7,280,7,21,16,257,23,265,277]

theorem envBound34657 : H12AffineFastState.Bounded env34657 := by
  intro p hp
  have h : env34657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34656_34657 : H12AffineEnvironment.transform 4 16 env34656 = env34657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env34656 == env34657) = true)

theorem identity34657 : scanCanonicalize (H12AffineFastState.compose env34657 (packedSelected [3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound34657 : packedSelected [3,5,8] rootPS < 2^1333 := by decide +kernel

def env34658 : List Nat := [2,4,8,16,16,0,20,21,17,9,28,13,24,13,16,24,23,12,24,17,13,13,27,21,20,26,7,7,13,7,21,16,20,23,28,0]

theorem envBound34658 : H12AffineFastState.Bounded env34658 := by
  intro p hp
  have h : env34658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34657_34658 : H12AffineEnvironment.transform 7 21 env34657 = env34658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env34657 == env34658) = true)

theorem identity34658 : scanCanonicalize (H12AffineFastState.compose env34658 (packedSelected [0,3,4] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound34658 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env34659 : List Nat := [2,4,4,16,16,0,20,21,17,5,16,1,20,1,16,20,23,0,20,17,1,1,23,21,20,22,7,7,1,7,21,16,20,23,16,0]

theorem envBound34659 : H12AffineFastState.Bounded env34659 := by
  intro p hp
  have h : env34659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34658_34659 : H12AffineEnvironment.transform 2 4 env34658 = env34659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env34658 == env34659) = true)

def env34660 : List Nat := [2,4,8,16,32,1,128,256,512,1024,2048,1557,24,1297,260,65536,66615,65664,1812,261,1557,648,65830,66832,901,66083,1087,66598,1297,68358,21,16,257,66614,1281,276]

theorem envBound34660 : H12AffineFastState.Bounded env34660 := by
  intro p hp
  have h : env34660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34626_34660 : H12AffineEnvironment.transform 5 1 env34626 = env34660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env34626 == env34660) = true)

theorem identity34660 : scanCanonicalize (H12AffineFastState.compose env34660 (packedSelected [1,8,28] rootPS)) = affineNative (2^(9+1) ^^^ 388) := by decide +kernel

theorem selectedBound34660 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env34661 : List Nat := [2,4,8,16,32,1,128,256,512,388,2048,913,24,149,260,65536,65971,65664,656,261,913,648,65830,65684,901,66083,443,65954,149,68358,21,16,257,65970,133,276]

theorem envBound34661 : H12AffineFastState.Bounded env34661 := by
  intro p hp
  have h : env34661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34660_34661 : H12AffineEnvironment.transform 9 388 env34660 = env34661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 388 env34660 == env34661) = true)

def env34662 : List Nat := [2,4,8,16,32,1,128,256,512,388,2048,913,24,149,260,140,319,12,656,261,913,648,426,24,901,687,443,302,149,2954,21,16,257,318,133,276]

theorem envBound34662 : H12AffineFastState.Bounded env34662 := by
  intro p hp
  have h : env34662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34661_34662 : H12AffineEnvironment.transform 15 140 env34661 = env34662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 140 env34661 == env34662) = true)

def env34663 : List Nat := [2,4,8,16,32,1,128,256,512,388,412,913,24,149,260,140,319,12,656,261,913,648,426,24,901,687,443,302,149,534,21,16,257,318,133,276]

theorem envBound34663 : H12AffineFastState.Bounded env34663 := by
  intro p hp
  have h : env34663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34662_34663 : H12AffineEnvironment.transform 10 412 env34662 = env34663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 412 env34662 == env34663) = true)

theorem identity34663 : scanCanonicalize (H12AffineFastState.compose env34663 (packedSelected [1,3,4,5,7,13,16,18,23,24] rootPS)) = affineNative (2^(8+1) ^^^ 319) := by decide +kernel

theorem selectedBound34663 : packedSelected [1,3,4,5,7,13,16,18,23,24] rootPS < 2^1333 := by decide +kernel

def env34664 : List Nat := [2,4,8,16,32,1,128,256,319,388,412,174,24,149,260,140,319,12,431,261,174,439,426,24,186,400,443,302,149,297,21,16,257,318,133,276]

theorem envBound34664 : H12AffineFastState.Bounded env34664 := by
  intro p hp
  have h : env34664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34663_34664 : H12AffineEnvironment.transform 8 319 env34663 = env34664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 319 env34663 == env34664) = true)

theorem identity34664 : scanCanonicalize (H12AffineFastState.compose env34664 (packedSelected [7,8,9,10,11,12,15] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound34664 : packedSelected [7,8,9,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env34665 : List Nat := [2,4,8,16,11,1,128,256,276,388,412,133,24,149,260,140,276,12,388,261,133,412,385,24,145,400,400,261,149,258,21,16,257,277,133,276]

theorem envBound34665 : H12AffineFastState.Bounded env34665 := by
  intro p hp
  have h : env34665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34664_34665 : H12AffineEnvironment.transform 4 11 env34664 = env34665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env34664 == env34665) = true)

theorem identity34665 : scanCanonicalize (H12AffineFastState.compose env34665 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound34665 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env34666 : List Nat := [2,4,8,16,11,1,8,256,276,268,276,13,24,29,260,4,276,12,268,261,13,276,265,24,25,280,280,261,29,258,21,16,257,277,13,276]

theorem envBound34666 : H12AffineFastState.Bounded env34666 := by
  intro p hp
  have h : env34666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34665_34666 : H12AffineEnvironment.transform 6 8 env34665 = env34666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env34665 == env34666) = true)

theorem identity34666 : scanCanonicalize (H12AffineFastState.compose env34666 (packedSelected [0,1,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 24) := by decide +kernel

theorem selectedBound34666 : packedSelected [0,1,5,7] rootPS < 2^1333 := by decide +kernel

def env34667 : List Nat := [2,4,8,16,11,1,8,24,12,20,12,13,24,29,28,4,12,12,20,29,13,12,17,24,25,0,0,29,29,26,21,16,25,13,13,12]

theorem envBound34667 : H12AffineFastState.Bounded env34667 := by
  intro p hp
  have h : env34667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34666_34667 : H12AffineEnvironment.transform 7 24 env34666 = env34667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 24 env34666 == env34667) = true)

theorem identity34667 : scanCanonicalize (H12AffineFastState.compose env34667 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound34667 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env34668 : List Nat := [2,4,2,16,1,1,2,18,6,20,6,7,18,23,22,4,6,6,20,23,7,6,17,18,19,0,0,23,23,16,21,16,19,7,7,6]

theorem envBound34668 : H12AffineFastState.Bounded env34668 := by
  intro p hp
  have h : env34668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34667_34668 : H12AffineEnvironment.transform 2 2 env34667 = env34668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env34667 == env34668) = true)

def env34669 : List Nat := [2,4,8,16,32,1,128,256,512,388,413,913,24,149,260,140,319,12,656,261,913,648,426,24,901,687,443,302,149,535,21,16,257,318,133,276]

theorem envBound34669 : H12AffineFastState.Bounded env34669 := by
  intro p hp
  have h : env34669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34662_34669 : H12AffineEnvironment.transform 10 413 env34662 = env34669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 413 env34662 == env34669) = true)

theorem identity34669 : scanCanonicalize (H12AffineFastState.compose env34669 (packedSelected [1,3,4,5,7,13,16,18,23,24] rootPS)) = affineNative (2^(8+1) ^^^ 313) := by decide +kernel

theorem selectedBound34669 : packedSelected [1,3,4,5,7,13,16,18,23,24] rootPS < 2^1333 := by decide +kernel

def env34670 : List Nat := [2,4,8,16,32,1,128,256,313,388,413,168,24,149,260,140,319,12,425,261,168,433,426,24,188,406,443,302,149,302,21,16,257,318,133,276]

theorem envBound34670 : H12AffineFastState.Bounded env34670 := by
  intro p hp
  have h : env34670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34669_34670 : H12AffineEnvironment.transform 8 313 env34669 = env34670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 313 env34669 == env34670) = true)

theorem identity34670 : scanCanonicalize (H12AffineFastState.compose env34670 (packedSelected [3,7,9,10,11,17] rootPS)) = affineNative (2^(6+1) ^^^ 51) := by decide +kernel

theorem selectedBound34670 : packedSelected [3,7,9,10,11,17] rootPS < 2^1333 := by decide +kernel

def env34671 : List Nat := [2,4,8,16,32,1,51,256,313,311,302,27,24,38,260,63,319,12,282,261,27,258,281,24,15,293,264,302,38,302,21,16,257,318,54,276]

theorem envBound34671 : H12AffineFastState.Bounded env34671 := by
  intro p hp
  have h : env34671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34670_34671 : H12AffineEnvironment.transform 6 51 env34670 = env34671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 51 env34670 == env34671) = true)

theorem identity34671 : scanCanonicalize (H12AffineFastState.compose env34671 (packedSelected [2,3,4,9,10,12] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound34671 : packedSelected [2,3,4,9,10,12] rootPS < 2^1333 := by decide +kernel

def env34672 : List Nat := [2,4,8,1,32,1,34,256,296,294,302,10,9,38,260,46,302,12,267,261,10,258,264,9,15,293,264,302,38,302,4,1,257,303,39,261]

theorem envBound34672 : H12AffineFastState.Bounded env34672 := by
  intro p hp
  have h : env34672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34671_34672 : H12AffineEnvironment.transform 3 1 env34671 = env34672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env34671 == env34672) = true)

theorem identity34672 : scanCanonicalize (H12AffineFastState.compose env34672 (packedSelected [4,5,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound34672 : packedSelected [4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env34673 : List Nat := [2,4,8,1,0,1,2,256,264,262,270,10,9,6,260,14,270,12,267,261,10,258,264,9,15,261,264,270,6,270,4,1,257,271,7,261]

theorem envBound34673 : H12AffineFastState.Bounded env34673 := by
  intro p hp
  have h : env34673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34672_34673 : H12AffineEnvironment.transform 4 0 env34672 = env34673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env34672 == env34673) = true)

theorem identity34673 : scanCanonicalize (H12AffineFastState.compose env34673 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound34673 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env34674 : List Nat := [2,4,3,1,0,1,2,256,259,262,261,1,2,6,260,5,261,7,256,261,1,258,259,2,4,261,259,261,6,261,4,1,257,260,7,261]

theorem envBound34674 : H12AffineFastState.Bounded env34674 := by
  intro p hp
  have h : env34674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34673_34674 : H12AffineEnvironment.transform 2 3 env34673 = env34674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env34673 == env34674) = true)

theorem identity34674 : scanCanonicalize (H12AffineFastState.compose env34674 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound34674 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34675 : List Nat := [2,3,3,1,0,1,2,256,259,257,258,1,2,1,259,2,258,0,256,258,1,258,259,2,3,258,259,258,1,258,3,1,257,259,0,258]

theorem envBound34675 : H12AffineFastState.Bounded env34675 := by
  intro p hp
  have h : env34675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34674_34675 : H12AffineEnvironment.transform 1 3 env34674 = env34675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env34674 == env34675) = true)

theorem identity34675 : scanCanonicalize (H12AffineFastState.compose env34675 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 1) := by decide +kernel

theorem selectedBound34675 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34676 : List Nat := [2,3,3,1,0,1,2,1,2,0,3,1,2,1,2,2,3,0,1,3,1,3,2,2,3,3,2,3,1,3,3,1,0,2,0,3]

theorem envBound34676 : H12AffineFastState.Bounded env34676 := by
  intro p hp
  have h : env34676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34675_34676 : H12AffineEnvironment.transform 7 1 env34675 = env34676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 1 env34675 == env34676) = true)

theorem identity34676 : scanCanonicalize (H12AffineFastState.compose env34676 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound34676 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34677 : List Nat := [0,1,1,1,0,1,0,1,0,0,1,1,0,1,0,0,1,0,1,1,1,1,0,0,1,1,0,1,1,1,1,1,0,0,0,1]

theorem envBound34677 : H12AffineFastState.Bounded env34677 := by
  intro p hp
  have h : env34677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34676_34677 : H12AffineEnvironment.transform 0 0 env34676 = env34677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env34676 == env34677) = true)

def env34678 : List Nat := [2,4,8,16,32,1,128,256,512,388,2048,913,24,149,260,141,318,13,656,261,913,648,427,25,901,686,443,303,149,2955,21,16,257,319,133,276]

theorem envBound34678 : H12AffineFastState.Bounded env34678 := by
  intro p hp
  have h : env34678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34661_34678 : H12AffineEnvironment.transform 15 141 env34661 = env34678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 141 env34661 == env34678) = true)

def env34679 : List Nat := [2,4,8,16,32,1,128,256,512,388,412,913,24,149,260,141,318,13,656,261,913,648,427,25,901,686,443,303,149,535,21,16,257,319,133,276]

theorem envBound34679 : H12AffineFastState.Bounded env34679 := by
  intro p hp
  have h : env34679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34678_34679 : H12AffineEnvironment.transform 10 412 env34678 = env34679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 412 env34678 == env34679) = true)

theorem identity34679 : scanCanonicalize (H12AffineFastState.compose env34679 (packedSelected [1,3,4,5,7,13,16,18,23,24] rootPS)) = affineNative (2^(8+1) ^^^ 38) := by decide +kernel

theorem selectedBound34679 : packedSelected [1,3,4,5,7,13,16,18,23,24] rootPS < 2^1333 := by decide +kernel

def env34680 : List Nat := [2,4,8,16,32,1,128,256,38,388,412,439,24,149,260,141,318,13,182,261,439,174,427,25,419,136,443,303,149,49,21,16,257,319,133,276]

theorem envBound34680 : H12AffineFastState.Bounded env34680 := by
  intro p hp
  have h : env34680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34679_34680 : H12AffineEnvironment.transform 8 38 env34679 = env34680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 38 env34679 == env34680) = true)

theorem identity34680 : scanCanonicalize (H12AffineFastState.compose env34680 (packedSelected [5,7,8,9,11,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 57) := by decide +kernel

theorem selectedBound34680 : packedSelected [5,7,8,9,11,12,15] rootPS < 2^1333 := by decide +kernel

def env34681 : List Nat := [2,4,8,16,32,1,128,57,38,189,165,142,24,149,61,141,7,13,182,60,142,174,146,25,154,136,130,22,149,49,21,16,56,6,133,45]

theorem envBound34681 : H12AffineFastState.Bounded env34681 := by
  intro p hp
  have h : env34681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34680_34681 : H12AffineEnvironment.transform 7 57 env34680 = env34681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 57 env34680 == env34681) = true)

theorem identity34681 : scanCanonicalize (H12AffineFastState.compose env34681 (packedSelected [0,2,4,5,8,12] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound34681 : packedSelected [0,2,4,5,8,12] rootPS < 2^1333 := by decide +kernel

def env34682 : List Nat := [2,4,8,16,32,1,5,57,38,56,32,11,24,16,61,8,7,13,51,60,11,43,23,25,31,13,7,22,16,49,21,16,56,6,0,45]

theorem envBound34682 : H12AffineFastState.Bounded env34682 := by
  intro p hp
  have h : env34682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34681_34682 : H12AffineEnvironment.transform 6 5 env34681 = env34682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env34681 == env34682) = true)

theorem identity34682 : scanCanonicalize (H12AffineFastState.compose env34682 (packedSelected [1,2,3,4,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound34682 : packedSelected [1,2,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env34683 : List Nat := [2,4,8,16,27,1,5,2,29,3,27,11,24,16,6,8,7,13,8,7,11,16,23,25,31,13,7,22,16,10,21,16,3,6,0,22]

theorem envBound34683 : H12AffineFastState.Bounded env34683 := by
  intro p hp
  have h : env34683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34682_34683 : H12AffineEnvironment.transform 4 27 env34682 = env34683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env34682 == env34683) = true)

theorem identity34683 : scanCanonicalize (H12AffineFastState.compose env34683 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound34683 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env34684 : List Nat := [2,3,8,16,27,1,2,2,26,3,27,11,24,16,1,8,0,10,8,0,11,16,16,25,24,10,0,17,16,10,18,16,3,1,0,17]

theorem envBound34684 : H12AffineFastState.Bounded env34684 := by
  intro p hp
  have h : env34684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34683_34684 : H12AffineEnvironment.transform 1 3 env34683 = env34684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env34683 == env34684) = true)

def env34685 : List Nat := [2,4,8,16,32,1,128,256,512,388,413,913,24,149,260,141,318,13,656,261,913,648,427,25,901,686,443,303,149,534,21,16,257,319,133,276]

theorem envBound34685 : H12AffineFastState.Bounded env34685 := by
  intro p hp
  have h : env34685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34678_34685 : H12AffineEnvironment.transform 10 413 env34678 = env34685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 413 env34678 == env34685) = true)

theorem identity34685 : scanCanonicalize (H12AffineFastState.compose env34685 (packedSelected [1,3,4,5,7,13,16,18,23,24] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound34685 : packedSelected [1,3,4,5,7,13,16,18,23,24] rootPS < 2^1333 := by decide +kernel

def env34686 : List Nat := [2,4,8,16,32,1,128,256,32,388,413,433,24,149,260,141,318,13,176,261,433,168,427,25,421,142,443,303,149,54,21,16,257,319,133,276]

theorem envBound34686 : H12AffineFastState.Bounded env34686 := by
  intro p hp
  have h : env34686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34685_34686 : H12AffineEnvironment.transform 8 32 env34685 = env34686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env34685 == env34686) = true)

theorem identity34686 : scanCanonicalize (H12AffineFastState.compose env34686 (packedSelected [0,1,2,4,7,9,12,17] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound34686 : packedSelected [0,1,2,4,7,9,12,17] rootPS < 2^1333 := by decide +kernel

def env34687 : List Nat := [2,4,8,16,32,1,35,256,32,295,318,274,24,54,260,46,318,13,19,261,274,11,264,25,262,45,280,303,54,54,21,16,257,319,38,276]

theorem envBound34687 : H12AffineFastState.Bounded env34687 := by
  intro p hp
  have h : env34687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34686_34687 : H12AffineEnvironment.transform 6 35 env34686 = env34687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env34686 == env34687) = true)

theorem identity34687 : scanCanonicalize (H12AffineFastState.compose env34687 (packedSelected [0,5,9] rootPS)) = affineNative (2^(7+1) ^^^ 40) := by decide +kernel

theorem selectedBound34687 : packedSelected [0,5,9] rootPS < 2^1333 := by decide +kernel

def env34688 : List Nat := [2,4,8,16,32,1,35,40,32,15,22,58,24,54,44,46,22,13,19,45,58,11,32,25,46,45,48,7,54,54,21,16,41,23,38,60]

theorem envBound34688 : H12AffineFastState.Bounded env34688 := by
  intro p hp
  have h : env34688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34687_34688 : H12AffineEnvironment.transform 7 40 env34687 = env34688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 40 env34687 == env34688) = true)

theorem identity34688 : scanCanonicalize (H12AffineFastState.compose env34688 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound34688 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env34689 : List Nat := [2,4,8,6,32,1,35,40,32,15,0,44,14,32,44,46,0,13,5,45,44,11,32,15,46,45,38,7,32,32,3,6,41,1,38,42]

theorem envBound34689 : H12AffineFastState.Bounded env34689 := by
  intro p hp
  have h : env34689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34688_34689 : H12AffineEnvironment.transform 3 6 env34688 = env34689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env34688 == env34689) = true)

theorem identity34689 : scanCanonicalize (H12AffineFastState.compose env34689 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound34689 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34690 : List Nat := [2,4,4,6,32,1,35,36,32,3,0,32,2,32,32,34,0,1,5,33,32,7,32,3,34,33,38,7,32,32,3,6,37,1,38,38]

theorem envBound34690 : H12AffineFastState.Bounded env34690 := by
  intro p hp
  have h : env34690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34689_34690 : H12AffineEnvironment.transform 2 4 env34689 = env34690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env34689 == env34690) = true)

theorem identity34690 : scanCanonicalize (H12AffineFastState.compose env34690 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound34690 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34691 : List Nat := [2,2,2,0,32,1,35,34,32,3,0,32,2,32,32,34,0,1,3,33,32,1,32,3,34,33,32,1,32,32,3,0,35,1,32,32]

theorem envBound34691 : H12AffineFastState.Bounded env34691 := by
  intro p hp
  have h : env34691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34690_34691 : H12AffineEnvironment.transform 1 2 env34690 = env34691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env34690 == env34691) = true)

def env34692 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74862,65665,4416,8540,4096,5277,74046,66897,13769,78894,1151,74814,1297,81226,8205,8200,257,74798,1344,5952]

theorem envBound34692 : H12AffineFastState.Bounded env34692 := by
  intro p hp
  have h : env34692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34567_34692 : H12AffineEnvironment.transform 17 65665 env34567 = env34692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env34567 == env34692) = true)

theorem identity34692 : scanCanonicalize (H12AffineFastState.compose env34692 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5465) := by decide +kernel

theorem selectedBound34692 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env34693 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5465,1297,5124,65536,69943,65665,4416,5125,4096,5277,70759,66897,144,65911,1151,69991,1297,67603,5460,5457,257,70007,1344,5952]

theorem envBound34693 : H12AffineFastState.Bounded env34693 := by
  intro p hp
  have h : env34693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34692_34693 : H12AffineEnvironment.transform 12 5465 env34692 = env34693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5465 env34692 == env34693) = true)

def env34694 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1556,845,1297,528,65536,67363,65665,1876,529,1556,649,66163,66897,144,65911,1151,67443,1297,67603,832,837,257,67427,1344,340]

theorem envBound34694 : H12AffineFastState.Bounded env34694 := by
  intro p hp
  have h : env34694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34693_34694 : H12AffineEnvironment.transform 11 1556 env34693 = env34694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env34693 == env34694) = true)

def env34695 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,836,845,65,528,65536,66163,65665,516,529,836,649,66163,65537,144,65911,303,66083,65,67603,832,837,257,66099,16,340]

theorem envBound34695 : H12AffineFastState.Bounded env34695 := by
  intro p hp
  have h : env34695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34694_34695 : H12AffineEnvironment.transform 9 336 env34694 = env34695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env34694 == env34695) = true)

theorem identity34695 : scanCanonicalize (H12AffineFastState.compose env34695 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 482) := by decide +kernel

theorem selectedBound34695 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env34696 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,836,845,65,528,482,913,355,516,529,836,649,913,483,144,149,303,961,65,2545,832,837,257,977,16,340]

theorem envBound34696 : H12AffineFastState.Bounded env34696 := by
  intro p hp
  have h : env34696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34695_34696 : H12AffineEnvironment.transform 15 482 env34695 = env34696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 482 env34695 == env34696) = true)

def env34697 : List Nat := [2,4,8,16,32,64,128,256,512,336,976,836,845,65,528,482,913,355,516,529,836,649,913,483,144,149,303,961,65,545,832,837,257,977,16,340]

theorem envBound34697 : H12AffineFastState.Bounded env34697 := by
  intro p hp
  have h : env34697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34696_34697 : H12AffineEnvironment.transform 10 976 env34696 = env34697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 976 env34696 == env34697) = true)

def env34698 : List Nat := [2,4,8,16,32,64,128,256,228,336,308,416,425,65,244,482,373,355,224,245,416,109,373,483,144,149,303,293,65,197,420,417,257,309,16,340]

theorem envBound34698 : H12AffineFastState.Bounded env34698 := by
  intro p hp
  have h : env34698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34697_34698 : H12AffineEnvironment.transform 8 228 env34697 = env34698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 228 env34697 == env34698) = true)

theorem identity34698 : scanCanonicalize (H12AffineFastState.compose env34698 (packedSelected [1,2,3,4,7,12,13,16,17,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 104) := by decide +kernel

theorem selectedBound34698 : packedSelected [1,2,3,4,7,12,13,16,17,20,21] rootPS < 2^1333 := by decide +kernel

def env34699 : List Nat := [2,4,8,16,32,64,128,104,228,56,92,200,193,65,244,138,29,11,224,245,200,109,29,139,144,149,71,77,65,197,204,201,105,93,16,60]

theorem envBound34699 : H12AffineFastState.Bounded env34699 := by
  intro p hp
  have h : env34699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34698_34699 : H12AffineEnvironment.transform 7 104 env34698 = env34699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 104 env34698 == env34699) = true)

theorem identity34699 : scanCanonicalize (H12AffineFastState.compose env34699 (packedSelected [0,1,4,7,8,9,12,13,17] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound34699 : packedSelected [0,1,4,7,8,9,12,13,17] rootPS < 2^1333 := by decide +kernel

def env34700 : List Nat := [2,4,8,16,32,64,41,104,77,56,92,97,104,65,93,35,29,11,73,92,97,109,29,34,57,60,71,77,65,108,101,96,105,93,16,60]

theorem envBound34700 : H12AffineFastState.Bounded env34700 := by
  intro p hp
  have h : env34700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34699_34700 : H12AffineEnvironment.transform 6 41 env34699 = env34700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env34699 == env34700) = true)

theorem identity34700 : scanCanonicalize (H12AffineFastState.compose env34700 (packedSelected [3,4,7,8,11] rootPS)) = affineNative (2^(5+1) ^^^ 44) := by decide +kernel

theorem selectedBound34700 : packedSelected [3,4,7,8,11] rootPS < 2^1333 := by decide +kernel

def env34701 : List Nat := [2,4,8,16,32,44,41,4,33,56,48,13,4,45,49,35,29,11,37,48,13,1,29,34,57,60,43,33,45,0,9,12,5,49,16,60]

theorem envBound34701 : H12AffineFastState.Bounded env34701 := by
  intro p hp
  have h : env34701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34700_34701 : H12AffineEnvironment.transform 5 44 env34700 = env34701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 44 env34700 == env34701) = true)

theorem identity34701 : scanCanonicalize (H12AffineFastState.compose env34701 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound34701 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env34702 : List Nat := [2,4,8,16,10,6,3,4,11,18,26,13,4,7,27,9,29,11,15,26,13,1,29,8,19,22,1,11,7,0,9,12,5,27,16,22]

theorem envBound34702 : H12AffineFastState.Bounded env34702 := by
  intro p hp
  have h : env34702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34701_34702 : H12AffineEnvironment.transform 4 10 env34701 = env34702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env34701 == env34702) = true)

theorem identity34702 : scanCanonicalize (H12AffineFastState.compose env34702 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound34702 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env34703 : List Nat := [2,4,4,16,6,6,3,4,7,18,22,1,4,7,23,5,17,7,3,22,1,1,17,4,19,22,1,7,7,0,5,0,5,23,16,22]

theorem envBound34703 : H12AffineFastState.Bounded env34703 := by
  intro p hp
  have h : env34703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34702_34703 : H12AffineEnvironment.transform 2 4 env34702 = env34703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env34702 == env34703) = true)

def env34704 : List Nat := [2,4,8,16,32,64,128,256,229,336,309,417,424,65,245,482,372,355,225,244,417,108,372,483,144,149,303,292,65,196,421,416,257,308,16,340]

theorem envBound34704 : H12AffineFastState.Bounded env34704 := by
  intro p hp
  have h : env34704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34697_34704 : H12AffineEnvironment.transform 8 229 env34697 = env34704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 229 env34697 == env34704) = true)

theorem identity34704 : scanCanonicalize (H12AffineFastState.compose env34704 (packedSelected [1,2,3,4,7,12,13,16,17,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 111) := by decide +kernel

theorem selectedBound34704 : packedSelected [1,2,3,4,7,12,13,16,17,20,21] rootPS < 2^1333 := by decide +kernel

def env34705 : List Nat := [2,4,8,16,32,64,128,111,229,63,90,206,199,65,245,141,27,12,225,244,206,108,27,140,144,149,64,75,65,196,202,207,110,91,16,59]

theorem envBound34705 : H12AffineFastState.Bounded env34705 := by
  intro p hp
  have h : env34705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34704_34705 : H12AffineEnvironment.transform 7 111 env34704 = env34705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 111 env34704 == env34705) = true)

theorem identity34705 : scanCanonicalize (H12AffineFastState.compose env34705 (packedSelected [1,2,3,5,7,9,10,11,12,17] rootPS)) = affineNative (2^(6+1) ^^^ 127) := by decide +kernel

theorem selectedBound34705 : packedSelected [1,2,3,5,7,9,10,11,12,17] rootPS < 2^1333 := by decide +kernel

def env34706 : List Nat := [2,4,8,16,32,64,127,111,26,63,90,49,56,65,10,114,27,12,30,11,49,108,27,115,111,106,64,75,65,59,53,48,110,91,16,59]

theorem envBound34706 : H12AffineFastState.Bounded env34706 := by
  intro p hp
  have h : env34706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34705_34706 : H12AffineEnvironment.transform 6 127 env34705 = env34706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 127 env34705 == env34706) = true)

theorem identity34706 : scanCanonicalize (H12AffineFastState.compose env34706 (packedSelected [0,1,7,8,11] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound34706 : packedSelected [0,1,7,8,11] rootPS < 2^1333 := by decide +kernel

def env34707 : List Nat := [2,4,8,16,27,64,68,84,26,4,90,10,3,65,10,73,27,12,30,11,10,87,27,72,84,81,64,75,65,0,14,11,85,91,16,0]

theorem envBound34707 : H12AffineFastState.Bounded env34707 := by
  intro p hp
  have h : env34707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34706_34707 : H12AffineEnvironment.transform 4 27 env34706 = env34707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env34706 == env34707) = true)

theorem identity34707 : scanCanonicalize (H12AffineFastState.compose env34707 (packedSelected [0,1,7] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound34707 : packedSelected [0,1,7] rootPS < 2^1333 := by decide +kernel

def env34708 : List Nat := [2,3,8,16,27,64,67,83,26,3,90,10,3,65,10,73,27,11,25,11,10,80,27,72,83,81,64,75,65,0,9,11,82,91,16,0]

theorem envBound34708 : H12AffineFastState.Bounded env34708 := by
  intro p hp
  have h : env34708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34707_34708 : H12AffineEnvironment.transform 1 3 env34707 = env34708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env34707 == env34708) = true)

theorem identity34708 : scanCanonicalize (H12AffineFastState.compose env34708 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound34708 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env34709 : List Nat := [2,3,8,10,1,64,67,73,0,3,64,10,3,65,10,73,1,11,3,11,10,74,1,72,73,75,64,75,65,0,9,11,72,65,10,0]

theorem envBound34709 : H12AffineFastState.Bounded env34709 := by
  intro p hp
  have h : env34709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34708_34709 : H12AffineEnvironment.transform 3 10 env34708 = env34709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env34708 == env34709) = true)

theorem identity34709 : scanCanonicalize (H12AffineFastState.compose env34709 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound34709 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34710 : List Nat := [2,3,8,10,1,10,9,3,0,3,10,10,3,11,10,3,1,11,3,11,10,0,1,2,3,1,10,1,11,0,9,11,2,11,10,0]

theorem envBound34710 : H12AffineFastState.Bounded env34710 := by
  intro p hp
  have h : env34710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34709_34710 : H12AffineEnvironment.transform 5 10 env34709 = env34710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env34709 == env34710) = true)

def env34711 : List Nat := [2,4,8,16,32,64,128,256,512,336,977,836,845,65,528,482,913,355,516,529,836,649,913,483,144,149,303,961,65,544,832,837,257,977,16,340]

theorem envBound34711 : H12AffineFastState.Bounded env34711 := by
  intro p hp
  have h : env34711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34696_34711 : H12AffineEnvironment.transform 10 977 env34696 = env34711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 977 env34696 == env34711) = true)

def env34712 : List Nat := [2,4,8,16,32,64,128,256,228,336,309,416,425,65,244,482,373,355,224,245,416,109,373,483,144,149,303,293,65,196,420,417,257,309,16,340]

theorem envBound34712 : H12AffineFastState.Bounded env34712 := by
  intro p hp
  have h : env34712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34711_34712 : H12AffineEnvironment.transform 8 228 env34711 = env34712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 228 env34711 == env34712) = true)

theorem identity34712 : scanCanonicalize (H12AffineFastState.compose env34712 (packedSelected [1,2,3,4,7,12,13,16,17,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 183) := by decide +kernel

theorem selectedBound34712 : packedSelected [1,2,3,4,7,12,13,16,17,20,21] rootPS < 2^1333 := by decide +kernel

def env34713 : List Nat := [2,4,8,16,32,64,128,183,228,231,130,23,30,65,244,85,194,212,224,245,23,109,194,84,144,149,152,146,65,196,19,22,182,130,16,227]

theorem envBound34713 : H12AffineFastState.Bounded env34713 := by
  intro p hp
  have h : env34713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34712_34713 : H12AffineEnvironment.transform 7 183 env34712 = env34713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 183 env34712 == env34713) = true)

theorem identity34713 : scanCanonicalize (H12AffineFastState.compose env34713 (packedSelected [3,10,13,15,17,18] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound34713 : packedSelected [3,10,13,15,17,18] rootPS < 2^1333 := by decide +kernel

def env34714 : List Nat := [2,4,8,16,32,64,14,57,106,105,12,23,30,65,122,85,76,90,110,123,23,109,76,84,30,27,22,28,65,74,19,22,56,12,16,109]

theorem envBound34714 : H12AffineFastState.Bounded env34714 := by
  intro p hp
  have h : env34714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34713_34714 : H12AffineEnvironment.transform 6 14 env34713 = env34714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env34713 == env34714) = true)

theorem identity34714 : scanCanonicalize (H12AffineFastState.compose env34714 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound34714 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env34715 : List Nat := [2,3,8,16,32,64,9,57,106,105,11,16,25,65,122,82,75,90,105,123,16,106,75,83,25,27,17,27,65,74,19,17,56,11,16,106]

theorem envBound34715 : H12AffineFastState.Bounded env34715 := by
  intro p hp
  have h : env34715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34714_34715 : H12AffineEnvironment.transform 1 3 env34714 = env34715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env34714 == env34715) = true)

theorem identity34715 : scanCanonicalize (H12AffineFastState.compose env34715 (packedSelected [8] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound34715 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env34716 : List Nat := [2,3,8,16,32,1,9,57,43,40,11,16,25,0,59,19,10,27,40,58,16,43,10,18,25,27,17,27,0,11,19,17,56,11,16,43]

theorem envBound34716 : H12AffineFastState.Bounded env34716 := by
  intro p hp
  have h : env34716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34715_34716 : H12AffineEnvironment.transform 5 1 env34715 = env34716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env34715 == env34716) = true)

theorem identity34716 : scanCanonicalize (H12AffineFastState.compose env34716 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound34716 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env34717 : List Nat := [2,3,2,16,32,1,3,51,33,34,1,16,19,0,49,19,0,17,34,48,16,33,0,18,19,17,17,17,0,1,19,17,50,1,16,33]

theorem envBound34717 : H12AffineFastState.Bounded env34717 := by
  intro p hp
  have h : env34717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34716_34717 : H12AffineEnvironment.transform 2 2 env34716 = env34717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env34716 == env34717) = true)

def env34718 : List Nat := [2,4,8,16,32,64,128,256,229,336,308,417,424,65,245,482,372,355,225,244,417,108,372,483,144,149,303,292,65,197,421,416,257,308,16,340]

theorem envBound34718 : H12AffineFastState.Bounded env34718 := by
  intro p hp
  have h : env34718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34711_34718 : H12AffineEnvironment.transform 8 229 env34711 = env34718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 229 env34711 == env34718) = true)

theorem identity34718 : scanCanonicalize (H12AffineFastState.compose env34718 (packedSelected [1,2,3,4,7,12,13,16,17,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 176) := by decide +kernel

theorem selectedBound34718 : packedSelected [1,2,3,4,7,12,13,16,17,20,21] rootPS < 2^1333 := by decide +kernel

def env34719 : List Nat := [2,4,8,16,32,64,128,176,229,224,132,17,24,65,245,82,196,211,225,244,17,108,196,83,144,149,159,148,65,197,21,16,177,132,16,228]

theorem envBound34719 : H12AffineFastState.Bounded env34719 := by
  intro p hp
  have h : env34719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34718_34719 : H12AffineEnvironment.transform 7 176 env34718 = env34719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 176 env34718 == env34719) = true)

theorem identity34719 : scanCanonicalize (H12AffineFastState.compose env34719 (packedSelected [4,9,16] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound34719 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env34720 : List Nat := [2,4,8,16,16,64,128,128,213,208,132,17,24,65,197,82,196,211,209,196,17,92,196,83,144,149,159,148,65,197,21,16,129,132,16,212]

theorem envBound34720 : H12AffineFastState.Bounded env34720 := by
  intro p hp
  have h : env34720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34719_34720 : H12AffineEnvironment.transform 4 16 env34719 = env34720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env34719 == env34720) = true)

theorem identity34720 : scanCanonicalize (H12AffineFastState.compose env34720 (packedSelected [0,3,8,10] rootPS)) = affineNative (2^(6+1) ^^^ 70) := by decide +kernel

theorem selectedBound34720 : packedSelected [0,3,8,10] rootPS < 2^1333 := by decide +kernel

def env34721 : List Nat := [2,4,8,16,16,64,70,70,19,22,66,17,24,65,3,82,2,21,23,2,17,92,2,83,86,83,89,82,65,3,21,16,71,66,16,18]

theorem envBound34721 : H12AffineFastState.Bounded env34721 := by
  intro p hp
  have h : env34721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34720_34721 : H12AffineEnvironment.transform 6 70 env34720 = env34721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 70 env34720 == env34721) = true)

def env34722 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,837,845,64,528,65536,66162,65665,517,529,837,649,66163,65536,144,65911,302,66082,64,67603,832,837,257,66098,17,340]

theorem envBound34722 : H12AffineFastState.Bounded env34722 := by
  intro p hp
  have h : env34722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34694_34722 : H12AffineEnvironment.transform 9 337 env34694 = env34722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env34694 == env34722) = true)

theorem identity34722 : scanCanonicalize (H12AffineFastState.compose env34722 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 759) := by decide +kernel

theorem selectedBound34722 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env34723 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,837,845,64,528,759,133,630,517,529,837,649,132,759,144,896,302,213,64,2788,832,837,257,197,17,340]

theorem envBound34723 : H12AffineFastState.Bounded env34723 := by
  intro p hp
  have h : env34723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34722_34723 : H12AffineEnvironment.transform 15 759 env34722 = env34723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 759 env34722 == env34723) = true)

def env34724 : List Nat := [2,4,8,16,32,64,128,256,384,337,2048,197,205,64,400,375,133,502,389,401,197,265,132,375,144,0,302,213,64,2404,192,197,257,197,17,340]

theorem envBound34724 : H12AffineFastState.Bounded env34724 := by
  intro p hp
  have h : env34724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34723_34724 : H12AffineEnvironment.transform 8 384 env34723 = env34724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 384 env34723 == env34724) = true)

theorem identity34724 : scanCanonicalize (H12AffineFastState.compose env34724 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 192) := by decide +kernel

theorem selectedBound34724 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env34725 : List Nat := [2,4,8,16,32,64,128,192,64,145,2048,197,205,64,80,183,133,54,69,81,197,201,132,183,144,0,238,213,64,2212,192,197,193,197,17,148]

theorem envBound34725 : H12AffineFastState.Bounded env34725 := by
  intro p hp
  have h : env34725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34724_34725 : H12AffineEnvironment.transform 7 192 env34724 = env34725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 192 env34724 == env34725) = true)

theorem identity34725 : scanCanonicalize (H12AffineFastState.compose env34725 (packedSelected [4,5,8,9,10,13,15,16,17] rootPS)) = affineNative (2^(6+1) ^^^ 116) := by decide +kernel

theorem selectedBound34725 : packedSelected [4,5,8,9,10,13,15,16,17] rootPS < 2^1333 := by decide +kernel

def env34726 : List Nat := [2,4,8,16,32,64,116,52,64,101,2048,49,57,64,80,67,113,54,69,81,49,61,112,67,100,0,26,33,64,2128,52,49,53,49,17,96]

theorem envBound34726 : H12AffineFastState.Bounded env34726 := by
  intro p hp
  have h : env34726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34725_34726 : H12AffineEnvironment.transform 6 116 env34725 = env34726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 116 env34725 == env34726) = true)

theorem identity34726 : scanCanonicalize (H12AffineFastState.compose env34726 (packedSelected [1,10,13,15,19] rootPS)) = affineNative (2^(10+1) ^^^ 6) := by decide +kernel

theorem selectedBound34726 : packedSelected [1,10,13,15,19] rootPS < 2^1333 := by decide +kernel

def env34727 : List Nat := [2,4,8,16,32,64,116,52,64,101,6,49,57,64,80,67,113,54,69,81,49,61,112,67,100,0,26,33,64,86,52,49,53,49,17,96]

theorem envBound34727 : H12AffineFastState.Bounded env34727 := by
  intro p hp
  have h : env34727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34726_34727 : H12AffineEnvironment.transform 10 6 env34726 = env34727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 6 env34726 == env34727) = true)

theorem identity34727 : scanCanonicalize (H12AffineFastState.compose env34727 (packedSelected [2,3,10] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound34727 : packedSelected [2,3,10] rootPS < 2^1333 := by decide +kernel

def env34728 : List Nat := [2,4,8,16,7,64,83,19,64,66,6,22,30,64,80,67,86,17,69,81,22,26,87,67,67,0,26,6,64,86,19,22,18,22,17,71]

theorem envBound34728 : H12AffineFastState.Bounded env34728 := by
  intro p hp
  have h : env34728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34727_34728 : H12AffineEnvironment.transform 4 7 env34727 = env34728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env34727 == env34728) = true)

def env34729 : List Nat := [2,4,8,16,32,64,128,256,385,337,2048,196,204,64,401,374,133,503,388,400,196,264,132,374,144,1,302,213,64,2405,193,196,257,197,17,340]

theorem envBound34729 : H12AffineFastState.Bounded env34729 := by
  intro p hp
  have h : env34729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34723_34729 : H12AffineEnvironment.transform 8 385 env34723 = env34729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 385 env34723 == env34729) = true)

theorem identity34729 : scanCanonicalize (H12AffineFastState.compose env34729 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(6+1) ^^^ 68) := by decide +kernel

theorem selectedBound34729 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env34730 : List Nat := [2,4,8,16,32,64,68,256,325,337,2048,0,8,64,341,374,65,307,320,340,0,264,64,374,84,1,302,17,64,2405,5,0,257,1,17,340]

theorem envBound34730 : H12AffineFastState.Bounded env34730 := by
  intro p hp
  have h : env34730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34729_34730 : H12AffineEnvironment.transform 6 68 env34729 = env34730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 68 env34729 == env34730) = true)

theorem identity34730 : scanCanonicalize (H12AffineFastState.compose env34730 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound34730 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env34731 : List Nat := [2,4,8,16,32,64,68,21,80,68,2048,0,8,64,64,99,65,38,85,65,0,29,64,99,84,1,59,17,64,2160,5,0,20,1,17,65]

theorem envBound34731 : H12AffineFastState.Bounded env34731 := by
  intro p hp
  have h : env34731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34730_34731 : H12AffineEnvironment.transform 7 21 env34730 = env34731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env34730 == env34731) = true)

theorem identity34731 : scanCanonicalize (H12AffineFastState.compose env34731 (packedSelected [0,3,5,7,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 23) := by decide +kernel

theorem selectedBound34731 : packedSelected [0,3,5,7,11,12] rootPS < 2^1333 := by decide +kernel

def env34732 : List Nat := [2,4,8,16,32,23,19,21,7,19,2048,0,8,23,23,52,22,38,2,22,0,29,23,52,3,1,59,17,23,2087,5,0,20,1,17,22]

theorem envBound34732 : H12AffineFastState.Bounded env34732 := by
  intro p hp
  have h : env34732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34731_34732 : H12AffineEnvironment.transform 5 23 env34731 = env34732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 23 env34731 == env34732) = true)

theorem identity34732 : scanCanonicalize (H12AffineFastState.compose env34732 (packedSelected [0,1,3,7,8,11] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound34732 : packedSelected [0,1,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env34733 : List Nat := [2,4,8,16,10,23,19,21,7,19,2048,0,8,23,23,30,22,12,2,22,0,29,23,30,3,1,17,17,23,2061,5,0,20,1,17,22]

theorem envBound34733 : H12AffineFastState.Bounded env34733 := by
  intro p hp
  have h : env34733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34732_34733 : H12AffineEnvironment.transform 4 10 env34732 = env34733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env34732 == env34733) = true)

theorem identity34733 : scanCanonicalize (H12AffineFastState.compose env34733 (packedSelected [0,2,4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound34733 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env34734 : List Nat := [2,4,8,16,10,23,19,21,7,19,1,0,8,23,23,30,22,12,2,22,0,29,23,30,3,1,17,17,23,12,5,0,20,1,17,22]

theorem envBound34734 : H12AffineFastState.Bounded env34734 := by
  intro p hp
  have h : env34734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34733_34734 : H12AffineEnvironment.transform 10 1 env34733 = env34734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env34733 == env34734) = true)

theorem identity34734 : scanCanonicalize (H12AffineFastState.compose env34734 (packedSelected [0,1,2,7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound34734 : packedSelected [0,1,2,7] rootPS < 2^1333 := by decide +kernel

def env34735 : List Nat := [2,4,8,0,10,7,3,5,7,3,1,0,8,7,7,14,6,12,2,6,0,13,7,14,3,1,1,1,7,12,5,0,4,1,1,6]

theorem envBound34735 : H12AffineFastState.Bounded env34735 := by
  intro p hp
  have h : env34735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34734_34735 : H12AffineEnvironment.transform 3 0 env34734 = env34735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env34734 == env34735) = true)

theorem identity34735 : scanCanonicalize (H12AffineFastState.compose env34735 (packedSelected [0,1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound34735 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env34736 : List Nat := [1,4,8,0,9,4,0,5,4,0,1,0,8,4,4,13,5,12,1,5,0,13,4,13,0,1,1,1,4,12,5,0,4,1,1,5]

theorem envBound34736 : H12AffineFastState.Bounded env34736 := by
  intro p hp
  have h : env34736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34735_34736 : H12AffineEnvironment.transform 0 1 env34735 = env34736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env34735 == env34736) = true)

theorem identity34736 : scanCanonicalize (H12AffineFastState.compose env34736 (packedSelected [0,2] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound34736 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env34737 : List Nat := [1,1,8,0,9,1,0,0,1,0,1,0,8,1,1,8,0,9,1,0,0,8,1,8,0,1,1,1,1,9,0,0,1,1,1,0]

theorem envBound34737 : H12AffineFastState.Bounded env34737 := by
  intro p hp
  have h : env34737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34736_34737 : H12AffineEnvironment.transform 1 1 env34736 = env34737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env34736 == env34737) = true)

theorem identity34737 : scanCanonicalize (H12AffineFastState.compose env34737 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound34737 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34738 : List Nat := [1,1,0,0,1,1,0,0,1,0,1,0,0,1,1,0,0,1,1,0,0,0,1,0,0,1,1,1,1,1,0,0,1,1,1,0]

theorem envBound34738 : H12AffineFastState.Bounded env34738 := by
  intro p hp
  have h : env34738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34737_34738 : H12AffineEnvironment.transform 2 0 env34737 = env34738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env34737 == env34738) = true)

def env34739 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1557,844,1297,529,65536,67362,65665,1877,528,1557,648,66162,66897,144,65911,1151,67442,1297,67603,833,836,257,67426,1344,341]

theorem envBound34739 : H12AffineFastState.Bounded env34739 := by
  intro p hp
  have h : env34739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34693_34739 : H12AffineEnvironment.transform 11 1557 env34693 = env34739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env34693 == env34739) = true)

def env34740 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,837,844,65,529,65536,66162,65665,517,528,837,648,66162,65537,144,65911,303,66082,65,67603,833,836,257,66098,16,341]

theorem envBound34740 : H12AffineFastState.Bounded env34740 := by
  intro p hp
  have h : env34740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34739_34740 : H12AffineEnvironment.transform 9 336 env34739 = env34740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env34739 == env34740) = true)

theorem identity34740 : scanCanonicalize (H12AffineFastState.compose env34740 (packedSelected [1,8,28] rootPS)) = affineNative (2^(8+1) ^^^ 385) := by decide +kernel

theorem selectedBound34740 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env34741 : List Nat := [2,4,8,16,32,64,128,256,385,336,2048,196,205,65,400,65536,66035,65665,388,401,196,265,66035,65537,144,65911,303,65955,65,67603,192,197,257,65971,16,341]

theorem envBound34741 : H12AffineFastState.Bounded env34741 := by
  intro p hp
  have h : env34741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34740_34741 : H12AffineEnvironment.transform 8 385 env34740 = env34741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 385 env34740 == env34741) = true)

def env34742 : List Nat := [2,4,8,16,32,64,20,256,277,336,2048,80,89,65,260,65536,65895,65557,272,261,80,265,65895,65537,4,65911,303,65847,65,67603,84,81,257,65831,16,341]

theorem envBound34742 : H12AffineFastState.Bounded env34742 := by
  intro p hp
  have h : env34742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34741_34742 : H12AffineEnvironment.transform 6 20 env34741 = env34742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 20 env34741 == env34742) = true)

theorem identity34742 : scanCanonicalize (H12AffineFastState.compose env34742 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound34742 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env34743 : List Nat := [2,4,8,16,32,64,20,5,16,85,2048,80,89,65,1,65536,65634,65557,21,0,80,12,65634,65537,4,65650,42,65586,65,67603,84,81,4,65570,16,80]

theorem envBound34743 : H12AffineFastState.Bounded env34743 := by
  intro p hp
  have h : env34743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34742_34743 : H12AffineEnvironment.transform 7 5 env34742 = env34743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env34742 == env34743) = true)

theorem identity34743 : scanCanonicalize (H12AffineFastState.compose env34743 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound34743 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env34744 : List Nat := [2,4,8,16,32,64,20,5,16,85,2048,80,89,65,1,34,64,55,21,0,80,12,64,35,4,80,42,16,65,2097,84,81,4,0,16,80]

theorem envBound34744 : H12AffineFastState.Bounded env34744 := by
  intro p hp
  have h : env34744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34743_34744 : H12AffineEnvironment.transform 15 34 env34743 = env34744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env34743 == env34744) = true)

theorem identity34744 : scanCanonicalize (H12AffineFastState.compose env34744 (packedSelected [1,3,5,12] rootPS)) = affineNative (2^(5+1) ^^^ 45) := by decide +kernel

theorem selectedBound34744 : packedSelected [1,3,5,12] rootPS < 2^1333 := by decide +kernel

def env34745 : List Nat := [2,4,8,16,32,45,20,5,16,56,2048,61,52,44,1,34,45,55,21,0,61,12,45,35,4,61,42,16,44,2097,57,60,4,0,16,61]

theorem envBound34745 : H12AffineFastState.Bounded env34745 := by
  intro p hp
  have h : env34745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34744_34745 : H12AffineEnvironment.transform 5 45 env34744 = env34745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 45 env34744 == env34745) = true)

def env34746 : List Nat := [2,4,8,16,32,64,21,256,276,336,2048,81,88,65,261,65536,65894,65556,273,260,81,265,65894,65537,5,65911,303,65846,65,67603,85,80,257,65830,16,341]

theorem envBound34746 : H12AffineFastState.Bounded env34746 := by
  intro p hp
  have h : env34746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34741_34746 : H12AffineEnvironment.transform 6 21 env34741 = env34746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 21 env34741 == env34746) = true)

theorem identity34746 : scanCanonicalize (H12AffineFastState.compose env34746 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound34746 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env34747 : List Nat := [2,4,8,16,32,64,21,68,80,20,2048,81,88,65,65,65536,65570,65556,85,64,81,77,65570,65537,5,65587,107,65650,65,67603,85,80,69,65634,16,17]

theorem envBound34747 : H12AffineFastState.Bounded env34747 := by
  intro p hp
  have h : env34747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34746_34747 : H12AffineEnvironment.transform 7 68 env34746 = env34747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env34746 == env34747) = true)

theorem identity34747 : scanCanonicalize (H12AffineFastState.compose env34747 (packedSelected [0,5,7,10,11,15,18,20] rootPS)) = affineNative (2^(5+1) ^^^ 22) := by decide +kernel

theorem selectedBound34747 : packedSelected [0,5,7,10,11,15,18,20] rootPS < 2^1333 := by decide +kernel

def env34748 : List Nat := [2,4,8,16,32,22,21,18,6,20,2048,7,14,23,23,65536,65570,65556,3,22,7,27,65570,65537,5,65587,61,65572,23,67603,3,6,19,65588,16,17]

theorem envBound34748 : H12AffineFastState.Bounded env34748 := by
  intro p hp
  have h : env34748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34747_34748 : H12AffineEnvironment.transform 5 22 env34747 = env34748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 22 env34747 == env34748) = true)

def env34749 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,836,844,64,529,65536,66163,65665,516,528,836,648,66162,65536,144,65911,302,66083,64,67603,833,836,257,66099,17,341]

theorem envBound34749 : H12AffineFastState.Bounded env34749 := by
  intro p hp
  have h : env34749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34739_34749 : H12AffineEnvironment.transform 9 337 env34739 = env34749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env34739 == env34749) = true)

theorem identity34749 : scanCanonicalize (H12AffineFastState.compose env34749 (packedSelected [1,8,28] rootPS)) = affineNative (2^(6+1) ^^^ 21) := by decide +kernel

theorem selectedBound34749 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env34750 : List Nat := [2,4,8,16,32,64,21,256,512,337,2048,836,844,64,529,65536,66163,65556,516,528,836,541,66162,65536,5,65911,302,66083,64,67603,833,836,257,66099,17,341]

theorem envBound34750 : H12AffineFastState.Bounded env34750 := by
  intro p hp
  have h : env34750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34749_34750 : H12AffineEnvironment.transform 6 21 env34749 = env34750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 21 env34749 == env34750) = true)

def env34751 : List Nat := [2,4,8,16,32,64,21,256,276,337,2048,80,88,64,261,65536,65895,65556,272,260,80,265,65894,65536,5,65911,302,65847,64,67603,85,80,257,65831,17,341]

theorem envBound34751 : H12AffineFastState.Bounded env34751 := by
  intro p hp
  have h : env34751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34750_34751 : H12AffineEnvironment.transform 8 276 env34750 = env34751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env34750 == env34751) = true)

theorem identity34751 : scanCanonicalize (H12AffineFastState.compose env34751 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound34751 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env34752 : List Nat := [2,4,8,16,32,64,21,4,16,85,2048,80,88,64,1,65536,65635,65556,20,0,80,13,65634,65536,5,65651,42,65587,64,67603,85,80,5,65571,17,81]

theorem envBound34752 : H12AffineFastState.Bounded env34752 := by
  intro p hp
  have h : env34752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34751_34752 : H12AffineEnvironment.transform 7 4 env34751 = env34752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env34751 == env34752) = true)

theorem identity34752 : scanCanonicalize (H12AffineFastState.compose env34752 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound34752 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env34753 : List Nat := [2,4,8,16,32,64,21,4,16,85,2048,80,88,64,1,34,65,54,20,0,80,13,64,34,5,81,42,17,64,2097,85,80,5,1,17,81]

theorem envBound34753 : H12AffineFastState.Bounded env34753 := by
  intro p hp
  have h : env34753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34752_34753 : H12AffineEnvironment.transform 15 34 env34752 = env34753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env34752 == env34753) = true)

theorem identity34753 : scanCanonicalize (H12AffineFastState.compose env34753 (packedSelected [1,3,5,12] rootPS)) = affineNative (2^(5+1) ^^^ 44) := by decide +kernel

theorem selectedBound34753 : packedSelected [1,3,5,12] rootPS < 2^1333 := by decide +kernel

def env34754 : List Nat := [2,4,8,16,32,44,21,4,16,57,2048,60,52,44,1,34,45,54,20,0,60,13,44,34,5,61,42,17,44,2097,57,60,5,1,17,61]

theorem envBound34754 : H12AffineFastState.Bounded env34754 := by
  intro p hp
  have h : env34754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34753_34754 : H12AffineEnvironment.transform 5 44 env34753 = env34754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 44 env34753 == env34754) = true)

theorem identity34754 : scanCanonicalize (H12AffineFastState.compose env34754 (packedSelected [1,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound34754 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env34755 : List Nat := [2,4,8,16,13,1,21,4,16,20,2048,17,25,1,1,15,0,27,20,0,17,13,1,15,5,16,7,17,1,2076,20,17,5,1,17,16]

theorem envBound34755 : H12AffineFastState.Bounded env34755 := by
  intro p hp
  have h : env34755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34754_34755 : H12AffineEnvironment.transform 4 13 env34754 = env34755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env34754 == env34755) = true)

theorem identity34755 : scanCanonicalize (H12AffineFastState.compose env34755 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound34755 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34756 : List Nat := [2,4,8,10,13,1,15,4,10,14,2048,11,3,1,1,15,0,1,14,0,11,13,1,15,5,10,7,11,1,2054,14,11,5,1,11,10]

theorem envBound34756 : H12AffineFastState.Bounded env34756 := by
  intro p hp
  have h : env34756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34755_34756 : H12AffineEnvironment.transform 3 10 env34755 = env34756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env34755 == env34756) = true)

theorem identity34756 : scanCanonicalize (H12AffineFastState.compose env34756 (packedSelected [2,4] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound34756 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env34757 : List Nat := [2,4,5,7,0,1,2,4,7,3,2048,6,3,1,1,2,0,1,3,0,6,0,1,2,5,7,7,6,1,2054,3,6,5,1,6,7]

theorem envBound34757 : H12AffineFastState.Bounded env34757 := by
  intro p hp
  have h : env34757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34756_34757 : H12AffineEnvironment.transform 2 5 env34756 = env34757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env34756 == env34757) = true)

theorem identity34757 : scanCanonicalize (H12AffineFastState.compose env34757 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 7) := by decide +kernel

theorem selectedBound34757 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34758 : List Nat := [2,4,5,7,0,1,2,4,7,3,7,6,3,1,1,2,0,1,3,0,6,0,1,2,5,7,7,6,1,1,3,6,5,1,6,7]

theorem envBound34758 : H12AffineFastState.Bounded env34758 := by
  intro p hp
  have h : env34758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34757_34758 : H12AffineEnvironment.transform 10 7 env34757 = env34758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 7 env34757 == env34758) = true)

theorem identity34758 : scanCanonicalize (H12AffineFastState.compose env34758 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound34758 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34759 : List Nat := [2,3,2,0,0,1,2,3,0,3,0,1,3,1,1,2,0,1,3,0,1,0,1,2,2,0,0,1,1,1,3,1,2,1,1,0]

theorem envBound34759 : H12AffineFastState.Bounded env34759 := by
  intro p hp
  have h : env34759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34758_34759 : H12AffineEnvironment.transform 1 3 env34758 = env34759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env34758 == env34759) = true)

def env34760 : List Nat := [2,4,8,16,32,64,21,256,277,337,2048,81,89,64,260,65536,65894,65556,273,261,81,264,65895,65536,5,65911,302,65846,64,67603,84,81,257,65830,17,341]

theorem envBound34760 : H12AffineFastState.Bounded env34760 := by
  intro p hp
  have h : env34760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34750_34760 : H12AffineEnvironment.transform 8 277 env34750 = env34760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env34750 == env34760) = true)

theorem identity34760 : scanCanonicalize (H12AffineFastState.compose env34760 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound34760 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env34761 : List Nat := [2,4,8,16,32,64,21,68,81,21,2048,81,89,64,64,65536,65570,65556,85,65,81,76,65571,65536,5,65587,106,65650,64,67603,84,81,69,65634,17,17]

theorem envBound34761 : H12AffineFastState.Bounded env34761 := by
  intro p hp
  have h : env34761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34760_34761 : H12AffineEnvironment.transform 7 68 env34760 = env34761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env34760 == env34761) = true)

theorem identity34761 : scanCanonicalize (H12AffineFastState.compose env34761 (packedSelected [0,5,7,10,11,15,18,20] rootPS)) = affineNative (2^(15+1) ^^^ 101) := by decide +kernel

theorem selectedBound34761 : packedSelected [0,5,7,10,11,15,18,20] rootPS < 2^1333 := by decide +kernel

def env34762 : List Nat := [2,4,8,16,32,64,21,68,81,21,2048,81,89,64,64,101,71,113,85,65,81,76,70,101,5,86,106,23,64,2166,84,81,69,7,17,17]

theorem envBound34762 : H12AffineFastState.Bounded env34762 := by
  intro p hp
  have h : env34762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34761_34762 : H12AffineEnvironment.transform 15 101 env34761 = env34762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 101 env34761 == env34762) = true)

theorem identity34762 : scanCanonicalize (H12AffineFastState.compose env34762 (packedSelected [0,2,4,5,7,8,9,10,11,13,15,16] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound34762 : packedSelected [0,2,4,5,7,8,9,10,11,13,15,16] rootPS < 2^1333 := by decide +kernel

def env34763 : List Nat := [2,4,8,12,32,64,9,68,77,9,2048,77,69,64,64,101,71,109,73,65,77,76,70,101,5,74,106,11,64,2154,72,77,69,7,13,13]

theorem envBound34763 : H12AffineFastState.Bounded env34763 := by
  intro p hp
  have h : env34763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34762_34763 : H12AffineEnvironment.transform 3 12 env34762 = env34763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env34762 == env34763) = true)

theorem identity34763 : scanCanonicalize (H12AffineFastState.compose env34763 (packedSelected [3,5,10] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound34763 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env34764 : List Nat := [2,4,3,7,32,64,2,68,70,2,2048,70,69,64,64,101,71,102,66,65,70,71,70,101,5,65,97,0,64,2145,67,70,69,7,6,6]

theorem envBound34764 : H12AffineFastState.Bounded env34764 := by
  intro p hp
  have h : env34764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34763_34764 : H12AffineEnvironment.transform 2 3 env34763 = env34764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env34763 == env34764) = true)

theorem identity34764 : scanCanonicalize (H12AffineFastState.compose env34764 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 39) := by decide +kernel

theorem selectedBound34764 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env34765 : List Nat := [2,4,3,7,32,64,2,68,70,2,39,70,69,64,64,101,71,102,66,65,70,71,70,101,5,65,97,0,64,70,67,70,69,7,6,6]

theorem envBound34765 : H12AffineFastState.Bounded env34765 := by
  intro p hp
  have h : env34765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34764_34765 : H12AffineEnvironment.transform 10 39 env34764 = env34765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 39 env34764 == env34765) = true)

theorem identity34765 : scanCanonicalize (H12AffineFastState.compose env34765 (packedSelected [5] rootPS)) = affineNative (2^(5+1) ^^^ 6) := by decide +kernel

theorem selectedBound34765 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env34766 : List Nat := [2,4,3,7,32,6,2,2,0,2,39,0,3,6,6,35,1,32,4,7,0,1,0,35,5,7,39,0,6,0,5,0,3,7,6,6]

theorem envBound34766 : H12AffineFastState.Bounded env34766 := by
  intro p hp
  have h : env34766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34765_34766 : H12AffineEnvironment.transform 5 6 env34765 = env34766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 6 env34765 == env34766) = true)

theorem identity34766 : scanCanonicalize (H12AffineFastState.compose env34766 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound34766 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34767 : List Nat := [2,4,3,7,6,6,2,2,0,2,1,0,3,6,6,5,1,6,4,7,0,1,0,5,5,7,1,0,6,0,5,0,3,7,6,6]

theorem envBound34767 : H12AffineFastState.Bounded env34767 := by
  intro p hp
  have h : env34767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34766_34767 : H12AffineEnvironment.transform 4 6 env34766 = env34767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env34766 == env34767) = true)

theorem identity34767 : scanCanonicalize (H12AffineFastState.compose env34767 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound34767 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34768 : List Nat := [2,3,3,0,1,1,2,2,0,2,1,0,3,1,1,2,1,1,3,0,0,1,0,2,2,0,1,0,1,0,2,0,3,0,1,1]

theorem envBound34768 : H12AffineFastState.Bounded env34768 := by
  intro p hp
  have h : env34768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34767_34768 : H12AffineEnvironment.transform 1 3 env34767 = env34768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env34767 == env34768) = true)

theorem identity34768 : scanCanonicalize (H12AffineFastState.compose env34768 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound34768 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34769 : List Nat := [0,1,1,0,1,1,0,0,0,0,1,0,1,1,1,0,1,1,1,0,0,1,0,0,0,0,1,0,1,0,0,0,1,0,1,1]

theorem envBound34769 : H12AffineFastState.Bounded env34769 := by
  intro p hp
  have h : env34769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34768_34769 : H12AffineEnvironment.transform 0 0 env34768 = env34769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env34768 == env34769) = true)

def env34770 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,16777216,33554432,672785,134217728,148801,33584585,96346,50962568,4294967296,34088328,4345352435,151462017,33563273]

theorem envBound34770 : H12AffineFastState.Bounded env34770 := by
  intro p hp
  have h : env34770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33572_34770 : H12AffineEnvironment.transform 20 4097 env33572 = env34770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env33572 == env34770) = true)

theorem identity34770 : scanCanonicalize (H12AffineFastState.compose env34770 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 134709482) := by decide +kernel

theorem selectedBound34770 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env34771 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,16777216,33554432,672785,134217728,148801,33584585,96346,50962568,134709482,34088328,185028633,151462017,33563273]

theorem envBound34771 : H12AffineFastState.Bounded env34771 := by
  intro p hp
  have h : env34771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34770_34771 : H12AffineEnvironment.transform 31 134709482 env34770 = env34771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 134709482 env34770 == env34771) = true)

def env34772 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,16777216,533640,672785,134217728,148801,545089,96346,16876544,134709482,256,152007825,151462017,525825]

theorem envBound34772 : H12AffineFastState.Bounded env34772 := by
  intro p hp
  have h : env34772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34771_34772 : H12AffineEnvironment.transform 24 533640 env34771 = env34772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533640 env34771 == env34772) = true)

def env34773 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,16777216,533640,672785,17245632,148801,545089,96346,16876544,16819498,256,545105,1345,525825]

theorem envBound34773 : H12AffineFastState.Bounded env34773 := by
  intro p hp
  have h : env34773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34772_34773 : H12AffineEnvironment.transform 26 17245632 env34772 = env34773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env34772 == env34773) = true)

theorem identity34773 : scanCanonicalize (H12AffineFastState.compose env34773 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 717114) := by decide +kernel

theorem selectedBound34773 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env34774 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,717114,533640,672785,906490,148801,545089,96346,750906,676880,256,545105,1345,525825]

theorem envBound34774 : H12AffineFastState.Bounded env34774 := by
  intro p hp
  have h : env34774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34773_34774 : H12AffineEnvironment.transform 23 717114 env34773 = env34774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 717114 env34773 == env34774) = true)

def env34775 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147521,58682,143496,20497,508154,148801,148801,96346,90426,16400,256,148817,1345,135681]

theorem envBound34775 : H12AffineFastState.Bounded env34775 := by
  intro p hp
  have h : env34775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34774_34775 : H12AffineEnvironment.transform 18 136192 env34774 = env34775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env34774 == env34775) = true)

def env34776 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147521,58518,143496,20497,508154,148717,148717,96346,90262,16400,172,148733,1261,135681]

theorem envBound34776 : H12AffineFastState.Bounded env34776 := by
  intro p hp
  have h : env34776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34775_34776 : H12AffineEnvironment.transform 7 172 env34775 = env34776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env34775 == env34776) = true)

def env34777 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61568,147473,58518,143496,20497,508074,148669,148669,96266,90262,16400,172,148653,1213,135681]

theorem envBound34777 : H12AffineFastState.Bounded env34777 := by
  intro p hp
  have h : env34777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34776_34777 : H12AffineEnvironment.transform 5 16 env34776 = env34777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34776 == env34777) = true)

theorem identity34777 : scanCanonicalize (H12AffineFastState.compose env34777 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 137352) := by decide +kernel

theorem selectedBound34777 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env34778 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137352,136192,32769,4097,61568,147473,58518,143496,20497,120866,148669,148669,96266,90262,16400,172,148653,1213,135681]

theorem envBound34778 : H12AffineFastState.Bounded env34778 := by
  intro p hp
  have h : env34778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34777_34778 : H12AffineEnvironment.transform 17 137352 env34777 = env34778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137352 env34777 == env34778) = true)

theorem identity34778 : scanCanonicalize (H12AffineFastState.compose env34778 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(16+1) ^^^ 62492) := by decide +kernel

theorem selectedBound34778 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env34779 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,62492,60564,57372,32769,4097,61568,46093,58518,50324,20497,120866,45217,45217,96266,90262,16400,172,45233,1213,58909]

theorem envBound34779 : H12AffineFastState.Bounded env34779 := by
  intro p hp
  have h : env34779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34778_34779 : H12AffineEnvironment.transform 16 62492 env34778 = env34779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 62492 env34778 == env34779) = true)

theorem identity34779 : scanCanonicalize (H12AffineFastState.compose env34779 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 49307) := by decide +kernel

theorem selectedBound34779 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env34780 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,49307,62492,60564,57372,32769,4097,61568,46093,58518,50324,20497,6329,45217,45217,47249,40973,16400,172,45233,1213,58909]

theorem envBound34780 : H12AffineFastState.Bounded env34780 := by
  intro p hp
  have h : env34780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34779_34780 : H12AffineEnvironment.transform 15 49307 env34779 = env34780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 49307 env34779 == env34780) = true)

theorem identity34780 : scanCanonicalize (H12AffineFastState.compose env34780 (packedSelected [0,2,3,5,6,7,10,13,17,20,21] rootPS)) = affineNative (2^(13+1) ^^^ 14888) := by decide +kernel

theorem selectedBound34780 : packedSelected [0,2,3,5,6,7,10,13,17,20,21] rootPS < 2^1333 := by decide +kernel

def env34781 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,14888,32768,47795,36404,38588,39476,32769,4097,35496,46093,40638,48828,10809,6329,45217,45217,47249,40973,14904,172,45233,1213,39989]

theorem envBound34781 : H12AffineFastState.Bounded env34781 := by
  intro p hp
  have h : env34781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34780_34781 : H12AffineEnvironment.transform 13 14888 env34780 = env34781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 14888 env34780 == env34781) = true)

theorem identity34781 : scanCanonicalize (H12AffineFastState.compose env34781 (packedSelected [0,2,3,5,6,7,10,13,18,19,20,23,26] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound34781 : packedSelected [0,2,3,5,6,7,10,13,18,19,20,23,26] rootPS < 2^1333 := by decide +kernel

def env34782 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,184,8192,10896,32768,43531,36404,34308,35468,32769,185,35496,42165,36358,44548,10809,2049,40985,40985,43049,40973,10880,172,40969,1213,35981]

theorem envBound34782 : H12AffineFastState.Bounded env34782 := by
  intro p hp
  have h : env34782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34781_34782 : H12AffineEnvironment.transform 11 184 env34781 = env34782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env34781 == env34782) = true)

theorem identity34782 : scanCanonicalize (H12AffineFastState.compose env34782 (packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS)) = affineNative (2^(14+1) ^^^ 3725) := by decide +kernel

theorem selectedBound34782 : packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env34783 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,184,8192,10896,3725,9350,185,2185,1025,3724,185,1061,10808,139,8329,10809,2049,11924,11924,9892,11904,10880,172,11908,1213,512]

theorem envBound34783 : H12AffineFastState.Bounded env34783 := by
  intro p hp
  have h : env34783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34782_34783 : H12AffineEnvironment.transform 14 3725 env34782 = env34783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3725 env34782 == env34783) = true)

theorem identity34783 : scanCanonicalize (H12AffineFastState.compose env34783 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 141) := by decide +kernel

theorem selectedBound34783 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env34784 : List Nat := [2,4,8,16,32,16,128,172,512,141,2048,184,8192,10896,2560,8203,185,2185,140,2561,185,168,10808,139,8329,10809,2049,10777,10777,8745,10765,10880,172,10761,48,512]

theorem envBound34784 : H12AffineFastState.Bounded env34784 := by
  intro p hp
  have h : env34784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34783_34784 : H12AffineEnvironment.transform 9 141 env34783 = env34784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 141 env34783 == env34784) = true)

theorem identity34784 : scanCanonicalize (H12AffineFastState.compose env34784 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 2235) := by decide +kernel

theorem selectedBound34784 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env34785 : List Nat := [2,4,8,16,32,16,128,172,512,141,2048,184,2235,555,2560,2224,185,2185,140,2561,185,168,643,139,2098,642,2049,674,674,2706,694,571,172,690,48,512]

theorem envBound34785 : H12AffineFastState.Bounded env34785 := by
  intro p hp
  have h : env34785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34784_34785 : H12AffineEnvironment.transform 12 2235 env34784 = env34785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2235 env34784 == env34785) = true)

theorem identity34785 : scanCanonicalize (H12AffineFastState.compose env34785 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound34785 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env34786 : List Nat := [2,4,8,10,32,10,128,172,512,141,2048,162,2209,555,2560,2218,163,2185,140,2561,163,168,643,139,2088,642,2049,674,674,2696,684,545,172,680,42,512]

theorem envBound34786 : H12AffineFastState.Bounded env34786 := by
  intro p hp
  have h : env34786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34785_34786 : H12AffineEnvironment.transform 3 10 env34785 = env34786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env34785 == env34786) = true)

theorem identity34786 : scanCanonicalize (H12AffineFastState.compose env34786 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound34786 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env34787 : List Nat := [2,4,8,10,32,10,128,172,136,141,2048,162,2209,163,2184,2218,163,2185,140,2185,163,168,11,139,2088,10,2049,42,42,2048,36,169,172,32,42,136]

theorem envBound34787 : H12AffineFastState.Bounded env34787 := by
  intro p hp
  have h : env34787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34786_34787 : H12AffineEnvironment.transform 8 136 env34786 = env34787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env34786 == env34787) = true)

theorem identity34787 : scanCanonicalize (H12AffineFastState.compose env34787 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound34787 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env34788 : List Nat := [2,4,8,10,32,10,128,172,136,141,42,162,139,163,162,128,163,163,140,163,163,168,11,139,2,10,43,42,42,42,36,169,172,32,42,136]

theorem envBound34788 : H12AffineFastState.Bounded env34788 := by
  intro p hp
  have h : env34788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34787_34788 : H12AffineEnvironment.transform 10 42 env34787 = env34788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env34787 == env34788) = true)

theorem identity34788 : scanCanonicalize (H12AffineFastState.compose env34788 (packedSelected [0,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound34788 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env34789 : List Nat := [2,4,8,10,32,10,9,37,1,4,42,43,2,42,43,9,42,42,5,42,42,33,11,2,2,10,43,42,42,42,36,32,37,32,42,1]

theorem envBound34789 : H12AffineFastState.Bounded env34789 := by
  intro p hp
  have h : env34789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34788_34789 : H12AffineEnvironment.transform 6 9 env34788 = env34789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34788 == env34789) = true)

theorem identity34789 : scanCanonicalize (H12AffineFastState.compose env34789 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound34789 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34790 : List Nat := [2,4,8,10,13,10,9,8,1,4,7,6,2,7,6,9,7,7,5,7,7,12,11,2,2,10,6,7,7,7,9,13,8,13,7,1]

theorem envBound34790 : H12AffineFastState.Bounded env34790 := by
  intro p hp
  have h : env34790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34789_34790 : H12AffineEnvironment.transform 4 13 env34789 = env34790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env34789 == env34790) = true)

def env34791 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61569,147472,58518,143496,20497,508075,148668,148668,96267,90262,16400,172,148652,1212,135681]

theorem envBound34791 : H12AffineFastState.Bounded env34791 := by
  intro p hp
  have h : env34791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34776_34791 : H12AffineEnvironment.transform 5 17 env34776 = env34791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env34776 == env34791) = true)

theorem identity34791 : scanCanonicalize (H12AffineFastState.compose env34791 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound34791 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env34792 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,45216,262144,42144,32769,4097,61569,61616,58518,32808,20497,356363,62492,62492,96267,90262,16400,172,62476,1212,41633]

theorem envBound34792 : H12AffineFastState.Bounded env34792 := by
  intro p hp
  have h : env34792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34791_34792 : H12AffineEnvironment.transform 16 45216 env34791 = env34792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env34791 == env34792) = true)

theorem identity34792 : scanCanonicalize (H12AffineFastState.compose env34792 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound34792 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env34793 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,45216,2184,42144,32769,4097,61569,61616,58518,32808,20497,96387,62492,62492,96267,90262,16400,172,62476,1212,41633]

theorem envBound34793 : H12AffineFastState.Bounded env34793 := by
  intro p hp
  have h : env34793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34792_34793 : H12AffineEnvironment.transform 17 2184 env34792 = env34793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env34792 == env34793) = true)

theorem identity34793 : scanCanonicalize (H12AffineFastState.compose env34793 (packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound34793 : packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env34794 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,5124,32768,65536,45216,2184,42144,32769,4097,42117,42164,45202,32808,1045,76935,40984,40984,76815,78994,5140,172,40968,1212,41633]

theorem envBound34794 : H12AffineFastState.Bounded env34794 := by
  intro p hp
  have h : env34794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart2