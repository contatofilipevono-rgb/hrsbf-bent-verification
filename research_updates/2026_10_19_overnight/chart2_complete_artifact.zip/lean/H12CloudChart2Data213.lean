import H12CloudChart2Data212

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound53659 : H12AffineFastState.Bounded env53659 := by
  intro p hp
  have h : env53659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53658_53659 : H12AffineEnvironment.transform 17 137353 env53658 = env53659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137353 env53658 == env53659) = true)

theorem identity53659 : scanCanonicalize (H12AffineFastState.compose env53659 (packedSelected [1,5,8,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 13375) := by decide +kernel

theorem selectedBound53659 : packedSelected [1,5,8,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env53660 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,13375,131072,137353,136192,32769,4096,61569,147473,41002,143497,20496,43168,148668,148669,19508,4117,136364,172,21677,1213,135680]

theorem envBound53660 : H12AffineFastState.Bounded env53660 := by
  intro p hp
  have h : env53660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53659_53660 : H12AffineEnvironment.transform 15 13375 env53659 = env53660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13375 env53659 == env53660) = true)

theorem identity53660 : scanCanonicalize (H12AffineFastState.compose env53660 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound53660 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env53661 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1213,32768,13375,131072,137353,136192,32769,4096,46140,132268,41002,143497,5293,43168,131073,131072,2185,4117,136364,172,4112,1213,135680]

theorem envBound53661 : H12AffineFastState.Bounded env53661 := by
  intro p hp
  have h : env53661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53660_53661 : H12AffineEnvironment.transform 13 1213 env53660 = env53661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env53660 == env53661) = true)

theorem identity53661 : scanCanonicalize (H12AffineFastState.compose env53661 (packedSelected [13,17] rootPS)) = affineNative (2^(14+1) ^^^ 9381) := by decide +kernel

theorem selectedBound53661 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env53662 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1213,9381,13375,131072,137353,136192,9380,4096,4249,132268,1167,143497,5293,3077,131073,131072,2185,4117,136364,172,4112,1213,135680]

theorem envBound53662 : H12AffineFastState.Bounded env53662 := by
  intro p hp
  have h : env53662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53661_53662 : H12AffineEnvironment.transform 14 9381 env53661 = env53662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9381 env53661 == env53662) = true)

theorem identity53662 : scanCanonicalize (H12AffineFastState.compose env53662 (packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS)) = affineNative (2^(16+1) ^^^ 3102) := by decide +kernel

theorem selectedBound53662 : packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env53663 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1213,9381,13375,3102,5271,6174,9380,4096,4249,2226,1167,15511,5293,3077,3103,3102,2185,4117,6322,172,4112,1213,7710]

theorem envBound53663 : H12AffineFastState.Bounded env53663 := by
  intro p hp
  have h : env53663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53662_53663 : H12AffineEnvironment.transform 16 3102 env53662 = env53663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 3102 env53662 == env53663) = true)

theorem identity53663 : scanCanonicalize (H12AffineFastState.compose env53663 (packedSelected [1,4,5,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound53663 : packedSelected [1,4,5,9,16] rootPS < 2^1333 := by decide +kernel

def env53664 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,1053,1213,184,4130,3102,5271,6174,185,4096,4249,2226,1167,6282,5293,3077,3103,3102,2185,4117,6322,172,4112,1213,7710]

theorem envBound53664 : H12AffineFastState.Bounded env53664 := by
  intro p hp
  have h : env53664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53663_53664 : H12AffineEnvironment.transform 12 1053 env53663 = env53664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env53663 == env53664) = true)

theorem identity53664 : scanCanonicalize (H12AffineFastState.compose env53664 (packedSelected [0,2,3,4,5,6,10,13] rootPS)) = affineNative (2^(9+1) ^^^ 140) := by decide +kernel

theorem selectedBound53664 : packedSelected [0,2,3,4,5,6,10,13] rootPS < 2^1333 := by decide +kernel

def env53665 : List Nat := [2,4,8,16,32,16,128,173,512,140,2048,4096,145,49,184,4130,2194,4123,6174,185,4096,4249,2226,3,6282,4129,2185,2195,2194,2185,4117,6322,172,4112,49,6802]

theorem envBound53665 : H12AffineFastState.Bounded env53665 := by
  intro p hp
  have h : env53665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53664_53665 : H12AffineEnvironment.transform 9 140 env53664 = env53665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 140 env53664 == env53665) = true)

theorem identity53665 : scanCanonicalize (H12AffineFastState.compose env53665 (packedSelected [7,9] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound53665 : packedSelected [7,9] rootPS < 2^1333 := by decide +kernel

def env53666 : List Nat := [2,4,8,16,32,16,128,173,27,140,2048,4096,145,49,184,4130,2194,4123,6174,185,4096,4249,2226,3,6282,4129,2185,2195,2194,2185,4117,6322,172,4112,49,6281]

theorem envBound53666 : H12AffineFastState.Bounded env53666 := by
  intro p hp
  have h : env53666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53665_53666 : H12AffineEnvironment.transform 8 27 env53665 = env53666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env53665 == env53666) = true)

theorem identity53666 : scanCanonicalize (H12AffineFastState.compose env53666 (packedSelected [0,3,4,5,6,10] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound53666 : packedSelected [0,3,4,5,6,10] rootPS < 2^1333 := by decide +kernel

def env53667 : List Nat := [2,4,8,16,32,16,128,173,27,140,43,4096,145,49,184,4130,185,4123,4149,185,4096,4249,153,3,4257,4129,162,184,185,162,4117,4249,172,4112,49,4258]

theorem envBound53667 : H12AffineFastState.Bounded env53667 := by
  intro p hp
  have h : env53667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53666_53667 : H12AffineEnvironment.transform 10 43 env53666 = env53667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env53666 == env53667) = true)

theorem identity53667 : scanCanonicalize (H12AffineFastState.compose env53667 (packedSelected [0,3,7] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound53667 : packedSelected [0,3,7] rootPS < 2^1333 := by decide +kernel

def env53668 : List Nat := [2,4,8,16,12,16,128,129,27,140,7,4096,145,29,148,4110,149,4123,4121,149,4096,4249,153,3,4237,4109,142,148,149,142,4117,4249,128,4112,29,4238]

theorem envBound53668 : H12AffineFastState.Bounded env53668 := by
  intro p hp
  have h : env53668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53667_53668 : H12AffineEnvironment.transform 4 12 env53667 = env53668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env53667 == env53668) = true)

theorem identity53668 : scanCanonicalize (H12AffineFastState.compose env53668 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(11+1) ^^^ 148) := by decide +kernel

theorem selectedBound53668 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env53669 : List Nat := [2,4,8,16,12,16,128,129,27,140,7,148,145,29,148,154,149,143,141,149,148,13,153,3,25,153,142,148,149,142,129,13,128,132,29,26]

theorem envBound53669 : H12AffineFastState.Bounded env53669 := by
  intro p hp
  have h : env53669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53668_53669 : H12AffineEnvironment.transform 11 148 env53668 = env53669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 148 env53668 == env53669) = true)

theorem identity53669 : scanCanonicalize (H12AffineFastState.compose env53669 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 23) := by decide +kernel

theorem selectedBound53669 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53670 : List Nat := [2,4,8,16,12,16,23,22,27,27,7,3,6,29,3,13,2,24,26,2,3,13,14,3,25,14,25,3,2,25,22,13,23,19,29,26]

theorem envBound53670 : H12AffineFastState.Bounded env53670 := by
  intro p hp
  have h : env53670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53669_53670 : H12AffineEnvironment.transform 6 23 env53669 = env53670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 23 env53669 == env53670) = true)

theorem identity53670 : scanCanonicalize (H12AffineFastState.compose env53670 (packedSelected [1,2,3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound53670 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env53671 : List Nat := [1,4,8,16,12,16,20,21,24,24,4,0,5,29,0,13,1,24,25,1,0,13,13,0,25,13,25,0,1,25,21,13,20,16,29,25]

theorem envBound53671 : H12AffineFastState.Bounded env53671 := by
  intro p hp
  have h : env53671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53670_53671 : H12AffineEnvironment.transform 0 1 env53670 = env53671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env53670 == env53671) = true)

theorem identity53671 : scanCanonicalize (H12AffineFastState.compose env53671 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound53671 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53672 : List Nat := [1,4,8,8,12,8,12,13,0,0,4,0,5,5,0,13,1,0,1,1,0,13,13,0,1,13,1,0,1,1,13,13,12,8,5,1]

theorem envBound53672 : H12AffineFastState.Bounded env53672 := by
  intro p hp
  have h : env53672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53671_53672 : H12AffineEnvironment.transform 3 8 env53671 = env53672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env53671 == env53672) = true)

theorem identity53672 : scanCanonicalize (H12AffineFastState.compose env53672 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound53672 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53673 : List Nat := [1,4,4,4,0,4,0,1,0,0,4,0,5,5,0,1,1,0,1,1,0,1,1,0,1,1,1,0,1,1,1,1,0,4,5,1]

theorem envBound53673 : H12AffineFastState.Bounded env53673 := by
  intro p hp
  have h : env53673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53672_53673 : H12AffineEnvironment.transform 2 4 env53672 = env53673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env53672 == env53673) = true)

def env53674 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147472,41002,143497,20496,492567,148669,148668,96266,74794,204946,172,90258,1212,135680]

theorem envBound53674 : H12AffineFastState.Bounded env53674 := by
  intro p hp
  have h : env53674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53657_53674 : H12AffineEnvironment.transform 5 17 env53657 = env53674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53657 == env53674) = true)

theorem identity53674 : scanCanonicalize (H12AffineFastState.compose env53674 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound53674 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env53675 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,45217,262144,42145,32769,4096,61568,61617,41002,32808,20496,341174,62492,62493,96266,74794,102451,172,90258,1212,41633]

theorem envBound53675 : H12AffineFastState.Bounded env53675 := by
  intro p hp
  have h : env53675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53674_53675 : H12AffineEnvironment.transform 16 45217 env53674 = env53675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env53674 == env53675) = true)

theorem identity53675 : scanCanonicalize (H12AffineFastState.compose env53675 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound53675 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env53676 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1213,32768,65536,45217,262144,42145,32769,4096,46141,46092,41002,32808,5293,341174,45217,45216,81079,74794,102451,172,74799,1212,41633]

theorem envBound53676 : H12AffineFastState.Bounded env53676 := by
  intro p hp
  have h : env53676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53675_53676 : H12AffineEnvironment.transform 13 1213 env53675 = env53676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env53675 == env53676) = true)

theorem identity53676 : scanCanonicalize (H12AffineFastState.compose env53676 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound53676 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env53677 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,185,8192,1213,32768,65536,40984,262144,42145,32769,185,42116,42165,41002,32808,1044,336911,40984,40985,76814,74794,98442,172,74799,1212,41633]

theorem envBound53677 : H12AffineFastState.Bounded env53677 := by
  intro p hp
  have h : env53677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53676_53677 : H12AffineEnvironment.transform 11 185 env53676 = env53677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env53676 == env53677) = true)

theorem identity53677 : scanCanonicalize (H12AffineFastState.compose env53677 (packedSelected [4,9,20] rootPS)) = affineNative (2^(15+1) ^^^ 33831) := by decide +kernel

theorem selectedBound53677 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env53678 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,185,8192,1213,32768,33831,40984,262144,42145,32769,185,42116,42165,41002,32808,1044,303144,40984,40985,43049,40973,1197,172,40968,1212,41633]

theorem envBound53678 : H12AffineFastState.Bounded env53678 := by
  intro p hp
  have h : env53678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53677_53678 : H12AffineEnvironment.transform 15 33831 env53677 = env53678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33831 env53677 == env53678) = true)

theorem identity53678 : scanCanonicalize (H12AffineFastState.compose env53678 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 8353) := by decide +kernel

theorem selectedBound53678 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env53679 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,185,8192,1213,8353,9350,185,262144,1024,8352,185,1061,1044,139,8329,1044,262281,185,184,2184,172,1197,172,169,1212,512]

theorem envBound53679 : H12AffineFastState.Bounded env53679 := by
  intro p hp
  have h : env53679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53678_53679 : H12AffineEnvironment.transform 14 8353 env53678 = env53679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8353 env53678 == env53679) = true)

theorem identity53679 : scanCanonicalize (H12AffineFastState.compose env53679 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2601) := by decide +kernel

theorem selectedBound53679 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53680 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,185,2601,1213,2696,3759,185,262144,1024,2697,185,1061,1044,139,2720,1044,262281,185,184,2184,172,1197,172,169,1212,512]

theorem envBound53680 : H12AffineFastState.Bounded env53680 := by
  intro p hp
  have h : env53680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53679_53680 : H12AffineEnvironment.transform 12 2601 env53679 = env53680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2601 env53679 == env53680) = true)

theorem identity53680 : scanCanonicalize (H12AffineFastState.compose env53680 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 2706) := by decide +kernel

theorem selectedBound53680 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env53681 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,185,2601,1213,2696,3759,185,2706,1024,2697,185,1061,1044,139,2720,1044,2587,185,184,2184,172,1197,172,169,1212,512]

theorem envBound53681 : H12AffineFastState.Bounded env53681 := by
  intro p hp
  have h : env53681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53680_53681 : H12AffineEnvironment.transform 17 2706 env53680 = env53681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2706 env53680 == env53681) = true)

theorem identity53681 : scanCanonicalize (H12AffineFastState.compose env53681 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1213) := by decide +kernel

theorem selectedBound53681 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env53682 : List Nat := [2,4,8,16,32,17,128,173,512,1024,1213,185,1684,1213,1589,530,185,1583,1024,1588,185,1061,1044,139,1565,1044,1702,185,184,1077,172,1197,172,169,1212,512]

theorem envBound53682 : H12AffineFastState.Bounded env53682 := by
  intro p hp
  have h : env53682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53681_53682 : H12AffineEnvironment.transform 10 1213 env53681 = env53682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1213 env53681 == env53682) = true)

theorem identity53682 : scanCanonicalize (H12AffineFastState.compose env53682 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound53682 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env53683 : List Nat := [2,4,8,10,32,11,128,173,512,1024,1191,163,1678,1191,1583,520,163,1583,1024,1582,163,1061,1038,139,1543,1038,1702,163,162,1071,172,1197,172,169,1190,512]

theorem envBound53683 : H12AffineFastState.Bounded env53683 := by
  intro p hp
  have h : env53683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53682_53683 : H12AffineEnvironment.transform 3 10 env53682 = env53683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env53682 == env53683) = true)

theorem identity53683 : scanCanonicalize (H12AffineFastState.compose env53683 (packedSelected [0,1,4,7] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound53683 : packedSelected [0,1,4,7] rootPS < 2^1333 := by decide +kernel

def env53684 : List Nat := [2,4,8,10,32,11,128,173,136,1024,1191,163,1030,1191,1191,128,163,1191,1024,1190,163,1061,1038,139,1167,1038,1070,163,162,1071,172,1197,172,169,1190,136]

theorem envBound53684 : H12AffineFastState.Bounded env53684 := by
  intro p hp
  have h : env53684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53683_53684 : H12AffineEnvironment.transform 8 136 env53683 = env53684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env53683 == env53684) = true)

theorem identity53684 : scanCanonicalize (H12AffineFastState.compose env53684 (packedSelected [1,4] rootPS)) = affineNative (2^(9+1) ^^^ 140) := by decide +kernel

theorem selectedBound53684 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env53685 : List Nat := [2,4,8,10,32,11,128,173,136,140,43,163,138,43,43,128,163,43,140,42,163,169,130,139,3,130,162,163,162,163,172,33,172,169,42,136]

theorem envBound53685 : H12AffineFastState.Bounded env53685 := by
  intro p hp
  have h : env53685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53684_53685 : H12AffineEnvironment.transform 9 140 env53684 = env53685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 140 env53684 == env53685) = true)

theorem identity53685 : scanCanonicalize (H12AffineFastState.compose env53685 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound53685 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53686 : List Nat := [2,4,8,10,32,11,4,41,12,8,43,39,14,43,43,4,39,43,8,42,39,45,6,15,3,6,38,39,38,39,40,33,40,45,42,12]

theorem envBound53686 : H12AffineFastState.Bounded env53686 := by
  intro p hp
  have h : env53686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53685_53686 : H12AffineEnvironment.transform 6 4 env53685 = env53686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env53685 == env53686) = true)

theorem identity53686 : scanCanonicalize (H12AffineFastState.compose env53686 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound53686 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env53687 : List Nat := [2,4,4,6,32,7,4,37,0,4,39,39,2,39,39,4,39,39,4,38,39,33,6,3,3,6,38,39,38,39,36,33,36,33,38,0]

theorem envBound53687 : H12AffineFastState.Bounded env53687 := by
  intro p hp
  have h : env53687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53686_53687 : H12AffineEnvironment.transform 2 4 env53686 = env53687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env53686 == env53687) = true)

def env53688 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147521,41002,143496,20497,493035,148801,148801,96347,74794,205166,257,90430,1344,135681]

theorem envBound53688 : H12AffineFastState.Bounded env53688 := by
  intro p hp
  have h : env53688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53626_53688 : H12AffineEnvironment.transform 18 136193 env53626 = env53688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env53626 == env53688) = true)

def env53689 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147521,41002,143496,20497,492615,148717,148717,96347,74794,204994,173,90258,1260,135681]

theorem envBound53689 : H12AffineFastState.Bounded env53689 := by
  intro p hp
  have h : env53689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53688_53689 : H12AffineEnvironment.transform 7 172 env53688 = env53689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env53688 == env53689) = true)

def env53690 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147473,41002,143496,20497,492567,148669,148669,96267,74794,204946,173,90258,1212,135681]

theorem envBound53690 : H12AffineFastState.Bounded env53690 := by
  intro p hp
  have h : env53690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53689_53690 : H12AffineEnvironment.transform 5 16 env53689 = env53690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env53689 == env53690) = true)

theorem identity53690 : scanCanonicalize (H12AffineFastState.compose env53690 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 114723) := by decide +kernel

theorem selectedBound53690 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env53691 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,114723,262144,119842,32769,4096,61569,98354,41002,127147,20497,279604,99486,99486,96267,74794,57521,173,90258,1212,119330]

theorem envBound53691 : H12AffineFastState.Bounded env53691 := by
  intro p hp
  have h : env53691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53690_53691 : H12AffineEnvironment.transform 16 114723 env53690 = env53691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114723 env53690 == env53691) = true)

theorem identity53691 : scanCanonicalize (H12AffineFastState.compose env53691 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 116755) := by decide +kernel

theorem selectedBound53691 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env53692 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,114723,116755,119842,32769,4096,61569,98354,41002,127147,20497,101415,99486,99486,96267,74794,57521,173,90258,1212,119330]

theorem envBound53692 : H12AffineFastState.Bounded env53692 := by
  intro p hp
  have h : env53692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53691_53692 : H12AffineEnvironment.transform 17 116755 env53691 = env53692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 116755 env53691 == env53692) = true)

theorem identity53692 : scanCanonicalize (H12AffineFastState.compose env53692 (packedSelected [7,16,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound53692 : packedSelected [7,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env53693 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,53282,4097,6193,1024,32769,4096,61569,20496,41002,8329,20497,23557,21692,21692,43049,62472,57521,173,45232,1212,512]

theorem envBound53693 : H12AffineFastState.Bounded env53693 := by
  intro p hp
  have h : env53693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53692_53693 : H12AffineEnvironment.transform 15 53282 env53692 = env53693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env53692 == env53693) = true)

theorem identity53693 : scanCanonicalize (H12AffineFastState.compose env53693 (packedSelected [4,9,16] rootPS)) = affineNative (2^(14+1) ^^^ 29860) := by decide +kernel

theorem selectedBound53693 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env53694 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,29860,9350,4097,6193,1024,29861,4096,1061,20496,21646,8329,20497,23557,21692,21692,23693,172,5141,173,17428,1212,512]

theorem envBound53694 : H12AffineFastState.Bounded env53694 := by
  intro p hp
  have h : env53694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53693_53694 : H12AffineEnvironment.transform 14 29860 env53693 = env53694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29860 env53693 == env53694) = true)

theorem identity53694 : scanCanonicalize (H12AffineFastState.compose env53694 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 5676) := by decide +kernel

theorem selectedBound53694 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env53695 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,5676,16384,17032,4778,4097,6193,1024,17033,4096,1061,20496,21646,5797,20497,23557,21692,21692,23693,172,5141,173,17428,1212,512]

theorem envBound53695 : H12AffineFastState.Bounded env53695 := by
  intro p hp
  have h : env53695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53694_53695 : H12AffineEnvironment.transform 12 5676 env53694 = env53695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5676 env53694 == env53695) = true)

theorem identity53695 : scanCanonicalize (H12AffineFastState.compose env53695 (packedSelected [0,3,4,8,13] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound53695 : packedSelected [0,3,4,8,13] rootPS < 2^1333 := by decide +kernel

def env53696 : List Nat := [2,4,8,16,32,16,128,172,26,1024,2048,4096,5174,16384,16530,4272,4097,6193,1024,16531,4096,1061,20496,21646,5311,20497,23557,21692,21692,23693,172,5141,173,17428,1212,26]

theorem envBound53696 : H12AffineFastState.Bounded env53696 := by
  intro p hp
  have h : env53696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53695_53696 : H12AffineEnvironment.transform 8 26 env53695 = env53696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env53695 == env53696) = true)

theorem identity53696 : scanCanonicalize (H12AffineFastState.compose env53696 (packedSelected [0,1,2,5,9,11,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 2048) := by decide +kernel

theorem selectedBound53696 : packedSelected [0,1,2,5,9,11,12,15] rootPS < 2^1333 := by decide +kernel

def env53697 : List Nat := [2,4,8,16,32,16,128,172,26,1024,2048,4096,5174,2048,2194,4272,4097,6193,1024,2195,4096,1061,6160,7310,5311,6161,5125,7356,7356,5261,172,5141,173,3092,1212,26]

theorem envBound53697 : H12AffineFastState.Bounded env53697 := by
  intro p hp
  have h : env53697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53696_53697 : H12AffineEnvironment.transform 13 2048 env53696 = env53697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2048 env53696 == env53697) = true)

theorem identity53697 : scanCanonicalize (H12AffineFastState.compose env53697 (packedSelected [1,3,5,7,8,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 1071) := by decide +kernel

theorem selectedBound53697 : packedSelected [1,3,5,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env53698 : List Nat := [2,4,8,16,32,16,128,172,26,1024,2048,1071,25,2048,2194,1183,1070,3102,1024,2195,1071,1061,3135,2209,144,3134,42,2195,2195,162,172,58,173,3092,1212,26]

theorem envBound53698 : H12AffineFastState.Bounded env53698 := by
  intro p hp
  have h : env53698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53697_53698 : H12AffineEnvironment.transform 11 1071 env53697 = env53698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1071 env53697 == env53698) = true)

theorem identity53698 : scanCanonicalize (H12AffineFastState.compose env53698 (packedSelected [1,4,6] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound53698 : packedSelected [1,4,6] rootPS < 2^1333 := by decide +kernel

def env53699 : List Nat := [2,4,8,16,32,16,128,172,26,1024,43,1071,25,43,185,1183,1070,1077,1024,184,1071,1061,1044,138,144,1045,42,184,184,162,172,58,173,1087,1212,26]

theorem envBound53699 : H12AffineFastState.Bounded env53699 := by
  intro p hp
  have h : env53699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53698_53699 : H12AffineEnvironment.transform 10 43 env53698 = env53699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env53698 == env53699) = true)

theorem identity53699 : scanCanonicalize (H12AffineFastState.compose env53699 (packedSelected [2,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 140) := by decide +kernel

theorem selectedBound53699 : packedSelected [2,3,4] rootPS < 2^1333 := by decide +kernel

def env53700 : List Nat := [2,4,8,16,32,16,128,172,26,140,43,163,25,43,185,19,162,185,140,184,163,169,152,138,144,153,42,184,184,162,172,58,173,179,48,26]

theorem envBound53700 : H12AffineFastState.Bounded env53700 := by
  intro p hp
  have h : env53700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53699_53700 : H12AffineEnvironment.transform 9 140 env53699 = env53700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 140 env53699 == env53700) = true)

theorem identity53700 : scanCanonicalize (H12AffineFastState.compose env53700 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound53700 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env53701 : List Nat := [2,4,8,16,10,16,128,134,26,140,1,137,25,1,147,19,136,147,140,146,137,131,152,138,144,153,0,146,146,136,134,16,135,153,26,26]

theorem envBound53701 : H12AffineFastState.Bounded env53701 := by
  intro p hp
  have h : env53701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53700_53701 : H12AffineEnvironment.transform 4 10 env53700 = env53701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env53700 == env53701) = true)

theorem identity53701 : scanCanonicalize (H12AffineFastState.compose env53701 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound53701 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env53702 : List Nat := [2,4,8,10,10,10,128,134,0,140,1,137,3,1,137,9,136,137,140,136,137,131,130,138,138,131,0,136,136,136,134,10,135,131,0,0]

theorem envBound53702 : H12AffineFastState.Bounded env53702 := by
  intro p hp
  have h : env53702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53701_53702 : H12AffineEnvironment.transform 3 10 env53701 = env53702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env53701 == env53702) = true)

theorem identity53702 : scanCanonicalize (H12AffineFastState.compose env53702 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound53702 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53703 : List Nat := [2,4,8,10,10,10,5,3,0,9,1,12,3,1,12,9,13,12,9,13,12,6,7,15,15,6,0,13,13,13,3,10,2,6,0,0]

theorem envBound53703 : H12AffineFastState.Bounded env53703 := by
  intro p hp
  have h : env53703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53702_53703 : H12AffineEnvironment.transform 6 5 env53702 = env53703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env53702 == env53703) = true)

theorem identity53703 : scanCanonicalize (H12AffineFastState.compose env53703 (packedSelected [9] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound53703 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env53704 : List Nat := [2,4,5,7,7,7,5,3,0,4,1,1,3,1,1,4,0,1,4,0,1,6,7,2,2,6,0,0,0,0,3,7,2,6,0,0]

theorem envBound53704 : H12AffineFastState.Bounded env53704 := by
  intro p hp
  have h : env53704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53703_53704 : H12AffineEnvironment.transform 2 5 env53703 = env53704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env53703 == env53704) = true)

def env53705 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147472,41002,143496,20497,492566,148668,148668,96266,74794,204947,173,90258,1213,135681]

theorem envBound53705 : H12AffineFastState.Bounded env53705 := by
  intro p hp
  have h : env53705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53689_53705 : H12AffineEnvironment.transform 5 17 env53689 = env53705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53689 == env53705) = true)

theorem identity53705 : scanCanonicalize (H12AffineFastState.compose env53705 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 223242) := by decide +kernel

theorem selectedBound53705 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env53706 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,223242,136193,32769,4096,61568,147472,41002,143496,20497,60444,148668,148668,96266,74794,204947,173,90258,1213,135681]

theorem envBound53706 : H12AffineFastState.Bounded env53706 := by
  intro p hp
  have h : env53706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53705_53706 : H12AffineEnvironment.transform 17 223242 env53705 = env53706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223242 env53705 == env53706) = true)

theorem identity53706 : scanCanonicalize (H12AffineFastState.compose env53706 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 28803) := by decide +kernel

theorem selectedBound53706 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env53707 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,28803,131072,137353,136193,32769,4096,61568,147472,41002,143496,20497,60444,148668,148668,2185,21673,151568,173,4113,1213,135681]

theorem envBound53707 : H12AffineFastState.Bounded env53707 := by
  intro p hp
  have h : env53707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53706_53707 : H12AffineEnvironment.transform 15 28803 env53706 = env53707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28803 env53706 == env53707) = true)

theorem identity53707 : scanCanonicalize (H12AffineFastState.compose env53707 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(16+1) ^^^ 40985) := by decide +kernel

theorem selectedBound53707 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env53708 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,28803,40985,47248,46104,32769,4096,61568,57353,41002,37009,20497,60444,58533,58533,2185,21673,61449,173,4113,1213,45592]

theorem envBound53708 : H12AffineFastState.Bounded env53708 := by
  intro p hp
  have h : env53708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53707_53708 : H12AffineEnvironment.transform 16 40985 env53707 = env53708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 40985 env53707 == env53708) = true)

theorem identity53708 : scanCanonicalize (H12AffineFastState.compose env53708 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound53708 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env53709 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1213,32768,13374,40985,47248,46104,32769,4096,46141,42164,41002,37009,5292,43169,40984,40984,2185,4116,46260,173,4113,1213,45592]

theorem envBound53709 : H12AffineFastState.Bounded env53709 := by
  intro p hp
  have h : env53709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53708_53709 : H12AffineEnvironment.transform 13 1213 env53708 = env53709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env53708 == env53709) = true)

theorem identity53709 : scanCanonicalize (H12AffineFastState.compose env53709 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(14+1) ^^^ 6186) := by decide +kernel

theorem selectedBound53709 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env53710 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1213,6186,13374,14387,8378,11314,6187,4096,11287,15518,14336,2235,5292,12427,14386,14386,2185,4116,11422,173,4113,1213,10802]

theorem envBound53710 : H12AffineFastState.Bounded env53710 := by
  intro p hp
  have h : env53710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53709_53710 : H12AffineEnvironment.transform 14 6186 env53709 = env53710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 6186 env53709 == env53710) = true)

theorem identity53710 : scanCanonicalize (H12AffineFastState.compose env53710 (packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 3127) := by decide +kernel

theorem selectedBound53710 : packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env53711 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,3127,1213,6186,6153,5124,3213,5,6187,4096,32,4265,5175,2235,5292,7356,5125,5125,2185,4116,169,173,4113,1213,1541]

theorem envBound53711 : H12AffineFastState.Bounded env53711 := by
  intro p hp
  have h : env53711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53710_53711 : H12AffineEnvironment.transform 12 3127 env53710 = env53711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3127 env53710 == env53711) = true)

theorem identity53711 : scanCanonicalize (H12AffineFastState.compose env53711 (packedSelected [1,2,3,6,10,11] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound53711 : packedSelected [1,2,3,6,10,11] rootPS < 2^1333 := by decide +kernel

def env53712 : List Nat := [2,4,8,16,32,17,128,172,1,1024,2048,4096,3127,1213,6186,6153,5124,3213,5,6187,4096,32,4265,5175,2235,5292,7356,5125,5125,2185,4116,169,173,4113,1213,1028]

theorem envBound53712 : H12AffineFastState.Bounded env53712 := by
  intro p hp
  have h : env53712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53711_53712 : H12AffineEnvironment.transform 8 1 env53711 = env53712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env53711 == env53712) = true)

theorem identity53712 : scanCanonicalize (H12AffineFastState.compose env53712 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 163) := by decide +kernel

theorem selectedBound53712 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env53713 : List Nat := [2,4,8,16,32,17,128,172,1,1024,163,4096,1172,1213,4233,4266,5124,1070,5,4232,4096,32,4265,5175,24,5292,5151,5125,5125,42,4116,169,173,4113,1213,1028]

theorem envBound53713 : H12AffineFastState.Bounded env53713 := by
  intro p hp
  have h : env53713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53712_53713 : H12AffineEnvironment.transform 10 163 env53712 = env53713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 163 env53712 == env53713) = true)

theorem identity53713 : scanCanonicalize (H12AffineFastState.compose env53713 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound53713 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env53714 : List Nat := [2,4,8,16,32,17,128,172,1,5,163,4096,145,184,4233,4266,4097,43,5,4232,4096,32,4265,4146,24,4265,4122,4096,4096,42,4116,169,173,4113,184,1]

theorem envBound53714 : H12AffineFastState.Bounded env53714 := by
  intro p hp
  have h : env53714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53713_53714 : H12AffineEnvironment.transform 9 5 env53713 = env53714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env53713 == env53714) = true)

theorem identity53714 : scanCanonicalize (H12AffineFastState.compose env53714 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 42) := by decide +kernel

theorem selectedBound53714 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env53715 : List Nat := [2,4,8,16,32,17,128,172,1,5,163,42,145,184,163,128,43,43,5,162,42,32,131,24,24,131,48,42,42,42,62,169,173,59,184,1]

theorem envBound53715 : H12AffineFastState.Bounded env53715 := by
  intro p hp
  have h : env53715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53714_53715 : H12AffineEnvironment.transform 11 42 env53714 = env53715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 42 env53714 == env53715) = true)

theorem identity53715 : scanCanonicalize (H12AffineFastState.compose env53715 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 29) := by decide +kernel

theorem selectedBound53715 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53716 : List Nat := [2,4,8,16,29,17,128,145,1,5,158,23,145,133,158,128,22,22,5,159,23,29,131,24,24,131,13,23,23,23,3,148,144,6,133,1]

theorem envBound53716 : H12AffineFastState.Bounded env53716 := by
  intro p hp
  have h : env53716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53715_53716 : H12AffineEnvironment.transform 4 29 env53715 = env53716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env53715 == env53716) = true)

theorem identity53716 : scanCanonicalize (H12AffineFastState.compose env53716 (packedSelected [1,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound53716 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env53717 : List Nat := [2,4,8,10,7,11,128,139,1,5,132,13,139,133,132,128,12,12,5,133,13,7,131,2,2,131,13,13,13,13,3,142,138,6,133,1]

theorem envBound53717 : H12AffineFastState.Bounded env53717 := by
  intro p hp
  have h : env53717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53716_53717 : H12AffineEnvironment.transform 3 10 env53716 = env53717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env53716 == env53717) = true)

theorem identity53717 : scanCanonicalize (H12AffineFastState.compose env53717 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound53717 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53718 : List Nat := [2,4,8,10,7,11,8,3,1,5,12,13,3,13,12,8,12,12,5,13,13,7,11,2,2,11,13,13,13,13,3,6,2,6,13,1]

theorem envBound53718 : H12AffineFastState.Bounded env53718 := by
  intro p hp
  have h : env53718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53717_53718 : H12AffineEnvironment.transform 6 8 env53717 = env53718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env53717 == env53718) = true)

theorem identity53718 : scanCanonicalize (H12AffineFastState.compose env53718 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound53718 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53719 : List Nat := [2,4,5,7,7,6,5,3,1,5,1,0,3,0,1,5,1,1,5,0,0,7,6,2,2,6,0,0,0,0,3,6,2,6,0,1]

theorem envBound53719 : H12AffineFastState.Bounded env53719 := by
  intro p hp
  have h : env53719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53718_53719 : H12AffineEnvironment.transform 2 5 env53718 = env53719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env53718 == env53719) = true)

def env53720 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147521,41002,143496,20497,492614,148716,148716,96347,74794,204995,172,90259,1261,135681]

theorem envBound53720 : H12AffineFastState.Bounded env53720 := by
  intro p hp
  have h : env53720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53688_53720 : H12AffineEnvironment.transform 7 173 env53688 = env53720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env53688 == env53720) = true)

def env53721 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147473,41002,143496,20497,492566,148668,148668,96267,74794,204947,172,90259,1213,135681]

theorem envBound53721 : H12AffineFastState.Bounded env53721 := by
  intro p hp
  have h : env53721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53720_53721 : H12AffineEnvironment.transform 5 16 env53720 = env53721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env53720 == env53721) = true)

theorem identity53721 : scanCanonicalize (H12AffineFastState.compose env53721 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound53721 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env53722 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,45216,262144,42145,32769,4096,61569,61617,41002,32808,20497,341174,62492,62492,96267,74794,102451,172,90259,1213,41633]

theorem envBound53722 : H12AffineFastState.Bounded env53722 := by
  intro p hp
  have h : env53722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53721_53722 : H12AffineEnvironment.transform 16 45216 env53721 = env53722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env53721 == env53722) = true)

theorem identity53722 : scanCanonicalize (H12AffineFastState.compose env53722 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound53722 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env53723 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1212,32768,65536,45216,262144,42145,32769,4096,46141,46093,41002,32808,5293,341174,45216,45216,81079,74794,102451,172,74799,1213,41633]

theorem envBound53723 : H12AffineFastState.Bounded env53723 := by
  intro p hp
  have h : env53723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53722_53723 : H12AffineEnvironment.transform 13 1212 env53722 = env53723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env53722 == env53723) = true)

theorem identity53723 : scanCanonicalize (H12AffineFastState.compose env53723 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound53723 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env53724 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,184,8192,1212,32768,65536,40984,262144,42145,32769,184,42117,42165,41002,32808,1045,336910,40984,40984,76815,74794,98443,172,74799,1213,41633]

theorem envBound53724 : H12AffineFastState.Bounded env53724 := by
  intro p hp
  have h : env53724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53723_53724 : H12AffineEnvironment.transform 11 184 env53723 = env53724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env53723 == env53724) = true)

theorem identity53724 : scanCanonicalize (H12AffineFastState.compose env53724 (packedSelected [4,9,20] rootPS)) = affineNative (2^(15+1) ^^^ 33830) := by decide +kernel

theorem selectedBound53724 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env53725 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,184,8192,1212,32768,33830,40984,262144,42145,32769,184,42117,42165,41002,32808,1045,303144,40984,40984,43049,40972,1197,172,40969,1213,41633]

theorem envBound53725 : H12AffineFastState.Bounded env53725 := by
  intro p hp
  have h : env53725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53724_53725 : H12AffineEnvironment.transform 15 33830 env53724 = env53725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33830 env53724 == env53725) = true)

theorem identity53725 : scanCanonicalize (H12AffineFastState.compose env53725 (packedSelected [1,3,5,6,8,13] rootPS)) = affineNative (2^(14+1) ^^^ 8353) := by decide +kernel

theorem selectedBound53725 : packedSelected [1,3,5,6,8,13] rootPS < 2^1333 := by decide +kernel

def env53726 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,184,8192,1212,8353,9351,185,262144,1024,8352,184,1060,1044,139,8329,1045,262281,185,185,2184,173,1197,172,168,1213,512]

theorem envBound53726 : H12AffineFastState.Bounded env53726 := by
  intro p hp
  have h : env53726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53725_53726 : H12AffineEnvironment.transform 14 8353 env53725 = env53726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8353 env53725 == env53726) = true)

theorem identity53726 : scanCanonicalize (H12AffineFastState.compose env53726 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2600) := by decide +kernel

theorem selectedBound53726 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53727 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,184,2600,1212,2697,3759,185,262144,1024,2696,184,1060,1044,139,2721,1045,262281,185,185,2184,173,1197,172,168,1213,512]

theorem envBound53727 : H12AffineFastState.Bounded env53727 := by
  intro p hp
  have h : env53727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53726_53727 : H12AffineEnvironment.transform 12 2600 env53726 = env53727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2600 env53726 == env53727) = true)

theorem identity53727 : scanCanonicalize (H12AffineFastState.compose env53727 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 2706) := by decide +kernel

theorem selectedBound53727 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env53728 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,184,2600,1212,2697,3759,185,2706,1024,2696,184,1060,1044,139,2721,1045,2587,185,185,2184,173,1197,172,168,1213,512]

theorem envBound53728 : H12AffineFastState.Bounded env53728 := by
  intro p hp
  have h : env53728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53727_53728 : H12AffineEnvironment.transform 17 2706 env53727 = env53728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2706 env53727 == env53728) = true)

theorem identity53728 : scanCanonicalize (H12AffineFastState.compose env53728 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1213) := by decide +kernel

theorem selectedBound53728 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env53729 : List Nat := [2,4,8,16,32,16,128,173,512,1024,1213,184,1685,1212,1588,530,185,1583,1024,1589,184,1060,1044,139,1564,1045,1702,185,185,1077,173,1197,172,168,1213,512]

theorem envBound53729 : H12AffineFastState.Bounded env53729 := by
  intro p hp
  have h : env53729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53728_53729 : H12AffineEnvironment.transform 10 1213 env53728 = env53729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1213 env53728 == env53729) = true)

theorem identity53729 : scanCanonicalize (H12AffineFastState.compose env53729 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound53729 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env53730 : List Nat := [2,4,8,10,32,10,128,173,512,1024,1191,162,1679,1190,1582,520,163,1583,1024,1583,162,1060,1038,139,1542,1039,1702,163,163,1071,173,1197,172,168,1191,512]

theorem envBound53730 : H12AffineFastState.Bounded env53730 := by
  intro p hp
  have h : env53730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53729_53730 : H12AffineEnvironment.transform 3 10 env53729 = env53730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env53729 == env53730) = true)

theorem identity53730 : scanCanonicalize (H12AffineFastState.compose env53730 (packedSelected [0,1,4,7] rootPS)) = affineNative (2^(9+1) ^^^ 653) := by decide +kernel

theorem selectedBound53730 : packedSelected [0,1,4,7] rootPS < 2^1333 := by decide +kernel

def env53731 : List Nat := [2,4,8,10,32,10,128,173,512,653,554,162,2,555,163,520,163,162,653,162,162,681,643,139,139,642,43,163,163,674,173,544,172,168,554,512]

theorem envBound53731 : H12AffineFastState.Bounded env53731 := by
  intro p hp
  have h : env53731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53730_53731 : H12AffineEnvironment.transform 9 653 env53730 = env53731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 653 env53730 == env53731) = true)

theorem identity53731 : scanCanonicalize (H12AffineFastState.compose env53731 (packedSelected [3,4] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound53731 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env53732 : List Nat := [2,4,8,10,32,10,128,173,137,4,163,162,2,162,163,129,163,162,4,162,162,32,10,139,139,11,43,163,163,43,173,169,172,168,163,137]

theorem envBound53732 : H12AffineFastState.Bounded env53732 := by
  intro p hp
  have h : env53732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53731_53732 : H12AffineEnvironment.transform 8 137 env53731 = env53732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env53731 == env53732) = true)

theorem identity53732 : scanCanonicalize (H12AffineFastState.compose env53732 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound53732 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53733 : List Nat := [2,4,8,10,7,10,128,138,137,4,132,133,2,133,132,129,132,133,4,133,133,7,10,139,139,11,12,132,132,12,138,142,139,143,132,137]

theorem envBound53733 : H12AffineFastState.Bounded env53733 := by
  intro p hp
  have h : env53733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53732_53733 : H12AffineEnvironment.transform 4 7 env53732 = env53733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env53732 == env53733) = true)

def env53734 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147472,41002,143496,20497,492567,148669,148669,96266,74794,204946,172,90259,1212,135681]

theorem envBound53734 : H12AffineFastState.Bounded env53734 := by
  intro p hp
  have h : env53734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53720_53734 : H12AffineEnvironment.transform 5 17 env53720 = env53734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53720 == env53734) = true)

theorem identity53734 : scanCanonicalize (H12AffineFastState.compose env53734 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 137352) := by decide +kernel

theorem selectedBound53734 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env53735 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,137352,136193,32769,4096,61568,147472,41002,143496,20497,105631,148669,148669,96266,74794,204946,172,90259,1212,135681]

theorem envBound53735 : H12AffineFastState.Bounded env53735 := by
  intro p hp
  have h : env53735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53734_53735 : H12AffineEnvironment.transform 17 137352 env53734 = env53735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137352 env53734 == env53735) = true)

theorem identity53735 : scanCanonicalize (H12AffineFastState.compose env53735 (packedSelected [1,5,8,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 13375) := by decide +kernel

theorem selectedBound53735 : packedSelected [1,5,8,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env53736 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,13375,131072,137352,136193,32769,4096,61568,147472,41002,143496,20497,43168,148669,148669,19509,4117,136365,172,21676,1212,135681]

theorem envBound53736 : H12AffineFastState.Bounded env53736 := by
  intro p hp
  have h : env53736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53735_53736 : H12AffineEnvironment.transform 15 13375 env53735 = env53736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13375 env53735 == env53736) = true)

theorem identity53736 : scanCanonicalize (H12AffineFastState.compose env53736 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound53736 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env53737 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1212,32768,13375,131072,137352,136193,32769,4096,46140,132268,41002,143496,5293,43168,131073,131073,2185,4117,136365,172,4112,1212,135681]

theorem envBound53737 : H12AffineFastState.Bounded env53737 := by
  intro p hp
  have h : env53737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53736_53737 : H12AffineEnvironment.transform 13 1212 env53736 = env53737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env53736 == env53737) = true)

theorem identity53737 : scanCanonicalize (H12AffineFastState.compose env53737 (packedSelected [13,17] rootPS)) = affineNative (2^(16+1) ^^^ 46244) := by decide +kernel

theorem selectedBound53737 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env53738 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1212,32768,13375,46244,44076,41125,32769,4096,46140,45064,41002,33836,5293,43168,46245,46245,2185,4117,40969,172,4112,1212,42661]

theorem envBound53738 : H12AffineFastState.Bounded env53738 := by
  intro p hp
  have h : env53738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53737_53738 : H12AffineEnvironment.transform 16 46244 env53737 = env53738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46244 env53737 == env53738) = true)

theorem identity53738 : scanCanonicalize (H12AffineFastState.compose env53738 (packedSelected [6,12,13,15] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound53738 : packedSelected [6,12,13,15] rootPS < 2^1333 := by decide +kernel

def env53739 : List Nat := [2,4,8,16,32,17,128,173,512,4,2048,4096,8192,184,32768,12347,45216,43048,41125,32769,4096,45112,45064,41002,32808,4265,43168,45217,45217,2185,4117,40969,172,4112,184,41633]

theorem envBound53739 : H12AffineFastState.Bounded env53739 := by
  intro p hp
  have h : env53739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53738_53739 : H12AffineEnvironment.transform 9 4 env53738 = env53739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env53738 == env53739) = true)

theorem identity53739 : scanCanonicalize (H12AffineFastState.compose env53739 (packedSelected [2,3,6,7,8,9] rootPS)) = affineNative (2^(14+1) ^^^ 6187) := by decide +kernel

theorem selectedBound53739 : packedSelected [2,3,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env53740 : List Nat := [2,4,8,16,32,17,128,173,512,4,2048,4096,8192,184,6187,12347,10379,12291,14478,6186,4096,10259,10275,14337,6147,4265,12427,10378,10378,2185,4117,14370,172,4112,184,14986]

theorem envBound53740 : H12AffineFastState.Bounded env53740 := by
  intro p hp
  have h : env53740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53739_53740 : H12AffineEnvironment.transform 14 6187 env53739 = env53740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 6187 env53739 == env53740) = true)

theorem identity53740 : scanCanonicalize (H12AffineFastState.compose env53740 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound53740 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env53741 : List Nat := [2,4,8,16,32,17,18,63,512,4,2048,4096,8192,42,6187,12347,10265,12291,14364,6186,4096,10259,10275,14337,6147,4155,12313,10264,10264,2075,4117,14370,62,4112,42,14872]

theorem envBound53741 : H12AffineFastState.Bounded env53741 := by
  intro p hp
  have h : env53741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53740_53741 : H12AffineEnvironment.transform 6 18 env53740 = env53741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env53740 == env53741) = true)

theorem identity53741 : scanCanonicalize (H12AffineFastState.compose env53741 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 2610) := by decide +kernel

theorem selectedBound53741 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env53742 : List Nat := [2,4,8,16,32,17,18,63,512,4,2048,4096,2610,42,6187,6665,555,6705,4654,6186,4096,545,529,4659,6147,4155,6699,554,554,2075,4117,4624,62,4112,42,4138]

theorem envBound53742 : H12AffineFastState.Bounded env53742 := by
  intro p hp
  have h : env53742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53741_53742 : H12AffineEnvironment.transform 12 2610 env53741 = env53742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2610 env53741 == env53742) = true)

theorem identity53742 : scanCanonicalize (H12AffineFastState.compose env53742 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 2560) := by decide +kernel

theorem selectedBound53742 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env53743 : List Nat := [2,4,8,16,32,17,18,63,512,4,2048,2560,2610,42,555,9,555,49,2094,554,2560,545,529,2099,515,2619,43,554,554,2075,2581,2064,62,2576,42,2602]

theorem envBound53743 : H12AffineFastState.Bounded env53743 := by
  intro p hp
  have h : env53743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53742_53743 : H12AffineEnvironment.transform 11 2560 env53742 = env53743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2560 env53742 == env53743) = true)

theorem identity53743 : scanCanonicalize (H12AffineFastState.compose env53743 (packedSelected [3,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound53743 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env53744 : List Nat := [2,4,8,16,32,17,18,63,512,4,42,554,536,42,555,9,555,49,4,554,554,545,529,25,515,529,43,554,554,49,575,58,62,570,42,512]

theorem envBound53744 : H12AffineFastState.Bounded env53744 := by
  intro p hp
  have h : env53744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53743_53744 : H12AffineEnvironment.transform 10 42 env53743 = env53744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env53743 == env53744) = true)

theorem identity53744 : scanCanonicalize (H12AffineFastState.compose env53744 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound53744 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53745 : List Nat := [2,4,8,16,32,17,18,63,1,4,42,43,25,42,42,9,42,49,4,43,43,32,16,25,2,16,43,43,43,49,62,58,62,59,42,1]

theorem envBound53745 : H12AffineFastState.Bounded env53745 := by
  intro p hp
  have h : env53745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53744_53745 : H12AffineEnvironment.transform 8 1 env53744 = env53745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env53744 == env53745) = true)

theorem identity53745 : scanCanonicalize (H12AffineFastState.compose env53745 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound53745 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53746 : List Nat := [2,4,8,16,23,17,18,8,1,4,29,28,25,29,29,9,29,6,4,28,28,23,16,25,2,16,28,28,28,6,9,13,9,12,29,1]

theorem envBound53746 : H12AffineFastState.Bounded env53746 := by
  intro p hp
  have h : env53746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53745_53746 : H12AffineEnvironment.transform 4 23 env53745 = env53746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env53745 == env53746) = true)

def env53747 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,16777216,33554432,672784,134217728,148801,33584585,96346,50962569,4294967296,34088328,4345352435,151462017,33563273]

theorem envBound53747 : H12AffineFastState.Bounded env53747 := by
  intro p hp
  have h : env53747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52550_53747 : H12AffineEnvironment.transform 20 4097 env52550 = env53747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env52550 == env53747) = true)

theorem identity53747 : scanCanonicalize (H12AffineFastState.compose env53747 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 185476455) := by decide +kernel

theorem selectedBound53747 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env53748 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,16777216,33554432,672784,134217728,148801,33584585,96346,50962569,185476455,34088328,135198100,151462017,33563273]

theorem envBound53748 : H12AffineFastState.Bounded env53748 := by
  intro p hp
  have h : env53748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53747_53748 : H12AffineEnvironment.transform 31 185476455 env53747 = env53748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 185476455 env53747 == env53748) = true)

def env53749 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,16777216,533640,672784,134217728,148801,545089,96346,16876545,151388655,256,135198100,151462017,525825]

theorem envBound53749 : H12AffineFastState.Bounded env53749 := by
  intro p hp
  have h : env53749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53748_53749 : H12AffineEnvironment.transform 24 533640 env53748 = env53749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533640 env53748 == env53749) = true)

def env53750 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,16777216,533640,672784,17245632,148801,545089,96346,16876545,74799,256,17420372,1345,525825]

theorem envBound53750 : H12AffineFastState.Bounded env53750 := by
  intro p hp
  have h : env53750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53749_53750 : H12AffineEnvironment.transform 26 17245632 env53749 = env53750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env53749 == env53750) = true)

theorem identity53750 : scanCanonicalize (H12AffineFastState.compose env53750 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(18+1) ^^^ 95614) := by decide +kernel

theorem selectedBound53750 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env53751 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95614,32769,4097,61648,147521,16777216,86518,209262,17245632,148801,74815,96346,16876545,74799,256,16819498,1345,95103]

theorem envBound53751 : H12AffineFastState.Bounded env53751 := by
  intro p hp
  have h : env53751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53750_53751 : H12AffineEnvironment.transform 18 95614 env53750 = env53751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 95614 env53750 == env53751) = true)

def env53752 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95614,32769,4097,61648,147521,284032,86518,209262,225344,148801,74815,96346,381313,74799,256,323754,1345,95103]

theorem envBound53752 : H12AffineFastState.Bounded env53752 := by
  intro p hp
  have h : env53752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53751_53752 : H12AffineEnvironment.transform 23 284032 env53751 = env53752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284032 env53751 == env53752) = true)

def env53753 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16464,262144,95614,32769,4097,61648,17,284032,86518,94526,77840,1297,74815,96346,381313,74799,256,323754,1345,95103]

theorem envBound53753 : H12AffineFastState.Bounded env53753 := by
  intro p hp
  have h : env53753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53752_53753 : H12AffineEnvironment.transform 16 16464 env53752 = env53753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16464 env53752 == env53753) = true)

def env53754 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1344,262144,77934,32769,4097,46528,17,266384,70886,78894,77840,1297,74815,81226,365713,74799,256,308666,1345,79471]

theorem envBound53754 : H12AffineFastState.Bounded env53754 := by
  intro p hp
  have h : env53754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53753_53754 : H12AffineEnvironment.transform 13 1296 env53753 = env53754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env53753 == env53754) = true)

theorem identity53754 : scanCanonicalize (H12AffineFastState.compose env53754 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound53754 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env53755 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1344,262144,77934,13341,4097,476,17,266384,70886,78894,77840,1297,74815,81226,336013,74799,256,262566,1345,79471]

theorem envBound53755 : H12AffineFastState.Bounded env53755 := by
  intro p hp
  have h : env53755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53754_53755 : H12AffineEnvironment.transform 14 13340 env53754 = env53755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env53754 == env53755) = true)

def env53756 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1344,65664,77934,13341,4097,476,17,69648,70886,78894,77840,1297,74815,81226,8205,74799,256,65830,1345,79471]

theorem envBound53756 : H12AffineFastState.Bounded env53756 := by
  intro p hp
  have h : env53756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53755_53756 : H12AffineEnvironment.transform 17 65664 env53755 = env53756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env53755 == env53756) = true)

theorem identity53756 : scanCanonicalize (H12AffineFastState.compose env53756 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound53756 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env53757 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1296,9293,65536,1344,65664,73791,9292,80,476,17,65601,66743,74879,73793,1297,74815,77083,8205,74799,256,65830,1345,75326]

theorem envBound53757 : H12AffineFastState.Bounded env53757 := by
  intro p hp
  have h : env53757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53756_53757 : H12AffineEnvironment.transform 11 81 env53756 = env53757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env53756 == env53757) = true)

def env53758 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1,8192,1296,9245,65536,1296,65664,73791,9244,0,396,17,65553,66743,74799,73745,1297,74815,77083,8205,74799,256,65830,1297,75326]

theorem envBound53758 : H12AffineFastState.Bounded env53758 := by
  intro p hp
  have h : env53758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53757_53758 : H12AffineEnvironment.transform 5 16 env53757 = env53758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env53757 == env53758) = true)

theorem identity53758 : scanCanonicalize (H12AffineFastState.compose env53758 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 1331) := by decide +kernel

theorem selectedBound53758 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env53759 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1,8192,1296,9245,1331,1296,1459,9484,9244,0,396,17,1314,388,8476,9506,1297,8460,10280,8205,8476,256,1045,1297,8973]

theorem envBound53759 : H12AffineFastState.Bounded env53759 := by
  intro p hp
  have h : env53759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53758_53759 : H12AffineEnvironment.transform 15 1331 env53758 = env53759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1331 env53758 == env53759) = true)

def env53760 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,0,8192,1296,9244,65536,1297,65664,73791,9245,1,397,17,65552,66743,74798,73744,1297,74815,77083,8205,74799,256,65830,1296,75326]

theorem envBound53760 : H12AffineFastState.Bounded env53760 := by
  intro p hp
  have h : env53760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53757_53760 : H12AffineEnvironment.transform 5 17 env53757 = env53760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53757 == env53760) = true)

theorem identity53760 : scanCanonicalize (H12AffineFastState.compose env53760 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound53760 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env53761 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,0,268,1296,1296,65536,1297,65664,65843,1297,1,397,17,65552,66743,66850,65820,1297,66867,68631,257,66851,256,65830,1296,67378]

theorem envBound53761 : H12AffineFastState.Bounded env53761 := by
  intro p hp
  have h : env53761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53760_53761 : H12AffineEnvironment.transform 12 268 env53760 = env53761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env53760 == env53761) = true)

theorem identity53761 : scanCanonicalize (H12AffineFastState.compose env53761 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 1330) := by decide +kernel

theorem selectedBound53761 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env53762 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,0,268,1296,1296,1330,1297,1458,1025,1297,1,397,17,1314,389,16,1070,1297,1,2341,257,17,256,1044,1296,512]

theorem envBound53762 : H12AffineFastState.Bounded env53762 := by
  intro p hp
  have h : env53762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53761_53762 : H12AffineEnvironment.transform 15 1330 env53761 = env53762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1330 env53761 == env53762) = true)

theorem identity53762 : scanCanonicalize (H12AffineFastState.compose env53762 (packedSelected [2,13,17] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound53762 : packedSelected [2,13,17] rootPS < 2^1333 := by decide +kernel

def env53763 : List Nat := [2,4,8,16,32,17,128,256,512,1024,513,0,268,1296,1296,1330,1297,1458,1025,1297,1,397,17,1314,389,16,1070,1297,1,804,257,17,256,1044,1296,512]

theorem envBound53763 : H12AffineFastState.Bounded env53763 := by
  intro p hp
  have h : env53763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53762_53763 : H12AffineEnvironment.transform 10 513 env53762 = env53763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env53762 == env53763) = true)

theorem identity53763 : scanCanonicalize (H12AffineFastState.compose env53763 (packedSelected [1,2,5] rootPS)) = affineNative (2^(9+1) ^^^ 31) := by decide +kernel

theorem selectedBound53763 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env53764 : List Nat := [2,4,8,16,32,17,128,256,512,31,513,0,268,271,271,301,270,429,30,270,1,397,17,317,389,16,49,270,1,804,257,17,256,11,271,512]

theorem envBound53764 : H12AffineFastState.Bounded env53764 := by
  intro p hp
  have h : env53764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53763_53764 : H12AffineEnvironment.transform 9 31 env53763 = env53764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 31 env53763 == env53764) = true)

theorem identity53764 : scanCanonicalize (H12AffineFastState.compose env53764 (packedSelected [0,1,2,3,7,8,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 182) := by decide +kernel

theorem selectedBound53764 : packedSelected [0,1,2,3,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env53765 : List Nat := [2,4,8,16,32,17,128,182,512,31,513,0,186,185,185,155,184,27,30,184,1,59,17,139,51,16,49,184,1,658,183,17,182,11,185,512]

theorem envBound53765 : H12AffineFastState.Bounded env53765 := by
  intro p hp
  have h : env53765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53764_53765 : H12AffineEnvironment.transform 7 182 env53764 = env53765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 182 env53764 == env53765) = true)

theorem identity53765 : scanCanonicalize (H12AffineFastState.compose env53765 (packedSelected [0,2,7,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 147) := by decide +kernel

theorem selectedBound53765 : packedSelected [0,2,7,8,9] rootPS < 2^1333 := by decide +kernel

def env53766 : List Nat := [2,4,8,16,32,17,128,182,147,31,146,0,186,185,185,155,184,27,30,184,1,59,17,139,51,16,49,184,1,1,183,17,182,11,185,147]

theorem envBound53766 : H12AffineFastState.Bounded env53766 := by
  intro p hp
  have h : env53766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53765_53766 : H12AffineEnvironment.transform 8 147 env53765 = env53766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 147 env53765 == env53766) = true)

theorem identity53766 : scanCanonicalize (H12AffineFastState.compose env53766 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound53766 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env53767 : List Nat := [2,4,8,16,32,17,35,21,48,31,49,0,25,26,26,56,27,27,30,27,1,59,17,40,51,16,49,27,1,1,20,17,21,11,26,48]

theorem envBound53767 : H12AffineFastState.Bounded env53767 := by
  intro p hp
  have h : env53767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53766_53767 : H12AffineEnvironment.transform 6 35 env53766 = env53767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env53766 == env53767) = true)

theorem identity53767 : scanCanonicalize (H12AffineFastState.compose env53767 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound53767 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53768 : List Nat := [2,4,8,10,32,11,35,15,42,5,43,0,3,0,0,34,1,1,4,1,1,33,11,40,41,10,43,1,1,1,14,11,15,11,0,42]

theorem envBound53768 : H12AffineFastState.Bounded env53768 := by
  intro p hp
  have h : env53768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53767_53768 : H12AffineEnvironment.transform 3 10 env53767 = env53768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env53767 == env53768) = true)

theorem identity53768 : scanCanonicalize (H12AffineFastState.compose env53768 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound53768 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53769 : List Nat := [2,4,5,7,32,6,35,2,39,5,38,0,3,0,0,34,1,1,4,1,1,33,6,37,36,7,38,1,1,1,3,6,2,6,0,39]

theorem envBound53769 : H12AffineFastState.Bounded env53769 := by
  intro p hp
  have h : env53769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53768_53769 : H12AffineEnvironment.transform 2 5 env53768 = env53769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env53768 == env53769) = true)

def env53770 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1344,65665,77934,13341,4097,476,17,69649,70886,78894,77840,1297,74815,81226,8204,74799,256,65831,1345,79471]

theorem envBound53770 : H12AffineFastState.Bounded env53770 := by
  intro p hp
  have h : env53770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53755_53770 : H12AffineEnvironment.transform 17 65665 env53755 = env53770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env53755 == env53770) = true)

theorem identity53770 : scanCanonicalize (H12AffineFastState.compose env53770 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound53770 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env53771 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,0,12556,65536,80,65665,77934,12557,4097,476,17,69649,70134,78142,77840,1,74031,79962,8204,74047,256,65831,81,78719]

theorem envBound53771 : H12AffineFastState.Bounded env53771 := by
  intro p hp
  have h : env53771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53770_53771 : H12AffineEnvironment.transform 9 272 env53770 = env53771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env53770 == env53771) = true)

def env53772 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,4096,8192,0,12556,65536,0,65665,77886,12557,4097,396,17,69649,70054,78142,77840,1,74031,79882,8204,74047,256,65831,1,78639]

theorem envBound53772 : H12AffineFastState.Bounded env53772 := by
  intro p hp
  have h : env53772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53771_53772 : H12AffineEnvironment.transform 5 16 env53771 = env53772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env53771 == env53772) = true)

theorem identity53772 : scanCanonicalize (H12AffineFastState.compose env53772 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 4131) := by decide +kernel

theorem selectedBound53772 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env53773 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,4096,8192,0,12556,4131,0,4258,8221,12557,4097,396,17,50,389,8477,8243,1,12556,10281,8204,12572,256,4356,1,8972]

theorem envBound53773 : H12AffineFastState.Bounded env53773 := by
  intro p hp
  have h : env53773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53772_53773 : H12AffineEnvironment.transform 15 4131 env53772 = env53773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4131 env53772 == env53773) = true)

theorem identity53773 : scanCanonicalize (H12AffineFastState.compose env53773 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound53773 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env53774 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,4096,269,0,4097,4131,0,4258,272,4096,4097,396,17,50,389,16,318,1,4097,2340,257,4113,256,4356,1,513]

theorem envBound53774 : H12AffineFastState.Bounded env53774 := by
  intro p hp
  have h : env53774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53773_53774 : H12AffineEnvironment.transform 12 269 env53773 = env53774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env53773 == env53774) = true)

theorem identity53774 : scanCanonicalize (H12AffineFastState.compose env53774 (packedSelected [2,13,17] rootPS)) = affineNative (2^(10+1) ^^^ 903) := by decide +kernel

theorem selectedBound53774 : packedSelected [2,13,17] rootPS < 2^1333 := by decide +kernel

def env53775 : List Nat := [2,4,8,16,32,16,128,256,512,272,903,4096,269,0,4097,4131,0,4258,272,4096,4097,396,17,50,389,16,318,1,4097,675,257,4113,256,4356,1,513]

theorem envBound53775 : H12AffineFastState.Bounded env53775 := by
  intro p hp
  have h : env53775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53774_53775 : H12AffineEnvironment.transform 10 903 env53774 = env53775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 903 env53774 == env53775) = true)

theorem identity53775 : scanCanonicalize (H12AffineFastState.compose env53775 (packedSelected [2,11,18] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound53775 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env53776 : List Nat := [2,4,8,16,32,16,128,256,49,272,438,4096,269,0,4097,4131,0,4258,272,4096,4097,396,17,50,389,16,318,1,4097,146,257,4113,256,4356,1,48]

theorem envBound53776 : H12AffineFastState.Bounded env53776 := by
  intro p hp
  have h : env53776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53775_53776 : H12AffineEnvironment.transform 8 49 env53775 = env53776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env53775 == env53776) = true)

theorem identity53776 : scanCanonicalize (H12AffineFastState.compose env53776 (packedSelected [0,1,2,3,5,7,8,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 397) := by decide +kernel

theorem selectedBound53776 : packedSelected [0,1,2,3,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env53777 : List Nat := [2,4,8,16,32,16,128,256,49,272,438,397,269,0,396,430,0,303,272,397,396,396,17,50,389,16,318,1,396,146,257,412,256,137,1,48]

theorem envBound53777 : H12AffineFastState.Bounded env53777 := by
  intro p hp
  have h : env53777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53776_53777 : H12AffineEnvironment.transform 11 397 env53776 = env53777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 397 env53776 == env53777) = true)

theorem identity53777 : scanCanonicalize (H12AffineFastState.compose env53777 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 160) := by decide +kernel

theorem selectedBound53777 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env53778 : List Nat := [2,4,8,16,32,16,128,160,49,176,22,45,173,0,44,14,0,143,176,45,44,44,17,50,37,16,158,1,44,146,161,60,160,137,1,48]

theorem envBound53778 : H12AffineFastState.Bounded env53778 := by
  intro p hp
  have h : env53778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53777_53778 : H12AffineEnvironment.transform 7 160 env53777 = env53778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 160 env53777 == env53778) = true)

theorem identity53778 : scanCanonicalize (H12AffineFastState.compose env53778 (packedSelected [0,3,7,9,12] rootPS)) = affineNative (2^(6+1) ^^^ 29) := by decide +kernel

theorem selectedBound53778 : packedSelected [0,3,7,9,12] rootPS < 2^1333 := by decide +kernel

def env53779 : List Nat := [2,4,8,16,32,16,29,61,49,45,22,45,48,0,44,14,0,18,45,45,44,44,17,50,37,16,3,1,44,15,60,60,61,20,1,48]

theorem envBound53779 : H12AffineFastState.Bounded env53779 := by
  intro p hp
  have h : env53779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53778_53779 : H12AffineEnvironment.transform 6 29 env53778 = env53779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 29 env53778 == env53779) = true)

theorem identity53779 : scanCanonicalize (H12AffineFastState.compose env53779 (packedSelected [1,3,8,10,13] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound53779 : packedSelected [1,3,8,10,13] rootPS < 2^1333 := by decide +kernel

def env53780 : List Nat := [2,4,8,13,32,13,0,32,44,45,11,45,45,0,44,14,0,15,45,45,44,44,12,47,37,13,3,1,44,15,33,33,32,9,1,45]

theorem envBound53780 : H12AffineFastState.Bounded env53780 := by
  intro p hp
  have h : env53780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53779_53780 : H12AffineEnvironment.transform 3 13 env53779 = env53780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env53779 == env53780) = true)

theorem identity53780 : scanCanonicalize (H12AffineFastState.compose env53780 (packedSelected [1,3] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound53780 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env53781 : List Nat := [0,4,8,13,32,13,0,32,44,45,9,45,45,0,44,12,0,13,45,45,44,44,12,45,37,13,1,1,44,13,33,33,32,9,1,45]

theorem envBound53781 : H12AffineFastState.Bounded env53781 := by
  intro p hp
  have h : env53781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53780_53781 : H12AffineEnvironment.transform 0 0 env53780 = env53781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env53780 == env53781) = true)

theorem identity53781 : scanCanonicalize (H12AffineFastState.compose env53781 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 4) := by decide +kernel

theorem selectedBound53781 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env53782 : List Nat := [0,4,8,13,4,13,0,4,8,9,9,9,9,0,8,12,0,13,9,9,8,8,12,9,1,13,1,1,8,13,5,5,4,9,1,9]

theorem envBound53782 : H12AffineFastState.Bounded env53782 := by
  intro p hp
  have h : env53782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53781_53782 : H12AffineEnvironment.transform 4 4 env53781 = env53782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 4 env53781 == env53782) = true)

theorem identity53782 : scanCanonicalize (H12AffineFastState.compose env53782 (packedSelected [0,1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound53782 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env53783 : List Nat := [0,1,8,8,1,8,0,1,8,9,9,9,9,0,8,9,0,8,9,9,8,8,9,9,1,8,1,1,8,8,0,0,1,9,1,9]

theorem envBound53783 : H12AffineFastState.Bounded env53783 := by
  intro p hp
  have h : env53783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53782_53783 : H12AffineEnvironment.transform 1 1 env53782 = env53783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env53782 == env53783) = true)

theorem identity53783 : scanCanonicalize (H12AffineFastState.compose env53783 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound53783 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53784 : List Nat := [0,1,1,1,1,1,0,1,1,0,0,0,0,0,1,0,0,1,0,0,1,1,0,0,1,1,1,1,1,1,0,0,1,0,1,0]

theorem envBound53784 : H12AffineFastState.Bounded env53784 := by
  intro p hp
  have h : env53784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53783_53784 : H12AffineEnvironment.transform 2 1 env53783 = env53784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env53783 == env53784) = true)

def env53785 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,4096,8192,0,12556,65536,1,65665,77887,12557,4097,397,17,69649,70055,78142,77840,1,74031,79883,8204,74047,256,65831,0,78638]

theorem envBound53785 : H12AffineFastState.Bounded env53785 := by
  intro p hp
  have h : env53785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53771_53785 : H12AffineEnvironment.transform 5 17 env53771 = env53785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53771 == env53785) = true)

theorem identity53785 : scanCanonicalize (H12AffineFastState.compose env53785 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound53785 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env53786 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,4096,269,0,4097,65536,1,65665,69938,4096,4097,397,17,69649,70055,69683,69917,1,65570,71942,257,65586,256,65831,0,70179]

theorem envBound53786 : H12AffineFastState.Bounded env53786 := by
  intro p hp
  have h : env53786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53785_53786 : H12AffineEnvironment.transform 12 269 env53785 = env53786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env53785 == env53786) = true)

theorem identity53786 : scanCanonicalize (H12AffineFastState.compose env53786 (packedSelected [1,2,3,5,8,10,13,19,21,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 5055) := by decide +kernel

theorem selectedBound53786 : packedSelected [1,2,3,5,8,10,13,19,21,23,32] rootPS < 2^1333 := by decide +kernel

def env53787 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,4096,269,0,4097,5055,1,4926,653,4096,4097,397,17,942,536,908,674,1,5021,2745,257,5005,256,4760,0,412]

theorem envBound53787 : H12AffineFastState.Bounded env53787 := by
  intro p hp
  have h : env53787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53786_53787 : H12AffineEnvironment.transform 15 5055 env53786 = env53787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5055 env53786 == env53787) = true)

theorem identity53787 : scanCanonicalize (H12AffineFastState.compose env53787 (packedSelected [0,1,3,4,7,8,9,10,18,19,21,23,26,28] rootPS)) = affineNative (2^(10+1) ^^^ 951) := by decide +kernel

theorem selectedBound53787 : packedSelected [0,1,3,4,7,8,9,10,18,19,21,23,26,28] rootPS < 2^1333 := by decide +kernel

def env53788 : List Nat := [2,4,8,16,32,17,128,256,512,272,951,4096,269,0,4097,5055,1,4926,653,4096,4097,397,17,942,536,908,674,1,5021,270,257,5005,256,4760,0,412]

theorem envBound53788 : H12AffineFastState.Bounded env53788 := by
  intro p hp
  have h : env53788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53787_53788 : H12AffineEnvironment.transform 10 951 env53787 = env53788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 951 env53787 == env53788) = true)

theorem identity53788 : scanCanonicalize (H12AffineFastState.compose env53788 (packedSelected [2,5,8,10,11,12,15,18,19] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound53788 : packedSelected [2,5,8,10,11,12,15,18,19] rootPS < 2^1333 := by decide +kernel

def env53789 : List Nat := [2,4,8,16,32,17,128,256,512,272,951,184,269,0,185,775,1,902,653,184,185,397,17,942,536,908,674,1,805,270,257,821,256,544,0,412]

theorem envBound53789 : H12AffineFastState.Bounded env53789 := by
  intro p hp
  have h : env53789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53788_53789 : H12AffineEnvironment.transform 11 184 env53788 = env53789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env53788 == env53789) = true)

theorem identity53789 : scanCanonicalize (H12AffineFastState.compose env53789 (packedSelected [0,2,4,12,13] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound53789 : packedSelected [0,2,4,12,13] rootPS < 2^1333 := by decide +kernel

def env53790 : List Nat := [2,4,8,16,32,17,128,173,512,189,538,184,160,0,185,682,1,555,653,184,185,32,17,515,536,545,674,1,648,163,172,664,173,544,0,49]

theorem envBound53790 : H12AffineFastState.Bounded env53790 := by
  intro p hp
  have h : env53790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53789_53790 : H12AffineEnvironment.transform 7 173 env53789 = env53790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env53789 == env53790) = true)

theorem identity53790 : scanCanonicalize (H12AffineFastState.compose env53790 (packedSelected [3,4,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound53790 : packedSelected [3,4,8,9] rootPS < 2^1333 := by decide +kernel

def env53791 : List Nat := [2,4,8,16,32,17,128,173,43,189,49,184,160,0,185,129,1,0,166,184,185,32,17,40,51,10,137,1,163,163,172,179,173,11,0,49]

theorem envBound53791 : H12AffineFastState.Bounded env53791 := by
  intro p hp
  have h : env53791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53790_53791 : H12AffineEnvironment.transform 8 43 env53790 = env53791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env53790 == env53791) = true)

theorem identity53791 : scanCanonicalize (H12AffineFastState.compose env53791 (packedSelected [3,5] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound53791 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env53792 : List Nat := [2,4,8,16,32,17,19,62,43,46,49,43,51,0,42,18,1,0,53,43,42,32,17,40,51,10,26,1,48,48,63,32,62,11,0,49]

theorem envBound53792 : H12AffineFastState.Bounded env53792 := by
  intro p hp
  have h : env53792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53791_53792 : H12AffineEnvironment.transform 6 19 env53791 = env53792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env53791 == env53792) = true)

theorem identity53792 : scanCanonicalize (H12AffineFastState.compose env53792 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound53792 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env53793 : List Nat := [2,4,8,16,10,17,19,20,1,4,27,1,25,0,0,18,1,0,31,1,0,10,17,2,25,10,26,1,26,26,21,10,20,11,0,27]

theorem envBound53793 : H12AffineFastState.Bounded env53793 := by
  intro p hp
  have h : env53793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53792_53793 : H12AffineEnvironment.transform 4 10 env53792 = env53793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env53792 == env53793) = true)

theorem identity53793 : scanCanonicalize (H12AffineFastState.compose env53793 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound53793 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53794 : List Nat := [2,3,8,16,10,17,19,19,1,3,27,1,25,0,0,18,1,0,24,1,0,10,17,2,25,10,26,1,26,26,18,10,19,11,0,27]

theorem envBound53794 : H12AffineFastState.Bounded env53794 := by
  intro p hp
  have h : env53794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53793_53794 : H12AffineEnvironment.transform 1 3 env53793 = env53794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env53793 == env53794) = true)

def env53795 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1345,262144,77935,32769,4097,46529,17,266385,70887,78895,77840,1297,74815,81227,365712,74799,256,308667,1345,79470]

theorem envBound53795 : H12AffineFastState.Bounded env53795 := by
  intro p hp
  have h : env53795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53753_53795 : H12AffineEnvironment.transform 13 1297 env53753 = env53795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env53753 == env53795) = true)

theorem identity53795 : scanCanonicalize (H12AffineFastState.compose env53795 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32883) := by decide +kernel

theorem selectedBound53795 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env53796 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,32883,1345,262144,45084,32769,4097,46529,17,266385,38036,46172,45155,1297,42060,48440,267491,42076,256,308667,1345,46621]

theorem envBound53796 : H12AffineFastState.Bounded env53796 := by
  intro p hp
  have h : env53796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53795_53796 : H12AffineEnvironment.transform 15 32883 env53795 = env53796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32883 env53795 == env53796) = true)

def env53797 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32883,1345,262144,42332,32769,1345,41089,17,263633,33236,41244,42275,1297,42060,43128,262563,42076,256,303355,1345,41821]

theorem envBound53797 : H12AffineFastState.Bounded env53797 := by
  intro p hp
  have h : env53797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53796_53797 : H12AffineEnvironment.transform 11 1344 env53796 = env53797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env53796 == env53797) = true)

theorem identity53797 : scanCanonicalize (H12AffineFastState.compose env53797 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound53797 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env53798 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,25,1297,32768,32883,1345,262144,34117,32769,1345,32920,17,263633,33236,33029,34106,1297,33877,34913,262563,33861,256,295138,1345,33604]

theorem envBound53798 : H12AffineFastState.Bounded env53798 := by
  intro p hp
  have h : env53798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53797_53798 : H12AffineEnvironment.transform 12 25 env53797 = env53798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env53797 == env53798) = true)

theorem identity53798 : scanCanonicalize (H12AffineFastState.compose env53798 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 35561) := by decide +kernel

theorem selectedBound53798 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env53799 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,25,1297,32768,32883,1345,35561,34117,32769,1345,32920,17,36664,33236,33029,34106,1297,33877,34913,35658,33861,256,2571,1345,33604]

theorem envBound53799 : H12AffineFastState.Bounded env53799 := by
  intro p hp
  have h : env53799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53798_53799 : H12AffineEnvironment.transform 17 35561 env53798 = env53799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35561 env53798 == env53799) = true)

def env53800 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32883,1345,262144,42333,32769,1344,41088,17,263632,33237,41245,42274,1297,42060,43129,262562,42076,256,303354,1345,41820]

theorem envBound53800 : H12AffineFastState.Bounded env53800 := by
  intro p hp
  have h : env53800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53796_53800 : H12AffineEnvironment.transform 11 1345 env53796 = env53800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env53796 == env53800) = true)

theorem identity53800 : scanCanonicalize (H12AffineFastState.compose env53800 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 41194) := by decide +kernel

theorem selectedBound53800 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env53801 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32883,1345,41194,42333,32769,1344,41088,17,42298,33237,41245,42274,1297,42060,43129,41288,42076,256,16,1345,41820]

theorem envBound53801 : H12AffineFastState.Bounded env53801 := by
  intro p hp
  have h : env53801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53800_53801 : H12AffineEnvironment.transform 17 41194 env53800 = env53801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 41194 env53800 == env53801) = true)

theorem identity53801 : scanCanonicalize (H12AffineFastState.compose env53801 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound53801 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env53802 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,8540,8495,1345,438,1025,8541,1344,476,17,1126,8329,65,1150,1297,1296,2341,20,1280,256,16,1345,512]

theorem envBound53802 : H12AffineFastState.Bounded env53802 := by
  intro p hp
  have h : env53802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53801_53802 : H12AffineEnvironment.transform 14 8540 env53801 = env53802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env53801 == env53802) = true)

theorem identity53802 : scanCanonicalize (H12AffineFastState.compose env53802 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound53802 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env53803 : List Nat := [2,4,8,16,32,64,128,69,512,1024,2048,1028,8192,1108,8217,8298,1028,243,1025,8216,1029,153,17,1126,8329,65,1150,1108,1109,2144,20,1093,69,16,1028,512]

theorem envBound53803 : H12AffineFastState.Bounded env53803 := by
  intro p hp
  have h : env53803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53802_53803 : H12AffineEnvironment.transform 7 69 env53802 = env53803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env53802 == env53803) = true)

theorem identity53803 : scanCanonicalize (H12AffineFastState.compose env53803 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1685) := by decide +kernel

theorem selectedBound53803 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env53804 : List Nat := [2,4,8,16,32,64,128,69,512,1024,2048,1028,1685,1108,1676,1791,1028,243,1025,1677,1029,153,17,1126,1564,65,1150,1108,1109,2144,20,1093,69,16,1028,512]

theorem envBound53804 : H12AffineFastState.Bounded env53804 := by
  intro p hp
  have h : env53804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53803_53804 : H12AffineEnvironment.transform 12 1685 env53803 = env53804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1685 env53803 == env53804) = true)

theorem identity53804 : scanCanonicalize (H12AffineFastState.compose env53804 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound53804 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env53805 : List Nat := [2,4,8,16,32,17,128,20,512,1024,2048,1028,1685,1029,1676,1710,1028,162,1025,1677,1029,153,17,1079,1564,16,1071,1029,1028,2097,20,1044,20,16,1028,512]

theorem envBound53805 : H12AffineFastState.Bounded env53805 := by
  intro p hp
  have h : env53805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53804_53805 : H12AffineEnvironment.transform 5 17 env53804 = env53805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53804 == env53805) = true)

theorem identity53805 : scanCanonicalize (H12AffineFastState.compose env53805 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1055) := by decide +kernel

theorem selectedBound53805 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env53806 : List Nat := [2,4,8,16,32,17,128,20,512,1024,1055,1028,1685,1029,1676,1710,1028,162,1025,1677,1029,153,17,1079,1564,16,1071,1029,1028,1070,20,1044,20,16,1028,512]

theorem envBound53806 : H12AffineFastState.Bounded env53806 := by
  intro p hp
  have h : env53806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53805_53806 : H12AffineEnvironment.transform 10 1055 env53805 = env53806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1055 env53805 == env53806) = true)

def env53807 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16465,262144,95614,32769,4097,61648,16,284032,86518,94527,77841,1296,74815,96346,381313,74799,256,323754,1345,95103]

theorem envBound53807 : H12AffineFastState.Bounded env53807 := by
  intro p hp
  have h : env53807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53752_53807 : H12AffineEnvironment.transform 16 16465 env53752 = env53807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16465 env53752 == env53807) = true)

def env53808 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1345,262144,77934,32769,4097,46528,16,266384,70886,78895,77841,1296,74815,81226,365713,74799,256,308666,1345,79471]

theorem envBound53808 : H12AffineFastState.Bounded env53808 := by
  intro p hp
  have h : env53808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53807_53808 : H12AffineEnvironment.transform 13 1296 env53807 = env53808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env53807 == env53808) = true)

theorem identity53808 : scanCanonicalize (H12AffineFastState.compose env53808 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32882) := by decide +kernel

theorem selectedBound53808 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env53809 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,32882,1345,262144,45084,32769,4097,46528,16,266384,38036,46173,45155,1296,42061,48440,267491,42077,256,308666,1345,46621]

theorem envBound53809 : H12AffineFastState.Bounded env53809 := by
  intro p hp
  have h : env53809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53808_53809 : H12AffineEnvironment.transform 15 32882 env53808 = env53809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32882 env53808 == env53809) = true)

def env53810 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32882,1345,262144,42332,32769,1345,41088,16,263632,33236,41245,42275,1296,42061,43128,262563,42077,256,303354,1345,41821]

theorem envBound53810 : H12AffineFastState.Bounded env53810 := by
  intro p hp
  have h : env53810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53809_53810 : H12AffineEnvironment.transform 11 1344 env53809 = env53810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env53809 == env53810) = true)

theorem identity53810 : scanCanonicalize (H12AffineFastState.compose env53810 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 9293) := by decide +kernel

theorem selectedBound53810 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env53811 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,9293,9279,1345,262144,273,9292,1345,1229,16,263632,9625,1360,366,1296,0,3125,262563,16,256,263351,1345,1808]

theorem envBound53811 : H12AffineFastState.Bounded env53811 := by
  intro p hp
  have h : env53811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53810_53811 : H12AffineEnvironment.transform 14 9293 env53810 = env53811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9293 env53810 == env53811) = true)

theorem identity53811 : scanCanonicalize (H12AffineFastState.compose env53811 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound53811 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env53812 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,80,8192,0,8541,8495,81,262144,273,8540,81,477,16,262336,8329,64,366,0,0,2341,262563,16,256,262567,81,512]

theorem envBound53812 : H12AffineFastState.Bounded env53812 := by
  intro p hp
  have h : env53812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53811_53812 : H12AffineEnvironment.transform 9 272 env53811 = env53812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env53811 == env53812) = true)

theorem identity53812 : scanCanonicalize (H12AffineFastState.compose env53812 (packedSelected [4,9,16] rootPS)) = affineNative (2^(17+1) ^^^ 242) := by decide +kernel

theorem selectedBound53812 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env53813 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,80,8192,0,8541,8495,81,242,273,8540,81,477,16,50,8329,64,366,0,0,2341,337,16,256,341,81,512]

theorem envBound53813 : H12AffineFastState.Bounded env53813 := by
  intro p hp
  have h : env53813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53812_53813 : H12AffineEnvironment.transform 17 242 env53812 = env53813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 242 env53812 == env53813) = true)

theorem identity53813 : scanCanonicalize (H12AffineFastState.compose env53813 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 705) := by decide +kernel

theorem selectedBound53813 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env53814 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,80,705,0,924,1006,81,242,273,925,81,477,16,50,584,64,366,0,0,2341,337,16,256,341,81,512]

theorem envBound53814 : H12AffineFastState.Bounded env53814 := by
  intro p hp
  have h : env53814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53813_53814 : H12AffineEnvironment.transform 12 705 env53813 = env53814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 705 env53813 == env53814) = true)

theorem identity53814 : scanCanonicalize (H12AffineFastState.compose env53814 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound53814 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env53815 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,1,656,0,924,959,0,163,273,925,0,396,16,50,537,17,319,0,0,2341,256,16,256,260,0,512]

theorem envBound53815 : H12AffineFastState.Bounded env53815 := by
  intro p hp
  have h : env53815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53814_53815 : H12AffineEnvironment.transform 5 17 env53814 = env53815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53814 == env53815) = true)

theorem identity53815 : scanCanonicalize (H12AffineFastState.compose env53815 (packedSelected [1,3,13] rootPS)) = affineNative (2^(10+1) ^^^ 319) := by decide +kernel

theorem selectedBound53815 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env53816 : List Nat := [2,4,8,16,32,17,128,256,512,272,319,1,656,0,924,959,0,163,273,925,0,396,16,50,537,17,319,0,0,26,256,16,256,260,0,512]

theorem envBound53816 : H12AffineFastState.Bounded env53816 := by
  intro p hp
  have h : env53816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53815_53816 : H12AffineEnvironment.transform 10 319 env53815 = env53816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 319 env53815 == env53816) = true)

theorem identity53816 : scanCanonicalize (H12AffineFastState.compose env53816 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound53816 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env53817 : List Nat := [2,4,8,16,32,17,128,172,512,188,147,1,656,0,560,531,0,163,189,561,0,32,16,50,537,17,147,0,0,26,172,16,172,168,0,512]

theorem envBound53817 : H12AffineFastState.Bounded env53817 := by
  intro p hp
  have h : env53817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53816_53817 : H12AffineEnvironment.transform 7 172 env53816 = env53817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env53816 == env53817) = true)

theorem identity53817 : scanCanonicalize (H12AffineFastState.compose env53817 (packedSelected [1,2,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound53817 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env53818 : List Nat := [2,4,8,11,32,10,128,172,512,167,136,1,651,0,555,520,0,163,166,554,0,32,11,41,514,10,136,0,0,1,172,11,172,168,0,512]

theorem envBound53818 : H12AffineFastState.Bounded env53818 := by
  intro p hp
  have h : env53818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53817_53818 : H12AffineEnvironment.transform 3 11 env53817 = env53818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env53817 == env53818) = true)

theorem identity53818 : scanCanonicalize (H12AffineFastState.compose env53818 (packedSelected [0,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound53818 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env53819 : List Nat := [2,4,8,11,32,10,128,172,0,167,136,1,139,0,43,8,0,163,166,42,0,32,11,41,2,10,136,0,0,1,172,11,172,168,0,0]

theorem envBound53819 : H12AffineFastState.Bounded env53819 := by
  intro p hp
  have h : env53819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53818_53819 : H12AffineEnvironment.transform 8 0 env53818 = env53819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env53818 == env53819) = true)

theorem identity53819 : scanCanonicalize (H12AffineFastState.compose env53819 (packedSelected [0,1,2] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound53819 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env53820 : List Nat := [2,4,8,11,32,10,34,14,0,5,42,1,41,0,43,8,0,1,4,42,0,32,11,41,2,10,42,0,0,1,14,11,14,10,0,0]

theorem envBound53820 : H12AffineFastState.Bounded env53820 := by
  intro p hp
  have h : env53820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53819_53820 : H12AffineEnvironment.transform 6 34 env53819 = env53820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env53819 == env53820) = true)

theorem identity53820 : scanCanonicalize (H12AffineFastState.compose env53820 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound53820 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53821 : List Nat := [2,4,8,11,6,10,4,14,0,5,12,1,15,0,13,8,0,1,4,12,0,6,11,15,2,10,12,0,0,1,14,11,14,10,0,0]

theorem envBound53821 : H12AffineFastState.Bounded env53821 := by
  intro p hp
  have h : env53821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53820_53821 : H12AffineEnvironment.transform 4 6 env53820 = env53821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env53820 == env53821) = true)

theorem identity53821 : scanCanonicalize (H12AffineFastState.compose env53821 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound53821 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53822 : List Nat := [2,4,4,7,6,6,4,2,0,5,0,1,3,0,1,4,0,1,4,0,0,6,7,3,2,6,0,0,0,1,2,7,2,6,0,0]

theorem envBound53822 : H12AffineFastState.Bounded env53822 := by
  intro p hp
  have h : env53822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53821_53822 : H12AffineEnvironment.transform 2 4 env53821 = env53822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env53821 == env53822) = true)

def env53823 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32882,1345,262144,42333,32769,1344,41089,16,263633,33237,41244,42274,1296,42061,43129,262562,42077,256,303355,1345,41820]

theorem envBound53823 : H12AffineFastState.Bounded env53823 := by
  intro p hp
  have h : env53823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53809_53823 : H12AffineEnvironment.transform 11 1345 env53809 = env53823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env53809 == env53823) = true)

theorem identity53823 : scanCanonicalize (H12AffineFastState.compose env53823 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 9407) := by decide +kernel

theorem selectedBound53823 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env53824 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32882,1345,9407,42333,32769,1344,41089,16,8558,33237,41244,42274,1296,42061,43129,9501,42077,256,33860,1345,41820]

theorem envBound53824 : H12AffineFastState.Bounded env53824 := by
  intro p hp
  have h : env53824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53823_53824 : H12AffineEnvironment.transform 17 9407 env53823 = env53824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 9407 env53823 == env53824) = true)

theorem identity53824 : scanCanonicalize (H12AffineFastState.compose env53824 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 3662) := by decide +kernel

theorem selectedBound53824 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env53825 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,3662,3644,1345,9407,11027,3663,1344,11983,16,8558,3995,12114,11116,1296,10755,9783,9501,10771,256,2570,1345,11538]

theorem envBound53825 : H12AffineFastState.Bounded env53825 := by
  intro p hp
  have h : env53825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53824_53825 : H12AffineEnvironment.transform 14 3662 env53824 = env53825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3662 env53824 == env53825) = true)

def env53826 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1344,262144,77935,32769,4097,46529,16,266385,70887,78894,77841,1296,74815,81227,365712,74799,256,308667,1345,79470]

theorem envBound53826 : H12AffineFastState.Bounded env53826 := by
  intro p hp
  have h : env53826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53807_53826 : H12AffineEnvironment.transform 13 1297 env53807 = env53826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env53807 == env53826) = true)

theorem identity53826 : scanCanonicalize (H12AffineFastState.compose env53826 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound53826 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env53827 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1344,262144,77935,13341,4097,477,16,266385,70887,78894,77841,1296,74815,81227,336012,74799,256,262567,1345,79470]

theorem envBound53827 : H12AffineFastState.Bounded env53827 := by
  intro p hp
  have h : env53827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53826_53827 : H12AffineEnvironment.transform 14 13340 env53826 = env53827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env53826 == env53827) = true)

def env53828 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1344,65664,77935,13341,4097,477,16,69649,70887,78894,77841,1296,74815,81227,8204,74799,256,65831,1345,79470]

theorem envBound53828 : H12AffineFastState.Bounded env53828 := by
  intro p hp
  have h : env53828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53827_53828 : H12AffineEnvironment.transform 17 65664 env53827 = env53828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env53827 == env53828) = true)

theorem identity53828 : scanCanonicalize (H12AffineFastState.compose env53828 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound53828 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env53829 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,25,1297,5125,65536,1344,65664,69750,5124,4097,477,16,69649,70887,70711,69640,1296,66598,73042,21,66614,256,65831,1345,71287]

theorem envBound53829 : H12AffineFastState.Bounded env53829 := by
  intro p hp
  have h : env53829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53828_53829 : H12AffineEnvironment.transform 12 25 env53828 = env53829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env53828 == env53829) = true)

def env53830 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,25,1297,5125,65536,1296,65664,69670,5124,4097,397,16,69649,70839,70711,69640,1296,66598,72962,21,66614,256,65831,1297,71207]

theorem envBound53830 : H12AffineFastState.Bounded env53830 := by
  intro p hp
  have h : env53830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53829_53830 : H12AffineEnvironment.transform 5 16 env53829 = env53830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env53829 == env53830) = true)

theorem identity53830 : scanCanonicalize (H12AffineFastState.compose env53830 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound53830 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env53831 : List Nat := [2,4,8,16,32,16,128,21,512,1024,2048,4096,25,1028,5125,65536,1029,65664,69670,5124,4097,152,16,69649,70839,70711,69640,1029,66598,72727,21,66614,21,65586,1028,71207]

theorem envBound53831 : H12AffineFastState.Bounded env53831 := by
  intro p hp
  have h : env53831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53830_53831 : H12AffineEnvironment.transform 7 21 env53830 = env53831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env53830 == env53831) = true)

def env53832 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,25,1297,5125,65536,1297,65664,69671,5124,4097,396,16,69649,70838,70711,69640,1296,66598,72963,21,66614,256,65831,1296,71206]

theorem envBound53832 : H12AffineFastState.Bounded env53832 := by
  intro p hp
  have h : env53832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53829_53832 : H12AffineEnvironment.transform 5 17 env53829 = env53832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53829 == env53832) = true)

theorem identity53832 : scanCanonicalize (H12AffineFastState.compose env53832 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 5426) := by decide +kernel

theorem selectedBound53832 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env53833 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,25,1297,5125,5426,1297,5554,1301,5124,4097,396,16,1315,388,261,1338,1296,4372,2097,21,4356,256,5141,1296,788]

theorem envBound53833 : H12AffineFastState.Bounded env53833 := by
  intro p hp
  have h : env53833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53832_53833 : H12AffineEnvironment.transform 15 5426 env53832 = env53833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5426 env53832 == env53833) = true)

theorem identity53833 : scanCanonicalize (H12AffineFastState.compose env53833 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound53833 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env53834 : List Nat := [2,4,8,16,32,17,128,20,512,1024,2048,4096,25,1029,5125,5158,1029,5286,1025,5124,4097,152,16,1079,144,17,1070,1028,4096,2097,21,4112,20,5141,1028,512]

theorem envBound53834 : H12AffineFastState.Bounded env53834 := by
  intro p hp
  have h : env53834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53833_53834 : H12AffineEnvironment.transform 7 20 env53833 = env53834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env53833 == env53834) = true)

theorem identity53834 : scanCanonicalize (H12AffineFastState.compose env53834 (packedSelected [2,13,17] rootPS)) = affineNative (2^(11+1) ^^^ 2697) := by decide +kernel

theorem selectedBound53834 : packedSelected [2,13,17] rootPS < 2^1333 := by decide +kernel

def env53835 : List Nat := [2,4,8,16,32,17,128,20,512,1024,2048,2697,25,1029,3724,3759,1029,3631,1025,3725,2696,152,16,1079,144,17,1070,1028,2697,2097,21,2713,20,3740,1028,512]

theorem envBound53835 : H12AffineFastState.Bounded env53835 := by
  intro p hp
  have h : env53835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53834_53835 : H12AffineEnvironment.transform 11 2697 env53834 = env53835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2697 env53834 == env53835) = true)

theorem identity53835 : scanCanonicalize (H12AffineFastState.compose env53835 (packedSelected [2,3,5,10,11,18] rootPS)) = affineNative (2^(10+1) ^^^ 146) := by decide +kernel

theorem selectedBound53835 : packedSelected [2,3,5,10,11,18] rootPS < 2^1333 := by decide +kernel

def env53836 : List Nat := [2,4,8,16,32,17,128,20,512,1024,146,539,25,1029,1566,1597,1029,1725,1025,1567,538,152,16,1079,144,17,1070,1028,539,163,21,523,20,1550,1028,512]

theorem envBound53836 : H12AffineFastState.Bounded env53836 := by
  intro p hp
  have h : env53836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53835_53836 : H12AffineEnvironment.transform 10 146 env53835 = env53836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 146 env53835 == env53836) = true)

theorem identity53836 : scanCanonicalize (H12AffineFastState.compose env53836 (packedSelected [0,2,3,5,7,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound53836 : packedSelected [0,2,3,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env53837 : List Nat := [2,4,8,16,32,17,8,20,512,1024,26,539,25,1029,1566,1597,1029,1589,1025,1567,538,16,16,1079,24,17,1070,1028,539,43,21,523,20,1550,1028,512]

theorem envBound53837 : H12AffineFastState.Bounded env53837 := by
  intro p hp
  have h : env53837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53836_53837 : H12AffineEnvironment.transform 6 8 env53836 = env53837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env53836 == env53837) = true)

theorem identity53837 : scanCanonicalize (H12AffineFastState.compose env53837 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 559) := by decide +kernel

theorem selectedBound53837 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env53838 : List Nat := [2,4,8,16,32,17,8,20,512,559,26,539,25,554,49,18,554,26,558,48,538,16,16,536,24,17,513,555,539,43,21,523,20,33,555,512]

theorem envBound53838 : H12AffineFastState.Bounded env53838 := by
  intro p hp
  have h : env53838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53837_53838 : H12AffineEnvironment.transform 9 559 env53837 = env53838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 559 env53837 == env53838) = true)

theorem identity53838 : scanCanonicalize (H12AffineFastState.compose env53838 (packedSelected [0,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound53838 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env53839 : List Nat := [2,4,8,16,17,17,8,20,512,542,26,539,25,539,0,18,539,26,543,1,538,16,16,536,24,17,513,538,539,26,21,523,20,16,538,512]

theorem envBound53839 : H12AffineFastState.Bounded env53839 := by
  intro p hp
  have h : env53839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53838_53839 : H12AffineEnvironment.transform 4 17 env53838 = env53839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env53838 == env53839) = true)

def env53840 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1344,65665,77935,13341,4097,477,16,69648,70887,78894,77841,1296,74815,81227,8205,74799,256,65830,1345,79470]

theorem envBound53840 : H12AffineFastState.Bounded env53840 := by
  intro p hp
  have h : env53840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53827_53840 : H12AffineEnvironment.transform 17 65665 env53827 = env53840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env53827 == env53840) = true)

theorem identity53840 : scanCanonicalize (H12AffineFastState.compose env53840 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5464) := by decide +kernel

theorem selectedBound53840 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env53841 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5464,1297,324,65536,1344,65665,66871,325,4097,477,16,69648,70887,65910,66889,1296,69991,67603,5461,70007,256,65830,1345,66358]

theorem envBound53841 : H12AffineFastState.Bounded env53841 := by
  intro p hp
  have h : env53841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53840_53841 : H12AffineEnvironment.transform 12 5464 env53840 = env53841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5464 env53840 == env53841) = true)

def env53842 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5384,1297,276,65536,1296,65665,66871,277,4097,397,16,69648,70839,65830,66841,1296,69943,67603,5381,69927,256,65830,1297,66358]

theorem envBound53842 : H12AffineFastState.Bounded env53842 := by
  intro p hp
  have h : env53842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53841_53842 : H12AffineEnvironment.transform 5 16 env53841 = env53842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env53841 == env53842) = true)

theorem identity53842 : scanCanonicalize (H12AffineFastState.compose env53842 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound53842 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env53843 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1029,269,1297,276,65536,1296,65665,66871,277,1028,397,16,66581,65714,65830,66841,1296,66866,67603,256,66850,256,65830,1297,66358]

theorem envBound53843 : H12AffineFastState.Bounded env53843 := by
  intro p hp
  have h : env53843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53842_53843 : H12AffineEnvironment.transform 11 1029 env53842 = env53843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env53842 == env53843) = true)

theorem identity53843 : scanCanonicalize (H12AffineFastState.compose env53843 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 311) := by decide +kernel

theorem selectedBound53843 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env53844 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1029,269,1297,276,311,1296,438,1024,277,1028,397,16,1314,389,17,1070,1296,1029,2340,256,1045,256,17,1297,513]

theorem envBound53844 : H12AffineFastState.Bounded env53844 := by
  intro p hp
  have h : env53844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53843_53844 : H12AffineEnvironment.transform 15 311 env53843 = env53844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 311 env53843 == env53844) = true)

theorem identity53844 : scanCanonicalize (H12AffineFastState.compose env53844 (packedSelected [2,13,17] rootPS)) = affineNative (2^(10+1) ^^^ 950) := by decide +kernel

theorem selectedBound53844 : packedSelected [2,13,17] rootPS < 2^1333 := by decide +kernel

def env53845 : List Nat := [2,4,8,16,32,16,128,256,512,1024,950,1029,269,1297,276,311,1296,438,1024,277,1028,397,16,1314,389,17,1070,1296,1029,658,256,1045,256,17,1297,513]

theorem envBound53845 : H12AffineFastState.Bounded env53845 := by
  intro p hp
  have h : env53845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53844_53845 : H12AffineEnvironment.transform 10 950 env53844 = env53845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 950 env53844 == env53845) = true)

theorem identity53845 : scanCanonicalize (H12AffineFastState.compose env53845 (packedSelected [1,5,10,13] rootPS)) = affineNative (2^(9+1) ^^^ 549) := by decide +kernel

theorem selectedBound53845 : packedSelected [1,5,10,13] rootPS < 2^1333 := by decide +kernel

def env53846 : List Nat := [2,4,8,16,32,16,128,256,512,549,950,544,269,820,276,311,821,438,549,277,545,397,16,775,389,17,523,821,544,658,256,560,256,17,820,513]

theorem envBound53846 : H12AffineFastState.Bounded env53846 := by
  intro p hp
  have h : env53846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53845_53846 : H12AffineEnvironment.transform 9 549 env53845 = env53846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 549 env53845 == env53846) = true)

theorem identity53846 : scanCanonicalize (H12AffineFastState.compose env53846 (packedSelected [0,2,7,8,10,11,12,15] rootPS)) = affineNative (2^(8+1) ^^^ 313) := by decide +kernel

theorem selectedBound53846 : packedSelected [0,2,7,8,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env53847 : List Nat := [2,4,8,16,32,16,128,256,313,284,143,281,269,13,276,311,12,438,284,277,280,397,16,62,389,17,306,12,281,427,256,265,256,17,13,312]

theorem envBound53847 : H12AffineFastState.Bounded env53847 := by
  intro p hp
  have h : env53847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53846_53847 : H12AffineEnvironment.transform 8 313 env53846 = env53847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 313 env53846 == env53847) = true)

theorem identity53847 : scanCanonicalize (H12AffineFastState.compose env53847 (packedSelected [2,3,5,10,11,18] rootPS)) = affineNative (2^(7+1) ^^^ 160) := by decide +kernel

theorem selectedBound53847 : packedSelected [2,3,5,10,11,18] rootPS < 2^1333 := by decide +kernel

def env53848 : List Nat := [2,4,8,16,32,16,128,160,153,188,143,185,173,13,180,151,12,22,188,181,184,45,16,62,37,17,146,12,185,11,160,169,160,17,13,152]

theorem envBound53848 : H12AffineFastState.Bounded env53848 := by
  intro p hp
  have h : env53848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53847_53848 : H12AffineEnvironment.transform 7 160 env53847 = env53848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 160 env53847 == env53848) = true)

theorem identity53848 : scanCanonicalize (H12AffineFastState.compose env53848 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound53848 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53849 : List Nat := [2,4,8,16,32,16,40,8,49,20,39,17,5,13,28,63,12,22,20,29,16,45,16,62,37,17,58,12,17,11,8,1,8,17,13,48]

theorem envBound53849 : H12AffineFastState.Bounded env53849 := by
  intro p hp
  have h : env53849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53848_53849 : H12AffineEnvironment.transform 6 40 env53848 = env53849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env53848 == env53849) = true)

theorem identity53849 : scanCanonicalize (H12AffineFastState.compose env53849 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound53849 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env53850 : List Nat := [2,4,8,16,7,16,15,8,22,20,0,17,5,13,28,24,12,22,20,29,16,10,16,25,2,17,29,12,17,11,8,1,8,17,13,23]

theorem envBound53850 : H12AffineFastState.Bounded env53850 := by
  intro p hp
  have h : env53850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53849_53850 : H12AffineEnvironment.transform 4 7 env53849 = env53850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env53849 == env53850) = true)

theorem identity53850 : scanCanonicalize (H12AffineFastState.compose env53850 (packedSelected [0,1,3] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound53850 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env53851 : List Nat := [2,4,8,5,7,5,15,8,3,1,0,4,5,13,9,13,12,3,1,8,5,10,5,12,2,4,8,12,4,11,8,1,8,4,13,2]

theorem envBound53851 : H12AffineFastState.Bounded env53851 := by
  intro p hp
  have h : env53851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53850_53851 : H12AffineEnvironment.transform 3 5 env53850 = env53851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env53850 == env53851) = true)

theorem identity53851 : scanCanonicalize (H12AffineFastState.compose env53851 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound53851 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env53852 : List Nat := [2,4,4,5,7,5,3,4,3,1,0,4,5,1,5,1,0,3,1,4,5,6,5,0,2,4,4,0,4,7,4,1,4,4,1,2]

theorem envBound53852 : H12AffineFastState.Bounded env53852 := by
  intro p hp
  have h : env53852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53851_53852 : H12AffineEnvironment.transform 2 4 env53851 = env53852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env53851 == env53852) = true)

theorem identity53852 : scanCanonicalize (H12AffineFastState.compose env53852 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound53852 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53853 : List Nat := [0,4,4,5,5,5,1,4,1,1,0,4,5,1,5,1,0,1,1,4,5,4,5,0,0,4,4,0,4,5,4,1,4,4,1,0]

theorem envBound53853 : H12AffineFastState.Bounded env53853 := by
  intro p hp
  have h : env53853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53852_53853 : H12AffineEnvironment.transform 0 0 env53852 = env53853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env53852 == env53853) = true)

theorem identity53853 : scanCanonicalize (H12AffineFastState.compose env53853 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound53853 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env53854 : List Nat := [0,1,1,0,0,0,1,1,1,1,0,1,0,1,0,1,0,1,1,1,0,1,0,0,0,1,1,0,1,0,1,1,1,1,1,0]

theorem envBound53854 : H12AffineFastState.Bounded env53854 := by
  intro p hp
  have h : env53854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53853_53854 : H12AffineEnvironment.transform 1 1 env53853 = env53854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env53853 == env53854) = true)

def env53855 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,5385,1297,277,65536,1297,65665,66871,276,4097,396,16,69648,70838,65831,66840,1296,69942,67603,5380,69926,256,65830,1296,66358]

theorem envBound53855 : H12AffineFastState.Bounded env53855 := by
  intro p hp
  have h : env53855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53841_53855 : H12AffineEnvironment.transform 5 17 env53841 = env53855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53841 == env53855) = true)

theorem identity53855 : scanCanonicalize (H12AffineFastState.compose env53855 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 5427) := by decide +kernel

theorem selectedBound53855 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env53856 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,5385,1297,277,5427,1297,5554,4100,276,4097,396,16,1315,389,5140,4139,1296,1029,7456,5380,1045,256,5141,1296,5637]

theorem envBound53856 : H12AffineFastState.Bounded env53856 := by
  intro p hp
  have h : env53856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53855_53856 : H12AffineEnvironment.transform 15 5427 env53855 = env53856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5427 env53855 == env53856) = true)

theorem identity53856 : scanCanonicalize (H12AffineFastState.compose env53856 (packedSelected [2,3,10,23,24,26,32] rootPS)) = affineNative (2^(11+1) ^^^ 924) := by decide +kernel

theorem selectedBound53856 : packedSelected [2,3,10,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env53857 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,924,1685,1297,277,1711,1297,1582,920,276,925,396,16,1315,389,1928,951,1296,1029,3772,1688,1045,256,1929,1296,1433]

theorem envBound53857 : H12AffineFastState.Bounded env53857 := by
  intro p hp
  have h : env53857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53856_53857 : H12AffineEnvironment.transform 11 924 env53856 = env53857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 924 env53856 == env53857) = true)

theorem identity53857 : scanCanonicalize (H12AffineFastState.compose env53857 (packedSelected [0,4,5,7,9,13,18,23,26,28] rootPS)) = affineNative (2^(10+1) ^^^ 1971) := by decide +kernel

theorem selectedBound53857 : packedSelected [0,4,5,7,9,13,18,23,26,28] rootPS < 2^1333 := by decide +kernel

def env53858 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1971,924,1685,1297,277,1711,1297,1582,920,276,925,396,16,1315,389,1928,951,1296,1029,271,1688,1045,256,1929,1296,1433]

theorem envBound53858 : H12AffineFastState.Bounded env53858 := by
  intro p hp
  have h : env53858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53857_53858 : H12AffineEnvironment.transform 10 1971 env53857 = env53858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1971 env53857 == env53858) = true)

theorem identity53858 : scanCanonicalize (H12AffineFastState.compose env53858 (packedSelected [1,2,3,11,12,13,15,18,21] rootPS)) = affineNative (2^(9+1) ^^^ 424) := by decide +kernel

theorem selectedBound53858 : packedSelected [1,2,3,11,12,13,15,18,21] rootPS < 2^1333 := by decide +kernel

def env53859 : List Nat := [2,4,8,16,32,17,128,256,512,424,539,924,829,185,277,775,185,902,920,276,925,396,16,139,389,544,951,184,429,271,816,445,256,545,184,49]

theorem envBound53859 : H12AffineFastState.Bounded env53859 := by
  intro p hp
  have h : env53859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53858_53859 : H12AffineEnvironment.transform 9 424 env53858 = env53859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 424 env53858 == env53859) = true)

theorem identity53859 : scanCanonicalize (H12AffineFastState.compose env53859 (packedSelected [3,4,5,7,10,12] rootPS)) = affineNative (2^(8+1) ^^^ 429) := by decide +kernel

theorem selectedBound53859 : packedSelected [3,4,5,7,10,12] rootPS < 2^1333 := by decide +kernel

def env53860 : List Nat := [2,4,8,16,32,17,128,256,429,424,438,49,144,185,277,170,185,43,53,276,48,396,16,139,389,397,26,184,429,271,157,445,256,396,184,49]

theorem envBound53860 : H12AffineFastState.Bounded env53860 := by
  intro p hp
  have h : env53860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53859_53860 : H12AffineEnvironment.transform 8 429 env53859 = env53860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 429 env53859 == env53860) = true)

theorem identity53860 : scanCanonicalize (H12AffineFastState.compose env53860 (packedSelected [0,2,4,5,7,8,9,10] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound53860 : packedSelected [0,2,4,5,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env53861 : List Nat := [2,4,8,16,16,17,128,256,413,408,390,1,144,137,277,154,137,27,5,276,0,396,16,139,389,397,26,136,413,271,157,397,256,396,136,1]

theorem envBound53861 : H12AffineFastState.Bounded env53861 := by
  intro p hp
  have h : env53861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53860_53861 : H12AffineEnvironment.transform 4 16 env53860 = env53861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env53860 == env53861) = true)

theorem identity53861 : scanCanonicalize (H12AffineFastState.compose env53861 (packedSelected [1,3,5] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound53861 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env53862 : List Nat := [2,2,8,16,16,17,128,256,411,408,384,1,144,137,275,154,137,27,3,274,0,394,16,139,387,395,26,136,411,265,155,395,256,394,136,1]

theorem envBound53862 : H12AffineFastState.Bounded env53862 := by
  intro p hp
  have h : env53862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53861_53862 : H12AffineEnvironment.transform 1 2 env53861 = env53862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env53861 == env53862) = true)

theorem identity53862 : scanCanonicalize (H12AffineFastState.compose env53862 (packedSelected [4,7] rootPS)) = affineNative (2^(7+1) ^^^ 9) := by decide +kernel

theorem selectedBound53862 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env53863 : List Nat := [2,2,8,16,16,17,128,9,146,145,137,1,144,137,26,154,137,27,3,27,0,131,16,139,138,130,26,136,146,0,155,130,9,131,136,1]

theorem envBound53863 : H12AffineFastState.Bounded env53863 := by
  intro p hp
  have h : env53863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53862_53863 : H12AffineEnvironment.transform 7 9 env53862 = env53863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 9 env53862 == env53863) = true)

theorem identity53863 : scanCanonicalize (H12AffineFastState.compose env53863 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound53863 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53864 : List Nat := [2,2,8,16,16,17,18,9,0,3,27,1,2,27,26,8,27,27,3,27,0,17,16,25,24,16,26,26,0,0,9,16,9,17,26,1]

theorem envBound53864 : H12AffineFastState.Bounded env53864 := by
  intro p hp
  have h : env53864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53863_53864 : H12AffineEnvironment.transform 6 18 env53863 = env53864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env53863 == env53864) = true)

theorem identity53864 : scanCanonicalize (H12AffineFastState.compose env53864 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound53864 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53865 : List Nat := [2,2,0,16,16,17,18,1,0,3,19,1,2,19,18,0,19,19,3,19,0,17,16,17,16,16,18,18,0,0,1,16,1,17,18,1]

theorem envBound53865 : H12AffineFastState.Bounded env53865 := by
  intro p hp
  have h : env53865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53864_53865 : H12AffineEnvironment.transform 2 0 env53864 = env53865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env53864 == env53865) = true)

theorem identity53865 : scanCanonicalize (H12AffineFastState.compose env53865 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound53865 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53866 : List Nat := [2,2,0,3,3,2,1,1,0,3,0,1,2,0,1,0,0,0,3,0,0,2,3,2,3,3,1,1,0,0,1,3,1,2,1,1]

theorem envBound53866 : H12AffineFastState.Bounded env53866 := by
  intro p hp
  have h : env53866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53865_53866 : H12AffineEnvironment.transform 3 3 env53865 = env53866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env53865 == env53866) = true)

def env53867 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95614,32769,4097,61648,147521,284033,86518,209262,225345,148801,74815,96346,381312,74799,256,323755,1345,95103]

theorem envBound53867 : H12AffineFastState.Bounded env53867 := by
  intro p hp
  have h : env53867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53751_53867 : H12AffineEnvironment.transform 23 284033 env53751 = env53867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284033 env53751 == env53867) = true)

def env53868 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16464,262144,95614,32769,4097,61648,17,284033,86518,94526,77841,1297,74815,96346,381312,74799,256,323755,1345,95103]

theorem envBound53868 : H12AffineFastState.Bounded env53868 := by
  intro p hp
  have h : env53868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53867_53868 : H12AffineEnvironment.transform 16 16464 env53867 = env53868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16464 env53867 == env53868) = true)

def env53869 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1344,262144,77934,32769,4097,46528,17,266385,70886,78894,77841,1297,74815,81226,365712,74799,256,308667,1345,79471]

theorem envBound53869 : H12AffineFastState.Bounded env53869 := by
  intro p hp
  have h : env53869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53868_53869 : H12AffineEnvironment.transform 13 1296 env53868 = env53869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env53868 == env53869) = true)

theorem identity53869 : scanCanonicalize (H12AffineFastState.compose env53869 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound53869 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env53870 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1344,262144,77934,13341,4097,476,17,266385,70886,78894,77841,1297,74815,81226,336012,74799,256,262567,1345,79471]

theorem envBound53870 : H12AffineFastState.Bounded env53870 := by
  intro p hp
  have h : env53870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53869_53870 : H12AffineEnvironment.transform 14 13340 env53869 = env53870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env53869 == env53870) = true)

def env53871 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1344,65664,77934,13341,4097,476,17,69649,70886,78894,77841,1297,74815,81226,8204,74799,256,65831,1345,79471]

theorem envBound53871 : H12AffineFastState.Bounded env53871 := by
  intro p hp
  have h : env53871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53870_53871 : H12AffineEnvironment.transform 17 65664 env53870 = env53871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env53870 == env53871) = true)

theorem identity53871 : scanCanonicalize (H12AffineFastState.compose env53871 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12670) := by decide +kernel

theorem selectedBound53871 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env53872 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,12670,1344,12798,272,13341,4097,476,17,8559,9624,1360,367,1297,5441,3124,8204,5457,256,12377,1345,1809]

theorem envBound53872 : H12AffineFastState.Bounded env53872 := by
  intro p hp
  have h : env53872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53871_53872 : H12AffineEnvironment.transform 15 12670 env53871 = env53872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12670 env53871 == env53872) = true)

def env53873 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,80,12636,12670,0,12798,272,12637,4097,476,17,8559,8408,16,367,81,4097,2420,8204,4113,256,12377,1,593]

theorem envBound53873 : H12AffineFastState.Bounded env53873 := by
  intro p hp
  have h : env53873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53872_53873 : H12AffineEnvironment.transform 9 320 env53872 = env53873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env53872 == env53873) = true)

theorem identity53873 : scanCanonicalize (H12AffineFastState.compose env53873 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound53873 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env53874 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,269,80,4177,4211,0,4339,272,4176,4097,476,17,98,469,16,367,81,4097,2420,257,4113,256,4436,1,593]

theorem envBound53874 : H12AffineFastState.Bounded env53874 := by
  intro p hp
  have h : env53874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53873_53874 : H12AffineEnvironment.transform 12 269 env53873 = env53874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env53873 == env53874) = true)

theorem identity53874 : scanCanonicalize (H12AffineFastState.compose env53874 (packedSelected [2,3,10,13,21,23,24,26,32] rootPS)) = affineNative (2^(11+1) ^^^ 925) := by decide +kernel

theorem selectedBound53874 : packedSelected [2,3,10,13,21,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env53875 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,925,269,80,972,1006,0,878,272,973,924,476,17,98,469,16,367,81,924,2420,257,908,256,713,1,593]

theorem envBound53875 : H12AffineFastState.Bounded env53875 := by
  intro p hp
  have h : env53875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53874_53875 : H12AffineEnvironment.transform 11 925 env53874 = env53875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 925 env53874 == env53875) = true)

theorem identity53875 : scanCanonicalize (H12AffineFastState.compose env53875 (packedSelected [0,1,4,7,8,9,18,19,21,23,24,28] rootPS)) = affineNative (2^(10+1) ^^^ 999) := by decide +kernel

theorem selectedBound53875 : packedSelected [0,1,4,7,8,9,18,19,21,23,24,28] rootPS < 2^1333 := by decide +kernel

def env53876 : List Nat := [2,4,8,16,32,64,128,256,512,320,999,925,269,80,972,1006,0,878,272,973,924,476,17,98,469,16,367,81,924,659,257,908,256,713,1,593]

theorem envBound53876 : H12AffineFastState.Bounded env53876 := by
  intro p hp
  have h : env53876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53875_53876 : H12AffineEnvironment.transform 10 999 env53875 = env53876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 999 env53875 == env53876) = true)

theorem identity53876 : scanCanonicalize (H12AffineFastState.compose env53876 (packedSelected [0,1,2,4,7,8,9,11,13,17,18,19] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound53876 : packedSelected [0,1,2,4,7,8,9,11,13,17,18,19] rootPS < 2^1333 := by decide +kernel

def env53877 : List Nat := [2,4,8,16,32,64,105,256,512,320,782,884,269,80,805,775,0,878,272,804,885,309,17,98,316,16,367,81,885,634,257,869,256,544,1,593]

theorem envBound53877 : H12AffineFastState.Bounded env53877 := by
  intro p hp
  have h : env53877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53876_53877 : H12AffineEnvironment.transform 6 105 env53876 = env53877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env53876 == env53877) = true)

theorem identity53877 : scanCanonicalize (H12AffineFastState.compose env53877 (packedSelected [0,2,3,5,9,12,13] rootPS)) = affineNative (2^(8+1) ^^^ 122) := by decide +kernel

theorem selectedBound53877 : packedSelected [0,2,3,5,9,12,13] rootPS < 2^1333 := by decide +kernel

def env53878 : List Nat := [2,4,8,16,32,64,105,256,122,320,372,270,269,80,351,381,0,276,272,350,271,309,17,98,316,16,367,81,271,0,257,287,256,90,1,43]

theorem envBound53878 : H12AffineFastState.Bounded env53878 := by
  intro p hp
  have h : env53878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53877_53878 : H12AffineEnvironment.transform 8 122 env53877 = env53878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 122 env53877 == env53878) = true)

theorem identity53878 : scanCanonicalize (H12AffineFastState.compose env53878 (packedSelected [1,3,4,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound53878 : packedSelected [1,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env53879 : List Nat := [2,4,8,16,32,64,105,15,122,79,123,1,2,80,80,114,0,27,31,81,0,58,17,98,51,16,96,81,0,0,14,16,15,90,1,43]

theorem envBound53879 : H12AffineFastState.Bounded env53879 := by
  intro p hp
  have h : env53879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53878_53879 : H12AffineEnvironment.transform 7 15 env53878 = env53879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env53878 == env53879) = true)

theorem identity53879 : scanCanonicalize (H12AffineFastState.compose env53879 (packedSelected [1,3,4,9] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound53879 : packedSelected [1,3,4,9] rootPS < 2^1333 := by decide +kernel

def env53880 : List Nat := [2,4,8,16,32,11,34,15,49,4,48,1,2,27,27,57,0,27,31,26,0,58,17,41,51,16,43,26,0,0,14,16,15,17,1,43]

theorem envBound53880 : H12AffineFastState.Bounded env53880 := by
  intro p hp
  have h : env53880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53879_53880 : H12AffineEnvironment.transform 5 11 env53879 = env53880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env53879 == env53880) = true)

theorem identity53880 : scanCanonicalize (H12AffineFastState.compose env53880 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound53880 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env53881 : List Nat := [2,4,8,16,22,11,20,15,7,4,6,1,2,27,27,15,0,27,31,26,0,12,17,31,5,16,29,26,0,0,14,16,15,17,1,29]

theorem envBound53881 : H12AffineFastState.Bounded env53881 := by
  intro p hp
  have h : env53881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53880_53881 : H12AffineEnvironment.transform 4 22 env53880 = env53881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env53880 == env53881) = true)

theorem identity53881 : scanCanonicalize (H12AffineFastState.compose env53881 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound53881 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env53882 : List Nat := [2,4,8,10,12,11,14,15,7,4,6,1,2,1,1,15,0,1,5,0,0,12,11,5,5,10,7,0,0,0,14,10,15,11,1,7]

theorem envBound53882 : H12AffineFastState.Bounded env53882 := by
  intro p hp
  have h : env53882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53881_53882 : H12AffineEnvironment.transform 3 10 env53881 = env53882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env53881 == env53882) = true)

def env53883 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,81,12637,12670,1,12798,272,12636,4097,476,17,8559,8409,17,367,80,4096,2421,8204,4112,256,12377,0,592]

theorem envBound53883 : H12AffineFastState.Bounded env53883 := by
  intro p hp
  have h : env53883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53872_53883 : H12AffineEnvironment.transform 9 321 env53872 = env53883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env53872 == env53883) = true)

theorem identity53883 : scanCanonicalize (H12AffineFastState.compose env53883 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound53883 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env53884 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,348,81,4097,4130,1,4258,272,4096,4097,476,17,51,389,17,367,80,4096,2421,336,4112,256,4357,0,592]

theorem envBound53884 : H12AffineFastState.Bounded env53884 := by
  intro p hp
  have h : env53884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53883_53884 : H12AffineEnvironment.transform 12 348 env53883 = env53884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env53883 == env53884) = true)

theorem identity53884 : scanCanonicalize (H12AffineFastState.compose env53884 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound53884 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env53885 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,4096,269,0,4097,4130,1,4258,272,4096,4097,397,17,51,389,17,318,1,4096,2340,257,4112,256,4357,0,513]

theorem envBound53885 : H12AffineFastState.Bounded env53885 := by
  intro p hp
  have h : env53885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53884_53885 : H12AffineEnvironment.transform 5 17 env53884 = env53885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53884 == env53885) = true)

theorem identity53885 : scanCanonicalize (H12AffineFastState.compose env53885 (packedSelected [2,13,17] rootPS)) = affineNative (2^(10+1) ^^^ 674) := by decide +kernel

theorem selectedBound53885 : packedSelected [2,13,17] rootPS < 2^1333 := by decide +kernel

def env53886 : List Nat := [2,4,8,16,32,17,128,256,512,272,674,4096,269,0,4097,4130,1,4258,272,4096,4097,397,17,51,389,17,318,1,4096,902,257,4112,256,4357,0,513]

theorem envBound53886 : H12AffineFastState.Bounded env53886 := by
  intro p hp
  have h : env53886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53885_53886 : H12AffineEnvironment.transform 10 674 env53885 = env53886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 674 env53885 == env53886) = true)

theorem identity53886 : scanCanonicalize (H12AffineFastState.compose env53886 (packedSelected [1,3,13] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound53886 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env53887 : List Nat := [2,4,8,16,32,17,128,256,48,272,146,4096,269,0,4097,4130,1,4258,272,4096,4097,397,17,51,389,17,318,1,4096,438,257,4112,256,4357,0,49]

theorem envBound53887 : H12AffineFastState.Bounded env53887 := by
  intro p hp
  have h : env53887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53886_53887 : H12AffineEnvironment.transform 8 48 env53886 = env53887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env53886 == env53887) = true)

theorem identity53887 : scanCanonicalize (H12AffineFastState.compose env53887 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound53887 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env53888 : List Nat := [2,4,8,16,32,17,128,20,48,4,146,4096,25,0,4097,4130,1,4258,4,4096,4097,153,17,51,145,17,42,1,4096,162,21,4112,20,4113,0,49]

theorem envBound53888 : H12AffineFastState.Bounded env53888 := by
  intro p hp
  have h : env53888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53887_53888 : H12AffineEnvironment.transform 7 20 env53887 = env53888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env53887 == env53888) = true)

theorem identity53888 : scanCanonicalize (H12AffineFastState.compose env53888 (packedSelected [5] rootPS)) = affineNative (2^(6+1) ^^^ 21) := by decide +kernel

theorem selectedBound53888 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env53889 : List Nat := [2,4,8,16,32,17,21,20,48,4,7,4096,25,0,4097,4130,1,4151,4,4096,4097,12,17,51,4,17,42,1,4096,55,21,4112,20,4113,0,49]

theorem envBound53889 : H12AffineFastState.Bounded env53889 := by
  intro p hp
  have h : env53889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53888_53889 : H12AffineEnvironment.transform 6 21 env53888 = env53889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 21 env53888 == env53889) = true)

theorem identity53889 : scanCanonicalize (H12AffineFastState.compose env53889 (packedSelected [1,8] rootPS)) = affineNative (2^(11+1) ^^^ 29) := by decide +kernel

theorem selectedBound53889 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env53890 : List Nat := [2,4,8,16,32,17,21,20,48,4,7,29,25,0,28,63,1,42,4,29,28,12,17,51,4,17,42,1,29,55,21,13,20,12,0,49]

theorem envBound53890 : H12AffineFastState.Bounded env53890 := by
  intro p hp
  have h : env53890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53889_53890 : H12AffineEnvironment.transform 11 29 env53889 = env53890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 29 env53889 == env53890) = true)

theorem identity53890 : scanCanonicalize (H12AffineFastState.compose env53890 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound53890 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env53891 : List Nat := [2,4,8,16,23,17,21,20,7,4,7,29,25,0,28,8,1,29,4,29,28,12,17,4,4,17,29,1,29,0,21,13,20,12,0,6]

theorem envBound53891 : H12AffineFastState.Bounded env53891 := by
  intro p hp
  have h : env53891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53890_53891 : H12AffineEnvironment.transform 4 23 env53890 = env53891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env53890 == env53891) = true)

theorem identity53891 : scanCanonicalize (H12AffineFastState.compose env53891 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound53891 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53892 : List Nat := [2,4,8,11,12,10,14,15,7,4,7,6,2,0,7,8,1,6,4,6,7,12,10,4,4,10,6,1,6,0,14,13,15,12,0,6]

theorem envBound53892 : H12AffineFastState.Bounded env53892 := by
  intro p hp
  have h : env53892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53891_53892 : H12AffineEnvironment.transform 3 11 env53891 = env53892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env53891 == env53892) = true)

theorem identity53892 : scanCanonicalize (H12AffineFastState.compose env53892 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound53892 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53893 : List Nat := [2,4,0,3,4,2,6,7,7,4,7,6,2,0,7,0,1,6,4,6,7,4,2,4,4,2,6,1,6,0,6,5,7,4,0,6]

theorem envBound53893 : H12AffineFastState.Bounded env53893 := by
  intro p hp
  have h : env53893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53892_53893 : H12AffineEnvironment.transform 2 0 env53892 = env53893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env53892 == env53893) = true)

theorem identity53893 : scanCanonicalize (H12AffineFastState.compose env53893 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound53893 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53894 : List Nat := [2,3,0,3,3,2,1,0,0,3,0,1,2,0,0,0,1,1,3,1,0,3,2,3,3,2,1,1,1,0,1,2,0,3,0,1]

theorem envBound53894 : H12AffineFastState.Bounded env53894 := by
  intro p hp
  have h : env53894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53893_53894 : H12AffineEnvironment.transform 1 3 env53893 = env53894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env53893 == env53894) = true)

theorem identity53894 : scanCanonicalize (H12AffineFastState.compose env53894 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound53894 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env53895 : List Nat := [1,0,0,0,0,1,1,0,0,0,0,1,1,0,0,0,1,1,0,1,0,0,1,0,0,1,1,1,1,0,1,1,0,0,0,1]

theorem envBound53895 : H12AffineFastState.Bounded env53895 := by
  intro p hp
  have h : env53895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53894_53895 : H12AffineEnvironment.transform 0 1 env53894 = env53895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env53894 == env53895) = true)

def env53896 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1344,65665,77934,13341,4097,476,17,69648,70886,78894,77841,1297,74815,81226,8205,74799,256,65830,1345,79471]

theorem envBound53896 : H12AffineFastState.Bounded env53896 := by
  intro p hp
  have h : env53896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53870_53896 : H12AffineEnvironment.transform 17 65665 env53870 = env53896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env53870 == env53896) = true)

theorem identity53896 : scanCanonicalize (H12AffineFastState.compose env53896 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9279) := by decide +kernel

theorem selectedBound53896 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env53897 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,9279,1344,9406,5201,13341,4097,476,17,13359,12505,4113,5166,1297,0,6517,8205,16,256,9497,1345,4688]

theorem envBound53897 : H12AffineFastState.Bounded env53897 := by
  intro p hp
  have h : env53897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53896_53897 : H12AffineEnvironment.transform 15 9279 env53896 = env53897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9279 env53896 == env53897) = true)

def env53898 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1296,9244,9279,1344,9406,1105,9245,1,476,17,9263,8409,17,1070,1297,0,2421,8205,16,256,9497,1345,592]

theorem envBound53898 : H12AffineFastState.Bounded env53898 := by
  intro p hp
  have h : env53898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53897_53898 : H12AffineEnvironment.transform 11 0 env53897 = env53898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env53897 == env53898) = true)

theorem identity53898 : scanCanonicalize (H12AffineFastState.compose env53898 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound53898 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env53899 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,349,1296,1345,1378,1344,1507,1105,1344,1,476,17,1394,388,17,1070,1297,0,2421,336,16,256,1092,1345,592]

theorem envBound53899 : H12AffineFastState.Bounded env53899 := by
  intro p hp
  have h : env53899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53898_53899 : H12AffineEnvironment.transform 12 349 env53898 = env53899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env53898 == env53899) = true)

def env53900 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1296,9245,9279,1344,9406,1104,9244,0,476,17,9262,8408,16,1071,1297,0,2420,8205,16,256,9497,1345,593]

theorem envBound53900 : H12AffineFastState.Bounded env53900 := by
  intro p hp
  have h : env53900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53897_53900 : H12AffineEnvironment.transform 11 1 env53897 = env53900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env53897 == env53900) = true)

theorem identity53900 : scanCanonicalize (H12AffineFastState.compose env53900 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound53900 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env53901 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,268,1296,1297,1331,1344,1458,1104,1296,0,476,17,1314,468,16,1071,1297,0,2420,257,16,256,1045,1345,593]

theorem envBound53901 : H12AffineFastState.Bounded env53901 := by
  intro p hp
  have h : env53901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53900_53901 : H12AffineEnvironment.transform 12 268 env53900 = env53901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env53900 == env53901) = true)

theorem identity53901 : scanCanonicalize (H12AffineFastState.compose env53901 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound53901 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env53902 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1,268,1296,1297,1331,1297,1458,1025,1296,0,397,17,1314,389,16,1071,1297,0,2341,257,16,256,1045,1296,512]

theorem envBound53902 : H12AffineFastState.Bounded env53902 := by
  intro p hp
  have h : env53902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53901_53902 : H12AffineEnvironment.transform 5 17 env53901 = env53902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53901 == env53902) = true)

theorem identity53902 : scanCanonicalize (H12AffineFastState.compose env53902 (packedSelected [2,13,17] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound53902 : packedSelected [2,13,17] rootPS < 2^1333 := by decide +kernel

def env53903 : List Nat := [2,4,8,16,32,17,128,256,512,1024,512,1,268,1296,1297,1331,1297,1458,1025,1296,0,397,17,1314,389,16,1071,1297,0,805,257,16,256,1045,1296,512]

theorem envBound53903 : H12AffineFastState.Bounded env53903 := by
  intro p hp
  have h : env53903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53902_53903 : H12AffineEnvironment.transform 10 512 env53902 = env53903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env53902 == env53903) = true)

theorem identity53903 : scanCanonicalize (H12AffineFastState.compose env53903 (packedSelected [1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound53903 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env53904 : List Nat := [2,4,8,16,32,17,128,256,48,1024,48,1,268,1296,1297,1331,1297,1458,1025,1296,0,397,17,1314,389,16,1071,1297,0,277,257,16,256,1045,1296,48]

theorem envBound53904 : H12AffineFastState.Bounded env53904 := by
  intro p hp
  have h : env53904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53903_53904 : H12AffineEnvironment.transform 8 48 env53903 = env53904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env53903 == env53904) = true)

theorem identity53904 : scanCanonicalize (H12AffineFastState.compose env53904 (packedSelected [3,8,12] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound53904 : packedSelected [3,8,12] rootPS < 2^1333 := by decide +kernel

def env53905 : List Nat := [2,4,8,16,32,17,128,256,48,189,48,1,268,429,428,398,428,271,188,429,0,397,17,415,389,16,146,428,0,277,257,16,256,168,429,48]

theorem envBound53905 : H12AffineFastState.Bounded env53905 := by
  intro p hp
  have h : env53905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53904_53905 : H12AffineEnvironment.transform 9 189 env53904 = env53905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env53904 == env53905) = true)

theorem identity53905 : scanCanonicalize (H12AffineFastState.compose env53905 (packedSelected [0,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound53905 : packedSelected [0,8] rootPS < 2^1333 := by decide +kernel

def env53906 : List Nat := [2,4,8,16,32,17,128,36,48,189,48,1,40,137,136,170,136,43,188,137,0,169,17,187,161,16,146,136,0,49,37,16,36,168,137,48]

theorem envBound53906 : H12AffineFastState.Bounded env53906 := by
  intro p hp
  have h : env53906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53905_53906 : H12AffineEnvironment.transform 7 36 env53905 = env53906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env53905 == env53906) = true)

theorem identity53906 : scanCanonicalize (H12AffineFastState.compose env53906 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound53906 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env53907 : List Nat := [2,4,8,16,17,17,128,21,1,140,1,1,25,137,136,155,136,26,141,137,0,152,17,138,144,16,146,136,0,0,20,16,21,153,137,1]

theorem envBound53907 : H12AffineFastState.Bounded env53907 := by
  intro p hp
  have h : env53907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53906_53907 : H12AffineEnvironment.transform 4 17 env53906 = env53907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env53906 == env53907) = true)

def env53908 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1345,262144,77935,32769,4097,46529,17,266384,70887,78895,77841,1297,74815,81227,365713,74799,256,308666,1345,79470]

theorem envBound53908 : H12AffineFastState.Bounded env53908 := by
  intro p hp
  have h : env53908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53868_53908 : H12AffineEnvironment.transform 13 1297 env53868 = env53908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env53868 == env53908) = true)

theorem identity53908 : scanCanonicalize (H12AffineFastState.compose env53908 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32883) := by decide +kernel

theorem selectedBound53908 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env53909 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,32883,1345,262144,45084,32769,4097,46529,17,266384,38036,46172,45154,1297,42060,48440,267490,42076,256,308666,1345,46621]

theorem envBound53909 : H12AffineFastState.Bounded env53909 := by
  intro p hp
  have h : env53909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53908_53909 : H12AffineEnvironment.transform 15 32883 env53908 = env53909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32883 env53908 == env53909) = true)

def env53910 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32883,1345,262144,42332,32769,1345,41089,17,263632,33236,41244,42274,1297,42060,43128,262562,42076,256,303354,1345,41821]

theorem envBound53910 : H12AffineFastState.Bounded env53910 := by
  intro p hp
  have h : env53910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53909_53910 : H12AffineEnvironment.transform 11 1344 env53909 = env53910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env53909 == env53910) = true)

theorem identity53910 : scanCanonicalize (H12AffineFastState.compose env53910 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 325) := by decide +kernel

theorem selectedBound53910 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env53911 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,325,310,1345,262144,9241,324,1345,8644,17,263632,145,8281,9319,1297,9481,10557,262562,9497,256,270783,1345,8728]

theorem envBound53911 : H12AffineFastState.Bounded env53911 := by
  intro p hp
  have h : env53911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53910_53911 : H12AffineEnvironment.transform 14 325 env53910 = env53911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 325 env53910 == env53911) = true)

theorem identity53911 : scanCanonicalize (H12AffineFastState.compose env53911 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 11188) := by decide +kernel

theorem selectedBound53911 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env53912 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,325,310,1345,11188,9241,324,1345,8644,17,11876,145,8281,9319,1297,9481,10557,10774,9497,256,2571,1345,8728]

theorem envBound53912 : H12AffineFastState.Bounded env53912 := by
  intro p hp
  have h : env53912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53911_53912 : H12AffineEnvironment.transform 17 11188 env53911 = env53912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 11188 env53911 == env53912) = true)

def env53913 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32883,1345,262144,42333,32769,1344,41088,17,263633,33237,41245,42275,1297,42060,43129,262563,42076,256,303355,1345,41820]

theorem envBound53913 : H12AffineFastState.Bounded env53913 := by
  intro p hp
  have h : env53913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53909_53913 : H12AffineEnvironment.transform 11 1345 env53909 = env53913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env53909 == env53913) = true)

theorem identity53913 : scanCanonicalize (H12AffineFastState.compose env53913 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 438) := by decide +kernel

theorem selectedBound53913 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env53914 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32883,1345,438,42333,32769,1344,41088,17,1127,33237,41245,42275,1297,42060,43129,21,42076,256,41293,1345,41820]

theorem envBound53914 : H12AffineFastState.Bounded env53914 := by
  intro p hp
  have h : env53914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53913_53914 : H12AffineEnvironment.transform 17 438 env53913 = env53914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 438 env53913 == env53914) = true)

theorem identity53914 : scanCanonicalize (H12AffineFastState.compose env53914 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound53914 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env53915 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,8540,8495,1345,438,1025,8541,1344,476,17,1127,8329,65,1151,1297,1296,2341,21,1280,256,17,1345,512]

theorem envBound53915 : H12AffineFastState.Bounded env53915 := by
  intro p hp
  have h : env53915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53914_53915 : H12AffineEnvironment.transform 14 8540 env53914 = env53915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env53914 == env53915) = true)

theorem identity53915 : scanCanonicalize (H12AffineFastState.compose env53915 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound53915 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env53916 : List Nat := [2,4,8,16,32,64,128,68,512,1024,2048,1029,8192,1109,8216,8299,1029,242,1025,8217,1028,152,17,1127,8329,65,1151,1109,1108,2145,21,1092,68,17,1029,512]

theorem envBound53916 : H12AffineFastState.Bounded env53916 := by
  intro p hp
  have h : env53916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53915_53916 : H12AffineEnvironment.transform 7 68 env53915 = env53916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env53915 == env53916) = true)

theorem identity53916 : scanCanonicalize (H12AffineFastState.compose env53916 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1685) := by decide +kernel

theorem selectedBound53916 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env53917 : List Nat := [2,4,8,16,32,64,128,68,512,1024,2048,1029,1685,1109,1677,1790,1029,242,1025,1676,1028,152,17,1127,1564,65,1151,1109,1108,2145,21,1092,68,17,1029,512]

theorem envBound53917 : H12AffineFastState.Bounded env53917 := by
  intro p hp
  have h : env53917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53916_53917 : H12AffineEnvironment.transform 12 1685 env53916 = env53917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1685 env53916 == env53917) = true)

end H12CloudChart2