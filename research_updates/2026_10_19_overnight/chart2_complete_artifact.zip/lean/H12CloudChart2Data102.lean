import H12CloudChart2Data101

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans25019_25020 : H12AffineEnvironment.transform 24 8328 env25019 = env25020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8328 env25019 == env25020) = true)

theorem identity25020 : scanCanonicalize (H12AffineFastState.compose env25020 (packedSelected [6,25] rootPS)) = affineNative (2^(28+1) ^^^ 268570625) := by decide +kernel

theorem selectedBound25020 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env25021 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,268435456,268570625,1073741824,92374096,4294967296,525568,4315938987,34359738368,513]

theorem envBound25021 : H12AffineFastState.Bounded env25021 := by
  intro p hp
  have h : env25021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25020_25021 : H12AffineEnvironment.transform 28 268570625 env25020 = env25021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 268570625 env25020 == env25021) = true)

theorem identity25021 : scanCanonicalize (H12AffineFastState.compose env25021 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(31+1) ^^^ 1103764635) := by decide +kernel

theorem selectedBound25021 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env25022 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,268435456,268570625,1073741824,92374096,1103764635,525568,1082793008,34359738368,513]

theorem envBound25022 : H12AffineFastState.Bounded env25022 := by
  intro p hp
  have h : env25022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25021_25022 : H12AffineEnvironment.transform 31 1103764635 env25021 = env25022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1103764635 env25021 == env25022) = true)

theorem identity25022 : scanCanonicalize (H12AffineFastState.compose env25022 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(29+1) ^^^ 497309835) := by decide +kernel

theorem selectedBound25022 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env25023 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,268435456,268570625,497309835,92374096,476988432,525568,489571515,34359738368,513]

theorem envBound25023 : H12AffineFastState.Bounded env25023 := by
  intro p hp
  have h : env25023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25022_25023 : H12AffineEnvironment.transform 29 497309835 env25022 = env25023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 497309835 env25022 == env25023) = true)

theorem identity25023 : scanCanonicalize (H12AffineFastState.compose env25023 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(27+1) ^^^ 160302575) := by decide +kernel

theorem selectedBound25023 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env25024 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,160302575,160175598,69885284,92374096,98583039,525568,77611348,34359738368,513]

theorem envBound25024 : H12AffineFastState.Bounded env25024 := by
  intro p hp
  have h : env25024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25023_25024 : H12AffineEnvironment.transform 27 160302575 env25023 = env25024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 160302575 env25023 == env25024) = true)

theorem identity25024 : scanCanonicalize (H12AffineFastState.compose env25024 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(34+1) ^^^ 69341248) := by decide +kernel

theorem selectedBound25024 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env25025 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,160302575,160175598,69885284,92374096,98583039,525568,77611348,69341248,513]

theorem envBound25025 : H12AffineFastState.Bounded env25025 := by
  intro p hp
  have h : env25025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25024_25025 : H12AffineEnvironment.transform 34 69341248 env25024 = env25025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 69341248 env25024 == env25025) = true)

theorem identity25025 : scanCanonicalize (H12AffineFastState.compose env25025 (packedSelected [3,5,8,10,28,31] rootPS)) = affineNative (2^(26+1) ^^^ 21331968) := by decide +kernel

theorem selectedBound25025 : packedSelected [3,5,8,10,28,31] rootPS < 2^1333 := by decide +kernel

def env25026 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,21331968,13338095,13211118,69885284,92374096,98583039,525568,77611348,69341248,513]

theorem envBound25026 : H12AffineFastState.Bounded env25026 := by
  intro p hp
  have h : env25026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25025_25026 : H12AffineEnvironment.transform 26 21331968 env25025 = env25026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21331968 env25025 == env25026) = true)

theorem identity25026 : scanCanonicalize (H12AffineFastState.compose env25026 (packedSelected [13,17,21,33] rootPS)) = affineNative (2^(25+1) ^^^ 7067119) := by decide +kernel

theorem selectedBound25026 : packedSelected [13,17,21,33] rootPS < 2^1333 := by decide +kernel

def env25027 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,7067119,21331968,13338095,13211118,4294795,32133567,25924624,525568,13341883,4834735,513]

theorem envBound25027 : H12AffineFastState.Bounded env25027 := by
  intro p hp
  have h : env25027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25026_25027 : H12AffineEnvironment.transform 25 7067119 env25026 = env25027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 7067119 env25026 == env25027) = true)

theorem identity25027 : scanCanonicalize (H12AffineFastState.compose env25027 (packedSelected [0,3,5,7,10,12,13,20,38] rootPS)) = affineNative (2^(23+1) ^^^ 4292744) := by decide +kernel

theorem selectedBound25027 : packedSelected [0,3,5,7,10,12,13,20,38] rootPS < 2^1333 := by decide +kernel

def env25028 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,4292744,8328,7067119,262280,13338095,13211118,4294795,11260215,13243544,525568,13341883,4834735,513]

theorem envBound25028 : H12AffineFastState.Bounded env25028 := by
  intro p hp
  have h : env25028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25027_25028 : H12AffineEnvironment.transform 23 4292744 env25027 = env25028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4292744 env25027 == env25028) = true)

def env25029 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,540928,4292744,8328,7067119,262280,4441327,4314350,4294795,2330679,4347288,525568,4445627,4834735,513]

theorem envBound25029 : H12AffineFastState.Bounded env25029 := by
  intro p hp
  have h : env25029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25028_25029 : H12AffineEnvironment.transform 22 540928 env25028 = env25029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 540928 env25028 == env25029) = true)

def env25030 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,131072,262144,524288,32769,2097152,4194304,525328,4292744,8328,7049471,262280,4424191,4297214,4294795,2330679,4329608,525568,4427947,4817087,513]

theorem envBound25030 : H12AffineFastState.Bounded env25030 := by
  intro p hp
  have h : env25030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25029_25030 : H12AffineEnvironment.transform 13 1296 env25029 = env25030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env25029 == env25030) = true)

theorem identity25030 : scanCanonicalize (H12AffineFastState.compose env25030 (packedSelected [0,6,27] rootPS)) = affineNative (2^(18+1) ^^^ 132421) := by decide +kernel

theorem selectedBound25030 : packedSelected [0,6,27] rootPS < 2^1333 := by decide +kernel

def env25031 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,131072,262144,132421,32769,2097152,4194304,131413,4292744,8328,6395322,262280,4424191,4297214,4294795,2330679,4329608,131141,4427947,4425210,513]

theorem envBound25031 : H12AffineFastState.Bounded env25031 := by
  intro p hp
  have h : env25031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25030_25031 : H12AffineEnvironment.transform 18 132421 env25030 = env25031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 132421 env25030 == env25031) = true)

def env25032 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,131072,262144,132421,32769,2097152,2102664,131413,2200832,8328,98354,262280,2331767,2196598,2202883,2330679,2229504,131141,2327843,2330738,513]

theorem envBound25032 : H12AffineFastState.Bounded env25032 := by
  intro p hp
  have h : env25032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25031_25032 : H12AffineEnvironment.transform 21 2102664 env25031 = env25032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2102664 env25031 == env25032) = true)

theorem identity25032 : scanCanonicalize (H12AffineFastState.compose env25032 (packedSelected [0,7,14,20] rootPS)) = affineNative (2^(16+1) ^^^ 98615) := by decide +kernel

theorem selectedBound25032 : packedSelected [0,7,14,20] rootPS < 2^1333 := by decide +kernel

def env25033 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,98615,262144,99442,32769,2097152,2102664,98402,2200832,8328,98354,262280,2102592,2196598,2202883,2101504,2196535,98674,2098196,2101573,513]

theorem envBound25033 : H12AffineFastState.Bounded env25033 := by
  intro p hp
  have h : env25033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25032_25033 : H12AffineEnvironment.transform 16 98615 env25032 = env25033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 98615 env25032 == env25033) = true)

def env25034 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,98615,262144,99442,32769,5204,476,98402,98644,8328,98354,262280,276,102434,100695,1364,102499,98674,4160,1297,513]

theorem envBound25034 : H12AffineFastState.Bounded env25034 := by
  intro p hp
  have h : env25034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25033_25034 : H12AffineEnvironment.transform 20 5204 env25033 = env25034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5204 env25033 == env25034) = true)

theorem identity25034 : scanCanonicalize (H12AffineFastState.compose env25034 (packedSelected [14] rootPS)) = affineNative (2^(15+1) ^^^ 34083) := by decide +kernel

theorem selectedBound25034 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env25035 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,34083,1044,262144,337,32769,5204,476,1345,1143,8328,1297,262280,276,5377,3188,1364,5440,1105,4160,1297,513]

theorem envBound25035 : H12AffineFastState.Bounded env25035 := by
  intro p hp
  have h : env25035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25034_25035 : H12AffineEnvironment.transform 15 34083 env25034 = env25035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34083 env25034 == env25035) = true)

theorem identity25035 : scanCanonicalize (H12AffineFastState.compose env25035 (packedSelected [3,5,10,12,13,15] rootPS)) = affineNative (2^(17+1) ^^^ 44245) := by decide +kernel

theorem selectedBound25035 : packedSelected [3,5,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env25036 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,34083,1044,44245,337,32769,5204,476,1345,1143,8328,1297,44125,276,5377,3188,1364,5440,1105,4160,1297,513]

theorem envBound25036 : H12AffineFastState.Bounded env25036 := by
  intro p hp
  have h : env25036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25035_25036 : H12AffineEnvironment.transform 17 44245 env25035 = env25036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 44245 env25035 == env25036) = true)

theorem identity25036 : scanCanonicalize (H12AffineFastState.compose env25036 (packedSelected [3,5,10,12] rootPS)) = affineNative (2^(9+1) ^^^ 116) := by decide +kernel

theorem selectedBound25036 : packedSelected [3,5,10,12] rootPS < 2^1333 := by decide +kernel

def env25037 : List Nat := [2,4,8,16,32,64,128,256,512,116,2048,4096,8192,356,32768,33111,96,43169,337,32769,4128,476,309,3,8328,357,43049,276,4469,2048,288,4404,37,4160,357,513]

theorem envBound25037 : H12AffineFastState.Bounded env25037 := by
  intro p hp
  have h : env25037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25036_25037 : H12AffineEnvironment.transform 9 116 env25036 = env25037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 116 env25036 == env25037) = true)

theorem identity25037 : scanCanonicalize (H12AffineFastState.compose env25037 (packedSelected [0,2,4,11] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound25037 : packedSelected [0,2,4,11] rootPS < 2^1333 := by decide +kernel

def env25038 : List Nat := [2,4,8,16,32,64,8,256,512,116,2048,4096,8192,356,32768,33111,96,43049,337,32769,4128,340,309,3,8192,357,43049,276,4469,2048,288,4404,37,4160,357,513]

theorem envBound25038 : H12AffineFastState.Bounded env25038 := by
  intro p hp
  have h : env25038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25037_25038 : H12AffineEnvironment.transform 6 8 env25037 = env25038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env25037 == env25038) = true)

def env25039 : List Nat := [2,4,8,16,32,64,8,256,512,116,2048,96,8192,356,32768,33111,96,43049,337,32769,64,340,309,3,8192,357,43049,276,277,2048,288,340,37,32,357,513]

theorem envBound25039 : H12AffineFastState.Bounded env25039 := by
  intro p hp
  have h : env25039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25038_25039 : H12AffineEnvironment.transform 11 96 env25038 = env25039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 96 env25038 == env25039) = true)

theorem identity25039 : scanCanonicalize (H12AffineFastState.compose env25039 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound25039 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25040 : List Nat := [2,4,8,16,32,64,8,256,32,116,2048,96,8192,356,32768,33111,96,43049,337,32769,64,340,309,3,8192,357,43049,276,277,2048,288,340,37,32,357,33]

theorem envBound25040 : H12AffineFastState.Bounded env25040 := by
  intro p hp
  have h : env25040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25039_25040 : H12AffineEnvironment.transform 8 32 env25039 = env25040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env25039 == env25040) = true)

theorem identity25040 : scanCanonicalize (H12AffineFastState.compose env25040 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 8216) := by decide +kernel

theorem selectedBound25040 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env25041 : List Nat := [2,4,8,16,32,64,8,256,32,116,2048,96,8192,356,8216,8527,96,2097,337,8217,64,340,309,3,8192,357,2097,276,277,2048,288,340,37,32,357,33]

theorem envBound25041 : H12AffineFastState.Bounded env25041 := by
  intro p hp
  have h : env25041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25040_25041 : H12AffineEnvironment.transform 14 8216 env25040 = env25041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8216 env25040 == env25041) = true)

theorem identity25041 : scanCanonicalize (H12AffineFastState.compose env25041 (packedSelected [0,1,5] rootPS)) = affineNative (2^(12+1) ^^^ 2120) := by decide +kernel

theorem selectedBound25041 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env25042 : List Nat := [2,4,8,16,32,64,8,256,32,116,2048,96,2120,356,2128,2311,96,2097,337,2129,64,340,309,3,2120,357,2097,276,277,2048,288,340,37,32,357,33]

theorem envBound25042 : H12AffineFastState.Bounded env25042 := by
  intro p hp
  have h : env25042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25041_25042 : H12AffineEnvironment.transform 12 2120 env25041 = env25042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2120 env25041 == env25042) = true)

def env25043 : List Nat := [2,4,8,16,16,64,8,256,16,68,2048,80,2120,340,2128,2311,80,2049,337,2129,64,340,261,3,2120,341,2049,276,277,2048,272,340,21,16,341,17]

theorem envBound25043 : H12AffineFastState.Bounded env25043 := by
  intro p hp
  have h : env25043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25042_25043 : H12AffineEnvironment.transform 4 16 env25042 = env25043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env25042 == env25043) = true)

theorem identity25043 : scanCanonicalize (H12AffineFastState.compose env25043 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound25043 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25044 : List Nat := [2,4,8,0,0,64,8,256,0,68,2048,64,2120,324,2112,2311,64,2049,321,2113,64,324,261,3,2120,325,2049,260,261,2048,256,324,5,0,325,1]

theorem envBound25044 : H12AffineFastState.Bounded env25044 := by
  intro p hp
  have h : env25044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25043_25044 : H12AffineEnvironment.transform 3 0 env25043 = env25044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env25043 == env25044) = true)

def env25045 : List Nat := [2,4,8,0,0,64,8,256,0,68,64,64,8,324,0,327,64,65,321,1,64,324,261,3,8,325,65,260,261,64,256,324,5,0,325,1]

theorem envBound25045 : H12AffineFastState.Bounded env25045 := by
  intro p hp
  have h : env25045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25044_25045 : H12AffineEnvironment.transform 10 64 env25044 = env25045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 64 env25044 == env25045) = true)

theorem identity25045 : scanCanonicalize (H12AffineFastState.compose env25045 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 74) := by decide +kernel

theorem selectedBound25045 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25046 : List Nat := [2,4,8,0,0,64,8,74,0,68,64,64,8,14,0,13,64,65,11,1,64,14,79,3,8,15,65,78,79,64,74,14,5,0,15,1]

theorem envBound25046 : H12AffineFastState.Bounded env25046 := by
  intro p hp
  have h : env25046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25045_25046 : H12AffineEnvironment.transform 7 74 env25045 = env25046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 74 env25045 == env25046) = true)

def leafEnv25046 : List Nat := [2,4,8,0,0,64,8,74,0,68,64,64,8,14,0,13,64,65,11,1,64,14,79,3,4,8,1,15,65,78,79,64,74,14,5,0,74,12,15,1,0,64,1]

def active25046 : List Nat := [0,1,2,5]

def tree25046 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25046 : H12WitnessSearch.Good tree25046 := H12GlobalWitnessIndex.good

theorem leafIdentity25046 : H12AffineFastState.composeSystem env25046 rootObs = leafEnv25046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25046 rootObs == leafEnv25046) = true)

theorem terminalChecked25046 : H12PackedTerminal.terminalCheckFast leafEnv25046 active25046 tree25046 = true := by decide +kernel

def env25047 : List Nat := [2,4,8,0,0,64,8,256,0,68,65,64,9,324,1,326,64,64,321,0,64,324,261,3,9,325,64,260,261,65,256,324,5,0,325,1]

theorem envBound25047 : H12AffineFastState.Bounded env25047 := by
  intro p hp
  have h : env25047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25044_25047 : H12AffineEnvironment.transform 10 65 env25044 = env25047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 65 env25044 == env25047) = true)

theorem identity25047 : scanCanonicalize (H12AffineFastState.compose env25047 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound25047 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25048 : List Nat := [2,4,6,0,0,64,6,256,0,68,65,64,7,324,1,326,64,64,321,0,64,324,261,3,7,325,64,260,261,65,256,324,5,0,325,1]

theorem envBound25048 : H12AffineFastState.Bounded env25048 := by
  intro p hp
  have h : env25048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25047_25048 : H12AffineEnvironment.transform 2 6 env25047 = env25048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env25047 == env25048) = true)

def leafEnv25048 : List Nat := [2,4,6,0,0,64,6,256,0,68,65,64,7,324,1,326,64,64,321,0,64,324,261,3,4,7,1,325,64,260,261,65,256,324,5,0,256,327,325,1,0,64,1]

def active25048 : List Nat := [0,1,5,7]

def tree25048 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25048 : H12WitnessSearch.Good tree25048 := H12GlobalWitnessIndex.good

theorem leafIdentity25048 : H12AffineFastState.composeSystem env25048 rootObs = leafEnv25048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25048 rootObs == leafEnv25048) = true)

theorem terminalChecked25048 : H12PackedTerminal.terminalCheckFast leafEnv25048 active25048 tree25048 = true := by decide +kernel

def env25049 : List Nat := [2,4,8,16,17,64,8,256,17,69,2048,81,2120,341,2128,2311,81,2048,337,2129,64,340,260,3,2120,340,2048,276,277,2048,273,340,20,17,340,16]

theorem envBound25049 : H12AffineFastState.Bounded env25049 := by
  intro p hp
  have h : env25049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25042_25049 : H12AffineEnvironment.transform 4 17 env25042 = env25049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env25042 == env25049) = true)

theorem identity25049 : scanCanonicalize (H12AffineFastState.compose env25049 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound25049 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25050 : List Nat := [2,4,8,16,17,64,8,85,17,69,2048,81,2120,0,2128,2130,81,2048,4,2129,64,1,81,3,2120,1,2048,65,64,2048,68,1,20,17,1,16]

theorem envBound25050 : H12AffineFastState.Bounded env25050 := by
  intro p hp
  have h : env25050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25049_25050 : H12AffineEnvironment.transform 7 85 env25049 = env25050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env25049 == env25050) = true)

theorem identity25050 : scanCanonicalize (H12AffineFastState.compose env25050 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound25050 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25051 : List Nat := [2,4,8,16,17,0,8,21,17,5,2048,17,2056,0,2064,2066,17,2048,4,2065,0,1,17,3,2056,1,2048,1,0,2048,4,1,20,17,1,16]

theorem envBound25051 : H12AffineFastState.Bounded env25051 := by
  intro p hp
  have h : env25051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25050_25051 : H12AffineEnvironment.transform 5 0 env25050 = env25051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env25050 == env25051) = true)

def env25052 : List Nat := [2,4,8,16,17,0,8,21,17,5,0,17,8,0,16,18,17,0,4,17,0,1,17,3,8,1,0,1,0,0,4,1,20,17,1,16]

theorem envBound25052 : H12AffineFastState.Bounded env25052 := by
  intro p hp
  have h : env25052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25051_25052 : H12AffineEnvironment.transform 10 0 env25051 = env25052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env25051 == env25052) = true)

theorem identity25052 : scanCanonicalize (H12AffineFastState.compose env25052 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound25052 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25053 : List Nat := [2,4,7,16,17,0,7,21,17,5,0,17,7,0,16,18,17,0,4,17,0,1,17,3,7,1,0,1,0,0,4,1,20,17,1,16]

theorem envBound25053 : H12AffineFastState.Bounded env25053 := by
  intro p hp
  have h : env25053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25052_25053 : H12AffineEnvironment.transform 2 7 env25052 = env25053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env25052 == env25053) = true)

def leafEnv25053 : List Nat := [2,4,7,16,17,0,7,21,17,5,0,17,7,0,16,18,17,0,4,17,0,1,17,3,4,7,1,1,0,1,0,0,4,1,20,17,4,19,1,16,0,0,1]

def active25053 : List Nat := [0,1,3]

def tree25053 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25053 : H12WitnessSearch.Good tree25053 := H12GlobalWitnessIndex.good

theorem leafIdentity25053 : H12AffineFastState.composeSystem env25053 rootObs = leafEnv25053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25053 rootObs == leafEnv25053) = true)

theorem terminalChecked25053 : H12PackedTerminal.terminalCheckFast leafEnv25053 active25053 tree25053 = true := by decide +kernel

def env25054 : List Nat := [2,4,8,16,17,0,8,21,17,5,1,17,9,0,17,19,17,1,4,16,0,1,17,3,9,1,1,1,0,1,4,1,20,17,1,16]

theorem envBound25054 : H12AffineFastState.Bounded env25054 := by
  intro p hp
  have h : env25054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25051_25054 : H12AffineEnvironment.transform 10 1 env25051 = env25054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env25051 == env25054) = true)

theorem identity25054 : scanCanonicalize (H12AffineFastState.compose env25054 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound25054 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25055 : List Nat := [2,4,8,15,14,0,8,10,14,5,1,14,9,0,14,12,14,1,4,15,0,1,14,3,9,1,1,1,0,1,4,1,11,14,1,15]

theorem envBound25055 : H12AffineFastState.Bounded env25055 := by
  intro p hp
  have h : env25055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25054_25055 : H12AffineEnvironment.transform 3 15 env25054 = env25055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env25054 == env25055) = true)

def leafEnv25055 : List Nat := [2,4,8,15,14,0,8,10,14,5,1,14,9,0,14,12,14,1,4,15,0,1,14,3,4,9,1,1,1,1,0,1,4,1,11,14,4,13,1,15,0,0,1]

def active25055 : List Nat := [0,1,2]

def tree25055 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25055 : H12WitnessSearch.Good tree25055 := H12GlobalWitnessIndex.good

theorem leafIdentity25055 : H12AffineFastState.composeSystem env25055 rootObs = leafEnv25055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25055 rootObs == leafEnv25055) = true)

theorem terminalChecked25055 : H12PackedTerminal.terminalCheckFast leafEnv25055 active25055 tree25055 = true := by decide +kernel

def env25056 : List Nat := [2,4,8,16,32,64,8,256,512,116,2048,97,8192,356,32768,33111,96,43049,337,32769,65,340,309,3,8192,357,43049,276,276,2048,288,341,37,33,357,513]

theorem envBound25056 : H12AffineFastState.Bounded env25056 := by
  intro p hp
  have h : env25056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25038_25056 : H12AffineEnvironment.transform 11 97 env25038 = env25056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 97 env25038 == env25056) = true)

theorem identity25056 : scanCanonicalize (H12AffineFastState.compose env25056 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 341) := by decide +kernel

theorem selectedBound25056 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25057 : List Nat := [2,4,8,16,32,64,8,256,341,116,2048,97,8192,356,32768,33111,96,43049,337,32769,65,340,309,3,8192,357,43049,276,276,2048,288,341,37,33,357,340]

theorem envBound25057 : H12AffineFastState.Bounded env25057 := by
  intro p hp
  have h : env25057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25056_25057 : H12AffineEnvironment.transform 8 341 env25056 = env25057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env25056 == env25057) = true)

theorem identity25057 : scanCanonicalize (H12AffineFastState.compose env25057 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound25057 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env25058 : List Nat := [2,4,8,16,32,64,8,69,16,116,2048,97,8192,33,32768,32786,96,43049,20,32769,65,17,112,3,8192,32,43049,81,81,2048,101,16,37,33,32,17]

theorem envBound25058 : H12AffineFastState.Bounded env25058 := by
  intro p hp
  have h : env25058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25057_25058 : H12AffineEnvironment.transform 7 69 env25057 = env25058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env25057 == env25058) = true)

theorem identity25058 : scanCanonicalize (H12AffineFastState.compose env25058 (packedSelected [0] rootPS)) = affineNative (2^(14+1) ^^^ 2129) := by decide +kernel

theorem selectedBound25058 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25059 : List Nat := [2,4,8,16,32,64,8,69,16,116,2048,97,8192,33,2129,2115,96,8312,20,2128,65,17,112,3,8192,32,8312,81,81,2048,101,16,37,33,32,17]

theorem envBound25059 : H12AffineFastState.Bounded env25059 := by
  intro p hp
  have h : env25059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25058_25059 : H12AffineEnvironment.transform 14 2129 env25058 = env25059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2129 env25058 == env25059) = true)

def env25060 : List Nat := [2,4,8,16,32,32,8,37,16,20,2048,1,8192,33,2097,2083,0,8216,20,2096,33,17,16,3,8192,32,8216,49,49,2048,5,16,37,33,32,17]

theorem envBound25060 : H12AffineFastState.Bounded env25060 := by
  intro p hp
  have h : env25060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25059_25060 : H12AffineEnvironment.transform 5 32 env25059 = env25060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env25059 == env25060) = true)

def env25061 : List Nat := [2,4,8,0,32,32,8,37,0,4,2048,1,8192,33,2081,2083,0,8200,4,2080,33,1,0,3,8192,32,8200,33,33,2048,5,0,37,33,32,1]

theorem envBound25061 : H12AffineFastState.Bounded env25061 := by
  intro p hp
  have h : env25061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25060_25061 : H12AffineEnvironment.transform 3 0 env25060 = env25061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env25060 == env25061) = true)

def env25062 : List Nat := [2,4,8,0,32,32,8,37,0,4,0,1,8192,33,33,35,0,8200,4,32,33,1,0,3,8192,32,8200,33,33,0,5,0,37,33,32,1]

theorem envBound25062 : H12AffineFastState.Bounded env25062 := by
  intro p hp
  have h : env25062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25061_25062 : H12AffineEnvironment.transform 10 0 env25061 = env25062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env25061 == env25062) = true)

theorem identity25062 : scanCanonicalize (H12AffineFastState.compose env25062 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound25062 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25063 : List Nat := [2,0,8,0,32,32,8,33,0,0,0,1,8192,33,33,35,0,8200,0,32,33,1,0,3,8192,32,8200,33,33,0,1,0,33,33,32,1]

theorem envBound25063 : H12AffineFastState.Bounded env25063 := by
  intro p hp
  have h : env25063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25062_25063 : H12AffineEnvironment.transform 1 0 env25062 = env25063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env25062 == env25063) = true)

def env25064 : List Nat := [2,0,8,0,0,0,8,1,0,0,0,1,8192,1,1,3,0,8200,0,0,1,1,0,3,8192,0,8200,1,1,0,1,0,1,1,0,1]

theorem envBound25064 : H12AffineFastState.Bounded env25064 := by
  intro p hp
  have h : env25064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25063_25064 : H12AffineEnvironment.transform 4 0 env25063 = env25064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env25063 == env25064) = true)

theorem identity25064 : scanCanonicalize (H12AffineFastState.compose env25064 (packedSelected [3] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound25064 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env25065 : List Nat := [2,0,8,0,0,0,8,1,0,0,0,1,9,1,1,3,0,1,0,0,1,1,0,3,9,0,1,1,1,0,1,0,1,1,0,1]

theorem envBound25065 : H12AffineFastState.Bounded env25065 := by
  intro p hp
  have h : env25065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25064_25065 : H12AffineEnvironment.transform 12 9 env25064 = env25065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env25064 == env25065) = true)

def leafEnv25065 : List Nat := [2,0,8,0,0,0,8,1,0,0,0,1,9,1,1,3,0,1,0,0,1,1,0,3,0,9,1,0,1,1,1,0,1,0,1,1,1,2,0,1,0,1,1]

def active25065 : List Nat := [0,2]

def tree25065 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25065 : H12WitnessSearch.Good tree25065 := H12GlobalWitnessIndex.good

theorem leafIdentity25065 : H12AffineFastState.composeSystem env25065 rootObs = leafEnv25065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25065 rootObs == leafEnv25065) = true)

theorem terminalChecked25065 : H12PackedTerminal.terminalCheckFast leafEnv25065 active25065 tree25065 = true := by decide +kernel

def env25066 : List Nat := [2,0,8,0,1,1,8,0,0,0,0,1,8192,0,0,2,0,8200,0,1,0,1,0,3,8192,1,8200,0,0,0,1,0,0,0,1,1]

theorem envBound25066 : H12AffineFastState.Bounded env25066 := by
  intro p hp
  have h : env25066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25063_25066 : H12AffineEnvironment.transform 4 1 env25063 = env25066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env25063 == env25066) = true)

def leafEnv25066 : List Nat := [2,0,8,0,1,1,8,0,0,0,0,1,8192,0,0,2,0,8200,0,1,0,1,0,3,0,8192,1,1,8200,0,0,0,1,0,0,0,1,3,1,1,0,0,1]

def active25066 : List Nat := [0,2,12]

def tree25066 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25066 : H12WitnessSearch.Good tree25066 := H12GlobalWitnessIndex.good

theorem leafIdentity25066 : H12AffineFastState.composeSystem env25066 rootObs = leafEnv25066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25066 rootObs == leafEnv25066) = true)

theorem terminalChecked25066 : H12PackedTerminal.terminalCheckFast leafEnv25066 active25066 tree25066 = true := by decide +kernel

def env25067 : List Nat := [2,4,8,0,32,32,8,37,0,4,1,1,8192,33,32,34,0,8200,4,33,33,1,0,3,8192,32,8200,33,33,1,5,0,37,33,32,1]

theorem envBound25067 : H12AffineFastState.Bounded env25067 := by
  intro p hp
  have h : env25067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25061_25067 : H12AffineEnvironment.transform 10 1 env25061 = env25067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env25061 == env25067) = true)

theorem identity25067 : scanCanonicalize (H12AffineFastState.compose env25067 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound25067 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25068 : List Nat := [2,4,8,0,5,5,8,0,0,4,1,1,8192,4,5,7,0,8200,4,4,4,1,0,3,8192,5,8200,4,4,1,5,0,0,4,5,1]

theorem envBound25068 : H12AffineFastState.Bounded env25068 := by
  intro p hp
  have h : env25068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25067_25068 : H12AffineEnvironment.transform 4 5 env25067 = env25068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env25067 == env25068) = true)

def env25069 : List Nat := [2,4,8,0,5,5,8,0,0,4,1,1,8,4,5,7,0,0,4,4,4,1,0,3,8,5,0,4,4,1,5,0,0,4,5,1]

theorem envBound25069 : H12AffineFastState.Bounded env25069 := by
  intro p hp
  have h : env25069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25068_25069 : H12AffineEnvironment.transform 12 8 env25068 = env25069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env25068 == env25069) = true)

def leafEnv25069 : List Nat := [2,4,8,0,5,5,8,0,0,4,1,1,8,4,5,7,0,0,4,4,4,1,0,3,4,8,1,5,0,4,4,1,5,0,0,4,5,6,5,1,0,4,1]

def active25069 : List Nat := [0,1,2]

def tree25069 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25069 : H12WitnessSearch.Good tree25069 := H12GlobalWitnessIndex.good

theorem leafIdentity25069 : H12AffineFastState.composeSystem env25069 rootObs = leafEnv25069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25069 rootObs == leafEnv25069) = true)

theorem terminalChecked25069 : H12PackedTerminal.terminalCheckFast leafEnv25069 active25069 tree25069 = true := by decide +kernel

def env25070 : List Nat := [2,4,8,0,5,5,8,0,0,4,1,1,9,4,5,7,0,1,4,4,4,1,0,3,9,5,1,4,4,1,5,0,0,4,5,1]

theorem envBound25070 : H12AffineFastState.Bounded env25070 := by
  intro p hp
  have h : env25070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25068_25070 : H12AffineEnvironment.transform 12 9 env25068 = env25070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env25068 == env25070) = true)

theorem identity25070 : scanCanonicalize (H12AffineFastState.compose env25070 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound25070 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env25071 : List Nat := [2,0,8,0,1,1,8,0,0,0,1,1,9,0,1,3,0,1,0,0,0,1,0,3,9,1,1,0,0,1,1,0,0,0,1,1]

theorem envBound25071 : H12AffineFastState.Bounded env25071 := by
  intro p hp
  have h : env25071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25070_25071 : H12AffineEnvironment.transform 1 0 env25070 = env25071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env25070 == env25071) = true)

def leafEnv25071 : List Nat := [2,0,8,0,1,1,8,0,0,0,1,1,9,0,1,3,0,1,0,0,0,1,0,3,0,9,1,1,1,0,0,1,1,0,0,0,1,2,1,1,0,0,1]

def active25071 : List Nat := [0,2]

def tree25071 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25071 : H12WitnessSearch.Good tree25071 := H12GlobalWitnessIndex.good

theorem leafIdentity25071 : H12AffineFastState.composeSystem env25071 rootObs = leafEnv25071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25071 rootObs == leafEnv25071) = true)

theorem terminalChecked25071 : H12PackedTerminal.terminalCheckFast leafEnv25071 active25071 tree25071 = true := by decide +kernel

def env25072 : List Nat := [2,4,8,1,32,32,8,37,1,5,2048,1,8192,33,2080,2083,0,8201,5,2081,33,0,1,3,8192,32,8201,32,32,2048,5,1,37,33,32,0]

theorem envBound25072 : H12AffineFastState.Bounded env25072 := by
  intro p hp
  have h : env25072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25060_25072 : H12AffineEnvironment.transform 3 1 env25060 = env25072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env25060 == env25072) = true)

def env25073 : List Nat := [2,4,8,1,32,32,8,37,1,5,0,1,8192,33,32,35,0,8201,5,33,33,0,1,3,8192,32,8201,32,32,0,5,1,37,33,32,0]

theorem envBound25073 : H12AffineFastState.Bounded env25073 := by
  intro p hp
  have h : env25073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25072_25073 : H12AffineEnvironment.transform 10 0 env25072 = env25073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env25072 == env25073) = true)

theorem identity25073 : scanCanonicalize (H12AffineFastState.compose env25073 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 12) := by decide +kernel

theorem selectedBound25073 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25074 : List Nat := [2,4,8,1,32,32,8,37,1,5,0,1,12,33,32,35,0,5,5,33,33,0,1,3,12,32,5,32,32,0,5,1,37,33,32,0]

theorem envBound25074 : H12AffineFastState.Bounded env25074 := by
  intro p hp
  have h : env25074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25073_25074 : H12AffineEnvironment.transform 12 12 env25073 = env25074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 12 env25073 == env25074) = true)

def env25075 : List Nat := [2,4,8,1,0,0,8,5,1,5,0,1,12,1,0,3,0,5,5,1,1,0,1,3,12,0,5,0,0,0,5,1,5,1,0,0]

theorem envBound25075 : H12AffineFastState.Bounded env25075 := by
  intro p hp
  have h : env25075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25074_25075 : H12AffineEnvironment.transform 4 0 env25074 = env25075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env25074 == env25075) = true)

def env25076 : List Nat := [2,4,8,1,1,1,8,4,1,5,0,1,12,0,1,2,0,5,5,0,0,0,1,3,12,1,5,1,1,0,5,1,4,0,1,0]

theorem envBound25076 : H12AffineFastState.Bounded env25076 := by
  intro p hp
  have h : env25076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25074_25076 : H12AffineEnvironment.transform 4 1 env25074 = env25076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env25074 == env25076) = true)

theorem identity25076 : scanCanonicalize (H12AffineFastState.compose env25076 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound25076 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env25077 : List Nat := [2,1,8,1,1,1,8,1,1,0,0,1,9,0,1,2,0,0,0,0,0,0,1,3,9,1,0,1,1,0,0,1,1,0,1,0]

theorem envBound25077 : H12AffineFastState.Bounded env25077 := by
  intro p hp
  have h : env25077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25076_25077 : H12AffineEnvironment.transform 1 1 env25076 = env25077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env25076 == env25077) = true)

def leafEnv25077 : List Nat := [2,1,8,1,1,1,8,1,1,0,0,1,9,0,1,2,0,0,0,0,0,0,1,3,1,9,1,1,0,1,1,0,0,1,1,0,0,3,1,0,0,0,1]

def active25077 : List Nat := [0,2]

def tree25077 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25077 : H12WitnessSearch.Good tree25077 := H12GlobalWitnessIndex.good

theorem leafIdentity25077 : H12AffineFastState.composeSystem env25077 rootObs = leafEnv25077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25077 rootObs == leafEnv25077) = true)

theorem terminalChecked25077 : H12PackedTerminal.terminalCheckFast leafEnv25077 active25077 tree25077 = true := by decide +kernel

def env25078 : List Nat := [2,4,8,1,32,32,8,37,1,5,1,1,8192,33,33,34,0,8201,5,32,33,0,1,3,8192,32,8201,32,32,1,5,1,37,33,32,0]

theorem envBound25078 : H12AffineFastState.Bounded env25078 := by
  intro p hp
  have h : env25078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25072_25078 : H12AffineEnvironment.transform 10 1 env25072 = env25078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env25072 == env25078) = true)

theorem identity25078 : scanCanonicalize (H12AffineFastState.compose env25078 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 45) := by decide +kernel

theorem selectedBound25078 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25079 : List Nat := [2,4,8,1,32,32,8,37,1,5,1,1,45,33,33,34,0,36,5,32,33,0,1,3,45,32,36,32,32,1,5,1,37,33,32,0]

theorem envBound25079 : H12AffineFastState.Bounded env25079 := by
  intro p hp
  have h : env25079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25078_25079 : H12AffineEnvironment.transform 12 45 env25078 = env25079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 45 env25078 == env25079) = true)

def env25080 : List Nat := [2,4,8,1,0,0,8,5,1,5,1,1,13,1,1,2,0,4,5,0,1,0,1,3,13,0,4,0,0,1,5,1,5,1,0,0]

theorem envBound25080 : H12AffineFastState.Bounded env25080 := by
  intro p hp
  have h : env25080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25079_25080 : H12AffineEnvironment.transform 4 0 env25079 = env25080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env25079 == env25080) = true)

def env25081 : List Nat := [2,4,8,1,1,1,8,4,1,5,1,1,12,0,0,3,0,5,5,1,0,0,1,3,12,1,5,1,1,1,5,1,4,0,1,0]

theorem envBound25081 : H12AffineFastState.Bounded env25081 := by
  intro p hp
  have h : env25081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25079_25081 : H12AffineEnvironment.transform 4 1 env25079 = env25081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env25079 == env25081) = true)

theorem identity25081 : scanCanonicalize (H12AffineFastState.compose env25081 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound25081 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env25082 : List Nat := [2,0,8,1,1,1,8,0,1,1,1,1,8,0,0,3,0,1,1,1,0,0,1,3,8,1,1,1,1,1,1,1,0,0,1,0]

theorem envBound25082 : H12AffineFastState.Bounded env25082 := by
  intro p hp
  have h : env25082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25081_25082 : H12AffineEnvironment.transform 1 0 env25081 = env25082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env25081 == env25082) = true)

def leafEnv25082 : List Nat := [2,0,8,1,1,1,8,0,1,1,1,1,8,0,0,3,0,1,1,1,0,0,1,3,0,8,1,1,1,1,1,1,1,1,0,0,1,2,1,0,0,0,1]

def active25082 : List Nat := [0,2]

def tree25082 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25082 : H12WitnessSearch.Good tree25082 := H12GlobalWitnessIndex.good

theorem leafIdentity25082 : H12AffineFastState.composeSystem env25082 rootObs = leafEnv25082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25082 rootObs == leafEnv25082) = true)

theorem terminalChecked25082 : H12PackedTerminal.terminalCheckFast leafEnv25082 active25082 tree25082 = true := by decide +kernel

def env25083 : List Nat := [2,4,8,16,32,33,8,36,16,21,2048,0,8192,33,2096,2082,1,8217,20,2097,32,17,17,3,8192,32,8217,48,48,2048,4,16,37,33,32,17]

theorem envBound25083 : H12AffineFastState.Bounded env25083 := by
  intro p hp
  have h : env25083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25059_25083 : H12AffineEnvironment.transform 5 33 env25059 = env25083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env25059 == env25083) = true)

theorem identity25083 : scanCanonicalize (H12AffineFastState.compose env25083 (packedSelected [4] rootPS)) = affineNative (2^(12+1) ^^^ 2072) := by decide +kernel

theorem selectedBound25083 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env25084 : List Nat := [2,4,8,16,32,33,8,36,16,21,2048,0,2072,33,2096,2082,1,2049,20,2097,32,17,17,3,2072,32,2049,48,48,2048,4,16,37,33,32,17]

theorem envBound25084 : H12AffineFastState.Bounded env25084 := by
  intro p hp
  have h : env25084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25083_25084 : H12AffineEnvironment.transform 12 2072 env25083 = env25084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2072 env25083 == env25084) = true)

theorem identity25084 : scanCanonicalize (H12AffineFastState.compose env25084 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound25084 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25085 : List Nat := [2,4,8,0,32,33,8,36,0,5,2048,0,2056,33,2080,2082,1,2049,4,2081,32,1,1,3,2056,32,2049,32,32,2048,4,0,37,33,32,1]

theorem envBound25085 : H12AffineFastState.Bounded env25085 := by
  intro p hp
  have h : env25085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25084_25085 : H12AffineEnvironment.transform 3 0 env25084 = env25085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env25084 == env25085) = true)

def env25086 : List Nat := [2,4,8,0,32,33,8,36,0,5,0,0,8,33,32,34,1,1,4,33,32,1,1,3,8,32,1,32,32,0,4,0,37,33,32,1]

theorem envBound25086 : H12AffineFastState.Bounded env25086 := by
  intro p hp
  have h : env25086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25085_25086 : H12AffineEnvironment.transform 10 0 env25085 = env25086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env25085 == env25086) = true)

theorem identity25086 : scanCanonicalize (H12AffineFastState.compose env25086 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 4) := by decide +kernel

theorem selectedBound25086 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25087 : List Nat := [2,4,8,0,4,5,8,0,0,5,0,0,8,5,4,6,1,1,4,5,4,1,1,3,8,4,1,4,4,0,4,0,1,5,4,1]

theorem envBound25087 : H12AffineFastState.Bounded env25087 := by
  intro p hp
  have h : env25087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25086_25087 : H12AffineEnvironment.transform 4 4 env25086 = env25087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 4 env25086 == env25087) = true)

def leafEnv25087 : List Nat := [2,4,8,0,4,5,8,0,0,5,0,0,8,5,4,6,1,1,4,5,4,1,1,3,4,8,1,4,1,4,4,0,4,0,1,5,4,7,4,1,0,4,1]

def active25087 : List Nat := [0,1,2]

def tree25087 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25087 : H12WitnessSearch.Good tree25087 := H12GlobalWitnessIndex.good

theorem leafIdentity25087 : H12AffineFastState.composeSystem env25087 rootObs = leafEnv25087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25087 rootObs == leafEnv25087) = true)

theorem terminalChecked25087 : H12PackedTerminal.terminalCheckFast leafEnv25087 active25087 tree25087 = true := by decide +kernel

def env25088 : List Nat := [2,4,8,0,32,33,8,36,0,5,1,0,9,33,33,35,1,0,4,32,32,1,1,3,9,32,0,32,32,1,4,0,37,33,32,1]

theorem envBound25088 : H12AffineFastState.Bounded env25088 := by
  intro p hp
  have h : env25088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25085_25088 : H12AffineEnvironment.transform 10 1 env25085 = env25088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env25085 == env25088) = true)

theorem identity25088 : scanCanonicalize (H12AffineFastState.compose env25088 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound25088 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25089 : List Nat := [2,1,8,0,32,33,8,33,0,0,1,0,9,33,33,35,1,0,1,32,32,1,1,3,9,32,0,32,32,1,1,0,32,33,32,1]

theorem envBound25089 : H12AffineFastState.Bounded env25089 := by
  intro p hp
  have h : env25089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25088_25089 : H12AffineEnvironment.transform 1 1 env25088 = env25089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env25088 == env25089) = true)

def leafEnv25089 : List Nat := [2,1,8,0,32,33,8,33,0,0,1,0,9,33,33,35,1,0,1,32,32,1,1,3,1,9,1,32,0,32,32,1,1,0,32,33,1,34,32,1,0,32,1]

def active25089 : List Nat := [0,2,4]

def tree25089 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25089 : H12WitnessSearch.Good tree25089 := H12GlobalWitnessIndex.good

theorem leafIdentity25089 : H12AffineFastState.composeSystem env25089 rootObs = leafEnv25089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25089 rootObs == leafEnv25089) = true)

theorem terminalChecked25089 : H12PackedTerminal.terminalCheckFast leafEnv25089 active25089 tree25089 = true := by decide +kernel

def env25090 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,98615,262144,99442,32769,5205,477,98402,98645,8328,98354,262280,277,102435,100694,1365,102498,98674,4161,1296,513]

theorem envBound25090 : H12AffineFastState.Bounded env25090 := by
  intro p hp
  have h : env25090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25033_25090 : H12AffineEnvironment.transform 20 5205 env25033 = env25090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5205 env25033 == env25090) = true)

theorem identity25090 : scanCanonicalize (H12AffineFastState.compose env25090 (packedSelected [14] rootPS)) = affineNative (2^(11+1) ^^^ 1045) := by decide +kernel

theorem selectedBound25090 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env25091 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1045,8192,1296,32768,65536,98615,262144,99442,32769,64,477,98402,98645,8328,98354,262280,277,99382,100694,1365,99447,98674,1108,1296,513]

theorem envBound25091 : H12AffineFastState.Bounded env25091 := by
  intro p hp
  have h : env25091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25090_25091 : H12AffineEnvironment.transform 11 1045 env25090 = env25091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env25090 == env25091) = true)

theorem identity25091 : scanCanonicalize (H12AffineFastState.compose env25091 (packedSelected [3,5,10,12,13,15] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound25091 : packedSelected [3,5,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env25092 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1045,8192,1296,32768,33246,233,262144,1452,32769,64,477,444,139,8328,492,262280,277,1512,2184,1365,1449,172,1108,1296,513]

theorem envBound25092 : H12AffineFastState.Bounded env25092 := by
  intro p hp
  have h : env25092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25091_25092 : H12AffineEnvironment.transform 15 33246 env25091 = env25092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env25091 == env25092) = true)

theorem identity25092 : scanCanonicalize (H12AffineFastState.compose env25092 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound25092 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env25093 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1045,8192,1296,32768,33246,233,43049,1452,32769,64,477,444,139,8328,492,43169,277,1512,2184,1365,1449,172,1108,1296,513]

theorem envBound25093 : H12AffineFastState.Bounded env25093 := by
  intro p hp
  have h : env25093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25092_25093 : H12AffineEnvironment.transform 17 43049 env25092 = env25093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env25092 == env25093) = true)

theorem identity25093 : scanCanonicalize (H12AffineFastState.compose env25093 (packedSelected [1,8] rootPS)) = affineNative (2^(14+1) ^^^ 2421) := by decide +kernel

theorem selectedBound25093 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env25094 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1045,8192,1296,2421,2219,233,8540,1452,2420,64,477,444,139,8328,492,8660,277,1512,2184,1365,1449,172,1108,1296,513]

theorem envBound25094 : H12AffineFastState.Bounded env25094 := by
  intro p hp
  have h : env25094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25093_25094 : H12AffineEnvironment.transform 14 2421 env25093 = env25094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2421 env25093 == env25094) = true)

def env25095 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1045,2088,1296,2421,2219,233,2420,1452,2420,64,477,444,139,2208,492,2556,277,1512,2184,1365,1449,172,1108,1296,513]

theorem envBound25095 : H12AffineFastState.Bounded env25095 := by
  intro p hp
  have h : env25095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25094_25095 : H12AffineEnvironment.transform 12 2088 env25094 = env25095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env25094 == env25095) = true)

theorem identity25095 : scanCanonicalize (H12AffineFastState.compose env25095 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound25095 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env25096 : List Nat := [2,4,8,16,32,64,128,256,512,84,2048,65,2088,324,2421,2219,233,2420,504,2420,64,477,444,139,2208,492,2556,277,444,2184,257,509,172,0,324,513]

theorem envBound25096 : H12AffineFastState.Bounded env25096 := by
  intro p hp
  have h : env25096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25095_25096 : H12AffineEnvironment.transform 9 84 env25095 = env25096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env25095 == env25096) = true)

theorem identity25096 : scanCanonicalize (H12AffineFastState.compose env25096 (packedSelected [1,3,10] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound25096 : packedSelected [1,3,10] rootPS < 2^1333 := by decide +kernel

def env25097 : List Nat := [2,4,8,16,32,64,128,68,512,84,2048,65,2088,0,2097,2219,233,2096,188,2096,64,153,248,139,2208,168,2232,81,248,2184,69,185,172,0,0,513]

theorem envBound25097 : H12AffineFastState.Bounded env25097 := by
  intro p hp
  have h : env25097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25096_25097 : H12AffineEnvironment.transform 7 68 env25096 = env25097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env25096 == env25097) = true)

theorem identity25097 : scanCanonicalize (H12AffineFastState.compose env25097 (packedSelected [7] rootPS)) = affineNative (2^(6+1) ^^^ 73) := by decide +kernel

theorem selectedBound25097 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env25098 : List Nat := [2,4,8,16,32,64,73,68,512,84,2048,65,2088,0,2097,2146,32,2096,117,2096,64,80,49,66,2153,97,2161,81,49,2113,69,112,101,0,0,513]

theorem envBound25098 : H12AffineFastState.Bounded env25098 := by
  intro p hp
  have h : env25098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25097_25098 : H12AffineEnvironment.transform 6 73 env25097 = env25098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 73 env25097 == env25098) = true)

def env25099 : List Nat := [2,4,8,16,32,0,9,4,512,20,2048,1,2088,0,2097,2082,32,2096,53,2096,0,16,49,2,2089,33,2097,17,49,2049,5,48,37,0,0,513]

theorem envBound25099 : H12AffineFastState.Bounded env25099 := by
  intro p hp
  have h : env25099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25098_25099 : H12AffineEnvironment.transform 5 0 env25098 = env25099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env25098 == env25099) = true)

theorem identity25099 : scanCanonicalize (H12AffineFastState.compose env25099 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound25099 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25100 : List Nat := [2,4,8,16,16,0,9,4,512,20,2048,1,2072,0,2049,2066,16,2048,5,2048,0,16,1,2,2073,17,2049,17,1,2049,5,0,21,0,0,513]

theorem envBound25100 : H12AffineFastState.Bounded env25100 := by
  intro p hp
  have h : env25100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25099_25100 : H12AffineEnvironment.transform 4 16 env25099 = env25100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env25099 == env25100) = true)

theorem identity25100 : scanCanonicalize (H12AffineFastState.compose env25100 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound25100 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25101 : List Nat := [2,4,8,16,16,0,9,4,0,20,2048,1,2072,0,2049,2066,16,2048,5,2048,0,16,1,2,2073,17,2049,17,1,2049,5,0,21,0,0,1]

theorem envBound25101 : H12AffineFastState.Bounded env25101 := by
  intro p hp
  have h : env25101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25100_25101 : H12AffineEnvironment.transform 8 0 env25100 = env25101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env25100 == env25101) = true)

def env25102 : List Nat := [2,4,8,0,0,0,9,4,0,4,2048,1,2056,0,2049,2050,0,2048,5,2048,0,0,1,2,2057,1,2049,1,1,2049,5,0,5,0,0,1]

theorem envBound25102 : H12AffineFastState.Bounded env25102 := by
  intro p hp
  have h : env25102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25101_25102 : H12AffineEnvironment.transform 3 0 env25101 = env25102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env25101 == env25102) = true)

theorem identity25102 : scanCanonicalize (H12AffineFastState.compose env25102 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound25102 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25103 : List Nat := [2,0,8,0,0,0,9,0,0,0,2048,1,2056,0,2049,2050,0,2048,1,2048,0,0,1,2,2057,1,2049,1,1,2049,1,0,1,0,0,1]

theorem envBound25103 : H12AffineFastState.Bounded env25103 := by
  intro p hp
  have h : env25103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25102_25103 : H12AffineEnvironment.transform 1 0 env25102 = env25103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env25102 == env25103) = true)

def leafEnv25103 : List Nat := [2,0,8,0,0,0,9,0,0,0,2048,1,2056,0,2049,2050,0,2048,1,2048,0,0,1,2,1,2057,1,1,2049,1,1,2049,1,0,1,0,0,2050,0,1,0,1,1]

def active25103 : List Nat := [0,2,10]

def tree25103 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25103 : H12WitnessSearch.Good tree25103 := H12GlobalWitnessIndex.good

theorem leafIdentity25103 : H12AffineFastState.composeSystem env25103 rootObs = leafEnv25103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25103 rootObs == leafEnv25103) = true)

theorem terminalChecked25103 : H12PackedTerminal.terminalCheckFast leafEnv25103 active25103 tree25103 = true := by decide +kernel

def env25104 : List Nat := [2,4,8,1,1,0,9,4,0,5,2048,1,2057,0,2049,2051,1,2048,5,2048,0,1,1,2,2056,0,2049,0,1,2049,5,0,4,0,0,1]

theorem envBound25104 : H12AffineFastState.Bounded env25104 := by
  intro p hp
  have h : env25104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25101_25104 : H12AffineEnvironment.transform 3 1 env25101 = env25104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env25101 == env25104) = true)

theorem identity25104 : scanCanonicalize (H12AffineFastState.compose env25104 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound25104 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25105 : List Nat := [2,4,7,1,1,0,6,4,0,5,2048,1,2054,0,2049,2051,1,2048,5,2048,0,1,1,2,2055,0,2049,0,1,2049,5,0,4,0,0,1]

theorem envBound25105 : H12AffineFastState.Bounded env25105 := by
  intro p hp
  have h : env25105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25104_25105 : H12AffineEnvironment.transform 2 7 env25104 = env25105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env25104 == env25105) = true)

def leafEnv25105 : List Nat := [2,4,7,1,1,0,6,4,0,5,2048,1,2054,0,2049,2051,1,2048,5,2048,0,1,1,2,4,2055,1,0,2049,0,1,2049,5,0,4,0,5,2051,0,1,0,1,1]

def active25105 : List Nat := [0,1,10]

def tree25105 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25105 : H12WitnessSearch.Good tree25105 := H12GlobalWitnessIndex.good

theorem leafIdentity25105 : H12AffineFastState.composeSystem env25105 rootObs = leafEnv25105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25105 rootObs == leafEnv25105) = true)

theorem terminalChecked25105 : H12PackedTerminal.terminalCheckFast leafEnv25105 active25105 tree25105 = true := by decide +kernel

def env25106 : List Nat := [2,4,8,16,32,1,8,5,512,21,2048,0,2088,0,2097,2083,32,2096,52,2096,1,17,49,3,2088,32,2096,16,49,2048,4,49,36,0,0,513]

theorem envBound25106 : H12AffineFastState.Bounded env25106 := by
  intro p hp
  have h : env25106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25098_25106 : H12AffineEnvironment.transform 5 1 env25098 = env25106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env25098 == env25106) = true)

def env25107 : List Nat := [2,4,8,16,0,1,8,5,512,21,2048,0,2056,0,2065,2051,0,2064,20,2064,1,17,17,3,2056,0,2064,16,17,2048,4,17,4,0,0,513]

theorem envBound25107 : H12AffineFastState.Bounded env25107 := by
  intro p hp
  have h : env25107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25106_25107 : H12AffineEnvironment.transform 4 0 env25106 = env25107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env25106 == env25107) = true)

theorem identity25107 : scanCanonicalize (H12AffineFastState.compose env25107 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound25107 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25108 : List Nat := [2,4,8,16,0,1,8,5,1,21,2048,0,2056,0,2065,2051,0,2064,20,2064,1,17,17,3,2056,0,2064,16,17,2048,4,17,4,0,0,0]

theorem envBound25108 : H12AffineFastState.Bounded env25108 := by
  intro p hp
  have h : env25108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25107_25108 : H12AffineEnvironment.transform 8 1 env25107 = env25108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env25107 == env25108) = true)

def env25109 : List Nat := [2,4,8,16,0,1,8,5,1,21,0,0,8,0,17,3,0,16,20,16,1,17,17,3,8,0,16,16,17,0,4,17,4,0,0,0]

theorem envBound25109 : H12AffineFastState.Bounded env25109 := by
  intro p hp
  have h : env25109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25108_25109 : H12AffineEnvironment.transform 10 0 env25108 = env25109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env25108 == env25109) = true)

theorem identity25109 : scanCanonicalize (H12AffineFastState.compose env25109 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound25109 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25110 : List Nat := [2,4,8,15,0,1,8,5,1,10,0,0,8,0,14,3,0,15,11,15,1,14,14,3,8,0,15,15,14,0,4,14,4,0,0,0]

theorem envBound25110 : H12AffineFastState.Bounded env25110 := by
  intro p hp
  have h : env25110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25109_25110 : H12AffineEnvironment.transform 3 15 env25109 = env25110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env25109 == env25110) = true)

def leafEnv25110 : List Nat := [2,4,8,15,0,1,8,5,1,10,0,0,8,0,14,3,0,15,11,15,1,14,14,3,4,8,1,0,15,15,14,0,4,14,4,0,4,2,0,0,0,0,1]

def active25110 : List Nat := [0,1,2]

def tree25110 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25110 : H12WitnessSearch.Good tree25110 := H12GlobalWitnessIndex.good

theorem leafIdentity25110 : H12AffineFastState.composeSystem env25110 rootObs = leafEnv25110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25110 rootObs == leafEnv25110) = true)

theorem terminalChecked25110 : H12PackedTerminal.terminalCheckFast leafEnv25110 active25110 tree25110 = true := by decide +kernel

def env25111 : List Nat := [2,4,8,16,0,1,8,5,1,21,1,0,9,0,16,2,0,17,20,17,1,17,17,3,9,0,17,16,17,1,4,17,4,0,0,0]

theorem envBound25111 : H12AffineFastState.Bounded env25111 := by
  intro p hp
  have h : env25111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25108_25111 : H12AffineEnvironment.transform 10 1 env25108 = env25111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env25108 == env25111) = true)

theorem identity25111 : scanCanonicalize (H12AffineFastState.compose env25111 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound25111 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25112 : List Nat := [2,4,6,16,0,1,6,5,1,21,1,0,7,0,16,2,0,17,20,17,1,17,17,3,7,0,17,16,17,1,4,17,4,0,0,0]

theorem envBound25112 : H12AffineFastState.Bounded env25112 := by
  intro p hp
  have h : env25112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25111_25112 : H12AffineEnvironment.transform 2 6 env25111 = env25112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env25111 == env25112) = true)

def leafEnv25112 : List Nat := [2,4,6,16,0,1,6,5,1,21,1,0,7,0,16,2,0,17,20,17,1,17,17,3,4,7,1,0,17,16,17,1,4,17,4,0,4,3,0,0,0,0,1]

def active25112 : List Nat := [0,1,3]

def tree25112 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25112 : H12WitnessSearch.Good tree25112 := H12GlobalWitnessIndex.good

theorem leafIdentity25112 : H12AffineFastState.composeSystem env25112 rootObs = leafEnv25112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25112 rootObs == leafEnv25112) = true)

theorem terminalChecked25112 : H12PackedTerminal.terminalCheckFast leafEnv25112 active25112 tree25112 = true := by decide +kernel

def env25113 : List Nat := [2,4,8,16,1,1,8,5,512,21,2048,0,2057,0,2064,2050,1,2065,21,2065,1,17,16,3,2057,1,2065,16,16,2048,4,16,5,0,0,513]

theorem envBound25113 : H12AffineFastState.Bounded env25113 := by
  intro p hp
  have h : env25113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25106_25113 : H12AffineEnvironment.transform 4 1 env25106 = env25113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env25106 == env25113) = true)

theorem identity25113 : scanCanonicalize (H12AffineFastState.compose env25113 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound25113 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25114 : List Nat := [2,4,8,16,1,1,8,5,17,21,2048,0,2057,0,2064,2050,1,2065,21,2065,1,17,16,3,2057,1,2065,16,16,2048,4,16,5,0,0,16]

theorem envBound25114 : H12AffineFastState.Bounded env25114 := by
  intro p hp
  have h : env25114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25113_25114 : H12AffineEnvironment.transform 8 17 env25113 = env25114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env25113 == env25114) = true)

def env25115 : List Nat := [2,4,8,16,1,1,8,5,17,21,0,0,9,0,16,2,1,17,21,17,1,17,16,3,9,1,17,16,16,0,4,16,5,0,0,16]

theorem envBound25115 : H12AffineFastState.Bounded env25115 := by
  intro p hp
  have h : env25115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25114_25115 : H12AffineEnvironment.transform 10 0 env25114 = env25115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env25114 == env25115) = true)

theorem identity25115 : scanCanonicalize (H12AffineFastState.compose env25115 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound25115 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25116 : List Nat := [2,4,8,5,1,1,8,5,4,0,0,0,9,0,5,2,1,4,0,4,1,4,5,3,9,1,4,5,5,0,4,5,5,0,0,5]

theorem envBound25116 : H12AffineFastState.Bounded env25116 := by
  intro p hp
  have h : env25116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25115_25116 : H12AffineEnvironment.transform 3 5 env25115 = env25116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env25115 == env25116) = true)

def leafEnv25116 : List Nat := [2,4,8,5,1,1,8,5,4,0,0,0,9,0,5,2,1,4,0,4,1,4,5,3,5,9,1,1,4,5,5,0,4,5,5,0,5,3,0,5,0,0,1]

def active25116 : List Nat := [0,1,2]

def tree25116 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25116 : H12WitnessSearch.Good tree25116 := H12GlobalWitnessIndex.good

theorem leafIdentity25116 : H12AffineFastState.composeSystem env25116 rootObs = leafEnv25116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25116 rootObs == leafEnv25116) = true)

theorem terminalChecked25116 : H12PackedTerminal.terminalCheckFast leafEnv25116 active25116 tree25116 = true := by decide +kernel

def env25117 : List Nat := [2,4,8,16,1,1,8,5,17,21,1,0,8,0,17,3,1,16,21,16,1,17,16,3,8,1,16,16,16,1,4,16,5,0,0,16]

theorem envBound25117 : H12AffineFastState.Bounded env25117 := by
  intro p hp
  have h : env25117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25114_25117 : H12AffineEnvironment.transform 10 1 env25114 = env25117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env25114 == env25117) = true)

theorem identity25117 : scanCanonicalize (H12AffineFastState.compose env25117 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound25117 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25118 : List Nat := [2,1,8,16,1,1,8,0,17,16,1,0,8,0,17,3,1,16,16,16,1,17,16,3,8,1,16,16,16,1,1,16,0,0,0,16]

theorem envBound25118 : H12AffineFastState.Bounded env25118 := by
  intro p hp
  have h : env25118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25117_25118 : H12AffineEnvironment.transform 1 1 env25117 = env25118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env25117 == env25118) = true)

def leafEnv25118 : List Nat := [2,1,8,16,1,1,8,0,17,16,1,0,8,0,17,3,1,16,16,16,1,17,16,3,0,8,1,1,16,16,16,1,1,16,0,0,0,2,0,16,0,0,1]

def active25118 : List Nat := [0,2,3]

def tree25118 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25118 : H12WitnessSearch.Good tree25118 := H12GlobalWitnessIndex.good

theorem leafIdentity25118 : H12AffineFastState.composeSystem env25118 rootObs = leafEnv25118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25118 rootObs == leafEnv25118) = true)

theorem terminalChecked25118 : H12PackedTerminal.terminalCheckFast leafEnv25118 active25118 tree25118 = true := by decide +kernel

def env25119 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1045,2089,1296,2421,2219,233,2421,1452,2420,64,477,444,139,2209,492,2557,277,1512,2184,1365,1449,172,1108,1296,513]

theorem envBound25119 : H12AffineFastState.Bounded env25119 := by
  intro p hp
  have h : env25119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25094_25119 : H12AffineEnvironment.transform 12 2089 env25094 = env25119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2089 env25094 == env25119) = true)

theorem identity25119 : scanCanonicalize (H12AffineFastState.compose env25119 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound25119 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env25120 : List Nat := [2,4,8,16,32,64,128,84,512,1024,2048,1045,2089,1092,2081,2219,233,2081,1272,2080,64,137,232,139,2209,184,2217,65,1212,2184,1025,1277,172,1108,1092,513]

theorem envBound25120 : H12AffineFastState.Bounded env25120 := by
  intro p hp
  have h : env25120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25119_25120 : H12AffineEnvironment.transform 7 84 env25119 = env25120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env25119 == env25120) = true)

theorem identity25120 : scanCanonicalize (H12AffineFastState.compose env25120 (packedSelected [1,3,10] rootPS)) = affineNative (2^(9+1) ^^^ 237) := by decide +kernel

theorem selectedBound25120 : packedSelected [1,3,10] rootPS < 2^1333 := by decide +kernel

def env25121 : List Nat := [2,4,8,16,32,64,128,84,512,237,2048,248,2089,169,2081,2219,233,2081,21,2080,64,137,232,139,2209,184,2217,65,81,2184,236,16,172,185,169,513]

theorem envBound25121 : H12AffineFastState.Bounded env25121 := by
  intro p hp
  have h : env25121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25120_25121 : H12AffineEnvironment.transform 9 237 env25120 = env25121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 237 env25120 == env25121) = true)

theorem identity25121 : scanCanonicalize (H12AffineFastState.compose env25121 (packedSelected [7] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound25121 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env25122 : List Nat := [2,4,8,16,32,32,128,52,512,141,2048,152,2089,169,2081,2219,137,2081,21,2080,32,137,136,139,2209,184,2217,33,49,2184,140,16,172,185,169,513]

theorem envBound25122 : H12AffineFastState.Bounded env25122 := by
  intro p hp
  have h : env25122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25121_25122 : H12AffineEnvironment.transform 5 32 env25121 = env25122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env25121 == env25122) = true)

def env25123 : List Nat := [2,4,8,16,0,0,128,20,512,141,2048,152,2057,137,2049,2187,137,2049,21,2048,0,137,136,139,2177,152,2185,1,17,2184,140,16,140,153,137,513]

theorem envBound25123 : H12AffineFastState.Bounded env25123 := by
  intro p hp
  have h : env25123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25122_25123 : H12AffineEnvironment.transform 4 0 env25122 = env25123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env25122 == env25123) = true)

theorem identity25123 : scanCanonicalize (H12AffineFastState.compose env25123 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound25123 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25124 : List Nat := [2,4,8,16,0,0,8,20,512,5,2048,16,2057,1,2049,2051,1,2049,21,2048,0,1,0,3,2057,16,2049,1,17,2048,4,16,4,17,1,513]

theorem envBound25124 : H12AffineFastState.Bounded env25124 := by
  intro p hp
  have h : env25124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25123_25124 : H12AffineEnvironment.transform 6 8 env25123 = env25124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env25123 == env25124) = true)

theorem identity25124 : scanCanonicalize (H12AffineFastState.compose env25124 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound25124 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25125 : List Nat := [2,4,8,16,0,0,8,20,1,5,2048,16,2057,1,2049,2051,1,2049,21,2048,0,1,0,3,2057,16,2049,1,17,2048,4,16,4,17,1,0]

theorem envBound25125 : H12AffineFastState.Bounded env25125 := by
  intro p hp
  have h : env25125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25124_25125 : H12AffineEnvironment.transform 8 1 env25124 = env25125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env25124 == env25125) = true)

def env25126 : List Nat := [2,4,8,0,0,0,8,4,1,5,2048,0,2057,1,2049,2051,1,2049,5,2048,0,1,0,3,2057,0,2049,1,1,2048,4,0,4,1,1,0]

theorem envBound25126 : H12AffineFastState.Bounded env25126 := by
  intro p hp
  have h : env25126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25125_25126 : H12AffineEnvironment.transform 3 0 env25125 = env25126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env25125 == env25126) = true)

theorem identity25126 : scanCanonicalize (H12AffineFastState.compose env25126 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 5) := by decide +kernel

theorem selectedBound25126 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25127 : List Nat := [2,4,8,0,0,0,8,4,1,5,5,0,12,1,4,6,1,4,5,5,0,1,0,3,12,0,4,1,1,5,4,0,4,1,1,0]

theorem envBound25127 : H12AffineFastState.Bounded env25127 := by
  intro p hp
  have h : env25127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25126_25127 : H12AffineEnvironment.transform 10 5 env25126 = env25127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 5 env25126 == env25127) = true)

def leafEnv25127 : List Nat := [2,4,8,0,0,0,8,4,1,5,5,0,12,1,4,6,1,4,5,5,0,1,0,3,5,12,1,0,4,1,1,5,4,0,4,1,5,7,1,0,0,1,1]

def active25127 : List Nat := [0,1,2]

def tree25127 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25127 : H12WitnessSearch.Good tree25127 := H12GlobalWitnessIndex.good

theorem leafIdentity25127 : H12AffineFastState.composeSystem env25127 rootObs = leafEnv25127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25127 rootObs == leafEnv25127) = true)

theorem terminalChecked25127 : H12PackedTerminal.terminalCheckFast leafEnv25127 active25127 tree25127 = true := by decide +kernel

def env25128 : List Nat := [2,4,8,1,0,0,8,5,1,5,2048,1,2057,1,2049,2051,1,2049,4,2048,0,1,0,3,2057,1,2049,1,0,2048,4,1,4,0,1,0]

theorem envBound25128 : H12AffineFastState.Bounded env25128 := by
  intro p hp
  have h : env25128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25125_25128 : H12AffineEnvironment.transform 3 1 env25125 = env25128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env25125 == env25128) = true)

theorem identity25128 : scanCanonicalize (H12AffineFastState.compose env25128 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 15) := by decide +kernel

theorem selectedBound25128 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25129 : List Nat := [2,4,8,1,0,0,8,5,1,5,15,1,6,1,14,12,1,14,4,15,0,1,0,3,6,1,14,1,0,15,4,1,4,0,1,0]

theorem envBound25129 : H12AffineFastState.Bounded env25129 := by
  intro p hp
  have h : env25129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25128_25129 : H12AffineEnvironment.transform 10 15 env25128 = env25129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 15 env25128 == env25129) = true)

def leafEnv25129 : List Nat := [2,4,8,1,0,0,8,5,1,5,15,1,6,1,14,12,1,14,4,15,0,1,0,3,4,6,1,1,14,1,0,15,4,1,4,0,4,13,1,0,0,1,1]

def active25129 : List Nat := [0,1,2]

def tree25129 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25129 : H12WitnessSearch.Good tree25129 := H12GlobalWitnessIndex.good

theorem leafIdentity25129 : H12AffineFastState.composeSystem env25129 rootObs = leafEnv25129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25129 rootObs == leafEnv25129) = true)

theorem terminalChecked25129 : H12PackedTerminal.terminalCheckFast leafEnv25129 active25129 tree25129 = true := by decide +kernel

def env25130 : List Nat := [2,4,8,16,1,1,128,21,512,141,2048,152,2056,136,2048,2186,137,2048,21,2049,1,137,136,139,2176,153,2184,0,16,2184,140,16,141,152,136,513]

theorem envBound25130 : H12AffineFastState.Bounded env25130 := by
  intro p hp
  have h : env25130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25122_25130 : H12AffineEnvironment.transform 4 1 env25122 = env25130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env25122 == env25130) = true)

def env25131 : List Nat := [2,4,8,0,1,1,128,5,512,141,2048,136,2056,136,2048,2186,137,2048,5,2049,1,137,136,139,2176,137,2184,0,0,2184,140,0,141,136,136,513]

theorem envBound25131 : H12AffineFastState.Bounded env25131 := by
  intro p hp
  have h : env25131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25130_25131 : H12AffineEnvironment.transform 3 0 env25130 = env25131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env25130 == env25131) = true)

theorem identity25131 : scanCanonicalize (H12AffineFastState.compose env25131 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound25131 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25132 : List Nat := [2,4,8,0,1,1,128,5,137,141,2048,136,2056,136,2048,2186,137,2048,5,2049,1,137,136,139,2176,137,2184,0,0,2184,140,0,141,136,136,136]

theorem envBound25132 : H12AffineFastState.Bounded env25132 := by
  intro p hp
  have h : env25132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25131_25132 : H12AffineEnvironment.transform 8 137 env25131 = env25132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env25131 == env25132) = true)

def env25133 : List Nat := [2,4,8,0,1,1,128,5,137,141,0,136,8,136,0,138,137,0,5,1,1,137,136,139,128,137,136,0,0,136,140,0,141,136,136,136]

theorem envBound25133 : H12AffineFastState.Bounded env25133 := by
  intro p hp
  have h : env25133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25132_25133 : H12AffineEnvironment.transform 10 0 env25132 = env25133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env25132 == env25133) = true)

theorem identity25133 : scanCanonicalize (H12AffineFastState.compose env25133 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound25133 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25134 : List Nat := [2,1,8,0,1,1,128,0,137,136,0,136,8,136,0,138,137,0,0,1,1,137,136,139,128,137,136,0,0,136,137,0,136,136,136,136]

theorem envBound25134 : H12AffineFastState.Bounded env25134 := by
  intro p hp
  have h : env25134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25133_25134 : H12AffineEnvironment.transform 1 1 env25133 = env25134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env25133 == env25134) = true)

def leafEnv25134 : List Nat := [2,1,8,0,1,1,128,0,137,136,0,136,8,136,0,138,137,0,0,1,1,137,136,139,0,128,1,137,136,0,0,136,137,0,136,136,136,3,136,136,0,0,1]

def active25134 : List Nat := [0,2,6]

def tree25134 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25134 : H12WitnessSearch.Good tree25134 := H12GlobalWitnessIndex.good

theorem leafIdentity25134 : H12AffineFastState.composeSystem env25134 rootObs = leafEnv25134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25134 rootObs == leafEnv25134) = true)

theorem terminalChecked25134 : H12PackedTerminal.terminalCheckFast leafEnv25134 active25134 tree25134 = true := by decide +kernel

def env25135 : List Nat := [2,4,8,0,1,1,128,5,137,141,1,136,9,136,1,139,137,1,5,0,1,137,136,139,129,137,137,0,0,137,140,0,141,136,136,136]

theorem envBound25135 : H12AffineFastState.Bounded env25135 := by
  intro p hp
  have h : env25135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25132_25135 : H12AffineEnvironment.transform 10 1 env25132 = env25135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env25132 == env25135) = true)

theorem identity25135 : scanCanonicalize (H12AffineFastState.compose env25135 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 13) := by decide +kernel

theorem selectedBound25135 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25136 : List Nat := [2,4,8,0,1,1,13,5,4,0,1,5,9,5,1,6,4,1,5,0,1,4,5,6,12,4,4,0,0,4,1,0,0,5,5,5]

theorem envBound25136 : H12AffineFastState.Bounded env25136 := by
  intro p hp
  have h : env25136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25135_25136 : H12AffineEnvironment.transform 6 13 env25135 = env25136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 13 env25135 == env25136) = true)

def leafEnv25136 : List Nat := [2,4,8,0,1,1,13,5,4,0,1,5,9,5,1,6,4,1,5,0,1,4,5,6,5,12,1,4,4,0,0,4,1,0,0,5,0,2,5,5,0,0,1]

def active25136 : List Nat := [0,1,2]

def tree25136 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25136 : H12WitnessSearch.Good tree25136 := H12GlobalWitnessIndex.good

theorem leafIdentity25136 : H12AffineFastState.composeSystem env25136 rootObs = leafEnv25136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25136 rootObs == leafEnv25136) = true)

theorem terminalChecked25136 : H12PackedTerminal.terminalCheckFast leafEnv25136 active25136 tree25136 = true := by decide +kernel

def env25137 : List Nat := [2,4,8,1,1,1,128,4,512,141,2048,137,2056,136,2048,2186,137,2048,4,2049,1,137,136,139,2176,136,2184,0,1,2184,140,1,141,137,136,513]

theorem envBound25137 : H12AffineFastState.Bounded env25137 := by
  intro p hp
  have h : env25137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25130_25137 : H12AffineEnvironment.transform 3 1 env25130 = env25137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env25130 == env25137) = true)

theorem identity25137 : scanCanonicalize (H12AffineFastState.compose env25137 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound25137 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25138 : List Nat := [2,4,8,1,1,1,128,4,0,141,2048,137,2056,136,2048,2186,137,2048,4,2049,1,137,136,139,2176,136,2184,0,1,2184,140,1,141,137,136,1]

theorem envBound25138 : H12AffineFastState.Bounded env25138 := by
  intro p hp
  have h : env25138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25137_25138 : H12AffineEnvironment.transform 8 0 env25137 = env25138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env25137 == env25138) = true)

def env25139 : List Nat := [2,4,8,1,1,1,128,4,0,141,0,137,8,136,0,138,137,0,4,1,1,137,136,139,128,136,136,0,1,136,140,1,141,137,136,1]

theorem envBound25139 : H12AffineFastState.Bounded env25139 := by
  intro p hp
  have h : env25139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25138_25139 : H12AffineEnvironment.transform 10 0 env25138 = env25139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env25138 == env25139) = true)

theorem identity25139 : scanCanonicalize (H12AffineFastState.compose env25139 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 6) := by decide +kernel

theorem selectedBound25139 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25140 : List Nat := [2,4,8,1,1,1,6,4,0,11,0,15,8,14,0,12,15,0,4,1,1,15,14,13,6,14,14,0,1,14,10,1,11,15,14,1]

theorem envBound25140 : H12AffineFastState.Bounded env25140 := by
  intro p hp
  have h : env25140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25139_25140 : H12AffineEnvironment.transform 6 6 env25139 = env25140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 6 env25139 == env25140) = true)

def leafEnv25140 : List Nat := [2,4,8,1,1,1,6,4,0,11,0,15,8,14,0,12,15,0,4,1,1,15,14,13,4,6,1,14,14,0,1,14,10,1,11,15,10,3,14,1,0,0,1]

def active25140 : List Nat := [0,1,2]

def tree25140 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25140 : H12WitnessSearch.Good tree25140 := H12GlobalWitnessIndex.good

theorem leafIdentity25140 : H12AffineFastState.composeSystem env25140 rootObs = leafEnv25140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25140 rootObs == leafEnv25140) = true)

theorem terminalChecked25140 : H12PackedTerminal.terminalCheckFast leafEnv25140 active25140 tree25140 = true := by decide +kernel

def env25141 : List Nat := [2,4,8,1,1,1,128,4,0,141,1,137,9,136,1,139,137,1,4,0,1,137,136,139,129,136,137,0,1,137,140,1,141,137,136,1]

theorem envBound25141 : H12AffineFastState.Bounded env25141 := by
  intro p hp
  have h : env25141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25138_25141 : H12AffineEnvironment.transform 10 1 env25138 = env25141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env25138 == env25141) = true)

theorem identity25141 : scanCanonicalize (H12AffineFastState.compose env25141 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound25141 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25142 : List Nat := [2,4,6,1,1,1,128,4,0,131,1,135,7,134,1,133,135,1,4,0,1,135,134,133,129,134,135,0,1,135,130,1,131,135,134,1]

theorem envBound25142 : H12AffineFastState.Bounded env25142 := by
  intro p hp
  have h : env25142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25141_25142 : H12AffineEnvironment.transform 2 6 env25141 = env25142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env25141 == env25142) = true)

def leafEnv25142 : List Nat := [2,4,6,1,1,1,128,4,0,131,1,135,7,134,1,133,135,1,4,0,1,135,134,133,4,129,1,134,135,0,1,135,130,1,131,135,130,2,134,1,0,0,1]

def active25142 : List Nat := [0,1,6]

def tree25142 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25142 : H12WitnessSearch.Good tree25142 := H12GlobalWitnessIndex.good

theorem leafIdentity25142 : H12AffineFastState.composeSystem env25142 rootObs = leafEnv25142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25142 rootObs == leafEnv25142) = true)

theorem terminalChecked25142 : H12PackedTerminal.terminalCheckFast leafEnv25142 active25142 tree25142 = true := by decide +kernel

def env25143 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,131072,262144,132421,32769,2097152,2102665,131413,2200833,8328,98355,262280,2331766,2196599,2202882,2330679,2229505,131141,2327842,2330739,513]

theorem envBound25143 : H12AffineFastState.Bounded env25143 := by
  intro p hp
  have h : env25143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25031_25143 : H12AffineEnvironment.transform 21 2102665 env25031 = env25143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2102665 env25031 == env25143) = true)

theorem identity25143 : scanCanonicalize (H12AffineFastState.compose env25143 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 324) := by decide +kernel

theorem selectedBound25143 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env25144 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,324,8192,1296,32768,65536,131072,262144,132421,32769,2097152,2098381,131413,2196549,8328,98355,262280,2327858,2196599,2198598,2326899,2229505,131141,2327842,2326839,513]

theorem envBound25144 : H12AffineFastState.Bounded env25144 := by
  intro p hp
  have h : env25144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25143_25144 : H12AffineEnvironment.transform 11 324 env25143 = env25144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 324 env25143 == env25144) = true)

def env25145 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,131072,262144,524288,32769,2097152,4194304,525329,4292744,8328,7049470,262280,4424190,4297215,4294795,2330679,4329609,525568,4427946,4817086,513]

theorem envBound25145 : H12AffineFastState.Bounded env25145 := by
  intro p hp
  have h : env25145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25029_25145 : H12AffineEnvironment.transform 13 1297 env25029 = env25145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env25029 == env25145) = true)

theorem identity25145 : scanCanonicalize (H12AffineFastState.compose env25145 (packedSelected [0,6,27] rootPS)) = affineNative (2^(20+1) ^^^ 626727) := by decide +kernel

theorem selectedBound25145 : packedSelected [0,6,27] rootPS < 2^1333 := by decide +kernel

def env25146 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,131072,262144,524288,32769,626727,4194304,525329,4292744,8328,4325593,262280,4424190,4297215,4294795,655376,4329609,525568,4427946,4817086,513]

theorem envBound25146 : H12AffineFastState.Bounded env25146 := by
  intro p hp
  have h : env25146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25145_25146 : H12AffineEnvironment.transform 20 626727 env25145 = env25146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 626727 env25145 == env25146) = true)

def env25147 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,131072,262144,136192,32769,230439,4194304,135185,4292744,8328,4325593,262280,4424190,4297215,4294795,5136,4329609,135424,4427946,4428990,513]

theorem envBound25147 : H12AffineFastState.Bounded env25147 := by
  intro p hp
  have h : env25147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25146_25147 : H12AffineEnvironment.transform 18 136192 env25146 = env25147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env25146 == env25147) = true)

theorem identity25147 : scanCanonicalize (H12AffineFastState.compose env25147 (packedSelected [6] rootPS)) = affineNative (2^(16+1) ^^^ 102515) := by decide +kernel

theorem selectedBound25147 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env25148 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,102515,262144,99443,32769,5204,4194304,98402,4292744,8328,4296874,262280,4198797,4297215,4294795,5136,4292858,98675,4194521,4195533,513]

theorem envBound25148 : H12AffineFastState.Bounded env25148 := by
  intro p hp
  have h : env25148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25147_25148 : H12AffineEnvironment.transform 16 102515 env25147 = env25148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 102515 env25147 == env25148) = true)

theorem identity25148 : scanCanonicalize (H12AffineFastState.compose env25148 (packedSelected [0,7,14,20] rootPS)) = affineNative (2^(21+1) ^^^ 4248) := by decide +kernel

theorem selectedBound25148 : packedSelected [0,7,14,20] rootPS < 2^1333 := by decide +kernel

def env25149 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,102515,262144,99443,32769,5204,4248,98402,102416,8328,98354,262280,277,98663,104467,5136,102498,98675,4161,5205,513]

theorem envBound25149 : H12AffineFastState.Bounded env25149 := by
  intro p hp
  have h : env25149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25148_25149 : H12AffineEnvironment.transform 21 4248 env25148 = env25149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 4248 env25148 == env25149) = true)

theorem identity25149 : scanCanonicalize (H12AffineFastState.compose env25149 (packedSelected [1,3,5,8,10,12,14] rootPS)) = affineNative (2^(15+1) ^^^ 37019) := by decide +kernel

theorem selectedBound25149 : packedSelected [1,3,5,8,10,12,14] rootPS < 2^1333 := by decide +kernel

def env25150 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,37019,232,262144,5352,32769,5204,4248,4345,139,8328,4265,262280,277,4604,2184,5136,249,4584,4161,5205,513]

theorem envBound25150 : H12AffineFastState.Bounded env25150 := by
  intro p hp
  have h : env25150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25149_25150 : H12AffineEnvironment.transform 15 37019 env25149 = env25150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 37019 env25149 == env25150) = true)

theorem identity25150 : scanCanonicalize (H12AffineFastState.compose env25150 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound25150 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env25151 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,37019,232,43049,5352,32769,5204,4248,4345,139,8328,4265,43169,277,4604,2184,5136,249,4584,4161,5205,513]

theorem envBound25151 : H12AffineFastState.Bounded env25151 := by
  intro p hp
  have h : env25151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25150_25151 : H12AffineEnvironment.transform 17 43049 env25150 = env25151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env25150 == env25151) = true)

def env25152 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,232,8192,1297,32768,32883,232,43049,1024,32769,1212,112,17,139,8328,65,43169,277,276,2184,1272,249,256,169,1213,513]

theorem envBound25152 : H12AffineFastState.Bounded env25152 := by
  intro p hp
  have h : env25152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25151_25152 : H12AffineEnvironment.transform 11 232 env25151 = env25152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 232 env25151 == env25152) = true)

theorem identity25152 : scanCanonicalize (H12AffineFastState.compose env25152 (packedSelected [0,2,7] rootPS)) = affineNative (2^(9+1) ^^^ 881) := by decide +kernel

theorem selectedBound25152 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env25153 : List Nat := [2,4,8,16,32,64,128,256,512,881,2048,232,8192,608,32768,32883,232,43049,881,32769,973,112,17,139,8328,65,43169,277,276,2184,905,249,256,169,972,513]

theorem envBound25153 : H12AffineFastState.Bounded env25153 := by
  intro p hp
  have h : env25153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25152_25153 : H12AffineEnvironment.transform 9 881 env25152 = env25153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 881 env25152 == env25153) = true)

theorem identity25153 : scanCanonicalize (H12AffineFastState.compose env25153 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 356) := by decide +kernel

theorem selectedBound25153 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env25154 : List Nat := [2,4,8,16,32,64,128,256,356,21,2048,232,8192,260,32768,32883,232,43049,21,32769,169,112,17,139,8328,65,43169,277,276,2184,237,249,256,169,168,357]

theorem envBound25154 : H12AffineFastState.Bounded env25154 := by
  intro p hp
  have h : env25154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25153_25154 : H12AffineEnvironment.transform 8 356 env25153 = env25154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 356 env25153 == env25154) = true)

theorem identity25154 : scanCanonicalize (H12AffineFastState.compose env25154 (packedSelected [0,2,4,11] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound25154 : packedSelected [0,2,4,11] rootPS < 2^1333 := by decide +kernel

def env25155 : List Nat := [2,4,8,16,32,64,57,256,356,21,2048,81,8192,260,32768,32883,81,43049,21,32769,16,112,17,50,8241,65,43032,277,276,2097,84,64,256,16,17,357]

theorem envBound25155 : H12AffineFastState.Bounded env25155 := by
  intro p hp
  have h : env25155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25154_25155 : H12AffineEnvironment.transform 6 57 env25154 = env25155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env25154 == env25155) = true)

def env25156 : List Nat := [2,4,8,16,16,64,9,256,340,21,2048,81,8192,260,32768,32835,81,43033,21,32769,16,64,17,2,8193,65,43032,277,276,2049,84,64,256,16,17,341]

theorem envBound25156 : H12AffineFastState.Bounded env25156 := by
  intro p hp
  have h : env25156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25155_25156 : H12AffineEnvironment.transform 4 16 env25155 = env25156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env25155 == env25156) = true)

theorem identity25156 : scanCanonicalize (H12AffineFastState.compose env25156 (packedSelected [0] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound25156 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25157 : List Nat := [2,4,8,16,16,64,9,256,340,21,2048,81,8192,260,8461,8526,81,2324,21,8460,16,64,17,2,8193,65,2325,277,276,2049,84,64,256,16,17,341]

theorem envBound25157 : H12AffineFastState.Bounded env25157 := by
  intro p hp
  have h : env25157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25156_25157 : H12AffineEnvironment.transform 14 8461 env25156 = env25157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env25156 == env25157) = true)

theorem identity25157 : scanCanonicalize (H12AffineFastState.compose env25157 (packedSelected [1,4,8] rootPS)) = affineNative (2^(12+1) ^^^ 2397) := by decide +kernel

theorem selectedBound25157 : packedSelected [1,4,8] rootPS < 2^1333 := by decide +kernel

def env25158 : List Nat := [2,4,8,16,16,64,9,256,340,21,2048,81,2397,260,2128,2067,81,2324,21,2129,16,64,17,2,2396,65,2325,277,276,2049,84,64,256,16,17,341]

theorem envBound25158 : H12AffineFastState.Bounded env25158 := by
  intro p hp
  have h : env25158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25157_25158 : H12AffineEnvironment.transform 12 2397 env25157 = env25158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2397 env25157 == env25158) = true)

theorem identity25158 : scanCanonicalize (H12AffineFastState.compose env25158 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound25158 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env25159 : List Nat := [2,4,8,16,16,64,9,20,64,21,2048,81,2121,16,2128,2067,81,2048,21,2129,16,64,17,2,2120,65,2049,1,0,2049,84,64,20,16,17,65]

theorem envBound25159 : H12AffineFastState.Bounded env25159 := by
  intro p hp
  have h : env25159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25158_25159 : H12AffineEnvironment.transform 7 20 env25158 = env25159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env25158 == env25159) = true)

theorem identity25159 : scanCanonicalize (H12AffineFastState.compose env25159 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound25159 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25160 : List Nat := [2,4,8,16,16,0,9,20,0,21,2048,17,2057,16,2064,2067,17,2048,21,2065,16,0,17,2,2056,1,2049,1,0,2049,20,0,20,16,17,1]

theorem envBound25160 : H12AffineFastState.Bounded env25160 := by
  intro p hp
  have h : env25160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25159_25160 : H12AffineEnvironment.transform 5 0 env25159 = env25160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env25159 == env25160) = true)

def env25161 : List Nat := [2,4,8,16,16,0,9,20,0,21,0,17,9,16,16,19,17,0,21,17,16,0,17,2,8,1,1,1,0,1,20,0,20,16,17,1]

theorem envBound25161 : H12AffineFastState.Bounded env25161 := by
  intro p hp
  have h : env25161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25160_25161 : H12AffineEnvironment.transform 10 0 env25160 = env25161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env25160 == env25161) = true)

theorem identity25161 : scanCanonicalize (H12AffineFastState.compose env25161 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound25161 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25162 : List Nat := [2,4,8,4,4,0,9,0,0,1,0,5,9,4,4,7,5,0,1,5,4,0,5,2,8,1,1,1,0,1,0,0,0,4,5,1]

theorem envBound25162 : H12AffineFastState.Bounded env25162 := by
  intro p hp
  have h : env25162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25161_25162 : H12AffineEnvironment.transform 3 4 env25161 = env25162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env25161 == env25162) = true)

def leafEnv25162 : List Nat := [2,4,8,4,4,0,9,0,0,1,0,5,9,4,4,7,5,0,1,5,4,0,5,2,1,8,1,1,1,1,0,1,0,0,0,4,5,7,5,1,0,4,1]

def active25162 : List Nat := [0,1,2]

def tree25162 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25162 : H12WitnessSearch.Good tree25162 := H12GlobalWitnessIndex.good

theorem leafIdentity25162 : H12AffineFastState.composeSystem env25162 rootObs = leafEnv25162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25162 rootObs == leafEnv25162) = true)

theorem terminalChecked25162 : H12PackedTerminal.terminalCheckFast leafEnv25162 active25162 tree25162 = true := by decide +kernel

def env25163 : List Nat := [2,4,8,16,16,0,9,20,0,21,1,17,8,16,17,18,17,1,21,16,16,0,17,2,9,1,0,1,0,0,20,0,20,16,17,1]

theorem envBound25163 : H12AffineFastState.Bounded env25163 := by
  intro p hp
  have h : env25163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25160_25163 : H12AffineEnvironment.transform 10 1 env25160 = env25163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env25160 == env25163) = true)

theorem identity25163 : scanCanonicalize (H12AffineFastState.compose env25163 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound25163 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25164 : List Nat := [2,0,8,16,16,0,9,16,0,17,1,17,8,16,17,18,17,1,17,16,16,0,17,2,9,1,0,1,0,0,16,0,16,16,17,1]

theorem envBound25164 : H12AffineFastState.Bounded env25164 := by
  intro p hp
  have h : env25164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25163_25164 : H12AffineEnvironment.transform 1 0 env25163 = env25164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env25163 == env25164) = true)

def leafEnv25164 : List Nat := [2,0,8,16,16,0,9,16,0,17,1,17,8,16,17,18,17,1,17,16,16,0,17,2,17,9,1,1,0,1,0,0,16,0,16,16,1,18,17,1,0,16,1]

def active25164 : List Nat := [0,2,3]

def tree25164 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25164 : H12WitnessSearch.Good tree25164 := H12GlobalWitnessIndex.good

theorem leafIdentity25164 : H12AffineFastState.composeSystem env25164 rootObs = leafEnv25164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25164 rootObs == leafEnv25164) = true)

theorem terminalChecked25164 : H12PackedTerminal.terminalCheckFast leafEnv25164 active25164 tree25164 = true := by decide +kernel

def env25165 : List Nat := [2,4,8,16,17,64,8,256,341,21,2048,81,8192,260,32768,32834,81,43032,21,32769,16,65,17,3,8192,65,43032,277,276,2048,84,64,256,16,17,340]

theorem envBound25165 : H12AffineFastState.Bounded env25165 := by
  intro p hp
  have h : env25165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25155_25165 : H12AffineEnvironment.transform 4 17 env25155 = env25165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env25155 == env25165) = true)

theorem identity25165 : scanCanonicalize (H12AffineFastState.compose env25165 (packedSelected [0] rootPS)) = affineNative (2^(14+1) ^^^ 2372) := by decide +kernel

theorem selectedBound25165 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25166 : List Nat := [2,4,8,16,17,64,8,256,341,21,2048,81,8192,260,2372,2310,81,8540,21,2373,16,65,17,3,8192,65,8540,277,276,2048,84,64,256,16,17,340]

theorem envBound25166 : H12AffineFastState.Bounded env25166 := by
  intro p hp
  have h : env25166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25165_25166 : H12AffineEnvironment.transform 14 2372 env25165 = env25166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2372 env25165 == env25166) = true)

theorem identity25166 : scanCanonicalize (H12AffineFastState.compose env25166 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound25166 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25167 : List Nat := [2,4,8,16,17,64,8,21,64,21,2048,81,8192,17,2129,2067,81,8265,21,2128,16,65,17,3,8192,65,8265,0,1,2048,84,64,21,16,17,65]

theorem envBound25167 : H12AffineFastState.Bounded env25167 := by
  intro p hp
  have h : env25167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25166_25167 : H12AffineEnvironment.transform 7 21 env25166 = env25167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env25166 == env25167) = true)

theorem identity25167 : scanCanonicalize (H12AffineFastState.compose env25167 (packedSelected [4] rootPS)) = affineNative (2^(12+1) ^^^ 2120) := by decide +kernel

theorem selectedBound25167 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env25168 : List Nat := [2,4,8,16,17,64,8,21,64,21,2048,81,2120,17,2129,2067,81,2049,21,2128,16,65,17,3,2120,65,2049,0,1,2048,84,64,21,16,17,65]

theorem envBound25168 : H12AffineFastState.Bounded env25168 := by
  intro p hp
  have h : env25168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25167_25168 : H12AffineEnvironment.transform 12 2120 env25167 = env25168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2120 env25167 == env25168) = true)

theorem identity25168 : scanCanonicalize (H12AffineFastState.compose env25168 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound25168 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25169 : List Nat := [2,4,8,16,17,0,8,21,0,21,2048,17,2056,17,2065,2067,17,2049,21,2064,16,1,17,3,2056,1,2049,0,1,2048,20,0,21,16,17,1]

theorem envBound25169 : H12AffineFastState.Bounded env25169 := by
  intro p hp
  have h : env25169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25168_25169 : H12AffineEnvironment.transform 5 0 env25168 = env25169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env25168 == env25169) = true)

def env25170 : List Nat := [2,4,8,16,17,0,8,21,0,21,0,17,8,17,17,19,17,1,21,16,16,1,17,3,8,1,1,0,1,0,20,0,21,16,17,1]

theorem envBound25170 : H12AffineFastState.Bounded env25170 := by
  intro p hp
  have h : env25170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25169_25170 : H12AffineEnvironment.transform 10 0 env25169 = env25170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env25169 == env25170) = true)

theorem identity25170 : scanCanonicalize (H12AffineFastState.compose env25170 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound25170 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25171 : List Nat := [2,0,8,16,17,0,8,17,0,17,0,17,8,17,17,19,17,1,17,16,16,1,17,3,8,1,1,0,1,0,16,0,17,16,17,1]

theorem envBound25171 : H12AffineFastState.Bounded env25171 := by
  intro p hp
  have h : env25171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25170_25171 : H12AffineEnvironment.transform 1 0 env25170 = env25171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env25170 == env25171) = true)

def leafEnv25171 : List Nat := [2,0,8,16,17,0,8,17,0,17,0,17,8,17,17,19,17,1,17,16,16,1,17,3,17,8,1,1,1,0,1,0,16,0,17,16,1,18,17,1,0,17,1]

def active25171 : List Nat := [0,2,3]

def tree25171 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25171 : H12WitnessSearch.Good tree25171 := H12GlobalWitnessIndex.good

theorem leafIdentity25171 : H12AffineFastState.composeSystem env25171 rootObs = leafEnv25171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25171 rootObs == leafEnv25171) = true)

theorem terminalChecked25171 : H12PackedTerminal.terminalCheckFast leafEnv25171 active25171 tree25171 = true := by decide +kernel

def env25172 : List Nat := [2,4,8,16,17,0,8,21,0,21,1,17,9,17,16,18,17,0,21,17,16,1,17,3,9,1,0,0,1,1,20,0,21,16,17,1]

theorem envBound25172 : H12AffineFastState.Bounded env25172 := by
  intro p hp
  have h : env25172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25169_25172 : H12AffineEnvironment.transform 10 1 env25169 = env25172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env25169 == env25172) = true)

theorem identity25172 : scanCanonicalize (H12AffineFastState.compose env25172 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound25172 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25173 : List Nat := [2,4,8,4,5,0,8,1,0,1,1,5,9,5,4,6,5,0,1,5,4,1,5,3,9,1,0,0,1,1,0,0,1,4,5,1]

theorem envBound25173 : H12AffineFastState.Bounded env25173 := by
  intro p hp
  have h : env25173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25172_25173 : H12AffineEnvironment.transform 3 4 env25172 = env25173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env25172 == env25173) = true)

def leafEnv25173 : List Nat := [2,4,8,4,5,0,8,1,0,1,1,5,9,5,4,6,5,0,1,5,4,1,5,3,1,9,1,1,0,0,1,1,0,0,1,4,5,7,5,1,0,5,1]

def active25173 : List Nat := [0,1,2]

def tree25173 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25173 : H12WitnessSearch.Good tree25173 := H12GlobalWitnessIndex.good

theorem leafIdentity25173 : H12AffineFastState.composeSystem env25173 rootObs = leafEnv25173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25173 rootObs == leafEnv25173) = true)

theorem terminalChecked25173 : H12PackedTerminal.terminalCheckFast leafEnv25173 active25173 tree25173 = true := by decide +kernel

def env25174 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,233,8192,1297,32768,32882,232,43049,1025,32769,1213,113,16,139,8328,64,43169,277,277,2184,1273,249,257,168,1212,513]

theorem envBound25174 : H12AffineFastState.Bounded env25174 := by
  intro p hp
  have h : env25174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25151_25174 : H12AffineEnvironment.transform 11 233 env25151 = env25174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 233 env25151 == env25174) = true)

theorem identity25174 : scanCanonicalize (H12AffineFastState.compose env25174 (packedSelected [0,2,7] rootPS)) = affineNative (2^(9+1) ^^^ 652) := by decide +kernel

theorem selectedBound25174 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env25175 : List Nat := [2,4,8,16,32,64,128,256,512,652,2048,233,8192,925,32768,32882,232,43049,653,32769,561,113,16,139,8328,64,43169,277,277,2184,629,249,257,168,560,513]

theorem envBound25175 : H12AffineFastState.Bounded env25175 := by
  intro p hp
  have h : env25175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25174_25175 : H12AffineEnvironment.transform 9 652 env25174 = env25175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 652 env25174 == env25175) = true)

theorem identity25175 : scanCanonicalize (H12AffineFastState.compose env25175 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 8808) := by decide +kernel

theorem selectedBound25175 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env25176 : List Nat := [2,4,8,16,32,64,128,256,512,652,2048,233,8192,925,8808,8730,232,2625,653,8809,561,113,16,139,8328,64,2761,277,277,2184,629,249,257,168,560,513]

theorem envBound25176 : H12AffineFastState.Bounded env25176 := by
  intro p hp
  have h : env25176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25175_25176 : H12AffineEnvironment.transform 14 8808 env25175 = env25176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8808 env25175 == env25176) = true)

theorem identity25176 : scanCanonicalize (H12AffineFastState.compose env25176 (packedSelected [0,2,4,11] rootPS)) = affineNative (2^(8+1) ^^^ 397) := by decide +kernel

theorem selectedBound25176 : packedSelected [0,2,4,11] rootPS < 2^1333 := by decide +kernel

def env25177 : List Nat := [2,4,8,16,32,64,128,256,397,257,2048,233,8192,16,8677,8599,232,2508,256,8676,444,113,16,139,8328,64,2372,277,277,2184,504,249,257,168,445,396]

theorem envBound25177 : H12AffineFastState.Bounded env25177 := by
  intro p hp
  have h : env25177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25176_25177 : H12AffineEnvironment.transform 8 397 env25176 = env25177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 397 env25176 == env25177) = true)

def env25178 : List Nat := [2,4,8,16,32,64,8,256,261,257,2048,97,8192,16,8557,8479,96,2372,256,8556,308,113,16,3,8192,64,2372,277,277,2048,368,113,257,32,309,260]

theorem envBound25178 : H12AffineFastState.Bounded env25178 := by
  intro p hp
  have h : env25178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25177_25178 : H12AffineEnvironment.transform 6 8 env25177 = env25178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env25177 == env25178) = true)

theorem identity25178 : scanCanonicalize (H12AffineFastState.compose env25178 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound25178 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25179 : List Nat := [2,4,8,16,32,64,8,37,32,36,2048,97,8192,16,8264,8250,96,2145,37,8265,17,113,16,3,8192,64,2145,48,48,2048,85,113,36,32,16,33]

theorem envBound25179 : H12AffineFastState.Bounded env25179 := by
  intro p hp
  have h : env25179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25178_25179 : H12AffineEnvironment.transform 7 37 env25178 = env25179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env25178 == env25179) = true)

theorem identity25179 : scanCanonicalize (H12AffineFastState.compose env25179 (packedSelected [0,1,3] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound25179 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env25180 : List Nat := [2,4,8,16,32,32,8,37,32,36,2048,1,8192,16,8232,8250,0,2049,37,8233,17,17,16,3,8192,32,2049,48,48,2048,53,17,36,32,16,33]

theorem envBound25180 : H12AffineFastState.Bounded env25180 := by
  intro p hp
  have h : env25180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25179_25180 : H12AffineEnvironment.transform 5 32 env25179 = env25180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env25179 == env25180) = true)

theorem identity25180 : scanCanonicalize (H12AffineFastState.compose env25180 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 2104) := by decide +kernel

theorem selectedBound25180 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25181 : List Nat := [2,4,8,16,32,32,8,37,32,36,2048,1,2104,16,2064,2050,0,2049,37,2065,17,17,16,3,2104,32,2049,48,48,2048,53,17,36,32,16,33]

theorem envBound25181 : H12AffineFastState.Bounded env25181 := by
  intro p hp
  have h : env25181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25180_25181 : H12AffineEnvironment.transform 12 2104 env25180 = env25181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2104 env25180 == env25181) = true)

theorem identity25181 : scanCanonicalize (H12AffineFastState.compose env25181 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound25181 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env25182 : List Nat := [2,4,8,16,0,0,8,5,0,4,2048,1,2072,16,2064,2050,0,2049,5,2065,17,17,16,3,2072,0,2049,16,16,2048,21,17,4,0,16,1]

theorem envBound25182 : H12AffineFastState.Bounded env25182 := by
  intro p hp
  have h : env25182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25181_25182 : H12AffineEnvironment.transform 4 0 env25181 = env25182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env25181 == env25182) = true)

def env25183 : List Nat := [2,4,8,16,0,0,8,5,0,4,0,1,24,16,16,2,0,1,5,17,17,17,16,3,24,0,1,16,16,0,21,17,4,0,16,1]

theorem envBound25183 : H12AffineFastState.Bounded env25183 := by
  intro p hp
  have h : env25183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25182_25183 : H12AffineEnvironment.transform 10 0 env25182 = env25183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env25182 == env25183) = true)

theorem identity25183 : scanCanonicalize (H12AffineFastState.compose env25183 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 14) := by decide +kernel

theorem selectedBound25183 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25184 : List Nat := [2,4,8,14,0,0,8,5,0,4,0,1,6,14,14,2,0,1,5,15,15,15,14,3,6,0,1,14,14,0,11,15,4,0,14,1]

theorem envBound25184 : H12AffineFastState.Bounded env25184 := by
  intro p hp
  have h : env25184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25183_25184 : H12AffineEnvironment.transform 3 14 env25183 = env25184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 14 env25183 == env25184) = true)

def leafEnv25184 : List Nat := [2,4,8,14,0,0,8,5,0,4,0,1,6,14,14,2,0,1,5,15,15,15,14,3,11,6,1,0,1,14,14,0,11,15,4,0,4,3,14,1,0,14,1]

def active25184 : List Nat := [0,1,2]

def tree25184 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25184 : H12WitnessSearch.Good tree25184 := H12GlobalWitnessIndex.good

theorem leafIdentity25184 : H12AffineFastState.composeSystem env25184 rootObs = leafEnv25184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25184 rootObs == leafEnv25184) = true)

theorem terminalChecked25184 : H12PackedTerminal.terminalCheckFast leafEnv25184 active25184 tree25184 = true := by decide +kernel

def env25185 : List Nat := [2,4,8,16,0,0,8,5,0,4,1,1,25,16,17,3,0,0,5,16,17,17,16,3,25,0,0,16,16,1,21,17,4,0,16,1]

theorem envBound25185 : H12AffineFastState.Bounded env25185 := by
  intro p hp
  have h : env25185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25182_25185 : H12AffineEnvironment.transform 10 1 env25182 = env25185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env25182 == env25185) = true)

theorem identity25185 : scanCanonicalize (H12AffineFastState.compose env25185 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound25185 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25186 : List Nat := [2,4,7,16,0,0,7,5,0,4,1,1,22,16,17,3,0,0,5,16,17,17,16,3,22,0,0,16,16,1,21,17,4,0,16,1]

theorem envBound25186 : H12AffineFastState.Bounded env25186 := by
  intro p hp
  have h : env25186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25185_25186 : H12AffineEnvironment.transform 2 7 env25185 = env25186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env25185 == env25186) = true)

def leafEnv25186 : List Nat := [2,4,7,16,0,0,7,5,0,4,1,1,22,16,17,3,0,0,5,16,17,17,16,3,21,22,1,0,0,16,16,1,21,17,4,0,4,2,16,1,0,16,1]

def active25186 : List Nat := [0,1,3]

def tree25186 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25186 : H12WitnessSearch.Good tree25186 := H12GlobalWitnessIndex.good

theorem leafIdentity25186 : H12AffineFastState.composeSystem env25186 rootObs = leafEnv25186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25186 rootObs == leafEnv25186) = true)

theorem terminalChecked25186 : H12PackedTerminal.terminalCheckFast leafEnv25186 active25186 tree25186 = true := by decide +kernel

def env25187 : List Nat := [2,4,8,16,32,64,9,256,260,257,2048,96,8192,16,8556,8478,97,2373,256,8557,309,113,16,2,8193,64,2372,277,277,2049,369,112,257,33,308,261]

theorem envBound25187 : H12AffineFastState.Bounded env25187 := by
  intro p hp
  have h : env25187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25177_25187 : H12AffineEnvironment.transform 6 9 env25177 = env25187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env25177 == env25187) = true)

theorem identity25187 : scanCanonicalize (H12AffineFastState.compose env25187 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound25187 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25188 : List Nat := [2,4,8,16,32,32,9,256,260,257,2048,0,8192,16,8460,8478,1,2341,256,8461,309,17,16,2,8193,32,2340,277,277,2049,273,16,257,33,308,261]

theorem envBound25188 : H12AffineFastState.Bounded env25188 := by
  intro p hp
  have h : env25188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25187_25188 : H12AffineEnvironment.transform 5 32 env25187 = env25188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env25187 == env25188) = true)

theorem identity25188 : scanCanonicalize (H12AffineFastState.compose env25188 (packedSelected [0,1,3] rootPS)) = affineNative (2^(12+1) ^^^ 2365) := by decide +kernel

theorem selectedBound25188 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env25189 : List Nat := [2,4,8,16,32,32,9,256,260,257,2048,0,2365,16,2097,2083,1,2341,256,2096,309,17,16,2,2364,32,2340,277,277,2049,273,16,257,33,308,261]

theorem envBound25189 : H12AffineFastState.Bounded env25189 := by
  intro p hp
  have h : env25189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25188_25189 : H12AffineEnvironment.transform 12 2365 env25188 = env25189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2365 env25188 == env25189) = true)

theorem identity25189 : scanCanonicalize (H12AffineFastState.compose env25189 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound25189 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env25190 : List Nat := [2,4,8,16,32,32,9,37,33,36,2048,0,2072,16,2097,2083,1,2048,37,2096,16,17,16,2,2073,32,2049,48,48,2049,52,16,36,33,17,32]

theorem envBound25190 : H12AffineFastState.Bounded env25190 := by
  intro p hp
  have h : env25190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25189_25190 : H12AffineEnvironment.transform 7 37 env25189 = env25190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env25189 == env25190) = true)

theorem identity25190 : scanCanonicalize (H12AffineFastState.compose env25190 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound25190 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25191 : List Nat := [2,4,8,16,1,1,9,4,0,5,2048,0,2072,16,2064,2050,1,2048,4,2065,16,17,16,2,2073,1,2049,17,17,2049,21,16,5,0,17,1]

theorem envBound25191 : H12AffineFastState.Bounded env25191 := by
  intro p hp
  have h : env25191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25190_25191 : H12AffineEnvironment.transform 4 1 env25190 = env25191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env25190 == env25191) = true)

def env25192 : List Nat := [2,4,8,16,1,1,9,4,0,5,0,0,24,16,16,2,1,0,4,17,16,17,16,2,25,1,1,17,17,1,21,16,5,0,17,1]

theorem envBound25192 : H12AffineFastState.Bounded env25192 := by
  intro p hp
  have h : env25192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25191_25192 : H12AffineEnvironment.transform 10 0 env25191 = env25192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env25191 == env25192) = true)

theorem identity25192 : scanCanonicalize (H12AffineFastState.compose env25192 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 14) := by decide +kernel

theorem selectedBound25192 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25193 : List Nat := [2,4,8,14,1,1,9,4,0,5,0,0,6,14,14,2,1,0,4,15,14,15,14,2,7,1,1,15,15,1,11,14,5,0,15,1]

theorem envBound25193 : H12AffineFastState.Bounded env25193 := by
  intro p hp
  have h : env25193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25192_25193 : H12AffineEnvironment.transform 3 14 env25192 = env25193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 14 env25192 == env25193) = true)

def leafEnv25193 : List Nat := [2,4,8,14,1,1,9,4,0,5,0,0,6,14,14,2,1,0,4,15,14,15,14,2,11,7,1,1,1,15,15,1,11,14,5,0,4,2,15,1,0,14,1]

def active25193 : List Nat := [0,1,2]

def tree25193 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25193 : H12WitnessSearch.Good tree25193 := H12GlobalWitnessIndex.good

theorem leafIdentity25193 : H12AffineFastState.composeSystem env25193 rootObs = leafEnv25193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25193 rootObs == leafEnv25193) = true)

theorem terminalChecked25193 : H12PackedTerminal.terminalCheckFast leafEnv25193 active25193 tree25193 = true := by decide +kernel

def env25194 : List Nat := [2,4,8,16,1,1,9,4,0,5,1,0,25,16,17,3,1,1,4,16,16,17,16,2,24,1,0,17,17,0,21,16,5,0,17,1]

theorem envBound25194 : H12AffineFastState.Bounded env25194 := by
  intro p hp
  have h : env25194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25191_25194 : H12AffineEnvironment.transform 10 1 env25191 = env25194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env25191 == env25194) = true)

theorem identity25194 : scanCanonicalize (H12AffineFastState.compose env25194 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound25194 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25195 : List Nat := [2,4,6,16,1,1,7,4,0,5,1,0,23,16,17,3,1,1,4,16,16,17,16,2,22,1,0,17,17,0,21,16,5,0,17,1]

theorem envBound25195 : H12AffineFastState.Bounded env25195 := by
  intro p hp
  have h : env25195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25194_25195 : H12AffineEnvironment.transform 2 6 env25194 = env25195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env25194 == env25195) = true)

def leafEnv25195 : List Nat := [2,4,6,16,1,1,7,4,0,5,1,0,23,16,17,3,1,1,4,16,16,17,16,2,21,22,1,1,0,17,17,0,21,16,5,0,4,3,17,1,0,16,1]

def active25195 : List Nat := [0,1,3]

def tree25195 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25195 : H12WitnessSearch.Good tree25195 := H12GlobalWitnessIndex.good

theorem leafIdentity25195 : H12AffineFastState.composeSystem env25195 rootObs = leafEnv25195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25195 rootObs == leafEnv25195) = true)

theorem terminalChecked25195 : H12PackedTerminal.terminalCheckFast leafEnv25195 active25195 tree25195 = true := by decide +kernel

def env25196 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,131072,262144,136193,32769,230438,4194304,135184,4292744,8328,4325593,262280,4424190,4297215,4294795,5137,4329609,135425,4427946,4428991,513]

theorem envBound25196 : H12AffineFastState.Bounded env25196 := by
  intro p hp
  have h : env25196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25146_25196 : H12AffineEnvironment.transform 18 136193 env25146 = env25196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env25146 == env25196) = true)

theorem identity25196 : scanCanonicalize (H12AffineFastState.compose env25196 (packedSelected [6] rootPS)) = affineNative (2^(21+1) ^^^ 4249) := by decide +kernel

theorem selectedBound25196 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env25197 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,131072,262144,136193,32769,230438,4249,135184,102417,8328,135232,262280,233831,98662,104466,5137,131088,135425,229427,230438,513]

theorem envBound25197 : H12AffineFastState.Bounded env25197 := by
  intro p hp
  have h : env25197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25196_25197 : H12AffineEnvironment.transform 21 4249 env25196 = env25197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 4249 env25196 == env25197) = true)

theorem identity25197 : scanCanonicalize (H12AffineFastState.compose env25197 (packedSelected [0,7,14,20] rootPS)) = affineNative (2^(16+1) ^^^ 102514) := by decide +kernel

theorem selectedBound25197 : packedSelected [0,7,14,20] rootPS < 2^1333 := by decide +kernel

def env25198 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,102514,262144,99443,32769,5204,4249,98402,102417,8328,98354,262280,277,98662,104466,5137,102498,98675,4161,5204,513]

theorem envBound25198 : H12AffineFastState.Bounded env25198 := by
  intro p hp
  have h : env25198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25197_25198 : H12AffineEnvironment.transform 16 102514 env25197 = env25198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 102514 env25197 == env25198) = true)

theorem identity25198 : scanCanonicalize (H12AffineFastState.compose env25198 (packedSelected [1,3,5,8,10,12,14] rootPS)) = affineNative (2^(17+1) ^^^ 80051) := by decide +kernel

theorem selectedBound25198 : packedSelected [1,3,5,8,10,12,14] rootPS < 2^1333 := by decide +kernel

def env25199 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,102514,80051,99443,32769,5204,4249,98402,102417,8328,98354,79931,277,98662,104466,5137,102498,98675,4161,5204,513]

theorem envBound25199 : H12AffineFastState.Bounded env25199 := by
  intro p hp
  have h : env25199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25198_25199 : H12AffineEnvironment.transform 17 80051 env25198 = env25199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 80051 env25198 == env25199) = true)

theorem identity25199 : scanCanonicalize (H12AffineFastState.compose env25199 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 37018) := by decide +kernel

theorem selectedBound25199 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env25200 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,37018,232,43049,5353,32769,5204,4249,4344,139,8328,4264,43169,277,4604,2184,5137,248,4585,4161,5204,513]

theorem envBound25200 : H12AffineFastState.Bounded env25200 := by
  intro p hp
  have h : env25200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25199_25200 : H12AffineEnvironment.transform 15 37018 env25199 = env25200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 37018 env25199 == env25200) = true)

def env25201 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,232,8192,1297,32768,32882,232,43049,1025,32769,1212,113,16,139,8328,64,43169,277,276,2184,1273,248,257,169,1212,513]

theorem envBound25201 : H12AffineFastState.Bounded env25201 := by
  intro p hp
  have h : env25201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25200_25201 : H12AffineEnvironment.transform 11 232 env25200 = env25201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 232 env25200 == env25201) = true)

theorem identity25201 : scanCanonicalize (H12AffineFastState.compose env25201 (packedSelected [0,2,7] rootPS)) = affineNative (2^(9+1) ^^^ 880) := by decide +kernel

theorem selectedBound25201 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env25202 : List Nat := [2,4,8,16,32,64,128,256,512,880,2048,232,8192,609,32768,32882,232,43049,881,32769,972,113,16,139,8328,64,43169,277,276,2184,905,248,257,169,972,513]

theorem envBound25202 : H12AffineFastState.Bounded env25202 := by
  intro p hp
  have h : env25202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25201_25202 : H12AffineEnvironment.transform 9 880 env25201 = env25202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 880 env25201 == env25202) = true)

theorem identity25202 : scanCanonicalize (H12AffineFastState.compose env25202 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 356) := by decide +kernel

theorem selectedBound25202 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env25203 : List Nat := [2,4,8,16,32,64,128,256,356,20,2048,232,8192,261,32768,32882,232,43049,21,32769,168,113,16,139,8328,64,43169,277,276,2184,237,248,257,169,168,357]

theorem envBound25203 : H12AffineFastState.Bounded env25203 := by
  intro p hp
  have h : env25203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25202_25203 : H12AffineEnvironment.transform 8 356 env25202 = env25203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 356 env25202 == env25203) = true)

theorem identity25203 : scanCanonicalize (H12AffineFastState.compose env25203 (packedSelected [0,2,4,11] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound25203 : packedSelected [0,2,4,11] rootPS < 2^1333 := by decide +kernel

def env25204 : List Nat := [2,4,8,16,32,64,57,256,356,20,2048,81,8192,261,32768,32882,81,43049,21,32769,17,113,16,50,8241,64,43032,277,276,2097,84,65,257,16,17,357]

theorem envBound25204 : H12AffineFastState.Bounded env25204 := by
  intro p hp
  have h : env25204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25203_25204 : H12AffineEnvironment.transform 6 57 env25203 = env25204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env25203 == env25204) = true)

def env25205 : List Nat := [2,4,8,16,16,64,9,256,340,20,2048,81,8192,261,32768,32834,81,43033,21,32769,17,65,16,2,8193,64,43032,277,276,2049,84,65,257,16,17,341]

theorem envBound25205 : H12AffineFastState.Bounded env25205 := by
  intro p hp
  have h : env25205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25204_25205 : H12AffineEnvironment.transform 4 16 env25204 = env25205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env25204 == env25205) = true)

theorem identity25205 : scanCanonicalize (H12AffineFastState.compose env25205 (packedSelected [0] rootPS)) = affineNative (2^(14+1) ^^^ 8217) := by decide +kernel

theorem selectedBound25205 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25206 : List Nat := [2,4,8,16,16,64,9,256,340,20,2048,81,8192,261,8217,8283,81,2048,21,8216,17,65,16,2,8193,64,2049,277,276,2049,84,65,257,16,17,341]

theorem envBound25206 : H12AffineFastState.Bounded env25206 := by
  intro p hp
  have h : env25206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25205_25206 : H12AffineEnvironment.transform 14 8217 env25205 = env25206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8217 env25205 == env25206) = true)

theorem identity25206 : scanCanonicalize (H12AffineFastState.compose env25206 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 2333) := by decide +kernel

theorem selectedBound25206 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25207 : List Nat := [2,4,8,16,16,64,9,256,340,20,2048,81,2333,261,2308,2374,81,2048,21,2309,17,65,16,2,2332,64,2049,277,276,2049,84,65,257,16,17,341]

theorem envBound25207 : H12AffineFastState.Bounded env25207 := by
  intro p hp
  have h : env25207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25206_25207 : H12AffineEnvironment.transform 12 2333 env25206 = env25207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2333 env25206 == env25207) = true)

theorem identity25207 : scanCanonicalize (H12AffineFastState.compose env25207 (packedSelected [4] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound25207 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env25208 : List Nat := [2,4,8,16,16,1,9,256,277,20,2048,16,2333,261,2308,2311,16,2048,21,2309,17,0,16,2,2332,1,2049,277,276,2049,21,0,257,16,17,276]

theorem envBound25208 : H12AffineFastState.Bounded env25208 := by
  intro p hp
  have h : env25208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25207_25208 : H12AffineEnvironment.transform 5 1 env25207 = env25208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env25207 == env25208) = true)

def env25209 : List Nat := [2,4,8,0,0,1,9,256,261,4,2048,0,2317,261,2308,2311,0,2048,5,2309,1,0,0,2,2316,1,2049,261,260,2049,5,0,257,0,1,260]

theorem envBound25209 : H12AffineFastState.Bounded env25209 := by
  intro p hp
  have h : env25209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25208_25209 : H12AffineEnvironment.transform 3 0 env25208 = env25209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env25208 == env25209) = true)

theorem identity25209 : scanCanonicalize (H12AffineFastState.compose env25209 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound25209 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25210 : List Nat := [2,0,8,0,0,1,9,256,257,0,2048,0,2313,257,2304,2307,0,2048,1,2305,1,0,0,2,2312,1,2049,257,256,2049,1,0,257,0,1,256]

theorem envBound25210 : H12AffineFastState.Bounded env25210 := by
  intro p hp
  have h : env25210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25209_25210 : H12AffineEnvironment.transform 1 0 env25209 = env25210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env25209 == env25210) = true)

def leafEnv25210 : List Nat := [2,0,8,0,0,1,9,256,257,0,2048,0,2313,257,2304,2307,0,2048,1,2305,1,0,0,2,1,2312,1,1,2049,257,256,2049,1,0,257,0,0,2307,1,256,0,256,1]

def active25210 : List Nat := [0,2,7,10]

def tree25210 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25210 : H12WitnessSearch.Good tree25210 := H12GlobalWitnessIndex.good

theorem leafIdentity25210 : H12AffineFastState.composeSystem env25210 rootObs = leafEnv25210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25210 rootObs == leafEnv25210) = true)

theorem terminalChecked25210 : H12PackedTerminal.terminalCheckFast leafEnv25210 active25210 tree25210 = true := by decide +kernel

def env25211 : List Nat := [2,4,8,1,1,1,9,256,260,5,2048,1,2316,261,2308,2311,1,2048,4,2309,0,0,1,2,2317,1,2049,260,261,2049,4,0,257,1,0,261]

theorem envBound25211 : H12AffineFastState.Bounded env25211 := by
  intro p hp
  have h : env25211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25208_25211 : H12AffineEnvironment.transform 3 1 env25208 = env25211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env25208 == env25211) = true)

theorem identity25211 : scanCanonicalize (H12AffineFastState.compose env25211 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 256) := by decide +kernel

theorem selectedBound25211 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25212 : List Nat := [2,4,8,1,1,1,9,256,260,5,256,1,12,261,4,7,1,256,4,5,0,0,1,2,13,1,257,260,261,257,4,0,257,1,0,261]

theorem envBound25212 : H12AffineFastState.Bounded env25212 := by
  intro p hp
  have h : env25212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25211_25212 : H12AffineEnvironment.transform 10 256 env25211 = env25212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 256 env25211 == env25212) = true)

def leafEnv25212 : List Nat := [2,4,8,1,1,1,9,256,260,5,256,1,12,261,4,7,1,256,4,5,0,0,1,2,4,13,1,1,257,260,261,257,4,0,257,1,4,7,0,261,0,260,1]

def active25212 : List Nat := [0,1,2,7]

def tree25212 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25212 : H12WitnessSearch.Good tree25212 := H12GlobalWitnessIndex.good

theorem leafIdentity25212 : H12AffineFastState.composeSystem env25212 rootObs = leafEnv25212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25212 rootObs == leafEnv25212) = true)

theorem terminalChecked25212 : H12PackedTerminal.terminalCheckFast leafEnv25212 active25212 tree25212 = true := by decide +kernel

def env25213 : List Nat := [2,4,8,16,17,64,8,256,341,20,2048,81,8192,261,32768,32835,81,43032,21,32769,17,64,16,3,8192,64,43032,277,276,2048,84,65,257,16,17,340]

theorem envBound25213 : H12AffineFastState.Bounded env25213 := by
  intro p hp
  have h : env25213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25204_25213 : H12AffineEnvironment.transform 4 17 env25204 = env25213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env25204 == env25213) = true)

theorem identity25213 : scanCanonicalize (H12AffineFastState.compose env25213 (packedSelected [0] rootPS)) = affineNative (2^(14+1) ^^^ 2129) := by decide +kernel

theorem selectedBound25213 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25214 : List Nat := [2,4,8,16,17,64,8,256,341,20,2048,81,8192,261,2129,2066,81,8265,21,2128,17,64,16,3,8192,64,8265,277,276,2048,84,65,257,16,17,340]

theorem envBound25214 : H12AffineFastState.Bounded env25214 := by
  intro p hp
  have h : env25214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25213_25214 : H12AffineEnvironment.transform 14 2129 env25213 = env25214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2129 env25213 == env25214) = true)

def env25215 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,233,8192,1297,32768,32883,232,43049,1024,32769,1213,112,17,139,8328,65,43169,277,277,2184,1272,248,256,168,1213,513]

theorem envBound25215 : H12AffineFastState.Bounded env25215 := by
  intro p hp
  have h : env25215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25200_25215 : H12AffineEnvironment.transform 11 233 env25200 = env25215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 233 env25200 == env25215) = true)

theorem identity25215 : scanCanonicalize (H12AffineFastState.compose env25215 (packedSelected [0,2,7] rootPS)) = affineNative (2^(9+1) ^^^ 653) := by decide +kernel

theorem selectedBound25215 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env25216 : List Nat := [2,4,8,16,32,64,128,256,512,653,2048,233,8192,924,32768,32883,232,43049,653,32769,560,112,17,139,8328,65,43169,277,277,2184,629,248,256,168,560,513]

theorem envBound25216 : H12AffineFastState.Bounded env25216 := by
  intro p hp
  have h : env25216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25215_25216 : H12AffineEnvironment.transform 9 653 env25215 = env25216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 653 env25215 == env25216) = true)

theorem identity25216 : scanCanonicalize (H12AffineFastState.compose env25216 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 8809) := by decide +kernel

theorem selectedBound25216 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env25217 : List Nat := [2,4,8,16,32,64,128,256,512,653,2048,233,8192,924,8809,8730,232,2624,653,8808,560,112,17,139,8328,65,2760,277,277,2184,629,248,256,168,560,513]

theorem envBound25217 : H12AffineFastState.Bounded env25217 := by
  intro p hp
  have h : env25217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25216_25217 : H12AffineEnvironment.transform 14 8809 env25216 = env25217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8809 env25216 == env25217) = true)

theorem identity25217 : scanCanonicalize (H12AffineFastState.compose env25217 (packedSelected [0,2,4,11] rootPS)) = affineNative (2^(8+1) ^^^ 396) := by decide +kernel

theorem selectedBound25217 : packedSelected [0,2,4,11] rootPS < 2^1333 := by decide +kernel

def env25218 : List Nat := [2,4,8,16,32,64,128,256,396,257,2048,233,8192,16,8677,8598,232,2508,257,8676,444,112,17,139,8328,65,2372,277,277,2184,505,248,256,168,444,397]

theorem envBound25218 : H12AffineFastState.Bounded env25218 := by
  intro p hp
  have h : env25218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25217_25218 : H12AffineEnvironment.transform 8 396 env25217 = env25218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 396 env25217 == env25218) = true)

def env25219 : List Nat := [2,4,8,16,32,64,8,256,260,257,2048,97,8192,16,8557,8478,96,2372,257,8556,308,112,17,3,8192,65,2372,277,277,2048,369,112,256,32,308,261]

theorem envBound25219 : H12AffineFastState.Bounded env25219 := by
  intro p hp
  have h : env25219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25218_25219 : H12AffineEnvironment.transform 6 8 env25218 = env25219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env25218 == env25219) = true)

def env25220 : List Nat := [2,4,8,16,32,64,9,256,261,257,2048,96,8192,16,8556,8479,97,2373,257,8557,309,112,17,2,8193,65,2372,277,277,2049,368,113,256,33,309,260]

theorem envBound25220 : H12AffineFastState.Bounded env25220 := by
  intro p hp
  have h : env25220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25218_25220 : H12AffineEnvironment.transform 6 9 env25218 = env25220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env25218 == env25220) = true)

theorem identity25220 : scanCanonicalize (H12AffineFastState.compose env25220 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound25220 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25221 : List Nat := [2,4,8,16,32,64,9,69,64,68,2048,96,8192,16,8233,8282,97,2048,68,8232,112,112,17,2,8193,65,2049,80,80,2049,53,113,69,33,112,65]

theorem envBound25221 : H12AffineFastState.Bounded env25221 := by
  intro p hp
  have h : env25221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25220_25221 : H12AffineEnvironment.transform 7 69 env25220 = env25221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env25220 == env25221) = true)

theorem identity25221 : scanCanonicalize (H12AffineFastState.compose env25221 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound25221 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25222 : List Nat := [2,4,8,16,1,64,9,69,64,68,2048,65,8192,16,8200,8282,64,2048,68,8201,81,81,17,2,8193,65,2049,80,80,2049,20,80,69,0,81,65]

theorem envBound25222 : H12AffineFastState.Bounded env25222 := by
  intro p hp
  have h : env25222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25221_25222 : H12AffineEnvironment.transform 4 1 env25221 = env25222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env25221 == env25222) = true)

theorem identity25222 : scanCanonicalize (H12AffineFastState.compose env25222 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 2073) := by decide +kernel

theorem selectedBound25222 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25223 : List Nat := [2,4,8,16,1,64,9,69,64,68,2048,65,2073,16,2065,2115,64,2048,68,2064,81,81,17,2,2072,65,2049,80,80,2049,20,80,69,0,81,65]

theorem envBound25223 : H12AffineFastState.Bounded env25223 := by
  intro p hp
  have h : env25223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25222_25223 : H12AffineEnvironment.transform 12 2073 env25222 = env25223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2073 env25222 == env25223) = true)

def env25224 : List Nat := [2,4,8,16,1,64,9,69,64,68,0,65,25,16,17,67,64,0,68,16,81,81,17,2,24,65,1,80,80,1,20,80,69,0,81,65]

theorem envBound25224 : H12AffineFastState.Bounded env25224 := by
  intro p hp
  have h : env25224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25223_25224 : H12AffineEnvironment.transform 10 0 env25223 = env25224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env25223 == env25224) = true)

theorem identity25224 : scanCanonicalize (H12AffineFastState.compose env25224 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound25224 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25225 : List Nat := [2,4,7,16,1,64,6,69,64,68,0,65,22,16,17,67,64,0,68,16,81,81,17,2,23,65,1,80,80,1,20,80,69,0,81,65]

theorem envBound25225 : H12AffineFastState.Bounded env25225 := by
  intro p hp
  have h : env25225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25224_25225 : H12AffineEnvironment.transform 2 7 env25224 = env25225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env25224 == env25225) = true)

def leafEnv25225 : List Nat := [2,4,7,16,1,64,6,69,64,68,0,65,22,16,17,67,64,0,68,16,81,81,17,2,21,23,1,65,1,80,80,1,20,80,69,0,5,67,81,65,0,17,1]

def active25225 : List Nat := [0,1,3,5]

def tree25225 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25225 : H12WitnessSearch.Good tree25225 := H12GlobalWitnessIndex.good

theorem leafIdentity25225 : H12AffineFastState.composeSystem env25225 rootObs = leafEnv25225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25225 rootObs == leafEnv25225) = true)

theorem terminalChecked25225 : H12PackedTerminal.terminalCheckFast leafEnv25225 active25225 tree25225 = true := by decide +kernel

def env25226 : List Nat := [2,4,8,16,1,64,9,69,64,68,1,65,24,16,16,66,64,1,68,17,81,81,17,2,25,65,0,80,80,0,20,80,69,0,81,65]

theorem envBound25226 : H12AffineFastState.Bounded env25226 := by
  intro p hp
  have h : env25226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25223_25226 : H12AffineEnvironment.transform 10 1 env25223 = env25226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env25223 == env25226) = true)

theorem identity25226 : scanCanonicalize (H12AffineFastState.compose env25226 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 31) := by decide +kernel

theorem selectedBound25226 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25227 : List Nat := [2,4,8,16,1,31,9,26,31,27,1,30,24,16,16,29,31,1,27,17,14,14,17,2,25,30,0,15,15,0,20,15,26,0,14,30]

theorem envBound25227 : H12AffineFastState.Bounded env25227 := by
  intro p hp
  have h : env25227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25226_25227 : H12AffineEnvironment.transform 5 31 env25226 = env25227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 31 env25226 == env25227) = true)

def leafEnv25227 : List Nat := [2,4,8,16,1,31,9,26,31,27,1,30,24,16,16,29,31,1,27,17,14,14,17,2,21,25,1,30,0,15,15,0,20,15,26,0,5,29,14,30,0,17,1]

def active25227 : List Nat := [0,1,2,3]

def tree25227 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25227 : H12WitnessSearch.Good tree25227 := H12GlobalWitnessIndex.good

theorem leafIdentity25227 : H12AffineFastState.composeSystem env25227 rootObs = leafEnv25227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25227 rootObs == leafEnv25227) = true)

theorem terminalChecked25227 : H12PackedTerminal.terminalCheckFast leafEnv25227 active25227 tree25227 = true := by decide +kernel

def env25228 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,540929,4292744,8328,7067119,262280,4441326,4314351,4294795,2330678,4347289,525568,4445626,4834735,513]

theorem envBound25228 : H12AffineFastState.Bounded env25228 := by
  intro p hp
  have h : env25228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25028_25228 : H12AffineEnvironment.transform 22 540929 env25028 = env25228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 540929 env25028 == env25228) = true)

def env25229 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,131072,262144,524288,32769,2097152,4194304,525329,4292744,8328,7049471,262280,4424190,4297215,4294795,2330678,4329609,525568,4427946,4817087,513]

theorem envBound25229 : H12AffineFastState.Bounded env25229 := by
  intro p hp
  have h : env25229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25228_25229 : H12AffineEnvironment.transform 13 1296 env25228 = env25229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env25228 == env25229) = true)

theorem identity25229 : scanCanonicalize (H12AffineFastState.compose env25229 (packedSelected [0,6,27] rootPS)) = affineNative (2^(20+1) ^^^ 626727) := by decide +kernel

theorem selectedBound25229 : packedSelected [0,6,27] rootPS < 2^1333 := by decide +kernel

def env25230 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,131072,262144,524288,32769,626727,4194304,525329,4292744,8328,4325592,262280,4424190,4297215,4294795,655377,4329609,525568,4427946,4817087,513]

theorem envBound25230 : H12AffineFastState.Bounded env25230 := by
  intro p hp
  have h : env25230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25229_25230 : H12AffineEnvironment.transform 20 626727 env25229 = env25230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 626727 env25229 == env25230) = true)

def env25231 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,131072,262144,136192,32769,230439,4194304,135185,4292744,8328,4325592,262280,4424190,4297215,4294795,5137,4329609,135424,4427946,4428991,513]

theorem envBound25231 : H12AffineFastState.Bounded env25231 := by
  intro p hp
  have h : env25231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25230_25231 : H12AffineEnvironment.transform 18 136192 env25230 = env25231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env25230 == env25231) = true)

theorem identity25231 : scanCanonicalize (H12AffineFastState.compose env25231 (packedSelected [6] rootPS)) = affineNative (2^(21+1) ^^^ 229610) := by decide +kernel

theorem selectedBound25231 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env25232 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,131072,262144,136192,32769,230439,229610,135185,131170,8328,98354,262280,276,135445,133217,5137,102499,135424,4160,5205,513]

theorem envBound25232 : H12AffineFastState.Bounded env25232 := by
  intro p hp
  have h : env25232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25231_25232 : H12AffineEnvironment.transform 21 229610 env25231 = env25232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 229610 env25231 == env25232) = true)

theorem identity25232 : scanCanonicalize (H12AffineFastState.compose env25232 (packedSelected [0,7,14,20] rootPS)) = affineNative (2^(16+1) ^^^ 102515) := by decide +kernel

theorem selectedBound25232 : packedSelected [0,7,14,20] rootPS < 2^1333 := by decide +kernel

def env25233 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,102515,262144,99443,32769,5204,4249,98402,102417,8328,98354,262280,276,98662,104466,5137,102499,98675,4160,5205,513]

theorem envBound25233 : H12AffineFastState.Bounded env25233 := by
  intro p hp
  have h : env25233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25232_25233 : H12AffineEnvironment.transform 16 102515 env25232 = env25233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 102515 env25232 == env25233) = true)

theorem identity25233 : scanCanonicalize (H12AffineFastState.compose env25233 (packedSelected [1,3,5,8,10,12,14] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound25233 : packedSelected [1,3,5,8,10,12,14] rootPS < 2^1333 := by decide +kernel

def env25234 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,102515,43049,99443,32769,5204,4249,98402,102417,8328,98354,43169,276,98662,104466,5137,102499,98675,4160,5205,513]

theorem envBound25234 : H12AffineFastState.Bounded env25234 := by
  intro p hp
  have h : env25234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25233_25234 : H12AffineEnvironment.transform 17 43049 env25233 = env25234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env25233 == env25234) = true)

theorem identity25234 : scanCanonicalize (H12AffineFastState.compose env25234 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 37018) := by decide +kernel

theorem selectedBound25234 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env25235 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,37018,233,43049,5353,32769,5204,4249,4344,139,8328,4264,43169,276,4604,2184,5137,249,4585,4160,5205,513]

theorem envBound25235 : H12AffineFastState.Bounded env25235 := by
  intro p hp
  have h : env25235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25234_25235 : H12AffineEnvironment.transform 15 37018 env25234 = env25235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 37018 env25234 == env25235) = true)

def env25236 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,232,8192,1296,32768,32882,233,43049,1025,32769,1212,113,16,139,8328,64,43169,276,276,2184,1273,249,257,168,1213,513]

theorem envBound25236 : H12AffineFastState.Bounded env25236 := by
  intro p hp
  have h : env25236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25235_25236 : H12AffineEnvironment.transform 11 232 env25235 = env25236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 232 env25235 == env25236) = true)

theorem identity25236 : scanCanonicalize (H12AffineFastState.compose env25236 (packedSelected [0,2,7] rootPS)) = affineNative (2^(9+1) ^^^ 653) := by decide +kernel

theorem selectedBound25236 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env25237 : List Nat := [2,4,8,16,32,64,128,256,512,653,2048,232,8192,925,32768,32882,233,43049,652,32769,561,113,16,139,8328,64,43169,276,276,2184,628,249,257,168,560,513]

theorem envBound25237 : H12AffineFastState.Bounded env25237 := by
  intro p hp
  have h : env25237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25236_25237 : H12AffineEnvironment.transform 9 653 env25236 = env25237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 653 env25236 == env25237) = true)

theorem identity25237 : scanCanonicalize (H12AffineFastState.compose env25237 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 8809) := by decide +kernel

theorem selectedBound25237 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env25238 : List Nat := [2,4,8,16,32,64,128,256,512,653,2048,232,8192,925,8809,8731,233,2624,652,8808,561,113,16,139,8328,64,2760,276,276,2184,628,249,257,168,560,513]

theorem envBound25238 : H12AffineFastState.Bounded env25238 := by
  intro p hp
  have h : env25238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25237_25238 : H12AffineEnvironment.transform 14 8809 env25237 = env25238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8809 env25237 == env25238) = true)

theorem identity25238 : scanCanonicalize (H12AffineFastState.compose env25238 (packedSelected [0,2,4,11] rootPS)) = affineNative (2^(8+1) ^^^ 397) := by decide +kernel

theorem selectedBound25238 : packedSelected [0,2,4,11] rootPS < 2^1333 := by decide +kernel

def env25239 : List Nat := [2,4,8,16,32,64,128,256,397,256,2048,232,8192,16,8676,8598,233,2509,257,8677,444,113,16,139,8328,64,2373,276,276,2184,505,249,257,168,445,396]

theorem envBound25239 : H12AffineFastState.Bounded env25239 := by
  intro p hp
  have h : env25239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25238_25239 : H12AffineEnvironment.transform 8 397 env25238 = env25239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 397 env25238 == env25239) = true)

def env25240 : List Nat := [2,4,8,16,32,64,8,256,261,256,2048,96,8192,16,8556,8478,97,2373,257,8557,308,113,16,3,8192,64,2373,276,276,2048,369,113,257,32,309,260]

theorem envBound25240 : H12AffineFastState.Bounded env25240 := by
  intro p hp
  have h : env25240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25239_25240 : H12AffineEnvironment.transform 6 8 env25239 = env25240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env25239 == env25240) = true)

theorem identity25240 : scanCanonicalize (H12AffineFastState.compose env25240 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound25240 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25241 : List Nat := [2,4,8,16,32,64,8,36,33,36,2048,96,8192,16,8264,8250,97,2145,37,8265,16,113,16,3,8192,64,2145,48,48,2048,85,113,37,32,17,32]

theorem envBound25241 : H12AffineFastState.Bounded env25241 := by
  intro p hp
  have h : env25241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25240_25241 : H12AffineEnvironment.transform 7 36 env25240 = env25241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env25240 == env25241) = true)

theorem identity25241 : scanCanonicalize (H12AffineFastState.compose env25241 (packedSelected [0,1,3] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound25241 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env25242 : List Nat := [2,4,8,16,32,32,8,36,33,36,2048,0,8192,16,8232,8250,1,2049,37,8233,16,17,16,3,8192,32,2049,48,48,2048,53,17,37,32,17,32]

theorem envBound25242 : H12AffineFastState.Bounded env25242 := by
  intro p hp
  have h : env25242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25241_25242 : H12AffineEnvironment.transform 5 32 env25241 = env25242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env25241 == env25242) = true)

theorem identity25242 : scanCanonicalize (H12AffineFastState.compose env25242 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 2104) := by decide +kernel

theorem selectedBound25242 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25243 : List Nat := [2,4,8,16,32,32,8,36,33,36,2048,0,2104,16,2064,2050,1,2049,37,2065,16,17,16,3,2104,32,2049,48,48,2048,53,17,37,32,17,32]

theorem envBound25243 : H12AffineFastState.Bounded env25243 := by
  intro p hp
  have h : env25243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25242_25243 : H12AffineEnvironment.transform 12 2104 env25242 = env25243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2104 env25242 == env25243) = true)

theorem identity25243 : scanCanonicalize (H12AffineFastState.compose env25243 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound25243 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env25244 : List Nat := [2,4,8,16,0,0,8,4,1,4,2048,0,2072,16,2064,2050,1,2049,5,2065,16,17,16,3,2072,0,2049,16,16,2048,21,17,5,0,17,0]

theorem envBound25244 : H12AffineFastState.Bounded env25244 := by
  intro p hp
  have h : env25244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25243_25244 : H12AffineEnvironment.transform 4 0 env25243 = env25244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env25243 == env25244) = true)

def env25245 : List Nat := [2,4,8,16,0,0,8,4,1,4,0,0,24,16,16,2,1,1,5,17,16,17,16,3,24,0,1,16,16,0,21,17,5,0,17,0]

theorem envBound25245 : H12AffineFastState.Bounded env25245 := by
  intro p hp
  have h : env25245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25244_25245 : H12AffineEnvironment.transform 10 0 env25244 = env25245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env25244 == env25245) = true)

theorem identity25245 : scanCanonicalize (H12AffineFastState.compose env25245 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound25245 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25246 : List Nat := [2,4,7,16,0,0,7,4,1,4,0,0,23,16,16,2,1,1,5,17,16,17,16,3,23,0,1,16,16,0,21,17,5,0,17,0]

theorem envBound25246 : H12AffineFastState.Bounded env25246 := by
  intro p hp
  have h : env25246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25245_25246 : H12AffineEnvironment.transform 2 7 env25245 = env25246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env25245 == env25246) = true)

def leafEnv25246 : List Nat := [2,4,7,16,0,0,7,4,1,4,0,0,23,16,16,2,1,1,5,17,16,17,16,3,21,23,1,0,1,16,16,0,21,17,5,0,4,3,17,0,0,16,1]

def active25246 : List Nat := [0,1,3]

def tree25246 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25246 : H12WitnessSearch.Good tree25246 := H12GlobalWitnessIndex.good

theorem leafIdentity25246 : H12AffineFastState.composeSystem env25246 rootObs = leafEnv25246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25246 rootObs == leafEnv25246) = true)

theorem terminalChecked25246 : H12PackedTerminal.terminalCheckFast leafEnv25246 active25246 tree25246 = true := by decide +kernel

def env25247 : List Nat := [2,4,8,16,0,0,8,4,1,4,1,0,25,16,17,3,1,0,5,16,16,17,16,3,25,0,0,16,16,1,21,17,5,0,17,0]

theorem envBound25247 : H12AffineFastState.Bounded env25247 := by
  intro p hp
  have h : env25247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25244_25247 : H12AffineEnvironment.transform 10 1 env25244 = env25247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env25244 == env25247) = true)

theorem identity25247 : scanCanonicalize (H12AffineFastState.compose env25247 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 14) := by decide +kernel

theorem selectedBound25247 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env25248 : List Nat := [2,4,8,14,0,0,8,4,1,4,1,0,7,14,15,3,1,0,5,14,14,15,14,3,7,0,0,14,14,1,11,15,5,0,15,0]

theorem envBound25248 : H12AffineFastState.Bounded env25248 := by
  intro p hp
  have h : env25248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25247_25248 : H12AffineEnvironment.transform 3 14 env25247 = env25248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 14 env25247 == env25248) = true)

def leafEnv25248 : List Nat := [2,4,8,14,0,0,8,4,1,4,1,0,7,14,15,3,1,0,5,14,14,15,14,3,11,7,1,0,0,14,14,1,11,15,5,0,4,2,15,0,0,14,1]

def active25248 : List Nat := [0,1,2]

def tree25248 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25248 : H12WitnessSearch.Good tree25248 := H12GlobalWitnessIndex.good

theorem leafIdentity25248 : H12AffineFastState.composeSystem env25248 rootObs = leafEnv25248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25248 rootObs == leafEnv25248) = true)

theorem terminalChecked25248 : H12PackedTerminal.terminalCheckFast leafEnv25248 active25248 tree25248 = true := by decide +kernel

def env25249 : List Nat := [2,4,8,16,32,64,9,256,260,256,2048,97,8192,16,8557,8479,96,2372,257,8556,309,113,16,2,8193,64,2373,276,276,2049,368,112,257,33,308,261]

theorem envBound25249 : H12AffineFastState.Bounded env25249 := by
  intro p hp
  have h : env25249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25239_25249 : H12AffineEnvironment.transform 6 9 env25239 = env25249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env25239 == env25249) = true)

theorem identity25249 : scanCanonicalize (H12AffineFastState.compose env25249 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound25249 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25250 : List Nat := [2,4,8,16,32,32,9,256,260,256,2048,1,8192,16,8461,8479,0,2340,257,8460,309,17,16,2,8193,32,2341,276,276,2049,272,16,257,33,308,261]

theorem envBound25250 : H12AffineFastState.Bounded env25250 := by
  intro p hp
  have h : env25250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart2