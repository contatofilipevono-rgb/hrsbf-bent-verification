import H12CloudChart2Data213

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity53917 : scanCanonicalize (H12AffineFastState.compose env53917 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound53917 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env53918 : List Nat := [2,4,8,16,32,17,128,21,512,1024,2048,1029,1685,1028,1677,1711,1029,163,1025,1676,1028,152,17,1078,1564,16,1070,1028,1029,2096,21,1045,21,17,1029,512]

theorem envBound53918 : H12AffineFastState.Bounded env53918 := by
  intro p hp
  have h : env53918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53917_53918 : H12AffineEnvironment.transform 5 17 env53917 = env53918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53917 == env53918) = true)

theorem identity53918 : scanCanonicalize (H12AffineFastState.compose env53918 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 163) := by decide +kernel

theorem selectedBound53918 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env53919 : List Nat := [2,4,8,16,32,17,128,21,512,1024,163,1029,1685,1028,1677,1711,1029,163,1025,1676,1028,152,17,1078,1564,16,1070,1028,1029,147,21,1045,21,17,1029,512]

theorem envBound53919 : H12AffineFastState.Bounded env53919 := by
  intro p hp
  have h : env53919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53918_53919 : H12AffineEnvironment.transform 10 163 env53918 = env53919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 163 env53918 == env53919) = true)

def env53920 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16465,262144,95614,32769,4097,61648,16,284033,86518,94527,77840,1296,74815,96346,381312,74799,256,323755,1345,95103]

theorem envBound53920 : H12AffineFastState.Bounded env53920 := by
  intro p hp
  have h : env53920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53867_53920 : H12AffineEnvironment.transform 16 16465 env53867 = env53920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16465 env53867 == env53920) = true)

def env53921 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1345,262144,77934,32769,4097,46528,16,266385,70886,78895,77840,1296,74815,81226,365712,74799,256,308667,1345,79471]

theorem envBound53921 : H12AffineFastState.Bounded env53921 := by
  intro p hp
  have h : env53921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53920_53921 : H12AffineEnvironment.transform 13 1296 env53920 = env53921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env53920 == env53921) = true)

theorem identity53921 : scanCanonicalize (H12AffineFastState.compose env53921 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32882) := by decide +kernel

theorem selectedBound53921 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env53922 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,32882,1345,262144,45084,32769,4097,46528,16,266385,38036,46173,45154,1296,42061,48440,267490,42077,256,308667,1345,46621]

theorem envBound53922 : H12AffineFastState.Bounded env53922 := by
  intro p hp
  have h : env53922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53921_53922 : H12AffineEnvironment.transform 15 32882 env53921 = env53922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32882 env53921 == env53922) = true)

def env53923 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32882,1345,262144,42332,32769,1345,41088,16,263633,33236,41245,42274,1296,42061,43128,262562,42077,256,303355,1345,41821]

theorem envBound53923 : H12AffineFastState.Bounded env53923 := by
  intro p hp
  have h : env53923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53922_53923 : H12AffineEnvironment.transform 11 1344 env53922 = env53923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env53922 == env53923) = true)

theorem identity53923 : scanCanonicalize (H12AffineFastState.compose env53923 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound53923 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env53924 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,81,8192,1,32768,32882,80,262144,41037,32769,80,41088,16,262336,33236,41245,41011,1,41308,43128,262562,41292,256,303355,80,41821]

theorem envBound53924 : H12AffineFastState.Bounded env53924 := by
  intro p hp
  have h : env53924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53923_53924 : H12AffineEnvironment.transform 9 273 env53923 = env53924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env53923 == env53924) = true)

theorem identity53924 : scanCanonicalize (H12AffineFastState.compose env53924 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound53924 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env53925 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,81,8192,1,8541,8495,80,262144,272,8540,80,477,16,262336,8329,64,366,1,1,2341,262562,17,256,262566,80,512]

theorem envBound53925 : H12AffineFastState.Bounded env53925 := by
  intro p hp
  have h : env53925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53924_53925 : H12AffineEnvironment.transform 14 8541 env53924 = env53925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env53924 == env53925) = true)

theorem identity53925 : scanCanonicalize (H12AffineFastState.compose env53925 (packedSelected [4,9,16] rootPS)) = affineNative (2^(17+1) ^^^ 243) := by decide +kernel

theorem selectedBound53925 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env53926 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,81,8192,1,8541,8495,80,243,272,8540,80,477,16,51,8329,64,366,1,1,2341,337,17,256,341,80,512]

theorem envBound53926 : H12AffineFastState.Bounded env53926 := by
  intro p hp
  have h : env53926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53925_53926 : H12AffineEnvironment.transform 17 243 env53925 = env53926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 243 env53925 == env53926) = true)

theorem identity53926 : scanCanonicalize (H12AffineFastState.compose env53926 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 705) := by decide +kernel

theorem selectedBound53926 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env53927 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,81,705,1,924,1006,80,243,272,925,80,477,16,51,584,64,366,1,1,2341,337,17,256,341,80,512]

theorem envBound53927 : H12AffineFastState.Bounded env53927 := by
  intro p hp
  have h : env53927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53926_53927 : H12AffineEnvironment.transform 12 705 env53926 = env53927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 705 env53926 == env53927) = true)

theorem identity53927 : scanCanonicalize (H12AffineFastState.compose env53927 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound53927 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env53928 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,0,656,1,924,959,1,162,272,925,1,396,16,51,537,17,319,1,1,2341,256,17,256,260,1,512]

theorem envBound53928 : H12AffineFastState.Bounded env53928 := by
  intro p hp
  have h : env53928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53927_53928 : H12AffineEnvironment.transform 5 17 env53927 = env53928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53927 == env53928) = true)

theorem identity53928 : scanCanonicalize (H12AffineFastState.compose env53928 (packedSelected [1,3,13] rootPS)) = affineNative (2^(10+1) ^^^ 319) := by decide +kernel

theorem selectedBound53928 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env53929 : List Nat := [2,4,8,16,32,17,128,256,512,273,319,0,656,1,924,959,1,162,272,925,1,396,16,51,537,17,319,1,1,26,256,17,256,260,1,512]

theorem envBound53929 : H12AffineFastState.Bounded env53929 := by
  intro p hp
  have h : env53929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53928_53929 : H12AffineEnvironment.transform 10 319 env53928 = env53929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 319 env53928 == env53929) = true)

theorem identity53929 : scanCanonicalize (H12AffineFastState.compose env53929 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound53929 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env53930 : List Nat := [2,4,8,16,32,17,128,172,512,189,147,0,656,1,560,531,1,162,188,561,1,32,16,51,537,17,147,1,1,26,172,17,172,168,1,512]

theorem envBound53930 : H12AffineFastState.Bounded env53930 := by
  intro p hp
  have h : env53930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53929_53930 : H12AffineEnvironment.transform 7 172 env53929 = env53930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env53929 == env53930) = true)

theorem identity53930 : scanCanonicalize (H12AffineFastState.compose env53930 (packedSelected [1,2,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound53930 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env53931 : List Nat := [2,4,8,11,32,10,128,172,512,166,136,0,651,1,555,520,1,162,167,554,1,32,11,40,514,10,136,1,1,1,172,10,172,168,1,512]

theorem envBound53931 : H12AffineFastState.Bounded env53931 := by
  intro p hp
  have h : env53931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53930_53931 : H12AffineEnvironment.transform 3 11 env53930 = env53931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env53930 == env53931) = true)

theorem identity53931 : scanCanonicalize (H12AffineFastState.compose env53931 (packedSelected [0,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 162) := by decide +kernel

theorem selectedBound53931 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env53932 : List Nat := [2,4,8,11,32,10,128,172,162,166,136,0,41,1,137,170,1,162,167,136,1,32,11,40,160,10,136,1,1,1,172,10,172,168,1,162]

theorem envBound53932 : H12AffineFastState.Bounded env53932 := by
  intro p hp
  have h : env53932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53931_53932 : H12AffineEnvironment.transform 8 162 env53931 = env53932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 162 env53931 == env53932) = true)

theorem identity53932 : scanCanonicalize (H12AffineFastState.compose env53932 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound53932 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env53933 : List Nat := [2,4,8,11,10,10,128,134,136,140,136,0,3,1,137,128,1,136,141,136,1,10,11,2,138,10,136,1,1,1,134,10,134,130,1,136]

theorem envBound53933 : H12AffineFastState.Bounded env53933 := by
  intro p hp
  have h : env53933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53932_53933 : H12AffineEnvironment.transform 4 10 env53932 = env53933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env53932 == env53933) = true)

def env53934 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32882,1345,262144,42333,32769,1344,41089,16,263632,33237,41244,42275,1296,42061,43129,262563,42077,256,303354,1345,41820]

theorem envBound53934 : H12AffineFastState.Bounded env53934 := by
  intro p hp
  have h : env53934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53922_53934 : H12AffineEnvironment.transform 11 1345 env53922 = env53934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env53922 == env53934) = true)

theorem identity53934 : scanCanonicalize (H12AffineFastState.compose env53934 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 34275) := by decide +kernel

theorem selectedBound53934 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env53935 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32882,1345,34275,42333,32769,1344,41089,16,32819,33237,41244,42275,1296,42061,43129,33856,42077,256,9497,1345,41820]

theorem envBound53935 : H12AffineFastState.Bounded env53935 := by
  intro p hp
  have h : env53935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53934_53935 : H12AffineEnvironment.transform 17 34275 env53934 = env53935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 34275 env53934 == env53935) = true)

theorem identity53935 : scanCanonicalize (H12AffineFastState.compose env53935 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(12+1) ^^^ 3859) := by decide +kernel

theorem selectedBound53935 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env53936 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,3859,1296,32768,32882,1345,34275,35406,32769,1344,36754,16,32819,33237,36367,35376,1296,35678,34666,33856,35662,256,2570,1345,35919]

theorem envBound53936 : H12AffineFastState.Bounded env53936 := by
  intro p hp
  have h : env53936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53935_53936 : H12AffineEnvironment.transform 12 3859 env53935 = env53936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3859 env53935 == env53936) = true)

def env53937 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1344,262144,77935,32769,4097,46529,16,266384,70887,78894,77840,1296,74815,81227,365713,74799,256,308666,1345,79470]

theorem envBound53937 : H12AffineFastState.Bounded env53937 := by
  intro p hp
  have h : env53937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53920_53937 : H12AffineEnvironment.transform 13 1297 env53920 = env53937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env53920 == env53937) = true)

theorem identity53937 : scanCanonicalize (H12AffineFastState.compose env53937 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound53937 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env53938 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1344,262144,77935,13341,4097,477,16,266384,70887,78894,77840,1296,74815,81227,336013,74799,256,262566,1345,79470]

theorem envBound53938 : H12AffineFastState.Bounded env53938 := by
  intro p hp
  have h : env53938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53937_53938 : H12AffineEnvironment.transform 14 13340 env53937 = env53938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env53937 == env53938) = true)

def env53939 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1344,65664,77935,13341,4097,477,16,69648,70887,78894,77840,1296,74815,81227,8205,74799,256,65830,1345,79470]

theorem envBound53939 : H12AffineFastState.Bounded env53939 := by
  intro p hp
  have h : env53939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53938_53939 : H12AffineEnvironment.transform 17 65664 env53938 = env53939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env53938 == env53939) = true)

theorem identity53939 : scanCanonicalize (H12AffineFastState.compose env53939 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 311) := by decide +kernel

theorem selectedBound53939 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env53940 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,311,1344,439,12632,13341,4097,477,16,4391,5584,13593,12583,1296,9480,15484,8205,9496,256,17,1345,14169]

theorem envBound53940 : H12AffineFastState.Bounded env53940 := by
  intro p hp
  have h : env53940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53939_53940 : H12AffineEnvironment.transform 15 311 env53939 = env53940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 311 env53939 == env53940) = true)

def env53941 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,1297,13340,311,1296,439,12552,13341,4097,397,16,4391,5504,13593,12583,1296,9480,15404,8205,9496,256,17,1297,14089]

theorem envBound53941 : H12AffineFastState.Bounded env53941 := by
  intro p hp
  have h : env53941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53940_53941 : H12AffineEnvironment.transform 5 16 env53940 = env53941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env53940 == env53941) = true)

theorem identity53941 : scanCanonicalize (H12AffineFastState.compose env53941 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound53941 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env53942 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,1297,5393,311,1296,439,4101,5392,4097,397,16,4391,5504,5140,4138,1296,1029,7457,256,1045,256,17,1297,5636]

theorem envBound53942 : H12AffineFastState.Bounded env53942 := by
  intro p hp
  have h : env53942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53941_53942 : H12AffineEnvironment.transform 12 269 env53941 = env53942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env53941 == env53942) = true)

theorem identity53942 : scanCanonicalize (H12AffineFastState.compose env53942 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound53942 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env53943 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1029,269,1297,276,311,1296,439,1024,277,1028,397,16,1314,389,17,1071,1296,1029,2340,256,1045,256,17,1297,513]

theorem envBound53943 : H12AffineFastState.Bounded env53943 := by
  intro p hp
  have h : env53943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53942_53943 : H12AffineEnvironment.transform 11 1029 env53942 = env53943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env53942 == env53943) = true)

theorem identity53943 : scanCanonicalize (H12AffineFastState.compose env53943 (packedSelected [2,13,17] rootPS)) = affineNative (2^(10+1) ^^^ 951) := by decide +kernel

theorem selectedBound53943 : packedSelected [2,13,17] rootPS < 2^1333 := by decide +kernel

def env53944 : List Nat := [2,4,8,16,32,16,128,256,512,1024,951,1029,269,1297,276,311,1296,439,1024,277,1028,397,16,1314,389,17,1071,1296,1029,659,256,1045,256,17,1297,513]

theorem envBound53944 : H12AffineFastState.Bounded env53944 := by
  intro p hp
  have h : env53944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53943_53944 : H12AffineEnvironment.transform 10 951 env53943 = env53944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 951 env53943 == env53944) = true)

theorem identity53944 : scanCanonicalize (H12AffineFastState.compose env53944 (packedSelected [1,5,10,13] rootPS)) = affineNative (2^(9+1) ^^^ 548) := by decide +kernel

theorem selectedBound53944 : packedSelected [1,5,10,13] rootPS < 2^1333 := by decide +kernel

def env53945 : List Nat := [2,4,8,16,32,16,128,256,512,548,951,545,269,821,276,311,820,439,548,277,544,397,16,774,389,17,523,820,545,659,256,561,256,17,821,513]

theorem envBound53945 : H12AffineFastState.Bounded env53945 := by
  intro p hp
  have h : env53945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53944_53945 : H12AffineEnvironment.transform 9 548 env53944 = env53945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 548 env53944 == env53945) = true)

theorem identity53945 : scanCanonicalize (H12AffineFastState.compose env53945 (packedSelected [0,2,7,8,10,11,12,15] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound53945 : packedSelected [0,2,7,8,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env53946 : List Nat := [2,4,5,16,32,16,128,256,512,548,951,545,256,821,276,311,820,439,548,277,544,384,16,774,389,17,518,820,545,659,256,561,256,17,821,513]

theorem envBound53946 : H12AffineFastState.Bounded env53946 := by
  intro p hp
  have h : env53946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53945_53946 : H12AffineEnvironment.transform 2 5 env53945 = env53946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env53945 == env53946) = true)

theorem identity53946 : scanCanonicalize (H12AffineFastState.compose env53946 (packedSelected [2,3,5,10,11,18] rootPS)) = affineNative (2^(8+1) ^^^ 148) := by decide +kernel

theorem selectedBound53946 : packedSelected [2,3,5,10,11,18] rootPS < 2^1333 := by decide +kernel

def env53947 : List Nat := [2,4,5,16,32,16,128,256,148,176,291,181,256,417,276,311,416,439,176,277,180,384,16,402,389,17,146,416,181,7,256,165,256,17,417,149]

theorem envBound53947 : H12AffineFastState.Bounded env53947 := by
  intro p hp
  have h : env53947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53946_53947 : H12AffineEnvironment.transform 8 148 env53946 = env53947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 148 env53946 == env53947) = true)

theorem identity53947 : scanCanonicalize (H12AffineFastState.compose env53947 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound53947 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53948 : List Nat := [2,4,5,16,32,16,128,4,148,176,39,181,4,165,16,51,164,179,176,17,180,132,16,150,129,17,146,164,181,7,4,165,4,17,165,149]

theorem envBound53948 : H12AffineFastState.Bounded env53948 := by
  intro p hp
  have h : env53948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53947_53948 : H12AffineEnvironment.transform 7 4 env53947 = env53948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env53947 == env53948) = true)

theorem identity53948 : scanCanonicalize (H12AffineFastState.compose env53948 (packedSelected [0,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 50) := by decide +kernel

theorem selectedBound53948 : packedSelected [0,5,7] rootPS < 2^1333 := by decide +kernel

def env53949 : List Nat := [2,4,5,16,32,16,50,4,38,2,39,7,4,23,16,51,22,1,2,17,6,54,16,36,51,17,32,22,7,7,4,23,4,17,23,39]

theorem envBound53949 : H12AffineFastState.Bounded env53949 := by
  intro p hp
  have h : env53949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53948_53949 : H12AffineEnvironment.transform 6 50 env53948 = env53949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 50 env53948 == env53949) = true)

theorem identity53949 : scanCanonicalize (H12AffineFastState.compose env53949 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 18) := by decide +kernel

theorem selectedBound53949 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env53950 : List Nat := [2,4,5,16,18,16,0,4,20,2,21,7,4,23,16,1,22,1,2,17,6,4,16,22,1,17,18,22,7,7,4,23,4,17,23,21]

theorem envBound53950 : H12AffineFastState.Bounded env53950 := by
  intro p hp
  have h : env53950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53949_53950 : H12AffineEnvironment.transform 4 18 env53949 = env53950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 18 env53949 == env53950) = true)

theorem identity53950 : scanCanonicalize (H12AffineFastState.compose env53950 (packedSelected [0,1,4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound53950 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env53951 : List Nat := [2,2,3,16,18,16,0,2,18,2,19,1,2,17,16,1,16,1,2,17,0,2,16,16,1,17,18,16,1,1,2,17,2,17,17,19]

theorem envBound53951 : H12AffineFastState.Bounded env53951 := by
  intro p hp
  have h : env53951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53950_53951 : H12AffineEnvironment.transform 1 2 env53950 = env53951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env53950 == env53951) = true)

theorem identity53951 : scanCanonicalize (H12AffineFastState.compose env53951 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound53951 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53952 : List Nat := [1,1,0,16,17,16,0,1,17,1,16,1,1,17,16,1,16,1,1,17,0,1,16,16,1,17,17,16,1,1,1,17,1,17,17,16]

theorem envBound53952 : H12AffineFastState.Bounded env53952 := by
  intro p hp
  have h : env53952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53951_53952 : H12AffineEnvironment.transform 0 1 env53951 = env53952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env53951 == env53952) = true)

theorem identity53952 : scanCanonicalize (H12AffineFastState.compose env53952 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound53952 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53953 : List Nat := [1,1,0,0,1,0,0,1,1,1,0,1,1,1,0,1,0,1,1,1,0,1,0,0,1,1,1,0,1,1,1,1,1,1,1,0]

theorem envBound53953 : H12AffineFastState.Bounded env53953 := by
  intro p hp
  have h : env53953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53952_53953 : H12AffineEnvironment.transform 3 0 env53952 = env53953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env53952 == env53953) = true)

def env53954 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1297,13340,311,1297,439,12553,13341,4097,396,16,4391,5505,13593,12583,1296,9480,15405,8205,9496,256,17,1296,14088]

theorem envBound53954 : H12AffineFastState.Bounded env53954 := by
  intro p hp
  have h : env53954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53940_53954 : H12AffineEnvironment.transform 5 17 env53940 = env53954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53940 == env53954) = true)

theorem identity53954 : scanCanonicalize (H12AffineFastState.compose env53954 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound53954 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env53955 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1028,8192,1297,8216,311,1297,439,9485,8217,1029,396,16,1315,389,8477,9507,1296,9480,10281,8205,9496,256,17,1296,8972]

theorem envBound53955 : H12AffineFastState.Bounded env53955 := by
  intro p hp
  have h : env53955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53954_53955 : H12AffineEnvironment.transform 11 1028 env53954 = env53955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env53954 == env53955) = true)

theorem identity53955 : scanCanonicalize (H12AffineFastState.compose env53955 (packedSelected [1,2,3,5,8,10,19,23,32] rootPS)) = affineNative (2^(9+1) ^^^ 652) := by decide +kernel

theorem selectedBound53955 : packedSelected [1,2,3,5,8,10,19,23,32] rootPS < 2^1333 := by decide +kernel

def env53956 : List Nat := [2,4,8,16,32,17,128,256,512,652,2048,648,8192,925,8216,311,925,439,9089,8217,649,396,16,943,389,8477,9135,924,9092,10281,8205,9108,256,17,924,8972]

theorem envBound53956 : H12AffineFastState.Bounded env53956 := by
  intro p hp
  have h : env53956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53955_53956 : H12AffineEnvironment.transform 9 652 env53955 = env53956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 652 env53955 == env53956) = true)

theorem identity53956 : scanCanonicalize (H12AffineFastState.compose env53956 (packedSelected [0,1,4,7,8,9,13,18,19,23,24,28] rootPS)) = affineNative (2^(12+1) ^^^ 2098) := by decide +kernel

theorem selectedBound53956 : packedSelected [0,1,4,7,8,9,13,18,19,23,24,28] rootPS < 2^1333 := by decide +kernel

def env53957 : List Nat := [2,4,8,16,32,17,128,256,512,652,2048,648,2098,925,2090,311,925,439,2995,2091,649,396,16,943,389,2351,2973,924,2998,27,2111,2982,256,17,924,2878]

theorem envBound53957 : H12AffineFastState.Bounded env53957 := by
  intro p hp
  have h : env53957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53956_53957 : H12AffineEnvironment.transform 12 2098 env53956 = env53957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2098 env53956 == env53957) = true)

theorem identity53957 : scanCanonicalize (H12AffineFastState.compose env53957 (packedSelected [0,2,3,4,7,8,9,11,12,13,15,17,18,19] rootPS)) = affineNative (2^(10+1) ^^^ 950) := by decide +kernel

theorem selectedBound53957 : packedSelected [0,2,3,4,7,8,9,11,12,13,15,17,18,19] rootPS < 2^1333 := by decide +kernel

def env53958 : List Nat := [2,4,8,16,32,17,128,256,512,652,950,648,900,925,924,311,925,439,5,925,649,396,16,943,389,665,43,924,0,27,905,16,256,17,924,136]

theorem envBound53958 : H12AffineFastState.Bounded env53958 := by
  intro p hp
  have h : env53958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53957_53958 : H12AffineEnvironment.transform 10 950 env53957 = env53958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 950 env53957 == env53958) = true)

theorem identity53958 : scanCanonicalize (H12AffineFastState.compose env53958 (packedSelected [0,1,7,10,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 63) := by decide +kernel

theorem selectedBound53958 : packedSelected [0,1,7,10,11,12] rootPS < 2^1333 := by decide +kernel

def env53959 : List Nat := [2,4,8,16,32,17,63,256,512,563,777,567,827,802,803,311,802,264,5,802,566,307,16,784,314,550,43,803,0,27,822,16,256,17,803,55]

theorem envBound53959 : H12AffineFastState.Bounded env53959 := by
  intro p hp
  have h : env53959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53958_53959 : H12AffineEnvironment.transform 6 63 env53958 = env53959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 63 env53958 == env53959) = true)

theorem identity53959 : scanCanonicalize (H12AffineFastState.compose env53959 (packedSelected [0,2,3,5,7,8,11,13] rootPS)) = affineNative (2^(7+1) ^^^ 9) := by decide +kernel

theorem selectedBound53959 : packedSelected [0,2,3,5,7,8,11,13] rootPS < 2^1333 := by decide +kernel

def env53960 : List Nat := [2,4,8,16,32,17,63,9,512,563,512,567,562,555,554,62,555,1,5,555,566,58,16,537,51,550,43,554,0,27,575,16,9,17,554,55]

theorem envBound53960 : H12AffineFastState.Bounded env53960 := by
  intro p hp
  have h : env53960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53959_53960 : H12AffineEnvironment.transform 7 9 env53959 = env53960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 9 env53959 == env53960) = true)

theorem identity53960 : scanCanonicalize (H12AffineFastState.compose env53960 (packedSelected [8] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound53960 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env53961 : List Nat := [2,4,8,11,32,10,36,9,512,552,512,556,553,555,554,37,555,1,5,555,557,33,11,514,40,550,43,554,0,0,548,11,9,10,554,44]

theorem envBound53961 : H12AffineFastState.Bounded env53961 := by
  intro p hp
  have h : env53961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53960_53961 : H12AffineEnvironment.transform 3 11 env53960 = env53961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env53960 == env53961) = true)

theorem identity53961 : scanCanonicalize (H12AffineFastState.compose env53961 (packedSelected [2,5] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound53961 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env53962 : List Nat := [2,4,8,11,13,10,9,9,512,517,512,513,516,518,519,8,518,1,5,518,512,12,11,514,5,523,6,519,0,0,521,11,9,10,519,1]

theorem envBound53962 : H12AffineFastState.Bounded env53962 := by
  intro p hp
  have h : env53962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53961_53962 : H12AffineEnvironment.transform 4 13 env53961 = env53962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env53961 == env53962) = true)

theorem identity53962 : scanCanonicalize (H12AffineFastState.compose env53962 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound53962 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53963 : List Nat := [2,4,8,11,13,10,9,9,0,5,0,1,4,6,7,8,6,1,5,6,0,12,11,2,5,11,6,7,0,0,9,11,9,10,7,1]

theorem envBound53963 : H12AffineFastState.Bounded env53963 := by
  intro p hp
  have h : env53963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53962_53963 : H12AffineEnvironment.transform 8 0 env53962 = env53963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env53962 == env53963) = true)

theorem identity53963 : scanCanonicalize (H12AffineFastState.compose env53963 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound53963 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53964 : List Nat := [2,4,6,5,3,4,7,7,0,5,0,1,4,6,7,6,6,1,5,6,0,2,5,2,5,5,6,7,0,0,7,5,7,4,7,1]

theorem envBound53964 : H12AffineFastState.Bounded env53964 := by
  intro p hp
  have h : env53964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53963_53964 : H12AffineEnvironment.transform 2 6 env53963 = env53964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env53963 == env53964) = true)

def env53965 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1344,65665,77935,13341,4097,477,16,69649,70887,78894,77840,1296,74815,81227,8204,74799,256,65831,1345,79470]

theorem envBound53965 : H12AffineFastState.Bounded env53965 := by
  intro p hp
  have h : env53965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53938_53965 : H12AffineEnvironment.transform 17 65665 env53938 = env53965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env53938 == env53965) = true)

theorem identity53965 : scanCanonicalize (H12AffineFastState.compose env53965 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5238) := by decide +kernel

theorem selectedBound53965 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env53966 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,5238,1344,5367,9241,13341,4097,477,16,1127,145,8280,9318,1296,12361,10557,8204,12377,256,5457,1345,8728]

theorem envBound53966 : H12AffineFastState.Bounded env53966 := by
  intro p hp
  have h : env53966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53965_53966 : H12AffineEnvironment.transform 15 5238 env53965 = env53966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5238 env53965 == env53966) = true)

def env53967 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,1297,13340,5158,1296,5287,9241,13341,4097,397,16,1079,145,8200,9270,1296,12313,10557,8204,12297,256,5377,1297,8728]

theorem envBound53967 : H12AffineFastState.Bounded env53967 := by
  intro p hp
  have h : env53967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53966_53967 : H12AffineEnvironment.transform 5 16 env53966 = env53967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env53966 == env53967) = true)

theorem identity53967 : scanCanonicalize (H12AffineFastState.compose env53967 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound53967 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env53968 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,1297,5392,5158,1296,5287,1301,5393,4097,397,16,1079,145,260,1338,1296,4373,2097,256,4357,256,5377,1297,788]

theorem envBound53968 : H12AffineFastState.Bounded env53968 := by
  intro p hp
  have h : env53968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53967_53968 : H12AffineEnvironment.transform 12 268 env53967 = env53968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env53967 == env53968) = true)

def env53969 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1297,13340,5159,1297,5286,9241,13341,4097,396,16,1078,145,8201,9271,1296,12312,10557,8204,12296,256,5376,1296,8728]

theorem envBound53969 : H12AffineFastState.Bounded env53969 := by
  intro p hp
  have h : env53969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53966_53969 : H12AffineEnvironment.transform 5 17 env53966 = env53969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53966 == env53969) = true)

theorem identity53969 : scanCanonicalize (H12AffineFastState.compose env53969 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound53969 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env53970 : List Nat := [2,4,8,16,32,17,128,21,512,1024,2048,4096,8192,1028,13340,5159,1028,5286,9241,13341,4097,153,16,1078,145,8201,9271,1029,12312,10280,8204,12296,21,5141,1029,8728]

theorem envBound53970 : H12AffineFastState.Bounded env53970 := by
  intro p hp
  have h : env53970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53969_53970 : H12AffineEnvironment.transform 7 21 env53969 = env53970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env53969 == env53970) = true)

theorem identity53970 : scanCanonicalize (H12AffineFastState.compose env53970 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound53970 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env53971 : List Nat := [2,4,8,16,32,17,128,21,512,1024,2048,4096,24,1028,5124,5159,1028,5286,1025,5125,4097,153,16,1078,145,17,1071,1029,4096,2096,20,4112,21,5141,1029,512]

theorem envBound53971 : H12AffineFastState.Bounded env53971 := by
  intro p hp
  have h : env53971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53970_53971 : H12AffineEnvironment.transform 12 24 env53970 = env53971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env53970 == env53971) = true)

theorem identity53971 : scanCanonicalize (H12AffineFastState.compose env53971 (packedSelected [2,13,17] rootPS)) = affineNative (2^(11+1) ^^^ 2697) := by decide +kernel

theorem selectedBound53971 : packedSelected [2,13,17] rootPS < 2^1333 := by decide +kernel

def env53972 : List Nat := [2,4,8,16,32,17,128,21,512,1024,2048,2697,24,1028,3725,3758,1028,3631,1025,3724,2696,153,16,1078,145,17,1071,1029,2697,2096,20,2713,21,3740,1029,512]

theorem envBound53972 : H12AffineFastState.Bounded env53972 := by
  intro p hp
  have h : env53972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53971_53972 : H12AffineEnvironment.transform 11 2697 env53971 = env53972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2697 env53971 == env53972) = true)

theorem identity53972 : scanCanonicalize (H12AffineFastState.compose env53972 (packedSelected [2,3,5,10,11,18] rootPS)) = affineNative (2^(9+1) ^^^ 543) := by decide +kernel

theorem selectedBound53972 : packedSelected [2,3,5,10,11,18] rootPS < 2^1333 := by decide +kernel

def env53973 : List Nat := [2,4,8,16,32,17,128,21,512,543,2048,2697,24,539,2194,2225,539,2096,542,2195,2696,153,16,553,145,17,560,538,2697,2096,20,2713,21,2179,538,512]

theorem envBound53973 : H12AffineFastState.Bounded env53973 := by
  intro p hp
  have h : env53973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53972_53973 : H12AffineEnvironment.transform 9 543 env53972 = env53973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 543 env53972 == env53973) = true)

theorem identity53973 : scanCanonicalize (H12AffineFastState.compose env53973 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound53973 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env53974 : List Nat := [2,4,8,16,32,17,56,21,512,543,2048,2609,24,539,2090,2057,539,2096,542,2091,2608,33,16,553,41,17,560,538,2609,2096,20,2593,21,2107,538,512]

theorem envBound53974 : H12AffineFastState.Bounded env53974 := by
  intro p hp
  have h : env53974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53973_53974 : H12AffineEnvironment.transform 6 56 env53973 = env53974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env53973 == env53974) = true)

def env53975 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,16777216,533640,672784,17245633,148801,545089,96346,16876545,74798,256,17420373,1344,525825]

theorem envBound53975 : H12AffineFastState.Bounded env53975 := by
  intro p hp
  have h : env53975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53749_53975 : H12AffineEnvironment.transform 26 17245633 env53749 = env53975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env53749 == env53975) = true)

theorem identity53975 : scanCanonicalize (H12AffineFastState.compose env53975 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 74863) := by decide +kernel

theorem selectedBound53975 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env53976 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,524288,32769,4097,61648,91182,16777216,533640,614527,17039790,90414,545089,96346,16876545,74798,256,17420373,1344,525825]

theorem envBound53976 : H12AffineFastState.Bounded env53976 := by
  intro p hp
  have h : env53976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53975_53976 : H12AffineEnvironment.transform 16 74863 env53975 = env53976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 74863 env53975 == env53976) = true)

def env53977 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,524288,32769,4097,61648,91182,123164,533640,614527,385202,90414,545089,96346,25885,74798,256,536905,1344,525825]

theorem envBound53977 : H12AffineFastState.Bounded env53977 := by
  intro p hp
  have h : env53977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53976_53977 : H12AffineEnvironment.transform 23 123164 env53976 = env53977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123164 env53976 == env53977) = true)

def env53978 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21584,32769,4097,61648,91182,123164,28888,78895,385202,90414,1297,96346,25885,74798,256,25881,1344,21073]

theorem envBound53978 : H12AffineFastState.Bounded env53978 := by
  intro p hp
  have h : env53978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53977_53978 : H12AffineEnvironment.transform 18 21584 env53977 = env53978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env53977 == env53978) = true)

theorem identity53978 : scanCanonicalize (H12AffineFastState.compose env53978 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound53978 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env53979 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13340,65536,74863,262144,21584,13341,4097,17612,91182,87296,28888,78895,349358,90414,1297,96346,25885,74798,256,25881,1344,21073]

theorem envBound53979 : H12AffineFastState.Bounded env53979 := by
  intro p hp
  have h : env53979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53978_53979 : H12AffineEnvironment.transform 14 13340 env53978 = env53979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env53978 == env53979) = true)

def env53980 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74863,262144,4416,13341,4097,476,74046,69648,13768,78895,332222,74814,1297,81226,8205,74798,256,8201,1344,5953]

theorem envBound53980 : H12AffineFastState.Bounded env53980 := by
  intro p hp
  have h : env53980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53979_53980 : H12AffineEnvironment.transform 13 1296 env53979 = env53980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env53979 == env53980) = true)

def env53981 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74863,65664,4416,13341,4097,476,74046,69648,13768,78895,4414,74814,1297,81226,8205,74798,256,8201,1344,5953]

theorem envBound53981 : H12AffineFastState.Bounded env53981 := by
  intro p hp
  have h : env53981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53980_53981 : H12AffineEnvironment.transform 17 65664 env53980 = env53981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env53980 == env53981) = true)

theorem identity53981 : scanCanonicalize (H12AffineFastState.compose env53981 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound53981 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env53982 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,24,1296,5124,65536,66679,65664,4416,5125,4097,476,65830,69648,5584,70711,4414,66598,1297,73042,21,66614,256,17,1344,5953]

theorem envBound53982 : H12AffineFastState.Bounded env53982 := by
  intro p hp
  have h : env53982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53981_53982 : H12AffineEnvironment.transform 12 24 env53981 = env53982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env53981 == env53982) = true)

def env53983 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,4096,24,1296,5124,65536,66679,65664,4416,5125,4097,476,65830,69648,5584,70711,4414,66598,1297,73042,21,66614,256,17,1344,5141]

theorem envBound53983 : H12AffineFastState.Bounded env53983 := by
  intro p hp
  have h : env53983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53982_53983 : H12AffineEnvironment.transform 8 340 env53982 = env53983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env53982 == env53983) = true)

def env53984 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,1280,24,1296,260,65536,66679,65664,1088,261,1281,476,65830,66832,208,65847,1086,66598,1297,67666,21,66614,256,17,1344,277]

theorem envBound53984 : H12AffineFastState.Bounded env53984 := by
  intro p hp
  have h : env53984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53983_53984 : H12AffineEnvironment.transform 11 1280 env53983 = env53984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env53983 == env53984) = true)

theorem identity53984 : scanCanonicalize (H12AffineFastState.compose env53984 (packedSelected [1,8,28] rootPS)) = affineNative (2^(9+1) ^^^ 171) := by decide +kernel

theorem selectedBound53984 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env53985 : List Nat := [2,4,8,16,32,64,128,256,340,171,2048,427,24,443,260,65536,65756,65664,235,261,426,476,65830,65979,208,65847,149,65677,442,67666,21,65693,256,17,491,277]

theorem envBound53985 : H12AffineFastState.Bounded env53985 := by
  intro p hp
  have h : env53985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53984_53985 : H12AffineEnvironment.transform 9 171 env53984 = env53985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 171 env53984 == env53985) = true)

def env53986 : List Nat := [2,4,8,16,32,64,128,256,340,171,2048,427,24,443,260,304,492,432,235,261,426,476,22,139,208,7,149,445,442,2402,21,429,256,17,491,277]

theorem envBound53986 : H12AffineFastState.Bounded env53986 := by
  intro p hp
  have h : env53986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53985_53986 : H12AffineEnvironment.transform 15 304 env53985 = env53986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 304 env53985 == env53986) = true)

theorem identity53986 : scanCanonicalize (H12AffineFastState.compose env53986 (packedSelected [3,4,9,10,17,18,19,20,21,23,24] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound53986 : packedSelected [3,4,9,10,17,18,19,20,21,23,24] rootPS < 2^1333 := by decide +kernel

def env53987 : List Nat := [2,3,8,16,32,64,128,256,339,171,2048,427,24,443,259,304,491,432,235,258,426,475,17,139,208,0,146,442,442,2402,18,426,256,17,491,274]

theorem envBound53987 : H12AffineFastState.Bounded env53987 := by
  intro p hp
  have h : env53987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53986_53987 : H12AffineEnvironment.transform 1 3 env53986 = env53987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env53986 == env53987) = true)

theorem identity53987 : scanCanonicalize (H12AffineFastState.compose env53987 (packedSelected [1,3,4,5,9,10,11,13,16,17,18,19] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound53987 : packedSelected [1,3,4,5,9,10,11,13,16,17,18,19] rootPS < 2^1333 := by decide +kernel

def env53988 : List Nat := [2,3,8,16,32,0,128,256,275,171,2048,427,24,443,259,304,427,432,171,258,426,411,17,139,144,0,146,442,442,2338,18,426,256,17,427,274]

theorem envBound53988 : H12AffineFastState.Bounded env53988 := by
  intro p hp
  have h : env53988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53987_53988 : H12AffineEnvironment.transform 5 0 env53987 = env53988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env53987 == env53988) = true)

theorem identity53988 : scanCanonicalize (H12AffineFastState.compose env53988 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 312) := by decide +kernel

theorem selectedBound53988 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env53989 : List Nat := [2,3,8,16,32,0,128,256,275,171,312,427,24,443,259,304,427,432,171,258,426,411,17,139,144,0,146,442,442,26,18,426,256,17,427,274]

theorem envBound53989 : H12AffineFastState.Bounded env53989 := by
  intro p hp
  have h : env53989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53988_53989 : H12AffineEnvironment.transform 10 312 env53988 = env53989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 312 env53988 == env53989) = true)

theorem identity53989 : scanCanonicalize (H12AffineFastState.compose env53989 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(7+1) ^^^ 129) := by decide +kernel

theorem selectedBound53989 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env53990 : List Nat := [2,3,8,16,32,0,128,129,146,171,185,42,24,58,130,177,42,49,171,131,43,26,17,139,144,0,146,59,59,26,18,43,129,17,42,147]

theorem envBound53990 : H12AffineFastState.Bounded env53990 := by
  intro p hp
  have h : env53990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53989_53990 : H12AffineEnvironment.transform 7 129 env53989 = env53990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 129 env53989 == env53990) = true)

theorem identity53990 : scanCanonicalize (H12AffineFastState.compose env53990 (packedSelected [0,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound53990 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env53991 : List Nat := [2,3,8,16,32,0,8,9,26,35,49,42,24,58,10,57,42,49,35,11,43,26,17,3,24,0,26,59,59,26,18,43,9,17,42,27]

theorem envBound53991 : H12AffineFastState.Bounded env53991 := by
  intro p hp
  have h : env53991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53990_53991 : H12AffineEnvironment.transform 6 8 env53990 = env53991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env53990 == env53991) = true)

theorem identity53991 : scanCanonicalize (H12AffineFastState.compose env53991 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound53991 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env53992 : List Nat := [2,3,8,16,26,0,8,9,26,25,11,16,24,0,10,3,16,11,25,11,17,26,17,3,24,0,26,1,1,26,18,17,9,17,16,27]

theorem envBound53992 : H12AffineFastState.Bounded env53992 := by
  intro p hp
  have h : env53992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53991_53992 : H12AffineEnvironment.transform 4 26 env53991 = env53992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env53991 == env53992) = true)

theorem identity53992 : scanCanonicalize (H12AffineFastState.compose env53992 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound53992 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53993 : List Nat := [2,3,8,11,1,0,8,9,1,2,11,11,3,0,10,3,11,11,2,11,10,1,10,3,3,0,1,1,1,1,9,10,9,10,11,0]

theorem envBound53993 : H12AffineFastState.Bounded env53993 := by
  intro p hp
  have h : env53993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53992_53993 : H12AffineEnvironment.transform 3 11 env53992 = env53993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env53992 == env53993) = true)

theorem identity53993 : scanCanonicalize (H12AffineFastState.compose env53993 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound53993 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53994 : List Nat := [1,0,8,8,1,0,8,9,1,1,8,8,0,0,9,0,8,8,1,8,9,1,9,0,0,0,1,1,1,1,9,9,9,9,8,0]

theorem envBound53994 : H12AffineFastState.Bounded env53994 := by
  intro p hp
  have h : env53994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53993_53994 : H12AffineEnvironment.transform 0 1 env53993 = env53994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env53993 == env53994) = true)

def env53995 : List Nat := [2,4,8,16,32,64,128,256,340,171,2048,427,24,443,260,305,493,433,235,261,426,476,23,138,208,6,149,444,442,2403,21,428,256,17,491,277]

theorem envBound53995 : H12AffineFastState.Bounded env53995 := by
  intro p hp
  have h : env53995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53985_53995 : H12AffineEnvironment.transform 15 305 env53985 = env53995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 305 env53985 == env53995) = true)

theorem identity53995 : scanCanonicalize (H12AffineFastState.compose env53995 (packedSelected [7,8,10,17,18,19,20,21,23,27] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound53995 : packedSelected [7,8,10,17,18,19,20,21,23,27] rootPS < 2^1333 := by decide +kernel

def env53996 : List Nat := [2,4,8,16,32,1,128,256,277,171,2048,427,24,443,260,305,428,433,170,261,426,413,23,138,145,6,149,444,442,2338,21,428,256,17,426,277]

theorem envBound53996 : H12AffineFastState.Bounded env53996 := by
  intro p hp
  have h : env53996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53995_53996 : H12AffineEnvironment.transform 5 1 env53995 = env53996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env53995 == env53996) = true)

theorem identity53996 : scanCanonicalize (H12AffineFastState.compose env53996 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 2) := by decide +kernel

theorem selectedBound53996 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env53997 : List Nat := [2,4,8,16,32,1,128,2,23,171,2048,169,24,185,6,51,174,179,170,7,168,159,23,138,145,6,149,190,184,2080,21,174,2,17,168,23]

theorem envBound53997 : H12AffineFastState.Bounded env53997 := by
  intro p hp
  have h : env53997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53996_53997 : H12AffineEnvironment.transform 7 2 env53996 = env53997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 2 env53996 == env53997) = true)

theorem identity53997 : scanCanonicalize (H12AffineFastState.compose env53997 (packedSelected [3,5,10,13,17] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound53997 : packedSelected [3,5,10,13,17] rootPS < 2^1333 := by decide +kernel

def env53998 : List Nat := [2,4,8,16,32,1,15,2,23,36,2048,38,24,54,6,51,33,60,37,7,39,16,23,5,30,6,26,49,55,2080,21,33,2,17,39,23]

theorem envBound53998 : H12AffineFastState.Bounded env53998 := by
  intro p hp
  have h : env53998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53997_53998 : H12AffineEnvironment.transform 6 15 env53997 = env53998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env53997 == env53998) = true)

theorem identity53998 : scanCanonicalize (H12AffineFastState.compose env53998 (packedSelected [0,4,5,7,9] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound53998 : packedSelected [0,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env53999 : List Nat := [2,4,8,0,32,1,15,2,7,36,2048,38,8,38,6,35,33,44,37,7,39,0,7,5,14,6,10,33,39,2080,5,33,2,1,39,7]

theorem envBound53999 : H12AffineFastState.Bounded env53999 := by
  intro p hp
  have h : env53999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53998_53999 : H12AffineEnvironment.transform 3 0 env53998 = env53999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env53998 == env53999) = true)

theorem identity53999 : scanCanonicalize (H12AffineFastState.compose env53999 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound53999 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env54000 : List Nat := [2,4,8,0,0,1,15,2,7,4,2048,6,8,6,6,3,1,12,5,7,7,0,7,5,14,6,10,1,7,2048,5,1,2,1,7,7]

theorem envBound54000 : H12AffineFastState.Bounded env54000 := by
  intro p hp
  have h : env54000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53999_54000 : H12AffineEnvironment.transform 4 0 env53999 = env54000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env53999 == env54000) = true)

theorem identity54000 : scanCanonicalize (H12AffineFastState.compose env54000 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound54000 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54001 : List Nat := [2,4,8,0,0,1,15,2,7,4,10,6,8,6,6,3,1,12,5,7,7,0,7,5,14,6,10,1,7,10,5,1,2,1,7,7]

theorem envBound54001 : H12AffineFastState.Bounded env54001 := by
  intro p hp
  have h : env54001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54000_54001 : H12AffineEnvironment.transform 10 10 env54000 = env54001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env54000 == env54001) = true)

theorem identity54001 : scanCanonicalize (H12AffineFastState.compose env54001 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound54001 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54002 : List Nat := [2,4,2,0,0,1,5,2,7,4,0,6,2,6,6,3,1,6,5,7,7,0,7,5,4,6,0,1,7,0,5,1,2,1,7,7]

theorem envBound54002 : H12AffineFastState.Bounded env54002 := by
  intro p hp
  have h : env54002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54001_54002 : H12AffineEnvironment.transform 2 2 env54001 = env54002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env54001 == env54002) = true)

theorem identity54002 : scanCanonicalize (H12AffineFastState.compose env54002 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound54002 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54003 : List Nat := [2,2,2,0,0,1,3,2,1,2,0,0,2,0,0,3,1,0,3,1,1,0,1,3,2,0,0,1,1,0,3,1,2,1,1,1]

theorem envBound54003 : H12AffineFastState.Bounded env54003 := by
  intro p hp
  have h : env54003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54002_54003 : H12AffineEnvironment.transform 1 2 env54002 = env54003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env54002 == env54003) = true)

def env54004 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,1281,24,1296,261,65536,66679,65664,1089,260,1280,476,65830,66833,209,65846,1087,66598,1297,67667,21,66614,256,17,1344,276]

theorem envBound54004 : H12AffineFastState.Bounded env54004 := by
  intro p hp
  have h : env54004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53983_54004 : H12AffineEnvironment.transform 11 1281 env53983 = env54004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env53983 == env54004) = true)

theorem identity54004 : scanCanonicalize (H12AffineFastState.compose env54004 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 187) := by decide +kernel

theorem selectedBound54004 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env54005 : List Nat := [2,4,8,16,32,64,128,187,239,1024,2048,1210,24,1195,190,65536,66679,65664,1089,191,1211,103,65693,66730,209,65677,1087,66598,1194,67667,21,66614,187,17,1275,175]

theorem envBound54005 : H12AffineFastState.Bounded env54005 := by
  intro p hp
  have h : env54005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54004_54005 : H12AffineEnvironment.transform 7 187 env54004 = env54005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 187 env54004 == env54005) = true)

def env54006 : List Nat := [2,4,8,16,32,64,128,187,239,172,2048,22,24,7,190,65536,65755,65664,237,191,23,103,65693,65542,209,65677,147,65674,6,67667,21,65690,187,17,87,175]

theorem envBound54006 : H12AffineFastState.Bounded env54006 := by
  intro p hp
  have h : env54006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54005_54006 : H12AffineEnvironment.transform 9 172 env54005 = env54006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 172 env54005 == env54006) = true)

theorem identity54006 : scanCanonicalize (H12AffineFastState.compose env54006 (packedSelected [3,4,9,10,17,18,19,20,21,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 140) := by decide +kernel

theorem selectedBound54006 : packedSelected [3,4,9,10,17,18,19,20,21,23,24] rootPS < 2^1333 := by decide +kernel

def env54007 : List Nat := [2,4,8,16,32,64,128,187,239,172,2048,22,24,7,190,140,87,12,237,191,23,103,17,138,209,1,147,6,6,2271,21,22,187,17,87,175]

theorem envBound54007 : H12AffineFastState.Bounded env54007 := by
  intro p hp
  have h : env54007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54006_54007 : H12AffineEnvironment.transform 15 140 env54006 = env54007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 140 env54006 == env54007) = true)

theorem identity54007 : scanCanonicalize (H12AffineFastState.compose env54007 (packedSelected [1,3,4,5,9,10,11,13,16,17,18,19] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound54007 : packedSelected [1,3,4,5,9,10,11,13,16,17,18,19] rootPS < 2^1333 := by decide +kernel

def env54008 : List Nat := [2,4,8,16,32,64,121,66,22,85,2048,22,24,7,71,117,87,12,20,70,23,103,17,115,40,1,106,6,6,2086,21,22,66,17,87,86]

theorem envBound54008 : H12AffineFastState.Bounded env54008 := by
  intro p hp
  have h : env54008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54007_54008 : H12AffineEnvironment.transform 6 121 env54007 = env54008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env54007 == env54008) = true)

theorem identity54008 : scanCanonicalize (H12AffineFastState.compose env54008 (packedSelected [0,1,3,4,5,7,9,10,11,12,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound54008 : packedSelected [0,1,3,4,5,7,9,10,11,12,15,16] rootPS < 2^1333 := by decide +kernel

def env54009 : List Nat := [2,4,8,16,32,17,40,19,22,4,2048,22,24,7,22,36,6,12,20,23,23,54,17,34,40,1,59,6,6,2086,21,22,19,17,6,7]

theorem envBound54009 : H12AffineFastState.Bounded env54009 := by
  intro p hp
  have h : env54009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54008_54009 : H12AffineEnvironment.transform 5 17 env54008 = env54009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54008 == env54009) = true)

theorem identity54009 : scanCanonicalize (H12AffineFastState.compose env54009 (packedSelected [1,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound54009 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env54010 : List Nat := [2,4,8,16,32,17,40,19,22,4,43,22,24,7,22,36,6,12,20,23,23,54,17,34,40,1,59,6,6,13,21,22,19,17,6,7]

theorem envBound54010 : H12AffineFastState.Bounded env54010 := by
  intro p hp
  have h : env54010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54009_54010 : H12AffineEnvironment.transform 10 43 env54009 = env54010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env54009 == env54010) = true)

theorem identity54010 : scanCanonicalize (H12AffineFastState.compose env54010 (packedSelected [3,4,7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound54010 : packedSelected [3,4,7] rootPS < 2^1333 := by decide +kernel

def env54011 : List Nat := [2,4,8,1,32,0,40,2,7,4,43,7,9,7,7,36,6,12,5,6,6,39,0,34,40,1,42,6,6,13,4,7,2,0,6,7]

theorem envBound54011 : H12AffineFastState.Bounded env54011 := by
  intro p hp
  have h : env54011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54010_54011 : H12AffineEnvironment.transform 3 1 env54010 = env54011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env54010 == env54011) = true)

theorem identity54011 : scanCanonicalize (H12AffineFastState.compose env54011 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound54011 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54012 : List Nat := [2,4,8,1,10,0,2,2,7,4,1,7,9,7,7,14,6,12,5,6,6,13,0,8,2,1,0,6,6,13,4,7,2,0,6,7]

theorem envBound54012 : H12AffineFastState.Bounded env54012 := by
  intro p hp
  have h : env54012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54011_54012 : H12AffineEnvironment.transform 4 10 env54011 = env54012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env54011 == env54012) = true)

theorem identity54012 : scanCanonicalize (H12AffineFastState.compose env54012 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound54012 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env54013 : List Nat := [2,4,3,1,1,0,2,2,7,4,1,7,2,7,7,5,6,7,5,6,6,6,0,3,2,1,0,6,6,6,4,7,2,0,6,7]

theorem envBound54013 : H12AffineFastState.Bounded env54013 := by
  intro p hp
  have h : env54013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54012_54013 : H12AffineEnvironment.transform 2 3 env54012 = env54013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env54012 == env54013) = true)

theorem identity54013 : scanCanonicalize (H12AffineFastState.compose env54013 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound54013 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54014 : List Nat := [2,2,3,1,1,0,2,2,1,2,1,1,2,1,1,3,0,1,3,0,0,0,0,3,2,1,0,0,0,0,2,1,2,0,0,1]

theorem envBound54014 : H12AffineFastState.Bounded env54014 := by
  intro p hp
  have h : env54014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54013_54014 : H12AffineEnvironment.transform 1 2 env54013 = env54014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env54013 == env54014) = true)

def env54015 : List Nat := [2,4,8,16,32,64,128,187,239,173,2048,23,24,6,190,65536,65754,65664,236,191,22,103,65693,65543,209,65677,146,65675,7,67667,21,65691,187,17,86,175]

theorem envBound54015 : H12AffineFastState.Bounded env54015 := by
  intro p hp
  have h : env54015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54005_54015 : H12AffineEnvironment.transform 9 173 env54005 = env54015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 173 env54005 == env54015) = true)

theorem identity54015 : scanCanonicalize (H12AffineFastState.compose env54015 (packedSelected [7,11,17,18,20,21,23,27,32] rootPS)) = affineNative (2^(10+1) ^^^ 124) := by decide +kernel

theorem selectedBound54015 : packedSelected [7,11,17,18,20,21,23,27,32] rootPS < 2^1333 := by decide +kernel

def env54016 : List Nat := [2,4,8,16,32,64,128,187,239,173,124,23,24,6,190,65536,65754,65664,236,191,22,103,65693,65543,209,65677,146,65675,7,65583,21,65691,187,17,86,175]

theorem envBound54016 : H12AffineFastState.Bounded env54016 := by
  intro p hp
  have h : env54016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54015_54016 : H12AffineEnvironment.transform 10 124 env54015 = env54016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 124 env54015 == env54016) = true)

theorem identity54016 : scanCanonicalize (H12AffineFastState.compose env54016 (packedSelected [8,10,13,16,18,19,20,21,23] rootPS)) = affineNative (2^(6+1) ^^^ 47) := by decide +kernel

theorem selectedBound54016 : packedSelected [8,10,13,16,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env54017 : List Nat := [2,4,8,16,32,64,47,20,64,2,124,23,24,6,17,65536,65653,65583,67,16,22,103,65586,65543,126,65570,61,65572,7,65583,21,65588,20,17,86,0]

theorem envBound54017 : H12AffineFastState.Bounded env54017 := by
  intro p hp
  have h : env54017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54016_54017 : H12AffineEnvironment.transform 6 47 env54016 = env54017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 47 env54016 == env54017) = true)

theorem identity54017 : scanCanonicalize (H12AffineFastState.compose env54017 (packedSelected [0,1,2,8,9,11,13,16] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound54017 : packedSelected [0,1,2,8,9,11,13,16] rootPS < 2^1333 := by decide +kernel

def env54018 : List Nat := [2,4,8,16,32,64,47,20,64,2,124,23,24,6,17,34,87,13,67,16,22,103,16,37,126,0,61,6,7,13,21,22,20,17,86,0]

theorem envBound54018 : H12AffineFastState.Bounded env54018 := by
  intro p hp
  have h : env54018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54017_54018 : H12AffineEnvironment.transform 15 34 env54017 = env54018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env54017 == env54018) = true)

theorem identity54018 : scanCanonicalize (H12AffineFastState.compose env54018 (packedSelected [0,1,3,5,9] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound54018 : packedSelected [0,1,3,5,9] rootPS < 2^1333 := by decide +kernel

def env54019 : List Nat := [2,2,8,16,32,64,41,18,64,2,122,17,24,0,17,34,81,11,67,16,16,97,16,35,120,0,59,0,1,11,19,16,18,17,80,0]

theorem envBound54019 : H12AffineFastState.Bounded env54019 := by
  intro p hp
  have h : env54019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54018_54019 : H12AffineEnvironment.transform 1 2 env54018 = env54019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env54018 == env54019) = true)

theorem identity54019 : scanCanonicalize (H12AffineFastState.compose env54019 (packedSelected [1,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound54019 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env54020 : List Nat := [2,2,8,16,32,0,41,18,0,2,58,17,24,0,17,34,17,11,3,16,16,33,16,35,56,0,59,0,1,11,19,16,18,17,16,0]

theorem envBound54020 : H12AffineFastState.Bounded env54020 := by
  intro p hp
  have h : env54020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54019_54020 : H12AffineEnvironment.transform 5 0 env54019 = env54020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env54019 == env54020) = true)

theorem identity54020 : scanCanonicalize (H12AffineFastState.compose env54020 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound54020 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env54021 : List Nat := [2,2,8,11,32,0,41,9,0,2,33,10,3,0,10,34,10,11,3,11,11,33,11,35,35,0,32,0,1,11,8,11,9,10,11,0]

theorem envBound54021 : H12AffineFastState.Bounded env54021 := by
  intro p hp
  have h : env54021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54020_54021 : H12AffineEnvironment.transform 3 11 env54020 = env54021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env54020 == env54021) = true)

theorem identity54021 : scanCanonicalize (H12AffineFastState.compose env54021 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound54021 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54022 : List Nat := [2,2,8,11,11,0,2,9,0,2,10,10,3,0,10,9,10,11,3,11,11,10,11,8,8,0,11,0,1,11,8,11,9,10,11,0]

theorem envBound54022 : H12AffineFastState.Bounded env54022 := by
  intro p hp
  have h : env54022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54021_54022 : H12AffineEnvironment.transform 4 11 env54021 = env54022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env54021 == env54022) = true)

theorem identity54022 : scanCanonicalize (H12AffineFastState.compose env54022 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound54022 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54023 : List Nat := [2,2,3,0,0,0,2,2,0,2,1,1,3,0,1,2,1,0,3,0,0,1,0,3,3,0,0,0,1,0,3,0,2,1,0,0]

theorem envBound54023 : H12AffineFastState.Bounded env54023 := by
  intro p hp
  have h : env54023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54022_54023 : H12AffineEnvironment.transform 2 3 env54022 = env54023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env54022 == env54023) = true)

def env54024 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,4096,24,1296,5124,65536,66679,65664,4416,5125,4097,476,65830,69648,5584,70711,4414,66598,1297,73042,21,66614,256,17,1344,5140]

theorem envBound54024 : H12AffineFastState.Bounded env54024 := by
  intro p hp
  have h : env54024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53982_54024 : H12AffineEnvironment.transform 8 341 env53982 = env54024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env53982 == env54024) = true)

def env54025 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,1280,24,1296,260,65536,66679,65664,1088,261,1281,476,65830,66832,208,65847,1086,66598,1297,67666,21,66614,256,17,1344,276]

theorem envBound54025 : H12AffineFastState.Bounded env54025 := by
  intro p hp
  have h : env54025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54024_54025 : H12AffineEnvironment.transform 11 1280 env54024 = env54025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env54024 == env54025) = true)

theorem identity54025 : scanCanonicalize (H12AffineFastState.compose env54025 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 1437) := by decide +kernel

theorem selectedBound54025 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env54026 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,1280,24,1296,260,1437,490,1309,1088,261,1281,476,1211,141,208,1194,1086,443,1297,3535,21,427,256,17,1344,276]

theorem envBound54026 : H12AffineFastState.Bounded env54026 := by
  intro p hp
  have h : env54026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54025_54026 : H12AffineEnvironment.transform 15 1437 env54025 = env54026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1437 env54025 == env54026) = true)

def env54027 : List Nat := [2,4,8,16,32,64,128,256,341,172,2048,428,24,444,260,305,490,433,236,261,429,476,23,141,208,6,146,443,445,2403,21,427,256,17,492,276]

theorem envBound54027 : H12AffineFastState.Bounded env54027 := by
  intro p hp
  have h : env54027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54026_54027 : H12AffineEnvironment.transform 9 172 env54026 = env54027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 172 env54026 == env54027) = true)

theorem identity54027 : scanCanonicalize (H12AffineFastState.compose env54027 (packedSelected [7,11,17,18,20,21,23,27,32] rootPS)) = affineNative (2^(10+1) ^^^ 454) := by decide +kernel

theorem selectedBound54027 : packedSelected [7,11,17,18,20,21,23,27,32] rootPS < 2^1333 := by decide +kernel

def env54028 : List Nat := [2,4,8,16,32,64,128,256,341,172,454,428,24,444,260,305,490,433,236,261,429,476,23,141,208,6,146,443,445,165,21,427,256,17,492,276]

theorem envBound54028 : H12AffineFastState.Bounded env54028 := by
  intro p hp
  have h : env54028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54027_54028 : H12AffineEnvironment.transform 10 454 env54027 = env54028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 454 env54027 == env54028) = true)

theorem identity54028 : scanCanonicalize (H12AffineFastState.compose env54028 (packedSelected [8,10,13,16,18,19,20,21,23] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound54028 : packedSelected [8,10,13,16,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env54029 : List Nat := [2,4,8,16,32,64,128,20,65,172,210,184,24,168,16,37,254,165,236,17,185,200,23,141,208,6,146,175,169,165,21,191,20,17,248,0]

theorem envBound54029 : H12AffineFastState.Bounded env54029 := by
  intro p hp
  have h : env54029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54028_54029 : H12AffineEnvironment.transform 7 20 env54028 = env54029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env54028 == env54029) = true)

theorem identity54029 : scanCanonicalize (H12AffineFastState.compose env54029 (packedSelected [0,1,2,8,9,11,13,16] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound54029 : packedSelected [0,1,2,8,9,11,13,16] rootPS < 2^1333 := by decide +kernel

def env54030 : List Nat := [2,3,8,16,32,64,128,19,65,171,210,184,24,168,16,34,249,162,235,17,185,200,16,138,208,1,146,168,169,162,18,184,19,17,248,0]

theorem envBound54030 : H12AffineFastState.Bounded env54030 := by
  intro p hp
  have h : env54030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54029_54030 : H12AffineEnvironment.transform 1 3 env54029 = env54030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env54029 == env54030) = true)

theorem identity54030 : scanCanonicalize (H12AffineFastState.compose env54030 (packedSelected [0,1,3,5,9] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound54030 : packedSelected [0,1,3,5,9] rootPS < 2^1333 := by decide +kernel

def env54031 : List Nat := [2,3,8,16,32,64,105,19,65,66,59,81,24,65,16,34,16,75,2,17,80,33,16,99,57,1,123,65,64,75,18,81,19,17,17,0]

theorem envBound54031 : H12AffineFastState.Bounded env54031 := by
  intro p hp
  have h : env54031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54030_54031 : H12AffineEnvironment.transform 6 105 env54030 = env54031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env54030 == env54031) = true)

theorem identity54031 : scanCanonicalize (H12AffineFastState.compose env54031 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound54031 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env54032 : List Nat := [2,3,8,11,32,64,105,8,65,66,32,74,3,65,11,34,11,75,2,10,75,33,11,99,34,1,96,65,64,75,9,74,8,10,10,0]

theorem envBound54032 : H12AffineFastState.Bounded env54032 := by
  intro p hp
  have h : env54032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54031_54032 : H12AffineEnvironment.transform 3 11 env54031 = env54032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env54031 == env54032) = true)

theorem identity54032 : scanCanonicalize (H12AffineFastState.compose env54032 (packedSelected [0,2,5,7] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound54032 : packedSelected [0,2,5,7] rootPS < 2^1333 := by decide +kernel

def env54033 : List Nat := [2,3,3,0,32,64,98,3,65,66,32,65,3,65,0,34,0,64,2,1,64,33,0,99,34,1,96,65,64,64,2,65,3,1,1,0]

theorem envBound54033 : H12AffineFastState.Bounded env54033 := by
  intro p hp
  have h : env54033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54032_54033 : H12AffineEnvironment.transform 2 3 env54032 = env54033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env54032 == env54033) = true)

def env54034 : List Nat := [2,4,8,16,32,64,128,256,341,173,2048,429,24,445,260,304,490,432,237,261,428,476,22,141,208,7,147,443,444,2402,21,427,256,17,493,276]

theorem envBound54034 : H12AffineFastState.Bounded env54034 := by
  intro p hp
  have h : env54034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54026_54034 : H12AffineEnvironment.transform 9 173 env54026 = env54034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 173 env54026 == env54034) = true)

theorem identity54034 : scanCanonicalize (H12AffineFastState.compose env54034 (packedSelected [3,4,9,10,17,18,19,20,21,23,24] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound54034 : packedSelected [3,4,9,10,17,18,19,20,21,23,24] rootPS < 2^1333 := by decide +kernel

def env54035 : List Nat := [2,3,8,16,32,64,128,256,338,170,2048,426,24,442,259,304,490,432,234,258,427,475,17,138,208,0,147,443,443,2402,18,427,256,17,490,275]

theorem envBound54035 : H12AffineFastState.Bounded env54035 := by
  intro p hp
  have h : env54035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54034_54035 : H12AffineEnvironment.transform 1 3 env54034 = env54035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env54034 == env54035) = true)

theorem identity54035 : scanCanonicalize (H12AffineFastState.compose env54035 (packedSelected [1,3,4,5,9,10,11,13,16,17,18,19] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound54035 : packedSelected [1,3,4,5,9,10,11,13,16,17,18,19] rootPS < 2^1333 := by decide +kernel

def env54036 : List Nat := [2,3,8,16,32,64,120,256,338,82,2048,338,24,322,259,304,274,328,18,258,339,291,17,114,40,0,107,323,323,2402,18,339,256,17,274,275]

theorem envBound54036 : H12AffineFastState.Bounded env54036 := by
  intro p hp
  have h : env54036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54035_54036 : H12AffineEnvironment.transform 6 120 env54035 = env54036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env54035 == env54036) = true)

theorem identity54036 : scanCanonicalize (H12AffineFastState.compose env54036 (packedSelected [0,1,3,4,5,7,9,10,11,12,15,16] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound54036 : packedSelected [0,1,3,4,5,7,9,10,11,12,15,16] rootPS < 2^1333 := by decide +kernel

def env54037 : List Nat := [2,3,8,0,32,64,104,256,322,66,2048,322,8,322,259,288,258,328,2,258,323,291,1,98,40,0,107,323,323,2402,2,323,256,1,258,259]

theorem envBound54037 : H12AffineFastState.Bounded env54037 := by
  intro p hp
  have h : env54037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54036_54037 : H12AffineEnvironment.transform 3 0 env54036 = env54037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env54036 == env54037) = true)

theorem identity54037 : scanCanonicalize (H12AffineFastState.compose env54037 (packedSelected [0,1,2,4,7,8,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 264) := by decide +kernel

theorem selectedBound54037 : packedSelected [0,1,2,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env54038 : List Nat := [2,3,8,0,32,64,104,256,322,66,264,322,8,322,259,288,258,328,2,258,323,291,1,98,40,0,107,323,323,106,2,323,256,1,258,259]

theorem envBound54038 : H12AffineFastState.Bounded env54038 := by
  intro p hp
  have h : env54038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54037_54038 : H12AffineEnvironment.transform 10 264 env54037 = env54038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 264 env54037 == env54038) = true)

theorem identity54038 : scanCanonicalize (H12AffineFastState.compose env54038 (packedSelected [3,5] rootPS)) = affineNative (2^(7+1) ^^^ 2) := by decide +kernel

theorem selectedBound54038 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env54039 : List Nat := [2,3,8,0,32,64,104,2,64,66,10,64,8,64,1,34,0,74,2,0,65,33,1,98,40,0,107,65,65,106,2,65,2,1,0,1]

theorem envBound54039 : H12AffineFastState.Bounded env54039 := by
  intro p hp
  have h : env54039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54038_54039 : H12AffineEnvironment.transform 7 2 env54038 = env54039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 2 env54038 == env54039) = true)

theorem identity54039 : scanCanonicalize (H12AffineFastState.compose env54039 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 43) := by decide +kernel

theorem selectedBound54039 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env54040 : List Nat := [2,3,8,0,32,43,3,2,43,41,10,43,8,43,1,34,0,33,2,0,42,33,1,9,40,0,0,42,42,1,2,42,2,1,0,1]

theorem envBound54040 : H12AffineFastState.Bounded env54040 := by
  intro p hp
  have h : env54040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54039_54040 : H12AffineEnvironment.transform 5 43 env54039 = env54040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 43 env54039 == env54040) = true)

theorem identity54040 : scanCanonicalize (H12AffineFastState.compose env54040 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound54040 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env54041 : List Nat := [2,3,8,0,0,11,3,2,11,9,10,11,8,11,1,2,0,1,2,0,10,1,1,9,8,0,0,10,10,1,2,10,2,1,0,1]

theorem envBound54041 : H12AffineFastState.Bounded env54041 := by
  intro p hp
  have h : env54041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54040_54041 : H12AffineEnvironment.transform 4 0 env54040 = env54041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env54040 == env54041) = true)

def env54042 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,1281,24,1296,261,65536,66679,65664,1089,260,1280,476,65830,66833,209,65846,1087,66598,1297,67667,21,66614,256,17,1344,277]

theorem envBound54042 : H12AffineFastState.Bounded env54042 := by
  intro p hp
  have h : env54042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54024_54042 : H12AffineEnvironment.transform 11 1281 env54024 = env54042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env54024 == env54042) = true)

theorem identity54042 : scanCanonicalize (H12AffineFastState.compose env54042 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 141) := by decide +kernel

theorem selectedBound54042 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env54043 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,1281,24,1296,261,141,1274,13,1089,260,1280,476,427,1436,209,443,1087,1195,1297,2270,21,1211,256,17,1344,277]

theorem envBound54043 : H12AffineFastState.Bounded env54043 := by
  intro p hp
  have h : env54043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54042_54043 : H12AffineEnvironment.transform 15 141 env54042 = env54043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 141 env54042 == env54043) = true)

def env54044 : List Nat := [2,4,8,16,32,64,128,256,341,172,2048,429,24,444,261,141,86,13,237,260,428,476,427,304,209,443,147,7,445,2270,21,23,256,17,492,277]

theorem envBound54044 : H12AffineFastState.Bounded env54044 := by
  intro p hp
  have h : env54044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54043_54044 : H12AffineEnvironment.transform 9 172 env54043 = env54044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 172 env54043 == env54044) = true)

theorem identity54044 : scanCanonicalize (H12AffineFastState.compose env54044 (packedSelected [3,4,9,10,17,18,19,20,21,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 186) := by decide +kernel

theorem selectedBound54044 : packedSelected [3,4,9,10,17,18,19,20,21,23,24] rootPS < 2^1333 := by decide +kernel

def env54045 : List Nat := [2,4,8,16,32,64,128,186,239,172,2048,23,24,6,191,141,86,13,237,190,22,102,17,138,209,1,147,7,7,2270,21,23,186,17,86,175]

theorem envBound54045 : H12AffineFastState.Bounded env54045 := by
  intro p hp
  have h : env54045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54044_54045 : H12AffineEnvironment.transform 7 186 env54044 = env54045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 186 env54044 == env54045) = true)

theorem identity54045 : scanCanonicalize (H12AffineFastState.compose env54045 (packedSelected [1,3,4,5,9,10,11,13,16,17,18,19] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound54045 : packedSelected [1,3,4,5,9,10,11,13,16,17,18,19] rootPS < 2^1333 := by decide +kernel

def env54046 : List Nat := [2,4,8,16,32,64,121,67,22,85,2048,23,24,6,70,116,86,13,20,71,22,102,17,115,40,1,106,7,7,2087,21,23,67,17,86,86]

theorem envBound54046 : H12AffineFastState.Bounded env54046 := by
  intro p hp
  have h : env54046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54045_54046 : H12AffineEnvironment.transform 6 121 env54045 = env54046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env54045 == env54046) = true)

theorem identity54046 : scanCanonicalize (H12AffineFastState.compose env54046 (packedSelected [0,1,3,4,5,7,9,10,11,12,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound54046 : packedSelected [0,1,3,4,5,7,9,10,11,12,15,16] rootPS < 2^1333 := by decide +kernel

def env54047 : List Nat := [2,4,8,16,32,17,40,18,22,4,2048,23,24,6,23,37,7,13,20,22,22,55,17,34,40,1,59,7,7,2087,21,23,18,17,7,7]

theorem envBound54047 : H12AffineFastState.Bounded env54047 := by
  intro p hp
  have h : env54047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54046_54047 : H12AffineEnvironment.transform 5 17 env54046 = env54047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54046 == env54047) = true)

theorem identity54047 : scanCanonicalize (H12AffineFastState.compose env54047 (packedSelected [1,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound54047 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env54048 : List Nat := [2,4,8,16,32,17,40,18,22,4,43,23,24,6,23,37,7,13,20,22,22,55,17,34,40,1,59,7,7,12,21,23,18,17,7,7]

theorem envBound54048 : H12AffineFastState.Bounded env54048 := by
  intro p hp
  have h : env54048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54047_54048 : H12AffineEnvironment.transform 10 43 env54047 = env54048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env54047 == env54048) = true)

theorem identity54048 : scanCanonicalize (H12AffineFastState.compose env54048 (packedSelected [3,4,7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound54048 : packedSelected [3,4,7] rootPS < 2^1333 := by decide +kernel

def env54049 : List Nat := [2,4,8,0,32,1,40,2,6,4,43,7,8,6,7,37,7,13,4,6,6,39,1,34,40,1,43,7,7,12,5,7,2,1,7,7]

theorem envBound54049 : H12AffineFastState.Bounded env54049 := by
  intro p hp
  have h : env54049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54048_54049 : H12AffineEnvironment.transform 3 0 env54048 = env54049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env54048 == env54049) = true)

theorem identity54049 : scanCanonicalize (H12AffineFastState.compose env54049 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound54049 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54050 : List Nat := [2,4,8,0,7,1,15,2,6,4,12,7,8,6,7,2,7,13,4,6,6,0,1,5,15,1,12,7,7,12,5,7,2,1,7,7]

theorem envBound54050 : H12AffineFastState.Bounded env54050 := by
  intro p hp
  have h : env54050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54049_54050 : H12AffineEnvironment.transform 4 7 env54049 = env54050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env54049 == env54050) = true)

theorem identity54050 : scanCanonicalize (H12AffineFastState.compose env54050 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound54050 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54051 : List Nat := [2,4,6,0,7,1,1,2,6,4,2,7,6,6,7,2,7,3,4,6,6,0,1,5,1,1,2,7,7,2,5,7,2,1,7,7]

theorem envBound54051 : H12AffineFastState.Bounded env54051 := by
  intro p hp
  have h : env54051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54050_54051 : H12AffineEnvironment.transform 2 6 env54050 = env54051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env54050 == env54051) = true)

theorem identity54051 : scanCanonicalize (H12AffineFastState.compose env54051 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound54051 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54052 : List Nat := [2,1,3,0,2,1,1,2,3,1,2,2,3,3,2,2,2,3,1,3,3,0,1,0,1,1,2,2,2,2,0,2,2,1,2,2]

theorem envBound54052 : H12AffineFastState.Bounded env54052 := by
  intro p hp
  have h : env54052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54051_54052 : H12AffineEnvironment.transform 1 1 env54051 = env54052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env54051 == env54052) = true)

theorem identity54052 : scanCanonicalize (H12AffineFastState.compose env54052 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound54052 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env54053 : List Nat := [1,1,0,0,1,1,1,1,0,1,1,1,0,0,1,1,1,0,1,0,0,0,1,0,1,1,1,1,1,1,0,1,1,1,1,1]

theorem envBound54053 : H12AffineFastState.Bounded env54053 := by
  intro p hp
  have h : env54053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54052_54053 : H12AffineEnvironment.transform 0 1 env54052 = env54053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env54052 == env54053) = true)

def env54054 : List Nat := [2,4,8,16,32,64,128,256,341,173,2048,428,24,445,261,141,87,13,236,260,429,476,427,305,209,443,146,6,444,2270,21,22,256,17,493,277]

theorem envBound54054 : H12AffineFastState.Bounded env54054 := by
  intro p hp
  have h : env54054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54043_54054 : H12AffineEnvironment.transform 9 173 env54043 = env54054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 173 env54043 == env54054) = true)

theorem identity54054 : scanCanonicalize (H12AffineFastState.compose env54054 (packedSelected [7,11,17,18,20,21,23,27,32] rootPS)) = affineNative (2^(10+1) ^^^ 455) := by decide +kernel

theorem selectedBound54054 : packedSelected [7,11,17,18,20,21,23,27,32] rootPS < 2^1333 := by decide +kernel

def env54055 : List Nat := [2,4,8,16,32,64,128,256,341,173,455,428,24,445,261,141,87,13,236,260,429,476,427,305,209,443,146,6,444,281,21,22,256,17,493,277]

theorem envBound54055 : H12AffineFastState.Bounded env54055 := by
  intro p hp
  have h : env54055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54054_54055 : H12AffineEnvironment.transform 10 455 env54054 = env54055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 455 env54054 == env54055) = true)

theorem identity54055 : scanCanonicalize (H12AffineFastState.compose env54055 (packedSelected [8,10,13,16,18,19,20,21,23] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound54055 : packedSelected [8,10,13,16,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env54056 : List Nat := [2,4,8,16,32,64,128,20,65,173,211,184,24,169,17,141,87,13,236,16,185,200,191,37,209,175,146,6,168,13,21,22,20,17,249,1]

theorem envBound54056 : H12AffineFastState.Bounded env54056 := by
  intro p hp
  have h : env54056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54055_54056 : H12AffineEnvironment.transform 7 20 env54055 = env54056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env54055 == env54056) = true)

theorem identity54056 : scanCanonicalize (H12AffineFastState.compose env54056 (packedSelected [0,1,2,8,9,11,13,16] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound54056 : packedSelected [0,1,2,8,9,11,13,16] rootPS < 2^1333 := by decide +kernel

def env54057 : List Nat := [2,4,8,16,32,0,128,20,1,173,147,184,24,169,17,141,23,13,172,16,185,136,191,37,145,175,146,6,168,13,21,22,20,17,185,1]

theorem envBound54057 : H12AffineFastState.Bounded env54057 := by
  intro p hp
  have h : env54057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54056_54057 : H12AffineEnvironment.transform 5 0 env54056 = env54057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env54056 == env54057) = true)

theorem identity54057 : scanCanonicalize (H12AffineFastState.compose env54057 (packedSelected [1,4,9,10] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound54057 : packedSelected [1,4,9,10] rootPS < 2^1333 := by decide +kernel

def env54058 : List Nat := [2,4,8,12,32,0,128,8,1,173,143,164,4,169,13,141,11,13,172,12,165,136,163,37,141,175,142,6,168,13,9,10,8,13,165,1]

theorem envBound54058 : H12AffineFastState.Bounded env54058 := by
  intro p hp
  have h : env54058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54057_54058 : H12AffineEnvironment.transform 3 12 env54057 = env54058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env54057 == env54058) = true)

theorem identity54058 : scanCanonicalize (H12AffineFastState.compose env54058 (packedSelected [0,1,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 37) := by decide +kernel

theorem selectedBound54058 : packedSelected [0,1,3,5] rootPS < 2^1333 := by decide +kernel

def env54059 : List Nat := [2,4,8,12,32,0,37,8,1,8,42,1,4,12,13,40,11,13,9,12,0,45,6,37,40,10,43,6,13,13,9,10,8,13,0,1]

theorem envBound54059 : H12AffineFastState.Bounded env54059 := by
  intro p hp
  have h : env54059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54058_54059 : H12AffineEnvironment.transform 6 37 env54058 = env54059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 37 env54058 == env54059) = true)

theorem identity54059 : scanCanonicalize (H12AffineFastState.compose env54059 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound54059 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54060 : List Nat := [2,2,8,10,32,0,35,8,1,8,42,1,2,10,11,40,11,11,9,10,0,43,0,35,40,10,43,0,11,11,9,10,8,11,0,1]

theorem envBound54060 : H12AffineFastState.Bounded env54060 := by
  intro p hp
  have h : env54060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54059_54060 : H12AffineEnvironment.transform 1 2 env54059 = env54060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env54059 == env54060) = true)

theorem identity54060 : scanCanonicalize (H12AffineFastState.compose env54060 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound54060 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env54061 : List Nat := [2,2,8,10,1,0,2,8,1,8,11,1,2,10,11,9,11,11,9,10,0,10,0,2,9,10,10,0,11,11,9,10,8,11,0,1]

theorem envBound54061 : H12AffineFastState.Bounded env54061 := by
  intro p hp
  have h : env54061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54060_54061 : H12AffineEnvironment.transform 4 1 env54060 = env54061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env54060 == env54061) = true)

theorem identity54061 : scanCanonicalize (H12AffineFastState.compose env54061 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound54061 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54062 : List Nat := [2,2,2,0,1,0,2,2,1,2,1,1,2,0,1,3,1,1,3,0,0,0,0,2,3,0,0,0,1,1,3,0,2,1,0,1]

theorem envBound54062 : H12AffineFastState.Bounded env54062 := by
  intro p hp
  have h : env54062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54061_54062 : H12AffineEnvironment.transform 2 2 env54061 = env54062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env54061 == env54062) = true)

def env54063 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74863,65665,4416,13341,4097,476,74046,69648,13768,78895,4415,74814,1297,81226,8205,74798,256,8201,1344,5953]

theorem envBound54063 : H12AffineFastState.Bounded env54063 := by
  intro p hp
  have h : env54063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53980_54063 : H12AffineEnvironment.transform 17 65665 env53980 = env54063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env53980 == env54063) = true)

theorem identity54063 : scanCanonicalize (H12AffineFastState.compose env54063 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5464) := by decide +kernel

theorem selectedBound54063 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env54064 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5464,1296,324,65536,69943,65665,4416,325,4097,476,70758,69648,144,65911,4415,69990,1297,67602,5461,70006,256,5457,1344,5953]

theorem envBound54064 : H12AffineFastState.Bounded env54064 := by
  intro p hp
  have h : env54064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54063_54064 : H12AffineEnvironment.transform 12 5464 env54063 = env54064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5464 env54063 == env54064) = true)

def env54065 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,4096,5464,1296,324,65536,69943,65665,4416,325,4097,476,70758,69648,144,65911,4415,69990,1297,67602,5461,70006,256,5457,1344,5141]

theorem envBound54065 : H12AffineFastState.Bounded env54065 := by
  intro p hp
  have h : env54065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54064_54065 : H12AffineEnvironment.transform 8 340 env54064 = env54065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env54064 == env54065) = true)

def env54066 : List Nat := [2,4,8,16,32,0,128,256,276,1024,2048,4096,5400,1296,260,65536,69943,65665,4352,261,4097,412,70694,69648,144,65847,4415,69926,1297,67602,5397,69942,256,5393,1280,5141]

theorem envBound54066 : H12AffineFastState.Bounded env54066 := by
  intro p hp
  have h : env54066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54065_54066 : H12AffineEnvironment.transform 5 0 env54065 = env54066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env54065 == env54066) = true)

theorem identity54066 : scanCanonicalize (H12AffineFastState.compose env54066 (packedSelected [1,8,28] rootPS)) = affineNative (2^(11+1) ^^^ 426) := by decide +kernel

theorem selectedBound54066 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env54067 : List Nat := [2,4,8,16,32,0,128,256,276,1024,2048,426,1202,1296,260,65536,65693,65665,170,261,427,412,66956,65978,144,65847,149,65676,1297,67602,1215,65692,256,1211,1280,1471]

theorem envBound54067 : H12AffineFastState.Bounded env54067 := by
  intro p hp
  have h : env54067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54066_54067 : H12AffineEnvironment.transform 11 426 env54066 = env54067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 426 env54066 == env54067) = true)

def env54068 : List Nat := [2,4,8,16,32,0,128,256,276,1024,2048,426,1202,1296,260,1436,1281,1309,170,261,427,412,16,1062,144,1195,149,1296,1297,3470,1215,1280,256,1211,1280,1471]

theorem envBound54068 : H12AffineFastState.Bounded env54068 := by
  intro p hp
  have h : env54068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54067_54068 : H12AffineEnvironment.transform 15 1436 env54067 = env54068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1436 env54067 == env54068) = true)

theorem identity54068 : scanCanonicalize (H12AffineFastState.compose env54068 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 170) := by decide +kernel

theorem selectedBound54068 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env54069 : List Nat := [2,4,8,16,32,0,128,170,190,1024,2048,0,1202,1210,174,1078,1195,1207,170,175,1,54,16,1062,144,1195,149,1210,1211,3108,1215,1194,170,1211,1194,1045]

theorem envBound54069 : H12AffineFastState.Bounded env54069 := by
  intro p hp
  have h : env54069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54068_54069 : H12AffineEnvironment.transform 7 170 env54068 = env54069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 170 env54068 == env54069) = true)

theorem identity54069 : scanCanonicalize (H12AffineFastState.compose env54069 (packedSelected [0,1,4,7,8,9,10,12,13,16,20] rootPS)) = affineNative (2^(10+1) ^^^ 1055) := by decide +kernel

theorem selectedBound54069 : packedSelected [0,1,4,7,8,9,10,12,13,16,20] rootPS < 2^1333 := by decide +kernel

def env54070 : List Nat := [2,4,8,16,32,0,128,170,190,1024,1055,0,1202,1210,174,1078,1195,1207,170,175,1,54,16,1062,144,1195,149,1210,1211,59,1215,1194,170,1211,1194,1045]

theorem envBound54070 : H12AffineFastState.Bounded env54070 := by
  intro p hp
  have h : env54070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54069_54070 : H12AffineEnvironment.transform 10 1055 env54069 = env54070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1055 env54069 == env54070) = true)

theorem identity54070 : scanCanonicalize (H12AffineFastState.compose env54070 (packedSelected [4,5,9,12,13,16] rootPS)) = affineNative (2^(9+1) ^^^ 154) := by decide +kernel

theorem selectedBound54070 : packedSelected [4,5,9,12,13,16] rootPS < 2^1333 := by decide +kernel

def env54071 : List Nat := [2,4,8,16,32,0,128,170,190,154,133,0,40,32,174,172,49,45,170,175,1,54,16,188,144,49,149,32,33,59,37,48,170,33,48,143]

theorem envBound54071 : H12AffineFastState.Bounded env54071 := by
  intro p hp
  have h : env54071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54070_54071 : H12AffineEnvironment.transform 9 154 env54070 = env54071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 154 env54070 == env54071) = true)

theorem identity54071 : scanCanonicalize (H12AffineFastState.compose env54071 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound54071 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env54072 : List Nat := [2,4,8,11,32,0,128,170,165,129,133,0,40,32,174,172,42,45,170,175,1,45,11,167,139,42,142,32,33,32,37,43,170,33,43,143]

theorem envBound54072 : H12AffineFastState.Bounded env54072 := by
  intro p hp
  have h : env54072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54071_54072 : H12AffineEnvironment.transform 3 11 env54071 = env54072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env54071 == env54072) = true)

theorem identity54072 : scanCanonicalize (H12AffineFastState.compose env54072 (packedSelected [1,5] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound54072 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env54073 : List Nat := [2,4,8,11,32,0,3,41,38,2,6,0,40,32,45,47,42,45,41,44,1,45,11,36,8,42,13,32,33,32,37,43,41,33,43,12]

theorem envBound54073 : H12AffineFastState.Bounded env54073 := by
  intro p hp
  have h : env54073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54072_54073 : H12AffineEnvironment.transform 6 3 env54072 = env54073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env54072 == env54073) = true)

theorem identity54073 : scanCanonicalize (H12AffineFastState.compose env54073 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound54073 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env54074 : List Nat := [2,4,8,11,1,0,3,8,7,2,6,0,9,1,12,14,11,12,8,13,1,12,11,5,8,11,13,1,0,1,4,10,8,0,10,12]

theorem envBound54074 : H12AffineFastState.Bounded env54074 := by
  intro p hp
  have h : env54074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54073_54074 : H12AffineEnvironment.transform 4 1 env54073 = env54074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env54073 == env54074) = true)

def env54075 : List Nat := [2,4,8,16,32,0,128,256,276,1024,2048,426,1202,1296,260,1437,1280,1308,170,261,427,412,17,1063,144,1194,149,1297,1297,3471,1215,1281,256,1211,1280,1471]

theorem envBound54075 : H12AffineFastState.Bounded env54075 := by
  intro p hp
  have h : env54075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54067_54075 : H12AffineEnvironment.transform 15 1437 env54067 = env54075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1437 env54067 == env54075) = true)

theorem identity54075 : scanCanonicalize (H12AffineFastState.compose env54075 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound54075 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env54076 : List Nat := [2,4,8,16,32,0,128,21,1,1024,2048,191,1202,1029,17,1160,1045,1033,170,16,190,137,17,1063,144,1194,149,1028,1028,3226,1215,1044,21,1211,1045,1194]

theorem envBound54076 : H12AffineFastState.Bounded env54076 := by
  intro p hp
  have h : env54076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54075_54076 : H12AffineEnvironment.transform 7 21 env54075 = env54076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env54075 == env54076) = true)

theorem identity54076 : scanCanonicalize (H12AffineFastState.compose env54076 (packedSelected [0,5,7,17,20] rootPS)) = affineNative (2^(6+1) ^^^ 63) := by decide +kernel

theorem selectedBound54076 : packedSelected [0,5,7,17,20] rootPS < 2^1333 := by decide +kernel

def env54077 : List Nat := [2,4,8,16,32,0,63,21,1,1024,2048,0,1037,1029,17,1079,1045,1033,21,16,1,54,17,1063,47,1045,42,1028,1028,3109,1024,1044,21,1028,1045,1045]

theorem envBound54077 : H12AffineFastState.Bounded env54077 := by
  intro p hp
  have h : env54077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54076_54077 : H12AffineEnvironment.transform 6 63 env54076 = env54077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 63 env54076 == env54077) = true)

theorem identity54077 : scanCanonicalize (H12AffineFastState.compose env54077 (packedSelected [1,2,3,5,15] rootPS)) = affineNative (2^(10+1) ^^^ 44) := by decide +kernel

theorem selectedBound54077 : packedSelected [1,2,3,5,15] rootPS < 2^1333 := by decide +kernel

def env54078 : List Nat := [2,4,8,16,32,0,63,21,1,1024,44,0,1037,1029,17,1079,1045,1033,21,16,1,54,17,1063,47,1045,42,1028,1028,1033,1024,1044,21,1028,1045,1045]

theorem envBound54078 : H12AffineFastState.Bounded env54078 := by
  intro p hp
  have h : env54078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54077_54078 : H12AffineEnvironment.transform 10 44 env54077 = env54078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 44 env54077 == env54078) = true)

theorem identity54078 : scanCanonicalize (H12AffineFastState.compose env54078 (packedSelected [0,1,2,4,7,8,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound54078 : packedSelected [0,1,2,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env54079 : List Nat := [2,4,8,16,32,0,63,21,1,52,44,0,57,49,17,3,33,61,21,16,1,54,17,19,47,33,42,48,48,61,52,32,21,48,33,33]

theorem envBound54079 : H12AffineFastState.Bounded env54079 := by
  intro p hp
  have h : env54079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54078_54079 : H12AffineEnvironment.transform 9 52 env54078 = env54079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env54078 == env54079) = true)

theorem identity54079 : scanCanonicalize (H12AffineFastState.compose env54079 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound54079 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env54080 : List Nat := [2,4,8,10,32,0,37,15,1,46,44,0,35,43,11,3,33,39,15,10,1,44,11,9,47,33,42,42,42,39,46,32,15,42,33,33]

theorem envBound54080 : H12AffineFastState.Bounded env54080 := by
  intro p hp
  have h : env54080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54079_54080 : H12AffineEnvironment.transform 3 10 env54079 = env54080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env54079 == env54080) = true)

theorem identity54080 : scanCanonicalize (H12AffineFastState.compose env54080 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound54080 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env54081 : List Nat := [2,4,8,10,0,0,5,15,1,14,12,0,3,11,11,3,1,7,15,10,1,12,11,9,15,1,10,10,10,7,14,0,15,10,1,1]

theorem envBound54081 : H12AffineFastState.Bounded env54081 := by
  intro p hp
  have h : env54081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54080_54081 : H12AffineEnvironment.transform 4 0 env54080 = env54081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env54080 == env54081) = true)

theorem identity54081 : scanCanonicalize (H12AffineFastState.compose env54081 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound54081 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54082 : List Nat := [2,4,3,1,0,0,5,4,1,5,7,0,3,0,0,3,1,7,4,1,1,7,0,2,4,1,1,1,1,7,5,0,4,1,1,1]

theorem envBound54082 : H12AffineFastState.Bounded env54082 := by
  intro p hp
  have h : env54082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54081_54082 : H12AffineEnvironment.transform 2 3 env54081 = env54082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env54081 == env54082) = true)

def env54083 : List Nat := [2,4,8,16,32,1,128,256,277,1024,2048,4096,5401,1296,261,65536,69943,65665,4353,260,4097,413,70695,69648,144,65846,4415,69927,1297,67602,5396,69943,256,5392,1281,5141]

theorem envBound54083 : H12AffineFastState.Bounded env54083 := by
  intro p hp
  have h : env54083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54065_54083 : H12AffineEnvironment.transform 5 1 env54065 = env54083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env54065 == env54083) = true)

theorem identity54083 : scanCanonicalize (H12AffineFastState.compose env54083 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 186) := by decide +kernel

theorem selectedBound54083 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env54084 : List Nat := [2,4,8,16,32,1,128,186,175,1024,2048,4096,5283,1194,191,65536,69773,65665,4283,190,4097,39,70695,69648,144,65676,4229,69789,1195,67602,5294,69773,186,5290,1211,5141]

theorem envBound54084 : H12AffineFastState.Bounded env54084 := by
  intro p hp
  have h : env54084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54083_54084 : H12AffineEnvironment.transform 7 186 env54083 = env54084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 186 env54083 == env54084) = true)

def env54085 : List Nat := [2,4,8,16,32,1,128,186,175,1024,2048,16,1203,1194,191,65536,65693,65665,171,190,17,39,66615,65536,144,65676,149,65677,1195,67602,1214,65693,186,1210,1211,1029]

theorem envBound54085 : H12AffineFastState.Bounded env54085 := by
  intro p hp
  have h : env54085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54084_54085 : H12AffineEnvironment.transform 11 16 env54084 = env54085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env54084 == env54085) = true)

theorem identity54085 : scanCanonicalize (H12AffineFastState.compose env54085 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 1177) := by decide +kernel

theorem selectedBound54085 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env54086 : List Nat := [2,4,8,16,32,1,128,186,175,1024,2048,16,1203,1194,191,1177,1028,1048,171,190,17,39,174,1177,144,1045,149,1044,1195,3211,1214,1028,186,1210,1211,1029]

theorem envBound54086 : H12AffineFastState.Bounded env54086 := by
  intro p hp
  have h : env54086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54085_54086 : H12AffineEnvironment.transform 15 1177 env54085 = env54086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1177 env54085 == env54086) = true)

theorem identity54086 : scanCanonicalize (H12AffineFastState.compose env54086 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 186) := by decide +kernel

theorem selectedBound54086 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env54087 : List Nat := [2,4,8,16,32,1,128,186,175,186,2048,16,9,16,191,35,190,162,171,190,17,39,174,35,144,175,149,174,17,2097,4,190,186,0,1,191]

theorem envBound54087 : H12AffineFastState.Bounded env54087 := by
  intro p hp
  have h : env54087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54086_54087 : H12AffineEnvironment.transform 9 186 env54086 = env54087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 186 env54086 == env54087) = true)

theorem identity54087 : scanCanonicalize (H12AffineFastState.compose env54087 (packedSelected [0,1,7,10,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 58) := by decide +kernel

theorem selectedBound54087 : packedSelected [0,1,7,10,11,13] rootPS < 2^1333 := by decide +kernel

def env54088 : List Nat := [2,4,8,16,32,1,128,186,175,186,58,16,9,16,191,35,190,162,171,190,17,39,174,35,144,175,149,174,17,11,4,190,186,0,1,191]

theorem envBound54088 : H12AffineFastState.Bounded env54088 := by
  intro p hp
  have h : env54088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54087_54088 : H12AffineEnvironment.transform 10 58 env54087 = env54088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 58 env54087 == env54088) = true)

theorem identity54088 : scanCanonicalize (H12AffineFastState.compose env54088 (packedSelected [1,2,3,4,8,9,10,11] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound54088 : packedSelected [1,2,3,4,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env54089 : List Nat := [2,4,8,16,6,1,128,156,137,156,28,16,9,16,153,5,152,132,141,152,17,1,136,5,144,137,149,136,17,11,4,152,156,0,1,153]

theorem envBound54089 : H12AffineFastState.Bounded env54089 := by
  intro p hp
  have h : env54089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54088_54089 : H12AffineEnvironment.transform 4 6 env54088 = env54089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env54088 == env54089) = true)

theorem identity54089 : scanCanonicalize (H12AffineFastState.compose env54089 (packedSelected [3,8] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound54089 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env54090 : List Nat := [2,4,8,16,6,1,4,24,13,24,28,16,9,16,29,5,28,0,9,28,17,1,12,5,20,13,17,12,17,11,4,28,24,0,1,29]

theorem envBound54090 : H12AffineFastState.Bounded env54090 := by
  intro p hp
  have h : env54090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54089_54090 : H12AffineEnvironment.transform 6 4 env54089 = env54090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env54089 == env54090) = true)

theorem identity54090 : scanCanonicalize (H12AffineFastState.compose env54090 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound54090 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env54091 : List Nat := [2,4,8,6,6,1,4,14,13,14,10,6,9,6,11,5,10,0,9,10,7,1,12,5,2,13,7,12,7,11,4,10,14,0,1,11]

theorem envBound54091 : H12AffineFastState.Bounded env54091 := by
  intro p hp
  have h : env54091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54090_54091 : H12AffineEnvironment.transform 3 6 env54090 = env54091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env54090 == env54091) = true)

theorem identity54091 : scanCanonicalize (H12AffineFastState.compose env54091 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound54091 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env54092 : List Nat := [2,4,2,6,6,1,4,4,7,4,0,6,3,6,1,5,0,0,3,0,7,1,6,5,2,7,7,6,7,1,4,0,4,0,1,1]

theorem envBound54092 : H12AffineFastState.Bounded env54092 := by
  intro p hp
  have h : env54092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54091_54092 : H12AffineEnvironment.transform 2 2 env54091 = env54092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env54091 == env54092) = true)

def env54093 : List Nat := [2,4,8,16,32,1,128,186,175,1024,2048,17,1202,1194,191,65536,65692,65665,170,190,16,39,66614,65537,144,65676,148,65676,1195,67602,1215,65692,186,1211,1211,1028]

theorem envBound54093 : H12AffineFastState.Bounded env54093 := by
  intro p hp
  have h : env54093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54084_54093 : H12AffineEnvironment.transform 11 17 env54084 = env54093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env54084 == env54093) = true)

theorem identity54093 : scanCanonicalize (H12AffineFastState.compose env54093 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 51) := by decide +kernel

theorem selectedBound54093 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env54094 : List Nat := [2,4,8,16,32,1,128,186,175,1024,2048,17,1202,1194,191,51,175,178,170,190,16,39,1029,50,144,191,148,191,1195,2081,1215,175,186,1211,1211,1028]

theorem envBound54094 : H12AffineFastState.Bounded env54094 := by
  intro p hp
  have h : env54094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54093_54094 : H12AffineEnvironment.transform 15 51 env54093 = env54094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 51 env54093 == env54094) = true)

theorem identity54094 : scanCanonicalize (H12AffineFastState.compose env54094 (packedSelected [1,2,3,4,9,10,12,16,17] rootPS)) = affineNative (2^(9+1) ^^^ 41) := by decide +kernel

theorem selectedBound54094 : packedSelected [1,2,3,4,9,10,12,16,17] rootPS < 2^1333 := by decide +kernel

def env54095 : List Nat := [2,4,8,16,32,1,128,186,175,41,2048,17,155,131,191,51,175,178,170,190,16,39,44,50,144,191,148,191,130,2081,150,175,186,146,146,45]

theorem envBound54095 : H12AffineFastState.Bounded env54095 := by
  intro p hp
  have h : env54095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54094_54095 : H12AffineEnvironment.transform 9 41 env54094 = env54095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 41 env54094 == env54095) = true)

theorem identity54095 : scanCanonicalize (H12AffineFastState.compose env54095 (packedSelected [0,2,3,7,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 29) := by decide +kernel

theorem selectedBound54095 : packedSelected [0,2,3,7,11,13] rootPS < 2^1333 := by decide +kernel

def env54096 : List Nat := [2,4,8,16,32,1,128,186,175,41,29,17,155,131,191,51,175,178,170,190,16,39,44,50,144,191,148,191,130,60,150,175,186,146,146,45]

theorem envBound54096 : H12AffineFastState.Bounded env54096 := by
  intro p hp
  have h : env54096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54095_54096 : H12AffineEnvironment.transform 10 29 env54095 = env54096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 29 env54095 == env54096) = true)

theorem identity54096 : scanCanonicalize (H12AffineFastState.compose env54096 (packedSelected [0,1,2,5,9,11,12] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound54096 : packedSelected [0,1,2,5,9,11,12] rootPS < 2^1333 := by decide +kernel

def env54097 : List Nat := [2,4,8,0,32,1,128,170,175,41,13,1,139,131,175,35,175,162,170,174,0,39,44,34,128,175,132,175,130,44,134,175,170,130,130,45]

theorem envBound54097 : H12AffineFastState.Bounded env54097 := by
  intro p hp
  have h : env54097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54096_54097 : H12AffineEnvironment.transform 3 0 env54096 = env54097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env54096 == env54097) = true)

theorem identity54097 : scanCanonicalize (H12AffineFastState.compose env54097 (packedSelected [2,5] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound54097 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env54098 : List Nat := [2,2,8,0,32,1,128,170,169,41,11,1,139,131,169,35,169,162,170,168,0,33,42,34,128,169,130,169,130,42,128,169,170,130,130,43]

theorem envBound54098 : H12AffineFastState.Bounded env54098 := by
  intro p hp
  have h : env54098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54097_54098 : H12AffineEnvironment.transform 1 2 env54097 = env54098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env54097 == env54098) = true)

theorem identity54098 : scanCanonicalize (H12AffineFastState.compose env54098 (packedSelected [1,2] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound54098 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env54099 : List Nat := [2,2,8,0,32,1,35,9,10,41,11,1,40,32,10,35,10,1,9,11,0,33,42,34,35,10,33,10,33,42,35,10,9,33,33,43]

theorem envBound54099 : H12AffineFastState.Bounded env54099 := by
  intro p hp
  have h : env54099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54098_54099 : H12AffineEnvironment.transform 6 35 env54098 = env54099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env54098 == env54099) = true)

theorem identity54099 : scanCanonicalize (H12AffineFastState.compose env54099 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound54099 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env54100 : List Nat := [2,2,8,0,10,1,9,9,10,3,11,1,2,10,10,9,10,1,9,11,0,11,0,8,9,10,11,10,11,0,9,10,9,11,11,1]

theorem envBound54100 : H12AffineFastState.Bounded env54100 := by
  intro p hp
  have h : env54100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54099_54100 : H12AffineEnvironment.transform 4 10 env54099 = env54100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env54099 == env54100) = true)

def env54101 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,4096,5464,1296,324,65536,69943,65665,4416,325,4097,476,70758,69648,144,65911,4415,69990,1297,67602,5461,70006,256,5457,1344,5140]

theorem envBound54101 : H12AffineFastState.Bounded env54101 := by
  intro p hp
  have h : env54101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54064_54101 : H12AffineEnvironment.transform 8 341 env54064 = env54101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env54064 == env54101) = true)

def env54102 : List Nat := [2,4,8,16,32,0,128,256,277,1024,2048,4096,5400,1296,260,65536,69943,65665,4352,261,4097,412,70694,69648,144,65847,4415,69926,1297,67602,5397,69942,256,5393,1280,5140]

theorem envBound54102 : H12AffineFastState.Bounded env54102 := by
  intro p hp
  have h : env54102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54101_54102 : H12AffineEnvironment.transform 5 0 env54101 = env54102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env54101 == env54102) = true)

theorem identity54102 : scanCanonicalize (H12AffineFastState.compose env54102 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 1436) := by decide +kernel

theorem selectedBound54102 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env54103 : List Nat := [2,4,8,16,32,0,128,256,277,1024,2048,4096,5400,1296,260,1436,5291,1309,4352,261,4097,412,4538,5516,144,1195,4415,5306,1297,3470,5397,5290,256,5393,1280,5140]

theorem envBound54103 : H12AffineFastState.Bounded env54103 := by
  intro p hp
  have h : env54103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54102_54103 : H12AffineEnvironment.transform 15 1436 env54102 = env54103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1436 env54102 == env54103) = true)

def env54104 : List Nat := [2,4,8,16,32,0,128,256,277,1024,2048,2180,3484,1296,260,1436,3119,1309,2436,261,2181,412,2366,3336,144,1195,2491,3134,1297,3470,3473,3118,256,3477,1280,3216]

theorem envBound54104 : H12AffineFastState.Bounded env54104 := by
  intro p hp
  have h : env54104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54103_54104 : H12AffineEnvironment.transform 11 2180 env54103 = env54104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2180 env54103 == env54104) = true)

theorem identity54104 : scanCanonicalize (H12AffineFastState.compose env54104 (packedSelected [4,8,9,10,16,18,19,23] rootPS)) = affineNative (2^(10+1) ^^^ 1410) := by decide +kernel

theorem selectedBound54104 : packedSelected [4,8,9,10,16,18,19,23] rootPS < 2^1333 := by decide +kernel

def env54105 : List Nat := [2,4,8,16,32,0,128,256,277,1024,1410,1286,30,1296,260,1436,429,1309,1030,261,1287,412,1212,138,144,1195,1081,444,1297,12,19,428,256,23,1280,274]

theorem envBound54105 : H12AffineFastState.Bounded env54105 := by
  intro p hp
  have h : env54105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54104_54105 : H12AffineEnvironment.transform 10 1410 env54104 = env54105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1410 env54104 == env54105) = true)

theorem identity54105 : scanCanonicalize (H12AffineFastState.compose env54105 (packedSelected [1,2,4,7,8,10,12,16,17,18,20] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound54105 : packedSelected [1,2,4,7,8,10,12,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env54106 : List Nat := [2,4,8,16,32,0,128,256,277,189,319,443,30,429,260,289,429,416,187,261,442,412,1,138,144,22,132,444,428,12,19,428,256,23,445,274]

theorem envBound54106 : H12AffineFastState.Bounded env54106 := by
  intro p hp
  have h : env54106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54105_54106 : H12AffineEnvironment.transform 9 189 env54105 = env54106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env54105 == env54106) = true)

theorem identity54106 : scanCanonicalize (H12AffineFastState.compose env54106 (packedSelected [0,1,4,5,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 47) := by decide +kernel

theorem selectedBound54106 : packedSelected [0,1,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env54107 : List Nat := [2,4,8,16,32,0,128,47,58,189,16,148,30,130,43,14,130,143,187,42,149,179,1,138,144,22,132,147,131,12,19,131,47,23,146,61]

theorem envBound54107 : H12AffineFastState.Bounded env54107 := by
  intro p hp
  have h : env54107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54106_54107 : H12AffineEnvironment.transform 7 47 env54106 = env54107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 47 env54106 == env54107) = true)

theorem identity54107 : scanCanonicalize (H12AffineFastState.compose env54107 (packedSelected [0,4,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound54107 : packedSelected [0,4,5,10] rootPS < 2^1333 := by decide +kernel

def env54108 : List Nat := [2,4,8,6,32,0,128,47,44,171,6,130,8,130,43,14,130,143,173,42,131,165,1,138,134,0,132,133,131,12,5,131,47,1,132,43]

theorem envBound54108 : H12AffineFastState.Bounded env54108 := by
  intro p hp
  have h : env54108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54107_54108 : H12AffineEnvironment.transform 3 6 env54107 = env54108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env54107 == env54108) = true)

theorem identity54108 : scanCanonicalize (H12AffineFastState.compose env54108 (packedSelected [0,2,4] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound54108 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env54109 : List Nat := [2,4,8,6,32,0,4,47,44,47,6,6,8,6,43,14,6,11,41,42,7,33,1,14,2,0,0,1,7,12,5,7,47,1,0,43]

theorem envBound54109 : H12AffineFastState.Bounded env54109 := by
  intro p hp
  have h : env54109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54108_54109 : H12AffineEnvironment.transform 6 4 env54108 = env54109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env54108 == env54109) = true)

theorem identity54109 : scanCanonicalize (H12AffineFastState.compose env54109 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound54109 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env54110 : List Nat := [2,4,8,6,1,0,4,14,13,14,6,6,8,6,10,14,6,11,8,11,7,0,1,14,2,0,0,1,7,12,5,7,14,1,0,10]

theorem envBound54110 : H12AffineFastState.Bounded env54110 := by
  intro p hp
  have h : env54110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54109_54110 : H12AffineEnvironment.transform 4 1 env54109 = env54110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env54109 == env54110) = true)

def env54111 : List Nat := [2,4,8,16,32,0,128,256,277,1024,2048,2181,3485,1296,260,1436,3118,1309,2437,261,2180,412,2367,3337,144,1195,2490,3135,1297,3470,3472,3119,256,3476,1280,3217]

theorem envBound54111 : H12AffineFastState.Bounded env54111 := by
  intro p hp
  have h : env54111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54103_54111 : H12AffineEnvironment.transform 11 2181 env54103 = env54111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2181 env54103 == env54111) = true)

theorem identity54111 : scanCanonicalize (H12AffineFastState.compose env54111 (packedSelected [4,8,9,10,16,18,19,23] rootPS)) = affineNative (2^(10+1) ^^^ 1412) := by decide +kernel

theorem selectedBound54111 : packedSelected [4,8,9,10,16,18,19,23] rootPS < 2^1333 := by decide +kernel

def env54112 : List Nat := [2,4,8,16,32,0,128,256,277,1024,1412,1281,25,1296,260,1436,426,1309,1025,261,1280,412,1211,141,144,1195,1086,443,1297,10,20,427,256,16,1280,277]

theorem envBound54112 : H12AffineFastState.Bounded env54112 := by
  intro p hp
  have h : env54112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54111_54112 : H12AffineEnvironment.transform 10 1412 env54111 = env54112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1412 env54111 == env54112) = true)

theorem identity54112 : scanCanonicalize (H12AffineFastState.compose env54112 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 430) := by decide +kernel

theorem selectedBound54112 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env54113 : List Nat := [2,4,8,16,32,0,128,256,277,430,42,175,25,190,260,50,426,179,431,261,174,412,277,141,144,261,400,443,191,10,20,427,256,16,174,277]

theorem envBound54113 : H12AffineFastState.Bounded env54113 := by
  intro p hp
  have h : env54113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54112_54113 : H12AffineEnvironment.transform 9 430 env54112 = env54113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 430 env54112 == env54113) = true)

theorem identity54113 : scanCanonicalize (H12AffineFastState.compose env54113 (packedSelected [1,2,4,5,8,9,11,12,13,15] rootPS)) = affineNative (2^(6+1) ^^^ 63) := by decide +kernel

theorem selectedBound54113 : packedSelected [1,2,4,5,8,9,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env54114 : List Nat := [2,4,8,16,32,0,63,256,277,273,42,16,25,1,260,50,277,12,272,261,17,291,277,50,47,261,303,260,0,10,20,276,256,16,17,277]

theorem envBound54114 : H12AffineFastState.Bounded env54114 := by
  intro p hp
  have h : env54114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54113_54114 : H12AffineEnvironment.transform 6 63 env54113 = env54114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 63 env54113 == env54114) = true)

theorem identity54114 : scanCanonicalize (H12AffineFastState.compose env54114 (packedSelected [3,5,10] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound54114 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env54115 : List Nat := [2,4,8,16,7,0,24,256,277,273,13,16,25,1,260,21,277,12,272,261,17,260,277,21,8,261,264,260,0,10,20,276,256,16,17,277]

theorem envBound54115 : H12AffineFastState.Bounded env54115 := by
  intro p hp
  have h : env54115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54114_54115 : H12AffineEnvironment.transform 4 7 env54114 = env54115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env54114 == env54115) = true)

theorem identity54115 : scanCanonicalize (H12AffineFastState.compose env54115 (packedSelected [1,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 2) := by decide +kernel

theorem selectedBound54115 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env54116 : List Nat := [2,4,8,16,7,0,24,2,23,19,13,16,25,1,6,21,23,12,18,7,17,6,23,21,8,7,10,6,0,10,20,22,2,16,17,23]

theorem envBound54116 : H12AffineFastState.Bounded env54116 := by
  intro p hp
  have h : env54116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54115_54116 : H12AffineEnvironment.transform 7 2 env54115 = env54116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 2 env54115 == env54116) = true)

theorem identity54116 : scanCanonicalize (H12AffineFastState.compose env54116 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound54116 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env54117 : List Nat := [2,4,8,7,7,0,15,2,0,4,13,7,14,1,6,2,0,12,5,7,6,6,0,2,8,7,10,6,0,10,3,1,2,7,6,0]

theorem envBound54117 : H12AffineFastState.Bounded env54117 := by
  intro p hp
  have h : env54117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54116_54117 : H12AffineEnvironment.transform 3 7 env54116 = env54117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env54116 == env54117) = true)

theorem identity54117 : scanCanonicalize (H12AffineFastState.compose env54117 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound54117 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54118 : List Nat := [2,4,3,7,7,0,4,2,0,4,6,7,5,1,6,2,0,7,5,7,6,6,0,2,3,7,1,6,0,1,3,1,2,7,6,0]

theorem envBound54118 : H12AffineFastState.Bounded env54118 := by
  intro p hp
  have h : env54118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54117_54118 : H12AffineEnvironment.transform 2 3 env54117 = env54118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env54117 == env54118) = true)

def env54119 : List Nat := [2,4,8,16,32,1,128,256,276,1024,2048,4096,5401,1296,261,65536,69943,65665,4353,260,4097,413,70695,69648,144,65846,4415,69927,1297,67602,5396,69943,256,5392,1281,5140]

theorem envBound54119 : H12AffineFastState.Bounded env54119 := by
  intro p hp
  have h : env54119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54101_54119 : H12AffineEnvironment.transform 5 1 env54101 = env54119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env54101 == env54119) = true)

theorem identity54119 : scanCanonicalize (H12AffineFastState.compose env54119 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 5517) := by decide +kernel

theorem selectedBound54119 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env54120 : List Nat := [2,4,8,16,32,1,128,256,276,1024,2048,4096,5401,1296,261,5517,1210,5388,4353,260,4097,413,426,1437,144,5307,4415,1194,1297,7583,5396,1210,256,5392,1281,5140]

theorem envBound54120 : H12AffineFastState.Bounded env54120 := by
  intro p hp
  have h : env54120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54119_54120 : H12AffineEnvironment.transform 15 5517 env54119 = env54120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5517 env54119 == env54120) = true)

def env54121 : List Nat := [2,4,8,16,32,1,128,256,276,1024,296,4096,5401,1296,261,5517,1210,5388,4353,260,4097,413,426,1437,144,5307,4415,1194,1297,5303,5396,1210,256,5392,1281,5140]

theorem envBound54121 : H12AffineFastState.Bounded env54121 := by
  intro p hp
  have h : env54121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54120_54121 : H12AffineEnvironment.transform 10 296 env54120 = env54121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 296 env54120 == env54121) = true)

theorem identity54121 : scanCanonicalize (H12AffineFastState.compose env54121 (packedSelected [0,2,3,4,5,9,10,11,12,13,15,16,17,21,23,27] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound54121 : packedSelected [0,2,3,4,5,9,10,11,12,13,15,16,17,21,23,27] rootPS < 2^1333 := by decide +kernel

def env54122 : List Nat := [2,4,8,16,32,1,24,256,276,1024,296,4096,5401,1296,261,5397,1058,5388,4353,260,4097,261,306,1285,8,5155,4415,1074,1297,5167,5396,1058,256,5392,1281,5140]

theorem envBound54122 : H12AffineFastState.Bounded env54122 := by
  intro p hp
  have h : env54122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54121_54122 : H12AffineEnvironment.transform 6 24 env54121 = env54122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env54121 == env54122) = true)

theorem identity54122 : scanCanonicalize (H12AffineFastState.compose env54122 (packedSelected [1,2,5,7,8,9,10,12,13,15,16,17,18,19] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound54122 : packedSelected [1,2,5,7,8,9,10,12,13,15,16,17,18,19] rootPS < 2^1333 := by decide +kernel

def env54123 : List Nat := [2,4,8,13,32,1,5,256,265,1024,296,4096,5380,1293,261,5384,1058,5388,4353,260,4097,261,303,1285,8,5155,4386,1071,1292,5167,5385,1058,256,5389,1281,5129]

theorem envBound54123 : H12AffineFastState.Bounded env54123 := by
  intro p hp
  have h : env54123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54122_54123 : H12AffineEnvironment.transform 3 13 env54122 = env54123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env54122 == env54123) = true)

theorem identity54123 : scanCanonicalize (H12AffineFastState.compose env54123 (packedSelected [1,5,7,8,9,10,11,12,13,16,17] rootPS)) = affineNative (2^(9+1) ^^^ 288) := by decide +kernel

theorem selectedBound54123 : packedSelected [1,5,7,8,9,10,11,12,13,16,17] rootPS < 2^1333 := by decide +kernel

def env54124 : List Nat := [2,4,8,13,32,1,5,256,265,288,296,4096,4132,45,261,4136,258,4140,4353,260,4097,261,303,37,8,4355,4386,271,44,4367,4137,258,256,4141,33,4393]

theorem envBound54124 : H12AffineFastState.Bounded env54124 := by
  intro p hp
  have h : env54124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54123_54124 : H12AffineEnvironment.transform 9 288 env54123 = env54124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 288 env54123 == env54124) = true)

theorem identity54124 : scanCanonicalize (H12AffineFastState.compose env54124 (packedSelected [3,4,7,8,11] rootPS)) = affineNative (2^(7+1) ^^^ 2) := by decide +kernel

theorem selectedBound54124 : packedSelected [3,4,7,8,11] rootPS < 2^1333 := by decide +kernel

def env54125 : List Nat := [2,4,8,13,32,1,5,2,11,34,42,4096,4132,45,7,4136,0,4140,4099,6,4097,7,45,37,8,4097,4128,13,44,4109,4137,0,2,4141,33,4139]

theorem envBound54125 : H12AffineFastState.Bounded env54125 := by
  intro p hp
  have h : env54125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54124_54125 : H12AffineEnvironment.transform 7 2 env54124 = env54125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 2 env54124 == env54125) = true)

theorem identity54125 : scanCanonicalize (H12AffineFastState.compose env54125 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound54125 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env54126 : List Nat := [2,4,8,13,32,1,5,2,11,34,42,0,36,45,7,40,0,44,3,6,1,7,45,37,8,1,32,13,44,13,41,0,2,45,33,43]

theorem envBound54126 : H12AffineFastState.Bounded env54126 := by
  intro p hp
  have h : env54126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54125_54126 : H12AffineEnvironment.transform 11 0 env54125 = env54126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env54125 == env54126) = true)

theorem identity54126 : scanCanonicalize (H12AffineFastState.compose env54126 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound54126 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54127 : List Nat := [2,4,8,13,7,1,5,2,11,5,13,0,3,10,7,15,0,11,3,6,1,7,10,2,8,1,7,13,11,13,14,0,2,10,6,12]

theorem envBound54127 : H12AffineFastState.Bounded env54127 := by
  intro p hp
  have h : env54127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54126_54127 : H12AffineEnvironment.transform 4 7 env54126 = env54127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env54126 == env54127) = true)

theorem identity54127 : scanCanonicalize (H12AffineFastState.compose env54127 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound54127 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env54128 : List Nat := [2,4,5,0,7,1,5,2,6,5,0,0,3,7,7,2,0,6,3,6,1,7,7,2,5,1,7,0,6,0,3,0,2,7,6,1]

theorem envBound54128 : H12AffineFastState.Bounded env54128 := by
  intro p hp
  have h : env54128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54127_54128 : H12AffineEnvironment.transform 2 5 env54127 = env54128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env54127 == env54128) = true)

theorem identity54128 : scanCanonicalize (H12AffineFastState.compose env54128 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound54128 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54129 : List Nat := [2,2,3,0,1,1,3,2,0,3,0,0,3,1,1,2,0,0,3,0,1,1,1,2,3,1,1,0,0,0,3,0,2,1,0,1]

theorem envBound54129 : H12AffineFastState.Bounded env54129 := by
  intro p hp
  have h : env54129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54128_54129 : H12AffineEnvironment.transform 1 2 env54128 = env54129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env54128 == env54129) = true)

theorem identity54129 : scanCanonicalize (H12AffineFastState.compose env54129 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound54129 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54130 : List Nat := [0,0,1,0,1,1,1,0,0,1,0,0,1,1,1,0,0,0,1,0,1,1,1,0,1,1,1,0,0,0,1,0,0,1,0,1]

theorem envBound54130 : H12AffineFastState.Bounded env54130 := by
  intro p hp
  have h : env54130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54129_54130 : H12AffineEnvironment.transform 0 0 env54129 = env54130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env54129 == env54130) = true)

def env54131 : List Nat := [2,4,8,16,32,1,128,256,276,1024,297,4096,5401,1296,261,5517,1210,5388,4353,260,4097,413,426,1437,144,5307,4415,1194,1297,5302,5396,1210,256,5392,1281,5140]

theorem envBound54131 : H12AffineFastState.Bounded env54131 := by
  intro p hp
  have h : env54131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54120_54131 : H12AffineEnvironment.transform 10 297 env54120 = env54131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 297 env54120 == env54131) = true)

theorem identity54131 : scanCanonicalize (H12AffineFastState.compose env54131 (packedSelected [0,2,3,4,5,9,10,11,12,13,15,16,17,21,23,27] rootPS)) = affineNative (2^(6+1) ^^^ 31) := by decide +kernel

theorem selectedBound54131 : packedSelected [0,2,3,4,5,9,10,11,12,13,15,16,17,21,23,27] rootPS < 2^1333 := by decide +kernel

def env54132 : List Nat := [2,4,8,16,32,1,31,256,276,1024,297,4096,5401,1296,261,5394,1061,5388,4353,260,4097,258,309,1282,15,5156,4415,1077,1297,5161,5396,1061,256,5392,1281,5140]

theorem envBound54132 : H12AffineFastState.Bounded env54132 := by
  intro p hp
  have h : env54132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54131_54132 : H12AffineEnvironment.transform 6 31 env54131 = env54132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 31 env54131 == env54132) = true)

theorem identity54132 : scanCanonicalize (H12AffineFastState.compose env54132 (packedSelected [0,2,4,10,13,17,18,19,20,21,24] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound54132 : packedSelected [0,2,4,10,13,17,18,19,20,21,24] rootPS < 2^1333 := by decide +kernel

def env54133 : List Nat := [2,4,8,16,32,1,31,53,33,1024,28,4096,5164,1061,48,5159,1061,5177,4148,49,4097,55,0,1079,15,5156,4106,1077,1060,5161,5153,1061,53,5157,1076,5140]

theorem envBound54133 : H12AffineFastState.Bounded env54133 := by
  intro p hp
  have h : env54133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54132_54133 : H12AffineEnvironment.transform 7 53 env54132 = env54133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env54132 == env54133) = true)

theorem identity54133 : scanCanonicalize (H12AffineFastState.compose env54133 (packedSelected [4,9,16] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound54133 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env54134 : List Nat := [2,4,8,16,1,1,31,20,0,1024,28,4096,5133,1028,17,5126,1028,5144,4117,16,4097,22,0,1046,15,5125,4106,1044,1029,5128,5120,1028,20,5124,1045,5140]

theorem envBound54134 : H12AffineFastState.Bounded env54134 := by
  intro p hp
  have h : env54134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54133_54134 : H12AffineEnvironment.transform 4 1 env54133 = env54134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env54133 == env54134) = true)

theorem identity54134 : scanCanonicalize (H12AffineFastState.compose env54134 (packedSelected [0,1,2,7,8,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound54134 : packedSelected [0,1,2,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env54135 : List Nat := [2,4,8,16,1,1,31,20,0,15,28,4096,4098,11,17,4105,11,4119,4117,16,4097,22,0,25,15,4106,4106,27,10,4103,4111,11,20,4107,26,4123]

theorem envBound54135 : H12AffineFastState.Bounded env54135 := by
  intro p hp
  have h : env54135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54134_54135 : H12AffineEnvironment.transform 9 15 env54134 = env54135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env54134 == env54135) = true)

theorem identity54135 : scanCanonicalize (H12AffineFastState.compose env54135 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 27) := by decide +kernel

theorem selectedBound54135 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env54136 : List Nat := [2,4,8,16,1,1,31,20,0,15,28,27,25,11,17,18,11,12,14,16,26,22,0,25,15,17,17,27,10,28,20,11,20,16,26,0]

theorem envBound54136 : H12AffineFastState.Bounded env54136 := by
  intro p hp
  have h : env54136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54135_54136 : H12AffineEnvironment.transform 11 27 env54135 = env54136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 27 env54135 == env54136) = true)

theorem identity54136 : scanCanonicalize (H12AffineFastState.compose env54136 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound54136 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env54137 : List Nat := [2,3,8,16,1,1,24,19,0,8,27,27,25,11,17,18,11,11,9,16,26,17,0,25,8,17,17,27,10,27,19,11,19,16,26,0]

theorem envBound54137 : H12AffineFastState.Bounded env54137 := by
  intro p hp
  have h : env54137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54136_54137 : H12AffineEnvironment.transform 1 3 env54136 = env54137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env54136 == env54137) = true)

theorem identity54137 : scanCanonicalize (H12AffineFastState.compose env54137 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound54137 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54138 : List Nat := [2,3,3,16,1,1,19,19,0,3,16,16,18,0,17,18,0,0,2,16,17,17,0,18,3,17,17,16,1,16,19,0,19,16,17,0]

theorem envBound54138 : H12AffineFastState.Bounded env54138 := by
  intro p hp
  have h : env54138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54137_54138 : H12AffineEnvironment.transform 2 3 env54137 = env54138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env54137 == env54138) = true)

theorem identity54138 : scanCanonicalize (H12AffineFastState.compose env54138 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound54138 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54139 : List Nat := [2,3,3,1,1,1,2,2,0,3,1,1,3,0,0,3,0,0,2,1,0,0,0,3,3,0,0,1,1,1,2,0,2,1,0,0]

theorem envBound54139 : H12AffineFastState.Bounded env54139 := by
  intro p hp
  have h : env54139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54138_54139 : H12AffineEnvironment.transform 3 1 env54138 = env54139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env54138 == env54139) = true)

def env54140 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74863,262144,4417,13341,4097,477,74047,69649,13769,78895,332223,74815,1297,81227,8204,74798,256,8200,1344,5952]

theorem envBound54140 : H12AffineFastState.Bounded env54140 := by
  intro p hp
  have h : env54140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53979_54140 : H12AffineEnvironment.transform 13 1297 env53979 = env54140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env53979 == env54140) = true)

def env54141 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74863,65664,4417,13341,4097,477,74047,69649,13769,78895,4415,74815,1297,81227,8204,74798,256,8200,1344,5952]

theorem envBound54141 : H12AffineFastState.Bounded env54141 := by
  intro p hp
  have h : env54141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54140_54141 : H12AffineEnvironment.transform 17 65664 env54140 = env54141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env54140 == env54141) = true)

theorem identity54141 : scanCanonicalize (H12AffineFastState.compose env54141 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound54141 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env54142 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1297,9293,65536,74863,65664,272,9292,80,477,74047,65600,9624,74878,366,74815,1297,77082,8204,74798,256,8200,1344,1809]

theorem envBound54142 : H12AffineFastState.Bounded env54142 := by
  intro p hp
  have h : env54142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54141_54142 : H12AffineEnvironment.transform 11 81 env54141 = env54142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env54141 == env54142) = true)

def env54143 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,81,8192,1297,9293,65536,74863,65664,272,9292,80,477,74047,65600,9624,74878,366,74815,1297,77082,8204,74798,256,8200,1344,1093]

theorem envBound54143 : H12AffineFastState.Bounded env54143 := by
  intro p hp
  have h : env54143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54142_54143 : H12AffineEnvironment.transform 8 340 env54142 = env54143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env54142 == env54143) = true)

def env54144 : List Nat := [2,4,8,16,32,0,128,256,276,1024,2048,17,8192,1297,9229,65536,74799,65664,272,9228,16,413,74047,65536,9624,74814,302,74815,1297,77082,8204,74798,256,8200,1280,1029]

theorem envBound54144 : H12AffineFastState.Bounded env54144 := by
  intro p hp
  have h : env54144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54143_54144 : H12AffineEnvironment.transform 5 0 env54143 = env54144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env54143 == env54144) = true)

theorem identity54144 : scanCanonicalize (H12AffineFastState.compose env54144 (packedSelected [1,8,28] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound54144 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env54145 : List Nat := [2,4,8,16,7,0,128,256,276,1024,2048,17,8192,1297,9229,65536,74760,65664,272,9228,16,413,74008,65536,9624,74777,265,74776,1297,77082,8204,74761,256,8200,1280,1029]

theorem envBound54145 : H12AffineFastState.Bounded env54145 := by
  intro p hp
  have h : env54145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54144_54145 : H12AffineEnvironment.transform 4 7 env54144 = env54145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env54144 == env54145) = true)

def env54146 : List Nat := [2,4,8,16,7,0,128,256,276,1024,2048,17,1288,1297,261,65536,65792,65664,272,260,16,413,66576,65536,144,65809,265,65808,1297,67602,1284,65793,256,1280,1280,1029]

theorem envBound54146 : H12AffineFastState.Bounded env54146 := by
  intro p hp
  have h : env54146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54145_54146 : H12AffineEnvironment.transform 12 1288 env54145 = env54146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1288 env54145 == env54146) = true)

theorem identity54146 : scanCanonicalize (H12AffineFastState.compose env54146 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 1285) := by decide +kernel

theorem selectedBound54146 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env54147 : List Nat := [2,4,8,16,7,0,128,256,276,1024,2048,17,1288,1297,261,1285,1029,1413,272,260,16,413,277,1285,144,1044,265,1045,1297,3351,1284,1028,256,1280,1280,1029]

theorem envBound54147 : H12AffineFastState.Bounded env54147 := by
  intro p hp
  have h : env54147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54146_54147 : H12AffineEnvironment.transform 15 1285 env54146 = env54147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1285 env54146 == env54147) = true)

theorem identity54147 : scanCanonicalize (H12AffineFastState.compose env54147 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound54147 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env54148 : List Nat := [2,4,8,1,7,0,128,256,261,1024,2048,0,1288,1280,261,1285,1029,1413,257,260,1,396,260,1285,129,1029,265,1028,1280,3334,1284,1028,256,1280,1280,1029]

theorem envBound54148 : H12AffineFastState.Bounded env54148 := by
  intro p hp
  have h : env54148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54147_54148 : H12AffineEnvironment.transform 3 1 env54147 = env54148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env54147 == env54148) = true)

theorem identity54148 : scanCanonicalize (H12AffineFastState.compose env54148 (packedSelected [1,2,3,5,13] rootPS)) = affineNative (2^(10+1) ^^^ 261) := by decide +kernel

theorem selectedBound54148 : packedSelected [1,2,3,5,13] rootPS < 2^1333 := by decide +kernel

def env54149 : List Nat := [2,4,8,1,7,0,128,256,261,1024,261,0,1288,1280,261,1285,1029,1413,257,260,1,396,260,1285,129,1029,265,1028,1280,1027,1284,1028,256,1280,1280,1029]

theorem envBound54149 : H12AffineFastState.Bounded env54149 := by
  intro p hp
  have h : env54149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54148_54149 : H12AffineEnvironment.transform 10 261 env54148 = env54149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env54148 == env54149) = true)

theorem identity54149 : scanCanonicalize (H12AffineFastState.compose env54149 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound54149 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env54150 : List Nat := [2,4,8,1,7,0,128,256,261,256,261,0,8,0,261,5,261,133,257,260,1,396,260,5,129,261,265,260,0,259,4,260,256,0,0,261]

theorem envBound54150 : H12AffineFastState.Bounded env54150 := by
  intro p hp
  have h : env54150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54149_54150 : H12AffineEnvironment.transform 9 256 env54149 = env54150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env54149 == env54150) = true)

theorem identity54150 : scanCanonicalize (H12AffineFastState.compose env54150 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound54150 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54151 : List Nat := [2,4,8,1,7,0,128,140,137,140,137,0,8,0,137,5,137,133,141,136,1,0,136,5,129,137,133,136,0,143,4,136,140,0,0,137]

theorem envBound54151 : H12AffineFastState.Bounded env54151 := by
  intro p hp
  have h : env54151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54150_54151 : H12AffineEnvironment.transform 7 140 env54150 = env54151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env54150 == env54151) = true)

theorem identity54151 : scanCanonicalize (H12AffineFastState.compose env54151 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound54151 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env54152 : List Nat := [2,4,5,1,7,0,128,129,132,129,132,0,5,0,132,5,132,133,128,133,1,0,133,5,129,132,133,133,0,130,4,133,129,0,0,132]

theorem envBound54152 : H12AffineFastState.Bounded env54152 := by
  intro p hp
  have h : env54152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54151_54152 : H12AffineEnvironment.transform 2 5 env54151 = env54152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env54151 == env54152) = true)

def env54153 : List Nat := [2,4,8,16,7,0,128,256,276,1024,2048,17,1289,1297,260,65536,65793,65664,272,261,16,413,66577,65536,145,65808,265,65809,1297,67603,1285,65792,256,1281,1280,1029]

theorem envBound54153 : H12AffineFastState.Bounded env54153 := by
  intro p hp
  have h : env54153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54145_54153 : H12AffineEnvironment.transform 12 1289 env54145 = env54153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1289 env54145 == env54153) = true)

theorem identity54153 : scanCanonicalize (H12AffineFastState.compose env54153 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 20) := by decide +kernel

theorem selectedBound54153 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env54154 : List Nat := [2,4,8,16,7,0,128,256,276,1024,2048,17,1289,1297,260,20,277,148,272,261,16,413,1029,20,145,260,265,261,1297,2055,1285,276,256,1281,1280,1029]

theorem envBound54154 : H12AffineFastState.Bounded env54154 := by
  intro p hp
  have h : env54154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54153_54154 : H12AffineEnvironment.transform 15 20 env54153 = env54154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 20 env54153 == env54154) = true)

theorem identity54154 : scanCanonicalize (H12AffineFastState.compose env54154 (packedSelected [1,2,3,4,9,10,12,16,17] rootPS)) = affineNative (2^(10+1) ^^^ 277) := by decide +kernel

theorem selectedBound54154 : packedSelected [1,2,3,4,9,10,12,16,17] rootPS < 2^1333 := by decide +kernel

def env54155 : List Nat := [2,4,8,16,7,0,128,256,276,1024,277,17,1289,1297,260,20,277,148,272,261,16,413,1029,20,145,260,265,261,1297,274,1285,276,256,1281,1280,1029]

theorem envBound54155 : H12AffineFastState.Bounded env54155 := by
  intro p hp
  have h : env54155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54154_54155 : H12AffineEnvironment.transform 10 277 env54154 = env54155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 277 env54154 == env54155) = true)

theorem identity54155 : scanCanonicalize (H12AffineFastState.compose env54155 (packedSelected [0,3,4,7,9,11,16] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound54155 : packedSelected [0,3,4,7,9,11,16] rootPS < 2^1333 := by decide +kernel

def env54156 : List Nat := [2,4,4,16,7,0,128,256,276,1024,277,17,1285,1297,260,20,277,148,272,261,16,401,1029,20,145,260,261,261,1297,274,1285,276,256,1281,1280,1029]

theorem envBound54156 : H12AffineFastState.Bounded env54156 := by
  intro p hp
  have h : env54156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54155_54156 : H12AffineEnvironment.transform 2 4 env54155 = env54156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env54155 == env54156) = true)

theorem identity54156 : scanCanonicalize (H12AffineFastState.compose env54156 (packedSelected [0,3,5,7,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound54156 : packedSelected [0,3,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env54157 : List Nat := [2,4,4,16,7,0,128,256,276,4,277,17,257,277,260,20,277,148,272,261,16,401,1,20,145,260,261,261,277,274,257,276,256,261,260,1]

theorem envBound54157 : H12AffineFastState.Bounded env54157 := by
  intro p hp
  have h : env54157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54156_54157 : H12AffineEnvironment.transform 9 4 env54156 = env54157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env54156 == env54157) = true)

theorem identity54157 : scanCanonicalize (H12AffineFastState.compose env54157 (packedSelected [2,8] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound54157 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env54158 : List Nat := [2,3,3,16,0,0,128,256,275,3,274,17,257,274,259,19,274,147,272,258,16,401,1,19,145,259,258,258,274,274,257,275,256,258,259,1]

theorem envBound54158 : H12AffineFastState.Bounded env54158 := by
  intro p hp
  have h : env54158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54157_54158 : H12AffineEnvironment.transform 1 3 env54157 = env54158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env54157 == env54158) = true)

def env54159 : List Nat := [2,4,8,16,32,1,128,256,277,1024,2048,16,8192,1297,9228,65536,74798,65664,272,9229,17,412,74047,65537,9624,74815,303,74815,1297,77082,8204,74798,256,8200,1281,1028]

theorem envBound54159 : H12AffineFastState.Bounded env54159 := by
  intro p hp
  have h : env54159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54143_54159 : H12AffineEnvironment.transform 5 1 env54143 = env54159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env54143 == env54159) = true)

theorem identity54159 : scanCanonicalize (H12AffineFastState.compose env54159 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 1327) := by decide +kernel

theorem selectedBound54159 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env54160 : List Nat := [2,4,8,16,32,1,128,256,277,1024,2048,16,1327,1297,291,65536,65793,65664,272,290,17,412,66576,65537,183,65808,303,65808,1297,67637,1315,65793,256,1319,1281,1028]

theorem envBound54160 : H12AffineFastState.Bounded env54160 := by
  intro p hp
  have h : env54160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54159_54160 : H12AffineEnvironment.transform 12 1327 env54159 = env54160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1327 env54159 == env54160) = true)

def env54161 : List Nat := [2,4,8,16,12,1,128,256,277,1024,2048,16,1283,1297,271,65536,65793,65664,272,270,17,412,66576,65537,155,65808,259,65808,1297,67609,1295,65793,256,1291,1281,1028]

theorem envBound54161 : H12AffineFastState.Bounded env54161 := by
  intro p hp
  have h : env54161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54160_54161 : H12AffineEnvironment.transform 4 12 env54160 = env54161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env54160 == env54161) = true)

theorem identity54161 : scanCanonicalize (H12AffineFastState.compose env54161 (packedSelected [0,8,13,15,24,27] rootPS)) = affineNative (2^(15+1) ^^^ 3205) := by decide +kernel

theorem selectedBound54161 : packedSelected [0,8,13,15,24,27] rootPS < 2^1333 := by decide +kernel

def env54162 : List Nat := [2,4,8,16,12,1,128,256,277,1024,2048,16,1283,1297,271,3205,3460,3077,272,270,17,412,2197,3204,155,3477,259,3477,1297,1180,1295,3460,256,1291,1281,1028]

theorem envBound54162 : H12AffineFastState.Bounded env54162 := by
  intro p hp
  have h : env54162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54161_54162 : H12AffineEnvironment.transform 15 3205 env54161 = env54162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3205 env54161 == env54162) = true)

theorem identity54162 : scanCanonicalize (H12AffineFastState.compose env54162 (packedSelected [0,1,2,5,8,9,13,15,17,19,21,32] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound54162 : packedSelected [0,1,2,5,8,9,13,15,17,19,21,32] rootPS < 2^1333 := by decide +kernel

def env54163 : List Nat := [2,4,8,16,12,1,128,20,1,1024,2048,16,1047,1029,27,3205,3216,3077,4,26,17,136,2197,3204,155,3201,23,3201,1029,1180,1051,3216,20,1055,1045,1028]

theorem envBound54163 : H12AffineFastState.Bounded env54163 := by
  intro p hp
  have h : env54163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54162_54163 : H12AffineEnvironment.transform 7 20 env54162 = env54163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env54162 == env54163) = true)

theorem identity54163 : scanCanonicalize (H12AffineFastState.compose env54163 (packedSelected [1,2,3,4,7,12,13,15,17,18] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound54163 : packedSelected [1,2,3,4,7,12,13,15,17,18] rootPS < 2^1333 := by decide +kernel

def env54164 : List Nat := [2,4,8,16,12,1,128,20,1,14,2048,16,25,11,27,2187,2206,2059,4,26,17,136,2197,2186,155,2191,23,2191,11,146,21,2206,20,17,27,10]

theorem envBound54164 : H12AffineFastState.Bounded env54164 := by
  intro p hp
  have h : env54164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54163_54164 : H12AffineEnvironment.transform 9 14 env54163 = env54164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env54163 == env54164) = true)

theorem identity54164 : scanCanonicalize (H12AffineFastState.compose env54164 (packedSelected [1,2,4,5,7,8,12] rootPS)) = affineNative (2^(10+1) ^^^ 6) := by decide +kernel

theorem selectedBound54164 : packedSelected [1,2,4,5,7,8,12] rootPS < 2^1333 := by decide +kernel

def env54165 : List Nat := [2,4,8,16,12,1,128,20,1,14,6,16,25,11,27,141,152,13,4,26,17,136,147,140,155,137,23,137,11,146,21,152,20,17,27,10]

theorem envBound54165 : H12AffineFastState.Bounded env54165 := by
  intro p hp
  have h : env54165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54164_54165 : H12AffineEnvironment.transform 10 6 env54164 = env54165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 6 env54164 == env54165) = true)

theorem identity54165 : scanCanonicalize (H12AffineFastState.compose env54165 (packedSelected [1,5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound54165 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env54166 : List Nat := [2,4,8,16,12,1,9,20,1,14,6,16,25,11,27,4,17,13,4,26,17,1,26,5,18,0,23,0,11,27,21,17,20,17,27,10]

theorem envBound54166 : H12AffineFastState.Bounded env54166 := by
  intro p hp
  have h : env54166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54165_54166 : H12AffineEnvironment.transform 6 9 env54165 = env54166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env54165 == env54166) = true)

theorem identity54166 : scanCanonicalize (H12AffineFastState.compose env54166 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound54166 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env54167 : List Nat := [2,4,4,16,0,1,5,20,1,2,6,16,21,7,23,4,17,1,4,22,17,1,22,5,18,0,23,0,7,23,21,17,20,17,23,6]

theorem envBound54167 : H12AffineFastState.Bounded env54167 := by
  intro p hp
  have h : env54167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54166_54167 : H12AffineEnvironment.transform 2 4 env54166 = env54167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env54166 == env54167) = true)

theorem identity54167 : scanCanonicalize (H12AffineFastState.compose env54167 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound54167 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env54168 : List Nat := [2,4,4,7,0,1,5,3,1,2,6,7,2,7,0,4,6,1,4,1,6,1,1,5,5,0,0,0,7,0,2,6,3,6,0,6]

theorem envBound54168 : H12AffineFastState.Bounded env54168 := by
  intro p hp
  have h : env54168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54167_54168 : H12AffineEnvironment.transform 3 7 env54167 = env54168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env54167 == env54168) = true)

theorem identity54168 : scanCanonicalize (H12AffineFastState.compose env54168 (packedSelected [0,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound54168 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env54169 : List Nat := [2,3,3,0,0,1,2,3,1,2,1,0,2,0,0,3,1,1,3,1,1,1,1,2,2,0,0,0,0,0,2,1,3,1,0,1]

theorem envBound54169 : H12AffineFastState.Bounded env54169 := by
  intro p hp
  have h : env54169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54168_54169 : H12AffineEnvironment.transform 1 3 env54168 = env54169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env54168 == env54169) = true)

def env54170 : List Nat := [2,4,8,16,13,1,128,256,277,1024,2048,16,1282,1297,270,65536,65793,65664,272,271,17,412,66576,65537,154,65808,258,65808,1297,67608,1294,65793,256,1290,1281,1028]

theorem envBound54170 : H12AffineFastState.Bounded env54170 := by
  intro p hp
  have h : env54170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54160_54170 : H12AffineEnvironment.transform 4 13 env54160 = env54170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env54160 == env54170) = true)

theorem identity54170 : scanCanonicalize (H12AffineFastState.compose env54170 (packedSelected [0,8,13,15,24,27] rootPS)) = affineNative (2^(15+1) ^^^ 3214) := by decide +kernel

theorem selectedBound54170 : packedSelected [0,8,13,15,24,27] rootPS < 2^1333 := by decide +kernel

def env54171 : List Nat := [2,4,8,16,13,1,128,256,277,1024,2048,16,1282,1297,270,3214,3471,3086,272,271,17,412,2206,3215,154,3486,258,3486,1297,1174,1294,3471,256,1290,1281,1028]

theorem envBound54171 : H12AffineFastState.Bounded env54171 := by
  intro p hp
  have h : env54171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54170_54171 : H12AffineEnvironment.transform 15 3214 env54170 = env54171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3214 env54170 == env54171) = true)

theorem identity54171 : scanCanonicalize (H12AffineFastState.compose env54171 (packedSelected [1,2,5,8,10,12,13,16,20,24,32] rootPS)) = affineNative (2^(10+1) ^^^ 280) := by decide +kernel

theorem selectedBound54171 : packedSelected [1,2,5,8,10,12,13,16,20,24,32] rootPS < 2^1333 := by decide +kernel

def env54172 : List Nat := [2,4,8,16,13,1,128,256,277,1024,280,16,1282,1297,270,1430,1175,1302,272,271,17,412,390,1431,154,1158,258,1158,1297,1174,1294,1175,256,1290,1281,1028]

theorem envBound54172 : H12AffineFastState.Bounded env54172 := by
  intro p hp
  have h : env54172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54171_54172 : H12AffineEnvironment.transform 10 280 env54171 = env54172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 280 env54171 == env54172) = true)

theorem identity54172 : scanCanonicalize (H12AffineFastState.compose env54172 (packedSelected [0,1,4,7,9,12,17] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound54172 : packedSelected [0,1,4,7,9,12,17] rootPS < 2^1333 := by decide +kernel

def env54173 : List Nat := [2,4,8,1,13,1,128,256,260,1024,265,1,1282,1280,270,1415,1158,1287,257,271,0,397,390,1414,139,1158,258,1158,1280,1159,1294,1158,256,1290,1281,1028]

theorem envBound54173 : H12AffineFastState.Bounded env54173 := by
  intro p hp
  have h : env54173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54172_54173 : H12AffineEnvironment.transform 3 1 env54172 = env54173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env54172 == env54173) = true)

theorem identity54173 : scanCanonicalize (H12AffineFastState.compose env54173 (packedSelected [1,2,3,4,5,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound54173 : packedSelected [1,2,3,4,5,9,10] rootPS < 2^1333 := by decide +kernel

def env54174 : List Nat := [2,4,8,1,13,1,15,256,260,1024,265,1,1282,1280,270,1288,1033,1287,257,271,0,258,265,1289,4,1033,258,1033,1280,1032,1294,1033,256,1290,1281,1028]

theorem envBound54174 : H12AffineFastState.Bounded env54174 := by
  intro p hp
  have h : env54174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54173_54174 : H12AffineEnvironment.transform 6 15 env54173 = env54174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env54173 == env54174) = true)

theorem identity54174 : scanCanonicalize (H12AffineFastState.compose env54174 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 262) := by decide +kernel

theorem selectedBound54174 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env54175 : List Nat := [2,4,8,1,13,1,15,256,260,262,265,1,4,6,270,14,271,1,257,271,0,258,265,15,4,271,258,271,6,270,8,271,256,12,7,258]

theorem envBound54175 : H12AffineFastState.Bounded env54175 := by
  intro p hp
  have h : env54175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54174_54175 : H12AffineEnvironment.transform 9 262 env54174 = env54175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 262 env54174 == env54175) = true)

theorem identity54175 : scanCanonicalize (H12AffineFastState.compose env54175 (packedSelected [0,4,5] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound54175 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env54176 : List Nat := [2,4,4,1,1,1,3,256,260,262,261,1,4,6,258,2,259,1,257,259,0,258,261,3,4,259,258,259,6,258,4,259,256,0,7,258]

theorem envBound54176 : H12AffineFastState.Bounded env54176 := by
  intro p hp
  have h : env54176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54175_54176 : H12AffineEnvironment.transform 2 4 env54175 = env54176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env54175 == env54176) = true)

theorem identity54176 : scanCanonicalize (H12AffineFastState.compose env54176 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 2) := by decide +kernel

theorem selectedBound54176 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54177 : List Nat := [2,4,4,1,1,1,3,2,6,4,7,1,4,6,0,2,1,1,3,1,0,0,7,3,4,1,0,1,6,0,4,1,2,0,7,0]

theorem envBound54177 : H12AffineFastState.Bounded env54177 := by
  intro p hp
  have h : env54177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54176_54177 : H12AffineEnvironment.transform 7 2 env54176 = env54177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 2 env54176 == env54177) = true)

theorem identity54177 : scanCanonicalize (H12AffineFastState.compose env54177 (packedSelected [8] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound54177 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env54178 : List Nat := [2,3,3,1,1,1,3,2,1,3,0,1,3,1,0,2,1,1,3,1,0,0,0,3,3,1,0,1,1,0,3,1,2,0,0,0]

theorem envBound54178 : H12AffineFastState.Bounded env54178 := by
  intro p hp
  have h : env54178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54177_54178 : H12AffineEnvironment.transform 1 3 env54177 = env54178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env54177 == env54178) = true)

theorem identity54178 : scanCanonicalize (H12AffineFastState.compose env54178 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound54178 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54179 : List Nat := [0,1,1,1,1,1,1,0,1,1,0,1,1,1,0,0,1,1,1,1,0,0,0,1,1,1,0,1,1,0,1,1,0,0,0,0]

end H12CloudChart2