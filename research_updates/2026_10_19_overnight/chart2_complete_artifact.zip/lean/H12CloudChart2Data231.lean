import H12CloudChart2Data230

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity58315 : scanCanonicalize (H12AffineFastState.compose env58315 (packedSelected [4,9,20] rootPS)) = affineNative (2^(14+1) ^^^ 29860) := by decide +kernel

theorem selectedBound58315 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env58316 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,29860,9351,21692,23692,16572,29861,4096,1061,5292,4146,25653,20497,6328,4096,4097,23692,17425,5141,172,17428,1212,18108]

theorem envBound58316 : H12AffineFastState.Bounded env58316 := by
  intro p hp
  have h : env58316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58315_58316 : H12AffineEnvironment.transform 14 29860 env58315 = env58316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29860 env58315 == env58316) = true)

theorem identity58316 : scanCanonicalize (H12AffineFastState.compose env58316 (packedSelected [0,2,3,4,5,6,11,16] rootPS)) = affineNative (2^(12+1) ^^^ 5661) := by decide +kernel

theorem selectedBound58316 : packedSelected [0,2,3,4,5,6,11,16] rootPS < 2^1333 := by decide +kernel

def env58317 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,5661,16384,17081,4762,21692,23692,16572,17080,4096,1061,5292,4146,21032,20497,6328,4096,4097,23692,17425,5141,172,17428,1212,18108]

theorem envBound58317 : H12AffineFastState.Bounded env58317 := by
  intro p hp
  have h : env58317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58316_58317 : H12AffineEnvironment.transform 12 5661 env58316 = env58317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5661 env58316 == env58317) = true)

theorem identity58317 : scanCanonicalize (H12AffineFastState.compose env58317 (packedSelected [1,3,6,7,9,11,15,17] rootPS)) = affineNative (2^(11+1) ^^^ 2091) := by decide +kernel

theorem selectedBound58317 : packedSelected [1,3,6,7,9,11,15,17] rootPS < 2^1333 := by decide +kernel

def env58318 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,2091,3638,16384,17081,2737,19607,17575,16572,17080,2091,1061,3207,2073,18947,18490,147,2091,2090,17575,17425,3134,172,17428,1212,18108]

theorem envBound58318 : H12AffineFastState.Bounded env58318 := by
  intro p hp
  have h : env58318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58317_58318 : H12AffineEnvironment.transform 11 2091 env58317 = env58318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2091 env58317 == env58318) = true)

theorem identity58318 : scanCanonicalize (H12AffineFastState.compose env58318 (packedSelected [1,3,13] rootPS)) = affineNative (2^(13+1) ^^^ 3102) := by decide +kernel

theorem selectedBound58318 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env58319 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,2091,3638,3102,3751,2737,137,2233,3234,3750,2091,1061,3207,2073,1565,1060,147,2091,2090,2233,2063,3134,172,2058,1212,2722]

theorem envBound58319 : H12AffineFastState.Bounded env58319 := by
  intro p hp
  have h : env58319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58318_58319 : H12AffineEnvironment.transform 13 3102 env58318 = env58319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3102 env58318 == env58319) = true)

theorem identity58319 : scanCanonicalize (H12AffineFastState.compose env58319 (packedSelected [0,4,5,7,8,9,10,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound58319 : packedSelected [0,4,5,7,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env58320 : List Nat := [2,4,8,16,10,16,128,135,512,1024,2048,2049,3612,3102,3725,2715,137,2195,3208,3724,2049,1039,3207,2073,1565,1038,147,2049,2048,2195,2063,3092,134,2058,1174,2696]

theorem envBound58320 : H12AffineFastState.Bounded env58320 := by
  intro p hp
  have h : env58320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58319_58320 : H12AffineEnvironment.transform 4 10 env58319 = env58320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env58319 == env58320) = true)

theorem identity58320 : scanCanonicalize (H12AffineFastState.compose env58320 (packedSelected [1,4,6,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound58320 : packedSelected [1,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env58321 : List Nat := [2,4,8,16,10,16,128,135,512,1024,0,1,1564,1054,1677,667,137,147,1160,1676,1,1039,1159,25,1565,1038,147,1,0,147,15,1044,134,10,1174,648]

theorem envBound58321 : H12AffineFastState.Bounded env58321 := by
  intro p hp
  have h : env58321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58320_58321 : H12AffineEnvironment.transform 10 0 env58320 = env58321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env58320 == env58321) = true)

theorem identity58321 : scanCanonicalize (H12AffineFastState.compose env58321 (packedSelected [2,3,5] rootPS)) = affineNative (2^(9+1) ^^^ 543) := by decide +kernel

theorem selectedBound58321 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env58322 : List Nat := [2,4,8,16,10,16,128,135,512,543,0,1,3,513,146,667,137,147,663,147,1,528,664,25,2,529,147,1,0,147,15,523,134,10,649,648]

theorem envBound58322 : H12AffineFastState.Bounded env58322 := by
  intro p hp
  have h : env58322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58321_58322 : H12AffineEnvironment.transform 9 543 env58321 = env58322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 543 env58321 == env58322) = true)

theorem identity58322 : scanCanonicalize (H12AffineFastState.compose env58322 (packedSelected [1,3,4,6,7] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound58322 : packedSelected [1,3,4,6,7] rootPS < 2^1333 := by decide +kernel

def env58323 : List Nat := [2,4,8,16,10,16,128,135,137,150,0,1,3,136,146,18,137,147,30,147,1,153,17,25,2,152,147,1,0,147,15,130,134,10,0,1]

theorem envBound58323 : H12AffineFastState.Bounded env58323 := by
  intro p hp
  have h : env58323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58322_58323 : H12AffineEnvironment.transform 8 137 env58322 = env58323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env58322 == env58323) = true)

theorem identity58323 : scanCanonicalize (H12AffineFastState.compose env58323 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound58323 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58324 : List Nat := [2,4,8,16,10,16,18,21,27,4,0,1,3,26,0,18,27,1,30,1,1,11,17,25,2,10,1,1,0,1,15,16,20,10,0,1]

theorem envBound58324 : H12AffineFastState.Bounded env58324 := by
  intro p hp
  have h : env58324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58323_58324 : H12AffineEnvironment.transform 6 18 env58323 = env58324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env58323 == env58324) = true)

theorem identity58324 : scanCanonicalize (H12AffineFastState.compose env58324 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound58324 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58325 : List Nat := [2,4,8,13,10,13,15,8,6,4,0,1,3,7,0,15,6,1,3,1,1,11,12,4,2,10,1,1,0,1,15,13,9,10,0,1]

theorem envBound58325 : H12AffineFastState.Bounded env58325 := by
  intro p hp
  have h : env58325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58324_58325 : H12AffineEnvironment.transform 3 13 env58324 = env58325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env58324 == env58325) = true)

theorem identity58325 : scanCanonicalize (H12AffineFastState.compose env58325 (packedSelected [6] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound58325 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58326 : List Nat := [2,3,8,10,10,10,8,8,1,3,0,1,3,0,0,8,1,1,3,1,1,11,11,3,2,10,1,1,0,1,8,10,9,10,0,1]

theorem envBound58326 : H12AffineFastState.Bounded env58326 := by
  intro p hp
  have h : env58326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58325_58326 : H12AffineEnvironment.transform 1 3 env58325 = env58326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env58325 == env58326) = true)

def env58327 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147473,58518,143497,20497,508074,148669,148668,96266,90262,222255,172,90259,1213,135680]

theorem envBound58327 : H12AffineFastState.Bounded env58327 := by
  intro p hp
  have h : env58327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58311_58327 : H12AffineEnvironment.transform 5 17 env58311 = env58327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env58311 == env58327) = true)

theorem identity58327 : scanCanonicalize (H12AffineFastState.compose env58327 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 99486) := by decide +kernel

theorem selectedBound58327 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env58328 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,99486,262144,102558,32769,4096,61568,115855,58518,111639,20497,279604,114723,114722,96266,90262,57521,172,90259,1213,104094]

theorem envBound58328 : H12AffineFastState.Bounded env58328 := by
  intro p hp
  have h : env58328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58327_58328 : H12AffineEnvironment.transform 16 99486 env58327 = env58328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 99486 env58327 == env58328) = true)

theorem identity58328 : scanCanonicalize (H12AffineFastState.compose env58328 (packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(14+1) ^^^ 12313) := by decide +kernel

theorem selectedBound58328 : packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env58329 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,12313,65536,78983,262144,73863,12312,4096,16537,95382,21647,66574,20497,279604,94266,94267,96266,90262,20648,172,90259,1213,75399]

theorem envBound58329 : H12AffineFastState.Bounded env58329 := by
  intro p hp
  have h : env58329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58328_58329 : H12AffineEnvironment.transform 14 12313 env58328 = env58329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12313 env58328 == env58329) = true)

theorem identity58329 : scanCanonicalize (H12AffineFastState.compose env58329 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 9351) := by decide +kernel

theorem selectedBound58329 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env58330 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,12313,9351,4096,262144,1024,12312,4096,16537,20497,21647,8329,20497,279604,21693,21692,23693,17425,20648,172,17428,1213,512]

theorem envBound58330 : H12AffineFastState.Bounded env58330 := by
  intro p hp
  have h : env58330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58329_58330 : H12AffineEnvironment.transform 15 9351 env58329 = env58330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9351 env58329 == env58330) = true)

theorem identity58330 : scanCanonicalize (H12AffineFastState.compose env58330 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound58330 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env58331 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1212,12313,9351,4096,262144,1024,12312,4096,1061,5293,4147,8329,5293,262280,4097,4096,6193,173,5140,172,168,1213,512]

theorem envBound58331 : H12AffineFastState.Bounded env58331 := by
  intro p hp
  have h : env58331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58330_58331 : H12AffineEnvironment.transform 13 1212 env58330 = env58331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env58330 == env58331) = true)

theorem identity58331 : scanCanonicalize (H12AffineFastState.compose env58331 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 4649) := by decide +kernel

theorem selectedBound58331 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env58332 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,4649,1212,560,5806,4096,262144,1024,561,4096,1061,5293,4147,4768,5293,262280,4097,4096,6193,173,5140,172,168,1213,512]

theorem envBound58332 : H12AffineFastState.Bounded env58332 := by
  intro p hp
  have h : env58332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58331_58332 : H12AffineEnvironment.transform 12 4649 env58331 = env58332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4649 env58331 == env58332) = true)

theorem identity58332 : scanCanonicalize (H12AffineFastState.compose env58332 (packedSelected [1,3,13] rootPS)) = affineNative (2^(17+1) ^^^ 7221) := by decide +kernel

theorem selectedBound58332 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env58333 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,4649,1212,560,5806,4096,7221,1024,561,4096,1061,5293,4147,4768,5293,7357,4097,4096,6193,173,5140,172,168,1213,512]

theorem envBound58333 : H12AffineFastState.Bounded env58333 := by
  intro p hp
  have h : env58333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58332_58333 : H12AffineEnvironment.transform 17 7221 env58332 = env58333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7221 env58332 == env58333) = true)

theorem identity58333 : scanCanonicalize (H12AffineFastState.compose env58333 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 2587) := by decide +kernel

theorem selectedBound58333 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env58334 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,2587,2098,1212,560,3253,2587,1582,1024,561,2587,1061,3766,2600,2235,3766,1702,2586,2587,554,173,3599,172,168,1213,512]

theorem envBound58334 : H12AffineFastState.Bounded env58334 := by
  intro p hp
  have h : env58334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58333_58334 : H12AffineEnvironment.transform 11 2587 env58333 = env58334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2587 env58333 == env58334) = true)

theorem identity58334 : scanCanonicalize (H12AffineFastState.compose env58334 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 675) := by decide +kernel

theorem selectedBound58334 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env58335 : List Nat := [2,4,8,16,32,17,128,173,512,1024,675,184,657,1212,560,1558,184,1582,1024,561,184,1061,1045,139,536,1045,1702,185,184,554,173,1196,172,168,1213,512]

theorem envBound58335 : H12AffineFastState.Bounded env58335 := by
  intro p hp
  have h : env58335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58334_58335 : H12AffineEnvironment.transform 10 675 env58334 = env58335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 675 env58334 == env58335) = true)

theorem identity58335 : scanCanonicalize (H12AffineFastState.compose env58335 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 663) := by decide +kernel

theorem selectedBound58335 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58336 : List Nat := [2,4,8,16,32,17,128,173,512,663,675,184,657,555,560,129,184,185,663,561,184,690,642,139,536,642,49,185,184,554,173,571,172,168,554,512]

theorem envBound58336 : H12AffineFastState.Bounded env58336 := by
  intro p hp
  have h : env58336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58335_58336 : H12AffineEnvironment.transform 9 663 env58335 = env58336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 663 env58335 == env58336) = true)

theorem identity58336 : scanCanonicalize (H12AffineFastState.compose env58336 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound58336 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env58337 : List Nat := [2,4,8,16,32,17,9,36,512,542,554,49,536,555,560,8,49,48,542,561,49,571,523,2,536,523,49,48,49,554,36,571,37,33,554,512]

theorem envBound58337 : H12AffineFastState.Bounded env58337 := by
  intro p hp
  have h : env58337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58336_58337 : H12AffineEnvironment.transform 6 9 env58336 = env58337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env58336 == env58337) = true)

theorem identity58337 : scanCanonicalize (H12AffineFastState.compose env58337 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 29) := by decide +kernel

theorem selectedBound58337 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env58338 : List Nat := [2,4,8,16,32,17,9,36,29,3,55,49,5,54,45,8,49,48,3,44,49,38,22,2,5,22,49,48,49,55,36,38,37,33,55,29]

theorem envBound58338 : H12AffineFastState.Bounded env58338 := by
  intro p hp
  have h : env58338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58337_58338 : H12AffineEnvironment.transform 8 29 env58337 = env58338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 29 env58337 == env58338) = true)

theorem identity58338 : scanCanonicalize (H12AffineFastState.compose env58338 (packedSelected [6] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound58338 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58339 : List Nat := [2,3,8,16,32,17,9,35,26,3,48,49,2,49,42,8,49,48,3,43,49,33,17,2,2,17,49,48,49,48,35,33,34,33,48,26]

theorem envBound58339 : H12AffineFastState.Bounded env58339 := by
  intro p hp
  have h : env58339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58338_58339 : H12AffineEnvironment.transform 1 3 env58338 = env58339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env58338 == env58339) = true)

theorem identity58339 : scanCanonicalize (H12AffineFastState.compose env58339 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound58339 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58340 : List Nat := [2,3,8,16,10,17,9,9,26,3,26,27,2,27,0,8,27,26,3,1,27,11,17,2,2,17,27,26,27,26,9,11,8,11,26,26]

theorem envBound58340 : H12AffineFastState.Bounded env58340 := by
  intro p hp
  have h : env58340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58339_58340 : H12AffineEnvironment.transform 4 10 env58339 = env58340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env58339 == env58340) = true)

theorem identity58340 : scanCanonicalize (H12AffineFastState.compose env58340 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound58340 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58341 : List Nat := [2,3,8,10,10,11,9,9,0,3,0,1,2,1,0,8,1,0,3,1,1,11,11,2,2,11,1,0,1,0,9,11,8,11,0,0]

theorem envBound58341 : H12AffineFastState.Bounded env58341 := by
  intro p hp
  have h : env58341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58340_58341 : H12AffineEnvironment.transform 3 10 env58340 = env58341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env58340 == env58341) = true)

def env58342 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147520,58682,143496,20496,508154,148801,148801,96347,90426,222335,257,90431,1345,135681]

theorem envBound58342 : H12AffineFastState.Bounded env58342 := by
  intro p hp
  have h : env58342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58277_58342 : H12AffineEnvironment.transform 18 136193 env58277 = env58342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env58277 == env58342) = true)

def env58343 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147520,58518,143496,20496,508154,148717,148717,96347,90262,222335,173,90259,1261,135681]

theorem envBound58343 : H12AffineFastState.Bounded env58343 := by
  intro p hp
  have h : env58343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58342_58343 : H12AffineEnvironment.transform 7 172 env58342 = env58343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env58342 == env58343) = true)

def env58344 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147472,58518,143496,20496,508074,148669,148669,96267,90262,222255,173,90259,1213,135681]

theorem envBound58344 : H12AffineFastState.Bounded env58344 := by
  intro p hp
  have h : env58344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58343_58344 : H12AffineEnvironment.transform 5 16 env58343 = env58344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env58343 == env58344) = true)

theorem identity58344 : scanCanonicalize (H12AffineFastState.compose env58344 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound58344 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env58345 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,45217,262144,42144,32769,4096,61569,61617,58518,32809,20496,356363,62492,62492,96267,90262,119950,173,90259,1213,41632]

theorem envBound58345 : H12AffineFastState.Bounded env58345 := by
  intro p hp
  have h : env58345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58344_58345 : H12AffineEnvironment.transform 16 45217 env58344 = env58345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env58344 == env58345) = true)

theorem identity58345 : scanCanonicalize (H12AffineFastState.compose env58345 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound58345 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env58346 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,45217,2185,42144,32769,4096,61569,61617,58518,32809,20496,96386,62492,62492,96267,90262,119950,173,90259,1213,41632]

theorem envBound58346 : H12AffineFastState.Bounded env58346 := by
  intro p hp
  have h : env58346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58345_58346 : H12AffineEnvironment.transform 17 2185 env58345 = env58346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env58345 == env58346) = true)

theorem identity58346 : scanCanonicalize (H12AffineFastState.compose env58346 (packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 24634) := by decide +kernel

theorem selectedBound58346 : packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env58347 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,24634,45217,2185,42144,32769,4096,61569,61617,58518,32809,20496,6328,62492,62492,6193,172,46260,173,169,1213,41632]

theorem envBound58347 : H12AffineFastState.Bounded env58347 := by
  intro p hp
  have h : env58347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58346_58347 : H12AffineEnvironment.transform 15 24634 env58346 = env58347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24634 env58346 == env58347) = true)

theorem identity58347 : scanCanonicalize (H12AffineFastState.compose env58347 (packedSelected [1,4,5,8,9,16,17,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound58347 : packedSelected [1,4,5,8,9,16,17,21,24] rootPS < 2^1333 := by decide +kernel

def env58348 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,5124,32768,13374,45217,2185,42144,32769,4096,42117,42165,45202,32809,1044,6328,40984,40984,6193,172,46260,173,169,1213,41632]

theorem envBound58348 : H12AffineFastState.Bounded env58348 := by
  intro p hp
  have h : env58348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58347_58348 : H12AffineEnvironment.transform 13 5124 env58347 = env58348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env58347 == env58348) = true)

theorem identity58348 : scanCanonicalize (H12AffineFastState.compose env58348 (packedSelected [2,3,5,6,10,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 3612) := by decide +kernel

theorem selectedBound58348 : packedSelected [2,3,5,6,10,15,17] rootPS < 2^1333 := by decide +kernel

def env58349 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,3612,5124,32768,6690,40637,2185,35516,32769,4096,35481,35497,40590,32809,1044,6328,36356,36356,6193,172,39592,173,169,1213,36028]

theorem envBound58349 : H12AffineFastState.Bounded env58349 := by
  intro p hp
  have h : env58349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58348_58349 : H12AffineEnvironment.transform 12 3612 env58348 = env58349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3612 env58348 == env58349) = true)

theorem identity58349 : scanCanonicalize (H12AffineFastState.compose env58349 (packedSelected [3,4,5,6,7,12,15,16] rootPS)) = affineNative (2^(11+1) ^^^ 2745) := by decide +kernel

theorem selectedBound58349 : packedSelected [3,4,5,6,7,12,15,16] rootPS < 2^1333 := by decide +kernel

def env58350 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,2745,3612,3773,32768,155,33796,2185,35516,32769,2745,35481,35497,33847,32809,1044,513,36356,36356,648,172,32785,173,169,1213,36028]

theorem envBound58350 : H12AffineFastState.Bounded env58350 := by
  intro p hp
  have h : env58350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58349_58350 : H12AffineEnvironment.transform 11 2745 env58349 = env58350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2745 env58349 == env58350) = true)

theorem identity58350 : scanCanonicalize (H12AffineFastState.compose env58350 (packedSelected [0,2,3,4,7,8,9,10,11,12] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound58350 : packedSelected [0,2,3,4,7,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env58351 : List Nat := [2,4,8,16,32,16,128,172,42,1024,2048,2195,3126,3223,32768,155,33796,2185,34966,32769,2195,34995,34947,33847,32809,1044,43,35886,35886,162,172,32785,173,169,1213,36028]

theorem envBound58351 : H12AffineFastState.Bounded env58351 := by
  intro p hp
  have h : env58351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58350_58351 : H12AffineEnvironment.transform 8 42 env58350 = env58351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env58350 == env58351) = true)

theorem identity58351 : scanCanonicalize (H12AffineFastState.compose env58351 (packedSelected [7,9,10,11] rootPS)) = affineNative (2^(14+1) ^^^ 1071) := by decide +kernel

theorem selectedBound58351 : packedSelected [7,9,10,11] rootPS < 2^1333 := by decide +kernel

def env58352 : List Nat := [2,4,8,16,32,16,128,172,42,1024,2048,2195,3126,3223,1071,155,43,2185,3257,1070,2195,3228,3244,24,1030,1044,43,2049,2049,162,172,1086,173,169,1213,2195]

theorem envBound58352 : H12AffineFastState.Bounded env58352 := by
  intro p hp
  have h : env58352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58351_58352 : H12AffineEnvironment.transform 14 1071 env58351 = env58352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1071 env58351 == env58352) = true)

theorem identity58352 : scanCanonicalize (H12AffineFastState.compose env58352 (packedSelected [1,4,5,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 185) := by decide +kernel

theorem selectedBound58352 : packedSelected [1,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env58353 : List Nat := [2,4,8,16,32,16,128,172,42,1024,185,42,1167,1070,1071,155,43,48,1024,1070,42,1061,1045,24,1030,1044,43,184,184,162,172,1086,173,169,1213,42]

theorem envBound58353 : H12AffineFastState.Bounded env58353 := by
  intro p hp
  have h : env58353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58352_58353 : H12AffineEnvironment.transform 10 185 env58352 = env58353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 185 env58352 == env58353) = true)

theorem identity58353 : scanCanonicalize (H12AffineFastState.compose env58353 (packedSelected [1,2,5] rootPS)) = affineNative (2^(9+1) ^^^ 30) := by decide +kernel

theorem selectedBound58353 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env58354 : List Nat := [2,4,8,16,32,16,128,172,42,30,185,42,145,48,49,155,43,48,30,48,42,59,11,24,24,10,43,184,184,162,172,32,173,169,163,42]

theorem envBound58354 : H12AffineFastState.Bounded env58354 := by
  intro p hp
  have h : env58354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58353_58354 : H12AffineEnvironment.transform 9 30 env58353 = env58354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 30 env58353 == env58354) = true)

theorem identity58354 : scanCanonicalize (H12AffineFastState.compose env58354 (packedSelected [0,2,4] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound58354 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env58355 : List Nat := [2,4,8,16,32,16,8,36,42,30,49,42,25,48,49,19,43,48,30,48,42,59,11,24,24,10,43,48,48,42,36,32,37,33,43,42]

theorem envBound58355 : H12AffineFastState.Bounded env58355 := by
  intro p hp
  have h : env58355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58354_58355 : H12AffineEnvironment.transform 6 8 env58354 = env58355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env58354 == env58355) = true)

theorem identity58355 : scanCanonicalize (H12AffineFastState.compose env58355 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound58355 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env58356 : List Nat := [2,4,8,10,32,10,8,36,42,4,43,42,3,42,43,9,43,42,4,42,42,33,11,2,2,10,43,42,42,42,36,32,37,33,43,42]

theorem envBound58356 : H12AffineFastState.Bounded env58356 := by
  intro p hp
  have h : env58356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58355_58356 : H12AffineEnvironment.transform 3 10 env58355 = env58356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env58355 == env58356) = true)

theorem identity58356 : scanCanonicalize (H12AffineFastState.compose env58356 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound58356 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58357 : List Nat := [2,4,4,6,32,6,4,36,38,4,39,38,3,38,39,5,39,38,4,38,38,33,7,2,2,6,39,38,38,38,36,32,37,33,39,38]

theorem envBound58357 : H12AffineFastState.Bounded env58357 := by
  intro p hp
  have h : env58357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58356_58357 : H12AffineEnvironment.transform 2 4 env58356 = env58357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env58356 == env58357) = true)

def env58358 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147473,58518,143496,20496,508075,148668,148668,96266,90262,222254,173,90259,1212,135681]

theorem envBound58358 : H12AffineFastState.Bounded env58358 := by
  intro p hp
  have h : env58358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58343_58358 : H12AffineEnvironment.transform 5 17 env58343 = env58358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env58343 == env58358) = true)

theorem identity58358 : scanCanonicalize (H12AffineFastState.compose env58358 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 137353) := by decide +kernel

theorem selectedBound58358 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env58359 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137353,136193,32769,4096,61568,147473,58518,143496,20496,120866,148668,148668,96266,90262,222254,173,90259,1212,135681]

theorem envBound58359 : H12AffineFastState.Bounded env58359 := by
  intro p hp
  have h : env58359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58358_58359 : H12AffineEnvironment.transform 17 137353 env58358 = env58359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137353 env58358 == env58359) = true)

theorem identity58359 : scanCanonicalize (H12AffineFastState.compose env58359 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(16+1) ^^^ 62492) := by decide +kernel

theorem selectedBound58359 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env58360 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,62492,60565,57373,32769,4096,61568,46093,58518,50324,20496,120866,45216,45216,96266,90262,102450,173,90259,1212,58909]

theorem envBound58360 : H12AffineFastState.Bounded env58360 := by
  intro p hp
  have h : env58360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58359_58360 : H12AffineEnvironment.transform 16 62492 env58359 = env58360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 62492 env58359 == env58360) = true)

theorem identity58360 : scanCanonicalize (H12AffineFastState.compose env58360 (packedSelected [4,9,16] rootPS)) = affineNative (2^(14+1) ^^^ 29861) := by decide +kernel

theorem selectedBound58360 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env58361 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,29861,65536,185,6192,5304,29860,4096,1061,16552,4147,12337,20496,76935,17413,17413,96266,90262,91287,173,90259,1212,4792]

theorem envBound58361 : H12AffineFastState.Bounded env58361 := by
  intro p hp
  have h : env58361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58360_58361 : H12AffineEnvironment.transform 14 29861 env58360 = env58361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29861 env58360 == env58361) = true)

theorem identity58361 : scanCanonicalize (H12AffineFastState.compose env58361 (packedSelected [0,2,3,5,6,7,10,13,20] rootPS)) = affineNative (2^(13+1) ^^^ 10896) := by decide +kernel

theorem selectedBound58361 : packedSelected [0,2,3,5,6,7,10,13,20] rootPS < 2^1333 := by decide +kernel

def env58362 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,10896,7733,65536,185,6192,5304,7732,4096,1061,10808,4147,12337,14976,76935,11925,11925,70298,68102,69127,173,68099,1212,4792]

theorem envBound58362 : H12AffineFastState.Bounded env58362 := by
  intro p hp
  have h : env58362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58361_58362 : H12AffineEnvironment.transform 13 10896 env58361 = env58362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10896 env58361 == env58362) = true)

theorem identity58362 : scanCanonicalize (H12AffineFastState.compose env58362 (packedSelected [17,18,19,21,23,26] rootPS)) = affineNative (2^(15+1) ^^^ 9350) := by decide +kernel

theorem selectedBound58362 : packedSelected [17,18,19,21,23,26] rootPS < 2^1333 := by decide +kernel

def env58363 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,10896,7733,9350,185,6192,5304,7732,4096,1061,10808,4147,12337,14976,2049,11925,11925,13852,11904,10881,173,11909,1212,4792]

theorem envBound58363 : H12AffineFastState.Bounded env58363 := by
  intro p hp
  have h : env58363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58362_58363 : H12AffineEnvironment.transform 15 9350 env58362 = env58363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9350 env58362 == env58363) = true)

theorem identity58363 : scanCanonicalize (H12AffineFastState.compose env58363 (packedSelected [1,2,4,6,7,8,10,11,17] rootPS)) = affineNative (2^(11+1) ^^^ 561) := by decide +kernel

theorem selectedBound58363 : packedSelected [1,2,4,6,7,8,10,11,17] rootPS < 2^1333 := by decide +kernel

def env58364 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,561,8192,10896,3076,9350,185,2561,1673,3077,561,1061,10808,514,8704,10417,2049,11925,11925,9261,11904,10881,173,11909,1212,137]

theorem envBound58364 : H12AffineFastState.Bounded env58364 := by
  intro p hp
  have h : env58364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58363_58364 : H12AffineEnvironment.transform 11 561 env58363 = env58364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 561 env58363 == env58364) = true)

theorem identity58364 : scanCanonicalize (H12AffineFastState.compose env58364 (packedSelected [2,4,5,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 1679) := by decide +kernel

theorem selectedBound58364 : packedSelected [2,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env58365 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,561,1679,3103,3076,521,185,2561,1673,3077,561,1061,3255,514,1167,3646,2049,2074,2074,674,2063,3086,173,2058,1212,137]

theorem envBound58365 : H12AffineFastState.Bounded env58365 := by
  intro p hp
  have h : env58365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58364_58365 : H12AffineEnvironment.transform 12 1679 env58364 = env58365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1679 env58364 == env58365) = true)

theorem identity58365 : scanCanonicalize (H12AffineFastState.compose env58365 (packedSelected [0,1,2,5,6,7,10] rootPS)) = affineNative (2^(9+1) ^^^ 30) := by decide +kernel

theorem selectedBound58365 : packedSelected [0,1,2,5,6,7,10] rootPS < 2^1333 := by decide +kernel

def env58366 : List Nat := [2,4,8,16,32,17,128,172,512,30,2048,561,657,2049,2074,521,185,2561,663,2075,561,59,2217,514,145,2592,2049,2074,2074,674,2063,2064,173,2058,162,137]

theorem envBound58366 : H12AffineFastState.Bounded env58366 := by
  intro p hp
  have h : env58366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58365_58366 : H12AffineEnvironment.transform 9 30 env58365 = env58366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 30 env58365 == env58366) = true)

theorem identity58366 : scanCanonicalize (H12AffineFastState.compose env58366 (packedSelected [2,3,5,6,7,9,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 162) := by decide +kernel

theorem selectedBound58366 : packedSelected [2,3,5,6,7,9,11,12] rootPS < 2^1333 := by decide +kernel

def env58367 : List Nat := [2,4,8,16,32,17,128,172,512,30,162,561,657,163,184,521,185,675,663,185,561,59,11,514,145,642,163,184,184,674,173,178,173,168,162,137]

theorem envBound58367 : H12AffineFastState.Bounded env58367 := by
  intro p hp
  have h : env58367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58366_58367 : H12AffineEnvironment.transform 10 162 env58366 = env58367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 162 env58366 == env58367) = true)

theorem identity58367 : scanCanonicalize (H12AffineFastState.compose env58367 (packedSelected [1,2,5,6] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound58367 : packedSelected [1,2,5,6] rootPS < 2^1333 := by decide +kernel

def env58368 : List Nat := [2,4,8,16,17,17,128,157,512,30,147,512,657,146,137,521,136,658,663,136,512,10,11,514,145,642,146,137,137,659,156,131,156,153,147,137]

theorem envBound58368 : H12AffineFastState.Bounded env58368 := by
  intro p hp
  have h : env58368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58367_58368 : H12AffineEnvironment.transform 4 17 env58367 = env58368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env58367 == env58368) = true)

theorem identity58368 : scanCanonicalize (H12AffineFastState.compose env58368 (packedSelected [1,2] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound58368 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env58369 : List Nat := [2,4,8,16,17,17,4,25,512,30,23,512,533,22,13,521,12,534,531,12,512,10,11,514,21,518,22,13,13,535,24,7,24,29,23,13]

theorem envBound58369 : H12AffineFastState.Bounded env58369 := by
  intro p hp
  have h : env58369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58368_58369 : H12AffineEnvironment.transform 6 4 env58368 = env58369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env58368 == env58369) = true)

theorem identity58369 : scanCanonicalize (H12AffineFastState.compose env58369 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 12) := by decide +kernel

theorem selectedBound58369 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env58370 : List Nat := [2,4,8,16,17,17,4,25,12,30,23,12,25,22,13,5,12,26,31,12,12,10,11,14,21,10,22,13,13,27,24,7,24,29,23,13]

theorem envBound58370 : H12AffineFastState.Bounded env58370 := by
  intro p hp
  have h : env58370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58369_58370 : H12AffineEnvironment.transform 8 12 env58369 = env58370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 12 env58369 == env58370) = true)

theorem identity58370 : scanCanonicalize (H12AffineFastState.compose env58370 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound58370 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58371 : List Nat := [2,4,8,7,6,6,4,14,12,9,0,12,14,1,13,5,12,13,8,12,12,10,11,14,2,10,1,13,13,12,15,7,15,10,0,13]

theorem envBound58371 : H12AffineFastState.Bounded env58371 := by
  intro p hp
  have h : env58371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58370_58371 : H12AffineEnvironment.transform 3 7 env58370 = env58371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env58370 == env58371) = true)

theorem identity58371 : scanCanonicalize (H12AffineFastState.compose env58371 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound58371 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58372 : List Nat := [2,4,0,7,6,6,4,6,4,1,0,4,6,1,5,5,4,5,0,4,4,2,3,6,2,2,1,5,5,4,7,7,7,2,0,5]

theorem envBound58372 : H12AffineFastState.Bounded env58372 := by
  intro p hp
  have h : env58372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58371_58372 : H12AffineEnvironment.transform 2 0 env58371 = env58372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env58371 == env58372) = true)

theorem identity58372 : scanCanonicalize (H12AffineFastState.compose env58372 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound58372 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env58373 : List Nat := [2,3,0,0,1,1,3,1,3,1,0,3,1,1,2,2,3,2,0,3,3,2,3,1,2,2,1,2,2,3,0,0,0,2,0,2]

theorem envBound58373 : H12AffineFastState.Bounded env58373 := by
  intro p hp
  have h : env58373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58372_58373 : H12AffineEnvironment.transform 1 3 env58372 = env58373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env58372 == env58373) = true)

theorem identity58373 : scanCanonicalize (H12AffineFastState.compose env58373 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound58373 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env58374 : List Nat := [0,1,0,0,1,1,1,1,1,1,0,1,1,1,0,0,1,0,0,1,1,0,1,1,0,0,1,0,0,1,0,0,0,0,0,0]

theorem envBound58374 : H12AffineFastState.Bounded env58374 := by
  intro p hp
  have h : env58374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58373_58374 : H12AffineEnvironment.transform 0 0 env58373 = env58374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env58373 == env58374) = true)

def env58375 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147520,58519,143496,20496,508154,148716,148716,96347,90263,222335,172,90258,1260,135681]

theorem envBound58375 : H12AffineFastState.Bounded env58375 := by
  intro p hp
  have h : env58375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58342_58375 : H12AffineEnvironment.transform 7 173 env58342 = env58375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env58342 == env58375) = true)

def env58376 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147472,58519,143496,20496,508074,148668,148668,96267,90263,222255,172,90258,1212,135681]

theorem envBound58376 : H12AffineFastState.Bounded env58376 := by
  intro p hp
  have h : env58376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58375_58376 : H12AffineEnvironment.transform 5 16 env58375 = env58376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env58375 == env58376) = true)

theorem identity58376 : scanCanonicalize (H12AffineFastState.compose env58376 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 99487) := by decide +kernel

theorem selectedBound58376 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env58377 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,99487,262144,102558,32769,4096,61569,115855,58519,111639,20496,279605,114723,114723,96267,90263,57520,172,90258,1212,104094]

theorem envBound58377 : H12AffineFastState.Bounded env58377 := by
  intro p hp
  have h : env58377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58376_58377 : H12AffineEnvironment.transform 16 99487 env58376 = env58377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 99487 env58376 == env58377) = true)

theorem identity58377 : scanCanonicalize (H12AffineFastState.compose env58377 (packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(14+1) ^^^ 12312) := by decide +kernel

theorem selectedBound58377 : packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env58378 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,12312,65536,78983,262144,73862,12313,4096,16537,95383,21647,66575,20496,279605,94267,94267,96267,90263,20648,172,90258,1212,75398]

theorem envBound58378 : H12AffineFastState.Bounded env58378 := by
  intro p hp
  have h : env58378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58377_58378 : H12AffineEnvironment.transform 14 12312 env58377 = env58378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12312 env58377 == env58378) = true)

theorem identity58378 : scanCanonicalize (H12AffineFastState.compose env58378 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 9350) := by decide +kernel

theorem selectedBound58378 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env58379 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,12312,9350,4097,262144,1024,12313,4096,16537,20497,21647,8329,20496,279605,21693,21693,23693,17425,20648,172,17428,1212,512]

theorem envBound58379 : H12AffineFastState.Bounded env58379 := by
  intro p hp
  have h : env58379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58378_58379 : H12AffineEnvironment.transform 15 9350 env58378 = env58379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9350 env58378 == env58379) = true)

theorem identity58379 : scanCanonicalize (H12AffineFastState.compose env58379 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound58379 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env58380 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1213,12312,9350,4097,262144,1024,12313,4096,1060,5292,4146,8329,5293,262280,4096,4096,6192,172,5141,172,169,1212,512]

theorem envBound58380 : H12AffineFastState.Bounded env58380 := by
  intro p hp
  have h : env58380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58379_58380 : H12AffineEnvironment.transform 13 1213 env58379 = env58380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env58379 == env58380) = true)

theorem identity58380 : scanCanonicalize (H12AffineFastState.compose env58380 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 656) := by decide +kernel

theorem selectedBound58380 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env58381 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,656,1213,4744,1558,4097,262144,1024,4745,4096,1060,5292,4146,537,5293,262280,4096,4096,6192,172,5141,172,169,1212,512]

theorem envBound58381 : H12AffineFastState.Bounded env58381 := by
  intro p hp
  have h : env58381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58380_58381 : H12AffineEnvironment.transform 12 656 env58380 = env58381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 656 env58380 == env58381) = true)

theorem identity58381 : scanCanonicalize (H12AffineFastState.compose env58381 (packedSelected [1,3,13] rootPS)) = affineNative (2^(17+1) ^^^ 3213) := by decide +kernel

theorem selectedBound58381 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env58382 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,656,1213,4744,1558,4097,3213,1024,4745,4096,1060,5292,4146,537,5293,3077,4096,4096,6192,172,5141,172,169,1212,512]

theorem envBound58382 : H12AffineFastState.Bounded env58382 := by
  intro p hp
  have h : env58382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58381_58382 : H12AffineEnvironment.transform 17 3213 env58381 = env58382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3213 env58381 == env58382) = true)

theorem identity58382 : scanCanonicalize (H12AffineFastState.compose env58382 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 674) := by decide +kernel

theorem selectedBound58382 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env58383 : List Nat := [2,4,8,16,32,16,128,173,512,1024,674,4096,656,1213,4744,1558,4097,1583,1024,4745,4096,1060,5292,4146,537,5293,1703,4096,4096,4754,172,5141,172,169,1212,512]

theorem envBound58383 : H12AffineFastState.Bounded env58383 := by
  intro p hp
  have h : env58383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58382_58383 : H12AffineEnvironment.transform 10 674 env58382 = env58383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 674 env58382 == env58383) = true)

theorem identity58383 : scanCanonicalize (H12AffineFastState.compose env58383 (packedSelected [1,3,17] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound58383 : packedSelected [1,3,17] rootPS < 2^1333 := by decide +kernel

def env58384 : List Nat := [2,4,8,16,32,16,128,173,512,5,674,4096,656,184,4744,531,4097,554,5,4745,4096,33,4265,4146,537,4264,674,4096,4096,4754,172,4112,172,169,185,512]

theorem envBound58384 : H12AffineFastState.Bounded env58384 := by
  intro p hp
  have h : env58384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58383_58384 : H12AffineEnvironment.transform 9 5 env58383 = env58384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env58383 == env58384) = true)

theorem identity58384 : scanCanonicalize (H12AffineFastState.compose env58384 (packedSelected [1,2,5] rootPS)) = affineNative (2^(11+1) ^^^ 696) := by decide +kernel

theorem selectedBound58384 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env58385 : List Nat := [2,4,8,16,32,16,128,173,512,5,674,696,656,184,48,531,697,554,5,49,696,33,529,650,537,528,674,696,696,42,172,680,172,169,185,512]

theorem envBound58385 : H12AffineFastState.Bounded env58385 := by
  intro p hp
  have h : env58385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58384_58385 : H12AffineEnvironment.transform 11 696 env58384 = env58385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 696 env58384 == env58385) = true)

theorem identity58385 : scanCanonicalize (H12AffineFastState.compose env58385 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound58385 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env58386 : List Nat := [2,4,8,10,32,10,128,173,512,5,674,674,650,162,42,521,675,554,5,43,674,33,523,650,515,522,674,674,674,42,172,680,172,169,163,512]

theorem envBound58386 : H12AffineFastState.Bounded env58386 := by
  intro p hp
  have h : env58386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58385_58386 : H12AffineEnvironment.transform 3 10 env58385 = env58386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env58385 == env58386) = true)

def env58387 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147473,58519,143496,20496,508075,148669,148669,96266,90263,222254,172,90258,1213,135681]

theorem envBound58387 : H12AffineFastState.Bounded env58387 := by
  intro p hp
  have h : env58387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58375_58387 : H12AffineEnvironment.transform 5 17 env58375 = env58387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env58375 == env58387) = true)

theorem identity58387 : scanCanonicalize (H12AffineFastState.compose env58387 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 208054) := by decide +kernel

theorem selectedBound58387 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env58388 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,208054,136193,32769,4096,61568,147473,58519,143496,20496,60445,148669,148669,96266,90263,222254,172,90258,1213,135681]

theorem envBound58388 : H12AffineFastState.Bounded env58388 := by
  intro p hp
  have h : env58388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58387_58388 : H12AffineEnvironment.transform 17 208054 env58387 = env58388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 208054 env58387 == env58388) = true)

theorem identity58388 : scanCanonicalize (H12AffineFastState.compose env58388 (packedSelected [1,3,5,7,8,10,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound58388 : packedSelected [1,3,5,7,8,10,20,26,27] rootPS < 2^1333 := by decide +kernel

def env58389 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,53282,131072,195732,136193,32769,4096,61568,147473,58519,143496,20496,60445,148669,148669,43048,45237,177164,172,45232,1213,135681]

theorem envBound58389 : H12AffineFastState.Bounded env58389 := by
  intro p hp
  have h : env58389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58388_58389 : H12AffineEnvironment.transform 15 53282 env58388 = env58389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env58388 == env58389) = true)

theorem identity58389 : scanCanonicalize (H12AffineFastState.compose env58389 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 21692) := by decide +kernel

theorem selectedBound58389 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env58390 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,53282,21692,43048,16573,32769,4096,61568,5293,58519,25652,20496,60445,4097,4097,43048,45237,57520,172,45232,1213,18109]

theorem envBound58390 : H12AffineFastState.Bounded env58390 := by
  intro p hp
  have h : env58390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58389_58390 : H12AffineEnvironment.transform 16 21692 env58389 = env58390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21692 env58389 == env58390) = true)

theorem identity58390 : scanCanonicalize (H12AffineFastState.compose env58390 (packedSelected [4,9,20] rootPS)) = affineNative (2^(14+1) ^^^ 29860) := by decide +kernel

theorem selectedBound58390 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env58391 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,29860,9350,21692,23692,16573,29861,4096,1060,5293,4147,25652,20496,6329,4097,4097,23692,17425,5140,172,17428,1213,18109]

theorem envBound58391 : H12AffineFastState.Bounded env58391 := by
  intro p hp
  have h : env58391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58390_58391 : H12AffineEnvironment.transform 14 29860 env58390 = env58391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29860 env58390 == env58391) = true)

theorem identity58391 : scanCanonicalize (H12AffineFastState.compose env58391 (packedSelected [0,2,3,4,5,6,11,16] rootPS)) = affineNative (2^(12+1) ^^^ 1701) := by decide +kernel

theorem selectedBound58391 : packedSelected [0,2,3,4,5,6,11,16] rootPS < 2^1333 := by decide +kernel

def env58392 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,1701,16384,20993,547,21692,23692,16573,20992,4096,1060,5293,4147,17041,20496,6329,4097,4097,23692,17425,5140,172,17428,1213,18109]

theorem envBound58392 : H12AffineFastState.Bounded env58392 := by
  intro p hp
  have h : env58392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58391_58392 : H12AffineEnvironment.transform 12 1701 env58391 = env58392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1701 env58391 == env58392) = true)

theorem identity58392 : scanCanonicalize (H12AffineFastState.compose env58392 (packedSelected [0,1,2,5,7,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 3119) := by decide +kernel

theorem selectedBound58392 : packedSelected [0,1,2,5,7,15,17] rootPS < 2^1333 := by decide +kernel

def env58393 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,1701,3119,7726,547,6291,4259,3218,7727,4096,1060,5293,4147,3774,7231,6329,4097,4097,4259,2110,5140,172,2107,1213,2706]

theorem envBound58393 : H12AffineFastState.Bounded env58393 := by
  intro p hp
  have h : env58393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58392_58393 : H12AffineEnvironment.transform 13 3119 env58392 = env58393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3119 env58392 == env58393) = true)

theorem identity58393 : scanCanonicalize (H12AffineFastState.compose env58393 (packedSelected [0,1,2,5,6,9,11,13] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound58393 : packedSelected [0,1,2,5,6,9,11,13] rootPS < 2^1333 := by decide +kernel

def env58394 : List Nat := [2,4,8,16,16,17,128,157,512,1024,2048,4096,1685,3103,7710,531,6291,4243,3218,7711,4096,1044,5277,4099,3726,7183,6281,4097,4097,4243,2062,5140,156,2059,1165,2706]

theorem envBound58394 : H12AffineFastState.Bounded env58394 := by
  intro p hp
  have h : env58394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58393_58394 : H12AffineEnvironment.transform 4 16 env58393 = env58394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env58393 == env58394) = true)

theorem identity58394 : scanCanonicalize (H12AffineFastState.compose env58394 (packedSelected [2,3,4,6,7,8,10,12] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound58394 : packedSelected [2,3,4,6,7,8,10,12] rootPS < 2^1333 := by decide +kernel

def env58395 : List Nat := [2,4,8,10,10,11,128,135,512,1024,2048,4096,1679,3077,7684,521,6281,4233,3208,7685,4096,1038,5255,4099,3726,7183,6281,4097,4097,4233,2062,5134,134,2059,1165,2696]

theorem envBound58395 : H12AffineFastState.Bounded env58395 := by
  intro p hp
  have h : env58395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58394_58395 : H12AffineEnvironment.transform 3 10 env58394 = env58395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env58394 == env58395) = true)

theorem identity58395 : scanCanonicalize (H12AffineFastState.compose env58395 (packedSelected [1,4,6,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound58395 : packedSelected [1,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env58396 : List Nat := [2,4,8,10,10,11,128,135,512,1024,0,4096,1679,1029,5636,521,4233,4233,1160,5637,4096,1038,5255,4099,1678,5135,4233,4097,4097,4233,14,5134,134,11,1165,648]

theorem envBound58396 : H12AffineFastState.Bounded env58396 := by
  intro p hp
  have h : env58396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58395_58396 : H12AffineEnvironment.transform 10 0 env58395 = env58396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env58395 == env58396) = true)

theorem identity58396 : scanCanonicalize (H12AffineFastState.compose env58396 (packedSelected [1,5,6,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound58396 : packedSelected [1,5,6,7,9] rootPS < 2^1333 := by decide +kernel

def env58397 : List Nat := [2,4,8,10,10,11,128,135,512,1024,0,1028,1679,1029,512,521,1165,1165,1160,513,1028,1038,131,1031,1678,11,1165,1029,1029,1165,14,10,134,11,1165,648]

theorem envBound58397 : H12AffineFastState.Bounded env58397 := by
  intro p hp
  have h : env58397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58396_58397 : H12AffineEnvironment.transform 11 1028 env58396 = env58397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env58396 == env58397) = true)

theorem identity58397 : scanCanonicalize (H12AffineFastState.compose env58397 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound58397 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env58398 : List Nat := [2,4,8,10,10,11,128,135,0,1024,0,1028,1167,1029,0,9,1165,1165,1160,1,1028,1038,131,1031,1166,11,1165,1029,1029,1165,14,10,134,11,1165,136]

theorem envBound58398 : H12AffineFastState.Bounded env58398 := by
  intro p hp
  have h : env58398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58397_58398 : H12AffineEnvironment.transform 8 0 env58397 = env58398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env58397 == env58398) = true)

theorem identity58398 : scanCanonicalize (H12AffineFastState.compose env58398 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound58398 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58399 : List Nat := [2,4,8,10,10,11,128,135,0,4,0,0,139,1,0,9,137,137,140,1,0,10,131,3,138,11,137,1,1,137,14,10,134,11,137,136]

theorem envBound58399 : H12AffineFastState.Bounded env58399 := by
  intro p hp
  have h : env58399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58398_58399 : H12AffineEnvironment.transform 9 4 env58398 = env58399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env58398 == env58399) = true)

theorem identity58399 : scanCanonicalize (H12AffineFastState.compose env58399 (packedSelected [0,1,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound58399 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env58400 : List Nat := [2,3,8,10,10,11,128,128,0,3,0,0,139,1,0,9,137,137,139,1,0,10,131,3,138,11,137,1,1,137,9,10,129,11,137,136]

theorem envBound58400 : H12AffineFastState.Bounded env58400 := by
  intro p hp
  have h : env58400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58399_58400 : H12AffineEnvironment.transform 1 3 env58399 = env58400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env58399 == env58400) = true)

theorem identity58400 : scanCanonicalize (H12AffineFastState.compose env58400 (packedSelected [1,5] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound58400 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env58401 : List Nat := [2,3,8,10,10,11,8,8,0,3,0,0,3,1,0,9,1,1,3,1,0,10,11,3,2,11,1,1,1,1,9,10,9,11,1,0]

theorem envBound58401 : H12AffineFastState.Bounded env58401 := by
  intro p hp
  have h : env58401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58400_58401 : H12AffineEnvironment.transform 6 8 env58400 = env58401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env58400 == env58401) = true)

def env58402 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,533641,672785,17245633,148801,545088,96347,16876544,618622,257,16876549,1344,525824]

theorem envBound58402 : H12AffineFastState.Bounded env58402 := by
  intro p hp
  have h : env58402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58275_58402 : H12AffineEnvironment.transform 26 17245633 env58275 = env58402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env58275 == env58402) = true)

theorem identity58402 : scanCanonicalize (H12AffineFastState.compose env58402 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 41003) := by decide +kernel

theorem selectedBound58402 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env58403 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,41003,533641,672785,493034,148801,545088,96347,74795,618622,257,74798,1344,525824]

theorem envBound58403 : H12AffineFastState.Bounded env58403 := by
  intro p hp
  have h : env58403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58402_58403 : H12AffineEnvironment.transform 23 41003 env58402 = env58403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41003 env58402 == env58403) = true)

def env58404 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147520,41003,143497,20497,493034,148801,148800,96347,74795,222334,257,74798,1344,135680]

theorem envBound58404 : H12AffineFastState.Bounded env58404 := by
  intro p hp
  have h : env58404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58403_58404 : H12AffineEnvironment.transform 18 136192 env58403 = env58404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env58403 == env58404) = true)

def env58405 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147520,41003,143497,20497,492614,148717,148716,96347,74795,222334,173,74798,1260,135680]

theorem envBound58405 : H12AffineFastState.Bounded env58405 := by
  intro p hp
  have h : env58405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58404_58405 : H12AffineEnvironment.transform 7 172 env58404 = env58405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env58404 == env58405) = true)

def env58406 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147472,41003,143497,20497,492566,148669,148668,96267,74795,222254,173,74798,1212,135680]

theorem envBound58406 : H12AffineFastState.Bounded env58406 := by
  intro p hp
  have h : env58406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58405_58406 : H12AffineEnvironment.transform 5 16 env58405 = env58406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env58405 == env58406) = true)

theorem identity58406 : scanCanonicalize (H12AffineFastState.compose env58406 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 137352) := by decide +kernel

theorem selectedBound58406 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env58407 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137352,136192,32769,4096,61569,147472,41003,143497,20497,105630,148669,148668,96267,74795,222254,173,74798,1212,135680]

theorem envBound58407 : H12AffineFastState.Bounded env58407 := by
  intro p hp
  have h : env58407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58406_58407 : H12AffineEnvironment.transform 17 137352 env58406 = env58407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137352 env58406 == env58407) = true)

theorem identity58407 : scanCanonicalize (H12AffineFastState.compose env58407 (packedSelected [1,5,8,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 13375) := by decide +kernel

theorem selectedBound58407 : packedSelected [1,5,8,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env58408 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,13375,131072,137352,136192,32769,4096,61569,147472,41003,143497,20497,43169,148669,148668,19508,4116,151569,173,4113,1212,135680]

theorem envBound58408 : H12AffineFastState.Bounded env58408 := by
  intro p hp
  have h : env58408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58407_58408 : H12AffineEnvironment.transform 15 13375 env58407 = env58408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13375 env58407 == env58408) = true)

theorem identity58408 : scanCanonicalize (H12AffineFastState.compose env58408 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound58408 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env58409 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1212,32768,13375,131072,137352,136192,32769,4096,46141,132268,41003,143497,5293,43169,131073,131072,2184,4116,136365,173,4113,1212,135680]

theorem envBound58409 : H12AffineFastState.Bounded env58409 := by
  intro p hp
  have h : env58409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58408_58409 : H12AffineEnvironment.transform 13 1212 env58408 = env58409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env58408 == env58409) = true)

theorem identity58409 : scanCanonicalize (H12AffineFastState.compose env58409 (packedSelected [13,17] rootPS)) = affineNative (2^(14+1) ^^^ 9381) := by decide +kernel

theorem selectedBound58409 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env58410 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1212,9381,13375,131072,137352,136192,9380,4096,4248,132268,1166,143497,5293,3076,131073,131072,2184,4116,136365,173,4113,1212,135680]

theorem envBound58410 : H12AffineFastState.Bounded env58410 := by
  intro p hp
  have h : env58410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58409_58410 : H12AffineEnvironment.transform 14 9381 env58409 = env58410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9381 env58409 == env58410) = true)

theorem identity58410 : scanCanonicalize (H12AffineFastState.compose env58410 (packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS)) = affineNative (2^(16+1) ^^^ 3102) := by decide +kernel

theorem selectedBound58410 : packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env58411 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1212,9381,13375,3102,5270,6174,9380,4096,4248,2226,1166,15511,5293,3076,3103,3102,2184,4116,6323,173,4113,1212,7710]

theorem envBound58411 : H12AffineFastState.Bounded env58411 := by
  intro p hp
  have h : env58411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58410_58411 : H12AffineEnvironment.transform 16 3102 env58410 = env58411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 3102 env58410 == env58411) = true)

theorem identity58411 : scanCanonicalize (H12AffineFastState.compose env58411 (packedSelected [1,4,5,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 6146) := by decide +kernel

theorem selectedBound58411 : packedSelected [1,4,5,9,16] rootPS < 2^1333 := by decide +kernel

def env58412 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,6146,1212,7335,3133,3102,5270,6174,7334,4096,4248,2226,1166,1173,5293,3076,3103,3102,2184,4116,6323,173,4113,1212,7710]

theorem envBound58412 : H12AffineFastState.Bounded env58412 := by
  intro p hp
  have h : env58412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58411_58412 : H12AffineEnvironment.transform 12 6146 env58411 = env58412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6146 env58411 == env58412) = true)

theorem identity58412 : scanCanonicalize (H12AffineFastState.compose env58412 (packedSelected [0,1,2,3,4,6,10,13] rootPS)) = affineNative (2^(11+1) ^^^ 49) := by decide +kernel

theorem selectedBound58412 : packedSelected [0,1,2,3,4,6,10,13] rootPS < 2^1333 := by decide +kernel

def env58413 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,49,2099,1212,3222,3133,3102,1191,2095,3223,49,169,2226,1166,1173,1180,3076,3103,3102,2184,37,2178,173,32,1212,3631]

theorem envBound58413 : H12AffineFastState.Bounded env58413 := by
  intro p hp
  have h : env58413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58412_58413 : H12AffineEnvironment.transform 11 49 env58412 = env58413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env58412 == env58413) = true)

theorem identity58413 : scanCanonicalize (H12AffineFastState.compose env58413 (packedSelected [0,1,2,4,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 141) := by decide +kernel

theorem selectedBound58413 : packedSelected [0,1,2,4,8,10] rootPS < 2^1333 := by decide +kernel

def env58414 : List Nat := [2,4,8,16,32,16,128,172,512,141,2048,49,2099,49,2075,2224,2195,42,2095,2074,49,169,2226,3,24,17,2185,2194,2195,2184,37,2178,173,32,49,2722]

theorem envBound58414 : H12AffineFastState.Bounded env58414 := by
  intro p hp
  have h : env58414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58413_58414 : H12AffineEnvironment.transform 9 141 env58413 = env58414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 141 env58413 == env58414) = true)

theorem identity58414 : scanCanonicalize (H12AffineFastState.compose env58414 (packedSelected [0,3,4,6] rootPS)) = affineNative (2^(8+1) ^^^ 143) := by decide +kernel

theorem selectedBound58414 : packedSelected [0,3,4,6] rootPS < 2^1333 := by decide +kernel

def env58415 : List Nat := [2,4,8,16,32,16,128,172,143,141,2048,49,2099,49,2075,2224,2195,42,2095,2074,49,169,2226,3,24,17,2185,2194,2195,2184,37,2178,173,32,49,2093]

theorem envBound58415 : H12AffineFastState.Bounded env58415 := by
  intro p hp
  have h : env58415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58414_58415 : H12AffineEnvironment.transform 8 143 env58414 = env58415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 143 env58414 == env58415) = true)

theorem identity58415 : scanCanonicalize (H12AffineFastState.compose env58415 (packedSelected [0,1,2,4,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 21) := by decide +kernel

theorem selectedBound58415 : packedSelected [0,1,2,4,5,8] rootPS < 2^1333 := by decide +kernel

def env58416 : List Nat := [2,4,8,16,32,16,21,57,26,24,2048,49,2099,49,2075,2085,2054,42,2095,2074,49,60,2087,3,24,17,2076,2055,2054,2077,37,2071,56,32,49,2093]

theorem envBound58416 : H12AffineFastState.Bounded env58416 := by
  intro p hp
  have h : env58416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58415_58416 : H12AffineEnvironment.transform 6 21 env58415 = env58416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 21 env58415 == env58416) = true)

def env58417 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147473,41003,143497,20497,492567,148668,148669,96266,74795,222255,173,74798,1213,135680]

theorem envBound58417 : H12AffineFastState.Bounded env58417 := by
  intro p hp
  have h : env58417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58405_58417 : H12AffineEnvironment.transform 5 17 env58405 = env58417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env58405 == env58417) = true)

theorem identity58417 : scanCanonicalize (H12AffineFastState.compose env58417 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound58417 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env58418 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,45216,262144,42144,32769,4096,61568,61617,41003,32809,20497,341175,62492,62493,96266,74795,119951,173,74798,1213,41632]

theorem envBound58418 : H12AffineFastState.Bounded env58418 := by
  intro p hp
  have h : env58418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58417_58418 : H12AffineEnvironment.transform 16 45216 env58417 = env58418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env58417 == env58418) = true)

theorem identity58418 : scanCanonicalize (H12AffineFastState.compose env58418 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound58418 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env58419 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1212,32768,65536,45216,262144,42144,32769,4096,46140,46093,41003,32809,5293,341175,45216,45217,81078,74795,102451,173,74798,1213,41632]

theorem envBound58419 : H12AffineFastState.Bounded env58419 := by
  intro p hp
  have h : env58419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58418_58419 : H12AffineEnvironment.transform 13 1212 env58418 = env58419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env58418 == env58419) = true)

theorem identity58419 : scanCanonicalize (H12AffineFastState.compose env58419 (packedSelected [4,9,16] rootPS)) = affineNative (2^(14+1) ^^^ 12312) := by decide +kernel

theorem selectedBound58419 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env58420 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1212,12312,65536,184,262144,5304,12313,4096,1060,1045,4147,12337,5293,341175,184,185,81078,74795,73771,173,74798,1213,4792]

theorem envBound58420 : H12AffineFastState.Bounded env58420 := by
  intro p hp
  have h : env58420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58419_58420 : H12AffineEnvironment.transform 14 12312 env58419 = env58420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12312 env58419 == env58420) = true)

theorem identity58420 : scanCanonicalize (H12AffineFastState.compose env58420 (packedSelected [4,9,20] rootPS)) = affineNative (2^(15+1) ^^^ 9351) := by decide +kernel

theorem selectedBound58420 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env58421 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1212,12312,9351,184,262144,5304,12313,4096,1060,1045,4147,12337,5293,266288,184,185,6193,172,1196,173,169,1213,4792]

theorem envBound58421 : H12AffineFastState.Bounded env58421 := by
  intro p hp
  have h : env58421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58420_58421 : H12AffineEnvironment.transform 15 9351 env58420 = env58421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9351 env58420 == env58421) = true)

theorem identity58421 : scanCanonicalize (H12AffineFastState.compose env58421 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound58421 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env58422 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1212,12312,9351,184,2185,5304,12313,4096,1060,1045,4147,12337,5293,6329,184,185,6193,172,1196,173,169,1213,4792]

theorem envBound58422 : H12AffineFastState.Bounded env58422 := by
  intro p hp
  have h : env58422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58421_58422 : H12AffineEnvironment.transform 17 2185 env58421 = env58422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env58421 == env58422) = true)

theorem identity58422 : scanCanonicalize (H12AffineFastState.compose env58422 (packedSelected [1,2,3,4,5,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound58422 : packedSelected [1,2,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env58423 : List Nat := [2,4,8,16,32,17,128,172,0,1024,2048,4096,8192,1212,12312,9351,184,2185,5304,12313,4096,1060,1045,4147,12337,5293,6329,184,185,6193,172,1196,173,169,1213,4280]

theorem envBound58423 : H12AffineFastState.Bounded env58423 := by
  intro p hp
  have h : env58423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58422_58423 : H12AffineEnvironment.transform 8 0 env58422 = env58423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env58422 == env58423) = true)

theorem identity58423 : scanCanonicalize (H12AffineFastState.compose env58423 (packedSelected [1,4,6,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound58423 : packedSelected [1,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env58424 : List Nat := [2,4,8,16,32,17,128,172,0,1024,49,4096,8192,1212,12312,9351,184,184,5304,12313,4096,1060,1045,4147,12337,5293,4232,184,185,4096,172,1196,173,169,1213,4280]

theorem envBound58424 : H12AffineFastState.Bounded env58424 := by
  intro p hp
  have h : env58424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58423_58424 : H12AffineEnvironment.transform 10 49 env58423 = env58424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env58423 == env58424) = true)

theorem identity58424 : scanCanonicalize (H12AffineFastState.compose env58424 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound58424 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58425 : List Nat := [2,4,8,16,32,17,128,172,0,1024,49,4096,24,1212,4096,1183,184,184,5304,4097,4096,1060,1045,4147,4137,5293,4232,184,185,4096,172,1196,173,169,1213,4280]

theorem envBound58425 : H12AffineFastState.Bounded env58425 := by
  intro p hp
  have h : env58425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58424_58425 : H12AffineEnvironment.transform 12 24 env58424 = env58425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env58424 == env58425) = true)

theorem identity58425 : scanCanonicalize (H12AffineFastState.compose env58425 (packedSelected [3,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 141) := by decide +kernel

theorem selectedBound58425 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env58426 : List Nat := [2,4,8,16,32,17,128,172,0,141,49,4096,24,49,4096,18,184,184,4149,4097,4096,169,152,4147,4137,4128,4232,184,185,4096,172,33,173,169,48,4280]

theorem envBound58426 : H12AffineFastState.Bounded env58426 := by
  intro p hp
  have h : env58426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58425_58426 : H12AffineEnvironment.transform 9 141 env58425 = env58426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 141 env58425 == env58426) = true)

theorem identity58426 : scanCanonicalize (H12AffineFastState.compose env58426 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 163) := by decide +kernel

theorem selectedBound58426 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env58427 : List Nat := [2,4,8,16,32,17,128,172,0,141,49,163,24,49,163,18,184,184,150,162,163,169,152,144,138,131,43,184,185,163,172,33,173,169,48,27]

theorem envBound58427 : H12AffineFastState.Bounded env58427 := by
  intro p hp
  have h : env58427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58426_58427 : H12AffineEnvironment.transform 11 163 env58426 = env58427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 163 env58426 == env58427) = true)

theorem identity58427 : scanCanonicalize (H12AffineFastState.compose env58427 (packedSelected [1,5] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound58427 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env58428 : List Nat := [2,4,8,16,32,17,19,63,0,30,49,48,24,49,48,18,43,43,5,49,48,58,11,3,25,16,43,43,42,48,63,33,62,58,48,27]

theorem envBound58428 : H12AffineFastState.Bounded env58428 := by
  intro p hp
  have h : env58428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58427_58428 : H12AffineEnvironment.transform 6 19 env58427 = env58428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env58427 == env58428) = true)

theorem identity58428 : scanCanonicalize (H12AffineFastState.compose env58428 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound58428 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58429 : List Nat := [2,4,5,16,32,17,19,50,0,19,49,48,21,49,48,18,38,38,5,49,48,55,6,3,20,16,38,38,39,48,50,33,51,55,48,22]

theorem envBound58429 : H12AffineFastState.Bounded env58429 := by
  intro p hp
  have h : env58429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58428_58429 : H12AffineEnvironment.transform 2 5 env58428 = env58429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env58428 == env58429) = true)

def env58430 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147520,41003,143497,20497,492615,148716,148717,96347,74795,222334,172,74798,1261,135680]

theorem envBound58430 : H12AffineFastState.Bounded env58430 := by
  intro p hp
  have h : env58430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58404_58430 : H12AffineEnvironment.transform 7 173 env58404 = env58430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env58404 == env58430) = true)

def env58431 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147472,41003,143497,20497,492567,148668,148669,96267,74795,222254,172,74798,1213,135680]

theorem envBound58431 : H12AffineFastState.Bounded env58431 := by
  intro p hp
  have h : env58431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58430_58431 : H12AffineEnvironment.transform 5 16 env58430 = env58431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env58430 == env58431) = true)

theorem identity58431 : scanCanonicalize (H12AffineFastState.compose env58431 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 223242) := by decide +kernel

theorem selectedBound58431 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env58432 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,223242,136192,32769,4096,61569,147472,41003,143497,20497,60445,148668,148669,96267,74795,222254,172,74798,1213,135680]

theorem envBound58432 : H12AffineFastState.Bounded env58432 := by
  intro p hp
  have h : env58432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58431_58432 : H12AffineEnvironment.transform 17 223242 env58431 = env58432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223242 env58431 == env58432) = true)

theorem identity58432 : scanCanonicalize (H12AffineFastState.compose env58432 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 28803) := by decide +kernel

theorem selectedBound58432 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env58433 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,28803,131072,137353,136192,32769,4096,61569,147472,41003,143497,20497,60445,148668,148669,2184,21672,136365,172,21677,1213,135680]

theorem envBound58433 : H12AffineFastState.Bounded env58433 := by
  intro p hp
  have h : env58433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58432_58433 : H12AffineEnvironment.transform 15 28803 env58432 = env58433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28803 env58432 == env58433) = true)

theorem identity58433 : scanCanonicalize (H12AffineFastState.compose env58433 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(14+1) ^^^ 29860) := by decide +kernel

theorem selectedBound58433 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env58434 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,29860,28803,131072,137353,136192,29861,4096,1061,147472,21647,143497,20497,6329,148668,148669,2184,21672,136365,172,21677,1213,135680]

theorem envBound58434 : H12AffineFastState.Bounded env58434 := by
  intro p hp
  have h : env58434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58433_58434 : H12AffineEnvironment.transform 14 29860 env58433 = env58434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29860 env58433 == env58434) = true)

theorem identity58434 : scanCanonicalize (H12AffineFastState.compose env58434 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound58434 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env58435 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1213,12313,13374,131072,137353,136192,12312,4096,1061,132269,4146,143497,5292,6329,131073,131072,2184,4117,136365,172,4112,1213,135680]

theorem envBound58435 : H12AffineFastState.Bounded env58435 := by
  intro p hp
  have h : env58435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58434_58435 : H12AffineEnvironment.transform 13 1213 env58434 = env58435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env58434 == env58435) = true)

theorem identity58435 : scanCanonicalize (H12AffineFastState.compose env58435 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(16+1) ^^^ 10379) := by decide +kernel

theorem selectedBound58435 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env58436 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1213,12313,13374,10379,12290,15499,12312,4096,1061,11302,4146,6146,5292,6329,10378,10379,2184,4117,15398,172,4112,1213,14987]

theorem envBound58436 : H12AffineFastState.Bounded env58436 := by
  intro p hp
  have h : env58436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58435_58436 : H12AffineEnvironment.transform 16 10379 env58435 = env58436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 10379 env58435 == env58436) = true)

theorem identity58436 : scanCanonicalize (H12AffineFastState.compose env58436 (packedSelected [0,4,5,7,8,9,10,17] rootPS)) = affineNative (2^(12+1) ^^^ 7311) := by decide +kernel

theorem selectedBound58436 : packedSelected [0,4,5,7,8,9,10,17] rootPS < 2^1333 := by decide +kernel

def env58437 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,7311,1213,3222,2225,5124,3213,4,3223,4096,1061,4265,4146,6146,5292,6329,5125,5124,2184,4117,169,172,4112,1213,1540]

theorem envBound58437 : H12AffineFastState.Bounded env58437 := by
  intro p hp
  have h : env58437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58436_58437 : H12AffineEnvironment.transform 12 7311 env58436 = env58437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7311 env58436 == env58437) = true)

theorem identity58437 : scanCanonicalize (H12AffineFastState.compose env58437 (packedSelected [0,1,2,3,4,5,7,8,9,11,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound58437 : packedSelected [0,1,2,3,4,5,7,8,9,11,12,15] rootPS < 2^1333 := by decide +kernel

def env58438 : List Nat := [2,4,8,16,32,16,128,173,512,517,2048,4096,6794,696,2707,2225,4609,2696,4,2706,4096,544,4265,4146,6146,4777,6329,4608,4609,2184,4117,169,172,4112,696,1]

theorem envBound58438 : H12AffineFastState.Bounded env58438 := by
  intro p hp
  have h : env58438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58437_58438 : H12AffineEnvironment.transform 9 517 env58437 = env58438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env58437 == env58438) = true)

theorem identity58438 : scanCanonicalize (H12AffineFastState.compose env58438 (packedSelected [1,2,3,5,6,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 674) := by decide +kernel

theorem selectedBound58438 : packedSelected [1,2,3,5,6,8,10,11] rootPS < 2^1333 := by decide +kernel

def env58439 : List Nat := [2,4,8,16,32,16,128,173,512,517,674,4096,4136,696,49,531,4609,42,4,48,4096,544,4265,4146,4768,4777,4635,4608,4609,554,4117,169,172,4112,696,1]

theorem envBound58439 : H12AffineFastState.Bounded env58439 := by
  intro p hp
  have h : env58439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58438_58439 : H12AffineEnvironment.transform 10 674 env58438 = env58439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 674 env58438 == env58439) = true)

theorem identity58439 : scanCanonicalize (H12AffineFastState.compose env58439 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 555) := by decide +kernel

theorem selectedBound58439 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env58440 : List Nat := [2,4,8,16,32,16,128,173,512,517,674,555,515,696,49,531,42,42,4,48,555,544,642,537,139,130,48,43,42,554,574,169,172,571,696,1]

theorem envBound58440 : H12AffineFastState.Bounded env58440 := by
  intro p hp
  have h : env58440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58439_58440 : H12AffineEnvironment.transform 11 555 env58439 = env58440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 555 env58439 == env58440) = true)

theorem identity58440 : scanCanonicalize (H12AffineFastState.compose env58440 (packedSelected [1,8] rootPS)) = affineNative (2^(8+1) ^^^ 146) := by decide +kernel

theorem selectedBound58440 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env58441 : List Nat := [2,4,8,16,32,16,128,173,146,151,48,185,145,42,49,129,42,42,4,48,185,178,16,139,139,130,48,43,42,184,172,169,172,169,42,1]

theorem envBound58441 : H12AffineFastState.Bounded env58441 := by
  intro p hp
  have h : env58441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58440_58441 : H12AffineEnvironment.transform 8 146 env58440 = env58441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 146 env58440 == env58441) = true)

theorem identity58441 : scanCanonicalize (H12AffineFastState.compose env58441 (packedSelected [0,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 31) := by decide +kernel

theorem selectedBound58441 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env58442 : List Nat := [2,4,8,16,32,16,31,50,13,8,48,38,14,42,49,30,42,42,4,48,38,45,16,20,20,29,48,43,42,39,51,54,51,54,42,1]

theorem envBound58442 : H12AffineFastState.Bounded env58442 := by
  intro p hp
  have h : env58442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58441_58442 : H12AffineEnvironment.transform 6 31 env58441 = env58442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 31 env58441 == env58442) = true)

theorem identity58442 : scanCanonicalize (H12AffineFastState.compose env58442 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound58442 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env58443 : List Nat := [2,4,4,16,32,16,19,50,1,4,48,38,2,38,49,18,38,38,4,48,38,33,16,20,20,17,48,39,38,39,51,54,51,54,38,1]

theorem envBound58443 : H12AffineFastState.Bounded env58443 := by
  intro p hp
  have h : env58443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58442_58443 : H12AffineEnvironment.transform 2 4 env58442 = env58443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env58442 == env58443) = true)

def env58444 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147473,41003,143497,20497,492566,148669,148668,96266,74795,222255,172,74798,1212,135680]

theorem envBound58444 : H12AffineFastState.Bounded env58444 := by
  intro p hp
  have h : env58444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58430_58444 : H12AffineEnvironment.transform 5 17 env58430 = env58444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env58430 == env58444) = true)

theorem identity58444 : scanCanonicalize (H12AffineFastState.compose env58444 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 114723) := by decide +kernel

theorem selectedBound58444 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env58445 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,114723,262144,119843,32769,4096,61568,98354,41003,127146,20497,279605,99486,99487,96266,74795,41996,172,74798,1212,119331]

theorem envBound58445 : H12AffineFastState.Bounded env58445 := by
  intro p hp
  have h : env58445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58444_58445 : H12AffineEnvironment.transform 16 114723 env58444 = env58445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114723 env58444 == env58445) = true)

theorem identity58445 : scanCanonicalize (H12AffineFastState.compose env58445 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 23693) := by decide +kernel

theorem selectedBound58445 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env58446 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,114723,23693,119843,32769,4096,61568,98354,41003,127146,20497,6328,99486,99487,96266,74795,41996,172,74798,1212,119331]

theorem envBound58446 : H12AffineFastState.Bounded env58446 := by
  intro p hp
  have h : env58446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58445_58446 : H12AffineEnvironment.transform 17 23693 env58445 = env58446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23693 env58445 == env58446) = true)

theorem identity58446 : scanCanonicalize (H12AffineFastState.compose env58446 (packedSelected [7,16,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound58446 : packedSelected [7,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env58447 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,53283,4096,23693,1024,32769,4096,61568,20497,41003,8329,20497,6328,21693,21692,43049,62472,41996,172,62477,1212,512]

theorem envBound58447 : H12AffineFastState.Bounded env58447 := by
  intro p hp
  have h : env58447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58446_58447 : H12AffineEnvironment.transform 15 53283 env58446 = env58447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env58446 == env58447) = true)

theorem identity58447 : scanCanonicalize (H12AffineFastState.compose env58447 (packedSelected [4,9,16] rootPS)) = affineNative (2^(14+1) ^^^ 12312) := by decide +kernel

theorem selectedBound58447 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env58448 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,12312,24635,4096,23693,1024,12313,4096,16536,20497,4147,8329,20497,6328,21693,21692,6193,17424,5140,172,17429,1212,512]

theorem envBound58448 : H12AffineFastState.Bounded env58448 := by
  intro p hp
  have h : env58448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58447_58448 : H12AffineEnvironment.transform 14 12312 env58447 = env58448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12312 env58447 == env58448) = true)

theorem identity58448 : scanCanonicalize (H12AffineFastState.compose env58448 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 8744) := by decide +kernel

theorem selectedBound58448 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env58449 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,8744,12312,531,4096,16037,1024,12313,4096,8880,12857,4147,8329,12857,6328,13973,13972,6193,9784,5140,172,9789,1212,512]

theorem envBound58449 : H12AffineFastState.Bounded env58449 := by
  intro p hp
  have h : env58449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58448_58449 : H12AffineEnvironment.transform 13 8744 env58448 = env58449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8744 env58448 == env58449) = true)

theorem identity58449 : scanCanonicalize (H12AffineFastState.compose env58449 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(12+1) ^^^ 5175) := by decide +kernel

theorem selectedBound58449 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env58450 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,5175,5663,1071,531,4096,2706,1024,1070,4096,5767,1550,4147,5310,1550,6328,674,675,6193,4623,5140,172,4618,1212,512]

theorem envBound58450 : H12AffineFastState.Bounded env58450 := by
  intro p hp
  have h : env58450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58449_58450 : H12AffineEnvironment.transform 12 5175 env58449 = env58450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5175 env58449 == env58450) = true)

theorem identity58450 : scanCanonicalize (H12AffineFastState.compose env58450 (packedSelected [1,3,13] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound58450 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env58451 : List Nat := [2,4,8,16,32,17,128,173,26,1024,2048,4096,5175,5125,1071,9,4096,2184,1024,1070,4096,5277,1044,4147,5310,1044,6328,184,185,6193,4117,5140,172,4112,1212,26]

theorem envBound58451 : H12AffineFastState.Bounded env58451 := by
  intro p hp
  have h : env58451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58450_58451 : H12AffineEnvironment.transform 8 26 env58450 = env58451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env58450 == env58451) = true)

theorem identity58451 : scanCanonicalize (H12AffineFastState.compose env58451 (packedSelected [1,2,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 3076) := by decide +kernel

theorem selectedBound58451 : packedSelected [1,2,5,6] rootPS < 2^1333 := by decide +kernel

def env58452 : List Nat := [2,4,8,16,32,17,128,173,26,1024,2048,3076,2099,2049,1071,9,3076,2184,1024,1070,3076,2201,1044,3127,2234,1044,1212,184,185,1077,3089,2064,172,3092,1212,26]

theorem envBound58452 : H12AffineFastState.Bounded env58452 := by
  intro p hp
  have h : env58452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58451_58452 : H12AffineEnvironment.transform 11 3076 env58451 = env58452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3076 env58451 == env58452) = true)

theorem identity58452 : scanCanonicalize (H12AffineFastState.compose env58452 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(10+1) ^^^ 1191) := by decide +kernel

theorem selectedBound58452 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env58453 : List Nat := [2,4,8,16,32,17,128,173,26,1024,1191,163,1172,1190,1071,9,163,1071,1024,1070,163,1086,1044,144,1053,1044,1212,184,185,1077,182,1207,172,179,1212,26]

theorem envBound58453 : H12AffineFastState.Bounded env58453 := by
  intro p hp
  have h : env58453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58452_58453 : H12AffineEnvironment.transform 10 1191 env58452 = env58453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1191 env58452 == env58453) = true)

theorem identity58453 : scanCanonicalize (H12AffineFastState.compose env58453 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound58453 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env58454 : List Nat := [2,4,8,16,32,17,18,63,26,1024,1077,49,1030,1076,1071,9,49,1071,1024,1070,49,1086,1044,2,1053,1044,1070,42,43,1077,36,1061,62,33,1070,26]

theorem envBound58454 : H12AffineFastState.Bounded env58454 := by
  intro p hp
  have h : env58454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58453_58454 : H12AffineEnvironment.transform 6 18 env58453 = env58454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env58453 == env58454) = true)

theorem identity58454 : scanCanonicalize (H12AffineFastState.compose env58454 (packedSelected [0,1,2] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound58454 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env58455 : List Nat := [2,4,8,16,32,17,18,63,26,4,49,49,2,48,43,9,49,43,4,42,49,58,16,2,25,16,42,42,43,49,36,33,62,33,42,26]

theorem envBound58455 : H12AffineFastState.Bounded env58455 := by
  intro p hp
  have h : env58455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58454_58455 : H12AffineEnvironment.transform 9 4 env58454 = env58455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env58454 == env58455) = true)

theorem identity58455 : scanCanonicalize (H12AffineFastState.compose env58455 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound58455 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env58456 : List Nat := [2,4,8,12,32,13,14,35,6,4,45,45,2,44,43,9,45,43,4,42,45,38,12,2,5,12,42,42,43,45,36,33,34,33,42,6]

theorem envBound58456 : H12AffineFastState.Bounded env58456 := by
  intro p hp
  have h : env58456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58455_58456 : H12AffineEnvironment.transform 3 12 env58455 = env58456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env58455 == env58456) = true)

theorem identity58456 : scanCanonicalize (H12AffineFastState.compose env58456 (packedSelected [0,9] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound58456 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env58457 : List Nat := [2,3,8,11,32,10,9,35,1,3,42,42,2,43,43,9,42,43,3,42,42,33,11,2,2,11,42,42,43,42,35,33,34,33,42,1]

theorem envBound58457 : H12AffineFastState.Bounded env58457 := by
  intro p hp
  have h : env58457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58456_58457 : H12AffineEnvironment.transform 1 3 env58456 = env58457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env58456 == env58457) = true)

def env58458 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147520,41003,143496,20496,493034,148801,148801,96347,74795,222335,257,74798,1344,135681]

theorem envBound58458 : H12AffineFastState.Bounded env58458 := by
  intro p hp
  have h : env58458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58403_58458 : H12AffineEnvironment.transform 18 136193 env58403 = env58458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env58403 == env58458) = true)

def env58459 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147520,41003,143496,20496,492614,148717,148717,96347,74795,222335,173,74798,1260,135681]

theorem envBound58459 : H12AffineFastState.Bounded env58459 := by
  intro p hp
  have h : env58459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58458_58459 : H12AffineEnvironment.transform 7 172 env58458 = env58459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env58458 == env58459) = true)

def env58460 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147472,41003,143496,20496,492566,148669,148669,96267,74795,222255,173,74798,1212,135681]

theorem envBound58460 : H12AffineFastState.Bounded env58460 := by
  intro p hp
  have h : env58460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58459_58460 : H12AffineEnvironment.transform 5 16 env58459 = env58460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env58459 == env58460) = true)

theorem identity58460 : scanCanonicalize (H12AffineFastState.compose env58460 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound58460 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env58461 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,45217,262144,42144,32769,4096,61569,61617,41003,32809,20496,341175,62492,62492,96267,74795,119950,173,74798,1212,41632]

theorem envBound58461 : H12AffineFastState.Bounded env58461 := by
  intro p hp
  have h : env58461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58460_58461 : H12AffineEnvironment.transform 16 45217 env58460 = env58461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env58460 == env58461) = true)

theorem identity58461 : scanCanonicalize (H12AffineFastState.compose env58461 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound58461 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env58462 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1213,32768,65536,45217,262144,42144,32769,4096,46140,46092,41003,32809,5293,341175,45217,45217,81078,74795,102451,173,74798,1212,41632]

theorem envBound58462 : H12AffineFastState.Bounded env58462 := by
  intro p hp
  have h : env58462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58461_58462 : H12AffineEnvironment.transform 13 1213 env58461 = env58462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env58461 == env58462) = true)

theorem identity58462 : scanCanonicalize (H12AffineFastState.compose env58462 (packedSelected [4,9,16] rootPS)) = affineNative (2^(14+1) ^^^ 12313) := by decide +kernel

theorem selectedBound58462 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env58463 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1213,12313,65536,184,262144,5305,12312,4096,1061,1045,4146,12336,5293,341175,184,184,81078,74795,73770,173,74798,1212,4793]

theorem envBound58463 : H12AffineFastState.Bounded env58463 := by
  intro p hp
  have h : env58463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58462_58463 : H12AffineEnvironment.transform 14 12313 env58462 = env58463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12313 env58462 == env58463) = true)

theorem identity58463 : scanCanonicalize (H12AffineFastState.compose env58463 (packedSelected [4,9,20] rootPS)) = affineNative (2^(15+1) ^^^ 9350) := by decide +kernel

theorem selectedBound58463 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env58464 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1213,12313,9350,184,262144,5305,12312,4096,1061,1045,4146,12336,5293,266289,184,184,6192,173,1196,173,168,1212,4793]

theorem envBound58464 : H12AffineFastState.Bounded env58464 := by
  intro p hp
  have h : env58464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58463_58464 : H12AffineEnvironment.transform 15 9350 env58463 = env58464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9350 env58463 == env58464) = true)

theorem identity58464 : scanCanonicalize (H12AffineFastState.compose env58464 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 6192) := by decide +kernel

theorem selectedBound58464 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env58465 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1213,12313,9350,184,6192,5305,12312,4096,1061,1045,4146,12336,5293,2049,184,184,6192,173,1196,173,168,1212,4793]

theorem envBound58465 : H12AffineFastState.Bounded env58465 := by
  intro p hp
  have h : env58465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58464_58465 : H12AffineEnvironment.transform 17 6192 env58464 = env58465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6192 env58464 == env58465) = true)

theorem identity58465 : scanCanonicalize (H12AffineFastState.compose env58465 (packedSelected [2,3,4,6,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 555) := by decide +kernel

theorem selectedBound58465 : packedSelected [2,3,4,6,8,9] rootPS < 2^1333 := by decide +kernel

def env58466 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,555,8192,1213,8754,9350,184,2587,1682,8755,555,1061,1045,537,8731,1670,2049,184,184,2587,173,1196,173,168,1212,146]

theorem envBound58466 : H12AffineFastState.Bounded env58466 := by
  intro p hp
  have h : env58466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58465_58466 : H12AffineEnvironment.transform 11 555 env58465 = env58466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 555 env58465 == env58466) = true)

theorem identity58466 : scanCanonicalize (H12AffineFastState.compose env58466 (packedSelected [1,3,6] rootPS)) = affineNative (2^(12+1) ^^^ 1564) := by decide +kernel

theorem selectedBound58466 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env58467 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,555,1564,1213,1070,666,184,2587,1682,1071,555,1061,1045,537,1031,1670,2049,184,184,2587,173,1196,173,168,1212,146]

theorem envBound58467 : H12AffineFastState.Bounded env58467 := by
  intro p hp
  have h : env58467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58466_58467 : H12AffineEnvironment.transform 12 1564 env58466 = env58467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1564 env58466 == env58467) = true)

theorem identity58467 : scanCanonicalize (H12AffineFastState.compose env58467 (packedSelected [0,2,4,10] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound58467 : packedSelected [0,2,4,10] rootPS < 2^1333 := by decide +kernel

def env58468 : List Nat := [2,4,8,16,32,16,128,172,136,1024,2048,163,1172,1213,1070,18,184,2195,1050,1071,163,1061,1045,145,1031,1038,2049,184,184,2195,173,1196,173,168,1212,146]

theorem envBound58468 : H12AffineFastState.Bounded env58468 := by
  intro p hp
  have h : env58468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58467_58468 : H12AffineEnvironment.transform 8 136 env58467 = env58468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env58467 == env58468) = true)

theorem identity58468 : scanCanonicalize (H12AffineFastState.compose env58468 (packedSelected [2,4,5,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 141) := by decide +kernel

theorem selectedBound58468 : packedSelected [2,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env58469 : List Nat := [2,4,8,16,32,16,128,172,136,141,2048,163,25,48,163,18,184,2195,151,162,163,168,152,145,138,131,2049,184,184,2195,173,33,173,168,49,146]

theorem envBound58469 : H12AffineFastState.Bounded env58469 := by
  intro p hp
  have h : env58469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58468_58469 : H12AffineEnvironment.transform 9 141 env58468 = env58469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 141 env58468 == env58469) = true)

theorem identity58469 : scanCanonicalize (H12AffineFastState.compose env58469 (packedSelected [3,5] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound58469 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env58470 : List Nat := [2,4,8,16,32,16,8,36,0,5,2048,43,25,48,43,18,48,2075,31,42,43,32,16,25,2,11,2049,48,48,2075,37,33,37,32,49,26]

theorem envBound58470 : H12AffineFastState.Bounded env58470 := by
  intro p hp
  have h : env58470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58469_58470 : H12AffineEnvironment.transform 6 8 env58469 = env58470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env58469 == env58470) = true)

theorem identity58470 : scanCanonicalize (H12AffineFastState.compose env58470 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound58470 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58471 : List Nat := [2,4,8,16,6,16,8,2,0,5,2048,13,25,22,13,18,22,2075,31,12,13,6,16,25,2,11,2049,22,22,2075,3,7,3,6,23,26]

theorem envBound58471 : H12AffineFastState.Bounded env58471 := by
  intro p hp
  have h : env58471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58470_58471 : H12AffineEnvironment.transform 4 6 env58470 = env58471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env58470 == env58471) = true)

theorem identity58471 : scanCanonicalize (H12AffineFastState.compose env58471 (packedSelected [2,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 12) := by decide +kernel

theorem selectedBound58471 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env58472 : List Nat := [2,4,8,16,6,16,8,2,0,5,12,13,25,22,13,18,22,23,31,12,13,6,16,25,2,11,13,22,22,23,3,7,3,6,23,26]

theorem envBound58472 : H12AffineFastState.Bounded env58472 := by
  intro p hp
  have h : env58472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58471_58472 : H12AffineEnvironment.transform 10 12 env58471 = env58472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 12 env58471 == env58472) = true)

theorem identity58472 : scanCanonicalize (H12AffineFastState.compose env58472 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound58472 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58473 : List Nat := [2,4,8,11,6,11,8,2,0,5,12,13,2,13,13,9,13,12,4,12,13,6,11,2,2,11,13,13,13,12,3,7,3,6,12,1]

theorem envBound58473 : H12AffineFastState.Bounded env58473 := by
  intro p hp
  have h : env58473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58472_58473 : H12AffineEnvironment.transform 3 11 env58472 = env58473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env58472 == env58473) = true)

theorem identity58473 : scanCanonicalize (H12AffineFastState.compose env58473 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound58473 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58474 : List Nat := [2,4,1,2,6,2,1,2,0,5,5,4,2,4,4,0,4,5,4,5,4,6,2,2,2,2,4,4,4,5,3,7,3,6,5,1]

theorem envBound58474 : H12AffineFastState.Bounded env58474 := by
  intro p hp
  have h : env58474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58473_58474 : H12AffineEnvironment.transform 2 1 env58473 = env58474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env58473 == env58474) = true)

theorem identity58474 : scanCanonicalize (H12AffineFastState.compose env58474 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound58474 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env58475 : List Nat := [2,0,1,2,2,2,1,2,0,1,1,0,2,0,0,0,0,1,0,1,0,2,2,2,2,2,0,0,0,1,3,3,3,2,1,1]

theorem envBound58475 : H12AffineFastState.Bounded env58475 := by
  intro p hp
  have h : env58475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58474_58475 : H12AffineEnvironment.transform 1 0 env58474 = env58475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env58474 == env58475) = true)

theorem identity58475 : scanCanonicalize (H12AffineFastState.compose env58475 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound58475 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env58476 : List Nat := [1,0,1,1,1,1,1,1,0,1,1,0,1,0,0,0,0,1,0,1,0,1,1,1,1,1,0,0,0,1,0,0,0,1,1,1]

theorem envBound58476 : H12AffineFastState.Bounded env58476 := by
  intro p hp
  have h : env58476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58475_58476 : H12AffineEnvironment.transform 0 1 env58475 = env58476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env58475 == env58476) = true)

def env58477 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147473,41003,143496,20496,492567,148668,148668,96266,74795,222254,173,74798,1213,135681]

theorem envBound58477 : H12AffineFastState.Bounded env58477 := by
  intro p hp
  have h : env58477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58459_58477 : H12AffineEnvironment.transform 5 17 env58459 = env58477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env58459 == env58477) = true)

theorem identity58477 : scanCanonicalize (H12AffineFastState.compose env58477 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 137353) := by decide +kernel

theorem selectedBound58477 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env58478 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137353,136193,32769,4096,61568,147473,41003,143496,20496,105630,148668,148668,96266,74795,222254,173,74798,1213,135681]

theorem envBound58478 : H12AffineFastState.Bounded env58478 := by
  intro p hp
  have h : env58478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58477_58478 : H12AffineEnvironment.transform 17 137353 env58477 = env58478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137353 env58477 == env58478) = true)

theorem identity58478 : scanCanonicalize (H12AffineFastState.compose env58478 (packedSelected [1,5,8,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 13375) := by decide +kernel

theorem selectedBound58478 : packedSelected [1,5,8,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env58479 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,13375,131072,137353,136193,32769,4096,61568,147473,41003,143496,20496,43169,148668,148668,19509,4116,151569,173,4113,1213,135681]

theorem envBound58479 : H12AffineFastState.Bounded env58479 := by
  intro p hp
  have h : env58479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58478_58479 : H12AffineEnvironment.transform 15 13375 env58478 = env58479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13375 env58478 == env58479) = true)

theorem identity58479 : scanCanonicalize (H12AffineFastState.compose env58479 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound58479 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env58480 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1213,32768,13375,131072,137353,136193,32769,4096,46141,132268,41003,143496,5293,43169,131073,131073,2184,4116,136364,173,4113,1213,135681]

theorem envBound58480 : H12AffineFastState.Bounded env58480 := by
  intro p hp
  have h : env58480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58479_58480 : H12AffineEnvironment.transform 13 1213 env58479 = env58480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env58479 == env58480) = true)

theorem identity58480 : scanCanonicalize (H12AffineFastState.compose env58480 (packedSelected [13,17] rootPS)) = affineNative (2^(16+1) ^^^ 46244) := by decide +kernel

theorem selectedBound58480 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env58481 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1213,32768,13375,46244,44077,41125,32769,4096,46141,45064,41003,33836,5293,43169,46245,46245,2184,4116,40968,173,4113,1213,42661]

theorem envBound58481 : H12AffineFastState.Bounded env58481 := by
  intro p hp
  have h : env58481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58480_58481 : H12AffineEnvironment.transform 16 46244 env58480 = env58481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46244 env58480 == env58481) = true)

theorem identity58481 : scanCanonicalize (H12AffineFastState.compose env58481 (packedSelected [6,12,13,15] rootPS)) = affineNative (2^(14+1) ^^^ 8352) := by decide +kernel

theorem selectedBound58481 : packedSelected [6,12,13,15] rootPS < 2^1333 := by decide +kernel

def env58482 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1213,8352,13375,5124,3213,5,8353,4096,5277,4264,139,9356,5293,2049,5125,5125,2184,4116,168,173,4113,1213,1541]

theorem envBound58482 : H12AffineFastState.Bounded env58482 := by
  intro p hp
  have h : env58482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58481_58482 : H12AffineEnvironment.transform 14 8352 env58481 = env58482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8352 env58481 == env58482) = true)

theorem identity58482 : scanCanonicalize (H12AffineFastState.compose env58482 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 6169) := by decide +kernel

theorem selectedBound58482 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env58483 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,6169,1213,6329,3110,5124,3213,5,6328,4096,5277,4264,139,7317,5293,2049,5125,5125,2184,4116,168,173,4113,1213,1541]

theorem envBound58483 : H12AffineFastState.Bounded env58483 := by
  intro p hp
  have h : env58483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58482_58483 : H12AffineEnvironment.transform 12 6169 env58482 = env58483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6169 env58482 == env58483) = true)

theorem identity58483 : scanCanonicalize (H12AffineFastState.compose env58483 (packedSelected [4,7] rootPS)) = affineNative (2^(10+1) ^^^ 1725) := by decide +kernel

theorem selectedBound58483 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env58484 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1725,4096,5796,1213,5636,667,5124,560,5,5637,4096,5277,4264,139,4648,5293,1724,5125,5125,1589,4116,168,173,4113,1213,1541]

theorem envBound58484 : H12AffineFastState.Bounded env58484 := by
  intro p hp
  have h : env58484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58483_58484 : H12AffineEnvironment.transform 10 1725 env58483 = env58484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1725 env58483 == env58484) = true)

theorem identity58484 : scanCanonicalize (H12AffineFastState.compose env58484 (packedSelected [0,1,3,4,6,10] rootPS)) = affineNative (2^(9+1) ^^^ 662) := by decide +kernel

theorem selectedBound58484 : packedSelected [0,1,3,4,6,10] rootPS < 2^1333 := by decide +kernel

def env58485 : List Nat := [2,4,8,16,32,17,128,172,512,662,43,4096,4146,555,4242,667,4754,560,5,4243,4096,4619,4264,139,4648,4667,42,4755,4755,163,4116,168,173,4113,555,147]

theorem envBound58485 : H12AffineFastState.Bounded env58485 := by
  intro p hp
  have h : env58485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58484_58485 : H12AffineEnvironment.transform 9 662 env58484 = env58485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 662 env58484 == env58485) = true)

theorem identity58485 : scanCanonicalize (H12AffineFastState.compose env58485 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound58485 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env58486 : List Nat := [2,4,8,16,32,17,18,62,512,516,43,4096,4146,555,4096,521,4608,560,5,4097,4096,4619,4154,25,4648,4667,42,4609,4609,49,4116,58,63,4113,555,1]

theorem envBound58486 : H12AffineFastState.Bounded env58486 := by
  intro p hp
  have h : env58486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58485_58486 : H12AffineEnvironment.transform 6 18 env58485 = env58486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env58485 == env58486) = true)

theorem identity58486 : scanCanonicalize (H12AffineFastState.compose env58486 (packedSelected [5,8] rootPS)) = affineNative (2^(11+1) ^^^ 42) := by decide +kernel

theorem selectedBound58486 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env58487 : List Nat := [2,4,8,16,32,17,18,62,512,516,43,42,24,555,42,521,554,560,5,43,42,545,16,25,514,529,42,555,555,49,62,58,63,59,555,1]

theorem envBound58487 : H12AffineFastState.Bounded env58487 := by
  intro p hp
  have h : env58487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58486_58487 : H12AffineEnvironment.transform 11 42 env58486 = env58487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 42 env58486 == env58487) = true)

theorem identity58487 : scanCanonicalize (H12AffineFastState.compose env58487 (packedSelected [0,1,4] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound58487 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env58488 : List Nat := [2,4,8,16,13,17,18,19,512,516,6,7,24,518,7,521,519,541,5,6,7,524,16,25,514,529,7,518,518,28,19,23,18,22,518,1]

theorem envBound58488 : H12AffineFastState.Bounded env58488 := by
  intro p hp
  have h : env58488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58487_58488 : H12AffineEnvironment.transform 4 13 env58487 = env58488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env58487 == env58488) = true)

theorem identity58488 : scanCanonicalize (H12AffineFastState.compose env58488 (packedSelected [3,5] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound58488 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env58489 : List Nat := [2,4,8,16,13,17,18,19,1,5,6,7,24,7,7,8,6,28,5,6,7,13,16,25,3,16,7,7,7,28,19,23,18,22,7,1]

theorem envBound58489 : H12AffineFastState.Bounded env58489 := by
  intro p hp
  have h : env58489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58488_58489 : H12AffineEnvironment.transform 8 1 env58488 = env58489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env58488 == env58489) = true)

theorem identity58489 : scanCanonicalize (H12AffineFastState.compose env58489 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound58489 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58490 : List Nat := [2,4,8,10,13,11,8,9,1,5,6,7,2,7,7,8,6,6,5,6,7,13,10,3,3,10,7,7,7,6,9,13,8,12,7,1]

theorem envBound58490 : H12AffineFastState.Bounded env58490 := by
  intro p hp
  have h : env58490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58489_58490 : H12AffineEnvironment.transform 3 10 env58489 = env58490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env58489 == env58490) = true)

def env58491 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147520,41003,143496,20496,492615,148716,148716,96347,74795,222335,172,74798,1261,135681]

theorem envBound58491 : H12AffineFastState.Bounded env58491 := by
  intro p hp
  have h : env58491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58458_58491 : H12AffineEnvironment.transform 7 173 env58458 = env58491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env58458 == env58491) = true)

def env58492 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147472,41003,143496,20496,492567,148668,148668,96267,74795,222255,172,74798,1213,135681]

theorem envBound58492 : H12AffineFastState.Bounded env58492 := by
  intro p hp
  have h : env58492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58491_58492 : H12AffineEnvironment.transform 5 16 env58491 = env58492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env58491 == env58492) = true)

theorem identity58492 : scanCanonicalize (H12AffineFastState.compose env58492 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 114723) := by decide +kernel

theorem selectedBound58492 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env58493 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,114723,262144,119842,32769,4096,61569,98355,41003,127147,20496,279604,99487,99487,96267,74795,41996,172,74798,1213,119330]

theorem envBound58493 : H12AffineFastState.Bounded env58493 := by
  intro p hp
  have h : env58493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58492_58493 : H12AffineEnvironment.transform 16 114723 env58492 = env58493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114723 env58492 == env58493) = true)

theorem identity58493 : scanCanonicalize (H12AffineFastState.compose env58493 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 23693) := by decide +kernel

theorem selectedBound58493 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env58494 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,114723,23693,119842,32769,4096,61569,98355,41003,127147,20496,6329,99487,99487,96267,74795,41996,172,74798,1213,119330]

theorem envBound58494 : H12AffineFastState.Bounded env58494 := by
  intro p hp
  have h : env58494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58493_58494 : H12AffineEnvironment.transform 17 23693 env58493 = env58494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23693 env58493 == env58494) = true)

theorem identity58494 : scanCanonicalize (H12AffineFastState.compose env58494 (packedSelected [7,16,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound58494 : packedSelected [7,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env58495 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,53282,4097,23693,1024,32769,4096,61569,20497,41003,8329,20496,6329,21693,21693,43049,62473,41996,172,62476,1213,512]

theorem envBound58495 : H12AffineFastState.Bounded env58495 := by
  intro p hp
  have h : env58495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58494_58495 : H12AffineEnvironment.transform 15 53282 env58494 = env58495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env58494 == env58495) = true)

theorem identity58495 : scanCanonicalize (H12AffineFastState.compose env58495 (packedSelected [4,9,16] rootPS)) = affineNative (2^(14+1) ^^^ 12313) := by decide +kernel

theorem selectedBound58495 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env58496 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,12313,24635,4097,23693,1024,12312,4096,16536,20497,4146,8329,20496,6329,21693,21693,6192,17424,5141,172,17429,1213,512]

theorem envBound58496 : H12AffineFastState.Bounded env58496 := by
  intro p hp
  have h : env58496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58495_58496 : H12AffineEnvironment.transform 14 12313 env58495 = env58496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12313 env58495 == env58496) = true)

theorem identity58496 : scanCanonicalize (H12AffineFastState.compose env58496 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 12944) := by decide +kernel

theorem selectedBound58496 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env58497 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,12944,12313,4779,4097,11805,1024,12312,4096,12808,8833,4146,8329,8832,6329,9773,9773,6192,13952,5141,172,13957,1213,512]

theorem envBound58497 : H12AffineFastState.Bounded env58497 := by
  intro p hp
  have h : env58497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58496_58497 : H12AffineEnvironment.transform 13 12944 env58496 = env58497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12944 env58496 == env58497) = true)

theorem identity58497 : scanCanonicalize (H12AffineFastState.compose env58497 (packedSelected [0,3,4,8,13] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound58497 : packedSelected [0,3,4,8,13] rootPS < 2^1333 := by decide +kernel

def env58498 : List Nat := [2,4,8,16,32,16,128,173,26,1024,2048,4096,8192,12426,12313,4273,4097,11271,1024,12312,4096,12306,8347,4146,8329,8346,6329,9271,9271,6192,13466,5141,172,13471,1213,26]

theorem envBound58498 : H12AffineFastState.Bounded env58498 := by
  intro p hp
  have h : env58498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58497_58498 : H12AffineEnvironment.transform 8 26 env58497 = env58498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env58497 == env58498) = true)

theorem identity58498 : scanCanonicalize (H12AffineFastState.compose env58498 (packedSelected [0,1,2,5,9,11,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 3077) := by decide +kernel

theorem selectedBound58498 : packedSelected [0,1,2,5,9,11,12,15] rootPS < 2^1333 := by decide +kernel

def env58499 : List Nat := [2,4,8,16,32,16,128,173,26,1024,2048,3077,8192,11407,11292,3252,3076,11271,1024,11293,3077,11287,8347,3127,8329,8346,1212,9271,9271,1077,10399,2064,172,10394,1213,26]

theorem envBound58499 : H12AffineFastState.Bounded env58499 := by
  intro p hp
  have h : env58499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58498_58499 : H12AffineEnvironment.transform 11 3077 env58498 = env58499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3077 env58498 == env58499) = true)

theorem identity58499 : scanCanonicalize (H12AffineFastState.compose env58499 (packedSelected [0,3,4,5,7,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound58499 : packedSelected [0,3,4,5,7,9,11] rootPS < 2^1333 := by decide +kernel

def env58500 : List Nat := [2,4,8,16,32,16,128,173,26,1024,2048,3077,25,3222,3077,3252,3076,3102,1024,3076,3077,3086,130,3127,144,131,1212,1070,1070,1077,2182,2064,172,2179,1213,26]

theorem envBound58500 : H12AffineFastState.Bounded env58500 := by
  intro p hp
  have h : env58500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58499_58500 : H12AffineEnvironment.transform 12 25 env58499 = env58500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env58499 == env58500) = true)

theorem identity58500 : scanCanonicalize (H12AffineFastState.compose env58500 (packedSelected [1,3,4,5,6,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 1190) := by decide +kernel

theorem selectedBound58500 : packedSelected [1,3,4,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env58501 : List Nat := [2,4,8,16,32,16,128,173,26,1024,1190,163,25,48,163,18,162,184,1024,162,163,168,130,145,144,131,1212,1070,1070,1077,1056,1206,172,1061,1213,26]

theorem envBound58501 : H12AffineFastState.Bounded env58501 := by
  intro p hp
  have h : env58501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58500_58501 : H12AffineEnvironment.transform 10 1190 env58500 = env58501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1190 env58500 == env58501) = true)

theorem identity58501 : scanCanonicalize (H12AffineFastState.compose env58501 (packedSelected [1,4,6] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound58501 : packedSelected [1,4,6] rootPS < 2^1333 := by decide +kernel

def env58502 : List Nat := [2,4,8,16,32,16,18,63,26,1024,1076,49,25,48,49,18,48,42,1024,48,49,58,16,3,2,17,1070,1070,1070,1077,1056,1060,62,1061,1071,26]

theorem envBound58502 : H12AffineFastState.Bounded env58502 := by
  intro p hp
  have h : env58502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58501_58502 : H12AffineEnvironment.transform 6 18 env58501 = env58502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env58501 == env58502) = true)

def env58503 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147473,41003,143496,20496,492566,148669,148669,96266,74795,222254,172,74798,1212,135681]

theorem envBound58503 : H12AffineFastState.Bounded env58503 := by
  intro p hp
  have h : env58503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58491_58503 : H12AffineEnvironment.transform 5 17 env58491 = env58503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env58491 == env58503) = true)

theorem identity58503 : scanCanonicalize (H12AffineFastState.compose env58503 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 223242) := by decide +kernel

theorem selectedBound58503 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env58504 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,223242,136193,32769,4096,61568,147473,41003,143496,20496,60444,148669,148669,96266,74795,222254,172,74798,1212,135681]

theorem envBound58504 : H12AffineFastState.Bounded env58504 := by
  intro p hp
  have h : env58504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58503_58504 : H12AffineEnvironment.transform 17 223242 env58503 = env58504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223242 env58503 == env58504) = true)

theorem identity58504 : scanCanonicalize (H12AffineFastState.compose env58504 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 28802) := by decide +kernel

theorem selectedBound58504 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env58505 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,28802,131072,137352,136193,32769,4096,61568,147473,41003,143496,20496,60444,148669,148669,2184,21673,136364,172,21676,1212,135681]

theorem envBound58505 : H12AffineFastState.Bounded env58505 := by
  intro p hp
  have h : env58505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58504_58505 : H12AffineEnvironment.transform 15 28802 env58504 = env58505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28802 env58504 == env58505) = true)

theorem identity58505 : scanCanonicalize (H12AffineFastState.compose env58505 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(14+1) ^^^ 29860) := by decide +kernel

theorem selectedBound58505 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env58506 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,29860,28802,131072,137352,136193,29861,4096,1060,147473,21647,143496,20496,6328,148669,148669,2184,21673,136364,172,21676,1212,135681]

theorem envBound58506 : H12AffineFastState.Bounded env58506 := by
  intro p hp
  have h : env58506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58505_58506 : H12AffineEnvironment.transform 14 29860 env58505 = env58506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29860 env58505 == env58506) = true)

theorem identity58506 : scanCanonicalize (H12AffineFastState.compose env58506 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound58506 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env58507 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1212,12312,13374,131072,137352,136193,12313,4096,1060,132269,4147,143496,5292,6328,131073,131073,2184,4117,136364,172,4112,1212,135681]

theorem envBound58507 : H12AffineFastState.Bounded env58507 := by
  intro p hp
  have h : env58507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58506_58507 : H12AffineEnvironment.transform 13 1212 env58506 = env58507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env58506 == env58507) = true)

theorem identity58507 : scanCanonicalize (H12AffineFastState.compose env58507 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(16+1) ^^^ 14386) := by decide +kernel

theorem selectedBound58507 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env58508 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1212,12312,13374,14386,8378,11315,12313,4096,1060,15519,4147,2234,5292,6328,14387,14387,2184,4117,11422,172,4112,1212,10803]

theorem envBound58508 : H12AffineFastState.Bounded env58508 := by
  intro p hp
  have h : env58508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58507_58508 : H12AffineEnvironment.transform 16 14386 env58507 = env58508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 14386 env58507 == env58508) = true)

theorem identity58508 : scanCanonicalize (H12AffineFastState.compose env58508 (packedSelected [0,4,5,7,8,9,10,17] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound58508 : packedSelected [0,4,5,7,8,9,10,17] rootPS < 2^1333 := by decide +kernel

def env58509 : List Nat := [2,4,8,16,32,17,128,173,512,4,2048,4096,8192,184,12312,12346,14386,8378,10295,12313,4096,32,14491,4147,2234,4264,6328,14387,14387,2184,4117,10394,172,4112,184,10803]

theorem envBound58509 : H12AffineFastState.Bounded env58509 := by
  intro p hp
  have h : env58509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58508_58509 : H12AffineEnvironment.transform 9 4 env58508 = env58509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env58508 == env58509) = true)

theorem identity58509 : scanCanonicalize (H12AffineFastState.compose env58509 (packedSelected [1,2,3,6,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 697) := by decide +kernel

theorem selectedBound58509 : packedSelected [1,2,3,6,10,11] rootPS < 2^1333 := by decide +kernel

def env58510 : List Nat := [2,4,8,16,32,17,128,173,512,4,2048,697,8192,184,8865,8835,10891,8378,10295,8864,697,32,10786,650,2234,529,2561,10890,10890,2184,684,10394,172,681,184,10803]

theorem envBound58510 : H12AffineFastState.Bounded env58510 := by
  intro p hp
  have h : env58510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58509_58510 : H12AffineEnvironment.transform 11 697 env58509 = env58510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 697 env58509 == env58510) = true)

theorem identity58510 : scanCanonicalize (H12AffineFastState.compose env58510 (packedSelected [5,6,7,9,12] rootPS)) = affineNative (2^(12+1) ^^^ 2695) := by decide +kernel

theorem selectedBound58510 : packedSelected [5,6,7,9,12] rootPS < 2^1333 := by decide +kernel

def env58511 : List Nat := [2,4,8,16,32,17,128,173,512,4,2048,697,2695,184,2086,2052,12,2621,688,2087,697,32,165,650,2234,529,2561,13,13,2184,684,541,172,681,184,180]

theorem envBound58511 : H12AffineFastState.Bounded env58511 := by
  intro p hp
  have h : env58511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58510_58511 : H12AffineEnvironment.transform 12 2695 env58510 = env58511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2695 env58510 == env58511) = true)

theorem identity58511 : scanCanonicalize (H12AffineFastState.compose env58511 (packedSelected [0,4,5,10,15] rootPS)) = affineNative (2^(10+1) ^^^ 23) := by decide +kernel

theorem selectedBound58511 : packedSelected [0,4,5,10,15] rootPS < 2^1333 := by decide +kernel

def env58512 : List Nat := [2,4,8,16,32,17,128,173,512,4,23,697,656,184,49,19,12,554,688,48,697,32,165,650,173,529,534,13,13,159,684,541,172,681,184,180]

theorem envBound58512 : H12AffineFastState.Bounded env58512 := by
  intro p hp
  have h : env58512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58511_58512 : H12AffineEnvironment.transform 10 23 env58511 = env58512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 23 env58511 == env58512) = true)

theorem identity58512 : scanCanonicalize (H12AffineFastState.compose env58512 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 180) := by decide +kernel

theorem selectedBound58512 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env58513 : List Nat := [2,4,8,16,32,17,128,173,180,4,23,13,36,184,49,19,12,158,4,48,13,32,165,62,173,165,162,13,13,159,24,169,172,29,184,180]

theorem envBound58513 : H12AffineFastState.Bounded env58513 := by
  intro p hp
  have h : env58513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58512_58513 : H12AffineEnvironment.transform 8 180 env58512 = env58513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 180 env58512 == env58513) = true)

theorem identity58513 : scanCanonicalize (H12AffineFastState.compose env58513 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound58513 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env58514 : List Nat := [2,4,8,16,32,17,18,63,38,4,23,13,36,42,49,19,12,12,4,48,13,32,55,62,63,55,48,13,13,13,24,59,62,29,42,38]

theorem envBound58514 : H12AffineFastState.Bounded env58514 := by
  intro p hp
  have h : env58514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58513_58514 : H12AffineEnvironment.transform 6 18 env58513 = env58514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env58513 == env58514) = true)

theorem identity58514 : scanCanonicalize (H12AffineFastState.compose env58514 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound58514 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env58515 : List Nat := [2,4,8,11,32,10,9,36,38,4,12,13,36,42,42,8,12,12,4,43,13,32,44,37,36,44,43,13,13,13,3,32,37,6,42,38]

theorem envBound58515 : H12AffineFastState.Bounded env58515 := by
  intro p hp
  have h : env58515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58514_58515 : H12AffineEnvironment.transform 3 11 env58514 = env58515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env58514 == env58515) = true)

def env58516 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,33554432,672785,134217728,148801,33584585,96346,50962569,4294967296,34088328,4345352435,151462017,33563273]

theorem envBound58516 : H12AffineFastState.Bounded env58516 := by
  intro p hp
  have h : env58516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57192_58516 : H12AffineEnvironment.transform 20 4097 env57192 = env58516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env57192 == env58516) = true)

theorem identity58516 : scanCanonicalize (H12AffineFastState.compose env58516 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 151802110) := by decide +kernel

theorem selectedBound58516 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env58517 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,33554432,672785,134217728,148801,33584585,96346,50962569,151802110,34088328,168591373,151462017,33563273]

theorem envBound58517 : H12AffineFastState.Bounded env58517 := by
  intro p hp
  have h : env58517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58516_58517 : H12AffineEnvironment.transform 31 151802110 env58516 = env58517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 151802110 env58516 == env58517) = true)

def env58518 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,533640,672785,134217728,148801,545089,96346,16876545,151802110,256,134521989,151462017,525825]

theorem envBound58518 : H12AffineFastState.Bounded env58518 := by
  intro p hp
  have h : env58518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58517_58518 : H12AffineEnvironment.transform 24 533640 env58517 = env58518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533640 env58517 == env58518) = true)

def env58519 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,533640,672785,17245632,148801,545089,96346,16876545,750910,256,17006917,1345,525825]

theorem envBound58519 : H12AffineFastState.Bounded env58519 := by
  intro p hp
  have h : env58519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58518_58519 : H12AffineEnvironment.transform 26 17245632 env58518 = env58519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env58518 == env58519) = true)

theorem identity58519 : scanCanonicalize (H12AffineFastState.compose env58519 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(18+1) ^^^ 95614) := by decide +kernel

theorem selectedBound58519 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env58520 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95614,32769,4097,61648,147520,16777216,86518,209263,17245632,148801,74815,96346,16876545,131136,256,17006917,1345,95103]

theorem envBound58520 : H12AffineFastState.Bounded env58520 := by
  intro p hp
  have h : env58520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58519_58520 : H12AffineEnvironment.transform 18 95614 env58519 = env58520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 95614 env58519 == env58520) = true)

def env58521 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95614,32769,4097,61648,147520,284032,86518,209263,225344,148801,74815,96346,381313,131136,256,513221,1345,95103]

theorem envBound58521 : H12AffineFastState.Bounded env58521 := by
  intro p hp
  have h : env58521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58520_58521 : H12AffineEnvironment.transform 23 284032 env58520 = env58521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284032 env58520 == env58521) = true)

def env58522 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,75056,262144,95614,32769,4097,61648,91504,284032,86518,5215,21872,90225,74815,96346,381313,75120,256,324085,1345,95103]

theorem envBound58522 : H12AffineFastState.Bounded env58522 := by
  intro p hp
  have h : env58522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58521_58522 : H12AffineEnvironment.transform 16 75056 env58521 = env58522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 75056 env58521 == env58522) = true)

def env58523 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,28704,21776,262144,1374,32769,4097,61648,5456,284032,8662,5215,21872,4177,21535,2170,303521,21840,256,324085,1345,863]

theorem envBound58523 : H12AffineFastState.Bounded env58523 := by
  intro p hp
  have h : env58523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58522_58523 : H12AffineEnvironment.transform 15 28704 env58522 = env58523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28704 env58522 == env58523) = true)

def env58524 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,28705,21777,262144,1375,32769,4097,61648,5457,284032,8663,5215,21872,4176,21534,2171,303520,21841,256,324085,1345,862]

theorem envBound58524 : H12AffineFastState.Bounded env58524 := by
  intro p hp
  have h : env58524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58522_58524 : H12AffineEnvironment.transform 15 28705 env58522 = env58524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28705 env58522 == env58524) = true)

theorem identity58524 : scanCanonicalize (H12AffineFastState.compose env58524 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 94) := by decide +kernel

theorem selectedBound58524 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env58525 : List Nat := [2,4,8,16,32,64,128,94,512,1024,2048,4096,8192,16384,32768,28705,21583,262144,1025,32769,4097,61648,5135,283870,8329,5215,21550,4176,21534,2171,303358,21519,94,323755,1055,512]

theorem envBound58525 : H12AffineFastState.Bounded env58525 := by
  intro p hp
  have h : env58525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58524_58525 : H12AffineEnvironment.transform 7 94 env58524 = env58525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 94 env58524 == env58525) = true)

theorem identity58525 : scanCanonicalize (H12AffineFastState.compose env58525 (packedSelected [4,9,16] rootPS)) = affineNative (2^(17+1) ^^^ 5356) := by decide +kernel

theorem selectedBound58525 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env58526 : List Nat := [2,4,8,16,32,64,128,94,512,1024,2048,4096,8192,16384,32768,28705,21583,5356,1025,32769,4097,61648,5135,16434,8329,5215,21550,4176,21534,2171,46098,21519,94,58439,1055,512]

theorem envBound58526 : H12AffineFastState.Bounded env58526 := by
  intro p hp
  have h : env58526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58525_58526 : H12AffineEnvironment.transform 17 5356 env58525 = env58526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 5356 env58525 == env58526) = true)

theorem identity58526 : scanCanonicalize (H12AffineFastState.compose env58526 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 25677) := by decide +kernel

theorem selectedBound58526 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env58527 : List Nat := [2,4,8,16,32,64,128,94,512,1024,2048,4096,8192,16384,25677,28705,21583,5356,1025,25676,4097,5277,5135,16434,8329,5215,21550,4176,21534,2171,20575,21519,94,10,1055,512]

theorem envBound58527 : H12AffineFastState.Bounded env58527 := by
  intro p hp
  have h : env58527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58526_58527 : H12AffineEnvironment.transform 14 25677 env58526 = env58527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25677 env58526 == env58527) = true)

theorem identity58527 : scanCanonicalize (H12AffineFastState.compose env58527 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound58527 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env58528 : List Nat := [2,4,8,16,32,17,128,15,512,1024,2048,4096,8192,16384,25628,28705,21534,5309,1025,25629,4097,5277,5135,16434,8329,5134,21550,4097,21534,2090,20494,21519,15,10,1055,512]

theorem envBound58528 : H12AffineFastState.Bounded env58528 := by
  intro p hp
  have h : env58528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58527_58528 : H12AffineEnvironment.transform 5 17 env58527 = env58528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env58527 == env58528) = true)

theorem identity58528 : scanCanonicalize (H12AffineFastState.compose env58528 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound58528 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58529 : List Nat := [2,4,8,16,32,17,128,15,512,4,2048,4096,8192,16384,24600,28705,20506,4281,5,24601,4097,4249,4107,16434,8329,4106,20522,4097,20506,2090,20494,20491,15,10,27,512]

theorem envBound58529 : H12AffineFastState.Bounded env58529 := by
  intro p hp
  have h : env58529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58528_58529 : H12AffineEnvironment.transform 9 4 env58528 = env58529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env58528 == env58529) = true)

theorem identity58529 : scanCanonicalize (H12AffineFastState.compose env58529 (packedSelected [6] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound58529 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58530 : List Nat := [2,4,8,11,32,10,128,15,512,4,2048,4096,8192,16384,24579,28705,20481,4258,5,24578,4097,4226,4107,16425,8329,4106,20522,4097,20481,2090,20494,20491,15,10,0,512]

theorem envBound58530 : H12AffineFastState.Bounded env58530 := by
  intro p hp
  have h : env58530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58529_58530 : H12AffineEnvironment.transform 3 11 env58529 = env58530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env58529 == env58530) = true)

theorem identity58530 : scanCanonicalize (H12AffineFastState.compose env58530 (packedSelected [1,3,5,8,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 554) := by decide +kernel

theorem selectedBound58530 : packedSelected [1,3,5,8,10,12] rootPS < 2^1333 := by decide +kernel

def env58531 : List Nat := [2,4,8,11,32,10,128,15,512,4,554,4096,8192,16384,24579,28705,20481,4258,5,24578,4097,4226,4107,16425,8329,4106,20522,4097,20481,512,20494,20491,15,10,0,512]

theorem envBound58531 : H12AffineFastState.Bounded env58531 := by
  intro p hp
  have h : env58531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58530_58531 : H12AffineEnvironment.transform 10 554 env58530 = env58531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 554 env58530 == env58531) = true)

theorem identity58531 : scanCanonicalize (H12AffineFastState.compose env58531 (packedSelected [10,15] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound58531 : packedSelected [10,15] rootPS < 2^1333 := by decide +kernel

def env58532 : List Nat := [2,4,8,11,11,10,128,15,512,4,513,4096,8192,16384,24579,28682,20481,4233,5,24578,4097,4226,4107,16386,8329,4106,20481,4097,20481,512,20494,20491,15,10,0,512]

theorem envBound58532 : H12AffineFastState.Bounded env58532 := by
  intro p hp
  have h : env58532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58531_58532 : H12AffineEnvironment.transform 4 11 env58531 = env58532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env58531 == env58532) = true)

theorem identity58532 : scanCanonicalize (H12AffineFastState.compose env58532 (packedSelected [9,10] rootPS)) = affineNative (2^(13+1) ^^^ 644) := by decide +kernel

theorem selectedBound58532 : packedSelected [9,10] rootPS < 2^1333 := by decide +kernel

def env58533 : List Nat := [2,4,8,11,11,10,128,15,512,4,513,4096,8192,644,8839,12942,4741,4233,5,8838,4097,4226,4107,646,8329,4106,4741,4097,4741,512,4746,4751,15,10,0,512]

theorem envBound58533 : H12AffineFastState.Bounded env58533 := by
  intro p hp
  have h : env58533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58532_58533 : H12AffineEnvironment.transform 13 644 env58532 = env58533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 644 env58532 == env58533) = true)

theorem identity58533 : scanCanonicalize (H12AffineFastState.compose env58533 (packedSelected [0,1,2,3,13] rootPS)) = affineNative (2^(12+1) ^^^ 4110) := by decide +kernel

theorem selectedBound58533 : packedSelected [0,1,2,3,13] rootPS < 2^1333 := by decide +kernel

def env58534 : List Nat := [2,4,8,11,11,10,128,15,512,4,513,4096,4110,644,4745,640,4741,4233,5,4744,4097,4226,4107,646,4231,4106,4741,4097,4741,512,4746,4751,15,10,0,512]

theorem envBound58534 : H12AffineFastState.Bounded env58534 := by
  intro p hp
  have h : env58534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58533_58534 : H12AffineEnvironment.transform 12 4110 env58533 = env58534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4110 env58533 == env58534) = true)

def env58535 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,75057,262144,95614,32769,4097,61648,91505,284032,86518,5214,21873,90224,74815,96346,381313,75121,256,324084,1345,95103]

theorem envBound58535 : H12AffineFastState.Bounded env58535 := by
  intro p hp
  have h : env58535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58521_58535 : H12AffineEnvironment.transform 16 75057 env58521 = env58535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 75057 env58521 == env58535) = true)

def env58536 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,28704,21777,262144,1374,32769,4097,61648,5457,284032,8662,5214,21873,4176,21535,2170,303521,21841,256,324084,1345,863]

theorem envBound58536 : H12AffineFastState.Bounded env58536 := by
  intro p hp
  have h : env58536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58535_58536 : H12AffineEnvironment.transform 15 28704 env58535 = env58536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28704 env58535 == env58536) = true)

theorem identity58536 : scanCanonicalize (H12AffineFastState.compose env58536 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 95) := by decide +kernel

theorem selectedBound58536 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env58537 : List Nat := [2,4,8,16,32,64,128,95,512,1024,2048,4096,8192,16384,32768,28704,21582,262144,1025,32769,4097,61648,5134,283871,8329,5214,21550,4176,21535,2170,303358,21518,95,323755,1054,512]

theorem envBound58537 : H12AffineFastState.Bounded env58537 := by
  intro p hp
  have h : env58537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58536_58537 : H12AffineEnvironment.transform 7 95 env58536 = env58537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 95 env58536 == env58537) = true)

theorem identity58537 : scanCanonicalize (H12AffineFastState.compose env58537 (packedSelected [4,9,16] rootPS)) = affineNative (2^(17+1) ^^^ 5357) := by decide +kernel

theorem selectedBound58537 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env58538 : List Nat := [2,4,8,16,32,64,128,95,512,1024,2048,4096,8192,16384,32768,28704,21582,5357,1025,32769,4097,61648,5134,16434,8329,5214,21550,4176,21535,2170,46099,21518,95,58438,1054,512]

theorem envBound58538 : H12AffineFastState.Bounded env58538 := by
  intro p hp
  have h : env58538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58537_58538 : H12AffineEnvironment.transform 17 5357 env58537 = env58538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 5357 env58537 == env58538) = true)

theorem identity58538 : scanCanonicalize (H12AffineFastState.compose env58538 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 25677) := by decide +kernel

theorem selectedBound58538 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env58539 : List Nat := [2,4,8,16,32,64,128,95,512,1024,2048,4096,8192,16384,25677,28704,21582,5357,1025,25676,4097,5277,5134,16434,8329,5214,21550,4176,21535,2170,20574,21518,95,11,1054,512]

theorem envBound58539 : H12AffineFastState.Bounded env58539 := by
  intro p hp
  have h : env58539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58538_58539 : H12AffineEnvironment.transform 14 25677 env58538 = env58539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25677 env58538 == env58539) = true)

theorem identity58539 : scanCanonicalize (H12AffineFastState.compose env58539 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound58539 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env58540 : List Nat := [2,4,8,16,32,17,128,14,512,1024,2048,4096,8192,16384,25628,28704,21535,5308,1025,25629,4097,5277,5134,16434,8329,5135,21550,4097,21535,2091,20495,21518,14,11,1054,512]

theorem envBound58540 : H12AffineFastState.Bounded env58540 := by
  intro p hp
  have h : env58540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58539_58540 : H12AffineEnvironment.transform 5 17 env58539 = env58540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env58539 == env58540) = true)

theorem identity58540 : scanCanonicalize (H12AffineFastState.compose env58540 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound58540 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58541 : List Nat := [2,4,8,16,32,17,128,14,512,4,2048,4096,8192,16384,24600,28704,20507,4280,5,24601,4097,4249,4106,16434,8329,4107,20522,4097,20507,2091,20495,20490,14,11,26,512]

theorem envBound58541 : H12AffineFastState.Bounded env58541 := by
  intro p hp
  have h : env58541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58540_58541 : H12AffineEnvironment.transform 9 4 env58540 = env58541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env58540 == env58541) = true)

theorem identity58541 : scanCanonicalize (H12AffineFastState.compose env58541 (packedSelected [6] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound58541 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58542 : List Nat := [2,4,8,10,32,11,128,14,512,4,2048,4096,8192,16384,24578,28704,20481,4258,5,24579,4097,4227,4106,16424,8329,4107,20522,4097,20481,2091,20495,20490,14,11,0,512]

theorem envBound58542 : H12AffineFastState.Bounded env58542 := by
  intro p hp
  have h : env58542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58541_58542 : H12AffineEnvironment.transform 3 10 env58541 = env58542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env58541 == env58542) = true)

theorem identity58542 : scanCanonicalize (H12AffineFastState.compose env58542 (packedSelected [1,3,5,8,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 555) := by decide +kernel

theorem selectedBound58542 : packedSelected [1,3,5,8,10,12] rootPS < 2^1333 := by decide +kernel

def env58543 : List Nat := [2,4,8,10,32,11,128,14,512,4,555,4096,8192,16384,24578,28704,20481,4258,5,24579,4097,4227,4106,16424,8329,4107,20522,4097,20481,512,20495,20490,14,11,0,512]

theorem envBound58543 : H12AffineFastState.Bounded env58543 := by
  intro p hp
  have h : env58543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58542_58543 : H12AffineEnvironment.transform 10 555 env58542 = env58543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 555 env58542 == env58543) = true)

theorem identity58543 : scanCanonicalize (H12AffineFastState.compose env58543 (packedSelected [10,15] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound58543 : packedSelected [10,15] rootPS < 2^1333 := by decide +kernel

def env58544 : List Nat := [2,4,8,10,10,11,128,14,512,4,513,4096,8192,16384,24578,28682,20481,4232,5,24579,4097,4227,4106,16386,8329,4107,20480,4097,20481,512,20495,20490,14,11,0,512]

theorem envBound58544 : H12AffineFastState.Bounded env58544 := by
  intro p hp
  have h : env58544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58543_58544 : H12AffineEnvironment.transform 4 10 env58543 = env58544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env58543 == env58544) = true)

theorem identity58544 : scanCanonicalize (H12AffineFastState.compose env58544 (packedSelected [9,10] rootPS)) = affineNative (2^(11+1) ^^^ 132) := by decide +kernel

theorem selectedBound58544 : packedSelected [9,10] rootPS < 2^1333 := by decide +kernel

def env58545 : List Nat := [2,4,8,10,10,11,128,14,512,4,513,132,8192,16384,24578,24718,16517,12,5,24579,133,7,142,16386,8329,143,16516,133,16517,512,16523,16526,14,11,0,512]

theorem envBound58545 : H12AffineFastState.Bounded env58545 := by
  intro p hp
  have h : env58545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58544_58545 : H12AffineEnvironment.transform 11 132 env58544 = env58545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 132 env58544 == env58545) = true)

theorem identity58545 : scanCanonicalize (H12AffineFastState.compose env58545 (packedSelected [0,1,2,3,13] rootPS)) = affineNative (2^(13+1) ^^^ 8331) := by decide +kernel

theorem selectedBound58545 : packedSelected [0,1,2,3,13] rootPS < 2^1333 := by decide +kernel

def env58546 : List Nat := [2,4,8,10,10,11,128,14,512,4,513,132,8192,8331,137,5,8206,12,5,136,133,7,142,8329,8329,143,8207,133,8206,512,8192,8197,14,11,0,512]

theorem envBound58546 : H12AffineFastState.Bounded env58546 := by
  intro p hp
  have h : env58546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58545_58546 : H12AffineEnvironment.transform 13 8331 env58545 = env58546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8331 env58545 == env58546) = true)

theorem identity58546 : scanCanonicalize (H12AffineFastState.compose env58546 (packedSelected [0,1,5] rootPS)) = affineNative (2^(12+1) ^^^ 14) := by decide +kernel

theorem selectedBound58546 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env58547 : List Nat := [2,4,8,10,10,11,128,14,512,4,513,132,14,133,137,5,0,12,5,136,133,7,142,135,135,143,1,133,0,512,14,11,14,11,0,512]

theorem envBound58547 : H12AffineFastState.Bounded env58547 := by
  intro p hp
  have h : env58547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58546_58547 : H12AffineEnvironment.transform 12 14 env58546 = env58547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 14 env58546 == env58547) = true)

def env58548 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,28705,21776,262144,1375,32769,4097,61648,5456,284032,8663,5214,21873,4177,21534,2171,303520,21840,256,324084,1345,862]

theorem envBound58548 : H12AffineFastState.Bounded env58548 := by
  intro p hp
  have h : env58548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58535_58548 : H12AffineEnvironment.transform 15 28705 env58535 = env58548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28705 env58535 == env58548) = true)

def env58549 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95614,32769,4097,61648,147520,284033,86518,209263,225345,148801,74815,96346,381312,131136,256,513220,1345,95103]

theorem envBound58549 : H12AffineFastState.Bounded env58549 := by
  intro p hp
  have h : env58549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58520_58549 : H12AffineEnvironment.transform 23 284033 env58520 = env58549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284033 env58520 == env58549) = true)

def env58550 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,75056,262144,95614,32769,4097,61648,91504,284033,86518,5215,21873,90225,74815,96346,381312,75120,256,324084,1345,95103]

theorem envBound58550 : H12AffineFastState.Bounded env58550 := by
  intro p hp
  have h : env58550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58549_58550 : H12AffineEnvironment.transform 16 75056 env58549 = env58550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 75056 env58549 == env58550) = true)

def env58551 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,28704,21776,262144,1374,32769,4097,61648,5456,284033,8662,5215,21873,4177,21535,2170,303520,21840,256,324084,1345,863]

theorem envBound58551 : H12AffineFastState.Bounded env58551 := by
  intro p hp
  have h : env58551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58550_58551 : H12AffineEnvironment.transform 15 28704 env58550 = env58551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28704 env58550 == env58551) = true)

def env58552 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,28705,21777,262144,1375,32769,4097,61648,5457,284033,8663,5215,21873,4176,21534,2171,303521,21841,256,324084,1345,862]

theorem envBound58552 : H12AffineFastState.Bounded env58552 := by
  intro p hp
  have h : env58552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58550_58552 : H12AffineEnvironment.transform 15 28705 env58550 = env58552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28705 env58550 == env58552) = true)

theorem identity58552 : scanCanonicalize (H12AffineFastState.compose env58552 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 94) := by decide +kernel

theorem selectedBound58552 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env58553 : List Nat := [2,4,8,16,32,64,128,94,512,1024,2048,4096,8192,16384,32768,28705,21583,262144,1025,32769,4097,61648,5135,283871,8329,5215,21551,4176,21534,2171,303359,21519,94,323754,1055,512]

theorem envBound58553 : H12AffineFastState.Bounded env58553 := by
  intro p hp
  have h : env58553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58552_58553 : H12AffineEnvironment.transform 7 94 env58552 = env58553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 94 env58552 == env58553) = true)

theorem identity58553 : scanCanonicalize (H12AffineFastState.compose env58553 (packedSelected [4,9,16] rootPS)) = affineNative (2^(17+1) ^^^ 5357) := by decide +kernel

theorem selectedBound58553 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env58554 : List Nat := [2,4,8,16,32,64,128,94,512,1024,2048,4096,8192,16384,32768,28705,21583,5357,1025,32769,4097,61648,5135,16434,8329,5215,21551,4176,21534,2171,46098,21519,94,58439,1055,512]

theorem envBound58554 : H12AffineFastState.Bounded env58554 := by
  intro p hp
  have h : env58554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58553_58554 : H12AffineEnvironment.transform 17 5357 env58553 = env58554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 5357 env58553 == env58554) = true)

theorem identity58554 : scanCanonicalize (H12AffineFastState.compose env58554 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 25677) := by decide +kernel

theorem selectedBound58554 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env58555 : List Nat := [2,4,8,16,32,64,128,94,512,1024,2048,4096,8192,16384,25677,28705,21583,5357,1025,25676,4097,5277,5135,16434,8329,5215,21551,4176,21534,2171,20575,21519,94,10,1055,512]

theorem envBound58555 : H12AffineFastState.Bounded env58555 := by
  intro p hp
  have h : env58555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58554_58555 : H12AffineEnvironment.transform 14 25677 env58554 = env58555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25677 env58554 == env58555) = true)

theorem identity58555 : scanCanonicalize (H12AffineFastState.compose env58555 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound58555 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env58556 : List Nat := [2,4,8,16,32,17,128,15,512,1024,2048,4096,8192,16384,25628,28705,21534,5308,1025,25629,4097,5277,5135,16434,8329,5134,21551,4097,21534,2090,20494,21519,15,10,1055,512]

theorem envBound58556 : H12AffineFastState.Bounded env58556 := by
  intro p hp
  have h : env58556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58555_58556 : H12AffineEnvironment.transform 5 17 env58555 = env58556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env58555 == env58556) = true)

theorem identity58556 : scanCanonicalize (H12AffineFastState.compose env58556 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound58556 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58557 : List Nat := [2,4,8,16,32,17,128,15,512,4,2048,4096,8192,16384,24600,28705,20506,4280,5,24601,4097,4249,4107,16434,8329,4106,20523,4097,20506,2090,20494,20491,15,10,27,512]

theorem envBound58557 : H12AffineFastState.Bounded env58557 := by
  intro p hp
  have h : env58557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58556_58557 : H12AffineEnvironment.transform 9 4 env58556 = env58557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env58556 == env58557) = true)

theorem identity58557 : scanCanonicalize (H12AffineFastState.compose env58557 (packedSelected [6] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound58557 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58558 : List Nat := [2,4,8,10,32,11,128,15,512,4,2048,4096,8192,16384,24578,28705,20480,4258,5,24579,4097,4227,4107,16424,8329,4106,20523,4097,20480,2090,20494,20491,15,10,1,512]

theorem envBound58558 : H12AffineFastState.Bounded env58558 := by
  intro p hp
  have h : env58558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58557_58558 : H12AffineEnvironment.transform 3 10 env58557 = env58558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env58557 == env58558) = true)

theorem identity58558 : scanCanonicalize (H12AffineFastState.compose env58558 (packedSelected [1,3,5,8,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 554) := by decide +kernel

theorem selectedBound58558 : packedSelected [1,3,5,8,10,12] rootPS < 2^1333 := by decide +kernel

def env58559 : List Nat := [2,4,8,10,32,11,128,15,512,4,554,4096,8192,16384,24578,28705,20480,4258,5,24579,4097,4227,4107,16424,8329,4106,20523,4097,20480,512,20494,20491,15,10,1,512]

theorem envBound58559 : H12AffineFastState.Bounded env58559 := by
  intro p hp
  have h : env58559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58558_58559 : H12AffineEnvironment.transform 10 554 env58558 = env58559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 554 env58558 == env58559) = true)

theorem identity58559 : scanCanonicalize (H12AffineFastState.compose env58559 (packedSelected [10,15] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound58559 : packedSelected [10,15] rootPS < 2^1333 := by decide +kernel

def env58560 : List Nat := [2,4,8,10,11,11,128,15,512,4,513,4096,8192,16384,24578,28682,20480,4233,5,24579,4097,4227,4107,16387,8329,4106,20480,4097,20480,512,20494,20491,15,10,1,512]

theorem envBound58560 : H12AffineFastState.Bounded env58560 := by
  intro p hp
  have h : env58560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58559_58560 : H12AffineEnvironment.transform 4 11 env58559 = env58560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env58559 == env58560) = true)

theorem identity58560 : scanCanonicalize (H12AffineFastState.compose env58560 (packedSelected [9,10] rootPS)) = affineNative (2^(11+1) ^^^ 524) := by decide +kernel

theorem selectedBound58560 : packedSelected [9,10] rootPS < 2^1333 := by decide +kernel

def env58561 : List Nat := [2,4,8,10,11,11,128,15,512,4,513,524,8192,16384,24578,25094,16908,645,5,24579,525,655,519,16387,8329,518,16908,525,16908,512,16898,16903,15,10,1,512]

theorem envBound58561 : H12AffineFastState.Bounded env58561 := by
  intro p hp
  have h : env58561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58560_58561 : H12AffineEnvironment.transform 11 524 env58560 = env58561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 524 env58560 == env58561) = true)

theorem identity58561 : scanCanonicalize (H12AffineFastState.compose env58561 (packedSelected [0,1,2,3,13] rootPS)) = affineNative (2^(12+1) ^^^ 15) := by decide +kernel

theorem selectedBound58561 : packedSelected [0,1,2,3,13] rootPS < 2^1333 := by decide +kernel

def env58562 : List Nat := [2,4,8,10,11,11,128,15,512,4,513,524,15,16384,16397,16905,16908,645,5,16396,525,655,519,16387,134,518,16908,525,16908,512,16898,16903,15,10,1,512]

theorem envBound58562 : H12AffineFastState.Bounded env58562 := by
  intro p hp
  have h : env58562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58561_58562 : H12AffineEnvironment.transform 12 15 env58561 = env58562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 15 env58561 == env58562) = true)

theorem identity58562 : scanCanonicalize (H12AffineFastState.compose env58562 (packedSelected [3] rootPS)) = affineNative (2^(13+1) ^^^ 136) := by decide +kernel

theorem selectedBound58562 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env58563 : List Nat := [2,4,8,10,11,11,128,15,512,4,513,524,15,136,133,641,644,645,5,132,525,655,519,139,134,518,644,525,644,512,650,655,15,10,1,512]

theorem envBound58563 : H12AffineFastState.Bounded env58563 := by
  intro p hp
  have h : env58563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58562_58563 : H12AffineEnvironment.transform 13 136 env58562 = env58563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 136 env58562 == env58563) = true)

theorem identity58563 : scanCanonicalize (H12AffineFastState.compose env58563 (packedSelected [1,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound58563 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env58564 : List Nat := [2,4,8,10,11,11,128,15,1,4,0,13,15,136,133,128,133,132,5,132,12,142,6,139,134,7,133,12,133,1,139,142,15,10,1,1]

theorem envBound58564 : H12AffineFastState.Bounded env58564 := by
  intro p hp
  have h : env58564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58563_58564 : H12AffineEnvironment.transform 8 1 env58563 = env58564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env58563 == env58564) = true)

theorem identity58564 : scanCanonicalize (H12AffineFastState.compose env58564 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound58564 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58565 : List Nat := [2,4,8,10,11,11,5,15,1,4,0,13,15,13,0,5,0,1,5,1,12,11,6,14,3,7,0,12,0,1,14,11,15,10,1,1]

theorem envBound58565 : H12AffineFastState.Bounded env58565 := by
  intro p hp
  have h : env58565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58564_58565 : H12AffineEnvironment.transform 6 5 env58564 = env58565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env58564 == env58565) = true)

def env58566 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,75057,262144,95614,32769,4097,61648,91505,284033,86518,5214,21872,90224,74815,96346,381312,75121,256,324085,1345,95103]

theorem envBound58566 : H12AffineFastState.Bounded env58566 := by
  intro p hp
  have h : env58566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58549_58566 : H12AffineEnvironment.transform 16 75057 env58549 = env58566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 75057 env58549 == env58566) = true)

def env58567 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,28704,21777,262144,1374,32769,4097,61648,5457,284033,8662,5214,21872,4176,21535,2170,303520,21841,256,324085,1345,863]

theorem envBound58567 : H12AffineFastState.Bounded env58567 := by
  intro p hp
  have h : env58567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58566_58567 : H12AffineEnvironment.transform 15 28704 env58566 = env58567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28704 env58566 == env58567) = true)

theorem identity58567 : scanCanonicalize (H12AffineFastState.compose env58567 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 95) := by decide +kernel

theorem selectedBound58567 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env58568 : List Nat := [2,4,8,16,32,64,128,95,512,1024,2048,4096,8192,16384,32768,28704,21582,262144,1025,32769,4097,61648,5134,283870,8329,5214,21551,4176,21535,2170,303359,21518,95,323754,1054,512]

theorem envBound58568 : H12AffineFastState.Bounded env58568 := by
  intro p hp
  have h : env58568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58567_58568 : H12AffineEnvironment.transform 7 95 env58567 = env58568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 95 env58567 == env58568) = true)

theorem identity58568 : scanCanonicalize (H12AffineFastState.compose env58568 (packedSelected [4,9,16] rootPS)) = affineNative (2^(17+1) ^^^ 5356) := by decide +kernel

theorem selectedBound58568 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env58569 : List Nat := [2,4,8,16,32,64,128,95,512,1024,2048,4096,8192,16384,32768,28704,21582,5356,1025,32769,4097,61648,5134,16434,8329,5214,21551,4176,21535,2170,46099,21518,95,58438,1054,512]

theorem envBound58569 : H12AffineFastState.Bounded env58569 := by
  intro p hp
  have h : env58569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58568_58569 : H12AffineEnvironment.transform 17 5356 env58568 = env58569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 5356 env58568 == env58569) = true)

theorem identity58569 : scanCanonicalize (H12AffineFastState.compose env58569 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 25677) := by decide +kernel

theorem selectedBound58569 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env58570 : List Nat := [2,4,8,16,32,64,128,95,512,1024,2048,4096,8192,16384,25677,28704,21582,5356,1025,25676,4097,5277,5134,16434,8329,5214,21551,4176,21535,2170,20574,21518,95,11,1054,512]

theorem envBound58570 : H12AffineFastState.Bounded env58570 := by
  intro p hp
  have h : env58570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58569_58570 : H12AffineEnvironment.transform 14 25677 env58569 = env58570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25677 env58569 == env58570) = true)

theorem identity58570 : scanCanonicalize (H12AffineFastState.compose env58570 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound58570 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env58571 : List Nat := [2,4,8,16,32,17,128,14,512,1024,2048,4096,8192,16384,25628,28704,21535,5309,1025,25629,4097,5277,5134,16434,8329,5135,21551,4097,21535,2091,20495,21518,14,11,1054,512]

end H12CloudChart2