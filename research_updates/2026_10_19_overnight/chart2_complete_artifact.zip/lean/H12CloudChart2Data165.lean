import H12CloudChart2Data164

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound41250 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env41251 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1345,262144,77935,13341,4096,477,16,266385,70886,78895,77840,1297,74814,81227,336012,262567,257,74798,1344,79471]

theorem envBound41251 : H12AffineFastState.Bounded env41251 := by
  intro p hp
  have h : env41251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41250_41251 : H12AffineEnvironment.transform 14 13340 env41250 = env41251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env41250 == env41251) = true)

def env41252 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1345,65664,77935,13341,4096,477,16,69649,70886,78895,77840,1297,74814,81227,8204,65831,257,74798,1344,79471]

theorem envBound41252 : H12AffineFastState.Bounded env41252 := by
  intro p hp
  have h : env41252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41251_41252 : H12AffineEnvironment.transform 17 65664 env41251 = env41252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env41251 == env41252) = true)

theorem identity41252 : scanCanonicalize (H12AffineFastState.compose env41252 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound41252 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env41253 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1296,9292,65536,1345,65664,73791,9293,80,477,16,65601,66742,74879,73792,1297,74814,77083,8204,65831,257,74798,1344,75327]

theorem envBound41253 : H12AffineFastState.Bounded env41253 := by
  intro p hp
  have h : env41253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41252_41253 : H12AffineEnvironment.transform 11 80 env41252 = env41253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env41252 == env41253) = true)

def env41254 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,0,8192,1296,9244,65536,1297,65664,73791,9245,0,397,16,65553,66742,74799,73744,1297,74814,77083,8204,65831,257,74798,1296,75327]

theorem envBound41254 : H12AffineFastState.Bounded env41254 := by
  intro p hp
  have h : env41254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41253_41254 : H12AffineEnvironment.transform 5 16 env41253 = env41254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env41253 == env41254) = true)

theorem identity41254 : scanCanonicalize (H12AffineFastState.compose env41254 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 8250) := by decide +kernel

theorem selectedBound41254 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env41255 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,0,8192,1296,9244,8250,1297,8378,5,9245,0,397,16,8235,9356,1045,42,1297,1028,3361,8204,8477,257,1044,1296,1541]

theorem envBound41255 : H12AffineFastState.Bounded env41255 := by
  intro p hp
  have h : env41255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41254_41255 : H12AffineEnvironment.transform 15 8250 env41254 = env41255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8250 env41254 == env41255) = true)

theorem identity41255 : scanCanonicalize (H12AffineFastState.compose env41255 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound41255 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env41256 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,8192,0,8460,8250,1,8378,5,8461,0,397,16,8235,8604,261,42,1,276,2097,8204,8477,257,260,0,789]

theorem envBound41256 : H12AffineFastState.Bounded env41256 := by
  intro p hp
  have h : env41256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41255_41256 : H12AffineEnvironment.transform 9 272 env41255 = env41256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env41255 == env41256) = true)

theorem identity41256 : scanCanonicalize (H12AffineFastState.compose env41256 (packedSelected [0,2,5,7,8,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound41256 : packedSelected [0,2,5,7,8,17,18] rootPS < 2^1333 := by decide +kernel

def env41257 : List Nat := [2,4,8,16,32,16,128,256,512,272,292,0,8192,0,8460,8250,1,8378,5,8461,0,397,16,8235,8604,261,42,1,276,277,8204,8477,257,260,0,789]

theorem envBound41257 : H12AffineFastState.Bounded env41257 := by
  intro p hp
  have h : env41257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41256_41257 : H12AffineEnvironment.transform 10 292 env41256 = env41257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env41256 == env41257) = true)

theorem identity41257 : scanCanonicalize (H12AffineFastState.compose env41257 (packedSelected [0,1,7,8,10,11,12,13,17] rootPS)) = affineNative (2^(12+1) ^^^ 51) := by decide +kernel

theorem selectedBound41257 : packedSelected [0,1,7,8,10,11,12,13,17] rootPS < 2^1333 := by decide +kernel

def env41258 : List Nat := [2,4,8,16,32,16,128,256,512,272,292,0,51,0,319,9,1,137,5,318,0,397,16,24,431,261,42,1,276,277,63,302,257,260,0,789]

theorem envBound41258 : H12AffineFastState.Bounded env41258 := by
  intro p hp
  have h : env41258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41257_41258 : H12AffineEnvironment.transform 12 51 env41257 = env41258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 51 env41257 == env41258) = true)

theorem identity41258 : scanCanonicalize (H12AffineFastState.compose env41258 (packedSelected [1,3,4,5,7,8,10,11] rootPS)) = affineNative (2^(7+1) ^^^ 63) := by decide +kernel

theorem selectedBound41258 : packedSelected [1,3,4,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env41259 : List Nat := [2,4,8,16,32,16,128,63,512,47,27,0,51,0,0,9,1,137,5,1,0,178,16,24,144,58,42,1,43,42,63,17,62,59,0,554]

theorem envBound41259 : H12AffineFastState.Bounded env41259 := by
  intro p hp
  have h : env41259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41258_41259 : H12AffineEnvironment.transform 7 63 env41258 = env41259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env41258 == env41259) = true)

theorem identity41259 : scanCanonicalize (H12AffineFastState.compose env41259 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound41259 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41260 : List Nat := [2,4,8,16,32,16,128,63,27,47,27,0,51,0,0,9,1,137,5,1,0,178,16,24,144,58,42,1,43,42,63,17,62,59,0,49]

theorem envBound41260 : H12AffineFastState.Bounded env41260 := by
  intro p hp
  have h : env41260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41259_41260 : H12AffineEnvironment.transform 8 27 env41259 = env41260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env41259 == env41260) = true)

theorem identity41260 : scanCanonicalize (H12AffineFastState.compose env41260 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound41260 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41261 : List Nat := [2,4,8,10,32,10,128,37,1,47,1,0,41,0,0,9,1,137,5,1,0,168,10,2,138,32,42,1,43,42,37,11,36,33,0,43]

theorem envBound41261 : H12AffineFastState.Bounded env41261 := by
  intro p hp
  have h : env41261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41260_41261 : H12AffineEnvironment.transform 3 10 env41260 = env41261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env41260 == env41261) = true)

theorem identity41261 : scanCanonicalize (H12AffineFastState.compose env41261 (packedSelected [1,5] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound41261 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env41262 : List Nat := [2,4,8,10,32,10,35,37,1,47,1,0,41,0,0,9,1,42,5,1,0,11,10,2,41,32,42,1,43,42,37,11,36,33,0,43]

theorem envBound41262 : H12AffineFastState.Bounded env41262 := by
  intro p hp
  have h : env41262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41261_41262 : H12AffineEnvironment.transform 6 35 env41261 = env41262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env41261 == env41262) = true)

theorem identity41262 : scanCanonicalize (H12AffineFastState.compose env41262 (packedSelected [0,1,4] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound41262 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env41263 : List Nat := [2,4,8,10,7,10,4,2,1,8,1,0,14,0,0,9,1,13,5,1,0,11,10,2,14,7,13,1,12,13,2,11,3,6,0,12]

theorem envBound41263 : H12AffineFastState.Bounded env41263 := by
  intro p hp
  have h : env41263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41262_41263 : H12AffineEnvironment.transform 4 7 env41262 = env41263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env41262 == env41263) = true)

theorem identity41263 : scanCanonicalize (H12AffineFastState.compose env41263 (packedSelected [0,1,7] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound41263 : packedSelected [0,1,7] rootPS < 2^1333 := by decide +kernel

def env41264 : List Nat := [2,4,5,7,7,7,4,2,1,5,1,0,3,0,0,4,1,0,5,1,0,6,7,2,3,7,0,1,1,0,2,6,3,6,0,1]

theorem envBound41264 : H12AffineFastState.Bounded env41264 := by
  intro p hp
  have h : env41264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41263_41264 : H12AffineEnvironment.transform 2 5 env41263 = env41264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env41263 == env41264) = true)

def env41265 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1,8192,1296,9245,65536,1296,65664,73791,9244,1,396,16,65552,66742,74798,73745,1297,74814,77083,8204,65831,257,74798,1297,75327]

theorem envBound41265 : H12AffineFastState.Bounded env41265 := by
  intro p hp
  have h : env41265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41253_41265 : H12AffineEnvironment.transform 5 17 env41253 = env41265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41253 == env41265) = true)

theorem identity41265 : scanCanonicalize (H12AffineFastState.compose env41265 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound41265 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env41266 : List Nat := [2,4,8,16,32,17,128,256,512,4,2048,1,8192,276,8217,65536,276,65664,73791,8216,1,396,16,65552,65714,73770,73745,277,73786,76063,8204,65831,257,73770,277,74299]

theorem envBound41266 : H12AffineFastState.Bounded env41266 := by
  intro p hp
  have h : env41266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41265_41266 : H12AffineEnvironment.transform 9 4 env41265 = env41266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env41265 == env41266) = true)

theorem identity41266 : scanCanonicalize (H12AffineFastState.compose env41266 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound41266 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env41267 : List Nat := [2,4,8,16,32,17,128,21,512,4,2048,1,8192,1,8217,65536,1,65664,73791,8216,1,153,16,65552,65714,73770,73745,0,73786,75786,8204,65586,20,73770,0,74299]

theorem envBound41267 : H12AffineFastState.Bounded env41267 := by
  intro p hp
  have h : env41267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41266_41267 : H12AffineEnvironment.transform 7 21 env41266 = env41267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env41266 == env41267) = true)

theorem identity41267 : scanCanonicalize (H12AffineFastState.compose env41267 (packedSelected [0,1,3,7,10,11,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 177) := by decide +kernel

theorem selectedBound41267 : packedSelected [0,1,3,7,10,11,17,19] rootPS < 2^1333 := by decide +kernel

def env41268 : List Nat := [2,4,8,16,32,17,128,21,512,4,2048,1,8192,1,8217,177,1,49,8334,8216,1,153,16,161,3,8347,8352,0,8331,10427,8204,131,20,8347,0,8842]

theorem envBound41268 : H12AffineFastState.Bounded env41268 := by
  intro p hp
  have h : env41268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41267_41268 : H12AffineEnvironment.transform 15 177 env41267 = env41268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 177 env41267 == env41268) = true)

theorem identity41268 : scanCanonicalize (H12AffineFastState.compose env41268 (packedSelected [0,2,3,5,7,10,11,13,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 2562) := by decide +kernel

theorem selectedBound41268 : packedSelected [0,2,3,5,7,10,11,13,15,17] rootPS < 2^1333 := by decide +kernel

def env41269 : List Nat := [2,4,8,16,32,17,128,21,512,4,2048,1,2562,1,2587,177,1,49,2700,2586,1,153,16,161,3,2713,2722,0,2697,697,2574,131,20,2713,0,2184]

theorem envBound41269 : H12AffineFastState.Bounded env41269 := by
  intro p hp
  have h : env41269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41268_41269 : H12AffineEnvironment.transform 12 2562 env41268 = env41269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2562 env41268 == env41269) = true)

theorem identity41269 : scanCanonicalize (H12AffineFastState.compose env41269 (packedSelected [0,2,7,10,11,13,15] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound41269 : packedSelected [0,2,7,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env41270 : List Nat := [2,4,8,16,32,17,128,21,136,4,2048,1,2186,1,2195,177,1,49,2052,2194,1,153,16,161,3,2065,2090,0,2049,49,2182,131,20,2065,0,2184]

theorem envBound41270 : H12AffineFastState.Bounded env41270 := by
  intro p hp
  have h : env41270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41269_41270 : H12AffineEnvironment.transform 8 136 env41269 = env41270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env41269 == env41270) = true)

theorem identity41270 : scanCanonicalize (H12AffineFastState.compose env41270 (packedSelected [2,3,8] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound41270 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env41271 : List Nat := [2,4,8,16,32,17,128,21,136,4,26,1,144,1,137,177,1,49,30,136,1,153,16,161,3,11,48,0,27,49,156,131,20,11,0,146]

theorem envBound41271 : H12AffineFastState.Bounded env41271 := by
  intro p hp
  have h : env41271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41270_41271 : H12AffineEnvironment.transform 10 26 env41270 = env41271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env41270 == env41271) = true)

theorem identity41271 : scanCanonicalize (H12AffineFastState.compose env41271 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound41271 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41272 : List Nat := [2,4,8,16,32,17,19,21,27,4,26,1,3,1,26,34,1,49,30,27,1,10,16,50,3,11,48,0,27,49,15,16,20,11,0,1]

theorem envBound41272 : H12AffineFastState.Bounded env41272 := by
  intro p hp
  have h : env41272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41271_41272 : H12AffineEnvironment.transform 6 19 env41271 = env41272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env41271 == env41272) = true)

theorem identity41272 : scanCanonicalize (H12AffineFastState.compose env41272 (packedSelected [0,1,4] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound41272 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env41273 : List Nat := [2,4,8,16,22,17,19,21,27,4,26,1,3,1,26,20,1,7,30,27,1,10,16,4,3,11,6,0,27,7,15,16,20,11,0,1]

theorem envBound41273 : H12AffineFastState.Bounded env41273 := by
  intro p hp
  have h : env41273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41272_41273 : H12AffineEnvironment.transform 4 22 env41272 = env41273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env41272 == env41273) = true)

theorem identity41273 : scanCanonicalize (H12AffineFastState.compose env41273 (packedSelected [0,3,9] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound41273 : packedSelected [0,3,9] rootPS < 2^1333 := by decide +kernel

def env41274 : List Nat := [2,2,8,16,16,17,19,19,27,2,26,1,3,1,26,18,1,1,24,27,1,10,16,2,3,11,0,0,27,1,9,16,18,11,0,1]

theorem envBound41274 : H12AffineFastState.Bounded env41274 := by
  intro p hp
  have h : env41274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41273_41274 : H12AffineEnvironment.transform 1 2 env41273 = env41274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env41273 == env41274) = true)

theorem identity41274 : scanCanonicalize (H12AffineFastState.compose env41274 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound41274 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41275 : List Nat := [2,2,8,10,10,11,9,9,1,2,0,1,3,1,0,8,1,1,2,1,1,10,10,2,3,11,0,0,1,1,9,10,8,11,0,1]

theorem envBound41275 : H12AffineFastState.Bounded env41275 := by
  intro p hp
  have h : env41275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41274_41275 : H12AffineEnvironment.transform 3 10 env41274 = env41275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env41274 == env41275) = true)

def env41276 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1345,65665,77935,13341,4096,477,16,69648,70886,78895,77840,1297,74814,81227,8205,65830,257,74798,1344,79471]

theorem envBound41276 : H12AffineFastState.Bounded env41276 := by
  intro p hp
  have h : env41276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41251_41276 : H12AffineEnvironment.transform 17 65665 env41251 = env41276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env41251 == env41276) = true)

theorem identity41276 : scanCanonicalize (H12AffineFastState.compose env41276 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound41276 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env41277 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,1,12557,65536,80,65665,77935,12556,4096,477,16,69648,70135,78142,77840,0,74031,79962,8205,65830,257,74047,81,78718]

theorem envBound41277 : H12AffineFastState.Bounded env41277 := by
  intro p hp
  have h : env41277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41276_41277 : H12AffineEnvironment.transform 9 273 env41276 = env41277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env41276 == env41277) = true)

def env41278 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,4096,8192,1,12557,65536,0,65665,77887,12556,4096,397,16,69648,70055,78142,77840,0,74031,79882,8205,65830,257,74047,1,78638]

theorem envBound41278 : H12AffineFastState.Bounded env41278 := by
  intro p hp
  have h : env41278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41277_41278 : H12AffineEnvironment.transform 5 16 env41277 = env41278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env41277 == env41278) = true)

theorem identity41278 : scanCanonicalize (H12AffineFastState.compose env41278 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 12346) := by decide +kernel

theorem selectedBound41278 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env41279 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,4096,8192,1,12557,12346,0,12475,5,12556,4096,397,16,8234,8605,260,42,0,4373,2096,8205,12572,257,4357,1,788]

theorem envBound41279 : H12AffineFastState.Bounded env41279 := by
  intro p hp
  have h : env41279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41278_41279 : H12AffineEnvironment.transform 15 12346 env41278 = env41279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12346 env41278 == env41279) = true)

theorem identity41279 : scanCanonicalize (H12AffineFastState.compose env41279 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound41279 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env41280 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,277,8192,1,8216,8495,0,8622,5,8217,277,397,16,8234,8605,260,42,0,0,2096,8205,8201,257,16,1,788]

theorem envBound41280 : H12AffineFastState.Bounded env41280 := by
  intro p hp
  have h : env41280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41279_41280 : H12AffineEnvironment.transform 11 277 env41279 = env41280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env41279 == env41280) = true)

theorem identity41280 : scanCanonicalize (H12AffineFastState.compose env41280 (packedSelected [0,2,3,7,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound41280 : packedSelected [0,2,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env41281 : List Nat := [2,4,8,16,32,16,128,256,512,273,512,277,8192,1,8216,8495,0,8622,5,8217,277,397,16,8234,8605,260,42,0,0,560,8205,8201,257,16,1,788]

theorem envBound41281 : H12AffineFastState.Bounded env41281 := by
  intro p hp
  have h : env41281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41280_41281 : H12AffineEnvironment.transform 10 512 env41280 = env41281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env41280 == env41281) = true)

theorem identity41281 : scanCanonicalize (H12AffineFastState.compose env41281 (packedSelected [1,3,10,17,19] rootPS)) = affineNative (2^(12+1) ^^^ 699) := by decide +kernel

theorem selectedBound41281 : packedSelected [1,3,10,17,19] rootPS < 2^1333 := by decide +kernel

def env41282 : List Nat := [2,4,8,16,32,16,128,256,512,273,512,277,699,1,675,916,0,789,5,674,277,397,16,657,806,260,42,0,0,560,694,690,257,16,1,788]

theorem envBound41282 : H12AffineFastState.Bounded env41282 := by
  intro p hp
  have h : env41282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41281_41282 : H12AffineEnvironment.transform 12 699 env41281 = env41282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 699 env41281 == env41282) = true)

theorem identity41282 : scanCanonicalize (H12AffineFastState.compose env41282 (packedSelected [1,3,12,15,17] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound41282 : packedSelected [1,3,12,15,17] rootPS < 2^1333 := by decide +kernel

def env41283 : List Nat := [2,4,8,16,32,16,128,256,1,273,1,277,186,1,162,405,0,276,5,163,277,397,16,144,295,260,42,0,0,49,183,179,257,16,1,277]

theorem envBound41283 : H12AffineFastState.Bounded env41283 := by
  intro p hp
  have h : env41283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41282_41283 : H12AffineEnvironment.transform 8 1 env41282 = env41283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env41282 == env41283) = true)

theorem identity41283 : scanCanonicalize (H12AffineFastState.compose env41283 (packedSelected [3,8] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound41283 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env41284 : List Nat := [2,4,8,16,32,16,128,15,1,30,1,26,186,1,162,154,0,27,5,163,26,130,16,144,40,11,42,0,0,49,183,179,14,16,1,26]

theorem envBound41284 : H12AffineFastState.Bounded env41284 := by
  intro p hp
  have h : env41284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41283_41284 : H12AffineEnvironment.transform 7 15 env41283 = env41284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env41283 == env41284) = true)

theorem identity41284 : scanCanonicalize (H12AffineFastState.compose env41284 (packedSelected [1,2,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound41284 : packedSelected [1,2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env41285 : List Nat := [2,4,8,16,32,16,9,15,1,30,1,26,51,1,43,19,0,27,5,42,26,11,16,25,40,11,42,0,0,49,62,58,14,16,1,26]

theorem envBound41285 : H12AffineFastState.Bounded env41285 := by
  intro p hp
  have h : env41285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41284_41285 : H12AffineEnvironment.transform 6 9 env41284 = env41285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env41284 == env41285) = true)

theorem identity41285 : scanCanonicalize (H12AffineFastState.compose env41285 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound41285 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41286 : List Nat := [2,4,8,16,11,16,9,15,1,30,1,26,24,1,0,19,0,27,5,1,26,11,16,25,3,11,1,0,0,26,21,17,14,16,1,26]

theorem envBound41286 : H12AffineFastState.Bounded env41286 := by
  intro p hp
  have h : env41286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41285_41286 : H12AffineEnvironment.transform 4 11 env41285 = env41286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env41285 == env41286) = true)

theorem identity41286 : scanCanonicalize (H12AffineFastState.compose env41286 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound41286 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41287 : List Nat := [2,3,8,16,11,16,9,8,1,25,1,26,24,1,0,19,0,27,2,1,26,11,16,25,3,11,1,0,0,26,18,17,9,16,1,26]

theorem envBound41287 : H12AffineFastState.Bounded env41287 := by
  intro p hp
  have h : env41287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41286_41287 : H12AffineEnvironment.transform 1 3 env41286 = env41287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env41286 == env41287) = true)

theorem identity41287 : scanCanonicalize (H12AffineFastState.compose env41287 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound41287 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41288 : List Nat := [2,3,8,11,11,11,9,8,1,2,1,1,3,1,0,8,0,0,2,1,1,11,11,2,3,11,1,0,0,1,9,10,9,11,1,1]

theorem envBound41288 : H12AffineFastState.Bounded env41288 := by
  intro p hp
  have h : env41288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41287_41288 : H12AffineEnvironment.transform 3 11 env41287 = env41288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env41287 == env41288) = true)

def env41289 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,4096,8192,1,12557,65536,1,65665,77886,12556,4096,396,16,69648,70054,78142,77840,0,74031,79883,8205,65830,257,74047,0,78639]

theorem envBound41289 : H12AffineFastState.Bounded env41289 := by
  intro p hp
  have h : env41289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41277_41289 : H12AffineEnvironment.transform 5 17 env41277 = env41289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41277 == env41289) = true)

theorem identity41289 : scanCanonicalize (H12AffineFastState.compose env41289 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound41289 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env41290 : List Nat := [2,4,8,16,32,17,128,21,512,4,2048,4096,8192,1,12312,65536,1,65665,77886,12313,4096,153,16,69648,69811,77867,77840,0,73786,79883,8205,65587,20,73770,0,78394]

theorem envBound41290 : H12AffineFastState.Bounded env41290 := by
  intro p hp
  have h : env41290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41289_41290 : H12AffineEnvironment.transform 7 21 env41289 = env41290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env41289 == env41290) = true)

theorem identity41290 : scanCanonicalize (H12AffineFastState.compose env41290 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 8251) := by decide +kernel

theorem selectedBound41290 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env41291 : List Nat := [2,4,8,16,32,17,128,21,512,4,2048,4096,8192,1,12312,8251,1,8378,4101,12313,4096,153,16,12331,12424,4112,4139,0,1,6192,8205,8200,20,17,0,4609]

theorem envBound41291 : H12AffineFastState.Bounded env41291 := by
  intro p hp
  have h : env41291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41290_41291 : H12AffineEnvironment.transform 15 8251 env41290 = env41291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8251 env41290 == env41291) = true)

theorem identity41291 : scanCanonicalize (H12AffineFastState.compose env41291 (packedSelected [10,11,13,17,18,19] rootPS)) = affineNative (2^(11+1) ^^^ 2096) := by decide +kernel

theorem selectedBound41291 : packedSelected [10,11,13,17,18,19] rootPS < 2^1333 := by decide +kernel

def env41292 : List Nat := [2,4,8,16,32,17,128,21,512,4,2048,2096,8192,1,10280,8251,1,8378,2101,10281,2096,153,16,10267,10424,2080,2075,0,1,0,8205,8200,20,17,0,2609]

theorem envBound41292 : H12AffineFastState.Bounded env41292 := by
  intro p hp
  have h : env41292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41291_41292 : H12AffineEnvironment.transform 11 2096 env41291 = env41292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2096 env41291 == env41292) = true)

theorem identity41292 : scanCanonicalize (H12AffineFastState.compose env41292 (packedSelected [1,2,3,10,12,13,17] rootPS)) = affineNative (2^(12+1) ^^^ 145) := by decide +kernel

theorem selectedBound41292 : packedSelected [1,2,3,10,12,13,17] rootPS < 2^1333 := by decide +kernel

def env41293 : List Nat := [2,4,8,16,32,17,128,21,512,4,2048,2096,145,1,2233,170,1,43,2101,2232,2096,153,16,2186,2089,2080,2075,0,1,0,156,153,20,17,0,2609]

theorem envBound41293 : H12AffineFastState.Bounded env41293 := by
  intro p hp
  have h : env41293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41292_41293 : H12AffineEnvironment.transform 12 145 env41292 = env41293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 145 env41292 == env41293) = true)

theorem identity41293 : scanCanonicalize (H12AffineFastState.compose env41293 (packedSelected [0,5,8,9,10] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound41293 : packedSelected [0,5,8,9,10] rootPS < 2^1333 := by decide +kernel

def env41294 : List Nat := [2,4,8,16,32,17,128,21,43,4,2048,2096,145,1,2233,170,1,43,2101,2232,2096,153,16,2186,2089,2080,2075,0,1,0,156,153,20,17,0,2074]

theorem envBound41294 : H12AffineFastState.Bounded env41294 := by
  intro p hp
  have h : env41294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41293_41294 : H12AffineEnvironment.transform 8 43 env41293 = env41294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env41293 == env41294) = true)

theorem identity41294 : scanCanonicalize (H12AffineFastState.compose env41294 (packedSelected [3,5] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound41294 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env41295 : List Nat := [2,4,8,16,32,17,18,21,43,4,2048,2096,3,1,2091,56,1,43,2101,2090,2096,11,16,2072,2089,2080,2075,0,1,0,14,11,20,17,0,2074]

theorem envBound41295 : H12AffineFastState.Bounded env41295 := by
  intro p hp
  have h : env41295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41294_41295 : H12AffineEnvironment.transform 6 18 env41294 = env41295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env41294 == env41295) = true)

theorem identity41295 : scanCanonicalize (H12AffineFastState.compose env41295 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound41295 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env41296 : List Nat := [2,4,8,16,10,17,18,21,1,4,2048,2074,3,1,2049,18,1,1,2079,2048,2074,11,16,2072,2051,2058,2075,0,1,0,14,11,20,17,0,2074]

theorem envBound41296 : H12AffineFastState.Bounded env41296 := by
  intro p hp
  have h : env41296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41295_41296 : H12AffineEnvironment.transform 4 10 env41295 = env41296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env41295 == env41296) = true)

theorem identity41296 : scanCanonicalize (H12AffineFastState.compose env41296 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound41296 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41297 : List Nat := [2,4,8,16,10,17,18,21,1,4,1,27,3,1,0,18,1,1,30,1,27,11,16,25,2,11,26,0,1,0,14,11,20,17,0,27]

theorem envBound41297 : H12AffineFastState.Bounded env41297 := by
  intro p hp
  have h : env41297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41296_41297 : H12AffineEnvironment.transform 10 1 env41296 = env41297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env41296 == env41297) = true)

def env41298 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1344,262144,77934,32769,4096,46528,16,266384,70887,78894,77840,1297,74814,81226,365713,308666,257,74798,1344,79470]

theorem envBound41298 : H12AffineFastState.Bounded env41298 := by
  intro p hp
  have h : env41298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41249_41298 : H12AffineEnvironment.transform 13 1297 env41249 = env41298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env41249 == env41298) = true)

theorem identity41298 : scanCanonicalize (H12AffineFastState.compose env41298 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32883) := by decide +kernel

theorem selectedBound41298 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env41299 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,32883,1344,262144,45085,32769,4096,46528,16,266384,38036,46173,45155,1297,42061,48441,267490,308666,257,42077,1344,46621]

theorem envBound41299 : H12AffineFastState.Bounded env41299 := by
  intro p hp
  have h : env41299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41298_41299 : H12AffineEnvironment.transform 15 32883 env41298 = env41299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32883 env41298 == env41299) = true)

def env41300 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32883,1344,262144,42333,32769,1344,41088,16,263632,33236,41245,42275,1297,42061,43129,262562,303354,257,42077,1344,41821]

theorem envBound41300 : H12AffineFastState.Bounded env41300 := by
  intro p hp
  have h : env41300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41299_41300 : H12AffineEnvironment.transform 11 1344 env41299 = env41300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env41299 == env41300) = true)

theorem identity41300 : scanCanonicalize (H12AffineFastState.compose env41300 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 324) := by decide +kernel

theorem selectedBound41300 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env41301 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,324,311,1344,262144,9241,325,1344,8644,16,263632,144,8281,9319,1297,9481,10557,262562,270782,257,9497,1344,8729]

theorem envBound41301 : H12AffineFastState.Bounded env41301 := by
  intro p hp
  have h : env41301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41300_41301 : H12AffineEnvironment.transform 14 324 env41300 = env41301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 324 env41300 == env41301) = true)

theorem identity41301 : scanCanonicalize (H12AffineFastState.compose env41301 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(10+1) ^^^ 1883) := by decide +kernel

theorem selectedBound41301 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env41302 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1883,1344,8192,1297,324,311,1344,262144,9241,325,1344,8644,16,263632,144,8281,9319,1297,9481,9830,262562,270782,257,9497,1344,8729]

theorem envBound41302 : H12AffineFastState.Bounded env41302 := by
  intro p hp
  have h : env41302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41301_41302 : H12AffineEnvironment.transform 10 1883 env41301 = env41302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1883 env41301 == env41302) = true)

def env41303 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32883,1344,262144,42332,32769,1345,41089,16,263633,33237,41244,42274,1297,42061,43128,262563,303355,257,42077,1344,41820]

theorem envBound41303 : H12AffineFastState.Bounded env41303 := by
  intro p hp
  have h : env41303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41299_41303 : H12AffineEnvironment.transform 11 1345 env41299 = env41303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env41299 == env41303) = true)

theorem identity41303 : scanCanonicalize (H12AffineFastState.compose env41303 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 438) := by decide +kernel

theorem selectedBound41303 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env41304 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32883,1344,438,42332,32769,1345,41089,16,1127,33237,41244,42274,1297,42061,43128,21,41293,257,42077,1344,41820]

theorem envBound41304 : H12AffineFastState.Bounded env41304 := by
  intro p hp
  have h : env41304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41303_41304 : H12AffineEnvironment.transform 17 438 env41303 = env41304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 438 env41303 == env41304) = true)

theorem identity41304 : scanCanonicalize (H12AffineFastState.compose env41304 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound41304 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env41305 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,8540,8495,1344,438,1024,8541,1345,477,16,1127,8329,64,1150,1297,1297,2340,21,17,257,1281,1344,512]

theorem envBound41305 : H12AffineFastState.Bounded env41305 := by
  intro p hp
  have h : env41305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41304_41305 : H12AffineEnvironment.transform 14 8540 env41304 = env41305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env41304 == env41305) = true)

theorem identity41305 : scanCanonicalize (H12AffineFastState.compose env41305 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound41305 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env41306 : List Nat := [2,4,8,16,32,64,128,256,512,84,2048,277,8192,325,8540,8495,276,438,84,8541,277,477,16,51,8329,64,42,325,325,2340,21,17,257,341,276,512]

theorem envBound41306 : H12AffineFastState.Bounded env41306 := by
  intro p hp
  have h : env41306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41305_41306 : H12AffineEnvironment.transform 9 84 env41305 = env41306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env41305 == env41306) = true)

theorem identity41306 : scanCanonicalize (H12AffineFastState.compose env41306 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 981) := by decide +kernel

theorem selectedBound41306 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41307 : List Nat := [2,4,8,16,32,64,128,256,512,84,2048,277,981,325,649,762,276,438,84,648,277,477,16,51,860,64,42,325,325,2340,21,17,257,341,276,512]

theorem envBound41307 : H12AffineFastState.Bounded env41307 := by
  intro p hp
  have h : env41307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41306_41307 : H12AffineEnvironment.transform 12 981 env41306 = env41307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 981 env41306 == env41307) = true)

theorem identity41307 : scanCanonicalize (H12AffineFastState.compose env41307 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound41307 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env41308 : List Nat := [2,4,8,16,32,17,128,256,512,5,2048,277,900,276,649,683,276,438,5,648,277,396,16,51,781,17,42,276,276,2340,21,17,257,260,276,512]

theorem envBound41308 : H12AffineFastState.Bounded env41308 := by
  intro p hp
  have h : env41308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41307_41308 : H12AffineEnvironment.transform 5 17 env41307 = env41308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41307 == env41308) = true)

theorem identity41308 : scanCanonicalize (H12AffineFastState.compose env41308 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound41308 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env41309 : List Nat := [2,4,8,16,32,17,128,21,512,5,2048,0,657,1,649,683,1,163,5,648,0,153,16,51,536,17,42,1,1,2097,21,17,20,17,1,512]

theorem envBound41309 : H12AffineFastState.Bounded env41309 := by
  intro p hp
  have h : env41309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41308_41309 : H12AffineEnvironment.transform 7 21 env41308 = env41309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env41308 == env41309) = true)

theorem identity41309 : scanCanonicalize (H12AffineFastState.compose env41309 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 660) := by decide +kernel

theorem selectedBound41309 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41310 : List Nat := [2,4,8,16,32,17,128,21,512,5,660,0,657,1,649,683,1,163,5,648,0,153,16,51,536,17,42,1,1,677,21,17,20,17,1,512]

theorem envBound41310 : H12AffineFastState.Bounded env41310 := by
  intro p hp
  have h : env41310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41309_41310 : H12AffineEnvironment.transform 10 660 env41309 = env41310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 660 env41309 == env41310) = true)

theorem identity41310 : scanCanonicalize (H12AffineFastState.compose env41310 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound41310 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env41311 : List Nat := [2,4,8,16,32,17,57,21,512,5,557,0,552,1,560,530,1,26,5,561,0,32,16,51,536,17,42,1,1,540,21,17,20,17,1,512]

theorem envBound41311 : H12AffineFastState.Bounded env41311 := by
  intro p hp
  have h : env41311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41310_41311 : H12AffineEnvironment.transform 6 57 env41310 = env41311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env41310 == env41311) = true)

theorem identity41311 : scanCanonicalize (H12AffineFastState.compose env41311 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 29) := by decide +kernel

theorem selectedBound41311 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41312 : List Nat := [2,4,8,16,32,17,57,21,29,5,48,0,53,1,45,15,1,26,5,44,0,32,16,51,5,17,42,1,1,1,21,17,20,17,1,29]

theorem envBound41312 : H12AffineFastState.Bounded env41312 := by
  intro p hp
  have h : env41312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41311_41312 : H12AffineEnvironment.transform 8 29 env41311 = env41312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 29 env41311 == env41312) = true)

def env41313 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,16777216,533641,672785,17245633,148800,545089,96347,16876545,16819498,257,545105,1345,525824]

theorem envBound41313 : H12AffineFastState.Bounded env41313 := by
  intro p hp
  have h : env41313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41064_41313 : H12AffineEnvironment.transform 26 17245633 env41064 = env41313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env41064 == env41313) = true)

theorem identity41313 : scanCanonicalize (H12AffineFastState.compose env41313 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 74862) := by decide +kernel

theorem selectedBound41313 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env41314 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,524288,32769,4096,61649,91183,16777216,533641,614527,17039791,90414,545089,96347,16876545,16819498,257,545105,1345,525824]

theorem envBound41314 : H12AffineFastState.Bounded env41314 := by
  intro p hp
  have h : env41314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41313_41314 : H12AffineEnvironment.transform 16 74862 env41313 = env41314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 74862 env41313 == env41314) = true)

def env41315 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,524288,32769,4096,61649,91183,123164,533641,614527,385203,90414,545089,96347,25885,82998,257,545105,1345,525824]

theorem envBound41315 : H12AffineFastState.Bounded env41315 := by
  intro p hp
  have h : env41315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41314_41315 : H12AffineEnvironment.transform 23 123164 env41314 = env41315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123164 env41314 == env41315) = true)

def env41316 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,21584,32769,4096,61649,91183,123164,28889,78895,385203,90414,1297,96347,25885,82998,257,1281,1345,21072]

theorem envBound41316 : H12AffineFastState.Bounded env41316 := by
  intro p hp
  have h : env41316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41315_41316 : H12AffineEnvironment.transform 18 21584 env41315 = env41316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env41315 == env41316) = true)

theorem identity41316 : scanCanonicalize (H12AffineFastState.compose env41316 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25677) := by decide +kernel

theorem selectedBound41316 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env41317 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25677,65536,74862,262144,21584,25676,4096,5276,91183,66897,28889,78895,328958,90414,1297,96347,25885,82998,257,1281,1345,21072]

theorem envBound41317 : H12AffineFastState.Bounded env41317 := by
  intro p hp
  have h : env41317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41316_41317 : H12AffineEnvironment.transform 14 25677 env41316 = env41317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25677 env41316 == env41317) = true)

def env41318 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74862,262144,4416,8540,4096,5276,74047,66897,13769,78895,328958,74814,1297,81227,8205,65830,257,1281,1345,5952]

theorem envBound41318 : H12AffineFastState.Bounded env41318 := by
  intro p hp
  have h : env41318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41317_41318 : H12AffineEnvironment.transform 13 1296 env41317 = env41318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env41317 == env41318) = true)

def env41319 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74862,65664,4416,8540,4096,5276,74047,66897,13769,78895,1150,74814,1297,81227,8205,65830,257,1281,1345,5952]

theorem envBound41319 : H12AffineFastState.Bounded env41319 := by
  intro p hp
  have h : env41319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41318_41319 : H12AffineEnvironment.transform 17 65664 env41318 = env41319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env41318 == env41319) = true)

theorem identity41319 : scanCanonicalize (H12AffineFastState.compose env41319 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5239) := by decide +kernel

theorem selectedBound41319 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env41320 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,5239,12313,5367,4416,8540,4096,5276,13640,4390,13769,8280,1150,12361,1297,10556,8205,5457,257,1281,1345,5952]

theorem envBound41320 : H12AffineFastState.Bounded env41320 := by
  intro p hp
  have h : env41320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41319_41320 : H12AffineEnvironment.transform 15 5239 env41319 = env41320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5239 env41319 == env41320) = true)

def env41321 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5464,1296,5125,5239,1345,5367,4416,5124,4096,5276,16,4390,145,5376,1150,1297,1297,7268,5461,5457,257,1281,1345,5952]

theorem envBound41321 : H12AffineFastState.Bounded env41321 := by
  intro p hp
  have h : env41321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41320_41321 : H12AffineEnvironment.transform 12 5464 env41320 = env41321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5464 env41320 == env41321) = true)

theorem identity41321 : scanCanonicalize (H12AffineFastState.compose env41321 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound41321 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env41322 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,1368,1296,1029,1143,1345,1271,320,1028,0,1180,16,294,145,1280,1150,1297,1297,3172,1365,1361,257,1281,1345,1856]

theorem envBound41322 : H12AffineFastState.Bounded env41322 := by
  intro p hp
  have h : env41322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41321_41322 : H12AffineEnvironment.transform 11 0 env41321 = env41322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env41321 == env41322) = true)

theorem identity41322 : scanCanonicalize (H12AffineFastState.compose env41322 (packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 951) := by decide +kernel

theorem selectedBound41322 : packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env41323 : List Nat := [2,4,8,16,32,64,128,256,512,1024,951,0,1368,1296,1029,1143,1345,1271,320,1028,0,1180,16,294,145,1280,1150,1297,1297,2003,1365,1361,257,1281,1345,1856]

theorem envBound41323 : H12AffineFastState.Bounded env41323 := by
  intro p hp
  have h : env41323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41322_41323 : H12AffineEnvironment.transform 10 951 env41322 = env41323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 951 env41322 == env41323) = true)

theorem identity41323 : scanCanonicalize (H12AffineFastState.compose env41323 (packedSelected [0,1,2,4,5,7,9,10,11,13,23] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound41323 : packedSelected [0,1,2,4,5,7,9,10,11,13,23] rootPS < 2^1333 := by decide +kernel

def env41324 : List Nat := [2,4,8,16,32,64,128,256,512,321,951,0,25,81,324,310,0,438,320,325,0,477,16,294,145,65,319,80,80,658,20,16,257,64,0,513]

theorem envBound41324 : H12AffineFastState.Bounded env41324 := by
  intro p hp
  have h : env41324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41323_41324 : H12AffineEnvironment.transform 9 321 env41323 = env41324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env41323 == env41324) = true)

theorem identity41324 : scanCanonicalize (H12AffineFastState.compose env41324 (packedSelected [1,8,10,12,13] rootPS)) = affineNative (2^(8+1) ^^^ 470) := by decide +kernel

theorem selectedBound41324 : packedSelected [1,8,10,12,13] rootPS < 2^1333 := by decide +kernel

def env41325 : List Nat := [2,4,8,16,32,64,128,256,470,321,97,0,25,81,324,310,0,438,320,325,0,477,16,294,145,65,319,80,80,324,20,16,257,64,0,471]

theorem envBound41325 : H12AffineFastState.Bounded env41325 := by
  intro p hp
  have h : env41325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41324_41325 : H12AffineEnvironment.transform 8 470 env41324 = env41325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 470 env41324 == env41325) = true)

theorem identity41325 : scanCanonicalize (H12AffineFastState.compose env41325 (packedSelected [0,2,3,5,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 60) := by decide +kernel

theorem selectedBound41325 : packedSelected [0,2,3,5,8,10] rootPS < 2^1333 := by decide +kernel

def env41326 : List Nat := [2,4,8,16,32,64,128,60,234,125,97,0,25,81,120,10,0,138,124,121,0,225,16,26,145,65,3,80,80,120,20,16,61,64,0,235]

theorem envBound41326 : H12AffineFastState.Bounded env41326 := by
  intro p hp
  have h : env41326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41325_41326 : H12AffineEnvironment.transform 7 60 env41325 = env41326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 60 env41325 == env41326) = true)

theorem identity41326 : scanCanonicalize (H12AffineFastState.compose env41326 (packedSelected [0,1,2,5,8,12] rootPS)) = affineNative (2^(4+1) ^^^ 19) := by decide +kernel

theorem selectedBound41326 : packedSelected [0,1,2,5,8,12] rootPS < 2^1333 := by decide +kernel

def env41327 : List Nat := [2,4,8,16,19,64,128,15,217,78,82,0,25,81,75,10,0,138,79,74,0,210,16,26,145,65,3,80,80,75,20,16,14,64,0,216]

theorem envBound41327 : H12AffineFastState.Bounded env41327 := by
  intro p hp
  have h : env41327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41326_41327 : H12AffineEnvironment.transform 4 19 env41326 = env41327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 19 env41326 == env41327) = true)

theorem identity41327 : scanCanonicalize (H12AffineFastState.compose env41327 (packedSelected [2,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 8) := by decide +kernel

theorem selectedBound41327 : packedSelected [2,4,5] rootPS < 2^1333 := by decide +kernel

def env41328 : List Nat := [2,4,8,16,19,8,128,15,145,6,26,0,25,25,3,10,0,138,7,2,0,154,16,26,145,9,3,24,24,3,20,16,14,8,0,144]

theorem envBound41328 : H12AffineFastState.Bounded env41328 := by
  intro p hp
  have h : env41328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41327_41328 : H12AffineEnvironment.transform 5 8 env41327 = env41328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 8 env41327 == env41328) = true)

theorem identity41328 : scanCanonicalize (H12AffineFastState.compose env41328 (packedSelected [1,2,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound41328 : packedSelected [1,2,4] rootPS < 2^1333 := by decide +kernel

def env41329 : List Nat := [2,4,8,10,9,8,128,15,139,6,0,0,3,3,3,10,0,138,7,2,0,128,10,0,139,9,3,2,2,3,14,10,14,8,0,138]

theorem envBound41329 : H12AffineFastState.Bounded env41329 := by
  intro p hp
  have h : env41329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41328_41329 : H12AffineEnvironment.transform 3 10 env41328 = env41329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env41328 == env41329) = true)

theorem identity41329 : scanCanonicalize (H12AffineFastState.compose env41329 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound41329 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env41330 : List Nat := [2,4,8,10,9,8,2,15,9,6,0,0,3,3,3,10,0,8,7,2,0,2,10,0,9,9,3,2,2,3,14,10,14,8,0,8]

theorem envBound41330 : H12AffineFastState.Bounded env41330 := by
  intro p hp
  have h : env41330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41329_41330 : H12AffineEnvironment.transform 6 2 env41329 = env41330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env41329 == env41330) = true)

theorem identity41330 : scanCanonicalize (H12AffineFastState.compose env41330 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound41330 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41331 : List Nat := [2,3,8,10,9,8,2,8,9,1,0,0,3,3,3,10,0,8,0,2,0,2,10,0,9,9,3,2,2,3,9,10,9,8,0,8]

theorem envBound41331 : H12AffineFastState.Bounded env41331 := by
  intro p hp
  have h : env41331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41330_41331 : H12AffineEnvironment.transform 1 3 env41330 = env41331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env41330 == env41331) = true)

theorem identity41331 : scanCanonicalize (H12AffineFastState.compose env41331 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound41331 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41332 : List Nat := [2,3,3,1,2,3,2,3,2,1,0,0,3,3,3,1,0,3,0,2,0,2,1,0,2,2,3,2,2,3,2,1,2,3,0,3]

theorem envBound41332 : H12AffineFastState.Bounded env41332 := by
  intro p hp
  have h : env41332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41331_41332 : H12AffineEnvironment.transform 2 3 env41331 = env41332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env41331 == env41332) = true)

theorem identity41332 : scanCanonicalize (H12AffineFastState.compose env41332 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound41332 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env41333 : List Nat := [1,0,0,1,1,0,1,0,1,1,0,0,0,0,0,1,0,0,0,1,0,1,1,0,1,1,0,1,1,0,1,1,1,0,0,0]

theorem envBound41333 : H12AffineFastState.Bounded env41333 := by
  intro p hp
  have h : env41333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41332_41333 : H12AffineEnvironment.transform 0 1 env41332 = env41333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env41332 == env41333) = true)

def env41334 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5465,1296,5124,5239,1344,5367,4416,5125,4096,5276,17,4390,144,5377,1150,1296,1297,7269,5460,5457,257,1281,1345,5952]

theorem envBound41334 : H12AffineFastState.Bounded env41334 := by
  intro p hp
  have h : env41334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41320_41334 : H12AffineEnvironment.transform 12 5465 env41320 = env41334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5465 env41320 == env41334) = true)

theorem identity41334 : scanCanonicalize (H12AffineFastState.compose env41334 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound41334 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env41335 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,4096,4445,276,4096,4211,324,4339,4416,4097,4096,4248,17,4390,144,4357,122,276,277,6241,4432,4437,257,261,325,4932]

theorem envBound41335 : H12AffineFastState.Bounded env41335 := by
  intro p hp
  have h : env41335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41334_41335 : H12AffineEnvironment.transform 9 4 env41334 = env41335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env41334 == env41335) = true)

theorem identity41335 : scanCanonicalize (H12AffineFastState.compose env41335 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 324) := by decide +kernel

theorem selectedBound41335 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env41336 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,324,25,276,324,311,324,439,4,325,324,476,17,98,144,65,122,276,277,2341,20,17,257,261,325,512]

theorem envBound41336 : H12AffineFastState.Bounded env41336 := by
  intro p hp
  have h : env41336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41335_41336 : H12AffineEnvironment.transform 11 324 env41335 = env41336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 324 env41335 == env41336) = true)

theorem identity41336 : scanCanonicalize (H12AffineFastState.compose env41336 (packedSelected [2,5,8,13] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound41336 : packedSelected [2,5,8,13] rootPS < 2^1333 := by decide +kernel

def env41337 : List Nat := [2,4,8,16,32,64,128,68,512,4,2048,0,25,80,0,115,0,243,4,1,0,152,17,98,144,65,122,80,81,2145,20,17,69,65,1,512]

theorem envBound41337 : H12AffineFastState.Bounded env41337 := by
  intro p hp
  have h : env41337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41336_41337 : H12AffineEnvironment.transform 7 68 env41336 = env41337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env41336 == env41337) = true)

theorem identity41337 : scanCanonicalize (H12AffineFastState.compose env41337 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound41337 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41338 : List Nat := [2,4,8,16,32,64,128,68,136,4,2048,0,25,80,0,115,0,243,4,1,0,152,17,98,144,65,122,80,81,2145,20,17,69,65,1,136]

theorem envBound41338 : H12AffineFastState.Bounded env41338 := by
  intro p hp
  have h : env41338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41337_41338 : H12AffineEnvironment.transform 8 136 env41337 = env41338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env41337 == env41338) = true)

theorem identity41338 : scanCanonicalize (H12AffineFastState.compose env41338 (packedSelected [0,2,3,7,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 195) := by decide +kernel

theorem selectedBound41338 : packedSelected [0,2,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env41339 : List Nat := [2,4,8,16,32,64,128,68,136,4,195,0,25,80,0,115,0,243,4,1,0,152,17,98,144,65,122,80,81,162,20,17,69,65,1,136]

theorem envBound41339 : H12AffineFastState.Bounded env41339 := by
  intro p hp
  have h : env41339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41338_41339 : H12AffineEnvironment.transform 10 195 env41338 = env41339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 195 env41338 == env41339) = true)

def env41340 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74862,65665,4416,8540,4096,5276,74047,66897,13769,78895,1151,74814,1297,81227,8205,65830,257,1281,1345,5952]

theorem envBound41340 : H12AffineFastState.Bounded env41340 := by
  intro p hp
  have h : env41340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41318_41340 : H12AffineEnvironment.transform 17 65665 env41318 = env41340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env41318 == env41340) = true)

theorem identity41340 : scanCanonicalize (H12AffineFastState.compose env41340 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 310) := by decide +kernel

theorem selectedBound41340 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env41341 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,310,9560,439,4416,8540,4096,5276,8201,1127,13769,13593,1151,9480,1297,15485,8205,16,257,1281,1345,5952]

theorem envBound41341 : H12AffineFastState.Bounded env41341 := by
  intro p hp
  have h : env41341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41340_41341 : H12AffineEnvironment.transform 15 310 env41340 = env41341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 310 env41340 == env41341) = true)

def env41342 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,8541,310,9560,439,1024,8540,1344,476,8201,1127,8329,8281,1151,9480,1297,10557,8205,16,257,1281,1345,512]

theorem envBound41342 : H12AffineFastState.Bounded env41342 := by
  intro p hp
  have h : env41342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41341_41342 : H12AffineEnvironment.transform 11 1344 env41341 = env41342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env41341 == env41342) = true)

theorem identity41342 : scanCanonicalize (H12AffineFastState.compose env41342 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound41342 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env41343 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,1101,1296,1296,310,277,439,1024,1297,1344,476,1092,1127,1220,1044,1151,325,1297,3440,1088,16,257,1281,1345,512]

theorem envBound41343 : H12AffineFastState.Bounded env41343 := by
  intro p hp
  have h : env41343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41342_41343 : H12AffineEnvironment.transform 12 1101 env41342 = env41343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env41342 == env41343) = true)

theorem identity41343 : scanCanonicalize (H12AffineFastState.compose env41343 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound41343 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env41344 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,1052,1296,1296,310,277,439,1024,1297,1297,397,1045,1078,1173,1044,1070,276,1297,3361,1041,16,257,1281,1296,512]

theorem envBound41344 : H12AffineFastState.Bounded env41344 := by
  intro p hp
  have h : env41344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41343_41344 : H12AffineEnvironment.transform 5 17 env41343 = env41344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41343 == env41344) = true)

theorem identity41344 : scanCanonicalize (H12AffineFastState.compose env41344 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 1297) := by decide +kernel

theorem selectedBound41344 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env41345 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1297,1297,1052,1296,1296,310,277,439,1024,1297,1297,397,1045,1078,1173,1044,1070,276,1297,48,1041,16,257,1281,1296,512]

theorem envBound41345 : H12AffineFastState.Bounded env41345 := by
  intro p hp
  have h : env41345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41344_41345 : H12AffineEnvironment.transform 10 1297 env41344 = env41345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1297 env41344 == env41345) = true)

theorem identity41345 : scanCanonicalize (H12AffineFastState.compose env41345 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(8+1) ^^^ 412) := by decide +kernel

theorem selectedBound41345 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env41346 : List Nat := [2,4,8,16,32,17,128,256,412,1024,1297,1297,1052,1296,1296,310,277,439,1024,1297,1297,397,1045,1078,1173,1044,1070,276,1297,48,1041,16,257,1281,1296,412]

theorem envBound41346 : H12AffineFastState.Bounded env41346 := by
  intro p hp
  have h : env41346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41345_41346 : H12AffineEnvironment.transform 8 412 env41345 = env41346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 412 env41345 == env41346) = true)

theorem identity41346 : scanCanonicalize (H12AffineFastState.compose env41346 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound41346 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env41347 : List Nat := [2,4,8,16,32,17,128,256,412,408,137,137,388,136,136,310,277,439,408,137,137,397,397,430,269,396,438,276,137,48,393,16,257,153,136,412]

theorem envBound41347 : H12AffineFastState.Bounded env41347 := by
  intro p hp
  have h : env41347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41346_41347 : H12AffineEnvironment.transform 9 408 env41346 = env41347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env41346 == env41347) = true)

theorem identity41347 : scanCanonicalize (H12AffineFastState.compose env41347 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound41347 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41348 : List Nat := [2,4,8,16,32,17,128,37,185,189,137,137,161,136,136,19,48,146,189,137,137,168,168,139,40,169,147,49,137,48,172,16,36,153,136,185]

theorem envBound41348 : H12AffineFastState.Bounded env41348 := by
  intro p hp
  have h : env41348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41347_41348 : H12AffineEnvironment.transform 7 37 env41347 = env41348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env41347 == env41348) = true)

theorem identity41348 : scanCanonicalize (H12AffineFastState.compose env41348 (packedSelected [1,4] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound41348 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env41349 : List Nat := [2,4,8,16,32,17,34,37,27,31,43,43,3,42,42,19,48,48,31,43,43,10,10,41,40,11,49,49,43,48,14,16,36,59,42,27]

theorem envBound41349 : H12AffineFastState.Bounded env41349 := by
  intro p hp
  have h : env41349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41348_41349 : H12AffineEnvironment.transform 6 34 env41348 = env41349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env41348 == env41349) = true)

theorem identity41349 : scanCanonicalize (H12AffineFastState.compose env41349 (packedSelected [0,1,2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound41349 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env41350 : List Nat := [2,4,8,16,10,17,8,15,27,31,1,1,3,0,0,19,26,26,31,1,1,10,10,3,2,11,27,27,1,26,14,16,14,17,0,27]

theorem envBound41350 : H12AffineFastState.Bounded env41350 := by
  intro p hp
  have h : env41350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41349_41350 : H12AffineEnvironment.transform 4 10 env41349 = env41350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env41349 == env41350) = true)

theorem identity41350 : scanCanonicalize (H12AffineFastState.compose env41350 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound41350 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41351 : List Nat := [2,4,8,12,10,13,8,15,7,3,1,1,3,0,0,15,6,6,3,1,1,10,10,3,2,11,7,7,1,6,14,12,14,13,0,7]

theorem envBound41351 : H12AffineFastState.Bounded env41351 := by
  intro p hp
  have h : env41351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41350_41351 : H12AffineEnvironment.transform 3 12 env41350 = env41351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env41350 == env41351) = true)

def env41352 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,8541,310,9560,439,1025,8540,1345,477,8201,1127,8328,8280,1151,9480,1297,10556,8205,16,257,1281,1345,513]

theorem envBound41352 : H12AffineFastState.Bounded env41352 := by
  intro p hp
  have h : env41352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41341_41352 : H12AffineEnvironment.transform 11 1345 env41341 = env41352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env41341 == env41352) = true)

theorem identity41352 : scanCanonicalize (H12AffineFastState.compose env41352 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound41352 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env41353 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,325,8192,276,8541,310,8540,439,5,8540,325,477,8201,99,8328,8280,123,8460,277,10556,8205,16,257,261,325,513]

theorem envBound41353 : H12AffineFastState.Bounded env41353 := by
  intro p hp
  have h : env41353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41352_41353 : H12AffineEnvironment.transform 9 4 env41352 = env41353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env41352 == env41353) = true)

theorem identity41353 : scanCanonicalize (H12AffineFastState.compose env41353 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound41353 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env41354 : List Nat := [2,4,8,16,32,64,128,69,512,4,2048,0,8192,81,8216,115,8217,242,5,8217,0,152,8201,99,8328,8280,123,8265,80,10361,8205,16,68,64,0,513]

theorem envBound41354 : H12AffineFastState.Bounded env41354 := by
  intro p hp
  have h : env41354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41353_41354 : H12AffineEnvironment.transform 7 69 env41353 = env41354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env41353 == env41354) = true)

theorem identity41354 : scanCanonicalize (H12AffineFastState.compose env41354 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 89) := by decide +kernel

theorem selectedBound41354 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41355 : List Nat := [2,4,8,16,32,64,128,69,512,4,2048,0,89,81,65,115,64,242,5,64,0,152,80,99,209,1,123,16,80,2080,84,16,68,64,0,513]

theorem envBound41355 : H12AffineFastState.Bounded env41355 := by
  intro p hp
  have h : env41355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41354_41355 : H12AffineEnvironment.transform 12 89 env41354 = env41355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 89 env41354 == env41355) = true)

theorem identity41355 : scanCanonicalize (H12AffineFastState.compose env41355 (packedSelected [0,1,5,7,8,11,12,17] rootPS)) = affineNative (2^(8+1) ^^^ 245) := by decide +kernel

theorem selectedBound41355 : packedSelected [0,1,5,7,8,11,12,17] rootPS < 2^1333 := by decide +kernel

def env41356 : List Nat := [2,4,8,16,32,64,128,69,245,4,2048,0,89,81,65,115,64,242,5,64,0,152,80,99,209,1,123,16,80,2080,84,16,68,64,0,244]

theorem envBound41356 : H12AffineFastState.Bounded env41356 := by
  intro p hp
  have h : env41356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41355_41356 : H12AffineEnvironment.transform 8 245 env41355 = env41356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 245 env41355 == env41356) = true)

theorem identity41356 : scanCanonicalize (H12AffineFastState.compose env41356 (packedSelected [2,11,12,13,15,18] rootPS)) = affineNative (2^(5+1) ^^^ 61) := by decide +kernel

theorem selectedBound41356 : packedSelected [2,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env41357 : List Nat := [2,4,8,16,32,61,128,56,136,4,2048,0,36,44,60,14,61,143,5,61,0,152,45,30,172,1,6,16,45,2080,41,16,57,61,0,137]

theorem envBound41357 : H12AffineFastState.Bounded env41357 := by
  intro p hp
  have h : env41357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41356_41357 : H12AffineEnvironment.transform 5 61 env41356 = env41357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 61 env41356 == env41357) = true)

theorem identity41357 : scanCanonicalize (H12AffineFastState.compose env41357 (packedSelected [1,2,3,12] rootPS)) = affineNative (2^(4+1) ^^^ 29) := by decide +kernel

theorem selectedBound41357 : packedSelected [1,2,3,12] rootPS < 2^1333 := by decide +kernel

def env41358 : List Nat := [2,4,8,16,29,0,128,5,136,4,2048,0,25,17,1,14,0,143,5,0,0,152,16,30,145,1,6,16,16,2077,20,16,4,0,0,137]

theorem envBound41358 : H12AffineFastState.Bounded env41358 := by
  intro p hp
  have h : env41358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41357_41358 : H12AffineEnvironment.transform 4 29 env41357 = env41358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env41357 == env41358) = true)

theorem identity41358 : scanCanonicalize (H12AffineFastState.compose env41358 (packedSelected [2,8] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound41358 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env41359 : List Nat := [2,4,8,12,1,0,128,5,136,4,2048,0,5,13,1,14,0,143,5,0,0,132,12,2,141,1,6,12,12,2049,8,12,4,0,0,137]

theorem envBound41359 : H12AffineFastState.Bounded env41359 := by
  intro p hp
  have h : env41359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41358_41359 : H12AffineEnvironment.transform 3 12 env41358 = env41359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env41358 == env41359) = true)

theorem identity41359 : scanCanonicalize (H12AffineFastState.compose env41359 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound41359 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41360 : List Nat := [2,0,8,8,1,0,128,1,136,0,2048,0,1,9,1,10,0,139,1,0,0,128,8,2,137,1,2,8,8,2049,8,8,0,0,0,137]

theorem envBound41360 : H12AffineFastState.Bounded env41360 := by
  intro p hp
  have h : env41360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41359_41360 : H12AffineEnvironment.transform 1 0 env41359 = env41360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env41359 == env41360) = true)

theorem identity41360 : scanCanonicalize (H12AffineFastState.compose env41360 (packedSelected [2,5] rootPS)) = affineNative (2^(10+1) ^^^ 2) := by decide +kernel

theorem selectedBound41360 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env41361 : List Nat := [2,0,8,8,1,0,128,1,136,0,2,0,1,9,1,10,0,139,1,0,0,128,8,2,137,1,2,8,8,3,8,8,0,0,0,137]

theorem envBound41361 : H12AffineFastState.Bounded env41361 := by
  intro p hp
  have h : env41361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41360_41361 : H12AffineEnvironment.transform 10 2 env41360 = env41361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 2 env41360 == env41361) = true)

theorem identity41361 : scanCanonicalize (H12AffineFastState.compose env41361 (packedSelected [1,2,3] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound41361 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env41362 : List Nat := [0,0,8,8,1,0,128,1,136,0,0,0,1,9,1,8,0,137,1,0,0,128,8,0,137,1,0,8,8,1,8,8,0,0,0,137]

theorem envBound41362 : H12AffineFastState.Bounded env41362 := by
  intro p hp
  have h : env41362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41361_41362 : H12AffineEnvironment.transform 0 0 env41361 = env41362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env41361 == env41362) = true)

theorem identity41362 : scanCanonicalize (H12AffineFastState.compose env41362 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound41362 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env41363 : List Nat := [0,0,0,0,1,0,128,1,128,0,0,0,1,1,1,0,0,129,1,0,0,128,0,0,129,1,0,0,0,1,0,0,0,0,0,129]

theorem envBound41363 : H12AffineFastState.Bounded env41363 := by
  intro p hp
  have h : env41363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41362_41363 : H12AffineEnvironment.transform 2 0 env41362 = env41363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env41362 == env41363) = true)

theorem identity41363 : scanCanonicalize (H12AffineFastState.compose env41363 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 0) := by decide +kernel

theorem selectedBound41363 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41364 : List Nat := [0,0,0,0,1,0,0,1,0,0,0,0,1,1,1,0,0,1,1,0,0,0,0,0,1,1,0,0,0,1,0,0,0,0,0,1]

theorem envBound41364 : H12AffineFastState.Bounded env41364 := by
  intro p hp
  have h : env41364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41363_41364 : H12AffineEnvironment.transform 6 0 env41363 = env41364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 0 env41363 == env41364) = true)

def env41365 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74862,262144,4417,8541,4096,5276,74046,66897,13768,78895,328958,74815,1297,81226,8204,65831,257,1281,1345,5953]

theorem envBound41365 : H12AffineFastState.Bounded env41365 := by
  intro p hp
  have h : env41365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41317_41365 : H12AffineEnvironment.transform 13 1297 env41317 = env41365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env41317 == env41365) = true)

def env41366 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74862,65664,4417,8541,4096,5276,74046,66897,13768,78895,1150,74815,1297,81226,8204,65831,257,1281,1345,5953]

theorem envBound41366 : H12AffineFastState.Bounded env41366 := by
  intro p hp
  have h : env41366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41365_41366 : H12AffineEnvironment.transform 17 65664 env41365 = env41366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env41365 == env41366) = true)

theorem identity41366 : scanCanonicalize (H12AffineFastState.compose env41366 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9278) := by decide +kernel

theorem selectedBound41366 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env41367 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,9278,80,9406,4417,8541,4096,5276,1280,8559,13768,4113,1150,1,1297,6516,8204,9497,257,1281,1345,5953]

theorem envBound41367 : H12AffineFastState.Bounded env41367 := by
  intro p hp
  have h : env41367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41366_41367 : H12AffineEnvironment.transform 15 9278 env41366 = env41367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9278 env41366 == env41367) = true)

def env41368 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,1,8540,8494,80,8622,4417,8541,4096,4492,16,8559,12504,4113,366,1,1,6516,8204,8201,257,17,81,4689]

theorem envBound41368 : H12AffineFastState.Bounded env41368 := by
  intro p hp
  have h : env41368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41367_41368 : H12AffineEnvironment.transform 9 272 env41367 = env41368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env41367 == env41368) = true)

theorem identity41368 : scanCanonicalize (H12AffineFastState.compose env41368 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 325) := by decide +kernel

theorem selectedBound41368 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env41369 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,325,8192,1,8540,8494,80,8622,4,8541,325,201,16,8559,8605,340,366,1,1,2097,8204,8201,257,17,81,788]

theorem envBound41369 : H12AffineFastState.Bounded env41369 := by
  intro p hp
  have h : env41369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41368_41369 : H12AffineEnvironment.transform 11 325 env41368 = env41369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 325 env41368 == env41369) = true)

theorem identity41369 : scanCanonicalize (H12AffineFastState.compose env41369 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound41369 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env41370 : List Nat := [2,4,8,16,32,64,128,20,512,4,2048,81,8192,1,8264,8250,80,8378,4,8265,81,201,16,8315,8329,64,122,1,1,2097,8204,8201,21,17,81,512]

theorem envBound41370 : H12AffineFastState.Bounded env41370 := by
  intro p hp
  have h : env41370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41369_41370 : H12AffineEnvironment.transform 7 20 env41369 = env41370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env41369 == env41370) = true)

theorem identity41370 : scanCanonicalize (H12AffineFastState.compose env41370 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound41370 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env41371 : List Nat := [2,4,8,16,32,17,128,20,512,4,2048,0,8192,1,8217,8250,1,8378,4,8216,0,152,16,8234,8329,17,43,1,1,2097,8204,8201,21,17,0,512]

theorem envBound41371 : H12AffineFastState.Bounded env41371 := by
  intro p hp
  have h : env41371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41370_41371 : H12AffineEnvironment.transform 5 17 env41370 = env41371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41370 == env41371) = true)

theorem identity41371 : scanCanonicalize (H12AffineFastState.compose env41371 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2721) := by decide +kernel

theorem selectedBound41371 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41372 : List Nat := [2,4,8,16,32,17,128,20,512,4,2048,0,2721,1,2744,2715,1,2587,4,2745,0,152,16,2699,2600,17,43,1,1,2097,2733,2728,21,17,0,512]

theorem envBound41372 : H12AffineFastState.Bounded env41372 := by
  intro p hp
  have h : env41372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41371_41372 : H12AffineEnvironment.transform 12 2721 env41371 = env41372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2721 env41371 == env41372) = true)

theorem identity41372 : scanCanonicalize (H12AffineFastState.compose env41372 (packedSelected [3,8] rootPS)) = affineNative (2^(10+1) ^^^ 184) := by decide +kernel

theorem selectedBound41372 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env41373 : List Nat := [2,4,8,16,32,17,128,20,512,4,184,0,537,1,512,547,1,675,4,513,0,152,16,563,656,17,43,1,1,137,533,528,21,17,0,512]

theorem envBound41373 : H12AffineFastState.Bounded env41373 := by
  intro p hp
  have h : env41373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41372_41373 : H12AffineEnvironment.transform 10 184 env41372 = env41373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 184 env41372 == env41373) = true)

theorem identity41373 : scanCanonicalize (H12AffineFastState.compose env41373 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound41373 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41374 : List Nat := [2,4,8,16,32,17,128,20,137,4,184,0,144,1,137,170,1,42,4,136,0,152,16,186,25,17,43,1,1,137,156,153,21,17,0,137]

theorem envBound41374 : H12AffineFastState.Bounded env41374 := by
  intro p hp
  have h : env41374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41373_41374 : H12AffineEnvironment.transform 8 137 env41373 = env41374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env41373 == env41374) = true)

theorem identity41374 : scanCanonicalize (H12AffineFastState.compose env41374 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound41374 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env41375 : List Nat := [2,4,8,16,32,17,57,20,48,4,1,0,41,1,48,19,1,42,4,49,0,33,16,3,25,17,43,1,1,48,37,32,21,17,0,48]

theorem envBound41375 : H12AffineFastState.Bounded env41375 := by
  intro p hp
  have h : env41375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41374_41375 : H12AffineEnvironment.transform 6 57 env41374 = env41375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env41374 == env41375) = true)

theorem identity41375 : scanCanonicalize (H12AffineFastState.compose env41375 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound41375 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env41376 : List Nat := [2,4,8,16,17,17,8,20,1,4,1,0,24,1,1,19,1,27,4,0,0,16,16,3,25,17,26,1,1,1,20,17,21,17,0,1]

theorem envBound41376 : H12AffineFastState.Bounded env41376 := by
  intro p hp
  have h : env41376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41375_41376 : H12AffineEnvironment.transform 4 17 env41375 = env41376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env41375 == env41376) = true)

theorem identity41376 : scanCanonicalize (H12AffineFastState.compose env41376 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound41376 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41377 : List Nat := [2,4,4,16,17,17,4,20,1,4,1,0,20,1,1,19,1,23,4,0,0,16,16,3,21,17,22,1,1,1,20,17,21,17,0,1]

theorem envBound41377 : H12AffineFastState.Bounded env41377 := by
  intro p hp
  have h : env41377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41376_41377 : H12AffineEnvironment.transform 2 4 env41376 = env41377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env41376 == env41377) = true)

def env41378 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,0,8540,8495,80,8623,4417,8541,4096,4493,17,8559,12505,4113,367,1,0,6516,8204,8200,257,16,80,4688]

theorem envBound41378 : H12AffineFastState.Bounded env41378 := by
  intro p hp
  have h : env41378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41367_41378 : H12AffineEnvironment.transform 9 273 env41367 = env41378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env41367 == env41378) = true)

theorem identity41378 : scanCanonicalize (H12AffineFastState.compose env41378 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 4120) := by decide +kernel

theorem selectedBound41378 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env41379 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,4120,0,4420,4407,80,4535,4417,4421,4096,4493,17,4471,193,4113,367,1,0,6516,4116,4112,257,16,80,4688]

theorem envBound41379 : H12AffineFastState.Bounded env41379 := by
  intro p hp
  have h : env41379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41378_41379 : H12AffineEnvironment.transform 12 4120 env41378 = env41379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4120 env41378 == env41379) = true)

theorem identity41379 : scanCanonicalize (H12AffineFastState.compose env41379 (packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS)) = affineNative (2^(11+1) ^^^ 924) := by decide +kernel

theorem selectedBound41379 : packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS < 2^1333 := by decide +kernel

def env41380 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,924,900,0,728,683,80,555,733,729,924,529,17,747,193,909,367,1,0,2792,904,908,257,16,80,460]

theorem envBound41380 : H12AffineFastState.Bounded env41380 := by
  intro p hp
  have h : env41380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41379_41380 : H12AffineEnvironment.transform 11 924 env41379 = env41380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 924 env41379 == env41380) = true)

theorem identity41380 : scanCanonicalize (H12AffineFastState.compose env41380 (packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound41380 : packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS < 2^1333 := by decide +kernel

def env41381 : List Nat := [2,4,8,16,32,64,128,69,512,84,2048,729,705,0,728,683,80,555,733,729,729,529,17,747,193,712,42,1,0,2792,717,713,68,16,80,137]

theorem envBound41381 : H12AffineFastState.Bounded env41381 := by
  intro p hp
  have h : env41381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41380_41381 : H12AffineEnvironment.transform 7 69 env41380 = env41381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env41380 == env41381) = true)

theorem identity41381 : scanCanonicalize (H12AffineFastState.compose env41381 (packedSelected [0,3,5,7,11] rootPS)) = affineNative (2^(8+1) ^^^ 123) := by decide +kernel

theorem selectedBound41381 : packedSelected [0,3,5,7,11] rootPS < 2^1333 := by decide +kernel

def env41382 : List Nat := [2,4,8,16,32,64,128,69,123,84,2048,162,186,0,163,208,80,80,166,162,162,106,17,144,193,179,42,1,0,2195,182,178,68,16,80,137]

theorem envBound41382 : H12AffineFastState.Bounded env41382 := by
  intro p hp
  have h : env41382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41381_41382 : H12AffineEnvironment.transform 8 123 env41381 = env41382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 123 env41381 == env41382) = true)

theorem identity41382 : scanCanonicalize (H12AffineFastState.compose env41382 (packedSelected [4,9,10,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 195) := by decide +kernel

theorem selectedBound41382 : packedSelected [4,9,10,15,16] rootPS < 2^1333 := by decide +kernel

def env41383 : List Nat := [2,4,8,16,32,64,128,69,123,84,195,162,186,0,163,208,80,80,166,162,162,106,17,144,193,179,42,1,0,80,182,178,68,16,80,137]

theorem envBound41383 : H12AffineFastState.Bounded env41383 := by
  intro p hp
  have h : env41383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41382_41383 : H12AffineEnvironment.transform 10 195 env41382 = env41383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 195 env41382 == env41383) = true)

theorem identity41383 : scanCanonicalize (H12AffineFastState.compose env41383 (packedSelected [1,2,5] rootPS)) = affineNative (2^(6+1) ^^^ 66) := by decide +kernel

theorem selectedBound41383 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env41384 : List Nat := [2,4,8,16,32,64,66,69,123,84,1,96,120,0,97,18,80,80,100,96,96,106,17,82,3,113,42,1,0,80,116,112,68,16,80,75]

theorem envBound41384 : H12AffineFastState.Bounded env41384 := by
  intro p hp
  have h : env41384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41383_41384 : H12AffineEnvironment.transform 6 66 env41383 = env41384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 66 env41383 == env41384) = true)

theorem identity41384 : scanCanonicalize (H12AffineFastState.compose env41384 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound41384 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env41385 : List Nat := [2,4,8,16,32,10,8,15,49,30,1,42,50,0,43,18,26,26,46,42,42,32,17,24,3,59,42,1,0,26,62,58,14,16,26,1]

theorem envBound41385 : H12AffineFastState.Bounded env41385 := by
  intro p hp
  have h : env41385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41384_41385 : H12AffineEnvironment.transform 5 10 env41384 = env41385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env41384 == env41385) = true)

theorem identity41385 : scanCanonicalize (H12AffineFastState.compose env41385 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound41385 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41386 : List Nat := [2,4,8,11,32,10,8,15,42,5,1,42,41,0,43,9,1,1,46,42,42,32,10,3,3,32,42,1,0,1,37,33,14,11,1,1]

theorem envBound41386 : H12AffineFastState.Bounded env41386 := by
  intro p hp
  have h : env41386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41385_41386 : H12AffineEnvironment.transform 3 11 env41385 = env41386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env41385 == env41386) = true)

theorem identity41386 : scanCanonicalize (H12AffineFastState.compose env41386 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound41386 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41387 : List Nat := [2,4,8,11,11,10,8,15,1,5,1,1,2,0,0,9,1,1,5,1,1,11,10,3,3,11,1,1,0,1,14,10,14,11,1,1]

theorem envBound41387 : H12AffineFastState.Bounded env41387 := by
  intro p hp
  have h : env41387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41386_41387 : H12AffineEnvironment.transform 4 11 env41386 = env41387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env41386 == env41387) = true)

theorem identity41387 : scanCanonicalize (H12AffineFastState.compose env41387 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound41387 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41388 : List Nat := [2,3,8,11,11,10,8,8,1,2,1,1,2,0,0,9,1,1,2,1,1,11,10,3,3,11,1,1,0,1,9,10,9,11,1,1]

theorem envBound41388 : H12AffineFastState.Bounded env41388 := by
  intro p hp
  have h : env41388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41387_41388 : H12AffineEnvironment.transform 1 3 env41387 = env41388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env41387 == env41388) = true)

def env41389 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74862,65665,4417,8541,4096,5276,74046,66897,13768,78895,1151,74815,1297,81226,8204,65831,257,1281,1345,5953]

theorem envBound41389 : H12AffineFastState.Bounded env41389 := by
  intro p hp
  have h : env41389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41365_41389 : H12AffineEnvironment.transform 17 65665 env41365 = env41389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env41365 == env41389) = true)

theorem identity41389 : scanCanonicalize (H12AffineFastState.compose env41389 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12670) := by decide +kernel

theorem selectedBound41389 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env41390 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,12670,5392,12799,4417,8541,4096,5276,4160,13359,13768,1361,1151,5441,1297,3124,8204,12377,257,1281,1345,5953]

theorem envBound41390 : H12AffineFastState.Bounded env41390 := by
  intro p hp
  have h : env41390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41389_41390 : H12AffineEnvironment.transform 15 12670 env41389 = env41390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12670 env41389 == env41390) = true)

def env41391 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1297,8540,8494,1344,8623,273,8541,80,1228,16,9343,9624,1361,1151,1297,1297,3124,8204,8201,257,1281,1345,1809]

theorem envBound41391 : H12AffineFastState.Bounded env41391 := by
  intro p hp
  have h : env41391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41390_41391 : H12AffineEnvironment.transform 11 80 env41390 = env41391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env41390 == env41391) = true)

theorem identity41391 : scanCanonicalize (H12AffineFastState.compose env41391 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound41391 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env41392 : List Nat := [2,4,8,16,32,64,128,21,512,1024,2048,80,8192,1028,8265,8251,1109,8378,4,8264,80,1228,16,9343,9357,1092,1151,1028,1028,3124,8204,8201,20,1044,1108,1540]

theorem envBound41392 : H12AffineFastState.Bounded env41392 := by
  intro p hp
  have h : env41392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41391_41392 : H12AffineEnvironment.transform 7 21 env41391 = env41392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env41391 == env41392) = true)

theorem identity41392 : scanCanonicalize (H12AffineFastState.compose env41392 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound41392 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env41393 : List Nat := [2,4,8,16,32,64,128,21,512,4,2048,80,8192,0,8265,8251,81,8378,4,8264,80,200,16,8315,8329,64,123,0,0,2096,8204,8201,20,16,80,512]

theorem envBound41393 : H12AffineFastState.Bounded env41393 := by
  intro p hp
  have h : env41393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41392_41393 : H12AffineEnvironment.transform 9 4 env41392 = env41393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env41392 == env41393) = true)

theorem identity41393 : scanCanonicalize (H12AffineFastState.compose env41393 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound41393 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env41394 : List Nat := [2,4,8,16,32,17,128,21,512,4,2048,1,8192,0,8216,8251,0,8378,4,8217,1,153,16,8234,8329,17,42,0,0,2096,8204,8201,20,16,1,512]

theorem envBound41394 : H12AffineFastState.Bounded env41394 := by
  intro p hp
  have h : env41394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41393_41394 : H12AffineEnvironment.transform 5 17 env41393 = env41394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41393 == env41394) = true)

theorem identity41394 : scanCanonicalize (H12AffineFastState.compose env41394 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2720) := by decide +kernel

theorem selectedBound41394 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41395 : List Nat := [2,4,8,16,32,17,128,21,512,4,2048,1,2720,0,2744,2715,0,2586,4,2745,1,153,16,2698,2601,17,42,0,0,2096,2732,2729,20,16,1,512]

theorem envBound41395 : H12AffineFastState.Bounded env41395 := by
  intro p hp
  have h : env41395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41394_41395 : H12AffineEnvironment.transform 12 2720 env41394 = env41395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2720 env41394 == env41395) = true)

theorem identity41395 : scanCanonicalize (H12AffineFastState.compose env41395 (packedSelected [3,8] rootPS)) = affineNative (2^(10+1) ^^^ 658) := by decide +kernel

theorem selectedBound41395 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env41396 : List Nat := [2,4,8,16,32,17,128,21,512,4,658,1,50,0,42,9,0,136,4,43,1,153,16,24,187,17,42,0,0,674,62,59,20,16,1,512]

theorem envBound41396 : H12AffineFastState.Bounded env41396 := by
  intro p hp
  have h : env41396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41395_41396 : H12AffineEnvironment.transform 10 658 env41395 = env41396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 658 env41395 == env41396) = true)

theorem identity41396 : scanCanonicalize (H12AffineFastState.compose env41396 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound41396 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41397 : List Nat := [2,4,8,16,32,17,128,21,136,4,26,1,50,0,42,9,0,136,4,43,1,153,16,24,187,17,42,0,0,42,62,59,20,16,1,136]

theorem envBound41397 : H12AffineFastState.Bounded env41397 := by
  intro p hp
  have h : env41397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41396_41397 : H12AffineEnvironment.transform 8 136 env41396 = env41397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env41396 == env41397) = true)

theorem identity41397 : scanCanonicalize (H12AffineFastState.compose env41397 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound41397 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env41398 : List Nat := [2,4,8,16,32,17,57,21,49,4,26,1,50,0,42,9,0,49,4,43,1,32,16,24,2,17,42,0,0,42,62,59,20,16,1,49]

theorem envBound41398 : H12AffineFastState.Bounded env41398 := by
  intro p hp
  have h : env41398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41397_41398 : H12AffineEnvironment.transform 6 57 env41397 = env41398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env41397 == env41398) = true)

theorem identity41398 : scanCanonicalize (H12AffineFastState.compose env41398 (packedSelected [3,4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound41398 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env41399 : List Nat := [2,4,8,16,11,17,18,21,26,4,26,1,25,0,1,9,0,26,4,0,1,11,16,24,2,17,1,0,0,1,21,16,20,16,1,26]

theorem envBound41399 : H12AffineFastState.Bounded env41399 := by
  intro p hp
  have h : env41399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41398_41399 : H12AffineEnvironment.transform 4 11 env41398 = env41399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env41398 == env41399) = true)

theorem identity41399 : scanCanonicalize (H12AffineFastState.compose env41399 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound41399 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41400 : List Nat := [2,4,8,7,11,6,5,2,13,4,13,1,14,0,1,9,0,13,4,0,1,11,7,15,2,6,1,0,0,1,2,7,3,7,1,13]

theorem envBound41400 : H12AffineFastState.Bounded env41400 := by
  intro p hp
  have h : env41400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41399_41400 : H12AffineEnvironment.transform 3 7 env41399 = env41400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env41399 == env41400) = true)

def env41401 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1297,8540,8495,1345,8622,272,8541,81,1229,17,9342,9625,1361,1151,1296,1297,3124,8204,8200,257,1281,1345,1808]

theorem envBound41401 : H12AffineFastState.Bounded env41401 := by
  intro p hp
  have h : env41401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41390_41401 : H12AffineEnvironment.transform 11 81 env41390 = env41401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env41390 == env41401) = true)

theorem identity41401 : scanCanonicalize (H12AffineFastState.compose env41401 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 73) := by decide +kernel

theorem selectedBound41401 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env41402 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,73,1297,277,358,1345,487,272,276,81,1229,17,1079,1488,1361,1151,1296,1297,3124,69,65,257,1281,1345,1808]

theorem envBound41402 : H12AffineFastState.Bounded env41402 := by
  intro p hp
  have h : env41402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41401_41402 : H12AffineEnvironment.transform 12 73 env41401 = env41402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env41401 == env41402) = true)

theorem identity41402 : scanCanonicalize (H12AffineFastState.compose env41402 (packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS)) = affineNative (2^(8+1) ^^^ 461) := by decide +kernel

theorem selectedBound41402 : packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS < 2^1333 := by decide +kernel

def env41403 : List Nat := [2,4,8,16,32,64,128,256,461,1024,2048,81,73,1297,277,358,1345,487,272,276,81,1229,17,1079,1488,1361,1151,1296,1297,3124,69,65,257,1281,1345,1245]

theorem envBound41403 : H12AffineFastState.Bounded env41403 := by
  intro p hp
  have h : env41403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41402_41403 : H12AffineEnvironment.transform 8 461 env41402 = env41403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 461 env41402 == env41403) = true)

theorem identity41403 : scanCanonicalize (H12AffineFastState.compose env41403 (packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound41403 : packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS < 2^1333 := by decide +kernel

def env41404 : List Nat := [2,4,8,16,32,64,128,256,461,84,2048,81,73,325,277,358,277,487,272,276,81,153,17,99,388,261,43,324,325,2144,69,65,257,341,277,137]

theorem envBound41404 : H12AffineFastState.Bounded env41404 := by
  intro p hp
  have h : env41404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41403_41404 : H12AffineEnvironment.transform 9 84 env41403 = env41404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env41403 == env41404) = true)

theorem identity41404 : scanCanonicalize (H12AffineFastState.compose env41404 (packedSelected [0,3,4,5,7,9,11,13,16,17] rootPS)) = affineNative (2^(10+1) ^^^ 217) := by decide +kernel

theorem selectedBound41404 : packedSelected [0,3,4,5,7,9,11,13,16,17] rootPS < 2^1333 := by decide +kernel

def env41405 : List Nat := [2,4,8,16,32,64,128,256,461,84,217,81,73,325,277,358,277,487,272,276,81,153,17,99,388,261,43,324,325,185,69,65,257,341,277,137]

theorem envBound41405 : H12AffineFastState.Bounded env41405 := by
  intro p hp
  have h : env41405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41404_41405 : H12AffineEnvironment.transform 10 217 env41404 = env41405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 217 env41404 == env41405) = true)

theorem identity41405 : scanCanonicalize (H12AffineFastState.compose env41405 (packedSelected [1,2,5,12,13,15] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound41405 : packedSelected [1,2,5,12,13,15] rootPS < 2^1333 := by decide +kernel

def env41406 : List Nat := [2,4,8,16,32,32,128,256,429,52,185,49,41,293,277,262,277,391,272,276,49,153,17,3,388,261,43,292,293,185,37,33,257,309,277,137]

theorem envBound41406 : H12AffineFastState.Bounded env41406 := by
  intro p hp
  have h : env41406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41405_41406 : H12AffineEnvironment.transform 5 32 env41405 = env41406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env41405 == env41406) = true)

theorem identity41406 : scanCanonicalize (H12AffineFastState.compose env41406 (packedSelected [1,2,4,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 135) := by decide +kernel

theorem selectedBound41406 : packedSelected [1,2,4,8,9] rootPS < 2^1333 := by decide +kernel

def env41407 : List Nat := [2,4,8,16,32,32,128,135,42,52,185,49,41,162,146,129,146,0,151,147,49,153,17,3,3,130,43,163,162,185,37,33,134,178,146,137]

theorem envBound41407 : H12AffineFastState.Bounded env41407 := by
  intro p hp
  have h : env41407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41406_41407 : H12AffineEnvironment.transform 7 135 env41406 = env41407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 135 env41406 == env41407) = true)

theorem identity41407 : scanCanonicalize (H12AffineFastState.compose env41407 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound41407 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env41408 : List Nat := [2,4,8,16,32,32,35,36,42,52,26,49,41,1,49,34,49,0,52,48,49,58,17,3,3,33,43,0,1,26,37,33,37,17,49,42]

theorem envBound41408 : H12AffineFastState.Bounded env41408 := by
  intro p hp
  have h : env41408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41407_41408 : H12AffineEnvironment.transform 6 35 env41407 = env41408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env41407 == env41408) = true)

theorem identity41408 : scanCanonicalize (H12AffineFastState.compose env41408 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound41408 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env41409 : List Nat := [2,4,8,16,17,17,18,21,27,5,26,0,24,1,0,19,0,0,5,1,0,11,17,3,3,16,26,0,1,26,20,16,20,17,0,27]

theorem envBound41409 : H12AffineFastState.Bounded env41409 := by
  intro p hp
  have h : env41409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41408_41409 : H12AffineEnvironment.transform 4 17 env41408 = env41409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env41408 == env41409) = true)

theorem identity41409 : scanCanonicalize (H12AffineFastState.compose env41409 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound41409 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41410 : List Nat := [2,2,8,16,17,17,18,19,27,3,26,0,24,1,0,19,0,0,3,1,0,11,17,3,3,16,26,0,1,26,18,16,18,17,0,27]

theorem envBound41410 : H12AffineFastState.Bounded env41410 := by
  intro p hp
  have h : env41410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41409_41410 : H12AffineEnvironment.transform 1 2 env41409 = env41410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env41409 == env41410) = true)

theorem identity41410 : scanCanonicalize (H12AffineFastState.compose env41410 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound41410 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41411 : List Nat := [2,2,8,10,11,11,8,9,1,3,0,0,2,1,0,9,0,0,3,1,0,11,11,3,3,10,0,0,1,0,8,10,8,11,0,1]

theorem envBound41411 : H12AffineFastState.Bounded env41411 := by
  intro p hp
  have h : env41411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41410_41411 : H12AffineEnvironment.transform 3 10 env41410 = env41411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env41410 == env41411) = true)

def env41412 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,21585,32769,4096,61649,91183,123164,28888,78894,385203,90414,1296,96347,25885,82998,257,1280,1345,21073]

theorem envBound41412 : H12AffineFastState.Bounded env41412 := by
  intro p hp
  have h : env41412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41315_41412 : H12AffineEnvironment.transform 18 21585 env41315 = env41412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env41315 == env41412) = true)

theorem identity41412 : scanCanonicalize (H12AffineFastState.compose env41412 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound41412 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env41413 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13340,65536,74862,262144,21585,13341,4096,17613,91183,87296,28888,78894,349359,90414,1296,96347,25885,82998,257,1280,1345,21073]

theorem envBound41413 : H12AffineFastState.Bounded env41413 := by
  intro p hp
  have h : env41413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41412_41413 : H12AffineEnvironment.transform 14 13340 env41412 = env41413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env41412 == env41413) = true)

def env41414 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74862,262144,4417,13341,4096,477,74047,69648,13768,78894,332223,74814,1296,81227,8205,65830,257,1280,1345,5953]

theorem envBound41414 : H12AffineFastState.Bounded env41414 := by
  intro p hp
  have h : env41414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41413_41414 : H12AffineEnvironment.transform 13 1296 env41413 = env41414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env41413 == env41414) = true)

def env41415 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74862,65664,4417,13341,4096,477,74047,69648,13768,78894,4415,74814,1296,81227,8205,65830,257,1280,1345,5953]

theorem envBound41415 : H12AffineFastState.Bounded env41415 := by
  intro p hp
  have h : env41415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41414_41415 : H12AffineEnvironment.transform 17 65664 env41414 = env41415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env41414 == env41415) = true)

theorem identity41415 : scanCanonicalize (H12AffineFastState.compose env41415 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 310) := by decide +kernel

theorem selectedBound41415 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env41416 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,310,9560,438,4417,13341,4096,477,8201,4390,13768,13592,4415,9480,1296,15485,8205,16,257,1280,1345,5953]

theorem envBound41416 : H12AffineFastState.Bounded env41416 := by
  intro p hp
  have h : env41416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41415_41416 : H12AffineEnvironment.transform 15 310 env41415 = env41416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 310 env41415 == env41416) = true)

def env41417 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,0,12556,310,8264,438,4417,12557,4096,477,8201,4390,12504,12296,4415,8216,0,14701,8205,16,257,16,81,4689]

theorem envBound41417 : H12AffineFastState.Bounded env41417 := by
  intro p hp
  have h : env41417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41416_41417 : H12AffineEnvironment.transform 9 272 env41416 = env41417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env41416 == env41417) = true)

theorem identity41417 : scanCanonicalize (H12AffineFastState.compose env41417 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 4120) := by decide +kernel

theorem selectedBound41417 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env41418 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,4120,0,276,310,4176,438,4417,277,4096,477,4113,4390,192,16,4415,4096,0,2421,4117,16,257,16,81,4689]

theorem envBound41418 : H12AffineFastState.Bounded env41418 := by
  intro p hp
  have h : env41418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41417_41418 : H12AffineEnvironment.transform 12 4120 env41417 = env41418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4120 env41417 == env41418) = true)

theorem identity41418 : scanCanonicalize (H12AffineFastState.compose env41418 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 325) := by decide +kernel

theorem selectedBound41418 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env41419 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,325,349,0,276,310,277,438,4,277,325,477,340,99,192,16,122,325,0,2421,336,16,257,16,81,788]

theorem envBound41419 : H12AffineFastState.Bounded env41419 := by
  intro p hp
  have h : env41419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41418_41419 : H12AffineEnvironment.transform 11 325 env41418 = env41419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 325 env41418 == env41419) = true)

theorem identity41419 : scanCanonicalize (H12AffineFastState.compose env41419 (packedSelected [0,2,3,7,10,11,12,15,17,19] rootPS)) = affineNative (2^(8+1) ^^^ 506) := by decide +kernel

theorem selectedBound41419 : packedSelected [0,2,3,7,10,11,12,15,17,19] rootPS < 2^1333 := by decide +kernel

def env41420 : List Nat := [2,4,8,16,32,64,128,256,506,272,2048,325,349,0,276,310,277,438,4,277,325,477,340,99,192,16,122,325,0,2421,336,16,257,16,81,238]

theorem envBound41420 : H12AffineFastState.Bounded env41420 := by
  intro p hp
  have h : env41420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41419_41420 : H12AffineEnvironment.transform 8 506 env41419 = env41420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 506 env41419 == env41420) = true)

theorem identity41420 : scanCanonicalize (H12AffineFastState.compose env41420 (packedSelected [0,3,4,5,7,9,10,12,13,15,18,23] rootPS)) = affineNative (2^(10+1) ^^^ 194) := by decide +kernel

theorem selectedBound41420 : packedSelected [0,3,4,5,7,9,10,12,13,15,18,23] rootPS < 2^1333 := by decide +kernel

def env41421 : List Nat := [2,4,8,16,32,64,128,256,506,272,194,325,349,0,276,310,277,438,4,277,325,477,340,99,192,16,122,325,0,439,336,16,257,16,81,238]

theorem envBound41421 : H12AffineFastState.Bounded env41421 := by
  intro p hp
  have h : env41421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41420_41421 : H12AffineEnvironment.transform 10 194 env41420 = env41421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 194 env41420 == env41421) = true)

theorem identity41421 : scanCanonicalize (H12AffineFastState.compose env41421 (packedSelected [0,3,4,5,7,9,10,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound41421 : packedSelected [0,3,4,5,7,9,10,13,17] rootPS < 2^1333 := by decide +kernel

def env41422 : List Nat := [2,4,8,16,32,64,128,68,190,84,194,1,25,0,80,114,81,242,4,81,1,153,16,99,192,16,122,1,0,243,20,16,69,16,81,238]

theorem envBound41422 : H12AffineFastState.Bounded env41422 := by
  intro p hp
  have h : env41422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41421_41422 : H12AffineEnvironment.transform 7 68 env41421 = env41422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env41421 == env41422) = true)

theorem identity41422 : scanCanonicalize (H12AffineFastState.compose env41422 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound41422 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env41423 : List Nat := [2,4,8,16,32,64,14,68,48,84,76,1,25,0,80,114,81,124,4,81,1,23,16,99,78,16,122,1,0,125,20,16,69,16,81,96]

theorem envBound41423 : H12AffineFastState.Bounded env41423 := by
  intro p hp
  have h : env41423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41422_41423 : H12AffineEnvironment.transform 6 14 env41422 = env41423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env41422 == env41423) = true)

theorem identity41423 : scanCanonicalize (H12AffineFastState.compose env41423 (packedSelected [2,5] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound41423 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env41424 : List Nat := [2,4,8,16,32,13,14,9,48,25,1,1,25,0,29,63,28,49,4,28,1,23,16,46,3,16,55,1,0,48,20,16,8,16,28,45]

theorem envBound41424 : H12AffineFastState.Bounded env41424 := by
  intro p hp
  have h : env41424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41423_41424 : H12AffineEnvironment.transform 5 13 env41423 = env41424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env41423 == env41424) = true)

theorem identity41424 : scanCanonicalize (H12AffineFastState.compose env41424 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound41424 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41425 : List Nat := [2,4,8,16,17,13,14,9,1,25,1,1,25,0,29,14,28,0,4,28,1,23,16,31,3,16,6,1,0,1,20,16,8,16,28,28]

theorem envBound41425 : H12AffineFastState.Bounded env41425 := by
  intro p hp
  have h : env41425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41424_41425 : H12AffineEnvironment.transform 4 17 env41424 = env41425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env41424 == env41425) = true)

theorem identity41425 : scanCanonicalize (H12AffineFastState.compose env41425 (packedSelected [1,4,7] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound41425 : packedSelected [1,4,7] rootPS < 2^1333 := by decide +kernel

def env41426 : List Nat := [2,2,8,16,17,11,8,9,1,25,1,1,25,0,27,8,26,0,2,26,1,17,16,25,3,16,0,1,0,1,18,16,8,16,26,26]

theorem envBound41426 : H12AffineFastState.Bounded env41426 := by
  intro p hp
  have h : env41426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41425_41426 : H12AffineEnvironment.transform 1 2 env41425 = env41426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env41425 == env41426) = true)

def env41427 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,1,12557,310,8265,438,4417,12556,4096,477,8201,4390,12505,12297,4415,8217,1,14700,8205,16,257,17,80,4688]

theorem envBound41427 : H12AffineFastState.Bounded env41427 := by
  intro p hp
  have h : env41427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41416_41427 : H12AffineEnvironment.transform 9 273 env41416 = env41427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env41416 == env41427) = true)

theorem identity41427 : scanCanonicalize (H12AffineFastState.compose env41427 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound41427 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env41428 : List Nat := [2,4,8,16,32,64,128,21,512,4,2048,4096,8192,1,12312,35,8265,163,4180,12313,4096,200,8201,4147,12505,12297,4138,8217,1,14457,8205,16,20,17,80,4688]

theorem envBound41428 : H12AffineFastState.Bounded env41428 := by
  intro p hp
  have h : env41428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41427_41428 : H12AffineEnvironment.transform 7 21 env41427 = env41428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env41427 == env41428) = true)

theorem identity41428 : scanCanonicalize (H12AffineFastState.compose env41428 (packedSelected [0,1,4,7,8,9,12,13,15,18,19,23] rootPS)) = affineNative (2^(12+1) ^^^ 4256) := by decide +kernel

theorem selectedBound41428 : packedSelected [0,1,4,7,8,9,12,13,15,18,19,23] rootPS < 2^1333 := by decide +kernel

def env41429 : List Nat := [2,4,8,16,32,64,128,21,512,4,2048,4096,4256,1,184,35,4329,163,4180,185,4096,200,4265,4147,121,169,4138,4281,1,2265,4269,16,20,17,80,4688]

theorem envBound41429 : H12AffineFastState.Bounded env41429 := by
  intro p hp
  have h : env41429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41428_41429 : H12AffineEnvironment.transform 12 4256 env41428 = env41429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4256 env41428 == env41429) = true)

theorem identity41429 : scanCanonicalize (H12AffineFastState.compose env41429 (packedSelected [0,3,5,7,10,12,17,18] rootPS)) = affineNative (2^(11+1) ^^^ 2122) := by decide +kernel

theorem selectedBound41429 : packedSelected [0,3,5,7,10,12,17,18] rootPS < 2^1333 := by decide +kernel

def env41430 : List Nat := [2,4,8,16,32,64,128,21,512,4,2048,2122,2282,1,184,35,2211,163,2078,185,2122,200,2275,2169,121,169,2144,2291,1,2265,2279,16,20,17,80,2586]

theorem envBound41430 : H12AffineFastState.Bounded env41430 := by
  intro p hp
  have h : env41430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41429_41430 : H12AffineEnvironment.transform 11 2122 env41429 = env41430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2122 env41429 == env41430) = true)

theorem identity41430 : scanCanonicalize (H12AffineFastState.compose env41430 (packedSelected [2,4,9,13,16] rootPS)) = affineNative (2^(8+1) ^^^ 123) := by decide +kernel

theorem selectedBound41430 : packedSelected [2,4,9,13,16] rootPS < 2^1333 := by decide +kernel

def env41431 : List Nat := [2,4,8,16,32,64,128,21,123,4,2048,2122,2282,1,184,35,2211,163,2078,185,2122,200,2275,2169,121,169,2144,2291,1,2265,2279,16,20,17,80,2145]

theorem envBound41431 : H12AffineFastState.Bounded env41431 := by
  intro p hp
  have h : env41431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41430_41431 : H12AffineEnvironment.transform 8 123 env41430 = env41431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 123 env41430 == env41431) = true)

theorem identity41431 : scanCanonicalize (H12AffineFastState.compose env41431 (packedSelected [1,2,3,4,9,10,12] rootPS)) = affineNative (2^(6+1) ^^^ 67) := by decide +kernel

theorem selectedBound41431 : packedSelected [1,2,3,4,9,10,12] rootPS < 2^1333 := by decide +kernel

def env41432 : List Nat := [2,4,8,16,32,64,67,21,123,4,2048,2122,2089,1,123,35,2144,96,2078,122,2122,11,2080,2169,121,106,2144,2096,1,2074,2084,16,20,17,80,2145]

theorem envBound41432 : H12AffineFastState.Bounded env41432 := by
  intro p hp
  have h : env41432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41431_41432 : H12AffineEnvironment.transform 6 67 env41431 = env41432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 67 env41431 == env41432) = true)

theorem identity41432 : scanCanonicalize (H12AffineFastState.compose env41432 (packedSelected [2,3,4,9] rootPS)) = affineNative (2^(10+1) ^^^ 71) := by decide +kernel

theorem selectedBound41432 : packedSelected [2,3,4,9] rootPS < 2^1333 := by decide +kernel

def env41433 : List Nat := [2,4,8,16,32,64,67,21,123,4,71,13,110,1,123,35,39,96,89,122,13,11,103,62,121,106,39,119,1,93,99,16,20,17,80,38]

theorem envBound41433 : H12AffineFastState.Bounded env41433 := by
  intro p hp
  have h : env41433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41432_41433 : H12AffineEnvironment.transform 10 71 env41432 = env41433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 71 env41432 == env41433) = true)

theorem identity41433 : scanCanonicalize (H12AffineFastState.compose env41433 (packedSelected [0,1,2,3,4,8,10] rootPS)) = affineNative (2^(5+1) ^^^ 29) := by decide +kernel

theorem selectedBound41433 : packedSelected [0,1,2,3,4,8,10] rootPS < 2^1333 := by decide +kernel

def env41434 : List Nat := [2,4,8,16,32,29,30,21,38,4,26,13,51,1,38,35,39,61,4,39,13,11,58,62,36,55,39,42,1,0,62,16,20,17,13,38]

theorem envBound41434 : H12AffineFastState.Bounded env41434 := by
  intro p hp
  have h : env41434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41433_41434 : H12AffineEnvironment.transform 5 29 env41433 = env41434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 29 env41433 == env41434) = true)

theorem identity41434 : scanCanonicalize (H12AffineFastState.compose env41434 (packedSelected [0,1,2] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound41434 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env41435 : List Nat := [2,4,8,16,28,29,30,21,26,4,26,13,15,1,26,31,27,1,4,27,13,11,6,2,24,11,27,22,1,0,2,16,20,17,13,26]

theorem envBound41435 : H12AffineFastState.Bounded env41435 := by
  intro p hp
  have h : env41435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41434_41435 : H12AffineEnvironment.transform 4 28 env41434 = env41435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env41434 == env41435) = true)

theorem identity41435 : scanCanonicalize (H12AffineFastState.compose env41435 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound41435 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41436 : List Nat := [2,4,8,6,10,11,8,3,12,4,12,13,15,1,12,9,13,1,4,13,13,11,6,2,14,11,13,0,1,0,2,6,2,7,13,12]

theorem envBound41436 : H12AffineFastState.Bounded env41436 := by
  intro p hp
  have h : env41436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41435_41436 : H12AffineEnvironment.transform 3 6 env41435 = env41436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env41435 == env41436) = true)

theorem identity41436 : scanCanonicalize (H12AffineFastState.compose env41436 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound41436 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41437 : List Nat := [2,4,5,6,7,6,5,3,1,4,1,0,2,1,1,4,0,1,4,0,0,6,6,2,3,6,0,0,1,0,2,6,2,7,0,1]

theorem envBound41437 : H12AffineFastState.Bounded env41437 := by
  intro p hp
  have h : env41437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41436_41437 : H12AffineEnvironment.transform 2 5 env41436 = env41437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env41436 == env41437) = true)

def env41438 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74862,65665,4417,13341,4096,477,74047,69648,13768,78894,4414,74814,1296,81227,8205,65830,257,1280,1345,5953]

theorem envBound41438 : H12AffineFastState.Bounded env41438 := by
  intro p hp
  have h : env41438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41414_41438 : H12AffineEnvironment.transform 17 65665 env41414 = env41438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env41414 == env41438) = true)

theorem identity41438 : scanCanonicalize (H12AffineFastState.compose env41438 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5238) := by decide +kernel

theorem selectedBound41438 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env41439 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,5238,12312,5367,4417,13341,4096,477,13641,1126,13768,8280,4414,12360,1296,10557,8205,5456,257,1280,1345,5953]

theorem envBound41439 : H12AffineFastState.Bounded env41439 := by
  intro p hp
  have h : env41439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41438_41439 : H12AffineEnvironment.transform 15 5238 env41438 = env41439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5238 env41438 == env41439) = true)

def env41440 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5464,1296,324,5238,1344,5367,4417,325,4096,477,17,1126,144,5376,4414,1296,1296,7269,5461,5456,257,1280,1345,5953]

theorem envBound41440 : H12AffineFastState.Bounded env41440 := by
  intro p hp
  have h : env41440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41439_41440 : H12AffineEnvironment.transform 12 5464 env41439 = env41440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5464 env41439 == env41440) = true)

theorem identity41440 : scanCanonicalize (H12AffineFastState.compose env41440 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound41440 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env41441 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,4120,80,324,4406,0,4535,4417,325,4096,477,17,294,144,4160,4414,80,80,6437,4117,4112,257,64,1,4609]

theorem envBound41441 : H12AffineFastState.Bounded env41441 := by
  intro p hp
  have h : env41441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41440_41441 : H12AffineEnvironment.transform 9 320 env41440 = env41441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env41440 == env41441) = true)

theorem identity41441 : scanCanonicalize (H12AffineFastState.compose env41441 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound41441 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env41442 : List Nat := [2,4,8,16,32,64,128,172,512,236,2048,4096,4120,80,232,4250,0,4123,4333,233,4096,113,17,138,144,4160,4242,80,80,6281,4117,4112,173,64,1,4609]

theorem envBound41442 : H12AffineFastState.Bounded env41442 := by
  intro p hp
  have h : env41442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41441_41442 : H12AffineEnvironment.transform 7 172 env41441 = env41442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env41441 == env41442) = true)

theorem identity41442 : scanCanonicalize (H12AffineFastState.compose env41442 (packedSelected [0,2,3,5,7,10,11,12,15,16,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 754) := by decide +kernel

theorem selectedBound41442 : packedSelected [0,2,3,5,7,10,11,12,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env41443 : List Nat := [2,4,8,16,32,64,128,172,512,236,754,4096,4120,80,232,4250,0,4123,4333,233,4096,113,17,138,144,4160,4242,80,80,4731,4117,4112,173,64,1,4609]

theorem envBound41443 : H12AffineFastState.Bounded env41443 := by
  intro p hp
  have h : env41443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41442_41443 : H12AffineEnvironment.transform 10 754 env41442 = env41443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 754 env41442 == env41443) = true)

theorem identity41443 : scanCanonicalize (H12AffineFastState.compose env41443 (packedSelected [0,2,3,7,8,10,12,15,16] rootPS)) = affineNative (2^(11+1) ^^^ 43) := by decide +kernel

theorem selectedBound41443 : packedSelected [0,2,3,7,8,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env41444 : List Nat := [2,4,8,16,32,64,128,172,512,236,754,43,51,80,232,177,0,48,198,233,43,113,17,138,144,107,185,80,80,592,62,59,173,64,1,554]

theorem envBound41444 : H12AffineFastState.Bounded env41444 := by
  intro p hp
  have h : env41444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41443_41444 : H12AffineEnvironment.transform 11 43 env41443 = env41444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 43 env41443 == env41444) = true)

theorem identity41444 : scanCanonicalize (H12AffineFastState.compose env41444 (packedSelected [0,2,3,4,7,8,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 115) := by decide +kernel

theorem selectedBound41444 : packedSelected [0,2,3,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env41445 : List Nat := [2,4,8,16,32,64,115,95,512,31,513,43,51,80,27,66,0,48,53,26,43,113,17,121,99,107,74,80,80,592,62,59,94,64,1,554]

theorem envBound41445 : H12AffineFastState.Bounded env41445 := by
  intro p hp
  have h : env41445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41444_41445 : H12AffineEnvironment.transform 6 115 env41444 = env41445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 115 env41444 == env41445) = true)

theorem identity41445 : scanCanonicalize (H12AffineFastState.compose env41445 (packedSelected [1,8] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound41445 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env41446 : List Nat := [2,4,8,16,32,64,115,95,1,31,0,43,51,80,27,66,0,48,53,26,43,113,17,121,99,107,74,80,80,81,62,59,94,64,1,43]

theorem envBound41446 : H12AffineFastState.Bounded env41446 := by
  intro p hp
  have h : env41446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41445_41446 : H12AffineEnvironment.transform 8 1 env41445 = env41446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env41445 == env41446) = true)

theorem identity41446 : scanCanonicalize (H12AffineFastState.compose env41446 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound41446 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env41447 : List Nat := [2,4,8,16,32,10,57,21,1,31,0,43,51,26,27,8,0,48,53,26,43,59,17,51,41,33,0,26,26,27,62,59,20,10,1,43]

theorem envBound41447 : H12AffineFastState.Bounded env41447 := by
  intro p hp
  have h : env41447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41446_41447 : H12AffineEnvironment.transform 5 10 env41446 = env41447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env41446 == env41447) = true)

theorem identity41447 : scanCanonicalize (H12AffineFastState.compose env41447 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound41447 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41448 : List Nat := [2,4,8,11,32,10,34,14,1,4,0,43,40,1,0,8,0,43,46,1,43,32,10,40,41,33,0,1,1,0,37,32,15,10,1,43]

theorem envBound41448 : H12AffineFastState.Bounded env41448 := by
  intro p hp
  have h : env41448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41447_41448 : H12AffineEnvironment.transform 3 11 env41447 = env41448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env41447 == env41448) = true)

theorem identity41448 : scanCanonicalize (H12AffineFastState.compose env41448 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound41448 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41449 : List Nat := [2,4,8,11,11,10,9,14,1,4,0,0,3,1,0,8,0,0,5,1,0,11,10,3,2,10,0,1,1,0,14,11,15,10,1,0]

theorem envBound41449 : H12AffineFastState.Bounded env41449 := by
  intro p hp
  have h : env41449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41448_41449 : H12AffineEnvironment.transform 4 11 env41448 = env41449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env41448 == env41449) = true)

theorem identity41449 : scanCanonicalize (H12AffineFastState.compose env41449 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound41449 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41450 : List Nat := [2,1,8,11,11,10,9,11,1,1,0,0,3,1,0,8,0,0,0,1,0,11,10,3,2,10,0,1,1,0,11,11,10,10,1,0]

theorem envBound41450 : H12AffineFastState.Bounded env41450 := by
  intro p hp
  have h : env41450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41449_41450 : H12AffineEnvironment.transform 1 1 env41449 = env41450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env41449 == env41450) = true)

theorem identity41450 : scanCanonicalize (H12AffineFastState.compose env41450 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound41450 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41451 : List Nat := [2,1,1,2,2,3,0,2,1,1,0,0,3,1,0,1,0,0,0,1,0,2,3,3,2,3,0,1,1,0,2,2,3,3,1,0]

theorem envBound41451 : H12AffineFastState.Bounded env41451 := by
  intro p hp
  have h : env41451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41450_41451 : H12AffineEnvironment.transform 2 1 env41450 = env41451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env41450 == env41451) = true)

theorem identity41451 : scanCanonicalize (H12AffineFastState.compose env41451 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound41451 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env41452 : List Nat := [0,1,1,0,0,1,0,0,1,1,0,0,1,1,0,1,0,0,0,1,0,0,1,1,0,1,0,1,1,0,0,0,1,1,1,0]

theorem envBound41452 : H12AffineFastState.Bounded env41452 := by
  intro p hp
  have h : env41452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41451_41452 : H12AffineEnvironment.transform 0 0 env41451 = env41452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env41451 == env41452) = true)

def env41453 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5465,1296,325,5238,1345,5367,4417,324,4096,477,16,1126,145,5377,4414,1297,1296,7268,5460,5456,257,1280,1345,5953]

theorem envBound41453 : H12AffineFastState.Bounded env41453 := by
  intro p hp
  have h : env41453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41439_41453 : H12AffineEnvironment.transform 12 5465 env41439 = env41453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5465 env41439 == env41453) = true)

theorem identity41453 : scanCanonicalize (H12AffineFastState.compose env41453 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound41453 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env41454 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,4096,4445,276,325,4210,325,4339,4417,324,4096,477,16,98,145,4357,4414,277,276,6240,4432,4436,257,260,325,4933]

theorem envBound41454 : H12AffineFastState.Bounded env41454 := by
  intro p hp
  have h : env41454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41453_41454 : H12AffineEnvironment.transform 9 4 env41453 = env41454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env41453 == env41454) = true)

theorem identity41454 : scanCanonicalize (H12AffineFastState.compose env41454 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 325) := by decide +kernel

theorem selectedBound41454 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env41455 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,325,24,276,325,311,325,438,4,324,325,477,16,98,145,64,123,277,276,2341,21,17,257,260,325,512]

theorem envBound41455 : H12AffineFastState.Bounded env41455 := by
  intro p hp
  have h : env41455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41454_41455 : H12AffineEnvironment.transform 11 325 env41454 = env41455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 325 env41454 == env41455) = true)

theorem identity41455 : scanCanonicalize (H12AffineFastState.compose env41455 (packedSelected [2,5,8,13] rootPS)) = affineNative (2^(10+1) ^^^ 471) := by decide +kernel

theorem selectedBound41455 : packedSelected [2,5,8,13] rootPS < 2^1333 := by decide +kernel

def env41456 : List Nat := [2,4,8,16,32,64,128,256,512,4,471,325,24,276,325,311,325,438,4,324,325,477,16,98,145,64,123,277,276,242,21,17,257,260,325,512]

theorem envBound41456 : H12AffineFastState.Bounded env41456 := by
  intro p hp
  have h : env41456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41455_41456 : H12AffineEnvironment.transform 10 471 env41455 = env41456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 471 env41455 == env41456) = true)

theorem identity41456 : scanCanonicalize (H12AffineFastState.compose env41456 (packedSelected [0,2,5,7,8,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound41456 : packedSelected [0,2,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env41457 : List Nat := [2,4,8,16,32,64,56,256,512,4,367,325,24,276,325,311,325,270,4,324,325,357,16,98,41,64,123,277,276,74,21,17,257,260,325,512]

theorem envBound41457 : H12AffineFastState.Bounded env41457 := by
  intro p hp
  have h : env41457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41456_41457 : H12AffineEnvironment.transform 6 56 env41456 = env41457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env41456 == env41457) = true)

theorem identity41457 : scanCanonicalize (H12AffineFastState.compose env41457 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound41457 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env41458 : List Nat := [2,4,8,16,32,64,56,256,49,4,367,325,24,276,325,311,325,270,4,324,325,357,16,98,41,64,123,277,276,74,21,17,257,260,325,49]

theorem envBound41458 : H12AffineFastState.Bounded env41458 := by
  intro p hp
  have h : env41458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41457_41458 : H12AffineEnvironment.transform 8 49 env41457 = env41458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env41457 == env41458) = true)

theorem identity41458 : scanCanonicalize (H12AffineFastState.compose env41458 (packedSelected [2,3,4,5,9] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound41458 : packedSelected [2,3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env41459 : List Nat := [2,4,8,16,32,64,56,14,49,4,97,75,24,26,75,57,75,0,4,74,75,107,16,98,41,64,123,27,26,74,21,17,15,10,75,49]

theorem envBound41459 : H12AffineFastState.Bounded env41459 := by
  intro p hp
  have h : env41459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41458_41459 : H12AffineEnvironment.transform 7 14 env41458 = env41459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env41458 == env41459) = true)

theorem identity41459 : scanCanonicalize (H12AffineFastState.compose env41459 (packedSelected [1,2,5] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound41459 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env41460 : List Nat := [2,4,8,16,32,58,56,14,49,4,27,49,24,26,49,57,49,0,4,48,49,17,16,24,41,58,1,27,26,48,21,17,15,10,49,49]

theorem envBound41460 : H12AffineFastState.Bounded env41460 := by
  intro p hp
  have h : env41460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41459_41460 : H12AffineEnvironment.transform 5 58 env41459 = env41460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env41459 == env41460) = true)

theorem identity41460 : scanCanonicalize (H12AffineFastState.compose env41460 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound41460 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41461 : List Nat := [2,4,8,16,11,17,19,14,26,4,27,26,24,26,26,18,26,0,4,27,26,17,16,24,2,17,1,27,26,27,21,17,15,10,26,26]

theorem envBound41461 : H12AffineFastState.Bounded env41461 := by
  intro p hp
  have h : env41461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41460_41461 : H12AffineEnvironment.transform 4 11 env41460 = env41461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env41460 == env41461) = true)

def env41462 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74862,262144,4416,13341,4096,476,74046,69649,13769,78894,332222,74815,1296,81226,8204,65831,257,1280,1345,5952]

theorem envBound41462 : H12AffineFastState.Bounded env41462 := by
  intro p hp
  have h : env41462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41413_41462 : H12AffineEnvironment.transform 13 1297 env41413 = env41462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env41413 == env41462) = true)

def env41463 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74862,65664,4416,13341,4096,476,74046,69649,13769,78894,4414,74815,1296,81226,8204,65831,257,1280,1345,5952]

theorem envBound41463 : H12AffineFastState.Bounded env41463 := by
  intro p hp
  have h : env41463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41462_41463 : H12AffineEnvironment.transform 17 65664 env41462 = env41463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env41462 == env41463) = true)

theorem identity41463 : scanCanonicalize (H12AffineFastState.compose env41463 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12670) := by decide +kernel

theorem selectedBound41463 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env41464 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,12670,5392,12798,4416,13341,4096,476,4160,8559,13769,1360,4414,5441,1296,3124,8204,12377,257,1280,1345,5952]

theorem envBound41464 : H12AffineFastState.Bounded env41464 := by
  intro p hp
  have h : env41464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41463_41464 : H12AffineEnvironment.transform 15 12670 env41463 = env41464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12670 env41463 == env41464) = true)

def env41465 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1297,9292,8494,1344,8622,272,9293,80,476,16,8559,9625,1360,366,1297,1296,3124,8204,8201,257,1280,1345,1808]

theorem envBound41465 : H12AffineFastState.Bounded env41465 := by
  intro p hp
  have h : env41465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41464_41465 : H12AffineEnvironment.transform 11 80 env41464 = env41465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env41464 == env41465) = true)

theorem identity41465 : scanCanonicalize (H12AffineFastState.compose env41465 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 1368) := by decide +kernel

theorem selectedBound41465 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env41466 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,1368,1297,276,1142,1344,1270,272,277,80,476,16,1079,193,1360,366,1297,1296,3124,1364,1361,257,1280,1345,1808]

theorem envBound41466 : H12AffineFastState.Bounded env41466 := by
  intro p hp
  have h : env41466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41465_41466 : H12AffineEnvironment.transform 12 1368 env41465 = env41466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1368 env41465 == env41466) = true)

theorem identity41466 : scanCanonicalize (H12AffineFastState.compose env41466 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound41466 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env41467 : List Nat := [2,4,8,16,32,64,128,256,512,189,2048,80,485,428,276,203,509,75,272,277,80,476,16,138,193,493,366,428,429,2185,489,492,257,445,508,941]

theorem envBound41467 : H12AffineFastState.Bounded env41467 := by
  intro p hp
  have h : env41467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41466_41467 : H12AffineEnvironment.transform 9 189 env41466 = env41467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env41466 == env41467) = true)

theorem identity41467 : scanCanonicalize (H12AffineFastState.compose env41467 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 216) := by decide +kernel

theorem selectedBound41467 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env41468 : List Nat := [2,4,8,16,32,64,128,256,216,189,2048,80,485,428,276,203,509,75,272,277,80,476,16,138,193,493,366,428,429,2185,489,492,257,445,508,373]

theorem envBound41468 : H12AffineFastState.Bounded env41468 := by
  intro p hp
  have h : env41468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41467_41468 : H12AffineEnvironment.transform 8 216 env41467 = env41468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env41467 == env41468) = true)

theorem identity41468 : scanCanonicalize (H12AffineFastState.compose env41468 (packedSelected [0,2,3,7,8,10,13,16] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound41468 : packedSelected [0,2,3,7,8,10,13,16] rootPS < 2^1333 := by decide +kernel

def env41469 : List Nat := [2,4,8,16,32,64,128,62,216,189,2048,80,219,146,42,203,195,75,46,43,80,226,16,138,193,211,80,146,147,2185,215,210,63,131,194,75]

theorem envBound41469 : H12AffineFastState.Bounded env41469 := by
  intro p hp
  have h : env41469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41468_41469 : H12AffineEnvironment.transform 7 62 env41468 = env41469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env41468 == env41469) = true)

theorem identity41469 : scanCanonicalize (H12AffineFastState.compose env41469 (packedSelected [0,4,7,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 194) := by decide +kernel

theorem selectedBound41469 : packedSelected [0,4,7,9,10] rootPS < 2^1333 := by decide +kernel

def env41470 : List Nat := [2,4,8,16,32,64,128,62,216,189,194,80,219,146,42,203,195,75,46,43,80,226,16,138,193,211,80,146,147,75,215,210,63,131,194,75]

theorem envBound41470 : H12AffineFastState.Bounded env41470 := by
  intro p hp
  have h : env41470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41469_41470 : H12AffineEnvironment.transform 10 194 env41469 = env41470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 194 env41469 == env41470) = true)

theorem identity41470 : scanCanonicalize (H12AffineFastState.compose env41470 (packedSelected [2,3,4,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 115) := by decide +kernel

theorem selectedBound41470 : packedSelected [2,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env41471 : List Nat := [2,4,8,16,32,64,115,62,43,78,49,80,40,97,42,56,48,75,46,43,80,17,16,121,50,32,80,97,96,75,36,33,63,112,49,75]

theorem envBound41471 : H12AffineFastState.Bounded env41471 := by
  intro p hp
  have h : env41471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41470_41471 : H12AffineEnvironment.transform 6 115 env41470 = env41471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 115 env41470 == env41471) = true)

theorem identity41471 : scanCanonicalize (H12AffineFastState.compose env41471 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound41471 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41472 : List Nat := [2,4,8,16,32,11,56,62,43,5,49,27,40,42,42,56,48,0,46,43,27,17,16,50,50,32,27,42,43,0,36,33,63,59,49,0]

theorem envBound41472 : H12AffineFastState.Bounded env41472 := by
  intro p hp
  have h : env41472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41471_41472 : H12AffineEnvironment.transform 5 11 env41471 = env41472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env41471 == env41472) = true)

theorem identity41472 : scanCanonicalize (H12AffineFastState.compose env41472 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound41472 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env41473 : List Nat := [2,4,8,16,17,11,9,15,26,5,0,27,25,27,27,9,1,0,31,26,27,17,16,3,3,17,27,27,26,0,21,16,14,10,0,0]

theorem envBound41473 : H12AffineFastState.Bounded env41473 := by
  intro p hp
  have h : env41473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41472_41473 : H12AffineEnvironment.transform 4 17 env41472 = env41473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env41472 == env41473) = true)

theorem identity41473 : scanCanonicalize (H12AffineFastState.compose env41473 (packedSelected [0,1,4] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound41473 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env41474 : List Nat := [2,4,8,13,12,11,9,15,7,5,0,6,4,6,6,9,1,0,2,7,6,12,13,3,3,12,6,6,7,0,8,13,14,10,0,0]

theorem envBound41474 : H12AffineFastState.Bounded env41474 := by
  intro p hp
  have h : env41474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41473_41474 : H12AffineEnvironment.transform 3 13 env41473 = env41474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env41473 == env41474) = true)

theorem identity41474 : scanCanonicalize (H12AffineFastState.compose env41474 (packedSelected [0,1,7] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound41474 : packedSelected [0,1,7] rootPS < 2^1333 := by decide +kernel

def env41475 : List Nat := [2,2,8,11,10,11,9,9,1,3,0,0,2,0,0,9,1,0,2,1,0,10,11,3,3,10,0,0,1,0,8,11,8,10,0,0]

theorem envBound41475 : H12AffineFastState.Bounded env41475 := by
  intro p hp
  have h : env41475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41474_41475 : H12AffineEnvironment.transform 1 2 env41474 = env41475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env41474 == env41475) = true)

theorem identity41475 : scanCanonicalize (H12AffineFastState.compose env41475 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound41475 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41476 : List Nat := [1,1,8,8,9,8,9,9,1,0,0,0,1,0,0,9,1,0,1,1,0,9,8,0,0,9,0,0,1,0,8,8,8,9,0,0]

theorem envBound41476 : H12AffineFastState.Bounded env41476 := by
  intro p hp
  have h : env41476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41475_41476 : H12AffineEnvironment.transform 0 1 env41475 = env41476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env41475 == env41476) = true)

theorem identity41476 : scanCanonicalize (H12AffineFastState.compose env41476 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound41476 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41477 : List Nat := [1,1,1,1,0,1,0,0,1,0,0,0,1,0,0,0,1,0,1,1,0,0,1,0,0,0,0,0,1,0,1,1,1,0,0,0]

theorem envBound41477 : H12AffineFastState.Bounded env41477 := by
  intro p hp
  have h : env41477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41476_41477 : H12AffineEnvironment.transform 2 1 env41476 = env41477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env41476 == env41477) = true)

def env41478 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1297,9293,8495,1345,8623,273,9292,81,476,17,8559,9624,1360,367,1296,1296,3124,8204,8200,257,1280,1345,1809]

theorem envBound41478 : H12AffineFastState.Bounded env41478 := by
  intro p hp
  have h : env41478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41464_41478 : H12AffineEnvironment.transform 11 81 env41464 = env41478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env41464 == env41478) = true)

theorem identity41478 : scanCanonicalize (H12AffineFastState.compose env41478 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound41478 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env41479 : List Nat := [2,4,8,16,32,64,128,21,512,1024,2048,81,8192,1028,9293,8250,1108,8378,4,9292,81,201,17,8314,9357,1093,122,1029,1029,3124,8204,8200,20,1045,1108,1540]

theorem envBound41479 : H12AffineFastState.Bounded env41479 := by
  intro p hp
  have h : env41479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41478_41479 : H12AffineEnvironment.transform 7 21 env41478 = env41479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env41478 == env41479) = true)

theorem identity41479 : scanCanonicalize (H12AffineFastState.compose env41479 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound41479 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env41480 : List Nat := [2,4,8,16,32,64,128,21,512,4,2048,81,8192,0,8265,8250,80,8378,4,8264,81,201,17,8314,8329,65,122,1,1,2096,8204,8200,20,17,80,512]

theorem envBound41480 : H12AffineFastState.Bounded env41480 := by
  intro p hp
  have h : env41480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41479_41480 : H12AffineEnvironment.transform 9 4 env41479 = env41480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env41479 == env41480) = true)

theorem identity41480 : scanCanonicalize (H12AffineFastState.compose env41480 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound41480 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env41481 : List Nat := [2,4,8,16,32,16,128,21,512,4,2048,1,8192,0,8217,8250,0,8378,4,8216,1,153,17,8234,8329,17,42,1,1,2096,8204,8200,20,17,0,512]

theorem envBound41481 : H12AffineFastState.Bounded env41481 := by
  intro p hp
  have h : env41481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41480_41481 : H12AffineEnvironment.transform 5 16 env41480 = env41481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env41480 == env41481) = true)

theorem identity41481 : scanCanonicalize (H12AffineFastState.compose env41481 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound41481 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41482 : List Nat := [2,4,8,16,32,16,128,21,512,4,561,1,8192,0,8217,8250,0,8378,4,8216,1,153,17,8234,8329,17,42,1,1,513,8204,8200,20,17,0,512]

theorem envBound41482 : H12AffineFastState.Bounded env41482 := by
  intro p hp
  have h : env41482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41481_41482 : H12AffineEnvironment.transform 10 561 env41481 = env41482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env41481 == env41482) = true)

theorem identity41482 : scanCanonicalize (H12AffineFastState.compose env41482 (packedSelected [3,8] rootPS)) = affineNative (2^(12+1) ^^^ 562) := by decide +kernel

theorem selectedBound41482 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env41483 : List Nat := [2,4,8,16,32,16,128,21,512,4,561,1,562,0,555,520,0,648,4,554,1,153,17,536,699,17,42,1,1,513,574,570,20,17,0,512]

theorem envBound41483 : H12AffineFastState.Bounded env41483 := by
  intro p hp
  have h : env41483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41482_41483 : H12AffineEnvironment.transform 12 562 env41482 = env41483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 562 env41482 == env41483) = true)

theorem identity41483 : scanCanonicalize (H12AffineFastState.compose env41483 (packedSelected [0,1,4,7] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound41483 : packedSelected [0,1,4,7] rootPS < 2^1333 := by decide +kernel

def env41484 : List Nat := [2,4,8,16,32,16,128,21,27,4,42,1,41,0,48,19,0,147,4,49,1,153,17,3,160,17,42,1,1,26,37,33,20,17,0,27]

theorem envBound41484 : H12AffineFastState.Bounded env41484 := by
  intro p hp
  have h : env41484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41483_41484 : H12AffineEnvironment.transform 8 27 env41483 = env41484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env41483 == env41484) = true)

theorem identity41484 : scanCanonicalize (H12AffineFastState.compose env41484 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound41484 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41485 : List Nat := [2,4,8,16,32,16,18,21,27,4,42,1,41,0,48,19,0,1,4,49,1,11,17,3,50,17,42,1,1,26,37,33,20,17,0,27]

theorem envBound41485 : H12AffineFastState.Bounded env41485 := by
  intro p hp
  have h : env41485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41484_41485 : H12AffineEnvironment.transform 6 18 env41484 = env41485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env41484 == env41485) = true)

theorem identity41485 : scanCanonicalize (H12AffineFastState.compose env41485 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound41485 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env41486 : List Nat := [2,4,8,16,11,16,18,21,27,4,1,1,2,0,27,19,0,1,4,26,1,11,17,3,25,17,1,1,1,26,14,10,20,17,0,27]

theorem envBound41486 : H12AffineFastState.Bounded env41486 := by
  intro p hp
  have h : env41486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41485_41486 : H12AffineEnvironment.transform 4 11 env41485 = env41486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env41485 == env41486) = true)

theorem identity41486 : scanCanonicalize (H12AffineFastState.compose env41486 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound41486 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env41487 : List Nat := [2,4,8,11,11,11,9,14,0,4,1,1,2,0,0,8,0,1,4,1,1,11,10,3,2,10,1,1,1,1,14,10,15,10,0,0]

theorem envBound41487 : H12AffineFastState.Bounded env41487 := by
  intro p hp
  have h : env41487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41486_41487 : H12AffineEnvironment.transform 3 11 env41486 = env41487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env41486 == env41487) = true)

theorem identity41487 : scanCanonicalize (H12AffineFastState.compose env41487 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound41487 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41488 : List Nat := [2,2,8,11,11,11,9,8,0,2,1,1,2,0,0,8,0,1,2,1,1,11,10,3,2,10,1,1,1,1,8,10,9,10,0,0]

theorem envBound41488 : H12AffineFastState.Bounded env41488 := by
  intro p hp
  have h : env41488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41487_41488 : H12AffineEnvironment.transform 1 2 env41487 = env41488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env41487 == env41488) = true)

def env41489 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74862,65665,4416,13341,4096,476,74046,69649,13769,78894,4415,74815,1296,81226,8204,65831,257,1280,1345,5952]

theorem envBound41489 : H12AffineFastState.Bounded env41489 := by
  intro p hp
  have h : env41489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41462_41489 : H12AffineEnvironment.transform 17 65665 env41462 = env41489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env41462 == env41489) = true)

theorem identity41489 : scanCanonicalize (H12AffineFastState.compose env41489 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9279) := by decide +kernel

theorem selectedBound41489 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env41490 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,9279,81,9406,4416,13341,4096,476,1281,13358,13769,4113,4415,0,1296,6517,8204,9496,257,1280,1345,5952]

theorem envBound41490 : H12AffineFastState.Bounded env41490 := by
  intro p hp
  have h : env41490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41489_41490 : H12AffineEnvironment.transform 15 9279 env41489 = env41490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9279 env41489 == env41490) = true)

def env41491 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,24,1297,5124,1063,81,1190,4416,5125,4096,476,1281,5174,5585,4113,4415,0,1296,6517,20,1280,257,1280,1345,5952]

theorem envBound41491 : H12AffineFastState.Bounded env41491 := by
  intro p hp
  have h : env41491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41490_41491 : H12AffineEnvironment.transform 12 24 env41490 = env41491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env41490 == env41491) = true)

theorem identity41491 : scanCanonicalize (H12AffineFastState.compose env41491 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound41491 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env41492 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,24,81,4420,359,81,486,4416,4421,4096,476,65,4470,4241,4113,4415,0,80,6517,20,64,257,64,1,4608]

theorem envBound41492 : H12AffineFastState.Bounded env41492 := by
  intro p hp
  have h : env41492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41491_41492 : H12AffineEnvironment.transform 9 320 env41491 = env41492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env41491 == env41492) = true)

theorem identity41492 : scanCanonicalize (H12AffineFastState.compose env41492 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound41492 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env41493 : List Nat := [2,4,8,16,32,64,128,68,512,4,2048,4096,24,81,4096,35,81,162,4100,4097,4096,152,65,4146,4241,4113,4219,0,80,6193,20,64,69,64,1,4608]

theorem envBound41493 : H12AffineFastState.Bounded env41493 := by
  intro p hp
  have h : env41493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41492_41493 : H12AffineEnvironment.transform 7 68 env41492 = env41493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env41492 == env41493) = true)

theorem identity41493 : scanCanonicalize (H12AffineFastState.compose env41493 (packedSelected [0,1,2,5,7,8,11,13,17] rootPS)) = affineNative (2^(10+1) ^^^ 29) := by decide +kernel

theorem selectedBound41493 : packedSelected [0,1,2,5,7,8,11,13,17] rootPS < 2^1333 := by decide +kernel

def env41494 : List Nat := [2,4,8,16,32,64,128,68,512,4,29,4096,24,81,4096,35,81,162,4100,4097,4096,152,65,4146,4241,4113,4219,0,80,4140,20,64,69,64,1,4608]

theorem envBound41494 : H12AffineFastState.Bounded env41494 := by
  intro p hp
  have h : env41494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41493_41494 : H12AffineEnvironment.transform 10 29 env41493 = env41494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 29 env41493 == env41494) = true)

theorem identity41494 : scanCanonicalize (H12AffineFastState.compose env41494 (packedSelected [0,1,4,7,8,9,12,13,15,18,19,23] rootPS)) = affineNative (2^(6+1) ^^^ 94) := by decide +kernel

theorem selectedBound41494 : packedSelected [0,1,4,7,8,9,12,13,15,18,19,23] rootPS < 2^1333 := by decide +kernel

def env41495 : List Nat := [2,4,8,16,32,64,94,68,512,4,29,4096,24,81,4096,35,81,124,4100,4097,4096,70,65,4146,4175,4113,4219,0,80,4140,20,64,69,64,1,4608]

theorem envBound41495 : H12AffineFastState.Bounded env41495 := by
  intro p hp
  have h : env41495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41494_41495 : H12AffineEnvironment.transform 6 94 env41494 = env41495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 94 env41494 == env41495) = true)

theorem identity41495 : scanCanonicalize (H12AffineFastState.compose env41495 (packedSelected [0,1,4,5,7,8,9,12,13] rootPS)) = affineNative (2^(8+1) ^^^ 28) := by decide +kernel

theorem selectedBound41495 : packedSelected [0,1,4,5,7,8,9,12,13] rootPS < 2^1333 := by decide +kernel

def env41496 : List Nat := [2,4,8,16,32,64,94,68,28,4,29,4096,24,81,4096,35,81,124,4100,4097,4096,70,65,4146,4175,4113,4219,0,80,4140,20,64,69,64,1,4124]

theorem envBound41496 : H12AffineFastState.Bounded env41496 := by
  intro p hp
  have h : env41496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41495_41496 : H12AffineEnvironment.transform 8 28 env41495 = env41496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 28 env41495 == env41496) = true)

theorem identity41496 : scanCanonicalize (H12AffineFastState.compose env41496 (packedSelected [2,4,5,8,9,11,12] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound41496 : packedSelected [2,4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env41497 : List Nat := [2,2,8,16,32,64,88,66,26,2,27,4096,24,81,4096,35,81,122,4098,4097,4096,64,65,4146,4169,4113,4219,0,80,4138,18,64,67,64,1,4122]

theorem envBound41497 : H12AffineFastState.Bounded env41497 := by
  intro p hp
  have h : env41497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41496_41497 : H12AffineEnvironment.transform 1 2 env41496 = env41497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env41496 == env41497) = true)

theorem identity41497 : scanCanonicalize (H12AffineFastState.compose env41497 (packedSelected [3] rootPS)) = affineNative (2^(11+1) ^^^ 49) := by decide +kernel

theorem selectedBound41497 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env41498 : List Nat := [2,2,8,16,32,64,88,66,26,2,27,49,24,81,49,35,81,122,51,48,49,64,65,3,120,32,74,0,80,27,18,64,67,64,1,43]

theorem envBound41498 : H12AffineFastState.Bounded env41498 := by
  intro p hp
  have h : env41498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41497_41498 : H12AffineEnvironment.transform 11 49 env41497 = env41498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env41497 == env41498) = true)

theorem identity41498 : scanCanonicalize (H12AffineFastState.compose env41498 (packedSelected [2,4,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound41498 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env41499 : List Nat := [2,2,8,10,32,64,66,66,0,2,1,43,2,75,43,35,75,96,41,42,43,64,65,3,98,32,74,0,74,1,8,64,67,64,1,43]

theorem envBound41499 : H12AffineFastState.Bounded env41499 := by
  intro p hp
  have h : env41499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41498_41499 : H12AffineEnvironment.transform 3 10 env41498 = env41499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env41498 == env41499) = true)

theorem identity41499 : scanCanonicalize (H12AffineFastState.compose env41499 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound41499 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41500 : List Nat := [2,2,8,10,32,33,35,35,0,2,1,43,2,42,43,35,42,1,41,42,43,33,32,3,3,32,43,0,43,1,8,33,34,33,1,43]

theorem envBound41500 : H12AffineFastState.Bounded env41500 := by
  intro p hp
  have h : env41500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41499_41500 : H12AffineEnvironment.transform 5 33 env41499 = env41500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env41499 == env41500) = true)

theorem identity41500 : scanCanonicalize (H12AffineFastState.compose env41500 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound41500 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41501 : List Nat := [2,2,8,10,10,11,9,9,0,2,1,1,2,0,1,9,0,1,3,0,1,11,10,3,3,10,1,0,1,1,8,11,8,11,1,1]

theorem envBound41501 : H12AffineFastState.Bounded env41501 := by
  intro p hp
  have h : env41501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41500_41501 : H12AffineEnvironment.transform 4 10 env41500 = env41501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env41500 == env41501) = true)

theorem identity41501 : scanCanonicalize (H12AffineFastState.compose env41501 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound41501 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41502 : List Nat := [2,2,0,2,2,3,1,1,0,2,1,1,2,0,1,1,0,1,3,0,1,3,2,3,3,2,1,0,1,1,0,3,0,3,1,1]

theorem envBound41502 : H12AffineFastState.Bounded env41502 := by
  intro p hp
  have h : env41502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41501_41502 : H12AffineEnvironment.transform 2 0 env41501 = env41502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env41501 == env41502) = true)

theorem identity41502 : scanCanonicalize (H12AffineFastState.compose env41502 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound41502 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env41503 : List Nat := [1,1,0,1,1,0,1,1,0,1,1,1,1,0,1,1,0,1,0,0,1,0,1,0,0,1,1,0,1,1,0,0,0,0,1,1]

theorem envBound41503 : H12AffineFastState.Bounded env41503 := by
  intro p hp
  have h : env41503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41502_41503 : H12AffineEnvironment.transform 0 1 env41502 = env41503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env41502 == env41503) = true)

def env41504 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,25,1297,5125,1062,81,1191,4416,5124,4096,476,1281,5175,5584,4113,4415,0,1296,6517,21,1281,257,1280,1345,5952]

theorem envBound41504 : H12AffineFastState.Bounded env41504 := by
  intro p hp
  have h : env41504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41490_41504 : H12AffineEnvironment.transform 12 25 env41490 = env41504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env41490 == env41504) = true)

theorem identity41504 : scanCanonicalize (H12AffineFastState.compose env41504 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 324) := by decide +kernel

theorem selectedBound41504 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env41505 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,324,25,1297,1345,1062,81,1191,4,1344,324,476,1281,1395,1172,341,123,0,1296,2097,21,1281,257,1280,1345,1540]

theorem envBound41505 : H12AffineFastState.Bounded env41505 := by
  intro p hp
  have h : env41505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41504_41505 : H12AffineEnvironment.transform 11 324 env41504 = env41505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 324 env41504 == env41505) = true)

theorem identity41505 : scanCanonicalize (H12AffineFastState.compose env41505 (packedSelected [0,3,4,5,7,9,10,12,13,15,18,23] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound41505 : packedSelected [0,3,4,5,7,9,10,12,13,15,18,23] rootPS < 2^1333 := by decide +kernel

def env41506 : List Nat := [2,4,8,16,32,64,105,256,512,1024,2048,324,25,1297,1345,1062,81,1102,4,1344,324,309,1281,1395,1149,341,123,0,1296,2097,21,1281,257,1280,1345,1540]

theorem envBound41506 : H12AffineFastState.Bounded env41506 := by
  intro p hp
  have h : env41506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41505_41506 : H12AffineEnvironment.transform 6 105 env41505 = env41506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env41505 == env41506) = true)

theorem identity41506 : scanCanonicalize (H12AffineFastState.compose env41506 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 863) := by decide +kernel

theorem selectedBound41506 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env41507 : List Nat := [2,4,8,16,32,64,105,256,512,1024,863,324,25,1297,1345,1062,81,1102,4,1344,324,309,1281,1395,1149,341,123,0,1296,878,21,1281,257,1280,1345,1540]

end H12CloudChart2