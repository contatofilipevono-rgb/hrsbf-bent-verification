import H12CloudChart2Data064

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound15912 : packedSelected [1,3,15,24,28,38] rootPS < 2^1333 := by decide +kernel

def env15913 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1297,32768,65536,1297,262144,1025,32769,1297,4194304,17,98564,8328,17,4456708,1296,1297,43049,1284,4194441,257,98599,1297,512]

theorem envBound15913 : H12AffineFastState.Bounded env15913 := by
  intro p hp
  have h : env15913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15912_15913 : H12AffineEnvironment.transform 5 17 env15912 = env15913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15912 == env15913) = true)

theorem identity15913 : scanCanonicalize (H12AffineFastState.compose env15913 (packedSelected [1,3,5] rootPS)) = affineNative (2^(17+1) ^^^ 66436) := by decide +kernel

theorem selectedBound15913 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env15914 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1297,32768,65536,1297,66436,1025,32769,1297,4194304,17,98564,8328,17,4260480,1296,1297,43049,1284,4194441,257,98599,1297,512]

theorem envBound15914 : H12AffineFastState.Bounded env15914 := by
  intro p hp
  have h : env15914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15913_15914 : H12AffineEnvironment.transform 17 66436 env15913 = env15914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 66436 env15913 == env15914) = true)

theorem identity15914 : scanCanonicalize (H12AffineFastState.compose env15914 (packedSelected [1,3,8] rootPS)) = affineNative (2^(14+1) ^^^ 9093) := by decide +kernel

theorem selectedBound15914 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env15915 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1297,9093,65536,1297,66436,1025,9092,1297,4194304,17,74369,8328,17,4260480,1296,1297,2988,1284,4194441,257,74402,1297,512]

theorem envBound15915 : H12AffineFastState.Bounded env15915 := by
  intro p hp
  have h : env15915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15914_15915 : H12AffineEnvironment.transform 14 9093 env15914 = env15915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9093 env15914 == env15915) = true)

theorem identity15915 : scanCanonicalize (H12AffineFastState.compose env15915 (packedSelected [1,12,13] rootPS)) = affineNative (2^(15+1) ^^^ 2720) := by decide +kernel

theorem selectedBound15915 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env15916 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1297,9093,2720,1297,2340,1025,9092,1297,4194304,17,10273,8328,17,4196384,1296,1297,2988,1284,4194441,257,10242,1297,512]

theorem envBound15916 : H12AffineFastState.Bounded env15916 := by
  intro p hp
  have h : env15916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15915_15916 : H12AffineEnvironment.transform 15 2720 env15915 = env15916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2720 env15915 == env15916) = true)

theorem identity15916 : scanCanonicalize (H12AffineFastState.compose env15916 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 2218) := by decide +kernel

theorem selectedBound15916 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env15917 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,2218,1297,2863,2720,1297,2340,1025,2862,1297,4194304,17,139,2082,17,4196384,1296,1297,2988,1284,4194441,257,168,1297,512]

theorem envBound15917 : H12AffineFastState.Bounded env15917 := by
  intro p hp
  have h : env15917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15916_15917 : H12AffineEnvironment.transform 12 2218 env15916 = env15917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2218 env15916 == env15917) = true)

theorem identity15917 : scanCanonicalize (H12AffineFastState.compose env15917 (packedSelected [0,2,4,6,7,9] rootPS)) = affineNative (2^(21+1) ^^^ 1977) := by decide +kernel

theorem selectedBound15917 : packedSelected [0,2,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env15918 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,2218,1297,2863,2720,1297,2340,1025,2862,1297,1977,17,139,2082,17,3993,1296,1297,2988,1284,1840,257,168,1297,512]

theorem envBound15918 : H12AffineFastState.Bounded env15918 := by
  intro p hp
  have h : env15918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15917_15918 : H12AffineEnvironment.transform 21 1977 env15917 = env15918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1977 env15917 == env15918) = true)

theorem identity15918 : scanCanonicalize (H12AffineFastState.compose env15918 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound15918 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15919 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,2218,0,2863,2720,0,2340,272,2862,0,680,17,139,2082,17,2696,1,0,2988,21,545,257,168,0,512]

theorem envBound15919 : H12AffineFastState.Bounded env15919 := by
  intro p hp
  have h : env15919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15918_15919 : H12AffineEnvironment.transform 9 273 env15918 = env15919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env15918 == env15919) = true)

theorem identity15919 : scanCanonicalize (H12AffineFastState.compose env15919 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 423) := by decide +kernel

theorem selectedBound15919 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15920 : List Nat := [2,4,8,16,32,17,128,256,512,273,423,1,269,0,648,775,0,131,272,649,0,680,17,139,389,17,815,1,0,523,21,545,257,168,0,512]

theorem envBound15920 : H12AffineFastState.Bounded env15920 := by
  intro p hp
  have h : env15920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15919_15920 : H12AffineEnvironment.transform 10 423 env15919 = env15920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 423 env15919 == env15920) = true)

theorem identity15920 : scanCanonicalize (H12AffineFastState.compose env15920 (packedSelected [2,6] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound15920 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15921 : List Nat := [2,4,8,16,32,17,128,256,137,273,423,1,269,0,1,398,0,131,272,0,0,33,17,139,389,17,422,1,0,130,21,168,257,168,0,137]

theorem envBound15921 : H12AffineFastState.Bounded env15921 := by
  intro p hp
  have h : env15921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15920_15921 : H12AffineEnvironment.transform 8 137 env15920 = env15921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env15920 == env15921) = true)

theorem identity15921 : scanCanonicalize (H12AffineFastState.compose env15921 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound15921 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15922 : List Nat := [2,4,8,16,32,17,128,20,137,5,179,1,25,0,1,154,0,131,4,0,0,33,17,139,145,17,178,1,0,130,21,168,21,168,0,137]

theorem envBound15922 : H12AffineFastState.Bounded env15922 := by
  intro p hp
  have h : env15922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15921_15922 : H12AffineEnvironment.transform 7 20 env15921 = env15922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env15921 == env15922) = true)

def env15923 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32769,4097,4194304,17664,16777216,8328,541008,4477268,16384,545089,1073741824,16876545,4294967296,256,4315938986,17420308,512]

theorem envBound15923 : H12AffineFastState.Bounded env15923 := by
  intro p hp
  have h : env15923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15884_15923 : H12AffineEnvironment.transform 16 1345 env15884 = env15923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env15884 == env15923) = true)

theorem identity15923 : scanCanonicalize (H12AffineFastState.compose env15923 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(23+1) ^^^ 98564) := by decide +kernel

theorem selectedBound15923 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env15924 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32769,4097,4194304,17664,98564,8328,541008,4477268,16384,545089,1073741824,1285,4294967296,256,4299260334,545040,512]

theorem envBound15924 : H12AffineFastState.Bounded env15924 := by
  intro p hp
  have h : env15924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15923_15924 : H12AffineEnvironment.transform 23 98564 env15923 = env15924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98564 env15923 == env15924) = true)

def env15925 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,21504,32769,4097,4194304,17664,98564,8328,5456,4477268,16384,1345,1073741824,1285,4294967296,256,4299260334,1296,512]

theorem envBound15925 : H12AffineFastState.Bounded env15925 := by
  intro p hp
  have h : env15925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15924_15925 : H12AffineEnvironment.transform 18 21504 env15924 = env15925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21504 env15924 == env15925) = true)

theorem identity15925 : scanCanonicalize (H12AffineFastState.compose env15925 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 4096) := by decide +kernel

theorem selectedBound15925 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env15926 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4096,32768,65536,1345,262144,1024,32769,4097,4194304,5376,98564,8328,5456,4456788,4096,1345,1073741824,1285,4294967296,256,4299260334,1296,512]

theorem envBound15926 : H12AffineFastState.Bounded env15926 := by
  intro p hp
  have h : env15926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15925_15926 : H12AffineEnvironment.transform 13 4096 env15925 = env15926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env15925 == env15926) = true)

def env15927 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,1297,262144,1024,32769,4097,4194304,5376,98564,8328,5376,4456708,4096,1297,1073741824,1285,4294967296,256,4299260334,1296,512]

theorem envBound15927 : H12AffineFastState.Bounded env15927 := by
  intro p hp
  have h : env15927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15926_15927 : H12AffineEnvironment.transform 5 16 env15926 = env15927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15926 == env15927) = true)

theorem identity15927 : scanCanonicalize (H12AffineFastState.compose env15927 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(31+1) ^^^ 4204933) := by decide +kernel

theorem selectedBound15927 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env15928 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,1297,262144,1024,32769,4097,4194304,5376,98564,8328,5376,4456708,4096,1297,1073741824,1285,4204933,256,108587,1296,512]

theorem envBound15928 : H12AffineFastState.Bounded env15928 := by
  intro p hp
  have h : env15928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15927_15928 : H12AffineEnvironment.transform 31 4204933 env15927 = env15928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4204933 env15927 == env15928) = true)

theorem identity15928 : scanCanonicalize (H12AffineFastState.compose env15928 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(21+1) ^^^ 773) := by decide +kernel

theorem selectedBound15928 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env15929 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,1297,262144,1024,32769,4097,773,5376,98564,8328,5376,262657,4096,1297,1073741824,1285,10880,256,108587,1296,512]

theorem envBound15929 : H12AffineFastState.Bounded env15929 := by
  intro p hp
  have h : env15929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15928_15929 : H12AffineEnvironment.transform 21 773 env15928 = env15929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 773 env15928 == env15929) = true)

theorem identity15929 : scanCanonicalize (H12AffineFastState.compose env15929 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(29+1) ^^^ 33060) := by decide +kernel

theorem selectedBound15929 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env15930 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,1297,262144,1024,32769,4097,773,5376,98564,8328,5376,262657,4096,1297,33060,1285,10880,256,108587,1296,512]

theorem envBound15930 : H12AffineFastState.Bounded env15930 := by
  intro p hp
  have h : env15930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15929_15930 : H12AffineEnvironment.transform 29 33060 env15929 = env15930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 33060 env15929 == env15930) = true)

theorem identity15930 : scanCanonicalize (H12AffineFastState.compose env15930 (packedSelected [1,3,5,12,13,24] rootPS)) = affineNative (2^(15+1) ^^^ 43822) := by decide +kernel

theorem selectedBound15930 : packedSelected [1,3,5,12,13,24] rootPS < 2^1333 := by decide +kernel

def env15931 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,43822,1297,262144,1024,32769,4097,773,5376,10794,8328,5376,262657,4096,1297,33060,1285,10880,256,773,1296,512]

theorem envBound15931 : H12AffineFastState.Bounded env15931 := by
  intro p hp
  have h : env15931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15930_15931 : H12AffineEnvironment.transform 15 43822 env15930 = env15931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 43822 env15930 == env15931) = true)

theorem identity15931 : scanCanonicalize (H12AffineFastState.compose env15931 (packedSelected [8,12,13,28] rootPS)) = affineNative (2^(17+1) ^^^ 8973) := by decide +kernel

theorem selectedBound15931 : packedSelected [8,12,13,28] rootPS < 2^1333 := by decide +kernel

def env15932 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,43822,1297,8973,1024,32769,4097,773,5376,10794,8328,5376,8460,4096,1297,33060,1285,10880,256,773,1296,512]

theorem envBound15932 : H12AffineFastState.Bounded env15932 := by
  intro p hp
  have h : env15932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15931_15932 : H12AffineEnvironment.transform 17 8973 env15931 = env15932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8973 env15931 == env15932) = true)

theorem identity15932 : scanCanonicalize (H12AffineFastState.compose env15932 (packedSelected [3,8,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 2721) := by decide +kernel

theorem selectedBound15932 : packedSelected [3,8,10,12] rootPS < 2^1333 := by decide +kernel

def env15933 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,2721,4096,32768,33167,1297,2476,1024,32769,4097,773,5376,139,2601,5376,2989,4096,1297,33060,1285,33,256,773,1296,512]

theorem envBound15933 : H12AffineFastState.Bounded env15933 := by
  intro p hp
  have h : env15933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15932_15933 : H12AffineEnvironment.transform 12 2721 env15932 = env15933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2721 env15932 == env15933) = true)

theorem identity15933 : scanCanonicalize (H12AffineFastState.compose env15933 (packedSelected [4,7] rootPS)) = affineNative (2^(14+1) ^^^ 2341) := by decide +kernel

theorem selectedBound15933 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env15934 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,2721,4096,2341,2218,1297,2476,1024,2340,4097,773,5376,139,2601,5376,2989,4096,1297,2049,1285,33,256,773,1296,512]

theorem envBound15934 : H12AffineFastState.Bounded env15934 := by
  intro p hp
  have h : env15934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15933_15934 : H12AffineEnvironment.transform 14 2341 env15933 = env15934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2341 env15933 == env15934) = true)

theorem identity15934 : scanCanonicalize (H12AffineFastState.compose env15934 (packedSelected [0,2,6] rootPS)) = affineNative (2^(11+1) ^^^ 1196) := by decide +kernel

theorem selectedBound15934 : packedSelected [0,2,6] rootPS < 2^1333 := by decide +kernel

def env15935 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1196,2721,1196,2341,2218,1297,2476,1024,2340,1197,773,428,139,2601,428,2989,1196,1297,2049,1285,33,256,773,1296,512]

theorem envBound15935 : H12AffineFastState.Bounded env15935 := by
  intro p hp
  have h : env15935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15934_15935 : H12AffineEnvironment.transform 11 1196 env15934 = env15935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1196 env15934 == env15935) = true)

def env15936 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,65536,1296,262144,1024,32769,4097,4194304,5376,98564,8328,5377,4456709,4096,1296,1073741824,1285,4294967296,256,4299260334,1296,512]

theorem envBound15936 : H12AffineFastState.Bounded env15936 := by
  intro p hp
  have h : env15936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15926_15936 : H12AffineEnvironment.transform 5 17 env15926 = env15936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15926 == env15936) = true)

theorem identity15936 : scanCanonicalize (H12AffineFastState.compose env15936 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound15936 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env15937 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,65536,1296,43049,1024,32769,4097,4194304,5376,98564,8328,5377,4237612,4096,1296,1073741824,1285,4294967296,256,4299260334,1296,512]

theorem envBound15937 : H12AffineFastState.Bounded env15937 := by
  intro p hp
  have h : env15937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15936_15937 : H12AffineEnvironment.transform 17 43049 env15936 = env15937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env15936 == env15937) = true)

theorem identity15937 : scanCanonicalize (H12AffineFastState.compose env15937 (packedSelected [10,12,13] rootPS)) = affineNative (2^(15+1) ^^^ 33167) := by decide +kernel

theorem selectedBound15937 : packedSelected [10,12,13] rootPS < 2^1333 := by decide +kernel

def env15938 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,33167,1296,43049,1024,32769,4097,4194304,5376,139,8328,5377,4237612,4096,1296,1073741824,1285,4294967296,256,4299161633,1296,512]

theorem envBound15938 : H12AffineFastState.Bounded env15938 := by
  intro p hp
  have h : env15938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15937_15938 : H12AffineEnvironment.transform 15 33167 env15937 = env15938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33167 env15937 == env15938) = true)

theorem identity15938 : scanCanonicalize (H12AffineFastState.compose env15938 (packedSelected [11,32] rootPS)) = affineNative (2^(29+1) ^^^ 4196613) := by decide +kernel

theorem selectedBound15938 : packedSelected [11,32] rootPS < 2^1333 := by decide +kernel

def env15939 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,33167,1296,43049,1024,32769,4097,4194304,5376,139,8328,5377,4237612,4096,1296,4196613,1285,4294967296,256,4299161633,1296,512]

theorem envBound15939 : H12AffineFastState.Bounded env15939 := by
  intro p hp
  have h : env15939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15938_15939 : H12AffineEnvironment.transform 29 4196613 env15938 = env15939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4196613 env15938 == env15939) = true)

def env15940 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1296,32768,33167,1296,43049,1024,32769,1297,4194304,16,139,8328,17,4237612,1296,1296,4196613,1285,4294967296,256,4299161633,1296,512]

theorem envBound15940 : H12AffineFastState.Bounded env15940 := by
  intro p hp
  have h : env15940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15939_15940 : H12AffineEnvironment.transform 11 1296 env15939 = env15940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env15939 == env15940) = true)

theorem identity15940 : scanCanonicalize (H12AffineFastState.compose env15940 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 4229769) := by decide +kernel

theorem selectedBound15940 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15941 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1296,32768,33167,1296,43049,1024,32769,1297,4194304,16,139,8328,17,4237612,1296,1296,4196613,1285,4229769,256,35496,1296,512]

theorem envBound15941 : H12AffineFastState.Bounded env15941 := by
  intro p hp
  have h : env15941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15940_15941 : H12AffineEnvironment.transform 31 4229769 env15940 = env15941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4229769 env15940 == env15941) = true)

theorem identity15941 : scanCanonicalize (H12AffineFastState.compose env15941 (packedSelected [3] rootPS)) = affineNative (2^(21+1) ^^^ 41261) := by decide +kernel

theorem selectedBound15941 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env15942 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1296,32768,33167,1296,43049,1024,32769,1297,41261,16,139,8328,17,2049,1296,1296,43048,1285,11172,256,35496,1296,512]

theorem envBound15942 : H12AffineFastState.Bounded env15942 := by
  intro p hp
  have h : env15942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15941_15942 : H12AffineEnvironment.transform 21 41261 env15941 = env15942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41261 env15941 == env15942) = true)

theorem identity15942 : scanCanonicalize (H12AffineFastState.compose env15942 (packedSelected [5] rootPS)) = affineNative (2^(14+1) ^^^ 2560) := by decide +kernel

theorem selectedBound15942 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env15943 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1296,2560,2959,1296,8745,1024,2561,1297,11053,16,139,8328,17,2049,1296,1296,8744,1285,11172,256,168,1296,512]

theorem envBound15943 : H12AffineFastState.Bounded env15943 := by
  intro p hp
  have h : env15943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15942_15943 : H12AffineEnvironment.transform 14 2560 env15942 = env15943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2560 env15942 == env15943) = true)

theorem identity15943 : scanCanonicalize (H12AffineFastState.compose env15943 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound15943 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env15944 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1296,8192,1296,2185,2310,1296,8352,1024,2184,1297,10660,16,139,8328,17,2049,1296,1296,8353,1285,10541,256,168,1296,137]

theorem envBound15944 : H12AffineFastState.Bounded env15944 := by
  intro p hp
  have h : env15944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15943_15944 : H12AffineEnvironment.transform 8 137 env15943 = env15944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env15943 == env15944) = true)

def env15945 : List Nat := [2,4,8,16,32,17,8,256,1,1024,2048,1296,8192,1296,2049,2310,1296,8232,1024,2048,1297,10540,16,3,8192,17,2049,1296,1296,8233,1285,10541,256,32,1296,1]

theorem envBound15945 : H12AffineFastState.Bounded env15945 := by
  intro p hp
  have h : env15945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15944_15945 : H12AffineEnvironment.transform 6 8 env15944 = env15945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15944 == env15945) = true)

theorem identity15945 : scanCanonicalize (H12AffineFastState.compose env15945 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 2348) := by decide +kernel

theorem selectedBound15945 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15946 : List Nat := [2,4,8,16,32,17,8,256,1,1024,2048,1296,2348,1296,2049,2310,1296,2308,1024,2048,1297,0,16,3,2348,17,2049,1296,1296,2309,1285,1,256,32,1296,1]

theorem envBound15946 : H12AffineFastState.Bounded env15946 := by
  intro p hp
  have h : env15946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15945_15946 : H12AffineEnvironment.transform 12 2348 env15945 = env15946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2348 env15945 == env15946) = true)

def env15947 : List Nat := [2,4,8,16,0,17,8,256,1,1024,2048,1296,2316,1296,2049,2310,1296,2308,1024,2048,1297,0,16,3,2316,17,2049,1296,1296,2309,1285,1,256,0,1296,1]

theorem envBound15947 : H12AffineFastState.Bounded env15947 := by
  intro p hp
  have h : env15947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15946_15947 : H12AffineEnvironment.transform 4 0 env15946 = env15947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15946 == env15947) = true)

def env15948 : List Nat := [2,4,8,16,1,17,8,256,1,1024,2048,1296,2317,1296,2049,2310,1296,2308,1024,2048,1297,0,16,3,2317,17,2049,1296,1296,2309,1285,1,256,1,1296,1]

theorem envBound15948 : H12AffineFastState.Bounded env15948 := by
  intro p hp
  have h : env15948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15946_15948 : H12AffineEnvironment.transform 4 1 env15946 = env15948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15946 == env15948) = true)

theorem identity15948 : scanCanonicalize (H12AffineFastState.compose env15948 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound15948 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15949 : List Nat := [2,4,8,16,1,17,8,5,1,1024,2048,1045,2056,1045,2049,2051,1045,2049,1024,2048,1044,0,16,3,2056,17,2049,1045,1045,2048,1024,1,5,1,1045,1]

theorem envBound15949 : H12AffineFastState.Bounded env15949 := by
  intro p hp
  have h : env15949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15948_15949 : H12AffineEnvironment.transform 7 5 env15948 = env15949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env15948 == env15949) = true)

def leafEnv15949 : List Nat := [2,4,8,16,1,17,8,5,1,1024,2048,1045,2056,1045,2049,2051,1045,2049,1024,2048,1044,0,16,3,1024,2056,1,17,2049,1045,1045,2048,1024,1,5,1,4,2050,1045,1,0,1044,1]

def active15949 : List Nat := [0,1,2,3,9,10]

def tree15949 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15949 : H12WitnessSearch.Good tree15949 := H12GlobalWitnessIndex.good

theorem leafIdentity15949 : H12AffineFastState.composeSystem env15949 rootObs = leafEnv15949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15949 rootObs == leafEnv15949) = true)

theorem terminalChecked15949 : H12PackedTerminal.terminalCheckFast leafEnv15949 active15949 tree15949 = true := by decide +kernel

def env15950 : List Nat := [2,4,8,16,32,17,9,256,0,1024,2048,1296,8192,1296,2048,2310,1296,8233,1024,2049,1297,10541,16,2,8193,17,2049,1296,1296,8232,1285,10541,256,33,1296,0]

theorem envBound15950 : H12AffineFastState.Bounded env15950 := by
  intro p hp
  have h : env15950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15944_15950 : H12AffineEnvironment.transform 6 9 env15944 = env15950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15944 == env15950) = true)

theorem identity15950 : scanCanonicalize (H12AffineFastState.compose env15950 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 2057) := by decide +kernel

theorem selectedBound15950 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15951 : List Nat := [2,4,8,16,32,17,9,256,0,1024,2048,1296,2057,1296,2048,2310,1296,2080,1024,2049,1297,292,16,2,2056,17,2049,1296,1296,2081,1285,292,256,33,1296,0]

theorem envBound15951 : H12AffineFastState.Bounded env15951 := by
  intro p hp
  have h : env15951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15950_15951 : H12AffineEnvironment.transform 12 2057 env15950 = env15951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2057 env15950 == env15951) = true)

def env15952 : List Nat := [2,4,8,16,0,17,9,256,0,1024,2048,1296,2057,1296,2048,2310,1296,2048,1024,2049,1297,260,16,2,2056,17,2049,1296,1296,2049,1285,260,256,1,1296,0]

theorem envBound15952 : H12AffineFastState.Bounded env15952 := by
  intro p hp
  have h : env15952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15951_15952 : H12AffineEnvironment.transform 4 0 env15951 = env15952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15951 == env15952) = true)

def leafEnv15952 : List Nat := [2,4,8,16,0,17,9,256,0,1024,2048,1296,2057,1296,2048,2310,1296,2048,1024,2049,1297,260,16,2,1285,2056,1,17,2049,1296,1296,2049,1285,260,256,1,4,2310,1296,0,0,1297,1]

def active15952 : List Nat := [0,1,2,3,7,9,10]

def tree15952 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15952 : H12WitnessSearch.Good tree15952 := H12GlobalWitnessIndex.good

theorem leafIdentity15952 : H12AffineFastState.composeSystem env15952 rootObs = leafEnv15952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15952 rootObs == leafEnv15952) = true)

theorem terminalChecked15952 : H12PackedTerminal.terminalCheckFast leafEnv15952 active15952 tree15952 = true := by decide +kernel

def env15953 : List Nat := [2,4,8,16,1,17,9,256,0,1024,2048,1296,2057,1296,2048,2310,1296,2049,1024,2049,1297,261,16,2,2056,17,2049,1296,1296,2048,1285,261,256,0,1296,0]

theorem envBound15953 : H12AffineFastState.Bounded env15953 := by
  intro p hp
  have h : env15953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15951_15953 : H12AffineEnvironment.transform 4 1 env15951 = env15953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15951 == env15953) = true)

theorem identity15953 : scanCanonicalize (H12AffineFastState.compose env15953 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound15953 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15954 : List Nat := [2,4,8,16,1,17,9,5,0,1024,2048,1045,2057,1045,2048,2051,1045,2049,1024,2049,1044,0,16,2,2056,17,2049,1045,1045,2048,1024,0,5,0,1045,0]

theorem envBound15954 : H12AffineFastState.Bounded env15954 := by
  intro p hp
  have h : env15954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15953_15954 : H12AffineEnvironment.transform 7 5 env15953 = env15954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env15953 == env15954) = true)

def leafEnv15954 : List Nat := [2,4,8,16,1,17,9,5,0,1024,2048,1045,2057,1045,2048,2051,1045,2049,1024,2049,1044,0,16,2,1024,2056,1,17,2049,1045,1045,2048,1024,0,5,0,4,2051,1045,0,0,1044,1]

def active15954 : List Nat := [0,1,2,3,9,10]

def tree15954 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15954 : H12WitnessSearch.Good tree15954 := H12GlobalWitnessIndex.good

theorem leafIdentity15954 : H12AffineFastState.composeSystem env15954 rootObs = leafEnv15954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15954 rootObs == leafEnv15954) = true)

theorem terminalChecked15954 : H12PackedTerminal.terminalCheckFast leafEnv15954 active15954 tree15954 = true := by decide +kernel

def env15955 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1297,32768,33167,1296,43049,1024,32769,1296,4194304,17,139,8328,16,4237612,1297,1296,4196613,1285,4294967296,256,4299161633,1296,512]

theorem envBound15955 : H12AffineFastState.Bounded env15955 := by
  intro p hp
  have h : env15955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15939_15955 : H12AffineEnvironment.transform 11 1297 env15939 = env15955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env15939 == env15955) = true)

theorem identity15955 : scanCanonicalize (H12AffineFastState.compose env15955 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 41380) := by decide +kernel

theorem selectedBound15955 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15956 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1297,32768,33167,1296,43049,1024,32769,1296,4194304,17,139,8328,16,4237612,1297,1296,4196613,1285,41380,256,4235653,1296,512]

theorem envBound15956 : H12AffineFastState.Bounded env15956 := by
  intro p hp
  have h : env15956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15955_15956 : H12AffineEnvironment.transform 31 41380 env15955 = env15956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 41380 env15955 == env15956) = true)

theorem identity15956 : scanCanonicalize (H12AffineFastState.compose env15956 (packedSelected [3] rootPS)) = affineNative (2^(14+1) ^^^ 8232) := by decide +kernel

theorem selectedBound15956 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env15957 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1297,8232,8615,1296,2049,1024,8233,1296,4194304,17,139,8328,16,4196612,1297,1296,4196613,1285,396,256,4194733,1296,512]

theorem envBound15957 : H12AffineFastState.Bounded env15957 := by
  intro p hp
  have h : env15957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15956_15957 : H12AffineEnvironment.transform 14 8232 env15956 = env15957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env15956 == env15957) = true)

theorem identity15957 : scanCanonicalize (H12AffineFastState.compose env15957 (packedSelected [5] rootPS)) = affineNative (2^(21+1) ^^^ 10661) := by decide +kernel

theorem selectedBound15957 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env15958 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1297,8232,8615,1296,2049,1024,8233,1296,10661,17,139,8328,16,8353,1297,1296,8352,1285,396,256,10248,1296,512]

theorem envBound15958 : H12AffineFastState.Bounded env15958 := by
  intro p hp
  have h : env15958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15957_15958 : H12AffineEnvironment.transform 21 10661 env15957 = env15958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10661 env15957 == env15958) = true)

theorem identity15958 : scanCanonicalize (H12AffineFastState.compose env15958 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound15958 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env15959 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1297,8192,1297,8232,8615,1296,2049,1024,8233,1296,10661,17,139,8328,16,8353,1297,1296,8352,1285,396,256,10248,1296,137]

theorem envBound15959 : H12AffineFastState.Bounded env15959 := by
  intro p hp
  have h : env15959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15958_15959 : H12AffineEnvironment.transform 8 137 env15958 = env15959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env15958 == env15959) = true)

theorem identity15959 : scanCanonicalize (H12AffineFastState.compose env15959 (packedSelected [0,2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound15959 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env15960 : List Nat := [2,4,8,16,32,17,128,36,137,1024,2048,1077,8192,1077,8232,8323,1076,2049,1024,8233,1076,10369,17,139,8328,16,8353,1077,1076,8352,1057,168,36,10248,1076,137]

theorem envBound15960 : H12AffineFastState.Bounded env15960 := by
  intro p hp
  have h : env15960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15959_15960 : H12AffineEnvironment.transform 7 36 env15959 = env15960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env15959 == env15960) = true)

theorem identity15960 : scanCanonicalize (H12AffineFastState.compose env15960 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound15960 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env15961 : List Nat := [2,4,8,16,0,17,128,4,137,1024,2048,1045,8192,1045,8200,8323,1044,2049,1024,8201,1044,10369,17,139,8328,16,8321,1045,1044,8320,1025,136,4,10248,1044,137]

theorem envBound15961 : H12AffineFastState.Bounded env15961 := by
  intro p hp
  have h : env15961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15960_15961 : H12AffineEnvironment.transform 4 0 env15960 = env15961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15960 == env15961) = true)

theorem identity15961 : scanCanonicalize (H12AffineFastState.compose env15961 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 2177) := by decide +kernel

theorem selectedBound15961 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env15962 : List Nat := [2,4,8,16,0,17,128,4,137,1024,2048,1045,2177,1045,2185,2050,1044,2049,1024,2184,1044,0,17,139,2057,16,2048,1045,1044,2049,1025,136,4,137,1044,137]

theorem envBound15962 : H12AffineFastState.Bounded env15962 := by
  intro p hp
  have h : env15962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15961_15962 : H12AffineEnvironment.transform 12 2177 env15961 = env15962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2177 env15961 == env15962) = true)

theorem identity15962 : scanCanonicalize (H12AffineFastState.compose env15962 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound15962 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15963 : List Nat := [2,4,8,16,0,17,9,4,0,1024,2048,1045,2056,1045,2048,2050,1044,2049,1024,2049,1044,0,17,2,2057,16,2048,1045,1044,2049,1025,1,4,0,1044,0]

theorem envBound15963 : H12AffineFastState.Bounded env15963 := by
  intro p hp
  have h : env15963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15962_15963 : H12AffineEnvironment.transform 6 9 env15962 = env15963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15962 == env15963) = true)

def leafEnv15963 : List Nat := [2,4,8,16,0,17,9,4,0,1024,2048,1045,2056,1045,2048,2050,1044,2049,1024,2049,1044,0,17,2,1025,2057,1,16,2048,1045,1044,2049,1025,1,4,0,4,2050,1044,0,0,1045,1]

def active15963 : List Nat := [0,1,2,3,9,10]

def tree15963 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15963 : H12WitnessSearch.Good tree15963 := H12GlobalWitnessIndex.good

theorem leafIdentity15963 : H12AffineFastState.composeSystem env15963 rootObs = leafEnv15963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15963 rootObs == leafEnv15963) = true)

theorem terminalChecked15963 : H12PackedTerminal.terminalCheckFast leafEnv15963 active15963 tree15963 = true := by decide +kernel

def env15964 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,21505,32769,4097,4194304,17664,98564,8328,5457,4477268,16384,1344,1073741824,1285,4294967296,256,4299260334,1297,512]

theorem envBound15964 : H12AffineFastState.Bounded env15964 := by
  intro p hp
  have h : env15964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15924_15964 : H12AffineEnvironment.transform 18 21505 env15924 = env15964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21505 env15924 == env15964) = true)

theorem identity15964 : scanCanonicalize (H12AffineFastState.compose env15964 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound15964 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env15965 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,1345,262144,1104,32769,4097,4194304,5457,98564,8328,5457,4456709,4177,1344,1073741824,1285,4294967296,256,4299260334,1297,512]

theorem envBound15965 : H12AffineFastState.Bounded env15965 := by
  intro p hp
  have h : env15965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15964_15965 : H12AffineEnvironment.transform 13 4177 env15964 = env15965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env15964 == env15965) = true)

theorem identity15965 : scanCanonicalize (H12AffineFastState.compose env15965 (packedSelected [9,22] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound15965 : packedSelected [9,22] rootPS < 2^1333 := by decide +kernel

def env15966 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,1297,262144,1024,32769,4097,4194304,5377,98564,8328,5377,4456709,4097,1296,1073741824,1285,4294967296,256,4299260334,1297,512]

theorem envBound15966 : H12AffineFastState.Bounded env15966 := by
  intro p hp
  have h : env15966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15965_15966 : H12AffineEnvironment.transform 5 16 env15965 = env15966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15965 == env15966) = true)

theorem identity15966 : scanCanonicalize (H12AffineFastState.compose env15966 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(29+1) ^^^ 4530339) := by decide +kernel

theorem selectedBound15966 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env15967 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,1297,262144,1024,32769,4097,4194304,5377,98564,8328,5377,4456709,4097,1296,4530339,1285,4294967296,256,4299260334,1297,512]

theorem envBound15967 : H12AffineFastState.Bounded env15967 := by
  intro p hp
  have h : env15967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15966_15967 : H12AffineEnvironment.transform 29 4530339 env15966 = env15967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4530339 env15966 == env15967) = true)

theorem identity15967 : scanCanonicalize (H12AffineFastState.compose env15967 (packedSelected [3,5,12,13] rootPS)) = affineNative (2^(17+1) ^^^ 76198) := by decide +kernel

theorem selectedBound15967 : packedSelected [3,5,12,13] rootPS < 2^1333 := by decide +kernel

def env15968 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,1297,76198,1024,32769,4097,4194304,5377,98564,8328,5377,4270243,4097,1296,4196613,1285,4294967296,256,4299260334,1297,512]

theorem envBound15968 : H12AffineFastState.Bounded env15968 := by
  intro p hp
  have h : env15968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15967_15968 : H12AffineEnvironment.transform 17 76198 env15967 = env15968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76198 env15967 == env15968) = true)

theorem identity15968 : scanCanonicalize (H12AffineFastState.compose env15968 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 33167) := by decide +kernel

theorem selectedBound15968 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env15969 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,33167,1297,43049,1024,32769,4097,4194304,5377,139,8328,5377,4237612,4097,1296,4196613,1285,4294967296,256,4299161633,1297,512]

theorem envBound15969 : H12AffineFastState.Bounded env15969 := by
  intro p hp
  have h : env15969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15968_15969 : H12AffineEnvironment.transform 15 33167 env15968 = env15969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33167 env15968 == env15969) = true)

def env15970 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1297,32768,33167,1297,43049,1024,32769,1297,4194304,17,139,8328,17,4237612,1297,1296,4196613,1285,4294967296,256,4299161633,1297,512]

theorem envBound15970 : H12AffineFastState.Bounded env15970 := by
  intro p hp
  have h : env15970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15969_15970 : H12AffineEnvironment.transform 11 1296 env15969 = env15970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env15969 == env15970) = true)

theorem identity15970 : scanCanonicalize (H12AffineFastState.compose env15970 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 4204813) := by decide +kernel

theorem selectedBound15970 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15971 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1297,32768,33167,1297,43049,1024,32769,1297,4194304,17,139,8328,17,4237612,1297,1296,4196613,1285,4204813,256,10540,1297,512]

theorem envBound15971 : H12AffineFastState.Bounded env15971 := by
  intro p hp
  have h : env15971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15970_15971 : H12AffineEnvironment.transform 31 4204813 env15970 = env15971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4204813 env15970 == env15971) = true)

theorem identity15971 : scanCanonicalize (H12AffineFastState.compose env15971 (packedSelected [3] rootPS)) = affineNative (2^(21+1) ^^^ 41261) := by decide +kernel

theorem selectedBound15971 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env15972 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1297,32768,33167,1297,43049,1024,32769,1297,41261,17,139,8328,17,2049,1297,1296,43048,1285,34848,256,10540,1297,512]

theorem envBound15972 : H12AffineFastState.Bounded env15972 := by
  intro p hp
  have h : env15972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15971_15972 : H12AffineEnvironment.transform 21 41261 env15971 = env15972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41261 env15971 == env15972) = true)

theorem identity15972 : scanCanonicalize (H12AffineFastState.compose env15972 (packedSelected [5] rootPS)) = affineNative (2^(14+1) ^^^ 2184) := by decide +kernel

theorem selectedBound15972 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env15973 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1297,2184,2311,1297,8353,1024,2185,1297,10661,17,139,8328,17,2049,1297,1296,8352,1285,168,256,10540,1297,512]

theorem envBound15973 : H12AffineFastState.Bounded env15973 := by
  intro p hp
  have h : env15973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15972_15973 : H12AffineEnvironment.transform 14 2184 env15972 = env15973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2184 env15972 == env15973) = true)

theorem identity15973 : scanCanonicalize (H12AffineFastState.compose env15973 (packedSelected [0,4] rootPS)) = affineNative (2^(12+1) ^^^ 2828) := by decide +kernel

theorem selectedBound15973 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env15974 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,2828,1297,2184,2311,1297,2989,1024,2185,1297,681,17,139,2948,17,2049,1297,1296,2988,1285,168,256,544,1297,512]

theorem envBound15974 : H12AffineFastState.Bounded env15974 := by
  intro p hp
  have h : env15974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15973_15974 : H12AffineEnvironment.transform 12 2828 env15973 = env15974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2828 env15973 == env15974) = true)

def env15975 : List Nat := [2,4,8,16,32,16,128,256,0,1024,2048,1296,2316,1297,2184,2311,1297,2477,1024,2185,1297,169,17,139,2436,17,2049,1297,1296,2476,1285,168,256,32,1297,0]

theorem envBound15975 : H12AffineFastState.Bounded env15975 := by
  intro p hp
  have h : env15975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15974_15975 : H12AffineEnvironment.transform 8 0 env15974 = env15975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env15974 == env15975) = true)

theorem identity15975 : scanCanonicalize (H12AffineFastState.compose env15975 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound15975 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15976 : List Nat := [2,4,8,16,32,16,40,256,0,1024,2048,1296,2316,1297,2080,2311,1297,2309,1024,2081,1297,1,17,35,2348,17,2049,1297,1296,2308,1285,0,256,32,1297,0]

theorem envBound15976 : H12AffineFastState.Bounded env15976 := by
  intro p hp
  have h : env15976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15975_15976 : H12AffineEnvironment.transform 6 40 env15975 = env15976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env15975 == env15976) = true)

def env15977 : List Nat := [2,4,8,16,0,16,8,256,0,1024,2048,1296,2316,1297,2048,2311,1297,2309,1024,2049,1297,1,17,3,2316,17,2049,1297,1296,2308,1285,0,256,0,1297,0]

theorem envBound15977 : H12AffineFastState.Bounded env15977 := by
  intro p hp
  have h : env15977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15976_15977 : H12AffineEnvironment.transform 4 0 env15976 = env15977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15976 == env15977) = true)

theorem identity15977 : scanCanonicalize (H12AffineFastState.compose env15977 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound15977 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15978 : List Nat := [2,4,8,16,0,16,8,4,0,1024,2048,1044,2056,1045,2048,2051,1045,2049,1024,2049,1045,1,17,3,2056,17,2049,1045,1044,2048,1025,0,4,0,1045,0]

theorem envBound15978 : H12AffineFastState.Bounded env15978 := by
  intro p hp
  have h : env15978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15977_15978 : H12AffineEnvironment.transform 7 4 env15977 = env15978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env15977 == env15978) = true)

def leafEnv15978 : List Nat := [2,4,8,16,0,16,8,4,0,1024,2048,1044,2056,1045,2048,2051,1045,2049,1024,2049,1045,1,17,3,1025,2056,1,17,2049,1045,1044,2048,1025,0,4,0,4,2050,1045,0,0,1045,1]

def active15978 : List Nat := [0,1,2,3,9,10]

def tree15978 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15978 : H12WitnessSearch.Good tree15978 := H12GlobalWitnessIndex.good

theorem leafIdentity15978 : H12AffineFastState.composeSystem env15978 rootObs = leafEnv15978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15978 rootObs == leafEnv15978) = true)

theorem terminalChecked15978 : H12PackedTerminal.terminalCheckFast leafEnv15978 active15978 tree15978 = true := by decide +kernel

def env15979 : List Nat := [2,4,8,16,1,16,9,256,0,1024,2048,1296,2316,1297,2049,2311,1297,2309,1024,2048,1297,1,17,2,2317,17,2049,1297,1296,2308,1285,0,256,1,1297,0]

theorem envBound15979 : H12AffineFastState.Bounded env15979 := by
  intro p hp
  have h : env15979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15976_15979 : H12AffineEnvironment.transform 4 1 env15976 = env15979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15976 == env15979) = true)

def env15980 : List Nat := [2,4,8,16,32,16,128,256,1,1024,2048,1296,2317,1297,2184,2311,1297,2476,1024,2185,1297,168,17,139,2437,17,2049,1297,1296,2477,1285,168,256,33,1297,1]

theorem envBound15980 : H12AffineFastState.Bounded env15980 := by
  intro p hp
  have h : env15980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15974_15980 : H12AffineEnvironment.transform 8 1 env15974 = env15980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env15974 == env15980) = true)

theorem identity15980 : scanCanonicalize (H12AffineFastState.compose env15980 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound15980 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15981 : List Nat := [2,4,8,16,32,16,128,5,1,1024,2048,1045,2056,1044,2184,2050,1044,2217,1024,2185,1044,168,17,139,2176,17,2049,1044,1045,2216,1024,168,5,33,1044,1]

theorem envBound15981 : H12AffineFastState.Bounded env15981 := by
  intro p hp
  have h : env15981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15980_15981 : H12AffineEnvironment.transform 7 5 env15980 = env15981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env15980 == env15981) = true)

def env15982 : List Nat := [2,4,8,16,0,16,128,5,1,1024,2048,1045,2056,1044,2184,2050,1044,2185,1024,2185,1044,136,17,139,2176,17,2049,1044,1045,2184,1024,136,5,1,1044,1]

theorem envBound15982 : H12AffineFastState.Bounded env15982 := by
  intro p hp
  have h : env15982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15981_15982 : H12AffineEnvironment.transform 4 0 env15981 = env15982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15981 == env15982) = true)

def env15983 : List Nat := [2,4,8,16,1,16,128,5,1,1024,2048,1045,2056,1044,2184,2050,1044,2184,1024,2185,1044,137,17,139,2176,17,2049,1044,1045,2185,1024,137,5,0,1044,1]

theorem envBound15983 : H12AffineFastState.Bounded env15983 := by
  intro p hp
  have h : env15983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15981_15983 : H12AffineEnvironment.transform 4 1 env15981 = env15983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15981 == env15983) = true)

theorem identity15983 : scanCanonicalize (H12AffineFastState.compose env15983 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound15983 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15984 : List Nat := [2,4,8,16,1,16,8,5,1,1024,2048,1045,2056,1044,2048,2050,1044,2048,1024,2049,1044,1,17,3,2056,17,2049,1044,1045,2049,1024,1,5,0,1044,1]

theorem envBound15984 : H12AffineFastState.Bounded env15984 := by
  intro p hp
  have h : env15984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15983_15984 : H12AffineEnvironment.transform 6 8 env15983 = env15984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15983 == env15984) = true)

def leafEnv15984 : List Nat := [2,4,8,16,1,16,8,5,1,1024,2048,1045,2056,1044,2048,2050,1044,2048,1024,2049,1044,1,17,3,1024,2056,1,17,2049,1044,1045,2049,1024,1,5,0,4,2051,1044,1,0,1044,1]

def active15984 : List Nat := [0,1,2,3,9,10]

def tree15984 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15984 : H12WitnessSearch.Good tree15984 := H12GlobalWitnessIndex.good

theorem leafIdentity15984 : H12AffineFastState.composeSystem env15984 rootObs = leafEnv15984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15984 rootObs == leafEnv15984) = true)

theorem terminalChecked15984 : H12PackedTerminal.terminalCheckFast leafEnv15984 active15984 tree15984 = true := by decide +kernel

def env15985 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,32768,33167,1297,43049,1024,32769,1296,4194304,16,139,8328,16,4237612,1296,1296,4196613,1285,4294967296,256,4299161633,1297,512]

theorem envBound15985 : H12AffineFastState.Bounded env15985 := by
  intro p hp
  have h : env15985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15969_15985 : H12AffineEnvironment.transform 11 1297 env15969 = env15985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env15969 == env15985) = true)

theorem identity15985 : scanCanonicalize (H12AffineFastState.compose env15985 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 544) := by decide +kernel

theorem selectedBound15985 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15986 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,32768,33167,1297,43049,1024,32769,1296,4194304,16,139,8328,16,4237612,1296,1296,4196613,1285,544,256,4194817,1297,512]

theorem envBound15986 : H12AffineFastState.Bounded env15986 := by
  intro p hp
  have h : env15986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15985_15986 : H12AffineEnvironment.transform 31 544 env15985 = env15986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 544 env15985 == env15986) = true)

theorem identity15986 : scanCanonicalize (H12AffineFastState.compose env15986 (packedSelected [3] rootPS)) = affineNative (2^(14+1) ^^^ 8232) := by decide +kernel

theorem selectedBound15986 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env15987 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,8232,8615,1297,2049,1024,8233,1296,4194304,16,139,8328,16,4196612,1296,1296,4196613,1285,544,256,4194817,1297,512]

theorem envBound15987 : H12AffineFastState.Bounded env15987 := by
  intro p hp
  have h : env15987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15986_15987 : H12AffineEnvironment.transform 14 8232 env15986 = env15987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env15986 == env15987) = true)

theorem identity15987 : scanCanonicalize (H12AffineFastState.compose env15987 (packedSelected [5] rootPS)) = affineNative (2^(21+1) ^^^ 11053) := by decide +kernel

theorem selectedBound15987 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env15988 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,8232,8615,1297,2049,1024,8233,1296,11053,16,139,8328,16,8745,1296,1296,8744,1285,544,256,10540,1297,512]

theorem envBound15988 : H12AffineFastState.Bounded env15988 := by
  intro p hp
  have h : env15988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15987_15988 : H12AffineEnvironment.transform 21 11053 env15987 = env15988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 11053 env15987 == env15988) = true)

theorem identity15988 : scanCanonicalize (H12AffineFastState.compose env15988 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 2601) := by decide +kernel

theorem selectedBound15988 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env15989 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,2601,1296,2561,2958,1297,2049,1024,2560,1296,260,16,139,2721,16,2048,1296,1296,2049,1285,544,256,773,1297,512]

theorem envBound15989 : H12AffineFastState.Bounded env15989 := by
  intro p hp
  have h : env15989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15988_15989 : H12AffineEnvironment.transform 12 2601 env15988 = env15989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2601 env15988 == env15989) = true)

theorem identity15989 : scanCanonicalize (H12AffineFastState.compose env15989 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound15989 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env15990 : List Nat := [2,4,8,16,32,16,128,256,293,1024,2048,1297,2316,1296,2340,2219,1297,2049,1024,2341,1296,260,16,139,2436,16,2048,1296,1296,2049,1285,261,256,32,1297,293]

theorem envBound15990 : H12AffineFastState.Bounded env15990 := by
  intro p hp
  have h : env15990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15989_15990 : H12AffineEnvironment.transform 8 293 env15989 = env15990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env15989 == env15990) = true)

theorem identity15990 : scanCanonicalize (H12AffineFastState.compose env15990 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound15990 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15991 : List Nat := [2,4,8,16,0,16,128,256,261,1024,2048,1297,2316,1296,2308,2187,1297,2049,1024,2309,1296,260,16,139,2436,16,2048,1296,1296,2049,1285,261,256,0,1297,261]

theorem envBound15991 : H12AffineFastState.Bounded env15991 := by
  intro p hp
  have h : env15991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15990_15991 : H12AffineEnvironment.transform 4 0 env15990 = env15991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15990 == env15991) = true)

def env15992 : List Nat := [2,4,8,16,0,16,8,256,261,1024,2048,1297,2316,1296,2308,2051,1297,2049,1024,2309,1296,260,16,3,2316,16,2048,1296,1296,2049,1285,261,256,0,1297,261]

theorem envBound15992 : H12AffineFastState.Bounded env15992 := by
  intro p hp
  have h : env15992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15991_15992 : H12AffineEnvironment.transform 6 8 env15991 = env15992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15991 == env15992) = true)

theorem identity15992 : scanCanonicalize (H12AffineFastState.compose env15992 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound15992 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env15993 : List Nat := [2,4,8,16,0,16,8,4,1,1024,2048,1045,2056,1044,2048,2051,1045,2049,1024,2049,1044,0,16,3,2056,16,2048,1044,1044,2049,1025,1,4,0,1045,1]

theorem envBound15993 : H12AffineFastState.Bounded env15993 := by
  intro p hp
  have h : env15993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15992_15993 : H12AffineEnvironment.transform 7 4 env15992 = env15993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env15992 == env15993) = true)

def leafEnv15993 : List Nat := [2,4,8,16,0,16,8,4,1,1024,2048,1045,2056,1044,2048,2051,1045,2049,1024,2049,1044,0,16,3,1025,2056,1,16,2048,1044,1044,2049,1025,1,4,0,4,2050,1045,1,0,1045,1]

def active15993 : List Nat := [0,1,2,3,9,10]

def tree15993 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15993 : H12WitnessSearch.Good tree15993 := H12GlobalWitnessIndex.good

theorem leafIdentity15993 : H12AffineFastState.composeSystem env15993 rootObs = leafEnv15993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15993 rootObs == leafEnv15993) = true)

theorem terminalChecked15993 : H12PackedTerminal.terminalCheckFast leafEnv15993 active15993 tree15993 = true := by decide +kernel

def env15994 : List Nat := [2,4,8,16,0,16,9,256,261,1024,2048,1297,2316,1296,2308,2050,1297,2049,1024,2309,1296,260,16,2,2317,16,2048,1296,1296,2049,1285,261,256,0,1297,261]

theorem envBound15994 : H12AffineFastState.Bounded env15994 := by
  intro p hp
  have h : env15994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15991_15994 : H12AffineEnvironment.transform 6 9 env15991 = env15994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15991 == env15994) = true)

def env15995 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,17665,16777216,8328,541009,4477269,148800,676864,1073741824,17006913,4294967296,132160,4315938986,17552725,512]

theorem envBound15995 : H12AffineFastState.Bounded env15995 := by
  intro p hp
  have h : env15995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15883_15995 : H12AffineEnvironment.transform 22 17665 env15883 = env15995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17665 env15883 == env15995) = true)

def env15996 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32769,4097,4194304,17665,16777216,8328,541009,4477269,16384,545088,1073741824,16876545,4294967296,256,4315938986,17420309,512]

theorem envBound15996 : H12AffineFastState.Bounded env15996 := by
  intro p hp
  have h : env15996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15995_15996 : H12AffineEnvironment.transform 16 1344 env15995 = env15996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env15995 == env15996) = true)

theorem identity15996 : scanCanonicalize (H12AffineFastState.compose env15996 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(18+1) ^^^ 21585) := by decide +kernel

theorem selectedBound15996 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env15997 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,21585,32769,4097,4194304,17665,16777216,8328,5376,4477269,16384,1297,1073741824,16876545,4294967296,256,4315938986,16876612,512]

theorem envBound15997 : H12AffineFastState.Bounded env15997 := by
  intro p hp
  have h : env15997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15996_15997 : H12AffineEnvironment.transform 18 21585 env15996 = env15997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env15996 == env15997) = true)

theorem identity15997 : scanCanonicalize (H12AffineFastState.compose env15997 (packedSelected [0,4,7,9,16,20] rootPS)) = affineNative (2^(11+1) ^^^ 1344) := by decide +kernel

theorem selectedBound15997 : packedSelected [0,4,7,9,16,20] rootPS < 2^1333 := by decide +kernel

def env15998 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,16384,32768,65536,1344,262144,16657,32769,1345,4194304,17665,16777216,8328,64,4473877,16384,1297,1073741824,16876545,4294967296,256,4315938986,16876612,512]

theorem envBound15998 : H12AffineFastState.Bounded env15998 := by
  intro p hp
  have h : env15998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15997_15998 : H12AffineEnvironment.transform 11 1344 env15997 = env15998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env15997 == env15998) = true)

theorem identity15998 : scanCanonicalize (H12AffineFastState.compose env15998 (packedSelected [4,16,22] rootPS)) = affineNative (2^(13+1) ^^^ 1297) := by decide +kernel

theorem selectedBound15998 : packedSelected [4,16,22] rootPS < 2^1333 := by decide +kernel

def env15999 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,65536,1344,262144,1024,32769,1345,4194304,16,16777216,8328,64,4456708,1297,1297,1073741824,16876545,4294967296,256,4315938986,16876612,512]

theorem envBound15999 : H12AffineFastState.Bounded env15999 := by
  intro p hp
  have h : env15999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15998_15999 : H12AffineEnvironment.transform 13 1297 env15998 = env15999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env15998 == env15999) = true)

theorem identity15999 : scanCanonicalize (H12AffineFastState.compose env15999 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(31+1) ^^^ 4194440) := by decide +kernel

theorem selectedBound15999 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env16000 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,65536,1344,262144,1024,32769,1345,4194304,16,16777216,8328,64,4456708,1297,1297,1073741824,16876545,4194440,256,16777250,16876612,512]

theorem envBound16000 : H12AffineFastState.Bounded env16000 := by
  intro p hp
  have h : env16000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15999_16000 : H12AffineEnvironment.transform 31 4194440 env15999 = env16000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4194440 env15999 == env16000) = true)

def env16001 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,65536,1344,8832,1024,32769,1345,4194304,16,16777216,8328,64,4203396,1297,1297,1073741824,16876545,4194440,256,16777250,16876612,512]

theorem envBound16001 : H12AffineFastState.Bounded env16001 := by
  intro p hp
  have h : env16001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16000_16001 : H12AffineEnvironment.transform 17 8832 env16000 = env16001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8832 env16000 == env16001) = true)

theorem identity16001 : scanCanonicalize (H12AffineFastState.compose env16001 (packedSelected [3,5,24] rootPS)) = affineNative (2^(23+1) ^^^ 4260100) := by decide +kernel

theorem selectedBound16001 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env16002 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,65536,1344,8832,1024,32769,1345,4194304,16,4260100,8328,64,4203396,1297,1297,1073741824,4228357,4194440,256,4260134,4228416,512]

theorem envBound16002 : H12AffineFastState.Bounded env16002 := by
  intro p hp
  have h : env16002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16001_16002 : H12AffineEnvironment.transform 23 4260100 env16001 = env16002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4260100 env16001 == env16002) = true)

def env16003 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,65536,1344,8832,1024,32769,1345,32768,16,98564,8328,64,41860,1297,1297,1073741824,1285,32904,256,98598,1344,512]

theorem envBound16003 : H12AffineFastState.Bounded env16003 := by
  intro p hp
  have h : env16003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16002_16003 : H12AffineEnvironment.transform 21 32768 env16002 = env16003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32768 env16002 == env16003) = true)

theorem identity16003 : scanCanonicalize (H12AffineFastState.compose env16003 (packedSelected [1,12,13] rootPS)) = affineNative (2^(29+1) ^^^ 43909) := by decide +kernel

theorem selectedBound16003 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env16004 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,65536,1344,8832,1024,32769,1345,32768,16,98564,8328,64,41860,1297,1297,43909,1285,32904,256,98598,1344,512]

theorem envBound16004 : H12AffineFastState.Bounded env16004 := by
  intro p hp
  have h : env16004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16003_16004 : H12AffineEnvironment.transform 29 43909 env16003 = env16004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 43909 env16003 == env16004) = true)

theorem identity16004 : scanCanonicalize (H12AffineFastState.compose env16004 (packedSelected [3,15,17] rootPS)) = affineNative (2^(15+1) ^^^ 2991) := by decide +kernel

theorem selectedBound16004 : packedSelected [3,15,17] rootPS < 2^1333 := by decide +kernel

def env16005 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,2991,1344,8832,1024,32769,1345,32768,16,35499,8328,64,41860,1297,1297,43909,1285,32904,256,35465,1344,512]

theorem envBound16005 : H12AffineFastState.Bounded env16005 := by
  intro p hp
  have h : env16005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16004_16005 : H12AffineEnvironment.transform 15 2991 env16004 = env16005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2991 env16004 == env16005) = true)

theorem identity16005 : scanCanonicalize (H12AffineFastState.compose env16005 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound16005 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env16006 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,389,1297,32768,2991,1344,773,1024,32769,1345,32768,16,35499,269,64,33281,1297,1297,35328,1285,32904,256,35465,1344,512]

theorem envBound16006 : H12AffineFastState.Bounded env16006 := by
  intro p hp
  have h : env16006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16005_16006 : H12AffineEnvironment.transform 12 389 env16005 = env16006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env16005 == env16006) = true)

theorem identity16006 : scanCanonicalize (H12AffineFastState.compose env16006 (packedSelected [8,12,38] rootPS)) = affineNative (2^(14+1) ^^^ 2592) := by decide +kernel

theorem selectedBound16006 : packedSelected [8,12,38] rootPS < 2^1333 := by decide +kernel

def env16007 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,389,1297,2592,2991,1344,773,1024,2593,1345,2592,16,139,269,64,2081,1297,1297,32,1285,2728,256,169,1344,512]

theorem envBound16007 : H12AffineFastState.Bounded env16007 := by
  intro p hp
  have h : env16007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16006_16007 : H12AffineEnvironment.transform 14 2592 env16006 = env16007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2592 env16006 == env16007) = true)

theorem identity16007 : scanCanonicalize (H12AffineFastState.compose env16007 (packedSelected [3,8,12] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound16007 : packedSelected [3,8,12] rootPS < 2^1333 := by decide +kernel

def env16008 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1344,268,1297,2592,2854,1344,773,1024,2593,1345,2592,16,2,269,64,2081,1297,1297,32,1285,2593,256,32,1344,512]

theorem envBound16008 : H12AffineFastState.Bounded env16008 := by
  intro p hp
  have h : env16008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16007_16008 : H12AffineEnvironment.transform 6 9 env16007 = env16008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16007 == env16008) = true)

theorem identity16008 : scanCanonicalize (H12AffineFastState.compose env16008 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 373) := by decide +kernel

theorem selectedBound16008 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env16009 : List Nat := [2,4,8,16,32,64,9,256,373,1024,2048,1344,268,1297,2389,2131,1344,112,1024,2388,1345,2389,16,2,269,64,2081,1297,1297,32,1285,2388,256,32,1344,373]

theorem envBound16009 : H12AffineFastState.Bounded env16009 := by
  intro p hp
  have h : env16009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16008_16009 : H12AffineEnvironment.transform 8 373 env16008 = env16009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 373 env16008 == env16009) = true)

theorem identity16009 : scanCanonicalize (H12AffineFastState.compose env16009 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound16009 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env16010 : List Nat := [2,4,8,16,32,64,9,256,373,321,2048,1,268,80,2389,2131,1,112,321,2388,0,2389,16,2,269,64,2081,80,80,32,68,2388,256,32,1,373]

theorem envBound16010 : H12AffineFastState.Bounded env16010 := by
  intro p hp
  have h : env16010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16009_16010 : H12AffineEnvironment.transform 9 321 env16009 = env16010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env16009 == env16010) = true)

theorem identity16010 : scanCanonicalize (H12AffineFastState.compose env16010 (packedSelected [0,1,2,6] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound16010 : packedSelected [0,1,2,6] rootPS < 2^1333 := by decide +kernel

def env16011 : List Nat := [2,4,8,16,32,64,9,256,373,321,33,1,268,80,372,114,1,112,321,373,0,372,16,2,269,64,0,80,80,32,68,373,256,32,1,373]

theorem envBound16011 : H12AffineFastState.Bounded env16011 := by
  intro p hp
  have h : env16011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16010_16011 : H12AffineEnvironment.transform 10 33 env16010 = env16011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env16010 == env16011) = true)

theorem identity16011 : scanCanonicalize (H12AffineFastState.compose env16011 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound16011 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16012 : List Nat := [2,4,8,16,0,64,9,256,341,321,1,1,268,80,340,82,1,80,321,341,0,340,16,2,269,64,0,80,80,0,68,341,256,0,1,341]

theorem envBound16012 : H12AffineFastState.Bounded env16012 := by
  intro p hp
  have h : env16012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16011_16012 : H12AffineEnvironment.transform 4 0 env16011 = env16012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16011 == env16012) = true)

theorem identity16012 : scanCanonicalize (H12AffineFastState.compose env16012 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound16012 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16013 : List Nat := [2,4,8,16,0,1,9,256,276,256,1,1,268,17,277,19,1,17,256,276,0,277,16,2,269,1,0,17,17,0,5,276,256,0,1,276]

theorem envBound16013 : H12AffineFastState.Bounded env16013 := by
  intro p hp
  have h : env16013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16012_16013 : H12AffineEnvironment.transform 5 1 env16012 = env16013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env16012 == env16013) = true)

def env16014 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,65536,1344,8832,1024,32769,1345,32769,16,98565,8328,64,41861,1297,1297,1073741824,1284,32905,256,98599,1345,512]

theorem envBound16014 : H12AffineFastState.Bounded env16014 := by
  intro p hp
  have h : env16014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16002_16014 : H12AffineEnvironment.transform 21 32769 env16002 = env16014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32769 env16002 == env16014) = true)

theorem identity16014 : scanCanonicalize (H12AffineFastState.compose env16014 (packedSelected [1,12,13] rootPS)) = affineNative (2^(12+1) ^^^ 2980) := by decide +kernel

theorem selectedBound16014 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env16015 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,2980,1297,32768,65536,1344,2340,1024,32769,1345,32769,16,98565,2860,64,34849,1297,1297,1073741824,1284,32905,256,98599,1345,512]

theorem envBound16015 : H12AffineFastState.Bounded env16015 := by
  intro p hp
  have h : env16015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16014_16015 : H12AffineEnvironment.transform 12 2980 env16014 = env16015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2980 env16014 == env16015) = true)

theorem identity16015 : scanCanonicalize (H12AffineFastState.compose env16015 (packedSelected [3,15,17] rootPS)) = affineNative (2^(15+1) ^^^ 35498) := by decide +kernel

theorem selectedBound16015 : packedSelected [3,15,17] rootPS < 2^1333 := by decide +kernel

def env16016 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,2980,1297,32768,35498,1344,2340,1024,32769,1345,32769,16,2991,2860,64,34849,1297,1297,1073741824,1284,32905,256,2957,1345,512]

theorem envBound16016 : H12AffineFastState.Bounded env16016 := by
  intro p hp
  have h : env16016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16015_16016 : H12AffineEnvironment.transform 15 35498 env16015 = env16016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35498 env16015 == env16016) = true)

theorem identity16016 : scanCanonicalize (H12AffineFastState.compose env16016 (packedSelected [1,8,28] rootPS)) = affineNative (2^(10+1) ^^^ 804) := by decide +kernel

theorem selectedBound16016 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env16017 : List Nat := [2,4,8,16,32,64,128,256,512,1024,804,1344,128,1297,32768,33166,1344,512,1024,32769,1345,32769,16,139,8,64,33541,1297,1297,1073741824,1284,32905,256,169,1345,512]

theorem envBound16017 : H12AffineFastState.Bounded env16017 := by
  intro p hp
  have h : env16017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16016_16017 : H12AffineEnvironment.transform 10 804 env16016 = env16017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 804 env16016 == env16017) = true)

def env16018 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,65536,1344,8833,1024,32769,1345,4194304,16,16777216,8328,64,4203397,1297,1297,1073741824,16876545,4194440,256,16777250,16876612,512]

theorem envBound16018 : H12AffineFastState.Bounded env16018 := by
  intro p hp
  have h : env16018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16000_16018 : H12AffineEnvironment.transform 17 8833 env16000 = env16018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8833 env16000 == env16018) = true)

theorem identity16018 : scanCanonicalize (H12AffineFastState.compose env16018 (packedSelected [3,5,24] rootPS)) = affineNative (2^(21+1) ^^^ 32769) := by decide +kernel

theorem selectedBound16018 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env16019 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,65536,1344,8833,1024,32769,1345,32769,16,16777216,8328,64,41860,1297,1297,1073741824,16876545,32905,256,16777250,16876612,512]

theorem envBound16019 : H12AffineFastState.Bounded env16019 := by
  intro p hp
  have h : env16019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16018_16019 : H12AffineEnvironment.transform 21 32769 env16018 = env16019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32769 env16018 == env16019) = true)

def env16020 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,65536,1344,8833,1024,32769,1345,32769,16,98304,8328,64,41860,1297,1297,1073741824,1025,32905,256,98338,1092,512]

theorem envBound16020 : H12AffineFastState.Bounded env16020 := by
  intro p hp
  have h : env16020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16019_16020 : H12AffineEnvironment.transform 23 98304 env16019 = env16020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98304 env16019 == env16020) = true)

theorem identity16020 : scanCanonicalize (H12AffineFastState.compose env16020 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound16020 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env16021 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,389,1297,32768,65536,1344,772,1024,32769,1345,32769,16,98304,269,64,33281,1297,1297,1073741824,1025,32905,256,98338,1092,512]

theorem envBound16021 : H12AffineFastState.Bounded env16021 := by
  intro p hp
  have h : env16021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16020_16021 : H12AffineEnvironment.transform 12 389 env16020 = env16021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env16020 == env16021) = true)

def env16022 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1344,269,1297,32768,65536,1344,772,1024,32769,1345,32769,16,98304,269,64,33281,1297,1297,1073741824,1025,32769,256,98338,1092,512]

theorem envBound16022 : H12AffineFastState.Bounded env16022 := by
  intro p hp
  have h : env16022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16021_16022 : H12AffineEnvironment.transform 6 8 env16021 = env16022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16021 == env16022) = true)

theorem identity16022 : scanCanonicalize (H12AffineFastState.compose env16022 (packedSelected [6,7] rootPS)) = affineNative (2^(29+1) ^^^ 101190) := by decide +kernel

theorem selectedBound16022 : packedSelected [6,7] rootPS < 2^1333 := by decide +kernel

def env16023 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1344,269,1297,32768,65536,1344,772,1024,32769,1345,32769,16,98304,269,64,33281,1297,1297,101190,1025,32769,256,98338,1092,512]

theorem envBound16023 : H12AffineFastState.Bounded env16023 := by
  intro p hp
  have h : env16023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16022_16023 : H12AffineEnvironment.transform 29 101190 env16022 = env16023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 101190 env16022 == env16023) = true)

def env16024 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1344,269,1297,1856,65536,1344,772,1024,1857,1345,1857,16,67392,269,64,1345,1297,1297,68614,1025,1857,256,67426,1092,512]

theorem envBound16024 : H12AffineFastState.Bounded env16024 := by
  intro p hp
  have h : env16024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16023_16024 : H12AffineEnvironment.transform 14 1856 env16023 = env16024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1856 env16023 == env16024) = true)

theorem identity16024 : scanCanonicalize (H12AffineFastState.compose env16024 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 774) := by decide +kernel

theorem selectedBound16024 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16025 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1344,269,1297,1856,774,1344,772,1024,1857,1345,1857,16,1094,269,64,1345,1297,1297,3840,1025,1857,256,1124,1092,512]

theorem envBound16025 : H12AffineFastState.Bounded env16025 := by
  intro p hp
  have h : env16025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16024_16025 : H12AffineEnvironment.transform 15 774 env16024 = env16025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 774 env16024 == env16025) = true)

theorem identity16025 : scanCanonicalize (H12AffineFastState.compose env16025 (packedSelected [3,5,13,17,41] rootPS)) = affineNative (2^(10+1) ^^^ 608) := by decide +kernel

theorem selectedBound16025 : packedSelected [3,5,13,17,41] rootPS < 2^1333 := by decide +kernel

def env16026 : List Nat := [2,4,8,16,32,64,8,256,512,1024,608,1344,269,1297,1856,774,1344,772,1024,1857,1345,1857,16,1094,269,64,1345,1297,1297,1376,1025,1857,256,1124,1092,512]

theorem envBound16026 : H12AffineFastState.Bounded env16026 := by
  intro p hp
  have h : env16026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16025_16026 : H12AffineEnvironment.transform 10 608 env16025 = env16026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 608 env16025 == env16026) = true)

theorem identity16026 : scanCanonicalize (H12AffineFastState.compose env16026 (packedSelected [1,4,12,23] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound16026 : packedSelected [1,4,12,23] rootPS < 2^1333 := by decide +kernel

def env16027 : List Nat := [2,4,8,16,32,64,8,20,512,1024,608,1108,25,1029,1620,530,1108,528,1024,1621,1109,1621,16,1094,25,64,1109,1029,1029,1140,1025,1621,20,1124,1092,512]

theorem envBound16027 : H12AffineFastState.Bounded env16027 := by
  intro p hp
  have h : env16027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16026_16027 : H12AffineEnvironment.transform 7 20 env16026 = env16027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env16026 == env16027) = true)

theorem identity16027 : scanCanonicalize (H12AffineFastState.compose env16027 (packedSelected [3,5,6] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound16027 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env16028 : List Nat := [2,4,8,16,32,64,8,20,17,1024,113,1108,25,1029,1093,3,1108,1,1024,1092,1109,1092,16,1094,25,64,1109,1029,1029,1140,1025,1092,20,1124,1092,17]

theorem envBound16028 : H12AffineFastState.Bounded env16028 := by
  intro p hp
  have h : env16028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16027_16028 : H12AffineEnvironment.transform 8 17 env16027 = env16028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env16027 == env16028) = true)

theorem identity16028 : scanCanonicalize (H12AffineFastState.compose env16028 (packedSelected [5] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound16028 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env16029 : List Nat := [2,4,8,16,32,64,8,20,17,20,113,64,25,17,81,3,64,1,20,80,65,80,16,82,25,64,65,17,17,96,21,80,20,112,80,17]

theorem envBound16029 : H12AffineFastState.Bounded env16029 := by
  intro p hp
  have h : env16029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16028_16029 : H12AffineEnvironment.transform 9 20 env16028 = env16029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env16028 == env16029) = true)

theorem identity16029 : scanCanonicalize (H12AffineFastState.compose env16029 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound16029 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env16030 : List Nat := [2,4,8,16,32,33,8,20,17,20,16,33,25,17,48,3,33,1,20,49,32,49,16,51,25,33,32,17,17,1,21,49,20,17,49,17]

theorem envBound16030 : H12AffineFastState.Bounded env16030 := by
  intro p hp
  have h : env16030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16029_16030 : H12AffineEnvironment.transform 5 33 env16029 = env16030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env16029 == env16030) = true)

theorem identity16030 : scanCanonicalize (H12AffineFastState.compose env16030 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound16030 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env16031 : List Nat := [2,4,8,16,17,16,8,20,17,20,16,16,25,17,1,3,16,1,20,0,17,0,16,2,25,16,17,17,17,1,21,0,20,17,0,17]

theorem envBound16031 : H12AffineFastState.Bounded env16031 := by
  intro p hp
  have h : env16031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16030_16031 : H12AffineEnvironment.transform 4 17 env16030 = env16031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env16030 == env16031) = true)

def env16032 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1344,269,1297,1857,65536,1344,772,1024,1856,1345,1856,16,67393,269,64,1344,1297,1297,68615,1025,1856,256,67427,1092,512]

theorem envBound16032 : H12AffineFastState.Bounded env16032 := by
  intro p hp
  have h : env16032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16023_16032 : H12AffineEnvironment.transform 14 1857 env16023 = env16032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1857 env16023 == env16032) = true)

theorem identity16032 : scanCanonicalize (H12AffineFastState.compose env16032 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 515) := by decide +kernel

theorem selectedBound16032 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16033 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1344,269,1297,1857,515,1344,772,1024,1856,1345,1856,16,1346,269,64,1344,1297,1297,3588,1025,1856,256,1376,1092,512]

theorem envBound16033 : H12AffineFastState.Bounded env16033 := by
  intro p hp
  have h : env16033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16032_16033 : H12AffineEnvironment.transform 15 515 env16032 = env16033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 515 env16032 == env16033) = true)

def env16034 : List Nat := [2,4,8,16,32,64,8,256,512,256,2048,64,269,17,577,515,64,772,256,576,65,576,16,66,269,64,64,17,17,2820,257,576,256,96,324,512]

theorem envBound16034 : H12AffineFastState.Bounded env16034 := by
  intro p hp
  have h : env16034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16033_16034 : H12AffineEnvironment.transform 9 256 env16033 = env16034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env16033 == env16034) = true)

theorem identity16034 : scanCanonicalize (H12AffineFastState.compose env16034 (packedSelected [6] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound16034 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env16035 : List Nat := [2,4,8,16,32,64,8,256,292,256,2048,64,269,17,357,295,64,32,256,356,65,356,16,66,269,64,64,17,17,2080,257,356,256,96,324,292]

theorem envBound16035 : H12AffineFastState.Bounded env16035 := by
  intro p hp
  have h : env16035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16034_16035 : H12AffineEnvironment.transform 8 292 env16034 = env16035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env16034 == env16035) = true)

theorem identity16035 : scanCanonicalize (H12AffineFastState.compose env16035 (packedSelected [1,5,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound16035 : packedSelected [1,5,8,11] rootPS < 2^1333 := by decide +kernel

def env16036 : List Nat := [2,4,8,16,32,64,8,256,292,256,292,64,269,17,357,295,64,32,256,356,65,356,16,66,269,64,64,17,17,260,257,356,256,96,324,292]

theorem envBound16036 : H12AffineFastState.Bounded env16036 := by
  intro p hp
  have h : env16036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16035_16036 : H12AffineEnvironment.transform 10 292 env16035 = env16036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env16035 == env16036) = true)

theorem identity16036 : scanCanonicalize (H12AffineFastState.compose env16036 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound16036 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env16037 : List Nat := [2,4,8,16,32,64,8,69,97,69,97,64,72,17,32,98,64,32,69,33,65,33,16,66,72,64,64,17,17,65,68,33,69,96,1,97]

theorem envBound16037 : H12AffineFastState.Bounded env16037 := by
  intro p hp
  have h : env16037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16036_16037 : H12AffineEnvironment.transform 7 69 env16036 = env16037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env16036 == env16037) = true)

theorem identity16037 : scanCanonicalize (H12AffineFastState.compose env16037 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound16037 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env16038 : List Nat := [2,4,8,16,32,48,8,53,17,53,17,48,56,17,32,18,48,32,53,33,49,33,16,50,56,48,48,17,17,49,52,33,53,16,1,17]

theorem envBound16038 : H12AffineFastState.Bounded env16038 := by
  intro p hp
  have h : env16038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16037_16038 : H12AffineEnvironment.transform 5 48 env16037 = env16038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env16037 == env16038) = true)

theorem identity16038 : scanCanonicalize (H12AffineFastState.compose env16038 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound16038 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env16039 : List Nat := [2,4,8,0,32,32,8,37,1,37,1,32,40,1,32,2,32,32,37,33,33,33,0,34,40,32,32,1,1,33,36,33,37,0,1,1]

theorem envBound16039 : H12AffineFastState.Bounded env16039 := by
  intro p hp
  have h : env16039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16038_16039 : H12AffineEnvironment.transform 3 0 env16038 = env16039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env16038 == env16039) = true)

theorem identity16039 : scanCanonicalize (H12AffineFastState.compose env16039 (packedSelected [8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound16039 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env16040 : List Nat := [2,4,8,0,0,0,8,5,1,5,1,0,8,1,0,2,0,0,5,1,1,1,0,2,8,0,0,1,1,1,4,1,5,0,1,1]

theorem envBound16040 : H12AffineFastState.Bounded env16040 := by
  intro p hp
  have h : env16040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16039_16040 : H12AffineEnvironment.transform 4 0 env16039 = env16040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16039 == env16040) = true)

def env16041 : List Nat := [2,4,8,16,32,64,8,256,512,257,2048,65,269,16,576,515,65,772,257,577,64,577,16,67,269,64,65,16,16,2821,256,577,256,97,325,512]

theorem envBound16041 : H12AffineFastState.Bounded env16041 := by
  intro p hp
  have h : env16041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16033_16041 : H12AffineEnvironment.transform 9 257 env16033 = env16041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env16033 == env16041) = true)

theorem identity16041 : scanCanonicalize (H12AffineFastState.compose env16041 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound16041 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env16042 : List Nat := [2,4,8,16,32,33,8,256,512,257,2048,32,269,16,545,515,32,772,257,544,33,544,16,34,269,33,32,16,16,2821,256,544,256,0,292,512]

theorem envBound16042 : H12AffineFastState.Bounded env16042 := by
  intro p hp
  have h : env16042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16041_16042 : H12AffineEnvironment.transform 5 33 env16041 = env16042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env16041 == env16042) = true)

theorem identity16042 : scanCanonicalize (H12AffineFastState.compose env16042 (packedSelected [1,5,8,12,17] rootPS)) = affineNative (2^(10+1) ^^^ 545) := by decide +kernel

theorem selectedBound16042 : packedSelected [1,5,8,12,17] rootPS < 2^1333 := by decide +kernel

def env16043 : List Nat := [2,4,8,16,32,33,8,256,512,257,545,32,269,16,545,515,32,772,257,544,33,544,16,34,269,33,32,16,16,292,256,544,256,0,292,512]

theorem envBound16043 : H12AffineFastState.Bounded env16043 := by
  intro p hp
  have h : env16043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16042_16043 : H12AffineEnvironment.transform 10 545 env16042 = env16043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 545 env16042 == env16043) = true)

theorem identity16043 : scanCanonicalize (H12AffineFastState.compose env16043 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound16043 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env16044 : List Nat := [2,4,8,1,32,33,8,256,512,257,545,32,269,1,545,515,32,772,257,544,33,544,1,34,269,33,32,1,1,292,256,544,256,0,292,512]

theorem envBound16044 : H12AffineFastState.Bounded env16044 := by
  intro p hp
  have h : env16044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16043_16044 : H12AffineEnvironment.transform 3 1 env16043 = env16044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env16043 == env16044) = true)

theorem identity16044 : scanCanonicalize (H12AffineFastState.compose env16044 (packedSelected [0,1,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound16044 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env16045 : List Nat := [2,4,8,1,1,0,8,256,512,257,512,1,269,1,512,515,1,772,257,513,0,513,1,3,269,0,1,1,1,261,256,513,256,0,261,512]

theorem envBound16045 : H12AffineFastState.Bounded env16045 := by
  intro p hp
  have h : env16045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16044_16045 : H12AffineEnvironment.transform 4 1 env16044 = env16045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16044 == env16045) = true)

theorem identity16045 : scanCanonicalize (H12AffineFastState.compose env16045 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound16045 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env16046 : List Nat := [2,4,8,1,1,0,8,256,0,257,0,1,269,1,0,3,1,260,257,1,0,1,1,3,269,0,1,1,1,261,256,1,256,0,261,0]

theorem envBound16046 : H12AffineFastState.Bounded env16046 := by
  intro p hp
  have h : env16046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16045_16046 : H12AffineEnvironment.transform 8 0 env16045 = env16046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env16045 == env16046) = true)

def env16047 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1344,268,1297,32768,65536,1344,772,1024,32769,1345,32769,16,98304,269,64,33281,1297,1297,1073741824,1025,32768,256,98338,1092,512]

theorem envBound16047 : H12AffineFastState.Bounded env16047 := by
  intro p hp
  have h : env16047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16021_16047 : H12AffineEnvironment.transform 6 9 env16021 = env16047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16021 == env16047) = true)

theorem identity16047 : scanCanonicalize (H12AffineFastState.compose env16047 (packedSelected [6,7] rootPS)) = affineNative (2^(29+1) ^^^ 100418) := by decide +kernel

theorem selectedBound16047 : packedSelected [6,7] rootPS < 2^1333 := by decide +kernel

def env16048 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1344,268,1297,32768,65536,1344,772,1024,32769,1345,32769,16,98304,269,64,33281,1297,1297,100418,1025,32768,256,98338,1092,512]

theorem envBound16048 : H12AffineFastState.Bounded env16048 := by
  intro p hp
  have h : env16048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16047_16048 : H12AffineEnvironment.transform 29 100418 env16047 = env16048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 100418 env16047 == env16048) = true)

def env16049 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1344,268,1297,1344,65536,1344,772,1024,1345,1345,1345,16,66880,269,64,1857,1297,1297,68866,1025,1344,256,66914,1092,512]

theorem envBound16049 : H12AffineFastState.Bounded env16049 := by
  intro p hp
  have h : env16049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16048_16049 : H12AffineEnvironment.transform 14 1344 env16048 = env16049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1344 env16048 == env16049) = true)

theorem identity16049 : scanCanonicalize (H12AffineFastState.compose env16049 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 806) := by decide +kernel

theorem selectedBound16049 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16050 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1344,268,1297,1344,806,1344,772,1024,1345,1345,1345,16,1638,269,64,1857,1297,1297,3620,1025,1344,256,1604,1092,512]

theorem envBound16050 : H12AffineFastState.Bounded env16050 := by
  intro p hp
  have h : env16050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16049_16050 : H12AffineEnvironment.transform 15 806 env16049 = env16050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 806 env16049 == env16050) = true)

def env16051 : List Nat := [2,4,8,16,32,0,9,256,512,1024,2048,1280,268,1297,1280,806,1280,772,1024,1281,1281,1281,16,1574,269,0,1793,1297,1297,3620,1025,1280,256,1540,1028,512]

theorem envBound16051 : H12AffineFastState.Bounded env16051 := by
  intro p hp
  have h : env16051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16050_16051 : H12AffineEnvironment.transform 5 0 env16050 = env16051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env16050 == env16051) = true)

theorem identity16051 : scanCanonicalize (H12AffineFastState.compose env16051 (packedSelected [6] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound16051 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env16052 : List Nat := [2,4,8,16,32,0,9,256,1,1024,2048,1280,268,1297,1280,295,1280,261,1024,1281,1281,1281,16,1063,269,0,1280,1297,1297,3109,1025,1280,256,1029,1028,1]

theorem envBound16052 : H12AffineFastState.Bounded env16052 := by
  intro p hp
  have h : env16052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16051_16052 : H12AffineEnvironment.transform 8 1 env16051 = env16052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env16051 == env16052) = true)

theorem identity16052 : scanCanonicalize (H12AffineFastState.compose env16052 (packedSelected [0,4,8,9,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 1297) := by decide +kernel

theorem selectedBound16052 : packedSelected [0,4,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env16053 : List Nat := [2,4,8,16,32,0,9,256,1,1024,1297,1280,268,1297,1280,295,1280,261,1024,1281,1281,1281,16,1063,269,0,1280,1297,1297,308,1025,1280,256,1029,1028,1]

theorem envBound16053 : H12AffineFastState.Bounded env16053 := by
  intro p hp
  have h : env16053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16052_16053 : H12AffineEnvironment.transform 10 1297 env16052 = env16053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1297 env16052 == env16053) = true)

theorem identity16053 : scanCanonicalize (H12AffineFastState.compose env16053 (packedSelected [0,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound16053 : packedSelected [0,3,5] rootPS < 2^1333 := by decide +kernel

def env16054 : List Nat := [2,4,8,16,32,0,9,52,1,1024,1061,1076,56,1061,1076,19,1076,49,1024,1077,1077,1077,16,1063,57,0,1076,1061,1061,0,1025,1076,52,1029,1028,1]

theorem envBound16054 : H12AffineFastState.Bounded env16054 := by
  intro p hp
  have h : env16054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16053_16054 : H12AffineEnvironment.transform 7 52 env16053 = env16054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env16053 == env16054) = true)

theorem identity16054 : scanCanonicalize (H12AffineFastState.compose env16054 (packedSelected [0,1,4] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound16054 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env16055 : List Nat := [2,4,8,16,32,0,9,52,1,52,17,0,56,17,0,19,0,49,52,1,1,1,16,19,57,0,0,17,17,0,53,0,52,49,48,1]

theorem envBound16055 : H12AffineFastState.Bounded env16055 := by
  intro p hp
  have h : env16055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16054_16055 : H12AffineEnvironment.transform 9 52 env16054 = env16055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env16054 == env16055) = true)

theorem identity16055 : scanCanonicalize (H12AffineFastState.compose env16055 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound16055 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env16056 : List Nat := [2,4,8,16,16,0,9,4,1,4,17,0,8,17,0,19,0,1,4,1,1,1,16,19,9,0,0,17,17,0,5,0,4,1,0,1]

theorem envBound16056 : H12AffineFastState.Bounded env16056 := by
  intro p hp
  have h : env16056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16055_16056 : H12AffineEnvironment.transform 4 16 env16055 = env16056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env16055 == env16056) = true)

theorem identity16056 : scanCanonicalize (H12AffineFastState.compose env16056 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound16056 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16057 : List Nat := [2,4,8,1,1,0,9,4,1,4,0,0,8,0,0,2,0,1,4,1,1,1,1,2,9,0,0,0,0,0,5,0,4,1,0,1]

theorem envBound16057 : H12AffineFastState.Bounded env16057 := by
  intro p hp
  have h : env16057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16056_16057 : H12AffineEnvironment.transform 3 1 env16056 = env16057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env16056 == env16057) = true)

def env16058 : List Nat := [2,4,8,16,32,1,9,256,512,1024,2048,1281,268,1297,1281,806,1281,772,1024,1280,1280,1280,16,1575,269,1,1792,1297,1297,3620,1025,1281,256,1541,1029,512]

theorem envBound16058 : H12AffineFastState.Bounded env16058 := by
  intro p hp
  have h : env16058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16050_16058 : H12AffineEnvironment.transform 5 1 env16050 = env16058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env16050 == env16058) = true)

theorem identity16058 : scanCanonicalize (H12AffineFastState.compose env16058 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound16058 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env16059 : List Nat := [2,4,8,16,32,1,9,256,512,517,2048,772,268,788,772,806,772,772,517,773,773,773,16,34,269,1,261,788,788,2081,516,772,256,0,512,512]

theorem envBound16059 : H12AffineFastState.Bounded env16059 := by
  intro p hp
  have h : env16059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16058_16059 : H12AffineEnvironment.transform 9 517 env16058 = env16059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env16058 == env16059) = true)

theorem identity16059 : scanCanonicalize (H12AffineFastState.compose env16059 (packedSelected [1,9,12] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound16059 : packedSelected [1,9,12] rootPS < 2^1333 := by decide +kernel

def env16060 : List Nat := [2,4,8,16,32,1,9,256,512,517,49,772,268,788,772,806,772,772,517,773,773,773,16,34,269,1,261,788,788,16,516,772,256,0,512,512]

theorem envBound16060 : H12AffineFastState.Bounded env16060 := by
  intro p hp
  have h : env16060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16059_16060 : H12AffineEnvironment.transform 10 49 env16059 = env16060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env16059 == env16060) = true)

theorem identity16060 : scanCanonicalize (H12AffineFastState.compose env16060 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound16060 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env16061 : List Nat := [2,4,8,16,0,1,9,256,512,517,17,772,268,788,772,774,772,772,517,773,773,773,16,2,269,1,261,788,788,16,516,772,256,0,512,512]

theorem envBound16061 : H12AffineFastState.Bounded env16061 := by
  intro p hp
  have h : env16061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16060_16061 : H12AffineEnvironment.transform 4 0 env16060 = env16061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16060 == env16061) = true)

theorem identity16061 : scanCanonicalize (H12AffineFastState.compose env16061 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound16061 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env16062 : List Nat := [2,4,8,16,0,1,9,256,17,20,17,277,268,261,277,279,277,277,20,276,276,276,16,2,269,1,261,261,261,16,21,277,256,0,17,17]

theorem envBound16062 : H12AffineFastState.Bounded env16062 := by
  intro p hp
  have h : env16062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16061_16062 : H12AffineEnvironment.transform 8 17 env16061 = env16062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env16061 == env16062) = true)

theorem identity16062 : scanCanonicalize (H12AffineFastState.compose env16062 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound16062 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16063 : List Nat := [2,4,8,0,0,1,9,256,1,4,1,261,268,261,261,263,261,261,4,260,260,260,0,2,269,1,261,261,261,0,5,261,256,0,1,1]

theorem envBound16063 : H12AffineFastState.Bounded env16063 := by
  intro p hp
  have h : env16063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16062_16063 : H12AffineEnvironment.transform 3 0 env16062 = env16063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env16062 == env16063) = true)

theorem identity16063 : scanCanonicalize (H12AffineFastState.compose env16063 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound16063 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16064 : List Nat := [2,4,8,0,0,1,9,4,1,4,1,1,8,1,1,3,1,1,4,0,0,0,0,2,9,1,1,1,1,0,5,1,4,0,1,1]

theorem envBound16064 : H12AffineFastState.Bounded env16064 := by
  intro p hp
  have h : env16064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16063_16064 : H12AffineEnvironment.transform 7 4 env16063 = env16064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env16063 == env16064) = true)

def env16065 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1344,268,1297,1345,65536,1344,772,1024,1344,1345,1344,16,66881,269,64,1856,1297,1297,68867,1025,1345,256,66915,1092,512]

theorem envBound16065 : H12AffineFastState.Bounded env16065 := by
  intro p hp
  have h : env16065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16048_16065 : H12AffineEnvironment.transform 14 1345 env16048 = env16065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1345 env16048 == env16065) = true)

theorem identity16065 : scanCanonicalize (H12AffineFastState.compose env16065 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 547) := by decide +kernel

theorem selectedBound16065 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16066 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1344,268,1297,1345,547,1344,772,1024,1344,1345,1344,16,1890,269,64,1856,1297,1297,3872,1025,1345,256,1856,1092,512]

theorem envBound16066 : H12AffineFastState.Bounded env16066 := by
  intro p hp
  have h : env16066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16065_16066 : H12AffineEnvironment.transform 15 547 env16065 = env16066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 547 env16065 == env16066) = true)

def env16067 : List Nat := [2,4,8,16,32,0,9,256,512,1024,2048,1280,268,1297,1281,547,1280,772,1024,1280,1281,1280,16,1826,269,0,1792,1297,1297,3872,1025,1281,256,1792,1028,512]

theorem envBound16067 : H12AffineFastState.Bounded env16067 := by
  intro p hp
  have h : env16067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16066_16067 : H12AffineEnvironment.transform 5 0 env16066 = env16067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env16066 == env16067) = true)

theorem identity16067 : scanCanonicalize (H12AffineFastState.compose env16067 (packedSelected [6] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound16067 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env16068 : List Nat := [2,4,8,16,32,0,9,256,1,1024,2048,1280,268,1297,1281,34,1280,261,1024,1280,1281,1280,16,1315,269,0,1281,1297,1297,3361,1025,1281,256,1281,1028,1]

theorem envBound16068 : H12AffineFastState.Bounded env16068 := by
  intro p hp
  have h : env16068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16067_16068 : H12AffineEnvironment.transform 8 1 env16067 = env16068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env16067 == env16068) = true)

theorem identity16068 : scanCanonicalize (H12AffineFastState.compose env16068 (packedSelected [3,5,15] rootPS)) = affineNative (2^(10+1) ^^^ 1329) := by decide +kernel

theorem selectedBound16068 : packedSelected [3,5,15] rootPS < 2^1333 := by decide +kernel

def env16069 : List Nat := [2,4,8,16,32,0,9,256,1,1024,1329,1280,268,1297,1281,34,1280,261,1024,1280,1281,1280,16,1315,269,0,1281,1297,1297,16,1025,1281,256,1281,1028,1]

theorem envBound16069 : H12AffineFastState.Bounded env16069 := by
  intro p hp
  have h : env16069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16068_16069 : H12AffineEnvironment.transform 10 1329 env16068 = env16069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1329 env16068 == env16069) = true)

theorem identity16069 : scanCanonicalize (H12AffineFastState.compose env16069 (packedSelected [0,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound16069 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env16070 : List Nat := [2,4,8,16,32,0,9,20,1,1024,1061,1044,24,1029,1045,34,1044,17,1024,1044,1045,1044,16,1079,25,0,1045,1029,1029,16,1025,1045,20,1045,1028,1]

theorem envBound16070 : H12AffineFastState.Bounded env16070 := by
  intro p hp
  have h : env16070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16069_16070 : H12AffineEnvironment.transform 7 20 env16069 = env16070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env16069 == env16070) = true)

theorem identity16070 : scanCanonicalize (H12AffineFastState.compose env16070 (packedSelected [0,1] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound16070 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env16071 : List Nat := [2,4,8,16,32,0,9,20,1,4,33,16,24,1,17,34,16,17,4,16,17,16,16,51,25,0,17,1,1,16,5,17,20,17,0,1]

theorem envBound16071 : H12AffineFastState.Bounded env16071 := by
  intro p hp
  have h : env16071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16070_16071 : H12AffineEnvironment.transform 9 4 env16070 = env16071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env16070 == env16071) = true)

def env16072 : List Nat := [2,4,8,16,32,1,9,256,512,1024,2048,1281,268,1297,1280,547,1281,772,1024,1281,1280,1281,16,1827,269,1,1793,1297,1297,3872,1025,1280,256,1793,1029,512]

theorem envBound16072 : H12AffineFastState.Bounded env16072 := by
  intro p hp
  have h : env16072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16066_16072 : H12AffineEnvironment.transform 5 1 env16066 = env16072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env16066 == env16072) = true)

theorem identity16072 : scanCanonicalize (H12AffineFastState.compose env16072 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound16072 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env16073 : List Nat := [2,4,8,16,32,1,9,256,512,516,2048,773,268,789,772,547,773,772,516,773,772,773,16,295,269,1,261,789,789,2340,517,772,256,261,513,512]

theorem envBound16073 : H12AffineFastState.Bounded env16073 := by
  intro p hp
  have h : env16073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16072_16073 : H12AffineEnvironment.transform 9 516 env16072 = env16073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env16072 == env16073) = true)

theorem identity16073 : scanCanonicalize (H12AffineFastState.compose env16073 (packedSelected [1,3,5,9,12,15] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound16073 : packedSelected [1,3,5,9,12,15] rootPS < 2^1333 := by decide +kernel

def env16074 : List Nat := [2,4,8,16,32,1,9,256,48,52,2048,309,268,293,308,19,309,308,52,309,308,309,16,295,269,1,261,293,293,2340,53,308,256,261,49,48]

theorem envBound16074 : H12AffineFastState.Bounded env16074 := by
  intro p hp
  have h : env16074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16073_16074 : H12AffineEnvironment.transform 8 48 env16073 = env16074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env16073 == env16074) = true)

theorem identity16074 : scanCanonicalize (H12AffineFastState.compose env16074 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound16074 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env16075 : List Nat := [2,4,8,16,32,1,9,52,48,52,2048,1,56,17,0,19,1,0,52,1,0,1,16,19,57,1,49,17,17,2064,53,0,52,49,49,48]

theorem envBound16075 : H12AffineFastState.Bounded env16075 := by
  intro p hp
  have h : env16075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16074_16075 : H12AffineEnvironment.transform 7 52 env16074 = env16075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env16074 == env16075) = true)

def env16076 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,65536,1344,8833,1024,32769,1345,32769,16,98305,8328,64,41860,1297,1297,1073741824,1024,32905,256,98339,1093,512]

theorem envBound16076 : H12AffineFastState.Bounded env16076 := by
  intro p hp
  have h : env16076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16019_16076 : H12AffineEnvironment.transform 23 98305 env16019 = env16076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98305 env16019 == env16076) = true)

theorem identity16076 : scanCanonicalize (H12AffineFastState.compose env16076 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 128) := by decide +kernel

theorem selectedBound16076 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env16077 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,128,1297,32768,65536,1344,513,1024,32769,1345,32769,16,98305,8,64,33540,1297,1297,1073741824,1024,32905,256,98339,1093,512]

theorem envBound16077 : H12AffineFastState.Bounded env16077 := by
  intro p hp
  have h : env16077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16076_16077 : H12AffineEnvironment.transform 12 128 env16076 = env16077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 128 env16076 == env16077) = true)

def env16078 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1344,8,1297,32768,65536,1344,513,1024,32769,1345,32769,16,98305,8,64,33540,1297,1297,1073741824,1024,32769,256,98339,1093,512]

theorem envBound16078 : H12AffineFastState.Bounded env16078 := by
  intro p hp
  have h : env16078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16077_16078 : H12AffineEnvironment.transform 6 8 env16077 = env16078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16077 == env16078) = true)

theorem identity16078 : scanCanonicalize (H12AffineFastState.compose env16078 (packedSelected [6,7] rootPS)) = affineNative (2^(8+1) ^^^ 325) := by decide +kernel

theorem selectedBound16078 : packedSelected [6,7] rootPS < 2^1333 := by decide +kernel

def env16079 : List Nat := [2,4,8,16,32,64,8,256,325,1024,2048,1344,8,1297,32768,65536,1344,324,1024,32769,1345,32769,16,98305,8,64,32833,1297,1297,1073741824,1024,32769,256,98339,1093,325]

theorem envBound16079 : H12AffineFastState.Bounded env16079 := by
  intro p hp
  have h : env16079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16078_16079 : H12AffineEnvironment.transform 8 325 env16078 = env16079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 325 env16078 == env16079) = true)

def env16080 : List Nat := [2,4,8,16,32,64,8,4,65,1024,2048,1092,8,1045,32768,65536,1092,64,1024,32769,1093,32769,16,98305,8,64,32833,1045,1045,1073741824,1024,32769,4,98339,1093,65]

theorem envBound16080 : H12AffineFastState.Bounded env16080 := by
  intro p hp
  have h : env16080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16079_16080 : H12AffineEnvironment.transform 7 4 env16079 = env16080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env16079 == env16080) = true)

theorem identity16080 : scanCanonicalize (H12AffineFastState.compose env16080 (packedSelected [2] rootPS)) = affineNative (2^(14+1) ^^^ 65) := by decide +kernel

theorem selectedBound16080 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16081 : List Nat := [2,4,8,16,32,64,8,4,65,1024,2048,1092,8,1045,65,65536,1092,64,1024,64,1093,64,16,65600,8,64,0,1045,1045,1073741824,1024,64,4,65634,1093,65]

theorem envBound16081 : H12AffineFastState.Bounded env16081 := by
  intro p hp
  have h : env16081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16080_16081 : H12AffineEnvironment.transform 14 65 env16080 = env16081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 65 env16080 == env16081) = true)

theorem identity16081 : scanCanonicalize (H12AffineFastState.compose env16081 (packedSelected [1,12,13] rootPS)) = affineNative (2^(10+1) ^^^ 96) := by decide +kernel

theorem selectedBound16081 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env16082 : List Nat := [2,4,8,16,32,64,8,4,65,1024,96,1092,8,1045,65,65536,1092,64,1024,64,1093,64,16,65600,8,64,0,1045,1045,1073741824,1024,64,4,65634,1093,65]

theorem envBound16082 : H12AffineFastState.Bounded env16082 := by
  intro p hp
  have h : env16082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16081_16082 : H12AffineEnvironment.transform 10 96 env16081 = env16082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 96 env16081 == env16082) = true)

theorem identity16082 : scanCanonicalize (H12AffineFastState.compose env16082 (packedSelected [4,6] rootPS)) = affineNative (2^(29+1) ^^^ 64) := by decide +kernel

theorem selectedBound16082 : packedSelected [4,6] rootPS < 2^1333 := by decide +kernel

def env16083 : List Nat := [2,4,8,16,32,64,8,4,65,1024,96,1092,8,1045,65,65536,1092,64,1024,64,1093,64,16,65600,8,64,0,1045,1045,64,1024,64,4,65634,1093,65]

theorem envBound16083 : H12AffineFastState.Bounded env16083 := by
  intro p hp
  have h : env16083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16082_16083 : H12AffineEnvironment.transform 29 64 env16082 = env16083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 64 env16082 == env16083) = true)

theorem identity16083 : scanCanonicalize (H12AffineFastState.compose env16083 (packedSelected [0,9] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound16083 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env16084 : List Nat := [2,4,8,16,32,0,8,4,1,1024,32,1028,8,1045,1,65536,1028,0,1024,0,1029,0,16,65536,8,0,0,1045,1045,0,1024,0,4,65570,1029,1]

theorem envBound16084 : H12AffineFastState.Bounded env16084 := by
  intro p hp
  have h : env16084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16083_16084 : H12AffineEnvironment.transform 5 0 env16083 = env16084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env16083 == env16084) = true)

theorem identity16084 : scanCanonicalize (H12AffineFastState.compose env16084 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound16084 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16085 : List Nat := [2,4,8,16,32,0,8,4,1,1024,32,1028,8,1045,1,34,1028,0,1024,0,1029,0,16,34,8,0,0,1045,1045,0,1024,0,4,0,1029,1]

theorem envBound16085 : H12AffineFastState.Bounded env16085 := by
  intro p hp
  have h : env16085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16084_16085 : H12AffineEnvironment.transform 15 34 env16084 = env16085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env16084 == env16085) = true)

theorem identity16085 : scanCanonicalize (H12AffineFastState.compose env16085 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound16085 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16086 : List Nat := [2,4,8,16,32,0,8,4,1,37,32,33,8,48,1,34,33,0,37,0,32,0,16,34,8,0,0,48,48,0,37,0,4,0,32,1]

theorem envBound16086 : H12AffineFastState.Bounded env16086 := by
  intro p hp
  have h : env16086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16085_16086 : H12AffineEnvironment.transform 9 37 env16085 = env16086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env16085 == env16086) = true)

theorem identity16086 : scanCanonicalize (H12AffineFastState.compose env16086 (packedSelected [3,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound16086 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env16087 : List Nat := [2,4,8,0,32,0,8,4,1,37,32,33,8,32,1,34,33,0,37,0,32,0,0,34,8,0,0,32,32,0,37,0,4,0,32,1]

theorem envBound16087 : H12AffineFastState.Bounded env16087 := by
  intro p hp
  have h : env16087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16086_16087 : H12AffineEnvironment.transform 3 0 env16086 = env16087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env16086 == env16087) = true)

theorem identity16087 : scanCanonicalize (H12AffineFastState.compose env16087 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound16087 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env16088 : List Nat := [2,4,8,0,0,0,8,4,1,5,0,1,8,0,1,2,1,0,5,0,0,0,0,2,8,0,0,0,0,0,5,0,4,0,0,1]

theorem envBound16088 : H12AffineFastState.Bounded env16088 := by
  intro p hp
  have h : env16088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16087_16088 : H12AffineEnvironment.transform 4 0 env16087 = env16088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16087 == env16088) = true)

def env16089 : List Nat := [2,4,8,16,32,64,8,5,64,1024,2048,1093,8,1044,32768,65536,1093,65,1024,32769,1092,32769,16,98305,8,64,32833,1044,1044,1073741824,1024,32769,5,98339,1093,64]

theorem envBound16089 : H12AffineFastState.Bounded env16089 := by
  intro p hp
  have h : env16089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16079_16089 : H12AffineEnvironment.transform 7 5 env16079 = env16089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env16079 == env16089) = true)

theorem identity16089 : scanCanonicalize (H12AffineFastState.compose env16089 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 33862) := by decide +kernel

theorem selectedBound16089 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16090 : List Nat := [2,4,8,16,32,64,8,5,64,1024,2048,1093,8,1044,32768,33862,1093,65,1024,32769,1092,32769,16,1095,8,64,32833,1044,1044,1073741824,1024,32769,5,1125,1093,64]

theorem envBound16090 : H12AffineFastState.Bounded env16090 := by
  intro p hp
  have h : env16090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16089_16090 : H12AffineEnvironment.transform 15 33862 env16089 = env16090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33862 env16089 == env16090) = true)

theorem identity16090 : scanCanonicalize (H12AffineFastState.compose env16090 (packedSelected [1,12] rootPS)) = affineNative (2^(29+1) ^^^ 34880) := by decide +kernel

theorem selectedBound16090 : packedSelected [1,12] rootPS < 2^1333 := by decide +kernel

def env16091 : List Nat := [2,4,8,16,32,64,8,5,64,1024,2048,1093,8,1044,32768,33862,1093,65,1024,32769,1092,32769,16,1095,8,64,32833,1044,1044,34880,1024,32769,5,1125,1093,64]

theorem envBound16091 : H12AffineFastState.Bounded env16091 := by
  intro p hp
  have h : env16091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16090_16091 : H12AffineEnvironment.transform 29 34880 env16090 = env16091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 34880 env16090 == env16091) = true)

theorem identity16091 : scanCanonicalize (H12AffineFastState.compose env16091 (packedSelected [3,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 3109) := by decide +kernel

theorem selectedBound16091 : packedSelected [3,15,17] rootPS < 2^1333 := by decide +kernel

def env16092 : List Nat := [2,4,8,16,32,64,8,5,64,1024,2048,1093,8,1044,3109,2147,1093,65,1024,3108,1092,3108,16,1095,8,64,3172,1044,1044,1125,1024,3108,5,1125,1093,64]

theorem envBound16092 : H12AffineFastState.Bounded env16092 := by
  intro p hp
  have h : env16092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16091_16092 : H12AffineEnvironment.transform 14 3109 env16091 = env16092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3109 env16091 == env16092) = true)

theorem identity16092 : scanCanonicalize (H12AffineFastState.compose env16092 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound16092 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env16093 : List Nat := [2,4,8,16,32,64,8,5,64,68,2048,1,8,80,2145,2147,1,65,68,2144,0,2144,16,3,8,64,2080,80,80,33,68,2144,5,33,1,64]

theorem envBound16093 : H12AffineFastState.Bounded env16093 := by
  intro p hp
  have h : env16093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16092_16093 : H12AffineEnvironment.transform 9 68 env16092 = env16093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env16092 == env16093) = true)

theorem identity16093 : scanCanonicalize (H12AffineFastState.compose env16093 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound16093 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env16094 : List Nat := [2,4,8,16,32,64,8,5,64,68,80,1,8,80,49,51,1,65,68,48,0,48,16,3,8,64,112,80,80,33,68,48,5,33,1,64]

theorem envBound16094 : H12AffineFastState.Bounded env16094 := by
  intro p hp
  have h : env16094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16093_16094 : H12AffineEnvironment.transform 10 80 env16093 = env16094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env16093 == env16094) = true)

theorem identity16094 : scanCanonicalize (H12AffineFastState.compose env16094 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound16094 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env16095 : List Nat := [2,4,8,16,32,48,8,5,48,52,32,1,8,32,49,51,1,49,52,48,0,48,16,3,8,48,0,32,32,33,52,48,5,33,1,48]

theorem envBound16095 : H12AffineFastState.Bounded env16095 := by
  intro p hp
  have h : env16095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16094_16095 : H12AffineEnvironment.transform 5 48 env16094 = env16095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env16094 == env16095) = true)

theorem identity16095 : scanCanonicalize (H12AffineFastState.compose env16095 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound16095 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16096 : List Nat := [2,4,8,1,32,33,8,5,33,37,32,1,8,32,32,34,1,32,37,33,0,33,1,3,8,33,0,32,32,33,37,33,5,33,1,33]

theorem envBound16096 : H12AffineFastState.Bounded env16096 := by
  intro p hp
  have h : env16096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16095_16096 : H12AffineEnvironment.transform 3 1 env16095 = env16096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env16095 == env16096) = true)

def env16097 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1344,9,1297,32768,65536,1344,513,1024,32769,1345,32769,16,98305,8,64,33540,1297,1297,1073741824,1024,32768,256,98339,1093,512]

theorem envBound16097 : H12AffineFastState.Bounded env16097 := by
  intro p hp
  have h : env16097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16077_16097 : H12AffineEnvironment.transform 6 9 env16077 = env16097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16077 == env16097) = true)

theorem identity16097 : scanCanonicalize (H12AffineFastState.compose env16097 (packedSelected [6,7] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound16097 : packedSelected [6,7] rootPS < 2^1333 := by decide +kernel

def env16098 : List Nat := [2,4,8,16,32,1,9,256,512,1024,2048,1281,9,1297,32768,65536,1281,513,1024,32769,1280,32769,16,98305,8,1,33540,1297,1297,1073741824,1024,32768,256,98339,1028,512]

theorem envBound16098 : H12AffineFastState.Bounded env16098 := by
  intro p hp
  have h : env16098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16097_16098 : H12AffineEnvironment.transform 5 1 env16097 = env16098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env16097 == env16098) = true)

def env16099 : List Nat := [2,4,8,16,32,1,9,4,512,1024,2048,1029,9,1045,32768,65536,1029,513,1024,32769,1028,32769,16,98305,8,1,33280,1045,1045,1073741824,1024,32768,4,98339,1028,512]

theorem envBound16099 : H12AffineFastState.Bounded env16099 := by
  intro p hp
  have h : env16099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16098_16099 : H12AffineEnvironment.transform 7 4 env16098 = env16099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env16098 == env16099) = true)

theorem identity16099 : scanCanonicalize (H12AffineFastState.compose env16099 (packedSelected [2] rootPS)) = affineNative (2^(14+1) ^^^ 544) := by decide +kernel

theorem selectedBound16099 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16100 : List Nat := [2,4,8,16,32,1,9,4,512,1024,2048,1029,9,1045,544,65536,1029,513,1024,545,1028,545,16,66081,8,1,32,1045,1045,1073741824,1024,544,4,66051,1028,512]

theorem envBound16100 : H12AffineFastState.Bounded env16100 := by
  intro p hp
  have h : env16100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16099_16100 : H12AffineEnvironment.transform 14 544 env16099 = env16100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 544 env16099 == env16100) = true)

theorem identity16100 : scanCanonicalize (H12AffineFastState.compose env16100 (packedSelected [1,12,13] rootPS)) = affineNative (2^(10+1) ^^^ 545) := by decide +kernel

theorem selectedBound16100 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env16101 : List Nat := [2,4,8,16,32,1,9,4,512,1024,545,1029,9,1045,544,65536,1029,513,1024,545,1028,545,16,66081,8,1,32,1045,1045,1073741824,1024,544,4,66051,1028,512]

theorem envBound16101 : H12AffineFastState.Bounded env16101 := by
  intro p hp
  have h : env16101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16100_16101 : H12AffineEnvironment.transform 10 545 env16100 = env16101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 545 env16100 == env16101) = true)

theorem identity16101 : scanCanonicalize (H12AffineFastState.compose env16101 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 49) := by decide +kernel

theorem selectedBound16101 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env16102 : List Nat := [2,4,8,16,32,1,9,4,512,1024,545,1029,9,1045,544,65536,1029,513,1024,545,1028,545,16,66081,8,1,32,1045,1045,49,1024,544,4,66051,1028,512]

theorem envBound16102 : H12AffineFastState.Bounded env16102 := by
  intro p hp
  have h : env16102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16101_16102 : H12AffineEnvironment.transform 29 49 env16101 = env16102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 49 env16101 == env16102) = true)

theorem identity16102 : scanCanonicalize (H12AffineFastState.compose env16102 (packedSelected [0,6,8,12,15] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound16102 : packedSelected [0,6,8,12,15] rootPS < 2^1333 := by decide +kernel

def env16103 : List Nat := [2,4,8,16,32,1,9,4,49,1024,16,1029,9,1045,17,65536,1029,48,1024,16,1028,16,16,65552,8,1,32,1045,1045,49,1024,17,4,65586,1028,49]

theorem envBound16103 : H12AffineFastState.Bounded env16103 := by
  intro p hp
  have h : env16103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16102_16103 : H12AffineEnvironment.transform 8 49 env16102 = env16103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env16102 == env16103) = true)

theorem identity16103 : scanCanonicalize (H12AffineFastState.compose env16103 (packedSelected [0,1,3,5] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound16103 : packedSelected [0,1,3,5] rootPS < 2^1333 := by decide +kernel

def env16104 : List Nat := [2,4,8,16,32,1,9,4,49,1024,16,1029,9,1045,17,2,1029,48,1024,16,1028,16,16,18,8,1,32,1045,1045,49,1024,17,4,48,1028,49]

theorem envBound16104 : H12AffineFastState.Bounded env16104 := by
  intro p hp
  have h : env16104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16103_16104 : H12AffineEnvironment.transform 15 2 env16103 = env16104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env16103 == env16104) = true)

theorem identity16104 : scanCanonicalize (H12AffineFastState.compose env16104 (packedSelected [0,3] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound16104 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env16105 : List Nat := [2,4,8,16,32,1,9,4,49,5,16,0,9,16,17,2,0,48,5,16,1,16,16,18,8,1,32,16,16,49,5,17,4,48,1,49]

theorem envBound16105 : H12AffineFastState.Bounded env16105 := by
  intro p hp
  have h : env16105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16104_16105 : H12AffineEnvironment.transform 9 5 env16104 = env16105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env16104 == env16105) = true)

theorem identity16105 : scanCanonicalize (H12AffineFastState.compose env16105 (packedSelected [0,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound16105 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env16106 : List Nat := [2,4,8,16,0,1,9,4,17,5,16,0,9,16,17,2,0,16,5,16,1,16,16,18,8,1,0,16,16,17,5,17,4,16,1,17]

theorem envBound16106 : H12AffineFastState.Bounded env16106 := by
  intro p hp
  have h : env16106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16105_16106 : H12AffineEnvironment.transform 4 0 env16105 = env16106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16105 == env16106) = true)

theorem identity16106 : scanCanonicalize (H12AffineFastState.compose env16106 (packedSelected [8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound16106 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env16107 : List Nat := [2,4,8,1,0,1,9,4,0,5,1,0,9,1,0,2,0,1,5,1,1,1,1,3,8,1,0,1,1,0,5,0,4,1,1,0]

theorem envBound16107 : H12AffineFastState.Bounded env16107 := by
  intro p hp
  have h : env16107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16106_16107 : H12AffineEnvironment.transform 3 1 env16106 = env16107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env16106 == env16107) = true)

def env16108 : List Nat := [2,4,8,16,32,1,9,5,512,1024,2048,1028,9,1044,32768,65536,1028,513,1024,32769,1029,32769,16,98305,8,1,33281,1044,1044,1073741824,1024,32768,5,98339,1028,512]

theorem envBound16108 : H12AffineFastState.Bounded env16108 := by
  intro p hp
  have h : env16108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16098_16108 : H12AffineEnvironment.transform 7 5 env16098 = env16108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env16098 == env16108) = true)

theorem identity16108 : scanCanonicalize (H12AffineFastState.compose env16108 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 34342) := by decide +kernel

theorem selectedBound16108 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16109 : List Nat := [2,4,8,16,32,1,9,5,512,1024,2048,1028,9,1044,32768,34342,1028,513,1024,32769,1029,32769,16,1575,8,1,33281,1044,1044,1073741824,1024,32768,5,1541,1028,512]

theorem envBound16109 : H12AffineFastState.Bounded env16109 := by
  intro p hp
  have h : env16109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16108_16109 : H12AffineEnvironment.transform 15 34342 env16108 = env16109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34342 env16108 == env16109) = true)

theorem identity16109 : scanCanonicalize (H12AffineFastState.compose env16109 (packedSelected [1,12,13] rootPS)) = affineNative (2^(29+1) ^^^ 35328) := by decide +kernel

theorem selectedBound16109 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env16110 : List Nat := [2,4,8,16,32,1,9,5,512,1024,2048,1028,9,1044,32768,34342,1028,513,1024,32769,1029,32769,16,1575,8,1,33281,1044,1044,35328,1024,32768,5,1541,1028,512]

theorem envBound16110 : H12AffineFastState.Bounded env16110 := by
  intro p hp
  have h : env16110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16109_16110 : H12AffineEnvironment.transform 29 35328 env16109 = env16110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 35328 env16109 == env16110) = true)

theorem identity16110 : scanCanonicalize (H12AffineFastState.compose env16110 (packedSelected [3,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 3076) := by decide +kernel

theorem selectedBound16110 : packedSelected [3,15,17] rootPS < 2^1333 := by decide +kernel

def env16111 : List Nat := [2,4,8,16,32,1,9,5,512,1024,2048,1028,9,1044,3076,2594,1028,513,1024,3077,1029,3077,16,1575,8,1,3589,1044,1044,1540,1024,3076,5,1541,1028,512]

theorem envBound16111 : H12AffineFastState.Bounded env16111 := by
  intro p hp
  have h : env16111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16110_16111 : H12AffineEnvironment.transform 14 3076 env16110 = env16111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3076 env16110 == env16111) = true)

theorem identity16111 : scanCanonicalize (H12AffineFastState.compose env16111 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound16111 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env16112 : List Nat := [2,4,8,16,32,1,9,5,32,1024,2048,1028,9,1044,3076,2050,1028,33,1024,3077,1029,3077,16,1031,8,1,3109,1044,1044,1060,1024,3076,5,1061,1028,32]

theorem envBound16112 : H12AffineFastState.Bounded env16112 := by
  intro p hp
  have h : env16112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16111_16112 : H12AffineEnvironment.transform 8 32 env16111 = env16112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env16111 == env16112) = true)

theorem identity16112 : scanCanonicalize (H12AffineFastState.compose env16112 (packedSelected [1,3,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound16112 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env16113 : List Nat := [2,4,8,1,32,1,9,5,32,1024,2048,1028,9,1029,3076,2050,1028,33,1024,3077,1029,3077,1,1031,8,1,3109,1029,1029,1060,1024,3076,5,1061,1028,32]

theorem envBound16113 : H12AffineFastState.Bounded env16113 := by
  intro p hp
  have h : env16113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16112_16113 : H12AffineEnvironment.transform 3 1 env16112 = env16113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env16112 == env16113) = true)

theorem identity16113 : scanCanonicalize (H12AffineFastState.compose env16113 (packedSelected [3] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound16113 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env16114 : List Nat := [2,4,8,1,32,1,9,5,32,4,2048,0,9,1,2048,2050,0,33,4,2049,1,2049,1,3,8,1,2081,1,1,32,4,2048,5,33,0,32]

theorem envBound16114 : H12AffineFastState.Bounded env16114 := by
  intro p hp
  have h : env16114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16113_16114 : H12AffineEnvironment.transform 9 4 env16113 = env16114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env16113 == env16114) = true)

def env16115 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32769,4097,4194304,17665,16777216,8328,541009,4477269,16385,545089,1073741824,16876544,4294967296,257,4315938986,17420308,512]

theorem envBound16115 : H12AffineFastState.Bounded env16115 := by
  intro p hp
  have h : env16115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15995_16115 : H12AffineEnvironment.transform 16 1345 env15995 = env16115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env15995 == env16115) = true)

def env16116 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,8914000,134217728,8519745,536870912,1073741824,562663488,4294967296,545789249,4315938986,702907649,512]

theorem envBound16116 : H12AffineFastState.Bounded env16116 := by
  intro p hp
  have h : env16116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15271_16116 : H12AffineEnvironment.transform 34 702907649 env15271 = env16116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 702907649 env15271 == env16116) = true)

def env16117 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,8914000,134217728,8519745,2769920,1073741824,27513920,4294967296,10637633,4315938986,164610305,512]

theorem envBound16117 : H12AffineFastState.Bounded env16117 := by
  intro p hp
  have h : env16117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16116_16117 : H12AffineEnvironment.transform 28 2769920 env16116 = env16117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 2769920 env16116 == env16117) = true)

def env16118 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,4194304,8388608,16777216,8328,8914000,134217728,8519745,676864,1073741824,25412672,4294967296,8536385,4315938986,164610305,512]

theorem envBound16118 : H12AffineFastState.Bounded env16118 := by
  intro p hp
  have h : env16118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16117_16118 : H12AffineEnvironment.transform 20 4096 env16117 = env16118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env16117 == env16118) = true)

theorem identity16118 : scanCanonicalize (H12AffineFastState.compose env16118 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 9147668) := by decide +kernel

theorem selectedBound16118 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env16119 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,4194304,8388608,9147668,8328,8914000,134217728,8519745,676864,1073741824,545108,4294967296,8536385,4308309438,138695701,512]

theorem envBound16119 : H12AffineFastState.Bounded env16119 := by
  intro p hp
  have h : env16119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16118_16119 : H12AffineEnvironment.transform 23 9147668 env16118 = env16119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 9147668 env16118 == env16119) = true)

def env16120 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32769,4096,4194304,8388608,9015380,8328,8914000,134217728,8389889,545088,1073741824,545108,4294967296,8406017,4308177150,138695701,512]

theorem envBound16120 : H12AffineFastState.Bounded env16120 := by
  intro p hp
  have h : env16120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16119_16120 : H12AffineEnvironment.transform 16 1344 env16119 = env16120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env16119 == env16120) = true)

def env16121 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32769,4096,4194304,17664,644436,8328,541008,134217728,16385,545088,1073741824,545108,4294967296,257,4299806206,138695701,512]

theorem envBound16121 : H12AffineFastState.Bounded env16121 := by
  intro p hp
  have h : env16121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16120_16121 : H12AffineEnvironment.transform 22 17664 env16120 = env16121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17664 env16120 == env16121) = true)

theorem identity16121 : scanCanonicalize (H12AffineFastState.compose env16121 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(26+1) ^^^ 4477269) := by decide +kernel

theorem selectedBound16121 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env16122 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32769,4096,4194304,17664,644436,8328,541008,4477269,16385,545088,1073741824,545108,4294967296,257,4299806206,1344,512]

theorem envBound16122 : H12AffineFastState.Bounded env16122 := by
  intro p hp
  have h : env16122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16121_16122 : H12AffineEnvironment.transform 26 4477269 env16121 = env16122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4477269 env16121 == env16122) = true)

theorem identity16122 : scanCanonicalize (H12AffineFastState.compose env16122 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound16122 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env16123 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,1025,32769,4096,4194304,17664,119125,8328,17745,4477269,16385,21825,1073741824,21845,4294967296,257,4299280895,1344,512]

theorem envBound16123 : H12AffineFastState.Bounded env16123 := by
  intro p hp
  have h : env16123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16122_16123 : H12AffineEnvironment.transform 18 1025 env16122 = env16123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env16122 == env16123) = true)

def env16124 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4096,32768,65536,1344,262144,1025,32769,4096,4194304,5376,98645,8328,5457,4456789,4097,1345,1073741824,1365,4294967296,257,4299260415,1344,512]

theorem envBound16124 : H12AffineFastState.Bounded env16124 := by
  intro p hp
  have h : env16124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16123_16124 : H12AffineEnvironment.transform 13 4096 env16123 = env16124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env16123 == env16124) = true)

theorem identity16124 : scanCanonicalize (H12AffineFastState.compose env16124 (packedSelected [12,13,15,17,38,41] rootPS)) = affineNative (2^(31+1) ^^^ 1077979297) := by decide +kernel

theorem selectedBound16124 : packedSelected [12,13,15,17,38,41] rootPS < 2^1333 := by decide +kernel

def env16125 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4096,32768,65536,1344,262144,1025,32769,4096,4194304,5376,98645,8328,5457,4456789,4097,1345,1073741824,1365,1077979297,257,1073817950,1344,512]

theorem envBound16125 : H12AffineFastState.Bounded env16125 := by
  intro p hp
  have h : env16125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16124_16125 : H12AffineEnvironment.transform 31 1077979297 env16124 = env16125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1077979297 env16124 == env16125) = true)

def env16126 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,1296,262144,1025,32769,4096,4194304,5376,98565,8328,5377,4456709,4097,1297,1073741824,1285,1077979297,257,1073817870,1296,512]

theorem envBound16126 : H12AffineFastState.Bounded env16126 := by
  intro p hp
  have h : env16126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16125_16126 : H12AffineEnvironment.transform 5 16 env16125 = env16126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env16125 == env16126) = true)

theorem identity16126 : scanCanonicalize (H12AffineFastState.compose env16126 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(21+1) ^^^ 261) := by decide +kernel

theorem selectedBound16126 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env16127 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,1296,262144,1025,32769,4096,261,5376,98565,8328,5377,262144,4097,1297,1073741824,1285,1073785252,257,1073817870,1296,512]

theorem envBound16127 : H12AffineFastState.Bounded env16127 := by
  intro p hp
  have h : env16127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16126_16127 : H12AffineEnvironment.transform 21 261 env16126 = env16127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 261 env16126 == env16127) = true)

theorem identity16127 : scanCanonicalize (H12AffineFastState.compose env16127 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(29+1) ^^^ 2561) := by decide +kernel

theorem selectedBound16127 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env16128 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,1296,262144,1025,32769,4096,261,5376,98565,8328,5377,262144,4097,1297,2561,1285,41893,257,74511,1296,512]

theorem envBound16128 : H12AffineFastState.Bounded env16128 := by
  intro p hp
  have h : env16128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16127_16128 : H12AffineEnvironment.transform 29 2561 env16127 = env16128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 2561 env16127 == env16128) = true)

theorem identity16128 : scanCanonicalize (H12AffineFastState.compose env16128 (packedSelected [1,3,5,12,13,24] rootPS)) = affineNative (2^(12+1) ^^^ 2208) := by decide +kernel

theorem selectedBound16128 : packedSelected [1,3,5,12,13,24] rootPS < 2^1333 := by decide +kernel

def env16129 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,2208,4096,32768,65536,1296,262144,1025,32769,4096,261,5376,98565,2088,5377,262144,4097,1297,2561,1285,35589,257,68527,1296,512]

theorem envBound16129 : H12AffineFastState.Bounded env16129 := by
  intro p hp
  have h : env16129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16128_16129 : H12AffineEnvironment.transform 12 2208 env16128 = env16129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2208 env16128 == env16129) = true)

theorem identity16129 : scanCanonicalize (H12AffineFastState.compose env16129 (packedSelected [8,12,13,28] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound16129 : packedSelected [8,12,13,28] rootPS < 2^1333 := by decide +kernel

def env16130 : List Nat := [2,4,8,16,32,16,128,256,1,1024,2048,4096,2208,4096,32768,65536,1296,262144,1025,32769,4096,261,5376,98565,2088,5377,262144,4097,1297,2048,1285,35076,257,68014,1296,1]

theorem envBound16130 : H12AffineFastState.Bounded env16130 := by
  intro p hp
  have h : env16130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16129_16130 : H12AffineEnvironment.transform 8 1 env16129 = env16130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env16129 == env16130) = true)

theorem identity16130 : scanCanonicalize (H12AffineFastState.compose env16130 (packedSelected [0,7] rootPS)) = affineNative (2^(17+1) ^^^ 32904) := by decide +kernel

theorem selectedBound16130 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env16131 : List Nat := [2,4,8,16,32,16,128,256,1,1024,2048,4096,2208,4096,32768,65536,1296,32904,1025,32769,4096,261,5376,98565,2088,5377,32904,4097,1297,2048,1285,35076,257,68014,1296,1]

theorem envBound16131 : H12AffineFastState.Bounded env16131 := by
  intro p hp
  have h : env16131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16130_16131 : H12AffineEnvironment.transform 17 32904 env16130 = env16131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32904 env16130 == env16131) = true)

def env16132 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,65536,1297,262144,1025,32769,4096,4194304,5376,98564,8328,5376,4456708,4097,1296,1073741824,1284,1077979297,257,1073817871,1297,512]

theorem envBound16132 : H12AffineFastState.Bounded env16132 := by
  intro p hp
  have h : env16132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16125_16132 : H12AffineEnvironment.transform 5 17 env16125 = env16132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env16125 == env16132) = true)

theorem identity16132 : scanCanonicalize (H12AffineFastState.compose env16132 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound16132 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env16133 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,4096,8192,4096,32768,65536,1297,262144,1025,32769,4096,4194304,5376,98564,8328,5376,4456708,4097,1296,1073741824,1284,1077979297,257,1073817871,1297,137]

theorem envBound16133 : H12AffineFastState.Bounded env16133 := by
  intro p hp
  have h : env16133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16132_16133 : H12AffineEnvironment.transform 8 137 env16132 = env16133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env16132 == env16133) = true)

theorem identity16133 : scanCanonicalize (H12AffineFastState.compose env16133 (packedSelected [1,12,13] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound16133 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env16134 : List Nat := [2,4,8,16,32,17,128,5,137,1024,2048,4096,8192,4096,32768,65536,1044,262144,1025,32769,4096,4194304,5125,98305,8328,5125,4456449,4097,1045,1073741824,1025,1077979297,4,1073817610,1044,137]

theorem envBound16134 : H12AffineFastState.Bounded env16134 := by
  intro p hp
  have h : env16134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16133_16134 : H12AffineEnvironment.transform 7 5 env16133 = env16134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env16133 == env16134) = true)

def env16135 : List Nat := [2,4,8,16,32,17,128,5,137,1024,2048,1044,8192,1044,32768,65536,1044,262144,1025,32769,1044,4194304,17,98305,8328,17,4456449,1045,1045,1073741824,1025,1077979297,4,1073817610,1044,137]

theorem envBound16135 : H12AffineFastState.Bounded env16135 := by
  intro p hp
  have h : env16135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16134_16135 : H12AffineEnvironment.transform 11 1044 env16134 = env16135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env16134 == env16135) = true)

theorem identity16135 : scanCanonicalize (H12AffineFastState.compose env16135 (packedSelected [1,3,5] rootPS)) = affineNative (2^(29+1) ^^^ 43049) := by decide +kernel

theorem selectedBound16135 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env16136 : List Nat := [2,4,8,16,32,17,128,5,137,1024,2048,1044,8192,1044,32768,65536,1044,262144,1025,32769,1044,4194304,17,98305,8328,17,4456449,1045,1045,43049,1025,4194440,4,98339,1044,137]

theorem envBound16136 : H12AffineFastState.Bounded env16136 := by
  intro p hp
  have h : env16136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16135_16136 : H12AffineEnvironment.transform 29 43049 env16135 = env16136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 43049 env16135 == env16136) = true)

def env16137 : List Nat := [2,4,8,16,32,17,128,5,137,20,2048,0,8192,0,32768,65536,0,262144,21,32769,0,4194304,17,98305,8328,17,4456449,1,1,43049,21,4194440,4,98339,0,137]

theorem envBound16137 : H12AffineFastState.Bounded env16137 := by
  intro p hp
  have h : env16137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16136_16137 : H12AffineEnvironment.transform 9 20 env16136 = env16137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env16136 == env16137) = true)

theorem identity16137 : scanCanonicalize (H12AffineFastState.compose env16137 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound16137 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16138 : List Nat := [2,4,8,16,32,17,128,5,137,20,2048,0,9,0,32768,65536,0,262144,21,32769,0,4194304,17,98305,129,17,4456449,1,1,34848,21,4194440,4,98339,0,137]

theorem envBound16138 : H12AffineFastState.Bounded env16138 := by
  intro p hp
  have h : env16138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16137_16138 : H12AffineEnvironment.transform 12 9 env16137 = env16138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env16137 == env16138) = true)

def env16139 : List Nat := [2,4,8,16,32,17,128,5,137,20,2048,0,9,0,0,65536,0,262144,21,1,0,4194304,17,65537,129,17,4456449,1,1,2080,21,4194440,4,65571,0,137]

theorem envBound16139 : H12AffineFastState.Bounded env16139 := by
  intro p hp
  have h : env16139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16138_16139 : H12AffineEnvironment.transform 14 0 env16138 = env16139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env16138 == env16139) = true)

theorem identity16139 : scanCanonicalize (H12AffineFastState.compose env16139 (packedSelected [2] rootPS)) = affineNative (2^(21+1) ^^^ 65722) := by decide +kernel

theorem selectedBound16139 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16140 : List Nat := [2,4,8,16,32,17,128,5,137,20,2048,0,9,0,0,65536,0,262144,21,1,0,65722,17,65537,129,17,327867,1,1,2080,21,65586,4,65571,0,137]

theorem envBound16140 : H12AffineFastState.Bounded env16140 := by
  intro p hp
  have h : env16140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16139_16140 : H12AffineEnvironment.transform 21 65722 env16139 = env16140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65722 env16139 == env16140) = true)

theorem identity16140 : scanCanonicalize (H12AffineFastState.compose env16140 (packedSelected [6] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound16140 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env16141 : List Nat := [2,4,8,1,32,0,128,5,137,5,2048,0,9,0,0,65536,0,262144,4,1,0,65707,0,65537,129,0,327850,1,1,2080,4,65571,4,65571,0,137]

theorem envBound16141 : H12AffineFastState.Bounded env16141 := by
  intro p hp
  have h : env16141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16140_16141 : H12AffineEnvironment.transform 3 1 env16140 = env16141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env16140 == env16141) = true)

def env16142 : List Nat := [2,4,8,1,32,0,128,5,137,5,0,0,9,0,0,65536,0,262144,4,1,0,65707,0,65537,129,0,327850,1,1,32,4,65571,4,65571,0,137]

theorem envBound16142 : H12AffineFastState.Bounded env16142 := by
  intro p hp
  have h : env16142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16141_16142 : H12AffineEnvironment.transform 10 0 env16141 = env16142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env16141 == env16142) = true)

def env16143 : List Nat := [2,4,8,1,32,0,128,5,137,5,1,0,9,0,0,65536,0,262144,4,1,0,65707,0,65537,129,0,327850,1,1,33,4,65571,4,65571,0,137]

theorem envBound16143 : H12AffineFastState.Bounded env16143 := by
  intro p hp
  have h : env16143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16141_16143 : H12AffineEnvironment.transform 10 1 env16141 = env16143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env16141 == env16143) = true)

theorem identity16143 : scanCanonicalize (H12AffineFastState.compose env16143 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound16143 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16144 : List Nat := [2,4,8,1,0,0,128,5,137,5,1,0,9,0,0,65536,0,262144,4,1,0,65675,0,65537,129,0,327818,1,1,1,4,65539,4,65539,0,137]

theorem envBound16144 : H12AffineFastState.Bounded env16144 := by
  intro p hp
  have h : env16144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16143_16144 : H12AffineEnvironment.transform 4 0 env16143 = env16144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16143 == env16144) = true)

def env16145 : List Nat := [2,4,8,1,0,0,128,5,137,5,1,0,9,0,0,65536,0,0,4,1,0,65675,0,65537,129,0,65674,1,1,1,4,65539,4,65539,0,137]

theorem envBound16145 : H12AffineFastState.Bounded env16145 := by
  intro p hp
  have h : env16145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16144_16145 : H12AffineEnvironment.transform 17 0 env16144 = env16145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 0 env16144 == env16145) = true)

theorem identity16145 : scanCanonicalize (H12AffineFastState.compose env16145 (packedSelected [7] rootPS)) = affineNative (2^(15+1) ^^^ 138) := by decide +kernel

theorem selectedBound16145 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env16146 : List Nat := [2,4,8,1,0,0,128,5,137,5,1,0,9,0,0,138,0,0,4,1,0,1,0,139,129,0,0,1,1,1,4,137,4,137,0,137]

theorem envBound16146 : H12AffineFastState.Bounded env16146 := by
  intro p hp
  have h : env16146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16145_16146 : H12AffineEnvironment.transform 15 138 env16145 = env16146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 138 env16145 == env16146) = true)

def leafEnv16146 : List Nat := [2,4,8,1,0,0,128,5,137,5,1,0,9,0,0,138,0,0,4,1,0,1,0,139,4,129,1,0,0,1,1,1,4,137,4,137,4,3,0,137,0,0,1]

def active16146 : List Nat := [0,1,2,6]

def tree16146 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16146 : H12WitnessSearch.Good tree16146 := H12GlobalWitnessIndex.good

theorem leafIdentity16146 : H12AffineFastState.composeSystem env16146 rootObs = leafEnv16146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16146 rootObs == leafEnv16146) = true)

theorem terminalChecked16146 : H12PackedTerminal.terminalCheckFast leafEnv16146 active16146 tree16146 = true := by decide +kernel

def env16147 : List Nat := [2,4,8,1,0,0,128,5,137,5,1,0,9,0,0,65536,0,1,4,1,0,65675,0,65537,129,0,65675,1,1,1,4,65539,4,65539,0,137]

theorem envBound16147 : H12AffineFastState.Bounded env16147 := by
  intro p hp
  have h : env16147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16144_16147 : H12AffineEnvironment.transform 17 1 env16144 = env16147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1 env16144 == env16147) = true)

def env16148 : List Nat := [2,4,8,16,32,17,128,5,137,20,2048,0,9,0,1,65536,0,262144,21,0,0,4194304,17,65536,129,17,4456449,1,1,2081,21,4194440,4,65570,0,137]

theorem envBound16148 : H12AffineFastState.Bounded env16148 := by
  intro p hp
  have h : env16148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16138_16148 : H12AffineEnvironment.transform 14 1 env16138 = env16148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env16138 == env16148) = true)

theorem identity16148 : scanCanonicalize (H12AffineFastState.compose env16148 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 51) := by decide +kernel

theorem selectedBound16148 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16149 : List Nat := [2,4,8,16,32,17,128,5,137,20,2048,0,9,0,1,51,0,262144,21,0,0,4194304,17,51,129,17,4456449,1,1,2081,21,4194440,4,17,0,137]

theorem envBound16149 : H12AffineFastState.Bounded env16149 := by
  intro p hp
  have h : env16149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16148_16149 : H12AffineEnvironment.transform 15 51 env16148 = env16149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 51 env16148 == env16149) = true)

def env16150 : List Nat := [2,4,8,16,32,17,128,5,137,21,2048,1,8192,1,32768,65536,1,262144,20,32769,1,4194304,17,98305,8328,17,4456449,0,0,43049,20,4194440,4,98339,1,137]

theorem envBound16150 : H12AffineFastState.Bounded env16150 := by
  intro p hp
  have h : env16150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16136_16150 : H12AffineEnvironment.transform 9 21 env16136 = env16150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env16136 == env16150) = true)

theorem identity16150 : scanCanonicalize (H12AffineFastState.compose env16150 (packedSelected [1] rootPS)) = affineNative (2^(21+1) ^^^ 370819) := by decide +kernel

theorem selectedBound16150 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16151 : List Nat := [2,4,8,16,32,17,128,5,137,21,2048,1,8192,1,32768,65536,1,262144,20,32769,1,370819,17,98305,8328,17,108674,0,0,43049,20,370699,4,98339,1,137]

theorem envBound16151 : H12AffineFastState.Bounded env16151 := by
  intro p hp
  have h : env16151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16150_16151 : H12AffineEnvironment.transform 21 370819 env16150 = env16151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 370819 env16150 == env16151) = true)

theorem identity16151 : scanCanonicalize (H12AffineFastState.compose env16151 (packedSelected [3] rootPS)) = affineNative (2^(17+1) ^^^ 67755) := by decide +kernel

theorem selectedBound16151 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env16152 : List Nat := [2,4,8,16,32,17,128,5,137,21,2048,1,8192,1,32768,65536,1,67755,20,32769,1,41000,17,98305,8328,17,108674,0,0,43049,20,41120,4,98339,1,137]

theorem envBound16152 : H12AffineFastState.Bounded env16152 := by
  intro p hp
  have h : env16152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16151_16152 : H12AffineEnvironment.transform 17 67755 env16151 = env16152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67755 env16151 == env16152) = true)

theorem identity16152 : scanCanonicalize (H12AffineFastState.compose env16152 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 41091) := by decide +kernel

theorem selectedBound16152 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env16153 : List Nat := [2,4,8,16,32,17,128,5,137,21,2048,1,8192,1,32768,41091,1,43048,20,32769,1,41000,17,8322,8328,17,2049,0,0,43049,20,41120,4,8352,1,137]

theorem envBound16153 : H12AffineFastState.Bounded env16153 := by
  intro p hp
  have h : env16153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16152_16153 : H12AffineEnvironment.transform 15 41091 env16152 = env16153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41091 env16152 == env16153) = true)

def env16154 : List Nat := [2,4,8,16,32,17,128,5,137,21,2048,1,8192,1,8352,35,1,2184,20,8353,1,136,17,8322,8328,17,2049,0,0,2185,20,0,4,8352,1,137]

theorem envBound16154 : H12AffineFastState.Bounded env16154 := by
  intro p hp
  have h : env16154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16153_16154 : H12AffineEnvironment.transform 14 8352 env16153 = env16154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8352 env16153 == env16154) = true)

theorem identity16154 : scanCanonicalize (H12AffineFastState.compose env16154 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 177) := by decide +kernel

theorem selectedBound16154 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16155 : List Nat := [2,4,8,16,32,17,128,5,137,21,2048,1,177,1,17,35,1,2184,20,16,1,136,17,51,57,17,2049,0,0,2185,20,0,4,17,1,137]

theorem envBound16155 : H12AffineFastState.Bounded env16155 := by
  intro p hp
  have h : env16155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16154_16155 : H12AffineEnvironment.transform 12 177 env16154 = env16155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 177 env16154 == env16155) = true)

def env16156 : List Nat := [2,4,8,16,32,17,128,5,137,21,48,1,177,1,17,35,1,184,20,16,1,136,17,51,57,17,49,0,0,185,20,0,4,17,1,137]

theorem envBound16156 : H12AffineFastState.Bounded env16156 := by
  intro p hp
  have h : env16156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16155_16156 : H12AffineEnvironment.transform 10 48 env16155 = env16156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env16155 == env16156) = true)

theorem identity16156 : scanCanonicalize (H12AffineFastState.compose env16156 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound16156 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env16157 : List Nat := [2,4,8,16,32,17,9,5,0,21,48,1,56,1,17,35,1,49,20,16,1,1,17,51,57,17,49,0,0,48,20,0,4,17,1,0]

theorem envBound16157 : H12AffineFastState.Bounded env16157 := by
  intro p hp
  have h : env16157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16156_16157 : H12AffineEnvironment.transform 6 9 env16156 = env16157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16156 == env16157) = true)

def env16158 : List Nat := [2,4,8,16,0,17,9,5,0,21,16,1,24,1,17,3,1,17,20,16,1,1,17,19,25,17,17,0,0,16,20,0,4,17,1,0]

theorem envBound16158 : H12AffineFastState.Bounded env16158 := by
  intro p hp
  have h : env16158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16157_16158 : H12AffineEnvironment.transform 4 0 env16157 = env16158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16157 == env16158) = true)

def env16159 : List Nat := [2,4,8,16,1,17,9,5,0,21,17,1,25,1,17,2,1,16,20,16,1,1,17,18,24,17,16,0,0,17,20,0,4,17,1,0]

theorem envBound16159 : H12AffineFastState.Bounded env16159 := by
  intro p hp
  have h : env16159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16157_16159 : H12AffineEnvironment.transform 4 1 env16157 = env16159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16157 == env16159) = true)

theorem identity16159 : scanCanonicalize (H12AffineFastState.compose env16159 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound16159 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16160 : List Nat := [2,4,8,0,1,1,9,5,0,5,1,1,9,1,1,2,1,0,4,0,1,1,1,2,8,1,0,0,0,1,4,0,4,1,1,0]

theorem envBound16160 : H12AffineFastState.Bounded env16160 := by
  intro p hp
  have h : env16160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16159_16160 : H12AffineEnvironment.transform 3 0 env16159 = env16160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env16159 == env16160) = true)

def leafEnv16160 : List Nat := [2,4,8,0,1,1,9,5,0,5,1,1,9,1,1,2,1,0,4,0,1,1,1,2,4,8,1,1,0,0,0,1,4,0,4,1,4,2,1,0,0,1,1]

def active16160 : List Nat := [0,1,2]

def tree16160 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16160 : H12WitnessSearch.Good tree16160 := H12GlobalWitnessIndex.good

theorem leafIdentity16160 : H12AffineFastState.composeSystem env16160 rootObs = leafEnv16160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16160 rootObs == leafEnv16160) = true)

theorem terminalChecked16160 : H12PackedTerminal.terminalCheckFast leafEnv16160 active16160 tree16160 = true := by decide +kernel

def env16161 : List Nat := [2,4,8,16,32,17,128,5,137,21,49,1,177,1,17,35,1,185,20,16,1,136,17,51,57,17,48,0,0,184,20,0,4,17,1,137]

theorem envBound16161 : H12AffineFastState.Bounded env16161 := by
  intro p hp
  have h : env16161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16155_16161 : H12AffineEnvironment.transform 10 49 env16155 = env16161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env16155 == env16161) = true)

def env16162 : List Nat := [2,4,8,16,32,17,128,5,137,21,2048,1,8192,1,8353,34,1,2185,20,8352,1,137,17,8322,8328,17,2049,0,0,2184,20,1,4,8352,1,137]

theorem envBound16162 : H12AffineFastState.Bounded env16162 := by
  intro p hp
  have h : env16162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16153_16162 : H12AffineEnvironment.transform 14 8353 env16153 = env16162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8353 env16153 == env16162) = true)

theorem identity16162 : scanCanonicalize (H12AffineFastState.compose env16162 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound16162 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16163 : List Nat := [2,4,8,16,32,17,128,5,137,21,2048,1,24,1,185,34,1,2185,20,184,1,137,17,154,144,17,2049,0,0,2184,20,1,4,184,1,137]

theorem envBound16163 : H12AffineFastState.Bounded env16163 := by
  intro p hp
  have h : env16163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16162_16163 : H12AffineEnvironment.transform 12 24 env16162 = env16163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env16162 == env16163) = true)

def env16164 : List Nat := [2,4,8,16,32,17,128,5,137,21,16,1,24,1,185,34,1,153,20,184,1,137,17,154,144,17,17,0,0,152,20,1,4,184,1,137]

theorem envBound16164 : H12AffineFastState.Bounded env16164 := by
  intro p hp
  have h : env16164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16163_16164 : H12AffineEnvironment.transform 10 16 env16163 = env16164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env16163 == env16164) = true)

theorem identity16164 : scanCanonicalize (H12AffineFastState.compose env16164 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound16164 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env16165 : List Nat := [2,4,8,16,32,17,8,5,1,21,16,1,24,1,49,34,1,17,20,48,1,1,17,18,24,17,17,0,0,16,20,1,4,48,1,1]

theorem envBound16165 : H12AffineFastState.Bounded env16165 := by
  intro p hp
  have h : env16165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16164_16165 : H12AffineEnvironment.transform 6 8 env16164 = env16165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16164 == env16165) = true)

def env16166 : List Nat := [2,4,8,16,0,17,8,5,1,21,16,1,24,1,17,2,1,17,20,16,1,1,17,18,24,17,17,0,0,16,20,1,4,16,1,1]

theorem envBound16166 : H12AffineFastState.Bounded env16166 := by
  intro p hp
  have h : env16166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16165_16166 : H12AffineEnvironment.transform 4 0 env16165 = env16166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16165 == env16166) = true)

def env16167 : List Nat := [2,4,8,16,1,17,8,5,1,21,16,1,24,1,16,3,1,17,20,17,1,1,17,18,24,17,17,0,0,16,20,1,4,17,1,1]

theorem envBound16167 : H12AffineFastState.Bounded env16167 := by
  intro p hp
  have h : env16167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16165_16167 : H12AffineEnvironment.transform 4 1 env16165 = env16167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16165 == env16167) = true)

theorem identity16167 : scanCanonicalize (H12AffineFastState.compose env16167 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound16167 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16168 : List Nat := [2,4,8,1,1,0,8,5,1,4,1,1,9,1,1,3,1,0,5,0,1,1,0,3,9,0,0,0,0,1,5,1,4,0,1,1]

theorem envBound16168 : H12AffineFastState.Bounded env16168 := by
  intro p hp
  have h : env16168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16167_16168 : H12AffineEnvironment.transform 3 1 env16167 = env16168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env16167 == env16168) = true)

def leafEnv16168 : List Nat := [2,4,8,1,1,0,8,5,1,4,1,1,9,1,1,3,1,0,5,0,1,1,0,3,5,9,1,0,0,0,0,1,5,1,4,0,4,2,1,1,0,1,1]

def active16168 : List Nat := [0,1,2]

def tree16168 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16168 : H12WitnessSearch.Good tree16168 := H12GlobalWitnessIndex.good

theorem leafIdentity16168 : H12AffineFastState.composeSystem env16168 rootObs = leafEnv16168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16168 rootObs == leafEnv16168) = true)

theorem terminalChecked16168 : H12PackedTerminal.terminalCheckFast leafEnv16168 active16168 tree16168 = true := by decide +kernel

def env16169 : List Nat := [2,4,8,16,32,17,128,5,137,21,17,1,24,1,185,34,1,152,20,184,1,137,17,154,144,17,16,0,0,153,20,1,4,184,1,137]

theorem envBound16169 : H12AffineFastState.Bounded env16169 := by
  intro p hp
  have h : env16169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16163_16169 : H12AffineEnvironment.transform 10 17 env16163 = env16169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env16163 == env16169) = true)

def env16170 : List Nat := [2,4,8,16,32,17,128,5,137,1024,2048,1045,8192,1045,32768,65536,1044,262144,1025,32769,1045,4194304,16,98305,8328,16,4456449,1044,1045,1073741824,1025,1077979297,4,1073817610,1044,137]

theorem envBound16170 : H12AffineFastState.Bounded env16170 := by
  intro p hp
  have h : env16170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16134_16170 : H12AffineEnvironment.transform 11 1045 env16134 = env16170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env16134 == env16170) = true)

theorem identity16170 : scanCanonicalize (H12AffineFastState.compose env16170 (packedSelected [1,3,5] rootPS)) = affineNative (2^(21+1) ^^^ 362634) := by decide +kernel

theorem selectedBound16170 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env16171 : List Nat := [2,4,8,16,32,17,128,5,137,1024,2048,1045,8192,1045,32768,65536,1044,262144,1025,32769,1045,362634,16,98305,8328,16,100491,1044,1045,1073741824,1025,1074077739,4,1073817610,1044,137]

theorem envBound16171 : H12AffineFastState.Bounded env16171 := by
  intro p hp
  have h : env16171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16170_16171 : H12AffineEnvironment.transform 21 362634 env16170 = env16171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 362634 env16170 == env16171) = true)

theorem identity16171 : scanCanonicalize (H12AffineFastState.compose env16171 (packedSelected [1,3,8] rootPS)) = affineNative (2^(29+1) ^^^ 360587) := by decide +kernel

theorem selectedBound16171 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

end H12CloudChart2