import H12CloudChart2Data233

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans59089_59090 : H12AffineEnvironment.transform 7 3 env59089 = env59090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 3 env59089 == env59090) = true)

theorem identity59090 : scanCanonicalize (H12AffineFastState.compose env59090 (packedSelected [0,7] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound59090 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env59091 : List Nat := [2,2,2,0,0,1,2,3,0,3,1,1,3,1,0,3,1,1,3,1,0,0,1,3,3,1,1,0,0,0,2,1,3,1,1,1]

theorem envBound59091 : H12AffineFastState.Bounded env59091 := by
  intro p hp
  have h : env59091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59090_59091 : H12AffineEnvironment.transform 1 2 env59090 = env59091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env59090 == env59091) = true)

theorem identity59091 : scanCanonicalize (H12AffineFastState.compose env59091 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound59091 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59092 : List Nat := [0,0,0,0,0,1,0,1,0,1,1,1,1,1,0,1,1,1,1,1,0,0,1,1,1,1,1,0,0,0,0,1,1,1,1,1]

theorem envBound59092 : H12AffineFastState.Bounded env59092 := by
  intro p hp
  have h : env59092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59091_59092 : H12AffineEnvironment.transform 0 0 env59091 = env59092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env59091 == env59092) = true)

def env59093 : List Nat := [2,4,5,0,32,64,128,256,324,1024,2048,1,1024,1281,1,65536,65634,65664,321,0,0,449,66851,65536,452,65571,291,65570,1280,67911,1024,1281,256,65831,1344,1028]

theorem envBound59093 : H12AffineFastState.Bounded env59093 := by
  intro p hp
  have h : env59093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59082_59093 : H12AffineEnvironment.transform 2 5 env59082 = env59093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env59082 == env59093) = true)

theorem identity59093 : scanCanonicalize (H12AffineFastState.compose env59093 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 1127) := by decide +kernel

theorem selectedBound59093 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env59094 : List Nat := [2,4,5,0,32,64,128,256,324,1024,2048,1,1024,1281,1,1127,1029,1255,321,0,0,449,324,1127,452,1092,291,1093,1280,3360,1024,1281,256,1344,1344,1028]

theorem envBound59094 : H12AffineFastState.Bounded env59094 := by
  intro p hp
  have h : env59094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59093_59094 : H12AffineEnvironment.transform 15 1127 env59093 = env59094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1127 env59093 == env59094) = true)

theorem identity59094 : scanCanonicalize (H12AffineFastState.compose env59094 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound59094 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env59095 : List Nat := [2,4,5,0,32,64,128,256,324,320,2048,1,320,65,1,295,325,423,321,0,0,449,324,295,452,260,291,261,64,2144,320,65,256,0,0,324]

theorem envBound59095 : H12AffineFastState.Bounded env59095 := by
  intro p hp
  have h : env59095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59094_59095 : H12AffineEnvironment.transform 9 320 env59094 = env59095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env59094 == env59095) = true)

theorem identity59095 : scanCanonicalize (H12AffineFastState.compose env59095 (packedSelected [0,2,3,5,7,8,11,12,13,15] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound59095 : packedSelected [0,2,3,5,7,8,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env59096 : List Nat := [2,4,5,0,32,0,128,256,260,256,2048,1,256,1,1,295,261,423,257,0,0,385,260,295,388,260,291,261,0,2080,256,1,256,0,0,260]

theorem envBound59096 : H12AffineFastState.Bounded env59096 := by
  intro p hp
  have h : env59096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59095_59096 : H12AffineEnvironment.transform 5 0 env59095 = env59096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env59095 == env59096) = true)

theorem identity59096 : scanCanonicalize (H12AffineFastState.compose env59096 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound59096 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59097 : List Nat := [2,4,5,0,32,0,128,256,260,256,1,1,256,1,1,295,261,423,257,0,0,385,260,295,388,260,291,261,0,33,256,1,256,0,0,260]

theorem envBound59097 : H12AffineFastState.Bounded env59097 := by
  intro p hp
  have h : env59097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59096_59097 : H12AffineEnvironment.transform 10 1 env59096 = env59097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env59096 == env59097) = true)

theorem identity59097 : scanCanonicalize (H12AffineFastState.compose env59097 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound59097 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59098 : List Nat := [2,4,5,0,32,0,128,36,32,36,1,1,36,1,1,3,33,131,37,0,0,165,32,3,160,32,7,33,0,33,36,1,36,0,0,32]

theorem envBound59098 : H12AffineFastState.Bounded env59098 := by
  intro p hp
  have h : env59098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59097_59098 : H12AffineEnvironment.transform 7 36 env59097 = env59098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env59097 == env59098) = true)

theorem identity59098 : scanCanonicalize (H12AffineFastState.compose env59098 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 36) := by decide +kernel

theorem selectedBound59098 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env59099 : List Nat := [2,4,5,0,32,0,36,36,32,36,1,1,36,1,1,3,33,39,37,0,0,1,32,3,4,32,7,33,0,33,36,1,36,0,0,32]

theorem envBound59099 : H12AffineFastState.Bounded env59099 := by
  intro p hp
  have h : env59099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59098_59099 : H12AffineEnvironment.transform 6 36 env59098 = env59099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 36 env59098 == env59099) = true)

def env59100 : List Nat := [2,4,8,1,32,64,128,256,325,1024,2048,1,8192,1280,9229,65536,74863,65664,321,9228,0,461,74031,65537,9673,74798,303,74798,1281,77130,8205,1281,256,65831,1344,1029]

theorem envBound59100 : H12AffineFastState.Bounded env59100 := by
  intro p hp
  have h : env59100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59080_59100 : H12AffineEnvironment.transform 3 1 env59080 = env59100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env59080 == env59100) = true)

theorem identity59100 : scanCanonicalize (H12AffineFastState.compose env59100 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 9) := by decide +kernel

theorem selectedBound59100 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env59101 : List Nat := [2,4,8,1,32,64,128,9,76,1024,2048,1,8192,1033,9229,65536,74863,65664,72,9228,0,196,73766,65537,9408,74798,38,74798,1032,76867,8205,1032,9,65582,1097,1029]

theorem envBound59101 : H12AffineFastState.Bounded env59101 := by
  intro p hp
  have h : env59101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59100_59101 : H12AffineEnvironment.transform 7 9 env59100 = env59101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 9 env59100 == env59101) = true)

def env59102 : List Nat := [2,4,4,1,32,64,128,5,64,1024,2048,1,8192,1029,9217,65536,74851,65664,68,9216,0,196,73766,65537,9408,74786,38,74786,1028,76867,8193,1028,5,65570,1093,1029]

theorem envBound59102 : H12AffineFastState.Bounded env59102 := by
  intro p hp
  have h : env59102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59101_59102 : H12AffineEnvironment.transform 2 4 env59101 = env59102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env59101 == env59102) = true)

theorem identity59102 : scanCanonicalize (H12AffineFastState.compose env59102 (packedSelected [13,21] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound59102 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env59103 : List Nat := [2,4,4,1,32,64,128,5,64,1024,2048,1,8192,1029,9217,35,9280,163,68,9216,0,196,8197,34,9408,9217,38,9217,1028,11360,8193,1028,5,1,1093,1029]

theorem envBound59103 : H12AffineFastState.Bounded env59103 := by
  intro p hp
  have h : env59103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59102_59103 : H12AffineEnvironment.transform 15 35 env59102 = env59103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env59102 == env59103) = true)

theorem identity59103 : scanCanonicalize (H12AffineFastState.compose env59103 (packedSelected [0,7,8,10,11,13,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 7) := by decide +kernel

theorem selectedBound59103 : packedSelected [0,7,8,10,11,13,15,17] rootPS < 2^1333 := by decide +kernel

def env59104 : List Nat := [2,4,4,1,32,64,128,5,64,1024,7,1,8192,1029,9217,35,9280,163,68,9216,0,196,8197,34,9408,9217,38,9217,1028,9319,8193,1028,5,1,1093,1029]

theorem envBound59104 : H12AffineFastState.Bounded env59104 := by
  intro p hp
  have h : env59104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59103_59104 : H12AffineEnvironment.transform 10 7 env59103 = env59104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 7 env59103 == env59104) = true)

theorem identity59104 : scanCanonicalize (H12AffineFastState.compose env59104 (packedSelected [0,1,2,7,8,11,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound59104 : packedSelected [0,1,2,7,8,11,12,15] rootPS < 2^1333 := by decide +kernel

def env59105 : List Nat := [2,4,4,1,32,64,128,5,64,36,7,1,8192,33,8229,35,8292,163,68,8228,0,196,8197,34,8420,8229,38,8229,32,8259,8193,32,5,1,97,33]

theorem envBound59105 : H12AffineFastState.Bounded env59105 := by
  intro p hp
  have h : env59105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59104_59105 : H12AffineEnvironment.transform 9 36 env59104 = env59105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env59104 == env59105) = true)

theorem identity59105 : scanCanonicalize (H12AffineFastState.compose env59105 (packedSelected [0,1,2,3,4,11] rootPS)) = affineNative (2^(6+1) ^^^ 98) := by decide +kernel

theorem selectedBound59105 : packedSelected [0,1,2,3,4,11] rootPS < 2^1333 := by decide +kernel

def env59106 : List Nat := [2,4,4,1,32,64,98,5,64,36,7,1,8192,33,8229,35,8292,65,68,8228,0,38,8197,34,8198,8229,38,8229,32,8259,8193,32,5,1,97,33]

theorem envBound59106 : H12AffineFastState.Bounded env59106 := by
  intro p hp
  have h : env59106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59105_59106 : H12AffineEnvironment.transform 6 98 env59105 = env59106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 98 env59105 == env59106) = true)

theorem identity59106 : scanCanonicalize (H12AffineFastState.compose env59106 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(12+1) ^^^ 4) := by decide +kernel

theorem selectedBound59106 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env59107 : List Nat := [2,4,4,1,32,64,98,5,64,36,7,1,4,33,33,35,96,65,68,32,0,38,1,34,2,33,38,33,32,71,5,32,5,1,97,33]

theorem envBound59107 : H12AffineFastState.Bounded env59107 := by
  intro p hp
  have h : env59107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59106_59107 : H12AffineEnvironment.transform 12 4 env59106 = env59107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4 env59106 == env59107) = true)

theorem identity59107 : scanCanonicalize (H12AffineFastState.compose env59107 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound59107 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env59108 : List Nat := [2,4,4,1,32,32,2,5,32,36,7,1,4,33,33,35,0,33,36,32,0,38,1,34,2,33,38,33,32,39,5,32,5,1,1,33]

theorem envBound59108 : H12AffineFastState.Bounded env59108 := by
  intro p hp
  have h : env59108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59107_59108 : H12AffineEnvironment.transform 5 32 env59107 = env59108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env59107 == env59108) = true)

theorem identity59108 : scanCanonicalize (H12AffineFastState.compose env59108 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound59108 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59109 : List Nat := [0,4,4,1,32,32,0,5,32,36,5,1,4,33,33,33,0,33,36,32,0,36,1,32,0,33,36,33,32,37,5,32,5,1,1,33]

theorem envBound59109 : H12AffineFastState.Bounded env59109 := by
  intro p hp
  have h : env59109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59108_59109 : H12AffineEnvironment.transform 0 0 env59108 = env59109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env59108 == env59109) = true)

theorem identity59109 : scanCanonicalize (H12AffineFastState.compose env59109 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound59109 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59110 : List Nat := [0,0,0,1,32,32,0,1,32,32,1,1,0,33,33,33,0,33,32,32,0,32,1,32,0,33,32,33,32,33,1,32,1,1,1,33]

theorem envBound59110 : H12AffineFastState.Bounded env59110 := by
  intro p hp
  have h : env59110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59109_59110 : H12AffineEnvironment.transform 1 0 env59109 = env59110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env59109 == env59110) = true)

theorem identity59110 : scanCanonicalize (H12AffineFastState.compose env59110 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound59110 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env59111 : List Nat := [0,0,0,1,0,0,0,1,0,0,1,1,0,1,1,1,0,1,0,0,0,0,1,0,0,1,0,1,0,1,1,0,1,1,1,1]

theorem envBound59111 : H12AffineFastState.Bounded env59111 := by
  intro p hp
  have h : env59111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59110_59111 : H12AffineEnvironment.transform 4 0 env59110 = env59111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env59110 == env59111) = true)

def env59112 : List Nat := [2,4,5,1,32,64,128,4,65,1024,2048,1,8192,1028,9216,65536,74850,65664,69,9217,0,196,73766,65537,9408,74787,38,74787,1029,76867,8192,1029,4,65571,1092,1029]

theorem envBound59112 : H12AffineFastState.Bounded env59112 := by
  intro p hp
  have h : env59112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59101_59112 : H12AffineEnvironment.transform 2 5 env59101 = env59112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env59101 == env59112) = true)

theorem identity59112 : scanCanonicalize (H12AffineFastState.compose env59112 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 4) := by decide +kernel

theorem selectedBound59112 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env59113 : List Nat := [2,4,5,1,32,64,128,4,65,1024,2048,1,4,1028,1028,65536,66662,65664,69,1029,0,196,65570,65537,1220,66599,38,66599,1029,68679,4,1029,4,65571,1092,1029]

theorem envBound59113 : H12AffineFastState.Bounded env59113 := by
  intro p hp
  have h : env59113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59112_59113 : H12AffineEnvironment.transform 12 4 env59112 = env59113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4 env59112 == env59113) = true)

theorem identity59113 : scanCanonicalize (H12AffineFastState.compose env59113 (packedSelected [1,2,3,8,10,11,12,13,15,20] rootPS)) = affineNative (2^(15+1) ^^^ 1186) := by decide +kernel

theorem selectedBound59113 : packedSelected [1,2,3,8,10,11,12,13,15,20] rootPS < 2^1333 := by decide +kernel

def env59114 : List Nat := [2,4,5,1,32,64,128,4,65,1024,2048,1,4,1028,1028,1186,196,1058,69,1029,0,196,1152,1187,1220,133,38,133,1029,2277,4,1029,4,1153,1092,1029]

theorem envBound59114 : H12AffineFastState.Bounded env59114 := by
  intro p hp
  have h : env59114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59113_59114 : H12AffineEnvironment.transform 15 1186 env59113 = env59114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1186 env59113 == env59114) = true)

theorem identity59114 : scanCanonicalize (H12AffineFastState.compose env59114 (packedSelected [1,2,5,8,10,11,12,13,18] rootPS)) = affineNative (2^(6+1) ^^^ 67) := by decide +kernel

theorem selectedBound59114 : packedSelected [1,2,5,8,10,11,12,13,18] rootPS < 2^1333 := by decide +kernel

def env59115 : List Nat := [2,4,5,1,32,64,67,4,65,1024,2048,1,4,1028,1028,1121,7,1058,69,1029,0,7,1091,1120,1031,70,38,70,1029,2086,4,1029,4,1090,1092,1029]

theorem envBound59115 : H12AffineFastState.Bounded env59115 := by
  intro p hp
  have h : env59115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59114_59115 : H12AffineEnvironment.transform 6 67 env59114 = env59115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 67 env59114 == env59115) = true)

theorem identity59115 : scanCanonicalize (H12AffineFastState.compose env59115 (packedSelected [0,1,3,4,7,8,9,10,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 3) := by decide +kernel

theorem selectedBound59115 : packedSelected [0,1,3,4,7,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env59116 : List Nat := [2,4,5,1,32,64,67,4,65,3,2048,1,4,7,7,98,7,33,69,6,0,7,64,99,4,70,38,70,6,2086,4,6,4,65,71,6]

theorem envBound59116 : H12AffineFastState.Bounded env59116 := by
  intro p hp
  have h : env59116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59115_59116 : H12AffineEnvironment.transform 9 3 env59115 = env59116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 3 env59115 == env59116) = true)

def env59117 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,1,8192,1297,9244,65536,74863,65664,321,9245,0,476,74046,65552,9673,74798,318,74815,1296,77130,8205,1281,256,65831,1344,1045]

theorem envBound59117 : H12AffineFastState.Bounded env59117 := by
  intro p hp
  have h : env59117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59079_59117 : H12AffineEnvironment.transform 8 341 env59079 = env59117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env59079 == env59117) = true)

def env59118 : List Nat := [2,4,8,0,32,64,128,256,325,1024,2048,1,8192,1281,9228,65536,74863,65664,321,9229,0,460,74030,65536,9673,74798,302,74799,1280,77130,8205,1281,256,65831,1344,1029]

theorem envBound59118 : H12AffineFastState.Bounded env59118 := by
  intro p hp
  have h : env59118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59117_59118 : H12AffineEnvironment.transform 3 0 env59117 = env59118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env59117 == env59118) = true)

theorem identity59118 : scanCanonicalize (H12AffineFastState.compose env59118 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 1327) := by decide +kernel

theorem selectedBound59118 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env59119 : List Nat := [2,4,8,0,32,64,128,256,325,1024,2048,1,8192,1281,9228,1327,8512,1455,321,9229,0,460,9217,1327,9673,8449,302,8448,1280,10341,8205,1281,256,1032,1344,1029]

theorem envBound59119 : H12AffineFastState.Bounded env59119 := by
  intro p hp
  have h : env59119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59118_59119 : H12AffineEnvironment.transform 15 1327 env59118 = env59119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1327 env59118 == env59119) = true)

def env59120 : List Nat := [2,4,8,0,32,64,128,256,325,1024,2048,1,1288,1281,260,1327,1096,1455,321,261,0,460,265,1327,193,1033,302,1032,1280,3437,1285,1281,256,1032,1344,1029]

theorem envBound59120 : H12AffineFastState.Bounded env59120 := by
  intro p hp
  have h : env59120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59119_59120 : H12AffineEnvironment.transform 12 1288 env59119 = env59120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1288 env59119 == env59120) = true)

theorem identity59120 : scanCanonicalize (H12AffineFastState.compose env59120 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound59120 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59121 : List Nat := [2,4,8,0,32,64,128,4,65,1024,2048,1,1036,1029,0,1067,1096,1195,69,1,0,200,13,1067,193,1033,42,1032,1028,3177,1025,1029,4,1032,1092,1029]

theorem envBound59121 : H12AffineFastState.Bounded env59121 := by
  intro p hp
  have h : env59121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59120_59121 : H12AffineEnvironment.transform 7 4 env59120 = env59121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env59120 == env59121) = true)

theorem identity59121 : scanCanonicalize (H12AffineFastState.compose env59121 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound59121 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env59122 : List Nat := [2,4,8,0,32,1,128,4,0,1024,2048,1,1036,1029,0,1067,1033,1195,4,1,0,137,13,1067,128,1033,42,1032,1028,3112,1025,1029,4,1032,1029,1029]

theorem envBound59122 : H12AffineFastState.Bounded env59122 := by
  intro p hp
  have h : env59122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59121_59122 : H12AffineEnvironment.transform 5 1 env59121 = env59122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env59121 == env59122) = true)

theorem identity59122 : scanCanonicalize (H12AffineFastState.compose env59122 (packedSelected [0,1,7,8,10,11,12,13] rootPS)) = affineNative (2^(10+1) ^^^ 133) := by decide +kernel

theorem selectedBound59122 : packedSelected [0,1,7,8,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env59123 : List Nat := [2,4,8,0,32,1,128,4,0,1024,133,1,1036,1029,0,1067,1033,1195,4,1,0,137,13,1067,128,1033,42,1032,1028,1197,1025,1029,4,1032,1029,1029]

theorem envBound59123 : H12AffineFastState.Bounded env59123 := by
  intro p hp
  have h : env59123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59122_59123 : H12AffineEnvironment.transform 10 133 env59122 = env59123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 133 env59122 == env59123) = true)

theorem identity59123 : scanCanonicalize (H12AffineFastState.compose env59123 (packedSelected [1,2] rootPS)) = affineNative (2^(9+1) ^^^ 35) := by decide +kernel

theorem selectedBound59123 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env59124 : List Nat := [2,4,8,0,32,1,128,4,0,35,133,1,47,38,0,8,42,136,4,1,0,137,13,8,128,42,42,43,39,142,34,38,4,43,38,38]

theorem envBound59124 : H12AffineFastState.Bounded env59124 := by
  intro p hp
  have h : env59124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59123_59124 : H12AffineEnvironment.transform 9 35 env59123 = env59124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 35 env59123 == env59124) = true)

theorem identity59124 : scanCanonicalize (H12AffineFastState.compose env59124 (packedSelected [5,8] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound59124 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59125 : List Nat := [2,4,8,0,32,1,41,4,0,35,44,1,47,38,0,8,42,33,4,1,0,32,13,8,41,42,42,43,39,39,34,38,4,43,38,38]

theorem envBound59125 : H12AffineFastState.Bounded env59125 := by
  intro p hp
  have h : env59125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59124_59125 : H12AffineEnvironment.transform 6 41 env59124 = env59125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env59124 == env59125) = true)

theorem identity59125 : scanCanonicalize (H12AffineFastState.compose env59125 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound59125 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env59126 : List Nat := [2,4,5,0,32,1,36,4,0,35,33,1,34,38,0,5,39,33,4,1,0,32,0,5,36,39,39,38,39,39,34,38,4,38,38,38]

theorem envBound59126 : H12AffineFastState.Bounded env59126 := by
  intro p hp
  have h : env59126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59125_59126 : H12AffineEnvironment.transform 2 5 env59125 = env59126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env59125 == env59126) = true)

theorem identity59126 : scanCanonicalize (H12AffineFastState.compose env59126 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound59126 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env59127 : List Nat := [2,4,5,0,7,1,3,4,0,4,6,1,5,1,0,5,0,6,4,1,0,7,0,5,3,0,0,1,0,0,5,1,4,1,1,1]

theorem envBound59127 : H12AffineFastState.Bounded env59127 := by
  intro p hp
  have h : env59127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59126_59127 : H12AffineEnvironment.transform 4 7 env59126 = env59127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env59126 == env59127) = true)

theorem identity59127 : scanCanonicalize (H12AffineFastState.compose env59127 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound59127 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59128 : List Nat := [1,4,5,0,4,1,0,4,0,4,5,1,5,1,0,5,0,5,4,1,0,4,0,5,0,0,0,1,0,0,5,1,4,1,1,1]

theorem envBound59128 : H12AffineFastState.Bounded env59128 := by
  intro p hp
  have h : env59128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59127_59128 : H12AffineEnvironment.transform 0 1 env59127 = env59128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env59127 == env59128) = true)

theorem identity59128 : scanCanonicalize (H12AffineFastState.compose env59128 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound59128 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env59129 : List Nat := [1,1,0,0,1,1,0,1,0,1,0,1,0,1,0,0,0,0,1,1,0,1,0,0,0,0,0,1,0,0,0,1,1,1,1,1]

theorem envBound59129 : H12AffineFastState.Bounded env59129 := by
  intro p hp
  have h : env59129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59128_59129 : H12AffineEnvironment.transform 1 1 env59128 = env59129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env59128 == env59129) = true)

def env59130 : List Nat := [2,4,8,0,32,64,128,256,325,1024,2048,1,1289,1281,261,1327,1097,1455,321,260,0,460,264,1327,192,1032,302,1033,1280,3436,1284,1281,256,1032,1344,1029]

theorem envBound59130 : H12AffineFastState.Bounded env59130 := by
  intro p hp
  have h : env59130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59119_59130 : H12AffineEnvironment.transform 12 1289 env59119 = env59130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1289 env59119 == env59130) = true)

theorem identity59130 : scanCanonicalize (H12AffineFastState.compose env59130 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound59130 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59131 : List Nat := [2,4,8,0,32,64,128,256,325,69,2048,1,332,324,261,362,12,490,321,260,0,460,264,362,192,77,302,76,325,2345,321,324,256,77,261,64]

theorem envBound59131 : H12AffineFastState.Bounded env59131 := by
  intro p hp
  have h : env59131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59130_59131 : H12AffineEnvironment.transform 9 69 env59130 = env59131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env59130 == env59131) = true)

theorem identity59131 : scanCanonicalize (H12AffineFastState.compose env59131 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 6) := by decide +kernel

theorem selectedBound59131 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env59132 : List Nat := [2,4,8,0,32,64,128,256,325,69,6,1,332,324,261,362,12,490,321,260,0,460,264,362,192,77,302,76,325,303,321,324,256,77,261,64]

theorem envBound59132 : H12AffineFastState.Bounded env59132 := by
  intro p hp
  have h : env59132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59131_59132 : H12AffineEnvironment.transform 10 6 env59131 = env59132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 6 env59131 == env59132) = true)

theorem identity59132 : scanCanonicalize (H12AffineFastState.compose env59132 (packedSelected [0,1,3,7,8,10,11,17] rootPS)) = affineNative (2^(6+1) ^^^ 78) := by decide +kernel

theorem selectedBound59132 : packedSelected [0,1,3,7,8,10,11,17] rootPS < 2^1333 := by decide +kernel

def env59133 : List Nat := [2,4,8,0,32,64,78,256,325,69,6,1,332,324,261,362,12,292,321,260,0,258,264,362,14,77,302,76,325,303,321,324,256,77,261,64]

theorem envBound59133 : H12AffineFastState.Bounded env59133 := by
  intro p hp
  have h : env59133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59132_59133 : H12AffineEnvironment.transform 6 78 env59132 = env59133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 78 env59132 == env59133) = true)

theorem identity59133 : scanCanonicalize (H12AffineFastState.compose env59133 (packedSelected [1,2,3,7,8,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 45) := by decide +kernel

theorem selectedBound59133 : packedSelected [1,2,3,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env59134 : List Nat := [2,4,8,0,32,45,35,256,296,40,6,1,289,297,261,263,12,292,300,260,0,258,264,263,14,32,302,33,296,303,300,297,256,32,261,45]

theorem envBound59134 : H12AffineFastState.Bounded env59134 := by
  intro p hp
  have h : env59134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59133_59134 : H12AffineEnvironment.transform 5 45 env59133 = env59134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 45 env59133 == env59134) = true)

theorem identity59134 : scanCanonicalize (H12AffineFastState.compose env59134 (packedSelected [0,2,3,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound59134 : packedSelected [0,2,3,7,8] rootPS < 2^1333 := by decide +kernel

def env59135 : List Nat := [2,4,8,0,12,1,15,256,260,4,6,1,269,261,261,263,12,264,256,260,0,258,264,263,14,12,258,13,260,259,256,261,256,12,261,1]

theorem envBound59135 : H12AffineFastState.Bounded env59135 := by
  intro p hp
  have h : env59135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59134_59135 : H12AffineEnvironment.transform 4 12 env59134 = env59135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env59134 == env59135) = true)

theorem identity59135 : scanCanonicalize (H12AffineFastState.compose env59135 (packedSelected [0,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 2) := by decide +kernel

theorem selectedBound59135 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env59136 : List Nat := [2,4,8,0,12,1,15,2,6,4,6,1,15,7,7,5,12,10,2,6,0,0,10,5,14,12,0,13,6,1,2,7,2,12,7,1]

theorem envBound59136 : H12AffineFastState.Bounded env59136 := by
  intro p hp
  have h : env59136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59135_59136 : H12AffineEnvironment.transform 7 2 env59135 = env59136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 2 env59135 == env59136) = true)

def env59137 : List Nat := [2,4,8,1,32,64,128,256,324,1024,2048,1,8192,1280,9229,65536,74863,65664,321,9228,0,461,74031,65537,9673,74798,303,74798,1281,77130,8205,1281,256,65831,1344,1028]

theorem envBound59137 : H12AffineFastState.Bounded env59137 := by
  intro p hp
  have h : env59137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59117_59137 : H12AffineEnvironment.transform 3 1 env59117 = env59137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env59117 == env59137) = true)

theorem identity59137 : scanCanonicalize (H12AffineFastState.compose env59137 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8230) := by decide +kernel

theorem selectedBound59137 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env59138 : List Nat := [2,4,8,1,32,64,128,256,324,1024,2048,1,8192,1280,9229,8230,1097,8358,321,9228,0,461,265,8231,9673,1032,303,1032,1281,3436,8205,1281,256,8449,1344,1028]

theorem envBound59138 : H12AffineFastState.Bounded env59138 := by
  intro p hp
  have h : env59138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59137_59138 : H12AffineEnvironment.transform 15 8230 env59137 = env59138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8230 env59137 == env59138) = true)

def env59139 : List Nat := [2,4,8,1,32,64,128,256,324,1024,2048,1,1024,1280,13,1062,1097,1190,321,12,0,461,265,1063,457,1032,303,1032,1281,3436,1037,1281,256,1281,1344,1028]

theorem envBound59139 : H12AffineFastState.Bounded env59139 := by
  intro p hp
  have h : env59139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59138_59139 : H12AffineEnvironment.transform 12 1024 env59138 = env59139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1024 env59138 == env59139) = true)

theorem identity59139 : scanCanonicalize (H12AffineFastState.compose env59139 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound59139 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env59140 : List Nat := [2,4,8,1,32,0,128,256,260,1024,2048,1,1024,1280,13,1062,1033,1190,257,12,0,397,265,1063,393,1032,303,1032,1281,3372,1037,1281,256,1281,1280,1028]

theorem envBound59140 : H12AffineFastState.Bounded env59140 := by
  intro p hp
  have h : env59140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59139_59140 : H12AffineEnvironment.transform 5 0 env59139 = env59140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env59139 == env59140) = true)

theorem identity59140 : scanCanonicalize (H12AffineFastState.compose env59140 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound59140 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env59141 : List Nat := [2,4,8,1,32,0,128,256,260,256,2048,1,256,0,13,294,265,422,257,12,0,397,265,295,393,264,303,264,1,2092,269,1,256,1,0,260]

theorem envBound59141 : H12AffineFastState.Bounded env59141 := by
  intro p hp
  have h : env59141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59140_59141 : H12AffineEnvironment.transform 9 256 env59140 = env59141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env59140 == env59141) = true)

theorem identity59141 : scanCanonicalize (H12AffineFastState.compose env59141 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 271) := by decide +kernel

theorem selectedBound59141 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env59142 : List Nat := [2,4,8,1,32,0,128,256,260,256,271,1,256,0,13,294,265,422,257,12,0,397,265,295,393,264,303,264,1,291,269,1,256,1,0,260]

theorem envBound59142 : H12AffineFastState.Bounded env59142 := by
  intro p hp
  have h : env59142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59141_59142 : H12AffineEnvironment.transform 10 271 env59141 = env59142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 271 env59141 == env59142) = true)

theorem identity59142 : scanCanonicalize (H12AffineFastState.compose env59142 (packedSelected [1,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound59142 : packedSelected [1,5,10] rootPS < 2^1333 := by decide +kernel

def env59143 : List Nat := [2,4,8,1,32,0,9,256,260,256,271,1,256,0,13,294,265,303,257,12,0,260,265,295,256,264,303,264,1,291,269,1,256,1,0,260]

theorem envBound59143 : H12AffineFastState.Bounded env59143 := by
  intro p hp
  have h : env59143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59142_59143 : H12AffineEnvironment.transform 6 9 env59142 = env59143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env59142 == env59143) = true)

theorem identity59143 : scanCanonicalize (H12AffineFastState.compose env59143 (packedSelected [1,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound59143 : packedSelected [1,5,7,8] rootPS < 2^1333 := by decide +kernel

def env59144 : List Nat := [2,4,8,1,32,0,9,14,10,14,1,1,14,0,13,40,7,33,15,12,0,10,7,41,14,6,33,6,1,45,3,1,14,1,0,10]

theorem envBound59144 : H12AffineFastState.Bounded env59144 := by
  intro p hp
  have h : env59144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59143_59144 : H12AffineEnvironment.transform 7 14 env59143 = env59144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env59143 == env59144) = true)

theorem identity59144 : scanCanonicalize (H12AffineFastState.compose env59144 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound59144 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env59145 : List Nat := [2,4,8,1,13,0,9,14,10,14,1,1,14,0,13,5,7,12,15,12,0,10,7,4,14,6,12,6,1,0,3,1,14,1,0,10]

theorem envBound59145 : H12AffineFastState.Bounded env59145 := by
  intro p hp
  have h : env59145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59144_59145 : H12AffineEnvironment.transform 4 13 env59144 = env59145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env59144 == env59145) = true)

theorem identity59145 : scanCanonicalize (H12AffineFastState.compose env59145 (packedSelected [0,2] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound59145 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env59146 : List Nat := [2,4,5,1,0,0,4,3,7,3,1,1,3,0,0,5,7,1,2,1,0,7,7,4,3,6,1,6,1,0,3,1,3,1,0,7]

theorem envBound59146 : H12AffineFastState.Bounded env59146 := by
  intro p hp
  have h : env59146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59145_59146 : H12AffineEnvironment.transform 2 5 env59145 = env59146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env59145 == env59146) = true)

def env59147 : List Nat := [2,4,8,1,32,64,128,256,324,1024,2048,1,1025,1280,12,1063,1097,1191,321,13,0,461,265,1062,456,1032,303,1032,1281,3436,1036,1281,256,1280,1344,1028]

theorem envBound59147 : H12AffineFastState.Bounded env59147 := by
  intro p hp
  have h : env59147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59138_59147 : H12AffineEnvironment.transform 12 1025 env59138 = env59147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1025 env59138 == env59147) = true)

theorem identity59147 : scanCanonicalize (H12AffineFastState.compose env59147 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound59147 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env59148 : List Nat := [2,4,8,1,32,12,128,256,264,1024,2048,1,1025,1280,12,1063,1029,1191,269,13,0,385,265,1062,388,1032,303,1032,1281,3360,1036,1281,256,1280,1292,1028]

theorem envBound59148 : H12AffineFastState.Bounded env59148 := by
  intro p hp
  have h : env59148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59147_59148 : H12AffineEnvironment.transform 5 12 env59147 = env59148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env59147 == env59148) = true)

theorem identity59148 : scanCanonicalize (H12AffineFastState.compose env59148 (packedSelected [5,8,10,15,17,21] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound59148 : packedSelected [5,8,10,15,17,21] rootPS < 2^1333 := by decide +kernel

def env59149 : List Nat := [2,4,8,1,32,12,128,256,264,37,2048,1,36,293,12,2,32,130,269,13,0,385,265,3,388,45,303,45,292,2309,41,292,256,293,297,33]

theorem envBound59149 : H12AffineFastState.Bounded env59149 := by
  intro p hp
  have h : env59149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59148_59149 : H12AffineEnvironment.transform 9 37 env59148 = env59149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env59148 == env59149) = true)

theorem identity59149 : scanCanonicalize (H12AffineFastState.compose env59149 (packedSelected [1,4,9,10,11,12,13,15,16,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 397) := by decide +kernel

theorem selectedBound59149 : packedSelected [1,4,9,10,11,12,13,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env59150 : List Nat := [2,4,8,1,32,12,128,256,264,37,397,1,36,293,12,2,32,130,269,13,0,385,265,3,388,45,303,45,292,136,41,292,256,293,297,33]

theorem envBound59150 : H12AffineFastState.Bounded env59150 := by
  intro p hp
  have h : env59150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59149_59150 : H12AffineEnvironment.transform 10 397 env59149 = env59150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 397 env59149 == env59150) = true)

def env59151 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74863,65665,4416,13340,4097,476,74046,69649,13768,78895,4414,74815,1296,81227,8205,1281,256,65831,1344,5953]

theorem envBound59151 : H12AffineFastState.Bounded env59151 := by
  intro p hp
  have h : env59151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59077_59151 : H12AffineEnvironment.transform 17 65665 env59077 = env59151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env59077 == env59151) = true)

theorem identity59151 : scanCanonicalize (H12AffineFastState.compose env59151 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound59151 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env59152 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,80,12636,65536,74030,65665,4416,12637,4097,476,74046,69649,12425,78190,4414,74110,81,79882,8205,64,256,65831,1,4608]

theorem envBound59152 : H12AffineFastState.Bounded env59152 := by
  intro p hp
  have h : env59152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59151_59152 : H12AffineEnvironment.transform 9 321 env59151 = env59152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env59151 == env59152) = true)

def env59153 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,4096,8192,80,12636,65536,74030,65665,4416,12637,4097,476,74046,69649,12425,78190,4414,74110,81,79882,8205,64,256,65831,1,4436]

theorem envBound59153 : H12AffineFastState.Bounded env59153 := by
  intro p hp
  have h : env59153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59152_59153 : H12AffineEnvironment.transform 8 340 env59152 = env59153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env59152 == env59153) = true)

def env59154 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,16,8192,80,8524,65536,74030,65665,336,8525,17,476,74046,65537,8345,74110,302,74110,81,75802,8205,64,256,65831,1,324]

theorem envBound59154 : H12AffineFastState.Bounded env59154 := by
  intro p hp
  have h : env59154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59153_59154 : H12AffineEnvironment.transform 11 16 env59153 = env59154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env59153 == env59154) = true)

theorem identity59154 : scanCanonicalize (H12AffineFastState.compose env59154 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 24) := by decide +kernel

theorem selectedBound59154 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env59155 : List Nat := [2,4,8,16,32,64,128,24,76,89,2048,16,8192,80,8276,65536,73782,65665,72,8277,17,196,73766,65537,8345,73830,54,73830,81,75802,8205,64,24,65599,1,92]

theorem envBound59155 : H12AffineFastState.Bounded env59155 := by
  intro p hp
  have h : env59155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59154_59155 : H12AffineEnvironment.transform 7 24 env59154 = env59155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 24 env59154 == env59155) = true)

def env59156 : List Nat := [2,4,8,0,32,64,128,8,76,73,2048,0,8192,64,8260,65536,73766,65665,72,8261,1,196,73766,65537,8329,73830,38,73830,65,75786,8205,64,8,65583,1,76]

theorem envBound59156 : H12AffineFastState.Bounded env59156 := by
  intro p hp
  have h : env59156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59155_59156 : H12AffineEnvironment.transform 3 0 env59155 = env59156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env59155 == env59156) = true)

theorem identity59156 : scanCanonicalize (H12AffineFastState.compose env59156 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 68) := by decide +kernel

theorem selectedBound59156 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59157 : List Nat := [2,4,8,0,32,64,128,8,76,73,2048,0,68,64,0,65536,65634,65665,72,1,1,196,65634,65537,205,65570,38,65570,65,67662,73,64,8,65583,1,76]

theorem envBound59157 : H12AffineFastState.Bounded env59157 := by
  intro p hp
  have h : env59157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59156_59157 : H12AffineEnvironment.transform 12 68 env59156 = env59157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 68 env59156 == env59157) = true)

theorem identity59157 : scanCanonicalize (H12AffineFastState.compose env59157 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound59157 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env59158 : List Nat := [2,4,8,0,32,1,128,8,13,8,2048,0,5,1,0,65536,65571,65665,9,1,1,133,65571,65537,140,65570,38,65570,0,67599,8,1,8,65583,1,13]

theorem envBound59158 : H12AffineFastState.Bounded env59158 := by
  intro p hp
  have h : env59158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59157_59158 : H12AffineEnvironment.transform 5 1 env59157 = env59158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env59157 == env59158) = true)

theorem identity59158 : scanCanonicalize (H12AffineFastState.compose env59158 (packedSelected [1,2,3,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound59158 : packedSelected [1,2,3,8,10] rootPS < 2^1333 := by decide +kernel

def env59159 : List Nat := [2,4,8,0,32,1,128,8,13,8,137,0,5,1,0,65536,65571,65665,9,1,1,133,65571,65537,140,65570,38,65570,0,65670,8,1,8,65583,1,13]

theorem envBound59159 : H12AffineFastState.Bounded env59159 := by
  intro p hp
  have h : env59159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59158_59159 : H12AffineEnvironment.transform 10 137 env59158 = env59159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env59158 == env59159) = true)

theorem identity59159 : scanCanonicalize (H12AffineFastState.compose env59159 (packedSelected [1,2,4,11] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound59159 : packedSelected [1,2,4,11] rootPS < 2^1333 := by decide +kernel

def env59160 : List Nat := [2,4,8,0,6,1,128,8,13,8,137,0,5,1,0,65536,65541,65665,9,1,1,133,65541,65537,140,65540,0,65540,0,65670,8,1,8,65545,1,13]

theorem envBound59160 : H12AffineFastState.Bounded env59160 := by
  intro p hp
  have h : env59160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59159_59160 : H12AffineEnvironment.transform 4 6 env59159 = env59160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env59159 == env59160) = true)

theorem identity59160 : scanCanonicalize (H12AffineFastState.compose env59160 (packedSelected [0,1,2,3,4,5] rootPS)) = affineNative (2^(15+1) ^^^ 140) := by decide +kernel

theorem selectedBound59160 : packedSelected [0,1,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env59161 : List Nat := [2,4,8,0,6,1,128,8,13,8,137,0,5,1,0,140,137,13,9,1,1,133,137,141,140,136,0,136,0,10,8,1,8,133,1,13]

theorem envBound59161 : H12AffineFastState.Bounded env59161 := by
  intro p hp
  have h : env59161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59160_59161 : H12AffineEnvironment.transform 15 140 env59160 = env59161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 140 env59160 == env59161) = true)

theorem identity59161 : scanCanonicalize (H12AffineFastState.compose env59161 (packedSelected [1,2] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound59161 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env59162 : List Nat := [2,4,8,0,6,1,14,8,13,8,7,0,5,1,0,2,7,13,9,1,1,11,7,3,2,6,0,6,0,10,8,1,8,11,1,13]

theorem envBound59162 : H12AffineFastState.Bounded env59162 := by
  intro p hp
  have h : env59162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59161_59162 : H12AffineEnvironment.transform 6 14 env59161 = env59162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env59161 == env59162) = true)

theorem identity59162 : scanCanonicalize (H12AffineFastState.compose env59162 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound59162 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59163 : List Nat := [2,4,2,0,6,1,4,2,7,2,7,0,5,1,0,2,7,7,3,1,1,1,7,3,2,6,0,6,0,0,2,1,2,1,1,7]

theorem envBound59163 : H12AffineFastState.Bounded env59163 := by
  intro p hp
  have h : env59163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59162_59163 : H12AffineEnvironment.transform 2 2 env59162 = env59163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env59162 == env59163) = true)

def env59164 : List Nat := [2,4,8,1,32,64,128,9,76,72,2048,1,8192,65,8261,65536,73767,65665,72,8260,0,196,73766,65537,8328,73830,39,73830,64,75787,8205,64,9,65582,1,77]

theorem envBound59164 : H12AffineFastState.Bounded env59164 := by
  intro p hp
  have h : env59164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59155_59164 : H12AffineEnvironment.transform 3 1 env59155 = env59164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env59155 == env59164) = true)

theorem identity59164 : scanCanonicalize (H12AffineFastState.compose env59164 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound59164 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59165 : List Nat := [2,4,8,1,32,64,128,9,76,72,2048,1,8192,65,8261,35,8196,162,72,8260,0,196,8197,34,8328,8261,39,8261,64,10280,8205,64,9,13,1,77]

theorem envBound59165 : H12AffineFastState.Bounded env59165 := by
  intro p hp
  have h : env59165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59164_59165 : H12AffineEnvironment.transform 15 35 env59164 = env59165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env59164 == env59165) = true)

theorem identity59165 : scanCanonicalize (H12AffineFastState.compose env59165 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound59165 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59166 : List Nat := [2,4,4,1,32,64,128,5,64,68,2048,1,8192,65,8261,35,8196,162,68,8260,0,196,8197,34,8324,8261,39,8261,64,10276,8193,64,5,1,1,65]

theorem envBound59166 : H12AffineFastState.Bounded env59166 := by
  intro p hp
  have h : env59166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59165_59166 : H12AffineEnvironment.transform 2 4 env59165 = env59166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env59165 == env59166) = true)

theorem identity59166 : scanCanonicalize (H12AffineFastState.compose env59166 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 5) := by decide +kernel

theorem selectedBound59166 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env59167 : List Nat := [2,4,4,1,32,64,128,5,64,68,2048,1,5,65,64,35,1,162,68,65,0,196,0,34,129,64,39,64,64,2081,4,64,5,1,1,65]

theorem envBound59167 : H12AffineFastState.Bounded env59167 := by
  intro p hp
  have h : env59167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59166_59167 : H12AffineEnvironment.transform 12 5 env59166 = env59167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5 env59166 == env59167) = true)

theorem identity59167 : scanCanonicalize (H12AffineFastState.compose env59167 (packedSelected [2,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 70) := by decide +kernel

theorem selectedBound59167 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env59168 : List Nat := [2,4,4,1,32,64,128,5,64,68,70,1,5,65,64,35,1,162,68,65,0,196,0,34,129,64,39,64,64,103,4,64,5,1,1,65]

theorem envBound59168 : H12AffineFastState.Bounded env59168 := by
  intro p hp
  have h : env59168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59167_59168 : H12AffineEnvironment.transform 10 70 env59167 = env59168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 70 env59167 == env59168) = true)

theorem identity59168 : scanCanonicalize (H12AffineFastState.compose env59168 (packedSelected [1,2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound59168 : packedSelected [1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env59169 : List Nat := [2,4,4,1,0,64,128,5,64,68,70,1,5,65,64,3,1,130,68,65,0,196,0,2,129,64,7,64,64,71,4,64,5,1,1,65]

theorem envBound59169 : H12AffineFastState.Bounded env59169 := by
  intro p hp
  have h : env59169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59168_59169 : H12AffineEnvironment.transform 4 0 env59168 = env59169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env59168 == env59169) = true)

theorem identity59169 : scanCanonicalize (H12AffineFastState.compose env59169 (packedSelected [0,1,3] rootPS)) = affineNative (2^(6+1) ^^^ 70) := by decide +kernel

theorem selectedBound59169 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env59170 : List Nat := [2,4,4,1,0,64,70,5,64,68,70,1,5,65,64,3,1,68,68,65,0,2,0,2,71,64,7,64,64,71,4,64,5,1,1,65]

theorem envBound59170 : H12AffineFastState.Bounded env59170 := by
  intro p hp
  have h : env59170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59169_59170 : H12AffineEnvironment.transform 6 70 env59169 = env59170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 70 env59169 == env59170) = true)

theorem identity59170 : scanCanonicalize (H12AffineFastState.compose env59170 (packedSelected [0,1,4,7] rootPS)) = affineNative (2^(5+1) ^^^ 5) := by decide +kernel

theorem selectedBound59170 : packedSelected [0,1,4,7] rootPS < 2^1333 := by decide +kernel

def env59171 : List Nat := [2,4,4,1,0,5,3,5,5,1,3,1,5,4,5,3,1,1,1,4,0,2,0,2,2,5,7,5,5,2,4,5,5,1,1,4]

theorem envBound59171 : H12AffineFastState.Bounded env59171 := by
  intro p hp
  have h : env59171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59170_59171 : H12AffineEnvironment.transform 5 5 env59170 = env59171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 5 env59170 == env59171) = true)

theorem identity59171 : scanCanonicalize (H12AffineFastState.compose env59171 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound59171 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env59172 : List Nat := [1,4,4,1,0,5,0,5,5,1,0,1,5,4,5,0,1,1,1,4,0,1,0,1,1,5,4,5,5,1,4,5,5,1,1,4]

theorem envBound59172 : H12AffineFastState.Bounded env59172 := by
  intro p hp
  have h : env59172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59171_59172 : H12AffineEnvironment.transform 0 1 env59171 = env59172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env59171 == env59172) = true)

theorem identity59172 : scanCanonicalize (H12AffineFastState.compose env59172 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound59172 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env59173 : List Nat := [1,0,0,1,0,1,0,1,1,1,0,1,1,0,1,0,1,1,1,0,0,1,0,1,1,1,0,1,1,1,0,1,1,1,1,0]

theorem envBound59173 : H12AffineFastState.Bounded env59173 := by
  intro p hp
  have h : env59173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59172_59173 : H12AffineEnvironment.transform 1 0 env59172 = env59173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env59172 == env59173) = true)

def env59174 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,17,8192,80,8525,65536,74030,65665,337,8524,16,476,74046,65536,8344,74111,303,74110,81,75803,8205,64,256,65831,1,325]

theorem envBound59174 : H12AffineFastState.Bounded env59174 := by
  intro p hp
  have h : env59174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59153_59174 : H12AffineEnvironment.transform 11 17 env59153 = env59174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env59153 == env59174) = true)

theorem identity59174 : scanCanonicalize (H12AffineFastState.compose env59174 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 337) := by decide +kernel

theorem selectedBound59174 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env59175 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,17,337,80,28,65536,65663,65665,337,29,16,476,65647,65536,457,65582,303,65583,81,67914,348,64,256,65831,1,325]

theorem envBound59175 : H12AffineFastState.Bounded env59175 := by
  intro p hp
  have h : env59175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59174_59175 : H12AffineEnvironment.transform 12 337 env59174 = env59175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 337 env59174 == env59175) = true)

def env59176 : List Nat := [2,4,8,0,32,64,128,256,324,321,2048,1,321,64,12,65536,65647,65665,321,13,0,460,65647,65536,457,65582,303,65583,65,67914,332,64,256,65831,1,325]

theorem envBound59176 : H12AffineFastState.Bounded env59176 := by
  intro p hp
  have h : env59176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59175_59176 : H12AffineEnvironment.transform 3 0 env59175 = env59176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env59175 == env59176) = true)

theorem identity59176 : scanCanonicalize (H12AffineFastState.compose env59176 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound59176 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59177 : List Nat := [2,4,8,0,32,64,128,256,324,321,2048,1,321,64,12,35,76,162,321,13,0,460,76,35,457,13,303,12,65,2409,332,64,256,260,1,325]

theorem envBound59177 : H12AffineFastState.Bounded env59177 := by
  intro p hp
  have h : env59177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59176_59177 : H12AffineEnvironment.transform 15 35 env59176 = env59177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env59176 == env59177) = true)

theorem identity59177 : scanCanonicalize (H12AffineFastState.compose env59177 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound59177 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59178 : List Nat := [2,4,8,0,32,64,128,4,64,69,2048,1,69,64,12,35,76,162,69,13,0,200,76,35,205,13,43,12,65,2157,72,64,4,0,1,65]

theorem envBound59178 : H12AffineFastState.Bounded env59178 := by
  intro p hp
  have h : env59178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59177_59178 : H12AffineEnvironment.transform 7 4 env59177 = env59178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env59177 == env59178) = true)

theorem identity59178 : scanCanonicalize (H12AffineFastState.compose env59178 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound59178 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env59179 : List Nat := [2,4,8,0,32,12,128,4,12,9,2048,1,9,12,12,35,0,162,9,13,0,132,0,35,129,13,43,12,13,2081,4,12,4,0,1,13]

theorem envBound59179 : H12AffineFastState.Bounded env59179 := by
  intro p hp
  have h : env59179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59178_59179 : H12AffineEnvironment.transform 5 12 env59178 = env59179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env59178 == env59179) = true)

theorem identity59179 : scanCanonicalize (H12AffineFastState.compose env59179 (packedSelected [2,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 47) := by decide +kernel

theorem selectedBound59179 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env59180 : List Nat := [2,4,8,0,32,12,47,4,12,9,2048,1,9,12,12,35,0,13,9,13,0,43,0,35,46,13,43,12,13,2081,4,12,4,0,1,13]

theorem envBound59180 : H12AffineFastState.Bounded env59180 := by
  intro p hp
  have h : env59180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59179_59180 : H12AffineEnvironment.transform 6 47 env59179 = env59180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 47 env59179 == env59180) = true)

theorem identity59180 : scanCanonicalize (H12AffineFastState.compose env59180 (packedSelected [1,2] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound59180 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env59181 : List Nat := [2,4,8,0,32,12,47,4,12,9,32,1,9,12,12,35,0,13,9,13,0,43,0,35,46,13,43,12,13,1,4,12,4,0,1,13]

theorem envBound59181 : H12AffineFastState.Bounded env59181 := by
  intro p hp
  have h : env59181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59180_59181 : H12AffineEnvironment.transform 10 32 env59180 = env59181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env59180 == env59181) = true)

theorem identity59181 : scanCanonicalize (H12AffineFastState.compose env59181 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound59181 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env59182 : List Nat := [2,4,8,0,13,12,2,4,12,9,13,1,9,12,12,14,0,13,9,13,0,6,0,14,3,13,6,12,13,1,4,12,4,0,1,13]

theorem envBound59182 : H12AffineFastState.Bounded env59182 := by
  intro p hp
  have h : env59182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59181_59182 : H12AffineEnvironment.transform 4 13 env59181 = env59182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env59181 == env59182) = true)

theorem identity59182 : scanCanonicalize (H12AffineFastState.compose env59182 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound59182 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env59183 : List Nat := [2,3,8,0,10,11,2,3,11,9,10,1,9,11,11,9,0,10,9,10,0,1,0,9,3,10,1,11,10,1,3,11,3,0,1,10]

theorem envBound59183 : H12AffineFastState.Bounded env59183 := by
  intro p hp
  have h : env59183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59182_59183 : H12AffineEnvironment.transform 1 3 env59182 = env59183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env59182 == env59183) = true)

theorem identity59183 : scanCanonicalize (H12AffineFastState.compose env59183 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound59183 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59184 : List Nat := [1,0,8,0,9,8,1,0,8,9,9,1,9,8,8,9,0,9,9,9,0,1,0,9,0,9,1,8,9,1,0,8,0,0,1,9]

theorem envBound59184 : H12AffineFastState.Bounded env59184 := by
  intro p hp
  have h : env59184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59183_59184 : H12AffineEnvironment.transform 0 1 env59183 = env59184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env59183 == env59184) = true)

theorem identity59184 : scanCanonicalize (H12AffineFastState.compose env59184 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound59184 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env59185 : List Nat := [1,0,1,0,0,1,1,0,1,0,0,1,0,1,1,0,0,0,0,0,0,1,0,0,0,0,1,1,0,1,0,1,0,0,1,0]

theorem envBound59185 : H12AffineFastState.Bounded env59185 := by
  intro p hp
  have h : env59185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59184_59185 : H12AffineEnvironment.transform 2 1 env59184 = env59185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env59184 == env59185) = true)

def env59186 : List Nat := [2,4,8,1,32,64,128,256,325,321,2048,0,320,65,13,65536,65646,65665,320,12,1,461,65647,65536,457,65582,303,65583,64,67914,333,64,256,65831,1,325]

theorem envBound59186 : H12AffineFastState.Bounded env59186 := by
  intro p hp
  have h : env59186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59175_59186 : H12AffineEnvironment.transform 3 1 env59175 = env59186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env59175 == env59186) = true)

theorem identity59186 : scanCanonicalize (H12AffineFastState.compose env59186 (packedSelected [4,9,16] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound59186 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59187 : List Nat := [2,4,5,1,32,64,128,256,325,321,2048,0,320,65,0,65536,65635,65665,320,1,1,448,65634,65536,452,65571,290,65570,64,67911,320,64,256,65831,1,325]

theorem envBound59187 : H12AffineFastState.Bounded env59187 := by
  intro p hp
  have h : env59187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59186_59187 : H12AffineEnvironment.transform 2 5 env59186 = env59187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env59186 == env59187) = true)

theorem identity59187 : scanCanonicalize (H12AffineFastState.compose env59187 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound59187 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env59188 : List Nat := [2,4,5,1,32,0,128,256,261,257,2048,0,256,1,0,65536,65571,65665,256,1,1,384,65570,65536,388,65571,290,65570,0,67847,256,0,256,65831,1,261]

theorem envBound59188 : H12AffineFastState.Bounded env59188 := by
  intro p hp
  have h : env59188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59187_59188 : H12AffineEnvironment.transform 5 0 env59187 = env59188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env59187 == env59188) = true)

theorem identity59188 : scanCanonicalize (H12AffineFastState.compose env59188 (packedSelected [1,2,3,8,10] rootPS)) = affineNative (2^(15+1) ^^^ 2215) := by decide +kernel

theorem selectedBound59188 : packedSelected [1,2,3,8,10] rootPS < 2^1333 := by decide +kernel

def env59189 : List Nat := [2,4,5,1,32,0,128,256,261,257,2048,0,256,1,0,2215,2180,2086,256,1,1,384,2181,2215,388,2180,290,2181,0,416,256,0,256,2432,1,261]

theorem envBound59189 : H12AffineFastState.Bounded env59189 := by
  intro p hp
  have h : env59189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59188_59189 : H12AffineEnvironment.transform 15 2215 env59188 = env59189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2215 env59188 == env59189) = true)

theorem identity59189 : scanCanonicalize (H12AffineFastState.compose env59189 (packedSelected [1,3,4,8,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound59189 : packedSelected [1,3,4,8,11,12] rootPS < 2^1333 := by decide +kernel

def env59190 : List Nat := [2,4,5,1,32,0,128,256,261,257,32,0,256,1,0,135,164,6,256,1,1,384,165,135,388,164,290,165,0,416,256,0,256,416,1,261]

theorem envBound59190 : H12AffineFastState.Bounded env59190 := by
  intro p hp
  have h : env59190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59189_59190 : H12AffineEnvironment.transform 10 32 env59189 = env59190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env59189 == env59190) = true)

theorem identity59190 : scanCanonicalize (H12AffineFastState.compose env59190 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 3) := by decide +kernel

theorem selectedBound59190 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env59191 : List Nat := [2,4,5,1,32,0,128,3,6,2,32,0,3,1,0,135,164,6,3,1,1,131,165,135,135,164,33,165,0,163,3,0,3,163,1,6]

theorem envBound59191 : H12AffineFastState.Bounded env59191 := by
  intro p hp
  have h : env59191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59190_59191 : H12AffineEnvironment.transform 7 3 env59190 = env59191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 3 env59190 == env59191) = true)

theorem identity59191 : scanCanonicalize (H12AffineFastState.compose env59191 (packedSelected [1,4] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound59191 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env59192 : List Nat := [2,4,5,1,32,0,34,3,6,2,32,0,3,1,0,37,6,6,3,1,1,33,7,37,37,6,33,7,0,1,3,0,3,1,1,6]

theorem envBound59192 : H12AffineFastState.Bounded env59192 := by
  intro p hp
  have h : env59192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59191_59192 : H12AffineEnvironment.transform 6 34 env59191 = env59192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env59191 == env59192) = true)

theorem identity59192 : scanCanonicalize (H12AffineFastState.compose env59192 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound59192 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59193 : List Nat := [2,2,3,1,32,0,34,3,0,2,32,0,3,1,0,35,0,0,3,1,1,33,1,35,35,0,33,1,0,1,3,0,3,1,1,0]

theorem envBound59193 : H12AffineFastState.Bounded env59193 := by
  intro p hp
  have h : env59193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59192_59193 : H12AffineEnvironment.transform 1 2 env59192 = env59193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env59192 == env59193) = true)

theorem identity59193 : scanCanonicalize (H12AffineFastState.compose env59193 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound59193 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env59194 : List Nat := [2,2,3,1,0,0,2,3,0,2,0,0,3,1,0,3,0,0,3,1,1,1,1,3,3,0,1,1,0,1,3,0,3,1,1,0]

theorem envBound59194 : H12AffineFastState.Bounded env59194 := by
  intro p hp
  have h : env59194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59193_59194 : H12AffineEnvironment.transform 4 0 env59193 = env59194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env59193 == env59194) = true)

def env59195 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,4096,8192,80,12636,65536,74030,65665,4416,12637,4097,476,74046,69649,12425,78190,4414,74110,81,79882,8205,64,256,65831,1,4437]

theorem envBound59195 : H12AffineFastState.Bounded env59195 := by
  intro p hp
  have h : env59195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59152_59195 : H12AffineEnvironment.transform 8 341 env59152 = env59195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env59152 == env59195) = true)

def env59196 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,16,8192,80,8524,65536,74030,65665,336,8525,17,476,74046,65537,8345,74110,302,74110,81,75802,8205,64,256,65831,1,325]

theorem envBound59196 : H12AffineFastState.Bounded env59196 := by
  intro p hp
  have h : env59196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59195_59196 : H12AffineEnvironment.transform 11 16 env59195 = env59196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env59195 == env59196) = true)

theorem identity59196 : scanCanonicalize (H12AffineFastState.compose env59196 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8247) := by decide +kernel

theorem selectedBound59196 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env59197 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,16,8192,80,8524,8247,281,8374,336,8525,17,476,265,8246,8345,329,302,329,81,2093,8205,64,256,8464,1,325]

theorem envBound59197 : H12AffineFastState.Bounded env59197 := by
  intro p hp
  have h : env59197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59196_59197 : H12AffineEnvironment.transform 15 8247 env59196 = env59197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8247 env59196 == env59197) = true)

def env59198 : List Nat := [2,4,8,0,32,64,128,256,325,321,2048,0,8192,64,8524,8231,265,8358,320,8525,1,460,265,8230,8329,329,302,329,65,2093,8205,64,256,8448,1,325]

theorem envBound59198 : H12AffineFastState.Bounded env59198 := by
  intro p hp
  have h : env59198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59197_59198 : H12AffineEnvironment.transform 3 0 env59197 = env59198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env59197 == env59198) = true)

theorem identity59198 : scanCanonicalize (H12AffineFastState.compose env59198 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 332) := by decide +kernel

theorem selectedBound59198 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59199 : List Nat := [2,4,8,0,32,64,128,256,325,321,2048,0,332,64,0,363,265,490,320,1,1,460,265,362,453,329,302,329,65,2093,321,64,256,76,1,325]

theorem envBound59199 : H12AffineFastState.Bounded env59199 := by
  intro p hp
  have h : env59199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59198_59199 : H12AffineEnvironment.transform 12 332 env59198 = env59199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 332 env59198 == env59199) = true)

theorem identity59199 : scanCanonicalize (H12AffineFastState.compose env59199 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound59199 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env59200 : List Nat := [2,4,8,0,32,1,128,256,260,256,2048,0,269,1,0,298,265,427,257,1,1,397,265,299,388,264,302,264,0,2093,256,1,256,13,1,260]

theorem envBound59200 : H12AffineFastState.Bounded env59200 := by
  intro p hp
  have h : env59200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59199_59200 : H12AffineEnvironment.transform 5 1 env59199 = env59200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env59199 == env59200) = true)

theorem identity59200 : scanCanonicalize (H12AffineFastState.compose env59200 (packedSelected [1,2,3,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 384) := by decide +kernel

theorem selectedBound59200 : packedSelected [1,2,3,8,10] rootPS < 2^1333 := by decide +kernel

def env59201 : List Nat := [2,4,8,0,32,1,128,256,260,256,384,0,269,1,0,298,265,427,257,1,1,397,265,299,388,264,302,264,0,429,256,1,256,13,1,260]

theorem envBound59201 : H12AffineFastState.Bounded env59201 := by
  intro p hp
  have h : env59201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59200_59201 : H12AffineEnvironment.transform 10 384 env59200 = env59201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 384 env59200 == env59201) = true)

theorem identity59201 : scanCanonicalize (H12AffineFastState.compose env59201 (packedSelected [1,3,4,8,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 161) := by decide +kernel

theorem selectedBound59201 : packedSelected [1,3,4,8,11,12] rootPS < 2^1333 := by decide +kernel

def env59202 : List Nat := [2,4,8,0,32,1,128,161,165,161,33,0,172,1,0,139,168,10,160,1,1,44,168,138,37,169,143,169,0,12,161,1,161,13,1,165]

theorem envBound59202 : H12AffineFastState.Bounded env59202 := by
  intro p hp
  have h : env59202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59201_59202 : H12AffineEnvironment.transform 7 161 env59201 = env59202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 161 env59201 == env59202) = true)

theorem identity59202 : scanCanonicalize (H12AffineFastState.compose env59202 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 47) := by decide +kernel

theorem selectedBound59202 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env59203 : List Nat := [2,4,8,0,32,1,47,14,10,14,33,0,3,1,0,36,7,10,15,1,1,44,7,37,37,6,32,6,0,12,14,1,14,13,1,10]

theorem envBound59203 : H12AffineFastState.Bounded env59203 := by
  intro p hp
  have h : env59203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59202_59203 : H12AffineEnvironment.transform 6 47 env59202 = env59203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 47 env59202 == env59203) = true)

theorem identity59203 : scanCanonicalize (H12AffineFastState.compose env59203 (packedSelected [1,4] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound59203 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env59204 : List Nat := [2,4,5,0,32,1,34,3,7,3,33,0,3,1,0,36,7,7,2,1,1,33,7,37,37,6,32,6,0,1,3,1,3,0,1,7]

theorem envBound59204 : H12AffineFastState.Bounded env59204 := by
  intro p hp
  have h : env59204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59203_59204 : H12AffineEnvironment.transform 2 5 env59203 = env59204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env59203 == env59204) = true)

theorem identity59204 : scanCanonicalize (H12AffineFastState.compose env59204 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound59204 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59205 : List Nat := [2,3,2,0,32,1,34,3,0,3,33,0,3,1,0,35,0,0,2,1,1,33,0,34,34,1,32,1,0,1,3,1,3,0,1,0]

theorem envBound59205 : H12AffineFastState.Bounded env59205 := by
  intro p hp
  have h : env59205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59204_59205 : H12AffineEnvironment.transform 1 3 env59204 = env59205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env59204 == env59205) = true)

theorem identity59205 : scanCanonicalize (H12AffineFastState.compose env59205 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound59205 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env59206 : List Nat := [2,3,2,0,1,1,3,3,0,3,0,0,3,1,0,2,0,0,2,1,1,0,0,3,3,1,1,1,0,1,3,1,3,0,1,0]

theorem envBound59206 : H12AffineFastState.Bounded env59206 := by
  intro p hp
  have h : env59206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59205_59206 : H12AffineEnvironment.transform 4 1 env59205 = env59206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env59205 == env59206) = true)

def env59207 : List Nat := [2,4,8,1,32,64,128,256,324,321,2048,1,8192,65,8524,8230,264,8359,321,8525,0,461,265,8231,8328,329,302,329,64,2093,8205,64,256,8449,1,325]

theorem envBound59207 : H12AffineFastState.Bounded env59207 := by
  intro p hp
  have h : env59207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59197_59207 : H12AffineEnvironment.transform 3 1 env59197 = env59207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env59197 == env59207) = true)

theorem identity59207 : scanCanonicalize (H12AffineFastState.compose env59207 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 5) := by decide +kernel

theorem selectedBound59207 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59208 : List Nat := [2,4,8,1,32,64,128,256,324,321,2048,1,5,65,329,35,264,162,321,328,0,461,265,34,141,329,302,329,64,2093,8,64,256,260,1,325]

theorem envBound59208 : H12AffineFastState.Bounded env59208 := by
  intro p hp
  have h : env59208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59207_59208 : H12AffineEnvironment.transform 12 5 env59207 = env59208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5 env59207 == env59208) = true)

theorem identity59208 : scanCanonicalize (H12AffineFastState.compose env59208 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound59208 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59209 : List Nat := [2,4,8,1,32,64,128,5,65,68,2048,1,5,65,76,35,13,162,68,77,0,200,12,34,141,76,43,76,64,2093,8,64,5,1,1,64]

theorem envBound59209 : H12AffineFastState.Bounded env59209 := by
  intro p hp
  have h : env59209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59208_59209 : H12AffineEnvironment.transform 7 5 env59208 = env59209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env59208 == env59209) = true)

theorem identity59209 : scanCanonicalize (H12AffineFastState.compose env59209 (packedSelected [3,5,10] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound59209 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env59210 : List Nat := [2,4,4,1,32,64,128,5,65,68,2048,1,5,65,64,35,1,162,68,65,0,196,0,34,129,64,39,64,64,2081,4,64,5,1,1,64]

theorem envBound59210 : H12AffineFastState.Bounded env59210 := by
  intro p hp
  have h : env59210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59209_59210 : H12AffineEnvironment.transform 2 4 env59209 = env59210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env59209 == env59210) = true)

theorem identity59210 : scanCanonicalize (H12AffineFastState.compose env59210 (packedSelected [2,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 70) := by decide +kernel

theorem selectedBound59210 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env59211 : List Nat := [2,4,4,1,32,64,128,5,65,68,70,1,5,65,64,35,1,162,68,65,0,196,0,34,129,64,39,64,64,103,4,64,5,1,1,64]

theorem envBound59211 : H12AffineFastState.Bounded env59211 := by
  intro p hp
  have h : env59211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59210_59211 : H12AffineEnvironment.transform 10 70 env59210 = env59211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 70 env59210 == env59211) = true)

theorem identity59211 : scanCanonicalize (H12AffineFastState.compose env59211 (packedSelected [1,2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound59211 : packedSelected [1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env59212 : List Nat := [2,4,4,1,1,64,128,5,65,68,70,1,5,65,64,2,1,131,68,65,0,196,0,3,129,64,6,64,64,70,4,64,5,1,1,64]

theorem envBound59212 : H12AffineFastState.Bounded env59212 := by
  intro p hp
  have h : env59212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59211_59212 : H12AffineEnvironment.transform 4 1 env59211 = env59212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env59211 == env59212) = true)

theorem identity59212 : scanCanonicalize (H12AffineFastState.compose env59212 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound59212 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59213 : List Nat := [2,4,4,1,1,1,128,5,0,5,7,1,5,0,1,2,1,131,5,0,0,133,0,3,129,1,6,1,1,7,4,1,5,1,1,1]

theorem envBound59213 : H12AffineFastState.Bounded env59213 := by
  intro p hp
  have h : env59213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59212_59213 : H12AffineEnvironment.transform 5 1 env59212 = env59213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env59212 == env59213) = true)

theorem identity59213 : scanCanonicalize (H12AffineFastState.compose env59213 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound59213 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59214 : List Nat := [0,4,4,1,1,1,128,5,0,5,5,1,5,0,1,0,1,129,5,0,0,133,0,1,129,1,4,1,1,5,4,1,5,1,1,1]

theorem envBound59214 : H12AffineFastState.Bounded env59214 := by
  intro p hp
  have h : env59214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59213_59214 : H12AffineEnvironment.transform 0 0 env59213 = env59214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env59213 == env59214) = true)

theorem identity59214 : scanCanonicalize (H12AffineFastState.compose env59214 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound59214 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env59215 : List Nat := [0,4,4,1,1,1,5,5,0,5,5,1,5,0,1,0,1,4,5,0,0,0,0,1,4,1,4,1,1,5,4,1,5,1,1,1]

theorem envBound59215 : H12AffineFastState.Bounded env59215 := by
  intro p hp
  have h : env59215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59214_59215 : H12AffineEnvironment.transform 6 5 env59214 = env59215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env59214 == env59215) = true)

theorem identity59215 : scanCanonicalize (H12AffineFastState.compose env59215 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound59215 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env59216 : List Nat := [0,1,1,1,1,1,0,0,0,0,0,1,0,0,1,0,1,1,0,0,0,0,0,1,1,1,1,1,1,0,1,1,0,1,1,1]

theorem envBound59216 : H12AffineFastState.Bounded env59216 := by
  intro p hp
  have h : env59216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59215_59216 : H12AffineEnvironment.transform 1 1 env59215 = env59216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env59215 == env59216) = true)

def env59217 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,17,8192,80,8525,65536,74030,65665,337,8524,16,476,74046,65536,8344,74111,303,74110,81,75803,8205,64,256,65831,1,324]

theorem envBound59217 : H12AffineFastState.Bounded env59217 := by
  intro p hp
  have h : env59217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59195_59217 : H12AffineEnvironment.transform 11 17 env59195 = env59217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env59195 == env59217) = true)

theorem identity59217 : scanCanonicalize (H12AffineFastState.compose env59217 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 126) := by decide +kernel

theorem selectedBound59217 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env59218 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,17,8192,80,8525,126,8528,255,337,8524,16,476,8512,126,8344,8449,303,8448,81,10341,8205,64,256,345,1,324]

theorem envBound59218 : H12AffineFastState.Bounded env59218 := by
  intro p hp
  have h : env59218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59217_59218 : H12AffineEnvironment.transform 15 126 env59217 = env59218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 126 env59217 == env59218) = true)

def env59219 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,17,72,80,261,126,280,255,337,260,16,476,264,126,208,329,303,328,81,2093,69,64,256,345,1,324]

theorem envBound59219 : H12AffineFastState.Bounded env59219 := by
  intro p hp
  have h : env59219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59218_59219 : H12AffineEnvironment.transform 12 72 env59218 = env59219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env59218 == env59219) = true)

theorem identity59219 : scanCanonicalize (H12AffineFastState.compose env59219 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound59219 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59220 : List Nat := [2,4,8,16,32,64,128,20,65,85,2048,17,72,80,17,126,12,255,69,16,16,200,28,126,208,93,59,92,81,2093,69,64,20,77,1,80]

theorem envBound59220 : H12AffineFastState.Bounded env59220 := by
  intro p hp
  have h : env59220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59219_59220 : H12AffineEnvironment.transform 7 20 env59219 = env59220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env59219 == env59220) = true)

theorem identity59220 : scanCanonicalize (H12AffineFastState.compose env59220 (packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 91) := by decide +kernel

theorem selectedBound59220 : packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS < 2^1333 := by decide +kernel

def env59221 : List Nat := [2,4,8,16,32,64,128,20,65,85,91,17,72,80,17,126,12,255,69,16,16,200,28,126,208,93,59,92,81,118,69,64,20,77,1,80]

theorem envBound59221 : H12AffineFastState.Bounded env59221 := by
  intro p hp
  have h : env59221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59220_59221 : H12AffineEnvironment.transform 10 91 env59220 = env59221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 91 env59220 == env59221) = true)

theorem identity59221 : scanCanonicalize (H12AffineFastState.compose env59221 (packedSelected [2,3,4,5,9,11,13,15,16,17,18] rootPS)) = affineNative (2^(5+1) ^^^ 23) := by decide +kernel

theorem selectedBound59221 : packedSelected [2,3,4,5,9,11,13,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env59222 : List Nat := [2,4,8,16,32,23,128,20,22,2,12,17,31,7,17,41,12,168,18,16,16,159,28,41,135,10,59,11,6,33,18,23,20,26,1,7]

theorem envBound59222 : H12AffineFastState.Bounded env59222 := by
  intro p hp
  have h : env59222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59221_59222 : H12AffineEnvironment.transform 5 23 env59221 = env59222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 23 env59221 == env59222) = true)

theorem identity59222 : scanCanonicalize (H12AffineFastState.compose env59222 (packedSelected [1,2,5,7,8,9,12] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound59222 : packedSelected [1,2,5,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env59223 : List Nat := [2,4,3,16,32,23,128,20,22,2,7,17,20,7,17,34,7,163,18,16,16,148,23,34,135,1,48,0,6,33,18,23,20,17,1,7]

theorem envBound59223 : H12AffineFastState.Bounded env59223 := by
  intro p hp
  have h : env59223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59222_59223 : H12AffineEnvironment.transform 2 3 env59222 = env59223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env59222 == env59223) = true)

theorem identity59223 : scanCanonicalize (H12AffineFastState.compose env59223 (packedSelected [2,5] rootPS)) = affineNative (2^(6+1) ^^^ 36) := by decide +kernel

theorem selectedBound59223 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env59224 : List Nat := [2,4,3,16,32,23,36,20,22,2,7,17,20,7,17,34,7,7,18,16,16,48,23,34,35,1,48,0,6,33,18,23,20,17,1,7]

theorem envBound59224 : H12AffineFastState.Bounded env59224 := by
  intro p hp
  have h : env59224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59223_59224 : H12AffineEnvironment.transform 6 36 env59223 = env59224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 36 env59223 == env59224) = true)

theorem identity59224 : scanCanonicalize (H12AffineFastState.compose env59224 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound59224 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env59225 : List Nat := [2,4,3,16,7,23,3,20,22,2,7,17,20,7,17,5,7,7,18,16,16,23,23,5,4,1,23,0,6,6,18,23,20,17,1,7]

theorem envBound59225 : H12AffineFastState.Bounded env59225 := by
  intro p hp
  have h : env59225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59224_59225 : H12AffineEnvironment.transform 4 7 env59224 = env59225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env59224 == env59225) = true)

def env59226 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,17,73,80,260,126,281,255,337,261,16,476,265,126,209,328,303,329,81,2092,68,64,256,345,1,324]

theorem envBound59226 : H12AffineFastState.Bounded env59226 := by
  intro p hp
  have h : env59226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59218_59226 : H12AffineEnvironment.transform 12 73 env59218 = env59226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env59218 == env59226) = true)

theorem identity59226 : scanCanonicalize (H12AffineFastState.compose env59226 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound59226 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59227 : List Nat := [2,4,8,16,32,64,128,4,81,69,2048,17,73,80,0,126,29,255,85,1,16,216,13,126,209,76,43,77,81,2092,68,64,4,93,1,64]

theorem envBound59227 : H12AffineFastState.Bounded env59227 := by
  intro p hp
  have h : env59227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59226_59227 : H12AffineEnvironment.transform 7 4 env59226 = env59227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env59226 == env59227) = true)

theorem identity59227 : scanCanonicalize (H12AffineFastState.compose env59227 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 190) := by decide +kernel

theorem selectedBound59227 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env59228 : List Nat := [2,4,8,16,32,64,128,4,81,69,190,17,73,80,0,126,29,255,85,1,16,216,13,126,209,76,43,77,81,146,68,64,4,93,1,64]

theorem envBound59228 : H12AffineFastState.Bounded env59228 := by
  intro p hp
  have h : env59228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59227_59228 : H12AffineEnvironment.transform 10 190 env59227 = env59228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 190 env59227 == env59228) = true)

theorem identity59228 : scanCanonicalize (H12AffineFastState.compose env59228 (packedSelected [1,4,9,12,13,16] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound59228 : packedSelected [1,4,9,12,13,16] rootPS < 2^1333 := by decide +kernel

def env59229 : List Nat := [2,4,8,16,32,64,56,4,81,69,6,17,73,80,0,126,29,71,85,1,16,96,13,126,105,76,43,77,81,42,68,64,4,93,1,64]

theorem envBound59229 : H12AffineFastState.Bounded env59229 := by
  intro p hp
  have h : env59229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59228_59229 : H12AffineEnvironment.transform 6 56 env59228 = env59229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env59228 == env59229) = true)

def env59230 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,533641,672785,134217728,148801,545088,96346,16876544,151802110,257,134521988,151462017,525824]

theorem envBound59230 : H12AffineFastState.Bounded env59230 := by
  intro p hp
  have h : env59230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58517_59230 : H12AffineEnvironment.transform 24 533641 env58517 = env59230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533641 env58517 == env59230) = true)

def env59231 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,533641,672785,17245632,148801,545088,96346,16876544,750910,257,17006916,1345,525824]

theorem envBound59231 : H12AffineFastState.Bounded env59231 := by
  intro p hp
  have h : env59231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59230_59231 : H12AffineEnvironment.transform 26 17245632 env59230 = env59231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env59230 == env59231) = true)

theorem identity59231 : scanCanonicalize (H12AffineFastState.compose env59231 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 717114) := by decide +kernel

theorem selectedBound59231 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env59232 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,717114,533641,672785,906490,148801,545088,96346,750906,750910,257,618622,1345,525824]

theorem envBound59232 : H12AffineFastState.Bounded env59232 := by
  intro p hp
  have h : env59232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59231_59232 : H12AffineEnvironment.transform 23 717114 env59231 = env59232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 717114 env59231 == env59232) = true)

def env59233 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147520,58682,143497,20497,508154,148801,148800,96346,90426,90430,257,222334,1345,135680]

theorem envBound59233 : H12AffineFastState.Bounded env59233 := by
  intro p hp
  have h : env59233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59232_59233 : H12AffineEnvironment.transform 18 136192 env59232 = env59233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env59232 == env59233) = true)

def env59234 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147520,58518,143497,20497,508154,148717,148716,96346,90262,90258,173,222334,1261,135680]

theorem envBound59234 : H12AffineFastState.Bounded env59234 := by
  intro p hp
  have h : env59234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59233_59234 : H12AffineEnvironment.transform 7 172 env59233 = env59234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env59233 == env59234) = true)

def env59235 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61568,147472,58518,143497,20497,508074,148669,148668,96266,90262,90258,173,222254,1213,135680]

theorem envBound59235 : H12AffineFastState.Bounded env59235 := by
  intro p hp
  have h : env59235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59234_59235 : H12AffineEnvironment.transform 5 16 env59234 = env59235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env59234 == env59235) = true)

theorem identity59235 : scanCanonicalize (H12AffineFastState.compose env59235 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound59235 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env59236 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,45216,262144,42144,32769,4097,61568,61616,58518,32809,20497,356362,62493,62492,96266,90262,90258,173,119950,1213,41632]

theorem envBound59236 : H12AffineFastState.Bounded env59236 := by
  intro p hp
  have h : env59236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59235_59236 : H12AffineEnvironment.transform 16 45216 env59235 = env59236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env59235 == env59236) = true)

theorem identity59236 : scanCanonicalize (H12AffineFastState.compose env59236 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound59236 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env59237 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,45216,2185,42144,32769,4097,61568,61616,58518,32809,20497,96387,62493,62492,96266,90262,90258,173,119950,1213,41632]

theorem envBound59237 : H12AffineFastState.Bounded env59237 := by
  intro p hp
  have h : env59237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59236_59237 : H12AffineEnvironment.transform 17 2185 env59236 = env59237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env59236 == env59237) = true)

theorem identity59237 : scanCanonicalize (H12AffineFastState.compose env59237 (packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 54310) := by decide +kernel

theorem selectedBound59237 : packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env59238 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,54310,45216,2185,42144,32769,4097,61568,61616,58518,32809,20497,44197,62493,62492,44076,46256,46260,173,168,1213,41632]

theorem envBound59238 : H12AffineFastState.Bounded env59238 := by
  intro p hp
  have h : env59238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59237_59238 : H12AffineEnvironment.transform 15 54310 env59237 = env59238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54310 env59237 == env59238) = true)

theorem identity59238 : scanCanonicalize (H12AffineFastState.compose env59238 (packedSelected [1,4,5,8,9,16,17,21,24] rootPS)) = affineNative (2^(14+1) ^^^ 24601) := by decide +kernel

theorem selectedBound59238 : packedSelected [1,4,5,8,9,16,17,21,24] rootPS < 2^1333 := by decide +kernel

def env59239 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,24601,13375,20665,2185,17593,24600,4097,4249,4265,1167,24624,20497,19644,5124,5125,19509,21673,21677,173,168,1213,17081]

theorem envBound59239 : H12AffineFastState.Bounded env59239 := by
  intro p hp
  have h : env59239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59238_59239 : H12AffineEnvironment.transform 14 24601 env59238 = env59239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 24601 env59238 == env59239) = true)

theorem identity59239 : scanCanonicalize (H12AffineFastState.compose env59239 (packedSelected [0,2,3,4,5,7,9,10,11,15] rootPS)) = affineNative (2^(13+1) ^^^ 1540) := by decide +kernel

theorem selectedBound59239 : packedSelected [0,2,3,4,5,7,9,10,11,15] rootPS < 2^1333 := by decide +kernel

def env59240 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1540,9757,13375,5821,2185,701,9756,4097,4249,4265,1167,9780,5653,2744,5124,5125,2609,4781,4777,173,168,1213,1213]

theorem envBound59240 : H12AffineFastState.Bounded env59240 := by
  intro p hp
  have h : env59240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59239_59240 : H12AffineEnvironment.transform 13 1540 env59239 = env59240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1540 env59239 == env59240) = true)

theorem identity59240 : scanCanonicalize (H12AffineFastState.compose env59240 (packedSelected [0,3,4,6,8,10,11,12,13] rootPS)) = affineNative (2^(11+1) ^^^ 3222) := by decide +kernel

theorem selectedBound59240 : packedSelected [0,3,4,6,8,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env59241 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,3222,8192,1540,9757,10409,2603,2185,701,9756,3223,3087,3135,1167,9780,2691,2744,2194,2195,2609,3643,3647,173,168,1213,1213]

theorem envBound59241 : H12AffineFastState.Bounded env59241 := by
  intro p hp
  have h : env59241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59240_59241 : H12AffineEnvironment.transform 11 3222 env59240 = env59241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3222 env59240 == env59241) = true)

theorem identity59241 : scanCanonicalize (H12AffineFastState.compose env59241 (packedSelected [0,4,6,7,9,11,17] rootPS)) = affineNative (2^(12+1) ^^^ 2584) := by decide +kernel

theorem selectedBound59241 : packedSelected [0,4,6,7,9,11,17] rootPS < 2^1333 := by decide +kernel

def env59242 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,3222,2584,1540,3077,689,2603,2185,701,3076,3223,3087,3135,1167,3116,2691,2744,2194,2195,2609,3643,3647,173,168,1213,1213]

theorem envBound59242 : H12AffineFastState.Bounded env59242 := by
  intro p hp
  have h : env59242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59241_59242 : H12AffineEnvironment.transform 12 2584 env59241 = env59242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2584 env59241 == env59242) = true)

theorem identity59242 : scanCanonicalize (H12AffineFastState.compose env59242 (packedSelected [0,1,5,6,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound59242 : packedSelected [0,1,5,6,9,10] rootPS < 2^1333 := by decide +kernel

def env59243 : List Nat := [2,4,8,16,32,16,128,172,512,1024,1076,162,1580,1540,49,689,1567,1213,701,48,163,59,11,1167,24,1719,1676,1190,1191,1541,527,523,173,168,1213,1213]

theorem envBound59243 : H12AffineFastState.Bounded env59243 := by
  intro p hp
  have h : env59243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59242_59243 : H12AffineEnvironment.transform 10 1076 env59242 = env59243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env59242 == env59243) = true)

theorem identity59243 : scanCanonicalize (H12AffineFastState.compose env59243 (packedSelected [0,2,3,4,6,7,8,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 150) := by decide +kernel

theorem selectedBound59243 : packedSelected [0,2,3,4,6,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env59244 : List Nat := [2,4,8,16,32,16,128,172,512,150,162,162,698,658,49,689,649,43,701,48,163,59,11,25,24,545,538,48,49,659,527,523,173,168,43,43]

theorem envBound59244 : H12AffineFastState.Bounded env59244 := by
  intro p hp
  have h : env59244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59243_59244 : H12AffineEnvironment.transform 9 150 env59243 = env59244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 150 env59243 == env59244) = true)

theorem identity59244 : scanCanonicalize (H12AffineFastState.compose env59244 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound59244 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env59245 : List Nat := [2,4,8,16,32,16,128,172,0,150,162,162,186,146,49,177,137,43,189,48,163,59,11,25,24,33,26,48,49,147,15,11,173,168,43,43]

theorem envBound59245 : H12AffineFastState.Bounded env59245 := by
  intro p hp
  have h : env59245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59244_59245 : H12AffineEnvironment.transform 8 0 env59244 = env59245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env59244 == env59245) = true)

theorem identity59245 : scanCanonicalize (H12AffineFastState.compose env59245 (packedSelected [3,5] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound59245 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env59246 : List Nat := [2,4,8,16,32,16,8,36,0,30,42,42,50,26,49,57,1,43,53,48,43,59,11,25,24,33,26,48,49,27,15,11,37,32,43,43]

theorem envBound59246 : H12AffineFastState.Bounded env59246 := by
  intro p hp
  have h : env59246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59245_59246 : H12AffineEnvironment.transform 6 8 env59245 = env59246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env59245 == env59246) = true)

def env59247 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61569,147473,58518,143497,20497,508075,148668,148669,96267,90262,90258,173,222255,1212,135680]

theorem envBound59247 : H12AffineFastState.Bounded env59247 := by
  intro p hp
  have h : env59247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59234_59247 : H12AffineEnvironment.transform 5 17 env59234 = env59247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env59234 == env59247) = true)

theorem identity59247 : scanCanonicalize (H12AffineFastState.compose env59247 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 137352) := by decide +kernel

theorem selectedBound59247 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env59248 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137352,136192,32769,4097,61569,147473,58518,143497,20497,120867,148668,148669,96267,90262,90258,173,222255,1212,135680]

theorem envBound59248 : H12AffineFastState.Bounded env59248 := by
  intro p hp
  have h : env59248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59247_59248 : H12AffineEnvironment.transform 17 137352 env59247 = env59248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137352 env59247 == env59248) = true)

theorem identity59248 : scanCanonicalize (H12AffineFastState.compose env59248 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(16+1) ^^^ 62493) := by decide +kernel

theorem selectedBound59248 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env59249 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,62493,60565,57373,32769,4097,61569,46092,58518,50324,20497,120867,45217,45216,96267,90262,90258,173,102450,1212,58909]

theorem envBound59249 : H12AffineFastState.Bounded env59249 := by
  intro p hp
  have h : env59249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59248_59249 : H12AffineEnvironment.transform 16 62493 env59248 = env59249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 62493 env59248 == env59249) = true)

theorem identity59249 : scanCanonicalize (H12AffineFastState.compose env59249 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound59249 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59250 : List Nat := [2,4,8,16,32,17,128,172,512,4,2048,4096,8192,16384,32768,65536,61465,59537,57373,32769,4097,61569,45064,57490,49296,20497,120867,45217,45216,96267,90262,90258,173,102450,184,57881]

theorem envBound59250 : H12AffineFastState.Bounded env59250 := by
  intro p hp
  have h : env59250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59249_59250 : H12AffineEnvironment.transform 9 4 env59249 = env59250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env59249 == env59250) = true)

theorem identity59250 : scanCanonicalize (H12AffineFastState.compose env59250 (packedSelected [0,2,3,4,5,6,7,9,10,13,17,18,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 2730) := by decide +kernel

theorem selectedBound59250 : packedSelected [0,2,3,4,5,6,7,9,10,13,17,18,21,23] rootPS < 2^1333 := by decide +kernel

def env59251 : List Nat := [2,4,8,16,32,17,128,172,512,4,2048,4096,8192,16384,32768,2730,61465,59537,57373,32769,4097,61569,45064,57490,49296,20497,53897,45217,45216,29345,27196,27192,173,39576,184,57881]

theorem envBound59251 : H12AffineFastState.Bounded env59251 := by
  intro p hp
  have h : env59251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59250_59251 : H12AffineEnvironment.transform 15 2730 env59250 = env59251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2730 env59250 == env59251) = true)

theorem identity59251 : scanCanonicalize (H12AffineFastState.compose env59251 (packedSelected [0,2,3,4,5,6,7,9,10,13,19,26] rootPS)) = affineNative (2^(14+1) ^^^ 23176) := by decide +kernel

theorem selectedBound59251 : packedSelected [0,2,3,4,5,6,7,9,10,13,19,26] rootPS < 2^1333 := by decide +kernel

def env59252 : List Nat := [2,4,8,16,32,17,128,172,512,4,2048,4096,8192,16384,23176,2730,10897,12825,14997,23177,4097,10761,27264,14874,6680,20497,2049,27177,27176,29345,27196,27192,173,16400,184,14481]

theorem envBound59252 : H12AffineFastState.Bounded env59252 := by
  intro p hp
  have h : env59252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59251_59252 : H12AffineEnvironment.transform 14 23176 env59251 = env59252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 23176 env59251 == env59252) = true)

theorem identity59252 : scanCanonicalize (H12AffineFastState.compose env59252 (packedSelected [1,2,4,6,7,8,10,11,17] rootPS)) = affineNative (2^(13+1) ^^^ 14496) := by decide +kernel

theorem selectedBound59252 : packedSelected [1,2,4,6,7,8,10,11,17] rootPS < 2^1333 := by decide +kernel

def env59253 : List Nat := [2,4,8,16,32,17,128,172,512,4,2048,4096,8192,14496,8744,2730,10897,12825,14997,8745,4097,10761,4640,14874,6680,10417,2049,4745,4744,2561,4764,4760,173,14512,184,14481]

theorem envBound59253 : H12AffineFastState.Bounded env59253 := by
  intro p hp
  have h : env59253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59252_59253 : H12AffineEnvironment.transform 13 14496 env59252 = env59253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 14496 env59252 == env59253) = true)

theorem identity59253 : scanCanonicalize (H12AffineFastState.compose env59253 (packedSelected [1,5,6,10,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 555) := by decide +kernel

theorem selectedBound59253 : packedSelected [1,5,6,10,11,13] rootPS < 2^1333 := by decide +kernel

def env59254 : List Nat := [2,4,8,16,32,17,128,172,512,4,555,4096,8192,12939,8744,129,8378,12825,12478,8745,4097,8226,4640,12337,4147,8858,554,4745,4744,42,4764,4760,173,12955,184,12986]

theorem envBound59254 : H12AffineFastState.Bounded env59254 := by
  intro p hp
  have h : env59254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59253_59254 : H12AffineEnvironment.transform 10 555 env59253 = env59254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 555 env59253 == env59254) = true)

theorem identity59254 : scanCanonicalize (H12AffineFastState.compose env59254 (packedSelected [2,3,5,6,7,9,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 42) := by decide +kernel

theorem selectedBound59254 : packedSelected [2,3,5,6,7,9,10,11] rootPS < 2^1333 := by decide +kernel

def env59255 : List Nat := [2,4,8,16,32,17,128,172,512,4,555,42,8192,8865,8744,129,8378,8755,8340,8745,43,8226,522,8219,25,8858,554,675,674,42,694,690,173,8881,184,8848]

theorem envBound59255 : H12AffineFastState.Bounded env59255 := by
  intro p hp
  have h : env59255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59254_59255 : H12AffineEnvironment.transform 11 42 env59254 = env59255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 42 env59254 == env59255) = true)

theorem identity59255 : scanCanonicalize (H12AffineFastState.compose env59255 (packedSelected [2,4,5,6,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound59255 : packedSelected [2,4,5,6,8,9] rootPS < 2^1333 := by decide +kernel

def env59256 : List Nat := [2,4,8,16,32,17,128,172,512,4,555,42,24,697,560,129,162,555,140,561,43,58,522,3,25,642,554,675,674,42,694,690,173,681,184,648]

theorem envBound59256 : H12AffineFastState.Bounded env59256 := by
  intro p hp
  have h : env59256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59255_59256 : H12AffineEnvironment.transform 12 24 env59255 = env59256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env59255 == env59256) = true)

theorem identity59256 : scanCanonicalize (H12AffineFastState.compose env59256 (packedSelected [1,2,4,6,7,8] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound59256 : packedSelected [1,2,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env59257 : List Nat := [2,4,8,11,32,10,128,172,512,4,555,42,3,674,555,129,162,555,140,554,43,33,522,3,2,642,554,675,674,42,685,681,173,681,163,648]

theorem envBound59257 : H12AffineFastState.Bounded env59257 := by
  intro p hp
  have h : env59257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59256_59257 : H12AffineEnvironment.transform 3 11 env59256 = env59257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env59256 == env59257) = true)

theorem identity59257 : scanCanonicalize (H12AffineFastState.compose env59257 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound59257 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env59258 : List Nat := [2,4,8,11,32,10,128,172,136,4,163,42,3,42,163,129,162,163,140,162,43,33,130,3,2,10,162,43,42,42,37,33,173,33,163,0]

theorem envBound59258 : H12AffineFastState.Bounded env59258 := by
  intro p hp
  have h : env59258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59257_59258 : H12AffineEnvironment.transform 8 136 env59257 = env59258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env59257 == env59258) = true)

theorem identity59258 : scanCanonicalize (H12AffineFastState.compose env59258 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound59258 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env59259 : List Nat := [2,4,8,11,10,10,128,134,136,4,137,0,3,0,137,129,136,137,140,136,1,11,130,3,2,10,136,1,0,0,15,11,135,11,137,0]

theorem envBound59259 : H12AffineFastState.Bounded env59259 := by
  intro p hp
  have h : env59259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59258_59259 : H12AffineEnvironment.transform 4 10 env59258 = env59259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env59258 == env59259) = true)

theorem identity59259 : scanCanonicalize (H12AffineFastState.compose env59259 (packedSelected [0,1,4] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound59259 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env59260 : List Nat := [2,4,5,6,7,7,128,134,133,4,132,0,3,0,132,129,133,132,129,133,1,6,130,3,2,7,133,1,0,0,2,6,135,6,132,0]

theorem envBound59260 : H12AffineFastState.Bounded env59260 := by
  intro p hp
  have h : env59260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59259_59260 : H12AffineEnvironment.transform 2 5 env59259 = env59260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env59259 == env59260) = true)

def env59261 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147520,58519,143497,20497,508154,148716,148717,96346,90263,90259,172,222334,1260,135680]

theorem envBound59261 : H12AffineFastState.Bounded env59261 := by
  intro p hp
  have h : env59261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59233_59261 : H12AffineEnvironment.transform 7 173 env59233 = env59261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env59233 == env59261) = true)

def env59262 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61568,147472,58519,143497,20497,508074,148668,148669,96266,90263,90259,172,222254,1212,135680]

theorem envBound59262 : H12AffineFastState.Bounded env59262 := by
  intro p hp
  have h : env59262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59261_59262 : H12AffineEnvironment.transform 5 16 env59261 = env59262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env59261 == env59262) = true)

theorem identity59262 : scanCanonicalize (H12AffineFastState.compose env59262 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 99487) := by decide +kernel

theorem selectedBound59262 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env59263 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,99487,262144,102559,32769,4097,61568,115855,58519,111638,20497,279605,114723,114722,96266,90263,90259,172,57521,1212,104095]

theorem envBound59263 : H12AffineFastState.Bounded env59263 := by
  intro p hp
  have h : env59263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59262_59263 : H12AffineEnvironment.transform 16 99487 env59262 = env59263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 99487 env59262 == env59263) = true)

theorem identity59263 : scanCanonicalize (H12AffineFastState.compose env59263 (packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 12347) := by decide +kernel

theorem selectedBound59263 : packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env59264 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,12347,46244,262144,41124,32769,4097,61568,62644,58519,33837,20497,279605,61464,61465,18481,20652,20648,172,57521,1212,42660]

theorem envBound59264 : H12AffineFastState.Bounded env59264 := by
  intro p hp
  have h : env59264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59263_59264 : H12AffineEnvironment.transform 15 12347 env59263 = env59264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12347 env59263 == env59264) = true)

theorem identity59264 : scanCanonicalize (H12AffineFastState.compose env59264 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 9380) := by decide +kernel

theorem selectedBound59264 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env59265 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,9380,12347,4096,262144,1024,9381,4097,21540,20496,16435,8329,20497,279605,21692,21693,18481,20652,20648,172,17429,1212,512]

theorem envBound59265 : H12AffineFastState.Bounded env59265 := by
  intro p hp
  have h : env59265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59264_59265 : H12AffineEnvironment.transform 14 9380 env59264 = env59265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9380 env59264 == env59265) = true)

theorem identity59265 : scanCanonicalize (H12AffineFastState.compose env59265 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound59265 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59266 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1213,9380,12347,4096,262144,1024,9381,4097,4249,5293,1166,8329,5292,262280,4097,4096,3212,5137,5141,172,168,1212,512]

theorem envBound59266 : H12AffineFastState.Bounded env59266 := by
  intro p hp
  have h : env59266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59265_59266 : H12AffineEnvironment.transform 13 1213 env59265 = env59266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env59265 == env59266) = true)

theorem identity59266 : scanCanonicalize (H12AffineFastState.compose env59266 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 4649) := by decide +kernel

theorem selectedBound59266 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env59267 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,4649,1213,5773,530,4096,262144,1024,5772,4097,4249,5293,1166,4768,5292,262280,4097,4096,3212,5137,5141,172,168,1212,512]

theorem envBound59267 : H12AffineFastState.Bounded env59267 := by
  intro p hp
  have h : env59267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59266_59267 : H12AffineEnvironment.transform 12 4649 env59266 = env59267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4649 env59266 == env59267) = true)

theorem identity59267 : scanCanonicalize (H12AffineFastState.compose env59267 (packedSelected [1,3,13] rootPS)) = affineNative (2^(17+1) ^^^ 6192) := by decide +kernel

theorem selectedBound59267 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env59268 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,4649,1213,5773,530,4096,6192,1024,5772,4097,4249,5293,1166,4768,5292,6328,4097,4096,3212,5137,5141,172,168,1212,512]

theorem envBound59268 : H12AffineFastState.Bounded env59268 := by
  intro p hp
  have h : env59268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59267_59268 : H12AffineEnvironment.transform 17 6192 env59267 = env59268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6192 env59267 == env59268) = true)

theorem identity59268 : scanCanonicalize (H12AffineFastState.compose env59268 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 2587) := by decide +kernel

theorem selectedBound59268 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env59269 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,2587,2098,1213,3222,530,2587,555,1024,3223,2586,2690,3766,1166,2235,3767,675,2586,2587,3212,3594,3598,172,168,1212,512]

theorem envBound59269 : H12AffineFastState.Bounded env59269 := by
  intro p hp
  have h : env59269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59268_59269 : H12AffineEnvironment.transform 11 2587 env59268 = env59269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2587 env59268 == env59269) = true)

def env59270 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61569,147473,58519,143497,20497,508075,148669,148668,96267,90263,90259,172,222255,1213,135680]

theorem envBound59270 : H12AffineFastState.Bounded env59270 := by
  intro p hp
  have h : env59270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59261_59270 : H12AffineEnvironment.transform 5 17 env59261 = env59270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env59261 == env59270) = true)

theorem identity59270 : scanCanonicalize (H12AffineFastState.compose env59270 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 208054) := by decide +kernel

theorem selectedBound59270 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env59271 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,208054,136192,32769,4097,61569,147473,58519,143497,20497,60445,148669,148668,96267,90263,90259,172,222255,1213,135680]

theorem envBound59271 : H12AffineFastState.Bounded env59271 := by
  intro p hp
  have h : env59271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59270_59271 : H12AffineEnvironment.transform 17 208054 env59270 = env59271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 208054 env59270 == env59271) = true)

theorem identity59271 : scanCanonicalize (H12AffineFastState.compose env59271 (packedSelected [1,3,5,7,8,10,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound59271 : packedSelected [1,3,5,7,8,10,20,26,27] rootPS < 2^1333 := by decide +kernel

def env59272 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,53283,131072,195733,136192,32769,4097,61569,147473,58519,143497,20497,60445,148669,148668,43048,45236,45232,172,177164,1213,135680]

theorem envBound59272 : H12AffineFastState.Bounded env59272 := by
  intro p hp
  have h : env59272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59271_59272 : H12AffineEnvironment.transform 15 53283 env59271 = env59272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env59271 == env59272) = true)

theorem identity59272 : scanCanonicalize (H12AffineFastState.compose env59272 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 21693) := by decide +kernel

theorem selectedBound59272 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env59273 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,53283,21693,43048,16573,32769,4097,61569,5292,58519,25652,20497,60445,4096,4097,43048,45236,45232,172,57521,1213,18109]

theorem envBound59273 : H12AffineFastState.Bounded env59273 := by
  intro p hp
  have h : env59273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59272_59273 : H12AffineEnvironment.transform 16 21693 env59272 = env59273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21693 env59272 == env59273) = true)

theorem identity59273 : scanCanonicalize (H12AffineFastState.compose env59273 (packedSelected [4,9,20] rootPS)) = affineNative (2^(14+1) ^^^ 9380) := by decide +kernel

theorem selectedBound59273 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env59274 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,9380,29831,21693,3212,16573,9381,4097,21541,5292,16435,25652,20497,18617,4096,4097,3212,5136,5140,172,17429,1213,18109]

theorem envBound59274 : H12AffineFastState.Bounded env59274 := by
  intro p hp
  have h : env59274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59273_59274 : H12AffineEnvironment.transform 14 9380 env59273 = env59274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9380 env59273 == env59274) = true)

theorem identity59274 : scanCanonicalize (H12AffineFastState.compose env59274 (packedSelected [0,2,3,4,5,6,11,13,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 673) := by decide +kernel

theorem selectedBound59274 : packedSelected [0,2,3,4,5,6,11,13,16,17] rootPS < 2^1333 := by decide +kernel

def env59275 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,673,16384,1541,22054,21693,3212,16573,1540,4097,21541,5292,16435,18069,20497,18617,4096,4097,3212,5136,5140,172,17429,1213,18109]

theorem envBound59275 : H12AffineFastState.Bounded env59275 := by
  intro p hp
  have h : env59275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59274_59275 : H12AffineEnvironment.transform 12 673 env59274 = env59275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 673 env59274 == env59275) = true)

theorem identity59275 : scanCanonicalize (H12AffineFastState.compose env59275 (packedSelected [1,3,6,7,9,11,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 3119) := by decide +kernel

theorem selectedBound59275 : packedSelected [1,3,6,7,9,11,13,15] rootPS < 2^1333 := by decide +kernel

def env59276 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,3119,673,16384,1541,18953,18578,3212,16573,1540,3118,18442,2179,16435,18069,19518,18617,3119,3118,3212,2111,2107,172,17429,1213,18109]

theorem envBound59276 : H12AffineFastState.Bounded env59276 := by
  intro p hp
  have h : env59276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59275_59276 : H12AffineEnvironment.transform 11 3119 env59275 = env59276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3119 env59275 == env59276) = true)

theorem identity59276 : scanCanonicalize (H12AffineFastState.compose env59276 (packedSelected [0,1,2,5,6,9,11,13] rootPS)) = affineNative (2^(13+1) ^^^ 3103) := by decide +kernel

theorem selectedBound59276 : packedSelected [0,1,2,5,6,9,11,13] rootPS < 2^1333 := by decide +kernel

def env59277 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,3119,673,3103,1541,1558,1165,3212,3234,1540,3118,1045,2179,3116,2698,33,1190,3119,3118,3212,2111,2107,172,2058,1213,2722]

theorem envBound59277 : H12AffineFastState.Bounded env59277 := by
  intro p hp
  have h : env59277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59276_59277 : H12AffineEnvironment.transform 13 3103 env59276 = env59277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3103 env59276 == env59277) = true)

theorem identity59277 : scanCanonicalize (H12AffineFastState.compose env59277 (packedSelected [2,6,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 162) := by decide +kernel

theorem selectedBound59277 : packedSelected [2,6,7,9] rootPS < 2^1333 := by decide +kernel

def env59278 : List Nat := [2,4,8,16,32,17,128,173,512,1024,162,1165,673,1213,1541,1558,1165,1070,1024,1540,1164,1045,33,1166,552,33,1190,1165,1164,1070,157,153,172,168,1213,512]

theorem envBound59278 : H12AffineFastState.Bounded env59278 := by
  intro p hp
  have h : env59278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59277_59278 : H12AffineEnvironment.transform 10 162 env59277 = env59278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 162 env59277 == env59278) = true)

theorem identity59278 : scanCanonicalize (H12AffineFastState.compose env59278 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound59278 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env59279 : List Nat := [2,4,8,16,32,17,128,173,0,1024,162,1165,161,1213,1029,1046,1165,1070,1024,1028,1164,1045,33,1166,40,33,1190,1165,1164,1070,157,153,172,168,1213,0]

theorem envBound59279 : H12AffineFastState.Bounded env59279 := by
  intro p hp
  have h : env59279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59278_59279 : H12AffineEnvironment.transform 8 0 env59278 = env59279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env59278 == env59279) = true)

theorem identity59279 : scanCanonicalize (H12AffineFastState.compose env59279 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound59279 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env59280 : List Nat := [2,4,8,16,32,17,19,62,0,1024,49,1054,50,1070,1029,1046,1054,1070,1024,1028,1055,1045,33,1053,40,33,1077,1054,1055,1070,14,10,63,59,1070,0]

theorem envBound59280 : H12AffineFastState.Bounded env59280 := by
  intro p hp
  have h : env59280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59279_59280 : H12AffineEnvironment.transform 6 19 env59279 = env59280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env59279 == env59280) = true)

theorem identity59280 : scanCanonicalize (H12AffineFastState.compose env59280 (packedSelected [0,1,2,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound59280 : packedSelected [0,1,2,5,7] rootPS < 2^1333 := by decide +kernel

def env59281 : List Nat := [2,4,8,16,11,17,19,21,0,1024,26,1054,25,1029,1029,1046,1054,1029,1024,1028,1055,1045,10,1053,3,10,1054,1054,1055,1029,14,10,20,16,1029,0]

theorem envBound59281 : H12AffineFastState.Bounded env59281 := by
  intro p hp
  have h : env59281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59280_59281 : H12AffineEnvironment.transform 4 11 env59280 = env59281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env59280 == env59281) = true)

theorem identity59281 : scanCanonicalize (H12AffineFastState.compose env59281 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound59281 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env59282 : List Nat := [2,4,8,10,11,11,9,15,0,1024,0,1028,3,1029,1029,1036,1028,1029,1024,1028,1029,1039,10,1031,3,10,1028,1028,1029,1029,14,10,14,10,1029,0]

theorem envBound59282 : H12AffineFastState.Bounded env59282 := by
  intro p hp
  have h : env59282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59281_59282 : H12AffineEnvironment.transform 3 10 env59281 = env59282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env59281 == env59282) = true)

theorem identity59282 : scanCanonicalize (H12AffineFastState.compose env59282 (packedSelected [0,5] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound59282 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env59283 : List Nat := [2,4,8,10,11,11,9,15,0,5,0,1,3,0,0,9,1,0,5,1,0,10,10,2,3,10,1,1,0,0,14,10,14,10,0,0]

theorem envBound59283 : H12AffineFastState.Bounded env59283 := by
  intro p hp
  have h : env59283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59282_59283 : H12AffineEnvironment.transform 9 5 env59282 = env59283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env59282 == env59283) = true)

theorem identity59283 : scanCanonicalize (H12AffineFastState.compose env59283 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound59283 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59284 : List Nat := [2,2,8,10,11,11,9,9,0,3,0,1,3,0,0,9,1,0,3,1,0,10,10,2,3,10,1,1,0,0,8,10,8,10,0,0]

theorem envBound59284 : H12AffineFastState.Bounded env59284 := by
  intro p hp
  have h : env59284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59283_59284 : H12AffineEnvironment.transform 1 2 env59283 = env59284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env59283 == env59284) = true)

def env59285 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147520,58683,143496,20496,508155,148801,148801,96346,90427,90431,257,222335,1345,135681]

theorem envBound59285 : H12AffineFastState.Bounded env59285 := by
  intro p hp
  have h : env59285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59232_59285 : H12AffineEnvironment.transform 18 136193 env59232 = env59285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env59232 == env59285) = true)

def env59286 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147520,58519,143496,20496,508155,148717,148717,96346,90263,90259,173,222335,1261,135681]

theorem envBound59286 : H12AffineFastState.Bounded env59286 := by
  intro p hp
  have h : env59286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59285_59286 : H12AffineEnvironment.transform 7 172 env59285 = env59286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env59285 == env59286) = true)

def env59287 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61568,147472,58519,143496,20496,508075,148669,148669,96266,90263,90259,173,222255,1213,135681]

theorem envBound59287 : H12AffineFastState.Bounded env59287 := by
  intro p hp
  have h : env59287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59286_59287 : H12AffineEnvironment.transform 5 16 env59286 = env59287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env59286 == env59287) = true)

theorem identity59287 : scanCanonicalize (H12AffineFastState.compose env59287 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 137353) := by decide +kernel

theorem selectedBound59287 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env59288 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137353,136193,32769,4097,61568,147472,58519,143496,20496,120866,148669,148669,96266,90263,90259,173,222255,1213,135681]

theorem envBound59288 : H12AffineFastState.Bounded env59288 := by
  intro p hp
  have h : env59288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59287_59288 : H12AffineEnvironment.transform 17 137353 env59287 = env59288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137353 env59287 == env59288) = true)

theorem identity59288 : scanCanonicalize (H12AffineFastState.compose env59288 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(16+1) ^^^ 62493) := by decide +kernel

theorem selectedBound59288 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env59289 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,62493,60564,57372,32769,4097,61568,46093,58519,50325,20496,120866,45216,45216,96266,90263,90259,173,102450,1213,58908]

theorem envBound59289 : H12AffineFastState.Bounded env59289 := by
  intro p hp
  have h : env59289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59288_59289 : H12AffineEnvironment.transform 16 62493 env59288 = env59289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 62493 env59288 == env59289) = true)

theorem identity59289 : scanCanonicalize (H12AffineFastState.compose env59289 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound59289 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59290 : List Nat := [2,4,8,16,32,16,128,172,512,5,2048,4096,8192,16384,32768,65536,61464,59537,57372,32769,4097,61568,45064,57490,49296,20496,120866,45216,45216,96266,90263,90259,173,102450,184,57881]

theorem envBound59290 : H12AffineFastState.Bounded env59290 := by
  intro p hp
  have h : env59290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59289_59290 : H12AffineEnvironment.transform 9 5 env59289 = env59290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env59289 == env59290) = true)

theorem identity59290 : scanCanonicalize (H12AffineFastState.compose env59290 (packedSelected [0,2,3,4,5,6,7,9,10,13,17,18,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 14889) := by decide +kernel

theorem selectedBound59290 : packedSelected [0,2,3,4,5,6,7,9,10,13,17,18,21,23] rootPS < 2^1333 := by decide +kernel

def env59291 : List Nat := [2,4,8,16,32,16,128,172,512,5,2048,4096,8192,14889,32768,65536,35377,37560,39477,32769,4097,35497,45064,39611,47801,10809,107019,45216,45216,66083,72382,72378,173,102450,184,38960]

theorem envBound59291 : H12AffineFastState.Bounded env59291 := by
  intro p hp
  have h : env59291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59290_59291 : H12AffineEnvironment.transform 13 14889 env59290 = env59291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 14889 env59290 == env59291) = true)

theorem identity59291 : scanCanonicalize (H12AffineFastState.compose env59291 (packedSelected [0,2,3,4,5,6,7,9,10,13,19,26] rootPS)) = affineNative (2^(15+1) ^^^ 43530) := by decide +kernel

theorem selectedBound59291 : packedSelected [0,2,3,4,5,6,7,9,10,13,19,26] rootPS < 2^1333 := by decide +kernel

def env59292 : List Nat := [2,4,8,16,32,16,128,172,512,5,2048,4096,8192,14889,32768,43530,35377,37560,39477,32769,4097,35497,45064,39611,47801,10809,2049,45216,45216,43049,45236,45232,173,14904,184,38960]

theorem envBound59292 : H12AffineFastState.Bounded env59292 := by
  intro p hp
  have h : env59292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59291_59292 : H12AffineEnvironment.transform 15 43530 env59291 = env59292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 43530 env59291 == env59292) = true)

theorem identity59292 : scanCanonicalize (H12AffineFastState.compose env59292 (packedSelected [0,1,6,8,9,10,12,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound59292 : packedSelected [0,1,6,8,9,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env59293 : List Nat := [2,4,8,16,32,16,128,172,512,5,2048,4096,2088,4609,32768,33314,35377,37560,39477,32769,4097,35497,38944,39611,37521,529,2049,39048,39048,32769,39068,39064,173,4624,184,38960]

theorem envBound59293 : H12AffineFastState.Bounded env59293 := by
  intro p hp
  have h : env59293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59292_59293 : H12AffineEnvironment.transform 12 2088 env59292 = env59293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env59292 == env59293) = true)

theorem identity59293 : scanCanonicalize (H12AffineFastState.compose env59293 (packedSelected [2,4,7,10,11,13] rootPS)) = affineNative (2^(14+1) ^^^ 696) := by decide +kernel

theorem selectedBound59293 : packedSelected [2,4,7,10,11,13] rootPS < 2^1333 := by decide +kernel

def env59294 : List Nat := [2,4,8,16,32,16,128,172,512,5,2048,4096,2088,4609,696,154,2185,4096,6285,697,4097,2065,6808,6147,4137,529,2049,6704,6704,697,6692,6688,173,4624,184,6792]

theorem envBound59294 : H12AffineFastState.Bounded env59294 := by
  intro p hp
  have h : env59294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59293_59294 : H12AffineEnvironment.transform 14 696 env59293 = env59294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 696 env59293 == env59294) = true)

theorem identity59294 : scanCanonicalize (H12AffineFastState.compose env59294 (packedSelected [2,3,6,7,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound59294 : packedSelected [2,3,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env59295 : List Nat := [2,4,8,16,32,16,18,62,512,5,2048,4096,2088,4609,554,8,2075,4096,6175,555,4097,2065,6666,6147,4137,529,2049,6704,6704,555,6692,6688,63,4624,42,6682]

theorem envBound59295 : H12AffineFastState.Bounded env59295 := by
  intro p hp
  have h : env59295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59294_59295 : H12AffineEnvironment.transform 6 18 env59294 = env59295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env59294 == env59295) = true)

theorem identity59295 : scanCanonicalize (H12AffineFastState.compose env59295 (packedSelected [0,1,2,3,4,6,10] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound59295 : packedSelected [0,1,2,3,4,6,10] rootPS < 2^1333 := by decide +kernel

def env59296 : List Nat := [2,4,8,16,32,16,18,62,512,5,49,4096,25,4609,554,8,42,4096,4142,555,4097,32,4667,4146,4137,529,48,4609,4609,555,4629,4625,63,4624,42,4651]

theorem envBound59296 : H12AffineFastState.Bounded env59296 := by
  intro p hp
  have h : env59296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59295_59296 : H12AffineEnvironment.transform 10 49 env59295 = env59296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env59295 == env59296) = true)

theorem identity59296 : scanCanonicalize (H12AffineFastState.compose env59296 (packedSelected [1,6,8] rootPS)) = affineNative (2^(11+1) ^^^ 560) := by decide +kernel

theorem selectedBound59296 : packedSelected [1,6,8] rootPS < 2^1333 := by decide +kernel

def env59297 : List Nat := [2,4,8,16,32,16,18,62,512,5,49,560,25,49,554,8,42,560,542,555,561,32,11,514,537,529,48,49,49,555,37,33,63,32,42,27]

theorem envBound59297 : H12AffineFastState.Bounded env59297 := by
  intro p hp
  have h : env59297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59296_59297 : H12AffineEnvironment.transform 11 560 env59296 = env59297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 560 env59296 == env59297) = true)

theorem identity59297 : scanCanonicalize (H12AffineFastState.compose env59297 (packedSelected [2,3,5] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound59297 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env59298 : List Nat := [2,4,8,16,32,16,18,62,1,5,49,49,25,49,43,8,42,49,31,42,48,32,11,3,24,16,48,49,49,42,37,33,63,32,42,27]

theorem envBound59298 : H12AffineFastState.Bounded env59298 := by
  intro p hp
  have h : env59298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59297_59298 : H12AffineEnvironment.transform 8 1 env59297 = env59298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env59297 == env59298) = true)

theorem identity59298 : scanCanonicalize (H12AffineFastState.compose env59298 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound59298 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env59299 : List Nat := [2,4,8,16,10,16,18,20,1,5,27,27,25,27,1,8,0,27,31,0,26,10,11,3,24,16,26,27,27,0,15,11,21,10,0,27]

theorem envBound59299 : H12AffineFastState.Bounded env59299 := by
  intro p hp
  have h : env59299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59298_59299 : H12AffineEnvironment.transform 4 10 env59298 = env59299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env59298 == env59299) = true)

theorem identity59299 : scanCanonicalize (H12AffineFastState.compose env59299 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound59299 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59300 : List Nat := [2,4,8,10,10,10,8,14,1,5,1,1,3,1,1,8,0,1,5,0,0,10,11,3,2,10,0,1,1,0,15,11,15,10,0,1]

theorem envBound59300 : H12AffineFastState.Bounded env59300 := by
  intro p hp
  have h : env59300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59299_59300 : H12AffineEnvironment.transform 3 10 env59299 = env59300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env59299 == env59300) = true)

theorem identity59300 : scanCanonicalize (H12AffineFastState.compose env59300 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound59300 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59301 : List Nat := [2,4,4,6,6,6,4,2,1,5,1,1,3,1,1,4,0,1,5,0,0,6,7,3,2,6,0,1,1,0,3,7,3,6,0,1]

theorem envBound59301 : H12AffineFastState.Bounded env59301 := by
  intro p hp
  have h : env59301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59300_59301 : H12AffineEnvironment.transform 2 4 env59300 = env59301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env59300 == env59301) = true)

def env59302 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61569,147473,58519,143496,20496,508074,148668,148668,96267,90263,90259,173,222254,1212,135681]

theorem envBound59302 : H12AffineFastState.Bounded env59302 := by
  intro p hp
  have h : env59302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59286_59302 : H12AffineEnvironment.transform 5 17 env59286 = env59302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env59286 == env59302) = true)

theorem identity59302 : scanCanonicalize (H12AffineFastState.compose env59302 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound59302 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env59303 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,45217,262144,42144,32769,4097,61569,61616,58519,32809,20496,356363,62493,62493,96267,90263,90259,173,119951,1212,41632]

theorem envBound59303 : H12AffineFastState.Bounded env59303 := by
  intro p hp
  have h : env59303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59302_59303 : H12AffineEnvironment.transform 16 45217 env59302 = env59303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env59302 == env59303) = true)

theorem identity59303 : scanCanonicalize (H12AffineFastState.compose env59303 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound59303 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env59304 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,45217,2185,42144,32769,4097,61569,61616,58519,32809,20496,96386,62493,62493,96267,90263,90259,173,119951,1212,41632]

theorem envBound59304 : H12AffineFastState.Bounded env59304 := by
  intro p hp
  have h : env59304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59303_59304 : H12AffineEnvironment.transform 17 2185 env59303 = env59304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env59303 == env59304) = true)

theorem identity59304 : scanCanonicalize (H12AffineFastState.compose env59304 (packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 54310) := by decide +kernel

theorem selectedBound59304 : packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env59305 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,54310,45217,2185,42144,32769,4097,61569,61616,58519,32809,20496,44196,62493,62493,44077,46257,46261,173,169,1212,41632]

theorem envBound59305 : H12AffineFastState.Bounded env59305 := by
  intro p hp
  have h : env59305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59304_59305 : H12AffineEnvironment.transform 15 54310 env59304 = env59305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54310 env59304 == env59305) = true)

theorem identity59305 : scanCanonicalize (H12AffineFastState.compose env59305 (packedSelected [1,4,5,8,9,16,17,21,24] rootPS)) = affineNative (2^(14+1) ^^^ 24601) := by decide +kernel

theorem selectedBound59305 : packedSelected [1,4,5,8,9,16,17,21,24] rootPS < 2^1333 := by decide +kernel

def env59306 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,24601,13375,20664,2185,17593,24600,4097,4248,4265,1166,24624,20496,19645,5124,5124,19508,21672,21676,173,169,1212,17081]

theorem envBound59306 : H12AffineFastState.Bounded env59306 := by
  intro p hp
  have h : env59306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59305_59306 : H12AffineEnvironment.transform 14 24601 env59305 = env59306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 24601 env59305 == env59306) = true)

theorem identity59306 : scanCanonicalize (H12AffineFastState.compose env59306 (packedSelected [0,2,3,4,5,7,9,10,11,15] rootPS)) = affineNative (2^(13+1) ^^^ 1540) := by decide +kernel

theorem selectedBound59306 : packedSelected [0,2,3,4,5,7,9,10,11,15] rootPS < 2^1333 := by decide +kernel

def env59307 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1540,9757,13375,5820,2185,701,9756,4097,4248,4265,1166,9780,5652,2745,5124,5124,2608,4780,4776,173,169,1212,1213]

theorem envBound59307 : H12AffineFastState.Bounded env59307 := by
  intro p hp
  have h : env59307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59306_59307 : H12AffineEnvironment.transform 13 1540 env59306 = env59307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1540 env59306 == env59307) = true)

theorem identity59307 : scanCanonicalize (H12AffineFastState.compose env59307 (packedSelected [0,3,4,6,8,10,11,12,13] rootPS)) = affineNative (2^(11+1) ^^^ 3630) := by decide +kernel

theorem selectedBound59307 : packedSelected [0,3,4,6,8,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env59308 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,3630,8192,1540,9757,10769,2194,2185,701,9756,3631,3766,3719,1166,9780,2106,2745,2602,2602,2608,3202,3206,173,169,1212,1213]

theorem envBound59308 : H12AffineFastState.Bounded env59308 := by
  intro p hp
  have h : env59308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59307_59308 : H12AffineEnvironment.transform 11 3630 env59307 = env59308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3630 env59307 == env59308) = true)

theorem identity59308 : scanCanonicalize (H12AffineFastState.compose env59308 (packedSelected [0,4,6,7,9,11,17] rootPS)) = affineNative (2^(12+1) ^^^ 3612) := by decide +kernel

theorem selectedBound59308 : packedSelected [0,4,6,7,9,11,17] rootPS < 2^1333 := by decide +kernel

def env59309 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,3630,3612,1540,2049,1037,2194,2185,701,2048,3631,3766,3719,1166,2088,2106,2745,2602,2602,2608,3202,3206,173,169,1212,1213]

theorem envBound59309 : H12AffineFastState.Bounded env59309 := by
  intro p hp
  have h : env59309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59308_59309 : H12AffineEnvironment.transform 12 3612 env59308 = env59309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3612 env59308 == env59309) = true)

theorem identity59309 : scanCanonicalize (H12AffineFastState.compose env59309 (packedSelected [0,1,5,6,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound59309 : packedSelected [0,1,5,6,9,10] rootPS < 2^1333 := by decide +kernel

def env59310 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1077,539,553,1540,1076,1037,1191,1212,701,1077,538,643,690,1166,1053,1039,1676,1567,1567,1541,183,179,173,169,1212,1213]

theorem envBound59310 : H12AffineFastState.Bounded env59310 := by
  intro p hp
  have h : env59310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59309_59310 : H12AffineEnvironment.transform 10 1077 env59309 = env59310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env59309 == env59310) = true)

theorem identity59310 : scanCanonicalize (H12AffineFastState.compose env59310 (packedSelected [1,2,6,7,8,9] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound59310 : packedSelected [1,2,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env59311 : List Nat := [2,4,8,11,32,10,128,172,512,1024,1070,512,553,1540,1071,1037,1191,1191,678,1070,513,643,681,1166,1030,1039,1676,1540,1540,1541,172,168,173,169,1191,1190]

theorem envBound59311 : H12AffineFastState.Bounded env59311 := by
  intro p hp
  have h : env59311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59310_59311 : H12AffineEnvironment.transform 3 11 env59310 = env59311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env59310 == env59311) = true)

theorem identity59311 : scanCanonicalize (H12AffineFastState.compose env59311 (packedSelected [2,5,6,8] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound59311 : packedSelected [2,5,6,8] rootPS < 2^1333 := by decide +kernel

def env59312 : List Nat := [2,4,8,11,32,10,128,172,137,1024,1070,137,160,1165,1071,1037,1191,1191,47,1070,136,10,32,1166,1030,1039,1029,1165,1165,1164,172,168,173,169,1191,1190]

theorem envBound59312 : H12AffineFastState.Bounded env59312 := by
  intro p hp
  have h : env59312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59311_59312 : H12AffineEnvironment.transform 8 137 env59311 = env59312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env59311 == env59312) = true)

theorem identity59312 : scanCanonicalize (H12AffineFastState.compose env59312 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 166) := by decide +kernel

theorem selectedBound59312 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env59313 : List Nat := [2,4,8,11,32,10,128,172,137,166,136,137,160,43,137,171,1,1,47,136,136,10,32,40,160,169,163,43,43,42,172,168,173,169,1,0]

theorem envBound59313 : H12AffineFastState.Bounded env59313 := by
  intro p hp
  have h : env59313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59312_59313 : H12AffineEnvironment.transform 9 166 env59312 = env59313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 166 env59312 == env59313) = true)

theorem identity59313 : scanCanonicalize (H12AffineFastState.compose env59313 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound59313 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env59314 : List Nat := [2,4,8,11,32,10,35,15,42,5,43,42,3,43,42,8,1,1,47,43,43,10,32,40,3,10,0,43,43,42,15,11,14,10,1,0]

theorem envBound59314 : H12AffineFastState.Bounded env59314 := by
  intro p hp
  have h : env59314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59313_59314 : H12AffineEnvironment.transform 6 35 env59313 = env59314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env59313 == env59314) = true)

theorem identity59314 : scanCanonicalize (H12AffineFastState.compose env59314 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound59314 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env59315 : List Nat := [2,2,8,11,32,10,35,9,42,3,43,42,3,43,42,8,1,1,41,43,43,10,32,40,3,10,0,43,43,42,9,11,8,10,1,0]

theorem envBound59315 : H12AffineFastState.Bounded env59315 := by
  intro p hp
  have h : env59315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59314_59315 : H12AffineEnvironment.transform 1 2 env59314 = env59315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env59314 == env59315) = true)

def env59316 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147520,58518,143496,20496,508155,148716,148716,96346,90262,90258,172,222335,1260,135681]

theorem envBound59316 : H12AffineFastState.Bounded env59316 := by
  intro p hp
  have h : env59316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59285_59316 : H12AffineEnvironment.transform 7 173 env59285 = env59316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env59285 == env59316) = true)

def env59317 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61568,147472,58518,143496,20496,508075,148668,148668,96266,90262,90258,172,222255,1212,135681]

theorem envBound59317 : H12AffineFastState.Bounded env59317 := by
  intro p hp
  have h : env59317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59316_59317 : H12AffineEnvironment.transform 5 16 env59316 = env59317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env59316 == env59317) = true)

theorem identity59317 : scanCanonicalize (H12AffineFastState.compose env59317 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 208055) := by decide +kernel

theorem selectedBound59317 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env59318 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,208055,136193,32769,4097,61568,147472,58518,143496,20496,60444,148668,148668,96266,90262,90258,172,222255,1212,135681]

theorem envBound59318 : H12AffineFastState.Bounded env59318 := by
  intro p hp
  have h : env59318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59317_59318 : H12AffineEnvironment.transform 17 208055 env59317 = env59318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 208055 env59317 == env59318) = true)

theorem identity59318 : scanCanonicalize (H12AffineFastState.compose env59318 (packedSelected [1,3,5,7,8,10,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound59318 : packedSelected [1,3,5,7,8,10,20,26,27] rootPS < 2^1333 := by decide +kernel

def env59319 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,53282,131072,195733,136193,32769,4097,61568,147472,58518,143496,20496,60444,148668,148668,43048,45236,45232,172,177165,1212,135681]

theorem envBound59319 : H12AffineFastState.Bounded env59319 := by
  intro p hp
  have h : env59319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59318_59319 : H12AffineEnvironment.transform 15 53282 env59318 = env59319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env59318 == env59319) = true)

theorem identity59319 : scanCanonicalize (H12AffineFastState.compose env59319 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 21693) := by decide +kernel

theorem selectedBound59319 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env59320 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,53282,21693,43048,16572,32769,4097,61568,5293,58518,25653,20496,60444,4097,4097,43048,45236,45232,172,57520,1212,18108]

theorem envBound59320 : H12AffineFastState.Bounded env59320 := by
  intro p hp
  have h : env59320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59319_59320 : H12AffineEnvironment.transform 16 21693 env59319 = env59320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21693 env59319 == env59320) = true)

theorem identity59320 : scanCanonicalize (H12AffineFastState.compose env59320 (packedSelected [4,9,20] rootPS)) = affineNative (2^(14+1) ^^^ 9381) := by decide +kernel

theorem selectedBound59320 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env59321 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,9381,29831,21693,3213,16572,9380,4097,21541,5293,16435,25653,20496,18617,4097,4097,3213,5137,5141,172,17429,1212,18108]

theorem envBound59321 : H12AffineFastState.Bounded env59321 := by
  intro p hp
  have h : env59321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59320_59321 : H12AffineEnvironment.transform 14 9381 env59320 = env59321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9381 env59320 == env59321) = true)

theorem identity59321 : scanCanonicalize (H12AffineFastState.compose env59321 (packedSelected [0,2,3,4,5,6,11,13,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 1700) := by decide +kernel

theorem selectedBound59321 : packedSelected [0,2,3,4,5,6,11,13,16,17] rootPS < 2^1333 := by decide +kernel

def env59322 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,1700,16384,513,21027,21693,3213,16572,512,4097,21541,5293,16435,17041,20496,18617,4097,4097,3213,5137,5141,172,17429,1212,18108]

theorem envBound59322 : H12AffineFastState.Bounded env59322 := by
  intro p hp
  have h : env59322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59321_59322 : H12AffineEnvironment.transform 12 1700 env59321 = env59322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1700 env59321 == env59322) = true)

theorem identity59322 : scanCanonicalize (H12AffineFastState.compose env59322 (packedSelected [1,3,4,6,7,11,13,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 7318) := by decide +kernel

theorem selectedBound59322 : packedSelected [1,3,4,6,7,11,13,15,16] rootPS < 2^1333 := by decide +kernel

def env59323 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,1700,7318,513,3765,2091,3213,7210,512,4097,2227,5293,7333,7687,3206,5167,4097,4097,3213,5137,5141,172,6275,1212,6698]

theorem envBound59323 : H12AffineFastState.Bounded env59323 := by
  intro p hp
  have h : env59323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59322_59323 : H12AffineEnvironment.transform 13 7318 env59322 = env59323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7318 env59322 == env59323) = true)

theorem identity59323 : scanCanonicalize (H12AffineFastState.compose env59323 (packedSelected [0,2,3,5,7,15] rootPS)) = affineNative (2^(10+1) ^^^ 163) := by decide +kernel

theorem selectedBound59323 : packedSelected [0,2,3,5,7,15] rootPS < 2^1333 := by decide +kernel

def env59324 : List Nat := [2,4,8,16,32,16,128,173,512,1024,163,4096,1700,5173,513,1558,136,1070,5257,512,4097,16,5293,5126,5796,1061,5167,4097,4097,1070,5137,5141,172,4128,1212,4745]

theorem envBound59324 : H12AffineFastState.Bounded env59324 := by
  intro p hp
  have h : env59324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59323_59324 : H12AffineEnvironment.transform 10 163 env59323 = env59324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 163 env59323 == env59324) = true)

theorem identity59324 : scanCanonicalize (H12AffineFastState.compose env59324 (packedSelected [2,6,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1164) := by decide +kernel

theorem selectedBound59324 : packedSelected [2,6,7,9] rootPS < 2^1333 := by decide +kernel

def env59325 : List Nat := [2,4,8,16,32,16,128,173,512,1024,163,1164,1700,185,513,1558,136,1070,5,512,1165,16,33,138,552,1061,163,1165,1165,1070,157,153,172,1196,1212,1541]

theorem envBound59325 : H12AffineFastState.Bounded env59325 := by
  intro p hp
  have h : env59325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59324_59325 : H12AffineEnvironment.transform 11 1164 env59324 = env59325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1164 env59324 == env59325) = true)

theorem identity59325 : scanCanonicalize (H12AffineFastState.compose env59325 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(9+1) ^^^ 663) := by decide +kernel

theorem selectedBound59325 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env59326 : List Nat := [2,4,8,16,32,16,128,173,512,663,163,539,51,185,513,129,136,697,5,512,538,16,33,138,552,690,163,538,538,697,157,153,172,571,555,146]

theorem envBound59326 : H12AffineFastState.Bounded env59326 := by
  intro p hp
  have h : env59326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59325_59326 : H12AffineEnvironment.transform 9 663 env59325 = env59326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 663 env59325 == env59326) = true)

theorem identity59326 : scanCanonicalize (H12AffineFastState.compose env59326 (packedSelected [1,2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound59326 : packedSelected [1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env59327 : List Nat := [2,4,8,16,6,16,128,139,512,663,133,539,21,159,513,129,136,671,5,512,538,16,7,138,526,660,133,538,538,671,157,153,138,541,525,146]

theorem envBound59327 : H12AffineFastState.Bounded env59327 := by
  intro p hp
  have h : env59327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59326_59327 : H12AffineEnvironment.transform 4 6 env59326 = env59327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env59326 == env59327) = true)

theorem identity59327 : scanCanonicalize (H12AffineFastState.compose env59327 (packedSelected [4,7] rootPS)) = affineNative (2^(6+1) ^^^ 31) := by decide +kernel

theorem selectedBound59327 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env59328 : List Nat := [2,4,8,16,6,16,31,20,512,520,26,539,21,0,513,30,23,512,5,512,538,16,7,21,526,523,26,538,538,512,2,6,21,541,525,13]

theorem envBound59328 : H12AffineFastState.Bounded env59328 := by
  intro p hp
  have h : env59328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59327_59328 : H12AffineEnvironment.transform 6 31 env59327 = env59328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 31 env59327 == env59328) = true)

theorem identity59328 : scanCanonicalize (H12AffineFastState.compose env59328 (packedSelected [1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 23) := by decide +kernel

theorem selectedBound59328 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env59329 : List Nat := [2,4,8,16,6,16,31,20,23,31,26,12,21,0,22,30,23,23,5,23,13,16,7,21,25,28,26,13,13,23,2,6,21,10,26,13]

theorem envBound59329 : H12AffineFastState.Bounded env59329 := by
  intro p hp
  have h : env59329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59328_59329 : H12AffineEnvironment.transform 8 23 env59328 = env59329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 23 env59328 == env59329) = true)

theorem identity59329 : scanCanonicalize (H12AffineFastState.compose env59329 (packedSelected [1,2] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound59329 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env59330 : List Nat := [2,4,8,7,6,7,8,3,0,8,13,12,2,0,1,9,0,0,5,0,13,7,7,2,14,11,13,13,13,0,2,6,2,10,13,13]

theorem envBound59330 : H12AffineFastState.Bounded env59330 := by
  intro p hp
  have h : env59330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59329_59330 : H12AffineEnvironment.transform 3 7 env59329 = env59330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env59329 == env59330) = true)

def env59331 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61569,147473,58518,143496,20496,508074,148669,148669,96267,90262,90258,172,222254,1213,135681]

theorem envBound59331 : H12AffineFastState.Bounded env59331 := by
  intro p hp
  have h : env59331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59316_59331 : H12AffineEnvironment.transform 5 17 env59316 = env59331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env59316 == env59331) = true)

theorem identity59331 : scanCanonicalize (H12AffineFastState.compose env59331 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 99486) := by decide +kernel

theorem selectedBound59331 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env59332 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,99486,262144,102559,32769,4097,61569,115855,58518,111638,20496,279604,114723,114723,96267,90262,90258,172,57520,1213,104095]

theorem envBound59332 : H12AffineFastState.Bounded env59332 := by
  intro p hp
  have h : env59332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59331_59332 : H12AffineEnvironment.transform 16 99486 env59331 = env59332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 99486 env59331 == env59332) = true)

theorem identity59332 : scanCanonicalize (H12AffineFastState.compose env59332 (packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 12346) := by decide +kernel

theorem selectedBound59332 : packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env59333 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,12346,46244,262144,41125,32769,4097,61569,62645,58518,33836,20496,279604,61465,61465,18481,20652,20648,172,57520,1213,42661]

theorem envBound59333 : H12AffineFastState.Bounded env59333 := by
  intro p hp
  have h : env59333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59332_59333 : H12AffineEnvironment.transform 15 12346 env59332 = env59333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12346 env59332 == env59333) = true)

theorem identity59333 : scanCanonicalize (H12AffineFastState.compose env59333 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 9381) := by decide +kernel

theorem selectedBound59333 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env59334 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,9381,12346,4097,262144,1024,9380,4097,21540,20496,16435,8329,20496,279604,21692,21692,18481,20652,20648,172,17429,1213,512]

theorem envBound59334 : H12AffineFastState.Bounded env59334 := by
  intro p hp
  have h : env59334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59333_59334 : H12AffineEnvironment.transform 14 9381 env59333 = env59334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9381 env59333 == env59334) = true)

theorem identity59334 : scanCanonicalize (H12AffineFastState.compose env59334 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound59334 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59335 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1212,9381,12346,4097,262144,1024,9380,4097,4248,5292,1167,8329,5292,262280,4096,4096,3213,5136,5140,172,169,1213,512]

theorem envBound59335 : H12AffineFastState.Bounded env59335 := by
  intro p hp
  have h : env59335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59334_59335 : H12AffineEnvironment.transform 13 1212 env59334 = env59335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env59334 == env59335) = true)

theorem identity59335 : scanCanonicalize (H12AffineFastState.compose env59335 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 5677) := by decide +kernel

theorem selectedBound59335 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env59336 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,5677,1212,4744,1559,4097,262144,1024,4745,4097,4248,5292,1167,5796,5292,262280,4096,4096,3213,5136,5140,172,169,1213,512]

theorem envBound59336 : H12AffineFastState.Bounded env59336 := by
  intro p hp
  have h : env59336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59335_59336 : H12AffineEnvironment.transform 12 5677 env59335 = env59336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5677 env59335 == env59336) = true)

theorem identity59336 : scanCanonicalize (H12AffineFastState.compose env59336 (packedSelected [1,3,13] rootPS)) = affineNative (2^(17+1) ^^^ 7220) := by decide +kernel

theorem selectedBound59336 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env59337 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,5677,1212,4744,1559,4097,7220,1024,4745,4097,4248,5292,1167,5796,5292,7356,4096,4096,3213,5136,5140,172,169,1213,512]

theorem envBound59337 : H12AffineFastState.Bounded env59337 := by
  intro p hp
  have h : env59337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59336_59337 : H12AffineEnvironment.transform 17 7220 env59336 = env59337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7220 env59336 == env59337) = true)

theorem identity59337 : scanCanonicalize (H12AffineFastState.compose env59337 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 3615) := by decide +kernel

theorem selectedBound59337 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env59338 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,3615,2098,1212,3223,1559,3614,555,1024,3222,3614,3719,2739,1167,2235,2739,675,3615,3615,3213,2575,2571,172,169,1213,512]

theorem envBound59338 : H12AffineFastState.Bounded env59338 := by
  intro p hp
  have h : env59338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59337_59338 : H12AffineEnvironment.transform 11 3615 env59337 = env59338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3615 env59337 == env59338) = true)

theorem identity59338 : scanCanonicalize (H12AffineFastState.compose env59338 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound59338 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env59339 : List Nat := [2,4,8,16,32,17,128,173,512,5,2048,2586,2098,185,2194,530,2587,555,5,2195,2587,2690,2739,138,2235,2739,675,2586,2586,2184,2575,2571,172,169,184,512]

theorem envBound59339 : H12AffineFastState.Bounded env59339 := by
  intro p hp
  have h : env59339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59338_59339 : H12AffineEnvironment.transform 9 5 env59338 = env59339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env59338 == env59339) = true)

theorem identity59339 : scanCanonicalize (H12AffineFastState.compose env59339 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound59339 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59340 : List Nat := [2,4,8,16,32,17,128,173,512,5,513,27,563,185,659,530,26,555,5,658,26,131,178,138,698,178,675,27,27,649,14,10,172,169,184,512]

theorem envBound59340 : H12AffineFastState.Bounded env59340 := by
  intro p hp
  have h : env59340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59339_59340 : H12AffineEnvironment.transform 10 513 env59339 = env59340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env59339 == env59340) = true)

theorem identity59340 : scanCanonicalize (H12AffineFastState.compose env59340 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound59340 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env59341 : List Nat := [2,4,8,16,32,17,57,20,512,5,513,27,563,0,554,530,26,555,5,555,26,58,11,51,515,11,538,27,27,560,14,10,21,16,1,512]

theorem envBound59341 : H12AffineFastState.Bounded env59341 := by
  intro p hp
  have h : env59341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59340_59341 : H12AffineEnvironment.transform 6 57 env59340 = env59341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env59340 == env59341) = true)

theorem identity59341 : scanCanonicalize (H12AffineFastState.compose env59341 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound59341 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59342 : List Nat := [2,4,8,16,7,17,30,20,512,5,513,27,532,0,525,530,26,524,5,524,26,29,11,20,515,11,538,27,27,535,14,10,21,16,1,512]

theorem envBound59342 : H12AffineFastState.Bounded env59342 := by
  intro p hp
  have h : env59342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59341_59342 : H12AffineEnvironment.transform 4 7 env59341 = env59342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env59341 == env59342) = true)

theorem identity59342 : scanCanonicalize (H12AffineFastState.compose env59342 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound59342 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env59343 : List Nat := [2,4,8,16,7,17,30,20,27,5,26,27,15,0,22,9,26,23,5,23,26,29,11,20,24,11,1,27,27,12,14,10,21,16,1,27]

theorem envBound59343 : H12AffineFastState.Bounded env59343 := by
  intro p hp
  have h : env59343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59342_59343 : H12AffineEnvironment.transform 8 27 env59342 = env59343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env59342 == env59343) = true)

theorem identity59343 : scanCanonicalize (H12AffineFastState.compose env59343 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound59343 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env59344 : List Nat := [2,4,8,10,7,11,4,14,1,5,0,1,15,0,12,9,0,13,5,13,0,7,11,14,2,11,1,1,1,12,14,10,15,10,1,1]

theorem envBound59344 : H12AffineFastState.Bounded env59344 := by
  intro p hp
  have h : env59344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59343_59344 : H12AffineEnvironment.transform 3 10 env59343 = env59344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env59343 == env59344) = true)

def env59345 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,533641,672785,17245633,148801,545088,96346,16876544,750911,257,17006917,1344,525824]

theorem envBound59345 : H12AffineFastState.Bounded env59345 := by
  intro p hp
  have h : env59345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59230_59345 : H12AffineEnvironment.transform 26 17245633 env59230 = env59345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env59230 == env59345) = true)

theorem identity59345 : scanCanonicalize (H12AffineFastState.compose env59345 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 41003) := by decide +kernel

theorem selectedBound59345 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env59346 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,41003,533641,672785,493034,148801,545088,96346,74795,750911,257,205166,1344,525824]

theorem envBound59346 : H12AffineFastState.Bounded env59346 := by
  intro p hp
  have h : env59346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59345_59346 : H12AffineEnvironment.transform 23 41003 env59345 = env59346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41003 env59345 == env59346) = true)

def env59347 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147520,41003,143497,20497,493034,148801,148800,96346,74795,90431,257,205166,1344,135680]

theorem envBound59347 : H12AffineFastState.Bounded env59347 := by
  intro p hp
  have h : env59347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59346_59347 : H12AffineEnvironment.transform 18 136192 env59346 = env59347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env59346 == env59347) = true)

def env59348 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147520,41003,143497,20497,492614,148717,148716,96346,74795,90259,173,204994,1260,135680]

theorem envBound59348 : H12AffineFastState.Bounded env59348 := by
  intro p hp
  have h : env59348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart2