import H12CloudChart2Data058

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity14423 : scanCanonicalize (H12AffineFastState.compose env14423 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound14423 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14424 : List Nat := [2,4,8,16,32,16,128,256,137,272,2048,0,269,1,2081,65536,0,260,273,2080,0,2048,17,67876,389,16,2049,1,1,261,21,2184,257,67846,1,137]

theorem envBound14424 : H12AffineFastState.Bounded env14424 := by
  intro p hp
  have h : env14424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14423_14424 : H12AffineEnvironment.transform 12 269 env14423 = env14424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env14423 == env14424) = true)

def env14425 : List Nat := [2,4,8,16,32,16,128,256,137,272,32,0,269,1,1,65536,0,260,273,0,0,32,17,65796,389,16,33,1,1,261,21,168,257,65830,1,137]

theorem envBound14425 : H12AffineFastState.Bounded env14425 := by
  intro p hp
  have h : env14425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14424_14425 : H12AffineEnvironment.transform 10 32 env14424 = env14425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env14424 == env14425) = true)

def env14426 : List Nat := [2,4,8,16,32,16,128,256,137,272,33,0,269,1,0,65536,0,260,273,1,0,33,17,65797,389,16,32,1,1,261,21,169,257,65831,1,137]

theorem envBound14426 : H12AffineFastState.Bounded env14426 := by
  intro p hp
  have h : env14426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14424_14426 : H12AffineEnvironment.transform 10 33 env14424 = env14426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env14424 == env14426) = true)

theorem identity14426 : scanCanonicalize (H12AffineFastState.compose env14426 (packedSelected [0,4] rootPS)) = affineNative (2^(15+1) ^^^ 398) := by decide +kernel

theorem selectedBound14426 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env14427 : List Nat := [2,4,8,16,32,16,128,256,137,272,33,0,269,1,0,398,0,260,273,1,0,33,17,139,389,16,32,1,1,261,21,169,257,169,1,137]

theorem envBound14427 : H12AffineFastState.Bounded env14427 := by
  intro p hp
  have h : env14427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14426_14427 : H12AffineEnvironment.transform 15 398 env14426 = env14427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 398 env14426 == env14427) = true)

theorem identity14427 : scanCanonicalize (H12AffineFastState.compose env14427 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound14427 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14428 : List Nat := [2,4,8,16,32,16,128,21,137,5,33,0,24,1,0,155,0,17,4,1,0,33,17,139,144,16,32,1,1,16,21,169,20,169,1,137]

theorem envBound14428 : H12AffineFastState.Bounded env14428 := by
  intro p hp
  have h : env14428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14427_14428 : H12AffineEnvironment.transform 7 21 env14427 = env14428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env14427 == env14428) = true)

def env14429 : List Nat := [2,4,8,16,0,16,128,21,137,5,1,0,24,1,0,155,0,17,4,1,0,1,17,139,144,16,0,1,1,16,21,137,20,137,1,137]

theorem envBound14429 : H12AffineFastState.Bounded env14429 := by
  intro p hp
  have h : env14429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14428_14429 : H12AffineEnvironment.transform 4 0 env14428 = env14429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14428 == env14429) = true)

theorem identity14429 : scanCanonicalize (H12AffineFastState.compose env14429 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound14429 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14430 : List Nat := [2,4,8,0,0,0,128,5,137,5,1,0,8,1,0,139,0,1,4,1,0,1,1,139,128,0,0,1,1,0,5,137,4,137,1,137]

theorem envBound14430 : H12AffineFastState.Bounded env14430 := by
  intro p hp
  have h : env14430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14429_14430 : H12AffineEnvironment.transform 3 0 env14429 = env14430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env14429 == env14430) = true)

def leafEnv14430 : List Nat := [2,4,8,0,0,0,128,5,137,5,1,0,8,1,0,139,0,1,4,1,0,1,1,139,5,128,1,0,0,1,1,0,5,137,4,137,4,2,1,137,0,0,1]

def active14430 : List Nat := [0,1,2,6]

def tree14430 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14430 : H12WitnessSearch.Good tree14430 := H12GlobalWitnessIndex.good

theorem leafIdentity14430 : H12AffineFastState.composeSystem env14430 rootObs = leafEnv14430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14430 rootObs == leafEnv14430) = true)

theorem terminalChecked14430 : H12PackedTerminal.terminalCheckFast leafEnv14430 active14430 tree14430 = true := by decide +kernel

def env14431 : List Nat := [2,4,8,16,1,16,128,21,137,5,0,0,24,1,0,155,0,17,4,1,0,0,17,139,144,16,1,1,1,16,21,136,20,136,1,137]

theorem envBound14431 : H12AffineFastState.Bounded env14431 := by
  intro p hp
  have h : env14431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14428_14431 : H12AffineEnvironment.transform 4 1 env14428 = env14431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14428 == env14431) = true)

def leafEnv14431 : List Nat := [2,4,8,16,1,16,128,21,137,5,0,0,24,1,0,155,0,17,4,1,0,0,17,139,21,144,1,16,1,1,1,16,21,136,20,136,4,18,1,137,0,0,1]

def active14431 : List Nat := [0,1,2,3,6]

def tree14431 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14431 : H12WitnessSearch.Good tree14431 := H12GlobalWitnessIndex.good

theorem leafIdentity14431 : H12AffineFastState.composeSystem env14431 rootObs = leafEnv14431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14431 rootObs == leafEnv14431) = true)

theorem terminalChecked14431 : H12PackedTerminal.terminalCheckFast leafEnv14431 active14431 tree14431 = true := by decide +kernel

def env14432 : List Nat := [2,4,8,16,32,16,128,256,137,273,2048,1,8192,0,2081,65536,1,8201,272,2080,1,10509,17,67876,8328,16,2049,0,0,8200,20,10629,257,67846,0,137]

theorem envBound14432 : H12AffineFastState.Bounded env14432 := by
  intro p hp
  have h : env14432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14422_14432 : H12AffineEnvironment.transform 9 273 env14422 = env14432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env14422 == env14432) = true)

theorem identity14432 : scanCanonicalize (H12AffineFastState.compose env14432 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 10402) := by decide +kernel

theorem selectedBound14432 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14433 : List Nat := [2,4,8,16,32,16,128,256,137,273,2048,1,8192,0,2081,10402,1,8201,272,2080,1,10509,17,8582,8328,16,2049,0,0,8200,20,10629,257,8612,0,137]

theorem envBound14433 : H12AffineFastState.Bounded env14433 := by
  intro p hp
  have h : env14433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14432_14433 : H12AffineEnvironment.transform 15 10402 env14432 = env14433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 10402 env14432 == env14433) = true)

def env14434 : List Nat := [2,4,8,16,32,16,128,256,137,273,168,1,8192,0,137,8202,1,8201,272,136,1,8613,17,8582,8328,16,169,0,0,8200,20,8493,257,8612,0,137]

theorem envBound14434 : H12AffineFastState.Bounded env14434 := by
  intro p hp
  have h : env14434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14433_14434 : H12AffineEnvironment.transform 10 168 env14433 = env14434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 168 env14433 == env14434) = true)

def env14435 : List Nat := [2,4,8,16,32,16,128,256,137,273,168,1,128,0,137,138,1,137,272,136,1,293,17,262,8,16,169,0,0,136,20,429,257,292,0,137]

theorem envBound14435 : H12AffineFastState.Bounded env14435 := by
  intro p hp
  have h : env14435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14434_14435 : H12AffineEnvironment.transform 12 128 env14434 = env14435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 128 env14434 == env14435) = true)

theorem identity14435 : scanCanonicalize (H12AffineFastState.compose env14435 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound14435 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14436 : List Nat := [2,4,8,16,32,16,56,256,49,273,16,1,56,0,49,50,1,49,272,48,1,293,17,262,8,16,17,0,0,48,20,277,257,292,0,49]

theorem envBound14436 : H12AffineFastState.Bounded env14436 := by
  intro p hp
  have h : env14436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14435_14436 : H12AffineEnvironment.transform 6 56 env14435 = env14436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env14435 == env14436) = true)

def env14437 : List Nat := [2,4,8,16,0,16,24,256,17,273,16,1,24,0,17,18,1,17,272,16,1,261,17,262,8,16,17,0,0,16,20,277,257,260,0,17]

theorem envBound14437 : H12AffineFastState.Bounded env14437 := by
  intro p hp
  have h : env14437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14436_14437 : H12AffineEnvironment.transform 4 0 env14436 = env14437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14436 == env14437) = true)

def env14438 : List Nat := [2,4,8,0,0,0,8,256,1,257,0,1,8,0,1,2,1,1,256,0,1,261,1,262,8,0,1,0,0,0,4,261,257,260,0,1]

theorem envBound14438 : H12AffineFastState.Bounded env14438 := by
  intro p hp
  have h : env14438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14437_14438 : H12AffineEnvironment.transform 3 0 env14437 = env14438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env14437 == env14438) = true)

theorem identity14438 : scanCanonicalize (H12AffineFastState.compose env14438 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound14438 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14439 : List Nat := [2,4,8,0,0,0,8,5,1,4,0,1,8,0,1,2,1,1,5,0,1,0,1,3,8,0,1,0,0,0,4,0,4,1,0,1]

theorem envBound14439 : H12AffineFastState.Bounded env14439 := by
  intro p hp
  have h : env14439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14438_14439 : H12AffineEnvironment.transform 7 5 env14438 = env14439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env14438 == env14439) = true)

def leafEnv14439 : List Nat := [2,4,8,0,0,0,8,5,1,4,0,1,8,0,1,2,1,1,5,0,1,0,1,3,4,8,1,0,1,0,0,0,4,0,4,1,4,3,0,1,0,1,1]

def active14439 : List Nat := [0,1,2]

def tree14439 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14439 : H12WitnessSearch.Good tree14439 := H12GlobalWitnessIndex.good

theorem leafIdentity14439 : H12AffineFastState.composeSystem env14439 rootObs = leafEnv14439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14439 rootObs == leafEnv14439) = true)

theorem terminalChecked14439 : H12PackedTerminal.terminalCheckFast leafEnv14439 active14439 tree14439 = true := by decide +kernel

def env14440 : List Nat := [2,4,8,1,0,1,9,256,0,256,1,1,9,0,0,3,1,0,257,1,1,261,0,262,8,1,0,0,0,1,5,260,257,260,0,0]

theorem envBound14440 : H12AffineFastState.Bounded env14440 := by
  intro p hp
  have h : env14440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14437_14440 : H12AffineEnvironment.transform 3 1 env14437 = env14440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env14437 == env14440) = true)

def env14441 : List Nat := [2,4,8,16,1,16,25,256,16,273,16,1,25,0,16,19,1,16,272,17,1,260,17,262,8,16,17,0,0,17,20,277,257,261,0,16]

theorem envBound14441 : H12AffineFastState.Bounded env14441 := by
  intro p hp
  have h : env14441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14436_14441 : H12AffineEnvironment.transform 4 1 env14436 = env14441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14436 == env14441) = true)

theorem identity14441 : scanCanonicalize (H12AffineFastState.compose env14441 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound14441 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14442 : List Nat := [2,4,8,16,1,16,25,5,16,20,16,1,25,0,16,19,1,16,21,17,1,1,17,3,8,16,17,0,0,17,20,16,4,0,0,16]

theorem envBound14442 : H12AffineFastState.Bounded env14442 := by
  intro p hp
  have h : env14442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14441_14442 : H12AffineEnvironment.transform 7 5 env14441 = env14442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env14441 == env14442) = true)

theorem identity14442 : scanCanonicalize (H12AffineFastState.compose env14442 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound14442 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14443 : List Nat := [2,4,8,1,1,1,8,5,1,5,1,1,8,0,1,2,1,1,4,0,1,1,0,3,8,1,0,0,0,0,5,1,4,0,0,1]

theorem envBound14443 : H12AffineFastState.Bounded env14443 := by
  intro p hp
  have h : env14443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14442_14443 : H12AffineEnvironment.transform 3 1 env14442 = env14443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env14442 == env14443) = true)

def leafEnv14443 : List Nat := [2,4,8,1,1,1,8,5,1,5,1,1,8,0,1,2,1,1,4,0,1,1,0,3,5,8,1,1,0,0,0,0,5,1,4,0,4,3,0,1,0,1,1]

def active14443 : List Nat := [0,1,2]

def tree14443 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14443 : H12WitnessSearch.Good tree14443 := H12GlobalWitnessIndex.good

theorem leafIdentity14443 : H12AffineFastState.composeSystem env14443 rootObs = leafEnv14443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14443 rootObs == leafEnv14443) = true)

theorem terminalChecked14443 : H12PackedTerminal.terminalCheckFast leafEnv14443 active14443 tree14443 = true := by decide +kernel

def env14444 : List Nat := [2,4,8,16,32,16,128,256,137,273,168,1,129,0,137,139,1,136,272,136,1,292,17,263,9,16,169,0,0,137,20,428,257,293,0,137]

theorem envBound14444 : H12AffineFastState.Bounded env14444 := by
  intro p hp
  have h : env14444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14434_14444 : H12AffineEnvironment.transform 12 129 env14434 = env14444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 129 env14434 == env14444) = true)

theorem identity14444 : scanCanonicalize (H12AffineFastState.compose env14444 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound14444 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14445 : List Nat := [2,4,8,16,32,16,24,256,17,273,48,1,25,0,17,19,1,16,272,16,1,292,17,263,9,16,49,0,0,17,20,308,257,293,0,17]

theorem envBound14445 : H12AffineFastState.Bounded env14445 := by
  intro p hp
  have h : env14445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14444_14445 : H12AffineEnvironment.transform 6 24 env14444 = env14445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env14444 == env14445) = true)

def env14446 : List Nat := [2,4,8,16,0,16,24,256,17,273,16,1,25,0,17,19,1,16,272,16,1,260,17,263,9,16,17,0,0,17,20,276,257,261,0,17]

theorem envBound14446 : H12AffineFastState.Bounded env14446 := by
  intro p hp
  have h : env14446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14445_14446 : H12AffineEnvironment.transform 4 0 env14445 = env14446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14445 == env14446) = true)

theorem identity14446 : scanCanonicalize (H12AffineFastState.compose env14446 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound14446 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14447 : List Nat := [2,4,8,0,0,0,8,256,1,257,0,1,9,0,1,3,1,0,256,0,1,260,1,263,9,0,1,0,0,1,4,260,257,261,0,1]

theorem envBound14447 : H12AffineFastState.Bounded env14447 := by
  intro p hp
  have h : env14447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14446_14447 : H12AffineEnvironment.transform 3 0 env14446 = env14447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env14446 == env14447) = true)

theorem identity14447 : scanCanonicalize (H12AffineFastState.compose env14447 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound14447 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14448 : List Nat := [2,4,8,0,0,0,8,4,1,5,0,1,9,0,1,3,1,0,4,0,1,0,1,3,9,0,1,0,0,1,4,0,5,1,0,1]

theorem envBound14448 : H12AffineFastState.Bounded env14448 := by
  intro p hp
  have h : env14448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14447_14448 : H12AffineEnvironment.transform 7 4 env14447 = env14448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env14447 == env14448) = true)

def leafEnv14448 : List Nat := [2,4,8,0,0,0,8,4,1,5,0,1,9,0,1,3,1,0,4,0,1,0,1,3,4,9,1,0,1,0,0,1,4,0,5,1,4,2,0,1,0,1,1]

def active14448 : List Nat := [0,1,2]

def tree14448 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14448 : H12WitnessSearch.Good tree14448 := H12GlobalWitnessIndex.good

theorem leafIdentity14448 : H12AffineFastState.composeSystem env14448 rootObs = leafEnv14448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14448 rootObs == leafEnv14448) = true)

theorem terminalChecked14448 : H12PackedTerminal.terminalCheckFast leafEnv14448 active14448 tree14448 = true := by decide +kernel

def env14449 : List Nat := [2,4,8,16,1,16,24,256,17,273,17,1,25,0,17,19,1,16,272,16,1,261,17,263,9,16,16,0,0,17,20,277,257,260,0,17]

theorem envBound14449 : H12AffineFastState.Bounded env14449 := by
  intro p hp
  have h : env14449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14445_14449 : H12AffineEnvironment.transform 4 1 env14445 = env14449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14445 == env14449) = true)

theorem identity14449 : scanCanonicalize (H12AffineFastState.compose env14449 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound14449 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14450 : List Nat := [2,4,8,16,1,16,24,21,17,4,17,1,25,0,17,19,1,16,5,16,1,16,17,18,9,16,16,0,0,17,20,0,20,17,0,17]

theorem envBound14450 : H12AffineFastState.Bounded env14450 := by
  intro p hp
  have h : env14450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14449_14450 : H12AffineEnvironment.transform 7 21 env14449 = env14450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env14449 == env14450) = true)

def env14451 : List Nat := [2,4,8,16,32,16,128,256,137,273,169,1,8192,0,136,8203,1,8201,272,137,1,8612,17,8582,8328,16,168,0,0,8200,20,8492,257,8612,0,137]

theorem envBound14451 : H12AffineFastState.Bounded env14451 := by
  intro p hp
  have h : env14451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14433_14451 : H12AffineEnvironment.transform 10 169 env14433 = env14451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 169 env14433 == env14451) = true)

def env14452 : List Nat := [2,4,8,16,32,16,128,256,137,273,169,1,128,0,136,139,1,137,272,137,1,292,17,262,8,16,168,0,0,136,20,428,257,292,0,137]

theorem envBound14452 : H12AffineFastState.Bounded env14452 := by
  intro p hp
  have h : env14452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14451_14452 : H12AffineEnvironment.transform 12 128 env14451 = env14452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 128 env14451 == env14452) = true)

theorem identity14452 : scanCanonicalize (H12AffineFastState.compose env14452 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 156) := by decide +kernel

theorem selectedBound14452 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14453 : List Nat := [2,4,8,16,32,16,128,156,137,141,169,1,128,0,136,139,1,137,140,137,1,184,17,154,8,16,168,0,0,136,20,48,157,184,0,137]

theorem envBound14453 : H12AffineFastState.Bounded env14453 := by
  intro p hp
  have h : env14453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14452_14453 : H12AffineEnvironment.transform 7 156 env14452 = env14453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 156 env14452 == env14453) = true)

def env14454 : List Nat := [2,4,8,16,0,16,128,156,137,141,137,1,128,0,136,139,1,137,140,137,1,152,17,154,8,16,136,0,0,136,20,16,157,152,0,137]

theorem envBound14454 : H12AffineFastState.Bounded env14454 := by
  intro p hp
  have h : env14454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14453_14454 : H12AffineEnvironment.transform 4 0 env14453 = env14454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14453 == env14454) = true)

theorem identity14454 : scanCanonicalize (H12AffineFastState.compose env14454 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound14454 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14455 : List Nat := [2,4,8,16,0,16,9,21,0,4,0,1,9,0,1,2,1,0,5,0,1,17,17,19,8,16,1,0,0,1,20,16,20,17,0,0]

theorem envBound14455 : H12AffineFastState.Bounded env14455 := by
  intro p hp
  have h : env14455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14454_14455 : H12AffineEnvironment.transform 6 9 env14454 = env14455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14454 == env14455) = true)

theorem identity14455 : scanCanonicalize (H12AffineFastState.compose env14455 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound14455 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14456 : List Nat := [2,4,8,1,0,1,9,4,0,4,0,1,9,0,1,2,1,0,5,0,1,0,0,2,8,1,1,0,0,1,5,1,5,0,0,0]

theorem envBound14456 : H12AffineFastState.Bounded env14456 := by
  intro p hp
  have h : env14456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14455_14456 : H12AffineEnvironment.transform 3 1 env14455 = env14456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env14455 == env14456) = true)

def leafEnv14456 : List Nat := [2,4,8,1,0,1,9,4,0,4,0,1,9,0,1,2,1,0,5,0,1,0,0,2,5,8,1,1,1,0,0,1,5,1,5,0,4,2,0,0,0,1,1]

def active14456 : List Nat := [0,1,2]

def tree14456 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14456 : H12WitnessSearch.Good tree14456 := H12GlobalWitnessIndex.good

theorem leafIdentity14456 : H12AffineFastState.composeSystem env14456 rootObs = leafEnv14456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14456 rootObs == leafEnv14456) = true)

theorem terminalChecked14456 : H12PackedTerminal.terminalCheckFast leafEnv14456 active14456 tree14456 = true := by decide +kernel

def env14457 : List Nat := [2,4,8,16,1,16,128,156,137,141,136,1,128,0,136,139,1,137,140,137,1,153,17,154,8,16,137,0,0,136,20,17,157,153,0,137]

theorem envBound14457 : H12AffineFastState.Bounded env14457 := by
  intro p hp
  have h : env14457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14453_14457 : H12AffineEnvironment.transform 4 1 env14453 = env14457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14453 == env14457) = true)

theorem identity14457 : scanCanonicalize (H12AffineFastState.compose env14457 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound14457 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14458 : List Nat := [2,4,8,0,1,0,128,140,137,141,136,1,128,0,136,139,1,137,140,137,1,137,1,138,8,0,137,0,0,136,4,1,141,137,0,137]

theorem envBound14458 : H12AffineFastState.Bounded env14458 := by
  intro p hp
  have h : env14458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14457_14458 : H12AffineEnvironment.transform 3 0 env14457 = env14458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env14457 == env14458) = true)

def env14459 : List Nat := [2,4,8,16,32,16,128,256,137,273,169,1,129,0,136,138,1,136,272,137,1,293,17,263,9,16,168,0,0,137,20,429,257,293,0,137]

theorem envBound14459 : H12AffineFastState.Bounded env14459 := by
  intro p hp
  have h : env14459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14451_14459 : H12AffineEnvironment.transform 12 129 env14451 = env14459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 129 env14451 == env14459) = true)

theorem identity14459 : scanCanonicalize (H12AffineFastState.compose env14459 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 189) := by decide +kernel

theorem selectedBound14459 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14460 : List Nat := [2,4,8,16,32,16,128,189,137,172,169,1,129,0,136,138,1,136,173,137,1,152,17,186,9,16,168,0,0,137,20,16,188,152,0,137]

theorem envBound14460 : H12AffineFastState.Bounded env14460 := by
  intro p hp
  have h : env14460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14459_14460 : H12AffineEnvironment.transform 7 189 env14459 = env14460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 189 env14459 == env14460) = true)

def env14461 : List Nat := [2,4,8,16,0,16,128,157,137,140,137,1,129,0,136,138,1,136,141,137,1,152,17,154,9,16,136,0,0,137,20,16,156,152,0,137]

theorem envBound14461 : H12AffineFastState.Bounded env14461 := by
  intro p hp
  have h : env14461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14460_14461 : H12AffineEnvironment.transform 4 0 env14460 = env14461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14460 == env14461) = true)

def env14462 : List Nat := [2,4,8,0,0,0,128,141,137,140,137,1,129,0,136,138,1,136,141,137,1,136,1,138,9,0,136,0,0,137,4,0,140,136,0,137]

theorem envBound14462 : H12AffineFastState.Bounded env14462 := by
  intro p hp
  have h : env14462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14461_14462 : H12AffineEnvironment.transform 3 0 env14461 = env14462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env14461 == env14462) = true)

def env14463 : List Nat := [2,4,8,1,0,1,128,140,137,140,137,1,129,0,136,138,1,136,141,137,1,137,0,139,9,1,136,0,0,137,5,1,141,137,0,137]

theorem envBound14463 : H12AffineFastState.Bounded env14463 := by
  intro p hp
  have h : env14463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14461_14463 : H12AffineEnvironment.transform 3 1 env14461 = env14463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env14461 == env14463) = true)

theorem identity14463 : scanCanonicalize (H12AffineFastState.compose env14463 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound14463 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14464 : List Nat := [2,4,8,1,0,1,9,5,0,5,0,1,8,0,1,3,1,1,4,0,1,0,0,2,9,1,1,0,0,0,5,1,4,0,0,0]

theorem envBound14464 : H12AffineFastState.Bounded env14464 := by
  intro p hp
  have h : env14464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14463_14464 : H12AffineEnvironment.transform 6 9 env14463 = env14464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14463 == env14464) = true)

def leafEnv14464 : List Nat := [2,4,8,1,0,1,9,5,0,5,0,1,8,0,1,3,1,1,4,0,1,0,0,2,5,9,1,1,1,0,0,0,5,1,4,0,4,3,0,0,0,1,1]

def active14464 : List Nat := [0,1,2]

def tree14464 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14464 : H12WitnessSearch.Good tree14464 := H12GlobalWitnessIndex.good

theorem leafIdentity14464 : H12AffineFastState.composeSystem env14464 rootObs = leafEnv14464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14464 rootObs == leafEnv14464) = true)

theorem terminalChecked14464 : H12PackedTerminal.terminalCheckFast leafEnv14464 active14464 tree14464 = true := by decide +kernel

def env14465 : List Nat := [2,4,8,16,1,16,128,156,137,141,136,1,129,0,136,138,1,136,140,137,1,152,17,155,9,16,137,0,0,137,20,16,157,152,0,137]

theorem envBound14465 : H12AffineFastState.Bounded env14465 := by
  intro p hp
  have h : env14465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14460_14465 : H12AffineEnvironment.transform 4 1 env14460 = env14465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14460 == env14465) = true)

theorem identity14465 : scanCanonicalize (H12AffineFastState.compose env14465 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound14465 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14466 : List Nat := [2,4,8,16,1,16,25,5,16,20,17,1,24,0,17,19,1,17,21,16,1,1,17,2,9,16,16,0,0,16,20,16,4,1,0,16]

theorem envBound14466 : H12AffineFastState.Bounded env14466 := by
  intro p hp
  have h : env14466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14465_14466 : H12AffineEnvironment.transform 6 25 env14465 = env14466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env14465 == env14466) = true)

theorem identity14466 : scanCanonicalize (H12AffineFastState.compose env14466 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound14466 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14467 : List Nat := [2,4,8,0,1,0,9,5,0,4,1,1,8,0,1,3,1,1,5,0,1,1,1,2,9,0,0,0,0,0,4,0,4,1,0,0]

theorem envBound14467 : H12AffineFastState.Bounded env14467 := by
  intro p hp
  have h : env14467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14466_14467 : H12AffineEnvironment.transform 3 0 env14466 = env14467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env14466 == env14467) = true)

def leafEnv14467 : List Nat := [2,4,8,0,1,0,9,5,0,4,1,1,8,0,1,3,1,1,5,0,1,1,1,2,4,9,1,0,0,0,0,0,4,0,4,1,4,3,0,0,0,1,1]

def active14467 : List Nat := [0,1,2]

def tree14467 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14467 : H12WitnessSearch.Good tree14467 := H12GlobalWitnessIndex.good

theorem leafIdentity14467 : H12AffineFastState.composeSystem env14467 rootObs = leafEnv14467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14467 rootObs == leafEnv14467) = true)

theorem terminalChecked14467 : H12PackedTerminal.terminalCheckFast leafEnv14467 active14467 tree14467 = true := by decide +kernel

def env14468 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1297,8192,1297,2081,65536,1297,8201,1025,2080,1297,4194304,17,67876,8328,17,4202764,1297,1297,4196613,1285,4194440,257,67846,1296,137]

theorem envBound14468 : H12AffineFastState.Bounded env14468 := by
  intro p hp
  have h : env14468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14420_14468 : H12AffineEnvironment.transform 5 17 env14420 = env14468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14420 == env14468) = true)

theorem identity14468 : scanCanonicalize (H12AffineFastState.compose env14468 (packedSelected [1,3] rootPS)) = affineNative (2^(21+1) ^^^ 67754) := by decide +kernel

theorem selectedBound14468 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14469 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1297,8192,1297,2081,65536,1297,8201,1025,2080,1297,67754,17,67876,8328,17,76198,1297,1297,65967,1285,67618,257,67846,1296,137]

theorem envBound14469 : H12AffineFastState.Bounded env14469 := by
  intro p hp
  have h : env14469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14468_14469 : H12AffineEnvironment.transform 21 67754 env14468 = env14469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 67754 env14468 == env14469) = true)

theorem identity14469 : scanCanonicalize (H12AffineFastState.compose env14469 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 2056) := by decide +kernel

theorem selectedBound14469 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env14470 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1297,2056,1297,2081,65536,1297,2049,1025,2080,1297,67754,17,67876,2176,17,65966,1297,1297,65967,1285,67618,257,67846,1296,137]

theorem envBound14470 : H12AffineFastState.Bounded env14470 := by
  intro p hp
  have h : env14470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14469_14470 : H12AffineEnvironment.transform 12 2056 env14469 = env14470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2056 env14469 == env14470) = true)

theorem identity14470 : scanCanonicalize (H12AffineFastState.compose env14470 (packedSelected [0,6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound14470 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env14471 : List Nat := [2,4,8,16,32,17,128,4,137,1024,2048,1045,2056,1045,2081,65536,1045,2049,1025,2080,1045,67754,17,67616,2176,17,65706,1045,1045,65707,1025,67618,5,67586,1044,137]

theorem envBound14471 : H12AffineFastState.Bounded env14471 := by
  intro p hp
  have h : env14471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14470_14471 : H12AffineEnvironment.transform 7 4 env14470 = env14471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env14470 == env14471) = true)

theorem identity14471 : scanCanonicalize (H12AffineFastState.compose env14471 (packedSelected [0,7] rootPS)) = affineNative (2^(15+1) ^^^ 2218) := by decide +kernel

theorem selectedBound14471 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env14472 : List Nat := [2,4,8,16,32,17,128,4,137,1024,2048,1045,2056,1045,2081,2218,1045,2049,1025,2080,1045,0,17,138,2176,17,2048,1045,1045,2049,1025,136,5,168,1044,137]

theorem envBound14472 : H12AffineFastState.Bounded env14472 := by
  intro p hp
  have h : env14472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14471_14472 : H12AffineEnvironment.transform 15 2218 env14471 = env14472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2218 env14471 == env14472) = true)

theorem identity14472 : scanCanonicalize (H12AffineFastState.compose env14472 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1180) := by decide +kernel

theorem selectedBound14472 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14473 : List Nat := [2,4,8,16,32,17,128,4,137,1024,1180,1045,1172,1045,1213,1078,1045,1181,1025,1212,1045,0,17,138,1052,17,1180,1045,1045,1181,1025,136,5,168,1044,137]

theorem envBound14473 : H12AffineFastState.Bounded env14473 := by
  intro p hp
  have h : env14473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14472_14473 : H12AffineEnvironment.transform 10 1180 env14472 = env14473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1180 env14472 == env14473) = true)

def env14474 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,65536,1344,262144,524288,32769,1345,4194304,525328,623876,8328,64,4456709,524560,524561,1073741824,1285,4294967296,525568,4299785646,524608,512]

theorem envBound14474 : H12AffineFastState.Bounded env14474 := by
  intro p hp
  have h : env14474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14408_14474 : H12AffineEnvironment.transform 11 1345 env14408 = env14474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env14408 == env14474) = true)

theorem identity14474 : scanCanonicalize (H12AffineFastState.compose env14474 (packedSelected [3,5,10] rootPS)) = affineNative (2^(31+1) ^^^ 1078504609) := by decide +kernel

theorem selectedBound14474 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env14475 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,65536,1344,262144,524288,32769,1345,4194304,525328,623876,8328,64,4456709,524560,524561,1073741824,1285,1078504609,525568,1073817871,524608,512]

theorem envBound14475 : H12AffineFastState.Bounded env14475 := by
  intro p hp
  have h : env14475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14474_14475 : H12AffineEnvironment.transform 31 1078504609 env14474 = env14475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1078504609 env14474 == env14475) = true)

theorem identity14475 : scanCanonicalize (H12AffineFastState.compose env14475 (packedSelected [0,7,20] rootPS)) = affineNative (2^(18+1) ^^^ 1105) := by decide +kernel

theorem selectedBound14475 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env14476 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,65536,1344,262144,1105,32769,1345,4194304,65,98645,8328,64,4456709,1345,1344,1073741824,1285,1077979376,337,1073817871,1297,512]

theorem envBound14476 : H12AffineFastState.Bounded env14476 := by
  intro p hp
  have h : env14476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14475_14476 : H12AffineEnvironment.transform 18 1105 env14475 = env14476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1105 env14475 == env14476) = true)

def env14477 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,8192,81,32768,65536,0,262144,273,32769,1,4194304,65,98645,8328,64,4456709,1,0,1073741824,69,1077979376,337,1073817871,81,512]

theorem envBound14477 : H12AffineFastState.Bounded env14477 := by
  intro p hp
  have h : env14477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14476_14477 : H12AffineEnvironment.transform 9 320 env14476 = env14477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env14476 == env14477) = true)

theorem identity14477 : scanCanonicalize (H12AffineFastState.compose env14477 (packedSelected [12] rootPS)) = affineNative (2^(21+1) ^^^ 362714) := by decide +kernel

theorem selectedBound14477 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env14478 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,8192,81,32768,65536,0,262144,273,32769,1,362714,65,98645,8328,64,100831,1,0,1073741824,69,1074077738,337,1073817871,81,512]

theorem envBound14478 : H12AffineFastState.Bounded env14478 := by
  intro p hp
  have h : env14478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14477_14478 : H12AffineEnvironment.transform 21 362714 env14477 = env14478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 362714 env14477 == env14478) = true)

theorem identity14478 : scanCanonicalize (H12AffineFastState.compose env14478 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(29+1) ^^^ 262145) := by decide +kernel

theorem selectedBound14478 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env14479 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,8192,81,32768,65536,0,262144,273,32769,1,362714,65,98645,8328,64,100831,1,0,262145,69,73771,337,338190,81,512]

theorem envBound14479 : H12AffineFastState.Bounded env14479 := by
  intro p hp
  have h : env14479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14478_14479 : H12AffineEnvironment.transform 29 262145 env14478 = env14479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 262145 env14478 == env14479) = true)

theorem identity14479 : scanCanonicalize (H12AffineFastState.compose env14479 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 76198) := by decide +kernel

theorem selectedBound14479 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env14480 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,8192,81,32768,65536,0,76198,273,32769,1,41340,65,98645,8328,64,100831,1,0,76199,69,73771,337,168,81,512]

theorem envBound14480 : H12AffineFastState.Bounded env14480 := by
  intro p hp
  have h : env14480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14479_14480 : H12AffineEnvironment.transform 17 76198 env14479 = env14480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76198 env14479 == env14480) = true)

theorem identity14480 : scanCanonicalize (H12AffineFastState.compose env14480 (packedSelected [15] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound14480 : packedSelected [15] rootPS < 2^1333 := by decide +kernel

def env14481 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,8192,81,32768,33246,0,43128,273,32769,1,41340,65,139,8328,64,2049,1,0,43129,69,41461,337,168,81,512]

theorem envBound14481 : H12AffineFastState.Bounded env14481 := by
  intro p hp
  have h : env14481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14480_14481 : H12AffineEnvironment.transform 15 33246 env14480 = env14481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env14480 == env14481) = true)

theorem identity14481 : scanCanonicalize (H12AffineFastState.compose env14481 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 217) := by decide +kernel

theorem selectedBound14481 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env14482 : List Nat := [2,4,8,16,32,64,128,256,217,320,2048,1,8192,81,32768,33246,0,43128,273,32769,1,41340,65,139,8328,64,2049,1,0,43129,69,41461,337,168,81,217]

theorem envBound14482 : H12AffineFastState.Bounded env14482 := by
  intro p hp
  have h : env14482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14481_14482 : H12AffineEnvironment.transform 8 217 env14481 = env14482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env14481 == env14482) = true)

theorem identity14482 : scanCanonicalize (H12AffineFastState.compose env14482 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound14482 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14483 : List Nat := [2,4,8,16,32,17,128,256,136,273,2048,1,8192,0,32768,33167,0,43049,273,32769,1,41261,16,139,8328,17,2049,1,0,43048,20,41380,256,168,0,136]

theorem envBound14483 : H12AffineFastState.Bounded env14483 := by
  intro p hp
  have h : env14483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14482_14483 : H12AffineEnvironment.transform 5 17 env14482 = env14483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14482 == env14483) = true)

theorem identity14483 : scanCanonicalize (H12AffineFastState.compose env14483 (packedSelected [1] rootPS)) = affineNative (2^(14+1) ^^^ 423) := by decide +kernel

theorem selectedBound14483 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14484 : List Nat := [2,4,8,16,32,17,128,256,136,273,2048,1,8192,0,423,40,0,10638,273,422,1,8330,16,139,8328,17,2049,1,0,10639,20,8195,256,168,0,136]

theorem envBound14484 : H12AffineFastState.Bounded env14484 := by
  intro p hp
  have h : env14484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14483_14484 : H12AffineEnvironment.transform 14 423 env14483 = env14484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 423 env14483 == env14484) = true)

theorem identity14484 : scanCanonicalize (H12AffineFastState.compose env14484 (packedSelected [3] rootPS)) = affineNative (2^(12+1) ^^^ 263) := by decide +kernel

theorem selectedBound14484 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env14485 : List Nat := [2,4,8,16,32,17,128,256,136,273,2048,1,263,0,423,40,0,2185,273,422,1,397,16,139,399,17,2049,1,0,2184,20,260,256,168,0,136]

theorem envBound14485 : H12AffineFastState.Bounded env14485 := by
  intro p hp
  have h : env14485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14484_14485 : H12AffineEnvironment.transform 12 263 env14484 = env14485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 263 env14484 == env14485) = true)

theorem identity14485 : scanCanonicalize (H12AffineFastState.compose env14485 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound14485 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14486 : List Nat := [2,4,8,16,32,17,40,256,32,273,2048,1,263,0,271,40,0,2081,273,270,1,293,16,35,295,17,2049,1,0,2080,20,260,256,0,0,32]

theorem envBound14486 : H12AffineFastState.Bounded env14486 := by
  intro p hp
  have h : env14486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14485_14486 : H12AffineEnvironment.transform 6 40 env14485 = env14486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env14485 == env14486) = true)

theorem identity14486 : scanCanonicalize (H12AffineFastState.compose env14486 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound14486 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env14487 : List Nat := [2,4,8,16,32,17,40,4,32,21,2048,1,3,0,11,40,0,2081,21,10,1,33,16,35,35,17,2049,1,0,2080,20,0,4,0,0,32]

theorem envBound14487 : H12AffineFastState.Bounded env14487 := by
  intro p hp
  have h : env14487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14486_14487 : H12AffineEnvironment.transform 7 4 env14486 = env14487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env14486 == env14487) = true)

def env14488 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,0,8192,80,32768,65536,1,262144,272,32769,0,4194304,65,98645,8328,64,4456709,0,1,1073741824,68,1077979376,337,1073817871,80,512]

theorem envBound14488 : H12AffineFastState.Bounded env14488 := by
  intro p hp
  have h : env14488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14476_14488 : H12AffineEnvironment.transform 9 321 env14476 = env14488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env14476 == env14488) = true)

theorem identity14488 : scanCanonicalize (H12AffineFastState.compose env14488 (packedSelected [12] rootPS)) = affineNative (2^(29+1) ^^^ 76199) := by decide +kernel

theorem selectedBound14488 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env14489 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,0,8192,80,32768,65536,1,262144,272,32769,0,4194304,65,98645,8328,64,4456709,0,1,76199,68,4292951,337,168,80,512]

theorem envBound14489 : H12AffineFastState.Bounded env14489 := by
  intro p hp
  have h : env14489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14488_14489 : H12AffineEnvironment.transform 29 76199 env14488 = env14489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 76199 env14488 == env14489) = true)

def env14490 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,0,8192,0,32768,65536,1,262144,272,32769,0,4194304,17,98565,8328,16,4456709,0,1,76199,20,4292871,257,168,0,512]

theorem envBound14490 : H12AffineFastState.Bounded env14490 := by
  intro p hp
  have h : env14490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14489_14490 : H12AffineEnvironment.transform 5 16 env14489 = env14490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14489 == env14490) = true)

theorem identity14490 : scanCanonicalize (H12AffineFastState.compose env14490 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 10752) := by decide +kernel

theorem selectedBound14490 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14491 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,0,8192,0,32768,10752,1,262144,272,32769,0,4194304,17,43781,8328,16,4456709,0,1,935,20,4238087,257,168,0,512]

theorem envBound14491 : H12AffineFastState.Bounded env14491 := by
  intro p hp
  have h : env14491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14490_14491 : H12AffineEnvironment.transform 15 10752 env14490 = env14491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 10752 env14490 == env14491) = true)

theorem identity14491 : scanCanonicalize (H12AffineFastState.compose env14491 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound14491 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env14492 : List Nat := [2,4,8,16,32,16,128,256,512,273,10,0,8192,0,32768,8714,1,262144,272,32769,0,4194304,17,41743,8328,16,4456709,0,1,935,20,4236045,257,168,0,512]

theorem envBound14492 : H12AffineFastState.Bounded env14492 := by
  intro p hp
  have h : env14492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14491_14492 : H12AffineEnvironment.transform 10 10 env14491 = env14492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env14491 == env14492) = true)

theorem identity14492 : scanCanonicalize (H12AffineFastState.compose env14492 (packedSelected [5] rootPS)) = affineNative (2^(21+1) ^^^ 270987) := by decide +kernel

theorem selectedBound14492 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env14493 : List Nat := [2,4,8,16,32,16,128,256,512,273,10,0,8192,0,32768,8714,1,262144,272,32769,0,270987,17,41743,8328,16,9102,0,1,935,20,295302,257,168,0,512]

theorem envBound14493 : H12AffineFastState.Bounded env14493 := by
  intro p hp
  have h : env14493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14492_14493 : H12AffineEnvironment.transform 21 270987 env14492 = env14493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 270987 env14492 == env14493) = true)

theorem identity14493 : scanCanonicalize (H12AffineFastState.compose env14493 (packedSelected [8] rootPS)) = affineNative (2^(14+1) ^^^ 9092) := by decide +kernel

theorem selectedBound14493 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env14494 : List Nat := [2,4,8,16,32,16,128,256,512,273,10,0,8192,0,9092,8714,1,262144,272,9093,0,270987,17,139,8328,16,9102,0,1,935,20,270850,257,168,0,512]

theorem envBound14494 : H12AffineFastState.Bounded env14494 := by
  intro p hp
  have h : env14494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14493_14494 : H12AffineEnvironment.transform 14 9092 env14493 = env14494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9092 env14493 == env14494) = true)

theorem identity14494 : scanCanonicalize (H12AffineFastState.compose env14494 (packedSelected [13] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound14494 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env14495 : List Nat := [2,4,8,16,32,16,128,256,512,273,10,0,268,0,648,774,1,262144,272,649,0,263047,17,139,388,16,642,0,1,935,20,262926,257,168,0,512]

theorem envBound14495 : H12AffineFastState.Bounded env14495 := by
  intro p hp
  have h : env14495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14494_14495 : H12AffineEnvironment.transform 12 268 env14494 = env14495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env14494 == env14495) = true)

theorem identity14495 : scanCanonicalize (H12AffineFastState.compose env14495 (packedSelected [0,2,4,6,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 303) := by decide +kernel

theorem selectedBound14495 : packedSelected [0,2,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env14496 : List Nat := [2,4,8,16,32,16,128,256,512,273,10,0,268,0,648,774,1,303,272,649,0,680,17,139,388,16,642,0,1,935,20,545,257,168,0,512]

theorem envBound14496 : H12AffineFastState.Bounded env14496 := by
  intro p hp
  have h : env14496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14495_14496 : H12AffineEnvironment.transform 17 303 env14495 = env14496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 303 env14495 == env14496) = true)

theorem identity14496 : scanCanonicalize (H12AffineFastState.compose env14496 (packedSelected [2,6] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound14496 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14497 : List Nat := [2,4,8,16,32,16,128,256,137,273,10,0,268,0,1,399,1,303,272,0,0,33,17,139,388,16,11,0,1,302,20,168,257,168,0,137]

theorem envBound14497 : H12AffineFastState.Bounded env14497 := by
  intro p hp
  have h : env14497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14496_14497 : H12AffineEnvironment.transform 8 137 env14496 = env14497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env14496 == env14497) = true)

theorem identity14497 : scanCanonicalize (H12AffineFastState.compose env14497 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound14497 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14498 : List Nat := [2,4,8,16,32,16,128,20,137,5,10,0,24,0,1,155,1,59,4,0,0,33,17,139,144,16,11,0,1,58,20,168,21,168,0,137]

theorem envBound14498 : H12AffineFastState.Bounded env14498 := by
  intro p hp
  have h : env14498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14497_14498 : H12AffineEnvironment.transform 7 20 env14497 = env14498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env14497 == env14498) = true)

def env14499 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,8192,1,32768,65536,1,262144,272,32769,0,4194304,16,98564,8328,17,4456709,0,1,76199,21,4292870,256,168,1,512]

theorem envBound14499 : H12AffineFastState.Bounded env14499 := by
  intro p hp
  have h : env14499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14489_14499 : H12AffineEnvironment.transform 5 17 env14489 = env14499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14489 == env14499) = true)

theorem identity14499 : scanCanonicalize (H12AffineFastState.compose env14499 (packedSelected [1] rootPS)) = affineNative (2^(17+1) ^^^ 11014) := by decide +kernel

theorem selectedBound14499 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14500 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,8192,1,32768,65536,1,11014,272,32769,0,4194304,16,98564,8328,17,4205059,0,1,76199,21,4292870,256,168,1,512]

theorem envBound14500 : H12AffineFastState.Bounded env14500 := by
  intro p hp
  have h : env14500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14499_14500 : H12AffineEnvironment.transform 17 11014 env14499 = env14500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 11014 env14499 == env14500) = true)

theorem identity14500 : scanCanonicalize (H12AffineFastState.compose env14500 (packedSelected [3] rootPS)) = affineNative (2^(12+1) ^^^ 911) := by decide +kernel

theorem selectedBound14500 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env14501 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,911,1,32768,65536,1,2185,272,32769,0,4194304,16,98564,775,17,4196748,0,1,68136,21,4292870,256,168,1,512]

theorem envBound14501 : H12AffineFastState.Bounded env14501 := by
  intro p hp
  have h : env14501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14500_14501 : H12AffineEnvironment.transform 12 911 env14500 = env14501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 911 env14500 == env14501) = true)

theorem identity14501 : scanCanonicalize (H12AffineFastState.compose env14501 (packedSelected [5] rootPS)) = affineNative (2^(21+1) ^^^ 98734) := by decide +kernel

theorem selectedBound14501 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env14502 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,911,1,32768,65536,1,2185,272,32769,0,98734,16,98564,775,17,100386,0,1,68136,21,168,256,168,1,512]

theorem envBound14502 : H12AffineFastState.Bounded env14502 := by
  intro p hp
  have h : env14502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14501_14502 : H12AffineEnvironment.transform 21 98734 env14501 = env14502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 98734 env14501 == env14502) = true)

theorem identity14502 : scanCanonicalize (H12AffineFastState.compose env14502 (packedSelected [8] rootPS)) = affineNative (2^(15+1) ^^^ 32803) := by decide +kernel

theorem selectedBound14502 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env14503 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,911,1,32768,32803,1,2185,272,32769,0,397,16,295,775,17,2049,0,1,35339,21,168,256,168,1,512]

theorem envBound14503 : H12AffineFastState.Bounded env14503 := by
  intro p hp
  have h : env14503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14502_14503 : H12AffineEnvironment.transform 15 32803 env14502 = env14503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32803 env14502 == env14503) = true)

theorem identity14503 : scanCanonicalize (H12AffineFastState.compose env14503 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 815) := by decide +kernel

theorem selectedBound14503 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env14504 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,911,1,815,780,1,2185,272,814,0,397,16,295,775,17,2049,0,1,2340,21,168,256,168,1,512]

theorem envBound14504 : H12AffineFastState.Bounded env14504 := by
  intro p hp
  have h : env14504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14503_14504 : H12AffineEnvironment.transform 14 815 env14503 = env14504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 815 env14503 == env14504) = true)

theorem identity14504 : scanCanonicalize (H12AffineFastState.compose env14504 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound14504 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env14505 : List Nat := [2,4,8,16,32,17,40,256,512,272,2048,0,807,1,815,780,1,2081,272,814,0,293,16,295,775,17,2049,0,1,2340,21,0,256,0,1,512]

theorem envBound14505 : H12AffineFastState.Bounded env14505 := by
  intro p hp
  have h : env14505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14504_14505 : H12AffineEnvironment.transform 6 40 env14504 = env14505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env14504 == env14505) = true)

theorem identity14505 : scanCanonicalize (H12AffineFastState.compose env14505 (packedSelected [11] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound14505 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env14506 : List Nat := [2,4,8,16,32,17,40,4,512,20,2048,0,547,1,555,520,1,2081,20,554,0,33,16,35,515,17,2049,0,1,2080,21,0,4,0,1,512]

theorem envBound14506 : H12AffineFastState.Bounded env14506 := by
  intro p hp
  have h : env14506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14505_14506 : H12AffineEnvironment.transform 7 4 env14505 = env14506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env14505 == env14506) = true)

theorem identity14506 : scanCanonicalize (H12AffineFastState.compose env14506 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound14506 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14507 : List Nat := [2,4,8,16,32,17,40,4,32,20,2048,0,3,1,11,40,1,2081,20,10,0,33,16,35,35,17,2049,0,1,2080,21,0,4,0,1,32]

theorem envBound14507 : H12AffineFastState.Bounded env14507 := by
  intro p hp
  have h : env14507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14506_14507 : H12AffineEnvironment.transform 8 32 env14506 = env14507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env14506 == env14507) = true)

def env14508 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32769,4096,4194304,8388608,8504325,8328,8914000,134217728,8389889,545088,1073741824,1284,4294967296,8406016,4307666095,139198532,512]

theorem envBound14508 : H12AffineFastState.Bounded env14508 := by
  intro p hp
  have h : env14508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14324_14508 : H12AffineEnvironment.transform 16 1345 env14324 = env14508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env14324 == env14508) = true)

theorem identity14508 : scanCanonicalize (H12AffineFastState.compose env14508 (packedSelected [7,20,27] rootPS)) = affineNative (2^(22+1) ^^^ 17664) := by decide +kernel

theorem selectedBound14508 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env14509 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32769,4096,4194304,17664,98565,8328,541008,134217728,16385,545088,1073741824,1284,4294967296,256,4299260335,139198532,512]

theorem envBound14509 : H12AffineFastState.Bounded env14509 := by
  intro p hp
  have h : env14509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14508_14509 : H12AffineEnvironment.transform 22 17664 env14508 = env14509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17664 env14508 == env14509) = true)

def env14510 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,16384,32768,65536,1345,262144,524288,32769,1344,4194304,17664,98565,8328,541008,134217728,16385,541696,1073741824,1284,4294967296,256,4299260335,139198532,512]

theorem envBound14510 : H12AffineFastState.Bounded env14510 := by
  intro p hp
  have h : env14510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14509_14510 : H12AffineEnvironment.transform 11 1344 env14509 = env14510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env14509 == env14510) = true)

def env14511 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,65536,1345,262144,524288,32769,1344,4194304,64,98565,8328,525328,134217728,1345,524608,1073741824,1284,4294967296,256,4299260335,139198532,512]

theorem envBound14511 : H12AffineFastState.Bounded env14511 := by
  intro p hp
  have h : env14511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14510_14511 : H12AffineEnvironment.transform 13 1344 env14510 = env14511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env14510 == env14511) = true)

theorem identity14511 : scanCanonicalize (H12AffineFastState.compose env14511 (packedSelected [9,22] rootPS)) = affineNative (2^(26+1) ^^^ 4982020) := by decide +kernel

theorem selectedBound14511 : packedSelected [9,22] rootPS < 2^1333 := by decide +kernel

def env14512 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,65536,1345,262144,524288,32769,1344,4194304,64,98565,8328,525328,4982020,1345,524608,1073741824,1284,4294967296,256,4299260335,1344,512]

theorem envBound14512 : H12AffineFastState.Bounded env14512 := by
  intro p hp
  have h : env14512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14511_14512 : H12AffineEnvironment.transform 26 4982020 env14511 = env14512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4982020 env14511 == env14512) = true)

def env14513 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,65536,1345,262144,1104,32769,1344,4194304,64,98565,8328,64,4456788,1345,1296,1073741824,1284,4294967296,256,4299260335,1344,512]

theorem envBound14513 : H12AffineFastState.Bounded env14513 := by
  intro p hp
  have h : env14513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14512_14513 : H12AffineEnvironment.transform 18 1104 env14512 = env14513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1104 env14512 == env14513) = true)

theorem identity14513 : scanCanonicalize (H12AffineFastState.compose env14513 (packedSelected [8,10,13,15] rootPS)) = affineNative (2^(29+1) ^^^ 106745) := by decide +kernel

theorem selectedBound14513 : packedSelected [8,10,13,15] rootPS < 2^1333 := by decide +kernel

def env14514 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,65536,1345,262144,1104,32769,1344,4194304,64,98565,8328,64,4456788,1345,1296,106745,1284,4294967296,256,4299260335,1344,512]

theorem envBound14514 : H12AffineFastState.Bounded env14514 := by
  intro p hp
  have h : env14514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14513_14514 : H12AffineEnvironment.transform 29 106745 env14513 = env14514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 106745 env14513 == env14514) = true)

theorem identity14514 : scanCanonicalize (H12AffineFastState.compose env14514 (packedSelected [3,8,10,13,17] rootPS)) = affineNative (2^(15+1) ^^^ 43404) := by decide +kernel

theorem selectedBound14514 : packedSelected [3,8,10,13,17] rootPS < 2^1333 := by decide +kernel

def env14515 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,43404,1345,262144,1104,32769,1344,4194304,64,10377,8328,64,4456788,1345,1296,2421,1284,4294967296,256,4299171875,1344,512]

theorem envBound14515 : H12AffineFastState.Bounded env14515 := by
  intro p hp
  have h : env14515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14514_14515 : H12AffineEnvironment.transform 15 43404 env14514 = env14515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 43404 env14514 == env14515) = true)

theorem identity14515 : scanCanonicalize (H12AffineFastState.compose env14515 (packedSelected [8,12,19,21] rootPS)) = affineNative (2^(12+1) ^^^ 2050) := by decide +kernel

theorem selectedBound14515 : packedSelected [8,12,19,21] rootPS < 2^1333 := by decide +kernel

def env14516 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,2050,1344,32768,33166,1345,262144,1104,32769,1344,4194304,64,139,2186,64,4456788,1345,1296,2421,1284,4294967296,256,4299161633,1344,512]

theorem envBound14516 : H12AffineFastState.Bounded env14516 := by
  intro p hp
  have h : env14516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14515_14516 : H12AffineEnvironment.transform 12 2050 env14515 = env14516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2050 env14515 == env14516) = true)

theorem identity14516 : scanCanonicalize (H12AffineFastState.compose env14516 (packedSelected [1,8,10,12,13,19] rootPS)) = affineNative (2^(21+1) ^^^ 295002) := by decide +kernel

theorem selectedBound14516 : packedSelected [1,8,10,12,13,19] rootPS < 2^1333 := by decide +kernel

def env14517 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,2050,1344,32768,33166,1345,262144,1104,32769,1344,295002,64,139,2186,64,33038,1345,1296,2421,1284,4294967296,256,4295262331,1344,512]

theorem envBound14517 : H12AffineFastState.Bounded env14517 := by
  intro p hp
  have h : env14517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14516_14517 : H12AffineEnvironment.transform 21 295002 env14516 = env14517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 295002 env14516 == env14517) = true)

theorem identity14517 : scanCanonicalize (H12AffineFastState.compose env14517 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 32891) := by decide +kernel

theorem selectedBound14517 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env14518 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,2050,1344,32768,33166,1345,32891,1104,32769,1344,33,64,139,2186,64,33038,1345,1296,2421,1284,4294967296,256,4294967296,1344,512]

theorem envBound14518 : H12AffineFastState.Bounded env14518 := by
  intro p hp
  have h : env14518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14517_14518 : H12AffineEnvironment.transform 17 32891 env14517 = env14518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32891 env14517 == env14518) = true)

theorem identity14518 : scanCanonicalize (H12AffineFastState.compose env14518 (packedSelected [5,10] rootPS)) = affineNative (2^(14+1) ^^^ 2318) := by decide +kernel

theorem selectedBound14518 : packedSelected [5,10] rootPS < 2^1333 := by decide +kernel

def env14519 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,2050,1344,2318,2176,1345,2421,1104,2319,1344,33,64,139,2186,64,2048,1345,1296,2421,1284,4294967296,256,4294967296,1344,512]

theorem envBound14519 : H12AffineFastState.Bounded env14519 := by
  intro p hp
  have h : env14519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14518_14519 : H12AffineEnvironment.transform 14 2318 env14518 = env14519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2318 env14518 == env14519) = true)

theorem identity14519 : scanCanonicalize (H12AffineFastState.compose env14519 (packedSelected [0,2,4] rootPS)) = affineNative (2^(31+1) ^^^ 123) := by decide +kernel

theorem selectedBound14519 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env14520 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,2050,1344,2318,2176,1345,2421,1104,2319,1344,33,64,139,2186,64,2048,1345,1296,2421,1284,123,256,123,1344,512]

theorem envBound14520 : H12AffineFastState.Bounded env14520 := by
  intro p hp
  have h : env14520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14519_14520 : H12AffineEnvironment.transform 31 123 env14519 = env14520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 123 env14519 == env14520) = true)

theorem identity14520 : scanCanonicalize (H12AffineFastState.compose env14520 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound14520 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env14521 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,2050,1297,2318,2176,1296,2340,1025,2319,1297,33,17,139,2186,17,2048,1296,1296,2340,1284,42,256,42,1297,512]

theorem envBound14521 : H12AffineFastState.Bounded env14521 := by
  intro p hp
  have h : env14521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14520_14521 : H12AffineEnvironment.transform 5 17 env14520 = env14521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14520 == env14521) = true)

theorem identity14521 : scanCanonicalize (H12AffineFastState.compose env14521 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound14521 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14522 : List Nat := [2,4,8,16,11,17,128,256,512,1024,2048,1297,2050,1297,2318,2176,1296,2319,1025,2319,1297,10,17,139,2186,17,2048,1296,1296,2319,1284,1,256,1,1297,512]

theorem envBound14522 : H12AffineFastState.Bounded env14522 := by
  intro p hp
  have h : env14522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14521_14522 : H12AffineEnvironment.transform 4 11 env14521 = env14522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env14521 == env14522) = true)

theorem identity14522 : scanCanonicalize (H12AffineFastState.compose env14522 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound14522 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14523 : List Nat := [2,4,8,16,11,17,128,256,276,1024,2048,1297,2050,1297,2318,2176,1296,2319,1025,2319,1297,10,17,139,2186,17,2048,1296,1296,2319,1284,1,256,1,1297,276]

theorem envBound14523 : H12AffineFastState.Bounded env14523 := by
  intro p hp
  have h : env14523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14522_14523 : H12AffineEnvironment.transform 8 276 env14522 = env14523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env14522 == env14523) = true)

theorem identity14523 : scanCanonicalize (H12AffineFastState.compose env14523 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 156) := by decide +kernel

theorem selectedBound14523 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env14524 : List Nat := [2,4,8,16,11,17,128,156,136,1024,2048,1165,2050,1165,2194,2176,1164,2195,1025,2195,1165,10,17,139,2186,17,2048,1164,1164,2195,1176,1,156,1,1165,136]

theorem envBound14524 : H12AffineFastState.Bounded env14524 := by
  intro p hp
  have h : env14524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14523_14524 : H12AffineEnvironment.transform 7 156 env14523 = env14524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 156 env14523 == env14524) = true)

theorem identity14524 : scanCanonicalize (H12AffineFastState.compose env14524 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound14524 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14525 : List Nat := [2,4,8,16,11,17,18,14,26,1024,2048,1055,2050,1055,2048,2066,1054,2049,1025,2049,1055,10,17,25,2072,17,2048,1054,1054,2049,1034,1,14,1,1055,26]

theorem envBound14525 : H12AffineFastState.Bounded env14525 := by
  intro p hp
  have h : env14525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14524_14525 : H12AffineEnvironment.transform 6 18 env14524 = env14525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env14524 == env14525) = true)

def env14526 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,65536,1345,262144,1105,32769,1344,4194304,64,98565,8328,65,4456789,1345,1297,1073741824,1284,4294967296,256,4299260335,1344,512]

theorem envBound14526 : H12AffineFastState.Bounded env14526 := by
  intro p hp
  have h : env14526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14512_14526 : H12AffineEnvironment.transform 18 1105 env14512 = env14526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1105 env14512 == env14526) = true)

theorem identity14526 : scanCanonicalize (H12AffineFastState.compose env14526 (packedSelected [8,10,13,15] rootPS)) = affineNative (2^(29+1) ^^^ 4466696) := by decide +kernel

theorem selectedBound14526 : packedSelected [8,10,13,15] rootPS < 2^1333 := by decide +kernel

def env14527 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,65536,1345,262144,1105,32769,1344,4194304,64,98565,8328,65,4456789,1345,1297,4466696,1284,4294967296,256,4299260335,1344,512]

theorem envBound14527 : H12AffineFastState.Bounded env14527 := by
  intro p hp
  have h : env14527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14526_14527 : H12AffineEnvironment.transform 29 4466696 env14526 = env14527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4466696 env14526 == env14527) = true)

theorem identity14527 : scanCanonicalize (H12AffineFastState.compose env14527 (packedSelected [8,12,19,21] rootPS)) = affineNative (2^(17+1) ^^^ 43128) := by decide +kernel

theorem selectedBound14527 : packedSelected [8,12,19,21] rootPS < 2^1333 := by decide +kernel

def env14528 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,65536,1345,43128,1105,32769,1344,4194304,64,98565,8328,65,4237613,1345,1297,4227184,1284,4294967296,256,4299260335,1344,512]

theorem envBound14528 : H12AffineFastState.Bounded env14528 := by
  intro p hp
  have h : env14528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14527_14528 : H12AffineEnvironment.transform 17 43128 env14527 = env14528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43128 env14527 == env14528) = true)

theorem identity14528 : scanCanonicalize (H12AffineFastState.compose env14528 (packedSelected [0,4,7,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 2420) := by decide +kernel

theorem selectedBound14528 : packedSelected [0,4,7,9,11] rootPS < 2^1333 := by decide +kernel

def env14529 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,2420,65536,1345,8460,1105,2421,1344,4194304,64,67697,8328,65,4202585,1345,1297,4196612,1284,4294967296,256,4299229403,1344,512]

theorem envBound14529 : H12AffineFastState.Bounded env14529 := by
  intro p hp
  have h : env14529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14528_14529 : H12AffineEnvironment.transform 14 2420 env14528 = env14529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2420 env14528 == env14529) = true)

theorem identity14529 : scanCanonicalize (H12AffineFastState.compose env14529 (packedSelected [5,10,19] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound14529 : packedSelected [5,10,19] rootPS < 2^1333 := by decide +kernel

def env14530 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1297,2341,65536,1296,8460,1024,2340,1297,4194304,17,67616,8328,16,4202504,1296,1297,4196612,1284,4294967296,256,4299229322,1297,512]

theorem envBound14530 : H12AffineFastState.Bounded env14530 := by
  intro p hp
  have h : env14530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14529_14530 : H12AffineEnvironment.transform 5 17 env14529 = env14530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14529 == env14530) = true)

theorem identity14530 : scanCanonicalize (H12AffineFastState.compose env14530 (packedSelected [1,3] rootPS)) = affineNative (2^(21+1) ^^^ 73890) := by decide +kernel

theorem selectedBound14530 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14531 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1297,2341,65536,1296,8460,1024,2340,1297,73890,17,67616,8328,16,65706,1296,1297,76198,1284,4294967296,256,4294977576,1297,512]

theorem envBound14531 : H12AffineFastState.Bounded env14531 := by
  intro p hp
  have h : env14531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14530_14531 : H12AffineEnvironment.transform 21 73890 env14530 = env14531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73890 env14530 == env14531) = true)

theorem identity14531 : scanCanonicalize (H12AffineFastState.compose env14531 (packedSelected [1,10] rootPS)) = affineNative (2^(15+1) ^^^ 2219) := by decide +kernel

theorem selectedBound14531 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env14532 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1297,2341,2219,1296,8460,1024,2340,1297,10249,17,139,8328,16,2049,1296,1297,8461,1284,4294967296,256,4294977576,1297,512]

theorem envBound14532 : H12AffineFastState.Bounded env14532 := by
  intro p hp
  have h : env14532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14531_14532 : H12AffineEnvironment.transform 15 2219 env14531 = env14532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2219 env14531 == env14532) = true)

theorem identity14532 : scanCanonicalize (H12AffineFastState.compose env14532 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound14532 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14533 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,2088,1297,2341,2219,1296,2340,1024,2340,1297,33,17,139,2208,16,2049,1296,1297,2341,1284,4294967296,256,4294967296,1297,512]

theorem envBound14533 : H12AffineFastState.Bounded env14533 := by
  intro p hp
  have h : env14533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14532_14533 : H12AffineEnvironment.transform 12 2088 env14532 = env14533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env14532 == env14533) = true)

theorem identity14533 : scanCanonicalize (H12AffineFastState.compose env14533 (packedSelected [2] rootPS)) = affineNative (2^(31+1) ^^^ 804) := by decide +kernel

theorem selectedBound14533 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14534 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,2088,1297,2341,2219,1296,2340,1024,2340,1297,33,17,139,2208,16,2049,1296,1297,2341,1284,804,256,804,1297,512]

theorem envBound14534 : H12AffineFastState.Bounded env14534 := by
  intro p hp
  have h : env14534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14533_14534 : H12AffineEnvironment.transform 31 804 env14533 = env14534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 804 env14533 == env14534) = true)

theorem identity14534 : scanCanonicalize (H12AffineFastState.compose env14534 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound14534 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env14535 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1297,2088,1297,2341,2219,1296,2340,1024,2340,1297,33,17,139,2208,16,2049,1296,1297,2341,1284,428,256,428,1297,136]

theorem envBound14535 : H12AffineFastState.Bounded env14535 := by
  intro p hp
  have h : env14535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14534_14535 : H12AffineEnvironment.transform 8 136 env14534 = env14535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env14534 == env14535) = true)

theorem identity14535 : scanCanonicalize (H12AffineFastState.compose env14535 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound14535 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14536 : List Nat := [2,4,8,16,32,17,128,36,136,1024,2048,1077,2088,1077,2049,2219,1076,2048,1024,2048,1077,33,17,139,2208,16,2049,1076,1077,2049,1056,136,36,136,1077,136]

theorem envBound14536 : H12AffineFastState.Bounded env14536 := by
  intro p hp
  have h : env14536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14535_14536 : H12AffineEnvironment.transform 7 36 env14535 = env14536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env14535 == env14536) = true)

def leafEnv14536 : List Nat := [2,4,8,16,32,17,128,36,136,1024,2048,1077,2088,1077,2049,2219,1076,2048,1024,2048,1077,33,17,139,1056,2208,1,16,2049,1076,1077,2049,1056,136,36,136,4,2082,1077,136,0,1077,1]

def active14536 : List Nat := [0,1,2,3,4,6,9,10]

def tree14536 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14536 : H12WitnessSearch.Good tree14536 := H12GlobalWitnessIndex.good

theorem leafIdentity14536 : H12AffineFastState.composeSystem env14536 rootObs = leafEnv14536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14536 rootObs == leafEnv14536) = true)

theorem terminalChecked14536 : H12PackedTerminal.terminalCheckFast leafEnv14536 active14536 tree14536 = true := by decide +kernel

def env14537 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1345,262144,524288,32769,1344,4194304,65,98565,8328,525329,134217728,1344,524609,1073741824,1284,4294967296,256,4299260335,139198532,512]

theorem envBound14537 : H12AffineFastState.Bounded env14537 := by
  intro p hp
  have h : env14537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14510_14537 : H12AffineEnvironment.transform 13 1345 env14510 = env14537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env14510 == env14537) = true)

theorem identity14537 : scanCanonicalize (H12AffineFastState.compose env14537 (packedSelected [9,22] rootPS)) = affineNative (2^(26+1) ^^^ 4456788) := by decide +kernel

theorem selectedBound14537 : packedSelected [9,22] rootPS < 2^1333 := by decide +kernel

def env14538 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1345,262144,524288,32769,1344,4194304,65,98565,8328,525329,4456788,1344,524609,1073741824,1284,4294967296,256,4299260335,524560,512]

theorem envBound14538 : H12AffineFastState.Bounded env14538 := by
  intro p hp
  have h : env14538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14537_14538 : H12AffineEnvironment.transform 26 4456788 env14537 = env14538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4456788 env14537 == env14538) = true)

def env14539 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1345,262144,1104,32769,1344,4194304,65,98565,8328,65,4456788,1344,1297,1073741824,1284,4294967296,256,4299260335,1344,512]

theorem envBound14539 : H12AffineFastState.Bounded env14539 := by
  intro p hp
  have h : env14539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14538_14539 : H12AffineEnvironment.transform 18 1104 env14538 = env14539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1104 env14538 == env14539) = true)

theorem identity14539 : scanCanonicalize (H12AffineFastState.compose env14539 (packedSelected [8,10,13,15] rootPS)) = affineNative (2^(17+1) ^^^ 106706) := by decide +kernel

theorem selectedBound14539 : packedSelected [8,10,13,15] rootPS < 2^1333 := by decide +kernel

def env14540 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1345,106706,1104,32769,1344,4194304,65,98565,8328,65,4301190,1344,1297,1073741824,1284,4294967296,256,4299260335,1344,512]

theorem envBound14540 : H12AffineFastState.Bounded env14540 := by
  intro p hp
  have h : env14540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14539_14540 : H12AffineEnvironment.transform 17 106706 env14539 = env14540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 106706 env14539 == env14540) = true)

theorem identity14540 : scanCanonicalize (H12AffineFastState.compose env14540 (packedSelected [3,8,10,13,17] rootPS)) = affineNative (2^(29+1) ^^^ 4294874) := by decide +kernel

theorem selectedBound14540 : packedSelected [3,8,10,13,17] rootPS < 2^1333 := by decide +kernel

def env14541 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1345,106706,1104,32769,1344,4194304,65,98565,8328,65,4301190,1344,1297,4294874,1284,4294967296,256,4299260335,1344,512]

theorem envBound14541 : H12AffineFastState.Bounded env14541 := by
  intro p hp
  have h : env14541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14540_14541 : H12AffineEnvironment.transform 29 4294874 env14540 = env14541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4294874 env14540 == env14541) = true)

theorem identity14541 : scanCanonicalize (H12AffineFastState.compose env14541 (packedSelected [1,3,5,10,12,21] rootPS)) = affineNative (2^(15+1) ^^^ 2219) := by decide +kernel

theorem selectedBound14541 : packedSelected [1,3,5,10,12,21] rootPS < 2^1333 := by decide +kernel

def env14542 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,2219,1345,43129,1104,32769,1344,4194304,65,35246,8328,65,4237613,1344,1297,4227185,1284,4294967296,256,4299196676,1344,512]

theorem envBound14542 : H12AffineFastState.Bounded env14542 := by
  intro p hp
  have h : env14542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14541_14542 : H12AffineEnvironment.transform 15 2219 env14541 = env14542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2219 env14541 == env14542) = true)

theorem identity14542 : scanCanonicalize (H12AffineFastState.compose env14542 (packedSelected [0,4,7,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 2421) := by decide +kernel

theorem selectedBound14542 : packedSelected [0,4,7,9,11] rootPS < 2^1333 := by decide +kernel

def env14543 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,2421,2219,1345,8460,1104,2420,1344,4194304,65,219,8328,65,4202584,1344,1297,4196612,1284,4294967296,256,4299161713,1344,512]

theorem envBound14543 : H12AffineFastState.Bounded env14543 := by
  intro p hp
  have h : env14543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14542_14543 : H12AffineEnvironment.transform 14 2421 env14542 = env14543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2421 env14542 == env14543) = true)

theorem identity14543 : scanCanonicalize (H12AffineFastState.compose env14543 (packedSelected [3,5,24] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound14543 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env14544 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1297,2341,2219,1297,8460,1024,2340,1296,4194304,17,139,8328,17,4202504,1296,1297,4196612,1284,4294967296,256,4299161633,1296,512]

theorem envBound14544 : H12AffineFastState.Bounded env14544 := by
  intro p hp
  have h : env14544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14543_14544 : H12AffineEnvironment.transform 5 16 env14543 = env14544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14543 == env14544) = true)

theorem identity14544 : scanCanonicalize (H12AffineFastState.compose env14544 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound14544 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14545 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,1213,8192,1212,2184,2219,1212,8353,1024,2185,1213,4194304,17,139,8328,17,4202504,1213,1212,4196521,1193,4294967296,173,4299161633,1213,512]

theorem envBound14545 : H12AffineFastState.Bounded env14545 := by
  intro p hp
  have h : env14545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14544_14545 : H12AffineEnvironment.transform 7 173 env14544 = env14545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env14544 == env14545) = true)

theorem identity14545 : scanCanonicalize (H12AffineFastState.compose env14545 (packedSelected [3] rootPS)) = affineNative (2^(12+1) ^^^ 2208) := by decide +kernel

theorem selectedBound14545 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env14546 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,1213,2208,1212,2184,2219,1212,2049,1024,2185,1213,4194304,17,139,2088,17,4196520,1213,1212,4196521,1193,4294967296,173,4299161633,1213,512]

theorem envBound14546 : H12AffineFastState.Bounded env14546 := by
  intro p hp
  have h : env14546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14545_14546 : H12AffineEnvironment.transform 12 2208 env14545 = env14546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2208 env14545 == env14546) = true)

theorem identity14546 : scanCanonicalize (H12AffineFastState.compose env14546 (packedSelected [0,7] rootPS)) = affineNative (2^(21+1) ^^^ 168) := by decide +kernel

theorem selectedBound14546 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env14547 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,1213,2208,1212,2184,2219,1212,2049,1024,2185,1213,168,17,139,2088,17,2048,1213,1212,2049,1193,4294967296,173,4294967433,1213,512]

theorem envBound14547 : H12AffineFastState.Bounded env14547 := by
  intro p hp
  have h : env14547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14546_14547 : H12AffineEnvironment.transform 21 168 env14546 = env14547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 168 env14546 == env14547) = true)

theorem identity14547 : scanCanonicalize (H12AffineFastState.compose env14547 (packedSelected [0,2,4] rootPS)) = affineNative (2^(31+1) ^^^ 1) := by decide +kernel

theorem selectedBound14547 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env14548 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,1213,2208,1212,2184,2219,1212,2049,1024,2185,1213,168,17,139,2088,17,2048,1213,1212,2049,1193,1,173,136,1213,512]

theorem envBound14548 : H12AffineFastState.Bounded env14548 := by
  intro p hp
  have h : env14548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14547_14548 : H12AffineEnvironment.transform 31 1 env14547 = env14548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1 env14547 == env14548) = true)

def env14549 : List Nat := [2,4,8,16,32,16,128,173,0,1024,2048,1213,2208,1212,2184,2219,1212,2049,1024,2185,1213,168,17,139,2088,17,2048,1213,1212,2049,1193,1,173,136,1213,0]

theorem envBound14549 : H12AffineFastState.Bounded env14549 := by
  intro p hp
  have h : env14549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14548_14549 : H12AffineEnvironment.transform 8 0 env14548 = env14549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env14548 == env14549) = true)

def env14550 : List Nat := [2,4,8,16,0,16,128,141,0,1024,2048,1181,2176,1180,2184,2187,1180,2049,1024,2185,1181,136,17,139,2056,17,2048,1181,1180,2049,1161,1,141,136,1181,0]

theorem envBound14550 : H12AffineFastState.Bounded env14550 := by
  intro p hp
  have h : env14550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14549_14550 : H12AffineEnvironment.transform 4 0 env14549 = env14550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14549 == env14550) = true)

def env14551 : List Nat := [2,4,8,16,1,16,128,140,0,1024,2048,1180,2177,1181,2184,2186,1181,2049,1024,2185,1180,137,17,139,2057,17,2048,1180,1181,2049,1160,1,140,136,1180,0]

theorem envBound14551 : H12AffineFastState.Bounded env14551 := by
  intro p hp
  have h : env14551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14549_14551 : H12AffineEnvironment.transform 4 1 env14549 = env14551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14549 == env14551) = true)

theorem identity14551 : scanCanonicalize (H12AffineFastState.compose env14551 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound14551 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14552 : List Nat := [2,4,8,16,1,16,8,4,0,1024,2048,1044,2057,1045,2048,2050,1045,2049,1024,2049,1044,1,17,3,2057,17,2048,1044,1045,2049,1024,1,4,0,1044,0]

theorem envBound14552 : H12AffineFastState.Bounded env14552 := by
  intro p hp
  have h : env14552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14551_14552 : H12AffineEnvironment.transform 6 8 env14551 = env14552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14551 == env14552) = true)

def leafEnv14552 : List Nat := [2,4,8,16,1,16,8,4,0,1024,2048,1044,2057,1045,2048,2050,1045,2049,1024,2049,1044,1,17,3,1024,2057,1,17,2048,1044,1045,2049,1024,1,4,0,4,2051,1044,0,0,1045,1]

def active14552 : List Nat := [0,1,2,3,9,10]

def tree14552 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14552 : H12WitnessSearch.Good tree14552 := H12GlobalWitnessIndex.good

theorem leafIdentity14552 : H12AffineFastState.composeSystem env14552 rootObs = leafEnv14552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14552 rootObs == leafEnv14552) = true)

theorem terminalChecked14552 : H12PackedTerminal.terminalCheckFast leafEnv14552 active14552 tree14552 = true := by decide +kernel

def env14553 : List Nat := [2,4,8,16,32,16,128,173,1,1024,2048,1213,2208,1212,2184,2219,1212,2049,1024,2185,1213,168,17,139,2088,17,2048,1213,1212,2049,1193,1,173,136,1213,1]

theorem envBound14553 : H12AffineFastState.Bounded env14553 := by
  intro p hp
  have h : env14553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14548_14553 : H12AffineEnvironment.transform 8 1 env14548 = env14553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env14548 == env14553) = true)

theorem identity14553 : scanCanonicalize (H12AffineFastState.compose env14553 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound14553 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14554 : List Nat := [2,4,8,16,32,16,9,36,1,1024,2048,1076,2089,1077,2049,2082,1077,2049,1024,2048,1076,33,17,2,2088,17,2048,1076,1077,2049,1056,1,36,1,1076,1]

theorem envBound14554 : H12AffineFastState.Bounded env14554 := by
  intro p hp
  have h : env14554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14553_14554 : H12AffineEnvironment.transform 6 9 env14553 = env14554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14553 == env14554) = true)

def leafEnv14554 : List Nat := [2,4,8,16,32,16,9,36,1,1024,2048,1076,2089,1077,2049,2082,1077,2049,1024,2048,1076,33,17,2,1056,2088,1,17,2048,1076,1077,2049,1056,1,36,1,4,2082,1076,1,0,1077,1]

def active14554 : List Nat := [0,1,2,3,4,9,10]

def tree14554 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14554 : H12WitnessSearch.Good tree14554 := H12GlobalWitnessIndex.good

theorem leafIdentity14554 : H12AffineFastState.composeSystem env14554 rootObs = leafEnv14554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14554 rootObs == leafEnv14554) = true)

theorem terminalChecked14554 : H12PackedTerminal.terminalCheckFast leafEnv14554 active14554 tree14554 = true := by decide +kernel

def env14555 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1345,262144,1105,32769,1344,4194304,65,98565,8328,64,4456788,1344,1296,1073741824,1284,4294967296,256,4299260335,1345,512]

theorem envBound14555 : H12AffineFastState.Bounded env14555 := by
  intro p hp
  have h : env14555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14538_14555 : H12AffineEnvironment.transform 18 1105 env14538 = env14555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1105 env14538 == env14555) = true)

theorem identity14555 : scanCanonicalize (H12AffineFastState.compose env14555 (packedSelected [8,10,13,15] rootPS)) = affineNative (2^(29+1) ^^^ 67884) := by decide +kernel

theorem selectedBound14555 : packedSelected [8,10,13,15] rootPS < 2^1333 := by decide +kernel

def env14556 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1345,262144,1105,32769,1344,4194304,65,98565,8328,64,4456788,1344,1296,67884,1284,4294967296,256,4299260335,1345,512]

theorem envBound14556 : H12AffineFastState.Bounded env14556 := by
  intro p hp
  have h : env14556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14555_14556 : H12AffineEnvironment.transform 29 67884 env14555 = env14556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 67884 env14555 == env14556) = true)

theorem identity14556 : scanCanonicalize (H12AffineFastState.compose env14556 (packedSelected [3,8,10,13,17] rootPS)) = affineNative (2^(31+1) ^^^ 101252) := by decide +kernel

theorem selectedBound14556 : packedSelected [3,8,10,13,17] rootPS < 2^1333 := by decide +kernel

def env14557 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1345,262144,1105,32769,1344,4194304,65,98565,8328,64,4456788,1344,1296,67884,1284,101252,256,4196907,1345,512]

theorem envBound14557 : H12AffineFastState.Bounded env14557 := by
  intro p hp
  have h : env14557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14556_14557 : H12AffineEnvironment.transform 31 101252 env14556 = env14557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 101252 env14556 == env14557) = true)

theorem identity14557 : scanCanonicalize (H12AffineFastState.compose env14557 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound14557 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env14558 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,32768,65536,1296,262144,1024,32769,1297,4194304,16,98565,8328,17,4456709,1297,1296,67884,1284,101252,256,4196907,1296,512]

theorem envBound14558 : H12AffineFastState.Bounded env14558 := by
  intro p hp
  have h : env14558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14557_14558 : H12AffineEnvironment.transform 5 17 env14557 = env14558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14557 == env14558) = true)

theorem identity14558 : scanCanonicalize (H12AffineFastState.compose env14558 (packedSelected [1,3,5] rootPS)) = affineNative (2^(15+1) ^^^ 2311) := by decide +kernel

theorem selectedBound14558 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env14559 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,32768,2311,1296,262144,1024,32769,1297,4194304,16,34818,8328,17,4456709,1297,1296,43,1284,33411,256,4196907,1296,512]

theorem envBound14559 : H12AffineFastState.Bounded env14559 := by
  intro p hp
  have h : env14559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14558_14559 : H12AffineEnvironment.transform 15 2311 env14558 = env14559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2311 env14558 == env14559) = true)

theorem identity14559 : scanCanonicalize (H12AffineFastState.compose env14559 (packedSelected [1,3,8] rootPS)) = affineNative (2^(21+1) ^^^ 10760) := by decide +kernel

theorem selectedBound14559 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env14560 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,32768,2311,1296,262144,1024,32769,1297,10760,16,34818,8328,17,273165,1297,1296,43,1284,33411,256,8227,1296,512]

theorem envBound14560 : H12AffineFastState.Bounded env14560 := by
  intro p hp
  have h : env14560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14559_14560 : H12AffineEnvironment.transform 21 10760 env14559 = env14560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10760 env14559 == env14560) = true)

theorem identity14560 : scanCanonicalize (H12AffineFastState.compose env14560 (packedSelected [1,10] rootPS)) = affineNative (2^(14+1) ^^^ 10243) := by decide +kernel

theorem selectedBound14560 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env14561 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,10243,2311,1296,262144,1024,10242,1297,10760,16,8193,8328,17,273165,1297,1296,43,1284,10880,256,8227,1296,512]

theorem envBound14561 : H12AffineFastState.Bounded env14561 := by
  intro p hp
  have h : env14561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14560_14561 : H12AffineEnvironment.transform 14 10243 env14560 = env14561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 10243 env14560 == env14561) = true)

theorem identity14561 : scanCanonicalize (H12AffineFastState.compose env14561 (packedSelected [1,12,13] rootPS)) = affineNative (2^(12+1) ^^^ 2316) := by decide +kernel

theorem selectedBound14561 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env14562 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,2316,1296,271,2311,1296,262144,1024,270,1297,772,16,2317,2436,17,262657,1297,1296,43,1284,908,256,2351,1296,512]

theorem envBound14562 : H12AffineFastState.Bounded env14562 := by
  intro p hp
  have h : env14562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14561_14562 : H12AffineEnvironment.transform 12 2316 env14561 = env14562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2316 env14561 == env14562) = true)

def env14563 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,16384,32768,65536,1345,262144,524288,32769,1345,4194304,17664,98565,8328,541008,134217728,16385,541697,1073741824,1284,4294967296,256,4299260335,139198532,512]

theorem envBound14563 : H12AffineFastState.Bounded env14563 := by
  intro p hp
  have h : env14563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14509_14563 : H12AffineEnvironment.transform 11 1345 env14509 = env14563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env14509 == env14563) = true)

def env14564 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1345,262144,524288,32769,1345,4194304,64,98565,8328,525328,134217728,1345,524609,1073741824,1284,4294967296,256,4299260335,139198532,512]

theorem envBound14564 : H12AffineFastState.Bounded env14564 := by
  intro p hp
  have h : env14564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14563_14564 : H12AffineEnvironment.transform 13 1344 env14563 = env14564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env14563 == env14564) = true)

def env14565 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1345,512,524288,32769,1345,4194304,64,98565,8328,525328,134217728,1345,524609,1073741824,1284,4294967296,256,4299260335,138936900,512]

theorem envBound14565 : H12AffineFastState.Bounded env14565 := by
  intro p hp
  have h : env14565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14564_14565 : H12AffineEnvironment.transform 17 512 env14564 = env14565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 512 env14564 == env14565) = true)

def env14566 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1345,512,1104,32769,1345,4194304,64,98565,8328,64,134217728,1345,1297,1073741824,1284,4294967296,256,4299260335,138413588,512]

theorem envBound14566 : H12AffineFastState.Bounded env14566 := by
  intro p hp
  have h : env14566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14565_14566 : H12AffineEnvironment.transform 18 1104 env14565 = env14566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1104 env14565 == env14566) = true)

theorem identity14566 : scanCanonicalize (H12AffineFastState.compose env14566 (packedSelected [3,5,24] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound14566 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env14567 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,388,1344,32768,65536,1345,512,1104,32769,1345,4194304,64,98565,268,64,134217728,1345,1297,1073741824,1284,4294967296,256,4299260335,138413588,512]

theorem envBound14567 : H12AffineFastState.Bounded env14567 := by
  intro p hp
  have h : env14567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14566_14567 : H12AffineEnvironment.transform 12 388 env14566 = env14567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env14566 == env14567) = true)

def env14568 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,388,1296,32768,65536,1297,512,1024,32769,1297,4194304,16,98565,268,16,134217728,1297,1297,1073741824,1284,4294967296,256,4299260335,138413588,512]

theorem envBound14568 : H12AffineFastState.Bounded env14568 := by
  intro p hp
  have h : env14568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14567_14568 : H12AffineEnvironment.transform 5 16 env14567 = env14568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14567 == env14568) = true)

theorem identity14568 : scanCanonicalize (H12AffineFastState.compose env14568 (packedSelected [3,5,8,28] rootPS)) = affineNative (2^(26+1) ^^^ 4195076) := by decide +kernel

theorem selectedBound14568 : packedSelected [3,5,8,28] rootPS < 2^1333 := by decide +kernel

def env14569 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,388,1296,32768,65536,1297,512,1024,32769,1297,4194304,16,98565,268,16,4195076,1297,1297,1073741824,1284,4294967296,256,4299260335,1296,512]

theorem envBound14569 : H12AffineFastState.Bounded env14569 := by
  intro p hp
  have h : env14569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14568_14569 : H12AffineEnvironment.transform 26 4195076 env14568 = env14569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4195076 env14568 == env14569) = true)

theorem identity14569 : scanCanonicalize (H12AffineFastState.compose env14569 (packedSelected [1,12,13] rootPS)) = affineNative (2^(29+1) ^^^ 4227753) := by decide +kernel

theorem selectedBound14569 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env14570 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,388,1296,32768,65536,1297,512,1024,32769,1297,4194304,16,98565,268,16,4195076,1297,1297,4227753,1284,4294967296,256,4299260335,1296,512]

theorem envBound14570 : H12AffineFastState.Bounded env14570 := by
  intro p hp
  have h : env14570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14569_14570 : H12AffineEnvironment.transform 29 4227753 env14569 = env14570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4227753 env14569 == env14570) = true)

theorem identity14570 : scanCanonicalize (H12AffineFastState.compose env14570 (packedSelected [12] rootPS)) = affineNative (2^(21+1) ^^^ 32936) := by decide +kernel

theorem selectedBound14570 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env14571 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,388,1296,32768,65536,1297,512,1024,32769,1297,32936,16,98565,268,16,33708,1297,1297,513,1284,4294967296,256,4295033095,1296,512]

theorem envBound14571 : H12AffineFastState.Bounded env14571 := by
  intro p hp
  have h : env14571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14570_14571 : H12AffineEnvironment.transform 21 32936 env14570 = env14571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32936 env14570 == env14571) = true)

theorem identity14571 : scanCanonicalize (H12AffineFastState.compose env14571 (packedSelected [1,3,15] rootPS)) = affineNative (2^(14+1) ^^^ 2989) := by decide +kernel

theorem selectedBound14571 : packedSelected [1,3,15] rootPS < 2^1333 := by decide +kernel

def env14572 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,388,1296,2989,65536,1297,512,1024,2988,1297,2821,16,68264,268,16,2049,1297,1297,513,1284,4294967296,256,4295033095,1296,512]

theorem envBound14572 : H12AffineFastState.Bounded env14572 := by
  intro p hp
  have h : env14572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14571_14572 : H12AffineEnvironment.transform 14 2989 env14571 = env14572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2989 env14571 == env14572) = true)

def env14573 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,1,388,0,2989,65536,1,512,272,2988,1,2821,16,68264,268,16,2049,1,1,513,20,4294967296,256,4295033095,0,512]

theorem envBound14573 : H12AffineFastState.Bounded env14573 := by
  intro p hp
  have h : env14573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14572_14573 : H12AffineEnvironment.transform 9 272 env14572 = env14573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env14572 == env14573) = true)

theorem identity14573 : scanCanonicalize (H12AffineFastState.compose env14573 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 2595) := by decide +kernel

theorem selectedBound14573 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14574 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,1,388,0,2989,2595,1,512,272,2988,1,2821,16,139,268,16,2049,1,1,513,20,4294967296,256,4294970148,0,512]

theorem envBound14574 : H12AffineFastState.Bounded env14574 := by
  intro p hp
  have h : env14574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14573_14574 : H12AffineEnvironment.transform 15 2595 env14573 = env14574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2595 env14573 == env14574) = true)

def env14575 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,1,388,0,2989,2595,1,512,272,2988,1,2821,16,139,268,16,2049,1,1,513,20,2592,256,260,0,512]

theorem envBound14575 : H12AffineFastState.Bounded env14575 := by
  intro p hp
  have h : env14575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14574_14575 : H12AffineEnvironment.transform 31 2592 env14574 = env14575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 2592 env14574 == env14575) = true)

theorem identity14575 : scanCanonicalize (H12AffineFastState.compose env14575 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 261) := by decide +kernel

theorem selectedBound14575 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14576 : List Nat := [2,4,8,16,32,16,128,256,512,272,261,1,388,0,680,806,1,512,272,681,1,512,16,139,268,16,260,1,1,513,20,805,256,260,0,512]

theorem envBound14576 : H12AffineFastState.Bounded env14576 := by
  intro p hp
  have h : env14576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14575_14576 : H12AffineEnvironment.transform 10 261 env14575 = env14576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env14575 == env14576) = true)

def env14577 : List Nat := [2,4,8,16,32,16,128,256,0,272,261,1,388,0,168,294,1,0,272,169,1,0,16,139,268,16,260,1,1,1,20,293,256,260,0,0]

theorem envBound14577 : H12AffineFastState.Bounded env14577 := by
  intro p hp
  have h : env14577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14576_14577 : H12AffineEnvironment.transform 8 0 env14576 = env14577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env14576 == env14577) = true)

theorem identity14577 : scanCanonicalize (H12AffineFastState.compose env14577 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound14577 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14578 : List Nat := [2,4,8,16,32,16,128,5,0,21,0,1,129,0,168,35,1,0,21,169,1,0,16,139,9,16,1,1,1,1,20,32,5,1,0,0]

theorem envBound14578 : H12AffineFastState.Bounded env14578 := by
  intro p hp
  have h : env14578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14577_14578 : H12AffineEnvironment.transform 7 5 env14577 = env14578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env14577 == env14578) = true)

def env14579 : List Nat := [2,4,8,16,0,16,128,5,0,21,0,1,129,0,136,3,1,0,21,137,1,0,16,139,9,16,1,1,1,1,20,0,5,1,0,0]

theorem envBound14579 : H12AffineFastState.Bounded env14579 := by
  intro p hp
  have h : env14579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14578_14579 : H12AffineEnvironment.transform 4 0 env14578 = env14579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14578 == env14579) = true)

def env14580 : List Nat := [2,4,8,16,1,16,128,5,0,21,0,1,129,0,137,2,1,0,21,136,1,0,16,139,9,16,1,1,1,1,20,1,5,1,0,0]

theorem envBound14580 : H12AffineFastState.Bounded env14580 := by
  intro p hp
  have h : env14580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14578_14580 : H12AffineEnvironment.transform 4 1 env14578 = env14580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14578 == env14580) = true)

theorem identity14580 : scanCanonicalize (H12AffineFastState.compose env14580 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound14580 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14581 : List Nat := [2,4,8,16,1,16,8,5,0,21,0,1,9,0,1,2,1,0,21,0,1,0,16,3,9,16,1,1,1,1,20,1,5,1,0,0]

theorem envBound14581 : H12AffineFastState.Bounded env14581 := by
  intro p hp
  have h : env14581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14580_14581 : H12AffineEnvironment.transform 6 8 env14580 = env14581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14580 == env14581) = true)

def leafEnv14581 : List Nat := [2,4,8,16,1,16,8,5,0,21,0,1,9,0,1,2,1,0,21,0,1,0,16,3,20,9,1,16,1,1,1,1,20,1,5,1,4,3,0,0,0,1,1]

def active14581 : List Nat := [0,1,2,3]

def tree14581 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14581 : H12WitnessSearch.Good tree14581 := H12GlobalWitnessIndex.good

theorem leafIdentity14581 : H12AffineFastState.composeSystem env14581 rootObs = leafEnv14581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14581 rootObs == leafEnv14581) = true)

theorem terminalChecked14581 : H12PackedTerminal.terminalCheckFast leafEnv14581 active14581 tree14581 = true := by decide +kernel

def env14582 : List Nat := [2,4,8,16,32,16,128,256,1,272,261,1,388,0,169,295,1,1,272,168,1,1,16,139,268,16,260,1,1,0,20,292,256,260,0,1]

theorem envBound14582 : H12AffineFastState.Bounded env14582 := by
  intro p hp
  have h : env14582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14576_14582 : H12AffineEnvironment.transform 8 1 env14576 = env14582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env14576 == env14582) = true)

theorem identity14582 : scanCanonicalize (H12AffineFastState.compose env14582 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound14582 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14583 : List Nat := [2,4,8,16,32,16,128,141,1,157,136,1,9,0,169,170,1,1,157,168,1,1,16,139,129,16,137,1,1,0,20,169,141,137,0,1]

theorem envBound14583 : H12AffineFastState.Bounded env14583 := by
  intro p hp
  have h : env14583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14582_14583 : H12AffineEnvironment.transform 7 141 env14582 = env14583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env14582 == env14583) = true)

theorem identity14583 : scanCanonicalize (H12AffineFastState.compose env14583 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound14583 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14584 : List Nat := [2,4,8,16,32,16,9,4,1,20,1,1,9,0,32,35,1,1,20,33,1,1,16,2,8,16,0,1,1,0,20,32,4,0,0,1]

theorem envBound14584 : H12AffineFastState.Bounded env14584 := by
  intro p hp
  have h : env14584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14583_14584 : H12AffineEnvironment.transform 6 9 env14583 = env14584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14583 == env14584) = true)

def leafEnv14584 : List Nat := [2,4,8,16,32,16,9,4,1,20,1,1,9,0,32,35,1,1,20,33,1,1,16,2,20,8,1,16,0,1,1,0,20,32,4,0,4,35,0,1,0,1,1]

def active14584 : List Nat := [0,1,2,3,4]

def tree14584 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14584 : H12WitnessSearch.Good tree14584 := H12GlobalWitnessIndex.good

theorem leafIdentity14584 : H12AffineFastState.composeSystem env14584 rootObs = leafEnv14584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14584 rootObs == leafEnv14584) = true)

theorem terminalChecked14584 : H12PackedTerminal.terminalCheckFast leafEnv14584 active14584 tree14584 = true := by decide +kernel

def env14585 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,1,388,0,2989,2595,1,512,272,2988,1,2821,16,139,268,16,2049,1,1,513,20,2593,256,261,0,512]

theorem envBound14585 : H12AffineFastState.Bounded env14585 := by
  intro p hp
  have h : env14585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14574_14585 : H12AffineEnvironment.transform 31 2593 env14574 = env14585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 2593 env14574 == env14585) = true)

theorem identity14585 : scanCanonicalize (H12AffineFastState.compose env14585 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound14585 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14586 : List Nat := [2,4,8,16,32,16,128,256,32,272,2048,1,388,0,2445,2051,1,32,272,2444,1,2341,16,139,268,16,2049,1,1,33,20,2049,256,261,0,32]

theorem envBound14586 : H12AffineFastState.Bounded env14586 := by
  intro p hp
  have h : env14586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14585_14586 : H12AffineEnvironment.transform 8 32 env14585 = env14586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env14585 == env14586) = true)

def env14587 : List Nat := [2,4,8,16,0,16,128,256,0,272,2048,1,388,0,2445,2051,1,0,272,2444,1,2309,16,139,268,16,2049,1,1,1,20,2049,256,261,0,0]

theorem envBound14587 : H12AffineFastState.Bounded env14587 := by
  intro p hp
  have h : env14587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14586_14587 : H12AffineEnvironment.transform 4 0 env14586 = env14587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14586 == env14587) = true)

theorem identity14587 : scanCanonicalize (H12AffineFastState.compose env14587 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound14587 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14588 : List Nat := [2,4,8,16,0,16,128,256,0,272,0,1,388,0,397,3,1,0,272,396,1,261,16,139,268,16,1,1,1,1,20,1,256,261,0,0]

theorem envBound14588 : H12AffineFastState.Bounded env14588 := by
  intro p hp
  have h : env14588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14587_14588 : H12AffineEnvironment.transform 10 0 env14587 = env14588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env14587 == env14588) = true)

def env14589 : List Nat := [2,4,8,16,0,16,8,256,0,272,0,1,268,0,261,3,1,0,272,260,1,261,16,3,268,16,1,1,1,1,20,1,256,261,0,0]

theorem envBound14589 : H12AffineFastState.Bounded env14589 := by
  intro p hp
  have h : env14589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14588_14589 : H12AffineEnvironment.transform 6 8 env14588 = env14589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14588 == env14589) = true)

def leafEnv14589 : List Nat := [2,4,8,16,0,16,8,256,0,272,0,1,268,0,261,3,1,0,272,260,1,261,16,3,20,268,1,16,1,1,1,1,20,1,256,261,4,2,0,0,0,1,1]

def active14589 : List Nat := [0,1,2,3,7]

def tree14589 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14589 : H12WitnessSearch.Good tree14589 := H12GlobalWitnessIndex.good

theorem leafIdentity14589 : H12AffineFastState.composeSystem env14589 rootObs = leafEnv14589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14589 rootObs == leafEnv14589) = true)

theorem terminalChecked14589 : H12PackedTerminal.terminalCheckFast leafEnv14589 active14589 tree14589 = true := by decide +kernel

def env14590 : List Nat := [2,4,8,16,0,16,9,256,0,272,0,1,269,0,260,3,1,0,272,261,1,261,16,2,268,16,1,1,1,1,20,1,256,261,0,0]

theorem envBound14590 : H12AffineFastState.Bounded env14590 := by
  intro p hp
  have h : env14590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14588_14590 : H12AffineEnvironment.transform 6 9 env14588 = env14590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14588 == env14590) = true)

theorem identity14590 : scanCanonicalize (H12AffineFastState.compose env14590 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound14590 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14591 : List Nat := [2,4,8,16,0,16,9,5,0,21,0,1,8,0,1,3,1,0,21,0,1,0,16,2,9,16,1,1,1,1,20,1,5,0,0,0]

theorem envBound14591 : H12AffineFastState.Bounded env14591 := by
  intro p hp
  have h : env14591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14590_14591 : H12AffineEnvironment.transform 7 5 env14590 = env14591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env14590 == env14591) = true)

def leafEnv14591 : List Nat := [2,4,8,16,0,16,9,5,0,21,0,1,8,0,1,3,1,0,21,0,1,0,16,2,20,9,1,16,1,1,1,1,20,1,5,0,4,3,0,0,0,1,1]

def active14591 : List Nat := [0,1,2,3]

def tree14591 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14591 : H12WitnessSearch.Good tree14591 := H12GlobalWitnessIndex.good

theorem leafIdentity14591 : H12AffineFastState.composeSystem env14591 rootObs = leafEnv14591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14591 rootObs == leafEnv14591) = true)

theorem terminalChecked14591 : H12PackedTerminal.terminalCheckFast leafEnv14591 active14591 tree14591 = true := by decide +kernel

def env14592 : List Nat := [2,4,8,16,1,16,128,256,1,272,2048,1,388,0,2445,2051,1,1,272,2444,1,2308,16,139,268,16,2049,1,1,0,20,2049,256,261,0,1]

theorem envBound14592 : H12AffineFastState.Bounded env14592 := by
  intro p hp
  have h : env14592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14586_14592 : H12AffineEnvironment.transform 4 1 env14586 = env14592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14586 == env14592) = true)

theorem identity14592 : scanCanonicalize (H12AffineFastState.compose env14592 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound14592 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14593 : List Nat := [2,4,8,16,1,16,128,256,1,272,136,1,388,0,261,139,1,1,272,260,1,396,16,139,268,16,137,1,1,0,20,137,256,261,0,1]

theorem envBound14593 : H12AffineFastState.Bounded env14593 := by
  intro p hp
  have h : env14593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14592_14593 : H12AffineEnvironment.transform 10 136 env14592 = env14593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env14592 == env14593) = true)

theorem identity14593 : scanCanonicalize (H12AffineFastState.compose env14593 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound14593 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14594 : List Nat := [2,4,8,16,1,16,128,5,1,21,136,1,129,0,0,139,1,1,21,1,1,137,16,139,9,16,137,1,1,0,20,137,5,0,0,1]

theorem envBound14594 : H12AffineFastState.Bounded env14594 := by
  intro p hp
  have h : env14594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14593_14594 : H12AffineEnvironment.transform 7 5 env14593 = env14594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env14593 == env14594) = true)

def leafEnv14594 : List Nat := [2,4,8,16,1,16,128,5,1,21,136,1,129,0,0,139,1,1,21,1,1,137,16,139,20,9,1,16,137,1,1,0,20,137,5,0,4,2,0,1,0,1,1]

def active14594 : List Nat := [0,1,2,3,6]

def tree14594 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14594 : H12WitnessSearch.Good tree14594 := H12GlobalWitnessIndex.good

theorem leafIdentity14594 : H12AffineFastState.composeSystem env14594 rootObs = leafEnv14594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14594 rootObs == leafEnv14594) = true)

theorem terminalChecked14594 : H12PackedTerminal.terminalCheckFast leafEnv14594 active14594 tree14594 = true := by decide +kernel

def env14595 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,0,388,1,2989,65536,0,512,273,2988,0,2821,16,68264,268,16,2049,0,0,513,21,4294967296,256,4295033095,1,512]

theorem envBound14595 : H12AffineFastState.Bounded env14595 := by
  intro p hp
  have h : env14595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14572_14595 : H12AffineEnvironment.transform 9 273 env14572 = env14595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env14572 == env14595) = true)

def env14596 : List Nat := [2,4,8,16,32,16,128,256,512,273,940,0,388,1,1,65536,0,512,273,0,0,169,16,65796,268,16,941,0,0,513,21,4294967296,256,4295033095,1,512]

theorem envBound14596 : H12AffineFastState.Bounded env14596 := by
  intro p hp
  have h : env14596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14595_14596 : H12AffineEnvironment.transform 10 940 env14595 = env14596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 940 env14595 == env14596) = true)

def env14597 : List Nat := [2,4,8,16,32,16,8,256,512,273,804,0,268,1,1,65536,0,512,273,0,0,33,16,65796,268,16,805,0,0,513,21,4294967296,256,4295033095,1,512]

theorem envBound14597 : H12AffineFastState.Bounded env14597 := by
  intro p hp
  have h : env14597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14596_14597 : H12AffineEnvironment.transform 6 8 env14596 = env14597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14596 == env14597) = true)

theorem identity14597 : scanCanonicalize (H12AffineFastState.compose env14597 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 66310) := by decide +kernel

theorem selectedBound14597 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14598 : List Nat := [2,4,8,16,32,16,8,256,512,273,804,0,268,1,1,65536,0,512,273,0,0,33,16,65796,268,16,805,0,0,513,21,66310,256,513,1,512]

theorem envBound14598 : H12AffineFastState.Bounded env14598 := by
  intro p hp
  have h : env14598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14597_14598 : H12AffineEnvironment.transform 31 66310 env14597 = env14598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 66310 env14597 == env14598) = true)

def env14599 : List Nat := [2,4,8,16,32,16,8,256,292,273,0,0,268,1,1,65536,0,292,273,0,0,33,16,65796,268,16,1,0,0,293,21,65570,256,293,1,292]

theorem envBound14599 : H12AffineFastState.Bounded env14599 := by
  intro p hp
  have h : env14599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14598_14599 : H12AffineEnvironment.transform 8 292 env14598 = env14599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env14598 == env14599) = true)

theorem identity14599 : scanCanonicalize (H12AffineFastState.compose env14599 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound14599 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14600 : List Nat := [2,4,8,16,32,16,8,36,0,53,0,0,40,1,1,65536,0,0,53,0,0,33,16,65568,40,16,1,0,0,1,21,65570,36,1,1,0]

theorem envBound14600 : H12AffineFastState.Bounded env14600 := by
  intro p hp
  have h : env14600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14599_14600 : H12AffineEnvironment.transform 7 36 env14599 = env14600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env14599 == env14600) = true)

def env14601 : List Nat := [2,4,8,16,0,16,8,4,0,21,0,0,8,1,1,65536,0,0,21,0,0,1,16,65536,8,16,1,0,0,1,21,65538,4,1,1,0]

theorem envBound14601 : H12AffineFastState.Bounded env14601 := by
  intro p hp
  have h : env14601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14600_14601 : H12AffineEnvironment.transform 4 0 env14600 = env14601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14600 == env14601) = true)

def leafEnv14601 : List Nat := [2,4,8,16,0,16,8,4,0,21,0,0,8,1,1,65536,0,0,21,0,0,1,16,65536,21,8,1,16,1,0,0,1,21,65538,4,1,4,2,1,0,0,0,1]

def active14601 : List Nat := [0,1,2,3,15]

def tree14601 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14601 : H12WitnessSearch.Good tree14601 := H12GlobalWitnessIndex.good

theorem leafIdentity14601 : H12AffineFastState.composeSystem env14601 rootObs = leafEnv14601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14601 rootObs == leafEnv14601) = true)

theorem terminalChecked14601 : H12PackedTerminal.terminalCheckFast leafEnv14601 active14601 tree14601 = true := by decide +kernel

def env14602 : List Nat := [2,4,8,16,1,16,8,5,0,20,0,0,9,1,1,65536,0,0,20,0,0,0,16,65537,9,16,1,0,0,1,21,65539,5,1,1,0]

theorem envBound14602 : H12AffineFastState.Bounded env14602 := by
  intro p hp
  have h : env14602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14600_14602 : H12AffineEnvironment.transform 4 1 env14600 = env14602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14600 == env14602) = true)

theorem identity14602 : scanCanonicalize (H12AffineFastState.compose env14602 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound14602 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14603 : List Nat := [2,4,8,16,1,16,8,5,0,20,0,0,9,1,1,2,0,0,20,0,0,0,16,3,9,16,1,0,0,1,21,1,5,1,1,0]

theorem envBound14603 : H12AffineFastState.Bounded env14603 := by
  intro p hp
  have h : env14603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14602_14603 : H12AffineEnvironment.transform 15 2 env14602 = env14603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env14602 == env14603) = true)

def leafEnv14603 : List Nat := [2,4,8,16,1,16,8,5,0,20,0,0,9,1,1,2,0,0,20,0,0,0,16,3,21,9,1,16,1,0,0,1,21,1,5,1,4,3,1,0,0,0,1]

def active14603 : List Nat := [0,1,2,3]

def tree14603 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14603 : H12WitnessSearch.Good tree14603 := H12GlobalWitnessIndex.good

theorem leafIdentity14603 : H12AffineFastState.composeSystem env14603 rootObs = leafEnv14603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14603 rootObs == leafEnv14603) = true)

theorem terminalChecked14603 : H12PackedTerminal.terminalCheckFast leafEnv14603 active14603 tree14603 = true := by decide +kernel

def env14604 : List Nat := [2,4,8,16,32,16,8,256,293,273,1,0,268,1,1,65536,0,293,273,0,0,33,16,65796,268,16,0,0,0,292,21,65571,256,292,1,293]

theorem envBound14604 : H12AffineFastState.Bounded env14604 := by
  intro p hp
  have h : env14604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14598_14604 : H12AffineEnvironment.transform 8 293 env14598 = env14604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env14598 == env14604) = true)

theorem identity14604 : scanCanonicalize (H12AffineFastState.compose env14604 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound14604 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14605 : List Nat := [2,4,8,16,32,16,8,256,293,273,1,0,268,1,1,35,0,293,273,0,0,33,16,295,268,16,0,0,0,292,21,0,256,292,1,293]

theorem envBound14605 : H12AffineFastState.Bounded env14605 := by
  intro p hp
  have h : env14605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14604_14605 : H12AffineEnvironment.transform 15 35 env14604 = env14605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env14604 == env14605) = true)

def env14606 : List Nat := [2,4,8,16,0,16,8,256,261,273,1,0,268,1,1,3,0,261,273,0,0,1,16,263,268,16,0,0,0,260,21,0,256,260,1,261]

theorem envBound14606 : H12AffineFastState.Bounded env14606 := by
  intro p hp
  have h : env14606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14605_14606 : H12AffineEnvironment.transform 4 0 env14605 = env14606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14605 == env14606) = true)

theorem identity14606 : scanCanonicalize (H12AffineFastState.compose env14606 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound14606 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14607 : List Nat := [2,4,8,16,0,16,8,5,0,20,1,0,9,1,1,3,0,0,20,0,0,1,16,2,9,16,0,0,0,1,21,0,5,1,1,0]

theorem envBound14607 : H12AffineFastState.Bounded env14607 := by
  intro p hp
  have h : env14607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14606_14607 : H12AffineEnvironment.transform 7 5 env14606 = env14607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env14606 == env14607) = true)

def leafEnv14607 : List Nat := [2,4,8,16,0,16,8,5,0,20,1,0,9,1,1,3,0,0,20,0,0,1,16,2,21,9,1,16,0,0,0,1,21,0,5,1,4,3,1,0,0,0,1]

def active14607 : List Nat := [0,1,2,3]

def tree14607 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14607 : H12WitnessSearch.Good tree14607 := H12GlobalWitnessIndex.good

theorem leafIdentity14607 : H12AffineFastState.composeSystem env14607 rootObs = leafEnv14607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14607 rootObs == leafEnv14607) = true)

theorem terminalChecked14607 : H12PackedTerminal.terminalCheckFast leafEnv14607 active14607 tree14607 = true := by decide +kernel

def env14608 : List Nat := [2,4,8,16,1,16,8,256,260,273,1,0,268,1,1,2,0,260,273,0,0,0,16,262,268,16,0,0,0,261,21,0,256,261,1,260]

theorem envBound14608 : H12AffineFastState.Bounded env14608 := by
  intro p hp
  have h : env14608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14605_14608 : H12AffineEnvironment.transform 4 1 env14605 = env14608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14605 == env14608) = true)

def env14609 : List Nat := [2,4,8,16,32,16,9,256,512,273,805,0,269,1,1,65536,0,512,273,0,0,32,16,65796,268,16,804,0,0,513,21,4294967296,256,4295033095,1,512]

theorem envBound14609 : H12AffineFastState.Bounded env14609 := by
  intro p hp
  have h : env14609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14596_14609 : H12AffineEnvironment.transform 6 9 env14596 = env14609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14596 == env14609) = true)

theorem identity14609 : scanCanonicalize (H12AffineFastState.compose env14609 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 65570) := by decide +kernel

theorem selectedBound14609 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14610 : List Nat := [2,4,8,16,32,16,9,256,512,273,805,0,269,1,1,65536,0,512,273,0,0,32,16,65796,268,16,804,0,0,513,21,65570,256,293,1,512]

theorem envBound14610 : H12AffineFastState.Bounded env14610 := by
  intro p hp
  have h : env14610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14609_14610 : H12AffineEnvironment.transform 31 65570 env14609 = env14610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 65570 env14609 == env14610) = true)

theorem identity14610 : scanCanonicalize (H12AffineFastState.compose env14610 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound14610 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14611 : List Nat := [2,4,8,16,32,16,9,256,32,273,261,0,269,1,1,65536,0,32,273,0,0,32,16,65796,268,16,260,0,0,33,21,65570,256,293,1,32]

theorem envBound14611 : H12AffineFastState.Bounded env14611 := by
  intro p hp
  have h : env14611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14610_14611 : H12AffineEnvironment.transform 8 32 env14610 = env14611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env14610 == env14611) = true)

def env14612 : List Nat := [2,4,8,16,32,16,9,36,32,53,33,0,41,1,1,65536,0,32,53,0,0,32,16,65568,40,16,32,0,0,33,21,65570,36,1,1,32]

theorem envBound14612 : H12AffineFastState.Bounded env14612 := by
  intro p hp
  have h : env14612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14611_14612 : H12AffineEnvironment.transform 7 36 env14611 = env14612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env14611 == env14612) = true)

theorem identity14612 : scanCanonicalize (H12AffineFastState.compose env14612 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound14612 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14613 : List Nat := [2,4,8,16,32,16,9,36,32,53,33,0,41,1,1,35,0,32,53,0,0,32,16,3,40,16,32,0,0,33,21,1,36,1,1,32]

theorem envBound14613 : H12AffineFastState.Bounded env14613 := by
  intro p hp
  have h : env14613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14612_14613 : H12AffineEnvironment.transform 15 35 env14612 = env14613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env14612 == env14613) = true)

theorem identity14613 : scanCanonicalize (H12AffineFastState.compose env14613 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound14613 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env14614 : List Nat := [2,4,8,16,1,16,9,5,1,20,0,0,8,1,1,2,0,1,20,0,0,1,16,3,9,16,1,0,0,0,21,1,5,1,1,1]

theorem envBound14614 : H12AffineFastState.Bounded env14614 := by
  intro p hp
  have h : env14614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14613_14614 : H12AffineEnvironment.transform 4 1 env14613 = env14614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14613 == env14614) = true)

def leafEnv14614 : List Nat := [2,4,8,16,1,16,9,5,1,20,0,0,8,1,1,2,0,1,20,0,0,1,16,3,21,9,1,16,1,0,0,0,21,1,5,1,4,3,1,1,0,0,1]

def active14614 : List Nat := [0,1,2,3]

def tree14614 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14614 : H12WitnessSearch.Good tree14614 := H12GlobalWitnessIndex.good

theorem leafIdentity14614 : H12AffineFastState.composeSystem env14614 rootObs = leafEnv14614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14614 rootObs == leafEnv14614) = true)

theorem terminalChecked14614 : H12PackedTerminal.terminalCheckFast leafEnv14614 active14614 tree14614 = true := by decide +kernel

def env14615 : List Nat := [2,4,8,16,32,16,9,37,32,52,32,0,40,1,1,65536,0,32,52,0,0,32,16,65569,41,16,33,0,0,33,21,65570,37,0,1,32]

theorem envBound14615 : H12AffineFastState.Bounded env14615 := by
  intro p hp
  have h : env14615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14611_14615 : H12AffineEnvironment.transform 7 37 env14611 = env14615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env14611 == env14615) = true)

def env14616 : List Nat := [2,4,8,16,0,16,9,5,0,20,0,0,8,1,1,65536,0,0,20,0,0,0,16,65537,9,16,1,0,0,1,21,65538,5,0,1,0]

theorem envBound14616 : H12AffineFastState.Bounded env14616 := by
  intro p hp
  have h : env14616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14615_14616 : H12AffineEnvironment.transform 4 0 env14615 = env14616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14615 == env14616) = true)

theorem identity14616 : scanCanonicalize (H12AffineFastState.compose env14616 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound14616 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env14617 : List Nat := [2,4,8,16,0,16,9,5,0,20,0,0,8,1,1,3,0,0,20,0,0,0,16,2,9,16,1,0,0,1,21,1,5,0,1,0]

theorem envBound14617 : H12AffineFastState.Bounded env14617 := by
  intro p hp
  have h : env14617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14616_14617 : H12AffineEnvironment.transform 15 3 env14616 = env14617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env14616 == env14617) = true)

def leafEnv14617 : List Nat := [2,4,8,16,0,16,9,5,0,20,0,0,8,1,1,3,0,0,20,0,0,0,16,2,21,9,1,16,1,0,0,1,21,1,5,0,4,3,1,0,0,0,1]

def active14617 : List Nat := [0,1,2,3]

def tree14617 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14617 : H12WitnessSearch.Good tree14617 := H12GlobalWitnessIndex.good

theorem leafIdentity14617 : H12AffineFastState.composeSystem env14617 rootObs = leafEnv14617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14617 rootObs == leafEnv14617) = true)

theorem terminalChecked14617 : H12PackedTerminal.terminalCheckFast leafEnv14617 active14617 tree14617 = true := by decide +kernel

def env14618 : List Nat := [2,4,8,16,1,16,9,4,1,21,1,0,9,1,1,65536,0,1,21,0,0,1,16,65536,8,16,0,0,0,0,21,65539,4,0,1,1]

theorem envBound14618 : H12AffineFastState.Bounded env14618 := by
  intro p hp
  have h : env14618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14615_14618 : H12AffineEnvironment.transform 4 1 env14615 = env14618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14615 == env14618) = true)

def leafEnv14618 : List Nat := [2,4,8,16,1,16,9,4,1,21,1,0,9,1,1,65536,0,1,21,0,0,1,16,65536,21,8,1,16,0,0,0,0,21,65539,4,0,4,2,1,1,0,0,1]

def active14618 : List Nat := [0,1,2,3,15]

def tree14618 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14618 : H12WitnessSearch.Good tree14618 := H12GlobalWitnessIndex.good

theorem leafIdentity14618 : H12AffineFastState.composeSystem env14618 rootObs = leafEnv14618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14618 rootObs == leafEnv14618) = true)

theorem terminalChecked14618 : H12PackedTerminal.terminalCheckFast leafEnv14618 active14618 tree14618 = true := by decide +kernel

def env14619 : List Nat := [2,4,8,16,32,16,128,256,512,273,941,0,388,1,0,65536,0,512,273,1,0,168,16,65797,268,16,940,0,0,513,21,4294967296,256,4295033095,1,512]

theorem envBound14619 : H12AffineFastState.Bounded env14619 := by
  intro p hp
  have h : env14619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14595_14619 : H12AffineEnvironment.transform 10 941 env14595 = env14619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 941 env14595 == env14619) = true)

def env14620 : List Nat := [2,4,8,16,32,16,8,256,512,273,805,0,268,1,0,65536,0,512,273,1,0,32,16,65797,268,16,804,0,0,513,21,4294967296,256,4295033095,1,512]

theorem envBound14620 : H12AffineFastState.Bounded env14620 := by
  intro p hp
  have h : env14620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14619_14620 : H12AffineEnvironment.transform 6 8 env14619 = env14620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14619 == env14620) = true)

theorem identity14620 : scanCanonicalize (H12AffineFastState.compose env14620 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 804) := by decide +kernel

theorem selectedBound14620 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14621 : List Nat := [2,4,8,16,32,16,8,256,512,273,805,0,268,1,0,65536,0,512,273,1,0,32,16,65797,268,16,804,0,0,513,21,804,256,66083,1,512]

theorem envBound14621 : H12AffineFastState.Bounded env14621 := by
  intro p hp
  have h : env14621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14620_14621 : H12AffineEnvironment.transform 31 804 env14620 = env14621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 804 env14620 == env14621) = true)

theorem identity14621 : scanCanonicalize (H12AffineFastState.compose env14621 (packedSelected [4,6] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound14621 : packedSelected [4,6] rootPS < 2^1333 := by decide +kernel

def env14622 : List Nat := [2,4,8,16,32,16,8,256,32,273,261,0,268,1,0,65536,0,32,273,1,0,32,16,65797,268,16,260,0,0,33,21,260,256,65539,1,32]

theorem envBound14622 : H12AffineFastState.Bounded env14622 := by
  intro p hp
  have h : env14622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14621_14622 : H12AffineEnvironment.transform 8 32 env14621 = env14622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env14621 == env14622) = true)

def env14623 : List Nat := [2,4,8,16,0,16,8,256,0,273,261,0,268,1,0,65536,0,0,273,1,0,0,16,65797,268,16,260,0,0,1,21,260,256,65539,1,0]

theorem envBound14623 : H12AffineFastState.Bounded env14623 := by
  intro p hp
  have h : env14623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14622_14623 : H12AffineEnvironment.transform 4 0 env14622 = env14623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14622 == env14623) = true)

def env14624 : List Nat := [2,4,8,16,0,16,8,4,0,21,1,0,8,1,0,65536,0,0,21,1,0,0,16,65537,8,16,0,0,0,1,21,0,4,65539,1,0]

theorem envBound14624 : H12AffineFastState.Bounded env14624 := by
  intro p hp
  have h : env14624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14623_14624 : H12AffineEnvironment.transform 7 4 env14623 = env14624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env14623 == env14624) = true)

def env14625 : List Nat := [2,4,8,16,0,16,8,5,0,20,0,0,9,1,0,65536,0,0,20,1,0,0,16,65536,9,16,1,0,0,1,21,1,5,65539,1,0]

theorem envBound14625 : H12AffineFastState.Bounded env14625 := by
  intro p hp
  have h : env14625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14623_14625 : H12AffineEnvironment.transform 7 5 env14623 = env14625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env14623 == env14625) = true)

theorem identity14625 : scanCanonicalize (H12AffineFastState.compose env14625 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound14625 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14626 : List Nat := [2,4,8,16,0,16,8,5,0,20,0,0,9,1,0,3,0,0,20,1,0,0,16,3,9,16,1,0,0,1,21,1,5,0,1,0]

theorem envBound14626 : H12AffineFastState.Bounded env14626 := by
  intro p hp
  have h : env14626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14625_14626 : H12AffineEnvironment.transform 15 3 env14625 = env14626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env14625 == env14626) = true)

def leafEnv14626 : List Nat := [2,4,8,16,0,16,8,5,0,20,0,0,9,1,0,3,0,0,20,1,0,0,16,3,21,9,1,16,1,0,0,1,21,1,5,0,4,2,1,0,0,0,1]

def active14626 : List Nat := [0,1,2,3]

def tree14626 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14626 : H12WitnessSearch.Good tree14626 := H12GlobalWitnessIndex.good

theorem leafIdentity14626 : H12AffineFastState.composeSystem env14626 rootObs = leafEnv14626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14626 rootObs == leafEnv14626) = true)

theorem terminalChecked14626 : H12PackedTerminal.terminalCheckFast leafEnv14626 active14626 tree14626 = true := by decide +kernel

def env14627 : List Nat := [2,4,8,16,1,16,8,256,1,273,261,0,268,1,0,65536,0,1,273,1,0,1,16,65797,268,16,260,0,0,0,21,260,256,65539,1,1]

theorem envBound14627 : H12AffineFastState.Bounded env14627 := by
  intro p hp
  have h : env14627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14622_14627 : H12AffineEnvironment.transform 4 1 env14622 = env14627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14622 == env14627) = true)

theorem identity14627 : scanCanonicalize (H12AffineFastState.compose env14627 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound14627 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14628 : List Nat := [2,4,8,16,1,16,8,256,1,273,261,0,268,1,0,262,0,1,273,1,0,1,16,3,268,16,260,0,0,0,21,260,256,261,1,1]

theorem envBound14628 : H12AffineFastState.Bounded env14628 := by
  intro p hp
  have h : env14628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14627_14628 : H12AffineEnvironment.transform 15 262 env14627 = env14628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env14627 == env14628) = true)

theorem identity14628 : scanCanonicalize (H12AffineFastState.compose env14628 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound14628 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14629 : List Nat := [2,4,8,16,1,16,8,5,1,20,0,0,9,1,0,3,0,1,20,1,0,1,16,3,9,16,1,0,0,0,21,1,5,0,1,1]

theorem envBound14629 : H12AffineFastState.Bounded env14629 := by
  intro p hp
  have h : env14629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14628_14629 : H12AffineEnvironment.transform 7 5 env14628 = env14629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env14628 == env14629) = true)

def leafEnv14629 : List Nat := [2,4,8,16,1,16,8,5,1,20,0,0,9,1,0,3,0,1,20,1,0,1,16,3,21,9,1,16,1,0,0,0,21,1,5,0,4,2,1,1,0,0,1]

def active14629 : List Nat := [0,1,2,3]

def tree14629 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14629 : H12WitnessSearch.Good tree14629 := H12GlobalWitnessIndex.good

theorem leafIdentity14629 : H12AffineFastState.composeSystem env14629 rootObs = leafEnv14629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14629 rootObs == leafEnv14629) = true)

theorem terminalChecked14629 : H12PackedTerminal.terminalCheckFast leafEnv14629 active14629 tree14629 = true := by decide +kernel

def env14630 : List Nat := [2,4,8,16,32,16,9,256,512,273,804,0,269,1,0,65536,0,512,273,1,0,33,16,65797,268,16,805,0,0,513,21,4294967296,256,4295033095,1,512]

theorem envBound14630 : H12AffineFastState.Bounded env14630 := by
  intro p hp
  have h : env14630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14619_14630 : H12AffineEnvironment.transform 6 9 env14619 = env14630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14619 == env14630) = true)

theorem identity14630 : scanCanonicalize (H12AffineFastState.compose env14630 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 0) := by decide +kernel

theorem selectedBound14630 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14631 : List Nat := [2,4,8,16,32,16,9,256,512,273,804,0,269,1,0,65536,0,512,273,1,0,33,16,65797,268,16,805,0,0,513,21,0,256,65799,1,512]

theorem envBound14631 : H12AffineFastState.Bounded env14631 := by
  intro p hp
  have h : env14631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14630_14631 : H12AffineEnvironment.transform 31 0 env14630 = env14631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 0 env14630 == env14631) = true)

def env14632 : List Nat := [2,4,8,16,32,16,9,36,512,53,512,0,41,1,0,65536,0,512,53,1,0,33,16,65569,40,16,513,0,0,513,21,0,36,65571,1,512]

theorem envBound14632 : H12AffineFastState.Bounded env14632 := by
  intro p hp
  have h : env14632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14631_14632 : H12AffineEnvironment.transform 7 36 env14631 = env14632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env14631 == env14632) = true)

theorem identity14632 : scanCanonicalize (H12AffineFastState.compose env14632 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound14632 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14633 : List Nat := [2,4,8,16,32,16,9,36,1,53,1,0,41,1,0,65536,0,1,53,1,0,33,16,65569,40,16,0,0,0,0,21,0,36,65571,1,1]

theorem envBound14633 : H12AffineFastState.Bounded env14633 := by
  intro p hp
  have h : env14633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14632_14633 : H12AffineEnvironment.transform 8 1 env14632 = env14633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env14632 == env14633) = true)

def env14634 : List Nat := [2,4,8,16,0,16,9,4,1,21,1,0,9,1,0,65536,0,1,21,1,0,1,16,65537,8,16,0,0,0,0,21,0,4,65539,1,1]

theorem envBound14634 : H12AffineFastState.Bounded env14634 := by
  intro p hp
  have h : env14634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14633_14634 : H12AffineEnvironment.transform 4 0 env14633 = env14634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14633 == env14634) = true)

def leafEnv14634 : List Nat := [2,4,8,16,0,16,9,4,1,21,1,0,9,1,0,65536,0,1,21,1,0,1,16,65537,21,8,1,16,0,0,0,0,21,0,4,65539,4,3,1,1,0,0,1]

def active14634 : List Nat := [0,1,2,3,15]

def tree14634 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14634 : H12WitnessSearch.Good tree14634 := H12GlobalWitnessIndex.good

theorem leafIdentity14634 : H12AffineFastState.composeSystem env14634 rootObs = leafEnv14634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14634 rootObs == leafEnv14634) = true)

theorem terminalChecked14634 : H12PackedTerminal.terminalCheckFast leafEnv14634 active14634 tree14634 = true := by decide +kernel

def env14635 : List Nat := [2,4,8,16,1,16,9,5,1,20,1,0,8,1,0,65536,0,1,20,1,0,0,16,65536,9,16,0,0,0,0,21,0,5,65538,1,1]

theorem envBound14635 : H12AffineFastState.Bounded env14635 := by
  intro p hp
  have h : env14635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14633_14635 : H12AffineEnvironment.transform 4 1 env14633 = env14635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14633 == env14635) = true)

theorem identity14635 : scanCanonicalize (H12AffineFastState.compose env14635 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound14635 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14636 : List Nat := [2,4,8,16,1,16,9,5,1,20,1,0,8,1,0,2,0,1,20,1,0,0,16,2,9,16,0,0,0,0,21,0,5,0,1,1]

theorem envBound14636 : H12AffineFastState.Bounded env14636 := by
  intro p hp
  have h : env14636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14635_14636 : H12AffineEnvironment.transform 15 2 env14635 = env14636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env14635 == env14636) = true)

def leafEnv14636 : List Nat := [2,4,8,16,1,16,9,5,1,20,1,0,8,1,0,2,0,1,20,1,0,0,16,2,21,9,1,16,0,0,0,0,21,0,5,0,4,2,1,1,0,0,1]

def active14636 : List Nat := [0,1,2,3]

def tree14636 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14636 : H12WitnessSearch.Good tree14636 := H12GlobalWitnessIndex.good

theorem leafIdentity14636 : H12AffineFastState.composeSystem env14636 rootObs = leafEnv14636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14636 rootObs == leafEnv14636) = true)

theorem terminalChecked14636 : H12PackedTerminal.terminalCheckFast leafEnv14636 active14636 tree14636 = true := by decide +kernel

def env14637 : List Nat := [2,4,8,16,32,16,9,37,512,52,513,0,40,1,0,65536,0,512,52,1,0,33,16,65568,41,16,512,0,0,513,21,0,37,65570,1,512]

theorem envBound14637 : H12AffineFastState.Bounded env14637 := by
  intro p hp
  have h : env14637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14631_14637 : H12AffineEnvironment.transform 7 37 env14631 = env14637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env14631 == env14637) = true)

theorem identity14637 : scanCanonicalize (H12AffineFastState.compose env14637 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 546) := by decide +kernel

theorem selectedBound14637 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14638 : List Nat := [2,4,8,16,32,16,9,37,512,52,513,0,40,1,0,546,0,512,52,1,0,33,16,514,41,16,512,0,0,513,21,0,37,512,1,512]

theorem envBound14638 : H12AffineFastState.Bounded env14638 := by
  intro p hp
  have h : env14638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14637_14638 : H12AffineEnvironment.transform 15 546 env14637 = env14638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 546 env14637 == env14638) = true)

def env14639 : List Nat := [2,4,8,16,32,16,9,37,0,52,1,0,40,1,0,34,0,0,52,1,0,33,16,2,41,16,0,0,0,1,21,0,37,0,1,0]

theorem envBound14639 : H12AffineFastState.Bounded env14639 := by
  intro p hp
  have h : env14639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14638_14639 : H12AffineEnvironment.transform 8 0 env14638 = env14639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env14638 == env14639) = true)

def env14640 : List Nat := [2,4,8,16,32,16,9,37,1,52,0,0,40,1,0,35,0,1,52,1,0,33,16,3,41,16,1,0,0,0,21,0,37,1,1,1]

theorem envBound14640 : H12AffineFastState.Bounded env14640 := by
  intro p hp
  have h : env14640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14638_14640 : H12AffineEnvironment.transform 8 1 env14638 = env14640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env14638 == env14640) = true)

theorem identity14640 : scanCanonicalize (H12AffineFastState.compose env14640 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound14640 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14641 : List Nat := [2,4,8,16,0,16,9,5,1,20,0,0,8,1,0,3,0,1,20,1,0,1,16,3,9,16,1,0,0,0,21,0,5,1,1,1]

theorem envBound14641 : H12AffineFastState.Bounded env14641 := by
  intro p hp
  have h : env14641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14640_14641 : H12AffineEnvironment.transform 4 0 env14640 = env14641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14640 == env14641) = true)

def leafEnv14641 : List Nat := [2,4,8,16,0,16,9,5,1,20,0,0,8,1,0,3,0,1,20,1,0,1,16,3,21,9,1,16,1,0,0,0,21,0,5,1,4,2,1,1,0,0,1]

def active14641 : List Nat := [0,1,2,3]

def tree14641 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14641 : H12WitnessSearch.Good tree14641 := H12GlobalWitnessIndex.good

theorem leafIdentity14641 : H12AffineFastState.composeSystem env14641 rootObs = leafEnv14641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14641 rootObs == leafEnv14641) = true)

theorem terminalChecked14641 : H12PackedTerminal.terminalCheckFast leafEnv14641 active14641 tree14641 = true := by decide +kernel

def env14642 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,388,1297,32768,65536,1296,512,1025,32769,1296,4194304,17,98565,268,17,134217728,1296,1297,1073741824,1284,4294967296,256,4299260335,138413588,512]

theorem envBound14642 : H12AffineFastState.Bounded env14642 := by
  intro p hp
  have h : env14642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14567_14642 : H12AffineEnvironment.transform 5 17 env14567 = env14642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14567 == env14642) = true)

theorem identity14642 : scanCanonicalize (H12AffineFastState.compose env14642 (packedSelected [3,5,10] rootPS)) = affineNative (2^(29+1) ^^^ 4262539) := by decide +kernel

theorem selectedBound14642 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env14643 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,388,1297,32768,65536,1296,512,1025,32769,1296,4194304,17,98565,268,17,134217728,1296,1297,4262539,1284,4294967296,256,4299260335,138413588,512]

theorem envBound14643 : H12AffineFastState.Bounded env14643 := by
  intro p hp
  have h : env14643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14642_14643 : H12AffineEnvironment.transform 29 4262539 env14642 = env14643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4262539 env14642 == env14643) = true)

theorem identity14643 : scanCanonicalize (H12AffineFastState.compose env14643 (packedSelected [1,8,19] rootPS)) = affineNative (2^(26+1) ^^^ 4227333) := by decide +kernel

theorem selectedBound14643 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env14644 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,388,1297,32768,65536,1296,512,1025,32769,1296,4194304,17,98565,268,17,4227333,1296,1297,4262539,1284,4294967296,256,4299260335,34577,512]

theorem envBound14644 : H12AffineFastState.Bounded env14644 := by
  intro p hp
  have h : env14644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14643_14644 : H12AffineEnvironment.transform 26 4227333 env14643 = env14644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4227333 env14643 == env14644) = true)

theorem identity14644 : scanCanonicalize (H12AffineFastState.compose env14644 (packedSelected [1,5,12] rootPS)) = affineNative (2^(21+1) ^^^ 2179) := by decide +kernel

theorem selectedBound14644 : packedSelected [1,5,12] rootPS < 2^1333 := by decide +kernel

def env14645 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,388,1297,32768,65536,1296,512,1025,32769,1296,2179,17,98565,268,17,35206,1296,1297,66056,1284,4294967296,256,4295067948,34577,512]

theorem envBound14645 : H12AffineFastState.Bounded env14645 := by
  intro p hp
  have h : env14645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14644_14645 : H12AffineEnvironment.transform 21 2179 env14644 = env14645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2179 env14644 == env14645) = true)

theorem identity14645 : scanCanonicalize (H12AffineFastState.compose env14645 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 512) := by decide +kernel

theorem selectedBound14645 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env14646 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,388,1297,512,65536,1296,512,1025,513,1296,2179,17,66309,268,17,2950,1296,1297,66056,1284,4294967296,256,4295035692,1297,512]

theorem envBound14646 : H12AffineFastState.Bounded env14646 := by
  intro p hp
  have h : env14646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14645_14646 : H12AffineEnvironment.transform 14 512 env14645 = env14646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 512 env14645 == env14646) = true)

theorem identity14646 : scanCanonicalize (H12AffineFastState.compose env14646 (packedSelected [1,3,5] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound14646 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env14647 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,388,1297,512,263,1296,512,1025,513,1296,2179,17,514,268,17,2950,1296,1297,783,1284,4294967296,256,4294969899,1297,512]

theorem envBound14647 : H12AffineFastState.Bounded env14647 := by
  intro p hp
  have h : env14647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14646_14647 : H12AffineEnvironment.transform 15 263 env14646 = env14647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env14646 == env14647) = true)

theorem identity14647 : scanCanonicalize (H12AffineFastState.compose env14647 (packedSelected [1,3,8] rootPS)) = affineNative (2^(10+1) ^^^ 428) := by decide +kernel

theorem selectedBound14647 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env14648 : List Nat := [2,4,8,16,32,17,128,256,512,1024,428,1296,388,1297,512,263,1296,512,1025,513,1296,303,17,514,268,17,554,1296,1297,783,1284,4294967296,256,4294968199,1297,512]

theorem envBound14648 : H12AffineFastState.Bounded env14648 := by
  intro p hp
  have h : env14648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14647_14648 : H12AffineEnvironment.transform 10 428 env14647 = env14648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 428 env14647 == env14648) = true)

theorem identity14648 : scanCanonicalize (H12AffineFastState.compose env14648 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 163) := by decide +kernel

theorem selectedBound14648 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14649 : List Nat := [2,4,8,16,32,17,128,256,163,1024,428,1296,388,1297,163,263,1296,163,1025,162,1296,303,17,161,268,17,137,1296,1297,428,1284,4294967296,256,4294967588,1297,163]

theorem envBound14649 : H12AffineFastState.Bounded env14649 := by
  intro p hp
  have h : env14649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14648_14649 : H12AffineEnvironment.transform 8 163 env14648 = env14649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 163 env14648 == env14649) = true)

theorem identity14649 : scanCanonicalize (H12AffineFastState.compose env14649 (packedSelected [2,4] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound14649 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env14650 : List Nat := [2,4,8,16,10,17,128,256,137,1024,390,1296,388,1297,137,263,1296,137,1025,136,1296,261,17,139,268,17,137,1296,1297,390,1284,4294967296,256,4294967566,1297,137]

theorem envBound14650 : H12AffineFastState.Bounded env14650 := by
  intro p hp
  have h : env14650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14649_14650 : H12AffineEnvironment.transform 4 10 env14649 = env14650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env14649 == env14650) = true)

theorem identity14650 : scanCanonicalize (H12AffineFastState.compose env14650 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 391) := by decide +kernel

theorem selectedBound14650 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14651 : List Nat := [2,4,8,16,10,17,128,256,137,1024,390,1296,388,1297,137,263,1296,137,1025,136,1296,261,17,139,268,17,137,1296,1297,390,1284,391,256,137,1297,137]

theorem envBound14651 : H12AffineFastState.Bounded env14651 := by
  intro p hp
  have h : env14651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14650_14651 : H12AffineEnvironment.transform 31 391 env14650 = env14651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 391 env14650 == env14651) = true)

theorem identity14651 : scanCanonicalize (H12AffineFastState.compose env14651 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound14651 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env14652 : List Nat := [2,4,8,16,10,17,128,14,137,1024,136,1054,138,1055,137,9,1054,137,1025,136,1054,11,17,139,2,17,137,1054,1055,136,1034,137,14,137,1055,137]

theorem envBound14652 : H12AffineFastState.Bounded env14652 := by
  intro p hp
  have h : env14652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14651_14652 : H12AffineEnvironment.transform 7 14 env14651 = env14652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env14651 == env14652) = true)

theorem identity14652 : scanCanonicalize (H12AffineFastState.compose env14652 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound14652 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14653 : List Nat := [2,4,8,10,10,11,128,14,137,1024,136,1028,138,1029,137,9,1028,137,1025,136,1028,11,11,139,2,11,137,1028,1029,136,1034,137,14,137,1029,137]

theorem envBound14653 : H12AffineFastState.Bounded env14653 := by
  intro p hp
  have h : env14653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14652_14653 : H12AffineEnvironment.transform 3 10 env14652 = env14653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env14652 == env14653) = true)

def env14654 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1345,512,1105,32769,1345,4194304,64,98565,8328,65,134217728,1345,1296,1073741824,1284,4294967296,256,4299260335,138413589,512]

theorem envBound14654 : H12AffineFastState.Bounded env14654 := by
  intro p hp
  have h : env14654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14565_14654 : H12AffineEnvironment.transform 18 1105 env14565 = env14654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1105 env14565 == env14654) = true)

theorem identity14654 : scanCanonicalize (H12AffineFastState.compose env14654 (packedSelected [3,5,24] rootPS)) = affineNative (2^(21+1) ^^^ 65804) := by decide +kernel

theorem selectedBound14654 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env14655 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1345,512,1105,32769,1345,65804,64,98565,8328,65,134217728,1345,1296,1073741824,1284,4294967296,256,4295000227,134285081,512]

theorem envBound14655 : H12AffineFastState.Bounded env14655 := by
  intro p hp
  have h : env14655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14654_14655 : H12AffineEnvironment.transform 21 65804 env14654 = env14655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65804 env14654 == env14655) = true)

def env14656 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,32768,65536,1297,512,1025,32769,1297,65804,16,98565,8328,17,134217728,1297,1296,1073741824,1284,4294967296,256,4295000227,134285081,512]

theorem envBound14656 : H12AffineFastState.Bounded env14656 := by
  intro p hp
  have h : env14656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14655_14656 : H12AffineEnvironment.transform 5 16 env14655 = env14656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14655 == env14656) = true)

theorem identity14656 : scanCanonicalize (H12AffineFastState.compose env14656 (packedSelected [3,5,10] rootPS)) = affineNative (2^(29+1) ^^^ 2988) := by decide +kernel

theorem selectedBound14656 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env14657 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,32768,65536,1297,512,1025,32769,1297,65804,16,98565,8328,17,134217728,1297,1296,2988,1284,4294967296,256,4295000227,134285081,512]

theorem envBound14657 : H12AffineFastState.Bounded env14657 := by
  intro p hp
  have h : env14657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14656_14657 : H12AffineEnvironment.transform 29 2988 env14656 = env14657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 2988 env14656 == env14657) = true)

theorem identity14657 : scanCanonicalize (H12AffineFastState.compose env14657 (packedSelected [1,8,19] rootPS)) = affineNative (2^(26+1) ^^^ 98338) := by decide +kernel

theorem selectedBound14657 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env14658 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,32768,65536,1297,512,1025,32769,1297,65804,16,98565,8328,17,98338,1297,1296,2988,1284,4294967296,256,4295000227,34619,512]

theorem envBound14658 : H12AffineFastState.Bounded env14658 := by
  intro p hp
  have h : env14658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14657_14658 : H12AffineEnvironment.transform 26 98338 env14657 = env14658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 98338 env14657 == env14658) = true)

theorem identity14658 : scanCanonicalize (H12AffineFastState.compose env14658 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 555) := by decide +kernel

theorem selectedBound14658 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env14659 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,555,65536,1297,512,1025,554,1297,65804,16,66350,8328,17,66057,1297,1296,2988,1284,4294967296,256,4294967944,1296,512]

theorem envBound14659 : H12AffineFastState.Bounded env14659 := by
  intro p hp
  have h : env14659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14658_14659 : H12AffineEnvironment.transform 14 555 env14658 = env14659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 555 env14658 == env14659) = true)

theorem identity14659 : scanCanonicalize (H12AffineFastState.compose env14659 (packedSelected [1,3,5] rootPS)) = affineNative (2^(15+1) ^^^ 8714) := by decide +kernel

theorem selectedBound14659 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env14660 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,555,8714,1297,512,1025,554,1297,8966,16,8484,8328,17,8195,1297,1296,2988,1284,4294967296,256,4294967944,1296,512]

theorem envBound14660 : H12AffineFastState.Bounded env14660 := by
  intro p hp
  have h : env14660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14659_14660 : H12AffineEnvironment.transform 15 8714 env14659 = env14660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8714 env14659 == env14660) = true)

theorem identity14660 : scanCanonicalize (H12AffineFastState.compose env14660 (packedSelected [1,3,8] rootPS)) = affineNative (2^(12+1) ^^^ 2051) := by decide +kernel

theorem selectedBound14660 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env14661 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,2051,1296,555,2569,1297,512,1025,554,1297,2821,16,2343,2187,17,2048,1297,1296,2988,1284,4294967296,256,4294967944,1296,512]

theorem envBound14661 : H12AffineFastState.Bounded env14661 := by
  intro p hp
  have h : env14661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14660_14661 : H12AffineEnvironment.transform 12 2051 env14660 = env14661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2051 env14660 == env14661) = true)

theorem identity14661 : scanCanonicalize (H12AffineFastState.compose env14661 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 782) := by decide +kernel

theorem selectedBound14661 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14662 : List Nat := [2,4,8,16,32,16,128,256,512,1024,782,1297,781,1296,555,263,1297,512,1025,554,1297,11,16,553,901,17,782,1297,1296,162,1284,4294967296,256,4294967944,1296,512]

theorem envBound14662 : H12AffineFastState.Bounded env14662 := by
  intro p hp
  have h : env14662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14661_14662 : H12AffineEnvironment.transform 10 782 env14661 = env14662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 782 env14661 == env14662) = true)

theorem identity14662 : scanCanonicalize (H12AffineFastState.compose env14662 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 162) := by decide +kernel

theorem selectedBound14662 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env14663 : List Nat := [2,4,8,16,32,16,128,256,162,1024,428,1297,431,1296,137,263,1297,162,1025,136,1297,11,16,139,295,17,428,1297,1296,162,1284,4294967296,256,4294967338,1296,162]

theorem envBound14663 : H12AffineFastState.Bounded env14663 := by
  intro p hp
  have h : env14663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14662_14663 : H12AffineEnvironment.transform 8 162 env14662 = env14663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 162 env14662 == env14663) = true)

theorem identity14663 : scanCanonicalize (H12AffineFastState.compose env14663 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 185) := by decide +kernel

theorem selectedBound14663 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14664 : List Nat := [2,4,8,16,32,16,128,256,162,1024,428,1297,431,1296,137,263,1297,162,1025,136,1297,11,16,139,295,17,428,1297,1296,162,1284,185,256,147,1296,162]

theorem envBound14664 : H12AffineFastState.Bounded env14664 := by
  intro p hp
  have h : env14664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14663_14664 : H12AffineEnvironment.transform 31 185 env14663 = env14664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 185 env14663 == env14664) = true)

theorem identity14664 : scanCanonicalize (H12AffineFastState.compose env14664 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound14664 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env14665 : List Nat := [2,4,8,16,10,16,128,256,136,1024,390,1297,389,1296,137,263,1297,136,1025,136,1297,11,16,139,269,17,390,1297,1296,136,1284,147,256,147,1296,136]

theorem envBound14665 : H12AffineFastState.Bounded env14665 := by
  intro p hp
  have h : env14665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14664_14665 : H12AffineEnvironment.transform 4 10 env14664 = env14665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env14664 == env14665) = true)

theorem identity14665 : scanCanonicalize (H12AffineFastState.compose env14665 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound14665 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

end H12CloudChart2