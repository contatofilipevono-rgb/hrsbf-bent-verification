import H12CloudChart2Data124

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound30911 : H12AffineFastState.Bounded env30911 := by
  intro p hp
  have h : env30911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30910_30911 : H12AffineEnvironment.transform 5 16 env30910 = env30911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env30910 == env30911) = true)

theorem identity30911 : scanCanonicalize (H12AffineFastState.compose env30911 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound30911 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env30912 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,277,8192,0,8216,65536,0,65664,74027,8217,276,397,16,65797,65714,73771,73988,0,74031,76063,8204,8201,257,16,0,74299]

theorem envBound30912 : H12AffineFastState.Bounded env30912 := by
  intro p hp
  have h : env30912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30911_30912 : H12AffineEnvironment.transform 11 277 env30911 = env30912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env30911 == env30912) = true)

theorem identity30912 : scanCanonicalize (H12AffineFastState.compose env30912 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound30912 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env30913 : List Nat := [2,4,8,16,32,16,128,20,512,4,2048,1,8192,0,8216,65536,0,65664,73791,8217,0,153,16,65553,65714,73771,73744,0,73787,75787,8204,8201,21,16,0,74299]

theorem envBound30913 : H12AffineFastState.Bounded env30913 := by
  intro p hp
  have h : env30913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30912_30913 : H12AffineEnvironment.transform 7 20 env30912 = env30913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env30912 == env30913) = true)

theorem identity30913 : scanCanonicalize (H12AffineFastState.compose env30913 (packedSelected [0,1,3,7,10,11,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 10882) := by decide +kernel

theorem selectedBound30913 : packedSelected [0,1,3,7,10,11,17,19] rootPS < 2^1333 := by decide +kernel

def env30914 : List Nat := [2,4,8,16,32,16,128,20,512,4,2048,1,8192,0,8216,10882,0,10754,2749,8217,0,153,16,10899,10800,2729,2706,0,2745,649,8204,8201,21,16,0,2233]

theorem envBound30914 : H12AffineFastState.Bounded env30914 := by
  intro p hp
  have h : env30914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30913_30914 : H12AffineEnvironment.transform 15 10882 env30913 = env30914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 10882 env30913 == env30914) = true)

theorem identity30914 : scanCanonicalize (H12AffineFastState.compose env30914 (packedSelected [1,8,13] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound30914 : packedSelected [1,8,13] rootPS < 2^1333 := by decide +kernel

def env30915 : List Nat := [2,4,8,16,32,16,128,20,1,4,2048,1,8192,0,8216,10371,0,10243,2236,8217,0,153,16,10386,10289,2216,2195,0,2232,136,8204,8201,21,16,0,2233]

theorem envBound30915 : H12AffineFastState.Bounded env30915 := by
  intro p hp
  have h : env30915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30914_30915 : H12AffineEnvironment.transform 8 1 env30914 = env30915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env30914 == env30915) = true)

theorem identity30915 : scanCanonicalize (H12AffineFastState.compose env30915 (packedSelected [0,2,3,7,8,11] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound30915 : packedSelected [0,2,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env30916 : List Nat := [2,4,8,16,32,16,19,20,1,4,2048,1,8192,0,8216,10256,0,10243,2095,8217,0,10,16,10241,10289,2107,2048,0,2091,27,8204,8201,21,16,0,2090]

theorem envBound30916 : H12AffineFastState.Bounded env30916 := by
  intro p hp
  have h : env30916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30915_30916 : H12AffineEnvironment.transform 6 19 env30915 = env30916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env30915 == env30916) = true)

theorem identity30916 : scanCanonicalize (H12AffineFastState.compose env30916 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound30916 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env30917 : List Nat := [2,4,8,11,32,11,8,15,1,4,2048,1,8192,0,8195,10251,0,10243,2095,8194,0,10,11,10241,10282,2080,2048,0,2091,0,8204,8201,14,11,0,2090]

theorem envBound30917 : H12AffineFastState.Bounded env30917 := by
  intro p hp
  have h : env30917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30916_30917 : H12AffineEnvironment.transform 3 11 env30916 = env30917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env30916 == env30917) = true)

def env30918 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,4096,8192,0,12557,65536,1,65664,77887,12556,4097,396,16,69648,70054,78142,77841,0,74031,79883,8204,8201,257,16,1,78639]

theorem envBound30918 : H12AffineFastState.Bounded env30918 := by
  intro p hp
  have h : env30918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30910_30918 : H12AffineEnvironment.transform 5 17 env30910 = env30918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30910 == env30918) = true)

theorem identity30918 : scanCanonicalize (H12AffineFastState.compose env30918 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 8250) := by decide +kernel

theorem selectedBound30918 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env30919 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,4096,8192,0,12557,8250,1,8378,4101,12556,4097,396,16,12330,12700,4356,4139,0,277,6193,8204,8201,257,16,1,4885]

theorem envBound30919 : H12AffineFastState.Bounded env30919 := by
  intro p hp
  have h : env30919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30918_30919 : H12AffineEnvironment.transform 15 8250 env30918 = env30919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8250 env30918 == env30919) = true)

theorem identity30919 : scanCanonicalize (H12AffineFastState.compose env30919 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound30919 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env30920 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,1,8192,0,8460,8250,1,8378,4,8461,0,396,16,8235,8605,261,42,0,277,2096,8204,8201,257,16,1,788]

theorem envBound30920 : H12AffineFastState.Bounded env30920 := by
  intro p hp
  have h : env30920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30919_30920 : H12AffineEnvironment.transform 11 1 env30919 = env30920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env30919 == env30920) = true)

theorem identity30920 : scanCanonicalize (H12AffineFastState.compose env30920 (packedSelected [0,1,2,3,7,10,17,18,19] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound30920 : packedSelected [0,1,2,3,7,10,17,18,19] rootPS < 2^1333 := by decide +kernel

def env30921 : List Nat := [2,4,8,16,32,17,128,256,512,272,561,1,8192,0,8460,8250,1,8378,4,8461,0,396,16,8235,8605,261,42,0,277,513,8204,8201,257,16,1,788]

theorem envBound30921 : H12AffineFastState.Bounded env30921 := by
  intro p hp
  have h : env30921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30920_30921 : H12AffineEnvironment.transform 10 561 env30920 = env30921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env30920 == env30921) = true)

theorem identity30921 : scanCanonicalize (H12AffineFastState.compose env30921 (packedSelected [0,1,2,7,8,13,18] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound30921 : packedSelected [0,1,2,7,8,13,18] rootPS < 2^1333 := by decide +kernel

def env30922 : List Nat := [2,4,8,16,32,17,128,256,512,272,561,1,268,0,0,310,1,438,4,1,0,396,16,295,145,261,42,0,277,513,256,261,257,16,1,788]

theorem envBound30922 : H12AffineFastState.Bounded env30922 := by
  intro p hp
  have h : env30922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30921_30922 : H12AffineEnvironment.transform 12 268 env30921 = env30922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env30921 == env30922) = true)

theorem identity30922 : scanCanonicalize (H12AffineFastState.compose env30922 (packedSelected [1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 319) := by decide +kernel

theorem selectedBound30922 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env30923 : List Nat := [2,4,8,16,32,17,128,256,319,272,270,1,268,0,0,310,1,438,4,1,0,396,16,295,145,261,42,0,277,318,256,261,257,16,1,43]

theorem envBound30923 : H12AffineFastState.Bounded env30923 := by
  intro p hp
  have h : env30923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30922_30923 : H12AffineEnvironment.transform 8 319 env30922 = env30923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 319 env30922 == env30923) = true)

theorem identity30923 : scanCanonicalize (H12AffineFastState.compose env30923 (packedSelected [2,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound30923 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env30924 : List Nat := [2,4,8,16,32,17,56,256,319,272,270,1,268,0,0,310,1,270,4,1,0,308,16,295,41,261,42,0,277,318,256,261,257,16,1,43]

theorem envBound30924 : H12AffineFastState.Bounded env30924 := by
  intro p hp
  have h : env30924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30923_30924 : H12AffineEnvironment.transform 6 56 env30923 = env30924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env30923 == env30924) = true)

theorem identity30924 : scanCanonicalize (H12AffineFastState.compose env30924 (packedSelected [0,1,2,7] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound30924 : packedSelected [0,1,2,7] rootPS < 2^1333 := by decide +kernel

def env30925 : List Nat := [2,4,8,12,32,13,36,256,291,268,270,1,268,0,0,298,1,270,4,1,0,296,12,295,41,261,42,0,265,290,256,261,257,12,1,43]

theorem envBound30925 : H12AffineFastState.Bounded env30925 := by
  intro p hp
  have h : env30925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30924_30925 : H12AffineEnvironment.transform 3 12 env30924 = env30925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env30924 == env30925) = true)

theorem identity30925 : scanCanonicalize (H12AffineFastState.compose env30925 (packedSelected [1,2,4,5,9] rootPS)) = affineNative (2^(7+1) ^^^ 9) := by decide +kernel

theorem selectedBound30925 : packedSelected [1,2,4,5,9] rootPS < 2^1333 := by decide +kernel

def env30926 : List Nat := [2,4,8,12,32,13,36,9,42,5,7,1,5,0,0,35,1,7,4,1,0,33,12,46,41,12,42,0,0,43,9,12,8,12,1,43]

theorem envBound30926 : H12AffineFastState.Bounded env30926 := by
  intro p hp
  have h : env30926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30925_30926 : H12AffineEnvironment.transform 7 9 env30925 = env30926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 9 env30925 == env30926) = true)

theorem identity30926 : scanCanonicalize (H12AffineFastState.compose env30926 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound30926 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30927 : List Nat := [2,4,8,12,1,13,5,9,11,5,7,1,5,0,0,2,1,7,4,1,0,0,12,15,8,12,11,0,0,10,9,12,8,12,1,10]

theorem envBound30927 : H12AffineFastState.Bounded env30927 := by
  intro p hp
  have h : env30927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30926_30927 : H12AffineEnvironment.transform 4 1 env30926 = env30927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env30926 == env30927) = true)

theorem identity30927 : scanCanonicalize (H12AffineFastState.compose env30927 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound30927 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30928 : List Nat := [2,4,2,6,1,7,5,3,1,5,7,1,5,0,0,2,1,7,4,1,0,0,6,5,2,6,1,0,0,0,3,6,2,6,1,0]

theorem envBound30928 : H12AffineFastState.Bounded env30928 := by
  intro p hp
  have h : env30928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30927_30928 : H12AffineEnvironment.transform 2 2 env30927 = env30928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env30927 == env30928) = true)

theorem identity30928 : scanCanonicalize (H12AffineFastState.compose env30928 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound30928 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30929 : List Nat := [2,0,2,2,1,3,1,3,1,1,3,1,1,0,0,2,1,3,0,1,0,0,2,1,2,2,1,0,0,0,3,2,2,2,1,0]

theorem envBound30929 : H12AffineFastState.Bounded env30929 := by
  intro p hp
  have h : env30929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30928_30929 : H12AffineEnvironment.transform 1 0 env30928 = env30929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env30928 == env30929) = true)

theorem identity30929 : scanCanonicalize (H12AffineFastState.compose env30929 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound30929 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env30930 : List Nat := [0,0,0,0,1,1,1,1,1,1,1,1,1,0,0,0,1,1,0,1,0,0,0,1,0,0,1,0,0,0,1,0,0,0,1,0]

theorem envBound30930 : H12AffineFastState.Bounded env30930 := by
  intro p hp
  have h : env30930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30929_30930 : H12AffineEnvironment.transform 0 0 env30929 = env30930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env30929 == env30930) = true)

def env30931 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1344,65665,77934,13340,4097,477,16,69649,70887,78894,77841,1296,74815,81226,8205,8200,257,1280,1344,79470]

theorem envBound30931 : H12AffineFastState.Bounded env30931 := by
  intro p hp
  have h : env30931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30908_30931 : H12AffineEnvironment.transform 17 65665 env30908 = env30931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env30908 == env30931) = true)

theorem identity30931 : scanCanonicalize (H12AffineFastState.compose env30931 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound30931 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env30932 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1296,9293,65536,1344,65665,73790,9292,81,477,16,65601,66743,74878,73793,1296,74815,77082,8205,8200,257,1280,1344,75326]

theorem envBound30932 : H12AffineFastState.Bounded env30932 := by
  intro p hp
  have h : env30932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30931_30932 : H12AffineEnvironment.transform 11 80 env30931 = env30932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env30931 == env30932) = true)

def env30933 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,1220,1296,137,65536,1344,65665,66810,136,81,477,16,65601,66743,65722,66693,1296,65787,68062,1225,1228,257,1280,1344,66298]

theorem envBound30933 : H12AffineFastState.Bounded env30933 := by
  intro p hp
  have h : env30933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30932_30933 : H12AffineEnvironment.transform 12 1220 env30932 = env30933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1220 env30932 == env30933) = true)

def env30934 : List Nat := [2,4,8,16,32,0,128,256,512,1024,2048,16,1156,1296,137,65536,1280,65665,66746,136,17,413,16,65537,66743,65722,66693,1296,65723,67998,1161,1164,257,1280,1280,66234]

theorem envBound30934 : H12AffineFastState.Bounded env30934 := by
  intro p hp
  have h : env30934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30933_30934 : H12AffineEnvironment.transform 5 0 env30933 = env30934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env30933 == env30934) = true)

theorem identity30934 : scanCanonicalize (H12AffineFastState.compose env30934 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 5) := by decide +kernel

theorem selectedBound30934 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env30935 : List Nat := [2,4,8,16,32,0,128,256,512,1024,2048,16,1156,1296,137,5,1280,132,1215,136,17,413,16,4,1202,191,1152,1296,190,2459,1161,1164,257,1280,1280,703]

theorem envBound30935 : H12AffineFastState.Bounded env30935 := by
  intro p hp
  have h : env30935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30934_30935 : H12AffineEnvironment.transform 15 5 env30934 = env30935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5 env30934 == env30935) = true)

def env30936 : List Nat := [2,4,8,0,32,0,128,256,512,1024,2048,0,1156,1280,137,5,1280,132,1199,136,1,397,0,4,1186,175,1152,1280,174,2443,1161,1164,257,1280,1280,687]

theorem envBound30936 : H12AffineFastState.Bounded env30936 := by
  intro p hp
  have h : env30936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30935_30936 : H12AffineEnvironment.transform 3 0 env30935 = env30936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env30935 == env30936) = true)

theorem identity30936 : scanCanonicalize (H12AffineFastState.compose env30936 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound30936 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env30937 : List Nat := [2,4,8,0,32,0,128,5,512,1024,2048,0,1156,1029,137,5,1029,132,1199,136,1,136,0,4,1186,175,1152,1029,174,2190,1161,1164,4,1029,1029,687]

theorem envBound30937 : H12AffineFastState.Bounded env30937 := by
  intro p hp
  have h : env30937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30936_30937 : H12AffineEnvironment.transform 7 5 env30936 = env30937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env30936 == env30937) = true)

theorem identity30937 : scanCanonicalize (H12AffineFastState.compose env30937 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 171) := by decide +kernel

theorem selectedBound30937 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env30938 : List Nat := [2,4,8,0,32,0,128,5,512,171,2048,0,47,174,137,5,174,132,4,136,1,136,0,4,9,175,43,174,174,2190,34,39,4,174,174,687]

theorem envBound30938 : H12AffineFastState.Bounded env30938 := by
  intro p hp
  have h : env30938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30937_30938 : H12AffineEnvironment.transform 9 171 env30937 = env30938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 171 env30937 == env30938) = true)

theorem identity30938 : scanCanonicalize (H12AffineFastState.compose env30938 (packedSelected [0,7,8,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound30938 : packedSelected [0,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env30939 : List Nat := [2,4,8,0,32,0,40,5,512,3,2048,0,47,6,33,5,6,44,4,32,1,32,0,4,9,7,43,6,6,2086,34,39,4,6,6,519]

theorem envBound30939 : H12AffineFastState.Bounded env30939 := by
  intro p hp
  have h : env30939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30938_30939 : H12AffineEnvironment.transform 6 40 env30938 = env30939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env30938 == env30939) = true)

theorem identity30939 : scanCanonicalize (H12AffineFastState.compose env30939 (packedSelected [1,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound30939 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env30940 : List Nat := [2,4,8,0,6,0,14,5,512,3,2048,0,9,6,7,5,6,10,4,6,1,6,0,4,9,7,13,6,6,2048,4,1,4,6,6,519]

theorem envBound30940 : H12AffineFastState.Bounded env30940 := by
  intro p hp
  have h : env30940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30939_30940 : H12AffineEnvironment.transform 4 6 env30939 = env30940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env30939 == env30940) = true)

theorem identity30940 : scanCanonicalize (H12AffineFastState.compose env30940 (packedSelected [2,8] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound30940 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env30941 : List Nat := [2,4,8,0,6,0,14,5,512,3,522,0,9,6,7,5,6,10,4,6,1,6,0,4,9,7,13,6,6,522,4,1,4,6,6,519]

theorem envBound30941 : H12AffineFastState.Bounded env30941 := by
  intro p hp
  have h : env30941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30940_30941 : H12AffineEnvironment.transform 10 522 env30940 = env30941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env30940 == env30941) = true)

theorem identity30941 : scanCanonicalize (H12AffineFastState.compose env30941 (packedSelected [1,2,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound30941 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env30942 : List Nat := [2,4,3,0,6,0,5,5,512,3,513,0,2,6,7,5,6,1,4,6,1,6,0,4,2,7,6,6,6,513,4,1,4,6,6,519]

theorem envBound30942 : H12AffineFastState.Bounded env30942 := by
  intro p hp
  have h : env30942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30941_30942 : H12AffineEnvironment.transform 2 3 env30941 = env30942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env30941 == env30942) = true)

theorem identity30942 : scanCanonicalize (H12AffineFastState.compose env30942 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 6) := by decide +kernel

theorem selectedBound30942 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30943 : List Nat := [2,4,3,0,6,0,5,5,6,3,7,0,2,6,7,5,6,1,4,6,1,6,0,4,2,7,6,6,6,7,4,1,4,6,6,1]

theorem envBound30943 : H12AffineFastState.Bounded env30943 := by
  intro p hp
  have h : env30943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30942_30943 : H12AffineEnvironment.transform 8 6 env30942 = env30943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 6 env30942 == env30943) = true)

theorem identity30943 : scanCanonicalize (H12AffineFastState.compose env30943 (packedSelected [10] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound30943 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env30944 : List Nat := [2,2,3,0,0,0,3,3,0,3,1,0,2,0,1,3,0,1,2,0,1,0,0,2,2,1,0,0,0,1,2,1,2,0,0,1]

theorem envBound30944 : H12AffineFastState.Bounded env30944 := by
  intro p hp
  have h : env30944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30943_30944 : H12AffineEnvironment.transform 1 2 env30943 = env30944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env30943 == env30944) = true)

theorem identity30944 : scanCanonicalize (H12AffineFastState.compose env30944 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound30944 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30945 : List Nat := [0,0,1,0,0,0,1,1,0,1,1,0,0,0,1,1,0,1,0,0,1,0,0,0,0,1,0,0,0,1,0,1,0,0,0,1]

theorem envBound30945 : H12AffineFastState.Bounded env30945 := by
  intro p hp
  have h : env30945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30944_30945 : H12AffineEnvironment.transform 0 0 env30944 = env30945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env30944 == env30945) = true)

def env30946 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,1,1156,1281,137,5,1280,132,1198,136,0,396,1,4,1187,174,1152,1281,175,2442,1161,1164,257,1280,1280,686]

theorem envBound30946 : H12AffineFastState.Bounded env30946 := by
  intro p hp
  have h : env30946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30935_30946 : H12AffineEnvironment.transform 3 1 env30935 = env30946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env30935 == env30946) = true)

theorem identity30946 : scanCanonicalize (H12AffineFastState.compose env30946 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 171) := by decide +kernel

theorem selectedBound30946 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env30947 : List Nat := [2,4,8,1,32,0,128,171,512,1024,2048,1,1156,1194,137,5,1195,132,1198,136,0,39,1,4,1187,174,1152,1194,175,2081,1161,1164,170,1195,1195,686]

theorem envBound30947 : H12AffineFastState.Bounded env30947 := by
  intro p hp
  have h : env30947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30946_30947 : H12AffineEnvironment.transform 7 171 env30946 = env30947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 171 env30946 == env30947) = true)

theorem identity30947 : scanCanonicalize (H12AffineFastState.compose env30947 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound30947 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env30948 : List Nat := [2,4,8,1,32,0,128,171,512,4,2048,1,128,174,137,5,175,132,170,136,0,39,1,4,167,174,132,174,175,2081,141,136,170,175,175,686]

theorem envBound30948 : H12AffineFastState.Bounded env30948 := by
  intro p hp
  have h : env30948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30947_30948 : H12AffineEnvironment.transform 9 4 env30947 = env30948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env30947 == env30948) = true)

theorem identity30948 : scanCanonicalize (H12AffineFastState.compose env30948 (packedSelected [2,10] rootPS)) = affineNative (2^(10+1) ^^^ 555) := by decide +kernel

theorem selectedBound30948 : packedSelected [2,10] rootPS < 2^1333 := by decide +kernel

def env30949 : List Nat := [2,4,8,1,32,0,128,171,512,4,555,1,128,174,137,5,175,132,170,136,0,39,1,4,167,174,132,174,175,522,141,136,170,175,175,686]

theorem envBound30949 : H12AffineFastState.Bounded env30949 := by
  intro p hp
  have h : env30949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30948_30949 : H12AffineEnvironment.transform 10 555 env30948 = env30949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 555 env30948 == env30949) = true)

theorem identity30949 : scanCanonicalize (H12AffineFastState.compose env30949 (packedSelected [2,5] rootPS)) = affineNative (2^(8+1) ^^^ 130) := by decide +kernel

theorem selectedBound30949 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env30950 : List Nat := [2,4,8,1,32,0,128,171,130,4,169,1,128,174,137,5,175,132,170,136,0,39,1,4,167,174,132,174,175,136,141,136,170,175,175,44]

theorem envBound30950 : H12AffineFastState.Bounded env30950 := by
  intro p hp
  have h : env30950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30949_30950 : H12AffineEnvironment.transform 8 130 env30949 = env30950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 130 env30949 == env30950) = true)

theorem identity30950 : scanCanonicalize (H12AffineFastState.compose env30950 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 36) := by decide +kernel

theorem selectedBound30950 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30951 : List Nat := [2,4,8,1,32,0,36,15,38,4,13,1,36,10,45,5,11,32,14,44,0,39,1,4,3,10,32,10,11,44,41,44,14,11,11,44]

theorem envBound30951 : H12AffineFastState.Bounded env30951 := by
  intro p hp
  have h : env30951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30950_30951 : H12AffineEnvironment.transform 6 36 env30950 = env30951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 36 env30950 == env30951) = true)

theorem identity30951 : scanCanonicalize (H12AffineFastState.compose env30951 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound30951 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env30952 : List Nat := [2,4,8,1,7,0,3,15,1,4,13,1,3,10,10,5,11,7,14,11,0,0,1,4,3,10,7,10,11,11,14,11,14,11,11,11]

theorem envBound30952 : H12AffineFastState.Bounded env30952 := by
  intro p hp
  have h : env30952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30951_30952 : H12AffineEnvironment.transform 4 7 env30951 = env30952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env30951 == env30952) = true)

theorem identity30952 : scanCanonicalize (H12AffineFastState.compose env30952 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound30952 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env30953 : List Nat := [2,4,3,1,7,0,3,4,1,4,6,1,3,1,1,5,0,7,5,0,0,0,1,4,3,1,7,1,0,0,5,0,5,0,0,0]

theorem envBound30953 : H12AffineFastState.Bounded env30953 := by
  intro p hp
  have h : env30953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30952_30953 : H12AffineEnvironment.transform 2 3 env30952 = env30953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env30952 == env30953) = true)

theorem identity30953 : scanCanonicalize (H12AffineFastState.compose env30953 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound30953 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30954 : List Nat := [2,1,3,1,2,0,3,1,1,1,3,1,3,1,1,0,0,2,0,0,0,0,1,1,3,1,2,1,0,0,0,0,0,0,0,0]

theorem envBound30954 : H12AffineFastState.Bounded env30954 := by
  intro p hp
  have h : env30954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30953_30954 : H12AffineEnvironment.transform 1 1 env30953 = env30954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env30953 == env30954) = true)

def env30955 : List Nat := [2,4,8,16,32,1,128,256,512,1024,2048,17,1157,1296,137,65536,1281,65665,66747,136,16,412,16,65536,66743,65722,66693,1296,65722,67999,1160,1165,257,1280,1281,66235]

theorem envBound30955 : H12AffineFastState.Bounded env30955 := by
  intro p hp
  have h : env30955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30933_30955 : H12AffineEnvironment.transform 5 1 env30933 = env30955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env30933 == env30955) = true)

theorem identity30955 : scanCanonicalize (H12AffineFastState.compose env30955 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 392) := by decide +kernel

theorem selectedBound30955 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env30956 : List Nat := [2,4,8,16,32,1,128,256,512,1024,2048,17,1157,1296,137,392,1281,265,1331,136,16,412,16,392,1343,306,1293,1296,306,2071,1160,1165,257,1280,1281,819]

theorem envBound30956 : H12AffineFastState.Bounded env30956 := by
  intro p hp
  have h : env30956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30955_30956 : H12AffineEnvironment.transform 15 392 env30955 = env30956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 392 env30955 == env30956) = true)

def env30957 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,1,1157,1280,137,392,1281,265,1315,136,0,396,0,392,1327,290,1293,1280,290,2055,1160,1165,257,1280,1281,803]

theorem envBound30957 : H12AffineFastState.Bounded env30957 := by
  intro p hp
  have h : env30957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30956_30957 : H12AffineEnvironment.transform 3 0 env30956 = env30957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env30956 == env30957) = true)

theorem identity30957 : scanCanonicalize (H12AffineFastState.compose env30957 (packedSelected [4,9,16] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound30957 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env30958 : List Nat := [2,4,8,0,7,1,128,256,512,1024,2048,1,1157,1280,137,392,1281,265,1284,136,0,396,0,392,1288,261,1293,1280,261,2055,1160,1165,257,1280,1281,772]

theorem envBound30958 : H12AffineFastState.Bounded env30958 := by
  intro p hp
  have h : env30958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30957_30958 : H12AffineEnvironment.transform 4 7 env30957 = env30958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env30957 == env30958) = true)

theorem identity30958 : scanCanonicalize (H12AffineFastState.compose env30958 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound30958 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env30959 : List Nat := [2,4,8,0,7,1,128,256,512,4,2048,1,129,260,137,392,261,265,256,136,0,396,0,392,268,261,265,260,261,2055,140,137,257,260,261,772]

theorem envBound30959 : H12AffineFastState.Bounded env30959 := by
  intro p hp
  have h : env30959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30958_30959 : H12AffineEnvironment.transform 9 4 env30958 = env30959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env30958 == env30959) = true)

theorem identity30959 : scanCanonicalize (H12AffineFastState.compose env30959 (packedSelected [2,10] rootPS)) = affineNative (2^(10+1) ^^^ 776) := by decide +kernel

theorem selectedBound30959 : packedSelected [2,10] rootPS < 2^1333 := by decide +kernel

def env30960 : List Nat := [2,4,8,0,7,1,128,256,512,4,776,1,129,260,137,392,261,265,256,136,0,396,0,392,268,261,265,260,261,783,140,137,257,260,261,772]

theorem envBound30960 : H12AffineFastState.Bounded env30960 := by
  intro p hp
  have h : env30960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30959_30960 : H12AffineEnvironment.transform 10 776 env30959 = env30960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 776 env30959 == env30960) = true)

theorem identity30960 : scanCanonicalize (H12AffineFastState.compose env30960 (packedSelected [2,5] rootPS)) = affineNative (2^(8+1) ^^^ 391) := by decide +kernel

theorem selectedBound30960 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env30961 : List Nat := [2,4,8,0,7,1,128,256,391,4,143,1,129,260,137,392,261,265,256,136,0,396,0,392,268,261,265,260,261,136,140,137,257,260,261,131]

theorem envBound30961 : H12AffineFastState.Bounded env30961 := by
  intro p hp
  have h : env30961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30960_30961 : H12AffineEnvironment.transform 8 391 env30960 = env30961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 391 env30960 == env30961) = true)

theorem identity30961 : scanCanonicalize (H12AffineFastState.compose env30961 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound30961 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30962 : List Nat := [2,4,3,0,7,1,128,256,391,4,132,1,129,260,130,387,261,258,256,131,0,391,0,387,263,261,258,260,261,131,135,130,257,260,261,131]

theorem envBound30962 : H12AffineFastState.Bounded env30962 := by
  intro p hp
  have h : env30962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30961_30962 : H12AffineEnvironment.transform 2 3 env30961 = env30962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env30961 == env30962) = true)

theorem identity30962 : scanCanonicalize (H12AffineFastState.compose env30962 (packedSelected [0,1,7] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound30962 : packedSelected [0,1,7] rootPS < 2^1333 := by decide +kernel

def env30963 : List Nat := [2,4,3,0,7,1,4,256,259,4,0,1,5,260,6,263,261,258,256,7,0,259,0,263,263,261,258,260,261,7,3,6,257,260,261,7]

theorem envBound30963 : H12AffineFastState.Bounded env30963 := by
  intro p hp
  have h : env30963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30962_30963 : H12AffineEnvironment.transform 6 4 env30962 = env30963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env30962 == env30963) = true)

theorem identity30963 : scanCanonicalize (H12AffineFastState.compose env30963 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound30963 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30964 : List Nat := [2,3,3,0,0,1,3,256,259,3,0,1,2,259,1,256,258,258,256,0,0,259,0,256,256,258,258,259,258,0,3,1,257,259,258,0]

theorem envBound30964 : H12AffineFastState.Bounded env30964 := by
  intro p hp
  have h : env30964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30963_30964 : H12AffineEnvironment.transform 1 3 env30963 = env30964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env30963 == env30964) = true)

theorem identity30964 : scanCanonicalize (H12AffineFastState.compose env30964 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 3) := by decide +kernel

theorem selectedBound30964 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env30965 : List Nat := [2,3,3,0,0,1,3,3,0,3,0,1,2,0,1,3,1,1,3,0,0,0,0,3,3,1,1,0,1,0,3,1,2,0,1,0]

theorem envBound30965 : H12AffineFastState.Bounded env30965 := by
  intro p hp
  have h : env30965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30964_30965 : H12AffineEnvironment.transform 7 3 env30964 = env30965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 3 env30964 == env30965) = true)

def env30966 : List Nat := [2,4,8,1,32,1,128,256,512,1024,2048,0,1157,1281,137,392,1281,265,1314,136,1,397,1,392,1326,291,1293,1281,291,2054,1160,1165,257,1280,1281,802]

theorem envBound30966 : H12AffineFastState.Bounded env30966 := by
  intro p hp
  have h : env30966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30956_30966 : H12AffineEnvironment.transform 3 1 env30956 = env30966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env30956 == env30966) = true)

theorem identity30966 : scanCanonicalize (H12AffineFastState.compose env30966 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound30966 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env30967 : List Nat := [2,4,8,1,32,1,128,4,512,1024,2048,0,1157,1029,137,140,1029,13,1062,136,1,137,1,140,1066,39,1033,1029,39,2054,1160,1165,5,1028,1029,550]

theorem envBound30967 : H12AffineFastState.Bounded env30967 := by
  intro p hp
  have h : env30967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30966_30967 : H12AffineEnvironment.transform 7 4 env30966 = env30967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env30966 == env30967) = true)

theorem identity30967 : scanCanonicalize (H12AffineFastState.compose env30967 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 34) := by decide +kernel

theorem selectedBound30967 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env30968 : List Nat := [2,4,8,1,32,1,128,4,512,34,2048,0,167,39,137,140,39,13,4,136,1,137,1,140,8,39,43,39,39,2054,170,175,5,38,39,550]

theorem envBound30968 : H12AffineFastState.Bounded env30968 := by
  intro p hp
  have h : env30968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30967_30968 : H12AffineEnvironment.transform 9 34 env30967 = env30968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 34 env30967 == env30968) = true)

theorem identity30968 : scanCanonicalize (H12AffineFastState.compose env30968 (packedSelected [0,7,8,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound30968 : packedSelected [0,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env30969 : List Nat := [2,4,8,1,32,1,15,4,512,34,2048,0,40,39,6,3,39,13,4,7,1,6,1,3,8,39,43,39,39,2054,37,32,5,38,39,550]

theorem envBound30969 : H12AffineFastState.Bounded env30969 := by
  intro p hp
  have h : env30969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30968_30969 : H12AffineEnvironment.transform 6 15 env30968 = env30969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env30968 == env30969) = true)

theorem identity30969 : scanCanonicalize (H12AffineFastState.compose env30969 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 525) := by decide +kernel

theorem selectedBound30969 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env30970 : List Nat := [2,4,8,1,32,1,15,4,512,34,525,0,40,39,6,3,39,13,4,7,1,6,1,3,8,39,43,39,39,523,37,32,5,38,39,550]

theorem envBound30970 : H12AffineFastState.Bounded env30970 := by
  intro p hp
  have h : env30970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30969_30970 : H12AffineEnvironment.transform 10 525 env30969 = env30970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 525 env30969 == env30970) = true)

theorem identity30970 : scanCanonicalize (H12AffineFastState.compose env30970 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound30970 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env30971 : List Nat := [2,4,8,1,10,1,15,4,512,8,525,0,2,13,6,3,13,13,4,7,1,6,1,3,8,13,1,13,13,523,15,10,5,12,13,524]

theorem envBound30971 : H12AffineFastState.Bounded env30971 := by
  intro p hp
  have h : env30971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30970_30971 : H12AffineEnvironment.transform 4 10 env30970 = env30971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env30970 == env30971) = true)

theorem identity30971 : scanCanonicalize (H12AffineFastState.compose env30971 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound30971 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30972 : List Nat := [2,4,8,1,10,1,15,4,11,8,6,0,2,13,6,3,13,13,4,7,1,6,1,3,8,13,1,13,13,0,15,10,5,12,13,7]

theorem envBound30972 : H12AffineFastState.Bounded env30972 := by
  intro p hp
  have h : env30972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30971_30972 : H12AffineEnvironment.transform 8 11 env30971 = env30972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env30971 == env30972) = true)

theorem identity30972 : scanCanonicalize (H12AffineFastState.compose env30972 (packedSelected [0,2,4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound30972 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env30973 : List Nat := [2,2,8,1,10,1,9,2,11,8,0,0,2,11,0,3,11,11,2,1,1,0,1,3,8,11,1,11,11,0,9,10,3,10,11,1]

theorem envBound30973 : H12AffineFastState.Bounded env30973 := by
  intro p hp
  have h : env30973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30972_30973 : H12AffineEnvironment.transform 1 2 env30972 = env30973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env30972 == env30973) = true)

theorem identity30973 : scanCanonicalize (H12AffineFastState.compose env30973 (packedSelected [0,7] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound30973 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env30974 : List Nat := [2,2,2,1,0,1,3,2,1,2,0,0,2,1,0,3,1,1,2,1,1,0,1,3,2,1,1,1,1,0,3,0,3,0,1,1]

theorem envBound30974 : H12AffineFastState.Bounded env30974 := by
  intro p hp
  have h : env30974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30973_30974 : H12AffineEnvironment.transform 2 2 env30973 = env30974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env30973 == env30974) = true)

def env30975 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,1221,1296,136,65536,1344,65665,66811,137,81,477,16,65601,66743,65723,66692,1296,65786,68063,1224,1229,257,1280,1344,66299]

theorem envBound30975 : H12AffineFastState.Bounded env30975 := by
  intro p hp
  have h : env30975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30932_30975 : H12AffineEnvironment.transform 12 1221 env30932 = env30975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1221 env30932 == env30975) = true)

def env30976 : List Nat := [2,4,8,16,32,0,128,256,512,1024,2048,16,1157,1296,136,65536,1280,65665,66747,137,17,413,16,65537,66743,65723,66692,1296,65722,67999,1160,1165,257,1280,1280,66235]

theorem envBound30976 : H12AffineFastState.Bounded env30976 := by
  intro p hp
  have h : env30976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30975_30976 : H12AffineEnvironment.transform 5 0 env30975 = env30976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env30975 == env30976) = true)

theorem identity30976 : scanCanonicalize (H12AffineFastState.compose env30976 (packedSelected [1,8,28] rootPS)) = affineNative (2^(9+1) ^^^ 430) := by decide +kernel

theorem selectedBound30976 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env30977 : List Nat := [2,4,8,16,32,0,128,256,512,430,2048,16,299,190,136,65536,174,65665,65813,137,17,413,16,65537,65817,65723,65834,190,65722,67999,294,291,257,174,174,66235]

theorem envBound30977 : H12AffineFastState.Bounded env30977 := by
  intro p hp
  have h : env30977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30976_30977 : H12AffineEnvironment.transform 9 430 env30976 = env30977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 430 env30976 == env30977) = true)

def env30978 : List Nat := [2,4,8,16,32,0,128,256,512,430,2048,16,299,190,136,4,174,133,273,137,17,413,16,5,285,191,302,190,190,2459,294,291,257,174,174,703]

theorem envBound30978 : H12AffineFastState.Bounded env30978 := by
  intro p hp
  have h : env30978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30977_30978 : H12AffineEnvironment.transform 15 4 env30977 = env30978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4 env30977 == env30978) = true)

theorem identity30978 : scanCanonicalize (H12AffineFastState.compose env30978 (packedSelected [1,2,3,5,10,11,17,18,19] rootPS)) = affineNative (2^(8+1) ^^^ 12) := by decide +kernel

theorem selectedBound30978 : packedSelected [1,2,3,5,10,11,17,18,19] rootPS < 2^1333 := by decide +kernel

def env30979 : List Nat := [2,4,8,16,32,0,128,256,12,430,2048,16,299,190,136,4,174,133,273,137,17,413,16,5,285,191,302,190,190,2459,294,291,257,174,174,179]

theorem envBound30979 : H12AffineFastState.Bounded env30979 := by
  intro p hp
  have h : env30979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30978_30979 : H12AffineEnvironment.transform 8 12 env30978 = env30979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 12 env30978 == env30979) = true)

theorem identity30979 : scanCanonicalize (H12AffineFastState.compose env30979 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound30979 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env30980 : List Nat := [2,4,8,16,32,0,128,21,12,187,2048,16,62,190,136,4,174,133,4,137,17,136,16,5,8,191,59,190,190,2190,51,54,20,174,174,179]

theorem envBound30980 : H12AffineFastState.Bounded env30980 := by
  intro p hp
  have h : env30980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30979_30980 : H12AffineEnvironment.transform 7 21 env30979 = env30980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env30979 == env30980) = true)

theorem identity30980 : scanCanonicalize (H12AffineFastState.compose env30980 (packedSelected [0,1,2,3,7,8,10,13,17,18] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound30980 : packedSelected [0,1,2,3,7,8,10,13,17,18] rootPS < 2^1333 := by decide +kernel

def env30981 : List Nat := [2,4,8,16,7,0,128,21,12,156,2048,16,25,153,136,4,137,133,4,137,17,136,16,5,8,152,28,153,153,2190,20,17,20,137,137,148]

theorem envBound30981 : H12AffineFastState.Bounded env30981 := by
  intro p hp
  have h : env30981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30980_30981 : H12AffineEnvironment.transform 4 7 env30980 = env30981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env30980 == env30981) = true)

theorem identity30981 : scanCanonicalize (H12AffineFastState.compose env30981 (packedSelected [0,1,3,5,7,8,10,11] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound30981 : packedSelected [0,1,3,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env30982 : List Nat := [2,3,8,16,0,0,128,18,11,155,2048,16,25,153,136,3,137,130,3,137,17,136,16,2,8,152,27,153,153,2185,19,17,19,137,137,147]

theorem envBound30982 : H12AffineFastState.Bounded env30982 := by
  intro p hp
  have h : env30982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30981_30982 : H12AffineEnvironment.transform 1 3 env30981 = env30982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env30981 == env30982) = true)

def env30983 : List Nat := [2,4,8,16,32,0,128,256,512,430,2048,16,299,190,136,5,174,132,272,137,17,413,16,4,284,190,303,190,191,2458,294,291,257,174,174,702]

theorem envBound30983 : H12AffineFastState.Bounded env30983 := by
  intro p hp
  have h : env30983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30977_30983 : H12AffineEnvironment.transform 15 5 env30977 = env30983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5 env30977 == env30983) = true)

theorem identity30983 : scanCanonicalize (H12AffineFastState.compose env30983 (packedSelected [1,2,3,5,10,11,17,18,19] rootPS)) = affineNative (2^(10+1) ^^^ 692) := by decide +kernel

theorem selectedBound30983 : packedSelected [1,2,3,5,10,11,17,18,19] rootPS < 2^1333 := by decide +kernel

def env30984 : List Nat := [2,4,8,16,32,0,128,256,512,430,692,16,299,190,136,5,174,132,272,137,17,413,16,4,284,190,303,190,191,814,294,291,257,174,174,702]

theorem envBound30984 : H12AffineFastState.Bounded env30984 := by
  intro p hp
  have h : env30984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30983_30984 : H12AffineEnvironment.transform 10 692 env30983 = env30984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 692 env30983 == env30984) = true)

theorem identity30984 : scanCanonicalize (H12AffineFastState.compose env30984 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 34) := by decide +kernel

theorem selectedBound30984 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env30985 : List Nat := [2,4,8,16,32,0,128,34,512,140,692,16,9,190,136,5,174,132,50,137,17,191,16,4,62,190,13,190,191,524,4,1,35,174,174,702]

theorem envBound30985 : H12AffineFastState.Bounded env30985 := by
  intro p hp
  have h : env30985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30984_30985 : H12AffineEnvironment.transform 7 34 env30984 = env30985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 34 env30984 == env30985) = true)

theorem identity30985 : scanCanonicalize (H12AffineFastState.compose env30985 (packedSelected [5,13,15] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound30985 : packedSelected [5,13,15] rootPS < 2^1333 := by decide +kernel

def env30986 : List Nat := [2,4,8,16,32,0,128,34,16,140,164,16,9,190,136,5,174,132,50,137,17,191,16,4,62,190,13,190,191,28,4,1,35,174,174,174]

theorem envBound30986 : H12AffineFastState.Bounded env30986 := by
  intro p hp
  have h : env30986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30985_30986 : H12AffineEnvironment.transform 8 16 env30985 = env30986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env30985 == env30986) = true)

theorem identity30986 : scanCanonicalize (H12AffineFastState.compose env30986 (packedSelected [0,2,3,4,5,7,8,9,10] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound30986 : packedSelected [0,2,3,4,5,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env30987 : List Nat := [2,4,8,16,28,0,128,30,16,140,152,16,9,130,136,5,146,132,14,137,17,131,16,4,2,130,13,130,131,28,4,1,31,146,146,146]

theorem envBound30987 : H12AffineFastState.Bounded env30987 := by
  intro p hp
  have h : env30987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30986_30987 : H12AffineEnvironment.transform 4 28 env30986 = env30987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env30986 == env30987) = true)

theorem identity30987 : scanCanonicalize (H12AffineFastState.compose env30987 (packedSelected [0,1,4] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound30987 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env30988 : List Nat := [2,4,8,16,28,0,18,30,16,30,10,16,9,16,26,5,0,22,14,27,17,17,16,4,2,16,13,16,17,28,4,1,31,0,0,0]

theorem envBound30988 : H12AffineFastState.Bounded env30988 := by
  intro p hp
  have h : env30988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30987_30988 : H12AffineEnvironment.transform 6 18 env30987 = env30988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env30987 == env30988) = true)

theorem identity30988 : scanCanonicalize (H12AffineFastState.compose env30988 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound30988 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env30989 : List Nat := [2,4,3,16,23,0,18,21,16,21,1,16,2,16,17,5,0,22,5,16,17,17,16,4,2,16,6,16,17,23,4,1,20,0,0,0]

theorem envBound30989 : H12AffineFastState.Bounded env30989 := by
  intro p hp
  have h : env30989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30988_30989 : H12AffineEnvironment.transform 2 3 env30988 = env30989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env30988 == env30989) = true)

def env30990 : List Nat := [2,4,8,16,32,1,128,256,512,1024,2048,17,1156,1296,136,65536,1281,65665,66746,137,16,412,16,65536,66743,65723,66692,1296,65723,67998,1161,1164,257,1280,1281,66234]

theorem envBound30990 : H12AffineFastState.Bounded env30990 := by
  intro p hp
  have h : env30990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30975_30990 : H12AffineEnvironment.transform 5 1 env30975 = env30990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env30975 == env30990) = true)

theorem identity30990 : scanCanonicalize (H12AffineFastState.compose env30990 (packedSelected [1,8,28] rootPS)) = affineNative (2^(9+1) ^^^ 35) := by decide +kernel

theorem selectedBound30990 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env30991 : List Nat := [2,4,8,16,32,1,128,256,512,35,2048,17,167,307,136,65536,290,65665,65689,137,16,412,16,65536,65684,65723,65703,307,65723,67998,170,175,257,291,290,66234]

theorem envBound30991 : H12AffineFastState.Bounded env30991 := by
  intro p hp
  have h : env30991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30990_30991 : H12AffineEnvironment.transform 9 35 env30990 = env30991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 35 env30990 == env30991) = true)

def env30992 : List Nat := [2,4,8,16,32,1,128,140,512,35,2048,17,167,191,136,65536,174,65665,65689,137,16,16,16,65536,65684,65723,65703,191,65723,67602,170,175,141,175,174,66234]

theorem envBound30992 : H12AffineFastState.Bounded env30992 := by
  intro p hp
  have h : env30992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30991_30992 : H12AffineEnvironment.transform 7 140 env30991 = env30992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env30991 == env30992) = true)

theorem identity30992 : scanCanonicalize (H12AffineFastState.compose env30992 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound30992 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env30993 : List Nat := [2,4,8,16,32,1,8,4,512,35,2048,17,47,55,0,65536,38,65545,65553,1,16,16,16,65536,65564,65587,65583,55,65587,67602,34,39,5,39,38,66098]

theorem envBound30993 : H12AffineFastState.Bounded env30993 := by
  intro p hp
  have h : env30993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30992_30993 : H12AffineEnvironment.transform 6 8 env30992 = env30993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30992 == env30993) = true)

theorem identity30993 : scanCanonicalize (H12AffineFastState.compose env30993 (packedSelected [2,3,4,5,8,9,11,15,16,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 560) := by decide +kernel

theorem selectedBound30993 : packedSelected [2,3,4,5,8,9,11,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env30994 : List Nat := [2,4,8,16,32,1,8,4,512,35,560,17,47,55,0,65536,38,65545,65553,1,16,16,16,65536,65564,65587,65583,55,65587,66082,34,39,5,39,38,66098]

theorem envBound30994 : H12AffineFastState.Bounded env30994 := by
  intro p hp
  have h : env30994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30993_30994 : H12AffineEnvironment.transform 10 560 env30993 = env30994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 560 env30993 == env30994) = true)

theorem identity30994 : scanCanonicalize (H12AffineFastState.compose env30994 (packedSelected [0,1,4,5,7,8,9,10,11,12,16,17] rootPS)) = affineNative (2^(8+1) ^^^ 55) := by decide +kernel

theorem selectedBound30994 : packedSelected [0,1,4,5,7,8,9,10,11,12,16,17] rootPS < 2^1333 := by decide +kernel

def env30995 : List Nat := [2,4,8,16,32,1,8,4,55,35,7,17,47,55,0,65536,38,65545,65553,1,16,16,16,65536,65564,65587,65583,55,65587,65557,34,39,5,39,38,65541]

theorem envBound30995 : H12AffineFastState.Bounded env30995 := by
  intro p hp
  have h : env30995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30994_30995 : H12AffineEnvironment.transform 8 55 env30994 = env30995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 55 env30994 == env30995) = true)

theorem identity30995 : scanCanonicalize (H12AffineFastState.compose env30995 (packedSelected [0,2,7,10,11,12] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound30995 : packedSelected [0,2,7,10,11,12] rootPS < 2^1333 := by decide +kernel

def env30996 : List Nat := [2,2,8,16,32,1,8,2,49,35,1,17,41,49,0,65536,32,65545,65553,1,16,16,16,65536,65562,65587,65577,49,65587,65555,34,33,3,33,32,65539]

theorem envBound30996 : H12AffineFastState.Bounded env30996 := by
  intro p hp
  have h : env30996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30995_30996 : H12AffineEnvironment.transform 1 2 env30995 = env30996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env30995 == env30996) = true)

theorem identity30996 : scanCanonicalize (H12AffineFastState.compose env30996 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound30996 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env30997 : List Nat := [2,2,8,16,11,1,8,2,26,8,1,17,2,26,0,65536,11,65545,65553,1,16,16,16,65536,65562,65560,65538,26,65560,65555,9,10,3,10,11,65539]

theorem envBound30997 : H12AffineFastState.Bounded env30997 := by
  intro p hp
  have h : env30997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30996_30997 : H12AffineEnvironment.transform 4 11 env30996 = env30997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env30996 == env30997) = true)

theorem identity30997 : scanCanonicalize (H12AffineFastState.compose env30997 (packedSelected [1,2,3] rootPS)) = affineNative (2^(15+1) ^^^ 8) := by decide +kernel

theorem selectedBound30997 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env30998 : List Nat := [2,2,8,16,11,1,8,2,26,8,1,17,2,26,0,8,11,1,25,1,16,16,16,8,18,16,10,26,16,27,9,10,3,10,11,11]

theorem envBound30998 : H12AffineFastState.Bounded env30998 := by
  intro p hp
  have h : env30998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30997_30998 : H12AffineEnvironment.transform 15 8 env30997 = env30998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8 env30997 == env30998) = true)

theorem identity30998 : scanCanonicalize (H12AffineFastState.compose env30998 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound30998 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30999 : List Nat := [2,2,8,10,11,1,8,2,0,8,1,11,2,0,0,8,11,1,3,1,10,10,10,8,8,10,10,0,10,1,9,10,3,10,11,11]

theorem envBound30999 : H12AffineFastState.Bounded env30999 := by
  intro p hp
  have h : env30999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30998_30999 : H12AffineEnvironment.transform 3 10 env30998 = env30999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env30998 == env30999) = true)

theorem identity30999 : scanCanonicalize (H12AffineFastState.compose env30999 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound30999 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31000 : List Nat := [2,2,3,1,0,1,3,2,0,3,1,0,2,0,0,3,0,1,3,1,1,1,1,3,3,1,1,0,1,1,2,1,3,1,0,0]

theorem envBound31000 : H12AffineFastState.Bounded env31000 := by
  intro p hp
  have h : env31000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30999_31000 : H12AffineEnvironment.transform 2 3 env30999 = env31000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env30999 == env31000) = true)

def env31001 : List Nat := [2,4,8,16,32,1,128,141,512,35,2048,17,167,190,136,65536,175,65665,65689,137,16,17,16,65536,65684,65723,65703,190,65723,67603,170,175,140,174,175,66234]

theorem envBound31001 : H12AffineFastState.Bounded env31001 := by
  intro p hp
  have h : env31001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30991_31001 : H12AffineEnvironment.transform 7 141 env30991 = env31001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env30991 == env31001) = true)

theorem identity31001 : scanCanonicalize (H12AffineFastState.compose env31001 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 51) := by decide +kernel

theorem selectedBound31001 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env31002 : List Nat := [2,4,8,16,32,1,128,141,512,35,2048,17,167,190,136,51,175,178,170,137,16,17,16,51,167,136,148,190,136,2080,170,175,140,174,175,649]

theorem envBound31002 : H12AffineFastState.Bounded env31002 := by
  intro p hp
  have h : env31002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31001_31002 : H12AffineEnvironment.transform 15 51 env31001 = env31002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 51 env31001 == env31002) = true)

theorem identity31002 : scanCanonicalize (H12AffineFastState.compose env31002 (packedSelected [0,1,3,4,5,7,8,9,10,11,12,15,16,17] rootPS)) = affineNative (2^(10+1) ^^^ 146) := by decide +kernel

theorem selectedBound31002 : packedSelected [0,1,3,4,5,7,8,9,10,11,12,15,16,17] rootPS < 2^1333 := by decide +kernel

def env31003 : List Nat := [2,4,8,16,32,1,128,141,512,35,146,17,167,190,136,51,175,178,170,137,16,17,16,51,167,136,148,190,136,178,170,175,140,174,175,649]

theorem envBound31003 : H12AffineFastState.Bounded env31003 := by
  intro p hp
  have h : env31003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31002_31003 : H12AffineEnvironment.transform 10 146 env31002 = env31003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 146 env31002 == env31003) = true)

theorem identity31003 : scanCanonicalize (H12AffineFastState.compose env31003 (packedSelected [1,8,12] rootPS)) = affineNative (2^(6+1) ^^^ 62) := by decide +kernel

theorem selectedBound31003 : packedSelected [1,8,12] rootPS < 2^1333 := by decide +kernel

def env31004 : List Nat := [2,4,8,16,32,1,62,51,512,35,44,17,25,0,54,51,17,12,20,55,16,17,16,51,25,54,42,0,54,12,20,17,50,16,17,567]

theorem envBound31004 : H12AffineFastState.Bounded env31004 := by
  intro p hp
  have h : env31004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31003_31004 : H12AffineEnvironment.transform 6 62 env31003 = env31004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 62 env31003 == env31004) = true)

theorem identity31004 : scanCanonicalize (H12AffineFastState.compose env31004 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 45) := by decide +kernel

theorem selectedBound31004 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env31005 : List Nat := [2,4,8,16,32,1,62,51,45,35,44,17,25,0,54,51,17,12,20,55,16,17,16,51,25,54,42,0,54,12,20,17,50,16,17,26]

theorem envBound31005 : H12AffineFastState.Bounded env31005 := by
  intro p hp
  have h : env31005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31004_31005 : H12AffineEnvironment.transform 8 45 env31004 = env31005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 45 env31004 == env31005) = true)

theorem identity31005 : scanCanonicalize (H12AffineFastState.compose env31005 (packedSelected [2,5,8] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound31005 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env31006 : List Nat := [2,4,8,7,32,1,41,36,45,35,44,6,14,0,33,36,6,12,3,32,7,6,7,36,14,33,42,0,33,12,3,6,37,7,6,13]

theorem envBound31006 : H12AffineFastState.Bounded env31006 := by
  intro p hp
  have h : env31006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31005_31006 : H12AffineEnvironment.transform 3 7 env31005 = env31006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env31005 == env31006) = true)

theorem identity31006 : scanCanonicalize (H12AffineFastState.compose env31006 (packedSelected [0,1,9] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound31006 : packedSelected [0,1,9] rootPS < 2^1333 := by decide +kernel

def env31007 : List Nat := [2,4,8,7,13,1,4,9,0,14,1,6,14,0,12,9,6,12,3,13,7,6,7,9,14,12,7,0,12,12,3,6,8,7,6,13]

theorem envBound31007 : H12AffineFastState.Bounded env31007 := by
  intro p hp
  have h : env31007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31006_31007 : H12AffineEnvironment.transform 4 13 env31006 = env31007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env31006 == env31007) = true)

theorem identity31007 : scanCanonicalize (H12AffineFastState.compose env31007 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound31007 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31008 : List Nat := [2,4,4,7,1,1,4,5,0,2,1,6,2,0,0,5,6,0,3,1,7,6,7,5,2,0,7,0,0,0,3,6,4,7,6,1]

theorem envBound31008 : H12AffineFastState.Bounded env31008 := by
  intro p hp
  have h : env31008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31007_31008 : H12AffineEnvironment.transform 2 4 env31007 = env31008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env31007 == env31008) = true)

theorem identity31008 : scanCanonicalize (H12AffineFastState.compose env31008 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound31008 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31009 : List Nat := [0,4,4,5,1,1,4,5,0,0,1,4,0,0,0,5,4,0,1,1,5,4,5,5,0,0,5,0,0,0,1,4,4,5,4,1]

theorem envBound31009 : H12AffineFastState.Bounded env31009 := by
  intro p hp
  have h : env31009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31008_31009 : H12AffineEnvironment.transform 0 0 env31008 = env31009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env31008 == env31009) = true)

theorem identity31009 : scanCanonicalize (H12AffineFastState.compose env31009 (packedSelected [10] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound31009 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env31010 : List Nat := [0,0,0,1,1,1,0,1,0,0,1,0,0,0,0,1,0,0,1,1,1,0,1,1,0,0,1,0,0,0,1,0,0,1,0,1]

theorem envBound31010 : H12AffineFastState.Bounded env31010 := by
  intro p hp
  have h : env31010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31009_31010 : H12AffineEnvironment.transform 1 0 env31009 = env31010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env31009 == env31010) = true)

def env31011 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1345,262144,77935,32769,4097,46529,16,266385,70886,78895,77841,1296,74815,81227,365712,365716,257,1281,1344,79471]

theorem envBound31011 : H12AffineFastState.Bounded env31011 := by
  intro p hp
  have h : env31011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30906_31011 : H12AffineEnvironment.transform 13 1297 env30906 = env31011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env30906 == env31011) = true)

theorem identity31011 : scanCanonicalize (H12AffineFastState.compose env31011 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32883) := by decide +kernel

theorem selectedBound31011 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env31012 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,32883,1345,262144,45084,32769,4097,46529,16,266385,38037,46172,45154,1296,42060,48440,267491,267495,257,1281,1344,46620]

theorem envBound31012 : H12AffineFastState.Bounded env31012 := by
  intro p hp
  have h : env31012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31011_31012 : H12AffineEnvironment.transform 15 32883 env31011 = env31012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32883 env31011 == env31012) = true)

def env31013 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32883,1345,262144,42332,32769,1345,41089,16,263633,33237,41244,42274,1296,42060,43128,262563,262567,257,1281,1344,41820]

theorem envBound31013 : H12AffineFastState.Bounded env31013 := by
  intro p hp
  have h : env31013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31012_31013 : H12AffineEnvironment.transform 11 1344 env31012 = env31013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env31012 == env31013) = true)

theorem identity31013 : scanCanonicalize (H12AffineFastState.compose env31013 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 439) := by decide +kernel

theorem selectedBound31013 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env31014 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32883,1345,439,42332,32769,1345,41089,16,1126,33237,41244,42274,1296,42060,43128,20,16,257,1281,1344,41820]

theorem envBound31014 : H12AffineFastState.Bounded env31014 := by
  intro p hp
  have h : env31014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31013_31014 : H12AffineEnvironment.transform 17 439 env31013 = env31014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 439 env31013 == env31014) = true)

theorem identity31014 : scanCanonicalize (H12AffineFastState.compose env31014 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound31014 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env31015 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,8540,8495,1345,439,1024,8541,1345,477,16,1126,8329,64,1150,1296,1296,2340,20,16,257,1281,1344,512]

theorem envBound31015 : H12AffineFastState.Bounded env31015 := by
  intro p hp
  have h : env31015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31014_31015 : H12AffineEnvironment.transform 14 8540 env31014 = env31015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env31014 == env31015) = true)

theorem identity31015 : scanCanonicalize (H12AffineFastState.compose env31015 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound31015 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env31016 : List Nat := [2,4,8,16,32,64,128,256,512,84,2048,276,8192,325,8540,8495,277,439,84,8541,277,477,16,50,8329,64,42,324,324,2340,20,16,257,341,276,512]

theorem envBound31016 : H12AffineFastState.Bounded env31016 := by
  intro p hp
  have h : env31016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31015_31016 : H12AffineEnvironment.transform 9 84 env31015 = env31016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env31015 == env31016) = true)

theorem identity31016 : scanCanonicalize (H12AffineFastState.compose env31016 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 980) := by decide +kernel

theorem selectedBound31016 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env31017 : List Nat := [2,4,8,16,32,64,128,256,512,84,2048,276,980,325,648,763,277,439,84,649,277,477,16,50,861,64,42,324,324,2340,20,16,257,341,276,512]

theorem envBound31017 : H12AffineFastState.Bounded env31017 := by
  intro p hp
  have h : env31017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31016_31017 : H12AffineEnvironment.transform 12 980 env31016 = env31017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 980 env31016 == env31017) = true)

theorem identity31017 : scanCanonicalize (H12AffineFastState.compose env31017 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound31017 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env31018 : List Nat := [2,4,8,16,32,17,128,256,512,5,2048,276,901,276,648,682,277,439,5,649,277,396,16,50,780,17,42,277,277,2340,20,16,257,260,276,512]

theorem envBound31018 : H12AffineFastState.Bounded env31018 := by
  intro p hp
  have h : env31018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31017_31018 : H12AffineEnvironment.transform 5 17 env31017 = env31018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31017 == env31018) = true)

theorem identity31018 : scanCanonicalize (H12AffineFastState.compose env31018 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound31018 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env31019 : List Nat := [2,4,8,16,32,17,128,172,512,5,2048,184,553,184,648,682,185,27,5,649,185,32,16,50,672,17,42,185,185,2184,20,16,173,168,184,512]

theorem envBound31019 : H12AffineFastState.Bounded env31019 := by
  intro p hp
  have h : env31019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31018_31019 : H12AffineEnvironment.transform 7 172 env31018 = env31019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env31018 == env31019) = true)

theorem identity31019 : scanCanonicalize (H12AffineFastState.compose env31019 (packedSelected [0,1,2,4,5,7,9] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound31019 : packedSelected [0,1,2,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env31020 : List Nat := [2,4,8,11,32,10,128,172,512,5,2048,163,553,163,648,682,162,0,5,649,162,32,11,41,672,10,42,162,162,2184,15,11,173,168,163,512]

theorem envBound31020 : H12AffineFastState.Bounded env31020 := by
  intro p hp
  have h : env31020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31019_31020 : H12AffineEnvironment.transform 3 11 env31019 = env31020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env31019 == env31020) = true)

theorem identity31020 : scanCanonicalize (H12AffineFastState.compose env31020 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 162) := by decide +kernel

theorem selectedBound31020 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env31021 : List Nat := [2,4,8,11,32,10,128,172,512,5,162,163,553,163,648,682,162,0,5,649,162,32,11,41,672,10,42,162,162,42,15,11,173,168,163,512]

theorem envBound31021 : H12AffineFastState.Bounded env31021 := by
  intro p hp
  have h : env31021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31020_31021 : H12AffineEnvironment.transform 10 162 env31020 = env31021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 162 env31020 == env31021) = true)

theorem identity31021 : scanCanonicalize (H12AffineFastState.compose env31021 (packedSelected [0,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound31021 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env31022 : List Nat := [2,4,8,11,32,10,128,172,136,5,162,163,161,163,0,34,162,0,5,1,162,32,11,41,40,10,42,162,162,42,15,11,173,168,163,136]

theorem envBound31022 : H12AffineFastState.Bounded env31022 := by
  intro p hp
  have h : env31022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31021_31022 : H12AffineEnvironment.transform 8 136 env31021 = env31022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env31021 == env31022) = true)

theorem identity31022 : scanCanonicalize (H12AffineFastState.compose env31022 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound31022 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env31023 : List Nat := [2,4,8,11,32,10,8,36,0,5,42,43,41,43,0,34,42,0,5,1,42,32,11,41,40,10,42,42,42,42,15,11,37,32,43,0]

theorem envBound31023 : H12AffineFastState.Bounded env31023 := by
  intro p hp
  have h : env31023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31022_31023 : H12AffineEnvironment.transform 6 8 env31022 = env31023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31022 == env31023) = true)

def env31024 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32883,1345,262144,42333,32769,1344,41088,16,263632,33236,41245,42275,1296,42060,43129,262562,262566,257,1281,1344,41821]

theorem envBound31024 : H12AffineFastState.Bounded env31024 := by
  intro p hp
  have h : env31024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31012_31024 : H12AffineEnvironment.transform 11 1345 env31012 = env31024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env31012 == env31024) = true)

theorem identity31024 : scanCanonicalize (H12AffineFastState.compose env31024 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 324) := by decide +kernel

theorem selectedBound31024 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env31025 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,324,311,1345,262144,9241,325,1344,8644,16,263632,144,8281,9319,1296,9480,10557,262562,262566,257,1281,1344,8729]

theorem envBound31025 : H12AffineFastState.Bounded env31025 := by
  intro p hp
  have h : env31025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31024_31025 : H12AffineEnvironment.transform 14 324 env31024 = env31025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 324 env31024 == env31025) = true)

theorem identity31025 : scanCanonicalize (H12AffineFastState.compose env31025 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(10+1) ^^^ 1883) := by decide +kernel

theorem selectedBound31025 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env31026 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1883,1345,8192,1297,324,311,1345,262144,9241,325,1344,8644,16,263632,144,8281,9319,1296,9480,9830,262562,262566,257,1281,1344,8729]

theorem envBound31026 : H12AffineFastState.Bounded env31026 := by
  intro p hp
  have h : env31026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31025_31026 : H12AffineEnvironment.transform 10 1883 env31025 = env31026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1883 env31025 == env31026) = true)

def env31027 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16465,262144,95614,32769,4097,61648,17,284032,86519,94527,77840,1297,74815,96346,381313,365717,257,16401,1344,95102]

theorem envBound31027 : H12AffineFastState.Bounded env31027 := by
  intro p hp
  have h : env31027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30905_31027 : H12AffineEnvironment.transform 16 16465 env30905 = env31027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16465 env30905 == env31027) = true)

def env31028 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1345,262144,77934,32769,4097,46528,17,266384,70887,78895,77840,1297,74815,81226,365713,365717,257,1281,1344,79470]

theorem envBound31028 : H12AffineFastState.Bounded env31028 := by
  intro p hp
  have h : env31028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31027_31028 : H12AffineEnvironment.transform 13 1296 env31027 = env31028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env31027 == env31028) = true)

theorem identity31028 : scanCanonicalize (H12AffineFastState.compose env31028 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32882) := by decide +kernel

theorem selectedBound31028 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env31029 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,32882,1345,262144,45084,32769,4097,46528,17,266384,38037,46173,45154,1297,42061,48440,267491,267495,257,1281,1344,46620]

theorem envBound31029 : H12AffineFastState.Bounded env31029 := by
  intro p hp
  have h : env31029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31028_31029 : H12AffineEnvironment.transform 15 32882 env31028 = env31029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32882 env31028 == env31029) = true)

def env31030 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32882,1345,262144,42332,32769,1345,41088,17,263632,33237,41245,42274,1297,42061,43128,262563,262567,257,1281,1344,41820]

theorem envBound31030 : H12AffineFastState.Bounded env31030 := by
  intro p hp
  have h : env31030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31029_31030 : H12AffineEnvironment.transform 11 1344 env31029 = env31030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env31029 == env31030) = true)

theorem identity31030 : scanCanonicalize (H12AffineFastState.compose env31030 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 34275) := by decide +kernel

theorem selectedBound31030 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env31031 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32882,1345,34275,42332,32769,1345,41088,17,32819,33237,41245,42274,1297,42061,43128,33856,33860,257,1281,1344,41820]

theorem envBound31031 : H12AffineFastState.Bounded env31031 := by
  intro p hp
  have h : env31031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31030_31031 : H12AffineEnvironment.transform 17 34275 env31030 = env31031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 34275 env31030 == env31031) = true)

theorem identity31031 : scanCanonicalize (H12AffineFastState.compose env31031 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(10+1) ^^^ 1883) := by decide +kernel

theorem selectedBound31031 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env31032 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1883,1344,8192,1296,32768,32882,1345,34275,42332,32769,1345,41088,17,32819,33237,41245,42274,1297,42061,42787,33856,33860,257,1281,1344,41820]

theorem envBound31032 : H12AffineFastState.Bounded env31032 := by
  intro p hp
  have h : env31032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31031_31032 : H12AffineEnvironment.transform 10 1883 env31031 = env31032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1883 env31031 == env31032) = true)

def env31033 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32882,1345,262144,42333,32769,1344,41089,17,263633,33236,41244,42275,1297,42061,43129,262562,262566,257,1281,1344,41821]

theorem envBound31033 : H12AffineFastState.Bounded env31033 := by
  intro p hp
  have h : env31033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31029_31033 : H12AffineEnvironment.transform 11 1345 env31029 = env31033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env31029 == env31033) = true)

theorem identity31033 : scanCanonicalize (H12AffineFastState.compose env31033 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound31033 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env31034 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,80,8192,1,32768,32882,80,262144,41036,32769,81,41089,17,262336,33236,41244,41010,0,41308,43129,262562,262566,257,16,81,41821]

theorem envBound31034 : H12AffineFastState.Bounded env31034 := by
  intro p hp
  have h : env31034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31033_31034 : H12AffineEnvironment.transform 9 273 env31033 = env31034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env31033 == env31034) = true)

theorem identity31034 : scanCanonicalize (H12AffineFastState.compose env31034 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound31034 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env31035 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,80,8192,1,8541,8495,80,262144,273,8540,81,476,17,262336,8329,65,367,0,1,2340,262562,262566,257,16,81,512]

theorem envBound31035 : H12AffineFastState.Bounded env31035 := by
  intro p hp
  have h : env31035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31034_31035 : H12AffineEnvironment.transform 14 8541 env31034 = env31035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env31034 == env31035) = true)

theorem identity31035 : scanCanonicalize (H12AffineFastState.compose env31035 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound31035 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env31036 : List Nat := [2,4,8,16,32,64,128,69,512,84,2048,80,8192,1,8216,8298,80,262144,84,8217,81,153,17,262336,8329,65,42,0,1,2145,262375,262371,68,16,81,512]

theorem envBound31036 : H12AffineFastState.Bounded env31036 := by
  intro p hp
  have h : env31036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31035_31036 : H12AffineEnvironment.transform 7 69 env31035 = env31036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env31035 == env31036) = true)

theorem identity31036 : scanCanonicalize (H12AffineFastState.compose env31036 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 657) := by decide +kernel

theorem selectedBound31036 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env31037 : List Nat := [2,4,8,16,32,64,128,69,512,84,2048,80,657,1,649,763,80,262144,84,648,81,153,17,262336,536,65,42,0,1,2145,262375,262371,68,16,81,512]

theorem envBound31037 : H12AffineFastState.Bounded env31037 := by
  intro p hp
  have h : env31037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31036_31037 : H12AffineEnvironment.transform 12 657 env31036 = env31037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 657 env31036 == env31037) = true)

theorem identity31037 : scanCanonicalize (H12AffineFastState.compose env31037 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound31037 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env31038 : List Nat := [2,4,8,16,32,17,128,20,512,5,2048,1,657,1,649,682,1,262144,5,648,0,153,17,262289,536,16,42,0,1,2096,262326,262322,21,16,0,512]

theorem envBound31038 : H12AffineFastState.Bounded env31038 := by
  intro p hp
  have h : env31038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31037_31038 : H12AffineEnvironment.transform 5 17 env31037 = env31038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31037 == env31038) = true)

def env31039 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1344,262144,77935,32769,4097,46529,17,266385,70886,78894,77840,1297,74815,81227,365712,365717,257,1280,1344,79471]

theorem envBound31039 : H12AffineFastState.Bounded env31039 := by
  intro p hp
  have h : env31039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31027_31039 : H12AffineEnvironment.transform 13 1297 env31027 = env31039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env31027 == env31039) = true)

theorem identity31039 : scanCanonicalize (H12AffineFastState.compose env31039 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound31039 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env31040 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1344,262144,77935,13340,4097,476,17,266385,70886,78894,77840,1297,74815,81227,336013,336008,257,1280,1344,79471]

theorem envBound31040 : H12AffineFastState.Bounded env31040 := by
  intro p hp
  have h : env31040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31039_31040 : H12AffineEnvironment.transform 14 13341 env31039 = env31040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env31039 == env31040) = true)

def env31041 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1344,65664,77935,13340,4097,476,17,69649,70886,78894,77840,1297,74815,81227,8205,8200,257,1280,1344,79471]

theorem envBound31041 : H12AffineFastState.Bounded env31041 := by
  intro p hp
  have h : env31041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31040_31041 : H12AffineEnvironment.transform 17 65664 env31040 = env31041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env31040 == env31041) = true)

theorem identity31041 : scanCanonicalize (H12AffineFastState.compose env31041 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5464) := by decide +kernel

theorem selectedBound31041 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env31042 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5464,1297,325,65536,1344,65664,66871,324,4097,476,17,69649,70886,65910,66888,1297,69991,67603,5461,5456,257,1280,1344,66359]

theorem envBound31042 : H12AffineFastState.Bounded env31042 := by
  intro p hp
  have h : env31042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31041_31042 : H12AffineEnvironment.transform 12 5464 env31041 = env31042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5464 env31041 == env31042) = true)

def env31043 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5384,1297,277,65536,1296,65664,66871,276,4097,396,17,69649,70838,65830,66840,1297,69943,67603,5381,5376,257,1280,1296,66359]

theorem envBound31043 : H12AffineFastState.Bounded env31043 := by
  intro p hp
  have h : env31043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31042_31043 : H12AffineEnvironment.transform 5 16 env31042 = env31043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31042 == env31043) = true)

theorem identity31043 : scanCanonicalize (H12AffineFastState.compose env31043 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 4131) := by decide +kernel

theorem selectedBound31043 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env31044 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5384,1297,277,4131,1296,4259,5396,276,4097,396,17,50,1173,4357,5435,1297,276,6192,5381,5376,257,1280,1296,4884]

theorem envBound31044 : H12AffineFastState.Bounded env31044 := by
  intro p hp
  have h : env31044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31043_31044 : H12AffineEnvironment.transform 15 4131 env31043 = env31044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4131 env31043 == env31044) = true)

theorem identity31044 : scanCanonicalize (H12AffineFastState.compose env31044 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound31044 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env31045 : List Nat := [2,4,8,16,32,16,128,256,512,4,2048,4096,4364,277,277,4131,276,4259,4368,276,4097,396,17,50,145,4357,4415,277,276,6192,4353,4356,257,260,276,4884]

theorem envBound31045 : H12AffineFastState.Bounded env31045 := by
  intro p hp
  have h : env31045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31044_31045 : H12AffineEnvironment.transform 9 4 env31044 = env31045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env31044 == env31045) = true)

theorem identity31045 : scanCanonicalize (H12AffineFastState.compose env31045 (packedSelected [0,2,3,7,8,10,12,15,17,18,19] rootPS)) = affineNative (2^(8+1) ^^^ 270) := by decide +kernel

theorem selectedBound31045 : packedSelected [0,2,3,7,8,10,12,15,17,18,19] rootPS < 2^1333 := by decide +kernel

def env31046 : List Nat := [2,4,8,16,32,16,128,256,270,4,2048,4096,4364,277,277,4131,276,4259,4368,276,4097,396,17,50,145,4357,4415,277,276,6192,4353,4356,257,260,276,4122]

theorem envBound31046 : H12AffineFastState.Bounded env31046 := by
  intro p hp
  have h : env31046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31045_31046 : H12AffineEnvironment.transform 8 270 env31045 = env31046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 270 env31045 == env31046) = true)

theorem identity31046 : scanCanonicalize (H12AffineFastState.compose env31046 (packedSelected [1,8,12,13,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 319) := by decide +kernel

theorem selectedBound31046 : packedSelected [1,8,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env31047 : List Nat := [2,4,8,16,32,16,128,256,270,4,319,4096,4364,277,277,4131,276,4259,4368,276,4097,396,17,50,145,4357,4415,277,276,4367,4353,4356,257,260,276,4122]

theorem envBound31047 : H12AffineFastState.Bounded env31047 := by
  intro p hp
  have h : env31047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31046_31047 : H12AffineEnvironment.transform 10 319 env31046 = env31047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 319 env31046 == env31047) = true)

theorem identity31047 : scanCanonicalize (H12AffineFastState.compose env31047 (packedSelected [2,4,5,8,9,10,11] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound31047 : packedSelected [2,4,5,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env31048 : List Nat := [2,4,8,16,16,16,128,256,270,4,271,4096,4364,277,277,4115,276,4243,4368,276,4097,396,17,2,145,4357,4367,277,276,4367,4353,4356,257,260,276,4122]

theorem envBound31048 : H12AffineFastState.Bounded env31048 := by
  intro p hp
  have h : env31048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31047_31048 : H12AffineEnvironment.transform 4 16 env31047 = env31048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env31047 == env31048) = true)

theorem identity31048 : scanCanonicalize (H12AffineFastState.compose env31048 (packedSelected [0,1,4,5,7,9,10] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound31048 : packedSelected [0,1,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env31049 : List Nat := [2,4,8,10,10,10,128,256,270,4,271,4096,4364,271,271,4105,270,4233,4362,270,4097,396,11,2,139,4357,4367,271,270,4367,4353,4356,257,260,270,4096]

theorem envBound31049 : H12AffineFastState.Bounded env31049 := by
  intro p hp
  have h : env31049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31048_31049 : H12AffineEnvironment.transform 3 10 env31048 = env31049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env31048 == env31049) = true)

theorem identity31049 : scanCanonicalize (H12AffineFastState.compose env31049 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 137) := by decide +kernel

theorem selectedBound31049 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31050 : List Nat := [2,4,8,10,10,10,128,256,270,4,271,137,389,271,271,128,270,0,387,270,136,396,11,2,139,396,390,271,270,390,392,397,257,260,270,137]

theorem envBound31050 : H12AffineFastState.Bounded env31050 := by
  intro p hp
  have h : env31050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31049_31050 : H12AffineEnvironment.transform 11 137 env31049 = env31050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 137 env31049 == env31050) = true)

def env31051 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,5385,1297,276,65536,1297,65664,66871,277,4097,397,17,69649,70839,65831,66841,1297,69942,67603,5380,5377,257,1280,1297,66359]

theorem envBound31051 : H12AffineFastState.Bounded env31051 := by
  intro p hp
  have h : env31051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31042_31051 : H12AffineEnvironment.transform 5 17 env31042 = env31051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31042 == env31051) = true)

theorem identity31051 : scanCanonicalize (H12AffineFastState.compose env31051 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound31051 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env31052 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,276,1053,1297,276,65536,1297,65664,66871,277,277,397,17,65797,66979,65831,66841,1297,65570,67603,1040,1045,257,1280,1297,66359]

theorem envBound31052 : H12AffineFastState.Bounded env31052 := by
  intro p hp
  have h : env31052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31051_31052 : H12AffineEnvironment.transform 11 276 env31051 = env31052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env31051 == env31052) = true)

theorem identity31052 : scanCanonicalize (H12AffineFastState.compose env31052 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 1331) := by decide +kernel

theorem selectedBound31052 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env31053 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,276,1053,1297,276,1331,1297,1459,4,277,277,397,17,1078,144,1044,42,1297,1297,3360,1040,1045,257,1280,1297,1540]

theorem envBound31053 : H12AffineFastState.Bounded env31053 := by
  intro p hp
  have h : env31053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31052_31053 : H12AffineEnvironment.transform 15 1331 env31052 = env31053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1331 env31052 == env31053) = true)

theorem identity31053 : scanCanonicalize (H12AffineFastState.compose env31053 (packedSelected [0,2,3,7,8,11,12,15,17] rootPS)) = affineNative (2^(9+1) ^^^ 387) := by decide +kernel

theorem selectedBound31053 : packedSelected [0,2,3,7,8,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env31054 : List Nat := [2,4,8,16,32,17,128,256,512,387,2048,276,414,146,276,176,146,48,4,277,277,397,17,437,144,407,42,146,146,2211,403,406,257,131,146,903]

theorem envBound31054 : H12AffineFastState.Bounded env31054 := by
  intro p hp
  have h : env31054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31053_31054 : H12AffineEnvironment.transform 9 387 env31053 = env31054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 387 env31053 == env31054) = true)

theorem identity31054 : scanCanonicalize (H12AffineFastState.compose env31054 (packedSelected [0,1,7,8,10,11,12,13] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound31054 : packedSelected [0,1,7,8,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env31055 : List Nat := [2,4,8,16,16,17,128,256,512,387,2048,276,414,146,276,128,146,0,4,277,277,397,17,389,144,407,26,146,146,2195,403,406,257,131,146,903]

theorem envBound31055 : H12AffineFastState.Bounded env31055 := by
  intro p hp
  have h : env31055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31054_31055 : H12AffineEnvironment.transform 4 16 env31054 = env31055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env31054 == env31055) = true)

theorem identity31055 : scanCanonicalize (H12AffineFastState.compose env31055 (packedSelected [0,2,5,7,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 390) := by decide +kernel

theorem selectedBound31055 : packedSelected [0,2,5,7,8,10] rootPS < 2^1333 := by decide +kernel

def env31056 : List Nat := [2,4,8,16,16,17,128,256,512,387,390,276,414,146,276,128,146,0,4,277,277,397,17,389,144,407,26,146,146,277,403,406,257,131,146,903]

theorem envBound31056 : H12AffineFastState.Bounded env31056 := by
  intro p hp
  have h : env31056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31055_31056 : H12AffineEnvironment.transform 10 390 env31055 = env31056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 390 env31055 == env31056) = true)

theorem identity31056 : scanCanonicalize (H12AffineFastState.compose env31056 (packedSelected [3,8] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound31056 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env31057 : List Nat := [2,4,8,16,16,17,128,256,0,387,390,276,414,146,276,128,146,0,4,277,277,397,17,389,144,407,26,146,146,277,403,406,257,131,146,391]

theorem envBound31057 : H12AffineFastState.Bounded env31057 := by
  intro p hp
  have h : env31057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31056_31057 : H12AffineEnvironment.transform 8 0 env31056 = env31057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env31056 == env31057) = true)

theorem identity31057 : scanCanonicalize (H12AffineFastState.compose env31057 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound31057 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env31058 : List Nat := [2,4,8,16,16,17,9,256,0,266,271,276,279,27,276,9,27,0,4,277,277,260,17,268,25,286,26,27,27,277,282,287,257,10,27,270]

theorem envBound31058 : H12AffineFastState.Bounded env31058 := by
  intro p hp
  have h : env31058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31057_31058 : H12AffineEnvironment.transform 6 9 env31057 = env31058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31057 == env31058) = true)

def env31059 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1344,65665,77935,13340,4097,476,17,69648,70886,78894,77840,1297,74815,81227,8204,8201,257,1280,1344,79471]

theorem envBound31059 : H12AffineFastState.Bounded env31059 := by
  intro p hp
  have h : env31059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31040_31059 : H12AffineEnvironment.transform 17 65665 env31040 = env31059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env31040 == env31059) = true)

theorem identity31059 : scanCanonicalize (H12AffineFastState.compose env31059 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound31059 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env31060 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,24,1297,5125,65536,1344,65665,69751,5124,4097,476,17,69648,70886,70710,69640,1297,66599,73043,20,17,257,1280,1344,71287]

theorem envBound31060 : H12AffineFastState.Bounded env31060 := by
  intro p hp
  have h : env31060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31059_31060 : H12AffineEnvironment.transform 12 24 env31059 = env31060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env31059 == env31060) = true)

def env31061 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,24,1297,5125,65536,1296,65665,69671,5124,4097,396,17,69648,70838,70710,69640,1297,66599,72963,20,17,257,1280,1296,71207]

theorem envBound31061 : H12AffineFastState.Bounded env31061 := by
  intro p hp
  have h : env31061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31060_31061 : H12AffineEnvironment.transform 5 16 env31060 = env31061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31060 == env31061) = true)

theorem identity31061 : scanCanonicalize (H12AffineFastState.compose env31061 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 1331) := by decide +kernel

theorem selectedBound31061 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env31062 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,24,1297,5125,1331,1296,1458,5396,5124,4097,396,17,5411,4485,4357,5435,1297,276,6192,20,17,257,1280,1296,4884]

theorem envBound31062 : H12AffineFastState.Bounded env31062 := by
  intro p hp
  have h : env31062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31061_31062 : H12AffineEnvironment.transform 15 1331 env31061 = env31062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1331 env31061 == env31062) = true)

theorem identity31062 : scanCanonicalize (H12AffineFastState.compose env31062 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound31062 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env31063 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,24,1297,277,1331,1296,1458,4,276,1297,396,17,51,1173,1045,43,1297,276,3360,20,17,257,1280,1296,1540]

theorem envBound31063 : H12AffineFastState.Bounded env31063 := by
  intro p hp
  have h : env31063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31062_31063 : H12AffineEnvironment.transform 11 1296 env31062 = env31063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env31062 == env31063) = true)

theorem identity31063 : scanCanonicalize (H12AffineFastState.compose env31063 (packedSelected [0,1,3,5,7,8,11] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound31063 : packedSelected [0,1,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env31064 : List Nat := [2,4,8,16,32,16,128,256,512,5,2048,277,24,276,277,310,277,439,4,276,276,396,17,51,144,16,43,276,276,2341,20,17,257,261,277,513]

theorem envBound31064 : H12AffineFastState.Bounded env31064 := by
  intro p hp
  have h : env31064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31063_31064 : H12AffineEnvironment.transform 9 5 env31063 = env31064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env31063 == env31064) = true)

theorem identity31064 : scanCanonicalize (H12AffineFastState.compose env31064 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound31064 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31065 : List Nat := [2,4,8,16,32,16,128,256,277,5,2048,277,24,276,277,310,277,439,4,276,276,396,17,51,144,16,43,276,276,2341,20,17,257,261,277,276]

theorem envBound31065 : H12AffineFastState.Bounded env31065 := by
  intro p hp
  have h : env31065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31064_31065 : H12AffineEnvironment.transform 8 277 env31064 = env31065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env31064 == env31065) = true)

theorem identity31065 : scanCanonicalize (H12AffineFastState.compose env31065 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound31065 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env31066 : List Nat := [2,4,8,16,32,16,128,256,277,5,0,277,24,276,277,310,277,439,4,276,276,396,17,51,144,16,43,276,276,293,20,17,257,261,277,276]

theorem envBound31066 : H12AffineFastState.Bounded env31066 := by
  intro p hp
  have h : env31066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31065_31066 : H12AffineEnvironment.transform 10 0 env31065 = env31066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env31065 == env31066) = true)

theorem identity31066 : scanCanonicalize (H12AffineFastState.compose env31066 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound31066 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env31067 : List Nat := [2,4,8,16,32,16,128,5,16,5,0,16,24,17,16,51,16,178,4,17,17,137,17,51,144,16,43,17,17,32,20,17,4,0,16,17]

theorem envBound31067 : H12AffineFastState.Bounded env31067 := by
  intro p hp
  have h : env31067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31066_31067 : H12AffineEnvironment.transform 7 5 env31066 = env31067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env31066 == env31067) = true)

theorem identity31067 : scanCanonicalize (H12AffineFastState.compose env31067 (packedSelected [0,1,3] rootPS)) = affineNative (2^(4+1) ^^^ 31) := by decide +kernel

theorem selectedBound31067 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env31068 : List Nat := [2,4,8,16,31,16,128,5,16,5,0,16,24,17,16,12,16,141,4,17,17,137,17,12,144,16,20,17,17,31,20,17,4,0,16,17]

theorem envBound31068 : H12AffineFastState.Bounded env31068 := by
  intro p hp
  have h : env31068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31067_31068 : H12AffineEnvironment.transform 4 31 env31067 = env31068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 31 env31067 == env31068) = true)

theorem identity31068 : scanCanonicalize (H12AffineFastState.compose env31068 (packedSelected [0,1,5,12] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound31068 : packedSelected [0,1,5,12] rootPS < 2^1333 := by decide +kernel

def env31069 : List Nat := [2,4,8,0,15,0,128,5,0,5,0,0,8,1,0,12,0,141,4,1,1,137,1,12,128,0,4,1,1,15,4,1,4,0,0,1]

theorem envBound31069 : H12AffineFastState.Bounded env31069 := by
  intro p hp
  have h : env31069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31068_31069 : H12AffineEnvironment.transform 3 0 env31068 = env31069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env31068 == env31069) = true)

theorem identity31069 : scanCanonicalize (H12AffineFastState.compose env31069 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 12) := by decide +kernel

theorem selectedBound31069 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31070 : List Nat := [2,4,8,0,15,0,12,5,0,5,0,0,8,1,0,12,0,1,4,1,1,5,1,12,12,0,4,1,1,15,4,1,4,0,0,1]

theorem envBound31070 : H12AffineFastState.Bounded env31070 := by
  intro p hp
  have h : env31070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31069_31070 : H12AffineEnvironment.transform 6 12 env31069 = env31070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 12 env31069 == env31070) = true)

theorem identity31070 : scanCanonicalize (H12AffineFastState.compose env31070 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound31070 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31071 : List Nat := [2,4,4,0,3,0,0,5,0,5,0,0,4,1,0,0,0,1,4,1,1,5,1,0,0,0,4,1,1,3,4,1,4,0,0,1]

theorem envBound31071 : H12AffineFastState.Bounded env31071 := by
  intro p hp
  have h : env31071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31070_31071 : H12AffineEnvironment.transform 2 4 env31070 = env31071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env31070 == env31071) = true)

theorem identity31071 : scanCanonicalize (H12AffineFastState.compose env31071 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound31071 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env31072 : List Nat := [2,3,3,0,3,0,0,2,0,2,0,0,3,1,0,0,0,1,3,1,1,2,1,0,0,0,3,1,1,3,3,1,3,0,0,1]

theorem envBound31072 : H12AffineFastState.Bounded env31072 := by
  intro p hp
  have h : env31072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31071_31072 : H12AffineEnvironment.transform 1 3 env31071 = env31072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env31071 == env31072) = true)

theorem identity31072 : scanCanonicalize (H12AffineFastState.compose env31072 (packedSelected [7] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound31072 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env31073 : List Nat := [1,0,0,0,0,0,0,1,0,1,0,0,0,1,0,0,0,1,0,1,1,1,1,0,0,0,0,1,1,0,0,1,0,0,0,1]

theorem envBound31073 : H12AffineFastState.Bounded env31073 := by
  intro p hp
  have h : env31073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31072_31073 : H12AffineEnvironment.transform 0 1 env31072 = env31073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env31072 == env31073) = true)

def env31074 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,24,1297,5125,65536,1297,65665,69670,5124,4097,397,17,69648,70839,70710,69640,1297,66599,72962,20,17,257,1280,1297,71206]

theorem envBound31074 : H12AffineFastState.Bounded env31074 := by
  intro p hp
  have h : env31074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31060_31074 : H12AffineEnvironment.transform 5 17 env31060 = env31074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31060 == env31074) = true)

theorem identity31074 : scanCanonicalize (H12AffineFastState.compose env31074 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound31074 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env31075 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,276,24,1297,1297,65536,1297,65665,65842,1296,277,397,17,65796,66979,66850,65820,1297,66599,68630,20,17,257,1280,1297,67378]

theorem envBound31075 : H12AffineFastState.Bounded env31075 := by
  intro p hp
  have h : env31075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31074_31075 : H12AffineEnvironment.transform 11 276 env31074 = env31075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env31074 == env31075) = true)

theorem identity31075 : scanCanonicalize (H12AffineFastState.compose env31075 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound31075 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env31076 : List Nat := [2,4,8,16,32,17,128,256,512,4,2048,276,24,277,277,65536,277,65665,65842,276,277,397,17,65796,65959,65830,65820,277,65571,67602,20,17,257,260,277,66358]

theorem envBound31076 : H12AffineFastState.Bounded env31076 := by
  intro p hp
  have h : env31076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31075_31076 : H12AffineEnvironment.transform 9 4 env31075 = env31076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env31075 == env31076) = true)

theorem identity31076 : scanCanonicalize (H12AffineFastState.compose env31076 (packedSelected [0,2,7,10,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 667) := by decide +kernel

theorem selectedBound31076 : packedSelected [0,2,7,10,18,19] rootPS < 2^1333 := by decide +kernel

def env31077 : List Nat := [2,4,8,16,32,17,128,256,512,4,2048,276,24,277,277,667,277,538,937,276,277,397,17,927,828,957,903,277,696,2697,20,17,257,260,277,429]

theorem envBound31077 : H12AffineFastState.Bounded env31077 := by
  intro p hp
  have h : env31077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31076_31077 : H12AffineEnvironment.transform 15 667 env31076 = env31077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 667 env31076 == env31077) = true)

theorem identity31077 : scanCanonicalize (H12AffineFastState.compose env31077 (packedSelected [0,1,7,8,12,13,15,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound31077 : packedSelected [0,1,7,8,12,13,15,17,18] rootPS < 2^1333 := by decide +kernel

def env31078 : List Nat := [2,4,8,16,32,17,128,256,512,4,49,276,24,277,277,667,277,538,937,276,277,397,17,927,828,957,903,277,696,696,20,17,257,260,277,429]

theorem envBound31078 : H12AffineFastState.Bounded env31078 := by
  intro p hp
  have h : env31078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31077_31078 : H12AffineEnvironment.transform 10 49 env31077 = env31078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env31077 == env31078) = true)

theorem identity31078 : scanCanonicalize (H12AffineFastState.compose env31078 (packedSelected [0,1,7,8,10,11,13,15] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound31078 : packedSelected [0,1,7,8,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env31079 : List Nat := [2,4,8,16,32,17,8,256,512,4,49,276,24,277,277,531,277,538,801,276,277,261,17,791,828,821,783,277,560,560,20,17,257,260,277,293]

theorem envBound31079 : H12AffineFastState.Bounded env31079 := by
  intro p hp
  have h : env31079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31078_31079 : H12AffineEnvironment.transform 6 8 env31078 = env31079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31078 == env31079) = true)

theorem identity31079 : scanCanonicalize (H12AffineFastState.compose env31079 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound31079 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env31080 : List Nat := [2,4,8,16,32,17,8,14,512,4,49,26,24,27,27,531,27,538,559,26,27,11,17,537,562,571,513,27,560,560,20,17,15,10,27,43]

theorem envBound31080 : H12AffineFastState.Bounded env31080 := by
  intro p hp
  have h : env31080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31079_31080 : H12AffineEnvironment.transform 7 14 env31079 = env31080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env31079 == env31080) = true)

theorem identity31080 : scanCanonicalize (H12AffineFastState.compose env31080 (packedSelected [2,4,7] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound31080 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env31081 : List Nat := [2,4,8,16,32,17,8,14,1,4,49,26,24,27,27,18,27,27,46,26,27,11,17,24,51,58,0,27,49,49,20,17,15,10,27,43]

theorem envBound31081 : H12AffineFastState.Bounded env31081 := by
  intro p hp
  have h : env31081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31080_31081 : H12AffineEnvironment.transform 8 1 env31080 = env31081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env31080 == env31081) = true)

theorem identity31081 : scanCanonicalize (H12AffineFastState.compose env31081 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound31081 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31082 : List Nat := [2,4,8,16,16,17,8,14,1,4,1,26,24,27,27,18,27,27,30,26,27,11,17,24,3,10,0,27,1,1,20,17,15,10,27,27]

theorem envBound31082 : H12AffineFastState.Bounded env31082 := by
  intro p hp
  have h : env31082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31081_31082 : H12AffineEnvironment.transform 4 16 env31081 = env31082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env31081 == env31082) = true)

theorem identity31082 : scanCanonicalize (H12AffineFastState.compose env31082 (packedSelected [0,1,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound31082 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env31083 : List Nat := [2,3,8,16,16,17,8,9,1,3,1,26,24,27,27,18,27,27,25,26,27,11,17,24,3,10,0,27,1,1,19,17,8,10,27,27]

theorem envBound31083 : H12AffineFastState.Bounded env31083 := by
  intro p hp
  have h : env31083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31082_31083 : H12AffineEnvironment.transform 1 3 env31082 = env31083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env31082 == env31083) = true)

def env31084 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95614,32769,4097,61648,147520,284033,86519,209262,225344,148800,74815,96346,381312,513221,257,131136,1344,95102]

theorem envBound31084 : H12AffineFastState.Bounded env31084 := by
  intro p hp
  have h : env31084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30904_31084 : H12AffineEnvironment.transform 23 284033 env30904 = env31084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284033 env30904 == env31084) = true)

def env31085 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16464,262144,95614,32769,4097,61648,16,284033,86519,94526,77840,1296,74815,96346,381312,365717,257,16400,1344,95102]

theorem envBound31085 : H12AffineFastState.Bounded env31085 := by
  intro p hp
  have h : env31085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31084_31085 : H12AffineEnvironment.transform 16 16464 env31084 = env31085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16464 env31084 == env31085) = true)

def env31086 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1344,262144,77934,32769,4097,46528,16,266385,70887,78894,77840,1296,74815,81226,365712,365717,257,1280,1344,79470]

theorem envBound31086 : H12AffineFastState.Bounded env31086 := by
  intro p hp
  have h : env31086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31085_31086 : H12AffineEnvironment.transform 13 1296 env31085 = env31086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env31085 == env31086) = true)

theorem identity31086 : scanCanonicalize (H12AffineFastState.compose env31086 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound31086 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env31087 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1344,262144,77934,13340,4097,477,16,266385,70887,78894,77840,1296,74815,81226,336013,336008,257,1280,1344,79470]

theorem envBound31087 : H12AffineFastState.Bounded env31087 := by
  intro p hp
  have h : env31087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31086_31087 : H12AffineEnvironment.transform 14 13341 env31086 = env31087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env31086 == env31087) = true)

def env31088 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1344,65664,77934,13340,4097,477,16,69649,70887,78894,77840,1296,74815,81226,8205,8200,257,1280,1344,79470]

theorem envBound31088 : H12AffineFastState.Bounded env31088 := by
  intro p hp
  have h : env31088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31087_31088 : H12AffineEnvironment.transform 17 65664 env31087 = env31088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env31087 == env31088) = true)

theorem identity31088 : scanCanonicalize (H12AffineFastState.compose env31088 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9279) := by decide +kernel

theorem selectedBound31088 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env31089 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,9279,1344,9407,5201,13340,4097,477,16,13358,12504,4113,5167,1296,0,6517,8205,8200,257,1280,1344,4689]

theorem envBound31089 : H12AffineFastState.Bounded env31089 := by
  intro p hp
  have h : env31089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31088_31089 : H12AffineEnvironment.transform 15 9279 env31088 = env31089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9279 env31088 == env31089) = true)

def env31090 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1296,9245,9279,1344,9407,1105,9244,1,477,16,9262,8408,17,1071,1296,0,2421,8205,8200,257,1280,1344,593]

theorem envBound31090 : H12AffineFastState.Bounded env31090 := by
  intro p hp
  have h : env31090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31089_31090 : H12AffineEnvironment.transform 11 0 env31089 = env31090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env31089 == env31090) = true)

theorem identity31090 : scanCanonicalize (H12AffineFastState.compose env31090 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound31090 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env31091 : List Nat := [2,4,8,16,32,64,128,21,512,1024,2048,0,8192,1029,9245,9279,1109,9407,1105,9244,1,200,16,9262,8408,17,1071,1029,0,2144,8205,8200,20,1045,1109,593]

theorem envBound31091 : H12AffineFastState.Bounded env31091 := by
  intro p hp
  have h : env31091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31090_31091 : H12AffineEnvironment.transform 7 21 env31090 = env31091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env31090 == env31091) = true)

theorem identity31091 : scanCanonicalize (H12AffineFastState.compose env31091 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound31091 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env31092 : List Nat := [2,4,8,16,32,64,128,21,512,85,2048,0,8192,80,8264,8298,0,8426,4,8265,1,200,16,8315,8408,17,122,80,0,2144,8205,8200,20,64,0,593]

theorem envBound31092 : H12AffineFastState.Bounded env31092 := by
  intro p hp
  have h : env31092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31091_31092 : H12AffineEnvironment.transform 9 85 env31091 = env31092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env31091 == env31092) = true)

theorem identity31092 : scanCanonicalize (H12AffineFastState.compose env31092 (packedSelected [5,8,17] rootPS)) = affineNative (2^(12+1) ^^^ 2051) := by decide +kernel

theorem selectedBound31092 : packedSelected [5,8,17] rootPS < 2^1333 := by decide +kernel

def env31093 : List Nat := [2,4,8,16,32,64,128,21,512,85,2048,0,2051,80,2123,2153,0,2281,4,2122,1,200,16,2168,2267,17,122,80,0,2144,2062,2059,20,64,0,593]

theorem envBound31093 : H12AffineFastState.Bounded env31093 := by
  intro p hp
  have h : env31093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31092_31093 : H12AffineEnvironment.transform 12 2051 env31092 = env31093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2051 env31092 == env31093) = true)

theorem identity31093 : scanCanonicalize (H12AffineFastState.compose env31093 (packedSelected [1,2,3,11,13,18] rootPS)) = affineNative (2^(8+1) ^^^ 80) := by decide +kernel

theorem selectedBound31093 : packedSelected [1,2,3,11,13,18] rootPS < 2^1333 := by decide +kernel

def env31094 : List Nat := [2,4,8,16,32,64,128,21,80,85,2048,0,2051,80,2123,2153,0,2281,4,2122,1,200,16,2168,2267,17,122,80,0,2144,2062,2059,20,64,0,1]

theorem envBound31094 : H12AffineFastState.Bounded env31094 := by
  intro p hp
  have h : env31094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31093_31094 : H12AffineEnvironment.transform 8 80 env31093 = env31094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 80 env31093 == env31094) = true)

theorem identity31094 : scanCanonicalize (H12AffineFastState.compose env31094 (packedSelected [0,1,2,7,8,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound31094 : packedSelected [0,1,2,7,8,11,13] rootPS < 2^1333 := by decide +kernel

def env31095 : List Nat := [2,4,8,16,32,64,128,21,80,85,137,0,138,80,194,224,0,96,4,195,1,200,16,241,82,17,122,80,0,233,135,130,20,64,0,1]

theorem envBound31095 : H12AffineFastState.Bounded env31095 := by
  intro p hp
  have h : env31095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31094_31095 : H12AffineEnvironment.transform 10 137 env31094 = env31095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env31094 == env31095) = true)

theorem identity31095 : scanCanonicalize (H12AffineFastState.compose env31095 (packedSelected [0,2,3,8,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound31095 : packedSelected [0,2,3,8,9,10] rootPS < 2^1333 := by decide +kernel

def env31096 : List Nat := [2,4,8,16,32,59,128,21,43,46,137,0,138,43,185,155,0,27,4,184,1,179,16,138,41,17,1,43,0,146,135,130,20,59,0,1]

theorem envBound31096 : H12AffineFastState.Bounded env31096 := by
  intro p hp
  have h : env31096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31095_31096 : H12AffineEnvironment.transform 5 59 env31095 = env31096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env31095 == env31096) = true)

theorem identity31096 : scanCanonicalize (H12AffineFastState.compose env31096 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound31096 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env31097 : List Nat := [2,4,8,16,17,10,128,21,26,31,137,0,138,26,136,155,0,27,4,137,1,130,16,138,24,17,1,26,0,146,135,130,20,10,0,1]

theorem envBound31097 : H12AffineFastState.Bounded env31097 := by
  intro p hp
  have h : env31097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31096_31097 : H12AffineEnvironment.transform 4 17 env31096 = env31097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env31096 == env31097) = true)

theorem identity31097 : scanCanonicalize (H12AffineFastState.compose env31097 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound31097 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31098 : List Nat := [2,4,8,16,17,10,9,21,26,31,0,0,3,26,1,18,0,27,4,0,1,11,16,3,24,17,1,26,0,27,14,11,20,10,0,1]

theorem envBound31098 : H12AffineFastState.Bounded env31098 := by
  intro p hp
  have h : env31098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31097_31098 : H12AffineEnvironment.transform 6 9 env31097 = env31098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31097 == env31098) = true)

theorem identity31098 : scanCanonicalize (H12AffineFastState.compose env31098 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound31098 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31099 : List Nat := [2,4,8,13,12,10,9,8,7,2,0,0,3,7,1,15,0,6,4,0,1,11,13,3,5,12,1,7,0,6,14,11,9,10,0,1]

theorem envBound31099 : H12AffineFastState.Bounded env31099 := by
  intro p hp
  have h : env31099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31098_31099 : H12AffineEnvironment.transform 3 13 env31098 = env31099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env31098 == env31099) = true)

theorem identity31099 : scanCanonicalize (H12AffineFastState.compose env31099 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound31099 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31100 : List Nat := [2,2,8,11,10,10,9,8,1,2,0,0,3,1,1,9,0,0,2,0,1,11,11,3,3,10,1,1,0,0,8,11,9,10,0,1]

theorem envBound31100 : H12AffineFastState.Bounded env31100 := by
  intro p hp
  have h : env31100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31099_31100 : H12AffineEnvironment.transform 1 2 env31099 = env31100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env31099 == env31100) = true)

def env31101 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1296,9244,9279,1344,9407,1104,9245,0,477,16,9263,8409,16,1070,1296,0,2420,8205,8200,257,1280,1344,592]

theorem envBound31101 : H12AffineFastState.Bounded env31101 := by
  intro p hp
  have h : env31101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31089_31101 : H12AffineEnvironment.transform 11 1 env31089 = env31101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env31089 == env31101) = true)

theorem identity31101 : scanCanonicalize (H12AffineFastState.compose env31101 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound31101 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env31102 : List Nat := [2,4,8,16,32,64,128,68,512,1024,2048,1,8192,1108,9244,9279,1028,9407,1104,9245,0,153,16,9263,8409,16,1070,1108,0,2096,8205,8200,69,1092,1028,592]

theorem envBound31102 : H12AffineFastState.Bounded env31102 := by
  intro p hp
  have h : env31102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31101_31102 : H12AffineEnvironment.transform 7 68 env31101 = env31102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env31101 == env31102) = true)

theorem identity31102 : scanCanonicalize (H12AffineFastState.compose env31102 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound31102 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env31103 : List Nat := [2,4,8,16,32,64,128,68,512,4,2048,1,8192,80,8216,8251,0,8379,84,8217,0,153,16,8235,8409,16,42,80,0,2096,8205,8200,69,64,0,592]

theorem envBound31103 : H12AffineFastState.Bounded env31103 := by
  intro p hp
  have h : env31103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31102_31103 : H12AffineEnvironment.transform 9 4 env31102 = env31103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env31102 == env31103) = true)

theorem identity31103 : scanCanonicalize (H12AffineFastState.compose env31103 (packedSelected [5,8,17] rootPS)) = affineNative (2^(8+1) ^^^ 74) := by decide +kernel

theorem selectedBound31103 : packedSelected [5,8,17] rootPS < 2^1333 := by decide +kernel

def env31104 : List Nat := [2,4,8,16,32,64,128,68,74,4,2048,1,8192,80,8216,8251,0,8379,84,8217,0,153,16,8235,8409,16,42,80,0,2096,8205,8200,69,64,0,26]

theorem envBound31104 : H12AffineFastState.Bounded env31104 := by
  intro p hp
  have h : env31104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31103_31104 : H12AffineEnvironment.transform 8 74 env31103 = env31104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 74 env31103 == env31104) = true)

theorem identity31104 : scanCanonicalize (H12AffineFastState.compose env31104 (packedSelected [3,8,11,18] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound31104 : packedSelected [3,8,11,18] rootPS < 2^1333 := by decide +kernel

def env31105 : List Nat := [2,4,8,16,32,59,128,63,49,4,2048,1,8192,43,8216,8251,0,8379,47,8217,0,153,16,8235,8354,16,42,43,0,2096,8205,8200,62,59,0,26]

theorem envBound31105 : H12AffineFastState.Bounded env31105 := by
  intro p hp
  have h : env31105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31104_31105 : H12AffineEnvironment.transform 5 59 env31104 = env31105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env31104 == env31105) = true)

theorem identity31105 : scanCanonicalize (H12AffineFastState.compose env31105 (packedSelected [0,1,2,3,5,7,8,10,11,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 2192) := by decide +kernel

theorem selectedBound31105 : packedSelected [0,1,2,3,5,7,8,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env31106 : List Nat := [2,4,8,16,32,59,128,63,49,4,2048,1,2192,43,2184,2219,0,2091,47,2185,0,153,16,2235,2098,16,42,43,0,2096,2205,2200,62,59,0,26]

theorem envBound31106 : H12AffineFastState.Bounded env31106 := by
  intro p hp
  have h : env31106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31105_31106 : H12AffineEnvironment.transform 12 2192 env31105 = env31106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2192 env31105 == env31106) = true)

theorem identity31106 : scanCanonicalize (H12AffineFastState.compose env31106 (packedSelected [0,4,5,8,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound31106 : packedSelected [0,4,5,8,10] rootPS < 2^1333 := by decide +kernel

def env31107 : List Nat := [2,4,8,16,32,59,8,63,49,4,2048,1,2072,43,2048,2083,0,2091,47,2049,0,17,16,2099,2098,16,42,43,0,2096,2069,2064,62,59,0,26]

theorem envBound31107 : H12AffineFastState.Bounded env31107 := by
  intro p hp
  have h : env31107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31106_31107 : H12AffineEnvironment.transform 6 8 env31106 = env31107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31106 == env31107) = true)

theorem identity31107 : scanCanonicalize (H12AffineFastState.compose env31107 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound31107 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31108 : List Nat := [2,4,8,16,32,59,8,63,49,4,49,1,41,43,49,18,0,26,47,48,0,17,16,2,3,16,42,43,0,1,36,33,62,59,0,26]

theorem envBound31108 : H12AffineFastState.Bounded env31108 := by
  intro p hp
  have h : env31108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31107_31108 : H12AffineEnvironment.transform 10 49 env31107 = env31108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env31107 == env31108) = true)

theorem identity31108 : scanCanonicalize (H12AffineFastState.compose env31108 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound31108 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env31109 : List Nat := [2,4,8,16,11,16,8,20,26,4,26,1,2,0,26,18,0,26,4,27,0,17,16,2,3,16,1,0,0,1,15,10,21,16,0,26]

theorem envBound31109 : H12AffineFastState.Bounded env31109 := by
  intro p hp
  have h : env31109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31108_31109 : H12AffineEnvironment.transform 4 11 env31108 = env31109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env31108 == env31109) = true)

theorem identity31109 : scanCanonicalize (H12AffineFastState.compose env31109 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound31109 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env31110 : List Nat := [2,4,8,11,11,11,8,15,1,4,1,1,2,0,1,9,0,1,4,0,0,10,11,2,3,11,1,0,0,1,15,10,14,11,0,1]

theorem envBound31110 : H12AffineFastState.Bounded env31110 := by
  intro p hp
  have h : env31110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31109_31110 : H12AffineEnvironment.transform 3 11 env31109 = env31110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env31109 == env31110) = true)

theorem identity31110 : scanCanonicalize (H12AffineFastState.compose env31110 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound31110 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31111 : List Nat := [2,2,8,11,11,11,8,9,1,2,1,1,2,0,1,9,0,1,2,0,0,10,11,2,3,11,1,0,0,1,9,10,8,11,0,1]

theorem envBound31111 : H12AffineFastState.Bounded env31111 := by
  intro p hp
  have h : env31111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31110_31111 : H12AffineEnvironment.transform 1 2 env31110 = env31111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env31110 == env31111) = true)

def env31112 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1344,65665,77934,13340,4097,477,16,69648,70887,78894,77840,1296,74815,81226,8204,8201,257,1280,1344,79470]

theorem envBound31112 : H12AffineFastState.Bounded env31112 := by
  intro p hp
  have h : env31112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31087_31112 : H12AffineEnvironment.transform 17 65665 env31087 = env31112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env31087 == env31112) = true)

theorem identity31112 : scanCanonicalize (H12AffineFastState.compose env31112 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12671) := by decide +kernel

theorem selectedBound31112 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env31113 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,12671,1344,12798,273,13340,4097,477,16,8559,9624,1361,367,1296,5440,3125,8204,8201,257,1280,1344,1809]

theorem envBound31113 : H12AffineFastState.Bounded env31113 := by
  intro p hp
  have h : env31113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31112_31113 : H12AffineEnvironment.transform 15 12671 env31112 = env31113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12671 env31112 == env31113) = true)

def env31114 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,80,12637,12671,0,12798,273,12636,4097,477,16,8559,8408,17,367,80,4096,2421,8204,8201,257,64,0,593]

theorem envBound31114 : H12AffineFastState.Bounded env31114 := by
  intro p hp
  have h : env31114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31113_31114 : H12AffineEnvironment.transform 9 320 env31113 = env31114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env31113 == env31114) = true)

theorem identity31114 : scanCanonicalize (H12AffineFastState.compose env31114 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound31114 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env31115 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,277,8192,80,8264,8298,0,8427,273,8265,276,477,16,8559,8408,17,367,80,277,2421,8204,8201,257,64,0,593]

theorem envBound31115 : H12AffineFastState.Bounded env31115 := by
  intro p hp
  have h : env31115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31114_31115 : H12AffineEnvironment.transform 11 277 env31114 = env31115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env31114 == env31115) = true)

theorem identity31115 : scanCanonicalize (H12AffineFastState.compose env31115 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound31115 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env31116 : List Nat := [2,4,8,16,32,64,128,68,512,4,2048,81,8192,80,8264,8298,0,8427,85,8265,80,153,16,8235,8408,17,43,80,81,2097,8204,8201,69,64,0,593]

theorem envBound31116 : H12AffineFastState.Bounded env31116 := by
  intro p hp
  have h : env31116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31115_31116 : H12AffineEnvironment.transform 7 68 env31115 = env31116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env31115 == env31116) = true)

theorem identity31116 : scanCanonicalize (H12AffineFastState.compose env31116 (packedSelected [0,1,2,5,7,13,17,18] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound31116 : packedSelected [0,1,2,5,7,13,17,18] rootPS < 2^1333 := by decide +kernel

def env31117 : List Nat := [2,4,8,16,32,64,88,68,512,4,2048,81,8192,80,8264,8298,0,8243,85,8265,80,65,16,8235,8192,17,43,80,81,2097,8204,8201,69,64,0,593]

theorem envBound31117 : H12AffineFastState.Bounded env31117 := by
  intro p hp
  have h : env31117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31116_31117 : H12AffineEnvironment.transform 6 88 env31116 = env31117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env31116 == env31117) = true)

theorem identity31117 : scanCanonicalize (H12AffineFastState.compose env31117 (packedSelected [1,2,5,13,17] rootPS)) = affineNative (2^(10+1) ^^^ 74) := by decide +kernel

theorem selectedBound31117 : packedSelected [1,2,5,13,17] rootPS < 2^1333 := by decide +kernel

def env31118 : List Nat := [2,4,8,16,32,64,88,68,512,4,74,81,8192,80,8264,8298,0,8243,85,8265,80,65,16,8235,8192,17,43,80,81,123,8204,8201,69,64,0,593]

theorem envBound31118 : H12AffineFastState.Bounded env31118 := by
  intro p hp
  have h : env31118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31117_31118 : H12AffineEnvironment.transform 10 74 env31117 = env31118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 74 env31117 == env31118) = true)

theorem identity31118 : scanCanonicalize (H12AffineFastState.compose env31118 (packedSelected [0,1,2,3,4,7,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound31118 : packedSelected [0,1,2,3,4,7,9,10] rootPS < 2^1333 := by decide +kernel

def env31119 : List Nat := [2,4,8,16,32,64,88,68,512,4,74,81,120,80,48,18,0,75,85,49,80,65,16,83,120,17,43,80,81,123,116,113,69,64,0,593]

theorem envBound31119 : H12AffineFastState.Bounded env31119 := by
  intro p hp
  have h : env31119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31118_31119 : H12AffineEnvironment.transform 12 120 env31118 = env31119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env31118 == env31119) = true)

def env31120 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,81,12636,12671,1,12798,273,12637,4097,477,16,8559,8409,16,367,81,4097,2420,8204,8201,257,65,1,592]

theorem envBound31120 : H12AffineFastState.Bounded env31120 := by
  intro p hp
  have h : env31120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31113_31120 : H12AffineEnvironment.transform 9 321 env31113 = env31120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env31113 == env31120) = true)

theorem identity31120 : scanCanonicalize (H12AffineFastState.compose env31120 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 325) := by decide +kernel

theorem selectedBound31120 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env31121 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,325,8192,81,8217,8250,1,8379,273,8216,324,477,16,8559,8409,16,367,81,324,2420,8204,8201,257,65,1,592]

theorem envBound31121 : H12AffineFastState.Bounded env31121 := by
  intro p hp
  have h : env31121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31120_31121 : H12AffineEnvironment.transform 11 325 env31120 = env31121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 325 env31120 == env31121) = true)

theorem identity31121 : scanCanonicalize (H12AffineFastState.compose env31121 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound31121 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env31122 : List Nat := [2,4,8,16,32,64,128,21,512,84,2048,80,8192,81,8217,8250,1,8379,4,8216,81,200,16,8314,8409,16,122,81,81,2145,8204,8201,20,65,1,592]

theorem envBound31122 : H12AffineFastState.Bounded env31122 := by
  intro p hp
  have h : env31122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31121_31122 : H12AffineEnvironment.transform 7 21 env31121 = env31122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env31121 == env31122) = true)

theorem identity31122 : scanCanonicalize (H12AffineFastState.compose env31122 (packedSelected [0,1,2,5,7,10,11,19] rootPS)) = affineNative (2^(10+1) ^^^ 592) := by decide +kernel

theorem selectedBound31122 : packedSelected [0,1,2,5,7,10,11,19] rootPS < 2^1333 := by decide +kernel

def env31123 : List Nat := [2,4,8,16,32,64,128,21,512,84,592,80,8192,81,8217,8250,1,8379,4,8216,81,200,16,8314,8409,16,122,81,81,561,8204,8201,20,65,1,592]

theorem envBound31123 : H12AffineFastState.Bounded env31123 := by
  intro p hp
  have h : env31123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31122_31123 : H12AffineEnvironment.transform 10 592 env31122 = env31123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 592 env31122 == env31123) = true)

theorem identity31123 : scanCanonicalize (H12AffineFastState.compose env31123 (packedSelected [0,2,5,7,8,11,17] rootPS)) = affineNative (2^(12+1) ^^^ 241) := by decide +kernel

theorem selectedBound31123 : packedSelected [0,2,5,7,8,11,17] rootPS < 2^1333 := by decide +kernel

def env31124 : List Nat := [2,4,8,16,32,64,128,21,512,84,592,80,241,81,232,203,1,74,4,233,81,200,16,139,40,16,122,81,81,561,253,248,20,65,1,592]

theorem envBound31124 : H12AffineFastState.Bounded env31124 := by
  intro p hp
  have h : env31124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31123_31124 : H12AffineEnvironment.transform 12 241 env31123 = env31124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 241 env31123 == env31124) = true)

theorem identity31124 : scanCanonicalize (H12AffineFastState.compose env31124 (packedSelected [1,3,4,9,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound31124 : packedSelected [1,3,4,9,10,11] rootPS < 2^1333 := by decide +kernel

def env31125 : List Nat := [2,4,8,16,32,59,128,21,512,47,555,43,138,42,147,176,1,49,4,146,42,179,16,139,40,16,1,42,42,561,134,131,20,58,1,555]

theorem envBound31125 : H12AffineFastState.Bounded env31125 := by
  intro p hp
  have h : env31125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31124_31125 : H12AffineEnvironment.transform 5 59 env31124 = env31125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env31124 == env31125) = true)

theorem identity31125 : scanCanonicalize (H12AffineFastState.compose env31125 (packedSelected [1,2,5,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 162) := by decide +kernel

theorem selectedBound31125 : packedSelected [1,2,5,7,9] rootPS < 2^1333 := by decide +kernel

def env31126 : List Nat := [2,4,8,16,32,59,128,21,162,47,137,43,138,42,147,176,1,49,4,146,42,179,16,139,40,16,1,42,42,147,134,131,20,58,1,137]

theorem envBound31126 : H12AffineFastState.Bounded env31126 := by
  intro p hp
  have h : env31126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31125_31126 : H12AffineEnvironment.transform 8 162 env31125 = env31126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 162 env31125 == env31126) = true)

def env31127 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1345,262144,77935,32769,4097,46529,16,266384,70886,78895,77840,1296,74815,81227,365713,365717,257,1281,1344,79471]

theorem envBound31127 : H12AffineFastState.Bounded env31127 := by
  intro p hp
  have h : env31127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31085_31127 : H12AffineEnvironment.transform 13 1297 env31085 = env31127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env31085 == env31127) = true)

theorem identity31127 : scanCanonicalize (H12AffineFastState.compose env31127 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32883) := by decide +kernel

theorem selectedBound31127 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env31128 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,32883,1345,262144,45084,32769,4097,46529,16,266384,38037,46172,45155,1296,42060,48440,267490,267494,257,1281,1344,46620]

theorem envBound31128 : H12AffineFastState.Bounded env31128 := by
  intro p hp
  have h : env31128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31127_31128 : H12AffineEnvironment.transform 15 32883 env31127 = env31128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32883 env31127 == env31128) = true)

def env31129 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32883,1345,262144,42332,32769,1345,41089,16,263632,33237,41244,42275,1296,42060,43128,262562,262566,257,1281,1344,41820]

theorem envBound31129 : H12AffineFastState.Bounded env31129 := by
  intro p hp
  have h : env31129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31128_31129 : H12AffineEnvironment.transform 11 1344 env31128 = env31129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env31128 == env31129) = true)

theorem identity31129 : scanCanonicalize (H12AffineFastState.compose env31129 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 41195) := by decide +kernel

theorem selectedBound31129 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env31130 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32883,1345,41195,42332,32769,1345,41089,16,42299,33237,41244,42275,1296,42060,43128,41289,41293,257,1281,1344,41820]

theorem envBound31130 : H12AffineFastState.Bounded env31130 := by
  intro p hp
  have h : env31130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31129_31130 : H12AffineEnvironment.transform 17 41195 env31129 = env31130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 41195 env31129 == env31130) = true)

theorem identity31130 : scanCanonicalize (H12AffineFastState.compose env31130 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound31130 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env31131 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,8540,8495,1345,439,1024,8541,1345,477,16,1127,8329,64,1151,1296,1296,2340,21,17,257,1281,1344,512]

theorem envBound31131 : H12AffineFastState.Bounded env31131 := by
  intro p hp
  have h : env31131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31130_31131 : H12AffineEnvironment.transform 14 8540 env31130 = env31131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env31130 == env31131) = true)

theorem identity31131 : scanCanonicalize (H12AffineFastState.compose env31131 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound31131 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env31132 : List Nat := [2,4,8,16,32,64,128,256,512,84,2048,276,8192,325,8540,8495,277,439,84,8541,277,477,16,51,8329,64,43,324,324,2340,21,17,257,341,276,512]

theorem envBound31132 : H12AffineFastState.Bounded env31132 := by
  intro p hp
  have h : env31132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31131_31132 : H12AffineEnvironment.transform 9 84 env31131 = env31132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env31131 == env31132) = true)

theorem identity31132 : scanCanonicalize (H12AffineFastState.compose env31132 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 981) := by decide +kernel

theorem selectedBound31132 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env31133 : List Nat := [2,4,8,16,32,64,128,256,512,84,2048,276,981,325,649,762,277,439,84,648,277,477,16,51,860,64,43,324,324,2340,21,17,257,341,276,512]

theorem envBound31133 : H12AffineFastState.Bounded env31133 := by
  intro p hp
  have h : env31133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31132_31133 : H12AffineEnvironment.transform 12 981 env31132 = env31133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 981 env31132 == env31133) = true)

theorem identity31133 : scanCanonicalize (H12AffineFastState.compose env31133 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound31133 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env31134 : List Nat := [2,4,8,16,32,17,128,256,512,5,2048,276,900,276,649,683,277,439,5,648,277,396,16,51,781,17,43,277,277,2340,21,17,257,260,276,512]

theorem envBound31134 : H12AffineFastState.Bounded env31134 := by
  intro p hp
  have h : env31134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31133_31134 : H12AffineEnvironment.transform 5 17 env31133 = env31134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31133 == env31134) = true)

theorem identity31134 : scanCanonicalize (H12AffineFastState.compose env31134 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound31134 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env31135 : List Nat := [2,4,8,16,32,17,128,21,512,5,2048,1,657,1,649,683,0,162,5,648,0,153,16,51,536,17,43,0,0,2097,21,17,20,17,1,512]

theorem envBound31135 : H12AffineFastState.Bounded env31135 := by
  intro p hp
  have h : env31135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31134_31135 : H12AffineEnvironment.transform 7 21 env31134 = env31135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env31134 == env31135) = true)

theorem identity31135 : scanCanonicalize (H12AffineFastState.compose env31135 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 661) := by decide +kernel

theorem selectedBound31135 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31136 : List Nat := [2,4,8,16,32,17,128,21,512,5,661,1,657,1,649,683,0,162,5,648,0,153,16,51,536,17,43,0,0,676,21,17,20,17,1,512]

theorem envBound31136 : H12AffineFastState.Bounded env31136 := by
  intro p hp
  have h : env31136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31135_31136 : H12AffineEnvironment.transform 10 661 env31135 = env31136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 661 env31135 == env31136) = true)

theorem identity31136 : scanCanonicalize (H12AffineFastState.compose env31136 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound31136 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env31137 : List Nat := [2,4,8,16,32,17,57,21,512,5,556,1,552,1,560,530,0,27,5,561,0,32,16,51,536,17,43,0,0,541,21,17,20,17,1,512]

theorem envBound31137 : H12AffineFastState.Bounded env31137 := by
  intro p hp
  have h : env31137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31136_31137 : H12AffineEnvironment.transform 6 57 env31136 = env31137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env31136 == env31137) = true)

theorem identity31137 : scanCanonicalize (H12AffineFastState.compose env31137 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 29) := by decide +kernel

theorem selectedBound31137 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31138 : List Nat := [2,4,8,16,32,17,57,21,29,5,49,1,53,1,45,15,0,27,5,44,0,32,16,51,5,17,43,0,0,0,21,17,20,17,1,29]

theorem envBound31138 : H12AffineFastState.Bounded env31138 := by
  intro p hp
  have h : env31138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31137_31138 : H12AffineEnvironment.transform 8 29 env31137 = env31138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 29 env31137 == env31138) = true)

def env31139 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32883,1345,262144,42333,32769,1344,41088,16,263633,33236,41245,42274,1296,42060,43129,262563,262567,257,1281,1344,41821]

theorem envBound31139 : H12AffineFastState.Bounded env31139 := by
  intro p hp
  have h : env31139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31128_31139 : H12AffineEnvironment.transform 11 1345 env31128 = env31139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env31128 == env31139) = true)

theorem identity31139 : scanCanonicalize (H12AffineFastState.compose env31139 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound31139 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env31140 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,24,1297,32768,32883,1345,262144,34117,32769,1344,32920,16,263633,33236,33029,34106,1296,33876,34913,262563,262567,257,1281,1344,33605]

theorem envBound31140 : H12AffineFastState.Bounded env31140 := by
  intro p hp
  have h : env31140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31139_31140 : H12AffineEnvironment.transform 12 24 env31139 = env31140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env31139 == env31140) = true)

theorem identity31140 : scanCanonicalize (H12AffineFastState.compose env31140 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(10+1) ^^^ 1883) := by decide +kernel

theorem selectedBound31140 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env31141 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1883,1345,24,1297,32768,32883,1345,262144,34117,32769,1344,32920,16,263633,33236,33029,34106,1296,33876,34618,262563,262567,257,1281,1344,33605]

theorem envBound31141 : H12AffineFastState.Bounded env31141 := by
  intro p hp
  have h : env31141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31140_31141 : H12AffineEnvironment.transform 10 1883 env31140 = env31141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1883 env31140 == env31141) = true)

def env31142 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16465,262144,95614,32769,4097,61648,17,284033,86519,94527,77841,1297,74815,96346,381312,365716,257,16401,1344,95102]

theorem envBound31142 : H12AffineFastState.Bounded env31142 := by
  intro p hp
  have h : env31142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31084_31142 : H12AffineEnvironment.transform 16 16465 env31084 = env31142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16465 env31084 == env31142) = true)

def env31143 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1345,262144,77934,32769,4097,46528,17,266385,70887,78895,77841,1297,74815,81226,365712,365716,257,1281,1344,79470]

theorem envBound31143 : H12AffineFastState.Bounded env31143 := by
  intro p hp
  have h : env31143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31142_31143 : H12AffineEnvironment.transform 13 1296 env31142 = env31143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env31142 == env31143) = true)

theorem identity31143 : scanCanonicalize (H12AffineFastState.compose env31143 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32882) := by decide +kernel

theorem selectedBound31143 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env31144 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,32882,1345,262144,45084,32769,4097,46528,17,266385,38037,46173,45155,1297,42061,48440,267490,267494,257,1281,1344,46620]

theorem envBound31144 : H12AffineFastState.Bounded env31144 := by
  intro p hp
  have h : env31144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31143_31144 : H12AffineEnvironment.transform 15 32882 env31143 = env31144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32882 env31143 == env31144) = true)

def env31145 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32882,1345,262144,42332,32769,1345,41088,17,263633,33237,41245,42275,1297,42061,43128,262562,262566,257,1281,1344,41820]

theorem envBound31145 : H12AffineFastState.Bounded env31145 := by
  intro p hp
  have h : env31145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31144_31145 : H12AffineEnvironment.transform 11 1344 env31144 = env31145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env31144 == env31145) = true)

theorem identity31145 : scanCanonicalize (H12AffineFastState.compose env31145 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 9407) := by decide +kernel

theorem selectedBound31145 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env31146 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32882,1345,9407,42332,32769,1345,41088,17,8558,33237,41245,42275,1297,42061,43128,9501,9497,257,1281,1344,41820]

theorem envBound31146 : H12AffineFastState.Bounded env31146 := by
  intro p hp
  have h : env31146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31145_31146 : H12AffineEnvironment.transform 17 9407 env31145 = env31146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 9407 env31145 == env31146) = true)

theorem identity31146 : scanCanonicalize (H12AffineFastState.compose env31146 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(10+1) ^^^ 1883) := by decide +kernel

theorem selectedBound31146 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env31147 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1883,1344,8192,1296,32768,32882,1345,9407,42332,32769,1345,41088,17,8558,33237,41245,42275,1297,42061,42787,9501,9497,257,1281,1344,41820]

theorem envBound31147 : H12AffineFastState.Bounded env31147 := by
  intro p hp
  have h : env31147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31146_31147 : H12AffineEnvironment.transform 10 1883 env31146 = env31147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1883 env31146 == env31147) = true)

def env31148 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32882,1345,262144,42333,32769,1344,41089,17,263632,33236,41244,42274,1297,42061,43129,262563,262567,257,1281,1344,41821]

theorem envBound31148 : H12AffineFastState.Bounded env31148 := by
  intro p hp
  have h : env31148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31144_31148 : H12AffineEnvironment.transform 11 1345 env31144 = env31148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env31144 == env31148) = true)

theorem identity31148 : scanCanonicalize (H12AffineFastState.compose env31148 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 9293) := by decide +kernel

theorem selectedBound31148 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env31149 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,9293,9279,1345,262144,272,9292,1344,1228,17,263632,9625,1361,367,1297,0,3124,262563,262567,257,1281,1344,1808]

theorem envBound31149 : H12AffineFastState.Bounded env31149 := by
  intro p hp
  have h : env31149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31148_31149 : H12AffineEnvironment.transform 14 9293 env31148 = env31149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9293 env31148 == env31149) = true)

theorem identity31149 : scanCanonicalize (H12AffineFastState.compose env31149 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound31149 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env31150 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,81,8192,0,8541,8495,81,262144,272,8540,80,476,17,262336,8329,65,367,1,0,2340,262563,262567,257,17,80,512]

theorem envBound31150 : H12AffineFastState.Bounded env31150 := by
  intro p hp
  have h : env31150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31149_31150 : H12AffineEnvironment.transform 9 272 env31149 = env31150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env31149 == env31150) = true)

theorem identity31150 : scanCanonicalize (H12AffineFastState.compose env31150 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound31150 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env31151 : List Nat := [2,4,8,16,32,64,128,68,512,84,2048,81,8192,0,8217,8299,81,262144,84,8216,80,152,17,262336,8329,65,43,1,0,2144,262375,262371,69,17,80,512]

theorem envBound31151 : H12AffineFastState.Bounded env31151 := by
  intro p hp
  have h : env31151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31150_31151 : H12AffineEnvironment.transform 7 68 env31150 = env31151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env31150 == env31151) = true)

theorem identity31151 : scanCanonicalize (H12AffineFastState.compose env31151 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 657) := by decide +kernel

theorem selectedBound31151 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env31152 : List Nat := [2,4,8,16,32,64,128,68,512,84,2048,81,657,0,648,762,81,262144,84,649,80,152,17,262336,536,65,43,1,0,2144,262375,262371,69,17,80,512]

theorem envBound31152 : H12AffineFastState.Bounded env31152 := by
  intro p hp
  have h : env31152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31151_31152 : H12AffineEnvironment.transform 12 657 env31151 = env31152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 657 env31151 == env31152) = true)

theorem identity31152 : scanCanonicalize (H12AffineFastState.compose env31152 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound31152 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env31153 : List Nat := [2,4,8,16,32,17,128,21,512,5,2048,0,657,0,648,683,0,262144,5,649,1,152,17,262289,536,16,43,1,0,2097,262326,262322,20,17,1,512]

theorem envBound31153 : H12AffineFastState.Bounded env31153 := by
  intro p hp
  have h : env31153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31152_31153 : H12AffineEnvironment.transform 5 17 env31152 = env31153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31152 == env31153) = true)

def env31154 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1344,262144,77935,32769,4097,46529,17,266384,70886,78894,77841,1297,74815,81227,365713,365716,257,1280,1344,79471]

theorem envBound31154 : H12AffineFastState.Bounded env31154 := by
  intro p hp
  have h : env31154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31142_31154 : H12AffineEnvironment.transform 13 1297 env31142 = env31154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env31142 == env31154) = true)

theorem identity31154 : scanCanonicalize (H12AffineFastState.compose env31154 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound31154 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env31155 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1344,262144,77935,13340,4097,476,17,266384,70886,78894,77841,1297,74815,81227,336012,336009,257,1280,1344,79471]

theorem envBound31155 : H12AffineFastState.Bounded env31155 := by
  intro p hp
  have h : env31155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31154_31155 : H12AffineEnvironment.transform 14 13341 env31154 = env31155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env31154 == env31155) = true)

def env31156 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1344,65664,77935,13340,4097,476,17,69648,70886,78894,77841,1297,74815,81227,8204,8201,257,1280,1344,79471]

theorem envBound31156 : H12AffineFastState.Bounded env31156 := by
  intro p hp
  have h : env31156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31155_31156 : H12AffineEnvironment.transform 17 65664 env31155 = env31156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env31155 == env31156) = true)

theorem identity31156 : scanCanonicalize (H12AffineFastState.compose env31156 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5238) := by decide +kernel

theorem selectedBound31156 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env31157 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,5238,1344,5366,9241,13340,4097,476,17,1126,144,8280,9319,1297,12361,10557,8204,8201,257,1280,1344,8729]

theorem envBound31157 : H12AffineFastState.Bounded env31157 := by
  intro p hp
  have h : env31157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31156_31157 : H12AffineEnvironment.transform 15 5238 env31156 = env31157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5238 env31156 == env31157) = true)

def env31158 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,1297,13341,5158,1296,5286,9241,13340,4097,396,17,1078,144,8200,9271,1297,12313,10557,8204,8201,257,1280,1296,8729]

theorem envBound31158 : H12AffineFastState.Bounded env31158 := by
  intro p hp
  have h : env31158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31157_31158 : H12AffineEnvironment.transform 5 16 env31157 = env31158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31157 == env31158) = true)

theorem identity31158 : scanCanonicalize (H12AffineFastState.compose env31158 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 4365) := by decide +kernel

theorem selectedBound31158 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env31159 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,4365,1297,1296,5158,1296,5286,5396,1297,4097,396,17,1078,144,4357,5434,1297,276,6192,4353,4356,257,1280,1296,4884]

theorem envBound31159 : H12AffineFastState.Bounded env31159 := by
  intro p hp
  have h : env31159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31158_31159 : H12AffineEnvironment.transform 12 4365 env31158 = env31159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4365 env31158 == env31159) = true)

theorem identity31159 : scanCanonicalize (H12AffineFastState.compose env31159 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound31159 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env31160 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,1053,1297,1296,310,1296,438,4,1297,1297,396,17,1078,144,1045,42,1297,276,3360,1041,1044,257,1280,1296,1540]

theorem envBound31160 : H12AffineFastState.Bounded env31160 := by
  intro p hp
  have h : env31160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31159_31160 : H12AffineEnvironment.transform 11 1296 env31159 = env31160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env31159 == env31160) = true)

theorem identity31160 : scanCanonicalize (H12AffineFastState.compose env31160 (packedSelected [0,1,3,7,10,11,13,19] rootPS)) = affineNative (2^(10+1) ^^^ 1802) := by decide +kernel

theorem selectedBound31160 : packedSelected [0,1,3,7,10,11,13,19] rootPS < 2^1333 := by decide +kernel

def env31161 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1802,1296,1053,1297,1296,310,1296,438,4,1297,1297,396,17,1078,144,1045,42,1297,276,554,1041,1044,257,1280,1296,1540]

theorem envBound31161 : H12AffineFastState.Bounded env31161 := by
  intro p hp
  have h : env31161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31160_31161 : H12AffineEnvironment.transform 10 1802 env31160 = env31161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1802 env31160 == env31161) = true)

theorem identity31161 : scanCanonicalize (H12AffineFastState.compose env31161 (packedSelected [0,1,5,7,12,15,17,18] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound31161 : packedSelected [0,1,5,7,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env31162 : List Nat := [2,4,8,16,32,16,128,256,512,273,539,1,268,0,1,310,1,438,4,0,0,396,17,295,144,260,42,0,276,554,256,261,257,17,1,789]

theorem envBound31162 : H12AffineFastState.Bounded env31162 := by
  intro p hp
  have h : env31162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31161_31162 : H12AffineEnvironment.transform 9 273 env31161 = env31162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env31161 == env31162) = true)

theorem identity31162 : scanCanonicalize (H12AffineFastState.compose env31162 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 63) := by decide +kernel

theorem selectedBound31162 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env31163 : List Nat := [2,4,8,16,32,16,128,63,512,46,539,1,51,0,1,9,1,137,4,0,0,179,17,24,144,59,42,0,43,554,63,58,62,17,1,554]

theorem envBound31163 : H12AffineFastState.Bounded env31163 := by
  intro p hp
  have h : env31163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31162_31163 : H12AffineEnvironment.transform 7 63 env31162 = env31163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env31162 == env31163) = true)

theorem identity31163 : scanCanonicalize (H12AffineFastState.compose env31163 (packedSelected [5,8] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound31163 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env31164 : List Nat := [2,4,8,10,32,10,128,37,512,46,513,1,41,0,1,9,1,137,4,0,0,169,11,2,138,33,42,0,43,554,37,32,36,11,1,554]

theorem envBound31164 : H12AffineFastState.Bounded env31164 := by
  intro p hp
  have h : env31164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31163_31164 : H12AffineEnvironment.transform 3 10 env31163 = env31164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env31163 == env31164) = true)

theorem identity31164 : scanCanonicalize (H12AffineFastState.compose env31164 (packedSelected [1,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound31164 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env31165 : List Nat := [2,4,8,10,10,10,128,15,512,4,513,1,3,0,1,9,1,137,4,0,0,131,11,2,138,11,0,0,1,512,15,10,14,11,1,512]

theorem envBound31165 : H12AffineFastState.Bounded env31165 := by
  intro p hp
  have h : env31165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31164_31165 : H12AffineEnvironment.transform 4 10 env31164 = env31165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env31164 == env31165) = true)

theorem identity31165 : scanCanonicalize (H12AffineFastState.compose env31165 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 143) := by decide +kernel

theorem selectedBound31165 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31166 : List Nat := [2,4,8,10,10,10,128,15,143,4,142,1,3,0,1,9,1,137,4,0,0,131,11,2,138,11,0,0,1,143,15,10,14,11,1,143]

theorem envBound31166 : H12AffineFastState.Bounded env31166 := by
  intro p hp
  have h : env31166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31165_31166 : H12AffineEnvironment.transform 8 143 env31165 = env31166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 143 env31165 == env31166) = true)

theorem identity31166 : scanCanonicalize (H12AffineFastState.compose env31166 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound31166 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31167 : List Nat := [2,2,8,10,10,10,128,9,137,2,136,1,3,0,1,9,1,137,2,0,0,131,11,2,138,11,0,0,1,137,9,10,8,11,1,137]

theorem envBound31167 : H12AffineFastState.Bounded env31167 := by
  intro p hp
  have h : env31167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31166_31167 : H12AffineEnvironment.transform 1 2 env31166 = env31167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env31166 == env31167) = true)

theorem identity31167 : scanCanonicalize (H12AffineFastState.compose env31167 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound31167 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env31168 : List Nat := [2,2,8,10,10,10,9,9,0,2,1,1,3,0,1,9,1,0,2,0,0,10,11,2,3,11,0,0,1,0,9,10,8,11,1,0]

theorem envBound31168 : H12AffineFastState.Bounded env31168 := by
  intro p hp
  have h : env31168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31167_31168 : H12AffineEnvironment.transform 6 9 env31167 = env31168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31167 == env31168) = true)

def env31169 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1297,13341,5159,1297,5287,9241,13340,4097,397,17,1079,144,8201,9270,1297,12312,10557,8204,8201,257,1280,1297,8729]

theorem envBound31169 : H12AffineFastState.Bounded env31169 := by
  intro p hp
  have h : env31169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31157_31169 : H12AffineEnvironment.transform 5 17 env31157 = env31169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31157 == env31169) = true)

theorem identity31169 : scanCanonicalize (H12AffineFastState.compose env31169 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound31169 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env31170 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,276,8192,1297,9481,1331,1297,1459,9241,9480,277,397,17,1079,144,8201,9270,1297,8460,10557,8204,8201,257,1280,1297,8729]

theorem envBound31170 : H12AffineFastState.Bounded env31170 := by
  intro p hp
  have h : env31170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31169_31170 : H12AffineEnvironment.transform 11 276 env31169 = env31170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env31169 == env31170) = true)

theorem identity31170 : scanCanonicalize (H12AffineFastState.compose env31170 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound31170 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env31171 : List Nat := [2,4,8,16,32,17,128,256,512,4,2048,276,8192,277,8461,311,277,439,8221,8460,277,397,17,51,144,8201,8242,277,8460,10557,8204,8201,257,260,277,8729]

end H12CloudChart2