import H12CloudChart2Data158

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound39698 : packedSelected [0,1,3,4,6,10] rootPS < 2^1333 := by decide +kernel

def env39699 : List Nat := [2,4,8,16,32,16,128,173,512,4,43,4096,4146,185,4242,9,4754,560,662,4243,4097,4249,4667,139,4648,4265,42,4755,4755,163,4116,168,173,4739,185,147]

theorem envBound39699 : H12AffineFastState.Bounded env39699 := by
  intro p hp
  have h : env39699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39698_39699 : H12AffineEnvironment.transform 10 43 env39698 = env39699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env39698 == env39699) = true)

theorem identity39699 : scanCanonicalize (H12AffineFastState.compose env39699 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound39699 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env39700 : List Nat := [2,4,8,16,32,16,18,63,512,4,43,4096,4146,43,4096,9,4608,560,516,4097,4097,4107,4667,25,4648,4155,42,4609,4609,49,4116,58,63,4625,43,1]

theorem envBound39700 : H12AffineFastState.Bounded env39700 := by
  intro p hp
  have h : env39700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39699_39700 : H12AffineEnvironment.transform 6 18 env39699 = env39700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env39699 == env39700) = true)

theorem identity39700 : scanCanonicalize (H12AffineFastState.compose env39700 (packedSelected [5,8] rootPS)) = affineNative (2^(11+1) ^^^ 554) := by decide +kernel

theorem selectedBound39700 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env39701 : List Nat := [2,4,8,16,32,16,18,63,512,4,43,554,536,43,554,9,42,560,516,555,555,545,17,25,2,529,42,43,43,49,574,58,63,59,43,1]

theorem envBound39701 : H12AffineFastState.Bounded env39701 := by
  intro p hp
  have h : env39701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39700_39701 : H12AffineEnvironment.transform 11 554 env39700 = env39701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 554 env39700 == env39701) = true)

theorem identity39701 : scanCanonicalize (H12AffineFastState.compose env39701 (packedSelected [0,1,4] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound39701 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env39702 : List Nat := [2,4,8,16,22,16,18,9,512,4,29,540,536,29,540,9,28,518,516,541,541,535,17,25,2,529,28,29,29,7,520,12,9,13,29,1]

theorem envBound39702 : H12AffineFastState.Bounded env39702 := by
  intro p hp
  have h : env39702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39701_39702 : H12AffineEnvironment.transform 4 22 env39701 = env39702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env39701 == env39702) = true)

theorem identity39702 : scanCanonicalize (H12AffineFastState.compose env39702 (packedSelected [3,5] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound39702 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env39703 : List Nat := [2,4,8,16,22,16,18,9,0,4,29,28,24,29,28,9,28,6,4,29,29,23,17,25,2,17,28,29,29,7,8,12,9,13,29,1]

theorem envBound39703 : H12AffineFastState.Bounded env39703 := by
  intro p hp
  have h : env39703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39702_39703 : H12AffineEnvironment.transform 8 0 env39702 = env39703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env39702 == env39703) = true)

theorem identity39703 : scanCanonicalize (H12AffineFastState.compose env39703 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound39703 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39704 : List Nat := [2,0,8,16,18,16,18,9,0,0,25,24,24,25,24,9,24,2,0,25,25,19,17,25,2,17,24,25,25,3,8,8,9,9,25,1]

theorem envBound39704 : H12AffineFastState.Bounded env39704 := by
  intro p hp
  have h : env39704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39703_39704 : H12AffineEnvironment.transform 1 0 env39703 = env39704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env39703 == env39704) = true)

theorem identity39704 : scanCanonicalize (H12AffineFastState.compose env39704 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound39704 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39705 : List Nat := [2,0,3,16,18,16,18,2,0,0,18,19,19,18,19,2,19,2,0,18,18,19,17,18,2,17,19,18,18,3,3,3,2,2,18,1]

theorem envBound39705 : H12AffineFastState.Bounded env39705 := by
  intro p hp
  have h : env39705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39704_39705 : H12AffineEnvironment.transform 2 3 env39704 = env39705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env39704 == env39705) = true)

theorem identity39705 : scanCanonicalize (H12AffineFastState.compose env39705 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound39705 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39706 : List Nat := [1,0,0,16,17,16,17,1,0,0,17,16,16,17,16,1,16,1,0,17,17,16,17,17,1,17,16,17,17,0,0,0,1,1,17,1]

theorem envBound39706 : H12AffineFastState.Bounded env39706 := by
  intro p hp
  have h : env39706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39705_39706 : H12AffineEnvironment.transform 0 1 env39705 = env39706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env39705 == env39706) = true)

theorem identity39706 : scanCanonicalize (H12AffineFastState.compose env39706 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound39706 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env39707 : List Nat := [1,0,0,1,0,1,0,1,0,0,0,1,1,0,1,1,1,1,0,0,0,1,0,0,1,0,1,0,0,0,0,0,1,1,0,1]

theorem envBound39707 : H12AffineFastState.Bounded env39707 := by
  intro p hp
  have h : env39707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39706_39707 : H12AffineEnvironment.transform 3 1 env39706 = env39707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env39706 == env39707) = true)

def env39708 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61569,147473,41003,143496,20496,492566,148669,148669,96267,74795,16401,173,131088,1212,135681]

theorem envBound39708 : H12AffineFastState.Bounded env39708 := by
  intro p hp
  have h : env39708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39690_39708 : H12AffineEnvironment.transform 5 17 env39690 = env39708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39690 == env39708) = true)

theorem identity39708 : scanCanonicalize (H12AffineFastState.compose env39708 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound39708 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env39709 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,45217,262144,42145,32769,4097,61569,61616,41003,32809,20496,341175,62492,62492,96267,74795,16401,173,45233,1212,41632]

theorem envBound39709 : H12AffineFastState.Bounded env39709 := by
  intro p hp
  have h : env39709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39708_39709 : H12AffineEnvironment.transform 16 45217 env39708 = env39709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env39708 == env39709) = true)

theorem identity39709 : scanCanonicalize (H12AffineFastState.compose env39709 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound39709 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env39710 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1213,32768,65536,45217,262144,42145,32769,4097,46140,46093,41003,32809,5293,341175,45217,45217,81078,74795,1196,173,45233,1212,41632]

theorem envBound39710 : H12AffineFastState.Bounded env39710 := by
  intro p hp
  have h : env39710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39709_39710 : H12AffineEnvironment.transform 13 1213 env39709 = env39710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env39709 == env39710) = true)

theorem identity39710 : scanCanonicalize (H12AffineFastState.compose env39710 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 9350) := by decide +kernel

theorem selectedBound39710 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env39711 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1213,32768,9350,45217,262144,42145,32769,4097,46140,46093,41003,32809,5293,266289,45217,45217,6192,173,1196,173,45233,1212,41632]

theorem envBound39711 : H12AffineFastState.Bounded env39711 := by
  intro p hp
  have h : env39711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39710_39711 : H12AffineEnvironment.transform 15 9350 env39710 = env39711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9350 env39710 == env39711) = true)

theorem identity39711 : scanCanonicalize (H12AffineFastState.compose env39711 (packedSelected [4,9,20] rootPS)) = affineNative (2^(14+1) ^^^ 12313) := by decide +kernel

theorem selectedBound39711 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env39712 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1213,12313,9350,184,262144,5304,12312,4097,1061,1044,4146,12336,5293,266289,184,184,6192,173,1196,173,168,1212,4793]

theorem envBound39712 : H12AffineFastState.Bounded env39712 := by
  intro p hp
  have h : env39712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39711_39712 : H12AffineEnvironment.transform 14 12313 env39711 = env39712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12313 env39711 == env39712) = true)

theorem identity39712 : scanCanonicalize (H12AffineFastState.compose env39712 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound39712 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env39713 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,185,8192,1213,8352,9350,184,262144,1025,8353,184,1061,1044,139,8329,1044,262280,184,184,2185,173,1196,173,168,1212,512]

theorem envBound39713 : H12AffineFastState.Bounded env39713 := by
  intro p hp
  have h : env39713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39712_39713 : H12AffineEnvironment.transform 11 185 env39712 = env39713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env39712 == env39713) = true)

theorem identity39713 : scanCanonicalize (H12AffineFastState.compose env39713 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2600) := by decide +kernel

theorem selectedBound39713 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39714 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,185,2600,1213,2696,3758,184,262144,1025,2697,184,1061,1044,139,2721,1044,262280,184,184,2185,173,1196,173,168,1212,512]

theorem envBound39714 : H12AffineFastState.Bounded env39714 := by
  intro p hp
  have h : env39714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39713_39714 : H12AffineEnvironment.transform 12 2600 env39713 = env39714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2600 env39713 == env39714) = true)

theorem identity39714 : scanCanonicalize (H12AffineFastState.compose env39714 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 2706) := by decide +kernel

theorem selectedBound39714 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env39715 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,185,2600,1213,2696,3758,184,2706,1025,2697,184,1061,1044,139,2721,1044,2586,184,184,2185,173,1196,173,168,1212,512]

theorem envBound39715 : H12AffineFastState.Bounded env39715 := by
  intro p hp
  have h : env39715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39714_39715 : H12AffineEnvironment.transform 17 2706 env39714 = env39715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2706 env39714 == env39715) = true)

theorem identity39715 : scanCanonicalize (H12AffineFastState.compose env39715 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1212) := by decide +kernel

theorem selectedBound39715 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env39716 : List Nat := [2,4,8,16,32,17,128,173,512,1024,1212,185,1684,1213,1588,530,184,1582,1025,1589,184,1061,1044,139,1565,1044,1702,184,184,1077,173,1196,173,168,1212,512]

theorem envBound39716 : H12AffineFastState.Bounded env39716 := by
  intro p hp
  have h : env39716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39715_39716 : H12AffineEnvironment.transform 10 1212 env39715 = env39716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1212 env39715 == env39716) = true)

theorem identity39716 : scanCanonicalize (H12AffineFastState.compose env39716 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound39716 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env39717 : List Nat := [2,4,8,11,32,10,128,173,512,1024,1191,162,1679,1190,1583,521,163,1582,1025,1582,163,1061,1039,139,1542,1039,1702,163,163,1070,173,1196,173,168,1191,512]

theorem envBound39717 : H12AffineFastState.Bounded env39717 := by
  intro p hp
  have h : env39717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39716_39717 : H12AffineEnvironment.transform 3 11 env39716 = env39717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env39716 == env39717) = true)

theorem identity39717 : scanCanonicalize (H12AffineFastState.compose env39717 (packedSelected [0,1,4,7] rootPS)) = affineNative (2^(9+1) ^^^ 653) := by decide +kernel

theorem selectedBound39717 : packedSelected [0,1,4,7] rootPS < 2^1333 := by decide +kernel

def env39718 : List Nat := [2,4,8,11,32,10,128,173,512,653,554,162,2,555,162,521,163,163,652,163,163,680,642,139,139,642,43,163,163,675,173,545,173,168,554,512]

theorem envBound39718 : H12AffineFastState.Bounded env39718 := by
  intro p hp
  have h : env39718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39717_39718 : H12AffineEnvironment.transform 9 653 env39717 = env39718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 653 env39717 == env39718) = true)

theorem identity39718 : scanCanonicalize (H12AffineFastState.compose env39718 (packedSelected [3,4] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound39718 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env39719 : List Nat := [2,4,8,11,32,10,128,173,137,4,163,162,2,162,162,128,163,163,5,163,163,33,11,139,139,11,43,163,163,42,173,168,173,168,163,137]

theorem envBound39719 : H12AffineFastState.Bounded env39719 := by
  intro p hp
  have h : env39719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39718_39719 : H12AffineEnvironment.transform 8 137 env39718 = env39719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env39718 == env39719) = true)

theorem identity39719 : scanCanonicalize (H12AffineFastState.compose env39719 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound39719 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39720 : List Nat := [2,4,8,11,32,10,4,41,13,4,39,38,2,38,38,4,39,39,5,39,39,33,11,15,15,11,43,39,39,42,41,44,41,44,39,13]

theorem envBound39720 : H12AffineFastState.Bounded env39720 := by
  intro p hp
  have h : env39720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39719_39720 : H12AffineEnvironment.transform 6 4 env39719 = env39720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env39719 == env39720) = true)

theorem identity39720 : scanCanonicalize (H12AffineFastState.compose env39720 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound39720 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39721 : List Nat := [2,4,5,6,32,7,4,36,0,4,39,38,2,38,38,4,39,39,5,39,39,33,6,2,2,6,38,39,39,39,36,33,36,33,39,0]

theorem envBound39721 : H12AffineFastState.Bounded env39721 := by
  intro p hp
  have h : env39721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39720_39721 : H12AffineEnvironment.transform 2 5 env39720 = env39721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env39720 == env39721) = true)

def env39722 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147520,41003,143497,20497,493034,148801,148800,96346,74795,16400,256,131137,1344,135680]

theorem envBound39722 : H12AffineFastState.Bounded env39722 := by
  intro p hp
  have h : env39722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39658_39722 : H12AffineEnvironment.transform 18 136193 env39658 = env39722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env39658 == env39722) = true)

def env39723 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147520,41003,143497,20497,492614,148717,148716,96346,74795,16400,172,131137,1260,135680]

theorem envBound39723 : H12AffineFastState.Bounded env39723 := by
  intro p hp
  have h : env39723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39722_39723 : H12AffineEnvironment.transform 7 172 env39722 = env39723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env39722 == env39723) = true)

def env39724 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61568,147472,41003,143497,20497,492566,148669,148668,96266,74795,16400,172,131089,1212,135680]

theorem envBound39724 : H12AffineFastState.Bounded env39724 := by
  intro p hp
  have h : env39724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39723_39724 : H12AffineEnvironment.transform 5 16 env39723 = env39724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env39723 == env39724) = true)

theorem identity39724 : scanCanonicalize (H12AffineFastState.compose env39724 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 114723) := by decide +kernel

theorem selectedBound39724 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env39725 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,114723,262144,119842,32769,4097,61568,98355,41003,127146,20497,279605,99486,99487,96266,74795,16400,172,114738,1212,119331]

theorem envBound39725 : H12AffineFastState.Bounded env39725 := by
  intro p hp
  have h : env39725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39724_39725 : H12AffineEnvironment.transform 16 114723 env39724 = env39725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114723 env39724 == env39725) = true)

theorem identity39725 : scanCanonicalize (H12AffineFastState.compose env39725 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 47249) := by decide +kernel

theorem selectedBound39725 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env39726 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,114723,47249,119842,32769,4097,61568,98355,41003,127146,20497,64676,99486,99487,96266,74795,16400,172,114738,1212,119331]

theorem envBound39726 : H12AffineFastState.Bounded env39726 := by
  intro p hp
  have h : env39726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39725_39726 : H12AffineEnvironment.transform 17 47249 env39725 = env39726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 47249 env39725 == env39726) = true)

theorem identity39726 : scanCanonicalize (H12AffineFastState.compose env39726 (packedSelected [7,16,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound39726 : packedSelected [7,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env39727 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,53283,4096,47249,1025,32769,4097,61568,20496,41003,8329,20497,64676,21693,21692,43049,62472,16400,172,4113,1212,512]

theorem envBound39727 : H12AffineFastState.Bounded env39727 := by
  intro p hp
  have h : env39727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39726_39727 : H12AffineEnvironment.transform 15 53283 env39726 = env39727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env39726 == env39727) = true)

theorem identity39727 : scanCanonicalize (H12AffineFastState.compose env39727 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound39727 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env39728 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,5124,32768,33831,4096,47249,1025,32769,4097,42116,1044,41003,8329,1045,43168,185,184,43049,40972,5140,172,4113,1212,512]

theorem envBound39728 : H12AffineFastState.Bounded env39728 := by
  intro p hp
  have h : env39728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39727_39728 : H12AffineEnvironment.transform 13 5124 env39727 = env39728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env39727 == env39728) = true)

theorem identity39728 : scanCanonicalize (H12AffineFastState.compose env39728 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 5677) := by decide +kernel

theorem selectedBound39728 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env39729 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,5677,5124,32768,33831,4096,36540,1025,32769,4097,37545,1044,38406,5796,1045,40589,185,184,40452,38433,5140,172,4113,1212,512]

theorem envBound39729 : H12AffineFastState.Bounded env39729 := by
  intro p hp
  have h : env39729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39728_39729 : H12AffineEnvironment.transform 12 5677 env39728 = env39729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5677 env39728 == env39729) = true)

theorem identity39729 : scanCanonicalize (H12AffineFastState.compose env39729 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(14+1) ^^^ 1070) := by decide +kernel

theorem selectedBound39729 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env39730 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,5677,5124,1070,9,4096,2706,1025,1071,4097,5767,1044,4648,5796,1045,6819,185,184,6698,4623,5140,172,4113,1212,512]

theorem envBound39730 : H12AffineFastState.Bounded env39730 := by
  intro p hp
  have h : env39730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39729_39730 : H12AffineEnvironment.transform 14 1070 env39729 = env39730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1070 env39729 == env39730) = true)

theorem identity39730 : scanCanonicalize (H12AffineFastState.compose env39730 (packedSelected [1,3,13] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound39730 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env39731 : List Nat := [2,4,8,16,32,16,128,172,27,1024,2048,4096,5174,5124,1070,9,4096,2185,1025,1071,4097,5276,1044,4147,5311,1045,6328,185,184,6193,4116,5140,172,4113,1212,27]

theorem envBound39731 : H12AffineFastState.Bounded env39731 := by
  intro p hp
  have h : env39731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39730_39731 : H12AffineEnvironment.transform 8 27 env39730 = env39731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env39730 == env39731) = true)

theorem identity39731 : scanCanonicalize (H12AffineFastState.compose env39731 (packedSelected [1,2,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound39731 : packedSelected [1,2,5,6] rootPS < 2^1333 := by decide +kernel

def env39732 : List Nat := [2,4,8,16,32,16,128,172,27,1024,1,4096,5174,5124,1070,9,4096,136,1025,1071,4097,5276,1044,4147,5311,1045,4281,185,184,4144,4116,5140,172,4113,1212,27]

theorem envBound39732 : H12AffineFastState.Bounded env39732 := by
  intro p hp
  have h : env39732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39731_39732 : H12AffineEnvironment.transform 10 1 env39731 = env39732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env39731 == env39732) = true)

theorem identity39732 : scanCanonicalize (H12AffineFastState.compose env39732 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound39732 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env39733 : List Nat := [2,4,8,16,16,16,128,156,27,1024,1,4096,5126,5124,1054,9,4096,136,1025,1055,4097,5276,1044,4099,5263,1045,4233,137,136,4096,4116,5140,156,4113,1164,27]

theorem envBound39733 : H12AffineFastState.Bounded env39733 := by
  intro p hp
  have h : env39733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39732_39733 : H12AffineEnvironment.transform 4 16 env39732 = env39733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env39732 == env39733) = true)

theorem identity39733 : scanCanonicalize (H12AffineFastState.compose env39733 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 146) := by decide +kernel

theorem selectedBound39733 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env39734 : List Nat := [2,4,8,16,16,16,128,156,27,1024,1,146,1172,1174,1054,9,146,136,1025,1055,147,1038,1044,145,1053,1045,27,137,136,146,134,1158,156,131,1164,27]

theorem envBound39734 : H12AffineFastState.Bounded env39734 := by
  intro p hp
  have h : env39734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39733_39734 : H12AffineEnvironment.transform 11 146 env39733 = env39734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 146 env39733 == env39734) = true)

theorem identity39734 : scanCanonicalize (H12AffineFastState.compose env39734 (packedSelected [0,2,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound39734 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env39735 : List Nat := [2,4,8,10,10,10,128,134,1,1024,1,136,1166,1164,1028,9,136,136,1025,1029,137,1038,1038,139,1031,1039,1,137,136,136,134,1158,134,131,1164,1]

theorem envBound39735 : H12AffineFastState.Bounded env39735 := by
  intro p hp
  have h : env39735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39734_39735 : H12AffineEnvironment.transform 3 10 env39734 = env39735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env39734 == env39735) = true)

theorem identity39735 : scanCanonicalize (H12AffineFastState.compose env39735 (packedSelected [0,1] rootPS)) = affineNative (2^(9+1) ^^^ 140) := by decide +kernel

theorem selectedBound39735 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env39736 : List Nat := [2,4,8,10,10,10,128,134,1,140,1,136,2,0,136,9,136,136,141,137,137,130,130,139,139,131,1,137,136,136,134,10,134,131,0,1]

theorem envBound39736 : H12AffineFastState.Bounded env39736 := by
  intro p hp
  have h : env39736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39735_39736 : H12AffineEnvironment.transform 9 140 env39735 = env39736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 140 env39735 == env39736) = true)

theorem identity39736 : scanCanonicalize (H12AffineFastState.compose env39736 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound39736 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39737 : List Nat := [2,4,8,10,10,10,5,3,1,9,1,13,2,0,13,9,13,13,8,12,12,7,7,14,14,6,1,12,13,13,3,10,3,6,0,1]

theorem envBound39737 : H12AffineFastState.Bounded env39737 := by
  intro p hp
  have h : env39737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39736_39737 : H12AffineEnvironment.transform 6 5 env39736 = env39737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env39736 == env39737) = true)

def env39738 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61569,147473,41003,143497,20497,492567,148668,148669,96267,74795,16400,172,131088,1213,135680]

theorem envBound39738 : H12AffineFastState.Bounded env39738 := by
  intro p hp
  have h : env39738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39723_39738 : H12AffineEnvironment.transform 5 17 env39723 = env39738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39723 == env39738) = true)

theorem identity39738 : scanCanonicalize (H12AffineFastState.compose env39738 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 223242) := by decide +kernel

theorem selectedBound39738 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env39739 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,223242,136193,32769,4097,61569,147473,41003,143497,20497,60445,148668,148669,96267,74795,16400,172,131088,1213,135680]

theorem envBound39739 : H12AffineFastState.Bounded env39739 := by
  intro p hp
  have h : env39739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39738_39739 : H12AffineEnvironment.transform 17 223242 env39738 = env39739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223242 env39738 == env39739) = true)

theorem identity39739 : scanCanonicalize (H12AffineFastState.compose env39739 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 28803) := by decide +kernel

theorem selectedBound39739 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env39740 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,28803,131072,137353,136193,32769,4097,61569,147473,41003,143497,20497,60445,148668,148669,2184,21672,16400,172,131088,1213,135680]

theorem envBound39740 : H12AffineFastState.Bounded env39740 := by
  intro p hp
  have h : env39740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39739_39740 : H12AffineEnvironment.transform 15 28803 env39739 = env39740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28803 env39739 == env39740) = true)

theorem identity39740 : scanCanonicalize (H12AffineFastState.compose env39740 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(16+1) ^^^ 40985) := by decide +kernel

theorem selectedBound39740 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env39741 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,28803,40985,47248,46104,32769,4097,61569,57352,41003,37008,20497,60445,58533,58532,2184,21672,16400,172,40969,1213,45593]

theorem envBound39741 : H12AffineFastState.Bounded env39741 := by
  intro p hp
  have h : env39741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39740_39741 : H12AffineEnvironment.transform 16 40985 env39740 = env39741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 40985 env39740 == env39741) = true)

theorem identity39741 : scanCanonicalize (H12AffineFastState.compose env39741 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound39741 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env39742 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1213,32768,13374,40985,47248,46104,32769,4097,46140,42165,41003,37008,5292,43168,40984,40985,2184,4117,1197,172,40969,1213,45593]

theorem envBound39742 : H12AffineFastState.Bounded env39742 := by
  intro p hp
  have h : env39742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39741_39742 : H12AffineEnvironment.transform 13 1213 env39741 = env39742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env39741 == env39742) = true)

theorem identity39742 : scanCanonicalize (H12AffineFastState.compose env39742 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(14+1) ^^^ 2195) := by decide +kernel

theorem selectedBound39742 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env39743 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1213,2195,13374,10378,12291,15499,2194,4097,15535,11302,10424,6147,5292,8243,10379,10378,2184,4117,1197,172,10394,1213,14986]

theorem envBound39743 : H12AffineFastState.Bounded env39743 := by
  intro p hp
  have h : env39743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39742_39743 : H12AffineEnvironment.transform 14 2195 env39742 = env39743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2195 env39742 == env39743) = true)

theorem identity39743 : scanCanonicalize (H12AffineFastState.compose env39743 (packedSelected [0,4,5,7,8,9,10,17] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound39743 : packedSelected [0,4,5,7,8,9,10,17] rootPS < 2^1333 := by decide +kernel

def env39744 : List Nat := [2,4,8,16,32,17,128,172,512,4,2048,4096,8192,185,2195,12346,10378,12291,14479,2194,4097,14507,10274,10424,6147,4264,8243,10379,10378,2184,4117,169,172,10394,185,14986]

theorem envBound39744 : H12AffineFastState.Bounded env39744 := by
  intro p hp
  have h : env39744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39743_39744 : H12AffineEnvironment.transform 9 4 env39743 = env39744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env39743 == env39744) = true)

theorem identity39744 : scanCanonicalize (H12AffineFastState.compose env39744 (packedSelected [0,1,2,3,4,5,7,8,9,11,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 697) := by decide +kernel

theorem selectedBound39744 : packedSelected [0,1,2,3,4,5,7,8,9,11,12,15] rootPS < 2^1333 := by decide +kernel

def env39745 : List Nat := [2,4,8,16,32,17,128,172,512,4,2048,697,8192,185,2195,8835,10378,8890,10806,2194,696,10770,10274,10424,2746,529,8243,10379,10378,2184,684,169,172,10394,185,10291]

theorem envBound39745 : H12AffineFastState.Bounded env39745 := by
  intro p hp
  have h : env39745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39744_39745 : H12AffineEnvironment.transform 11 697 env39744 = env39745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 697 env39744 == env39745) = true)

theorem identity39745 : scanCanonicalize (H12AffineFastState.compose env39745 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 657) := by decide +kernel

theorem selectedBound39745 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env39746 : List Nat := [2,4,8,16,32,17,128,172,512,4,2048,697,657,185,2195,18,2587,43,2215,2194,696,2179,2739,2601,2746,529,674,2586,2587,2184,684,169,172,2571,185,2722]

theorem envBound39746 : H12AffineFastState.Bounded env39746 := by
  intro p hp
  have h : env39746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39745_39746 : H12AffineEnvironment.transform 12 657 env39745 = env39746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 657 env39745 == env39746) = true)

theorem identity39746 : scanCanonicalize (H12AffineFastState.compose env39746 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound39746 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env39747 : List Nat := [2,4,8,16,32,17,128,172,512,4,49,697,657,185,162,18,554,43,150,163,696,178,642,536,651,529,674,555,554,185,684,169,172,570,185,659]

theorem envBound39747 : H12AffineFastState.Bounded env39747 := by
  intro p hp
  have h : env39747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39746_39747 : H12AffineEnvironment.transform 10 49 env39746 = env39747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env39746 == env39747) = true)

theorem identity39747 : scanCanonicalize (H12AffineFastState.compose env39747 (packedSelected [3,4,5,9] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound39747 : packedSelected [3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env39748 : List Nat := [2,4,8,16,32,17,128,172,137,4,49,48,24,185,162,18,163,43,150,163,49,178,11,145,2,152,43,162,163,185,37,169,172,179,185,26]

theorem envBound39748 : H12AffineFastState.Bounded env39748 := by
  intro p hp
  have h : env39748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39747_39748 : H12AffineEnvironment.transform 8 137 env39747 = env39748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env39747 == env39748) = true)

theorem identity39748 : scanCanonicalize (H12AffineFastState.compose env39748 (packedSelected [0,1,4] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound39748 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env39749 : List Nat := [2,4,8,16,32,17,5,41,12,4,49,48,24,60,39,18,38,43,19,38,49,55,11,20,2,29,43,39,38,60,37,44,41,54,60,26]

theorem envBound39749 : H12AffineFastState.Bounded env39749 := by
  intro p hp
  have h : env39749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39748_39749 : H12AffineEnvironment.transform 6 5 env39748 = env39749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env39748 == env39749) = true)

def env39750 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147520,41003,143497,20497,492615,148716,148717,96346,74795,16400,173,131137,1261,135680]

theorem envBound39750 : H12AffineFastState.Bounded env39750 := by
  intro p hp
  have h : env39750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39722_39750 : H12AffineEnvironment.transform 7 173 env39722 = env39750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env39722 == env39750) = true)

def env39751 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61568,147472,41003,143497,20497,492567,148668,148669,96266,74795,16400,173,131089,1213,135680]

theorem envBound39751 : H12AffineFastState.Bounded env39751 := by
  intro p hp
  have h : env39751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39750_39751 : H12AffineEnvironment.transform 5 16 env39750 = env39751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env39750 == env39751) = true)

theorem identity39751 : scanCanonicalize (H12AffineFastState.compose env39751 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound39751 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env39752 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,45216,262144,42145,32769,4097,61568,61616,41003,32809,20497,341175,62492,62493,96266,74795,16400,173,45233,1213,41632]

theorem envBound39752 : H12AffineFastState.Bounded env39752 := by
  intro p hp
  have h : env39752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39751_39752 : H12AffineEnvironment.transform 16 45216 env39751 = env39752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env39751 == env39752) = true)

theorem identity39752 : scanCanonicalize (H12AffineFastState.compose env39752 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound39752 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env39753 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1212,32768,65536,45216,262144,42145,32769,4097,46140,46092,41003,32809,5293,341175,45216,45217,81078,74795,1196,173,45233,1213,41632]

theorem envBound39753 : H12AffineFastState.Bounded env39753 := by
  intro p hp
  have h : env39753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39752_39753 : H12AffineEnvironment.transform 13 1212 env39752 = env39753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env39752 == env39753) = true)

theorem identity39753 : scanCanonicalize (H12AffineFastState.compose env39753 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 9351) := by decide +kernel

theorem selectedBound39753 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env39754 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1212,32768,9351,45216,262144,42145,32769,4097,46140,46092,41003,32809,5293,266288,45216,45217,6193,172,1196,173,45233,1213,41632]

theorem envBound39754 : H12AffineFastState.Bounded env39754 := by
  intro p hp
  have h : env39754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39753_39754 : H12AffineEnvironment.transform 15 9351 env39753 = env39754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9351 env39753 == env39754) = true)

theorem identity39754 : scanCanonicalize (H12AffineFastState.compose env39754 (packedSelected [4,9,20] rootPS)) = affineNative (2^(14+1) ^^^ 12312) := by decide +kernel

theorem selectedBound39754 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env39755 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1212,12312,9351,184,262144,5305,12313,4097,1060,1044,4147,12337,5293,266288,184,185,6193,172,1196,173,169,1213,4792]

theorem envBound39755 : H12AffineFastState.Bounded env39755 := by
  intro p hp
  have h : env39755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39754_39755 : H12AffineEnvironment.transform 14 12312 env39754 = env39755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12312 env39754 == env39755) = true)

theorem identity39755 : scanCanonicalize (H12AffineFastState.compose env39755 (packedSelected [1,3,6,10,12,13,17] rootPS)) = affineNative (2^(17+1) ^^^ 9407) := by decide +kernel

theorem selectedBound39755 : packedSelected [1,3,6,10,12,13,17] rootPS < 2^1333 := by decide +kernel

def env39756 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1212,12312,9351,184,9407,5305,12313,4097,1060,1044,4147,12337,5293,13455,184,185,6193,172,1196,173,169,1213,4792]

theorem envBound39756 : H12AffineFastState.Bounded env39756 := by
  intro p hp
  have h : env39756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39755_39756 : H12AffineEnvironment.transform 17 9407 env39755 = env39756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 9407 env39755 == env39756) = true)

theorem identity39756 : scanCanonicalize (H12AffineFastState.compose env39756 (packedSelected [1,2,3,10,11,12,18] rootPS)) = affineNative (2^(12+1) ^^^ 2747) := by decide +kernel

theorem selectedBound39756 : packedSelected [1,2,3,10,11,12,18] rootPS < 2^1333 := by decide +kernel

def env39757 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,2747,1212,6819,3644,184,3588,5305,6818,4097,1060,1044,4147,6794,5293,7732,184,185,6193,172,1196,173,169,1213,4792]

theorem envBound39757 : H12AffineFastState.Bounded env39757 := by
  intro p hp
  have h : env39757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39756_39757 : H12AffineEnvironment.transform 12 2747 env39756 = env39757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2747 env39756 == env39757) = true)

theorem identity39757 : scanCanonicalize (H12AffineFastState.compose env39757 (packedSelected [5,8] rootPS)) = affineNative (2^(11+1) ^^^ 2194) := by decide +kernel

theorem selectedBound39757 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env39758 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,2194,2747,1212,561,3644,184,3588,3115,560,2195,1060,1044,2209,536,3135,1702,184,185,163,172,1196,173,169,1213,2602]

theorem envBound39758 : H12AffineFastState.Bounded env39758 := by
  intro p hp
  have h : env39758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39757_39758 : H12AffineEnvironment.transform 11 2194 env39757 = env39758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2194 env39757 == env39758) = true)

theorem identity39758 : scanCanonicalize (H12AffineFastState.compose env39758 (packedSelected [0,2,3,5,7,11] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound39758 : packedSelected [0,2,3,5,7,11] rootPS < 2^1333 := by decide +kernel

def env39759 : List Nat := [2,4,8,16,32,16,128,173,27,1024,2048,2194,2208,1212,42,3111,184,3103,3115,43,2195,1060,1044,2209,3,3135,1213,184,185,163,172,1196,173,169,1213,2097]

theorem envBound39759 : H12AffineFastState.Bounded env39759 := by
  intro p hp
  have h : env39759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39758_39759 : H12AffineEnvironment.transform 8 27 env39758 = env39759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env39758 == env39759) = true)

theorem identity39759 : scanCanonicalize (H12AffineFastState.compose env39759 (packedSelected [0,1,2,3,4,6,10] rootPS)) = affineNative (2^(10+1) ^^^ 1190) := by decide +kernel

theorem selectedBound39759 : packedSelected [0,1,2,3,4,6,10] rootPS < 2^1333 := by decide +kernel

def env39760 : List Nat := [2,4,8,16,32,16,128,173,27,1024,1190,1076,1030,1212,42,129,184,185,141,43,1077,1060,1044,1031,3,153,1213,184,185,163,172,1196,173,169,1213,1175]

theorem envBound39760 : H12AffineFastState.Bounded env39760 := by
  intro p hp
  have h : env39760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39759_39760 : H12AffineEnvironment.transform 10 1190 env39759 = env39760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1190 env39759 == env39760) = true)

theorem identity39760 : scanCanonicalize (H12AffineFastState.compose env39760 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound39760 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env39761 : List Nat := [2,4,8,16,32,16,18,63,27,1024,1076,1076,1030,1070,42,19,42,43,31,43,1077,1060,1044,1031,3,11,1071,42,43,49,62,1086,63,59,1071,1029]

theorem envBound39761 : H12AffineFastState.Bounded env39761 := by
  intro p hp
  have h : env39761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39760_39761 : H12AffineEnvironment.transform 6 18 env39760 = env39761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env39760 == env39761) = true)

theorem identity39761 : scanCanonicalize (H12AffineFastState.compose env39761 (packedSelected [2,3] rootPS)) = affineNative (2^(9+1) ^^^ 56) := by decide +kernel

theorem selectedBound39761 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env39762 : List Nat := [2,4,8,16,32,16,18,63,27,56,12,12,62,22,42,19,42,43,31,43,13,28,44,63,3,11,23,42,43,49,62,6,63,59,23,61]

theorem envBound39762 : H12AffineFastState.Bounded env39762 := by
  intro p hp
  have h : env39762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39761_39762 : H12AffineEnvironment.transform 9 56 env39761 = env39762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 56 env39761 == env39762) = true)

theorem identity39762 : scanCanonicalize (H12AffineFastState.compose env39762 (packedSelected [1,2,6] rootPS)) = affineNative (2^(4+1) ^^^ 29) := by decide +kernel

theorem selectedBound39762 : packedSelected [1,2,6] rootPS < 2^1333 := by decide +kernel

def env39763 : List Nat := [2,4,8,16,29,16,18,2,27,5,12,12,3,22,23,19,23,22,31,22,13,28,17,2,3,11,23,23,22,12,3,6,2,6,23,0]

theorem envBound39763 : H12AffineFastState.Bounded env39763 := by
  intro p hp
  have h : env39763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39762_39763 : H12AffineEnvironment.transform 4 29 env39762 = env39763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env39762 == env39763) = true)

theorem identity39763 : scanCanonicalize (H12AffineFastState.compose env39763 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound39763 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39764 : List Nat := [2,4,8,11,6,11,9,2,0,5,12,12,3,13,12,8,12,13,4,13,13,7,10,2,3,11,12,12,13,12,3,6,2,6,12,0]

theorem envBound39764 : H12AffineFastState.Bounded env39764 := by
  intro p hp
  have h : env39764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39763_39764 : H12AffineEnvironment.transform 3 11 env39763 = env39764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env39763 == env39764) = true)

theorem identity39764 : scanCanonicalize (H12AffineFastState.compose env39764 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound39764 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39765 : List Nat := [2,4,4,7,6,7,5,2,0,5,0,0,3,1,0,4,0,1,4,1,1,7,6,2,3,7,0,0,1,0,3,6,2,6,0,0]

theorem envBound39765 : H12AffineFastState.Bounded env39765 := by
  intro p hp
  have h : env39765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39764_39765 : H12AffineEnvironment.transform 2 4 env39764 = env39765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env39764 == env39765) = true)

def env39766 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61569,147473,41003,143497,20497,492566,148669,148668,96267,74795,16400,173,131088,1212,135680]

theorem envBound39766 : H12AffineFastState.Bounded env39766 := by
  intro p hp
  have h : env39766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39750_39766 : H12AffineEnvironment.transform 5 17 env39750 = env39766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39750 == env39766) = true)

theorem identity39766 : scanCanonicalize (H12AffineFastState.compose env39766 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 137352) := by decide +kernel

theorem selectedBound39766 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env39767 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,137352,136193,32769,4097,61569,147473,41003,143497,20497,105630,148669,148668,96267,74795,16400,173,131088,1212,135680]

theorem envBound39767 : H12AffineFastState.Bounded env39767 := by
  intro p hp
  have h : env39767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39766_39767 : H12AffineEnvironment.transform 17 137352 env39766 = env39767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137352 env39766 == env39767) = true)

theorem identity39767 : scanCanonicalize (H12AffineFastState.compose env39767 (packedSelected [1,5,8,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 13375) := by decide +kernel

theorem selectedBound39767 : packedSelected [1,5,8,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env39768 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,13375,131072,137352,136193,32769,4097,61569,147473,41003,143497,20497,43169,148669,148668,19508,4116,16400,173,131088,1212,135680]

theorem envBound39768 : H12AffineFastState.Bounded env39768 := by
  intro p hp
  have h : env39768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39767_39768 : H12AffineEnvironment.transform 15 13375 env39767 = env39768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13375 env39767 == env39768) = true)

theorem identity39768 : scanCanonicalize (H12AffineFastState.compose env39768 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound39768 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env39769 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1212,32768,13375,131072,137352,136193,32769,4097,46141,132269,41003,143497,5293,43169,131073,131072,2184,4116,1196,173,131088,1212,135680]

theorem envBound39769 : H12AffineFastState.Bounded env39769 := by
  intro p hp
  have h : env39769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39768_39769 : H12AffineEnvironment.transform 13 1212 env39768 = env39769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env39768 == env39769) = true)

theorem identity39769 : scanCanonicalize (H12AffineFastState.compose env39769 (packedSelected [13,17] rootPS)) = affineNative (2^(16+1) ^^^ 46244) := by decide +kernel

theorem selectedBound39769 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env39770 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1212,32768,13375,46244,44076,41125,32769,4097,46141,45065,41003,33837,5293,43169,46245,46244,2184,4116,1196,173,46260,1212,42660]

theorem envBound39770 : H12AffineFastState.Bounded env39770 := by
  intro p hp
  have h : env39770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39769_39770 : H12AffineEnvironment.transform 16 46244 env39769 = env39770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46244 env39769 == env39770) = true)

theorem identity39770 : scanCanonicalize (H12AffineFastState.compose env39770 (packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 3103) := by decide +kernel

theorem selectedBound39770 : packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env39771 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,3103,8192,1212,32768,10272,43195,44076,41125,32769,3102,43042,44054,41003,33837,2226,43169,43194,43195,2184,3083,1196,173,43179,1212,42660]

theorem envBound39771 : H12AffineFastState.Bounded env39771 := by
  intro p hp
  have h : env39771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39770_39771 : H12AffineEnvironment.transform 11 3103 env39770 = env39771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3103 env39770 == env39771) = true)

theorem identity39771 : scanCanonicalize (H12AffineFastState.compose env39771 (packedSelected [1,4,5,9,16] rootPS)) = affineNative (2^(14+1) ^^^ 1213) := by decide +kernel

theorem selectedBound39771 : packedSelected [1,4,5,9,16] rootPS < 2^1333 := by decide +kernel

def env39772 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,3103,8192,1212,1213,10272,11270,10385,9240,1212,3102,11423,10411,9366,144,2226,11292,11271,11270,2184,3083,1196,173,11286,1212,8729]

theorem envBound39772 : H12AffineFastState.Bounded env39772 := by
  intro p hp
  have h : env39772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39771_39772 : H12AffineEnvironment.transform 14 1213 env39771 = env39772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1213 env39771 == env39772) = true)

theorem identity39772 : scanCanonicalize (H12AffineFastState.compose env39772 (packedSelected [0,1,2,3,4,6,10,13] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound39772 : packedSelected [0,1,2,3,4,6,10,13] rootPS < 2^1333 := by decide +kernel

def env39773 : List Nat := [2,4,8,16,32,17,128,173,512,1024,42,1077,8192,1212,1213,8202,9260,8379,9240,1212,1076,9397,8321,9366,144,152,9270,9261,9260,162,1057,1196,173,9276,1212,8729]

theorem envBound39773 : H12AffineFastState.Bounded env39773 := by
  intro p hp
  have h : env39773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39772_39773 : H12AffineEnvironment.transform 10 42 env39772 = env39773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env39772 == env39773) = true)

theorem identity39773 : scanCanonicalize (H12AffineFastState.compose env39773 (packedSelected [0,3,4,6,7,8,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 150) := by decide +kernel

theorem selectedBound39773 : packedSelected [0,3,4,6,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env39774 : List Nat := [2,4,8,16,32,17,128,173,512,150,42,163,8192,42,43,8202,8378,8379,8334,42,162,8227,8321,8192,144,152,8352,8379,8378,162,183,58,173,8362,42,8729]

theorem envBound39774 : H12AffineFastState.Bounded env39774 := by
  intro p hp
  have h : env39774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39773_39774 : H12AffineEnvironment.transform 9 150 env39773 = env39774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 150 env39773 == env39774) = true)

theorem identity39774 : scanCanonicalize (H12AffineFastState.compose env39774 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 144) := by decide +kernel

theorem selectedBound39774 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env39775 : List Nat := [2,4,8,16,32,17,128,173,512,150,42,163,144,42,43,154,42,43,30,42,162,179,17,144,144,152,48,43,42,162,183,58,173,58,42,649]

theorem envBound39775 : H12AffineFastState.Bounded env39775 := by
  intro p hp
  have h : env39775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39774_39775 : H12AffineEnvironment.transform 12 144 env39774 = env39775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 144 env39774 == env39775) = true)

theorem identity39775 : scanCanonicalize (H12AffineFastState.compose env39775 (packedSelected [0,2,4,5,6] rootPS)) = affineNative (2^(8+1) ^^^ 29) := by decide +kernel

theorem selectedBound39775 : packedSelected [0,2,4,5,6] rootPS < 2^1333 := by decide +kernel

def env39776 : List Nat := [2,4,8,16,32,17,128,173,29,150,42,163,144,42,43,154,42,43,30,42,162,179,17,144,144,152,48,43,42,162,183,58,173,58,42,148]

theorem envBound39776 : H12AffineFastState.Bounded env39776 := by
  intro p hp
  have h : env39776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39775_39776 : H12AffineEnvironment.transform 8 29 env39775 = env39776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 29 env39775 == env39776) = true)

def env39777 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,533641,672784,134217728,148801,545088,96346,16876545,135123450,257,151332224,151462017,525824]

theorem envBound39777 : H12AffineFastState.Bounded env39777 := by
  intro p hp
  have h : env39777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39530_39777 : H12AffineEnvironment.transform 24 533641 env39530 = env39777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533641 env39530 == env39777) = true)

def env39778 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,533641,672784,17245632,148801,545088,96346,16876545,17495098,257,131136,1345,525824]

theorem envBound39778 : H12AffineFastState.Bounded env39778 := by
  intro p hp
  have h : env39778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39777_39778 : H12AffineEnvironment.transform 26 17245632 env39777 = env39778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env39777 == env39778) = true)

theorem identity39778 : scanCanonicalize (H12AffineFastState.compose env39778 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(18+1) ^^^ 95614) := by decide +kernel

theorem selectedBound39778 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env39779 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95614,32769,4097,61648,147520,16777216,86519,209262,17245632,148801,74814,96346,16876545,17006916,257,131136,1345,95102]

theorem envBound39779 : H12AffineFastState.Bounded env39779 := by
  intro p hp
  have h : env39779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39778_39779 : H12AffineEnvironment.transform 18 95614 env39778 = env39779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 95614 env39778 == env39779) = true)

def env39780 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95614,32769,4097,61648,147520,284032,86519,209262,225344,148801,74814,96346,381313,513220,257,131136,1345,95102]

theorem envBound39780 : H12AffineFastState.Bounded env39780 := by
  intro p hp
  have h : env39780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39779_39780 : H12AffineEnvironment.transform 23 284032 env39779 = env39780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284032 env39779 == env39780) = true)

def env39781 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16464,262144,95614,32769,4097,61648,16,284032,86519,94526,77840,1297,74814,96346,381313,365716,257,16400,1345,95102]

theorem envBound39781 : H12AffineFastState.Bounded env39781 := by
  intro p hp
  have h : env39781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39780_39781 : H12AffineEnvironment.transform 16 16464 env39780 = env39781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16464 env39780 == env39781) = true)

def env39782 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1344,262144,77934,32769,4097,46528,16,266384,70887,78894,77840,1297,74814,81226,365713,365716,257,1280,1345,79470]

theorem envBound39782 : H12AffineFastState.Bounded env39782 := by
  intro p hp
  have h : env39782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39781_39782 : H12AffineEnvironment.transform 13 1296 env39781 = env39782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env39781 == env39782) = true)

theorem identity39782 : scanCanonicalize (H12AffineFastState.compose env39782 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32883) := by decide +kernel

theorem selectedBound39782 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env39783 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,32883,1344,262144,45085,32769,4097,46528,16,266384,38036,46173,45155,1297,42061,48441,267490,267495,257,1280,1345,46621]

theorem envBound39783 : H12AffineFastState.Bounded env39783 := by
  intro p hp
  have h : env39783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39782_39783 : H12AffineEnvironment.transform 15 32883 env39782 = env39783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32883 env39782 == env39783) = true)

def env39784 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32883,1344,262144,42333,32769,1345,41088,16,263632,33236,41245,42275,1297,42061,43129,262562,262567,257,1280,1345,41821]

theorem envBound39784 : H12AffineFastState.Bounded env39784 := by
  intro p hp
  have h : env39784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39783_39784 : H12AffineEnvironment.transform 11 1344 env39783 = env39784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env39783 == env39784) = true)

theorem identity39784 : scanCanonicalize (H12AffineFastState.compose env39784 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound39784 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env39785 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,25,1296,32768,32883,1344,262144,34116,32769,1345,32921,16,263632,33236,33028,34106,1297,33876,34912,262562,262567,257,1280,1345,33604]

theorem envBound39785 : H12AffineFastState.Bounded env39785 := by
  intro p hp
  have h : env39785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39784_39785 : H12AffineEnvironment.transform 12 25 env39784 = env39785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env39784 == env39785) = true)

theorem identity39785 : scanCanonicalize (H12AffineFastState.compose env39785 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 2560) := by decide +kernel

theorem selectedBound39785 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env39786 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,25,1296,32768,32883,1344,2560,34116,32769,1345,32921,16,4048,33236,33028,34106,1297,33876,34912,2978,2983,257,1280,1345,33604]

theorem envBound39786 : H12AffineFastState.Bounded env39786 := by
  intro p hp
  have h : env39786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39785_39786 : H12AffineEnvironment.transform 17 2560 env39785 = env39786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2560 env39785 == env39786) = true)

def env39787 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32883,1344,262144,42332,32769,1344,41089,16,263633,33237,41244,42274,1297,42061,43128,262563,262566,257,1280,1345,41820]

theorem envBound39787 : H12AffineFastState.Bounded env39787 := by
  intro p hp
  have h : env39787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39783_39787 : H12AffineEnvironment.transform 11 1345 env39783 = env39787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env39783 == env39787) = true)

theorem identity39787 : scanCanonicalize (H12AffineFastState.compose env39787 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 41195) := by decide +kernel

theorem selectedBound39787 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env39788 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32883,1344,41195,42332,32769,1344,41089,16,42298,33237,41244,42274,1297,42061,43128,41288,41293,257,1280,1345,41820]

theorem envBound39788 : H12AffineFastState.Bounded env39788 := by
  intro p hp
  have h : env39788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39787_39788 : H12AffineEnvironment.transform 17 41195 env39787 = env39788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 41195 env39787 == env39788) = true)

theorem identity39788 : scanCanonicalize (H12AffineFastState.compose env39788 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound39788 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env39789 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,8540,8495,1344,439,1024,8541,1344,477,16,1126,8329,64,1150,1297,1297,2340,20,17,257,1280,1345,512]

theorem envBound39789 : H12AffineFastState.Bounded env39789 := by
  intro p hp
  have h : env39789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39788_39789 : H12AffineEnvironment.transform 14 8540 env39788 = env39789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env39788 == env39789) = true)

theorem identity39789 : scanCanonicalize (H12AffineFastState.compose env39789 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound39789 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env39790 : List Nat := [2,4,8,16,32,64,128,256,512,85,2048,276,8192,325,8540,8495,277,439,85,8541,277,477,16,51,8329,64,43,324,324,2340,20,17,257,341,276,512]

theorem envBound39790 : H12AffineFastState.Bounded env39790 := by
  intro p hp
  have h : env39790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39789_39790 : H12AffineEnvironment.transform 9 85 env39789 = env39790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env39789 == env39790) = true)

theorem identity39790 : scanCanonicalize (H12AffineFastState.compose env39790 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 980) := by decide +kernel

theorem selectedBound39790 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env39791 : List Nat := [2,4,8,16,32,64,128,256,512,85,2048,276,980,325,648,763,277,439,85,649,277,477,16,51,861,64,43,324,324,2340,20,17,257,341,276,512]

theorem envBound39791 : H12AffineFastState.Bounded env39791 := by
  intro p hp
  have h : env39791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39790_39791 : H12AffineEnvironment.transform 12 980 env39790 = env39791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 980 env39790 == env39791) = true)

theorem identity39791 : scanCanonicalize (H12AffineFastState.compose env39791 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound39791 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env39792 : List Nat := [2,4,8,16,32,17,128,256,512,4,2048,276,901,276,648,682,277,439,4,649,277,396,16,51,780,17,43,277,277,2340,20,17,257,260,276,512]

theorem envBound39792 : H12AffineFastState.Bounded env39792 := by
  intro p hp
  have h : env39792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39791_39792 : H12AffineEnvironment.transform 5 17 env39791 = env39792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39791 == env39792) = true)

theorem identity39792 : scanCanonicalize (H12AffineFastState.compose env39792 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound39792 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env39793 : List Nat := [2,4,8,16,32,17,128,20,512,4,2048,0,657,0,648,682,1,163,4,649,1,152,16,51,536,17,43,1,1,2096,20,17,21,16,0,512]

theorem envBound39793 : H12AffineFastState.Bounded env39793 := by
  intro p hp
  have h : env39793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39792_39793 : H12AffineEnvironment.transform 7 20 env39792 = env39793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env39792 == env39793) = true)

theorem identity39793 : scanCanonicalize (H12AffineFastState.compose env39793 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 22) := by decide +kernel

theorem selectedBound39793 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39794 : List Nat := [2,4,8,16,32,17,128,20,22,4,2048,0,135,0,158,188,1,163,4,159,1,152,16,51,14,17,43,1,1,2096,20,17,21,16,0,22]

theorem envBound39794 : H12AffineFastState.Bounded env39794 := by
  intro p hp
  have h : env39794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39793_39794 : H12AffineEnvironment.transform 8 22 env39793 = env39794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 22 env39793 == env39794) = true)

theorem identity39794 : scanCanonicalize (H12AffineFastState.compose env39794 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound39794 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env39795 : List Nat := [2,4,8,16,17,17,128,20,22,4,2048,0,135,0,158,141,1,146,4,159,1,152,16,2,14,17,26,1,1,2049,20,17,21,16,0,22]

theorem envBound39795 : H12AffineFastState.Bounded env39795 := by
  intro p hp
  have h : env39795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39794_39795 : H12AffineEnvironment.transform 4 17 env39794 = env39795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env39794 == env39795) = true)

theorem identity39795 : scanCanonicalize (H12AffineFastState.compose env39795 (packedSelected [0,2] rootPS)) = affineNative (2^(10+1) ^^^ 13) := by decide +kernel

theorem selectedBound39795 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env39796 : List Nat := [2,4,8,16,17,17,128,20,22,4,13,0,135,0,158,141,1,146,4,159,1,152,16,2,14,17,26,1,1,12,20,17,21,16,0,22]

theorem envBound39796 : H12AffineFastState.Bounded env39796 := by
  intro p hp
  have h : env39796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39795_39796 : H12AffineEnvironment.transform 10 13 env39795 = env39796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 13 env39795 == env39796) = true)

theorem identity39796 : scanCanonicalize (H12AffineFastState.compose env39796 (packedSelected [5] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound39796 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env39797 : List Nat := [2,4,8,16,17,17,8,20,22,4,13,0,15,0,22,5,1,26,4,23,1,16,16,2,14,17,26,1,1,12,20,17,21,16,0,22]

theorem envBound39797 : H12AffineFastState.Bounded env39797 := by
  intro p hp
  have h : env39797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39796_39797 : H12AffineEnvironment.transform 6 8 env39796 = env39797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39796 == env39797) = true)

theorem identity39797 : scanCanonicalize (H12AffineFastState.compose env39797 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound39797 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39798 : List Nat := [2,4,4,16,17,17,4,20,22,4,1,0,3,0,22,5,1,22,4,23,1,16,16,2,2,17,22,1,1,0,20,17,21,16,0,22]

theorem envBound39798 : H12AffineFastState.Bounded env39798 := by
  intro p hp
  have h : env39798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39797_39798 : H12AffineEnvironment.transform 2 4 env39797 = env39798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env39797 == env39798) = true)

theorem identity39798 : scanCanonicalize (H12AffineFastState.compose env39798 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound39798 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env39799 : List Nat := [2,4,4,6,7,7,4,2,0,4,1,0,3,0,0,5,1,0,4,1,1,6,6,2,2,7,0,1,1,0,2,7,3,6,0,0]

theorem envBound39799 : H12AffineFastState.Bounded env39799 := by
  intro p hp
  have h : env39799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39798_39799 : H12AffineEnvironment.transform 3 6 env39798 = env39799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env39798 == env39799) = true)

def env39800 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1345,262144,77935,32769,4097,46529,16,266385,70886,78895,77840,1297,74814,81227,365712,365716,257,1281,1345,79471]

theorem envBound39800 : H12AffineFastState.Bounded env39800 := by
  intro p hp
  have h : env39800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39781_39800 : H12AffineEnvironment.transform 13 1297 env39781 = env39800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env39781 == env39800) = true)

theorem identity39800 : scanCanonicalize (H12AffineFastState.compose env39800 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound39800 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env39801 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1345,262144,77935,13341,4097,477,16,266385,70886,78895,77840,1297,74814,81227,336012,336008,257,1281,1345,79471]

theorem envBound39801 : H12AffineFastState.Bounded env39801 := by
  intro p hp
  have h : env39801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39800_39801 : H12AffineEnvironment.transform 14 13340 env39800 = env39801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env39800 == env39801) = true)

def env39802 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1345,65664,77935,13341,4097,477,16,69649,70886,78895,77840,1297,74814,81227,8204,8200,257,1281,1345,79471]

theorem envBound39802 : H12AffineFastState.Bounded env39802 := by
  intro p hp
  have h : env39802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39801_39802 : H12AffineEnvironment.transform 17 65664 env39801 = env39802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env39801 == env39802) = true)

theorem identity39802 : scanCanonicalize (H12AffineFastState.compose env39802 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12671) := by decide +kernel

theorem selectedBound39802 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env39803 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,12671,1345,12799,272,13341,4097,477,16,8558,9625,1360,367,1297,5441,3124,8204,8200,257,1281,1345,1808]

theorem envBound39803 : H12AffineFastState.Bounded env39803 := by
  intro p hp
  have h : env39803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39802_39803 : H12AffineEnvironment.transform 15 12671 env39802 = env39803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12671 env39802 == env39803) = true)

def env39804 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,81,12636,12671,1,12799,272,12637,4097,477,16,8558,8409,16,367,81,4097,2420,8204,8200,257,65,1,592]

theorem envBound39804 : H12AffineFastState.Bounded env39804 := by
  intro p hp
  have h : env39804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39803_39804 : H12AffineEnvironment.transform 9 320 env39803 = env39804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env39803 == env39804) = true)

theorem identity39804 : scanCanonicalize (H12AffineFastState.compose env39804 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 325) := by decide +kernel

theorem selectedBound39804 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env39805 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,325,8192,81,8217,8250,1,8378,272,8216,324,477,16,8558,8409,16,367,81,324,2420,8204,8200,257,65,1,592]

theorem envBound39805 : H12AffineFastState.Bounded env39805 := by
  intro p hp
  have h : env39805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39804_39805 : H12AffineEnvironment.transform 11 325 env39804 = env39805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 325 env39804 == env39805) = true)

theorem identity39805 : scanCanonicalize (H12AffineFastState.compose env39805 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound39805 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env39806 : List Nat := [2,4,8,16,32,64,128,69,512,5,2048,0,8192,81,8217,8250,1,8378,85,8216,1,152,16,8235,8409,16,42,81,1,2097,8204,8200,68,65,1,592]

theorem envBound39806 : H12AffineFastState.Bounded env39806 := by
  intro p hp
  have h : env39806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39805_39806 : H12AffineEnvironment.transform 7 69 env39805 = env39806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env39805 == env39806) = true)

theorem identity39806 : scanCanonicalize (H12AffineFastState.compose env39806 (packedSelected [5,8,17] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound39806 : packedSelected [5,8,17] rootPS < 2^1333 := by decide +kernel

def env39807 : List Nat := [2,4,8,16,32,64,128,69,26,5,2048,0,8192,81,8217,8250,1,8378,85,8216,1,152,16,8235,8409,16,42,81,1,2097,8204,8200,68,65,1,74]

theorem envBound39807 : H12AffineFastState.Bounded env39807 := by
  intro p hp
  have h : env39807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39806_39807 : H12AffineEnvironment.transform 8 26 env39806 = env39807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env39806 == env39807) = true)

theorem identity39807 : scanCanonicalize (H12AffineFastState.compose env39807 (packedSelected [3,8,11,18] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound39807 : packedSelected [3,8,11,18] rootPS < 2^1333 := by decide +kernel

def env39808 : List Nat := [2,4,8,16,32,64,128,69,26,5,80,0,8192,81,8217,8250,1,8378,85,8216,1,152,16,8235,8409,16,42,81,1,97,8204,8200,68,65,1,74]

theorem envBound39808 : H12AffineFastState.Bounded env39808 := by
  intro p hp
  have h : env39808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39807_39808 : H12AffineEnvironment.transform 10 80 env39807 = env39808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env39807 == env39808) = true)

theorem identity39808 : scanCanonicalize (H12AffineFastState.compose env39808 (packedSelected [0,1,3,5,7,8,10,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound39808 : packedSelected [0,1,3,5,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env39809 : List Nat := [2,4,8,16,11,64,128,69,26,5,80,0,8192,81,8217,8209,1,8337,85,8216,1,152,16,8192,8409,16,1,81,1,74,8204,8200,68,65,1,74]

theorem envBound39809 : H12AffineFastState.Bounded env39809 := by
  intro p hp
  have h : env39809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39808_39809 : H12AffineEnvironment.transform 4 11 env39808 = env39809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env39808 == env39809) = true)

theorem identity39809 : scanCanonicalize (H12AffineFastState.compose env39809 (packedSelected [2,4,9] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound39809 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env39810 : List Nat := [2,4,8,10,11,64,128,69,0,5,74,0,8192,75,8195,8203,1,8331,79,8194,1,130,10,8192,8387,10,1,75,1,74,8204,8200,68,65,1,74]

theorem envBound39810 : H12AffineFastState.Bounded env39810 := by
  intro p hp
  have h : env39810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39809_39810 : H12AffineEnvironment.transform 3 10 env39809 = env39810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env39809 == env39810) = true)

theorem identity39810 : scanCanonicalize (H12AffineFastState.compose env39810 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(12+1) ^^^ 193) := by decide +kernel

theorem selectedBound39810 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env39811 : List Nat := [2,4,8,10,11,64,128,69,0,5,74,0,193,75,194,202,1,74,79,195,1,130,10,193,2,10,1,75,1,74,205,201,68,65,1,74]

theorem envBound39811 : H12AffineFastState.Bounded env39811 := by
  intro p hp
  have h : env39811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39810_39811 : H12AffineEnvironment.transform 12 193 env39810 = env39811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 193 env39810 == env39811) = true)

theorem identity39811 : scanCanonicalize (H12AffineFastState.compose env39811 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 67) := by decide +kernel

theorem selectedBound39811 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env39812 : List Nat := [2,4,8,10,11,64,67,69,0,5,74,0,2,75,1,9,1,74,79,0,1,65,10,2,2,10,1,75,1,74,14,10,68,65,1,74]

theorem envBound39812 : H12AffineFastState.Bounded env39812 := by
  intro p hp
  have h : env39812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39811_39812 : H12AffineEnvironment.transform 6 67 env39811 = env39812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 67 env39811 == env39812) = true)

theorem identity39812 : scanCanonicalize (H12AffineFastState.compose env39812 (packedSelected [0,1,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound39812 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env39813 : List Nat := [2,3,8,10,11,64,67,66,0,2,74,0,2,75,1,9,1,74,72,0,1,65,10,2,2,10,1,75,1,74,9,10,67,65,1,74]

theorem envBound39813 : H12AffineFastState.Bounded env39813 := by
  intro p hp
  have h : env39813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39812_39813 : H12AffineEnvironment.transform 1 3 env39812 = env39813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env39812 == env39813) = true)

def env39814 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,80,12637,12671,0,12799,272,12636,4097,477,16,8558,8408,17,367,80,4096,2421,8204,8200,257,64,0,593]

theorem envBound39814 : H12AffineFastState.Bounded env39814 := by
  intro p hp
  have h : env39814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39803_39814 : H12AffineEnvironment.transform 9 321 env39803 = env39814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env39803 == env39814) = true)

theorem identity39814 : scanCanonicalize (H12AffineFastState.compose env39814 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound39814 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env39815 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,277,8192,80,8264,8298,0,8426,272,8265,276,477,16,8558,8408,17,367,80,277,2421,8204,8200,257,64,0,593]

theorem envBound39815 : H12AffineFastState.Bounded env39815 := by
  intro p hp
  have h : env39815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39814_39815 : H12AffineEnvironment.transform 11 277 env39814 = env39815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env39814 == env39815) = true)

theorem identity39815 : scanCanonicalize (H12AffineFastState.compose env39815 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound39815 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env39816 : List Nat := [2,4,8,16,32,64,128,21,512,84,2048,0,8192,80,8264,8298,0,8426,5,8265,1,200,16,8315,8408,17,122,80,0,2144,8204,8200,20,64,0,593]

theorem envBound39816 : H12AffineFastState.Bounded env39816 := by
  intro p hp
  have h : env39816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39815_39816 : H12AffineEnvironment.transform 7 21 env39815 = env39816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env39815 == env39816) = true)

theorem identity39816 : scanCanonicalize (H12AffineFastState.compose env39816 (packedSelected [5,8,17] rootPS)) = affineNative (2^(10+1) ^^^ 162) := by decide +kernel

theorem selectedBound39816 : packedSelected [5,8,17] rootPS < 2^1333 := by decide +kernel

def env39817 : List Nat := [2,4,8,16,32,64,128,21,512,84,162,0,8192,80,8264,8298,0,8426,5,8265,1,200,16,8315,8408,17,122,80,0,194,8204,8200,20,64,0,593]

theorem envBound39817 : H12AffineFastState.Bounded env39817 := by
  intro p hp
  have h : env39817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39816_39817 : H12AffineEnvironment.transform 10 162 env39816 = env39817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 162 env39816 == env39817) = true)

theorem identity39817 : scanCanonicalize (H12AffineFastState.compose env39817 (packedSelected [0,1,3,5,7,8,11,12,15] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound39817 : packedSelected [0,1,3,5,7,8,11,12,15] rootPS < 2^1333 := by decide +kernel

def env39818 : List Nat := [2,4,8,10,32,64,128,15,512,78,162,0,8192,74,8264,8298,0,8426,5,8265,1,200,10,8289,8386,11,96,74,0,194,8204,8200,14,64,0,587]

theorem envBound39818 : H12AffineFastState.Bounded env39818 := by
  intro p hp
  have h : env39818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39817_39818 : H12AffineEnvironment.transform 3 10 env39817 = env39818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env39817 == env39818) = true)

theorem identity39818 : scanCanonicalize (H12AffineFastState.compose env39818 (packedSelected [0,4,10] rootPS)) = affineNative (2^(12+1) ^^^ 673) := by decide +kernel

theorem selectedBound39818 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env39819 : List Nat := [2,4,8,10,32,64,128,15,512,78,162,0,673,74,745,715,0,587,5,744,1,200,10,704,611,11,96,74,0,194,685,681,14,64,0,587]

theorem envBound39819 : H12AffineFastState.Bounded env39819 := by
  intro p hp
  have h : env39819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39818_39819 : H12AffineEnvironment.transform 12 673 env39818 = env39819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 673 env39818 == env39819) = true)

theorem identity39819 : scanCanonicalize (H12AffineFastState.compose env39819 (packedSelected [1,2,3,4,5,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound39819 : packedSelected [1,2,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env39820 : List Nat := [2,4,8,10,10,64,128,15,512,78,136,0,651,74,707,715,0,587,5,706,1,200,10,704,585,11,74,74,0,194,647,643,14,64,0,587]

theorem envBound39820 : H12AffineFastState.Bounded env39820 := by
  intro p hp
  have h : env39820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39819_39820 : H12AffineEnvironment.transform 4 10 env39819 = env39820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env39819 == env39820) = true)

theorem identity39820 : scanCanonicalize (H12AffineFastState.compose env39820 (packedSelected [1,2,4,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 74) := by decide +kernel

theorem selectedBound39820 : packedSelected [1,2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env39821 : List Nat := [2,4,8,10,10,64,128,15,74,78,136,0,193,74,137,129,0,1,5,136,1,200,10,138,3,11,74,74,0,194,205,201,14,64,0,1]

theorem envBound39821 : H12AffineFastState.Bounded env39821 := by
  intro p hp
  have h : env39821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39820_39821 : H12AffineEnvironment.transform 8 74 env39820 = env39821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 74 env39820 == env39821) = true)

theorem identity39821 : scanCanonicalize (H12AffineFastState.compose env39821 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound39821 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39822 : List Nat := [2,4,8,10,10,10,128,15,0,4,136,0,139,0,137,129,0,1,5,136,1,130,10,138,3,11,0,0,0,136,135,131,14,10,0,1]

theorem envBound39822 : H12AffineFastState.Bounded env39822 := by
  intro p hp
  have h : env39822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39821_39822 : H12AffineEnvironment.transform 5 10 env39821 = env39822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env39821 == env39822) = true)

theorem identity39822 : scanCanonicalize (H12AffineFastState.compose env39822 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound39822 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env39823 : List Nat := [2,4,0,2,2,2,128,7,0,4,128,0,131,0,129,129,0,1,5,128,1,130,2,130,3,3,0,0,0,128,135,131,6,2,0,1]

theorem envBound39823 : H12AffineFastState.Bounded env39823 := by
  intro p hp
  have h : env39823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39822_39823 : H12AffineEnvironment.transform 2 0 env39822 = env39823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env39822 == env39823) = true)

theorem identity39823 : scanCanonicalize (H12AffineFastState.compose env39823 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound39823 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env39824 : List Nat := [2,4,0,2,2,2,3,7,0,4,3,0,0,0,2,2,0,1,5,3,1,1,2,1,3,3,0,0,0,3,4,0,6,2,0,1]

theorem envBound39824 : H12AffineFastState.Bounded env39824 := by
  intro p hp
  have h : env39824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39823_39824 : H12AffineEnvironment.transform 6 3 env39823 = env39824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env39823 == env39824) = true)

theorem identity39824 : scanCanonicalize (H12AffineFastState.compose env39824 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound39824 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39825 : List Nat := [2,2,0,2,2,2,3,1,0,2,3,0,0,0,2,2,0,1,3,3,1,1,2,1,3,3,0,0,0,3,2,0,0,2,0,1]

theorem envBound39825 : H12AffineFastState.Bounded env39825 := by
  intro p hp
  have h : env39825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39824_39825 : H12AffineEnvironment.transform 1 2 env39824 = env39825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env39824 == env39825) = true)

theorem identity39825 : scanCanonicalize (H12AffineFastState.compose env39825 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound39825 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env39826 : List Nat := [0,0,0,0,0,0,1,1,0,0,1,0,0,0,0,0,0,1,1,1,1,1,0,1,1,1,0,0,0,1,0,0,0,0,0,1]

theorem envBound39826 : H12AffineFastState.Bounded env39826 := by
  intro p hp
  have h : env39826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39825_39826 : H12AffineEnvironment.transform 0 0 env39825 = env39826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env39825 == env39826) = true)

def env39827 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1345,65665,77935,13341,4097,477,16,69648,70886,78895,77840,1297,74814,81227,8205,8201,257,1281,1345,79471]

theorem envBound39827 : H12AffineFastState.Bounded env39827 := by
  intro p hp
  have h : env39827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39801_39827 : H12AffineEnvironment.transform 17 65665 env39801 = env39827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env39801 == env39827) = true)

theorem identity39827 : scanCanonicalize (H12AffineFastState.compose env39827 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9278) := by decide +kernel

theorem selectedBound39827 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env39828 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,9278,1345,9407,5201,13341,4097,477,16,13358,12504,4113,5166,1297,0,6517,8205,8201,257,1281,1345,4689]

theorem envBound39828 : H12AffineFastState.Bounded env39828 := by
  intro p hp
  have h : env39828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39827_39828 : H12AffineEnvironment.transform 15 9278 env39827 = env39828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9278 env39827 == env39828) = true)

def env39829 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1297,9244,9278,1345,9407,1105,9245,1,477,16,9262,8408,17,1070,1297,0,2421,8205,8201,257,1281,1345,593]

theorem envBound39829 : H12AffineFastState.Bounded env39829 := by
  intro p hp
  have h : env39829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39828_39829 : H12AffineEnvironment.transform 11 0 env39828 = env39829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env39828 == env39829) = true)

theorem identity39829 : scanCanonicalize (H12AffineFastState.compose env39829 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound39829 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env39830 : List Nat := [2,4,8,16,32,64,128,21,512,1024,2048,0,8192,1028,9244,9278,1108,9407,1105,9245,1,200,16,9262,8408,17,1070,1028,0,2144,8205,8201,20,1044,1108,593]

theorem envBound39830 : H12AffineFastState.Bounded env39830 := by
  intro p hp
  have h : env39830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39829_39830 : H12AffineEnvironment.transform 7 21 env39829 = env39830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env39829 == env39830) = true)

theorem identity39830 : scanCanonicalize (H12AffineFastState.compose env39830 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound39830 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env39831 : List Nat := [2,4,8,16,32,64,128,21,512,5,2048,0,8192,1,8217,8251,81,8378,84,8216,1,200,16,8235,8408,17,43,1,0,2144,8205,8201,20,17,81,593]

theorem envBound39831 : H12AffineFastState.Bounded env39831 := by
  intro p hp
  have h : env39831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39830_39831 : H12AffineEnvironment.transform 9 5 env39830 = env39831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env39830 == env39831) = true)

theorem identity39831 : scanCanonicalize (H12AffineFastState.compose env39831 (packedSelected [0,1,2,5,7,10,11,19] rootPS)) = affineNative (2^(10+1) ^^^ 232) := by decide +kernel

theorem selectedBound39831 : packedSelected [0,1,2,5,7,10,11,19] rootPS < 2^1333 := by decide +kernel

def env39832 : List Nat := [2,4,8,16,32,64,128,21,512,5,232,0,8192,1,8217,8251,81,8378,84,8216,1,200,16,8235,8408,17,43,1,0,136,8205,8201,20,17,81,593]

theorem envBound39832 : H12AffineFastState.Bounded env39832 := by
  intro p hp
  have h : env39832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39831_39832 : H12AffineEnvironment.transform 10 232 env39831 = env39832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 232 env39831 == env39832) = true)

theorem identity39832 : scanCanonicalize (H12AffineFastState.compose env39832 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 553) := by decide +kernel

theorem selectedBound39832 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39833 : List Nat := [2,4,8,16,32,64,128,21,512,5,232,0,553,1,560,530,81,659,84,561,1,200,16,514,753,17,43,1,0,136,548,544,20,17,81,593]

theorem envBound39833 : H12AffineFastState.Bounded env39833 := by
  intro p hp
  have h : env39833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39832_39833 : H12AffineEnvironment.transform 12 553 env39832 = env39833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 553 env39832 == env39833) = true)

theorem identity39833 : scanCanonicalize (H12AffineFastState.compose env39833 (packedSelected [1,3,13] rootPS)) = affineNative (2^(8+1) ^^^ 216) := by decide +kernel

theorem selectedBound39833 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env39834 : List Nat := [2,4,8,16,32,64,128,21,216,5,232,0,241,1,232,202,81,75,84,233,1,200,16,218,41,17,43,1,0,136,252,248,20,17,81,137]

theorem envBound39834 : H12AffineFastState.Bounded env39834 := by
  intro p hp
  have h : env39834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39833_39834 : H12AffineEnvironment.transform 8 216 env39833 = env39834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env39833 == env39834) = true)

theorem identity39834 : scanCanonicalize (H12AffineFastState.compose env39834 (packedSelected [4,5,8,9,10,11] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound39834 : packedSelected [4,5,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env39835 : List Nat := [2,4,8,16,10,64,128,21,216,5,194,0,219,1,194,202,81,75,84,195,1,200,16,218,3,17,1,1,0,136,214,210,20,17,81,137]

theorem envBound39835 : H12AffineFastState.Bounded env39835 := by
  intro p hp
  have h : env39835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39834_39835 : H12AffineEnvironment.transform 4 10 env39834 = env39835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env39834 == env39835) = true)

theorem identity39835 : scanCanonicalize (H12AffineFastState.compose env39835 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound39835 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env39836 : List Nat := [2,4,8,10,10,64,128,15,194,5,194,0,193,1,194,202,75,75,78,195,1,200,10,192,3,11,1,1,0,136,204,200,14,11,75,137]

theorem envBound39836 : H12AffineFastState.Bounded env39836 := by
  intro p hp
  have h : env39836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39835_39836 : H12AffineEnvironment.transform 3 10 env39835 = env39836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env39835 == env39836) = true)

theorem identity39836 : scanCanonicalize (H12AffineFastState.compose env39836 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound39836 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39837 : List Nat := [2,4,8,10,10,10,128,15,136,5,136,0,139,1,136,128,1,1,4,137,1,130,10,138,3,11,1,1,0,136,134,130,14,11,1,137]

theorem envBound39837 : H12AffineFastState.Bounded env39837 := by
  intro p hp
  have h : env39837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39836_39837 : H12AffineEnvironment.transform 5 10 env39836 = env39837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env39836 == env39837) = true)

theorem identity39837 : scanCanonicalize (H12AffineFastState.compose env39837 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound39837 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env39838 : List Nat := [2,4,0,2,2,2,128,7,128,5,128,0,131,1,128,128,1,1,4,129,1,130,2,130,3,3,1,1,0,128,134,130,6,3,1,129]

theorem envBound39838 : H12AffineFastState.Bounded env39838 := by
  intro p hp
  have h : env39838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39837_39838 : H12AffineEnvironment.transform 2 0 env39837 = env39838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env39837 == env39838) = true)

theorem identity39838 : scanCanonicalize (H12AffineFastState.compose env39838 (packedSelected [0,4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound39838 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env39839 : List Nat := [1,4,0,1,1,1,128,4,128,5,128,0,128,1,128,128,1,1,4,129,1,129,1,129,0,0,1,1,0,128,133,129,5,0,1,129]

theorem envBound39839 : H12AffineFastState.Bounded env39839 := by
  intro p hp
  have h : env39839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39838_39839 : H12AffineEnvironment.transform 0 1 env39838 = env39839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env39838 == env39839) = true)

theorem identity39839 : scanCanonicalize (H12AffineFastState.compose env39839 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound39839 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39840 : List Nat := [1,0,0,1,1,1,128,0,128,1,128,0,128,1,128,128,1,1,0,129,1,129,1,129,0,0,1,1,0,128,129,129,1,0,1,129]

theorem envBound39840 : H12AffineFastState.Bounded env39840 := by
  intro p hp
  have h : env39840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39839_39840 : H12AffineEnvironment.transform 1 0 env39839 = env39840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env39839 == env39840) = true)

theorem identity39840 : scanCanonicalize (H12AffineFastState.compose env39840 (packedSelected [5] rootPS)) = affineNative (2^(6+1) ^^^ 1) := by decide +kernel

theorem selectedBound39840 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env39841 : List Nat := [1,0,0,1,1,1,1,0,1,1,1,0,1,1,1,1,1,1,0,0,1,0,1,0,0,0,1,1,0,1,0,0,1,0,1,0]

theorem envBound39841 : H12AffineFastState.Bounded env39841 := by
  intro p hp
  have h : env39841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39840_39841 : H12AffineEnvironment.transform 6 1 env39840 = env39841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 1 env39840 == env39841) = true)

def env39842 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1297,9245,9278,1345,9407,1104,9244,0,477,16,9263,8409,16,1071,1297,0,2420,8205,8201,257,1281,1345,592]

theorem envBound39842 : H12AffineFastState.Bounded env39842 := by
  intro p hp
  have h : env39842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39828_39842 : H12AffineEnvironment.transform 11 1 env39828 = env39842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env39828 == env39842) = true)

theorem identity39842 : scanCanonicalize (H12AffineFastState.compose env39842 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound39842 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env39843 : List Nat := [2,4,8,16,32,64,128,68,512,1024,2048,1,8192,1109,9245,9278,1029,9407,1104,9244,0,153,16,9263,8409,16,1071,1109,0,2096,8205,8201,69,1093,1029,592]

theorem envBound39843 : H12AffineFastState.Bounded env39843 := by
  intro p hp
  have h : env39843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39842_39843 : H12AffineEnvironment.transform 7 68 env39842 = env39843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env39842 == env39843) = true)

theorem identity39843 : scanCanonicalize (H12AffineFastState.compose env39843 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound39843 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env39844 : List Nat := [2,4,8,16,32,64,128,68,512,85,2048,1,8192,0,8264,8299,80,8426,5,8265,0,153,16,8314,8409,16,122,0,0,2096,8205,8201,69,16,80,592]

theorem envBound39844 : H12AffineFastState.Bounded env39844 := by
  intro p hp
  have h : env39844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39843_39844 : H12AffineEnvironment.transform 9 85 env39843 = env39844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env39843 == env39844) = true)

theorem identity39844 : scanCanonicalize (H12AffineFastState.compose env39844 (packedSelected [1,2,3,5,8,13,17] rootPS)) = affineNative (2^(10+1) ^^^ 555) := by decide +kernel

theorem selectedBound39844 : packedSelected [1,2,3,5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env39845 : List Nat := [2,4,8,16,32,64,128,68,512,85,555,1,8192,0,8264,8299,80,8426,5,8265,0,153,16,8314,8409,16,122,0,0,539,8205,8201,69,16,80,592]

theorem envBound39845 : H12AffineFastState.Bounded env39845 := by
  intro p hp
  have h : env39845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39844_39845 : H12AffineEnvironment.transform 10 555 env39844 = env39845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 555 env39844 == env39845) = true)

theorem identity39845 : scanCanonicalize (H12AffineFastState.compose env39845 (packedSelected [0,3,7,8,18] rootPS)) = affineNative (2^(12+1) ^^^ 746) := by decide +kernel

theorem selectedBound39845 : packedSelected [0,3,7,8,18] rootPS < 2^1333 := by decide +kernel

def env39846 : List Nat := [2,4,8,16,32,64,128,68,512,85,555,1,746,0,674,641,80,512,5,675,0,153,16,656,563,16,122,0,0,539,743,739,69,16,80,592]

theorem envBound39846 : H12AffineFastState.Bounded env39846 := by
  intro p hp
  have h : env39846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39845_39846 : H12AffineEnvironment.transform 12 746 env39845 = env39846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 746 env39845 == env39846) = true)

theorem identity39846 : scanCanonicalize (H12AffineFastState.compose env39846 (packedSelected [0,7,11] rootPS)) = affineNative (2^(8+1) ^^^ 216) := by decide +kernel

theorem selectedBound39846 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env39847 : List Nat := [2,4,8,16,32,64,128,68,216,85,243,1,50,0,122,89,80,216,5,123,0,153,16,72,235,16,122,0,0,195,63,59,69,16,80,136]

theorem envBound39847 : H12AffineFastState.Bounded env39847 := by
  intro p hp
  have h : env39847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39846_39847 : H12AffineEnvironment.transform 8 216 env39846 = env39847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env39846 == env39847) = true)

theorem identity39847 : scanCanonicalize (H12AffineFastState.compose env39847 (packedSelected [1,4,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound39847 : packedSelected [1,4,8,9] rootPS < 2^1333 := by decide +kernel

def env39848 : List Nat := [2,4,8,16,32,58,128,62,162,47,137,1,50,0,0,35,42,162,5,1,0,153,16,50,145,16,0,0,0,185,63,59,63,16,42,136]

theorem envBound39848 : H12AffineFastState.Bounded env39848 := by
  intro p hp
  have h : env39848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39847_39848 : H12AffineEnvironment.transform 5 58 env39847 = env39848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env39847 == env39848) = true)

theorem identity39848 : scanCanonicalize (H12AffineFastState.compose env39848 (packedSelected [0,1,4] rootPS)) = affineNative (2^(6+1) ^^^ 36) := by decide +kernel

theorem selectedBound39848 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env39849 : List Nat := [2,4,8,16,32,58,36,62,6,47,45,1,50,0,0,35,42,6,5,1,0,61,16,50,53,16,0,0,0,29,63,59,63,16,42,44]

theorem envBound39849 : H12AffineFastState.Bounded env39849 := by
  intro p hp
  have h : env39849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39848_39849 : H12AffineEnvironment.transform 6 36 env39848 = env39849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 36 env39848 == env39849) = true)

theorem identity39849 : scanCanonicalize (H12AffineFastState.compose env39849 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound39849 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env39850 : List Nat := [2,4,8,16,13,23,9,19,6,2,0,1,31,0,0,14,7,6,5,1,0,16,16,31,24,16,0,0,0,29,18,22,18,16,7,1]

theorem envBound39850 : H12AffineFastState.Bounded env39850 := by
  intro p hp
  have h : env39850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39849_39850 : H12AffineEnvironment.transform 4 13 env39849 = env39850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env39849 == env39850) = true)

theorem identity39850 : scanCanonicalize (H12AffineFastState.compose env39850 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound39850 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39851 : List Nat := [2,4,8,11,13,12,9,8,6,2,0,1,4,0,0,14,7,6,5,1,0,11,11,4,3,11,0,0,0,6,9,13,9,11,7,1]

theorem envBound39851 : H12AffineFastState.Bounded env39851 := by
  intro p hp
  have h : env39851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39850_39851 : H12AffineEnvironment.transform 3 11 env39850 = env39851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env39850 == env39851) = true)

def env39852 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16465,262144,95614,32769,4097,61648,17,284032,86519,94527,77841,1296,74814,96346,381313,365717,257,16401,1345,95102]

theorem envBound39852 : H12AffineFastState.Bounded env39852 := by
  intro p hp
  have h : env39852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39780_39852 : H12AffineEnvironment.transform 16 16465 env39780 = env39852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16465 env39780 == env39852) = true)

def env39853 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1345,262144,77934,32769,4097,46528,17,266384,70887,78895,77841,1296,74814,81226,365713,365717,257,1281,1345,79470]

theorem envBound39853 : H12AffineFastState.Bounded env39853 := by
  intro p hp
  have h : env39853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39852_39853 : H12AffineEnvironment.transform 13 1296 env39852 = env39853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env39852 == env39853) = true)

theorem identity39853 : scanCanonicalize (H12AffineFastState.compose env39853 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound39853 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env39854 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1345,262144,77934,13341,4097,476,17,266384,70887,78895,77841,1296,74814,81226,336013,336009,257,1281,1345,79470]

theorem envBound39854 : H12AffineFastState.Bounded env39854 := by
  intro p hp
  have h : env39854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39853_39854 : H12AffineEnvironment.transform 14 13340 env39853 = env39854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env39853 == env39854) = true)

def env39855 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1345,65664,77934,13341,4097,476,17,69648,70887,78895,77841,1296,74814,81226,8205,8201,257,1281,1345,79470]

theorem envBound39855 : H12AffineFastState.Bounded env39855 := by
  intro p hp
  have h : env39855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39854_39855 : H12AffineEnvironment.transform 17 65664 env39854 = env39855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env39854 == env39855) = true)

theorem identity39855 : scanCanonicalize (H12AffineFastState.compose env39855 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 311) := by decide +kernel

theorem selectedBound39855 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env39856 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,311,1345,439,12633,13341,4097,476,17,4391,5584,13592,12582,1296,9481,15485,8205,8201,257,1281,1345,14169]

theorem envBound39856 : H12AffineFastState.Bounded env39856 := by
  intro p hp
  have h : env39856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39855_39856 : H12AffineEnvironment.transform 15 311 env39855 = env39856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 311 env39855 == env39856) = true)

def env39857 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,24,1296,5124,311,1345,439,4417,5125,4097,476,17,4391,5584,5376,4414,1296,1297,7269,21,17,257,1281,1345,5953]

theorem envBound39857 : H12AffineFastState.Bounded env39857 := by
  intro p hp
  have h : env39857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39856_39857 : H12AffineEnvironment.transform 12 24 env39856 = env39857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env39856 == env39857) = true)

theorem identity39857 : scanCanonicalize (H12AffineFastState.compose env39857 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound39857 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env39858 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,4096,24,277,4097,311,324,439,4417,4096,4097,476,17,4391,4565,4357,4414,277,276,6240,21,17,257,260,324,4932]

theorem envBound39858 : H12AffineFastState.Bounded env39858 := by
  intro p hp
  have h : env39858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39857_39858 : H12AffineEnvironment.transform 9 5 env39857 = env39858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env39857 == env39858) = true)

theorem identity39858 : scanCanonicalize (H12AffineFastState.compose env39858 (packedSelected [3,4,9,10,13,17,18,19,20,23,24] rootPS)) = affineNative (2^(11+1) ^^^ 2195) := by decide +kernel

theorem selectedBound39858 : packedSelected [3,4,9,10,13,17,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env39859 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,2195,24,277,2194,311,324,439,2514,2195,2194,476,17,2484,2374,2454,2477,277,276,243,21,17,257,260,324,3031]

theorem envBound39859 : H12AffineFastState.Bounded env39859 := by
  intro p hp
  have h : env39859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39858_39859 : H12AffineEnvironment.transform 11 2195 env39858 = env39859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2195 env39858 == env39859) = true)

theorem identity39859 : scanCanonicalize (H12AffineFastState.compose env39859 (packedSelected [1,2,3,4,5,8,9,12,15,16,17] rootPS)) = affineNative (2^(10+1) ^^^ 831) := by decide +kernel

theorem selectedBound39859 : packedSelected [1,2,3,4,5,8,9,12,15,16,17] rootPS < 2^1333 := by decide +kernel

def env39860 : List Nat := [2,4,8,16,32,64,128,256,512,5,831,940,24,277,941,311,324,439,749,940,941,476,17,651,633,681,658,277,276,243,21,17,257,260,324,232]

theorem envBound39860 : H12AffineFastState.Bounded env39860 := by
  intro p hp
  have h : env39860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39859_39860 : H12AffineEnvironment.transform 10 831 env39859 = env39860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 831 env39859 == env39860) = true)

theorem identity39860 : scanCanonicalize (H12AffineFastState.compose env39860 (packedSelected [5,8,10,12,13,15,16,18] rootPS)) = affineNative (2^(8+1) ^^^ 74) := by decide +kernel

theorem selectedBound39860 : packedSelected [5,8,10,12,13,15,16,18] rootPS < 2^1333 := by decide +kernel

def env39861 : List Nat := [2,4,8,16,32,64,128,256,74,5,373,486,24,277,487,311,324,439,167,486,487,476,17,193,51,227,216,277,276,243,21,17,257,260,324,232]

theorem envBound39861 : H12AffineFastState.Bounded env39861 := by
  intro p hp
  have h : env39861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39860_39861 : H12AffineEnvironment.transform 8 74 env39860 = env39861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 74 env39860 == env39861) = true)

theorem identity39861 : scanCanonicalize (H12AffineFastState.compose env39861 (packedSelected [2,3,4,5,9,10,12,13] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound39861 : packedSelected [2,3,4,5,9,10,12,13] rootPS < 2^1333 := by decide +kernel

def env39862 : List Nat := [2,4,8,16,32,64,19,256,74,5,373,373,24,277,372,311,324,292,52,373,372,335,17,82,51,112,75,277,276,96,21,17,257,260,324,123]

theorem envBound39862 : H12AffineFastState.Bounded env39862 := by
  intro p hp
  have h : env39862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39861_39862 : H12AffineEnvironment.transform 6 19 env39861 = env39862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env39861 == env39862) = true)

theorem identity39862 : scanCanonicalize (H12AffineFastState.compose env39862 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound39862 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env39863 : List Nat := [2,4,8,16,32,64,19,117,74,5,0,0,24,96,1,66,49,81,52,0,1,58,17,82,51,112,75,96,97,96,21,17,116,113,49,123]

theorem envBound39863 : H12AffineFastState.Bounded env39863 := by
  intro p hp
  have h : env39863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39862_39863 : H12AffineEnvironment.transform 7 117 env39862 = env39863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env39862 == env39863) = true)

theorem identity39863 : scanCanonicalize (H12AffineFastState.compose env39863 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound39863 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39864 : List Nat := [2,4,8,16,32,59,19,14,49,5,0,0,24,27,1,57,49,42,52,0,1,58,17,41,51,11,48,27,26,27,21,17,15,10,49,0]

theorem envBound39864 : H12AffineFastState.Bounded env39864 := by
  intro p hp
  have h : env39864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39863_39864 : H12AffineEnvironment.transform 5 59 env39863 = env39864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env39863 == env39864) = true)

theorem identity39864 : scanCanonicalize (H12AffineFastState.compose env39864 (packedSelected [1,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound39864 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env39865 : List Nat := [2,4,8,16,17,10,19,14,0,5,0,0,24,27,1,8,0,27,5,0,1,11,17,24,2,11,1,27,26,27,21,17,15,10,0,0]

theorem envBound39865 : H12AffineFastState.Bounded env39865 := by
  intro p hp
  have h : env39865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39864_39865 : H12AffineEnvironment.transform 4 17 env39864 = env39865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env39864 == env39865) = true)

theorem identity39865 : scanCanonicalize (H12AffineFastState.compose env39865 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound39865 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env39866 : List Nat := [2,4,8,11,10,10,8,14,0,5,0,0,3,0,1,8,0,0,5,0,1,11,10,3,2,11,1,0,1,0,14,10,15,10,0,0]

theorem envBound39866 : H12AffineFastState.Bounded env39866 := by
  intro p hp
  have h : env39866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39865_39866 : H12AffineEnvironment.transform 3 11 env39865 = env39866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env39865 == env39866) = true)

theorem identity39866 : scanCanonicalize (H12AffineFastState.compose env39866 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound39866 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39867 : List Nat := [2,4,4,7,6,6,4,2,0,5,0,0,3,0,1,4,0,0,5,0,1,7,6,3,2,7,1,0,1,0,2,6,3,6,0,0]

theorem envBound39867 : H12AffineFastState.Bounded env39867 := by
  intro p hp
  have h : env39867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39866_39867 : H12AffineEnvironment.transform 2 4 env39866 = env39867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env39866 == env39867) = true)

def env39868 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,25,1296,5125,311,1345,439,4416,5124,4097,476,17,4391,5584,5377,4415,1296,1296,7268,20,16,257,1281,1345,5952]

theorem envBound39868 : H12AffineFastState.Bounded env39868 := by
  intro p hp
  have h : env39868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39856_39868 : H12AffineEnvironment.transform 12 25 env39856 = env39868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env39856 == env39868) = true)

theorem identity39868 : scanCanonicalize (H12AffineFastState.compose env39868 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound39868 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env39869 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,25,80,4421,311,1,439,4416,4420,4097,476,17,4391,4240,4161,4415,80,80,6436,20,16,257,65,1,4608]

theorem envBound39869 : H12AffineFastState.Bounded env39869 := by
  intro p hp
  have h : env39869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39868_39869 : H12AffineEnvironment.transform 9 320 env39868 = env39869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env39868 == env39869) = true)

theorem identity39869 : scanCanonicalize (H12AffineFastState.compose env39869 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(10+1) ^^^ 318) := by decide +kernel

theorem selectedBound39869 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env39870 : List Nat := [2,4,8,16,32,64,128,256,512,320,318,4096,25,80,4421,311,1,439,4416,4420,4097,476,17,4391,4240,4161,4415,80,80,4122,20,16,257,65,1,4608]

theorem envBound39870 : H12AffineFastState.Bounded env39870 := by
  intro p hp
  have h : env39870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39869_39870 : H12AffineEnvironment.transform 10 318 env39869 = env39870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 318 env39869 == env39870) = true)

theorem identity39870 : scanCanonicalize (H12AffineFastState.compose env39870 (packedSelected [1,3,10,11,16] rootPS)) = affineNative (2^(11+1) ^^^ 1020) := by decide +kernel

theorem selectedBound39870 : packedSelected [1,3,10,11,16] rootPS < 2^1333 := by decide +kernel

def env39871 : List Nat := [2,4,8,16,32,64,128,256,512,320,318,1020,25,80,697,311,1,439,700,696,1021,476,17,731,876,957,707,80,80,998,20,16,257,65,1,508]

theorem envBound39871 : H12AffineFastState.Bounded env39871 := by
  intro p hp
  have h : env39871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39870_39871 : H12AffineEnvironment.transform 11 1020 env39870 = env39871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1020 env39870 == env39871) = true)

theorem identity39871 : scanCanonicalize (H12AffineFastState.compose env39871 (packedSelected [3,8,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 134) := by decide +kernel

theorem selectedBound39871 : packedSelected [3,8,10,12] rootPS < 2^1333 := by decide +kernel

def env39872 : List Nat := [2,4,8,16,32,64,128,134,512,198,184,634,25,80,697,177,1,49,700,696,635,90,17,731,746,571,707,80,80,608,20,16,135,65,1,122]

theorem envBound39872 : H12AffineFastState.Bounded env39872 := by
  intro p hp
  have h : env39872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39871_39872 : H12AffineEnvironment.transform 7 134 env39871 = env39872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 134 env39871 == env39872) = true)

theorem identity39872 : scanCanonicalize (H12AffineFastState.compose env39872 (packedSelected [3,4,5,9,10,11,13] rootPS)) = affineNative (2^(8+1) ^^^ 232) := by decide +kernel

theorem selectedBound39872 : packedSelected [3,4,5,9,10,11,13] rootPS < 2^1333 := by decide +kernel

def env39873 : List Nat := [2,4,8,16,32,64,128,134,232,198,184,146,25,80,81,177,1,49,84,80,147,90,17,51,2,211,43,80,80,136,20,16,135,65,1,122]

theorem envBound39873 : H12AffineFastState.Bounded env39873 := by
  intro p hp
  have h : env39873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39872_39873 : H12AffineEnvironment.transform 8 232 env39872 = env39873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 232 env39872 == env39873) = true)

theorem identity39873 : scanCanonicalize (H12AffineFastState.compose env39873 (packedSelected [2,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 114) := by decide +kernel

theorem selectedBound39873 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env39874 : List Nat := [2,4,8,16,32,64,114,116,26,52,74,96,25,80,81,67,1,49,84,80,97,90,17,51,2,33,43,80,80,122,20,16,117,65,1,122]

theorem envBound39874 : H12AffineFastState.Bounded env39874 := by
  intro p hp
  have h : env39874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39873_39874 : H12AffineEnvironment.transform 6 114 env39873 = env39874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 114 env39873 == env39874) = true)

theorem identity39874 : scanCanonicalize (H12AffineFastState.compose env39874 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound39874 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env39875 : List Nat := [2,4,8,16,32,58,8,14,26,52,48,26,25,42,43,57,1,49,46,42,27,32,17,51,2,33,43,42,42,0,20,16,15,59,1,0]

theorem envBound39875 : H12AffineFastState.Bounded env39875 := by
  intro p hp
  have h : env39875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39874_39875 : H12AffineEnvironment.transform 5 58 env39874 = env39875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env39874 == env39875) = true)

theorem identity39875 : scanCanonicalize (H12AffineFastState.compose env39875 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound39875 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env39876 : List Nat := [2,4,8,16,10,16,8,14,26,30,26,26,25,0,1,19,1,27,4,0,27,10,17,25,2,11,1,0,0,0,20,16,15,17,1,0]

theorem envBound39876 : H12AffineFastState.Bounded env39876 := by
  intro p hp
  have h : env39876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39875_39876 : H12AffineEnvironment.transform 4 10 env39875 = env39876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env39875 == env39876) = true)

theorem identity39876 : scanCanonicalize (H12AffineFastState.compose env39876 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound39876 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39877 : List Nat := [2,3,8,16,10,16,8,9,26,25,26,26,25,0,1,19,1,27,3,0,27,10,17,25,2,11,1,0,0,0,19,16,8,17,1,0]

theorem envBound39877 : H12AffineFastState.Bounded env39877 := by
  intro p hp
  have h : env39877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39876_39877 : H12AffineEnvironment.transform 1 3 env39876 = env39877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env39876 == env39877) = true)

theorem identity39877 : scanCanonicalize (H12AffineFastState.compose env39877 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound39877 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39878 : List Nat := [2,3,8,10,10,10,8,9,0,3,0,0,3,0,1,9,1,1,3,0,1,10,11,3,2,11,1,0,0,0,9,10,8,11,1,0]

theorem envBound39878 : H12AffineFastState.Bounded env39878 := by
  intro p hp
  have h : env39878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39877_39878 : H12AffineEnvironment.transform 3 10 env39877 = env39878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env39877 == env39878) = true)

def env39879 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,1345,65665,77934,13341,4097,476,17,69649,70887,78895,77841,1296,74814,81226,8204,8200,257,1281,1345,79470]

theorem envBound39879 : H12AffineFastState.Bounded env39879 := by
  intro p hp
  have h : env39879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39854_39879 : H12AffineEnvironment.transform 17 65665 env39854 = env39879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env39854 == env39879) = true)

theorem identity39879 : scanCanonicalize (H12AffineFastState.compose env39879 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5238) := by decide +kernel

theorem selectedBound39879 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env39880 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,5238,1345,5367,9240,13341,4097,476,17,1127,145,8281,9319,1296,12360,10556,8204,8200,257,1281,1345,8728]

theorem envBound39880 : H12AffineFastState.Bounded env39880 := by
  intro p hp
  have h : env39880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39879_39880 : H12AffineEnvironment.transform 15 5238 env39879 = env39880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5238 env39879 == env39880) = true)

def env39881 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,1296,13340,5158,1297,5287,9240,13341,4097,396,17,1079,145,8201,9271,1296,12312,10556,8204,8200,257,1281,1297,8728]

theorem envBound39881 : H12AffineFastState.Bounded env39881 := by
  intro p hp
  have h : env39881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39880_39881 : H12AffineEnvironment.transform 5 16 env39880 = env39881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env39880 == env39881) = true)

theorem identity39881 : scanCanonicalize (H12AffineFastState.compose env39881 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 4364) := by decide +kernel

theorem selectedBound39881 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env39882 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,4364,1296,1296,5158,1297,5287,5396,1297,4097,396,17,1079,145,4357,5435,1296,276,6192,4352,4356,257,1281,1297,4884]

theorem envBound39882 : H12AffineFastState.Bounded env39882 := by
  intro p hp
  have h : env39882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39881_39882 : H12AffineEnvironment.transform 12 4364 env39881 = env39882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4364 env39881 == env39882) = true)

theorem identity39882 : scanCanonicalize (H12AffineFastState.compose env39882 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound39882 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env39883 : List Nat := [2,4,8,16,32,16,128,256,512,5,2048,4096,4364,277,277,4131,276,4258,4369,276,4097,396,17,50,145,4357,4414,277,276,6192,4352,4356,257,260,276,4884]

theorem envBound39883 : H12AffineFastState.Bounded env39883 := by
  intro p hp
  have h : env39883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39882_39883 : H12AffineEnvironment.transform 9 5 env39882 = env39883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env39882 == env39883) = true)

theorem identity39883 : scanCanonicalize (H12AffineFastState.compose env39883 (packedSelected [0,2,3,7,8,10,12,15,17,18,19] rootPS)) = affineNative (2^(8+1) ^^^ 438) := by decide +kernel

theorem selectedBound39883 : packedSelected [0,2,3,7,8,10,12,15,17,18,19] rootPS < 2^1333 := by decide +kernel

def env39884 : List Nat := [2,4,8,16,32,16,128,256,438,5,2048,4096,4364,277,277,4131,276,4258,4369,276,4097,396,17,50,145,4357,4414,277,276,6192,4352,4356,257,260,276,4258]

theorem envBound39884 : H12AffineFastState.Bounded env39884 := by
  intro p hp
  have h : env39884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39883_39884 : H12AffineEnvironment.transform 8 438 env39883 = env39884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 438 env39883 == env39884) = true)

theorem identity39884 : scanCanonicalize (H12AffineFastState.compose env39884 (packedSelected [2,3,5,12,13,15,17] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound39884 : packedSelected [2,3,5,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env39885 : List Nat := [2,4,8,16,32,16,34,256,276,5,2048,4096,4364,277,277,4131,276,4096,4369,276,4097,302,17,50,51,4357,4414,277,276,6192,4352,4356,257,260,276,4096]

theorem envBound39885 : H12AffineFastState.Bounded env39885 := by
  intro p hp
  have h : env39885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39884_39885 : H12AffineEnvironment.transform 6 34 env39884 = env39885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env39884 == env39885) = true)

theorem identity39885 : scanCanonicalize (H12AffineFastState.compose env39885 (packedSelected [0,2,5,7,8,11,13] rootPS)) = affineNative (2^(11+1) ^^^ 2325) := by decide +kernel

theorem selectedBound39885 : packedSelected [0,2,5,7,8,11,13] rootPS < 2^1333 := by decide +kernel

def env39886 : List Nat := [2,4,8,16,32,16,34,256,276,5,2048,2325,2073,277,277,2358,276,2325,2052,276,2324,302,17,50,51,2064,2091,277,276,293,2069,2065,257,260,276,2325]

theorem envBound39886 : H12AffineFastState.Bounded env39886 := by
  intro p hp
  have h : env39886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39885_39886 : H12AffineEnvironment.transform 11 2325 env39885 = env39886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2325 env39885 == env39886) = true)

theorem identity39886 : scanCanonicalize (H12AffineFastState.compose env39886 (packedSelected [3,5,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound39886 : packedSelected [3,5,7,9] rootPS < 2^1333 := by decide +kernel

def env39887 : List Nat := [2,4,8,16,32,16,34,256,276,5,49,292,40,277,277,263,276,292,53,276,293,302,17,50,51,33,26,277,276,293,36,32,257,260,276,292]

theorem envBound39887 : H12AffineFastState.Bounded env39887 := by
  intro p hp
  have h : env39887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39886_39887 : H12AffineEnvironment.transform 10 49 env39886 = env39887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env39886 == env39887) = true)

theorem identity39887 : scanCanonicalize (H12AffineFastState.compose env39887 (packedSelected [1,2,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound39887 : packedSelected [1,2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env39888 : List Nat := [2,4,8,16,32,16,34,20,0,5,49,48,40,1,1,19,0,48,53,0,49,58,17,50,51,33,26,1,0,49,36,32,21,16,0,48]

theorem envBound39888 : H12AffineFastState.Bounded env39888 := by
  intro p hp
  have h : env39888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39887_39888 : H12AffineEnvironment.transform 7 20 env39887 = env39888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env39887 == env39888) = true)

theorem identity39888 : scanCanonicalize (H12AffineFastState.compose env39888 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound39888 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39889 : List Nat := [2,4,8,10,32,10,34,14,0,5,43,42,40,1,1,9,0,42,47,0,43,32,11,40,41,33,0,1,0,43,36,32,15,10,0,42]

theorem envBound39889 : H12AffineFastState.Bounded env39889 := by
  intro p hp
  have h : env39889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39888_39889 : H12AffineEnvironment.transform 3 10 env39888 = env39889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env39888 == env39889) = true)

def env39890 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1296,13340,5159,1296,5286,9240,13341,4097,397,17,1078,145,8200,9270,1296,12313,10556,8204,8200,257,1281,1296,8728]

theorem envBound39890 : H12AffineFastState.Bounded env39890 := by
  intro p hp
  have h : env39890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39880_39890 : H12AffineEnvironment.transform 5 17 env39880 = env39890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39880 == env39890) = true)

theorem identity39890 : scanCanonicalize (H12AffineFastState.compose env39890 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound39890 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env39891 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,276,8192,1296,9480,1331,1296,1458,9240,9481,277,397,17,1078,145,8200,9270,1296,8461,10556,8204,8200,257,1281,1296,8728]

theorem envBound39891 : H12AffineFastState.Bounded env39891 := by
  intro p hp
  have h : env39891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39890_39891 : H12AffineEnvironment.transform 11 276 env39890 = env39891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env39890 == env39891) = true)

theorem identity39891 : scanCanonicalize (H12AffineFastState.compose env39891 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound39891 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env39892 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,276,1053,1296,277,1331,1296,1458,5,276,277,397,17,1078,145,1045,43,1296,1296,3361,1041,1045,257,1281,1296,1541]

theorem envBound39892 : H12AffineFastState.Bounded env39892 := by
  intro p hp
  have h : env39892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39891_39892 : H12AffineEnvironment.transform 12 1053 env39891 = env39892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env39891 == env39892) = true)

theorem identity39892 : scanCanonicalize (H12AffineFastState.compose env39892 (packedSelected [0,2,3,7,8,11,12,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 184) := by decide +kernel

theorem selectedBound39892 : packedSelected [0,2,3,7,8,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env39893 : List Nat := [2,4,8,16,32,17,128,256,512,1024,184,276,1053,1296,277,1331,1296,1458,5,276,277,397,17,1078,145,1045,43,1296,1296,1433,1041,1045,257,1281,1296,1541]

theorem envBound39893 : H12AffineFastState.Bounded env39893 := by
  intro p hp
  have h : env39893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39892_39893 : H12AffineEnvironment.transform 10 184 env39892 = env39893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 184 env39892 == env39893) = true)

theorem identity39893 : scanCanonicalize (H12AffineFastState.compose env39893 (packedSelected [1,2,8,10,15] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound39893 : packedSelected [1,2,8,10,15] rootPS < 2^1333 := by decide +kernel

def env39894 : List Nat := [2,4,8,16,32,17,128,256,276,1024,184,276,1053,1296,277,1331,1296,1458,5,276,277,397,17,1078,145,1045,43,1296,1296,1433,1041,1045,257,1281,1296,1297]

theorem envBound39894 : H12AffineFastState.Bounded env39894 := by
  intro p hp
  have h : env39894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39893_39894 : H12AffineEnvironment.transform 8 276 env39893 = env39894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env39893 == env39894) = true)

theorem identity39894 : scanCanonicalize (H12AffineFastState.compose env39894 (packedSelected [2,5,8,11,13,18] rootPS)) = affineNative (2^(7+1) ^^^ 183) := by decide +kernel

theorem selectedBound39894 : packedSelected [2,5,8,11,13,18] rootPS < 2^1333 := by decide +kernel

def env39895 : List Nat := [2,4,8,16,32,17,128,183,163,1024,184,163,1053,1191,162,1156,1191,1029,5,163,162,58,17,1078,145,1045,43,1191,1191,1070,1041,1045,182,1206,1191,1190]

theorem envBound39895 : H12AffineFastState.Bounded env39895 := by
  intro p hp
  have h : env39895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39894_39895 : H12AffineEnvironment.transform 7 183 env39894 = env39895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 183 env39894 == env39895) = true)

theorem identity39895 : scanCanonicalize (H12AffineFastState.compose env39895 (packedSelected [2,3,4,5,9] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound39895 : packedSelected [2,3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env39896 : List Nat := [2,4,8,16,10,17,128,157,137,1024,146,137,1053,1165,136,1156,1165,1029,5,137,136,16,17,1052,145,1045,1,1165,1165,1028,1041,1045,156,1180,1165,1164]

theorem envBound39896 : H12AffineFastState.Bounded env39896 := by
  intro p hp
  have h : env39896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39895_39896 : H12AffineEnvironment.transform 4 10 env39895 = env39896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env39895 == env39896) = true)

theorem identity39896 : scanCanonicalize (H12AffineFastState.compose env39896 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 150) := by decide +kernel

theorem selectedBound39896 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env39897 : List Nat := [2,4,8,16,10,17,128,157,137,150,146,137,139,27,136,18,27,147,5,137,136,16,17,138,145,131,1,27,27,146,135,131,156,10,27,26]

theorem envBound39897 : H12AffineFastState.Bounded env39897 := by
  intro p hp
  have h : env39897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39896_39897 : H12AffineEnvironment.transform 9 150 env39896 = env39897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 150 env39896 == env39897) = true)

theorem identity39897 : scanCanonicalize (H12AffineFastState.compose env39897 (packedSelected [2,4,7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound39897 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env39898 : List Nat := [2,4,8,11,10,10,128,134,137,141,137,137,139,0,136,9,0,136,5,137,136,11,10,138,138,131,1,0,0,137,135,131,135,10,0,1]

theorem envBound39898 : H12AffineFastState.Bounded env39898 := by
  intro p hp
  have h : env39898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39897_39898 : H12AffineEnvironment.transform 3 11 env39897 = env39898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env39897 == env39898) = true)

theorem identity39898 : scanCanonicalize (H12AffineFastState.compose env39898 (packedSelected [0,1,4] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound39898 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env39899 : List Nat := [2,4,8,11,10,10,15,9,6,2,6,6,4,0,7,9,0,7,5,6,7,11,10,5,5,12,1,0,0,6,8,12,8,10,0,1]

theorem envBound39899 : H12AffineFastState.Bounded env39899 := by
  intro p hp
  have h : env39899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39898_39899 : H12AffineEnvironment.transform 6 15 env39898 = env39899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env39898 == env39899) = true)

def env39900 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1344,262144,77935,32769,4097,46529,17,266385,70886,78894,77841,1296,74814,81227,365712,365717,257,1280,1345,79471]

theorem envBound39900 : H12AffineFastState.Bounded env39900 := by
  intro p hp
  have h : env39900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39852_39900 : H12AffineEnvironment.transform 13 1297 env39852 = env39900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env39852 == env39900) = true)

theorem identity39900 : scanCanonicalize (H12AffineFastState.compose env39900 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32882) := by decide +kernel

theorem selectedBound39900 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env39901 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,32882,1344,262144,45085,32769,4097,46529,17,266385,38036,46172,45155,1296,42060,48441,267490,267495,257,1280,1345,46621]

theorem envBound39901 : H12AffineFastState.Bounded env39901 := by
  intro p hp
  have h : env39901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39900_39901 : H12AffineEnvironment.transform 15 32882 env39900 = env39901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32882 env39900 == env39901) = true)

def env39902 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32882,1344,262144,42333,32769,1345,41089,17,263633,33236,41244,42275,1296,42060,43129,262562,262567,257,1280,1345,41821]

theorem envBound39902 : H12AffineFastState.Bounded env39902 := by
  intro p hp
  have h : env39902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39901_39902 : H12AffineEnvironment.transform 11 1344 env39901 = env39902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env39901 == env39902) = true)

theorem identity39902 : scanCanonicalize (H12AffineFastState.compose env39902 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 9292) := by decide +kernel

theorem selectedBound39902 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env39903 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,9292,9278,1344,262144,273,9293,1345,1229,17,263633,9624,1360,367,1296,0,3125,262562,262567,257,1280,1345,1809]

theorem envBound39903 : H12AffineFastState.Bounded env39903 := by
  intro p hp
  have h : env39903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39902_39903 : H12AffineEnvironment.transform 14 9292 env39902 = env39903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9292 env39902 == env39903) = true)

theorem identity39903 : scanCanonicalize (H12AffineFastState.compose env39903 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound39903 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env39904 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,81,8192,0,8541,8495,81,262144,273,8540,80,476,17,262336,8329,65,367,1,0,2340,262562,262567,257,17,80,512]

theorem envBound39904 : H12AffineFastState.Bounded env39904 := by
  intro p hp
  have h : env39904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39903_39904 : H12AffineEnvironment.transform 9 273 env39903 = env39904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env39903 == env39904) = true)

theorem identity39904 : scanCanonicalize (H12AffineFastState.compose env39904 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound39904 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env39905 : List Nat := [2,4,8,16,32,64,128,68,512,85,2048,81,8192,0,8217,8299,81,262144,85,8216,80,152,17,262336,8329,65,43,1,0,2144,262374,262371,69,17,80,512]

theorem envBound39905 : H12AffineFastState.Bounded env39905 := by
  intro p hp
  have h : env39905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39904_39905 : H12AffineEnvironment.transform 7 68 env39904 = env39905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env39904 == env39905) = true)

theorem identity39905 : scanCanonicalize (H12AffineFastState.compose env39905 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 656) := by decide +kernel

theorem selectedBound39905 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env39906 : List Nat := [2,4,8,16,32,64,128,68,512,85,2048,81,656,0,649,763,81,262144,85,648,80,152,17,262336,537,65,43,1,0,2144,262374,262371,69,17,80,512]

theorem envBound39906 : H12AffineFastState.Bounded env39906 := by
  intro p hp
  have h : env39906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39905_39906 : H12AffineEnvironment.transform 12 656 env39905 = env39906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 656 env39905 == env39906) = true)

theorem identity39906 : scanCanonicalize (H12AffineFastState.compose env39906 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound39906 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env39907 : List Nat := [2,4,8,16,32,17,128,21,512,4,2048,0,656,0,649,682,0,262144,4,648,1,152,17,262289,537,16,43,1,0,2097,262327,262322,20,17,1,512]

theorem envBound39907 : H12AffineFastState.Bounded env39907 := by
  intro p hp
  have h : env39907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39906_39907 : H12AffineEnvironment.transform 5 17 env39906 = env39907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39906 == env39907) = true)

theorem identity39907 : scanCanonicalize (H12AffineFastState.compose env39907 (packedSelected [1,3,13] rootPS)) = affineNative (2^(17+1) ^^^ 26) := by decide +kernel

theorem selectedBound39907 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env39908 : List Nat := [2,4,8,16,32,17,128,21,512,4,2048,0,656,0,649,682,0,26,4,648,1,152,17,139,537,16,43,1,0,2097,173,168,20,17,1,512]

theorem envBound39908 : H12AffineFastState.Bounded env39908 := by
  intro p hp
  have h : env39908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39907_39908 : H12AffineEnvironment.transform 17 26 env39907 = env39908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 26 env39907 == env39908) = true)

theorem identity39908 : scanCanonicalize (H12AffineFastState.compose env39908 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 648) := by decide +kernel

theorem selectedBound39908 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39909 : List Nat := [2,4,8,16,32,17,128,21,512,4,648,0,656,0,649,682,0,26,4,648,1,152,17,139,537,16,43,1,0,697,173,168,20,17,1,512]

theorem envBound39909 : H12AffineFastState.Bounded env39909 := by
  intro p hp
  have h : env39909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39908_39909 : H12AffineEnvironment.transform 10 648 env39908 = env39909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 648 env39908 == env39909) = true)

theorem identity39909 : scanCanonicalize (H12AffineFastState.compose env39909 (packedSelected [0,5] rootPS)) = affineNative (2^(8+1) ^^^ 146) := by decide +kernel

theorem selectedBound39909 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env39910 : List Nat := [2,4,8,16,32,17,128,21,146,4,26,0,2,0,27,56,0,26,4,26,1,152,17,139,139,16,43,1,0,43,173,168,20,17,1,146]

theorem envBound39910 : H12AffineFastState.Bounded env39910 := by
  intro p hp
  have h : env39910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39909_39910 : H12AffineEnvironment.transform 8 146 env39909 = env39910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 146 env39909 == env39910) = true)

theorem identity39910 : scanCanonicalize (H12AffineFastState.compose env39910 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound39910 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env39911 : List Nat := [2,4,8,16,32,17,18,21,0,4,26,0,2,0,27,56,0,26,4,26,1,10,17,25,25,16,43,1,0,43,63,58,20,17,1,0]

theorem envBound39911 : H12AffineFastState.Bounded env39911 := by
  intro p hp
  have h : env39911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39910_39911 : H12AffineEnvironment.transform 6 18 env39910 = env39911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env39910 == env39911) = true)

theorem identity39911 : scanCanonicalize (H12AffineFastState.compose env39911 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound39911 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env39912 : List Nat := [2,4,8,10,32,11,8,15,0,4,0,0,2,0,1,34,0,0,4,0,1,10,11,3,3,10,43,1,0,43,37,32,14,11,1,0]

theorem envBound39912 : H12AffineFastState.Bounded env39912 := by
  intro p hp
  have h : env39912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39911_39912 : H12AffineEnvironment.transform 3 10 env39911 = env39912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env39911 == env39912) = true)

def env39913 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32882,1344,262144,42332,32769,1344,41088,17,263632,33237,41245,42274,1296,42060,43128,262563,262566,257,1280,1345,41820]

theorem envBound39913 : H12AffineFastState.Bounded env39913 := by
  intro p hp
  have h : env39913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39901_39913 : H12AffineEnvironment.transform 11 1345 env39901 = env39913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env39901 == env39913) = true)

theorem identity39913 : scanCanonicalize (H12AffineFastState.compose env39913 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 9407) := by decide +kernel

theorem selectedBound39913 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env39914 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32882,1344,9407,42332,32769,1344,41088,17,8559,33237,41245,42274,1296,42060,43128,9500,9497,257,1280,1345,41820]

theorem envBound39914 : H12AffineFastState.Bounded env39914 := by
  intro p hp
  have h : env39914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39913_39914 : H12AffineEnvironment.transform 17 9407 env39913 = env39914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 9407 env39913 == env39914) = true)

theorem identity39914 : scanCanonicalize (H12AffineFastState.compose env39914 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(12+1) ^^^ 3775) := by decide +kernel

theorem selectedBound39914 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env39915 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,3775,1297,32768,32882,1344,2560,35811,32769,1344,36415,17,4048,33237,36770,35741,1296,35571,34503,2979,2982,257,1280,1345,36323]

theorem envBound39915 : H12AffineFastState.Bounded env39915 := by
  intro p hp
  have h : env39915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39914_39915 : H12AffineEnvironment.transform 12 3775 env39914 = env39915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3775 env39914 == env39915) = true)

def env39916 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95614,32769,4097,61648,147520,284033,86519,209262,225345,148801,74814,96346,381312,513221,257,131136,1345,95102]

theorem envBound39916 : H12AffineFastState.Bounded env39916 := by
  intro p hp
  have h : env39916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39779_39916 : H12AffineEnvironment.transform 23 284033 env39779 = env39916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284033 env39779 == env39916) = true)

def env39917 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16464,262144,95614,32769,4097,61648,16,284033,86519,94526,77841,1297,74814,96346,381312,365717,257,16400,1345,95102]

theorem envBound39917 : H12AffineFastState.Bounded env39917 := by
  intro p hp
  have h : env39917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39916_39917 : H12AffineEnvironment.transform 16 16464 env39916 = env39917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16464 env39916 == env39917) = true)

def env39918 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1344,262144,77934,32769,4097,46528,16,266385,70887,78894,77841,1297,74814,81226,365712,365717,257,1280,1345,79470]

theorem envBound39918 : H12AffineFastState.Bounded env39918 := by
  intro p hp
  have h : env39918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39917_39918 : H12AffineEnvironment.transform 13 1296 env39917 = env39918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env39917 == env39918) = true)

theorem identity39918 : scanCanonicalize (H12AffineFastState.compose env39918 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32883) := by decide +kernel

theorem selectedBound39918 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env39919 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,32883,1344,262144,45085,32769,4097,46528,16,266385,38036,46173,45154,1297,42061,48441,267491,267494,257,1280,1345,46621]

theorem envBound39919 : H12AffineFastState.Bounded env39919 := by
  intro p hp
  have h : env39919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39918_39919 : H12AffineEnvironment.transform 15 32883 env39918 = env39919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32883 env39918 == env39919) = true)

def env39920 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32883,1344,262144,42333,32769,1345,41088,16,263633,33236,41245,42274,1297,42061,43129,262563,262566,257,1280,1345,41821]

theorem envBound39920 : H12AffineFastState.Bounded env39920 := by
  intro p hp
  have h : env39920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39919_39920 : H12AffineEnvironment.transform 11 1344 env39919 = env39920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env39919 == env39920) = true)

theorem identity39920 : scanCanonicalize (H12AffineFastState.compose env39920 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 325) := by decide +kernel

theorem selectedBound39920 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env39921 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,325,310,1344,262144,9240,324,1345,8645,16,263633,145,8280,9319,1297,9480,10556,262563,262566,257,1280,1345,8728]

theorem envBound39921 : H12AffineFastState.Bounded env39921 := by
  intro p hp
  have h : env39921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39920_39921 : H12AffineEnvironment.transform 14 325 env39920 = env39921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 325 env39920 == env39921) = true)

theorem identity39921 : scanCanonicalize (H12AffineFastState.compose env39921 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 2561) := by decide +kernel

theorem selectedBound39921 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env39922 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,325,310,1344,2561,9240,324,1345,8645,16,4048,145,8280,9319,1297,9480,10556,2978,2983,257,1280,1345,8728]

theorem envBound39922 : H12AffineFastState.Bounded env39922 := by
  intro p hp
  have h : env39922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39921_39922 : H12AffineEnvironment.transform 17 2561 env39921 = env39922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2561 env39921 == env39922) = true)

def env39923 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32883,1344,262144,42332,32769,1344,41089,16,263632,33237,41244,42275,1297,42061,43128,262562,262567,257,1280,1345,41820]

theorem envBound39923 : H12AffineFastState.Bounded env39923 := by
  intro p hp
  have h : env39923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39919_39923 : H12AffineEnvironment.transform 11 1345 env39919 = env39923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env39919 == env39923) = true)

theorem identity39923 : scanCanonicalize (H12AffineFastState.compose env39923 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 439) := by decide +kernel

theorem selectedBound39923 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env39924 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32883,1344,439,42332,32769,1344,41089,16,1127,33237,41244,42275,1297,42061,43128,21,16,257,1280,1345,41820]

theorem envBound39924 : H12AffineFastState.Bounded env39924 := by
  intro p hp
  have h : env39924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39923_39924 : H12AffineEnvironment.transform 17 439 env39923 = env39924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 439 env39923 == env39924) = true)

theorem identity39924 : scanCanonicalize (H12AffineFastState.compose env39924 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound39924 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env39925 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,8540,8495,1344,439,1024,8541,1344,477,16,1127,8329,64,1151,1297,1297,2340,21,16,257,1280,1345,512]

theorem envBound39925 : H12AffineFastState.Bounded env39925 := by
  intro p hp
  have h : env39925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39924_39925 : H12AffineEnvironment.transform 14 8540 env39924 = env39925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env39924 == env39925) = true)

theorem identity39925 : scanCanonicalize (H12AffineFastState.compose env39925 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 85) := by decide +kernel

theorem selectedBound39925 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env39926 : List Nat := [2,4,8,16,32,64,128,256,512,85,2048,276,8192,325,8540,8495,277,439,85,8541,277,477,16,50,8329,64,42,324,324,2340,21,16,257,341,276,512]

theorem envBound39926 : H12AffineFastState.Bounded env39926 := by
  intro p hp
  have h : env39926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39925_39926 : H12AffineEnvironment.transform 9 85 env39925 = env39926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 85 env39925 == env39926) = true)

theorem identity39926 : scanCanonicalize (H12AffineFastState.compose env39926 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 981) := by decide +kernel

theorem selectedBound39926 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env39927 : List Nat := [2,4,8,16,32,64,128,256,512,85,2048,276,981,325,649,762,277,439,85,648,277,477,16,50,860,64,42,324,324,2340,21,16,257,341,276,512]

theorem envBound39927 : H12AffineFastState.Bounded env39927 := by
  intro p hp
  have h : env39927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39926_39927 : H12AffineEnvironment.transform 12 981 env39926 = env39927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 981 env39926 == env39927) = true)

theorem identity39927 : scanCanonicalize (H12AffineFastState.compose env39927 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound39927 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env39928 : List Nat := [2,4,8,16,32,17,128,256,512,4,2048,276,900,276,649,683,277,439,4,648,277,396,16,50,781,17,42,277,277,2340,21,16,257,260,276,512]

theorem envBound39928 : H12AffineFastState.Bounded env39928 := by
  intro p hp
  have h : env39928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39927_39928 : H12AffineEnvironment.transform 5 17 env39927 = env39928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39927 == env39928) = true)

theorem identity39928 : scanCanonicalize (H12AffineFastState.compose env39928 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound39928 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env39929 : List Nat := [2,4,8,16,32,17,128,173,512,4,2048,185,553,185,649,683,184,26,4,648,184,33,16,50,672,17,42,184,184,2185,21,16,172,169,185,512]

theorem envBound39929 : H12AffineFastState.Bounded env39929 := by
  intro p hp
  have h : env39929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39928_39929 : H12AffineEnvironment.transform 7 173 env39928 = env39929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env39928 == env39929) = true)

theorem identity39929 : scanCanonicalize (H12AffineFastState.compose env39929 (packedSelected [0,1,2,4,5,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound39929 : packedSelected [0,1,2,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env39930 : List Nat := [2,4,8,16,32,17,128,173,512,4,512,185,553,185,649,683,184,26,4,648,184,33,16,50,672,17,42,184,184,649,21,16,172,169,185,512]

theorem envBound39930 : H12AffineFastState.Bounded env39930 := by
  intro p hp
  have h : env39930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39929_39930 : H12AffineEnvironment.transform 10 512 env39929 = env39930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env39929 == env39930) = true)

theorem identity39930 : scanCanonicalize (H12AffineFastState.compose env39930 (packedSelected [0,2,5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound39930 : packedSelected [0,2,5] rootPS < 2^1333 := by decide +kernel

def env39931 : List Nat := [2,4,8,16,32,17,9,36,512,4,512,48,553,48,512,546,49,26,4,513,49,33,16,50,553,17,42,49,49,512,21,16,37,32,48,512]

theorem envBound39931 : H12AffineFastState.Bounded env39931 := by
  intro p hp
  have h : env39931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39930_39931 : H12AffineEnvironment.transform 6 9 env39930 = env39931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env39930 == env39931) = true)

theorem identity39931 : scanCanonicalize (H12AffineFastState.compose env39931 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound39931 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39932 : List Nat := [2,4,8,16,17,17,9,21,512,4,512,1,536,1,512,531,0,26,4,513,0,16,16,3,536,17,27,0,0,512,21,16,20,17,1,512]

theorem envBound39932 : H12AffineFastState.Bounded env39932 := by
  intro p hp
  have h : env39932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39931_39932 : H12AffineEnvironment.transform 4 17 env39931 = env39932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env39931 == env39932) = true)

theorem identity39932 : scanCanonicalize (H12AffineFastState.compose env39932 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound39932 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39933 : List Nat := [2,4,5,16,17,17,4,21,512,4,512,1,533,1,512,531,0,23,4,513,0,16,16,3,533,17,22,0,0,512,21,16,20,17,1,512]

theorem envBound39933 : H12AffineFastState.Bounded env39933 := by
  intro p hp
  have h : env39933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39932_39933 : H12AffineEnvironment.transform 2 5 env39932 = env39933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env39932 == env39933) = true)

def env39934 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1345,262144,77935,32769,4097,46529,16,266384,70886,78895,77841,1297,74814,81227,365713,365717,257,1281,1345,79471]

theorem envBound39934 : H12AffineFastState.Bounded env39934 := by
  intro p hp
  have h : env39934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39917_39934 : H12AffineEnvironment.transform 13 1297 env39917 = env39934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env39917 == env39934) = true)

theorem identity39934 : scanCanonicalize (H12AffineFastState.compose env39934 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound39934 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env39935 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1345,262144,77935,13341,4097,477,16,266384,70886,78895,77841,1297,74814,81227,336013,336009,257,1281,1345,79471]

theorem envBound39935 : H12AffineFastState.Bounded env39935 := by
  intro p hp
  have h : env39935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39934_39935 : H12AffineEnvironment.transform 14 13340 env39934 = env39935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env39934 == env39935) = true)

def env39936 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1345,65664,77935,13341,4097,477,16,69648,70886,78895,77841,1297,74814,81227,8205,8201,257,1281,1345,79471]

theorem envBound39936 : H12AffineFastState.Bounded env39936 := by
  intro p hp
  have h : env39936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39935_39936 : H12AffineEnvironment.transform 17 65664 env39935 = env39936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env39935 == env39936) = true)

theorem identity39936 : scanCanonicalize (H12AffineFastState.compose env39936 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound39936 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env39937 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1297,9292,65536,1345,65664,73791,9293,81,477,16,65600,66742,74879,73793,1297,74814,77083,8205,8201,257,1281,1345,75327]

theorem envBound39937 : H12AffineFastState.Bounded env39937 := by
  intro p hp
  have h : env39937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39936_39937 : H12AffineEnvironment.transform 11 80 env39936 = env39937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env39936 == env39937) = true)

def env39938 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,1220,1297,136,65536,1345,65664,66811,137,81,477,16,65600,66742,65723,66693,1297,65786,68063,1225,1229,257,1281,1345,66299]

theorem envBound39938 : H12AffineFastState.Bounded env39938 := by
  intro p hp
  have h : env39938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39937_39938 : H12AffineEnvironment.transform 12 1220 env39937 = env39938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1220 env39937 == env39938) = true)

def env39939 : List Nat := [2,4,8,16,32,0,128,256,512,1024,2048,16,1156,1297,136,65536,1281,65664,66747,137,17,413,16,65536,66742,65723,66693,1297,65722,67999,1161,1165,257,1281,1281,66235]

theorem envBound39939 : H12AffineFastState.Bounded env39939 := by
  intro p hp
  have h : env39939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39938_39939 : H12AffineEnvironment.transform 5 0 env39938 = env39939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env39938 == env39939) = true)

theorem identity39939 : scanCanonicalize (H12AffineFastState.compose env39939 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 1421) := by decide +kernel

theorem selectedBound39939 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env39940 : List Nat := [2,4,8,16,32,0,128,256,512,1024,2048,16,1156,1297,136,1421,1281,1293,310,137,17,413,16,1421,315,1334,264,1297,1335,3090,1161,1165,257,1281,1281,1846]

theorem envBound39940 : H12AffineFastState.Bounded env39940 := by
  intro p hp
  have h : env39940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39939_39940 : H12AffineEnvironment.transform 15 1421 env39939 = env39940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1421 env39939 == env39940) = true)

def env39941 : List Nat := [2,4,8,0,32,0,128,256,512,1024,2048,0,1156,1281,136,1421,1281,1293,294,137,1,397,0,1421,299,1318,264,1281,1319,3074,1161,1165,257,1281,1281,1830]

theorem envBound39941 : H12AffineFastState.Bounded env39941 := by
  intro p hp
  have h : env39941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39940_39941 : H12AffineEnvironment.transform 3 0 env39940 = env39941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env39940 == env39941) = true)

theorem identity39941 : scanCanonicalize (H12AffineFastState.compose env39941 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound39941 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env39942 : List Nat := [2,4,8,0,32,0,128,5,512,1024,2048,0,1156,1028,136,1160,1028,1032,35,137,1,136,0,1160,46,1059,13,1028,1058,3074,1161,1165,4,1028,1028,1571]

theorem envBound39942 : H12AffineFastState.Bounded env39942 := by
  intro p hp
  have h : env39942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39941_39942 : H12AffineEnvironment.transform 7 5 env39941 = env39942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env39941 == env39942) = true)

theorem identity39942 : scanCanonicalize (H12AffineFastState.compose env39942 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound39942 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env39943 : List Nat := [2,4,8,0,32,0,128,5,512,5,2048,0,129,1,136,141,1,13,35,137,1,136,0,141,46,38,13,1,39,2055,140,136,4,1,1,550]

theorem envBound39943 : H12AffineFastState.Bounded env39943 := by
  intro p hp
  have h : env39943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39942_39943 : H12AffineEnvironment.transform 9 5 env39942 = env39943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env39942 == env39943) = true)

theorem identity39943 : scanCanonicalize (H12AffineFastState.compose env39943 (packedSelected [0,2,5,7,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 168) := by decide +kernel

theorem selectedBound39943 : packedSelected [0,2,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env39944 : List Nat := [2,4,8,0,32,0,128,5,512,5,168,0,129,1,136,141,1,13,35,137,1,136,0,141,46,38,13,1,39,175,140,136,4,1,1,550]

theorem envBound39944 : H12AffineFastState.Bounded env39944 := by
  intro p hp
  have h : env39944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39943_39944 : H12AffineEnvironment.transform 10 168 env39943 = env39944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 168 env39943 == env39944) = true)

theorem identity39944 : scanCanonicalize (H12AffineFastState.compose env39944 (packedSelected [0,1,7] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound39944 : packedSelected [0,1,7] rootPS < 2^1333 := by decide +kernel

def env39945 : List Nat := [2,3,8,0,32,0,128,2,512,2,168,0,129,1,136,138,1,10,35,137,1,136,0,138,41,33,10,1,32,168,139,136,3,1,1,545]

theorem envBound39945 : H12AffineFastState.Bounded env39945 := by
  intro p hp
  have h : env39945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39944_39945 : H12AffineEnvironment.transform 1 3 env39944 = env39945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env39944 == env39945) = true)

theorem identity39945 : scanCanonicalize (H12AffineFastState.compose env39945 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 168) := by decide +kernel

theorem selectedBound39945 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39946 : List Nat := [2,3,8,0,32,0,128,2,168,2,168,0,129,1,136,138,1,10,35,137,1,136,0,138,41,33,10,1,32,168,139,136,3,1,1,137]

theorem envBound39946 : H12AffineFastState.Bounded env39946 := by
  intro p hp
  have h : env39946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39945_39946 : H12AffineEnvironment.transform 8 168 env39945 = env39946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 168 env39945 == env39946) = true)

theorem identity39946 : scanCanonicalize (H12AffineFastState.compose env39946 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound39946 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env39947 : List Nat := [2,3,8,0,32,0,9,2,33,2,33,0,8,1,1,3,1,10,35,0,1,1,0,3,41,33,10,1,32,33,2,1,3,1,1,0]

theorem envBound39947 : H12AffineFastState.Bounded env39947 := by
  intro p hp
  have h : env39947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39946_39947 : H12AffineEnvironment.transform 6 9 env39946 = env39947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env39946 == env39947) = true)

theorem identity39947 : scanCanonicalize (H12AffineFastState.compose env39947 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound39947 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39948 : List Nat := [2,3,8,0,10,0,9,2,11,2,11,0,8,1,1,3,1,10,9,0,1,1,0,3,3,11,10,1,10,11,2,1,3,1,1,0]

theorem envBound39948 : H12AffineFastState.Bounded env39948 := by
  intro p hp
  have h : env39948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39947_39948 : H12AffineEnvironment.transform 4 10 env39947 = env39948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env39947 == env39948) = true)

def env39949 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,1,1156,1280,136,1421,1281,1293,295,137,0,396,1,1421,298,1319,264,1280,1318,3075,1161,1165,257,1281,1281,1831]

theorem envBound39949 : H12AffineFastState.Bounded env39949 := by
  intro p hp
  have h : env39949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39940_39949 : H12AffineEnvironment.transform 3 1 env39940 = env39949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env39940 == env39949) = true)

theorem identity39949 : scanCanonicalize (H12AffineFastState.compose env39949 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 34) := by decide +kernel

theorem selectedBound39949 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env39950 : List Nat := [2,4,8,1,32,0,128,256,512,34,2048,1,166,290,136,431,291,303,295,137,0,396,1,431,298,261,264,290,260,2081,171,175,257,291,291,773]

theorem envBound39950 : H12AffineFastState.Bounded env39950 := by
  intro p hp
  have h : env39950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39949_39950 : H12AffineEnvironment.transform 9 34 env39949 = env39950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 34 env39949 == env39950) = true)

theorem identity39950 : scanCanonicalize (H12AffineFastState.compose env39950 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 34) := by decide +kernel

theorem selectedBound39950 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env39951 : List Nat := [2,4,8,1,32,0,128,34,512,34,2048,1,166,0,136,141,1,13,5,137,0,174,1,141,8,39,42,0,38,2081,171,175,35,1,1,551]

theorem envBound39951 : H12AffineFastState.Bounded env39951 := by
  intro p hp
  have h : env39951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39950_39951 : H12AffineEnvironment.transform 7 34 env39950 = env39951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 34 env39950 == env39951) = true)

theorem identity39951 : scanCanonicalize (H12AffineFastState.compose env39951 (packedSelected [0,7,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 162) := by decide +kernel

theorem selectedBound39951 : packedSelected [0,7,10,11] rootPS < 2^1333 := by decide +kernel

def env39952 : List Nat := [2,4,8,1,32,0,128,34,512,34,162,1,166,0,136,141,1,13,5,137,0,174,1,141,8,39,42,0,38,131,171,175,35,1,1,551]

theorem envBound39952 : H12AffineFastState.Bounded env39952 := by
  intro p hp
  have h : env39952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39951_39952 : H12AffineEnvironment.transform 10 162 env39951 = env39952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 162 env39951 == env39952) = true)

theorem identity39952 : scanCanonicalize (H12AffineFastState.compose env39952 (packedSelected [0,1,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound39952 : packedSelected [0,1,4,7,9] rootPS < 2^1333 := by decide +kernel

def env39953 : List Nat := [2,4,8,1,12,0,128,14,512,14,142,1,138,0,136,141,1,13,5,137,0,130,1,141,8,11,6,0,10,131,135,131,15,1,1,523]

theorem envBound39953 : H12AffineFastState.Bounded env39953 := by
  intro p hp
  have h : env39953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39952_39953 : H12AffineEnvironment.transform 4 12 env39952 = env39953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env39952 == env39953) = true)

theorem identity39953 : scanCanonicalize (H12AffineFastState.compose env39953 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound39953 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env39954 : List Nat := [2,4,2,1,6,0,128,4,512,4,132,1,128,0,130,135,1,7,5,131,0,130,1,135,2,1,6,0,0,131,135,131,5,1,1,513]

theorem envBound39954 : H12AffineFastState.Bounded env39954 := by
  intro p hp
  have h : env39954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39953_39954 : H12AffineEnvironment.transform 2 2 env39953 = env39954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env39953 == env39954) = true)

theorem identity39954 : scanCanonicalize (H12AffineFastState.compose env39954 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 6) := by decide +kernel

theorem selectedBound39954 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39955 : List Nat := [2,4,2,1,6,0,128,4,6,4,132,1,128,0,130,135,1,7,5,131,0,130,1,135,2,1,6,0,0,131,135,131,5,1,1,7]

theorem envBound39955 : H12AffineFastState.Bounded env39955 := by
  intro p hp
  have h : env39955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39954_39955 : H12AffineEnvironment.transform 8 6 env39954 = env39955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 6 env39954 == env39955) = true)

theorem identity39955 : scanCanonicalize (H12AffineFastState.compose env39955 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound39955 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39956 : List Nat := [2,0,2,1,2,0,128,0,2,0,128,1,128,0,130,131,1,3,1,131,0,130,1,131,2,1,2,0,0,131,131,131,1,1,1,3]

theorem envBound39956 : H12AffineFastState.Bounded env39956 := by
  intro p hp
  have h : env39956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart2