import H12CloudChart2Data045

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env11222 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,4096,8,4096,32768,33167,4096,262144,1025,32768,4096,4194304,5377,5531,5521,5376,4461588,4097,4097,4196613,4116,4294967296,257,4299161632,4097,5528]

theorem envBound11222 : H12AffineFastState.Bounded env11222 := by
  intro p hp
  have h : env11222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11221_11222 : H12AffineEnvironment.transform 15 33167 env11221 = env11222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33167 env11221 == env11222) = true)

theorem identity11222 : scanCanonicalize (H12AffineFastState.compose env11222 (packedSelected [5,8,10,12,13] rootPS)) = affineNative (2^(17+1) ^^^ 40240) := by decide +kernel

theorem selectedBound11222 : packedSelected [5,8,10,12,13] rootPS < 2^1333 := by decide +kernel

def env11223 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,4096,8,4096,32768,33167,4096,40240,1025,32768,4096,4194304,5377,5531,5521,5376,4229412,4097,4097,4196613,4116,4294967296,257,4299161632,4097,5528]

theorem envBound11223 : H12AffineFastState.Bounded env11223 := by
  intro p hp
  have h : env11223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11222_11223 : H12AffineEnvironment.transform 17 40240 env11222 = env11223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 40240 env11222 == env11223) = true)

theorem identity11223 : scanCanonicalize (H12AffineFastState.compose env11223 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound11223 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env11224 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1296,8,1296,32768,33167,1296,34848,1025,32768,1296,4194304,17,139,129,16,4229412,1297,1297,4196613,1284,4294967296,257,4299161632,1297,136]

theorem envBound11224 : H12AffineFastState.Bounded env11224 := by
  intro p hp
  have h : env11224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11223_11224 : H12AffineEnvironment.transform 11 1296 env11223 = env11224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env11223 == env11224) = true)

theorem identity11224 : scanCanonicalize (H12AffineFastState.compose env11224 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 32816) := by decide +kernel

theorem selectedBound11224 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11225 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1296,8,1296,32768,33167,1296,34848,1025,32768,1296,4194304,17,139,129,16,4229412,1297,1297,4196613,1284,32816,257,4227088,1297,136]

theorem envBound11225 : H12AffineFastState.Bounded env11225 := by
  intro p hp
  have h : env11225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11224_11225 : H12AffineEnvironment.transform 31 32816 env11224 = env11225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 32816 env11224 == env11225) = true)

theorem identity11225 : scanCanonicalize (H12AffineFastState.compose env11225 (packedSelected [3] rootPS)) = affineNative (2^(14+1) ^^^ 33) := by decide +kernel

theorem selectedBound11225 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env11226 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1296,8,1296,33,430,1296,2049,1025,33,1296,4194304,17,139,129,16,4196613,1297,1297,4196613,1284,17,257,4194353,1297,136]

theorem envBound11226 : H12AffineFastState.Bounded env11226 := by
  intro p hp
  have h : env11226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11225_11226 : H12AffineEnvironment.transform 14 33 env11225 = env11226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 33 env11225 == env11226) = true)

def env11227 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,641,16384,32768,65536,4097,262144,1025,32768,4096,4194304,17665,16777216,33554432,16875797,21352448,16897044,4096,20978847,16876544,4294967296,257,4332832438,4096,33554441]

theorem envBound11227 : H12AffineFastState.Bounded env11227 := by
  intro p hp
  have h : env11227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11185_11227 : H12AffineEnvironment.transform 16 4097 env11185 = env11227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4097 env11185 == env11227) = true)

theorem identity11227 : scanCanonicalize (H12AffineFastState.compose env11227 (packedSelected [1,3,5,8,9,10,19,22] rootPS)) = affineNative (2^(24+1) ^^^ 16893076) := by decide +kernel

theorem selectedBound11227 : packedSelected [1,3,5,8,9,10,19,22] rootPS < 2^1333 := by decide +kernel

def env11228 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,641,16384,32768,65536,4097,262144,1025,32768,4096,4194304,17665,16777216,16893076,16875797,21352448,16897044,4096,20978847,16876544,4294967296,257,4315939362,4096,16893085]

theorem envBound11228 : H12AffineFastState.Bounded env11228 := by
  intro p hp
  have h : env11228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11227_11228 : H12AffineEnvironment.transform 24 16893076 env11227 = env11228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 16893076 env11227 == env11228) = true)

def env11229 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,4096,9,16384,32768,65536,4097,262144,1025,32768,4096,4194304,17665,16777216,16893076,16875797,21352448,16897044,4096,20978847,16876544,4294967296,257,4315938986,4096,16893085]

theorem envBound11229 : H12AffineFastState.Bounded env11229 := by
  intro p hp
  have h : env11229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11228_11229 : H12AffineEnvironment.transform 8 136 env11228 = env11229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env11228 == env11229) = true)

theorem identity11229 : scanCanonicalize (H12AffineFastState.compose env11229 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound11229 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env11230 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1297,9,16384,32768,65536,1296,262144,1025,32768,1297,4194304,17665,16777216,16893076,16875797,21349649,16892165,1297,20973966,16876544,4294967296,257,4315938986,1297,16893085]

theorem envBound11230 : H12AffineFastState.Bounded env11230 := by
  intro p hp
  have h : env11230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11229_11230 : H12AffineEnvironment.transform 11 1297 env11229 = env11230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env11229 == env11230) = true)

theorem identity11230 : scanCanonicalize (H12AffineFastState.compose env11230 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 1296) := by decide +kernel

theorem selectedBound11230 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env11231 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1297,9,1296,32768,65536,1296,262144,1025,32768,1297,4194304,17,16777216,16875908,16875797,21331969,16876565,1297,20973966,16876544,4294967296,257,4315938986,1297,16875917]

theorem envBound11231 : H12AffineFastState.Bounded env11231 := by
  intro p hp
  have h : env11231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11230_11231 : H12AffineEnvironment.transform 13 1296 env11230 = env11231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env11230 == env11231) = true)

theorem identity11231 : scanCanonicalize (H12AffineFastState.compose env11231 (packedSelected [1,3,4,9,12,13,15,16,17] rootPS)) = affineNative (2^(17+1) ^^^ 68014) := by decide +kernel

theorem selectedBound11231 : packedSelected [1,3,4,9,12,13,15,16,17] rootPS < 2^1333 := by decide +kernel

def env11232 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1297,9,1296,32768,65536,1296,68014,1025,32768,1297,4194304,17,16777216,16875908,16875797,21006767,16876565,1297,20973966,16876544,4294967296,257,4315938986,1297,16875917]

theorem envBound11232 : H12AffineFastState.Bounded env11232 := by
  intro p hp
  have h : env11232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11231_11232 : H12AffineEnvironment.transform 17 68014 env11231 = env11232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 68014 env11231 == env11232) = true)

theorem identity11232 : scanCanonicalize (H12AffineFastState.compose env11232 (packedSelected [0,1,3,7,12,13,15,20,21] rootPS)) = affineNative (2^(23+1) ^^^ 33166) := by decide +kernel

theorem selectedBound11232 : packedSelected [0,1,3,7,12,13,15,20,21] rootPS < 2^1333 := by decide +kernel

def env11233 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1297,9,1296,32768,65536,1296,68014,1025,32768,1297,4194304,17,33166,65546,65691,4196385,66971,1297,4229120,66958,4294967296,257,4299194660,1297,65539]

theorem envBound11233 : H12AffineFastState.Bounded env11233 := by
  intro p hp
  have h : env11233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11232_11233 : H12AffineEnvironment.transform 23 33166 env11232 = env11233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 33166 env11232 == env11233) = true)

theorem identity11233 : scanCanonicalize (H12AffineFastState.compose env11233 (packedSelected [0,1,3,7,13,20] rootPS)) = affineNative (2^(31+1) ^^^ 98703) := by decide +kernel

theorem selectedBound11233 : packedSelected [0,1,3,7,13,20] rootPS < 2^1333 := by decide +kernel

def env11234 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1297,9,1296,32768,65536,1296,68014,1025,32768,1297,4194304,17,33166,65546,65691,4196385,66971,1297,4229120,66958,98703,257,4260011,1297,65539]

theorem envBound11234 : H12AffineFastState.Bounded env11234 := by
  intro p hp
  have h : env11234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11233_11234 : H12AffineEnvironment.transform 31 98703 env11233 = env11234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 98703 env11233 == env11234) = true)

theorem identity11234 : scanCanonicalize (H12AffineFastState.compose env11234 (packedSelected [1,4,5,8,9,13,16,28] rootPS)) = affineNative (2^(14+1) ^^^ 260) := by decide +kernel

theorem selectedBound11234 : packedSelected [1,4,5,8,9,13,16,28] rootPS < 2^1333 := by decide +kernel

def env11235 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1297,9,1296,260,65536,1296,68014,1025,260,1297,4194304,17,138,65546,65691,4196385,66971,1297,4196612,66958,65675,257,4260011,1297,65539]

theorem envBound11235 : H12AffineFastState.Bounded env11235 := by
  intro p hp
  have h : env11235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11234_11235 : H12AffineEnvironment.transform 14 260 env11234 = env11235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 260 env11234 == env11235) = true)

theorem identity11235 : scanCanonicalize (H12AffineFastState.compose env11235 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 138) := by decide +kernel

theorem selectedBound11235 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env11236 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1297,9,1296,260,138,1296,2340,1025,260,1297,4194304,17,138,128,17,4196385,1297,1297,4196612,1284,1,257,4194337,1297,137]

theorem envBound11236 : H12AffineFastState.Bounded env11236 := by
  intro p hp
  have h : env11236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11235_11236 : H12AffineEnvironment.transform 15 138 env11235 = env11236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 138 env11235 == env11236) = true)

theorem identity11236 : scanCanonicalize (H12AffineFastState.compose env11236 (packedSelected [1] rootPS)) = affineNative (2^(21+1) ^^^ 293) := by decide +kernel

theorem selectedBound11236 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11237 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1297,9,1296,260,138,1296,2340,1025,260,1297,293,17,138,128,17,2308,1297,1297,2081,1284,1,257,260,1297,137]

theorem envBound11237 : H12AffineFastState.Bounded env11237 := by
  intro p hp
  have h : env11237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11236_11237 : H12AffineEnvironment.transform 21 293 env11236 = env11237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 293 env11236 == env11237) = true)

theorem identity11237 : scanCanonicalize (H12AffineFastState.compose env11237 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 397) := by decide +kernel

theorem selectedBound11237 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env11238 : List Nat := [2,4,8,16,32,17,128,256,136,1024,397,1297,9,1296,260,138,1296,169,1025,260,1297,293,17,138,128,17,137,1297,1297,428,1284,1,257,260,1297,137]

theorem envBound11238 : H12AffineFastState.Bounded env11238 := by
  intro p hp
  have h : env11238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11237_11238 : H12AffineEnvironment.transform 10 397 env11237 = env11238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 397 env11237 == env11238) = true)

theorem identity11238 : scanCanonicalize (H12AffineFastState.compose env11238 (packedSelected [5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound11238 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env11239 : List Nat := [2,4,8,16,32,17,9,256,1,1024,260,1297,9,1296,260,3,1296,32,1025,260,1297,293,17,3,9,17,0,1297,1297,293,1284,1,257,260,1297,0]

theorem envBound11239 : H12AffineFastState.Bounded env11239 := by
  intro p hp
  have h : env11239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11238_11239 : H12AffineEnvironment.transform 6 9 env11238 = env11239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11238 == env11239) = true)

theorem identity11239 : scanCanonicalize (H12AffineFastState.compose env11239 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound11239 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11240 : List Nat := [2,4,2,16,32,17,3,256,1,1024,260,1297,3,1296,260,3,1296,32,1025,260,1297,293,17,3,3,17,0,1297,1297,293,1284,1,257,260,1297,0]

theorem envBound11240 : H12AffineFastState.Bounded env11240 := by
  intro p hp
  have h : env11240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11239_11240 : H12AffineEnvironment.transform 2 2 env11239 = env11240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env11239 == env11240) = true)

theorem identity11240 : scanCanonicalize (H12AffineFastState.compose env11240 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound11240 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env11241 : List Nat := [2,4,2,16,32,17,3,53,1,1024,49,1060,3,1061,49,3,1061,32,1025,49,1060,16,17,3,3,17,0,1060,1060,16,1073,1,52,49,1060,0]

theorem envBound11241 : H12AffineFastState.Bounded env11241 := by
  intro p hp
  have h : env11241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11240_11241 : H12AffineEnvironment.transform 7 53 env11240 = env11241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env11240 == env11241) = true)

theorem identity11241 : scanCanonicalize (H12AffineFastState.compose env11241 (packedSelected [6] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound11241 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env11242 : List Nat := [2,4,2,1,32,0,3,36,1,1024,32,1060,3,1061,32,3,1061,32,1025,32,1060,1,0,3,3,0,0,1060,1060,1,1056,1,37,32,1060,0]

theorem envBound11242 : H12AffineFastState.Bounded env11242 := by
  intro p hp
  have h : env11242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11241_11242 : H12AffineEnvironment.transform 3 1 env11241 = env11242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env11241 == env11242) = true)

theorem identity11242 : scanCanonicalize (H12AffineFastState.compose env11242 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound11242 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env11243 : List Nat := [2,4,2,1,0,0,3,4,1,1024,0,1028,3,1029,0,3,1029,0,1025,0,1028,1,0,3,3,0,0,1028,1028,1,1024,1,5,0,1028,0]

theorem envBound11243 : H12AffineFastState.Bounded env11243 := by
  intro p hp
  have h : env11243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11242_11243 : H12AffineEnvironment.transform 4 0 env11242 = env11243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env11242 == env11243) = true)

def leafEnv11243 : List Nat := [2,4,2,1,0,0,3,4,1,1024,0,1028,3,1029,0,3,1029,0,1025,0,1028,1,0,3,1025,3,1,0,0,1028,1028,1,1024,1,5,0,5,3,1028,0,0,1028,1]

def active11243 : List Nat := [0,1,9]

def tree11243 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11243 : H12WitnessSearch.Good tree11243 := H12GlobalWitnessIndex.good

theorem leafIdentity11243 : H12AffineFastState.composeSystem env11243 rootObs = leafEnv11243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11243 rootObs == leafEnv11243) = true)

theorem terminalChecked11243 : H12PackedTerminal.terminalCheckFast leafEnv11243 active11243 tree11243 = true := by decide +kernel

def env11244 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,4096,8,16384,32768,65536,4097,262144,1025,32768,4096,4194304,17665,16777216,16893076,16875797,21352448,16897044,4096,20978847,16876544,4294967296,257,4315938987,4096,16893085]

theorem envBound11244 : H12AffineFastState.Bounded env11244 := by
  intro p hp
  have h : env11244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11228_11244 : H12AffineEnvironment.transform 8 137 env11228 = env11244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env11228 == env11244) = true)

theorem identity11244 : scanCanonicalize (H12AffineFastState.compose env11244 (packedSelected [6,25] rootPS)) = affineNative (2^(23+1) ^^^ 115733) := by decide +kernel

theorem selectedBound11244 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env11245 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,4096,8,16384,32768,65536,4097,262144,1025,32768,4096,4194304,17665,115733,129,17664,4461589,4097,4096,4315274,16405,4294967296,257,4299277502,4096,136]

theorem envBound11245 : H12AffineFastState.Bounded env11245 := by
  intro p hp
  have h : env11245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11244_11245 : H12AffineEnvironment.transform 23 115733 env11244 = env11245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 115733 env11244 == env11245) = true)

theorem identity11245 : scanCanonicalize (H12AffineFastState.compose env11245 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 4096) := by decide +kernel

theorem selectedBound11245 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env11246 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,4096,8,4096,32768,65536,4097,262144,1025,32768,4096,4194304,5377,103445,129,5376,4461589,4097,4096,4294794,4117,4294967296,257,4299265214,4096,136]

theorem envBound11246 : H12AffineFastState.Bounded env11246 := by
  intro p hp
  have h : env11246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11245_11246 : H12AffineEnvironment.transform 13 4096 env11245 = env11246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env11245 == env11246) = true)

def env11247 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,17665,16777216,33554432,67108864,134217728,67130625,536870912,1073741824,553878608,4294967296,537002321,4417151346,694534145,33563272]

theorem envBound11247 : H12AffineFastState.Bounded env11247 := by
  intro p hp
  have h : env11247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10090_11247 : H12AffineEnvironment.transform 34 694534145 env10090 = env11247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 694534145 env10090 == env11247) = true)

def env11248 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,17665,16777216,33554432,67108864,134217728,67130625,157794304,1073741824,140788816,4294967296,157663569,4417151346,131073,33563272]

theorem envBound11248 : H12AffineFastState.Bounded env11248 := by
  intro p hp
  have h : env11248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11247_11248 : H12AffineEnvironment.transform 28 157794304 env11247 = env11248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 157794304 env11247 == env11248) = true)

theorem identity11248 : scanCanonicalize (H12AffineFastState.compose env11248 (packedSelected [14] rootPS)) = affineNative (2^(25+1) ^^^ 2098433) := by decide +kernel

theorem selectedBound11248 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env11249 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,17665,16777216,33554432,2098433,134217728,2117632,157794304,1073741824,140788816,4294967296,157663569,4352140403,131073,33563272]

theorem envBound11249 : H12AffineFastState.Bounded env11249 := by
  intro p hp
  have h : env11249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11248_11249 : H12AffineEnvironment.transform 25 2098433 env11248 = env11249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 2098433 env11248 == env11249) = true)

def env11250 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,17665,16777216,33554432,2098433,23445584,2117632,131152,1073741824,16876544,4294967296,257,4352140403,131073,33563272]

theorem envBound11250 : H12AffineFastState.Bounded env11250 := by
  intro p hp
  have h : env11250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11249_11250 : H12AffineEnvironment.transform 26 23445584 env11249 = env11250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 23445584 env11249 == env11250) = true)

theorem identity11250 : scanCanonicalize (H12AffineFastState.compose env11250 (packedSelected [35] rootPS)) = affineNative (2^(23+1) ^^^ 230469) := by decide +kernel

theorem selectedBound11250 : packedSelected [35] rootPS < 2^1333 := by decide +kernel

def env11251 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,17665,230469,33554432,2098433,6702101,2117632,131152,1073741824,131141,4294967296,257,4335591478,131073,33563272]

theorem envBound11251 : H12AffineFastState.Bounded env11251 := by
  intro p hp
  have h : env11251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11250_11251 : H12AffineEnvironment.transform 23 230469 env11250 = env11251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 230469 env11250 == env11251) = true)

def env11252 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,10248,17665,230469,33554432,2098433,2518045,2117632,131152,1073741824,131141,4294967296,257,4331391038,131073,33563272]

theorem envBound11252 : H12AffineFastState.Bounded env11252 := by
  intro p hp
  have h : env11252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11251_11252 : H12AffineEnvironment.transform 21 10248 env11251 = env11252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10248 env11251 == env11252) = true)

def env11253 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,10248,17665,230469,8328,2098433,2518045,2117632,131152,1073741824,131141,4294967296,257,4297844918,131073,512]

theorem envBound11253 : H12AffineFastState.Bounded env11253 := by
  intro p hp
  have h : env11253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11252_11253 : H12AffineEnvironment.transform 24 8328 env11252 = env11253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8328 env11252 == env11253) = true)

theorem identity11253 : scanCanonicalize (H12AffineFastState.compose env11253 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(29+1) ^^^ 2220242) := by decide +kernel

theorem selectedBound11253 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env11254 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,10248,17665,230469,8328,2098433,2518045,2117632,131152,2220242,131141,4294967296,257,4297844918,131073,512]

theorem envBound11254 : H12AffineFastState.Bounded env11254 := by
  intro p hp
  have h : env11254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11253_11254 : H12AffineEnvironment.transform 29 2220242 env11253 = env11254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 2220242 env11253 == env11254) = true)

theorem identity11254 : scanCanonicalize (H12AffineFastState.compose env11254 (packedSelected [0,1,4,5,6,7,8,16,19,20,22,24,25,26] rootPS)) = affineNative (2^(20+1) ^^^ 57693) := by decide +kernel

theorem selectedBound11254 : packedSelected [0,1,4,5,6,7,8,16,19,20,22,24,25,26] rootPS < 2^1333 := by decide +kernel

def env11255 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,57693,10248,17665,230469,8328,58460,429376,45405,131152,65935,131141,4294967296,257,4295690731,131073,512]

theorem envBound11255 : H12AffineFastState.Bounded env11255 := by
  intro p hp
  have h : env11255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11254_11255 : H12AffineEnvironment.transform 20 57693 env11254 = env11255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 57693 env11254 == env11255) = true)

theorem identity11255 : scanCanonicalize (H12AffineFastState.compose env11255 (packedSelected [1,3,6,17,21,24,25,28] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound11255 : packedSelected [1,3,6,17,21,24,25,28] rootPS < 2^1333 := by decide +kernel

def env11256 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8461,65536,131072,262144,524288,8461,16464,10248,17665,206152,8328,17745,404557,4176,131152,65935,131141,4294967296,257,4295690731,131073,512]

theorem envBound11256 : H12AffineFastState.Bounded env11256 := by
  intro p hp
  have h : env11256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11255_11256 : H12AffineEnvironment.transform 14 8461 env11255 = env11256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env11255 == env11256) = true)

theorem identity11256 : scanCanonicalize (H12AffineFastState.compose env11256 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(16+1) ^^^ 11461) := by decide +kernel

theorem selectedBound11256 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env11257 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8461,65536,11461,262144,524288,8461,16464,10248,17665,67981,8328,17745,262280,4176,11413,65935,11392,4294967296,257,4295566638,11460,512]

theorem envBound11257 : H12AffineFastState.Bounded env11257 := by
  intro p hp
  have h : env11257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11256_11257 : H12AffineEnvironment.transform 16 11461 env11256 = env11257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 11461 env11256 == env11257) = true)

def env11258 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8461,65536,11461,2048,524288,8461,16464,10248,17665,67981,8328,17745,2184,4176,11413,65935,11392,4294967296,257,4295566638,11460,512]

theorem envBound11258 : H12AffineFastState.Bounded env11258 := by
  intro p hp
  have h : env11258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11257_11258 : H12AffineEnvironment.transform 17 2048 env11257 = env11258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2048 env11257 == env11258) = true)

def env11259 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8461,65536,11341,2048,524288,8461,16464,10248,17665,67845,8192,17745,2048,4176,11293,65799,11272,4294967296,257,4295566638,11340,512]

theorem envBound11259 : H12AffineFastState.Bounded env11259 := by
  intro p hp
  have h : env11259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11258_11259 : H12AffineEnvironment.transform 6 8 env11258 = env11259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env11258 == env11259) = true)

theorem identity11259 : scanCanonicalize (H12AffineFastState.compose env11259 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 2082) := by decide +kernel

theorem selectedBound11259 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env11260 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8461,2082,11341,2048,524288,8461,16464,10248,17665,295,8192,17745,2048,4176,11293,2341,11272,4294967296,257,4295503116,11340,512]

theorem envBound11260 : H12AffineFastState.Bounded env11260 := by
  intro p hp
  have h : env11260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11259_11260 : H12AffineEnvironment.transform 15 2082 env11259 = env11260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2082 env11259 == env11260) = true)

theorem identity11260 : scanCanonicalize (H12AffineFastState.compose env11260 (packedSelected [0,2,9] rootPS)) = affineNative (2^(31+1) ^^^ 546347) := by decide +kernel

theorem selectedBound11260 : packedSelected [0,2,9] rootPS < 2^1333 := by decide +kernel

def env11261 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8461,2082,11341,2048,524288,8461,16464,10248,17665,295,8192,17745,2048,4176,11293,2341,11272,546347,257,31527,11340,512]

theorem envBound11261 : H12AffineFastState.Bounded env11261 := by
  intro p hp
  have h : env11261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11260_11261 : H12AffineEnvironment.transform 31 546347 env11260 = env11261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 546347 env11260 == env11261) = true)

theorem identity11261 : scanCanonicalize (H12AffineFastState.compose env11261 (packedSelected [11,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound11261 : packedSelected [11,16,18] rootPS < 2^1333 := by decide +kernel

def env11262 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,8192,16384,8232,2082,11341,2048,524288,8232,16464,10248,17444,2,8192,17524,2048,4176,11293,2048,11272,546347,36,31234,11340,512]

theorem envBound11262 : H12AffineFastState.Bounded env11262 := by
  intro p hp
  have h : env11262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11261_11262 : H12AffineEnvironment.transform 7 37 env11261 = env11262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env11261 == env11262) = true)

theorem identity11262 : scanCanonicalize (H12AffineFastState.compose env11262 (packedSelected [0,1,4,5,7,10,12,22] rootPS)) = affineNative (2^(18+1) ^^^ 11305) := by decide +kernel

theorem selectedBound11262 : packedSelected [0,1,4,5,7,10,12,22] rootPS < 2^1333 := by decide +kernel

def env11263 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,8192,16384,8232,2082,11341,2048,11305,8232,16464,10248,17444,2,8192,17524,2048,4176,11293,2048,11272,31234,36,31234,11340,512]

theorem envBound11263 : H12AffineFastState.Bounded env11263 := by
  intro p hp
  have h : env11263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11262_11263 : H12AffineEnvironment.transform 18 11305 env11262 = env11263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 11305 env11262 == env11263) = true)

theorem identity11263 : scanCanonicalize (H12AffineFastState.compose env11263 (packedSelected [1,2,4,5,6,7,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 1567) := by decide +kernel

theorem selectedBound11263 : packedSelected [1,2,4,5,6,7,10,12] rootPS < 2^1333 := by decide +kernel

def env11264 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,1567,8192,16384,8232,2082,11341,2048,11305,8232,16464,10248,17444,2,8192,17524,2048,1615,11293,2048,11272,27677,36,27677,11340,512]

theorem envBound11264 : H12AffineFastState.Bounded env11264 := by
  intro p hp
  have h : env11264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11263_11264 : H12AffineEnvironment.transform 11 1567 env11263 = env11264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1567 env11263 == env11264) = true)

def env11265 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,1567,8192,1076,8232,2082,11341,2048,11305,8232,1124,10248,16,2,8192,64,2048,1615,11293,2048,11272,10281,36,10281,11340,512]

theorem envBound11265 : H12AffineFastState.Bounded env11265 := by
  intro p hp
  have h : env11265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11264_11265 : H12AffineEnvironment.transform 13 1076 env11264 = env11265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1076 env11264 == env11265) = true)

theorem identity11265 : scanCanonicalize (H12AffineFastState.compose env11265 (packedSelected [0,4,6] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound11265 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env11266 : List Nat := [2,4,8,16,32,64,8,37,512,1024,42,1567,8192,1076,8232,8,9319,42,9219,8232,1124,8226,16,2,8192,64,42,1615,9271,42,9250,8195,36,8195,9318,512]

theorem envBound11266 : H12AffineFastState.Bounded env11266 := by
  intro p hp
  have h : env11266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11265_11266 : H12AffineEnvironment.transform 10 42 env11265 = env11266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env11265 == env11266) = true)

theorem identity11266 : scanCanonicalize (H12AffineFastState.compose env11266 (packedSelected [11] rootPS)) = affineNative (2^(12+1) ^^^ 546) := by decide +kernel

theorem selectedBound11266 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env11267 : List Nat := [2,4,8,16,32,64,8,37,512,1024,42,1567,546,1076,522,8,1605,42,1569,522,1124,512,16,2,546,64,42,1615,1557,42,1536,545,36,545,1604,512]

theorem envBound11267 : H12AffineFastState.Bounded env11267 := by
  intro p hp
  have h : env11267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11266_11267 : H12AffineEnvironment.transform 12 546 env11266 = env11267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 546 env11266 == env11267) = true)

theorem identity11267 : scanCanonicalize (H12AffineFastState.compose env11267 (packedSelected [0,1,2,4,10] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound11267 : packedSelected [0,1,2,4,10] rootPS < 2^1333 := by decide +kernel

def env11268 : List Nat := [2,4,8,16,32,64,8,37,512,36,42,571,546,16,522,8,609,42,517,522,64,512,16,2,546,64,42,619,561,42,548,545,36,545,608,512]

theorem envBound11268 : H12AffineFastState.Bounded env11268 := by
  intro p hp
  have h : env11268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11267_11268 : H12AffineEnvironment.transform 9 36 env11267 = env11268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env11267 == env11268) = true)

theorem identity11268 : scanCanonicalize (H12AffineFastState.compose env11268 (packedSelected [13] rootPS)) = affineNative (2^(8+1) ^^^ 122) := by decide +kernel

theorem selectedBound11268 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env11269 : List Nat := [2,4,8,16,32,64,8,37,122,36,42,65,88,16,112,8,27,42,127,112,64,122,16,2,88,64,42,17,75,42,94,91,36,91,26,122]

theorem envBound11269 : H12AffineFastState.Bounded env11269 := by
  intro p hp
  have h : env11269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11268_11269 : H12AffineEnvironment.transform 8 122 env11268 = env11269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 122 env11268 == env11269) = true)

theorem identity11269 : scanCanonicalize (H12AffineFastState.compose env11269 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound11269 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11270 : List Nat := [2,4,8,16,32,16,8,37,42,36,42,17,8,16,32,8,27,42,47,32,16,42,16,2,8,16,42,17,27,42,14,11,36,11,26,42]

theorem envBound11270 : H12AffineFastState.Bounded env11270 := by
  intro p hp
  have h : env11270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11269_11270 : H12AffineEnvironment.transform 5 16 env11269 = env11270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env11269 == env11270) = true)

theorem identity11270 : scanCanonicalize (H12AffineFastState.compose env11270 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound11270 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11271 : List Nat := [2,4,2,16,32,16,2,37,32,36,32,17,2,16,32,2,17,32,37,32,16,32,16,2,2,16,32,17,17,32,4,1,36,1,16,32]

theorem envBound11271 : H12AffineFastState.Bounded env11271 := by
  intro p hp
  have h : env11271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11270_11271 : H12AffineEnvironment.transform 2 2 env11270 = env11271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env11270 == env11271) = true)

theorem identity11271 : scanCanonicalize (H12AffineFastState.compose env11271 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound11271 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11272 : List Nat := [2,4,2,2,32,2,2,37,32,36,32,3,2,2,32,2,3,32,37,32,2,32,2,2,2,2,32,3,3,32,4,1,36,1,2,32]

theorem envBound11272 : H12AffineFastState.Bounded env11272 := by
  intro p hp
  have h : env11272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11271_11272 : H12AffineEnvironment.transform 3 2 env11271 = env11272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env11271 == env11272) = true)

def leafEnv11272 : List Nat := [2,4,2,2,32,2,2,37,32,36,32,3,2,2,32,2,3,32,37,32,2,32,2,2,5,2,1,2,32,3,3,32,4,1,36,1,5,2,2,32,0,2,1]

def active11272 : List Nat := [0,1,4]

def tree11272 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11272 : H12WitnessSearch.Good tree11272 := H12GlobalWitnessIndex.good

theorem leafIdentity11272 : H12AffineFastState.composeSystem env11272 rootObs = leafEnv11272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11272 rootObs == leafEnv11272) = true)

theorem terminalChecked11272 : H12PackedTerminal.terminalCheckFast leafEnv11272 active11272 tree11272 = true := by decide +kernel

def env11273 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,1567,8192,1077,8232,2082,11341,2048,11305,8232,1125,10248,17,2,8192,65,2048,1615,11293,2048,11272,10280,36,10280,11340,512]

theorem envBound11273 : H12AffineFastState.Bounded env11273 := by
  intro p hp
  have h : env11273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11264_11273 : H12AffineEnvironment.transform 13 1077 env11264 = env11273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1077 env11264 == env11273) = true)

theorem identity11273 : scanCanonicalize (H12AffineFastState.compose env11273 (packedSelected [0,4,6] rootPS)) = affineNative (2^(12+1) ^^^ 83) := by decide +kernel

theorem selectedBound11273 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env11274 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,1567,83,1077,123,2082,3102,2048,3194,123,1125,2139,17,2,83,65,2048,1615,3150,2048,3163,2171,36,2171,3103,512]

theorem envBound11274 : H12AffineFastState.Bounded env11274 := by
  intro p hp
  have h : env11274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11273_11274 : H12AffineEnvironment.transform 12 83 env11273 = env11274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 83 env11273 == env11274) = true)

theorem identity11274 : scanCanonicalize (H12AffineFastState.compose env11274 (packedSelected [11] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound11274 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env11275 : List Nat := [2,4,2,16,32,64,2,37,512,1024,2048,1557,83,1077,113,2082,3092,2048,3184,113,1125,2129,17,2,83,65,2048,1605,3140,2048,3153,2161,36,2161,3093,512]

theorem envBound11275 : H12AffineFastState.Bounded env11275 := by
  intro p hp
  have h : env11275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11274_11275 : H12AffineEnvironment.transform 2 2 env11274 = env11275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env11274 == env11275) = true)

theorem identity11275 : scanCanonicalize (H12AffineFastState.compose env11275 (packedSelected [1,2,10] rootPS)) = affineNative (2^(10+1) ^^^ 1061) := by decide +kernel

theorem selectedBound11275 : packedSelected [1,2,10] rootPS < 2^1333 := by decide +kernel

def env11276 : List Nat := [2,4,2,16,32,64,2,37,512,1024,1061,1557,83,1077,113,1031,49,1061,85,113,1125,1140,17,2,83,65,1061,1605,97,1061,116,1108,36,1108,48,512]

theorem envBound11276 : H12AffineFastState.Bounded env11276 := by
  intro p hp
  have h : env11276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11275_11276 : H12AffineEnvironment.transform 10 1061 env11275 = env11276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1061 env11275 == env11276) = true)

theorem identity11276 : scanCanonicalize (H12AffineFastState.compose env11276 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound11276 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env11277 : List Nat := [2,4,2,16,32,64,2,37,512,5,32,528,83,48,113,2,49,32,85,113,96,113,17,2,83,65,32,576,97,32,116,81,36,81,48,512]

theorem envBound11277 : H12AffineFastState.Bounded env11277 := by
  intro p hp
  have h : env11277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11276_11277 : H12AffineEnvironment.transform 9 5 env11276 = env11277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env11276 == env11277) = true)

def env11278 : List Nat := [2,4,2,16,32,64,2,37,0,5,32,16,83,48,113,2,49,32,85,113,96,113,17,2,83,65,32,64,97,32,116,81,36,81,48,0]

theorem envBound11278 : H12AffineFastState.Bounded env11278 := by
  intro p hp
  have h : env11278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11277_11278 : H12AffineEnvironment.transform 8 0 env11277 = env11278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env11277 == env11278) = true)

theorem identity11278 : scanCanonicalize (H12AffineFastState.compose env11278 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound11278 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11279 : List Nat := [2,4,2,16,32,17,2,37,0,5,32,16,2,48,32,2,49,32,4,32,49,32,17,2,2,16,32,17,48,32,37,0,36,0,48,0]

theorem envBound11279 : H12AffineFastState.Bounded env11279 := by
  intro p hp
  have h : env11279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11278_11279 : H12AffineEnvironment.transform 5 17 env11278 = env11279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env11278 == env11279) = true)

theorem identity11279 : scanCanonicalize (H12AffineFastState.compose env11279 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound11279 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11280 : List Nat := [2,4,2,2,32,3,2,37,0,5,32,2,2,34,32,2,35,32,4,32,35,32,3,2,2,2,32,3,34,32,37,0,36,0,34,0]

theorem envBound11280 : H12AffineFastState.Bounded env11280 := by
  intro p hp
  have h : env11280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11279_11280 : H12AffineEnvironment.transform 3 2 env11279 = env11280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env11279 == env11280) = true)

theorem identity11280 : scanCanonicalize (H12AffineFastState.compose env11280 (packedSelected [13] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound11280 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env11281 : List Nat := [2,4,2,2,1,3,2,4,0,5,1,2,2,3,1,2,2,1,4,1,2,1,3,2,2,2,1,3,3,1,4,0,5,0,3,0]

theorem envBound11281 : H12AffineFastState.Bounded env11281 := by
  intro p hp
  have h : env11281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11280_11281 : H12AffineEnvironment.transform 4 1 env11280 = env11281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env11280 == env11281) = true)

def leafEnv11281 : List Nat := [2,4,2,2,1,3,2,4,0,5,1,2,2,3,1,2,2,1,4,1,2,1,3,2,5,2,1,2,1,3,3,1,4,0,5,0,5,2,3,0,0,2,1]

def active11281 : List Nat := [0,1]

def tree11281 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11281 : H12WitnessSearch.Good tree11281 := H12GlobalWitnessIndex.good

theorem leafIdentity11281 : H12AffineFastState.composeSystem env11281 rootObs = leafEnv11281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11281 rootObs == leafEnv11281) = true)

theorem terminalChecked11281 : H12PackedTerminal.terminalCheckFast leafEnv11281 active11281 tree11281 = true := by decide +kernel

def env11282 : List Nat := [2,4,2,16,32,64,2,37,1,5,32,17,83,48,113,2,49,32,85,113,96,113,17,2,83,65,32,65,97,32,116,81,36,81,48,1]

theorem envBound11282 : H12AffineFastState.Bounded env11282 := by
  intro p hp
  have h : env11282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11277_11282 : H12AffineEnvironment.transform 8 1 env11277 = env11282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env11277 == env11282) = true)

theorem identity11282 : scanCanonicalize (H12AffineFastState.compose env11282 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound11282 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11283 : List Nat := [2,4,2,16,32,49,2,37,1,5,32,17,34,48,0,2,49,32,36,0,17,0,17,2,34,48,32,48,16,32,5,32,36,32,48,1]

theorem envBound11283 : H12AffineFastState.Bounded env11283 := by
  intro p hp
  have h : env11283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11282_11283 : H12AffineEnvironment.transform 5 49 env11282 = env11283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env11282 == env11283) = true)

def env11284 : List Nat := [2,4,2,16,0,17,2,5,1,5,0,17,2,16,0,2,17,0,4,0,17,0,17,2,2,16,0,16,16,0,5,0,4,0,16,1]

theorem envBound11284 : H12AffineFastState.Bounded env11284 := by
  intro p hp
  have h : env11284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11283_11284 : H12AffineEnvironment.transform 4 0 env11283 = env11284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env11283 == env11284) = true)

theorem identity11284 : scanCanonicalize (H12AffineFastState.compose env11284 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound11284 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11285 : List Nat := [2,4,2,3,0,2,2,5,1,5,0,2,2,3,0,2,2,0,4,0,2,0,2,2,2,3,0,3,3,0,5,0,4,0,3,1]

theorem envBound11285 : H12AffineFastState.Bounded env11285 := by
  intro p hp
  have h : env11285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11284_11285 : H12AffineEnvironment.transform 3 3 env11284 = env11285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env11284 == env11285) = true)

def leafEnv11285 : List Nat := [2,4,2,3,0,2,2,5,1,5,0,2,2,3,0,2,2,0,4,0,2,0,2,2,4,2,1,3,0,3,3,0,5,0,4,0,5,2,3,1,0,2,1]

def active11285 : List Nat := [0,1]

def tree11285 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11285 : H12WitnessSearch.Good tree11285 := H12GlobalWitnessIndex.good

theorem leafIdentity11285 : H12AffineFastState.composeSystem env11285 rootObs = leafEnv11285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11285 rootObs == leafEnv11285) = true)

theorem terminalChecked11285 : H12PackedTerminal.terminalCheckFast leafEnv11285 active11285 tree11285 = true := by decide +kernel

def env11286 : List Nat := [2,4,2,16,1,16,2,4,1,5,1,17,3,17,0,2,16,1,5,0,17,0,17,2,3,17,1,17,16,1,5,1,5,1,17,1]

theorem envBound11286 : H12AffineFastState.Bounded env11286 := by
  intro p hp
  have h : env11286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11283_11286 : H12AffineEnvironment.transform 4 1 env11283 = env11286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env11283 == env11286) = true)

theorem identity11286 : scanCanonicalize (H12AffineFastState.compose env11286 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound11286 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11287 : List Nat := [0,4,0,16,1,16,0,4,1,5,1,17,1,17,0,0,16,1,5,0,17,0,17,0,1,17,1,17,16,1,5,1,5,1,17,1]

theorem envBound11287 : H12AffineFastState.Bounded env11287 := by
  intro p hp
  have h : env11287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11286_11287 : H12AffineEnvironment.transform 0 0 env11286 = env11287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env11286 == env11287) = true)

def leafEnv11287 : List Nat := [0,4,0,16,1,16,0,4,1,5,1,17,1,17,0,0,16,1,5,0,17,0,17,0,5,1,1,17,1,17,16,1,5,1,5,1,5,0,17,1,0,17,1]

def active11287 : List Nat := [1,3]

def tree11287 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11287 : H12WitnessSearch.Good tree11287 := H12GlobalWitnessIndex.good

theorem leafIdentity11287 : H12AffineFastState.composeSystem env11287 rootObs = leafEnv11287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11287 rootObs == leafEnv11287) = true)

theorem terminalChecked11287 : H12PackedTerminal.terminalCheckFast leafEnv11287 active11287 tree11287 = true := by decide +kernel

def env11288 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8461,65536,11340,2048,524288,8461,16464,10248,17665,67844,8193,17745,2049,4176,11292,65798,11273,4294967296,257,4295566638,11341,512]

theorem envBound11288 : H12AffineFastState.Bounded env11288 := by
  intro p hp
  have h : env11288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11258_11288 : H12AffineEnvironment.transform 6 9 env11258 = env11288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11258 == env11288) = true)

theorem identity11288 : scanCanonicalize (H12AffineFastState.compose env11288 (packedSelected [16,20] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound11288 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env11289 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,16384,8232,65536,11340,2048,524288,8232,16464,10248,17444,67617,8193,17524,2049,4176,11292,65571,11273,4294967296,36,4295566347,11341,512]

theorem envBound11289 : H12AffineFastState.Bounded env11289 := by
  intro p hp
  have h : env11289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11288_11289 : H12AffineEnvironment.transform 7 37 env11288 = env11289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env11288 == env11289) = true)

theorem identity11289 : scanCanonicalize (H12AffineFastState.compose env11289 (packedSelected [0,4,7,11,22,32] rootPS)) = affineNative (2^(15+1) ^^^ 2082) := by decide +kernel

theorem selectedBound11289 : packedSelected [0,4,7,11,22,32] rootPS < 2^1333 := by decide +kernel

def env11290 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,16384,8232,2082,11340,2048,524288,8232,16464,10248,17444,3,8193,17524,2049,4176,11292,2049,11273,4294967296,36,4295502889,11341,512]

theorem envBound11290 : H12AffineFastState.Bounded env11290 := by
  intro p hp
  have h : env11290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11289_11290 : H12AffineEnvironment.transform 15 2082 env11289 = env11290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2082 env11289 == env11290) = true)

theorem identity11290 : scanCanonicalize (H12AffineFastState.compose env11290 (packedSelected [0,2,9] rootPS)) = affineNative (2^(31+1) ^^^ 546346) := by decide +kernel

theorem selectedBound11290 : packedSelected [0,2,9] rootPS < 2^1333 := by decide +kernel

def env11291 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,16384,8232,2082,11340,2048,524288,8232,16464,10248,17444,3,8193,17524,2049,4176,11292,2049,11273,546346,36,31235,11341,512]

theorem envBound11291 : H12AffineFastState.Bounded env11291 := by
  intro p hp
  have h : env11291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11290_11291 : H12AffineEnvironment.transform 31 546346 env11290 = env11291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 546346 env11290 == env11291) = true)

theorem identity11291 : scanCanonicalize (H12AffineFastState.compose env11291 (packedSelected [12,15] rootPS)) = affineNative (2^(18+1) ^^^ 16484) := by decide +kernel

theorem selectedBound11291 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env11292 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,16384,8232,2082,11340,2048,16484,8232,16464,10248,17444,3,8193,17524,2049,4176,11292,2049,11273,5710,36,31235,11341,512]

theorem envBound11292 : H12AffineFastState.Bounded env11292 := by
  intro p hp
  have h : env11292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11291_11292 : H12AffineEnvironment.transform 18 16484 env11291 = env11292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 16484 env11291 == env11292) = true)

theorem identity11292 : scanCanonicalize (H12AffineFastState.compose env11292 (packedSelected [0,2,4] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound11292 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env11293 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,2088,16384,2048,2082,1124,2048,16484,2048,16464,32,17444,3,2089,17524,2049,4176,1076,2049,1057,5710,36,21035,1125,512]

theorem envBound11293 : H12AffineFastState.Bounded env11293 := by
  intro p hp
  have h : env11293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11292_11293 : H12AffineEnvironment.transform 12 2088 env11292 = env11293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env11292 == env11293) = true)

theorem identity11293 : scanCanonicalize (H12AffineFastState.compose env11293 (packedSelected [0,6,7] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound11293 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env11294 : List Nat := [2,4,8,16,32,64,9,37,43,1024,2048,4096,2088,16384,2048,2082,1124,2048,16484,2048,16464,32,17444,3,2089,17524,2049,4176,1076,2049,1057,5221,36,20480,1125,43]

theorem envBound11294 : H12AffineFastState.Bounded env11294 := by
  intro p hp
  have h : env11294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11293_11294 : H12AffineEnvironment.transform 8 43 env11293 = env11294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env11293 == env11294) = true)

theorem identity11294 : scanCanonicalize (H12AffineFastState.compose env11294 (packedSelected [1,5,6,10,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 4176) := by decide +kernel

theorem selectedBound11294 : packedSelected [1,5,6,10,11,12] rootPS < 2^1333 := by decide +kernel

def env11295 : List Nat := [2,4,8,16,32,64,9,37,43,1024,2048,4096,2088,4176,2048,2082,1124,2048,4148,2048,4096,32,5236,3,2089,5156,2049,4176,1076,2049,1057,5221,36,80,1125,43]

theorem envBound11295 : H12AffineFastState.Bounded env11295 := by
  intro p hp
  have h : env11295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11294_11295 : H12AffineEnvironment.transform 13 4176 env11294 = env11295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env11294 == env11295) = true)

theorem identity11295 : scanCanonicalize (H12AffineFastState.compose env11295 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 18) := by decide +kernel

theorem selectedBound11295 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11296 : List Nat := [2,4,8,16,32,18,9,37,43,1024,2048,4096,2088,4098,2048,2082,1078,2048,4148,2048,4096,32,5158,3,2089,5156,2049,4098,1076,2049,1057,5175,36,2,1079,43]

theorem envBound11296 : H12AffineFastState.Bounded env11296 := by
  intro p hp
  have h : env11296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11295_11296 : H12AffineEnvironment.transform 5 18 env11295 = env11296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 18 env11295 == env11296) = true)

theorem identity11296 : scanCanonicalize (H12AffineFastState.compose env11296 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 35) := by decide +kernel

theorem selectedBound11296 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env11297 : List Nat := [2,4,8,16,32,18,9,37,43,1024,35,4096,11,4098,35,1,1078,35,4148,35,4096,32,5158,3,10,5156,34,4098,1076,34,1057,5175,36,2,1079,43]

theorem envBound11297 : H12AffineFastState.Bounded env11297 := by
  intro p hp
  have h : env11297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11296_11297 : H12AffineEnvironment.transform 10 35 env11296 = env11297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 35 env11296 == env11297) = true)

theorem identity11297 : scanCanonicalize (H12AffineFastState.compose env11297 (packedSelected [10,13] rootPS)) = affineNative (2^(11+1) ^^^ 50) := by decide +kernel

theorem selectedBound11297 : packedSelected [10,13] rootPS < 2^1333 := by decide +kernel

def env11298 : List Nat := [2,4,8,16,32,18,9,37,43,1024,35,50,11,48,35,1,1078,35,6,35,50,32,1044,3,10,1046,34,48,1076,34,1057,1029,36,2,1079,43]

theorem envBound11298 : H12AffineFastState.Bounded env11298 := by
  intro p hp
  have h : env11298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11297_11298 : H12AffineEnvironment.transform 11 50 env11297 = env11298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 50 env11297 == env11298) = true)

theorem identity11298 : scanCanonicalize (H12AffineFastState.compose env11298 (packedSelected [2,22] rootPS)) = affineNative (2^(9+1) ^^^ 6) := by decide +kernel

theorem selectedBound11298 : packedSelected [2,22] rootPS < 2^1333 := by decide +kernel

def env11299 : List Nat := [2,4,8,16,32,18,9,37,43,6,35,50,11,48,35,1,48,35,6,35,50,32,18,3,10,16,34,48,50,34,39,3,36,2,49,43]

theorem envBound11299 : H12AffineFastState.Bounded env11299 := by
  intro p hp
  have h : env11299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11298_11299 : H12AffineEnvironment.transform 9 6 env11298 = env11299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 6 env11298 == env11299) = true)

theorem identity11299 : scanCanonicalize (H12AffineFastState.compose env11299 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 8) := by decide +kernel

theorem selectedBound11299 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11300 : List Nat := [2,4,8,16,8,18,9,13,3,6,11,26,11,24,11,1,24,11,6,11,26,8,18,3,10,16,10,24,26,10,15,3,12,2,25,3]

theorem envBound11300 : H12AffineFastState.Bounded env11300 := by
  intro p hp
  have h : env11300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11299_11300 : H12AffineEnvironment.transform 4 8 env11299 = env11300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 8 env11299 == env11300) = true)

theorem identity11300 : scanCanonicalize (H12AffineFastState.compose env11300 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound11300 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11301 : List Nat := [2,4,2,16,2,18,3,7,3,6,1,16,1,18,1,1,18,1,6,1,16,2,18,3,0,16,0,18,16,0,5,3,6,2,19,3]

theorem envBound11301 : H12AffineFastState.Bounded env11301 := by
  intro p hp
  have h : env11301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11300_11301 : H12AffineEnvironment.transform 2 2 env11300 = env11301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env11300 == env11301) = true)

def leafEnv11301 : List Nat := [2,4,2,16,2,18,3,7,3,6,1,16,1,18,1,1,18,1,6,1,16,2,18,3,5,0,1,16,0,18,16,0,5,3,6,2,5,0,19,3,0,17,1]

def active11301 : List Nat := [0,1,3]

def tree11301 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11301 : H12WitnessSearch.Good tree11301 := H12GlobalWitnessIndex.good

theorem leafIdentity11301 : H12AffineFastState.composeSystem env11301 rootObs = leafEnv11301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11301 rootObs == leafEnv11301) = true)

theorem terminalChecked11301 : H12PackedTerminal.terminalCheckFast leafEnv11301 active11301 tree11301 = true := by decide +kernel

def env11302 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8461,65536,11461,2049,524288,8461,16464,10248,17665,67981,8328,17745,2185,4176,11413,65935,11392,4294967296,257,4295566638,11460,512]

theorem envBound11302 : H12AffineFastState.Bounded env11302 := by
  intro p hp
  have h : env11302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11257_11302 : H12AffineEnvironment.transform 17 2049 env11257 = env11302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2049 env11257 == env11302) = true)

theorem identity11302 : scanCanonicalize (H12AffineFastState.compose env11302 (packedSelected [0,4,7,11,16,22,23] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound11302 : packedSelected [0,4,7,11,16,22,23] rootPS < 2^1333 := by decide +kernel

def env11303 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,8192,16384,8233,65536,11461,2049,524288,8233,16464,10248,17445,67753,8328,17525,2185,4176,11413,65707,11392,4294967296,37,4295566346,11460,512]

theorem envBound11303 : H12AffineFastState.Bounded env11303 := by
  intro p hp
  have h : env11303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11302_11303 : H12AffineEnvironment.transform 7 36 env11302 = env11303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env11302 == env11303) = true)

theorem identity11303 : scanCanonicalize (H12AffineFastState.compose env11303 (packedSelected [0,4,7,11,16,20,22,32] rootPS)) = affineNative (2^(15+1) ^^^ 2083) := by decide +kernel

theorem selectedBound11303 : packedSelected [0,4,7,11,16,20,22,32] rootPS < 2^1333 := by decide +kernel

def env11304 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,8192,16384,8233,2083,11461,2049,524288,8233,16464,10248,17445,138,8328,17525,2185,4176,11413,2184,11392,4294967296,37,4295502889,11460,512]

theorem envBound11304 : H12AffineFastState.Bounded env11304 := by
  intro p hp
  have h : env11304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11303_11304 : H12AffineEnvironment.transform 15 2083 env11303 = env11304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2083 env11303 == env11304) = true)

theorem identity11304 : scanCanonicalize (H12AffineFastState.compose env11304 (packedSelected [0,2,9] rootPS)) = affineNative (2^(31+1) ^^^ 546346) := by decide +kernel

theorem selectedBound11304 : packedSelected [0,2,9] rootPS < 2^1333 := by decide +kernel

def env11305 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,8192,16384,8233,2083,11461,2049,524288,8233,16464,10248,17445,138,8328,17525,2185,4176,11413,2184,11392,546346,37,31235,11460,512]

theorem envBound11305 : H12AffineFastState.Bounded env11305 := by
  intro p hp
  have h : env11305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11304_11305 : H12AffineEnvironment.transform 31 546346 env11304 = env11305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 546346 env11304 == env11305) = true)

def env11306 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,8192,4176,8233,2083,11461,2049,524288,8233,4096,10248,5237,138,8328,5157,2185,4176,11413,2184,11392,525946,37,10835,11460,512]

theorem envBound11306 : H12AffineFastState.Bounded env11306 := by
  intro p hp
  have h : env11306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11305_11306 : H12AffineEnvironment.transform 13 4176 env11305 = env11306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env11305 == env11306) = true)

theorem identity11306 : scanCanonicalize (H12AffineFastState.compose env11306 (packedSelected [2,4,6,7] rootPS)) = affineNative (2^(18+1) ^^^ 14902) := by decide +kernel

theorem selectedBound11306 : packedSelected [2,4,6,7] rootPS < 2^1333 := by decide +kernel

def env11307 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,8192,4176,8233,2083,11461,2049,14902,8233,4096,10248,5237,138,8328,5157,2185,4176,11413,2184,11392,15436,37,10835,11460,512]

theorem envBound11307 : H12AffineFastState.Bounded env11307 := by
  intro p hp
  have h : env11307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11306_11307 : H12AffineEnvironment.transform 18 14902 env11306 = env11307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 14902 env11306 == env11307) = true)

theorem identity11307 : scanCanonicalize (H12AffineFastState.compose env11307 (packedSelected [11] rootPS)) = affineNative (2^(12+1) ^^^ 89) := by decide +kernel

theorem selectedBound11307 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env11308 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,89,4176,112,2083,3228,2049,6767,112,4096,2129,5237,138,209,5157,2185,4176,3276,2184,3289,7189,37,2570,3229,512]

theorem envBound11308 : H12AffineFastState.Bounded env11308 := by
  intro p hp
  have h : env11308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11307_11308 : H12AffineEnvironment.transform 12 89 env11307 = env11308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 89 env11307 == env11308) = true)

theorem identity11308 : scanCanonicalize (H12AffineFastState.compose env11308 (packedSelected [0,2,3,4,5,6,10,12] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound11308 : packedSelected [0,2,3,4,5,6,10,12] rootPS < 2^1333 := by decide +kernel

def env11309 : List Nat := [2,4,8,16,32,64,128,36,43,1024,2048,4096,89,4176,112,2083,3228,2049,6212,112,4096,2129,5237,138,209,5157,2185,4176,3276,2184,3289,7189,37,2081,3229,43]

theorem envBound11309 : H12AffineFastState.Bounded env11309 := by
  intro p hp
  have h : env11309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11308_11309 : H12AffineEnvironment.transform 8 43 env11308 = env11309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env11308 == env11309) = true)

theorem identity11309 : scanCanonicalize (H12AffineFastState.compose env11309 (packedSelected [1,3,6] rootPS)) = affineNative (2^(10+1) ^^^ 113) := by decide +kernel

theorem selectedBound11309 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env11310 : List Nat := [2,4,8,16,32,64,128,36,43,1024,113,4096,89,4176,112,82,1261,112,4149,112,4096,32,5237,138,209,5157,248,4176,1213,249,1192,5220,37,80,1260,43]

theorem envBound11310 : H12AffineFastState.Bounded env11310 := by
  intro p hp
  have h : env11310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11309_11310 : H12AffineEnvironment.transform 10 113 env11309 = env11310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 113 env11309 == env11310) = true)

theorem identity11310 : scanCanonicalize (H12AffineFastState.compose env11310 (packedSelected [1,3,10,13] rootPS)) = affineNative (2^(11+1) ^^^ 97) := by decide +kernel

theorem selectedBound11310 : packedSelected [1,3,10,13] rootPS < 2^1333 := by decide +kernel

def env11311 : List Nat := [2,4,8,16,32,64,128,36,43,1024,113,97,89,49,112,82,1261,112,84,112,97,32,1044,138,209,1092,248,49,1213,249,1192,1029,37,80,1260,43]

theorem envBound11311 : H12AffineFastState.Bounded env11311 := by
  intro p hp
  have h : env11311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11310_11311 : H12AffineEnvironment.transform 11 97 env11310 = env11311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 97 env11310 == env11311) = true)

theorem identity11311 : scanCanonicalize (H12AffineFastState.compose env11311 (packedSelected [1,5,10,15] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound11311 : packedSelected [1,5,10,15] rootPS < 2^1333 := by decide +kernel

def env11312 : List Nat := [2,4,8,16,32,64,8,36,43,1024,113,97,89,49,112,82,1125,112,84,112,97,32,1044,2,89,1092,112,49,1077,113,1056,1029,37,80,1124,43]

theorem envBound11312 : H12AffineFastState.Bounded env11312 := by
  intro p hp
  have h : env11312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11311_11312 : H12AffineEnvironment.transform 6 8 env11311 = env11312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env11311 == env11312) = true)

theorem identity11312 : scanCanonicalize (H12AffineFastState.compose env11312 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 19) := by decide +kernel

theorem selectedBound11312 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11313 : List Nat := [2,4,8,16,32,19,8,36,43,1024,34,50,10,49,35,1,1078,35,7,35,50,32,1044,2,10,1047,35,49,1077,34,1056,1029,37,3,1079,43]

theorem envBound11313 : H12AffineFastState.Bounded env11313 := by
  intro p hp
  have h : env11313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11312_11313 : H12AffineEnvironment.transform 5 19 env11312 = env11313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 19 env11312 == env11313) = true)

theorem identity11313 : scanCanonicalize (H12AffineFastState.compose env11313 (packedSelected [2,22] rootPS)) = affineNative (2^(9+1) ^^^ 7) := by decide +kernel

theorem selectedBound11313 : packedSelected [2,22] rootPS < 2^1333 := by decide +kernel

def env11314 : List Nat := [2,4,8,16,32,19,8,36,43,7,34,50,10,49,35,1,49,35,7,35,50,32,19,2,10,16,35,49,50,34,39,2,37,3,48,43]

theorem envBound11314 : H12AffineFastState.Bounded env11314 := by
  intro p hp
  have h : env11314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11313_11314 : H12AffineEnvironment.transform 9 7 env11313 = env11314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 7 env11313 == env11314) = true)

theorem identity11314 : scanCanonicalize (H12AffineFastState.compose env11314 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 8) := by decide +kernel

theorem selectedBound11314 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11315 : List Nat := [2,4,8,16,8,19,8,12,3,7,10,26,10,25,11,1,25,11,7,11,26,8,19,2,10,16,11,25,26,10,15,2,13,3,24,3]

theorem envBound11315 : H12AffineFastState.Bounded env11315 := by
  intro p hp
  have h : env11315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11314_11315 : H12AffineEnvironment.transform 4 8 env11314 = env11315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 8 env11314 == env11315) = true)

theorem identity11315 : scanCanonicalize (H12AffineFastState.compose env11315 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound11315 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11316 : List Nat := [2,4,2,16,2,19,2,6,3,7,0,16,0,19,1,1,19,1,7,1,16,2,19,2,0,16,1,19,16,0,5,2,7,3,18,3]

theorem envBound11316 : H12AffineFastState.Bounded env11316 := by
  intro p hp
  have h : env11316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11315_11316 : H12AffineEnvironment.transform 2 2 env11315 = env11316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env11315 == env11316) = true)

def leafEnv11316 : List Nat := [2,4,2,16,2,19,2,6,3,7,0,16,0,19,1,1,19,1,7,1,16,2,19,2,5,0,1,16,1,19,16,0,5,2,7,3,5,1,18,3,0,17,1]

def active11316 : List Nat := [0,1,3]

def tree11316 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11316 : H12WitnessSearch.Good tree11316 := H12GlobalWitnessIndex.good

theorem leafIdentity11316 : H12AffineFastState.composeSystem env11316 rootObs = leafEnv11316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11316 rootObs == leafEnv11316) = true)

theorem terminalChecked11316 : H12PackedTerminal.terminalCheckFast leafEnv11316 active11316 tree11316 = true := by decide +kernel

def env11317 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,8192,4177,8233,2083,11461,2049,524288,8233,4097,10248,5236,138,8328,5156,2185,4176,11413,2184,11392,525947,37,10834,11460,512]

theorem envBound11317 : H12AffineFastState.Bounded env11317 := by
  intro p hp
  have h : env11317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11305_11317 : H12AffineEnvironment.transform 13 4177 env11305 = env11317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env11305 == env11317) = true)

theorem identity11317 : scanCanonicalize (H12AffineFastState.compose env11317 (packedSelected [2,4,6,7] rootPS)) = affineNative (2^(18+1) ^^^ 4759) := by decide +kernel

theorem selectedBound11317 : packedSelected [2,4,6,7] rootPS < 2^1333 := by decide +kernel

def env11318 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,8192,4177,8233,2083,11461,2049,4759,8233,4097,10248,5236,138,8328,5156,2185,4176,11413,2184,11392,5356,37,10834,11460,512]

theorem envBound11318 : H12AffineFastState.Bounded env11318 := by
  intro p hp
  have h : env11318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11317_11318 : H12AffineEnvironment.transform 18 4759 env11317 = env11318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4759 env11317 == env11318) = true)

theorem identity11318 : scanCanonicalize (H12AffineFastState.compose env11318 (packedSelected [11] rootPS)) = affineNative (2^(12+1) ^^^ 5180) := by decide +kernel

theorem selectedBound11318 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env11319 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,5180,4177,5141,2083,6393,2049,4759,5141,4097,7220,5236,138,5300,5156,2185,4176,6313,2184,6332,5356,37,7790,6392,512]

theorem envBound11319 : H12AffineFastState.Bounded env11319 := by
  intro p hp
  have h : env11319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11318_11319 : H12AffineEnvironment.transform 12 5180 env11318 = env11319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5180 env11318 == env11319) = true)

def env11320 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,10248,17665,230469,8329,2098433,2518045,2117632,131152,1073741824,131141,4294967296,257,4297844919,131073,513]

theorem envBound11320 : H12AffineFastState.Bounded env11320 := by
  intro p hp
  have h : env11320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11252_11320 : H12AffineEnvironment.transform 24 8329 env11252 = env11320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8329 env11252 == env11320) = true)

def env11321 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,8200,17665,230469,8329,2098433,2515997,2117632,131152,1073741824,131141,4294967296,257,4297842871,131073,513]

theorem envBound11321 : H12AffineFastState.Bounded env11321 := by
  intro p hp
  have h : env11321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11320_11321 : H12AffineEnvironment.transform 10 0 env11320 = env11321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env11320 == env11321) = true)

def env11322 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,131072,262144,524288,32768,4096,8200,17665,230469,8329,5377,422941,16384,131152,1073741824,131141,4294967296,257,4295749815,131073,513]

theorem envBound11322 : H12AffineFastState.Bounded env11322 := by
  intro p hp
  have h : env11322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11321_11322 : H12AffineEnvironment.transform 20 4096 env11321 = env11322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env11321 == env11322) = true)

theorem identity11322 : scanCanonicalize (H12AffineFastState.compose env11322 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 456672) := by decide +kernel

theorem selectedBound11322 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env11323 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,131072,262144,524288,32768,4096,8200,17665,230469,8329,5377,422941,16384,131152,456672,131141,4294967296,257,4295749815,131073,513]

theorem envBound11323 : H12AffineFastState.Bounded env11323 := by
  intro p hp
  have h : env11323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11322_11323 : H12AffineEnvironment.transform 29 456672 env11322 = env11323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 456672 env11322 == env11323) = true)

theorem identity11323 : scanCanonicalize (H12AffineFastState.compose env11323 (packedSelected [0,4,6,7,16,20,22,25] rootPS)) = affineNative (2^(18+1) ^^^ 21585) := by decide +kernel

theorem selectedBound11323 : packedSelected [0,4,6,7,16,20,22,25] rootPS < 2^1333 := by decide +kernel

def env11324 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,131072,262144,21585,32768,4096,8200,17665,230469,8329,5377,422941,16384,131152,456672,131141,4294967296,257,4295206118,131073,513]

theorem envBound11324 : H12AffineFastState.Bounded env11324 := by
  intro p hp
  have h : env11324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11323_11324 : H12AffineEnvironment.transform 18 21585 env11323 = env11324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env11323 == env11324) = true)

theorem identity11324 : scanCanonicalize (H12AffineFastState.compose env11324 (packedSelected [4,9,16] rootPS)) = affineNative (2^(17+1) ^^^ 218978) := by decide +kernel

theorem selectedBound11324 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env11325 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,131072,218978,21585,32768,4096,8200,17665,230469,8329,5377,74623,16384,131152,106626,131141,4294967296,257,4295206118,131073,513]

theorem envBound11325 : H12AffineFastState.Bounded env11325 := by
  intro p hp
  have h : env11325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11324_11325 : H12AffineEnvironment.transform 17 218978 env11324 = env11325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 218978 env11324 == env11325) = true)

theorem identity11325 : scanCanonicalize (H12AffineFastState.compose env11325 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound11325 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env11326 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,4177,32768,65536,131072,198451,1024,32768,4096,8200,5456,230469,8329,5377,74623,4177,131152,106626,131141,4294967296,257,4295206118,131073,513]

theorem envBound11326 : H12AffineFastState.Bounded env11326 := by
  intro p hp
  have h : env11326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11325_11326 : H12AffineEnvironment.transform 13 4177 env11325 = env11326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env11325 == env11326) = true)

theorem identity11326 : scanCanonicalize (H12AffineFastState.compose env11326 (packedSelected [13,21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound11326 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env11327 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,4177,8540,65536,131072,198451,1024,8540,4096,8200,5456,206105,8329,5377,74623,4177,131152,66014,131141,4294967296,257,4295165370,131073,513]

theorem envBound11327 : H12AffineFastState.Bounded env11327 := by
  intro p hp
  have h : env11327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11326_11327 : H12AffineEnvironment.transform 14 8540 env11326 = env11327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env11326 == env11327) = true)

def env11328 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,131072,262144,524288,32768,4097,8200,17665,230469,8329,5376,422940,16385,131152,1073741824,131141,4294967296,257,4295749814,131073,513]

theorem envBound11328 : H12AffineFastState.Bounded env11328 := by
  intro p hp
  have h : env11328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11321_11328 : H12AffineEnvironment.transform 20 4097 env11321 = env11328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env11321 == env11328) = true)

theorem identity11328 : scanCanonicalize (H12AffineFastState.compose env11328 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 451232) := by decide +kernel

theorem selectedBound11328 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env11329 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,131072,262144,524288,32768,4097,8200,17665,230469,8329,5376,422940,16385,131152,451232,131141,4294967296,257,4295749814,131073,513]

theorem envBound11329 : H12AffineFastState.Bounded env11329 := by
  intro p hp
  have h : env11329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11328_11329 : H12AffineEnvironment.transform 29 451232 env11328 = env11329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 451232 env11328 == env11329) = true)

def env11330 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1344,262144,524288,32768,4097,8200,17665,98565,8329,5376,291164,16385,1296,321504,1285,4294967296,257,4295620086,1345,513]

theorem envBound11330 : H12AffineFastState.Bounded env11330 := by
  intro p hp
  have h : env11330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11329_11330 : H12AffineEnvironment.transform 16 1344 env11329 = env11330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env11329 == env11330) = true)

theorem identity11330 : scanCanonicalize (H12AffineFastState.compose env11330 (packedSelected [0,4,7,9,16,20] rootPS)) = affineNative (2^(13+1) ^^^ 1992) := by decide +kernel

theorem selectedBound11330 : packedSelected [0,4,7,9,16,20] rootPS < 2^1333 := by decide +kernel

def env11331 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,1992,32768,65536,1344,262144,524288,32768,4097,8200,713,98565,8329,5376,276116,1993,1296,303144,1285,4294967296,257,4295602750,1345,513]

theorem envBound11331 : H12AffineFastState.Bounded env11331 := by
  intro p hp
  have h : env11331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11330_11331 : H12AffineEnvironment.transform 13 1992 env11330 = env11331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1992 env11330 == env11331) = true)

theorem identity11331 : scanCanonicalize (H12AffineFastState.compose env11331 (packedSelected [4,16,22] rootPS)) = affineNative (2^(18+1) ^^^ 5016) := by decide +kernel

theorem selectedBound11331 : packedSelected [4,16,22] rootPS < 2^1333 := by decide +kernel

def env11332 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,1992,32768,65536,1344,262144,5016,32768,4097,8200,713,98565,8329,5376,276116,1993,1296,303144,1285,4294967296,257,4295074214,1345,513]

theorem envBound11332 : H12AffineFastState.Bounded env11332 := by
  intro p hp
  have h : env11332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11331_11332 : H12AffineEnvironment.transform 18 5016 env11331 = env11332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 5016 env11331 == env11332) = true)

theorem identity11332 : scanCanonicalize (H12AffineFastState.compose env11332 (packedSelected [4,9,16] rootPS)) = affineNative (2^(17+1) ^^^ 71475) := by decide +kernel

theorem selectedBound11332 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env11333 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,1992,32768,65536,1344,71475,5016,32768,4097,8200,713,98565,8329,5376,74151,1993,1296,112411,1285,4294967296,257,4295074214,1345,513]

theorem envBound11333 : H12AffineFastState.Bounded env11333 := by
  intro p hp
  have h : env11333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11332_11333 : H12AffineEnvironment.transform 17 71475 env11332 = env11333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 71475 env11332 == env11333) = true)

theorem identity11333 : scanCanonicalize (H12AffineFastState.compose env11333 (packedSelected [3,8,10,13,17] rootPS)) = affineNative (2^(15+1) ^^^ 41382) := by decide +kernel

theorem selectedBound11333 : packedSelected [3,8,10,13,17] rootPS < 2^1333 := by decide +kernel

def env11334 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,1992,32768,41382,1344,46741,5016,32768,4097,8200,713,8355,8329,5376,32769,1993,1296,5821,1285,4294967296,257,4294967296,1345,513]

theorem envBound11334 : H12AffineFastState.Bounded env11334 := by
  intro p hp
  have h : env11334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11333_11334 : H12AffineEnvironment.transform 15 41382 env11333 = env11334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41382 env11333 == env11334) = true)

theorem identity11334 : scanCanonicalize (H12AffineFastState.compose env11334 (packedSelected [1,3,5,8,12,13,15,21] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound11334 : packedSelected [1,3,5,8,12,13,15,21] rootPS < 2^1333 := by decide +kernel

def env11335 : List Nat := [2,4,8,16,32,64,128,36,512,1024,0,4096,8192,1772,32768,41090,1124,46741,4796,32768,4097,8200,713,8355,8329,5156,32769,1773,1076,5821,1057,4294967296,37,4294967296,1125,513]

theorem envBound11335 : H12AffineFastState.Bounded env11335 := by
  intro p hp
  have h : env11335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11334_11335 : H12AffineEnvironment.transform 7 36 env11334 = env11335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env11334 == env11335) = true)

theorem identity11335 : scanCanonicalize (H12AffineFastState.compose env11335 (packedSelected [0,2,3,4,5,6,12,13] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound11335 : packedSelected [0,2,3,4,5,6,12,13] rootPS < 2^1333 := by decide +kernel

def env11336 : List Nat := [2,4,8,16,32,64,128,36,512,1024,0,4096,40,1772,32768,32938,1124,38589,4796,32768,4097,32,713,139,161,5156,32769,1773,1076,5821,1057,4294967296,37,4294967296,1125,513]

theorem envBound11336 : H12AffineFastState.Bounded env11336 := by
  intro p hp
  have h : env11336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11335_11336 : H12AffineEnvironment.transform 12 40 env11335 = env11336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env11335 == env11336) = true)

theorem identity11336 : scanCanonicalize (H12AffineFastState.compose env11336 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1076) := by decide +kernel

theorem selectedBound11336 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11337 : List Nat := [2,4,8,16,32,64,128,36,512,1024,0,1076,40,1772,32768,32938,1124,33417,1672,32768,1077,32,713,139,161,16,32769,1773,1076,649,1057,4294967296,37,4294967296,1125,513]

theorem envBound11337 : H12AffineFastState.Bounded env11337 := by
  intro p hp
  have h : env11337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11336_11337 : H12AffineEnvironment.transform 11 1076 env11336 = env11337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1076 env11336 == env11337) = true)

theorem identity11337 : scanCanonicalize (H12AffineFastState.compose env11337 (packedSelected [2,4] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound11337 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env11338 : List Nat := [2,4,8,16,17,64,128,21,512,1024,0,1029,25,1757,32768,32923,1109,33417,1672,32768,1028,17,713,139,144,16,32769,1756,1029,649,1040,4294967296,20,4294967296,1108,513]

theorem envBound11338 : H12AffineFastState.Bounded env11338 := by
  intro p hp
  have h : env11338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11337_11338 : H12AffineEnvironment.transform 4 17 env11337 = env11338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env11337 == env11338) = true)

theorem identity11338 : scanCanonicalize (H12AffineFastState.compose env11338 (packedSelected [5] rootPS)) = affineNative (2^(14+1) ^^^ 147) := by decide +kernel

theorem selectedBound11338 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env11339 : List Nat := [2,4,8,16,17,64,128,21,512,1024,0,1029,25,1757,147,8,1109,538,1672,147,1028,17,713,139,144,16,146,1756,1029,649,1040,4294967296,20,4294967296,1108,513]

theorem envBound11339 : H12AffineFastState.Bounded env11339 := by
  intro p hp
  have h : env11339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11338_11339 : H12AffineEnvironment.transform 14 147 env11338 = env11339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 147 env11338 == env11339) = true)

theorem identity11339 : scanCanonicalize (H12AffineFastState.compose env11339 (packedSelected [8] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound11339 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env11340 : List Nat := [2,4,8,16,17,64,18,21,512,1024,0,1029,25,1615,1,8,1109,538,1562,1,1028,17,603,25,2,16,0,1614,1029,539,1040,4294967296,20,4294967296,1108,513]

theorem envBound11340 : H12AffineFastState.Bounded env11340 := by
  intro p hp
  have h : env11340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11339_11340 : H12AffineEnvironment.transform 6 18 env11339 = env11340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env11339 == env11340) = true)

def env11341 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1345,262144,524288,32768,4097,8200,17665,98564,8329,5376,291165,16385,1297,321505,1284,4294967296,257,4295620087,1344,513]

theorem envBound11341 : H12AffineFastState.Bounded env11341 := by
  intro p hp
  have h : env11341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11329_11341 : H12AffineEnvironment.transform 16 1345 env11329 = env11341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env11329 == env11341) = true)

theorem identity11341 : scanCanonicalize (H12AffineFastState.compose env11341 (packedSelected [0,4,7,9,16,20] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound11341 : packedSelected [0,4,7,9,16,20] rootPS < 2^1333 := by decide +kernel

def env11342 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,4096,8192,16384,32768,65536,1345,262144,524288,32768,4097,8200,17665,98564,8329,5376,291165,16385,1297,320872,1284,4294967296,257,4295620087,1344,136]

theorem envBound11342 : H12AffineFastState.Bounded env11342 := by
  intro p hp
  have h : env11342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11341_11342 : H12AffineEnvironment.transform 8 137 env11341 = env11342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env11341 == env11342) = true)

theorem identity11342 : scanCanonicalize (H12AffineFastState.compose env11342 (packedSelected [1,3,12,13,15,17] rootPS)) = affineNative (2^(17+1) ^^^ 50276) := by decide +kernel

theorem selectedBound11342 : packedSelected [1,3,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env11343 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,4096,8192,16384,32768,65536,1345,50276,524288,32768,4097,8200,17665,98564,8329,5376,46393,16385,1297,8460,1284,4294967296,257,4295620087,1344,136]

theorem envBound11343 : H12AffineFastState.Bounded env11343 := by
  intro p hp
  have h : env11343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11342_11343 : H12AffineEnvironment.transform 17 50276 env11342 = env11343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 50276 env11342 == env11343) = true)

theorem identity11343 : scanCanonicalize (H12AffineFastState.compose env11343 (packedSelected [0,2,5,6,8,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 9293) := by decide +kernel

theorem selectedBound11343 : packedSelected [0,2,5,6,8,9,16] rootPS < 2^1333 := by decide +kernel

def env11344 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,4096,8192,9293,32768,65536,1345,41001,524288,32768,4097,8200,8524,98564,8329,5376,46393,9292,1297,8460,1284,4294967296,257,4295594426,1344,136]

theorem envBound11344 : H12AffineFastState.Bounded env11344 := by
  intro p hp
  have h : env11344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11343_11344 : H12AffineEnvironment.transform 13 9293 env11343 = env11344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9293 env11343 == env11344) = true)

theorem identity11344 : scanCanonicalize (H12AffineFastState.compose env11344 (packedSelected [0,1,2,3,6,9,10,13,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 5149) := by decide +kernel

theorem selectedBound11344 : packedSelected [0,1,2,3,6,9,10,13,15,18] rootPS < 2^1333 := by decide +kernel

def env11345 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,4096,5149,4176,32768,65536,1345,37940,524288,32768,4097,5141,5457,98564,5268,5376,33060,4177,1297,5393,1284,4294967296,257,4295594426,1344,136]

theorem envBound11345 : H12AffineFastState.Bounded env11345 := by
  intro p hp
  have h : env11345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11344_11345 : H12AffineEnvironment.transform 12 5149 env11344 = env11345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5149 env11344 == env11345) = true)

theorem identity11345 : scanCanonicalize (H12AffineFastState.compose env11345 (packedSelected [5,8] rootPS)) = affineNative (2^(18+1) ^^^ 99727) := by decide +kernel

theorem selectedBound11345 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env11346 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,4096,5149,4176,32768,65536,1345,37940,99727,32768,4097,5141,5457,98564,5268,5376,33060,4177,1297,5393,1284,4294967296,257,4294972469,1344,136]

theorem envBound11346 : H12AffineFastState.Bounded env11346 := by
  intro p hp
  have h : env11346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11345_11346 : H12AffineEnvironment.transform 18 99727 env11345 = env11346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 99727 env11345 == env11346) = true)

theorem identity11346 : scanCanonicalize (H12AffineFastState.compose env11346 (packedSelected [1,2,4,12,13] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound11346 : packedSelected [1,2,4,12,13] rootPS < 2^1333 := by decide +kernel

def env11347 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,4096,5149,4176,1,65536,1345,5173,66958,1,4097,5141,5457,65797,5268,5376,293,4177,1297,5393,1284,4294967296,257,4294972469,1344,136]

theorem envBound11347 : H12AffineFastState.Bounded env11347 := by
  intro p hp
  have h : env11347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11346_11347 : H12AffineEnvironment.transform 14 1 env11346 = env11347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env11346 == env11347) = true)

def env11348 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,1296,269,1344,1,65536,1345,293,66958,1,1297,261,65,65797,388,16,293,1345,1297,1,1284,4294967296,257,4294967589,1344,136]

theorem envBound11348 : H12AffineFastState.Bounded env11348 := by
  intro p hp
  have h : env11348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11347_11348 : H12AffineEnvironment.transform 11 1296 env11347 = env11348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env11347 == env11348) = true)

theorem identity11348 : scanCanonicalize (H12AffineFastState.compose env11348 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 350) := by decide +kernel

theorem selectedBound11348 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11349 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,1296,269,1344,1,65536,1345,293,66958,1,1297,261,65,65797,388,16,293,1345,1297,1,1284,350,257,123,1344,136]

theorem envBound11349 : H12AffineFastState.Bounded env11349 := by
  intro p hp
  have h : env11349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11348_11349 : H12AffineEnvironment.transform 31 350 env11348 = env11349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 350 env11348 == env11349) = true)

def env11350 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,1297,268,1345,1,65536,1345,292,66958,1,1296,260,64,65797,389,17,293,1344,1297,0,1284,4294967296,257,4294967588,1344,136]

theorem envBound11350 : H12AffineFastState.Bounded env11350 := by
  intro p hp
  have h : env11350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11347_11350 : H12AffineEnvironment.transform 11 1297 env11347 = env11350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env11347 == env11350) = true)

theorem identity11350 : scanCanonicalize (H12AffineFastState.compose env11350 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 470) := by decide +kernel

theorem selectedBound11350 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11351 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,1297,268,1345,1,65536,1345,292,66958,1,1296,260,64,65797,389,17,293,1344,1297,0,1284,470,257,242,1344,136]

theorem envBound11351 : H12AffineFastState.Bounded env11351 := by
  intro p hp
  have h : env11351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11350_11351 : H12AffineEnvironment.transform 31 470 env11350 = env11351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 470 env11350 == env11351) = true)

theorem identity11351 : scanCanonicalize (H12AffineFastState.compose env11351 (packedSelected [7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound11351 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env11352 : List Nat := [2,4,8,16,32,64,128,37,137,1024,0,1076,41,1124,1,65536,1124,1,66731,1,1077,33,64,65568,160,17,0,1125,1076,0,1057,243,36,242,1125,136]

theorem envBound11352 : H12AffineFastState.Bounded env11352 := by
  intro p hp
  have h : env11352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11351_11352 : H12AffineEnvironment.transform 7 37 env11351 = env11352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env11351 == env11352) = true)

theorem identity11352 : scanCanonicalize (H12AffineFastState.compose env11352 (packedSelected [1,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound11352 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env11353 : List Nat := [2,4,8,16,32,64,25,37,16,1024,0,1076,41,1124,1,65536,1124,1,66610,1,1077,33,64,65568,57,17,0,1125,1076,0,1057,106,36,107,1125,17]

theorem envBound11353 : H12AffineFastState.Bounded env11353 := by
  intro p hp
  have h : env11353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11352_11353 : H12AffineEnvironment.transform 6 25 env11352 = env11353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env11352 == env11353) = true)

def env11354 : List Nat := [2,4,8,16,32,64,25,37,16,1024,0,1076,41,1124,1,88,1124,1,1130,1,1077,33,64,120,57,17,0,1125,1076,0,1057,106,36,107,1125,17]

theorem envBound11354 : H12AffineFastState.Bounded env11354 := by
  intro p hp
  have h : env11354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11353_11354 : H12AffineEnvironment.transform 15 88 env11353 = env11354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 88 env11353 == env11354) = true)

theorem identity11354 : scanCanonicalize (H12AffineFastState.compose env11354 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound11354 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11355 : List Nat := [2,4,8,16,10,64,25,15,16,1024,0,1054,3,1102,1,88,1102,1,1088,1,1055,11,64,82,19,17,0,1103,1054,0,1035,64,14,65,1103,17]

theorem envBound11355 : H12AffineFastState.Bounded env11355 := by
  intro p hp
  have h : env11355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11354_11355 : H12AffineEnvironment.transform 4 10 env11354 = env11355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env11354 == env11355) = true)

def env11356 : List Nat := [2,4,8,16,10,0,25,15,16,1024,0,1054,3,1038,1,24,1038,1,1024,1,1055,11,0,18,19,17,0,1039,1054,0,1035,0,14,1,1039,17]

theorem envBound11356 : H12AffineFastState.Bounded env11356 := by
  intro p hp
  have h : env11356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11355_11356 : H12AffineEnvironment.transform 5 0 env11355 = env11356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env11355 == env11356) = true)

def leafEnv11356 : List Nat := [2,4,8,16,10,0,25,15,16,1024,0,1054,3,1038,1,24,1038,1,1024,1,1055,11,0,18,1035,19,1,17,0,1039,1054,0,1035,0,14,1,5,9,1039,17,0,1055,1]

def active11356 : List Nat := [0,1,2,3,9]

def tree11356 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11356 : H12WitnessSearch.Good tree11356 := H12GlobalWitnessIndex.good

theorem leafIdentity11356 : H12AffineFastState.composeSystem env11356 rootObs = leafEnv11356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11356 rootObs == leafEnv11356) = true)

theorem terminalChecked11356 : H12PackedTerminal.terminalCheckFast leafEnv11356 active11356 tree11356 = true := by decide +kernel

def env11357 : List Nat := [2,4,8,16,10,1,25,15,16,1024,0,1054,3,1039,1,25,1039,1,1025,1,1055,11,1,19,19,17,0,1038,1054,0,1035,1,14,0,1038,17]

theorem envBound11357 : H12AffineFastState.Bounded env11357 := by
  intro p hp
  have h : env11357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11355_11357 : H12AffineEnvironment.transform 5 1 env11355 = env11357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env11355 == env11357) = true)

theorem identity11357 : scanCanonicalize (H12AffineFastState.compose env11357 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound11357 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11358 : List Nat := [2,4,2,16,0,1,19,5,16,1024,0,1044,3,1029,1,19,1029,1,1025,1,1045,1,1,19,19,17,0,1028,1044,0,1025,1,4,0,1028,17]

theorem envBound11358 : H12AffineFastState.Bounded env11358 := by
  intro p hp
  have h : env11358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11357_11358 : H12AffineEnvironment.transform 2 2 env11357 = env11358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env11357 == env11358) = true)

def leafEnv11358 : List Nat := [2,4,2,16,0,1,19,5,16,1024,0,1044,3,1029,1,19,1029,1,1025,1,1045,1,1,19,1024,19,1,17,0,1028,1044,0,1025,1,4,0,5,3,1028,17,0,1045,1]

def active11358 : List Nat := [0,1,3,9]

def tree11358 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11358 : H12WitnessSearch.Good tree11358 := H12GlobalWitnessIndex.good

theorem leafIdentity11358 : H12AffineFastState.composeSystem env11358 rootObs = leafEnv11358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11358 rootObs == leafEnv11358) = true)

theorem terminalChecked11358 : H12PackedTerminal.terminalCheckFast leafEnv11358 active11358 tree11358 = true := by decide +kernel

def env11359 : List Nat := [2,4,8,16,32,64,25,37,16,1024,0,1076,41,1124,1,89,1124,1,1131,1,1077,33,64,121,57,17,0,1125,1076,0,1057,106,36,107,1125,17]

theorem envBound11359 : H12AffineFastState.Bounded env11359 := by
  intro p hp
  have h : env11359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11353_11359 : H12AffineEnvironment.transform 15 89 env11353 = env11359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 89 env11353 == env11359) = true)

theorem identity11359 : scanCanonicalize (H12AffineFastState.compose env11359 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound11359 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11360 : List Nat := [2,4,8,16,32,0,25,37,16,1024,0,1076,41,1060,1,25,1060,1,1067,1,1077,33,0,57,57,17,0,1061,1076,0,1057,42,36,43,1061,17]

theorem envBound11360 : H12AffineFastState.Bounded env11360 := by
  intro p hp
  have h : env11360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11359_11360 : H12AffineEnvironment.transform 5 0 env11359 = env11360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env11359 == env11360) = true)

theorem identity11360 : scanCanonicalize (H12AffineFastState.compose env11360 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound11360 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env11361 : List Nat := [2,4,8,16,11,0,25,14,16,1024,0,1055,2,1039,1,25,1039,1,1024,1,1054,10,0,18,18,17,0,1038,1055,0,1034,1,15,0,1038,17]

theorem envBound11361 : H12AffineFastState.Bounded env11361 := by
  intro p hp
  have h : env11361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11360_11361 : H12AffineEnvironment.transform 4 11 env11360 = env11361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env11360 == env11361) = true)

def leafEnv11361 : List Nat := [2,4,8,16,11,0,25,14,16,1024,0,1055,2,1039,1,25,1039,1,1024,1,1054,10,0,18,1034,18,1,17,0,1038,1055,0,1034,1,15,0,5,8,1038,17,0,1054,1]

def active11361 : List Nat := [0,1,2,3,9]

def tree11361 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11361 : H12WitnessSearch.Good tree11361 := H12GlobalWitnessIndex.good

theorem leafIdentity11361 : H12AffineFastState.composeSystem env11361 rootObs = leafEnv11361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11361 rootObs == leafEnv11361) = true)

theorem terminalChecked11361 : H12PackedTerminal.terminalCheckFast leafEnv11361 active11361 tree11361 = true := by decide +kernel

def env11362 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,8201,17665,230469,8329,2098433,2515996,2117632,131152,1073741824,131141,4294967296,257,4297842870,131073,513]

theorem envBound11362 : H12AffineFastState.Bounded env11362 := by
  intro p hp
  have h : env11362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11320_11362 : H12AffineEnvironment.transform 10 1 env11320 = env11362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env11320 == env11362) = true)

def env11363 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,131072,262144,524288,32768,4096,8201,17665,230469,8329,5377,422940,16384,131152,1073741824,131141,4294967296,257,4295749814,131073,513]

theorem envBound11363 : H12AffineFastState.Bounded env11363 := by
  intro p hp
  have h : env11363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11362_11363 : H12AffineEnvironment.transform 20 4096 env11362 = env11363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env11362 == env11363) = true)

theorem identity11363 : scanCanonicalize (H12AffineFastState.compose env11363 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 133017) := by decide +kernel

theorem selectedBound11363 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env11364 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,131072,262144,524288,32768,4096,8201,17665,230469,8329,5377,422940,16384,131152,133017,131141,4294967296,257,4295749814,131073,513]

theorem envBound11364 : H12AffineFastState.Bounded env11364 := by
  intro p hp
  have h : env11364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11363_11364 : H12AffineEnvironment.transform 29 133017 env11363 = env11364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 133017 env11363 == env11364) = true)

theorem identity11364 : scanCanonicalize (H12AffineFastState.compose env11364 (packedSelected [0,4,6,7,16,20,22,25] rootPS)) = affineNative (2^(18+1) ^^^ 21585) := by decide +kernel

theorem selectedBound11364 : packedSelected [0,4,6,7,16,20,22,25] rootPS < 2^1333 := by decide +kernel

def env11365 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,131072,262144,21585,32768,4096,8201,17665,230469,8329,5377,422940,16384,131152,133017,131141,4294967296,257,4295206119,131073,513]

theorem envBound11365 : H12AffineFastState.Bounded env11365 := by
  intro p hp
  have h : env11365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11364_11365 : H12AffineEnvironment.transform 18 21585 env11364 = env11365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env11364 == env11365) = true)

theorem identity11365 : scanCanonicalize (H12AffineFastState.compose env11365 (packedSelected [4,9,16] rootPS)) = affineNative (2^(16+1) ^^^ 108315) := by decide +kernel

theorem selectedBound11365 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env11366 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,108315,262144,21585,32768,4096,8201,17665,9054,8329,5377,381703,16384,108363,106626,108382,4294967296,257,4294968316,108314,513]

theorem envBound11366 : H12AffineFastState.Bounded env11366 := by
  intro p hp
  have h : env11366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11365_11366 : H12AffineEnvironment.transform 16 108315 env11365 = env11366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 108315 env11365 == env11366) = true)

theorem identity11366 : scanCanonicalize (H12AffineFastState.compose env11366 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound11366 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env11367 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4177,32768,65536,108315,262144,1024,32768,4096,8201,5456,9054,8329,5377,361302,4177,108363,106626,108382,4294967296,257,4294968316,108314,513]

theorem envBound11367 : H12AffineFastState.Bounded env11367 := by
  intro p hp
  have h : env11367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11366_11367 : H12AffineEnvironment.transform 13 4177 env11366 = env11367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env11366 == env11367) = true)

theorem identity11367 : scanCanonicalize (H12AffineFastState.compose env11367 (packedSelected [13,21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound11367 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env11368 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4177,8540,65536,67143,262144,1024,8540,4096,8201,5456,9054,8329,5377,336394,4177,67095,66014,67074,4294967296,257,4294968316,67142,513]

theorem envBound11368 : H12AffineFastState.Bounded env11368 := by
  intro p hp
  have h : env11368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11367_11368 : H12AffineEnvironment.transform 14 8540 env11367 = env11368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env11367 == env11368) = true)

def env11369 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,131072,262144,524288,32768,4097,8201,17665,230469,8329,5376,422941,16385,131152,1073741824,131141,4294967296,257,4295749815,131073,513]

theorem envBound11369 : H12AffineFastState.Bounded env11369 := by
  intro p hp
  have h : env11369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11362_11369 : H12AffineEnvironment.transform 20 4097 env11362 = env11369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env11362 == env11369) = true)

theorem identity11369 : scanCanonicalize (H12AffineFastState.compose env11369 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 135896) := by decide +kernel

theorem selectedBound11369 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env11370 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,131072,262144,524288,32768,4097,8201,17665,230469,8329,5376,422941,16385,131152,135896,131141,4294967296,257,4295749815,131073,513]

theorem envBound11370 : H12AffineFastState.Bounded env11370 := by
  intro p hp
  have h : env11370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11369_11370 : H12AffineEnvironment.transform 29 135896 env11369 = env11370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 135896 env11369 == env11370) = true)

def env11371 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,4824,262144,524288,32768,4097,8201,17665,104093,8329,5376,288453,16385,4744,0,4765,4294967296,257,4295615087,4825,513]

theorem envBound11371 : H12AffineFastState.Bounded env11371 := by
  intro p hp
  have h : env11371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11370_11371 : H12AffineEnvironment.transform 16 4824 env11370 = env11371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4824 env11370 == env11371) = true)

def env11372 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1296,8192,16384,32768,65536,1992,262144,524288,32768,1297,8201,17665,99213,8329,16,288453,16385,1944,0,1933,4294967296,257,4295615087,1993,513]

theorem envBound11372 : H12AffineFastState.Bounded env11372 := by
  intro p hp
  have h : env11372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11371_11372 : H12AffineEnvironment.transform 11 1296 env11371 = env11372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env11371 == env11372) = true)

theorem identity11372 : scanCanonicalize (H12AffineFastState.compose env11372 (packedSelected [18] rootPS)) = affineNative (2^(17+1) ^^^ 50924) := by decide +kernel

theorem selectedBound11372 : packedSelected [18] rootPS < 2^1333 := by decide +kernel

def env11373 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1296,8192,16384,32768,65536,1992,50924,524288,32768,1297,8201,17665,99213,8329,16,41001,16385,1944,0,1933,4294967296,257,4295615087,1993,513]

theorem envBound11373 : H12AffineFastState.Bounded env11373 := by
  intro p hp
  have h : env11373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11372_11373 : H12AffineEnvironment.transform 17 50924 env11372 = env11373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 50924 env11372 == env11373) = true)

theorem identity11373 : scanCanonicalize (H12AffineFastState.compose env11373 (packedSelected [1,2,3,4,6,7,12,16,17,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound11373 : packedSelected [1,2,3,4,6,7,12,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env11374 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1296,269,16384,32768,65536,1992,50924,524288,32768,1297,260,17665,99213,388,16,33060,16385,1944,0,1933,4294967296,257,4295607138,1993,513]

theorem envBound11374 : H12AffineFastState.Bounded env11374 := by
  intro p hp
  have h : env11374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11373_11374 : H12AffineEnvironment.transform 12 269 env11373 = env11374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env11373 == env11374) = true)

theorem identity11374 : scanCanonicalize (H12AffineFastState.compose env11374 (packedSelected [4,5,8,9,13,15,16,19] rootPS)) = affineNative (2^(13+1) ^^^ 1992) := by decide +kernel

theorem selectedBound11374 : packedSelected [4,5,8,9,13,15,16,19] rootPS < 2^1333 := by decide +kernel

def env11375 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1296,269,1992,32768,65536,1992,33060,524288,32768,1297,260,713,99213,388,16,33060,1993,1944,0,1933,4294967296,257,4295591082,1993,513]

theorem envBound11375 : H12AffineFastState.Bounded env11375 := by
  intro p hp
  have h : env11375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11374_11375 : H12AffineEnvironment.transform 13 1992 env11374 = env11375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1992 env11374 == env11375) = true)

theorem identity11375 : scanCanonicalize (H12AffineFastState.compose env11375 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(18+1) ^^^ 99726) := by decide +kernel

theorem selectedBound11375 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env11376 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1296,269,1992,32768,65536,1992,33060,99726,32768,1297,260,713,99213,388,16,33060,1993,1944,0,1933,4294967296,257,4294967588,1993,513]

theorem envBound11376 : H12AffineFastState.Bounded env11376 := by
  intro p hp
  have h : env11376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11375_11376 : H12AffineEnvironment.transform 18 99726 env11375 = env11376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 99726 env11375 == env11376) = true)

theorem identity11376 : scanCanonicalize (H12AffineFastState.compose env11376 (packedSelected [0,7] rootPS)) = affineNative (2^(15+1) ^^^ 33542) := by decide +kernel

theorem selectedBound11376 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env11377 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1296,269,1992,32768,33542,1992,33060,1672,32768,1297,260,713,139,388,16,33060,1993,1944,0,1933,4294967296,257,4294967588,1993,513]

theorem envBound11377 : H12AffineFastState.Bounded env11377 := by
  intro p hp
  have h : env11377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11376_11377 : H12AffineEnvironment.transform 15 33542 env11376 = env11377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33542 env11376 == env11377) = true)

def env11378 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1297,8192,16384,32768,65536,1993,262144,524288,32768,1296,8201,17665,99212,8329,17,288453,16385,1945,0,1932,4294967296,257,4295615087,1992,513]

theorem envBound11378 : H12AffineFastState.Bounded env11378 := by
  intro p hp
  have h : env11378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11371_11378 : H12AffineEnvironment.transform 11 1297 env11371 = env11378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env11371 == env11378) = true)

theorem identity11378 : scanCanonicalize (H12AffineFastState.compose env11378 (packedSelected [18] rootPS)) = affineNative (2^(17+1) ^^^ 50276) := by decide +kernel

theorem selectedBound11378 : packedSelected [18] rootPS < 2^1333 := by decide +kernel

def env11379 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1297,8192,16384,32768,65536,1993,50276,524288,32768,1296,8201,17665,99212,8329,17,41633,16385,1945,0,1932,4294967296,257,4295615087,1992,513]

theorem envBound11379 : H12AffineFastState.Bounded env11379 := by
  intro p hp
  have h : env11379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11378_11379 : H12AffineEnvironment.transform 17 50276 env11378 = env11379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 50276 env11378 == env11379) = true)

theorem identity11379 : scanCanonicalize (H12AffineFastState.compose env11379 (packedSelected [0,1,2,3,6,9,12,17,19] rootPS)) = affineNative (2^(18+1) ^^^ 107651) := by decide +kernel

theorem selectedBound11379 : packedSelected [0,1,2,3,6,9,12,17,19] rootPS < 2^1333 := by decide +kernel

def env11380 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1297,8192,16384,32768,65536,1993,50276,107651,32768,1296,8201,17665,99212,8329,17,41633,16385,1945,0,1932,4294967296,257,4294985452,1992,513]

theorem envBound11380 : H12AffineFastState.Bounded env11380 := by
  intro p hp
  have h : env11380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11379_11380 : H12AffineEnvironment.transform 18 107651 env11379 = env11380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 107651 env11379 == env11380) = true)

theorem identity11380 : scanCanonicalize (H12AffineFastState.compose env11380 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(15+1) ^^^ 33543) := by decide +kernel

theorem selectedBound11380 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env11381 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1297,8192,16384,32768,33543,1993,50276,10116,32768,1296,8201,17665,139,8329,17,41633,16385,1945,0,1932,4294967296,257,4294985452,1992,513]

theorem envBound11381 : H12AffineFastState.Bounded env11381 := by
  intro p hp
  have h : env11381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11380_11381 : H12AffineEnvironment.transform 15 33543 env11380 = env11381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33543 env11380 == env11381) = true)

theorem identity11381 : scanCanonicalize (H12AffineFastState.compose env11381 (packedSelected [1,3,4,9,10,13,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 1992) := by decide +kernel

theorem selectedBound11381 : packedSelected [1,3,4,9,10,13,15,16] rootPS < 2^1333 := by decide +kernel

def env11382 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1297,8192,1992,32768,33543,1993,33708,10116,32768,1296,8201,713,139,8329,17,41633,1993,1945,0,1932,4294967296,257,4294967588,1992,513]

theorem envBound11382 : H12AffineFastState.Bounded env11382 := by
  intro p hp
  have h : env11382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11381_11382 : H12AffineEnvironment.transform 13 1992 env11381 = env11382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1992 env11381 == env11382) = true)

theorem identity11382 : scanCanonicalize (H12AffineFastState.compose env11382 (packedSelected [1,3,10,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound11382 : packedSelected [1,3,10,13,15] rootPS < 2^1333 := by decide +kernel

def env11383 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1297,269,1992,32768,33543,1993,33708,1673,32768,1296,260,713,139,388,17,33708,1993,1945,0,1932,4294967296,257,4294967588,1992,513]

theorem envBound11383 : H12AffineFastState.Bounded env11383 := by
  intro p hp
  have h : env11383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11382_11383 : H12AffineEnvironment.transform 12 269 env11382 = env11383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env11382 == env11383) = true)

def env11384 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,4825,262144,524288,32768,4097,8201,17665,104092,8329,5376,288452,16385,4745,1,4764,4294967296,257,4295615086,4824,513]

theorem envBound11384 : H12AffineFastState.Bounded env11384 := by
  intro p hp
  have h : env11384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11370_11384 : H12AffineEnvironment.transform 16 4825 env11370 = env11384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4825 env11370 == env11384) = true)

theorem identity11384 : scanCanonicalize (H12AffineFastState.compose env11384 (packedSelected [0,4,7,18,20,22] rootPS)) = affineNative (2^(17+1) ^^^ 61560) := by decide +kernel

theorem selectedBound11384 : packedSelected [0,4,7,18,20,22] rootPS < 2^1333 := by decide +kernel

def env11385 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,4825,61560,524288,32768,4097,8201,17665,104092,8329,5376,38588,16385,4745,1,4764,4294967296,257,4295615086,4824,513]

theorem envBound11385 : H12AffineFastState.Bounded env11385 := by
  intro p hp
  have h : env11385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11384_11385 : H12AffineEnvironment.transform 17 61560 env11384 = env11385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 61560 env11384 == env11385) = true)

theorem identity11385 : scanCanonicalize (H12AffineFastState.compose env11385 (packedSelected [16,18,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 9925) := by decide +kernel

theorem selectedBound11385 : packedSelected [16,18,20,23] rootPS < 2^1333 := by decide +kernel

def env11386 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,9925,32768,65536,4825,38589,524288,32768,4097,8201,9156,104092,8329,5376,38588,9924,4745,1,4764,4294967296,257,4295591083,4824,513]

theorem envBound11386 : H12AffineFastState.Bounded env11386 := by
  intro p hp
  have h : env11386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11385_11386 : H12AffineEnvironment.transform 13 9925 env11385 = env11386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9925 env11385 == env11386) = true)

def env11387 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1296,8192,9925,32768,65536,1993,33709,524288,32768,1297,8201,9156,99212,8329,16,33708,9924,1945,1,1932,4294967296,257,4295591083,1992,513]

theorem envBound11387 : H12AffineFastState.Bounded env11387 := by
  intro p hp
  have h : env11387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11386_11387 : H12AffineEnvironment.transform 11 1296 env11386 = env11387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env11386 == env11387) = true)

theorem identity11387 : scanCanonicalize (H12AffineFastState.compose env11387 (packedSelected [0,1,2,3,4,5,6,8,12,13,15,16,17] rootPS)) = affineNative (2^(15+1) ^^^ 9007) := by decide +kernel

theorem selectedBound11387 : packedSelected [0,1,2,3,4,5,6,8,12,13,15,16,17] rootPS < 2^1333 := by decide +kernel

def env11388 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1296,8192,9925,32768,9007,1993,33709,524288,32768,1297,8201,9156,41123,8329,16,33708,9924,1945,1,1932,4294967296,257,4295534468,1992,513]

theorem envBound11388 : H12AffineFastState.Bounded env11388 := by
  intro p hp
  have h : env11388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11387_11388 : H12AffineEnvironment.transform 15 9007 env11387 = env11388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9007 env11387 == env11388) = true)

theorem identity11388 : scanCanonicalize (H12AffineFastState.compose env11388 (packedSelected [1,2,3,4,6,7,10,12,13,16] rootPS)) = affineNative (2^(14+1) ^^^ 940) := by decide +kernel

theorem selectedBound11388 : packedSelected [1,2,3,4,6,7,10,12,13,16] rootPS < 2^1333 := by decide +kernel

def env11389 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1296,8192,9925,940,9007,1993,1,524288,940,1297,8201,9156,8975,8329,16,0,9924,1945,1,1932,4294967296,257,4295500840,1992,513]

theorem envBound11389 : H12AffineFastState.Bounded env11389 := by
  intro p hp
  have h : env11389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11388_11389 : H12AffineEnvironment.transform 14 940 env11388 = env11389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 940 env11388 == env11389) = true)

theorem identity11389 : scanCanonicalize (H12AffineFastState.compose env11389 (packedSelected [2,4,6,7] rootPS)) = affineNative (2^(18+1) ^^^ 1672) := by decide +kernel

theorem selectedBound11389 : packedSelected [2,4,6,7] rootPS < 2^1333 := by decide +kernel

def env11390 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1296,8192,9925,940,9007,1993,1,1672,940,1297,8201,9156,8975,8329,16,0,9924,1945,1,1932,4294967296,257,4294976160,1992,513]

theorem envBound11390 : H12AffineFastState.Bounded env11390 := by
  intro p hp
  have h : env11390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11389_11390 : H12AffineEnvironment.transform 18 1672 env11389 = env11390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1672 env11389 == env11390) = true)

theorem identity11390 : scanCanonicalize (H12AffineFastState.compose env11390 (packedSelected [0,2,6,9] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound11390 : packedSelected [0,2,6,9] rootPS < 2^1333 := by decide +kernel

def env11391 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1296,269,1992,940,546,1993,1,1672,940,1297,260,713,514,388,16,0,1993,1945,1,1932,4294967296,257,4294968237,1992,513]

theorem envBound11391 : H12AffineFastState.Bounded env11391 := by
  intro p hp
  have h : env11391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11390_11391 : H12AffineEnvironment.transform 12 269 env11390 = env11391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env11390 == env11391) = true)

theorem identity11391 : scanCanonicalize (H12AffineFastState.compose env11391 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound11391 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env11392 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,1296,269,1345,293,171,1344,1,1025,293,1297,260,64,139,388,16,0,1344,1296,1,1285,4294967296,257,4294967588,1345,136]

theorem envBound11392 : H12AffineFastState.Bounded env11392 := by
  intro p hp
  have h : env11392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11391_11392 : H12AffineEnvironment.transform 8 137 env11391 = env11392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env11391 == env11392) = true)

theorem identity11392 : scanCanonicalize (H12AffineFastState.compose env11392 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound11392 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11393 : List Nat := [2,4,8,16,32,64,128,36,137,1024,1,1076,41,1125,1,171,1124,1,1025,1,1077,32,64,139,160,16,0,1124,1076,1,1057,4294967296,37,4294967296,1125,136]

theorem envBound11393 : H12AffineFastState.Bounded env11393 := by
  intro p hp
  have h : env11393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11392_11393 : H12AffineEnvironment.transform 7 36 env11392 = env11393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env11392 == env11393) = true)

theorem identity11393 : scanCanonicalize (H12AffineFastState.compose env11393 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 75) := by decide +kernel

theorem selectedBound11393 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11394 : List Nat := [2,4,8,16,32,64,128,36,137,1024,1,1076,41,1125,1,171,1124,1,1025,1,1077,32,64,139,160,16,0,1124,1076,1,1057,75,37,75,1125,136]

theorem envBound11394 : H12AffineFastState.Bounded env11394 := by
  intro p hp
  have h : env11394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11393_11394 : H12AffineEnvironment.transform 31 75 env11393 = env11394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 75 env11393 == env11394) = true)

theorem identity11394 : scanCanonicalize (H12AffineFastState.compose env11394 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 67) := by decide +kernel

theorem selectedBound11394 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11395 : List Nat := [2,4,8,16,32,64,67,36,74,1024,1,1076,41,1125,1,104,1124,1,1025,1,1077,32,64,72,99,16,0,1124,1076,1,1057,75,37,75,1125,75]

theorem envBound11395 : H12AffineFastState.Bounded env11395 := by
  intro p hp
  have h : env11395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11394_11395 : H12AffineEnvironment.transform 6 67 env11394 = env11395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 67 env11394 == env11395) = true)

theorem identity11395 : scanCanonicalize (H12AffineFastState.compose env11395 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound11395 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11396 : List Nat := [2,4,8,11,32,64,67,36,74,1024,1,1071,41,1125,1,104,1124,1,1025,1,1070,32,64,72,99,11,0,1124,1071,1,1057,75,37,75,1125,75]

theorem envBound11396 : H12AffineFastState.Bounded env11396 := by
  intro p hp
  have h : env11396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11395_11396 : H12AffineEnvironment.transform 3 11 env11395 = env11396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env11395 == env11396) = true)

theorem identity11396 : scanCanonicalize (H12AffineFastState.compose env11396 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound11396 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env11397 : List Nat := [2,4,8,11,10,64,67,14,74,1024,1,1029,3,1103,1,66,1102,1,1025,1,1028,10,64,72,73,11,0,1102,1029,1,1035,75,15,75,1103,75]

theorem envBound11397 : H12AffineFastState.Bounded env11397 := by
  intro p hp
  have h : env11397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11396_11397 : H12AffineEnvironment.transform 4 10 env11396 = env11397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env11396 == env11397) = true)

theorem identity11397 : scanCanonicalize (H12AffineFastState.compose env11397 (packedSelected [5] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound11397 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env11398 : List Nat := [2,4,8,11,10,11,8,14,1,1024,1,1029,3,1028,1,9,1029,1,1025,1,1028,10,11,3,2,11,0,1029,1029,1,1035,0,15,0,1028,0]

theorem envBound11398 : H12AffineFastState.Bounded env11398 := by
  intro p hp
  have h : env11398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11397_11398 : H12AffineEnvironment.transform 5 11 env11397 = env11398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env11397 == env11398) = true)

def env11399 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1297,8192,9925,32768,65536,1992,33708,524288,32768,1296,8201,9156,99213,8329,17,33709,9924,1944,1,1933,4294967296,257,4295591083,1993,513]

theorem envBound11399 : H12AffineFastState.Bounded env11399 := by
  intro p hp
  have h : env11399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11386_11399 : H12AffineEnvironment.transform 11 1297 env11386 = env11399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env11386 == env11399) = true)

theorem identity11399 : scanCanonicalize (H12AffineFastState.compose env11399 (packedSelected [0,1,2,3,4,5,6,8,12,13,15,16,17] rootPS)) = affineNative (2^(14+1) ^^^ 8865) := by decide +kernel

theorem selectedBound11399 : packedSelected [0,1,2,3,4,5,6,8,12,13,15,16,17] rootPS < 2^1333 := by decide +kernel

def env11400 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1297,8192,9925,8865,65536,1992,8461,524288,8865,1296,8201,9156,74028,8329,17,8460,9924,1944,1,1933,4294967296,257,4295566858,1993,513]

theorem envBound11400 : H12AffineFastState.Bounded env11400 := by
  intro p hp
  have h : env11400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11399_11400 : H12AffineEnvironment.transform 14 8865 env11399 = env11400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8865 env11399 == env11400) = true)

theorem identity11400 : scanCanonicalize (H12AffineFastState.compose env11400 (packedSelected [0,2,3,5,6,9,10,12] rootPS)) = affineNative (2^(18+1) ^^^ 66730) := by decide +kernel

theorem selectedBound11400 : packedSelected [0,2,3,5,6,9,10,12] rootPS < 2^1333 := by decide +kernel

def env11401 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1297,8192,9925,8865,65536,1992,8461,66730,8865,1296,8201,9156,74028,8329,17,8460,9924,1944,1,1933,4294967296,257,4294976160,1993,513]

theorem envBound11401 : H12AffineFastState.Bounded env11401 := by
  intro p hp
  have h : env11401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11400_11401 : H12AffineEnvironment.transform 18 66730 env11400 = env11401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 66730 env11400 == env11401) = true)

theorem identity11401 : scanCanonicalize (H12AffineFastState.compose env11401 (packedSelected [0,1,5,7,13] rootPS)) = affineNative (2^(12+1) ^^^ 900) := by decide +kernel

theorem selectedBound11401 : packedSelected [0,1,5,7,13] rootPS < 2^1333 := by decide +kernel

def env11402 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1297,900,1345,293,65536,1992,649,66730,293,1296,909,64,66216,781,17,648,1344,1944,1,1933,4294967296,257,4294967588,1993,513]

theorem envBound11402 : H12AffineFastState.Bounded env11402 := by
  intro p hp
  have h : env11402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11401_11402 : H12AffineEnvironment.transform 12 900 env11401 = env11402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 900 env11401 == env11402) = true)

theorem identity11402 : scanCanonicalize (H12AffineFastState.compose env11402 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound11402 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env11403 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,1297,269,1345,293,65536,1345,0,66730,293,1296,260,64,65569,388,17,1,1344,1297,1,1284,4294967296,257,4294967588,1344,136]

theorem envBound11403 : H12AffineFastState.Bounded env11403 := by
  intro p hp
  have h : env11403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11402_11403 : H12AffineEnvironment.transform 8 137 env11402 = env11403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env11402 == env11403) = true)

theorem identity11403 : scanCanonicalize (H12AffineFastState.compose env11403 (packedSelected [2,3,4,10] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound11403 : packedSelected [2,3,4,10] rootPS < 2^1333 := by decide +kernel

def env11404 : List Nat := [2,4,8,16,32,64,128,37,137,1024,1,1076,40,1124,0,65536,1124,0,66730,0,1077,33,64,65569,161,17,1,1125,1076,1,1057,4294967296,36,4294967297,1125,136]

theorem envBound11404 : H12AffineFastState.Bounded env11404 := by
  intro p hp
  have h : env11404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11403_11404 : H12AffineEnvironment.transform 7 37 env11403 = env11404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env11403 == env11404) = true)

theorem identity11404 : scanCanonicalize (H12AffineFastState.compose env11404 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 65625) := by decide +kernel

theorem selectedBound11404 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11405 : List Nat := [2,4,8,16,32,64,128,37,137,1024,1,1076,40,1124,0,65536,1124,0,66730,0,1077,33,64,65569,161,17,1,1125,1076,1,1057,65625,36,65624,1125,136]

theorem envBound11405 : H12AffineFastState.Bounded env11405 := by
  intro p hp
  have h : env11405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11404_11405 : H12AffineEnvironment.transform 31 65625 env11404 = env11405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 65625 env11404 == env11405) = true)

theorem identity11405 : scanCanonicalize (H12AffineFastState.compose env11405 (packedSelected [1,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound11405 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env11406 : List Nat := [2,4,8,16,32,64,25,37,16,1024,1,1076,40,1124,0,65536,1124,0,66611,0,1077,33,64,65569,56,17,1,1125,1076,1,1057,65625,36,65624,1125,17]

theorem envBound11406 : H12AffineFastState.Bounded env11406 := by
  intro p hp
  have h : env11406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11405_11406 : H12AffineEnvironment.transform 6 25 env11405 = env11406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env11405 == env11406) = true)

def env11407 : List Nat := [2,4,8,16,32,64,25,37,16,1024,1,1076,40,1124,0,88,1124,0,1131,0,1077,33,64,121,56,17,1,1125,1076,1,1057,1,36,0,1125,17]

theorem envBound11407 : H12AffineFastState.Bounded env11407 := by
  intro p hp
  have h : env11407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11406_11407 : H12AffineEnvironment.transform 15 88 env11406 = env11407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 88 env11406 == env11407) = true)

theorem identity11407 : scanCanonicalize (H12AffineFastState.compose env11407 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound11407 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11408 : List Nat := [2,4,8,16,32,0,25,37,16,1024,1,1076,40,1060,0,24,1060,0,1067,0,1077,33,0,57,56,17,1,1061,1076,1,1057,1,36,0,1061,17]

theorem envBound11408 : H12AffineFastState.Bounded env11408 := by
  intro p hp
  have h : env11408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11407_11408 : H12AffineEnvironment.transform 5 0 env11407 = env11408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env11407 == env11408) = true)

theorem identity11408 : scanCanonicalize (H12AffineFastState.compose env11408 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound11408 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env11409 : List Nat := [2,4,8,16,11,0,25,14,16,1024,1,1055,3,1039,0,24,1039,0,1024,0,1054,10,0,18,19,17,1,1038,1055,1,1034,1,15,0,1038,17]

theorem envBound11409 : H12AffineFastState.Bounded env11409 := by
  intro p hp
  have h : env11409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11408_11409 : H12AffineEnvironment.transform 4 11 env11408 = env11409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env11408 == env11409) = true)

def leafEnv11409 : List Nat := [2,4,8,16,11,0,25,14,16,1024,1,1055,3,1039,0,24,1039,0,1024,0,1054,10,0,18,1034,19,1,17,1,1038,1055,1,1034,1,15,0,5,9,1038,17,0,1054,1]

def active11409 : List Nat := [0,1,2,3,9]

def tree11409 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11409 : H12WitnessSearch.Good tree11409 := H12GlobalWitnessIndex.good

theorem leafIdentity11409 : H12AffineFastState.composeSystem env11409 rootObs = leafEnv11409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11409 rootObs == leafEnv11409) = true)

theorem terminalChecked11409 : H12PackedTerminal.terminalCheckFast leafEnv11409 active11409 tree11409 = true := by decide +kernel

def env11410 : List Nat := [2,4,8,16,32,64,25,37,16,1024,1,1076,40,1124,0,89,1124,0,1130,0,1077,33,64,120,56,17,1,1125,1076,1,1057,0,36,1,1125,17]

theorem envBound11410 : H12AffineFastState.Bounded env11410 := by
  intro p hp
  have h : env11410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11406_11410 : H12AffineEnvironment.transform 15 89 env11406 = env11410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 89 env11406 == env11410) = true)

theorem identity11410 : scanCanonicalize (H12AffineFastState.compose env11410 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound11410 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11411 : List Nat := [2,4,8,16,10,64,25,15,16,1024,1,1054,2,1102,0,89,1102,0,1088,0,1055,11,64,82,18,17,1,1103,1054,1,1035,0,14,1,1103,17]

theorem envBound11411 : H12AffineFastState.Bounded env11411 := by
  intro p hp
  have h : env11411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11410_11411 : H12AffineEnvironment.transform 4 10 env11410 = env11411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env11410 == env11411) = true)

def env11412 : List Nat := [2,4,8,16,10,0,25,15,16,1024,1,1054,2,1038,0,25,1038,0,1024,0,1055,11,0,18,18,17,1,1039,1054,1,1035,0,14,1,1039,17]

theorem envBound11412 : H12AffineFastState.Bounded env11412 := by
  intro p hp
  have h : env11412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11411_11412 : H12AffineEnvironment.transform 5 0 env11411 = env11412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env11411 == env11412) = true)

def leafEnv11412 : List Nat := [2,4,8,16,10,0,25,15,16,1024,1,1054,2,1038,0,25,1038,0,1024,0,1055,11,0,18,1035,18,1,17,1,1039,1054,1,1035,0,14,1,5,8,1039,17,0,1055,1]

def active11412 : List Nat := [0,1,2,3,9]

def tree11412 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11412 : H12WitnessSearch.Good tree11412 := H12GlobalWitnessIndex.good

theorem leafIdentity11412 : H12AffineFastState.composeSystem env11412 rootObs = leafEnv11412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11412 rootObs == leafEnv11412) = true)

theorem terminalChecked11412 : H12PackedTerminal.terminalCheckFast leafEnv11412 active11412 tree11412 = true := by decide +kernel

def env11413 : List Nat := [2,4,8,16,10,1,25,15,16,1024,1,1054,2,1039,0,24,1039,0,1025,0,1055,11,1,19,18,17,1,1038,1054,1,1035,0,14,1,1038,17]

theorem envBound11413 : H12AffineFastState.Bounded env11413 := by
  intro p hp
  have h : env11413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11411_11413 : H12AffineEnvironment.transform 5 1 env11411 = env11413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env11411 == env11413) = true)

theorem identity11413 : scanCanonicalize (H12AffineFastState.compose env11413 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound11413 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11414 : List Nat := [2,4,2,16,0,1,19,5,16,1024,1,1044,2,1029,0,18,1029,0,1025,0,1045,1,1,19,18,17,1,1028,1044,1,1025,0,4,1,1028,17]

theorem envBound11414 : H12AffineFastState.Bounded env11414 := by
  intro p hp
  have h : env11414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11413_11414 : H12AffineEnvironment.transform 2 2 env11413 = env11414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env11413 == env11414) = true)

def leafEnv11414 : List Nat := [2,4,2,16,0,1,19,5,16,1024,1,1044,2,1029,0,18,1029,0,1025,0,1045,1,1,19,1024,18,1,17,1,1028,1044,1,1025,0,4,1,5,2,1028,17,0,1045,1]

def active11414 : List Nat := [0,1,3,9]

def tree11414 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11414 : H12WitnessSearch.Good tree11414 := H12GlobalWitnessIndex.good

theorem leafIdentity11414 : H12AffineFastState.composeSystem env11414 rootObs = leafEnv11414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11414 rootObs == leafEnv11414) = true)

theorem terminalChecked11414 : H12PackedTerminal.terminalCheckFast leafEnv11414 active11414 tree11414 = true := by decide +kernel

def env11415 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,10249,17665,230469,33554432,2098433,2518044,2117632,131152,1073741824,131141,4294967296,257,4331391039,131073,33563272]

theorem envBound11415 : H12AffineFastState.Bounded env11415 := by
  intro p hp
  have h : env11415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11251_11415 : H12AffineEnvironment.transform 21 10249 env11251 = env11415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10249 env11251 == env11415) = true)

def env11416 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,10249,17665,230469,8328,2098433,2518044,2117632,131152,1073741824,131141,4294967296,257,4297844919,131073,512]

theorem envBound11416 : H12AffineFastState.Bounded env11416 := by
  intro p hp
  have h : env11416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11415_11416 : H12AffineEnvironment.transform 24 8328 env11415 = env11416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8328 env11415 == env11416) = true)

theorem identity11416 : scanCanonicalize (H12AffineFastState.compose env11416 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(29+1) ^^^ 2220243) := by decide +kernel

theorem selectedBound11416 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env11417 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,10249,17665,230469,8328,2098433,2518044,2117632,131152,2220243,131141,4294967296,257,4297844919,131073,512]

theorem envBound11417 : H12AffineFastState.Bounded env11417 := by
  intro p hp
  have h : env11417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11416_11417 : H12AffineEnvironment.transform 29 2220243 env11416 = env11417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 2220243 env11416 == env11417) = true)

theorem identity11417 : scanCanonicalize (H12AffineFastState.compose env11417 (packedSelected [0,1,4,5,6,7,8,16,19,20,22,24,25,26] rootPS)) = affineNative (2^(20+1) ^^^ 57693) := by decide +kernel

theorem selectedBound11417 : packedSelected [0,1,4,5,6,7,8,16,19,20,22,24,25,26] rootPS < 2^1333 := by decide +kernel

def env11418 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,57693,10249,17665,230469,8328,58460,429377,45405,131152,65934,131141,4294967296,257,4295690730,131073,512]

theorem envBound11418 : H12AffineFastState.Bounded env11418 := by
  intro p hp
  have h : env11418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11417_11418 : H12AffineEnvironment.transform 20 57693 env11417 = env11418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 57693 env11417 == env11418) = true)

theorem identity11418 : scanCanonicalize (H12AffineFastState.compose env11418 (packedSelected [1,3,6,17,21,24,25,28] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound11418 : packedSelected [1,3,6,17,21,24,25,28] rootPS < 2^1333 := by decide +kernel

def env11419 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8461,65536,131072,262144,524288,8461,16464,10249,17665,206152,8328,17745,404556,4176,131152,65934,131141,4294967296,257,4295690730,131073,512]

theorem envBound11419 : H12AffineFastState.Bounded env11419 := by
  intro p hp
  have h : env11419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11418_11419 : H12AffineEnvironment.transform 14 8461 env11418 = env11419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env11418 == env11419) = true)

theorem identity11419 : scanCanonicalize (H12AffineFastState.compose env11419 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(16+1) ^^^ 11460) := by decide +kernel

theorem selectedBound11419 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env11420 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8461,65536,11460,262144,524288,8461,16464,10249,17665,67980,8328,17745,262280,4176,11412,65934,11393,4294967296,257,4295566638,11461,512]

theorem envBound11420 : H12AffineFastState.Bounded env11420 := by
  intro p hp
  have h : env11420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11419_11420 : H12AffineEnvironment.transform 16 11460 env11419 = env11420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 11460 env11419 == env11420) = true)

def env11421 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8461,65536,11460,2048,524288,8461,16464,10249,17665,67980,8328,17745,2184,4176,11412,65934,11393,4294967296,257,4295566638,11461,512]

theorem envBound11421 : H12AffineFastState.Bounded env11421 := by
  intro p hp
  have h : env11421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11420_11421 : H12AffineEnvironment.transform 17 2048 env11420 = env11421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2048 env11420 == env11421) = true)

theorem identity11421 : scanCanonicalize (H12AffineFastState.compose env11421 (packedSelected [0,4,7,11,16,22,23] rootPS)) = affineNative (2^(15+1) ^^^ 2310) := by decide +kernel

theorem selectedBound11421 : packedSelected [0,4,7,11,16,22,23] rootPS < 2^1333 := by decide +kernel

def env11422 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8461,2310,11460,2048,524288,8461,16464,10249,17665,138,8328,17745,2184,4176,11412,2184,11393,4294967296,257,4295502888,11461,512]

theorem envBound11422 : H12AffineFastState.Bounded env11422 := by
  intro p hp
  have h : env11422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11421_11422 : H12AffineEnvironment.transform 15 2310 env11421 = env11422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2310 env11421 == env11422) = true)

theorem identity11422 : scanCanonicalize (H12AffineFastState.compose env11422 (packedSelected [16,20] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound11422 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env11423 : List Nat := [2,4,8,16,32,64,128,37,512,1024,2048,4096,8192,16384,8232,2083,11460,2048,524288,8232,16464,10249,17444,138,8328,17524,2184,4176,11412,2184,11393,4294967296,36,4295502888,11461,512]

theorem envBound11423 : H12AffineFastState.Bounded env11423 := by
  intro p hp
  have h : env11423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11422_11423 : H12AffineEnvironment.transform 7 37 env11422 = env11423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env11422 == env11423) = true)

theorem identity11423 : scanCanonicalize (H12AffineFastState.compose env11423 (packedSelected [0,2,9] rootPS)) = affineNative (2^(31+1) ^^^ 546347) := by decide +kernel

theorem selectedBound11423 : packedSelected [0,2,9] rootPS < 2^1333 := by decide +kernel

def env11424 : List Nat := [2,4,8,16,32,64,128,37,512,1024,2048,4096,8192,16384,8232,2083,11460,2048,524288,8232,16464,10249,17444,138,8328,17524,2184,4176,11412,2184,11393,546347,36,31235,11461,512]

theorem envBound11424 : H12AffineFastState.Bounded env11424 := by
  intro p hp
  have h : env11424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11423_11424 : H12AffineEnvironment.transform 31 546347 env11423 = env11424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 546347 env11423 == env11424) = true)

def env11425 : List Nat := [2,4,8,16,32,64,128,37,512,1024,2048,4096,8192,4176,8232,2083,11460,2048,524288,8232,4096,10249,5236,138,8328,5156,2184,4176,11412,2184,11393,525947,36,10835,11461,512]

theorem envBound11425 : H12AffineFastState.Bounded env11425 := by
  intro p hp
  have h : env11425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11424_11425 : H12AffineEnvironment.transform 13 4176 env11424 = env11425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env11424 == env11425) = true)

theorem identity11425 : scanCanonicalize (H12AffineFastState.compose env11425 (packedSelected [2,4,6,7] rootPS)) = affineNative (2^(18+1) ^^^ 14903) := by decide +kernel

theorem selectedBound11425 : packedSelected [2,4,6,7] rootPS < 2^1333 := by decide +kernel

def env11426 : List Nat := [2,4,8,16,32,64,128,37,512,1024,2048,4096,8192,4176,8232,2083,11460,2048,14903,8232,4096,10249,5236,138,8328,5156,2184,4176,11412,2184,11393,15436,36,10835,11461,512]

theorem envBound11426 : H12AffineFastState.Bounded env11426 := by
  intro p hp
  have h : env11426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11425_11426 : H12AffineEnvironment.transform 18 14903 env11425 = env11426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 14903 env11425 == env11426) = true)

theorem identity11426 : scanCanonicalize (H12AffineFastState.compose env11426 (packedSelected [11] rootPS)) = affineNative (2^(12+1) ^^^ 208) := by decide +kernel

theorem selectedBound11426 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env11427 : List Nat := [2,4,8,16,32,64,128,37,512,1024,2048,4096,208,4176,248,2083,3092,2048,6887,248,4096,2265,5236,138,88,5156,2184,4176,3140,2184,3153,7324,36,2691,3093,512]

theorem envBound11427 : H12AffineFastState.Bounded env11427 := by
  intro p hp
  have h : env11427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11426_11427 : H12AffineEnvironment.transform 12 208 env11426 = env11427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 208 env11426 == env11427) = true)

theorem identity11427 : scanCanonicalize (H12AffineFastState.compose env11427 (packedSelected [0,2,3,4,5,6,10,12] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound11427 : packedSelected [0,2,3,4,5,6,10,12] rootPS < 2^1333 := by decide +kernel

def env11428 : List Nat := [2,4,8,16,32,64,128,37,42,1024,2048,4096,208,4176,248,2083,3092,2048,6349,248,4096,2265,5236,138,88,5156,2184,4176,3140,2184,3153,7324,36,2217,3093,42]

theorem envBound11428 : H12AffineFastState.Bounded env11428 := by
  intro p hp
  have h : env11428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11427_11428 : H12AffineEnvironment.transform 8 42 env11427 = env11428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env11427 == env11428) = true)

theorem identity11428 : scanCanonicalize (H12AffineFastState.compose env11428 (packedSelected [1,3,6] rootPS)) = affineNative (2^(10+1) ^^^ 249) := by decide +kernel

theorem selectedBound11428 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env11429 : List Nat := [2,4,8,16,32,64,128,37,42,1024,249,4096,208,4176,248,218,1261,249,4148,248,4096,32,5236,138,88,5156,113,4176,1213,113,1192,5221,36,80,1260,42]

theorem envBound11429 : H12AffineFastState.Bounded env11429 := by
  intro p hp
  have h : env11429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11428_11429 : H12AffineEnvironment.transform 10 249 env11428 = env11429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 249 env11428 == env11429) = true)

theorem identity11429 : scanCanonicalize (H12AffineFastState.compose env11429 (packedSelected [0,2,4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound11429 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env11430 : List Nat := [2,4,8,16,32,64,9,37,42,1024,112,4096,89,4176,113,83,1124,112,4148,113,4096,32,5236,3,88,5156,113,4176,1076,113,1057,5221,36,80,1125,42]

theorem envBound11430 : H12AffineFastState.Bounded env11430 := by
  intro p hp
  have h : env11430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11429_11430 : H12AffineEnvironment.transform 6 9 env11429 = env11430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11429 == env11430) = true)

theorem identity11430 : scanCanonicalize (H12AffineFastState.compose env11430 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 18) := by decide +kernel

theorem selectedBound11430 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11431 : List Nat := [2,4,8,16,32,18,9,37,42,1024,34,4096,11,4098,35,1,1078,34,4148,35,4096,32,5158,3,10,5156,35,4098,1076,35,1057,5175,36,2,1079,42]

theorem envBound11431 : H12AffineFastState.Bounded env11431 := by
  intro p hp
  have h : env11431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11430_11431 : H12AffineEnvironment.transform 5 18 env11430 = env11431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 18 env11430 == env11431) = true)

theorem identity11431 : scanCanonicalize (H12AffineFastState.compose env11431 (packedSelected [10,13] rootPS)) = affineNative (2^(11+1) ^^^ 50) := by decide +kernel

theorem selectedBound11431 : packedSelected [10,13] rootPS < 2^1333 := by decide +kernel

def env11432 : List Nat := [2,4,8,16,32,18,9,37,42,1024,34,50,11,48,35,1,1078,34,6,35,50,32,1044,3,10,1046,35,48,1076,35,1057,1029,36,2,1079,42]

theorem envBound11432 : H12AffineFastState.Bounded env11432 := by
  intro p hp
  have h : env11432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11431_11432 : H12AffineEnvironment.transform 11 50 env11431 = env11432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 50 env11431 == env11432) = true)

theorem identity11432 : scanCanonicalize (H12AffineFastState.compose env11432 (packedSelected [2,22] rootPS)) = affineNative (2^(9+1) ^^^ 6) := by decide +kernel

theorem selectedBound11432 : packedSelected [2,22] rootPS < 2^1333 := by decide +kernel

def env11433 : List Nat := [2,4,8,16,32,18,9,37,42,6,34,50,11,48,35,1,48,34,6,35,50,32,18,3,10,16,35,48,50,35,39,3,36,2,49,42]

theorem envBound11433 : H12AffineFastState.Bounded env11433 := by
  intro p hp
  have h : env11433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11432_11433 : H12AffineEnvironment.transform 9 6 env11432 = env11433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 6 env11432 == env11433) = true)

theorem identity11433 : scanCanonicalize (H12AffineFastState.compose env11433 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 9) := by decide +kernel

theorem selectedBound11433 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11434 : List Nat := [2,4,8,16,9,18,9,12,3,6,11,27,11,25,10,1,25,11,6,10,27,9,18,3,10,16,10,25,27,10,14,3,13,2,24,3]

theorem envBound11434 : H12AffineFastState.Bounded env11434 := by
  intro p hp
  have h : env11434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11433_11434 : H12AffineEnvironment.transform 4 9 env11433 = env11434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 9 env11433 == env11434) = true)

theorem identity11434 : scanCanonicalize (H12AffineFastState.compose env11434 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound11434 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11435 : List Nat := [2,4,3,16,2,18,2,7,3,6,0,16,0,18,1,1,18,0,6,1,16,2,18,3,1,16,1,18,16,1,5,3,6,2,19,3]

theorem envBound11435 : H12AffineFastState.Bounded env11435 := by
  intro p hp
  have h : env11435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11434_11435 : H12AffineEnvironment.transform 2 3 env11434 = env11435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env11434 == env11435) = true)

def leafEnv11435 : List Nat := [2,4,3,16,2,18,2,7,3,6,0,16,0,18,1,1,18,0,6,1,16,2,18,3,5,1,1,16,1,18,16,1,5,3,6,2,5,0,19,3,0,17,1]

def active11435 : List Nat := [0,1,3]

def tree11435 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11435 : H12WitnessSearch.Good tree11435 := H12GlobalWitnessIndex.good

theorem leafIdentity11435 : H12AffineFastState.composeSystem env11435 rootObs = leafEnv11435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11435 rootObs == leafEnv11435) = true)

theorem terminalChecked11435 : H12PackedTerminal.terminalCheckFast leafEnv11435 active11435 tree11435 = true := by decide +kernel

def env11436 : List Nat := [2,4,8,16,32,64,128,37,512,1024,2048,4096,8192,4177,8232,2083,11460,2048,524288,8232,4097,10249,5237,138,8328,5157,2184,4176,11412,2184,11393,525946,36,10834,11461,512]

theorem envBound11436 : H12AffineFastState.Bounded env11436 := by
  intro p hp
  have h : env11436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11424_11436 : H12AffineEnvironment.transform 13 4177 env11424 = env11436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env11424 == env11436) = true)

theorem identity11436 : scanCanonicalize (H12AffineFastState.compose env11436 (packedSelected [2,4,6,7] rootPS)) = affineNative (2^(18+1) ^^^ 4758) := by decide +kernel

theorem selectedBound11436 : packedSelected [2,4,6,7] rootPS < 2^1333 := by decide +kernel

def env11437 : List Nat := [2,4,8,16,32,64,128,37,512,1024,2048,4096,8192,4177,8232,2083,11460,2048,4758,8232,4097,10249,5237,138,8328,5157,2184,4176,11412,2184,11393,5356,36,10834,11461,512]

theorem envBound11437 : H12AffineFastState.Bounded env11437 := by
  intro p hp
  have h : env11437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11436_11437 : H12AffineEnvironment.transform 18 4758 env11436 = env11437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4758 env11436 == env11437) = true)

theorem identity11437 : scanCanonicalize (H12AffineFastState.compose env11437 (packedSelected [11] rootPS)) = affineNative (2^(12+1) ^^^ 5300) := by decide +kernel

theorem selectedBound11437 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env11438 : List Nat := [2,4,8,16,32,64,128,37,512,1024,2048,4096,5300,4177,5276,2083,6256,2048,4758,5276,4097,7357,5237,138,5180,5157,2184,4176,6176,2184,6197,5356,36,7910,6257,512]

theorem envBound11438 : H12AffineFastState.Bounded env11438 := by
  intro p hp
  have h : env11438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11437_11438 : H12AffineEnvironment.transform 12 5300 env11437 = env11438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5300 env11437 == env11438) = true)

def env11439 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8461,65536,11460,2049,524288,8461,16464,10249,17665,67980,8328,17745,2185,4176,11412,65934,11393,4294967296,257,4295566638,11461,512]

theorem envBound11439 : H12AffineFastState.Bounded env11439 := by
  intro p hp
  have h : env11439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11420_11439 : H12AffineEnvironment.transform 17 2049 env11420 = env11439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2049 env11420 == env11439) = true)

theorem identity11439 : scanCanonicalize (H12AffineFastState.compose env11439 (packedSelected [0,4,7,11,16,22,23] rootPS)) = affineNative (2^(15+1) ^^^ 2082) := by decide +kernel

theorem selectedBound11439 : packedSelected [0,4,7,11,16,22,23] rootPS < 2^1333 := by decide +kernel

def env11440 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8461,2082,11460,2049,524288,8461,16464,10249,17665,430,8328,17745,2185,4176,11412,2476,11393,4294967296,257,4295503116,11461,512]

theorem envBound11440 : H12AffineFastState.Bounded env11440 := by
  intro p hp
  have h : env11440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11439_11440 : H12AffineEnvironment.transform 15 2082 env11439 = env11440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2082 env11439 == env11440) = true)

theorem identity11440 : scanCanonicalize (H12AffineFastState.compose env11440 (packedSelected [0,2,9] rootPS)) = affineNative (2^(31+1) ^^^ 546695) := by decide +kernel

theorem selectedBound11440 : packedSelected [0,2,9] rootPS < 2^1333 := by decide +kernel

def env11441 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8461,2082,11460,2049,524288,8461,16464,10249,17665,430,8328,17745,2185,4176,11412,2476,11393,546695,257,31371,11461,512]

theorem envBound11441 : H12AffineFastState.Bounded env11441 := by
  intro p hp
  have h : env11441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11440_11441 : H12AffineEnvironment.transform 31 546695 env11440 = env11441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 546695 env11440 == env11441) = true)

theorem identity11441 : scanCanonicalize (H12AffineFastState.compose env11441 (packedSelected [11,18,20] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound11441 : packedSelected [11,18,20] rootPS < 2^1333 := by decide +kernel

def env11442 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,8192,16384,8233,2082,11460,2049,524288,8233,16464,10249,17445,138,8328,17525,2185,4176,11412,2184,11393,546467,37,31371,11461,512]

theorem envBound11442 : H12AffineFastState.Bounded env11442 := by
  intro p hp
  have h : env11442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11441_11442 : H12AffineEnvironment.transform 7 36 env11441 = env11442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env11441 == env11442) = true)

def env11443 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,8192,4176,8233,2082,11460,2049,524288,8233,4096,10249,5237,138,8328,5157,2185,4176,11412,2184,11393,526067,37,10971,11461,512]

theorem envBound11443 : H12AffineFastState.Bounded env11443 := by
  intro p hp
  have h : env11443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11442_11443 : H12AffineEnvironment.transform 13 4176 env11442 = env11443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env11442 == env11443) = true)

theorem identity11443 : scanCanonicalize (H12AffineFastState.compose env11443 (packedSelected [2,4,6,7] rootPS)) = affineNative (2^(18+1) ^^^ 15038) := by decide +kernel

theorem selectedBound11443 : packedSelected [2,4,6,7] rootPS < 2^1333 := by decide +kernel

def env11444 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,8192,4176,8233,2082,11460,2049,15038,8233,4096,10249,5237,138,8328,5157,2185,4176,11412,2184,11393,15437,37,10971,11461,512]

theorem envBound11444 : H12AffineFastState.Bounded env11444 := by
  intro p hp
  have h : env11444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11443_11444 : H12AffineEnvironment.transform 18 15038 env11443 = env11444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 15038 env11443 == env11444) = true)

theorem identity11444 : scanCanonicalize (H12AffineFastState.compose env11444 (packedSelected [11] rootPS)) = affineNative (2^(12+1) ^^^ 209) := by decide +kernel

theorem selectedBound11444 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env11445 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,209,4176,248,2082,3093,2049,6767,248,4096,2264,5237,138,89,5157,2185,4176,3141,2184,3152,7324,37,2570,3092,512]

theorem envBound11445 : H12AffineFastState.Bounded env11445 := by
  intro p hp
  have h : env11445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11444_11445 : H12AffineEnvironment.transform 12 209 env11444 = env11445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 209 env11444 == env11445) = true)

theorem identity11445 : scanCanonicalize (H12AffineFastState.compose env11445 (packedSelected [0,2,6,22] rootPS)) = affineNative (2^(11+1) ^^^ 1567) := by decide +kernel

theorem selectedBound11445 : packedSelected [0,2,6,22] rootPS < 2^1333 := by decide +kernel

def env11446 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,1567,209,1615,248,2082,3093,2049,3184,248,1567,2264,618,138,89,570,2185,1615,3141,2184,3152,2691,37,2570,3092,512]

theorem envBound11446 : H12AffineFastState.Bounded env11446 := by
  intro p hp
  have h : env11446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11445_11446 : H12AffineEnvironment.transform 11 1567 env11445 = env11446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1567 env11445 == env11446) = true)

def env11447 : List Nat := [2,4,8,16,32,32,128,36,512,1024,2048,1567,177,1583,152,2082,3093,2049,3088,152,1567,2232,522,138,57,570,2185,1583,3109,2184,3120,2691,37,2570,3092,512]

theorem envBound11447 : H12AffineFastState.Bounded env11447 := by
  intro p hp
  have h : env11447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11446_11447 : H12AffineEnvironment.transform 5 32 env11446 = env11447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env11446 == env11447) = true)

theorem identity11447 : scanCanonicalize (H12AffineFastState.compose env11447 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 58) := by decide +kernel

theorem selectedBound11447 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11448 : List Nat := [2,4,8,16,32,32,58,36,512,1024,2048,1567,11,1583,34,2082,3093,2049,3088,34,1567,2050,522,48,57,570,2099,1583,3109,2098,3120,2617,37,2570,3092,512]

theorem envBound11448 : H12AffineFastState.Bounded env11448 := by
  intro p hp
  have h : env11448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11447_11448 : H12AffineEnvironment.transform 6 58 env11447 = env11448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 58 env11447 == env11448) = true)

def env11449 : List Nat := [2,4,8,16,32,32,58,36,512,1024,16,1567,11,1583,34,50,1029,17,1024,34,1567,18,522,48,57,570,35,1583,1077,34,1056,553,37,538,1028,512]

theorem envBound11449 : H12AffineFastState.Bounded env11449 := by
  intro p hp
  have h : env11449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11448_11449 : H12AffineEnvironment.transform 10 16 env11448 = env11449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env11448 == env11449) = true)

theorem identity11449 : scanCanonicalize (H12AffineFastState.compose env11449 (packedSelected [2,4] rootPS)) = affineNative (2^(4+1) ^^^ 18) := by decide +kernel

theorem selectedBound11449 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env11450 : List Nat := [2,4,8,16,18,18,8,22,512,1024,16,1567,11,1565,16,0,1029,17,1024,16,1567,18,522,2,11,520,17,1565,1031,16,1042,539,23,538,1028,512]

theorem envBound11450 : H12AffineFastState.Bounded env11450 := by
  intro p hp
  have h : env11450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11449_11450 : H12AffineEnvironment.transform 4 18 env11449 = env11450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 18 env11449 == env11450) = true)

theorem identity11450 : scanCanonicalize (H12AffineFastState.compose env11450 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 542) := by decide +kernel

theorem selectedBound11450 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env11451 : List Nat := [2,4,8,16,18,18,8,22,512,542,16,1,11,3,16,0,539,17,542,16,1,18,522,2,11,520,17,3,537,16,524,539,23,538,538,512]

theorem envBound11451 : H12AffineFastState.Bounded env11451 := by
  intro p hp
  have h : env11451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11450_11451 : H12AffineEnvironment.transform 9 542 env11450 = env11451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 542 env11450 == env11451) = true)

theorem identity11451 : scanCanonicalize (H12AffineFastState.compose env11451 (packedSelected [10] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound11451 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env11452 : List Nat := [2,4,8,10,8,8,8,12,512,516,10,1,11,3,10,0,513,11,516,10,1,8,522,2,11,520,11,3,515,10,524,513,13,512,512,512]

theorem envBound11452 : H12AffineFastState.Bounded env11452 := by
  intro p hp
  have h : env11452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11451_11452 : H12AffineEnvironment.transform 3 10 env11451 = env11452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env11451 == env11452) = true)

theorem identity11452 : scanCanonicalize (H12AffineFastState.compose env11452 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 9) := by decide +kernel

theorem selectedBound11452 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11453 : List Nat := [2,4,8,10,8,8,8,12,9,13,10,1,11,3,10,0,8,11,13,10,1,8,3,2,11,1,11,3,10,10,5,8,13,9,9,9]

theorem envBound11453 : H12AffineFastState.Bounded env11453 := by
  intro p hp
  have h : env11453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11452_11453 : H12AffineEnvironment.transform 8 9 env11452 = env11453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env11452 == env11453) = true)

def env11454 : List Nat := [2,4,0,2,0,0,0,4,1,5,2,1,3,3,2,0,0,3,5,2,1,0,3,2,3,1,3,3,2,2,5,0,5,1,1,1]

theorem envBound11454 : H12AffineFastState.Bounded env11454 := by
  intro p hp
  have h : env11454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11453_11454 : H12AffineEnvironment.transform 2 0 env11453 = env11454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env11453 == env11454) = true)

theorem identity11454 : scanCanonicalize (H12AffineFastState.compose env11454 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound11454 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11455 : List Nat := [1,4,0,1,0,0,0,4,1,5,1,1,0,0,1,0,0,0,5,1,1,0,0,1,0,1,0,0,1,1,5,0,5,1,1,1]

theorem envBound11455 : H12AffineFastState.Bounded env11455 := by
  intro p hp
  have h : env11455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11454_11455 : H12AffineEnvironment.transform 0 1 env11454 = env11455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env11454 == env11455) = true)

def leafEnv11455 : List Nat := [1,4,0,1,0,0,0,4,1,5,1,1,0,0,1,0,0,0,5,1,1,0,0,1,5,0,1,1,0,0,1,1,5,0,5,1,5,0,1,1,0,0,1]

def active11455 : List Nat := [1]

def tree11455 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11455 : H12WitnessSearch.Good tree11455 := H12GlobalWitnessIndex.good

theorem leafIdentity11455 : H12AffineFastState.composeSystem env11455 rootObs = leafEnv11455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11455 rootObs == leafEnv11455) = true)

theorem terminalChecked11455 : H12PackedTerminal.terminalCheckFast leafEnv11455 active11455 tree11455 = true := by decide +kernel

def env11456 : List Nat := [2,4,1,3,1,1,1,5,0,4,3,1,2,3,3,0,1,2,4,3,1,1,3,2,2,1,2,3,3,3,5,1,4,0,0,0]

theorem envBound11456 : H12AffineFastState.Bounded env11456 := by
  intro p hp
  have h : env11456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11453_11456 : H12AffineEnvironment.transform 2 1 env11453 = env11456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env11453 == env11456) = true)

def leafEnv11456 : List Nat := [2,4,1,3,1,1,1,5,0,4,3,1,2,3,3,0,1,2,4,3,1,1,3,2,5,2,1,1,2,3,3,3,5,1,4,0,5,0,0,0,0,2,1]

def active11456 : List Nat := [0,1]

def tree11456 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11456 : H12WitnessSearch.Good tree11456 := H12GlobalWitnessIndex.good

theorem leafIdentity11456 : H12AffineFastState.composeSystem env11456 rootObs = leafEnv11456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11456 rootObs == leafEnv11456) = true)

theorem terminalChecked11456 : H12PackedTerminal.terminalCheckFast leafEnv11456 active11456 tree11456 = true := by decide +kernel

def env11457 : List Nat := [2,4,8,16,32,32,58,36,512,1024,17,1567,11,1583,34,51,1028,16,1025,34,1567,19,522,48,57,570,34,1583,1076,35,1057,552,37,539,1029,512]

theorem envBound11457 : H12AffineFastState.Bounded env11457 := by
  intro p hp
  have h : env11457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11448_11457 : H12AffineEnvironment.transform 10 17 env11448 = env11457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env11448 == env11457) = true)

theorem identity11457 : scanCanonicalize (H12AffineFastState.compose env11457 (packedSelected [2,4] rootPS)) = affineNative (2^(8+1) ^^^ 24) := by decide +kernel

theorem selectedBound11457 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env11458 : List Nat := [2,4,8,16,32,32,58,36,24,1024,17,1031,11,1079,34,51,1028,16,1025,34,1031,19,18,48,57,34,34,1079,1076,35,1057,48,37,3,1029,24]

theorem envBound11458 : H12AffineFastState.Bounded env11458 := by
  intro p hp
  have h : env11458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11457_11458 : H12AffineEnvironment.transform 8 24 env11457 = env11458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 24 env11457 == env11458) = true)

def env11459 : List Nat := [2,4,8,16,32,33,128,36,512,1024,2048,1567,176,1582,153,2082,3093,2049,3089,153,1567,2233,523,138,56,570,2185,1582,3108,2184,3121,2691,37,2570,3092,512]

theorem envBound11459 : H12AffineFastState.Bounded env11459 := by
  intro p hp
  have h : env11459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11446_11459 : H12AffineEnvironment.transform 5 33 env11446 = env11459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env11446 == env11459) = true)

theorem identity11459 : scanCanonicalize (H12AffineFastState.compose env11459 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 170) := by decide +kernel

theorem selectedBound11459 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11460 : List Nat := [2,4,8,16,32,33,128,36,512,1024,170,1567,176,1582,153,136,1215,171,1211,153,1567,19,523,138,56,570,35,1582,1166,34,1179,553,37,672,1214,512]

theorem envBound11460 : H12AffineFastState.Bounded env11460 := by
  intro p hp
  have h : env11460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11459_11460 : H12AffineEnvironment.transform 10 170 env11459 = env11460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 170 env11459 == env11460) = true)

def env11461 : List Nat := [2,4,8,16,32,33,128,36,144,1024,170,1167,176,1214,153,136,1215,171,1211,153,1167,19,155,138,56,170,35,1214,1166,34,1179,185,37,48,1214,144]

theorem envBound11461 : H12AffineFastState.Bounded env11461 := by
  intro p hp
  have h : env11461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11460_11461 : H12AffineEnvironment.transform 8 144 env11460 = env11461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 144 env11460 == env11461) = true)

theorem identity11461 : scanCanonicalize (H12AffineFastState.compose env11461 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 19) := by decide +kernel

theorem selectedBound11461 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11462 : List Nat := [2,4,8,16,19,18,128,23,144,1024,153,1167,131,1165,153,136,1164,152,1160,153,1167,19,155,138,11,153,16,1165,1166,17,1179,138,22,3,1165,144]

theorem envBound11462 : H12AffineFastState.Bounded env11462 := by
  intro p hp
  have h : env11462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11461_11462 : H12AffineEnvironment.transform 4 19 env11461 = env11462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 19 env11461 == env11462) = true)

theorem identity11462 : scanCanonicalize (H12AffineFastState.compose env11462 (packedSelected [2,4] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound11462 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env11463 : List Nat := [2,4,8,16,19,18,8,23,24,1024,17,1031,11,1029,17,0,1028,16,1024,17,1031,19,19,2,11,17,16,1029,1030,17,1043,2,22,3,1029,24]

theorem envBound11463 : H12AffineFastState.Bounded env11463 := by
  intro p hp
  have h : env11463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11462_11463 : H12AffineEnvironment.transform 6 8 env11462 = env11463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env11462 == env11463) = true)

theorem identity11463 : scanCanonicalize (H12AffineFastState.compose env11463 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound11463 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11464 : List Nat := [2,4,8,8,11,10,8,15,0,1024,9,1031,11,1029,9,0,1028,8,1024,9,1031,11,11,2,11,9,8,1029,1030,9,1035,2,14,3,1029,0]

theorem envBound11464 : H12AffineFastState.Bounded env11464 := by
  intro p hp
  have h : env11464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11463_11464 : H12AffineEnvironment.transform 3 8 env11463 = env11464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env11463 == env11464) = true)

theorem identity11464 : scanCanonicalize (H12AffineFastState.compose env11464 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound11464 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11465 : List Nat := [2,4,8,8,11,10,8,15,0,14,9,9,11,11,9,0,10,8,14,9,9,11,11,2,11,9,8,11,8,9,5,2,14,3,11,0]

theorem envBound11465 : H12AffineFastState.Bounded env11465 := by
  intro p hp
  have h : env11465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11464_11465 : H12AffineEnvironment.transform 9 14 env11464 = env11465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env11464 == env11465) = true)

theorem identity11465 : scanCanonicalize (H12AffineFastState.compose env11465 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound11465 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env11466 : List Nat := [2,4,1,1,2,3,1,6,0,7,0,0,2,2,0,0,3,1,7,0,0,2,2,2,2,0,1,2,1,0,5,2,7,3,2,0]

theorem envBound11466 : H12AffineFastState.Bounded env11466 := by
  intro p hp
  have h : env11466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart2