import H12CloudChart2Data206

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound52114 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env52115 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,9293,9278,1345,262144,273,9292,1344,1228,16,263633,9625,1360,367,1296,1,3125,262563,17,256,263350,1345,1808]

theorem envBound52115 : H12AffineFastState.Bounded env52115 := by
  intro p hp
  have h : env52115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52114_52115 : H12AffineEnvironment.transform 14 9293 env52114 = env52115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9293 env52114 == env52115) = true)

theorem identity52115 : scanCanonicalize (H12AffineFastState.compose env52115 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound52115 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env52116 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,81,8192,0,8541,8494,81,262144,273,8540,80,476,16,262337,8329,64,367,0,1,2341,262563,17,256,262566,81,512]

theorem envBound52116 : H12AffineFastState.Bounded env52116 := by
  intro p hp
  have h : env52116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52115_52116 : H12AffineEnvironment.transform 9 272 env52115 = env52116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env52115 == env52116) = true)

theorem identity52116 : scanCanonicalize (H12AffineFastState.compose env52116 (packedSelected [4,9,16] rootPS)) = affineNative (2^(17+1) ^^^ 243) := by decide +kernel

theorem selectedBound52116 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env52117 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,81,8192,0,8541,8494,81,243,273,8540,80,476,16,50,8329,64,367,0,1,2341,336,17,256,341,81,512]

theorem envBound52117 : H12AffineFastState.Bounded env52117 := by
  intro p hp
  have h : env52117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52116_52117 : H12AffineEnvironment.transform 17 243 env52116 = env52117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 243 env52116 == env52117) = true)

theorem identity52117 : scanCanonicalize (H12AffineFastState.compose env52117 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 981) := by decide +kernel

theorem selectedBound52117 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52118 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,81,981,0,648,763,81,243,273,649,80,476,16,50,860,64,367,0,1,2341,336,17,256,341,81,512]

theorem envBound52118 : H12AffineFastState.Bounded env52118 := by
  intro p hp
  have h : env52118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52117_52118 : H12AffineEnvironment.transform 12 981 env52117 = env52118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 981 env52117 == env52118) = true)

theorem identity52118 : scanCanonicalize (H12AffineFastState.compose env52118 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound52118 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env52119 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,1,901,0,648,683,1,163,273,649,0,396,16,50,780,16,319,0,1,2341,256,17,256,261,1,512]

theorem envBound52119 : H12AffineFastState.Bounded env52119 := by
  intro p hp
  have h : env52119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52118_52119 : H12AffineEnvironment.transform 5 16 env52118 = env52119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52118 == env52119) = true)

theorem identity52119 : scanCanonicalize (H12AffineFastState.compose env52119 (packedSelected [1,3,13] rootPS)) = affineNative (2^(10+1) ^^^ 319) := by decide +kernel

theorem selectedBound52119 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env52120 : List Nat := [2,4,8,16,32,16,128,256,512,272,319,1,901,0,648,683,1,163,273,649,0,396,16,50,780,16,319,0,1,26,256,17,256,261,1,512]

theorem envBound52120 : H12AffineFastState.Bounded env52120 := by
  intro p hp
  have h : env52120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52119_52120 : H12AffineEnvironment.transform 10 319 env52119 = env52120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 319 env52119 == env52120) = true)

theorem identity52120 : scanCanonicalize (H12AffineFastState.compose env52120 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound52120 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env52121 : List Nat := [2,4,8,16,32,16,128,172,512,188,147,1,553,0,648,683,1,163,189,649,0,32,16,50,672,16,147,0,1,26,172,17,172,169,1,512]

theorem envBound52121 : H12AffineFastState.Bounded env52121 := by
  intro p hp
  have h : env52121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52120_52121 : H12AffineEnvironment.transform 7 172 env52120 = env52121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env52120 == env52121) = true)

theorem identity52121 : scanCanonicalize (H12AffineFastState.compose env52121 (packedSelected [1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound52121 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env52122 : List Nat := [2,4,8,16,32,16,128,172,137,188,147,1,160,0,1,34,1,163,189,0,0,32,16,50,41,16,147,0,1,26,172,17,172,169,1,137]

theorem envBound52122 : H12AffineFastState.Bounded env52122 := by
  intro p hp
  have h : env52122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52121_52122 : H12AffineEnvironment.transform 8 137 env52121 = env52122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env52121 == env52122) = true)

theorem identity52122 : scanCanonicalize (H12AffineFastState.compose env52122 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound52122 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52123 : List Nat := [2,4,8,16,32,16,18,62,27,46,1,1,50,0,1,34,1,49,47,0,0,32,16,50,41,16,1,0,1,26,62,17,62,59,1,27]

theorem envBound52123 : H12AffineFastState.Bounded env52123 := by
  intro p hp
  have h : env52123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52122_52123 : H12AffineEnvironment.transform 6 18 env52122 = env52123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env52122 == env52123) = true)

theorem identity52123 : scanCanonicalize (H12AffineFastState.compose env52123 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound52123 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env52124 : List Nat := [2,4,8,10,32,10,8,36,1,46,1,1,40,0,1,34,1,43,47,0,0,32,10,40,41,10,1,0,1,0,36,11,36,33,1,1]

theorem envBound52124 : H12AffineFastState.Bounded env52124 := by
  intro p hp
  have h : env52124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52123_52124 : H12AffineEnvironment.transform 3 10 env52123 = env52124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env52123 == env52124) = true)

theorem identity52124 : scanCanonicalize (H12AffineFastState.compose env52124 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound52124 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env52125 : List Nat := [2,4,8,10,11,10,8,15,1,5,1,1,3,0,1,9,1,0,4,0,0,11,10,3,2,10,1,0,1,0,15,11,15,10,1,1]

theorem envBound52125 : H12AffineFastState.Bounded env52125 := by
  intro p hp
  have h : env52125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52124_52125 : H12AffineEnvironment.transform 4 11 env52124 = env52125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env52124 == env52125) = true)

theorem identity52125 : scanCanonicalize (H12AffineFastState.compose env52125 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound52125 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52126 : List Nat := [2,4,4,6,7,6,4,3,1,5,1,1,3,0,1,5,1,0,4,0,0,7,6,3,2,6,1,0,1,0,3,7,3,6,1,1]

theorem envBound52126 : H12AffineFastState.Bounded env52126 := by
  intro p hp
  have h : env52126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52125_52126 : H12AffineEnvironment.transform 2 4 env52125 = env52126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env52125 == env52126) = true)

def env52127 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1344,262144,77935,32769,4097,46529,16,266385,70887,78894,77840,1296,74815,81227,365712,74798,256,308666,1345,79470]

theorem envBound52127 : H12AffineFastState.Bounded env52127 := by
  intro p hp
  have h : env52127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52108_52127 : H12AffineEnvironment.transform 13 1297 env52108 = env52127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env52108 == env52127) = true)

theorem identity52127 : scanCanonicalize (H12AffineFastState.compose env52127 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound52127 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env52128 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1344,262144,77935,13340,4097,476,16,266385,70887,78894,77840,1296,74815,81227,336013,74798,256,262567,1345,79470]

theorem envBound52128 : H12AffineFastState.Bounded env52128 := by
  intro p hp
  have h : env52128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52127_52128 : H12AffineEnvironment.transform 14 13341 env52127 = env52128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env52127 == env52128) = true)

def env52129 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1344,65664,77935,13340,4097,476,16,69649,70887,78894,77840,1296,74815,81227,8205,74798,256,65831,1345,79470]

theorem envBound52129 : H12AffineFastState.Bounded env52129 := by
  intro p hp
  have h : env52129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52128_52129 : H12AffineEnvironment.transform 17 65664 env52128 = env52129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env52128 == env52129) = true)

theorem identity52129 : scanCanonicalize (H12AffineFastState.compose env52129 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5239) := by decide +kernel

theorem selectedBound52129 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env52130 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,5239,1344,5367,9240,13340,4097,476,16,1126,144,8281,9319,1296,12360,10556,8205,12377,256,5456,1345,8729]

theorem envBound52130 : H12AffineFastState.Bounded env52130 := by
  intro p hp
  have h : env52130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52129_52130 : H12AffineEnvironment.transform 15 5239 env52129 = env52130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5239 env52129 == env52130) = true)

def env52131 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,1297,13341,5159,1296,5287,9240,13340,4097,396,16,1078,144,8201,9271,1296,12312,10556,8205,12297,256,5376,1297,8729]

theorem envBound52131 : H12AffineFastState.Bounded env52131 := by
  intro p hp
  have h : env52131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52130_52131 : H12AffineEnvironment.transform 5 16 env52130 = env52131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52130 == env52131) = true)

theorem identity52131 : scanCanonicalize (H12AffineFastState.compose env52131 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound52131 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env52132 : List Nat := [2,4,8,16,32,16,128,20,512,1024,2048,4096,8192,1029,13341,5159,1028,5287,9240,13340,4097,152,16,1078,144,8201,9271,1028,12312,10280,8205,12297,20,5140,1029,8729]

theorem envBound52132 : H12AffineFastState.Bounded env52132 := by
  intro p hp
  have h : env52132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52131_52132 : H12AffineEnvironment.transform 7 20 env52131 = env52132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env52131 == env52132) = true)

theorem identity52132 : scanCanonicalize (H12AffineFastState.compose env52132 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound52132 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env52133 : List Nat := [2,4,8,16,32,16,128,20,512,1024,2048,1029,8192,1029,8216,34,1028,162,9240,8217,1028,152,16,1078,144,8201,9271,1028,9245,10280,8205,9228,20,17,1029,8729]

theorem envBound52133 : H12AffineFastState.Bounded env52133 := by
  intro p hp
  have h : env52133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52132_52133 : H12AffineEnvironment.transform 11 1029 env52132 = env52133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env52132 == env52133) = true)

theorem identity52133 : scanCanonicalize (H12AffineFastState.compose env52133 (packedSelected [0,1,3,5,7,8,11,12,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 3078) := by decide +kernel

theorem selectedBound52133 : packedSelected [0,1,3,5,7,8,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env52134 : List Nat := [2,4,8,16,32,16,128,20,512,1024,2048,1029,3078,1029,3102,34,1028,162,2078,3103,1028,152,16,1078,144,3087,2097,1028,2075,1070,3083,2058,20,17,1029,3615]

theorem envBound52134 : H12AffineFastState.Bounded env52134 := by
  intro p hp
  have h : env52134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52133_52134 : H12AffineEnvironment.transform 12 3078 env52133 = env52134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3078 env52133 == env52134) = true)

theorem identity52134 : scanCanonicalize (H12AffineFastState.compose env52134 (packedSelected [0,1,3,7,18] rootPS)) = affineNative (2^(9+1) ^^^ 151) := by decide +kernel

theorem selectedBound52134 : packedSelected [0,1,3,7,18] rootPS < 2^1333 := by decide +kernel

def env52135 : List Nat := [2,4,8,16,32,16,128,20,512,151,2048,146,2193,146,2185,34,147,162,2078,2184,147,152,16,161,144,2200,2097,147,2075,185,2204,2058,20,17,146,2696]

theorem envBound52135 : H12AffineFastState.Bounded env52135 := by
  intro p hp
  have h : env52135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52134_52135 : H12AffineEnvironment.transform 9 151 env52134 = env52135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 151 env52134 == env52135) = true)

theorem identity52135 : scanCanonicalize (H12AffineFastState.compose env52135 (packedSelected [0,1,2,7,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 539) := by decide +kernel

theorem selectedBound52135 : packedSelected [0,1,2,7,8,10] rootPS < 2^1333 := by decide +kernel

def env52136 : List Nat := [2,4,8,16,32,16,128,20,512,151,539,146,650,146,658,34,147,162,517,659,147,152,16,161,144,643,554,147,512,185,647,529,20,17,146,147]

theorem envBound52136 : H12AffineFastState.Bounded env52136 := by
  intro p hp
  have h : env52136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52135_52136 : H12AffineEnvironment.transform 10 539 env52135 = env52136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 539 env52135 == env52136) = true)

theorem identity52136 : scanCanonicalize (H12AffineFastState.compose env52136 (packedSelected [0,2,3,7,8,11] rootPS)) = affineNative (2^(8+1) ^^^ 185) := by decide +kernel

theorem selectedBound52136 : packedSelected [0,2,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env52137 : List Nat := [2,4,8,16,32,16,128,20,185,151,162,146,51,146,43,34,147,162,188,42,147,152,16,161,144,58,147,147,185,185,62,168,20,17,146,147]

theorem envBound52137 : H12AffineFastState.Bounded env52137 := by
  intro p hp
  have h : env52137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52136_52137 : H12AffineEnvironment.transform 8 185 env52136 = env52137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 185 env52136 == env52137) = true)

theorem identity52137 : scanCanonicalize (H12AffineFastState.compose env52137 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound52137 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52138 : List Nat := [2,4,8,11,32,11,128,15,162,140,162,137,40,137,43,34,136,162,167,42,136,131,11,161,139,33,136,136,162,162,37,168,15,10,137,136]

theorem envBound52138 : H12AffineFastState.Bounded env52138 := by
  intro p hp
  have h : env52138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52137_52138 : H12AffineEnvironment.transform 3 11 env52137 = env52138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env52137 == env52138) = true)

theorem identity52138 : scanCanonicalize (H12AffineFastState.compose env52138 (packedSelected [3,5] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound52138 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env52139 : List Nat := [2,4,8,11,32,11,35,15,1,47,1,42,40,42,43,34,43,1,4,42,43,32,11,2,40,33,43,43,1,1,37,11,15,10,42,43]

theorem envBound52139 : H12AffineFastState.Bounded env52139 := by
  intro p hp
  have h : env52139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52138_52139 : H12AffineEnvironment.transform 6 35 env52138 = env52139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env52138 == env52139) = true)

theorem identity52139 : scanCanonicalize (H12AffineFastState.compose env52139 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound52139 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52140 : List Nat := [2,3,8,11,32,11,35,8,1,40,1,42,40,42,43,34,43,1,3,42,43,32,11,2,40,33,43,43,1,1,34,11,8,10,42,43]

theorem envBound52140 : H12AffineFastState.Bounded env52140 := by
  intro p hp
  have h : env52140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52139_52140 : H12AffineEnvironment.transform 1 3 env52139 = env52140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env52139 == env52140) = true)

theorem identity52140 : scanCanonicalize (H12AffineFastState.compose env52140 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound52140 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env52141 : List Nat := [2,3,8,11,11,11,8,8,1,3,1,1,3,1,0,9,0,1,3,1,0,11,11,2,3,10,0,0,1,1,9,11,8,10,1,0]

theorem envBound52141 : H12AffineFastState.Bounded env52141 := by
  intro p hp
  have h : env52141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52140_52141 : H12AffineEnvironment.transform 4 11 env52140 = env52141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env52140 == env52141) = true)

theorem identity52141 : scanCanonicalize (H12AffineFastState.compose env52141 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound52141 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52142 : List Nat := [2,3,1,2,2,2,1,1,1,3,1,1,3,1,0,0,0,1,3,1,0,2,2,2,3,3,0,0,1,1,0,2,1,3,1,0]

theorem envBound52142 : H12AffineFastState.Bounded env52142 := by
  intro p hp
  have h : env52142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52141_52142 : H12AffineEnvironment.transform 2 1 env52141 = env52142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env52141 == env52142) = true)

theorem identity52142 : scanCanonicalize (H12AffineFastState.compose env52142 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound52142 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env52143 : List Nat := [1,0,1,1,1,1,1,1,1,0,1,1,0,1,0,0,0,1,0,1,0,1,1,1,0,0,0,0,1,1,0,1,1,0,1,0]

theorem envBound52143 : H12AffineFastState.Bounded env52143 := by
  intro p hp
  have h : env52143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52142_52143 : H12AffineEnvironment.transform 0 1 env52142 = env52143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env52142 == env52143) = true)

def env52144 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1297,13341,5158,1297,5286,9240,13340,4097,397,16,1079,144,8200,9270,1296,12313,10556,8205,12296,256,5377,1296,8729]

theorem envBound52144 : H12AffineFastState.Bounded env52144 := by
  intro p hp
  have h : env52144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52130_52144 : H12AffineEnvironment.transform 5 17 env52130 = env52144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52130 == env52144) = true)

theorem identity52144 : scanCanonicalize (H12AffineFastState.compose env52144 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound52144 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env52145 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,1297,5393,5158,1297,5286,1300,5392,4097,397,16,1079,144,260,1338,1296,4373,2096,257,4356,256,5377,1296,789]

theorem envBound52145 : H12AffineFastState.Bounded env52145 := by
  intro p hp
  have h : env52145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52144_52145 : H12AffineEnvironment.transform 12 268 env52144 = env52145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env52144 == env52145) = true)

theorem identity52145 : scanCanonicalize (H12AffineFastState.compose env52145 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound52145 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env52146 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,268,1297,0,311,1297,439,1300,1,1296,397,16,1079,144,260,1338,1296,1028,2096,257,1045,256,16,1296,789]

theorem envBound52146 : H12AffineFastState.Bounded env52146 := by
  intro p hp
  have h : env52146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52145_52146 : H12AffineEnvironment.transform 11 1297 env52145 = env52146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env52145 == env52146) = true)

theorem identity52146 : scanCanonicalize (H12AffineFastState.compose env52146 (packedSelected [0,1,2,3,5,7,8,12,13,15,18] rootPS)) = affineNative (2^(10+1) ^^^ 675) := by decide +kernel

theorem selectedBound52146 : packedSelected [0,1,2,3,5,7,8,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env52147 : List Nat := [2,4,8,16,32,17,128,256,512,1024,675,1297,268,1297,0,311,1297,439,1300,1,1296,397,16,1079,144,260,1338,1296,1028,659,257,1045,256,16,1296,789]

theorem envBound52147 : H12AffineFastState.Bounded env52147 := by
  intro p hp
  have h : env52147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52146_52147 : H12AffineEnvironment.transform 10 675 env52146 = env52147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 675 env52146 == env52147) = true)

theorem identity52147 : scanCanonicalize (H12AffineFastState.compose env52147 (packedSelected [1,2,5,10,12,13,15,19] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound52147 : packedSelected [1,2,5,10,12,13,15,19] rootPS < 2^1333 := by decide +kernel

def env52148 : List Nat := [2,4,8,16,32,17,128,256,292,1024,391,1297,268,1297,0,311,1297,439,1300,1,1296,397,16,1079,144,260,1338,1296,1028,439,257,1045,256,16,1296,49]

theorem envBound52148 : H12AffineFastState.Bounded env52148 := by
  intro p hp
  have h : env52148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52147_52148 : H12AffineEnvironment.transform 8 292 env52147 = env52148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env52147 == env52148) = true)

theorem identity52148 : scanCanonicalize (H12AffineFastState.compose env52148 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound52148 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env52149 : List Nat := [2,4,8,16,32,17,128,172,136,1024,43,1213,160,1213,0,155,1213,27,1208,1,1212,33,16,1079,144,168,1174,1212,1028,27,173,1045,172,16,1212,49]

theorem envBound52149 : H12AffineFastState.Bounded env52149 := by
  intro p hp
  have h : env52149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52148_52149 : H12AffineEnvironment.transform 7 172 env52148 = env52149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env52148 == env52149) = true)

theorem identity52149 : scanCanonicalize (H12AffineFastState.compose env52149 (packedSelected [5,7,8,9] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound52149 : packedSelected [5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env52150 : List Nat := [2,4,8,16,16,17,128,156,136,1024,27,1165,144,1165,0,155,1165,27,1160,1,1164,17,16,1031,144,152,1174,1164,1028,27,157,1045,156,16,1164,1]

theorem envBound52150 : H12AffineFastState.Bounded env52150 := by
  intro p hp
  have h : env52150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52149_52150 : H12AffineEnvironment.transform 4 16 env52149 = env52150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env52149 == env52150) = true)

theorem identity52150 : scanCanonicalize (H12AffineFastState.compose env52150 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 151) := by decide +kernel

theorem selectedBound52150 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env52151 : List Nat := [2,4,8,16,16,17,128,156,136,151,27,26,144,26,0,155,26,27,31,1,27,17,16,144,144,152,1,27,147,27,157,130,156,16,27,1]

theorem envBound52151 : H12AffineFastState.Bounded env52151 := by
  intro p hp
  have h : env52151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52150_52151 : H12AffineEnvironment.transform 9 151 env52150 = env52151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 151 env52150 == env52151) = true)

def env52152 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1344,65665,77935,13340,4097,476,16,69648,70887,78894,77840,1296,74815,81227,8204,74798,256,65830,1345,79470]

theorem envBound52152 : H12AffineFastState.Bounded env52152 := by
  intro p hp
  have h : env52152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52128_52152 : H12AffineEnvironment.transform 17 65665 env52128 = env52152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env52128 == env52152) = true)

theorem identity52152 : scanCanonicalize (H12AffineFastState.compose env52152 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 311) := by decide +kernel

theorem selectedBound52152 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env52153 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,311,1344,438,12632,13340,4097,476,16,4391,5584,13593,12583,1296,9480,15484,8204,9497,256,17,1345,14169]

theorem envBound52153 : H12AffineFastState.Bounded env52153 := by
  intro p hp
  have h : env52153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52152_52153 : H12AffineEnvironment.transform 15 311 env52152 = env52153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 311 env52152 == env52153) = true)

def env52154 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,1297,13341,311,1296,438,12552,13340,4097,396,16,4391,5504,13593,12583,1296,9480,15404,8204,9497,256,17,1297,14089]

theorem envBound52154 : H12AffineFastState.Bounded env52154 := by
  intro p hp
  have h : env52154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52153_52154 : H12AffineEnvironment.transform 5 16 env52153 = env52154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52153 == env52154) = true)

theorem identity52154 : scanCanonicalize (H12AffineFastState.compose env52154 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound52154 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env52155 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1029,8192,1297,8216,311,1296,438,9485,8217,1028,396,16,1314,389,8476,9506,1296,9480,10281,8204,9497,256,17,1297,8972]

theorem envBound52155 : H12AffineFastState.Bounded env52155 := by
  intro p hp
  have h : env52155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52154_52155 : H12AffineEnvironment.transform 11 1029 env52154 = env52155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env52154 == env52155) = true)

theorem identity52155 : scanCanonicalize (H12AffineFastState.compose env52155 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound52155 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env52156 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1029,24,1297,0,311,1296,438,1301,1,1028,396,16,1314,389,260,1338,1296,1296,2097,20,1281,256,17,1297,788]

theorem envBound52156 : H12AffineFastState.Bounded env52156 := by
  intro p hp
  have h : env52156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52155_52156 : H12AffineEnvironment.transform 12 24 env52155 = env52156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env52155 == env52156) = true)

theorem identity52156 : scanCanonicalize (H12AffineFastState.compose env52156 (packedSelected [0,1,2,5,7,10,11,19] rootPS)) = affineNative (2^(10+1) ^^^ 1213) := by decide +kernel

theorem selectedBound52156 : packedSelected [0,1,2,5,7,10,11,19] rootPS < 2^1333 := by decide +kernel

def env52157 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1213,1029,24,1297,0,311,1296,438,1301,1,1028,396,16,1314,389,260,1338,1296,1296,1164,20,1281,256,17,1297,788]

theorem envBound52157 : H12AffineFastState.Bounded env52157 := by
  intro p hp
  have h : env52157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52156_52157 : H12AffineEnvironment.transform 10 1213 env52156 = env52157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1213 env52156 == env52157) = true)

theorem identity52157 : scanCanonicalize (H12AffineFastState.compose env52157 (packedSelected [0,1,3,7,10,11,13,15,17] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound52157 : packedSelected [0,1,3,7,10,11,13,15,17] rootPS < 2^1333 := by decide +kernel

def env52158 : List Nat := [2,4,8,16,32,16,128,256,43,1024,1213,1029,24,1297,0,311,1296,438,1301,1,1028,396,16,1314,389,260,1338,1296,1296,1164,20,1281,256,17,1297,319]

theorem envBound52158 : H12AffineFastState.Bounded env52158 := by
  intro p hp
  have h : env52158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52157_52158 : H12AffineEnvironment.transform 8 43 env52157 = env52158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env52157 == env52158) = true)

theorem identity52158 : scanCanonicalize (H12AffineFastState.compose env52158 (packedSelected [0,2,3,5,7,11,13] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound52158 : packedSelected [0,2,3,5,7,11,13] rootPS < 2^1333 := by decide +kernel

def env52159 : List Nat := [2,4,8,16,32,16,128,256,43,273,428,276,24,0,0,311,1,438,4,1,277,396,16,51,389,260,43,1,1,413,20,16,256,17,0,319]

theorem envBound52159 : H12AffineFastState.Bounded env52159 := by
  intro p hp
  have h : env52159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52158_52159 : H12AffineEnvironment.transform 9 273 env52158 = env52159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env52158 == env52159) = true)

theorem identity52159 : scanCanonicalize (H12AffineFastState.compose env52159 (packedSelected [1,2] rootPS)) = affineNative (2^(7+1) ^^^ 35) := by decide +kernel

theorem selectedBound52159 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env52160 : List Nat := [2,4,8,16,32,16,128,35,43,50,143,55,24,0,0,20,1,149,4,1,54,175,16,51,166,39,43,1,1,190,20,16,35,17,0,28]

theorem envBound52160 : H12AffineFastState.Bounded env52160 := by
  intro p hp
  have h : env52160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52159_52160 : H12AffineEnvironment.transform 7 35 env52159 = env52160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 35 env52159 == env52160) = true)

theorem identity52160 : scanCanonicalize (H12AffineFastState.compose env52160 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound52160 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env52161 : List Nat := [2,4,8,11,32,11,128,35,43,41,143,44,3,0,0,15,1,142,4,1,45,175,11,40,166,39,43,1,1,165,15,11,35,10,0,7]

theorem envBound52161 : H12AffineFastState.Bounded env52161 := by
  intro p hp
  have h : env52161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52160_52161 : H12AffineEnvironment.transform 3 11 env52160 = env52161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env52160 == env52161) = true)

theorem identity52161 : scanCanonicalize (H12AffineFastState.compose env52161 (packedSelected [1,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound52161 : packedSelected [1,4,7] rootPS < 2^1333 := by decide +kernel

def env52162 : List Nat := [2,4,8,11,13,11,128,14,6,4,143,1,3,0,0,15,1,142,4,1,0,130,11,5,139,10,6,1,1,136,15,11,14,10,0,7]

theorem envBound52162 : H12AffineFastState.Bounded env52162 := by
  intro p hp
  have h : env52162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52161_52162 : H12AffineEnvironment.transform 4 13 env52161 = env52162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env52161 == env52162) = true)

def env52163 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1297,13341,311,1297,438,12553,13340,4097,397,16,4391,5505,13593,12583,1296,9480,15405,8204,9497,256,17,1296,14088]

theorem envBound52163 : H12AffineFastState.Bounded env52163 := by
  intro p hp
  have h : env52163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52153_52163 : H12AffineEnvironment.transform 5 17 env52153 = env52163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52153 == env52163) = true)

theorem identity52163 : scanCanonicalize (H12AffineFastState.compose env52163 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound52163 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env52164 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,269,1297,5392,311,1297,438,4100,5393,4097,397,16,4391,5505,5140,4138,1296,1029,7456,257,1044,256,17,1296,5637]

theorem envBound52164 : H12AffineFastState.Bounded env52164 := by
  intro p hp
  have h : env52164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52163_52164 : H12AffineEnvironment.transform 12 269 env52163 = env52164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env52163 == env52164) = true)

theorem identity52164 : scanCanonicalize (H12AffineFastState.compose env52164 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound52164 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env52165 : List Nat := [2,4,8,16,32,17,128,20,512,1024,2048,4096,25,1029,5124,35,1029,162,4100,5125,4097,153,16,4147,5269,5140,4138,1028,1029,7220,21,1044,20,17,1028,5637]

theorem envBound52165 : H12AffineFastState.Bounded env52165 := by
  intro p hp
  have h : env52165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52164_52165 : H12AffineEnvironment.transform 7 20 env52164 = env52165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env52164 == env52165) = true)

theorem identity52165 : scanCanonicalize (H12AffineFastState.compose env52165 (packedSelected [10,11,13,17,18,19] rootPS)) = affineNative (2^(11+1) ^^^ 2074) := by decide +kernel

theorem selectedBound52165 : packedSelected [10,11,13,17,18,19] rootPS < 2^1333 := by decide +kernel

def env52166 : List Nat := [2,4,8,16,32,17,128,20,512,1024,2048,2074,25,1029,3102,35,1029,162,2078,3103,2075,153,16,2089,3215,3086,2096,1028,1029,1070,21,1044,20,17,1028,3615]

theorem envBound52166 : H12AffineFastState.Bounded env52166 := by
  intro p hp
  have h : env52166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52165_52166 : H12AffineEnvironment.transform 11 2074 env52165 = env52166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2074 env52165 == env52166) = true)

theorem identity52166 : scanCanonicalize (H12AffineFastState.compose env52166 (packedSelected [0,7,11,12,13,15] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound52166 : packedSelected [0,7,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env52167 : List Nat := [2,4,8,16,32,17,35,20,512,1024,2048,2074,25,1029,3102,35,1029,1,2078,3103,2075,58,16,2089,3116,3086,2096,1028,1029,1070,21,1044,20,17,1028,3615]

theorem envBound52167 : H12AffineFastState.Bounded env52167 := by
  intro p hp
  have h : env52167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52166_52167 : H12AffineEnvironment.transform 6 35 env52166 = env52167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env52166 == env52167) = true)

theorem identity52167 : scanCanonicalize (H12AffineFastState.compose env52167 (packedSelected [4,9] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound52167 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env52168 : List Nat := [2,4,8,16,11,17,8,20,512,1024,2048,2074,25,1029,3102,8,1029,1,2078,3103,2075,17,16,2050,3079,3086,2075,1028,1029,1029,21,1044,20,17,1028,3615]

theorem envBound52168 : H12AffineFastState.Bounded env52168 := by
  intro p hp
  have h : env52168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52167_52168 : H12AffineEnvironment.transform 4 11 env52167 = env52168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env52167 == env52168) = true)

theorem identity52168 : scanCanonicalize (H12AffineFastState.compose env52168 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound52168 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env52169 : List Nat := [2,4,8,16,11,17,8,20,1,1024,2048,2074,25,1029,3102,8,1029,1,2078,3103,2075,17,16,2050,3079,3086,2075,1028,1029,1029,21,1044,20,17,1028,3102]

theorem envBound52169 : H12AffineFastState.Bounded env52169 := by
  intro p hp
  have h : env52169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52168_52169 : H12AffineEnvironment.transform 8 1 env52168 = env52169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env52168 == env52169) = true)

theorem identity52169 : scanCanonicalize (H12AffineFastState.compose env52169 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound52169 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env52170 : List Nat := [2,4,8,10,11,11,8,14,1,1024,2048,2048,3,1029,3076,8,1029,1,2052,3077,2049,11,10,2050,3079,3086,2049,1028,1029,1029,15,1038,14,11,1028,3076]

theorem envBound52170 : H12AffineFastState.Bounded env52170 := by
  intro p hp
  have h : env52170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52169_52170 : H12AffineEnvironment.transform 3 10 env52169 = env52170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env52169 == env52170) = true)

theorem identity52170 : scanCanonicalize (H12AffineFastState.compose env52170 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1029) := by decide +kernel

theorem selectedBound52170 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52171 : List Nat := [2,4,8,10,11,11,8,14,1,1024,1029,1029,3,1029,1,8,1029,1,1025,0,1028,11,10,1031,2,11,1028,1028,1029,1029,15,1038,14,11,1028,1]

theorem envBound52171 : H12AffineFastState.Bounded env52171 := by
  intro p hp
  have h : env52171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52170_52171 : H12AffineEnvironment.transform 10 1029 env52170 = env52171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1029 env52170 == env52171) = true)

theorem identity52171 : scanCanonicalize (H12AffineFastState.compose env52171 (packedSelected [0,1] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound52171 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env52172 : List Nat := [2,4,8,10,11,11,8,14,1,5,0,0,3,0,1,8,0,1,4,0,1,11,10,2,2,11,1,1,0,0,15,11,14,11,1,1]

theorem envBound52172 : H12AffineFastState.Bounded env52172 := by
  intro p hp
  have h : env52172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52171_52172 : H12AffineEnvironment.transform 9 5 env52171 = env52172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env52171 == env52172) = true)

theorem identity52172 : scanCanonicalize (H12AffineFastState.compose env52172 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound52172 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52173 : List Nat := [2,4,5,7,6,6,5,3,1,5,0,0,3,0,1,5,0,1,4,0,1,6,7,2,2,6,1,1,0,0,2,6,3,6,1,1]

theorem envBound52173 : H12AffineFastState.Bounded env52173 := by
  intro p hp
  have h : env52173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52172_52173 : H12AffineEnvironment.transform 2 5 env52172 = env52173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env52172 == env52173) = true)

def env52174 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95614,32769,4097,61648,147521,284033,86518,209262,225344,148801,74815,96346,381312,205166,256,456170,1345,95103]

theorem envBound52174 : H12AffineFastState.Bounded env52174 := by
  intro p hp
  have h : env52174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52038_52174 : H12AffineEnvironment.transform 23 284033 env52038 = env52174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284033 env52038 == env52174) = true)

def env52175 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16464,262144,95614,32769,4097,61648,17,284033,86518,94526,77840,1297,74815,96346,381312,90430,256,308666,1345,95103]

theorem envBound52175 : H12AffineFastState.Bounded env52175 := by
  intro p hp
  have h : env52175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52174_52175 : H12AffineEnvironment.transform 16 16464 env52174 = env52175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16464 env52174 == env52175) = true)

def env52176 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1344,262144,77934,32769,4097,46528,17,266385,70886,78894,77840,1297,74815,81226,365712,74798,256,308666,1345,79471]

theorem envBound52176 : H12AffineFastState.Bounded env52176 := by
  intro p hp
  have h : env52176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52175_52176 : H12AffineEnvironment.transform 13 1296 env52175 = env52176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env52175 == env52176) = true)

theorem identity52176 : scanCanonicalize (H12AffineFastState.compose env52176 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound52176 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env52177 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1344,262144,77934,13340,4097,477,17,266385,70886,78894,77840,1297,74815,81226,336013,74798,256,262567,1345,79471]

theorem envBound52177 : H12AffineFastState.Bounded env52177 := by
  intro p hp
  have h : env52177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52176_52177 : H12AffineEnvironment.transform 14 13341 env52176 = env52177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env52176 == env52177) = true)

def env52178 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1344,65664,77934,13340,4097,477,17,69649,70886,78894,77840,1297,74815,81226,8205,74798,256,65831,1345,79471]

theorem envBound52178 : H12AffineFastState.Bounded env52178 := by
  intro p hp
  have h : env52178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52177_52178 : H12AffineEnvironment.transform 17 65664 env52177 = env52178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env52177 == env52178) = true)

theorem identity52178 : scanCanonicalize (H12AffineFastState.compose env52178 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound52178 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env52179 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,0,12557,65536,80,65664,77934,12556,4097,477,17,69649,70134,78142,77840,1,74031,79962,8205,74046,256,65831,81,78719]

theorem envBound52179 : H12AffineFastState.Bounded env52179 := by
  intro p hp
  have h : env52179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52178_52179 : H12AffineEnvironment.transform 9 272 env52178 = env52179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env52178 == env52179) = true)

def env52180 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,4096,8192,0,12557,65536,0,65664,77886,12556,4097,397,17,69649,70054,78142,77840,1,74031,79882,8205,74046,256,65831,1,78639]

theorem envBound52180 : H12AffineFastState.Bounded env52180 := by
  intro p hp
  have h : env52180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52179_52180 : H12AffineEnvironment.transform 5 16 env52179 = env52180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52179 == env52180) = true)

theorem identity52180 : scanCanonicalize (H12AffineFastState.compose env52180 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound52180 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env52181 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,4096,269,0,4096,65536,0,65664,69939,4097,4097,397,17,69649,70054,69683,69917,1,65570,71943,256,65587,256,65831,1,70178]

theorem envBound52181 : H12AffineFastState.Bounded env52181 := by
  intro p hp
  have h : env52181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52180_52181 : H12AffineEnvironment.transform 12 269 env52180 = env52181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env52180 == env52181) = true)

theorem identity52181 : scanCanonicalize (H12AffineFastState.compose env52181 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound52181 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env52182 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,269,0,0,65536,0,65664,65843,1,1,397,17,65553,65958,65587,65821,1,65570,67847,256,65587,256,65831,1,66082]

theorem envBound52182 : H12AffineFastState.Bounded env52182 := by
  intro p hp
  have h : env52182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52181_52182 : H12AffineEnvironment.transform 11 0 env52181 = env52182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env52181 == env52182) = true)

theorem identity52182 : scanCanonicalize (H12AffineFastState.compose env52182 (packedSelected [0,1,3,5,7,8,11,12,15,17] rootPS)) = affineNative (2^(15+1) ^^^ 2082) := by decide +kernel

theorem selectedBound52182 : packedSelected [0,1,3,5,7,8,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env52183 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,269,0,0,2082,0,2210,2321,1,1,397,17,2099,2436,2065,2367,1,2048,293,256,2065,256,2309,1,2560]

theorem envBound52183 : H12AffineFastState.Bounded env52183 := by
  intro p hp
  have h : env52183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52182_52183 : H12AffineEnvironment.transform 15 2082 env52182 = env52183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2082 env52182 == env52183) = true)

theorem identity52183 : scanCanonicalize (H12AffineFastState.compose env52183 (packedSelected [1,3,5,8,11,18] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound52183 : packedSelected [1,3,5,8,11,18] rootPS < 2^1333 := by decide +kernel

def env52184 : List Nat := [2,4,8,16,32,16,128,15,512,31,2048,0,2,0,0,2082,0,2210,2078,1,1,130,17,2099,2187,2065,2096,1,2048,42,15,2065,15,2058,1,2560]

theorem envBound52184 : H12AffineFastState.Bounded env52184 := by
  intro p hp
  have h : env52184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52183_52184 : H12AffineEnvironment.transform 7 15 env52183 = env52184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env52183 == env52184) = true)

theorem identity52184 : scanCanonicalize (H12AffineFastState.compose env52184 (packedSelected [1,3,4,9] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound52184 : packedSelected [1,3,4,9] rootPS < 2^1333 := by decide +kernel

def env52185 : List Nat := [2,4,8,16,32,16,18,15,512,31,2048,0,2,0,0,2082,0,2096,2078,1,1,16,17,2099,2073,2065,2096,1,2048,42,15,2065,15,2058,1,2560]

theorem envBound52185 : H12AffineFastState.Bounded env52185 := by
  intro p hp
  have h : env52185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52184_52185 : H12AffineEnvironment.transform 6 18 env52184 = env52185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env52184 == env52185) = true)

theorem identity52185 : scanCanonicalize (H12AffineFastState.compose env52185 (packedSelected [1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound52185 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env52186 : List Nat := [2,4,8,16,32,16,18,15,27,31,2048,0,2,0,0,2082,0,2096,2078,1,1,16,17,2099,2073,2065,2096,1,2048,42,15,2065,15,2058,1,2075]

theorem envBound52186 : H12AffineFastState.Bounded env52186 := by
  intro p hp
  have h : env52186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52185_52186 : H12AffineEnvironment.transform 8 27 env52185 = env52186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env52185 == env52186) = true)

theorem identity52186 : scanCanonicalize (H12AffineFastState.compose env52186 (packedSelected [2,4,5,7,8] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound52186 : packedSelected [2,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env52187 : List Nat := [2,4,8,11,32,11,9,15,0,4,2048,0,2,0,0,2082,0,2091,2053,1,1,11,10,2088,2050,2058,2091,1,2048,42,15,2058,15,2058,1,2048]

theorem envBound52187 : H12AffineFastState.Bounded env52187 := by
  intro p hp
  have h : env52187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52186_52187 : H12AffineEnvironment.transform 3 11 env52186 = env52187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env52186 == env52187) = true)

theorem identity52187 : scanCanonicalize (H12AffineFastState.compose env52187 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound52187 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52188 : List Nat := [2,4,8,11,10,11,9,15,0,4,2048,0,2,0,0,2056,0,2049,2053,1,1,11,10,2050,2050,2058,2049,1,2048,0,15,2058,15,2058,1,2048]

theorem envBound52188 : H12AffineFastState.Bounded env52188 := by
  intro p hp
  have h : env52188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52187_52188 : H12AffineEnvironment.transform 4 10 env52187 = env52188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env52187 == env52188) = true)

theorem identity52188 : scanCanonicalize (H12AffineFastState.compose env52188 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound52188 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52189 : List Nat := [2,4,4,7,6,7,5,3,0,4,2048,0,2,0,0,2052,0,2049,2053,1,1,7,6,2050,2050,2054,2049,1,2048,0,3,2054,3,2054,1,2048]

theorem envBound52189 : H12AffineFastState.Bounded env52189 := by
  intro p hp
  have h : env52189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52188_52189 : H12AffineEnvironment.transform 2 4 env52188 = env52189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env52188 == env52189) = true)

theorem identity52189 : scanCanonicalize (H12AffineFastState.compose env52189 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound52189 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env52190 : List Nat := [2,4,4,7,6,7,5,3,0,4,1,0,2,0,0,5,0,0,4,1,1,7,6,3,3,7,0,1,1,0,3,7,3,7,1,1]

theorem envBound52190 : H12AffineFastState.Bounded env52190 := by
  intro p hp
  have h : env52190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52189_52190 : H12AffineEnvironment.transform 10 1 env52189 = env52190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env52189 == env52190) = true)

theorem identity52190 : scanCanonicalize (H12AffineFastState.compose env52190 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound52190 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52191 : List Nat := [2,1,1,2,3,2,0,3,0,1,1,0,2,0,0,0,0,0,1,1,1,2,3,3,3,2,0,1,1,0,3,2,3,2,1,1]

theorem envBound52191 : H12AffineFastState.Bounded env52191 := by
  intro p hp
  have h : env52191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52190_52191 : H12AffineEnvironment.transform 1 1 env52190 = env52191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env52190 == env52191) = true)

theorem identity52191 : scanCanonicalize (H12AffineFastState.compose env52191 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound52191 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env52192 : List Nat := [1,1,1,1,0,1,0,0,0,1,1,0,1,0,0,0,0,0,1,1,1,1,0,0,0,1,0,1,1,0,0,1,0,1,1,1]

theorem envBound52192 : H12AffineFastState.Bounded env52192 := by
  intro p hp
  have h : env52192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52191_52192 : H12AffineEnvironment.transform 0 1 env52191 = env52192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env52191 == env52192) = true)

def env52193 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,4096,8192,0,12557,65536,1,65664,77887,12556,4097,396,17,69649,70055,78142,77840,1,74031,79883,8205,74046,256,65831,0,78638]

theorem envBound52193 : H12AffineFastState.Bounded env52193 := by
  intro p hp
  have h : env52193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52179_52193 : H12AffineEnvironment.transform 5 17 env52179 = env52193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52179 == env52193) = true)

theorem identity52193 : scanCanonicalize (H12AffineFastState.compose env52193 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 4130) := by decide +kernel

theorem selectedBound52193 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env52194 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,4096,8192,0,12557,4130,1,4258,8221,12556,4097,396,17,51,389,8476,8242,1,12557,10281,8205,12572,256,4357,0,8972]

theorem envBound52194 : H12AffineFastState.Bounded env52194 := by
  intro p hp
  have h : env52194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52193_52194 : H12AffineEnvironment.transform 15 4130 env52193 = env52194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4130 env52193 == env52194) = true)

theorem identity52194 : scanCanonicalize (H12AffineFastState.compose env52194 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound52194 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env52195 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,8192,0,8461,34,1,162,8221,8460,1,396,17,51,389,8476,8242,1,8461,10281,8205,8476,256,261,0,8972]

theorem envBound52195 : H12AffineFastState.Bounded env52195 := by
  intro p hp
  have h : env52195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52194_52195 : H12AffineEnvironment.transform 11 0 env52194 = env52195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env52194 == env52195) = true)

theorem identity52195 : scanCanonicalize (H12AffineFastState.compose env52195 (packedSelected [0,2,7,10,12,15,17,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 2828) := by decide +kernel

theorem selectedBound52195 : packedSelected [0,2,7,10,12,15,17,18,19] rootPS < 2^1333 := by decide +kernel

def env52196 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,2828,0,2561,34,1,162,2833,2560,1,396,17,51,389,2576,2878,1,2561,805,2817,2576,256,261,0,2048]

theorem envBound52196 : H12AffineFastState.Bounded env52196 := by
  intro p hp
  have h : env52196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52195_52196 : H12AffineEnvironment.transform 12 2828 env52195 = env52196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2828 env52195 == env52196) = true)

theorem identity52196 : scanCanonicalize (H12AffineFastState.compose env52196 (packedSelected [3,8] rootPS)) = affineNative (2^(8+1) ^^^ 271) := by decide +kernel

theorem selectedBound52196 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env52197 : List Nat := [2,4,8,16,32,17,128,256,271,272,2048,0,2051,0,2318,34,1,162,2078,2319,1,396,17,51,389,2335,2097,1,2318,42,2062,2335,256,261,0,2048]

theorem envBound52197 : H12AffineFastState.Bounded env52197 := by
  intro p hp
  have h : env52197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52196_52197 : H12AffineEnvironment.transform 8 271 env52196 = env52197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 271 env52196 == env52197) = true)

theorem identity52197 : scanCanonicalize (H12AffineFastState.compose env52197 (packedSelected [0,1,2,3,7,11,13,17] rootPS)) = affineNative (2^(10+1) ^^^ 412) := by decide +kernel

theorem selectedBound52197 : packedSelected [0,1,2,3,7,11,13,17] rootPS < 2^1333 := by decide +kernel

def env52198 : List Nat := [2,4,8,16,32,17,128,256,271,272,412,0,415,0,146,34,1,162,386,147,1,396,17,51,389,131,429,1,146,42,402,131,256,261,0,412]

theorem envBound52198 : H12AffineFastState.Bounded env52198 := by
  intro p hp
  have h : env52198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52197_52198 : H12AffineEnvironment.transform 10 412 env52197 = env52198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 412 env52197 == env52198) = true)

theorem identity52198 : scanCanonicalize (H12AffineFastState.compose env52198 (packedSelected [1,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound52198 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env52199 : List Nat := [2,4,8,16,17,17,128,256,271,272,412,0,415,0,146,19,1,147,386,147,1,396,17,2,389,131,412,1,146,27,402,131,256,261,0,412]

theorem envBound52199 : H12AffineFastState.Bounded env52199 := by
  intro p hp
  have h : env52199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52198_52199 : H12AffineEnvironment.transform 4 17 env52198 = env52199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env52198 == env52199) = true)

theorem identity52199 : scanCanonicalize (H12AffineFastState.compose env52199 (packedSelected [2,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 135) := by decide +kernel

theorem selectedBound52199 : packedSelected [2,7,9] rootPS < 2^1333 := by decide +kernel

def env52200 : List Nat := [2,4,8,16,17,17,128,135,136,151,27,0,24,0,146,19,1,147,5,147,1,11,17,2,2,131,27,1,146,27,21,131,135,130,0,27]

theorem envBound52200 : H12AffineFastState.Bounded env52200 := by
  intro p hp
  have h : env52200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52199_52200 : H12AffineEnvironment.transform 7 135 env52199 = env52200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 135 env52199 == env52200) = true)

theorem identity52200 : scanCanonicalize (H12AffineFastState.compose env52200 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound52200 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52201 : List Nat := [2,2,8,16,17,17,128,129,136,145,27,0,24,0,146,19,1,147,3,147,1,11,17,2,2,131,27,1,146,27,19,131,129,130,0,27]

theorem envBound52201 : H12AffineFastState.Bounded env52201 := by
  intro p hp
  have h : env52201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52200_52201 : H12AffineEnvironment.transform 1 2 env52200 = env52201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env52200 == env52201) = true)

theorem identity52201 : scanCanonicalize (H12AffineFastState.compose env52201 (packedSelected [2,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound52201 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env52202 : List Nat := [2,2,8,10,11,11,128,129,136,139,1,0,2,0,136,9,1,137,3,137,1,11,11,2,2,131,1,1,136,1,9,131,129,130,0,1]

theorem envBound52202 : H12AffineFastState.Bounded env52202 := by
  intro p hp
  have h : env52202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52201_52202 : H12AffineEnvironment.transform 3 10 env52201 = env52202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env52201 == env52202) = true)

theorem identity52202 : scanCanonicalize (H12AffineFastState.compose env52202 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound52202 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52203 : List Nat := [2,2,8,10,11,11,9,8,1,2,1,0,2,0,1,9,1,0,3,0,1,11,11,2,2,10,1,1,1,1,9,10,8,11,0,1]

theorem envBound52203 : H12AffineFastState.Bounded env52203 := by
  intro p hp
  have h : env52203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52202_52203 : H12AffineEnvironment.transform 6 9 env52202 = env52203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env52202 == env52203) = true)

def env52204 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1344,65665,77934,13340,4097,477,17,69648,70886,78894,77840,1297,74815,81226,8204,74798,256,65830,1345,79471]

theorem envBound52204 : H12AffineFastState.Bounded env52204 := by
  intro p hp
  have h : env52204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52177_52204 : H12AffineEnvironment.transform 17 65665 env52177 = env52204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env52177 == env52204) = true)

theorem identity52204 : scanCanonicalize (H12AffineFastState.compose env52204 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound52204 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env52205 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1296,9293,65536,1344,65665,73790,9292,81,477,17,65600,66742,74878,73792,1297,74815,77082,8204,74798,256,65830,1345,75327]

theorem envBound52205 : H12AffineFastState.Bounded env52205 := by
  intro p hp
  have h : env52205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52204_52205 : H12AffineEnvironment.transform 11 80 env52204 = env52205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env52204 == env52205) = true)

def env52206 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,0,8192,1296,9245,65536,1296,65665,73790,9244,1,397,17,65552,66742,74798,73744,1297,74815,77082,8204,74798,256,65830,1297,75327]

theorem envBound52206 : H12AffineFastState.Bounded env52206 := by
  intro p hp
  have h : env52206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52205_52206 : H12AffineEnvironment.transform 5 16 env52205 = env52206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52205 == env52206) = true)

theorem identity52206 : scanCanonicalize (H12AffineFastState.compose env52206 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound52206 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env52207 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,0,268,1296,1297,65536,1296,65665,65842,1296,1,397,17,65552,66742,66850,65820,1297,66867,68630,256,66850,256,65830,1297,67379]

theorem envBound52207 : H12AffineFastState.Bounded env52207 := by
  intro p hp
  have h : env52207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52206_52207 : H12AffineEnvironment.transform 12 268 env52206 = env52207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env52206 == env52207) = true)

theorem identity52207 : scanCanonicalize (H12AffineFastState.compose env52207 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound52207 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env52208 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,0,268,1296,1297,35,1296,162,273,1296,1,397,17,51,1173,1281,319,1297,1296,3125,256,1281,256,261,1297,1808]

theorem envBound52208 : H12AffineFastState.Bounded env52208 := by
  intro p hp
  have h : env52208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52207_52208 : H12AffineEnvironment.transform 15 35 env52207 = env52208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env52207 == env52208) = true)

theorem identity52208 : scanCanonicalize (H12AffineFastState.compose env52208 (packedSelected [0,2,3,7,8,10,12,15,17,18,19] rootPS)) = affineNative (2^(9+1) ^^^ 288) := by decide +kernel

theorem selectedBound52208 : packedSelected [0,2,3,7,8,10,12,15,17,18,19] rootPS < 2^1333 := by decide +kernel

def env52209 : List Nat := [2,4,8,16,32,16,128,256,512,288,2048,0,268,48,49,35,48,162,273,48,1,397,17,51,437,33,319,49,48,2325,256,33,256,261,49,560]

theorem envBound52209 : H12AffineFastState.Bounded env52209 := by
  intro p hp
  have h : env52209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52208_52209 : H12AffineEnvironment.transform 9 288 env52208 = env52209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 288 env52208 == env52209) = true)

theorem identity52209 : scanCanonicalize (H12AffineFastState.compose env52209 (packedSelected [0,1,2,5,7,11,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 413) := by decide +kernel

theorem selectedBound52209 : packedSelected [0,1,2,5,7,11,12,15] rootPS < 2^1333 := by decide +kernel

def env52210 : List Nat := [2,4,8,16,32,16,128,256,512,288,413,0,268,48,49,35,48,162,273,48,1,397,17,51,437,33,319,49,48,136,256,33,256,261,49,560]

theorem envBound52210 : H12AffineFastState.Bounded env52210 := by
  intro p hp
  have h : env52210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52209_52210 : H12AffineEnvironment.transform 10 413 env52209 = env52210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 413 env52209 == env52210) = true)

theorem identity52210 : scanCanonicalize (H12AffineFastState.compose env52210 (packedSelected [4,7] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound52210 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env52211 : List Nat := [2,4,8,16,17,16,128,256,512,273,413,0,268,1,0,18,1,147,273,1,1,397,17,2,388,16,270,0,1,136,256,16,256,261,0,513]

theorem envBound52211 : H12AffineFastState.Bounded env52211 := by
  intro p hp
  have h : env52211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52210_52211 : H12AffineEnvironment.transform 4 17 env52210 = env52211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env52210 == env52211) = true)

theorem identity52211 : scanCanonicalize (H12AffineFastState.compose env52211 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 147) := by decide +kernel

theorem selectedBound52211 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52212 : List Nat := [2,4,8,16,17,16,128,256,147,273,413,0,268,1,0,18,1,147,273,1,1,397,17,2,388,16,270,0,1,136,256,16,256,261,0,146]

theorem envBound52212 : H12AffineFastState.Bounded env52212 := by
  intro p hp
  have h : env52212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52211_52212 : H12AffineEnvironment.transform 8 147 env52211 = env52212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 147 env52211 == env52212) = true)

theorem identity52212 : scanCanonicalize (H12AffineFastState.compose env52212 (packedSelected [1,2,5] rootPS)) = affineNative (2^(7+1) ^^^ 135) := by decide +kernel

theorem selectedBound52212 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env52213 : List Nat := [2,4,8,16,17,16,128,135,147,150,26,0,139,1,0,18,1,147,150,1,1,10,17,2,3,16,137,0,1,136,135,16,135,130,0,146]

theorem envBound52213 : H12AffineFastState.Bounded env52213 := by
  intro p hp
  have h : env52213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52212_52213 : H12AffineEnvironment.transform 7 135 env52212 = env52213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 135 env52212 == env52213) = true)

theorem identity52213 : scanCanonicalize (H12AffineFastState.compose env52213 (packedSelected [0,1,2] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound52213 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env52214 : List Nat := [2,4,0,16,17,16,128,135,147,150,18,0,131,1,0,18,1,147,150,1,1,2,17,2,3,16,129,0,1,128,135,16,135,130,0,146]

theorem envBound52214 : H12AffineFastState.Bounded env52214 := by
  intro p hp
  have h : env52214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52213_52214 : H12AffineEnvironment.transform 2 0 env52213 = env52214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env52213 == env52214) = true)

theorem identity52214 : scanCanonicalize (H12AffineFastState.compose env52214 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound52214 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env52215 : List Nat := [2,4,0,1,0,1,128,135,130,135,3,0,131,1,0,3,1,130,135,1,1,2,0,2,3,1,129,0,1,128,135,1,135,130,0,131]

theorem envBound52215 : H12AffineFastState.Bounded env52215 := by
  intro p hp
  have h : env52215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52214_52215 : H12AffineEnvironment.transform 3 1 env52214 = env52215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env52214 == env52215) = true)

theorem identity52215 : scanCanonicalize (H12AffineFastState.compose env52215 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound52215 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52216 : List Nat := [2,2,0,1,0,1,128,129,130,129,3,0,131,1,0,3,1,130,129,1,1,2,0,2,3,1,129,0,1,128,129,1,129,130,0,131]

theorem envBound52216 : H12AffineFastState.Bounded env52216 := by
  intro p hp
  have h : env52216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52215_52216 : H12AffineEnvironment.transform 1 2 env52215 = env52216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env52215 == env52216) = true)

theorem identity52216 : scanCanonicalize (H12AffineFastState.compose env52216 (packedSelected [8] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound52216 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env52217 : List Nat := [0,0,0,1,0,1,128,129,128,129,1,0,129,1,0,1,1,128,129,1,1,0,0,0,1,1,129,0,1,128,129,1,129,128,0,129]

theorem envBound52217 : H12AffineFastState.Bounded env52217 := by
  intro p hp
  have h : env52217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52216_52217 : H12AffineEnvironment.transform 0 0 env52216 = env52217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env52216 == env52217) = true)

def env52218 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1,8192,1296,9244,65536,1297,65665,73790,9245,0,396,17,65553,66742,74799,73745,1297,74815,77082,8204,74798,256,65830,1296,75327]

theorem envBound52218 : H12AffineFastState.Bounded env52218 := by
  intro p hp
  have h : env52218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52205_52218 : H12AffineEnvironment.transform 5 17 env52205 = env52218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52205 == env52218) = true)

theorem identity52218 : scanCanonicalize (H12AffineFastState.compose env52218 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 1330) := by decide +kernel

theorem selectedBound52218 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env52219 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1,8192,1296,9244,1330,1297,1459,9484,9245,0,396,17,1315,388,8477,9507,1297,8461,10280,8204,8476,256,1044,1296,8973]

theorem envBound52219 : H12AffineFastState.Bounded env52219 := by
  intro p hp
  have h : env52219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52218_52219 : H12AffineEnvironment.transform 15 1330 env52218 = env52219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1330 env52218 == env52219) = true)

theorem identity52219 : scanCanonicalize (H12AffineFastState.compose env52219 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound52219 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env52220 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1,1052,1296,0,1330,1297,1459,272,1,0,396,17,1315,388,1281,319,1297,1297,3124,1040,1280,256,1044,1296,1809]

theorem envBound52220 : H12AffineFastState.Bounded env52220 := by
  intro p hp
  have h : env52220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52219_52220 : H12AffineEnvironment.transform 12 1052 env52219 = env52220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env52219 == env52220) = true)

theorem identity52220 : scanCanonicalize (H12AffineFastState.compose env52220 (packedSelected [0,2,3,7,8,11,12,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 1541) := by decide +kernel

theorem selectedBound52220 : packedSelected [0,2,3,7,8,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env52221 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1541,1,1052,1296,0,1330,1297,1459,272,1,0,396,17,1315,388,1281,319,1297,1297,561,1040,1280,256,1044,1296,1809]

theorem envBound52221 : H12AffineFastState.Bounded env52221 := by
  intro p hp
  have h : env52221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52220_52221 : H12AffineEnvironment.transform 10 1541 env52220 = env52221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1541 env52220 == env52221) = true)

theorem identity52221 : scanCanonicalize (H12AffineFastState.compose env52221 (packedSelected [2,10,19] rootPS)) = affineNative (2^(9+1) ^^^ 700) := by decide +kernel

theorem selectedBound52221 : packedSelected [2,10,19] rootPS < 2^1333 := by decide +kernel

def env52222 : List Nat := [2,4,8,16,32,17,128,256,512,700,185,1,672,940,0,910,941,783,272,1,0,396,17,927,388,957,319,941,941,561,684,956,256,680,940,429]

theorem envBound52222 : H12AffineFastState.Bounded env52222 := by
  intro p hp
  have h : env52222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52221_52222 : H12AffineEnvironment.transform 9 700 env52221 = env52222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 700 env52221 == env52222) = true)

theorem identity52222 : scanCanonicalize (H12AffineFastState.compose env52222 (packedSelected [1,5,11,18] rootPS)) = affineNative (2^(7+1) ^^^ 63) := by decide +kernel

theorem selectedBound52222 : packedSelected [1,5,11,18] rootPS < 2^1333 := by decide +kernel

def env52223 : List Nat := [2,4,8,16,32,17,128,63,512,700,185,1,672,659,0,689,658,560,47,1,0,179,17,672,187,642,0,658,658,561,684,643,63,680,659,146]

theorem envBound52223 : H12AffineFastState.Bounded env52223 := by
  intro p hp
  have h : env52223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52222_52223 : H12AffineEnvironment.transform 7 63 env52222 = env52223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env52222 == env52223) = true)

theorem identity52223 : scanCanonicalize (H12AffineFastState.compose env52223 (packedSelected [2,4,7] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound52223 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env52224 : List Nat := [2,4,8,16,32,17,128,63,136,52,185,1,40,27,0,57,26,184,47,1,0,179,17,40,187,10,0,26,26,185,36,11,63,32,27,146]

theorem envBound52224 : H12AffineFastState.Bounded env52224 := by
  intro p hp
  have h : env52224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52223_52224 : H12AffineEnvironment.transform 8 136 env52223 = env52224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env52223 == env52224) = true)

theorem identity52224 : scanCanonicalize (H12AffineFastState.compose env52224 (packedSelected [1,8] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound52224 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env52225 : List Nat := [2,4,8,16,32,17,56,63,48,52,1,1,40,27,0,57,26,0,47,1,0,11,17,40,3,10,0,26,26,1,36,11,63,32,27,42]

theorem envBound52225 : H12AffineFastState.Bounded env52225 := by
  intro p hp
  have h : env52225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52224_52225 : H12AffineEnvironment.transform 6 56 env52224 = env52225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env52224 == env52225) = true)

def env52226 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1345,262144,77935,32769,4097,46529,17,266384,70887,78895,77840,1297,74815,81227,365713,74799,256,308666,1345,79470]

theorem envBound52226 : H12AffineFastState.Bounded env52226 := by
  intro p hp
  have h : env52226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52175_52226 : H12AffineEnvironment.transform 13 1297 env52175 = env52226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env52175 == env52226) = true)

theorem identity52226 : scanCanonicalize (H12AffineFastState.compose env52226 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32882) := by decide +kernel

theorem selectedBound52226 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env52227 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,32882,1345,262144,45085,32769,4097,46529,17,266384,38037,46173,45154,1297,42061,48441,267491,42077,256,308666,1345,46620]

theorem envBound52227 : H12AffineFastState.Bounded env52227 := by
  intro p hp
  have h : env52227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52226_52227 : H12AffineEnvironment.transform 15 32882 env52226 = env52227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32882 env52226 == env52227) = true)

def env52228 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32882,1345,262144,42333,32769,1345,41089,17,263632,33237,41245,42274,1297,42061,43129,262563,42077,256,303354,1345,41820]

theorem envBound52228 : H12AffineFastState.Bounded env52228 := by
  intro p hp
  have h : env52228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52227_52228 : H12AffineEnvironment.transform 11 1344 env52227 = env52228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env52227 == env52228) = true)

theorem identity52228 : scanCanonicalize (H12AffineFastState.compose env52228 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 438) := by decide +kernel

theorem selectedBound52228 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env52229 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32882,1345,438,42333,32769,1345,41089,17,1126,33237,41245,42274,1297,42061,43129,21,42077,256,41292,1345,41820]

theorem envBound52229 : H12AffineFastState.Bounded env52229 := by
  intro p hp
  have h : env52229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52228_52229 : H12AffineEnvironment.transform 17 438 env52228 = env52229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 438 env52228 == env52229) = true)

theorem identity52229 : scanCanonicalize (H12AffineFastState.compose env52229 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound52229 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env52230 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,8540,8494,1345,438,1025,8541,1345,477,17,1126,8329,65,1150,1297,1297,2341,21,1281,256,16,1345,512]

theorem envBound52230 : H12AffineFastState.Bounded env52230 := by
  intro p hp
  have h : env52230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52229_52230 : H12AffineEnvironment.transform 14 8540 env52229 = env52230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env52229 == env52230) = true)

theorem identity52230 : scanCanonicalize (H12AffineFastState.compose env52230 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound52230 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env52231 : List Nat := [2,4,8,16,32,64,128,69,512,1024,2048,1029,8192,1108,8217,8299,1028,243,1025,8216,1028,152,17,1126,8329,65,1150,1108,1108,2144,21,1092,69,16,1028,512]

theorem envBound52231 : H12AffineFastState.Bounded env52231 := by
  intro p hp
  have h : env52231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52230_52231 : H12AffineEnvironment.transform 7 69 env52230 = env52231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env52230 == env52231) = true)

theorem identity52231 : scanCanonicalize (H12AffineFastState.compose env52231 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 657) := by decide +kernel

theorem selectedBound52231 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52232 : List Nat := [2,4,8,16,32,64,128,69,512,1024,2048,1029,657,1108,648,762,1028,243,1025,649,1028,152,17,1126,536,65,1150,1108,1108,2144,21,1092,69,16,1028,512]

theorem envBound52232 : H12AffineFastState.Bounded env52232 := by
  intro p hp
  have h : env52232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52231_52232 : H12AffineEnvironment.transform 12 657 env52231 = env52232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 657 env52231 == env52232) = true)

theorem identity52232 : scanCanonicalize (H12AffineFastState.compose env52232 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound52232 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env52233 : List Nat := [2,4,8,16,32,16,128,21,512,1024,2048,1029,657,1028,648,682,1028,163,1025,649,1028,152,17,1078,536,17,1070,1028,1028,2096,21,1044,21,16,1028,512]

theorem envBound52233 : H12AffineFastState.Bounded env52233 := by
  intro p hp
  have h : env52233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52232_52233 : H12AffineEnvironment.transform 5 16 env52232 = env52233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52232 == env52233) = true)

theorem identity52233 : scanCanonicalize (H12AffineFastState.compose env52233 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1174) := by decide +kernel

theorem selectedBound52233 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env52234 : List Nat := [2,4,8,16,32,16,128,21,512,1024,1174,1029,657,1028,648,682,1028,163,1025,649,1028,152,17,1078,536,17,1070,1028,1028,1190,21,1044,21,16,1028,512]

theorem envBound52234 : H12AffineFastState.Bounded env52234 := by
  intro p hp
  have h : env52234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52233_52234 : H12AffineEnvironment.transform 10 1174 env52233 = env52234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1174 env52233 == env52234) = true)

theorem identity52234 : scanCanonicalize (H12AffineFastState.compose env52234 (packedSelected [0,1,2,5,7,11] rootPS)) = affineNative (2^(9+1) ^^^ 151) := by decide +kernel

theorem selectedBound52234 : packedSelected [0,1,2,5,7,11] rootPS < 2^1333 := by decide +kernel

def env52235 : List Nat := [2,4,8,16,32,16,128,21,512,151,1,146,657,147,648,682,147,163,150,649,147,152,17,161,536,17,185,147,147,49,21,131,21,16,147,512]

theorem envBound52235 : H12AffineFastState.Bounded env52235 := by
  intro p hp
  have h : env52235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52234_52235 : H12AffineEnvironment.transform 9 151 env52234 = env52235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 151 env52234 == env52235) = true)

theorem identity52235 : scanCanonicalize (H12AffineFastState.compose env52235 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound52235 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env52236 : List Nat := [2,4,8,16,32,16,8,21,512,31,1,26,537,27,512,546,27,43,30,513,27,16,17,41,536,17,49,27,27,49,21,11,21,16,27,512]

theorem envBound52236 : H12AffineFastState.Bounded env52236 := by
  intro p hp
  have h : env52236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52235_52236 : H12AffineEnvironment.transform 6 8 env52235 = env52236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52235 == env52236) = true)

theorem identity52236 : scanCanonicalize (H12AffineFastState.compose env52236 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound52236 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52237 : List Nat := [2,4,8,16,10,16,8,21,512,31,1,26,537,27,512,520,27,1,30,513,27,16,17,3,536,17,27,27,27,27,21,11,21,16,27,512]

theorem envBound52237 : H12AffineFastState.Bounded env52237 := by
  intro p hp
  have h : env52237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52236_52237 : H12AffineEnvironment.transform 4 10 env52236 = env52237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env52236 == env52237) = true)

theorem identity52237 : scanCanonicalize (H12AffineFastState.compose env52237 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound52237 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env52238 : List Nat := [2,4,8,10,10,10,8,15,512,5,1,0,515,1,512,520,1,1,4,513,1,10,11,3,514,11,1,1,1,1,15,11,15,10,1,512]

theorem envBound52238 : H12AffineFastState.Bounded env52238 := by
  intro p hp
  have h : env52238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52237_52238 : H12AffineEnvironment.transform 3 10 env52237 = env52238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env52237 == env52238) = true)

theorem identity52238 : scanCanonicalize (H12AffineFastState.compose env52238 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound52238 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52239 : List Nat := [2,4,4,6,6,6,4,3,512,5,1,0,515,1,512,516,1,1,4,513,1,6,7,3,514,7,1,1,1,1,3,7,3,6,1,512]

theorem envBound52239 : H12AffineFastState.Bounded env52239 := by
  intro p hp
  have h : env52239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52238_52239 : H12AffineEnvironment.transform 2 4 env52238 = env52239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env52238 == env52239) = true)

theorem identity52239 : scanCanonicalize (H12AffineFastState.compose env52239 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound52239 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52240 : List Nat := [2,4,4,6,6,6,4,3,1,5,1,0,2,1,1,5,1,1,4,0,1,6,7,3,3,7,1,1,1,1,3,7,3,6,1,1]

theorem envBound52240 : H12AffineFastState.Bounded env52240 := by
  intro p hp
  have h : env52240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52239_52240 : H12AffineEnvironment.transform 8 1 env52239 = env52240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env52239 == env52240) = true)

def env52241 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32882,1345,262144,42332,32769,1344,41088,17,263633,33236,41244,42275,1297,42061,43128,262562,42077,256,303355,1345,41821]

theorem envBound52241 : H12AffineFastState.Bounded env52241 := by
  intro p hp
  have h : env52241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52227_52241 : H12AffineEnvironment.transform 11 1345 env52227 = env52241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env52227 == env52241) = true)

theorem identity52241 : scanCanonicalize (H12AffineFastState.compose env52241 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 324) := by decide +kernel

theorem selectedBound52241 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env52242 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,324,310,1345,262144,9240,325,1344,8644,17,263633,144,8280,9319,1297,9481,10556,262562,9497,256,270783,1345,8729]

theorem envBound52242 : H12AffineFastState.Bounded env52242 := by
  intro p hp
  have h : env52242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52241_52242 : H12AffineEnvironment.transform 14 324 env52241 = env52242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 324 env52241 == env52242) = true)

theorem identity52242 : scanCanonicalize (H12AffineFastState.compose env52242 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 10186) := by decide +kernel

theorem selectedBound52242 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env52243 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,324,310,1345,10186,9240,325,1344,8644,17,8731,144,8280,9319,1297,9481,10556,9832,9497,256,1653,1345,8729]

theorem envBound52243 : H12AffineFastState.Bounded env52243 := by
  intro p hp
  have h : env52243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52242_52243 : H12AffineEnvironment.transform 17 10186 env52242 = env52243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10186 env52242 == env52243) = true)

def env52244 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16465,262144,95614,32769,4097,61648,16,284033,86518,94527,77841,1296,74815,96346,381312,90431,256,308667,1345,95103]

theorem envBound52244 : H12AffineFastState.Bounded env52244 := by
  intro p hp
  have h : env52244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52174_52244 : H12AffineEnvironment.transform 16 16465 env52174 = env52244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16465 env52174 == env52244) = true)

def env52245 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1345,262144,77934,32769,4097,46528,16,266385,70886,78895,77841,1296,74815,81226,365712,74799,256,308667,1345,79471]

theorem envBound52245 : H12AffineFastState.Bounded env52245 := by
  intro p hp
  have h : env52245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52244_52245 : H12AffineEnvironment.transform 13 1296 env52244 = env52245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env52244 == env52245) = true)

theorem identity52245 : scanCanonicalize (H12AffineFastState.compose env52245 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32883) := by decide +kernel

theorem selectedBound52245 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env52246 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,32883,1345,262144,45085,32769,4097,46528,16,266385,38037,46172,45154,1296,42060,48441,267491,42076,256,308667,1345,46620]

theorem envBound52246 : H12AffineFastState.Bounded env52246 := by
  intro p hp
  have h : env52246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52245_52246 : H12AffineEnvironment.transform 15 32883 env52245 = env52246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32883 env52245 == env52246) = true)

def env52247 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32883,1345,262144,42333,32769,1345,41088,16,263633,33237,41244,42274,1296,42060,43129,262563,42076,256,303355,1345,41820]

theorem envBound52247 : H12AffineFastState.Bounded env52247 := by
  intro p hp
  have h : env52247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52246_52247 : H12AffineEnvironment.transform 11 1344 env52246 = env52247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env52246 == env52247) = true)

theorem identity52247 : scanCanonicalize (H12AffineFastState.compose env52247 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 34274) := by decide +kernel

theorem selectedBound52247 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env52248 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32883,1345,34274,42333,32769,1345,41088,16,32819,33237,41244,42274,1296,42060,43129,33857,42076,256,9497,1345,41820]

theorem envBound52248 : H12AffineFastState.Bounded env52248 := by
  intro p hp
  have h : env52248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52247_52248 : H12AffineEnvironment.transform 17 34274 env52247 = env52248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 34274 env52247 == env52248) = true)

theorem identity52248 : scanCanonicalize (H12AffineFastState.compose env52248 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(12+1) ^^^ 877) := by decide +kernel

theorem selectedBound52248 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env52249 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,877,1296,32768,32883,1345,34274,34352,32769,1345,33773,16,32819,33237,33393,34383,1296,34593,35604,33857,34609,256,1652,1345,32817]

theorem envBound52249 : H12AffineFastState.Bounded env52249 := by
  intro p hp
  have h : env52249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52248_52249 : H12AffineEnvironment.transform 12 877 env52248 = env52249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 877 env52248 == env52249) = true)

def env52250 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32883,1345,262144,42332,32769,1344,41089,16,263632,33236,41245,42275,1296,42060,43128,262562,42076,256,303354,1345,41821]

theorem envBound52250 : H12AffineFastState.Bounded env52250 := by
  intro p hp
  have h : env52250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52246_52250 : H12AffineEnvironment.transform 11 1345 env52246 = env52250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env52246 == env52250) = true)

theorem identity52250 : scanCanonicalize (H12AffineFastState.compose env52250 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound52250 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env52251 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,80,8192,1,32768,32883,80,262144,41037,32769,81,41089,16,262337,33236,41245,41010,1,41309,43128,262562,41293,256,303354,80,41821]

theorem envBound52251 : H12AffineFastState.Bounded env52251 := by
  intro p hp
  have h : env52251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52250_52251 : H12AffineEnvironment.transform 9 273 env52250 = env52251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env52250 == env52251) = true)

theorem identity52251 : scanCanonicalize (H12AffineFastState.compose env52251 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound52251 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env52252 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,80,8192,1,8541,8494,80,262144,272,8540,81,476,16,262337,8329,64,367,1,0,2341,262562,16,256,262567,80,512]

theorem envBound52252 : H12AffineFastState.Bounded env52252 := by
  intro p hp
  have h : env52252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52251_52252 : H12AffineEnvironment.transform 14 8541 env52251 = env52252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env52251 == env52252) = true)

theorem identity52252 : scanCanonicalize (H12AffineFastState.compose env52252 (packedSelected [4,9,16] rootPS)) = affineNative (2^(17+1) ^^^ 242) := by decide +kernel

theorem selectedBound52252 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env52253 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,80,8192,1,8541,8494,80,242,272,8540,81,476,16,51,8329,64,367,1,0,2341,336,16,256,341,80,512]

theorem envBound52253 : H12AffineFastState.Bounded env52253 := by
  intro p hp
  have h : env52253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52252_52253 : H12AffineEnvironment.transform 17 242 env52252 = env52253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 242 env52252 == env52253) = true)

theorem identity52253 : scanCanonicalize (H12AffineFastState.compose env52253 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 980) := by decide +kernel

theorem selectedBound52253 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52254 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,80,980,1,649,762,80,242,272,648,81,476,16,51,861,64,367,1,0,2341,336,16,256,341,80,512]

theorem envBound52254 : H12AffineFastState.Bounded env52254 := by
  intro p hp
  have h : env52254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52253_52254 : H12AffineEnvironment.transform 12 980 env52253 = env52254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 980 env52253 == env52254) = true)

theorem identity52254 : scanCanonicalize (H12AffineFastState.compose env52254 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound52254 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env52255 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,0,900,1,649,682,0,162,272,648,1,396,16,51,781,16,319,1,0,2341,256,16,256,261,0,512]

theorem envBound52255 : H12AffineFastState.Bounded env52255 := by
  intro p hp
  have h : env52255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52254_52255 : H12AffineEnvironment.transform 5 16 env52254 = env52255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52254 == env52255) = true)

theorem identity52255 : scanCanonicalize (H12AffineFastState.compose env52255 (packedSelected [1,3,13] rootPS)) = affineNative (2^(10+1) ^^^ 319) := by decide +kernel

theorem selectedBound52255 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env52256 : List Nat := [2,4,8,16,32,16,128,256,512,273,319,0,900,1,649,682,0,162,272,648,1,396,16,51,781,16,319,1,0,26,256,16,256,261,0,512]

theorem envBound52256 : H12AffineFastState.Bounded env52256 := by
  intro p hp
  have h : env52256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52255_52256 : H12AffineEnvironment.transform 10 319 env52255 = env52256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 319 env52255 == env52256) = true)

theorem identity52256 : scanCanonicalize (H12AffineFastState.compose env52256 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound52256 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env52257 : List Nat := [2,4,8,16,32,16,128,172,512,189,147,0,552,1,649,682,0,162,188,648,1,32,16,51,673,16,147,1,0,26,172,16,172,169,0,512]

theorem envBound52257 : H12AffineFastState.Bounded env52257 := by
  intro p hp
  have h : env52257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52256_52257 : H12AffineEnvironment.transform 7 172 env52256 = env52257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env52256 == env52257) = true)

theorem identity52257 : scanCanonicalize (H12AffineFastState.compose env52257 (packedSelected [1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound52257 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env52258 : List Nat := [2,4,8,16,32,16,128,172,137,189,147,0,161,1,0,35,0,162,188,1,1,32,16,51,40,16,147,1,0,26,172,16,172,169,0,137]

theorem envBound52258 : H12AffineFastState.Bounded env52258 := by
  intro p hp
  have h : env52258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52257_52258 : H12AffineEnvironment.transform 8 137 env52257 = env52258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env52257 == env52258) = true)

theorem identity52258 : scanCanonicalize (H12AffineFastState.compose env52258 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound52258 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52259 : List Nat := [2,4,8,16,11,16,128,135,137,150,147,0,138,1,0,8,0,137,151,1,1,11,16,24,3,16,147,1,0,26,135,16,135,130,0,137]

theorem envBound52259 : H12AffineFastState.Bounded env52259 := by
  intro p hp
  have h : env52259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52258_52259 : H12AffineEnvironment.transform 4 11 env52258 = env52259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env52258 == env52259) = true)

theorem identity52259 : scanCanonicalize (H12AffineFastState.compose env52259 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound52259 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env52260 : List Nat := [2,4,8,11,11,11,128,135,137,141,136,0,138,1,0,8,0,137,140,1,1,11,11,3,3,11,136,1,0,1,135,11,135,130,0,137]

theorem envBound52260 : H12AffineFastState.Bounded env52260 := by
  intro p hp
  have h : env52260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52259_52260 : H12AffineEnvironment.transform 3 11 env52259 = env52260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env52259 == env52260) = true)

theorem identity52260 : scanCanonicalize (H12AffineFastState.compose env52260 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound52260 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env52261 : List Nat := [2,4,8,11,11,11,8,15,1,5,0,0,2,1,0,8,0,1,4,1,1,11,11,3,3,11,0,1,0,1,15,11,15,10,0,1]

theorem envBound52261 : H12AffineFastState.Bounded env52261 := by
  intro p hp
  have h : env52261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52260_52261 : H12AffineEnvironment.transform 6 8 env52260 = env52261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52260 == env52261) = true)

theorem identity52261 : scanCanonicalize (H12AffineFastState.compose env52261 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound52261 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52262 : List Nat := [2,4,4,7,7,7,4,3,1,5,0,0,2,1,0,4,0,1,4,1,1,7,7,3,3,7,0,1,0,1,3,7,3,6,0,1]

theorem envBound52262 : H12AffineFastState.Bounded env52262 := by
  intro p hp
  have h : env52262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52261_52262 : H12AffineEnvironment.transform 2 4 env52261 = env52262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env52261 == env52262) = true)

def env52263 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1344,262144,77935,32769,4097,46529,16,266384,70887,78894,77841,1296,74815,81227,365713,74798,256,308667,1345,79470]

theorem envBound52263 : H12AffineFastState.Bounded env52263 := by
  intro p hp
  have h : env52263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52244_52263 : H12AffineEnvironment.transform 13 1297 env52244 = env52263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env52244 == env52263) = true)

theorem identity52263 : scanCanonicalize (H12AffineFastState.compose env52263 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound52263 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env52264 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1344,262144,77935,13340,4097,476,16,266384,70887,78894,77841,1296,74815,81227,336012,74798,256,262566,1345,79470]

theorem envBound52264 : H12AffineFastState.Bounded env52264 := by
  intro p hp
  have h : env52264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52263_52264 : H12AffineEnvironment.transform 14 13341 env52263 = env52264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env52263 == env52264) = true)

def env52265 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1344,65664,77935,13340,4097,476,16,69648,70887,78894,77841,1296,74815,81227,8204,74798,256,65830,1345,79470]

theorem envBound52265 : H12AffineFastState.Bounded env52265 := by
  intro p hp
  have h : env52265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52264_52265 : H12AffineEnvironment.transform 17 65664 env52264 = env52265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env52264 == env52265) = true)

theorem identity52265 : scanCanonicalize (H12AffineFastState.compose env52265 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5464) := by decide +kernel

theorem selectedBound52265 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env52266 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5464,1297,325,65536,1344,65664,66871,324,4097,476,16,69648,70887,65910,66889,1296,69991,67603,5460,70006,256,65830,1345,66358]

theorem envBound52266 : H12AffineFastState.Bounded env52266 := by
  intro p hp
  have h : env52266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52265_52266 : H12AffineEnvironment.transform 12 5464 env52265 = env52266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5464 env52265 == env52266) = true)

def env52267 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5384,1297,277,65536,1296,65664,66871,276,4097,396,16,69648,70839,65830,66841,1296,69943,67603,5380,69926,256,65830,1297,66358]

theorem envBound52267 : H12AffineFastState.Bounded env52267 := by
  intro p hp
  have h : env52267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52266_52267 : H12AffineEnvironment.transform 5 16 env52266 = env52267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52266 == env52267) = true)

theorem identity52267 : scanCanonicalize (H12AffineFastState.compose env52267 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 5426) := by decide +kernel

theorem selectedBound52267 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env52268 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5384,1297,277,5426,1296,5554,4101,276,4097,396,16,1314,389,5140,4139,1296,1029,7457,5380,1044,256,5140,1297,5636]

theorem envBound52268 : H12AffineFastState.Bounded env52268 := by
  intro p hp
  have h : env52268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52267_52268 : H12AffineEnvironment.transform 15 5426 env52267 = env52268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5426 env52267 == env52268) = true)

theorem identity52268 : scanCanonicalize (H12AffineFastState.compose env52268 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound52268 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env52269 : List Nat := [2,4,8,16,32,16,128,21,512,1024,2048,4096,5149,1028,0,5159,1029,5287,4101,1,4097,153,16,1079,144,5140,4139,1029,1029,7220,5137,1044,21,5140,1028,5636]

theorem envBound52269 : H12AffineFastState.Bounded env52269 := by
  intro p hp
  have h : env52269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52268_52269 : H12AffineEnvironment.transform 7 21 env52268 = env52269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env52268 == env52269) = true)

theorem identity52269 : scanCanonicalize (H12AffineFastState.compose env52269 (packedSelected [10,11,13,17,18,19] rootPS)) = affineNative (2^(11+1) ^^^ 27) := by decide +kernel

theorem selectedBound52269 : packedSelected [10,11,13,17,18,19] rootPS < 2^1333 := by decide +kernel

def env52270 : List Nat := [2,4,8,16,32,16,128,21,512,1024,2048,27,1030,1028,0,1084,1029,1212,30,1,26,153,16,1079,144,1039,48,1029,1029,3119,1034,1044,21,1039,1028,1567]

theorem envBound52270 : H12AffineFastState.Bounded env52270 := by
  intro p hp
  have h : env52270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52269_52270 : H12AffineEnvironment.transform 11 27 env52269 = env52270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 27 env52269 == env52270) = true)

theorem identity52270 : scanCanonicalize (H12AffineFastState.compose env52270 (packedSelected [1,2,3,10,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 1175) := by decide +kernel

theorem selectedBound52270 : packedSelected [1,2,3,10,13,15] rootPS < 2^1333 := by decide +kernel

def env52271 : List Nat := [2,4,8,16,32,16,128,21,512,1024,1175,27,1030,1028,0,1084,1029,1212,30,1,26,153,16,1079,144,1039,48,1029,1029,184,1034,1044,21,1039,1028,1567]

theorem envBound52271 : H12AffineFastState.Bounded env52271 := by
  intro p hp
  have h : env52271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52270_52271 : H12AffineEnvironment.transform 10 1175 env52270 = env52271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1175 env52270 == env52271) = true)

theorem identity52271 : scanCanonicalize (H12AffineFastState.compose env52271 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 167) := by decide +kernel

theorem selectedBound52271 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env52272 : List Nat := [2,4,8,16,32,16,128,21,512,167,48,27,161,163,0,155,162,27,30,1,26,153,16,144,144,168,48,162,162,184,173,179,21,168,163,696]

theorem envBound52272 : H12AffineFastState.Bounded env52272 := by
  intro p hp
  have h : env52272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52271_52272 : H12AffineEnvironment.transform 9 167 env52271 = env52272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 167 env52271 == env52272) = true)

theorem identity52272 : scanCanonicalize (H12AffineFastState.compose env52272 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 146) := by decide +kernel

theorem selectedBound52272 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52273 : List Nat := [2,4,8,16,32,16,128,21,146,167,48,27,161,163,0,155,162,27,30,1,26,153,16,144,144,168,48,162,162,184,173,179,21,168,163,42]

theorem envBound52273 : H12AffineFastState.Bounded env52273 := by
  intro p hp
  have h : env52273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52272_52273 : H12AffineEnvironment.transform 8 146 env52272 = env52273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 146 env52272 == env52273) = true)

theorem identity52273 : scanCanonicalize (H12AffineFastState.compose env52273 (packedSelected [1,3,4,9] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound52273 : packedSelected [1,3,4,9] rootPS < 2^1333 := by decide +kernel

def env52274 : List Nat := [2,4,8,16,32,16,35,21,49,4,48,27,2,0,0,56,1,27,30,1,26,58,16,51,51,11,48,1,1,27,14,16,21,11,0,42]

theorem envBound52274 : H12AffineFastState.Bounded env52274 := by
  intro p hp
  have h : env52274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52273_52274 : H12AffineEnvironment.transform 6 35 env52273 = env52274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env52273 == env52274) = true)

theorem identity52274 : scanCanonicalize (H12AffineFastState.compose env52274 (packedSelected [0,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound52274 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env52275 : List Nat := [2,4,8,16,28,16,31,21,13,4,12,27,2,0,0,4,1,27,30,1,26,6,16,15,15,11,12,1,1,27,14,16,21,11,0,22]

theorem envBound52275 : H12AffineFastState.Bounded env52275 := by
  intro p hp
  have h : env52275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52274_52275 : H12AffineEnvironment.transform 4 28 env52274 = env52275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env52274 == env52275) = true)

theorem identity52275 : scanCanonicalize (H12AffineFastState.compose env52275 (packedSelected [3,5] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound52275 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env52276 : List Nat := [2,4,8,6,10,6,9,3,13,4,12,13,2,0,0,4,1,13,8,1,12,6,6,15,15,11,12,1,1,13,14,6,3,11,0,0]

theorem envBound52276 : H12AffineFastState.Bounded env52276 := by
  intro p hp
  have h : env52276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52275_52276 : H12AffineEnvironment.transform 3 6 env52275 = env52276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env52275 == env52276) = true)

def env52277 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,5385,1297,276,65536,1297,65664,66871,277,4097,397,16,69648,70838,65831,66840,1296,69942,67603,5381,69927,256,65830,1296,66358]

theorem envBound52277 : H12AffineFastState.Bounded env52277 := by
  intro p hp
  have h : env52277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52266_52277 : H12AffineEnvironment.transform 5 17 env52266 = env52277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52266 == env52277) = true)

theorem identity52277 : scanCanonicalize (H12AffineFastState.compose env52277 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound52277 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env52278 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1028,269,1297,276,65536,1297,65664,66871,277,1029,397,16,66580,65714,65831,66840,1296,66866,67603,257,66851,256,65830,1296,66358]

theorem envBound52278 : H12AffineFastState.Bounded env52278 := by
  intro p hp
  have h : env52278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52277_52278 : H12AffineEnvironment.transform 11 1028 env52277 = env52278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env52277 == env52278) = true)

theorem identity52278 : scanCanonicalize (H12AffineFastState.compose env52278 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound52278 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env52279 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1028,269,1297,276,35,1297,163,1300,277,1029,397,16,1079,145,260,1339,1296,1297,2096,257,1280,256,261,1296,789]

theorem envBound52279 : H12AffineFastState.Bounded env52279 := by
  intro p hp
  have h : env52279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52278_52279 : H12AffineEnvironment.transform 15 35 env52278 = env52279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env52278 == env52279) = true)

theorem identity52279 : scanCanonicalize (H12AffineFastState.compose env52279 (packedSelected [0,1,2,5,7,10,11,19] rootPS)) = affineNative (2^(9+1) ^^^ 827) := by decide +kernel

theorem selectedBound52279 : packedSelected [0,1,2,5,7,10,11,19] rootPS < 2^1333 := by decide +kernel

def env52280 : List Nat := [2,4,8,16,32,17,128,256,512,827,2048,831,269,554,276,35,554,163,559,277,830,397,16,780,145,260,512,555,554,2096,257,571,256,261,555,789]

theorem envBound52280 : H12AffineFastState.Bounded env52280 := by
  intro p hp
  have h : env52280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52279_52280 : H12AffineEnvironment.transform 9 827 env52279 = env52280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 827 env52279 == env52280) = true)

theorem identity52280 : scanCanonicalize (H12AffineFastState.compose env52280 (packedSelected [0,1,2,7,8,17,18] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound52280 : packedSelected [0,1,2,7,8,17,18] rootPS < 2^1333 := by decide +kernel

def env52281 : List Nat := [2,4,8,16,16,17,128,256,512,779,2048,783,269,538,276,19,538,147,543,277,782,397,16,780,145,260,512,539,538,2048,257,523,256,261,539,789]

theorem envBound52281 : H12AffineFastState.Bounded env52281 := by
  intro p hp
  have h : env52281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52280_52281 : H12AffineEnvironment.transform 4 16 env52280 = env52281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env52280 == env52281) = true)

theorem identity52281 : scanCanonicalize (H12AffineFastState.compose env52281 (packedSelected [2,13] rootPS)) = affineNative (2^(10+1) ^^^ 391) := by decide +kernel

theorem selectedBound52281 : packedSelected [2,13] rootPS < 2^1333 := by decide +kernel

def env52282 : List Nat := [2,4,8,16,16,17,128,256,512,779,391,783,269,538,276,19,538,147,543,277,782,397,16,780,145,260,512,539,538,391,257,523,256,261,539,789]

theorem envBound52282 : H12AffineFastState.Bounded env52282 := by
  intro p hp
  have h : env52282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52281_52282 : H12AffineEnvironment.transform 10 391 env52281 = env52282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 391 env52281 == env52282) = true)

theorem identity52282 : scanCanonicalize (H12AffineFastState.compose env52282 (packedSelected [2,3,7,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 157) := by decide +kernel

theorem selectedBound52282 : packedSelected [2,3,7,8,9] rootPS < 2^1333 := by decide +kernel

def env52283 : List Nat := [2,4,8,16,16,17,128,157,512,662,26,658,144,538,137,19,538,147,543,136,659,16,16,657,145,153,512,539,538,26,156,523,157,152,539,648]

theorem envBound52283 : H12AffineFastState.Bounded env52283 := by
  intro p hp
  have h : env52283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52282_52283 : H12AffineEnvironment.transform 7 157 env52282 = env52283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 157 env52282 == env52283) = true)

theorem identity52283 : scanCanonicalize (H12AffineFastState.compose env52283 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound52283 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52284 : List Nat := [2,4,8,10,10,11,128,135,512,652,0,648,138,512,137,9,512,137,517,136,649,10,10,651,139,131,512,513,512,0,134,523,135,130,513,648]

theorem envBound52284 : H12AffineFastState.Bounded env52284 := by
  intro p hp
  have h : env52284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52283_52284 : H12AffineEnvironment.transform 3 10 env52283 = env52284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env52283 == env52284) = true)

def env52285 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1344,65665,77935,13340,4097,476,16,69649,70887,78894,77841,1296,74815,81227,8205,74798,256,65831,1345,79470]

theorem envBound52285 : H12AffineFastState.Bounded env52285 := by
  intro p hp
  have h : env52285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52264_52285 : H12AffineEnvironment.transform 17 65665 env52264 = env52285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env52264 == env52285) = true)

theorem identity52285 : scanCanonicalize (H12AffineFastState.compose env52285 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound52285 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env52286 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,24,1297,5125,65536,1344,65665,69751,5124,4097,476,16,69649,70887,70710,69641,1296,66599,73043,21,66614,256,65831,1345,71286]

theorem envBound52286 : H12AffineFastState.Bounded env52286 := by
  intro p hp
  have h : env52286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52285_52286 : H12AffineEnvironment.transform 12 24 env52285 = env52286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env52285 == env52286) = true)

def env52287 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,24,1297,5125,65536,1296,65665,69671,5124,4097,396,16,69649,70839,70710,69641,1296,66599,72963,21,66614,256,65831,1297,71206]

theorem envBound52287 : H12AffineFastState.Bounded env52287 := by
  intro p hp
  have h : env52287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52286_52287 : H12AffineEnvironment.transform 5 16 env52286 = env52287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52286 == env52287) = true)

theorem identity52287 : scanCanonicalize (H12AffineFastState.compose env52287 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 5427) := by decide +kernel

theorem selectedBound52287 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env52288 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,24,1297,5125,5427,1296,5554,1300,5124,4097,396,16,1314,388,261,1338,1296,4372,2096,21,4357,256,5140,1297,789]

theorem envBound52288 : H12AffineFastState.Bounded env52288 := by
  intro p hp
  have h : env52288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52287_52288 : H12AffineEnvironment.transform 15 5427 env52287 = env52288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5427 env52287 == env52288) = true)

theorem identity52288 : scanCanonicalize (H12AffineFastState.compose env52288 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound52288 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env52289 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,24,1297,276,34,1296,163,1300,277,1296,396,16,1314,388,261,1338,1296,1029,2096,21,1044,256,261,1297,789]

theorem envBound52289 : H12AffineFastState.Bounded env52289 := by
  intro p hp
  have h : env52289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52288_52289 : H12AffineEnvironment.transform 11 1297 env52288 = env52289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env52288 == env52289) = true)

theorem identity52289 : scanCanonicalize (H12AffineFastState.compose env52289 (packedSelected [0,1,3,7,10,11,12,15,19] rootPS)) = affineNative (2^(10+1) ^^^ 1190) := by decide +kernel

theorem selectedBound52289 : packedSelected [0,1,3,7,10,11,12,15,19] rootPS < 2^1333 := by decide +kernel

def env52290 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1190,1297,24,1297,276,34,1296,163,1300,277,1296,396,16,1314,388,261,1338,1296,1029,1174,21,1044,256,261,1297,789]

theorem envBound52290 : H12AffineFastState.Bounded env52290 := by
  intro p hp
  have h : env52290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52289_52290 : H12AffineEnvironment.transform 10 1190 env52289 = env52290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1190 env52289 == env52290) = true)

theorem identity52290 : scanCanonicalize (H12AffineFastState.compose env52290 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound52290 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env52291 : List Nat := [2,4,8,16,32,16,128,173,512,1024,1190,1212,24,1212,185,34,1213,163,1209,184,1213,33,16,1167,41,168,1175,1213,1029,1174,21,1044,173,168,1212,696]

theorem envBound52291 : H12AffineFastState.Bounded env52291 := by
  intro p hp
  have h : env52291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52290_52291 : H12AffineEnvironment.transform 7 173 env52290 = env52291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env52290 == env52291) = true)

theorem identity52291 : scanCanonicalize (H12AffineFastState.compose env52291 (packedSelected [0,1,2,4,5,7,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 542) := by decide +kernel

theorem selectedBound52291 : packedSelected [0,1,2,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env52292 : List Nat := [2,4,8,16,32,16,128,173,512,542,696,674,24,674,185,34,675,163,679,184,675,33,16,657,41,168,649,675,539,648,21,522,173,168,674,696]

theorem envBound52292 : H12AffineFastState.Bounded env52292 := by
  intro p hp
  have h : env52292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52291_52292 : H12AffineEnvironment.transform 9 542 env52291 = env52292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 542 env52291 == env52292) = true)

theorem identity52292 : scanCanonicalize (H12AffineFastState.compose env52292 (packedSelected [0,1,5,7,11] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound52292 : packedSelected [0,1,5,7,11] rootPS < 2^1333 := by decide +kernel

def env52293 : List Nat := [2,4,8,11,32,11,128,173,512,517,675,674,3,674,162,34,675,163,679,163,675,33,11,650,41,168,649,675,512,648,14,522,173,168,674,675]

theorem envBound52293 : H12AffineFastState.Bounded env52293 := by
  intro p hp
  have h : env52293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52292_52293 : H12AffineEnvironment.transform 3 11 env52292 = env52293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env52292 == env52293) = true)

theorem identity52293 : scanCanonicalize (H12AffineFastState.compose env52293 (packedSelected [3,5] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound52293 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env52294 : List Nat := [2,4,8,11,32,11,128,173,42,47,137,136,3,136,162,34,137,163,141,163,137,33,11,160,41,168,163,137,42,162,14,32,173,168,136,137]

theorem envBound52294 : H12AffineFastState.Bounded env52294 := by
  intro p hp
  have h : env52294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52293_52294 : H12AffineEnvironment.transform 8 42 env52293 = env52294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env52293 == env52294) = true)

theorem identity52294 : scanCanonicalize (H12AffineFastState.compose env52294 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound52294 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52295 : List Nat := [2,4,8,11,11,11,128,134,1,4,137,136,3,136,137,9,137,136,141,136,137,10,11,139,2,131,136,137,1,137,14,11,134,131,136,137]

theorem envBound52295 : H12AffineFastState.Bounded env52295 := by
  intro p hp
  have h : env52295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52294_52295 : H12AffineEnvironment.transform 4 11 env52294 = env52295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env52294 == env52295) = true)

theorem identity52295 : scanCanonicalize (H12AffineFastState.compose env52295 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound52295 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52296 : List Nat := [2,4,8,11,11,11,9,15,1,4,0,1,3,1,0,9,0,1,4,1,0,10,11,2,2,10,1,0,1,0,14,11,15,10,1,0]

theorem envBound52296 : H12AffineFastState.Bounded env52296 := by
  intro p hp
  have h : env52296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52295_52296 : H12AffineEnvironment.transform 6 9 env52295 = env52296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env52295 == env52296) = true)

theorem identity52296 : scanCanonicalize (H12AffineFastState.compose env52296 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound52296 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52297 : List Nat := [2,4,7,4,4,4,6,0,1,4,0,1,3,1,0,6,0,1,4,1,0,5,4,2,2,5,1,0,1,0,1,4,0,5,1,0]

theorem envBound52297 : H12AffineFastState.Bounded env52297 := by
  intro p hp
  have h : env52297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52296_52297 : H12AffineEnvironment.transform 2 7 env52296 = env52297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env52296 == env52297) = true)

theorem identity52297 : scanCanonicalize (H12AffineFastState.compose env52297 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound52297 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52298 : List Nat := [2,3,0,3,3,3,1,0,1,3,0,1,3,1,0,1,0,1,3,1,0,2,3,2,2,2,1,0,1,0,1,3,0,2,1,0]

theorem envBound52298 : H12AffineFastState.Bounded env52298 := by
  intro p hp
  have h : env52298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52297_52298 : H12AffineEnvironment.transform 1 3 env52297 = env52298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env52297 == env52298) = true)

theorem identity52298 : scanCanonicalize (H12AffineFastState.compose env52298 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound52298 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env52299 : List Nat := [1,0,0,0,0,0,1,0,1,0,0,1,0,1,0,1,0,1,0,1,0,1,0,1,1,1,1,0,1,0,1,0,0,1,1,0]

theorem envBound52299 : H12AffineFastState.Bounded env52299 := by
  intro p hp
  have h : env52299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52298_52299 : H12AffineEnvironment.transform 0 1 env52298 = env52299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env52298 == env52299) = true)

def env52300 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,24,1297,5125,65536,1297,65665,69670,5124,4097,397,16,69649,70838,70710,69641,1296,66599,72962,21,66614,256,65831,1296,71207]

theorem envBound52300 : H12AffineFastState.Bounded env52300 := by
  intro p hp
  have h : env52300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52286_52300 : H12AffineEnvironment.transform 5 17 env52286 = env52300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52286 == env52300) = true)

theorem identity52300 : scanCanonicalize (H12AffineFastState.compose env52300 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound52300 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env52301 : List Nat := [2,4,8,16,32,17,128,20,512,1024,2048,4096,24,1029,5125,65536,1029,65665,69670,5124,4097,153,16,69649,70838,70710,69641,1028,66599,72726,21,66614,20,65587,1028,71207]

theorem envBound52301 : H12AffineFastState.Bounded env52301 := by
  intro p hp
  have h : env52301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52300_52301 : H12AffineEnvironment.transform 7 20 env52300 = env52301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env52300 == env52301) = true)

theorem identity52301 : scanCanonicalize (H12AffineFastState.compose env52301 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound52301 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env52302 : List Nat := [2,4,8,16,32,17,128,20,512,1024,2048,1029,24,1029,0,65536,1029,65665,66595,1,1028,153,16,66580,65715,65587,66572,1028,66599,67603,21,66614,20,65587,1028,66082]

theorem envBound52302 : H12AffineFastState.Bounded env52302 := by
  intro p hp
  have h : env52302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52301_52302 : H12AffineEnvironment.transform 11 1029 env52301 = env52302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env52301 == env52302) = true)

theorem identity52302 : scanCanonicalize (H12AffineFastState.compose env52302 (packedSelected [0,1,2,3,7,10,12,15,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 3253) := by decide +kernel

theorem selectedBound52302 : packedSelected [0,1,2,3,7,10,12,15,18,19] rootPS < 2^1333 := by decide +kernel

def env52303 : List Nat := [2,4,8,16,32,17,128,20,512,1024,2048,1029,24,1029,0,3253,1029,3124,2198,1,1028,153,16,2209,3078,3206,2233,1028,2194,1190,21,2179,20,3206,1028,3735]

theorem envBound52303 : H12AffineFastState.Bounded env52303 := by
  intro p hp
  have h : env52303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52302_52303 : H12AffineEnvironment.transform 15 3253 env52302 = env52303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3253 env52302 == env52303) = true)

theorem identity52303 : scanCanonicalize (H12AffineFastState.compose env52303 (packedSelected [0,1,3,5,7,8,11,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 1174) := by decide +kernel

theorem selectedBound52303 : packedSelected [0,1,3,5,7,8,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env52304 : List Nat := [2,4,8,16,32,17,128,20,512,1024,1174,1029,24,1029,0,35,1029,162,1024,1,1028,153,16,1079,144,16,1071,1028,1028,1190,21,1045,20,16,1028,513]

theorem envBound52304 : H12AffineFastState.Bounded env52304 := by
  intro p hp
  have h : env52304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52303_52304 : H12AffineEnvironment.transform 10 1174 env52303 = env52304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1174 env52303 == env52304) = true)

theorem identity52304 : scanCanonicalize (H12AffineFastState.compose env52304 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 147) := by decide +kernel

theorem selectedBound52304 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env52305 : List Nat := [2,4,8,16,32,17,128,20,147,1024,1174,1029,24,1029,0,35,1029,162,1024,1,1028,153,16,1079,144,16,1071,1028,1028,1190,21,1045,20,16,1028,146]

theorem envBound52305 : H12AffineFastState.Bounded env52305 := by
  intro p hp
  have h : env52305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52304_52305 : H12AffineEnvironment.transform 8 147 env52304 = env52305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 147 env52304 == env52305) = true)

theorem identity52305 : scanCanonicalize (H12AffineFastState.compose env52305 (packedSelected [3,8] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound52305 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env52306 : List Nat := [2,4,8,16,11,17,128,20,147,1024,1174,1029,24,1029,0,8,1029,137,1024,1,1028,153,16,1052,144,16,1028,1028,1028,1165,21,1045,20,16,1028,146]

theorem envBound52306 : H12AffineFastState.Bounded env52306 := by
  intro p hp
  have h : env52306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52305_52306 : H12AffineEnvironment.transform 4 11 env52305 = env52306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env52305 == env52306) = true)

theorem identity52306 : scanCanonicalize (H12AffineFastState.compose env52306 (packedSelected [3,4] rootPS)) = affineNative (2^(9+1) ^^^ 28) := by decide +kernel

theorem selectedBound52306 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env52307 : List Nat := [2,4,8,16,11,17,128,20,147,28,138,25,24,25,0,8,25,137,28,1,24,153,16,0,144,16,24,24,24,145,21,9,20,16,24,146]

theorem envBound52307 : H12AffineFastState.Bounded env52307 := by
  intro p hp
  have h : env52307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52306_52307 : H12AffineEnvironment.transform 9 28 env52306 = env52307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 28 env52306 == env52307) = true)

theorem identity52307 : scanCanonicalize (H12AffineFastState.compose env52307 (packedSelected [1,7] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound52307 : packedSelected [1,7] rootPS < 2^1333 := by decide +kernel

def env52308 : List Nat := [0,4,8,16,9,17,128,20,145,28,136,25,24,25,0,8,25,137,28,1,24,153,16,0,144,16,24,24,24,145,21,9,20,16,24,144]

theorem envBound52308 : H12AffineFastState.Bounded env52308 := by
  intro p hp
  have h : env52308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52307_52308 : H12AffineEnvironment.transform 0 0 env52307 = env52308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env52307 == env52308) = true)

theorem identity52308 : scanCanonicalize (H12AffineFastState.compose env52308 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound52308 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env52309 : List Nat := [0,4,8,1,9,0,128,5,128,13,136,8,9,8,0,8,8,137,13,1,9,136,1,0,129,1,9,9,9,128,4,9,5,1,9,129]

theorem envBound52309 : H12AffineFastState.Bounded env52309 := by
  intro p hp
  have h : env52309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52308_52309 : H12AffineEnvironment.transform 3 1 env52308 = env52309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env52308 == env52309) = true)

theorem identity52309 : scanCanonicalize (H12AffineFastState.compose env52309 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound52309 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52310 : List Nat := [0,4,5,1,4,0,128,5,128,0,133,5,4,5,0,5,5,132,0,1,4,133,1,0,129,1,4,4,4,128,4,4,5,1,4,129]

theorem envBound52310 : H12AffineFastState.Bounded env52310 := by
  intro p hp
  have h : env52310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52309_52310 : H12AffineEnvironment.transform 2 5 env52309 = env52310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env52309 == env52310) = true)

theorem identity52310 : scanCanonicalize (H12AffineFastState.compose env52310 (packedSelected [2,3] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound52310 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env52311 : List Nat := [0,1,0,1,1,0,128,0,128,0,128,0,1,0,0,0,0,129,0,1,1,128,1,0,129,1,1,1,1,128,1,1,0,1,1,129]

theorem envBound52311 : H12AffineFastState.Bounded env52311 := by
  intro p hp
  have h : env52311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52310_52311 : H12AffineEnvironment.transform 1 1 env52310 = env52311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env52310 == env52311) = true)

def env52312 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,16777216,533641,672784,134217728,148801,545088,96346,16876544,151258286,257,135065812,151462016,525824]

theorem envBound52312 : H12AffineFastState.Bounded env52312 := by
  intro p hp
  have h : env52312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans51283_52312 : H12AffineEnvironment.transform 24 533641 env51283 = env52312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533641 env51283 == env52312) = true)

def env52313 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,16777216,533641,672784,17245632,148801,545088,96346,16876544,205166,257,17552660,1344,525824]

theorem envBound52313 : H12AffineFastState.Bounded env52313 := by
  intro p hp
  have h : env52313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52312_52313 : H12AffineEnvironment.transform 26 17245632 env52312 = env52313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env52312 == env52313) = true)

theorem identity52313 : scanCanonicalize (H12AffineFastState.compose env52313 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 41003) := by decide +kernel

theorem selectedBound52313 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env52314 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147521,41003,533641,672784,493035,148801,545088,96346,74795,205166,257,750911,1344,525824]

theorem envBound52314 : H12AffineFastState.Bounded env52314 := by
  intro p hp
  have h : env52314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52313_52314 : H12AffineEnvironment.transform 23 41003 env52313 = env52314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41003 env52313 == env52314) = true)

def env52315 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147521,41003,143497,20496,493035,148801,148800,96346,74795,205166,257,90431,1344,135680]

theorem envBound52315 : H12AffineFastState.Bounded env52315 := by
  intro p hp
  have h : env52315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52314_52315 : H12AffineEnvironment.transform 18 136192 env52314 = env52315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env52314 == env52315) = true)

def env52316 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147521,41003,143497,20496,492615,148717,148716,96346,74795,204994,173,90259,1260,135680]

theorem envBound52316 : H12AffineFastState.Bounded env52316 := by
  intro p hp
  have h : env52316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52315_52316 : H12AffineEnvironment.transform 7 172 env52315 = env52316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env52315 == env52316) = true)

def env52317 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61568,147473,41003,143497,20496,492567,148669,148668,96266,74795,204946,173,90259,1212,135680]

theorem envBound52317 : H12AffineFastState.Bounded env52317 := by
  intro p hp
  have h : env52317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52316_52317 : H12AffineEnvironment.transform 5 16 env52316 = env52317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52316 == env52317) = true)

theorem identity52317 : scanCanonicalize (H12AffineFastState.compose env52317 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 137352) := by decide +kernel

theorem selectedBound52317 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env52318 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137352,136192,32769,4097,61568,147473,41003,143497,20496,105631,148669,148668,96266,74795,204946,173,90259,1212,135680]

theorem envBound52318 : H12AffineFastState.Bounded env52318 := by
  intro p hp
  have h : env52318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52317_52318 : H12AffineEnvironment.transform 17 137352 env52317 = env52318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137352 env52317 == env52318) = true)

theorem identity52318 : scanCanonicalize (H12AffineFastState.compose env52318 (packedSelected [1,5,8,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 13374) := by decide +kernel

theorem selectedBound52318 : packedSelected [1,5,8,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env52319 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,13374,131072,137352,136192,32769,4097,61568,147473,41003,143497,20496,43169,148669,148668,19508,4117,136364,173,21677,1212,135680]

theorem envBound52319 : H12AffineFastState.Bounded env52319 := by
  intro p hp
  have h : env52319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52318_52319 : H12AffineEnvironment.transform 15 13374 env52318 = env52319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13374 env52318 == env52319) = true)

theorem identity52319 : scanCanonicalize (H12AffineFastState.compose env52319 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound52319 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env52320 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1212,32768,13374,131072,137352,136192,32769,4097,46140,132269,41003,143497,5292,43169,131073,131072,2184,4117,136364,173,4113,1212,135680]

theorem envBound52320 : H12AffineFastState.Bounded env52320 := by
  intro p hp
  have h : env52320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52319_52320 : H12AffineEnvironment.transform 13 1212 env52319 = env52320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env52319 == env52320) = true)

theorem identity52320 : scanCanonicalize (H12AffineFastState.compose env52320 (packedSelected [13,17] rootPS)) = affineNative (2^(14+1) ^^^ 9380) := by decide +kernel

theorem selectedBound52320 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env52321 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1212,9380,13374,131072,137352,136192,9381,4097,4248,132269,1167,143497,5292,3077,131073,131072,2184,4117,136364,173,4113,1212,135680]

theorem envBound52321 : H12AffineFastState.Bounded env52321 := by
  intro p hp
  have h : env52321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52320_52321 : H12AffineEnvironment.transform 14 9380 env52320 = env52321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9380 env52320 == env52321) = true)

theorem identity52321 : scanCanonicalize (H12AffineFastState.compose env52321 (packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 3103) := by decide +kernel

theorem selectedBound52321 : packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env52322 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,3103,8192,1212,9380,10273,131072,132247,133151,9381,3102,3207,132269,1167,142486,2227,3077,131073,131072,2184,3082,133299,173,3086,1212,134687]

theorem envBound52322 : H12AffineFastState.Bounded env52322 := by
  intro p hp
  have h : env52322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52321_52322 : H12AffineEnvironment.transform 11 3103 env52321 = env52322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3103 env52321 == env52322) = true)

theorem identity52322 : scanCanonicalize (H12AffineFastState.compose env52322 (packedSelected [1,4,5,9,16] rootPS)) = affineNative (2^(16+1) ^^^ 10243) := by decide +kernel

theorem selectedBound52322 : packedSelected [1,4,5,9,16] rootPS < 2^1333 := by decide +kernel

def env52323 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,3103,8192,1212,9380,10273,10243,11412,8220,9381,3102,3207,11438,1167,1173,2227,3077,10242,10243,2184,3082,8368,173,3086,1212,9756]

theorem envBound52323 : H12AffineFastState.Bounded env52323 := by
  intro p hp
  have h : env52323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52322_52323 : H12AffineEnvironment.transform 16 10243 env52322 = env52323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 10243 env52322 == env52323) = true)

theorem identity52323 : scanCanonicalize (H12AffineFastState.compose env52323 (packedSelected [0,1,2,3,4,6,10,13] rootPS)) = affineNative (2^(12+1) ^^^ 2098) := by decide +kernel

theorem selectedBound52323 : packedSelected [0,1,2,3,4,6,10,13] rootPS < 2^1333 := by decide +kernel

def env52324 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,3103,2098,1212,3222,19,49,1190,2094,3223,3102,3207,1180,1167,1173,2227,3077,48,49,2184,3082,2178,173,3086,1212,3630]

theorem envBound52324 : H12AffineFastState.Bounded env52324 := by
  intro p hp
  have h : env52324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52323_52324 : H12AffineEnvironment.transform 12 2098 env52323 = env52324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2098 env52323 == env52324) = true)

theorem identity52324 : scanCanonicalize (H12AffineFastState.compose env52324 (packedSelected [0,1,2,4,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 141) := by decide +kernel

theorem selectedBound52324 : packedSelected [0,1,2,4,8,10] rootPS < 2^1333 := by decide +kernel

def env52325 : List Nat := [2,4,8,16,32,16,128,172,512,141,2048,2194,2098,49,2075,19,49,43,2094,2074,2195,2058,17,2,24,2227,2184,48,49,2184,2183,2178,173,2179,49,2723]

theorem envBound52325 : H12AffineFastState.Bounded env52325 := by
  intro p hp
  have h : env52325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52324_52325 : H12AffineEnvironment.transform 9 141 env52324 = env52325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 141 env52324 == env52325) = true)

theorem identity52325 : scanCanonicalize (H12AffineFastState.compose env52325 (packedSelected [0,1,2,4,6] rootPS)) = affineNative (2^(10+1) ^^^ 6) := by decide +kernel

theorem selectedBound52325 : packedSelected [0,1,2,4,6] rootPS < 2^1333 := by decide +kernel

def env52326 : List Nat := [2,4,8,16,32,16,128,172,512,141,6,148,52,49,29,19,49,43,40,28,149,12,17,2,24,181,142,48,49,142,129,132,173,133,49,677]

theorem envBound52326 : H12AffineFastState.Bounded env52326 := by
  intro p hp
  have h : env52326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52325_52326 : H12AffineEnvironment.transform 10 6 env52325 = env52326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 6 env52325 == env52326) = true)

theorem identity52326 : scanCanonicalize (H12AffineFastState.compose env52326 (packedSelected [0,3,4,5,8] rootPS)) = affineNative (2^(8+1) ^^^ 54) := by decide +kernel

theorem selectedBound52326 : packedSelected [0,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env52327 : List Nat := [2,4,8,16,32,16,128,172,54,141,6,148,52,49,29,19,49,43,40,28,149,12,17,2,24,181,142,48,49,142,129,132,173,133,49,147]

theorem envBound52327 : H12AffineFastState.Bounded env52327 := by
  intro p hp
  have h : env52327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52326_52327 : H12AffineEnvironment.transform 8 54 env52326 = env52327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 54 env52326 == env52327) = true)

def env52328 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61569,147472,41003,143497,20496,492566,148668,148669,96267,74795,204947,173,90259,1213,135680]

theorem envBound52328 : H12AffineFastState.Bounded env52328 := by
  intro p hp
  have h : env52328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52316_52328 : H12AffineEnvironment.transform 5 17 env52316 = env52328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52316 == env52328) = true)

theorem identity52328 : scanCanonicalize (H12AffineFastState.compose env52328 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound52328 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env52329 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,45216,262144,42144,32769,4097,61569,61616,41003,32809,20496,341174,62492,62493,96267,74795,102451,173,90259,1213,41632]

theorem envBound52329 : H12AffineFastState.Bounded env52329 := by
  intro p hp
  have h : env52329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52328_52329 : H12AffineEnvironment.transform 16 45216 env52328 = env52329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env52328 == env52329) = true)

theorem identity52329 : scanCanonicalize (H12AffineFastState.compose env52329 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound52329 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env52330 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1212,32768,65536,45216,262144,42144,32769,4097,46141,46092,41003,32809,5292,341174,45216,45217,81079,74795,102451,173,74799,1213,41632]

theorem envBound52330 : H12AffineFastState.Bounded env52330 := by
  intro p hp
  have h : env52330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52329_52330 : H12AffineEnvironment.transform 13 1212 env52329 = env52330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env52329 == env52330) = true)

theorem identity52330 : scanCanonicalize (H12AffineFastState.compose env52330 (packedSelected [4,9,16] rootPS)) = affineNative (2^(14+1) ^^^ 12312) := by decide +kernel

theorem selectedBound52330 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env52331 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1212,12312,65536,184,262144,5304,12313,4097,1061,1044,4147,12337,5292,341174,184,185,81079,74795,73771,173,74799,1213,4792]

theorem envBound52331 : H12AffineFastState.Bounded env52331 := by
  intro p hp
  have h : env52331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52330_52331 : H12AffineEnvironment.transform 14 12312 env52330 = env52331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12312 env52330 == env52331) = true)

theorem identity52331 : scanCanonicalize (H12AffineFastState.compose env52331 (packedSelected [4,9,20] rootPS)) = affineNative (2^(15+1) ^^^ 9350) := by decide +kernel

theorem selectedBound52331 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env52332 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1212,12312,9350,184,262144,5304,12313,4097,1061,1044,4147,12337,5292,266288,184,185,6193,173,1197,173,169,1213,4792]

theorem envBound52332 : H12AffineFastState.Bounded env52332 := by
  intro p hp
  have h : env52332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52331_52332 : H12AffineEnvironment.transform 15 9350 env52331 = env52332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9350 env52331 == env52332) = true)

theorem identity52332 : scanCanonicalize (H12AffineFastState.compose env52332 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound52332 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env52333 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1212,12312,9350,184,2185,5304,12313,4097,1061,1044,4147,12337,5292,6329,184,185,6193,173,1197,173,169,1213,4792]

theorem envBound52333 : H12AffineFastState.Bounded env52333 := by
  intro p hp
  have h : env52333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52332_52333 : H12AffineEnvironment.transform 17 2185 env52332 = env52333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env52332 == env52333) = true)

theorem identity52333 : scanCanonicalize (H12AffineFastState.compose env52333 (packedSelected [1,2,3,4,5,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound52333 : packedSelected [1,2,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env52334 : List Nat := [2,4,8,16,32,17,128,172,0,1024,2048,4096,8192,1212,12312,9350,184,2185,5304,12313,4097,1061,1044,4147,12337,5292,6329,184,185,6193,173,1197,173,169,1213,4280]

theorem envBound52334 : H12AffineFastState.Bounded env52334 := by
  intro p hp
  have h : env52334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52333_52334 : H12AffineEnvironment.transform 8 0 env52333 = env52334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env52333 == env52334) = true)

theorem identity52334 : scanCanonicalize (H12AffineFastState.compose env52334 (packedSelected [1,4,6,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound52334 : packedSelected [1,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env52335 : List Nat := [2,4,8,16,32,17,128,172,0,1024,48,4096,8192,1212,12312,9350,184,185,5304,12313,4097,1061,1044,4147,12337,5292,4233,184,185,4097,173,1197,173,169,1213,4280]

theorem envBound52335 : H12AffineFastState.Bounded env52335 := by
  intro p hp
  have h : env52335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52334_52335 : H12AffineEnvironment.transform 10 48 env52334 = env52335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env52334 == env52335) = true)

theorem identity52335 : scanCanonicalize (H12AffineFastState.compose env52335 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound52335 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52336 : List Nat := [2,4,8,16,32,17,128,172,0,1024,48,4096,25,1212,4097,1183,184,185,5304,4096,4097,1061,1044,4147,4136,5292,4233,184,185,4097,173,1197,173,169,1213,4280]

theorem envBound52336 : H12AffineFastState.Bounded env52336 := by
  intro p hp
  have h : env52336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52335_52336 : H12AffineEnvironment.transform 12 25 env52335 = env52336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env52335 == env52336) = true)

theorem identity52336 : scanCanonicalize (H12AffineFastState.compose env52336 (packedSelected [3,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 1077) := by decide +kernel

theorem selectedBound52336 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env52337 : List Nat := [2,4,8,16,32,17,128,172,0,1024,48,1077,25,1212,1076,1183,184,185,141,1077,1076,1061,1044,1030,1053,153,1212,184,185,1076,173,1197,173,169,1213,1165]

theorem envBound52337 : H12AffineFastState.Bounded env52337 := by
  intro p hp
  have h : env52337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52336_52337 : H12AffineEnvironment.transform 11 1077 env52336 = env52337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1077 env52336 == env52337) = true)

theorem identity52337 : scanCanonicalize (H12AffineFastState.compose env52337 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(9+1) ^^^ 151) := by decide +kernel

theorem selectedBound52337 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env52338 : List Nat := [2,4,8,16,32,17,128,172,0,151,48,162,25,43,163,8,184,185,141,162,163,178,131,145,138,153,43,184,185,163,173,58,173,169,42,26]

theorem envBound52338 : H12AffineFastState.Bounded env52338 := by
  intro p hp
  have h : env52338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52337_52338 : H12AffineEnvironment.transform 9 151 env52337 = env52338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 151 env52337 == env52338) = true)

theorem identity52338 : scanCanonicalize (H12AffineFastState.compose env52338 (packedSelected [1,5] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound52338 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env52339 : List Nat := [2,4,8,16,32,17,8,36,0,31,48,42,25,43,43,8,48,49,5,42,43,58,11,25,2,17,43,48,49,43,37,58,37,33,42,26]

theorem envBound52339 : H12AffineFastState.Bounded env52339 := by
  intro p hp
  have h : env52339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52338_52339 : H12AffineEnvironment.transform 6 8 env52338 = env52339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52338 == env52339) = true)

theorem identity52339 : scanCanonicalize (H12AffineFastState.compose env52339 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound52339 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52340 : List Nat := [2,4,8,16,28,17,8,24,0,31,12,22,25,23,23,8,12,13,5,22,23,6,11,25,2,17,23,12,13,23,25,6,25,29,22,26]

theorem envBound52340 : H12AffineFastState.Bounded env52340 := by
  intro p hp
  have h : env52340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52339_52340 : H12AffineEnvironment.transform 4 28 env52339 = env52340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env52339 == env52340) = true)

def env52341 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147521,41003,143497,20496,492614,148716,148717,96346,74795,204995,172,90258,1261,135680]

theorem envBound52341 : H12AffineFastState.Bounded env52341 := by
  intro p hp
  have h : env52341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52315_52341 : H12AffineEnvironment.transform 7 173 env52315 = env52341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env52315 == env52341) = true)

def env52342 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61568,147473,41003,143497,20496,492566,148668,148669,96266,74795,204947,172,90258,1213,135680]

theorem envBound52342 : H12AffineFastState.Bounded env52342 := by
  intro p hp
  have h : env52342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52341_52342 : H12AffineEnvironment.transform 5 16 env52341 = env52342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52341 == env52342) = true)

theorem identity52342 : scanCanonicalize (H12AffineFastState.compose env52342 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 223243) := by decide +kernel

theorem selectedBound52342 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env52343 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,223243,136192,32769,4097,61568,147473,41003,143497,20496,60445,148668,148669,96266,74795,204947,172,90258,1213,135680]

theorem envBound52343 : H12AffineFastState.Bounded env52343 := by
  intro p hp
  have h : env52343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52342_52343 : H12AffineEnvironment.transform 17 223243 env52342 = env52343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223243 env52342 == env52343) = true)

theorem identity52343 : scanCanonicalize (H12AffineFastState.compose env52343 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 28802) := by decide +kernel

theorem selectedBound52343 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env52344 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,28802,131072,137353,136192,32769,4097,61568,147473,41003,143497,20496,60445,148668,148669,2184,21673,151569,172,4112,1213,135680]

theorem envBound52344 : H12AffineFastState.Bounded env52344 := by
  intro p hp
  have h : env52344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52343_52344 : H12AffineEnvironment.transform 15 28802 env52343 = env52344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28802 env52343 == env52344) = true)

theorem identity52344 : scanCanonicalize (H12AffineFastState.compose env52344 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(14+1) ^^^ 12313) := by decide +kernel

theorem selectedBound52344 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env52345 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,12313,28802,131072,137353,136192,12312,4097,16537,147473,4146,143497,20496,23556,148668,148669,2184,21673,151569,172,4112,1213,135680]

theorem envBound52345 : H12AffineFastState.Bounded env52345 := by
  intro p hp
  have h : env52345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52344_52345 : H12AffineEnvironment.transform 14 12313 env52344 = env52345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12313 env52344 == env52345) = true)

theorem identity52345 : scanCanonicalize (H12AffineFastState.compose env52345 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound52345 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env52346 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1213,12313,13375,131072,137353,136192,12312,4097,1060,132268,4146,143497,5293,6329,131073,131072,2184,4116,136364,172,4112,1213,135680]

theorem envBound52346 : H12AffineFastState.Bounded env52346 := by
  intro p hp
  have h : env52346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52345_52346 : H12AffineEnvironment.transform 13 1213 env52345 = env52346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env52345 == env52346) = true)

theorem identity52346 : scanCanonicalize (H12AffineFastState.compose env52346 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(16+1) ^^^ 10379) := by decide +kernel

theorem selectedBound52346 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env52347 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1213,12313,13375,10379,12290,15499,12312,4097,1060,11303,4146,6146,5293,6329,10378,10379,2184,4116,15399,172,4112,1213,14987]

theorem envBound52347 : H12AffineFastState.Bounded env52347 := by
  intro p hp
  have h : env52347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52346_52347 : H12AffineEnvironment.transform 16 10379 env52346 = env52347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 10379 env52346 == env52347) = true)

theorem identity52347 : scanCanonicalize (H12AffineFastState.compose env52347 (packedSelected [0,4,5,7,8,9,10,17] rootPS)) = affineNative (2^(12+1) ^^^ 7310) := by decide +kernel

theorem selectedBound52347 : packedSelected [0,4,5,7,8,9,10,17] rootPS < 2^1333 := by decide +kernel

def env52348 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,7310,1213,3223,2225,5125,3212,5,3222,4097,1060,4265,4146,6146,5293,6329,5124,5125,2184,4116,169,172,4112,1213,1541]

theorem envBound52348 : H12AffineFastState.Bounded env52348 := by
  intro p hp
  have h : env52348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52347_52348 : H12AffineEnvironment.transform 12 7310 env52347 = env52348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7310 env52347 == env52348) = true)

theorem identity52348 : scanCanonicalize (H12AffineFastState.compose env52348 (packedSelected [0,1,2,3,4,5,7,8,9,11,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound52348 : packedSelected [0,1,2,3,4,5,7,8,9,11,12,15] rootPS < 2^1333 := by decide +kernel

def env52349 : List Nat := [2,4,8,16,32,16,128,173,512,516,2048,4096,6794,697,2707,2225,4609,2696,5,2706,4097,544,4265,4146,6146,4777,6329,4608,4609,2184,4116,169,172,4112,697,1]

theorem envBound52349 : H12AffineFastState.Bounded env52349 := by
  intro p hp
  have h : env52349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52348_52349 : H12AffineEnvironment.transform 9 516 env52348 = env52349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env52348 == env52349) = true)

theorem identity52349 : scanCanonicalize (H12AffineFastState.compose env52349 (packedSelected [1,2,3,5,6,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 674) := by decide +kernel

theorem selectedBound52349 : packedSelected [1,2,3,5,6,8,10,11] rootPS < 2^1333 := by decide +kernel

def env52350 : List Nat := [2,4,8,16,32,16,128,173,512,516,674,4096,4136,697,49,531,4609,42,5,48,4097,544,4265,4146,4768,4777,4635,4608,4609,554,4116,169,172,4112,697,1]

theorem envBound52350 : H12AffineFastState.Bounded env52350 := by
  intro p hp
  have h : env52350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52349_52350 : H12AffineEnvironment.transform 10 674 env52349 = env52350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 674 env52349 == env52350) = true)

theorem identity52350 : scanCanonicalize (H12AffineFastState.compose env52350 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(8+1) ^^^ 146) := by decide +kernel

theorem selectedBound52350 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env52351 : List Nat := [2,4,8,16,32,16,128,173,146,150,48,4096,4136,43,49,129,4243,42,5,48,4097,178,4265,4146,4146,4155,4233,4242,4243,184,4116,169,172,4112,43,1]

theorem envBound52351 : H12AffineFastState.Bounded env52351 := by
  intro p hp
  have h : env52351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52350_52351 : H12AffineEnvironment.transform 8 146 env52350 = env52351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 146 env52350 == env52351) = true)

theorem identity52351 : scanCanonicalize (H12AffineFastState.compose env52351 (packedSelected [1,8] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound52351 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env52352 : List Nat := [2,4,8,16,32,16,128,173,146,150,48,184,144,43,49,129,43,42,5,48,185,178,17,138,138,131,49,42,43,184,172,169,172,168,43,1]

theorem envBound52352 : H12AffineFastState.Bounded env52352 := by
  intro p hp
  have h : env52352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52351_52352 : H12AffineEnvironment.transform 11 184 env52351 = env52352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env52351 == env52352) = true)

theorem identity52352 : scanCanonicalize (H12AffineFastState.compose env52352 (packedSelected [0,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound52352 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env52353 : List Nat := [2,4,8,16,6,16,128,139,146,150,22,158,144,13,23,129,13,12,5,22,159,148,17,138,138,131,23,12,13,158,138,143,138,142,13,1]

theorem envBound52353 : H12AffineFastState.Bounded env52353 := by
  intro p hp
  have h : env52353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52352_52353 : H12AffineEnvironment.transform 4 6 env52352 = env52353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env52352 == env52353) = true)

theorem identity52353 : scanCanonicalize (H12AffineFastState.compose env52353 (packedSelected [1,5] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound52353 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env52354 : List Nat := [2,4,8,16,6,16,19,24,1,5,22,13,3,13,23,18,13,12,5,22,12,7,17,25,25,16,23,12,13,13,25,28,25,29,13,1]

theorem envBound52354 : H12AffineFastState.Bounded env52354 := by
  intro p hp
  have h : env52354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52353_52354 : H12AffineEnvironment.transform 6 19 env52353 = env52354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env52353 == env52354) = true)

theorem identity52354 : scanCanonicalize (H12AffineFastState.compose env52354 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound52354 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52355 : List Nat := [2,4,4,16,6,16,19,20,1,5,22,1,3,1,23,18,1,0,5,22,0,7,17,21,21,16,23,0,1,1,21,16,21,17,1,1]

theorem envBound52355 : H12AffineFastState.Bounded env52355 := by
  intro p hp
  have h : env52355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52354_52355 : H12AffineEnvironment.transform 2 4 env52354 = env52355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env52354 == env52355) = true)

theorem identity52355 : scanCanonicalize (H12AffineFastState.compose env52355 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound52355 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52356 : List Nat := [2,4,4,6,6,6,5,2,1,5,0,1,3,1,1,4,1,0,5,0,0,7,7,3,3,6,1,0,1,1,3,6,3,7,1,1]

theorem envBound52356 : H12AffineFastState.Bounded env52356 := by
  intro p hp
  have h : env52356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52355_52356 : H12AffineEnvironment.transform 3 6 env52355 = env52356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env52355 == env52356) = true)

def env52357 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61569,147472,41003,143497,20496,492567,148669,148668,96267,74795,204946,172,90258,1212,135680]

theorem envBound52357 : H12AffineFastState.Bounded env52357 := by
  intro p hp
  have h : env52357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52341_52357 : H12AffineEnvironment.transform 5 17 env52341 = env52357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52341 == env52357) = true)

theorem identity52357 : scanCanonicalize (H12AffineFastState.compose env52357 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 114722) := by decide +kernel

theorem selectedBound52357 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env52358 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,114722,262144,119842,32769,4097,61569,98354,41003,127147,20496,279605,99487,99486,96267,74795,57520,172,90258,1212,119330]

theorem envBound52358 : H12AffineFastState.Bounded env52358 := by
  intro p hp
  have h : env52358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52357_52358 : H12AffineEnvironment.transform 16 114722 env52357 = env52358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114722 env52357 == env52358) = true)

theorem identity52358 : scanCanonicalize (H12AffineFastState.compose env52358 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 6192) := by decide +kernel

theorem selectedBound52358 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env52359 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,114722,6192,119842,32769,4097,61569,98354,41003,127147,20496,23557,99487,99486,96267,74795,57520,172,90258,1212,119330]

theorem envBound52359 : H12AffineFastState.Bounded env52359 := by
  intro p hp
  have h : env52359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52358_52359 : H12AffineEnvironment.transform 17 6192 env52358 = env52359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6192 env52358 == env52359) = true)

theorem identity52359 : scanCanonicalize (H12AffineFastState.compose env52359 (packedSelected [7,16,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound52359 : packedSelected [7,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env52360 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,53282,4096,6192,1024,32769,4097,61569,20496,41003,8329,20496,23557,21693,21692,43049,62473,57520,172,45232,1212,512]

theorem envBound52360 : H12AffineFastState.Bounded env52360 := by
  intro p hp
  have h : env52360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52359_52360 : H12AffineEnvironment.transform 15 53282 env52359 = env52360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env52359 == env52360) = true)

theorem identity52360 : scanCanonicalize (H12AffineFastState.compose env52360 (packedSelected [4,9,16] rootPS)) = affineNative (2^(14+1) ^^^ 29861) := by decide +kernel

theorem selectedBound52360 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env52361 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,29861,9351,4096,6192,1024,29860,4097,1060,20496,21646,8329,20496,23557,21693,21692,23692,172,5141,172,17429,1212,512]

theorem envBound52361 : H12AffineFastState.Bounded env52361 := by
  intro p hp
  have h : env52361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52360_52361 : H12AffineEnvironment.transform 14 29861 env52360 = env52361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29861 env52360 == env52361) = true)

theorem identity52361 : scanCanonicalize (H12AffineFastState.compose env52361 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 8744) := by decide +kernel

theorem selectedBound52361 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52362 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,8744,5773,9351,4096,6192,1024,5772,4097,1060,12856,13990,8329,12856,15917,13973,13972,16036,172,5141,172,9789,1212,512]

theorem envBound52362 : H12AffineFastState.Bounded env52362 := by
  intro p hp
  have h : env52362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52361_52362 : H12AffineEnvironment.transform 13 8744 env52361 = env52362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8744 env52361 == env52362) = true)

theorem identity52362 : scanCanonicalize (H12AffineFastState.compose env52362 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(12+1) ^^^ 5174) := by decide +kernel

theorem selectedBound52362 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env52363 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,5174,5662,5773,4273,4096,6192,1024,5772,4097,1060,1550,656,5311,1550,2587,675,674,2706,172,5141,172,4619,1212,512]

theorem envBound52363 : H12AffineFastState.Bounded env52363 := by
  intro p hp
  have h : env52363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52362_52363 : H12AffineEnvironment.transform 12 5174 env52362 = env52363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5174 env52362 == env52363) = true)

theorem identity52363 : scanCanonicalize (H12AffineFastState.compose env52363 (packedSelected [1,3,13] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound52363 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env52364 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,184,1166,1702,1589,9,184,2184,1024,1588,185,1060,1550,656,1031,1550,2587,675,674,2706,172,1197,172,691,1212,512]

theorem envBound52364 : H12AffineFastState.Bounded env52364 := by
  intro p hp
  have h : env52364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52363_52364 : H12AffineEnvironment.transform 11 184 env52363 = env52364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env52363 == env52364) = true)

theorem identity52364 : scanCanonicalize (H12AffineFastState.compose env52364 (packedSelected [1,2,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 1703) := by decide +kernel

theorem selectedBound52364 : packedSelected [1,2,5,6] rootPS < 2^1333 := by decide +kernel

def env52365 : List Nat := [2,4,8,16,32,17,128,173,512,1024,1703,184,1166,1702,1589,9,184,1583,1024,1588,185,1060,1550,656,1031,1550,1212,675,674,1077,172,1197,172,691,1212,512]

theorem envBound52365 : H12AffineFastState.Bounded env52365 := by
  intro p hp
  have h : env52365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52364_52365 : H12AffineEnvironment.transform 10 1703 env52364 = env52365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1703 env52364 == env52365) = true)

theorem identity52365 : scanCanonicalize (H12AffineFastState.compose env52365 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound52365 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env52366 : List Nat := [2,4,8,16,32,17,128,173,0,1024,1191,184,1166,1190,1077,9,184,1071,1024,1076,185,1060,1038,144,1031,1038,1212,163,162,1077,172,1197,172,179,1212,0]

theorem envBound52366 : H12AffineFastState.Bounded env52366 := by
  intro p hp
  have h : env52366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52365_52366 : H12AffineEnvironment.transform 8 0 env52365 = env52366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env52365 == env52366) = true)

def env52367 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147521,41003,143496,20497,493035,148801,148801,96346,74795,205166,257,90430,1344,135681]

theorem envBound52367 : H12AffineFastState.Bounded env52367 := by
  intro p hp
  have h : env52367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52314_52367 : H12AffineEnvironment.transform 18 136193 env52314 = env52367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env52314 == env52367) = true)

def env52368 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147521,41003,143496,20497,492615,148717,148717,96346,74795,204994,173,90258,1260,135681]

theorem envBound52368 : H12AffineFastState.Bounded env52368 := by
  intro p hp
  have h : env52368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52367_52368 : H12AffineEnvironment.transform 7 172 env52367 = env52368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env52367 == env52368) = true)

def env52369 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61568,147473,41003,143496,20497,492567,148669,148669,96266,74795,204946,173,90258,1212,135681]

theorem envBound52369 : H12AffineFastState.Bounded env52369 := by
  intro p hp
  have h : env52369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52368_52369 : H12AffineEnvironment.transform 5 16 env52368 = env52369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52368 == env52369) = true)

theorem identity52369 : scanCanonicalize (H12AffineFastState.compose env52369 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound52369 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env52370 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,45217,262144,42144,32769,4097,61568,61616,41003,32809,20497,341174,62492,62492,96266,74795,102451,173,90258,1212,41632]

theorem envBound52370 : H12AffineFastState.Bounded env52370 := by
  intro p hp
  have h : env52370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52369_52370 : H12AffineEnvironment.transform 16 45217 env52369 = env52370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env52369 == env52370) = true)

theorem identity52370 : scanCanonicalize (H12AffineFastState.compose env52370 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound52370 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env52371 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1213,32768,65536,45217,262144,42144,32769,4097,46141,46093,41003,32809,5292,341174,45217,45217,81079,74795,102451,173,74799,1212,41632]

theorem envBound52371 : H12AffineFastState.Bounded env52371 := by
  intro p hp
  have h : env52371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52370_52371 : H12AffineEnvironment.transform 13 1213 env52370 = env52371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env52370 == env52371) = true)

end H12CloudChart2