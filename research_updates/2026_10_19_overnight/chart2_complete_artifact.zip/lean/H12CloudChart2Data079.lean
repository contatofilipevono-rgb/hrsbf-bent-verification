import H12CloudChart2Data078

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans19373_19374 : H12AffineEnvironment.transform 14 773 env19373 = env19374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 773 env19373 == env19374) = true)

theorem identity19374 : scanCanonicalize (H12AffineFastState.compose env19374 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound19374 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env19375 : List Nat := [2,4,8,16,0,17,8,256,512,273,2048,0,9,0,773,263,0,262144,273,772,0,513,16,775,9,16,262916,1,1,2821,20,513,256,773,0,512]

theorem envBound19375 : H12AffineFastState.Bounded env19375 := by
  intro p hp
  have h : env19375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19374_19375 : H12AffineEnvironment.transform 6 8 env19374 = env19375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19374 == env19375) = true)

theorem identity19375 : scanCanonicalize (H12AffineFastState.compose env19375 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound19375 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19376 : List Nat := [2,4,8,0,0,1,8,256,512,257,2048,0,9,0,773,263,0,262144,257,772,0,513,0,775,9,0,262916,1,1,2821,4,513,256,773,0,512]

theorem envBound19376 : H12AffineFastState.Bounded env19376 := by
  intro p hp
  have h : env19376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19375_19376 : H12AffineEnvironment.transform 3 0 env19375 = env19376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env19375 == env19376) = true)

theorem identity19376 : scanCanonicalize (H12AffineFastState.compose env19376 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound19376 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env19377 : List Nat := [2,4,8,0,0,1,8,4,512,5,2048,0,9,0,513,3,0,262144,5,512,0,513,0,515,9,0,262656,1,1,2561,4,513,4,513,0,512]

theorem envBound19377 : H12AffineFastState.Bounded env19377 := by
  intro p hp
  have h : env19377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19376_19377 : H12AffineEnvironment.transform 7 4 env19376 = env19377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env19376 == env19377) = true)

theorem identity19377 : scanCanonicalize (H12AffineFastState.compose env19377 (packedSelected [12] rootPS)) = affineNative (2^(17+1) ^^^ 0) := by decide +kernel

theorem selectedBound19377 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env19378 : List Nat := [2,4,8,0,0,1,8,4,512,5,2048,0,9,0,513,3,0,0,5,512,0,513,0,515,9,0,512,1,1,2561,4,513,4,513,0,512]

theorem envBound19378 : H12AffineFastState.Bounded env19378 := by
  intro p hp
  have h : env19378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19377_19378 : H12AffineEnvironment.transform 17 0 env19377 = env19378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 0 env19377 == env19378) = true)

theorem identity19378 : scanCanonicalize (H12AffineFastState.compose env19378 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound19378 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env19379 : List Nat := [2,4,8,0,0,1,8,4,1,5,2048,0,9,0,0,3,0,0,5,1,0,0,0,2,9,0,1,1,1,2048,4,0,4,0,0,1]

theorem envBound19379 : H12AffineFastState.Bounded env19379 := by
  intro p hp
  have h : env19379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19378_19379 : H12AffineEnvironment.transform 8 1 env19378 = env19379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env19378 == env19379) = true)

theorem identity19379 : scanCanonicalize (H12AffineFastState.compose env19379 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound19379 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19380 : List Nat := [2,4,8,0,0,1,8,4,1,5,0,0,9,0,0,3,0,0,5,1,0,0,0,2,9,0,1,1,1,0,4,0,4,0,0,1]

theorem envBound19380 : H12AffineFastState.Bounded env19380 := by
  intro p hp
  have h : env19380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19379_19380 : H12AffineEnvironment.transform 10 0 env19379 = env19380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env19379 == env19380) = true)

def env19381 : List Nat := [2,4,8,16,1,17,128,256,512,273,2048,0,129,0,32768,65536,0,262144,273,32769,0,4194304,16,4293516,9,16,263052,1,1,1073741824,4194973,4194440,256,4293519,0,512]

theorem envBound19381 : H12AffineFastState.Bounded env19381 := by
  intro p hp
  have h : env19381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19369_19381 : H12AffineEnvironment.transform 4 1 env19369 = env19381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19369 == env19381) = true)

theorem identity19381 : scanCanonicalize (H12AffineFastState.compose env19381 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 33419) := by decide +kernel

theorem selectedBound19381 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19382 : List Nat := [2,4,8,16,1,17,128,256,512,273,2048,0,129,0,32768,33419,0,262144,273,32769,0,4194304,16,4194567,9,16,263052,1,1,1073741824,4194973,4194440,256,4194564,0,512]

theorem envBound19382 : H12AffineFastState.Bounded env19382 := by
  intro p hp
  have h : env19382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19381_19382 : H12AffineEnvironment.transform 15 33419 env19381 = env19382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33419 env19381 == env19382) = true)

theorem identity19382 : scanCanonicalize (H12AffineFastState.compose env19382 (packedSelected [2,3,6,8,11,13,17,18] rootPS)) = affineNative (2^(21+1) ^^^ 396) := by decide +kernel

theorem selectedBound19382 : packedSelected [2,3,6,8,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env19383 : List Nat := [2,4,8,16,1,17,128,256,512,273,2048,0,129,0,32768,33419,0,262144,273,32769,0,396,16,139,9,16,263052,1,1,1073741824,785,260,256,136,0,512]

theorem envBound19383 : H12AffineFastState.Bounded env19383 := by
  intro p hp
  have h : env19383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19382_19383 : H12AffineEnvironment.transform 21 396 env19382 = env19383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 396 env19382 == env19383) = true)

theorem identity19383 : scanCanonicalize (H12AffineFastState.compose env19383 (packedSelected [13,17] rootPS)) = affineNative (2^(29+1) ^^^ 35725) := by decide +kernel

theorem selectedBound19383 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env19384 : List Nat := [2,4,8,16,1,17,128,256,512,273,2048,0,129,0,32768,33419,0,262144,273,32769,0,396,16,139,9,16,263052,1,1,35725,785,260,256,136,0,512]

theorem envBound19384 : H12AffineFastState.Bounded env19384 := by
  intro p hp
  have h : env19384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19383_19384 : H12AffineEnvironment.transform 29 35725 env19383 = env19384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 35725 env19383 == env19384) = true)

theorem identity19384 : scanCanonicalize (H12AffineFastState.compose env19384 (packedSelected [0,2,3,4,6,7,8,9,11,12,13,15,23] rootPS)) = affineNative (2^(14+1) ^^^ 396) := by decide +kernel

theorem selectedBound19384 : packedSelected [0,2,3,4,6,7,8,9,11,12,13,15,23] rootPS < 2^1333 := by decide +kernel

def env19385 : List Nat := [2,4,8,16,1,17,128,256,512,273,2048,0,129,0,396,775,0,262144,273,397,0,396,16,139,9,16,263052,1,1,2561,785,260,256,136,0,512]

theorem envBound19385 : H12AffineFastState.Bounded env19385 := by
  intro p hp
  have h : env19385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19384_19385 : H12AffineEnvironment.transform 14 396 env19384 = env19385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 396 env19384 == env19385) = true)

theorem identity19385 : scanCanonicalize (H12AffineFastState.compose env19385 (packedSelected [4,9,11,15] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound19385 : packedSelected [4,9,11,15] rootPS < 2^1333 := by decide +kernel

def env19386 : List Nat := [2,4,8,16,1,17,128,256,137,273,2048,0,129,0,396,398,0,262144,273,397,0,396,16,139,9,16,262405,1,1,2184,408,260,256,136,0,137]

theorem envBound19386 : H12AffineFastState.Bounded env19386 := by
  intro p hp
  have h : env19386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19385_19386 : H12AffineEnvironment.transform 8 137 env19385 = env19386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env19385 == env19386) = true)

theorem identity19386 : scanCanonicalize (H12AffineFastState.compose env19386 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound19386 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19387 : List Nat := [2,4,8,16,1,17,25,256,16,273,2048,0,24,0,277,279,0,262144,273,276,0,277,16,18,9,16,262405,1,1,2065,257,260,256,17,0,16]

theorem envBound19387 : H12AffineFastState.Bounded env19387 := by
  intro p hp
  have h : env19387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19386_19387 : H12AffineEnvironment.transform 6 25 env19386 = env19387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env19386 == env19387) = true)

theorem identity19387 : scanCanonicalize (H12AffineFastState.compose env19387 (packedSelected [0,3,7,11,12] rootPS)) = affineNative (2^(17+1) ^^^ 2308) := by decide +kernel

theorem selectedBound19387 : packedSelected [0,3,7,11,12] rootPS < 2^1333 := by decide +kernel

def env19388 : List Nat := [2,4,8,16,1,17,25,256,16,273,2048,0,24,0,277,279,0,2308,273,276,0,277,16,18,9,16,2049,1,1,2065,257,260,256,17,0,16]

theorem envBound19388 : H12AffineFastState.Bounded env19388 := by
  intro p hp
  have h : env19388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19387_19388 : H12AffineEnvironment.transform 17 2308 env19387 = env19388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2308 env19387 == env19388) = true)

theorem identity19388 : scanCanonicalize (H12AffineFastState.compose env19388 (packedSelected [3,4,7] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound19388 : packedSelected [3,4,7] rootPS < 2^1333 := by decide +kernel

def env19389 : List Nat := [2,4,8,16,1,17,25,20,16,5,2048,0,24,0,1,3,0,2064,5,0,0,1,16,18,9,16,2049,1,1,2065,21,16,20,17,0,16]

theorem envBound19389 : H12AffineFastState.Bounded env19389 := by
  intro p hp
  have h : env19389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19388_19389 : H12AffineEnvironment.transform 7 20 env19388 = env19389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env19388 == env19389) = true)

def env19390 : List Nat := [2,4,8,16,1,17,25,20,16,5,0,0,24,0,1,3,0,16,5,0,0,1,16,18,9,16,1,1,1,17,21,16,20,17,0,16]

theorem envBound19390 : H12AffineFastState.Bounded env19390 := by
  intro p hp
  have h : env19390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19389_19390 : H12AffineEnvironment.transform 10 0 env19389 = env19390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env19389 == env19390) = true)

def leafEnv19390 : List Nat := [2,4,8,16,1,17,25,20,16,5,0,0,24,0,1,3,0,16,5,0,0,1,16,18,20,9,1,16,1,1,1,17,21,16,20,17,5,19,0,16,0,0,1]

def active19390 : List Nat := [0,1,2,3]

def tree19390 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19390 : H12WitnessSearch.Good tree19390 := H12GlobalWitnessIndex.good

theorem leafIdentity19390 : H12AffineFastState.composeSystem env19390 rootObs = leafEnv19390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19390 rootObs == leafEnv19390) = true)

theorem terminalChecked19390 : H12PackedTerminal.terminalCheckFast leafEnv19390 active19390 tree19390 = true := by decide +kernel

def env19391 : List Nat := [2,4,8,16,1,17,25,20,16,5,1,0,24,0,1,3,0,17,5,0,0,1,16,18,9,16,0,1,1,16,21,16,20,17,0,16]

theorem envBound19391 : H12AffineFastState.Bounded env19391 := by
  intro p hp
  have h : env19391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19389_19391 : H12AffineEnvironment.transform 10 1 env19389 = env19391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env19389 == env19391) = true)

theorem identity19391 : scanCanonicalize (H12AffineFastState.compose env19391 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound19391 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19392 : List Nat := [2,4,8,0,1,1,9,4,0,5,1,0,8,0,1,3,0,1,5,0,0,1,0,2,9,0,0,1,1,0,5,0,4,1,0,0]

theorem envBound19392 : H12AffineFastState.Bounded env19392 := by
  intro p hp
  have h : env19392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19391_19392 : H12AffineEnvironment.transform 3 0 env19391 = env19392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env19391 == env19392) = true)

def leafEnv19392 : List Nat := [2,4,8,0,1,1,9,4,0,5,1,0,8,0,1,3,0,1,5,0,0,1,0,2,4,9,1,0,0,1,1,0,5,0,4,1,5,3,0,0,0,0,1]

def active19392 : List Nat := [0,1,2]

def tree19392 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19392 : H12WitnessSearch.Good tree19392 := H12GlobalWitnessIndex.good

theorem leafIdentity19392 : H12AffineFastState.composeSystem env19392 rootObs = leafEnv19392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19392 rootObs == leafEnv19392) = true)

theorem terminalChecked19392 : H12PackedTerminal.terminalCheckFast leafEnv19392 active19392 tree19392 = true := by decide +kernel

def env19393 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1344,262144,1024,32769,1344,4194304,64,16777216,8328,17,21331968,1344,1344,1073741824,16876544,4294967296,256,4315938986,1344,512]

theorem envBound19393 : H12AffineFastState.Bounded env19393 := by
  intro p hp
  have h : env19393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19249_19393 : H12AffineEnvironment.transform 13 1345 env19249 = env19393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env19249 == env19393) = true)

theorem identity19393 : scanCanonicalize (H12AffineFastState.compose env19393 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound19393 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env19394 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1297,32768,65536,1296,262144,1024,32769,1296,4194304,16,16777216,8328,17,21331968,1296,1296,1073741824,16876544,4294967296,256,4315938986,1296,512]

theorem envBound19394 : H12AffineFastState.Bounded env19394 := by
  intro p hp
  have h : env19394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19393_19394 : H12AffineEnvironment.transform 5 16 env19393 = env19394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19393 == env19394) = true)

theorem identity19394 : scanCanonicalize (H12AffineFastState.compose env19394 (packedSelected [13,21] rootPS)) = affineNative (2^(31+1) ^^^ 4194440) := by decide +kernel

theorem selectedBound19394 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env19395 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1297,32768,65536,1296,262144,1024,32769,1296,4194304,16,16777216,8328,17,21331968,1296,1296,1073741824,16876544,4194440,256,16777250,1296,512]

theorem envBound19395 : H12AffineFastState.Bounded env19395 := by
  intro p hp
  have h : env19395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19394_19395 : H12AffineEnvironment.transform 31 4194440 env19394 = env19395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4194440 env19394 == env19395) = true)

theorem identity19395 : scanCanonicalize (H12AffineFastState.compose env19395 (packedSelected [1,3,24,28] rootPS)) = affineNative (2^(29+1) ^^^ 21071872) := by decide +kernel

theorem selectedBound19395 : packedSelected [1,3,24,28] rootPS < 2^1333 := by decide +kernel

def env19396 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1297,32768,65536,1296,262144,1024,32769,1296,4194304,16,16777216,8328,17,21331968,1296,1296,21071872,16876544,4194440,256,16777250,1296,512]

theorem envBound19396 : H12AffineFastState.Bounded env19396 := by
  intro p hp
  have h : env19396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19395_19396 : H12AffineEnvironment.transform 29 21071872 env19395 = env19396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 21071872 env19395 == env19396) = true)

theorem identity19396 : scanCanonicalize (H12AffineFastState.compose env19396 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(23+1) ^^^ 338220) := by decide +kernel

theorem selectedBound19396 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env19397 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1297,32768,65536,1296,262144,1024,32769,1296,4194304,16,338220,8328,17,4237612,1296,1296,4497708,306476,4194440,256,338190,1296,512]

theorem envBound19397 : H12AffineFastState.Bounded env19397 := by
  intro p hp
  have h : env19397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19396_19397 : H12AffineEnvironment.transform 23 338220 env19396 = env19397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 338220 env19396 == env19397) = true)

theorem identity19397 : scanCanonicalize (H12AffineFastState.compose env19397 (packedSelected [0,1,3,5,7,8,11,12,15,18] rootPS)) = affineNative (2^(21+1) ^^^ 362634) := by decide +kernel

theorem selectedBound19397 : packedSelected [0,1,3,5,7,8,11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env19398 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1297,32768,65536,1296,262144,1024,32769,1296,362634,16,338220,8328,17,336294,1296,1296,76198,306476,362498,256,338190,1296,512]

theorem envBound19398 : H12AffineFastState.Bounded env19398 := by
  intro p hp
  have h : env19398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19397_19398 : H12AffineEnvironment.transform 21 362634 env19397 = env19398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 362634 env19397 == env19398) = true)

theorem identity19398 : scanCanonicalize (H12AffineFastState.compose env19398 (packedSelected [1,3,5,8,13,17] rootPS)) = affineNative (2^(15+1) ^^^ 8614) := by decide +kernel

theorem selectedBound19398 : packedSelected [1,3,5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env19399 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1297,32768,8614,1296,262144,1024,32769,1296,305452,16,264330,8328,17,262144,1296,1296,2048,306476,305572,256,264360,1296,512]

theorem envBound19399 : H12AffineFastState.Bounded env19399 := by
  intro p hp
  have h : env19399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19398_19399 : H12AffineEnvironment.transform 15 8614 env19398 = env19399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8614 env19398 == env19399) = true)

theorem identity19399 : scanCanonicalize (H12AffineFastState.compose env19399 (packedSelected [0,7] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound19399 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env19400 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1297,32768,8614,1296,43048,1024,32769,1296,260,16,41122,8328,17,43048,1296,1296,2048,1284,396,256,41088,1296,512]

theorem envBound19400 : H12AffineFastState.Bounded env19400 := by
  intro p hp
  have h : env19400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19399_19400 : H12AffineEnvironment.transform 17 43048 env19399 = env19400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env19399 == env19400) = true)

theorem identity19400 : scanCanonicalize (H12AffineFastState.compose env19400 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound19400 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19401 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,8192,1297,32768,8614,1296,43048,1024,32769,1296,260,16,41122,8328,17,43048,1296,1296,2048,1284,396,256,41088,1296,137]

theorem envBound19401 : H12AffineFastState.Bounded env19401 := by
  intro p hp
  have h : env19401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19400_19401 : H12AffineEnvironment.transform 8 137 env19400 = env19401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env19400 == env19401) = true)

theorem identity19401 : scanCanonicalize (H12AffineFastState.compose env19401 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound19401 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env19402 : List Nat := [2,4,8,16,32,16,128,5,137,1024,2048,1045,8192,1044,32768,8355,1045,43048,1024,32769,1045,1,16,41122,8328,17,43048,1045,1045,2048,1025,137,5,41088,1045,137]

theorem envBound19402 : H12AffineFastState.Bounded env19402 := by
  intro p hp
  have h : env19402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19401_19402 : H12AffineEnvironment.transform 7 5 env19401 = env19402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env19401 == env19402) = true)

theorem identity19402 : scanCanonicalize (H12AffineFastState.compose env19402 (packedSelected [0,6] rootPS)) = affineNative (2^(14+1) ^^^ 2080) := by decide +kernel

theorem selectedBound19402 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env19403 : List Nat := [2,4,8,16,32,16,128,5,137,1024,2048,1045,8192,1044,2080,8355,1045,8200,1024,2081,1045,1,16,10370,8328,17,8200,1045,1045,2048,1025,137,5,10400,1045,137]

theorem envBound19403 : H12AffineFastState.Bounded env19403 := by
  intro p hp
  have h : env19403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19402_19403 : H12AffineEnvironment.transform 14 2080 env19402 = env19403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2080 env19402 == env19403) = true)

theorem identity19403 : scanCanonicalize (H12AffineFastState.compose env19403 (packedSelected [2,4] rootPS)) = affineNative (2^(12+1) ^^^ 2056) := by decide +kernel

theorem selectedBound19403 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env19404 : List Nat := [2,4,8,16,32,16,128,5,137,1024,2048,1045,2056,1044,2080,2219,1045,2048,1024,2081,1045,1,16,138,2176,17,2048,1045,1045,2048,1025,137,5,168,1045,137]

theorem envBound19404 : H12AffineFastState.Bounded env19404 := by
  intro p hp
  have h : env19404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19403_19404 : H12AffineEnvironment.transform 12 2056 env19403 = env19404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2056 env19403 == env19404) = true)

theorem identity19404 : scanCanonicalize (H12AffineFastState.compose env19404 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1180) := by decide +kernel

theorem selectedBound19404 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19405 : List Nat := [2,4,8,16,32,16,128,5,137,1024,1180,1045,1172,1044,1212,1079,1045,1180,1024,1213,1045,1,16,138,1052,17,1180,1045,1045,1180,1025,137,5,168,1045,137]

theorem envBound19405 : H12AffineFastState.Bounded env19405 := by
  intro p hp
  have h : env19405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19404_19405 : H12AffineEnvironment.transform 10 1180 env19404 = env19405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1180 env19404 == env19405) = true)

def env19406 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,16384,32768,65536,1344,262144,1024,32769,1345,4194304,17665,16777216,8328,17744,21331968,16385,16384,1073741824,16876544,4294967296,256,4315938986,1344,512]

theorem envBound19406 : H12AffineFastState.Bounded env19406 := by
  intro p hp
  have h : env19406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19248_19406 : H12AffineEnvironment.transform 11 1345 env19248 = env19406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env19248 == env19406) = true)

def env19407 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1344,262144,1024,32769,1345,4194304,65,16777216,8328,16,21331968,1345,1344,1073741824,16876544,4294967296,256,4315938986,1344,512]

theorem envBound19407 : H12AffineFastState.Bounded env19407 := by
  intro p hp
  have h : env19407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19406_19407 : H12AffineEnvironment.transform 13 1344 env19406 = env19407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env19406 == env19407) = true)

theorem identity19407 : scanCanonicalize (H12AffineFastState.compose env19407 (packedSelected [0,7,20] rootPS)) = affineNative (2^(23+1) ^^^ 98564) := by decide +kernel

theorem selectedBound19407 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env19408 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1344,262144,1024,32769,1345,4194304,65,98564,8328,16,4456708,1345,1344,1073741824,1284,4294967296,256,4299260334,1344,512]

theorem envBound19408 : H12AffineFastState.Bounded env19408 := by
  intro p hp
  have h : env19408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19407_19408 : H12AffineEnvironment.transform 23 98564 env19407 = env19408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98564 env19407 == env19408) = true)

theorem identity19408 : scanCanonicalize (H12AffineFastState.compose env19408 (packedSelected [17,21] rootPS)) = affineNative (2^(29+1) ^^^ 43049) := by decide +kernel

theorem selectedBound19408 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env19409 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1344,262144,1024,32769,1345,4194304,65,98564,8328,16,4456708,1345,1344,43049,1284,4294967296,256,4299260334,1344,512]

theorem envBound19409 : H12AffineFastState.Bounded env19409 := by
  intro p hp
  have h : env19409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19408_19409 : H12AffineEnvironment.transform 29 43049 env19408 = env19409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 43049 env19408 == env19409) = true)

def env19410 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,8192,0,32768,65536,0,262144,320,32769,1,4194304,65,98564,8328,16,4456708,1,0,43049,68,4294967296,256,4299260334,0,512]

theorem envBound19410 : H12AffineFastState.Bounded env19410 := by
  intro p hp
  have h : env19410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19409_19410 : H12AffineEnvironment.transform 9 320 env19409 = env19410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env19409 == env19410) = true)

theorem identity19410 : scanCanonicalize (H12AffineFastState.compose env19410 (packedSelected [1,3,5,8,10] rootPS)) = affineNative (2^(17+1) ^^^ 109047) := by decide +kernel

theorem selectedBound19410 : packedSelected [1,3,5,8,10] rootPS < 2^1333 := by decide +kernel

def env19411 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,8192,0,32768,65536,0,109047,320,32769,1,4194304,65,98564,8328,16,4303091,1,0,43049,68,4294967296,256,4299260334,0,512]

theorem envBound19411 : H12AffineFastState.Bounded env19411 := by
  intro p hp
  have h : env19411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19410_19411 : H12AffineEnvironment.transform 17 109047 env19410 = env19411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 109047 env19410 == env19411) = true)

theorem identity19411 : scanCanonicalize (H12AffineFastState.compose env19411 (packedSelected [5,8,12,13] rootPS)) = affineNative (2^(21+1) ^^^ 41892) := by decide +kernel

theorem selectedBound19411 : packedSelected [5,8,12,13] rootPS < 2^1333 := by decide +kernel

def env19412 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,8192,0,32768,65536,0,109047,320,32769,1,41892,65,98564,8328,16,68439,1,0,43049,68,4294967296,256,4295041546,0,512]

theorem envBound19412 : H12AffineFastState.Bounded env19412 := by
  intro p hp
  have h : env19412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19411_19412 : H12AffineEnvironment.transform 21 41892 env19411 = env19412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41892 env19411 == env19412) = true)

theorem identity19412 : scanCanonicalize (H12AffineFastState.compose env19412 (packedSelected [15] rootPS)) = affineNative (2^(31+1) ^^^ 8613) := by decide +kernel

theorem selectedBound19412 : packedSelected [15] rootPS < 2^1333 := by decide +kernel

def env19413 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,8192,0,32768,65536,0,109047,320,32769,1,41892,65,98564,8328,16,68439,1,0,43049,68,8613,256,66479,0,512]

theorem envBound19413 : H12AffineFastState.Bounded env19413 := by
  intro p hp
  have h : env19413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19412_19413 : H12AffineEnvironment.transform 31 8613 env19412 = env19413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 8613 env19412 == env19413) = true)

def env19414 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,1,8192,0,32768,65536,0,108967,272,32769,1,41892,17,98564,8328,16,68359,1,0,43049,20,8613,256,66479,0,512]

theorem envBound19414 : H12AffineFastState.Bounded env19414 := by
  intro p hp
  have h : env19414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19413_19414 : H12AffineEnvironment.transform 5 16 env19413 = env19414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19413 == env19414) = true)

theorem identity19414 : scanCanonicalize (H12AffineFastState.compose env19414 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 41514) := by decide +kernel

theorem selectedBound19414 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19415 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,1,8192,0,32768,41514,0,2957,272,32769,1,41892,17,9006,8328,16,43309,1,0,43049,20,8613,256,41349,0,512]

theorem envBound19415 : H12AffineFastState.Bounded env19415 := by
  intro p hp
  have h : env19415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19414_19415 : H12AffineEnvironment.transform 15 41514 env19414 = env19415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41514 env19414 == env19415) = true)

theorem identity19415 : scanCanonicalize (H12AffineFastState.compose env19415 (packedSelected [5] rootPS)) = affineNative (2^(14+1) ^^^ 8492) := by decide +kernel

theorem selectedBound19415 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env19416 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,1,8192,0,8492,774,0,2957,272,8493,1,648,17,9006,8328,16,2049,1,0,2309,20,8613,256,169,0,512]

theorem envBound19416 : H12AffineFastState.Bounded env19416 := by
  intro p hp
  have h : env19416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19415_19416 : H12AffineEnvironment.transform 14 8492 env19415 = env19416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8492 env19415 == env19416) = true)

theorem identity19416 : scanCanonicalize (H12AffineFastState.compose env19416 (packedSelected [8] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound19416 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env19417 : List Nat := [2,4,8,16,32,16,128,256,137,272,2048,1,8192,0,8492,399,0,2308,272,8493,1,1,17,8615,8328,16,2049,1,0,2309,20,8613,256,169,0,137]

theorem envBound19417 : H12AffineFastState.Bounded env19417 := by
  intro p hp
  have h : env19417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19416_19417 : H12AffineEnvironment.transform 8 137 env19416 = env19417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env19416 == env19417) = true)

def env19418 : List Nat := [2,4,8,16,0,16,128,256,137,272,2048,1,8192,0,8460,399,0,2308,272,8461,1,1,17,8583,8328,16,2049,1,0,2309,20,8581,256,137,0,137]

theorem envBound19418 : H12AffineFastState.Bounded env19418 := by
  intro p hp
  have h : env19418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19417_19418 : H12AffineEnvironment.transform 4 0 env19417 = env19418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19417 == env19418) = true)

theorem identity19418 : scanCanonicalize (H12AffineFastState.compose env19418 (packedSelected [0,4] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound19418 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env19419 : List Nat := [2,4,8,16,0,16,128,256,137,272,2048,1,268,0,0,399,0,2308,272,1,1,1,17,139,388,16,2049,1,0,2309,20,137,256,137,0,137]

theorem envBound19419 : H12AffineFastState.Bounded env19419 := by
  intro p hp
  have h : env19419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19418_19419 : H12AffineEnvironment.transform 12 268 env19418 = env19419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env19418 == env19419) = true)

theorem identity19419 : scanCanonicalize (H12AffineFastState.compose env19419 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound19419 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19420 : List Nat := [2,4,8,16,0,16,128,20,137,4,2048,1,24,0,0,155,0,2064,4,1,1,1,17,139,144,16,2049,1,0,2065,20,137,20,137,0,137]

theorem envBound19420 : H12AffineFastState.Bounded env19420 := by
  intro p hp
  have h : env19420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19419_19420 : H12AffineEnvironment.transform 7 20 env19419 = env19420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env19419 == env19420) = true)

def env19421 : List Nat := [2,4,8,16,0,16,128,20,137,4,0,1,24,0,0,155,0,16,4,1,1,1,17,139,144,16,1,1,0,17,20,137,20,137,0,137]

theorem envBound19421 : H12AffineFastState.Bounded env19421 := by
  intro p hp
  have h : env19421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19420_19421 : H12AffineEnvironment.transform 10 0 env19420 = env19421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env19420 == env19421) = true)

def leafEnv19421 : List Nat := [2,4,8,16,0,16,128,20,137,4,0,1,24,0,0,155,0,16,4,1,1,1,17,139,21,144,1,16,1,1,0,17,20,137,20,137,5,18,0,137,0,1,1]

def active19421 : List Nat := [0,1,2,3,6]

def tree19421 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19421 : H12WitnessSearch.Good tree19421 := H12GlobalWitnessIndex.good

theorem leafIdentity19421 : H12AffineFastState.composeSystem env19421 rootObs = leafEnv19421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19421 rootObs == leafEnv19421) = true)

theorem terminalChecked19421 : H12PackedTerminal.terminalCheckFast leafEnv19421 active19421 tree19421 = true := by decide +kernel

def env19422 : List Nat := [2,4,8,16,0,16,128,20,137,4,1,1,24,0,0,155,0,17,4,1,1,1,17,139,144,16,0,1,0,16,20,137,20,137,0,137]

theorem envBound19422 : H12AffineFastState.Bounded env19422 := by
  intro p hp
  have h : env19422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19420_19422 : H12AffineEnvironment.transform 10 1 env19420 = env19422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env19420 == env19422) = true)

theorem identity19422 : scanCanonicalize (H12AffineFastState.compose env19422 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound19422 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19423 : List Nat := [2,4,8,0,0,0,128,4,137,4,1,1,8,0,0,139,0,1,4,1,1,1,1,139,128,0,0,1,0,0,4,137,4,137,0,137]

theorem envBound19423 : H12AffineFastState.Bounded env19423 := by
  intro p hp
  have h : env19423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19422_19423 : H12AffineEnvironment.transform 3 0 env19422 = env19423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env19422 == env19423) = true)

def leafEnv19423 : List Nat := [2,4,8,0,0,0,128,4,137,4,1,1,8,0,0,139,0,1,4,1,1,1,1,139,5,128,1,0,0,1,0,0,4,137,4,137,5,2,0,137,0,1,1]

def active19423 : List Nat := [0,1,2,6]

def tree19423 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19423 : H12WitnessSearch.Good tree19423 := H12GlobalWitnessIndex.good

theorem leafIdentity19423 : H12AffineFastState.composeSystem env19423 rootObs = leafEnv19423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19423 rootObs == leafEnv19423) = true)

theorem terminalChecked19423 : H12PackedTerminal.terminalCheckFast leafEnv19423 active19423 tree19423 = true := by decide +kernel

def env19424 : List Nat := [2,4,8,16,1,16,128,256,137,272,2048,1,8192,0,8461,399,0,2308,272,8460,1,1,17,8582,8328,16,2049,1,0,2309,20,8580,256,136,0,137]

theorem envBound19424 : H12AffineFastState.Bounded env19424 := by
  intro p hp
  have h : env19424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19417_19424 : H12AffineEnvironment.transform 4 1 env19417 = env19424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19417 == env19424) = true)

def env19425 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,8192,0,32768,65536,0,108966,273,32769,1,41892,16,98564,8328,16,68358,1,0,43049,21,8613,256,66479,0,512]

theorem envBound19425 : H12AffineFastState.Bounded env19425 := by
  intro p hp
  have h : env19425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19413_19425 : H12AffineEnvironment.transform 5 17 env19413 = env19425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19413 == env19425) = true)

theorem identity19425 : scanCanonicalize (H12AffineFastState.compose env19425 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 388) := by decide +kernel

theorem selectedBound19425 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19426 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,8192,0,32768,388,0,43042,273,32769,1,41892,16,32896,8328,16,2690,1,0,43049,21,8613,256,555,0,512]

theorem envBound19426 : H12AffineFastState.Bounded env19426 := by
  intro p hp
  have h : env19426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19425_19426 : H12AffineEnvironment.transform 15 388 env19425 = env19426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 388 env19425 == env19426) = true)

theorem identity19426 : scanCanonicalize (H12AffineFastState.compose env19426 (packedSelected [3] rootPS)) = affineNative (2^(14+1) ^^^ 9093) := by decide +kernel

theorem selectedBound19426 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env19427 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,8192,0,9093,388,0,2983,273,9092,1,33,16,8965,8328,16,2690,1,0,2988,21,8613,256,555,0,512]

theorem envBound19427 : H12AffineFastState.Bounded env19427 := by
  intro p hp
  have h : env19427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19426_19427 : H12AffineEnvironment.transform 14 9093 env19426 = env19427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9093 env19426 == env19427) = true)

theorem identity19427 : scanCanonicalize (H12AffineFastState.compose env19427 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound19427 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env19428 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,269,0,648,388,0,2983,273,649,1,33,16,520,389,16,2690,1,0,2988,21,168,256,555,0,512]

theorem envBound19428 : H12AffineFastState.Bounded env19428 := by
  intro p hp
  have h : env19428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19427_19428 : H12AffineEnvironment.transform 12 269 env19427 = env19428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env19427 == env19428) = true)

theorem identity19428 : scanCanonicalize (H12AffineFastState.compose env19428 (packedSelected [0,2,4,6,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound19428 : packedSelected [0,2,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env19429 : List Nat := [2,4,8,16,32,17,128,256,137,273,2048,1,269,0,1,388,0,2350,273,0,1,33,16,129,389,16,2059,1,0,2341,21,168,256,162,0,137]

theorem envBound19429 : H12AffineFastState.Bounded env19429 := by
  intro p hp
  have h : env19429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19428_19429 : H12AffineEnvironment.transform 8 137 env19428 = env19429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env19428 == env19429) = true)

theorem identity19429 : scanCanonicalize (H12AffineFastState.compose env19429 (packedSelected [2,6] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound19429 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19430 : List Nat := [2,4,2,16,32,17,128,256,131,273,2048,1,263,0,1,388,0,2340,273,0,1,33,16,129,389,16,2049,1,0,2341,21,162,256,162,0,131]

theorem envBound19430 : H12AffineFastState.Bounded env19430 := by
  intro p hp
  have h : env19430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19429_19430 : H12AffineEnvironment.transform 2 2 env19429 = env19430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env19429 == env19430) = true)

theorem identity19430 : scanCanonicalize (H12AffineFastState.compose env19430 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound19430 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19431 : List Nat := [2,4,2,16,32,17,128,21,131,4,2048,1,18,0,1,145,0,2097,4,0,1,33,16,129,144,16,2049,1,0,2096,21,162,21,162,0,131]

theorem envBound19431 : H12AffineFastState.Bounded env19431 := by
  intro p hp
  have h : env19431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19430_19431 : H12AffineEnvironment.transform 7 21 env19430 = env19431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env19430 == env19431) = true)

def env19432 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,0,8192,1,32768,65536,1,262144,321,32769,0,4194304,65,98564,8328,16,4456708,0,1,43049,69,4294967296,256,4299260334,1,512]

theorem envBound19432 : H12AffineFastState.Bounded env19432 := by
  intro p hp
  have h : env19432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19409_19432 : H12AffineEnvironment.transform 9 321 env19409 = env19432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env19409 == env19432) = true)

theorem identity19432 : scanCanonicalize (H12AffineFastState.compose env19432 (packedSelected [1,3,5,8,10] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound19432 : packedSelected [1,3,5,8,10] rootPS < 2^1333 := by decide +kernel

def env19433 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,0,8192,1,80,65536,1,262144,321,81,0,4194304,65,65876,8328,16,4456708,0,1,10361,69,4294967296,256,4299227646,1,512]

theorem envBound19433 : H12AffineFastState.Bounded env19433 := by
  intro p hp
  have h : env19433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19432_19433 : H12AffineEnvironment.transform 14 80 env19432 = env19433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env19432 == env19433) = true)

theorem identity19433 : scanCanonicalize (H12AffineFastState.compose env19433 (packedSelected [5,8,12,13] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound19433 : packedSelected [5,8,12,13] rootPS < 2^1333 := by decide +kernel

def env19434 : List Nat := [2,4,8,16,32,64,128,256,137,321,2048,0,8192,1,80,65536,1,262144,321,81,0,4194304,65,65876,8328,16,4456708,0,1,10361,69,4294967296,256,4299227646,1,137]

theorem envBound19434 : H12AffineFastState.Bounded env19434 := by
  intro p hp
  have h : env19434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19433_19434 : H12AffineEnvironment.transform 8 137 env19433 = env19434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env19433 == env19434) = true)

theorem identity19434 : scanCanonicalize (H12AffineFastState.compose env19434 (packedSelected [15] rootPS)) = affineNative (2^(31+1) ^^^ 73850) := by decide +kernel

theorem selectedBound19434 : packedSelected [15] rootPS < 2^1333 := by decide +kernel

def env19435 : List Nat := [2,4,8,16,32,64,128,256,137,321,2048,0,8192,1,80,65536,1,262144,321,81,0,4194304,65,65876,8328,16,4456708,0,1,10361,69,73850,256,4202884,1,137]

theorem envBound19435 : H12AffineFastState.Bounded env19435 := by
  intro p hp
  have h : env19435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19434_19435 : H12AffineEnvironment.transform 31 73850 env19434 = env19435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 73850 env19434 == env19435) = true)

def env19436 : List Nat := [2,4,8,16,32,16,128,256,137,273,2048,0,8192,1,0,65536,1,262144,273,1,0,4194304,17,65796,8328,16,4456708,0,1,10281,21,73770,256,4202884,1,137]

theorem envBound19436 : H12AffineFastState.Bounded env19436 := by
  intro p hp
  have h : env19436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19435_19436 : H12AffineEnvironment.transform 5 16 env19435 = env19436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19435 == env19436) = true)

theorem identity19436 : scanCanonicalize (H12AffineFastState.compose env19436 (packedSelected [1] rootPS)) = affineNative (2^(21+1) ^^^ 272425) := by decide +kernel

theorem selectedBound19436 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19437 : List Nat := [2,4,8,16,32,16,128,256,137,273,2048,0,8192,1,0,65536,1,262144,273,1,0,272425,17,65796,8328,16,10541,0,1,10281,21,73770,256,264621,1,137]

theorem envBound19437 : H12AffineFastState.Bounded env19437 := by
  intro p hp
  have h : env19437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19436_19437 : H12AffineEnvironment.transform 21 272425 env19436 = env19437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272425 env19436 == env19437) = true)

theorem identity19437 : scanCanonicalize (H12AffineFastState.compose env19437 (packedSelected [3] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound19437 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env19438 : List Nat := [2,4,8,16,32,16,128,256,137,273,2048,0,8192,1,0,65536,1,10280,273,1,0,1,17,65796,8328,16,10541,0,1,10281,21,73770,256,8581,1,137]

theorem envBound19438 : H12AffineFastState.Bounded env19438 := by
  intro p hp
  have h : env19438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19437_19438 : H12AffineEnvironment.transform 17 10280 env19437 = env19438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env19437 == env19438) = true)

theorem identity19438 : scanCanonicalize (H12AffineFastState.compose env19438 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 300) := by decide +kernel

theorem selectedBound19438 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env19439 : List Nat := [2,4,8,16,32,16,128,256,137,273,2048,0,300,1,0,65536,1,2308,273,1,0,1,17,65796,420,16,2049,0,1,2309,21,65798,256,169,1,137]

theorem envBound19439 : H12AffineFastState.Bounded env19439 := by
  intro p hp
  have h : env19439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19438_19439 : H12AffineEnvironment.transform 12 300 env19438 = env19439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 300 env19438 == env19439) = true)

def env19440 : List Nat := [2,4,8,16,0,16,128,256,137,273,2048,0,268,1,0,65536,1,2308,273,1,0,1,17,65796,388,16,2049,0,1,2309,21,65798,256,137,1,137]

theorem envBound19440 : H12AffineFastState.Bounded env19440 := by
  intro p hp
  have h : env19440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19439_19440 : H12AffineEnvironment.transform 4 0 env19439 = env19440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19439 == env19440) = true)

def env19441 : List Nat := [2,4,8,16,1,16,128,256,137,273,2048,0,269,1,0,65536,1,2308,273,1,0,1,17,65796,389,16,2049,0,1,2309,21,65798,256,136,1,137]

theorem envBound19441 : H12AffineFastState.Bounded env19441 := by
  intro p hp
  have h : env19441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19439_19441 : H12AffineEnvironment.transform 4 1 env19439 = env19441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19439 == env19441) = true)

theorem identity19441 : scanCanonicalize (H12AffineFastState.compose env19441 (packedSelected [0,4] rootPS)) = affineNative (2^(15+1) ^^^ 399) := by decide +kernel

theorem selectedBound19441 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env19442 : List Nat := [2,4,8,16,1,16,128,256,137,273,2048,0,269,1,0,399,1,2308,273,1,0,1,17,139,389,16,2049,0,1,2309,21,137,256,136,1,137]

theorem envBound19442 : H12AffineFastState.Bounded env19442 := by
  intro p hp
  have h : env19442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19441_19442 : H12AffineEnvironment.transform 15 399 env19441 = env19442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 399 env19441 == env19442) = true)

theorem identity19442 : scanCanonicalize (H12AffineFastState.compose env19442 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound19442 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19443 : List Nat := [2,4,8,16,1,16,25,256,16,273,2048,0,269,1,0,278,1,2308,273,1,0,1,17,18,284,16,2049,0,1,2309,21,16,256,17,1,16]

theorem envBound19443 : H12AffineFastState.Bounded env19443 := by
  intro p hp
  have h : env19443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19442_19443 : H12AffineEnvironment.transform 6 25 env19442 = env19443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env19442 == env19443) = true)

def env19444 : List Nat := [2,4,8,16,1,16,25,256,16,273,0,0,269,1,0,278,1,260,273,1,0,1,17,18,284,16,1,0,1,261,21,16,256,17,1,16]

theorem envBound19444 : H12AffineFastState.Bounded env19444 := by
  intro p hp
  have h : env19444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19443_19444 : H12AffineEnvironment.transform 10 0 env19443 = env19444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env19443 == env19444) = true)

theorem identity19444 : scanCanonicalize (H12AffineFastState.compose env19444 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound19444 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19445 : List Nat := [2,4,8,16,1,16,25,4,16,21,0,0,9,1,0,18,1,0,21,1,0,1,17,18,24,16,1,0,1,1,21,16,4,17,1,16]

theorem envBound19445 : H12AffineFastState.Bounded env19445 := by
  intro p hp
  have h : env19445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19444_19445 : H12AffineEnvironment.transform 7 4 env19444 = env19445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env19444 == env19445) = true)

def leafEnv19445 : List Nat := [2,4,8,16,1,16,25,4,16,21,0,0,9,1,0,18,1,0,21,1,0,1,17,18,20,24,1,16,1,0,1,1,21,16,4,17,5,2,1,16,0,0,1]

def active19445 : List Nat := [0,1,2,3]

def tree19445 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19445 : H12WitnessSearch.Good tree19445 := H12GlobalWitnessIndex.good

theorem leafIdentity19445 : H12AffineFastState.composeSystem env19445 rootObs = leafEnv19445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19445 rootObs == leafEnv19445) = true)

theorem terminalChecked19445 : H12PackedTerminal.terminalCheckFast leafEnv19445 active19445 tree19445 = true := by decide +kernel

def env19446 : List Nat := [2,4,8,16,1,16,25,256,16,273,1,0,269,1,0,278,1,261,273,1,0,1,17,18,284,16,0,0,1,260,21,16,256,17,1,16]

theorem envBound19446 : H12AffineFastState.Bounded env19446 := by
  intro p hp
  have h : env19446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19443_19446 : H12AffineEnvironment.transform 10 1 env19443 = env19446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env19443 == env19446) = true)

def leafEnv19446 : List Nat := [2,4,8,16,1,16,25,256,16,273,1,0,269,1,0,278,1,261,273,1,0,1,17,18,20,284,1,16,0,0,1,260,21,16,256,17,5,262,1,16,0,0,1]

def active19446 : List Nat := [0,1,2,3,7]

def tree19446 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19446 : H12WitnessSearch.Good tree19446 := H12GlobalWitnessIndex.good

theorem leafIdentity19446 : H12AffineFastState.composeSystem env19446 rootObs = leafEnv19446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19446 rootObs == leafEnv19446) = true)

theorem terminalChecked19446 : H12PackedTerminal.terminalCheckFast leafEnv19446 active19446 tree19446 = true := by decide +kernel

def env19447 : List Nat := [2,4,8,16,32,17,128,256,137,272,2048,0,8192,1,1,65536,1,262144,272,0,0,4194304,16,65797,8328,16,4456708,0,1,10280,20,73771,256,4202884,1,137]

theorem envBound19447 : H12AffineFastState.Bounded env19447 := by
  intro p hp
  have h : env19447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19435_19447 : H12AffineEnvironment.transform 5 17 env19435 = env19447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19435 == env19447) = true)

theorem identity19447 : scanCanonicalize (H12AffineFastState.compose env19447 (packedSelected [1] rootPS)) = affineNative (2^(17+1) ^^^ 10275) := by decide +kernel

theorem selectedBound19447 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19448 : List Nat := [2,4,8,16,32,17,128,256,137,272,2048,0,8192,1,1,65536,1,10275,272,0,0,4194304,16,65797,8328,16,4204839,0,1,10280,20,73771,256,4202884,1,137]

theorem envBound19448 : H12AffineFastState.Bounded env19448 := by
  intro p hp
  have h : env19448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19447_19448 : H12AffineEnvironment.transform 17 10275 env19447 = env19448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10275 env19447 == env19448) = true)

theorem identity19448 : scanCanonicalize (H12AffineFastState.compose env19448 (packedSelected [3] rootPS)) = affineNative (2^(21+1) ^^^ 43) := by decide +kernel

theorem selectedBound19448 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env19449 : List Nat := [2,4,8,16,32,17,128,256,137,272,2048,0,8192,1,1,65536,1,10275,272,0,0,43,16,65797,8328,16,10508,0,1,10280,20,73771,256,8623,1,137]

theorem envBound19449 : H12AffineFastState.Bounded env19449 := by
  intro p hp
  have h : env19449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19448_19449 : H12AffineEnvironment.transform 21 43 env19448 = env19449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 43 env19448 == env19449) = true)

theorem identity19449 : scanCanonicalize (H12AffineFastState.compose env19449 (packedSelected [5] rootPS)) = affineNative (2^(15+1) ^^^ 388) := by decide +kernel

theorem selectedBound19449 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env19450 : List Nat := [2,4,8,16,32,17,128,256,137,272,2048,0,8192,1,1,388,1,10275,272,0,0,43,16,129,8328,16,10508,0,1,10280,20,8623,256,8623,1,137]

theorem envBound19450 : H12AffineFastState.Bounded env19450 := by
  intro p hp
  have h : env19450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19449_19450 : H12AffineEnvironment.transform 15 388 env19449 = env19450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 388 env19449 == env19450) = true)

theorem identity19450 : scanCanonicalize (H12AffineFastState.compose env19450 (packedSelected [8] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound19450 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env19451 : List Nat := [2,4,8,16,32,17,128,256,137,272,2048,0,269,1,1,388,1,2350,272,0,0,43,16,129,389,16,2049,0,1,2341,20,162,256,162,1,137]

theorem envBound19451 : H12AffineFastState.Bounded env19451 := by
  intro p hp
  have h : env19451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19450_19451 : H12AffineEnvironment.transform 12 269 env19450 = env19451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env19450 == env19451) = true)

theorem identity19451 : scanCanonicalize (H12AffineFastState.compose env19451 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 31) := by decide +kernel

theorem selectedBound19451 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19452 : List Nat := [2,4,8,16,32,17,128,31,137,15,2048,0,18,1,1,155,1,2097,15,0,0,43,16,129,154,16,2049,0,1,2106,20,162,31,162,1,137]

theorem envBound19452 : H12AffineFastState.Bounded env19452 := by
  intro p hp
  have h : env19452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19451_19452 : H12AffineEnvironment.transform 7 31 env19451 = env19452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 31 env19451 == env19452) = true)

theorem identity19452 : scanCanonicalize (H12AffineFastState.compose env19452 (packedSelected [6] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound19452 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env19453 : List Nat := [2,4,3,16,32,17,128,20,130,4,2048,0,18,1,1,144,1,2097,4,0,0,32,16,129,145,16,2049,0,1,2097,20,162,20,162,1,130]

theorem envBound19453 : H12AffineFastState.Bounded env19453 := by
  intro p hp
  have h : env19453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19452_19453 : H12AffineEnvironment.transform 2 3 env19452 = env19453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env19452 == env19453) = true)

theorem identity19453 : scanCanonicalize (H12AffineFastState.compose env19453 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound19453 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env19454 : List Nat := [2,4,3,16,32,17,128,20,130,4,49,0,18,1,1,144,1,0,4,0,0,32,16,129,145,16,48,0,1,0,20,162,20,162,1,130]

theorem envBound19454 : H12AffineFastState.Bounded env19454 := by
  intro p hp
  have h : env19454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19453_19454 : H12AffineEnvironment.transform 10 49 env19453 = env19454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env19453 == env19454) = true)

theorem identity19454 : scanCanonicalize (H12AffineFastState.compose env19454 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound19454 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19455 : List Nat := [2,4,3,16,17,17,128,20,130,4,0,0,18,1,1,144,1,0,4,0,0,17,16,129,145,16,1,0,1,0,20,147,20,147,1,130]

theorem envBound19455 : H12AffineFastState.Bounded env19455 := by
  intro p hp
  have h : env19455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19454_19455 : H12AffineEnvironment.transform 4 17 env19454 = env19455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env19454 == env19455) = true)

def env19456 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,65536,1344,262144,1024,32769,1345,4194304,64,16777216,8328,17,21331968,1344,1345,1073741824,16876544,4294967296,256,4315938986,1344,512]

theorem envBound19456 : H12AffineFastState.Bounded env19456 := by
  intro p hp
  have h : env19456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19406_19456 : H12AffineEnvironment.transform 13 1345 env19406 = env19456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env19406 == env19456) = true)

theorem identity19456 : scanCanonicalize (H12AffineFastState.compose env19456 (packedSelected [0,7,20] rootPS)) = affineNative (2^(23+1) ^^^ 98645) := by decide +kernel

theorem selectedBound19456 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env19457 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,65536,1344,262144,1024,32769,1345,4194304,64,98645,8328,17,4456789,1344,1345,1073741824,1365,4294967296,256,4299260415,1344,512]

theorem envBound19457 : H12AffineFastState.Bounded env19457 := by
  intro p hp
  have h : env19457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19456_19457 : H12AffineEnvironment.transform 23 98645 env19456 = env19457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98645 env19456 == env19457) = true)

theorem identity19457 : scanCanonicalize (H12AffineFastState.compose env19457 (packedSelected [1,3,24,28] rootPS)) = affineNative (2^(29+1) ^^^ 4196693) := by decide +kernel

theorem selectedBound19457 : packedSelected [1,3,24,28] rootPS < 2^1333 := by decide +kernel

def env19458 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,65536,1344,262144,1024,32769,1345,4194304,64,98645,8328,17,4456789,1344,1345,4196693,1365,4294967296,256,4299260415,1344,512]

theorem envBound19458 : H12AffineFastState.Bounded env19458 := by
  intro p hp
  have h : env19458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19457_19458 : H12AffineEnvironment.transform 29 4196693 env19457 = env19458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4196693 env19457 == env19458) = true)

theorem identity19458 : scanCanonicalize (H12AffineFastState.compose env19458 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(31+1) ^^^ 4235425) := by decide +kernel

theorem selectedBound19458 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env19459 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,65536,1344,262144,1024,32769,1345,4194304,64,98645,8328,17,4456789,1344,1345,4196693,1365,4235425,256,74078,1344,512]

theorem envBound19459 : H12AffineFastState.Bounded env19459 := by
  intro p hp
  have h : env19459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19458_19459 : H12AffineEnvironment.transform 31 4235425 env19458 = env19459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4235425 env19458 == env19459) = true)

theorem identity19459 : scanCanonicalize (H12AffineFastState.compose env19459 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 43129) := by decide +kernel

theorem selectedBound19459 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env19460 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,65536,1344,43129,1024,32769,1345,4194304,64,98645,8328,17,4237612,1344,1345,4196693,1365,4235425,256,74078,1344,512]

theorem envBound19460 : H12AffineFastState.Bounded env19460 := by
  intro p hp
  have h : env19460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19459_19460 : H12AffineEnvironment.transform 17 43129 env19459 = env19460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43129 env19459 == env19460) = true)

theorem identity19460 : scanCanonicalize (H12AffineFastState.compose env19460 (packedSelected [13,17] rootPS)) = affineNative (2^(21+1) ^^^ 341) := by decide +kernel

theorem selectedBound19460 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env19461 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,65536,1344,43129,1024,32769,1345,341,64,98645,8328,17,43129,1344,1345,2048,1365,41460,256,74078,1344,512]

theorem envBound19461 : H12AffineFastState.Bounded env19461 := by
  intro p hp
  have h : env19461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19460_19461 : H12AffineEnvironment.transform 21 341 env19460 = env19461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 341 env19460 == env19461) = true)

theorem identity19461 : scanCanonicalize (H12AffineFastState.compose env19461 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound19461 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env19462 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1296,32768,65536,1297,43048,1024,32769,1296,260,17,98564,8328,17,43048,1297,1296,2048,1284,41381,256,73999,1297,512]

theorem envBound19462 : H12AffineFastState.Bounded env19462 := by
  intro p hp
  have h : env19462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19461_19462 : H12AffineEnvironment.transform 5 17 env19461 = env19462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19461 == env19462) = true)

theorem identity19462 : scanCanonicalize (H12AffineFastState.compose env19462 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound19462 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19463 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1296,8192,1296,32768,65536,1297,43048,1024,32769,1296,260,17,98564,8328,17,43048,1297,1296,2048,1284,41381,256,73999,1297,137]

theorem envBound19463 : H12AffineFastState.Bounded env19463 := by
  intro p hp
  have h : env19463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19462_19463 : H12AffineEnvironment.transform 8 137 env19462 = env19463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env19462 == env19463) = true)

theorem identity19463 : scanCanonicalize (H12AffineFastState.compose env19463 (packedSelected [5] rootPS)) = affineNative (2^(15+1) ^^^ 8355) := by decide +kernel

theorem selectedBound19463 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env19464 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1296,8192,1296,32768,8355,1297,43048,1024,32769,1296,260,17,41383,8328,17,43048,1297,1296,2048,1284,41381,256,428,1297,137]

theorem envBound19464 : H12AffineFastState.Bounded env19464 := by
  intro p hp
  have h : env19464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19463_19464 : H12AffineEnvironment.transform 15 8355 env19463 = env19464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8355 env19463 == env19464) = true)

theorem identity19464 : scanCanonicalize (H12AffineFastState.compose env19464 (packedSelected [1,10] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound19464 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env19465 : List Nat := [2,4,8,16,32,17,128,5,137,1024,2048,1045,8192,1045,32768,8355,1044,43048,1024,32769,1045,1,17,41122,8328,17,43048,1044,1045,2048,1025,41120,5,169,1044,137]

theorem envBound19465 : H12AffineFastState.Bounded env19465 := by
  intro p hp
  have h : env19465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19464_19465 : H12AffineEnvironment.transform 7 5 env19464 = env19465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env19464 == env19465) = true)

theorem identity19465 : scanCanonicalize (H12AffineFastState.compose env19465 (packedSelected [0,6] rootPS)) = affineNative (2^(14+1) ^^^ 2080) := by decide +kernel

theorem selectedBound19465 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env19466 : List Nat := [2,4,8,16,32,17,128,5,137,1024,2048,1045,8192,1045,2080,8355,1044,8200,1024,2081,1045,1,17,10370,8328,17,8200,1044,1045,2048,1025,10368,5,169,1044,137]

theorem envBound19466 : H12AffineFastState.Bounded env19466 := by
  intro p hp
  have h : env19466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19465_19466 : H12AffineEnvironment.transform 14 2080 env19465 = env19466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2080 env19465 == env19466) = true)

theorem identity19466 : scanCanonicalize (H12AffineFastState.compose env19466 (packedSelected [2,4] rootPS)) = affineNative (2^(12+1) ^^^ 2056) := by decide +kernel

theorem selectedBound19466 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env19467 : List Nat := [2,4,8,16,32,17,128,5,137,1024,2048,1045,2056,1045,2080,2219,1044,2048,1024,2081,1045,1,17,138,2176,17,2048,1044,1045,2048,1025,136,5,169,1044,137]

theorem envBound19467 : H12AffineFastState.Bounded env19467 := by
  intro p hp
  have h : env19467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19466_19467 : H12AffineEnvironment.transform 12 2056 env19466 = env19467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2056 env19466 == env19467) = true)

theorem identity19467 : scanCanonicalize (H12AffineFastState.compose env19467 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1212) := by decide +kernel

theorem selectedBound19467 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19468 : List Nat := [2,4,8,16,32,17,128,5,137,1024,1212,1045,1204,1045,1180,1047,1044,1212,1024,1181,1045,1,17,138,1084,17,1212,1044,1045,1212,1025,136,5,169,1044,137]

theorem envBound19468 : H12AffineFastState.Bounded env19468 := by
  intro p hp
  have h : env19468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19467_19468 : H12AffineEnvironment.transform 10 1212 env19467 = env19468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1212 env19467 == env19468) = true)

def env19469 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,4194304,147521,16777216,8328,672784,21857281,16385,676865,1073741824,16876544,4294967296,256,4315938986,1345,512]

theorem envBound19469 : H12AffineFastState.Bounded env19469 := by
  intro p hp
  have h : env19469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19245_19469 : H12AffineEnvironment.transform 26 21857281 env19245 = env19469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21857281 env19245 == env19469) = true)

def env19470 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,8388608,16777216,8328,8914001,134217728,8519744,676864,1073741824,25412672,4294967296,8536384,4315938986,164610305,512]

theorem envBound19470 : H12AffineFastState.Bounded env19470 := by
  intro p hp
  have h : env19470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans18913_19470 : H12AffineEnvironment.transform 20 4097 env18913 = env19470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env18913 == env19470) = true)

theorem identity19470 : scanCanonicalize (H12AffineFastState.compose env19470 (packedSelected [14] rootPS)) = affineNative (2^(26+1) ^^^ 21857280) := by decide +kernel

theorem selectedBound19470 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env19471 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,8388608,16777216,8328,8914001,21857280,8519744,676864,1073741824,25412672,4294967296,8536384,4315938986,8537345,512]

theorem envBound19471 : H12AffineFastState.Bounded env19471 := by
  intro p hp
  have h : env19471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19470_19471 : H12AffineEnvironment.transform 26 21857280 env19470 = env19471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21857280 env19470 == env19471) = true)

def env19472 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,147520,16777216,8328,672785,21857280,16384,676864,1073741824,16876544,4294967296,256,4315938986,1345,512]

theorem envBound19472 : H12AffineFastState.Bounded env19472 := by
  intro p hp
  have h : env19472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19471_19472 : H12AffineEnvironment.transform 22 147520 env19471 = env19472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147520 env19471 == env19472) = true)

theorem identity19472 : scanCanonicalize (H12AffineFastState.compose env19472 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(18+1) ^^^ 1024) := by decide +kernel

theorem selectedBound19472 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env19473 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4097,4194304,147520,16777216,8328,147473,21331968,16384,151552,1073741824,16876544,4294967296,256,4315938986,1345,512]

theorem envBound19473 : H12AffineFastState.Bounded env19473 := by
  intro p hp
  have h : env19473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19472_19473 : H12AffineEnvironment.transform 18 1024 env19472 = env19473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env19472 == env19473) = true)

theorem identity19473 : scanCanonicalize (H12AffineFastState.compose env19473 (packedSelected [7,20,27] rootPS)) = affineNative (2^(16+1) ^^^ 1344) := by decide +kernel

theorem selectedBound19473 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env19474 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,1024,32769,4097,4194304,17664,16777216,8328,17745,21331968,16384,21824,1073741824,16876544,4294967296,256,4315938986,1345,512]

theorem envBound19474 : H12AffineFastState.Bounded env19474 := by
  intro p hp
  have h : env19474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19473_19474 : H12AffineEnvironment.transform 16 1344 env19473 = env19474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env19473 == env19474) = true)

def env19475 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,16384,32768,65536,1344,262144,1024,32769,1345,4194304,17664,16777216,8328,17745,21331968,16384,16384,1073741824,16876544,4294967296,256,4315938986,1345,512]

theorem envBound19475 : H12AffineFastState.Bounded env19475 := by
  intro p hp
  have h : env19475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19474_19475 : H12AffineEnvironment.transform 11 1344 env19474 = env19475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env19474 == env19475) = true)

def env19476 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1344,32768,65536,1344,262144,1024,32769,1345,4194304,64,16777216,8328,17,21331968,1344,1344,1073741824,16876544,4294967296,256,4315938986,1345,512]

theorem envBound19476 : H12AffineFastState.Bounded env19476 := by
  intro p hp
  have h : env19476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19475_19476 : H12AffineEnvironment.transform 13 1344 env19475 = env19476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env19475 == env19476) = true)

theorem identity19476 : scanCanonicalize (H12AffineFastState.compose env19476 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound19476 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env19477 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,32768,65536,1296,262144,1024,32769,1297,4194304,16,16777216,8328,17,21331968,1296,1296,1073741824,16876544,4294967296,256,4315938986,1297,512]

theorem envBound19477 : H12AffineFastState.Bounded env19477 := by
  intro p hp
  have h : env19477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19476_19477 : H12AffineEnvironment.transform 5 16 env19476 = env19477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19476 == env19477) = true)

theorem identity19477 : scanCanonicalize (H12AffineFastState.compose env19477 (packedSelected [13,21] rootPS)) = affineNative (2^(31+1) ^^^ 4194440) := by decide +kernel

theorem selectedBound19477 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env19478 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,32768,65536,1296,262144,1024,32769,1297,4194304,16,16777216,8328,17,21331968,1296,1296,1073741824,16876544,4194440,256,16777250,1297,512]

theorem envBound19478 : H12AffineFastState.Bounded env19478 := by
  intro p hp
  have h : env19478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19477_19478 : H12AffineEnvironment.transform 31 4194440 env19477 = env19478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4194440 env19477 == env19478) = true)

theorem identity19478 : scanCanonicalize (H12AffineFastState.compose env19478 (packedSelected [1,3,24,28] rootPS)) = affineNative (2^(29+1) ^^^ 21071872) := by decide +kernel

theorem selectedBound19478 : packedSelected [1,3,24,28] rootPS < 2^1333 := by decide +kernel

def env19479 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,32768,65536,1296,262144,1024,32769,1297,4194304,16,16777216,8328,17,21331968,1296,1296,21071872,16876544,4194440,256,16777250,1297,512]

theorem envBound19479 : H12AffineFastState.Bounded env19479 := by
  intro p hp
  have h : env19479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19478_19479 : H12AffineEnvironment.transform 29 21071872 env19478 = env19479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 21071872 env19478 == env19479) = true)

theorem identity19479 : scanCanonicalize (H12AffineFastState.compose env19479 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(23+1) ^^^ 338220) := by decide +kernel

theorem selectedBound19479 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env19480 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,32768,65536,1296,262144,1024,32769,1297,4194304,16,338220,8328,17,4237612,1296,1296,4497708,306476,4194440,256,338190,1297,512]

theorem envBound19480 : H12AffineFastState.Bounded env19480 := by
  intro p hp
  have h : env19480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19479_19480 : H12AffineEnvironment.transform 23 338220 env19479 = env19480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 338220 env19479 == env19480) = true)

theorem identity19480 : scanCanonicalize (H12AffineFastState.compose env19480 (packedSelected [0,1,3,5,7,8,11,12,15,18] rootPS)) = affineNative (2^(21+1) ^^^ 362634) := by decide +kernel

theorem selectedBound19480 : packedSelected [0,1,3,5,7,8,11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env19481 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,32768,65536,1296,262144,1024,32769,1297,362634,16,338220,8328,17,336294,1296,1296,76198,306476,362498,256,338190,1297,512]

theorem envBound19481 : H12AffineFastState.Bounded env19481 := by
  intro p hp
  have h : env19481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19480_19481 : H12AffineEnvironment.transform 21 362634 env19480 = env19481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 362634 env19480 == env19481) = true)

theorem identity19481 : scanCanonicalize (H12AffineFastState.compose env19481 (packedSelected [1,3,5,8,13,17] rootPS)) = affineNative (2^(15+1) ^^^ 8614) := by decide +kernel

theorem selectedBound19481 : packedSelected [1,3,5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env19482 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,32768,8614,1296,262144,1024,32769,1297,305452,16,264330,8328,17,262144,1296,1296,2048,306476,305572,256,264360,1297,512]

theorem envBound19482 : H12AffineFastState.Bounded env19482 := by
  intro p hp
  have h : env19482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19481_19482 : H12AffineEnvironment.transform 15 8614 env19481 = env19482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8614 env19481 == env19482) = true)

theorem identity19482 : scanCanonicalize (H12AffineFastState.compose env19482 (packedSelected [0,7] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound19482 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env19483 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,32768,8614,1296,43048,1024,32769,1297,260,16,41122,8328,17,43048,1296,1296,2048,1284,396,256,41088,1297,512]

theorem envBound19483 : H12AffineFastState.Bounded env19483 := by
  intro p hp
  have h : env19483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19482_19483 : H12AffineEnvironment.transform 17 43048 env19482 = env19483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env19482 == env19483) = true)

theorem identity19483 : scanCanonicalize (H12AffineFastState.compose env19483 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound19483 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19484 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,8192,1296,32768,8614,1296,43048,1024,32769,1297,260,16,41122,8328,17,43048,1296,1296,2048,1284,396,256,41088,1297,137]

theorem envBound19484 : H12AffineFastState.Bounded env19484 := by
  intro p hp
  have h : env19484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19483_19484 : H12AffineEnvironment.transform 8 137 env19483 = env19484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env19483 == env19484) = true)

theorem identity19484 : scanCanonicalize (H12AffineFastState.compose env19484 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound19484 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env19485 : List Nat := [2,4,8,16,32,16,128,5,137,1024,2048,1045,8192,1045,32768,8355,1045,43048,1024,32769,1044,1,16,41122,8328,17,43048,1045,1045,2048,1025,137,5,41088,1044,137]

theorem envBound19485 : H12AffineFastState.Bounded env19485 := by
  intro p hp
  have h : env19485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19484_19485 : H12AffineEnvironment.transform 7 5 env19484 = env19485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env19484 == env19485) = true)

theorem identity19485 : scanCanonicalize (H12AffineFastState.compose env19485 (packedSelected [0,6] rootPS)) = affineNative (2^(14+1) ^^^ 2081) := by decide +kernel

theorem selectedBound19485 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env19486 : List Nat := [2,4,8,16,32,16,128,5,137,1024,2048,1045,8192,1045,2081,8355,1045,8201,1024,2080,1044,1,16,10371,8328,17,8201,1045,1045,2048,1025,137,5,10401,1044,137]

theorem envBound19486 : H12AffineFastState.Bounded env19486 := by
  intro p hp
  have h : env19486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19485_19486 : H12AffineEnvironment.transform 14 2081 env19485 = env19486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2081 env19485 == env19486) = true)

def env19487 : List Nat := [2,4,8,16,32,16,128,5,137,1024,2048,1045,2056,1045,2081,2219,1045,2049,1024,2080,1044,1,16,139,2176,17,2049,1045,1045,2048,1025,137,5,169,1044,137]

theorem envBound19487 : H12AffineFastState.Bounded env19487 := by
  intro p hp
  have h : env19487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19486_19487 : H12AffineEnvironment.transform 12 2056 env19486 = env19487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2056 env19486 == env19487) = true)

theorem identity19487 : scanCanonicalize (H12AffineFastState.compose env19487 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound19487 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19488 : List Nat := [2,4,8,16,32,16,128,5,137,1024,137,1045,129,1045,168,34,1045,136,1024,169,1044,1,16,139,9,17,136,1045,1045,137,1025,137,5,169,1044,137]

theorem envBound19488 : H12AffineFastState.Bounded env19488 := by
  intro p hp
  have h : env19488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19487_19488 : H12AffineEnvironment.transform 10 137 env19487 = env19488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env19487 == env19488) = true)

theorem identity19488 : scanCanonicalize (H12AffineFastState.compose env19488 (packedSelected [0,2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound19488 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env19489 : List Nat := [2,4,8,16,32,16,128,5,137,52,137,33,129,33,168,34,33,136,52,169,32,1,16,139,9,17,136,33,33,137,53,137,5,169,32,137]

theorem envBound19489 : H12AffineFastState.Bounded env19489 := by
  intro p hp
  have h : env19489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19488_19489 : H12AffineEnvironment.transform 9 52 env19488 = env19489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env19488 == env19489) = true)

def env19490 : List Nat := [2,4,8,16,0,16,128,5,137,20,137,1,129,1,136,2,1,136,20,137,0,1,16,139,9,17,136,1,1,137,21,137,5,137,0,137]

theorem envBound19490 : H12AffineFastState.Bounded env19490 := by
  intro p hp
  have h : env19490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19489_19490 : H12AffineEnvironment.transform 4 0 env19489 = env19490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19489 == env19490) = true)

theorem identity19490 : scanCanonicalize (H12AffineFastState.compose env19490 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound19490 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19491 : List Nat := [2,4,8,1,0,1,128,5,137,5,137,1,129,1,136,2,1,136,5,137,0,1,1,139,9,0,136,1,1,137,4,137,5,137,0,137]

theorem envBound19491 : H12AffineFastState.Bounded env19491 := by
  intro p hp
  have h : env19491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19490_19491 : H12AffineEnvironment.transform 3 1 env19490 = env19491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env19490 == env19491) = true)

def leafEnv19491 : List Nat := [2,4,8,1,0,1,128,5,137,5,137,1,129,1,136,2,1,136,5,137,0,1,1,139,5,9,1,0,136,1,1,137,4,137,5,137,5,139,0,137,0,1,1]

def active19491 : List Nat := [0,1,2,6]

def tree19491 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19491 : H12WitnessSearch.Good tree19491 := H12GlobalWitnessIndex.good

theorem leafIdentity19491 : H12AffineFastState.composeSystem env19491 rootObs = leafEnv19491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19491 rootObs == leafEnv19491) = true)

theorem terminalChecked19491 : H12PackedTerminal.terminalCheckFast leafEnv19491 active19491 tree19491 = true := by decide +kernel

def env19492 : List Nat := [2,4,8,16,1,16,128,5,137,21,137,0,129,0,137,3,0,136,21,136,1,1,16,139,9,17,136,0,0,137,20,137,5,136,1,137]

theorem envBound19492 : H12AffineFastState.Bounded env19492 := by
  intro p hp
  have h : env19492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19489_19492 : H12AffineEnvironment.transform 4 1 env19489 = env19492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19489 == env19492) = true)

theorem identity19492 : scanCanonicalize (H12AffineFastState.compose env19492 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound19492 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19493 : List Nat := [2,4,8,16,1,16,25,5,16,21,16,0,24,0,16,3,0,17,21,17,1,1,16,18,9,17,17,0,0,16,20,16,5,17,1,16]

theorem envBound19493 : H12AffineFastState.Bounded env19493 := by
  intro p hp
  have h : env19493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19492_19493 : H12AffineEnvironment.transform 6 25 env19492 = env19493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env19492 == env19493) = true)

def leafEnv19493 : List Nat := [2,4,8,16,1,16,25,5,16,21,16,0,24,0,16,3,0,17,21,17,1,1,16,18,21,9,1,17,17,0,0,16,20,16,5,17,5,19,1,16,0,0,1]

def active19493 : List Nat := [0,1,2,3]

def tree19493 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19493 : H12WitnessSearch.Good tree19493 := H12GlobalWitnessIndex.good

theorem leafIdentity19493 : H12AffineFastState.composeSystem env19493 rootObs = leafEnv19493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19493 rootObs == leafEnv19493) = true)

theorem terminalChecked19493 : H12PackedTerminal.terminalCheckFast leafEnv19493 active19493 tree19493 = true := by decide +kernel

def env19494 : List Nat := [2,4,8,16,32,16,128,5,137,1024,2048,1045,2057,1045,2081,2218,1045,2048,1024,2080,1044,1,16,138,2177,17,2048,1045,1045,2048,1025,137,5,168,1044,137]

theorem envBound19494 : H12AffineFastState.Bounded env19494 := by
  intro p hp
  have h : env19494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19486_19494 : H12AffineEnvironment.transform 12 2057 env19486 = env19494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2057 env19486 == env19494) = true)

theorem identity19494 : scanCanonicalize (H12AffineFastState.compose env19494 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1181) := by decide +kernel

theorem selectedBound19494 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19495 : List Nat := [2,4,8,16,32,16,128,5,137,1024,1181,1045,1172,1045,1212,1079,1045,1181,1024,1213,1044,1,16,138,1052,17,1181,1045,1045,1181,1025,137,5,168,1044,137]

theorem envBound19495 : H12AffineFastState.Bounded env19495 := by
  intro p hp
  have h : env19495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19494_19495 : H12AffineEnvironment.transform 10 1181 env19494 = env19495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1181 env19494 == env19495) = true)

def env19496 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1345,32768,65536,1344,262144,1024,32769,1345,4194304,65,16777216,8328,16,21331968,1345,1345,1073741824,16876544,4294967296,256,4315938986,1345,512]

theorem envBound19496 : H12AffineFastState.Bounded env19496 := by
  intro p hp
  have h : env19496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19475_19496 : H12AffineEnvironment.transform 13 1345 env19475 = env19496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env19475 == env19496) = true)

def env19497 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1297,32768,65536,1296,262144,1024,32769,1297,4194304,17,16777216,8328,16,21331968,1297,1297,1073741824,16876544,4294967296,256,4315938986,1297,512]

theorem envBound19497 : H12AffineFastState.Bounded env19497 := by
  intro p hp
  have h : env19497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19496_19497 : H12AffineEnvironment.transform 5 16 env19496 = env19497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19496 == env19497) = true)

theorem identity19497 : scanCanonicalize (H12AffineFastState.compose env19497 (packedSelected [13,21] rootPS)) = affineNative (2^(31+1) ^^^ 1073842178) := by decide +kernel

theorem selectedBound19497 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env19498 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1297,32768,65536,1296,262144,1024,32769,1297,4194304,17,16777216,8328,16,21331968,1297,1297,1073741824,16876544,1073842178,256,1094813864,1297,512]

theorem envBound19498 : H12AffineFastState.Bounded env19498 := by
  intro p hp
  have h : env19498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19497_19498 : H12AffineEnvironment.transform 31 1073842178 env19497 = env19498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1073842178 env19497 == env19498) = true)

def env19499 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,128,1297,32768,65536,1296,262144,1024,32769,1297,4194304,17,16777216,8,16,21331968,1297,1297,1073741824,16876544,1073842178,256,1094813864,1297,512]

theorem envBound19499 : H12AffineFastState.Bounded env19499 := by
  intro p hp
  have h : env19499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19498_19499 : H12AffineEnvironment.transform 12 128 env19498 = env19499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 128 env19498 == env19499) = true)

theorem identity19499 : scanCanonicalize (H12AffineFastState.compose env19499 (packedSelected [3,5,24] rootPS)) = affineNative (2^(23+1) ^^^ 4227712) := by decide +kernel

theorem selectedBound19499 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env19500 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,128,1297,32768,65536,1296,262144,1024,32769,1297,4194304,17,4227712,8,16,328320,1297,1297,1073741824,4261504,1073842178,256,1073809960,1297,512]

theorem envBound19500 : H12AffineFastState.Bounded env19500 := by
  intro p hp
  have h : env19500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19499_19500 : H12AffineEnvironment.transform 23 4227712 env19499 = env19500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4227712 env19499 == env19500) = true)

def env19501 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,128,1297,32768,65536,1296,262144,1024,32769,1297,4194304,17,4227712,8,16,328320,1297,1297,68224,4261504,33410,256,168,1297,512]

theorem envBound19501 : H12AffineFastState.Bounded env19501 := by
  intro p hp
  have h : env19501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19500_19501 : H12AffineEnvironment.transform 29 68224 env19500 = env19501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 68224 env19500 == env19501) = true)

theorem identity19501 : scanCanonicalize (H12AffineFastState.compose env19501 (packedSelected [5] rootPS)) = affineNative (2^(21+1) ^^^ 65570) := by decide +kernel

theorem selectedBound19501 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env19502 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,128,1297,32768,65536,1296,262144,1024,32769,1297,65570,17,98978,8,16,328320,1297,1297,68224,1698,33410,256,168,1297,512]

theorem envBound19502 : H12AffineFastState.Bounded env19502 := by
  intro p hp
  have h : env19502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19501_19502 : H12AffineEnvironment.transform 21 65570 env19501 = env19502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65570 env19501 == env19502) = true)

theorem identity19502 : scanCanonicalize (H12AffineFastState.compose env19502 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 35598) := by decide +kernel

theorem selectedBound19502 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env19503 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,128,1297,32768,65536,1296,35598,1024,32769,1297,65570,17,98978,8,16,100750,1297,1297,68224,1698,33410,256,168,1297,512]

theorem envBound19503 : H12AffineFastState.Bounded env19503 := by
  intro p hp
  have h : env19503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19502_19503 : H12AffineEnvironment.transform 17 35598 env19502 = env19503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35598 env19502 == env19503) = true)

theorem identity19503 : scanCanonicalize (H12AffineFastState.compose env19503 (packedSelected [0,1,3,7,8,11,12,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 423) := by decide +kernel

theorem selectedBound19503 : packedSelected [0,1,3,7,8,11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env19504 : List Nat := [2,4,8,16,32,16,128,256,423,1024,2048,1296,128,1297,32768,65536,1296,34985,1024,32769,1297,65570,17,98565,8,16,100750,1297,1297,67879,1285,33061,256,168,1297,423]

theorem envBound19504 : H12AffineFastState.Bounded env19504 := by
  intro p hp
  have h : env19504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19503_19504 : H12AffineEnvironment.transform 8 423 env19503 = env19504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 423 env19503 == env19504) = true)

theorem identity19504 : scanCanonicalize (H12AffineFastState.compose env19504 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 167) := by decide +kernel

theorem selectedBound19504 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19505 : List Nat := [2,4,8,16,32,16,128,167,0,1024,2048,1207,128,1206,32768,65536,1207,34985,1024,32769,1206,65570,17,98466,8,16,100393,1206,1206,67712,1186,32898,167,168,1206,0]

theorem envBound19505 : H12AffineFastState.Bounded env19505 := by
  intro p hp
  have h : env19505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19504_19505 : H12AffineEnvironment.transform 7 167 env19504 = env19505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 167 env19504 == env19505) = true)

def env19506 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,128,1297,32768,65536,1296,262144,1024,32769,1297,4194304,17,4227712,8,16,328320,1297,1297,68225,4261504,33411,256,169,1297,512]

theorem envBound19506 : H12AffineFastState.Bounded env19506 := by
  intro p hp
  have h : env19506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19500_19506 : H12AffineEnvironment.transform 29 68225 env19500 = env19506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 68225 env19500 == env19506) = true)

theorem identity19506 : scanCanonicalize (H12AffineFastState.compose env19506 (packedSelected [5] rootPS)) = affineNative (2^(21+1) ^^^ 66866) := by decide +kernel

theorem selectedBound19506 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env19507 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,128,1297,32768,65536,1296,262144,1024,32769,1297,66866,17,100274,8,16,328320,1297,1297,68225,946,33411,256,169,1297,512]

theorem envBound19507 : H12AffineFastState.Bounded env19507 := by
  intro p hp
  have h : env19507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19506_19507 : H12AffineEnvironment.transform 21 66866 env19506 = env19507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 66866 env19506 == env19507) = true)

theorem identity19507 : scanCanonicalize (H12AffineFastState.compose env19507 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 33951) := by decide +kernel

theorem selectedBound19507 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env19508 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,128,1297,32768,33951,1296,262144,1024,32769,1297,33197,17,813,8,16,296479,1297,1297,36382,946,33411,256,169,1297,512]

theorem envBound19508 : H12AffineFastState.Bounded env19508 := by
  intro p hp
  have h : env19508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19507_19508 : H12AffineEnvironment.transform 15 33951 env19507 = env19508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33951 env19507 == env19508) = true)

theorem identity19508 : scanCanonicalize (H12AffineFastState.compose env19508 (packedSelected [1,3,8] rootPS)) = affineNative (2^(9+1) ^^^ 695) := by decide +kernel

theorem selectedBound19508 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env19509 : List Nat := [2,4,8,16,32,16,128,256,512,695,2048,935,128,934,32768,33320,935,262144,695,32769,934,33197,17,813,8,16,295080,934,934,34985,946,33411,256,169,934,512]

theorem envBound19509 : H12AffineFastState.Bounded env19509 := by
  intro p hp
  have h : env19509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19508_19509 : H12AffineEnvironment.transform 9 695 env19508 = env19509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 695 env19508 == env19509) = true)

theorem identity19509 : scanCanonicalize (H12AffineFastState.compose env19509 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound19509 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19510 : List Nat := [2,4,8,16,32,16,128,256,1,182,2048,422,128,423,32768,32809,422,262144,182,32769,423,33197,17,300,8,16,295080,423,423,34985,435,32898,256,169,423,1]

theorem envBound19510 : H12AffineFastState.Bounded env19510 := by
  intro p hp
  have h : env19510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19509_19510 : H12AffineEnvironment.transform 8 1 env19509 = env19510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env19509 == env19510) = true)

theorem identity19510 : scanCanonicalize (H12AffineFastState.compose env19510 (packedSelected [1,10] rootPS)) = affineNative (2^(7+1) ^^^ 167) := by decide +kernel

theorem selectedBound19510 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env19511 : List Nat := [2,4,8,16,32,16,128,167,1,182,2048,1,128,0,32768,32809,1,262144,182,32769,0,32778,17,139,8,16,295080,0,0,34985,20,32898,167,169,0,1]

theorem envBound19511 : H12AffineFastState.Bounded env19511 := by
  intro p hp
  have h : env19511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19510_19511 : H12AffineEnvironment.transform 7 167 env19510 = env19511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 167 env19510 == env19511) = true)

theorem identity19511 : scanCanonicalize (H12AffineFastState.compose env19511 (packedSelected [1] rootPS)) = affineNative (2^(14+1) ^^^ 169) := by decide +kernel

theorem selectedBound19511 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19512 : List Nat := [2,4,8,16,32,16,128,167,1,182,2048,1,128,0,169,128,1,262144,182,168,0,163,17,139,8,16,262145,0,0,2048,20,43,167,169,0,1]

theorem envBound19512 : H12AffineFastState.Bounded env19512 := by
  intro p hp
  have h : env19512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19511_19512 : H12AffineEnvironment.transform 14 169 env19511 = env19512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 169 env19511 == env19512) = true)

theorem identity19512 : scanCanonicalize (H12AffineFastState.compose env19512 (packedSelected [0,2] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound19512 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env19513 : List Nat := [2,4,8,16,32,16,128,167,1,182,137,1,128,0,169,128,1,262144,182,168,0,163,17,139,8,16,262145,0,0,137,20,43,167,169,0,1]

theorem envBound19513 : H12AffineFastState.Bounded env19513 := by
  intro p hp
  have h : env19513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19512_19513 : H12AffineEnvironment.transform 10 137 env19512 = env19513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env19512 == env19513) = true)

theorem identity19513 : scanCanonicalize (H12AffineFastState.compose env19513 (packedSelected [0,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound19513 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env19514 : List Nat := [2,4,8,16,32,16,8,47,1,62,1,1,8,0,33,8,1,262144,62,32,0,43,17,3,8,16,262145,0,0,1,20,43,47,33,0,1]

theorem envBound19514 : H12AffineFastState.Bounded env19514 := by
  intro p hp
  have h : env19514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19513_19514 : H12AffineEnvironment.transform 6 8 env19513 = env19514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19513 == env19514) = true)

theorem identity19514 : scanCanonicalize (H12AffineFastState.compose env19514 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound19514 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19515 : List Nat := [2,4,8,16,17,16,8,30,1,15,1,1,8,0,16,8,1,262144,15,17,0,26,17,3,8,16,262145,0,0,1,20,26,30,16,0,1]

theorem envBound19515 : H12AffineFastState.Bounded env19515 := by
  intro p hp
  have h : env19515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19514_19515 : H12AffineEnvironment.transform 4 17 env19514 = env19515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env19514 == env19515) = true)

def env19516 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,129,1297,32768,65536,1296,262144,1024,32769,1297,4194304,17,16777216,9,16,21331968,1297,1297,1073741824,16876544,1073842178,256,1094813864,1297,512]

theorem envBound19516 : H12AffineFastState.Bounded env19516 := by
  intro p hp
  have h : env19516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19498_19516 : H12AffineEnvironment.transform 12 129 env19498 = env19516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 129 env19498 == env19516) = true)

theorem identity19516 : scanCanonicalize (H12AffineFastState.compose env19516 (packedSelected [3,5,24] rootPS)) = affineNative (2^(21+1) ^^^ 66437) := by decide +kernel

theorem selectedBound19516 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env19517 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,129,1297,32768,65536,1296,262144,1024,32769,1297,66437,17,16777216,9,16,17073029,1297,1297,1073741824,16876544,1073842178,256,1090554669,1297,512]

theorem envBound19517 : H12AffineFastState.Bounded env19517 := by
  intro p hp
  have h : env19517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19516_19517 : H12AffineEnvironment.transform 21 66437 env19516 = env19517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 66437 env19516 == env19517) = true)

def env19518 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,129,1,32768,65536,0,262144,272,32769,1,66437,17,16777216,9,16,17073029,1,1,1073741824,16875792,1073842178,256,1090554669,1,512]

theorem envBound19518 : H12AffineFastState.Bounded env19518 := by
  intro p hp
  have h : env19518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19517_19518 : H12AffineEnvironment.transform 9 272 env19517 = env19518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env19517 == env19518) = true)

theorem identity19518 : scanCanonicalize (H12AffineFastState.compose env19518 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 422) := by decide +kernel

theorem selectedBound19518 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env19519 : List Nat := [2,4,8,16,32,16,128,256,422,272,2048,0,129,1,32768,65536,0,262144,272,32769,1,65571,17,16777216,9,16,17072163,1,1,1073741824,16875792,1073842178,256,1090553995,1,422]

theorem envBound19519 : H12AffineFastState.Bounded env19519 := by
  intro p hp
  have h : env19519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19518_19519 : H12AffineEnvironment.transform 8 422 env19518 = env19519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 422 env19518 == env19519) = true)

def env19520 : List Nat := [2,4,8,16,32,16,128,256,422,272,2048,0,129,1,32768,65536,0,262144,272,32769,1,65571,17,16777216,9,16,17072163,1,1,34952,16875792,65674,256,16777219,1,422]

theorem envBound19520 : H12AffineFastState.Bounded env19520 := by
  intro p hp
  have h : env19520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19519_19520 : H12AffineEnvironment.transform 29 34952 env19519 = env19520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 34952 env19519 == env19520) = true)

theorem identity19520 : scanCanonicalize (H12AffineFastState.compose env19520 (packedSelected [1] rootPS)) = affineNative (2^(23+1) ^^^ 264460) := by decide +kernel

theorem selectedBound19520 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19521 : List Nat := [2,4,8,16,32,16,128,256,422,272,2048,0,129,1,32768,65536,0,262144,272,32769,1,65571,17,264460,9,16,35119,1,1,34952,362524,65674,256,264463,1,422]

theorem envBound19521 : H12AffineFastState.Bounded env19521 := by
  intro p hp
  have h : env19521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19520_19521 : H12AffineEnvironment.transform 23 264460 env19520 = env19521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 264460 env19520 == env19521) = true)

def env19522 : List Nat := [2,4,8,16,32,16,128,256,422,272,2048,0,129,1,0,65536,0,262144,272,1,1,65571,17,264460,9,16,2351,1,1,2184,329756,65674,256,264463,1,422]

theorem envBound19522 : H12AffineFastState.Bounded env19522 := by
  intro p hp
  have h : env19522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19521_19522 : H12AffineEnvironment.transform 14 0 env19521 = env19522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env19521 == env19522) = true)

theorem identity19522 : scanCanonicalize (H12AffineFastState.compose env19522 (packedSelected [2] rootPS)) = affineNative (2^(17+1) ^^^ 68030) := by decide +kernel

theorem selectedBound19522 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19523 : List Nat := [2,4,8,16,32,16,128,256,422,272,2048,0,129,1,0,65536,0,68030,272,1,1,65571,17,65714,9,16,2351,1,1,2184,418,65674,256,65713,1,422]

theorem envBound19523 : H12AffineFastState.Bounded env19523 := by
  intro p hp
  have h : env19523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19522_19523 : H12AffineEnvironment.transform 17 68030 env19522 = env19523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 68030 env19522 == env19523) = true)

theorem identity19523 : scanCanonicalize (H12AffineFastState.compose env19523 (packedSelected [3,8,12,13,38] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound19523 : packedSelected [3,8,12,13,38] rootPS < 2^1333 := by decide +kernel

def env19524 : List Nat := [2,4,8,16,1,16,128,256,391,272,2048,0,129,1,0,65536,0,67999,272,1,1,65538,17,65683,9,16,2318,1,1,2184,387,65674,256,65680,1,391]

theorem envBound19524 : H12AffineFastState.Bounded env19524 := by
  intro p hp
  have h : env19524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19523_19524 : H12AffineEnvironment.transform 4 1 env19523 = env19524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19523 == env19524) = true)

def env19525 : List Nat := [2,4,8,16,32,16,128,256,422,272,2048,0,129,1,1,65536,0,262144,272,0,1,65571,17,264460,9,16,2350,1,1,2185,329757,65674,256,264463,1,422]

theorem envBound19525 : H12AffineFastState.Bounded env19525 := by
  intro p hp
  have h : env19525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19521_19525 : H12AffineEnvironment.transform 14 1 env19521 = env19525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env19521 == env19525) = true)

theorem identity19525 : scanCanonicalize (H12AffineFastState.compose env19525 (packedSelected [2] rootPS)) = affineNative (2^(17+1) ^^^ 2492) := by decide +kernel

theorem selectedBound19525 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19526 : List Nat := [2,4,8,16,32,16,128,256,422,272,2048,0,129,1,1,65536,0,2492,272,0,1,65571,17,176,9,16,2350,1,1,2185,65953,65674,256,179,1,422]

theorem envBound19526 : H12AffineFastState.Bounded env19526 := by
  intro p hp
  have h : env19526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19525_19526 : H12AffineEnvironment.transform 17 2492 env19525 = env19526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2492 env19525 == env19526) = true)

theorem identity19526 : scanCanonicalize (H12AffineFastState.compose env19526 (packedSelected [3,8,12,13,38] rootPS)) = affineNative (2^(15+1) ^^^ 405) := by decide +kernel

theorem selectedBound19526 : packedSelected [3,8,12,13,38] rootPS < 2^1333 := by decide +kernel

def env19527 : List Nat := [2,4,8,16,32,16,128,256,422,272,2048,0,129,1,1,405,0,2492,272,0,1,438,17,176,9,16,2350,1,1,2185,52,287,256,179,1,422]

theorem envBound19527 : H12AffineFastState.Bounded env19527 := by
  intro p hp
  have h : env19527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19526_19527 : H12AffineEnvironment.transform 15 405 env19526 = env19527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 405 env19526 == env19527) = true)

theorem identity19527 : scanCanonicalize (H12AffineFastState.compose env19527 (packedSelected [3,10] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound19527 : packedSelected [3,10] rootPS < 2^1333 := by decide +kernel

def env19528 : List Nat := [2,4,8,16,0,16,128,256,390,272,2048,0,129,1,1,405,0,2460,272,0,1,406,17,144,9,16,2318,1,1,2185,20,287,256,147,1,390]

theorem envBound19528 : H12AffineFastState.Bounded env19528 := by
  intro p hp
  have h : env19528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19527_19528 : H12AffineEnvironment.transform 4 0 env19527 = env19528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19527 == env19528) = true)

theorem identity19528 : scanCanonicalize (H12AffineFastState.compose env19528 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound19528 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env19529 : List Nat := [2,4,8,16,0,16,3,256,261,272,2048,0,2,1,1,278,0,2335,272,0,1,277,17,19,9,16,2318,1,1,2058,20,287,256,16,1,261]

theorem envBound19529 : H12AffineFastState.Bounded env19529 := by
  intro p hp
  have h : env19529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19528_19529 : H12AffineEnvironment.transform 6 3 env19528 = env19529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env19528 == env19529) = true)

def env19530 : List Nat := [2,4,8,16,32,16,128,256,422,272,2048,0,129,1,32768,65536,0,262144,272,32769,1,65571,17,16777216,9,16,17072163,1,1,34953,16875792,65675,256,16777218,1,422]

theorem envBound19530 : H12AffineFastState.Bounded env19530 := by
  intro p hp
  have h : env19530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19519_19530 : H12AffineEnvironment.transform 29 34953 env19519 = env19530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 34953 env19519 == env19530) = true)

theorem identity19530 : scanCanonicalize (H12AffineFastState.compose env19530 (packedSelected [1] rootPS)) = affineNative (2^(17+1) ^^^ 100360) := by decide +kernel

theorem selectedBound19530 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19531 : List Nat := [2,4,8,16,32,16,128,256,422,272,2048,0,129,1,32768,65536,0,100360,272,32769,1,65571,17,16777216,9,16,16844843,1,1,34953,16875792,65675,256,16777218,1,422]

theorem envBound19531 : H12AffineFastState.Bounded env19531 := by
  intro p hp
  have h : env19531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19530_19531 : H12AffineEnvironment.transform 17 100360 env19530 = env19531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 100360 env19530 == env19531) = true)

def env19532 : List Nat := [2,4,8,16,32,16,128,256,422,272,2048,0,129,1,0,65536,0,67592,272,1,1,65571,17,16777216,9,16,16844843,1,1,2185,16843024,65675,256,16777218,1,422]

theorem envBound19532 : H12AffineFastState.Bounded env19532 := by
  intro p hp
  have h : env19532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19531_19532 : H12AffineEnvironment.transform 14 0 env19531 = env19532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env19531 == env19532) = true)

theorem identity19532 : scanCanonicalize (H12AffineFastState.compose env19532 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound19532 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19533 : List Nat := [2,4,8,16,27,16,128,256,413,272,2048,0,129,1,0,65536,0,67592,272,1,1,65560,17,16777216,9,16,16844816,1,1,2185,16843024,65675,256,16777218,1,413]

theorem envBound19533 : H12AffineFastState.Bounded env19533 := by
  intro p hp
  have h : env19533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19532_19533 : H12AffineEnvironment.transform 4 27 env19532 = env19533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env19532 == env19533) = true)

theorem identity19533 : scanCanonicalize (H12AffineFastState.compose env19533 (packedSelected [3,8,12,13,38] rootPS)) = affineNative (2^(23+1) ^^^ 65823) := by decide +kernel

theorem selectedBound19533 : packedSelected [3,8,12,13,38] rootPS < 2^1333 := by decide +kernel

def env19534 : List Nat := [2,4,8,16,27,16,128,256,413,272,2048,0,129,1,0,65536,0,67592,272,1,1,65560,17,65823,9,16,2319,1,1,2185,15,65675,256,65821,1,413]

theorem envBound19534 : H12AffineFastState.Bounded env19534 := by
  intro p hp
  have h : env19534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19533_19534 : H12AffineEnvironment.transform 23 65823 env19533 = env19534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 65823 env19533 == env19534) = true)

def env19535 : List Nat := [2,4,8,16,32,16,128,256,422,272,2048,0,129,1,1,65536,0,67593,272,0,1,65571,17,16777216,9,16,16844843,1,1,2184,16843025,65675,256,16777218,1,422]

theorem envBound19535 : H12AffineFastState.Bounded env19535 := by
  intro p hp
  have h : env19535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19531_19535 : H12AffineEnvironment.transform 14 1 env19531 = env19535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env19531 == env19535) = true)

theorem identity19535 : scanCanonicalize (H12AffineFastState.compose env19535 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 57) := by decide +kernel

theorem selectedBound19535 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19536 : List Nat := [2,4,8,16,32,16,128,256,422,272,2048,0,129,1,1,57,0,2096,272,0,1,26,17,16777216,9,16,16779282,1,1,2184,16777512,178,256,16777218,1,422]

theorem envBound19536 : H12AffineFastState.Bounded env19536 := by
  intro p hp
  have h : env19536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19535_19536 : H12AffineEnvironment.transform 15 57 env19535 = env19536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 57 env19535 == env19536) = true)

theorem identity19536 : scanCanonicalize (H12AffineFastState.compose env19536 (packedSelected [3,8,12,13,38] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound19536 : packedSelected [3,8,12,13,38] rootPS < 2^1333 := by decide +kernel

def env19537 : List Nat := [2,4,8,16,1,16,128,256,391,272,2048,0,129,1,1,24,0,2065,272,0,1,26,17,16777216,9,16,16779282,1,1,2184,16777481,147,256,16777218,1,391]

theorem envBound19537 : H12AffineFastState.Bounded env19537 := by
  intro p hp
  have h : env19537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19536_19537 : H12AffineEnvironment.transform 4 1 env19536 = env19537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19536 == env19537) = true)

theorem identity19537 : scanCanonicalize (H12AffineFastState.compose env19537 (packedSelected [3,10] rootPS)) = affineNative (2^(23+1) ^^^ 285) := by decide +kernel

theorem selectedBound19537 : packedSelected [3,10] rootPS < 2^1333 := by decide +kernel

def env19538 : List Nat := [2,4,8,16,1,16,128,256,391,272,2048,0,129,1,1,24,0,2065,272,0,1,26,17,285,9,16,2319,1,1,2184,20,147,256,287,1,391]

theorem envBound19538 : H12AffineFastState.Bounded env19538 := by
  intro p hp
  have h : env19538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19537_19538 : H12AffineEnvironment.transform 23 285 env19537 = env19538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 285 env19537 == env19538) = true)

theorem identity19538 : scanCanonicalize (H12AffineFastState.compose env19538 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound19538 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env19539 : List Nat := [2,4,8,16,1,16,2,256,261,272,2048,0,3,1,1,24,0,2065,272,0,1,26,17,285,9,16,2319,1,1,2058,20,17,256,287,1,261]

theorem envBound19539 : H12AffineFastState.Bounded env19539 := by
  intro p hp
  have h : env19539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19538_19539 : H12AffineEnvironment.transform 6 2 env19538 = env19539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env19538 == env19539) = true)

def env19540 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,129,0,32768,65536,1,262144,273,32769,0,66437,17,16777216,9,16,17073029,0,0,1073741824,16875793,1073842178,256,1090554669,0,512]

theorem envBound19540 : H12AffineFastState.Bounded env19540 := by
  intro p hp
  have h : env19540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19517_19540 : H12AffineEnvironment.transform 9 273 env19517 = env19540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env19517 == env19540) = true)

theorem identity19540 : scanCanonicalize (H12AffineFastState.compose env19540 (packedSelected [5] rootPS)) = affineNative (2^(29+1) ^^^ 16812067) := by decide +kernel

theorem selectedBound19540 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env19541 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,129,0,32768,65536,1,262144,273,32769,0,66437,17,16777216,9,16,17073029,0,0,16812067,16875793,16842785,256,782,0,512]

theorem envBound19541 : H12AffineFastState.Bounded env19541 := by
  intro p hp
  have h : env19541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19540_19541 : H12AffineEnvironment.transform 29 16812067 env19540 = env19541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 16812067 env19540 == env19541) = true)

def env19542 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,129,0,32768,33288,1,262144,273,32769,0,33165,17,16777216,9,16,17073029,0,0,16812067,16778009,16810537,256,782,0,512]

theorem envBound19542 : H12AffineFastState.Bounded env19542 := by
  intro p hp
  have h : env19542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19541_19542 : H12AffineEnvironment.transform 15 33288 env19541 = env19542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33288 env19541 == env19542) = true)

theorem identity19542 : scanCanonicalize (H12AffineFastState.compose env19542 (packedSelected [1] rootPS)) = affineNative (2^(14+1) ^^^ 648) := by decide +kernel

theorem selectedBound19542 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19543 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,129,0,648,128,1,262144,273,649,0,773,17,16777216,9,16,17039629,0,0,16779947,16778009,16777377,256,782,0,512]

theorem envBound19543 : H12AffineFastState.Bounded env19543 := by
  intro p hp
  have h : env19543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19542_19543 : H12AffineEnvironment.transform 14 648 env19542 = env19543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 648 env19542 == env19543) = true)

def env19544 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,129,0,648,128,1,262144,273,649,0,773,17,160,9,16,262573,0,0,2571,953,1,256,782,0,512]

theorem envBound19544 : H12AffineFastState.Bounded env19544 := by
  intro p hp
  have h : env19544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19543_19544 : H12AffineEnvironment.transform 23 160 env19543 = env19544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 160 env19543 == env19544) = true)

theorem identity19544 : scanCanonicalize (H12AffineFastState.compose env19544 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound19544 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env19545 : List Nat := [2,4,8,16,32,16,128,256,11,273,2048,1,129,0,131,128,1,262144,273,130,0,270,17,160,9,16,262573,0,0,2048,434,1,256,261,0,11]

theorem envBound19545 : H12AffineFastState.Bounded env19545 := by
  intro p hp
  have h : env19545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19544_19545 : H12AffineEnvironment.transform 8 11 env19544 = env19545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env19544 == env19545) = true)

theorem identity19545 : scanCanonicalize (H12AffineFastState.compose env19545 (packedSelected [2,13] rootPS)) = affineNative (2^(17+1) ^^^ 2366) := by decide +kernel

theorem selectedBound19545 : packedSelected [2,13] rootPS < 2^1333 := by decide +kernel

def env19546 : List Nat := [2,4,8,16,32,16,128,256,11,273,2048,1,129,0,131,128,1,2366,273,130,0,270,17,160,9,16,2195,0,0,2048,434,1,256,261,0,11]

theorem envBound19546 : H12AffineFastState.Bounded env19546 := by
  intro p hp
  have h : env19546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19545_19546 : H12AffineEnvironment.transform 17 2366 env19545 = env19546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2366 env19545 == env19546) = true)

theorem identity19546 : scanCanonicalize (H12AffineFastState.compose env19546 (packedSelected [23,32] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound19546 : packedSelected [23,32] rootPS < 2^1333 := by decide +kernel

def env19547 : List Nat := [2,4,8,16,32,16,128,173,11,188,2048,1,129,0,131,128,1,2195,188,130,0,163,17,160,9,16,2195,0,0,2048,31,1,173,168,0,11]

theorem envBound19547 : H12AffineFastState.Bounded env19547 := by
  intro p hp
  have h : env19547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19546_19547 : H12AffineEnvironment.transform 7 173 env19546 = env19547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env19546 == env19547) = true)

theorem identity19547 : scanCanonicalize (H12AffineFastState.compose env19547 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 50) := by decide +kernel

theorem selectedBound19547 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env19548 : List Nat := [2,4,8,16,32,16,50,31,11,14,2048,1,51,0,49,50,1,2081,14,48,0,17,17,18,9,16,2081,0,0,2048,31,1,31,26,0,11]

theorem envBound19548 : H12AffineFastState.Bounded env19548 := by
  intro p hp
  have h : env19548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19547_19548 : H12AffineEnvironment.transform 6 50 env19547 = env19548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 50 env19547 == env19548) = true)

theorem identity19548 : scanCanonicalize (H12AffineFastState.compose env19548 (packedSelected [0,2,8] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound19548 : packedSelected [0,2,8] rootPS < 2^1333 := by decide +kernel

def env19549 : List Nat := [2,4,8,16,32,16,50,31,11,14,43,1,51,0,49,50,1,10,14,48,0,17,17,18,9,16,10,0,0,43,31,1,31,26,0,11]

theorem envBound19549 : H12AffineFastState.Bounded env19549 := by
  intro p hp
  have h : env19549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19548_19549 : H12AffineEnvironment.transform 10 43 env19548 = env19549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env19548 == env19549) = true)

theorem identity19549 : scanCanonicalize (H12AffineFastState.compose env19549 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound19549 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env19550 : List Nat := [2,4,8,16,26,16,8,31,11,14,17,1,9,0,11,8,1,10,14,10,0,17,17,18,9,16,10,0,0,17,31,1,31,26,0,11]

theorem envBound19550 : H12AffineFastState.Bounded env19550 := by
  intro p hp
  have h : env19550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19549_19550 : H12AffineEnvironment.transform 4 26 env19549 = env19550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env19549 == env19550) = true)

theorem identity19550 : scanCanonicalize (H12AffineFastState.compose env19550 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound19550 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19551 : List Nat := [2,4,8,0,10,0,8,15,11,14,1,1,9,0,11,8,1,10,14,10,0,1,1,2,9,0,10,0,0,1,15,1,15,10,0,11]

theorem envBound19551 : H12AffineFastState.Bounded env19551 := by
  intro p hp
  have h : env19551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19550_19551 : H12AffineEnvironment.transform 3 0 env19550 = env19551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env19550 == env19551) = true)

def env19552 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,129,0,648,128,1,262144,273,649,0,773,17,161,9,16,262572,0,0,2570,952,0,256,782,0,512]

theorem envBound19552 : H12AffineFastState.Bounded env19552 := by
  intro p hp
  have h : env19552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19543_19552 : H12AffineEnvironment.transform 23 161 env19543 = env19552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 161 env19543 == env19552) = true)

theorem identity19552 : scanCanonicalize (H12AffineFastState.compose env19552 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 166) := by decide +kernel

theorem selectedBound19552 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env19553 : List Nat := [2,4,8,16,32,16,128,166,512,183,2048,1,129,0,648,128,1,262144,183,649,0,675,17,161,9,16,262154,0,0,2570,542,0,166,680,0,512]

theorem envBound19553 : H12AffineFastState.Bounded env19553 := by
  intro p hp
  have h : env19553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19552_19553 : H12AffineEnvironment.transform 7 166 env19552 = env19553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 166 env19552 == env19553) = true)

theorem identity19553 : scanCanonicalize (H12AffineFastState.compose env19553 (packedSelected [2,8] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound19553 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env19554 : List Nat := [2,4,8,10,32,10,128,166,512,173,2048,1,129,0,648,128,1,262144,173,649,0,675,11,161,9,10,262154,0,0,2570,516,0,166,680,0,512]

theorem envBound19554 : H12AffineFastState.Bounded env19554 := by
  intro p hp
  have h : env19554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19553_19554 : H12AffineEnvironment.transform 3 10 env19553 = env19554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env19553 == env19554) = true)

theorem identity19554 : scanCanonicalize (H12AffineFastState.compose env19554 (packedSelected [2,23,32] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound19554 : packedSelected [2,23,32] rootPS < 2^1333 := by decide +kernel

def env19555 : List Nat := [2,4,3,1,32,1,128,166,512,166,2048,1,129,0,643,128,1,262144,166,642,0,675,0,161,2,1,262145,0,0,2561,516,0,166,675,0,512]

theorem envBound19555 : H12AffineFastState.Bounded env19555 := by
  intro p hp
  have h : env19555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19554_19555 : H12AffineEnvironment.transform 2 3 env19554 = env19555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env19554 == env19555) = true)

theorem identity19555 : scanCanonicalize (H12AffineFastState.compose env19555 (packedSelected [2,7] rootPS)) = affineNative (2^(8+1) ^^^ 162) := by decide +kernel

theorem selectedBound19555 : packedSelected [2,7] rootPS < 2^1333 := by decide +kernel

def env19556 : List Nat := [2,4,3,1,32,1,128,166,162,166,2048,1,129,0,33,128,1,262144,166,32,0,1,0,161,2,1,262145,0,0,2211,166,0,166,1,0,162]

theorem envBound19556 : H12AffineFastState.Bounded env19556 := by
  intro p hp
  have h : env19556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19555_19556 : H12AffineEnvironment.transform 8 162 env19555 = env19556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 162 env19555 == env19556) = true)

theorem identity19556 : scanCanonicalize (H12AffineFastState.compose env19556 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound19556 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env19557 : List Nat := [2,4,3,1,0,1,128,134,130,134,2048,1,129,0,1,128,1,262144,134,0,0,1,0,129,2,1,262145,0,0,2179,134,0,134,1,0,130]

theorem envBound19557 : H12AffineFastState.Bounded env19557 := by
  intro p hp
  have h : env19557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19556_19557 : H12AffineEnvironment.transform 4 0 env19556 = env19557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19556 == env19557) = true)

theorem identity19557 : scanCanonicalize (H12AffineFastState.compose env19557 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound19557 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19558 : List Nat := [2,4,3,1,0,1,3,5,1,5,2048,1,2,0,1,3,1,262144,5,0,0,1,0,2,2,1,262145,0,0,2048,5,0,5,1,0,1]

theorem envBound19558 : H12AffineFastState.Bounded env19558 := by
  intro p hp
  have h : env19558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19557_19558 : H12AffineEnvironment.transform 6 3 env19557 = env19558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env19557 == env19558) = true)

theorem identity19558 : scanCanonicalize (H12AffineFastState.compose env19558 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound19558 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19559 : List Nat := [2,4,3,1,0,1,3,5,1,5,1,1,2,0,1,3,1,262144,5,0,0,1,0,2,2,1,262145,0,0,1,5,0,5,1,0,1]

theorem envBound19559 : H12AffineFastState.Bounded env19559 := by
  intro p hp
  have h : env19559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19558_19559 : H12AffineEnvironment.transform 10 1 env19558 = env19559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env19558 == env19559) = true)

def env19560 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,129,0,32768,33289,1,262144,273,32769,0,33164,17,16777216,9,16,17073029,0,0,16812067,16778008,16810536,256,782,0,512]

theorem envBound19560 : H12AffineFastState.Bounded env19560 := by
  intro p hp
  have h : env19560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19541_19560 : H12AffineEnvironment.transform 15 33289 env19541 = env19560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33289 env19541 == env19560) = true)

theorem identity19560 : scanCanonicalize (H12AffineFastState.compose env19560 (packedSelected [1] rootPS)) = affineNative (2^(23+1) ^^^ 33157) := by decide +kernel

theorem selectedBound19560 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19561 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,129,0,32768,33289,1,262144,273,32769,0,33164,17,33157,9,16,262656,0,0,2470,33437,941,256,782,0,512]

theorem envBound19561 : H12AffineFastState.Bounded env19561 := by
  intro p hp
  have h : env19561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19560_19561 : H12AffineEnvironment.transform 23 33157 env19560 = env19561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 33157 env19560 == env19561) = true)

def env19562 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,129,0,648,129,1,262144,273,649,0,772,17,781,9,16,262656,0,0,2470,21,941,256,782,0,512]

theorem envBound19562 : H12AffineFastState.Bounded env19562 := by
  intro p hp
  have h : env19562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19561_19562 : H12AffineEnvironment.transform 14 648 env19561 = env19562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 648 env19561 == env19562) = true)

theorem identity19562 : scanCanonicalize (H12AffineFastState.compose env19562 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound19562 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env19563 : List Nat := [2,4,8,16,32,16,128,256,10,273,2048,1,129,0,130,129,1,262144,273,131,0,270,17,263,9,16,262154,0,0,2470,21,423,256,260,0,10]

theorem envBound19563 : H12AffineFastState.Bounded env19563 := by
  intro p hp
  have h : env19563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19562_19563 : H12AffineEnvironment.transform 8 10 env19562 = env19563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env19562 == env19563) = true)

theorem identity19563 : scanCanonicalize (H12AffineFastState.compose env19563 (packedSelected [8] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound19563 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env19564 : List Nat := [2,4,8,16,32,16,128,140,10,157,2048,1,129,0,130,129,1,262144,157,131,0,130,17,139,9,16,262154,0,0,2090,21,43,140,136,0,10]

theorem envBound19564 : H12AffineFastState.Bounded env19564 := by
  intro p hp
  have h : env19564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19563_19564 : H12AffineEnvironment.transform 7 140 env19563 = env19564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env19563 == env19564) = true)

theorem identity19564 : scanCanonicalize (H12AffineFastState.compose env19564 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound19564 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19565 : List Nat := [2,4,8,16,32,16,35,47,10,62,2048,1,34,0,33,34,1,262144,62,32,0,33,17,40,9,16,262154,0,0,2090,21,43,47,43,0,10]

theorem envBound19565 : H12AffineFastState.Bounded env19565 := by
  intro p hp
  have h : env19565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19564_19565 : H12AffineEnvironment.transform 6 35 env19564 = env19565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env19564 == env19565) = true)

theorem identity19565 : scanCanonicalize (H12AffineFastState.compose env19565 (packedSelected [0,7,11] rootPS)) = affineNative (2^(17+1) ^^^ 2059) := by decide +kernel

theorem selectedBound19565 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env19566 : List Nat := [2,4,8,16,32,16,35,47,10,62,2048,1,34,0,33,34,1,2059,62,32,0,33,17,40,9,16,2049,0,0,2090,21,43,47,43,0,10]

theorem envBound19566 : H12AffineFastState.Bounded env19566 := by
  intro p hp
  have h : env19566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19565_19566 : H12AffineEnvironment.transform 17 2059 env19565 = env19566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2059 env19565 == env19566) = true)

theorem identity19566 : scanCanonicalize (H12AffineFastState.compose env19566 (packedSelected [2,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound19566 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env19567 : List Nat := [2,4,8,16,27,16,24,20,10,5,2048,1,25,0,26,25,1,2059,5,27,0,26,17,19,9,16,2049,0,0,2065,21,16,20,16,0,10]

theorem envBound19567 : H12AffineFastState.Bounded env19567 := by
  intro p hp
  have h : env19567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19566_19567 : H12AffineEnvironment.transform 4 27 env19566 = env19567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env19566 == env19567) = true)

theorem identity19567 : scanCanonicalize (H12AffineFastState.compose env19567 (packedSelected [0,2,9] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound19567 : packedSelected [0,2,9] rootPS < 2^1333 := by decide +kernel

def env19568 : List Nat := [2,4,8,11,0,11,3,15,10,5,2048,1,2,0,1,2,1,2059,5,0,0,1,10,8,9,11,2049,0,0,2058,14,11,15,11,0,10]

theorem envBound19568 : H12AffineFastState.Bounded env19568 := by
  intro p hp
  have h : env19568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19567_19568 : H12AffineEnvironment.transform 3 11 env19567 = env19568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env19567 == env19568) = true)

def env19569 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,129,0,649,128,1,262144,273,648,0,773,17,780,9,16,262656,0,0,2470,20,941,256,782,0,512]

theorem envBound19569 : H12AffineFastState.Bounded env19569 := by
  intro p hp
  have h : env19569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19561_19569 : H12AffineEnvironment.transform 14 649 env19561 = env19569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 649 env19561 == env19569) = true)

theorem identity19569 : scanCanonicalize (H12AffineFastState.compose env19569 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 166) := by decide +kernel

theorem selectedBound19569 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env19570 : List Nat := [2,4,8,16,32,16,128,166,512,183,2048,1,129,0,649,128,1,262144,183,648,0,675,17,682,9,16,262656,0,0,2048,20,523,166,680,0,512]

theorem envBound19570 : H12AffineFastState.Bounded env19570 := by
  intro p hp
  have h : env19570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19569_19570 : H12AffineEnvironment.transform 7 166 env19569 = env19570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 166 env19569 == env19570) = true)

theorem identity19570 : scanCanonicalize (H12AffineFastState.compose env19570 (packedSelected [8] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound19570 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env19571 : List Nat := [2,4,8,16,32,16,128,166,1,183,2048,1,129,0,136,128,1,262144,183,137,0,162,17,171,9,16,262145,0,0,2048,20,10,166,169,0,1]

theorem envBound19571 : H12AffineFastState.Bounded env19571 := by
  intro p hp
  have h : env19571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19570_19571 : H12AffineEnvironment.transform 8 1 env19570 = env19571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env19570 == env19571) = true)

theorem identity19571 : scanCanonicalize (H12AffineFastState.compose env19571 (packedSelected [0,2] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound19571 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env19572 : List Nat := [2,4,8,16,32,16,128,166,1,183,137,1,129,0,136,128,1,262144,183,137,0,162,17,171,9,16,262145,0,0,137,20,10,166,169,0,1]

theorem envBound19572 : H12AffineFastState.Bounded env19572 := by
  intro p hp
  have h : env19572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19571_19572 : H12AffineEnvironment.transform 10 137 env19571 = env19572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env19571 == env19572) = true)

theorem identity19572 : scanCanonicalize (H12AffineFastState.compose env19572 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound19572 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env19573 : List Nat := [2,4,8,16,32,16,41,15,1,30,32,1,40,0,33,41,1,262144,30,32,0,11,17,2,9,16,262145,0,0,32,20,10,15,0,0,1]

theorem envBound19573 : H12AffineFastState.Bounded env19573 := by
  intro p hp
  have h : env19573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19572_19573 : H12AffineEnvironment.transform 6 41 env19572 = env19573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env19572 == env19573) = true)

theorem identity19573 : scanCanonicalize (H12AffineFastState.compose env19573 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound19573 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env19574 : List Nat := [2,4,8,16,26,16,19,15,1,30,26,1,18,0,27,19,1,262144,30,26,0,11,17,2,9,16,262145,0,0,26,20,10,15,0,0,1]

theorem envBound19574 : H12AffineFastState.Bounded env19574 := by
  intro p hp
  have h : env19574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19573_19574 : H12AffineEnvironment.transform 4 26 env19573 = env19574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env19573 == env19574) = true)

theorem identity19574 : scanCanonicalize (H12AffineFastState.compose env19574 (packedSelected [4,9] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound19574 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env19575 : List Nat := [2,4,8,10,0,10,9,15,1,4,0,1,8,0,1,9,1,262144,4,0,0,11,11,2,9,10,262145,0,0,0,14,10,15,0,0,1]

theorem envBound19575 : H12AffineFastState.Bounded env19575 := by
  intro p hp
  have h : env19575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19574_19575 : H12AffineEnvironment.transform 3 10 env19574 = env19575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env19574 == env19575) = true)

def env19576 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,32768,65536,1297,262144,1024,32769,1296,4194304,16,16777216,8328,16,21331968,1296,1296,1073741824,16876544,4294967296,256,4315938986,1296,512]

theorem envBound19576 : H12AffineFastState.Bounded env19576 := by
  intro p hp
  have h : env19576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19496_19576 : H12AffineEnvironment.transform 5 17 env19496 = env19576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19496 == env19576) = true)

theorem identity19576 : scanCanonicalize (H12AffineFastState.compose env19576 (packedSelected [13,21] rootPS)) = affineNative (2^(31+1) ^^^ 4194440) := by decide +kernel

theorem selectedBound19576 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env19577 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,32768,65536,1297,262144,1024,32769,1296,4194304,16,16777216,8328,16,21331968,1296,1296,1073741824,16876544,4194440,256,16777250,1296,512]

theorem envBound19577 : H12AffineFastState.Bounded env19577 := by
  intro p hp
  have h : env19577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19576_19577 : H12AffineEnvironment.transform 31 4194440 env19576 = env19577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4194440 env19576 == env19577) = true)

def env19578 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,128,1296,32768,65536,1297,262144,1024,32769,1296,4194304,16,16777216,8,16,21331968,1296,1296,1073741824,16876544,4194440,256,16777250,1296,512]

theorem envBound19578 : H12AffineFastState.Bounded env19578 := by
  intro p hp
  have h : env19578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19577_19578 : H12AffineEnvironment.transform 12 128 env19577 = env19578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 128 env19577 == env19578) = true)

theorem identity19578 : scanCanonicalize (H12AffineFastState.compose env19578 (packedSelected [3,5,24] rootPS)) = affineNative (2^(23+1) ^^^ 98952) := by decide +kernel

theorem selectedBound19578 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env19579 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,128,1296,32768,65536,1297,262144,1024,32769,1296,4194304,16,98952,8,16,4457096,1296,1296,1073741824,1672,4194440,256,98986,1296,512]

theorem envBound19579 : H12AffineFastState.Bounded env19579 := by
  intro p hp
  have h : env19579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19578_19579 : H12AffineEnvironment.transform 23 98952 env19578 = env19579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98952 env19578 == env19579) = true)

def env19580 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,1,128,0,32768,65536,1,262144,272,32769,0,4194304,16,98952,8,16,4457096,0,0,1073741824,920,4194440,256,98986,0,512]

theorem envBound19580 : H12AffineFastState.Bounded env19580 := by
  intro p hp
  have h : env19580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19579_19580 : H12AffineEnvironment.transform 9 272 env19579 = env19580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env19579 == env19580) = true)

def env19581 : List Nat := [2,4,8,16,0,17,128,256,512,272,2048,1,128,0,32768,65536,1,262144,272,32769,0,4194304,16,98952,8,16,4457096,0,0,1073741824,920,4194440,256,98954,0,512]

theorem envBound19581 : H12AffineFastState.Bounded env19581 := by
  intro p hp
  have h : env19581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19580_19581 : H12AffineEnvironment.transform 4 0 env19580 = env19581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19580 == env19581) = true)

theorem identity19581 : scanCanonicalize (H12AffineFastState.compose env19581 (packedSelected [1] rootPS)) = affineNative (2^(29+1) ^^^ 34816) := by decide +kernel

theorem selectedBound19581 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19582 : List Nat := [2,4,8,16,0,17,128,256,512,272,2048,1,128,0,32768,65536,1,262144,272,32769,0,4194304,16,98952,8,16,4457096,0,0,34816,920,4194440,256,98954,0,512]

theorem envBound19582 : H12AffineFastState.Bounded env19582 := by
  intro p hp
  have h : env19582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19581_19582 : H12AffineEnvironment.transform 29 34816 env19581 = env19582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 34816 env19581 == env19582) = true)

theorem identity19582 : scanCanonicalize (H12AffineFastState.compose env19582 (packedSelected [3,8,12,15,17,38,41] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound19582 : packedSelected [3,8,12,15,17,38,41] rootPS < 2^1333 := by decide +kernel

def env19583 : List Nat := [2,4,8,16,0,17,128,256,137,272,2048,1,128,0,32768,65536,1,262144,272,32769,0,4194304,16,98305,8,16,4456449,0,0,34816,273,4194440,256,98307,0,137]

theorem envBound19583 : H12AffineFastState.Bounded env19583 := by
  intro p hp
  have h : env19583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19582_19583 : H12AffineEnvironment.transform 8 137 env19582 = env19583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env19582 == env19583) = true)

theorem identity19583 : scanCanonicalize (H12AffineFastState.compose env19583 (packedSelected [8,12,38] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound19583 : packedSelected [8,12,38] rootPS < 2^1333 := by decide +kernel

def env19584 : List Nat := [2,4,8,16,0,17,128,5,137,21,2048,1,128,0,32768,65536,1,262144,21,32769,0,4194304,16,98305,8,16,4456449,0,0,34816,20,4194440,5,98307,0,137]

theorem envBound19584 : H12AffineFastState.Bounded env19584 := by
  intro p hp
  have h : env19584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19583_19584 : H12AffineEnvironment.transform 7 5 env19583 = env19584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env19583 == env19584) = true)

theorem identity19584 : scanCanonicalize (H12AffineFastState.compose env19584 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound19584 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env19585 : List Nat := [2,4,8,16,0,17,9,5,0,21,2048,1,9,0,32768,65536,1,262144,21,32769,0,4194304,16,98305,8,16,4456449,0,0,34816,20,4194305,5,98307,0,0]

theorem envBound19585 : H12AffineFastState.Bounded env19585 := by
  intro p hp
  have h : env19585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19584_19585 : H12AffineEnvironment.transform 6 9 env19584 = env19585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19584 == env19585) = true)

def env19586 : List Nat := [2,4,8,16,0,17,9,5,0,21,2048,1,9,0,0,65536,1,262144,21,1,0,4194304,16,65537,8,16,4456449,0,0,2048,20,4194305,5,65539,0,0]

theorem envBound19586 : H12AffineFastState.Bounded env19586 := by
  intro p hp
  have h : env19586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19585_19586 : H12AffineEnvironment.transform 14 0 env19585 = env19586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env19585 == env19586) = true)

theorem identity19586 : scanCanonicalize (H12AffineFastState.compose env19586 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound19586 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19587 : List Nat := [2,4,8,16,0,17,9,5,0,21,17,1,9,0,0,65536,1,262144,21,1,0,4194304,16,65537,8,16,4456449,0,0,17,20,4194305,5,65539,0,0]

theorem envBound19587 : H12AffineFastState.Bounded env19587 := by
  intro p hp
  have h : env19587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19586_19587 : H12AffineEnvironment.transform 10 17 env19586 = env19587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env19586 == env19587) = true)

theorem identity19587 : scanCanonicalize (H12AffineFastState.compose env19587 (packedSelected [2] rootPS)) = affineNative (2^(21+1) ^^^ 65554) := by decide +kernel

theorem selectedBound19587 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19588 : List Nat := [2,4,8,16,0,17,9,5,0,21,17,1,9,0,0,65536,1,262144,21,1,0,65554,16,65537,8,16,327699,0,0,17,20,65555,5,65539,0,0]

theorem envBound19588 : H12AffineFastState.Bounded env19588 := by
  intro p hp
  have h : env19588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19587_19588 : H12AffineEnvironment.transform 21 65554 env19587 = env19588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65554 env19587 == env19588) = true)

theorem identity19588 : scanCanonicalize (H12AffineFastState.compose env19588 (packedSelected [6] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound19588 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env19589 : List Nat := [2,4,8,0,0,1,9,5,0,5,1,1,9,0,0,65536,1,262144,5,1,0,65538,0,65537,8,0,327683,0,0,1,4,65539,5,65539,0,0]

theorem envBound19589 : H12AffineFastState.Bounded env19589 := by
  intro p hp
  have h : env19589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19588_19589 : H12AffineEnvironment.transform 3 0 env19588 = env19589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env19588 == env19589) = true)

def env19590 : List Nat := [2,4,8,0,0,1,9,5,0,5,1,1,9,0,0,65536,1,0,5,1,0,65538,0,65537,8,0,65539,0,0,1,4,65539,5,65539,0,0]

theorem envBound19590 : H12AffineFastState.Bounded env19590 := by
  intro p hp
  have h : env19590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19589_19590 : H12AffineEnvironment.transform 17 0 env19589 = env19590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 0 env19589 == env19590) = true)

theorem identity19590 : scanCanonicalize (H12AffineFastState.compose env19590 (packedSelected [7] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound19590 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env19591 : List Nat := [2,4,8,0,0,1,9,5,0,5,1,1,9,0,0,3,1,0,5,1,0,1,0,2,8,0,0,0,0,1,4,0,5,0,0,0]

theorem envBound19591 : H12AffineFastState.Bounded env19591 := by
  intro p hp
  have h : env19591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19590_19591 : H12AffineEnvironment.transform 15 3 env19590 = env19591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env19590 == env19591) = true)

def leafEnv19591 : List Nat := [2,4,8,0,0,1,9,5,0,5,1,1,9,0,0,3,1,0,5,1,0,1,0,2,5,8,1,0,0,0,0,1,4,0,5,0,5,3,0,0,0,0,1]

def active19591 : List Nat := [0,1,2]

def tree19591 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19591 : H12WitnessSearch.Good tree19591 := H12GlobalWitnessIndex.good

theorem leafIdentity19591 : H12AffineFastState.composeSystem env19591 rootObs = leafEnv19591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19591 rootObs == leafEnv19591) = true)

theorem terminalChecked19591 : H12PackedTerminal.terminalCheckFast leafEnv19591 active19591 tree19591 = true := by decide +kernel

def env19592 : List Nat := [2,4,8,0,0,1,9,5,0,5,1,1,9,0,0,65536,1,1,5,1,0,65538,0,65537,8,0,65538,0,0,1,4,65539,5,65539,0,0]

theorem envBound19592 : H12AffineFastState.Bounded env19592 := by
  intro p hp
  have h : env19592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19589_19592 : H12AffineEnvironment.transform 17 1 env19589 = env19592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1 env19589 == env19592) = true)

def env19593 : List Nat := [2,4,8,16,0,17,9,5,0,21,2048,1,9,0,1,65536,1,262144,21,0,0,4194304,16,65536,8,16,4456449,0,0,2049,20,4194305,5,65538,0,0]

theorem envBound19593 : H12AffineFastState.Bounded env19593 := by
  intro p hp
  have h : env19593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19585_19593 : H12AffineEnvironment.transform 14 1 env19585 = env19593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env19585 == env19593) = true)

theorem identity19593 : scanCanonicalize (H12AffineFastState.compose env19593 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 18) := by decide +kernel

theorem selectedBound19593 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19594 : List Nat := [2,4,8,16,0,17,9,5,0,21,2048,1,9,0,1,18,1,262144,21,0,0,4194304,16,18,8,16,4456449,0,0,2049,20,4194305,5,16,0,0]

theorem envBound19594 : H12AffineFastState.Bounded env19594 := by
  intro p hp
  have h : env19594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19593_19594 : H12AffineEnvironment.transform 15 18 env19593 = env19594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 18 env19593 == env19594) = true)

def env19595 : List Nat := [2,4,8,16,1,17,128,256,512,272,2048,1,128,0,32768,65536,1,262144,272,32769,0,4194304,16,98952,8,16,4457096,0,0,1073741824,920,4194440,256,98955,0,512]

theorem envBound19595 : H12AffineFastState.Bounded env19595 := by
  intro p hp
  have h : env19595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19580_19595 : H12AffineEnvironment.transform 4 1 env19580 = env19595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19580 == env19595) = true)

theorem identity19595 : scanCanonicalize (H12AffineFastState.compose env19595 (packedSelected [1] rootPS)) = affineNative (2^(29+1) ^^^ 35725) := by decide +kernel

theorem selectedBound19595 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19596 : List Nat := [2,4,8,16,1,17,128,256,512,272,2048,1,128,0,32768,65536,1,262144,272,32769,0,4194304,16,98952,8,16,4457096,0,0,35725,920,4194440,256,98955,0,512]

theorem envBound19596 : H12AffineFastState.Bounded env19596 := by
  intro p hp
  have h : env19596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19595_19596 : H12AffineEnvironment.transform 29 35725 env19595 = env19596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 35725 env19595 == env19596) = true)

theorem identity19596 : scanCanonicalize (H12AffineFastState.compose env19596 (packedSelected [3,8,12,15,17,38,41] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound19596 : packedSelected [3,8,12,15,17,38,41] rootPS < 2^1333 := by decide +kernel

def env19597 : List Nat := [2,4,8,16,1,17,128,256,137,272,2048,1,128,0,32768,65536,1,262144,272,32769,0,4194304,16,98305,8,16,4456449,0,0,35076,273,4194440,256,98306,0,137]

theorem envBound19597 : H12AffineFastState.Bounded env19597 := by
  intro p hp
  have h : env19597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19596_19597 : H12AffineEnvironment.transform 8 137 env19596 = env19597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env19596 == env19597) = true)

theorem identity19597 : scanCanonicalize (H12AffineFastState.compose env19597 (packedSelected [8,12,38] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound19597 : packedSelected [8,12,38] rootPS < 2^1333 := by decide +kernel

def env19598 : List Nat := [2,4,8,16,1,17,128,5,137,21,2048,1,128,0,32768,65536,1,262144,21,32769,0,4194304,16,98305,8,16,4456449,0,0,34817,20,4194440,5,98306,0,137]

theorem envBound19598 : H12AffineFastState.Bounded env19598 := by
  intro p hp
  have h : env19598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19597_19598 : H12AffineEnvironment.transform 7 5 env19597 = env19598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env19597 == env19598) = true)

theorem identity19598 : scanCanonicalize (H12AffineFastState.compose env19598 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound19598 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env19599 : List Nat := [2,4,8,16,1,17,9,5,0,21,2048,1,9,0,32768,65536,1,262144,21,32769,0,4194304,16,98305,8,16,4456449,0,0,34817,20,4194305,5,98306,0,0]

theorem envBound19599 : H12AffineFastState.Bounded env19599 := by
  intro p hp
  have h : env19599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19598_19599 : H12AffineEnvironment.transform 6 9 env19598 = env19599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19598 == env19599) = true)

def env19600 : List Nat := [2,4,8,16,1,17,9,5,0,21,2048,1,9,0,0,65536,1,262144,21,1,0,4194304,16,65537,8,16,4456449,0,0,2049,20,4194305,5,65538,0,0]

theorem envBound19600 : H12AffineFastState.Bounded env19600 := by
  intro p hp
  have h : env19600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19599_19600 : H12AffineEnvironment.transform 14 0 env19599 = env19600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env19599 == env19600) = true)

theorem identity19600 : scanCanonicalize (H12AffineFastState.compose env19600 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound19600 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19601 : List Nat := [2,4,8,1,1,0,9,5,0,4,2048,1,9,0,0,65536,1,262144,4,1,0,4194304,1,65537,8,1,4456449,0,0,2049,5,4194305,5,65538,0,0]

theorem envBound19601 : H12AffineFastState.Bounded env19601 := by
  intro p hp
  have h : env19601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19600_19601 : H12AffineEnvironment.transform 3 1 env19600 = env19601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env19600 == env19601) = true)

theorem identity19601 : scanCanonicalize (H12AffineFastState.compose env19601 (packedSelected [2] rootPS)) = affineNative (2^(21+1) ^^^ 65538) := by decide +kernel

theorem selectedBound19601 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19602 : List Nat := [2,4,8,1,1,0,9,5,0,4,2048,1,9,0,0,65536,1,262144,4,1,0,65538,1,65537,8,1,327683,0,0,2049,5,65539,5,65538,0,0]

theorem envBound19602 : H12AffineFastState.Bounded env19602 := by
  intro p hp
  have h : env19602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19601_19602 : H12AffineEnvironment.transform 21 65538 env19601 = env19602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65538 env19601 == env19602) = true)

def env19603 : List Nat := [2,4,8,16,1,17,9,5,0,21,2048,1,9,0,1,65536,1,262144,21,0,0,4194304,16,65536,8,16,4456449,0,0,2048,20,4194305,5,65539,0,0]

theorem envBound19603 : H12AffineFastState.Bounded env19603 := by
  intro p hp
  have h : env19603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19599_19603 : H12AffineEnvironment.transform 14 1 env19599 = env19603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env19599 == env19603) = true)

theorem identity19603 : scanCanonicalize (H12AffineFastState.compose env19603 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 2067) := by decide +kernel

theorem selectedBound19603 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19604 : List Nat := [2,4,8,16,1,17,9,5,0,21,2048,1,9,0,1,2067,1,262144,21,0,0,4194304,16,2067,8,16,4456449,0,0,2048,20,4194305,5,2064,0,0]

theorem envBound19604 : H12AffineFastState.Bounded env19604 := by
  intro p hp
  have h : env19604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19603_19604 : H12AffineEnvironment.transform 15 2067 env19603 = env19604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2067 env19603 == env19604) = true)

theorem identity19604 : scanCanonicalize (H12AffineFastState.compose env19604 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound19604 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19605 : List Nat := [2,4,8,16,1,17,9,5,0,21,0,1,9,0,1,19,1,262144,21,0,0,4194304,16,19,8,16,4456449,0,0,0,20,4194305,5,16,0,0]

theorem envBound19605 : H12AffineFastState.Bounded env19605 := by
  intro p hp
  have h : env19605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19604_19605 : H12AffineEnvironment.transform 10 0 env19604 = env19605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env19604 == env19605) = true)

theorem identity19605 : scanCanonicalize (H12AffineFastState.compose env19605 (packedSelected [4] rootPS)) = affineNative (2^(17+1) ^^^ 0) := by decide +kernel

theorem selectedBound19605 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env19606 : List Nat := [2,4,8,16,1,17,9,5,0,21,0,1,9,0,1,19,1,0,21,0,0,4194304,16,19,8,16,4194305,0,0,0,20,4194305,5,16,0,0]

theorem envBound19606 : H12AffineFastState.Bounded env19606 := by
  intro p hp
  have h : env19606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19605_19606 : H12AffineEnvironment.transform 17 0 env19605 = env19606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 0 env19605 == env19606) = true)

def env19607 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,0,128,1,32768,65536,0,262144,273,32769,1,4194304,16,98952,8,16,4457096,1,1,1073741824,921,4194440,256,98986,1,512]

theorem envBound19607 : H12AffineFastState.Bounded env19607 := by
  intro p hp
  have h : env19607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19579_19607 : H12AffineEnvironment.transform 9 273 env19579 = env19607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env19579 == env19607) = true)

theorem identity19607 : scanCanonicalize (H12AffineFastState.compose env19607 (packedSelected [5] rootPS)) = affineNative (2^(29+1) ^^^ 4197000) := by decide +kernel

theorem selectedBound19607 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env19608 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,0,128,1,32768,65536,0,262144,273,32769,1,4194304,16,98952,8,16,4457096,1,1,4197000,921,4194440,256,98986,1,512]

theorem envBound19608 : H12AffineFastState.Bounded env19608 := by
  intro p hp
  have h : env19608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19607_19608 : H12AffineEnvironment.transform 29 4197000 env19607 = env19608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4197000 env19607 == env19608) = true)

theorem identity19608 : scanCanonicalize (H12AffineFastState.compose env19608 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 35620) := by decide +kernel

theorem selectedBound19608 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env19609 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,0,128,1,32768,65536,0,35620,273,32769,1,4194304,16,98952,8,16,4229548,1,1,4197000,921,4194440,256,98986,1,512]

theorem envBound19609 : H12AffineFastState.Bounded env19609 := by
  intro p hp
  have h : env19609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19608_19609 : H12AffineEnvironment.transform 17 35620 env19608 = env19609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35620 env19608 == env19609) = true)

theorem identity19609 : scanCanonicalize (H12AffineFastState.compose env19609 (packedSelected [0,1,3,7,8,11,12,15,18] rootPS)) = affineNative (2^(21+1) ^^^ 33197) := by decide +kernel

theorem selectedBound19609 : packedSelected [0,1,3,7,8,11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env19610 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,0,128,1,32768,65536,0,35620,273,32769,1,33197,16,98952,8,16,2049,1,1,35621,921,33061,256,98986,1,512]

theorem envBound19610 : H12AffineFastState.Bounded env19610 := by
  intro p hp
  have h : env19610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19609_19610 : H12AffineEnvironment.transform 21 33197 env19609 = env19610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33197 env19609 == env19610) = true)

theorem identity19610 : scanCanonicalize (H12AffineFastState.compose env19610 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 396) := by decide +kernel

theorem selectedBound19610 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env19611 : List Nat := [2,4,8,16,32,17,128,256,396,273,2048,0,128,1,32768,65536,0,34984,273,32769,1,33197,16,98564,8,16,2049,1,1,34985,21,33061,256,98598,1,396]

theorem envBound19611 : H12AffineFastState.Bounded env19611 := by
  intro p hp
  have h : env19611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19610_19611 : H12AffineEnvironment.transform 8 396 env19610 = env19611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 396 env19610 == env19611) = true)

theorem identity19611 : scanCanonicalize (H12AffineFastState.compose env19611 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 33030) := by decide +kernel

theorem selectedBound19611 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19612 : List Nat := [2,4,8,16,32,17,128,256,396,273,2048,0,128,1,32768,33030,0,34984,273,32769,1,33197,16,2,8,16,2049,1,1,34985,21,33061,256,32,1,396]

theorem envBound19612 : H12AffineFastState.Bounded env19612 := by
  intro p hp
  have h : env19612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19611_19612 : H12AffineEnvironment.transform 15 33030 env19611 = env19612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33030 env19611 == env19612) = true)

theorem identity19612 : scanCanonicalize (H12AffineFastState.compose env19612 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound19612 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env19613 : List Nat := [2,4,8,16,32,17,128,5,137,20,2048,0,128,1,32768,32771,0,34984,20,32769,1,32936,16,2,8,16,2049,1,1,34985,21,32800,5,32,1,137]

theorem envBound19613 : H12AffineFastState.Bounded env19613 := by
  intro p hp
  have h : env19613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19612_19613 : H12AffineEnvironment.transform 7 5 env19612 = env19613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env19612 == env19613) = true)

def env19614 : List Nat := [2,4,8,16,32,17,128,5,137,20,2048,0,128,1,2048,2051,0,168,20,2049,1,2216,16,2,8,16,2049,1,1,169,21,2080,5,32,1,137]

theorem envBound19614 : H12AffineFastState.Bounded env19614 := by
  intro p hp
  have h : env19614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19613_19614 : H12AffineEnvironment.transform 14 2048 env19613 = env19614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2048 env19613 == env19614) = true)

theorem identity19614 : scanCanonicalize (H12AffineFastState.compose env19614 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound19614 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19615 : List Nat := [2,4,8,16,32,17,128,5,137,20,16,0,128,1,16,19,0,168,20,17,1,184,16,2,8,16,17,1,1,169,21,48,5,32,1,137]

theorem envBound19615 : H12AffineFastState.Bounded env19615 := by
  intro p hp
  have h : env19615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19614_19615 : H12AffineEnvironment.transform 10 16 env19614 = env19615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env19614 == env19615) = true)

def env19616 : List Nat := [2,4,8,16,16,17,128,5,137,20,16,0,128,1,16,19,0,152,20,17,1,136,16,2,8,16,17,1,1,153,21,0,5,16,1,137]

theorem envBound19616 : H12AffineFastState.Bounded env19616 := by
  intro p hp
  have h : env19616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19615_19616 : H12AffineEnvironment.transform 4 16 env19615 = env19616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env19615 == env19616) = true)

def env19617 : List Nat := [2,4,8,0,0,1,128,5,137,4,0,0,128,1,0,3,0,136,4,1,1,136,0,2,8,0,1,1,1,137,5,0,5,0,1,137]

theorem envBound19617 : H12AffineFastState.Bounded env19617 := by
  intro p hp
  have h : env19617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19616_19617 : H12AffineEnvironment.transform 3 0 env19616 = env19617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env19616 == env19617) = true)

def env19618 : List Nat := [2,4,8,1,1,0,128,5,137,5,1,0,128,1,1,2,0,137,5,0,1,136,1,2,8,1,0,1,1,136,4,0,5,1,1,137]

theorem envBound19618 : H12AffineFastState.Bounded env19618 := by
  intro p hp
  have h : env19618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19616_19618 : H12AffineEnvironment.transform 3 1 env19616 = env19618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env19616 == env19618) = true)

theorem identity19618 : scanCanonicalize (H12AffineFastState.compose env19618 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound19618 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env19619 : List Nat := [2,4,8,1,1,0,9,5,0,5,1,0,9,1,1,2,0,0,5,0,1,1,1,2,8,1,0,1,1,1,4,0,5,1,1,0]

theorem envBound19619 : H12AffineFastState.Bounded env19619 := by
  intro p hp
  have h : env19619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19618_19619 : H12AffineEnvironment.transform 6 9 env19618 = env19619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19618 == env19619) = true)

def leafEnv19619 : List Nat := [2,4,8,1,1,0,9,5,0,5,1,0,9,1,1,2,0,0,5,0,1,1,1,2,5,8,1,1,0,1,1,1,4,0,5,1,5,2,1,0,0,1,1]

def active19619 : List Nat := [0,1,2]

def tree19619 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood19619 : H12WitnessSearch.Good tree19619 := H12GlobalWitnessIndex.good

theorem leafIdentity19619 : H12AffineFastState.composeSystem env19619 rootObs = leafEnv19619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env19619 rootObs == leafEnv19619) = true)

theorem terminalChecked19619 : H12PackedTerminal.terminalCheckFast leafEnv19619 active19619 tree19619 = true := by decide +kernel

def env19620 : List Nat := [2,4,8,16,17,17,128,5,137,20,16,0,128,1,16,19,0,153,20,17,1,137,16,2,8,16,17,1,1,152,21,1,5,17,1,137]

theorem envBound19620 : H12AffineFastState.Bounded env19620 := by
  intro p hp
  have h : env19620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19615_19620 : H12AffineEnvironment.transform 4 17 env19615 = env19620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env19615 == env19620) = true)

theorem identity19620 : scanCanonicalize (H12AffineFastState.compose env19620 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound19620 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19621 : List Nat := [2,4,8,16,17,17,25,5,16,20,16,0,25,1,16,19,0,0,20,17,1,16,16,2,8,16,17,1,1,1,21,1,5,17,1,16]

theorem envBound19621 : H12AffineFastState.Bounded env19621 := by
  intro p hp
  have h : env19621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19620_19621 : H12AffineEnvironment.transform 6 25 env19620 = env19621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env19620 == env19621) = true)

def env19622 : List Nat := [2,4,8,16,32,17,128,5,137,20,2048,0,128,1,2049,2050,0,169,20,2048,1,2217,16,2,8,16,2049,1,1,168,21,2081,5,32,1,137]

theorem envBound19622 : H12AffineFastState.Bounded env19622 := by
  intro p hp
  have h : env19622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19613_19622 : H12AffineEnvironment.transform 14 2049 env19613 = env19622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2049 env19613 == env19622) = true)

theorem identity19622 : scanCanonicalize (H12AffineFastState.compose env19622 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound19622 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19623 : List Nat := [2,4,8,16,32,17,56,5,49,20,2048,0,56,1,2049,2050,0,17,20,2048,1,2065,16,2,8,16,2049,1,1,16,21,2081,5,32,1,49]

theorem envBound19623 : H12AffineFastState.Bounded env19623 := by
  intro p hp
  have h : env19623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19622_19623 : H12AffineEnvironment.transform 6 56 env19622 = env19623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env19622 == env19623) = true)

def env19624 : List Nat := [2,4,8,16,32,17,56,5,49,20,32,0,56,1,33,34,0,17,20,32,1,49,16,2,8,16,33,1,1,16,21,1,5,32,1,49]

theorem envBound19624 : H12AffineFastState.Bounded env19624 := by
  intro p hp
  have h : env19624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19623_19624 : H12AffineEnvironment.transform 10 32 env19623 = env19624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env19623 == env19624) = true)

theorem identity19624 : scanCanonicalize (H12AffineFastState.compose env19624 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound19624 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19625 : List Nat := [2,4,8,16,1,17,25,5,16,20,1,0,25,1,0,3,0,17,20,1,1,16,16,2,8,16,0,1,1,16,21,1,5,1,1,16]

theorem envBound19625 : H12AffineFastState.Bounded env19625 := by
  intro p hp
  have h : env19625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19624_19625 : H12AffineEnvironment.transform 4 1 env19624 = env19625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19624 == env19625) = true)

def env19626 : List Nat := [2,4,8,16,32,17,56,5,49,20,33,0,56,1,32,35,0,17,20,33,1,48,16,2,8,16,32,1,1,16,21,0,5,32,1,49]

theorem envBound19626 : H12AffineFastState.Bounded env19626 := by
  intro p hp
  have h : env19626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19623_19626 : H12AffineEnvironment.transform 10 33 env19623 = env19626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env19623 == env19626) = true)

theorem identity19626 : scanCanonicalize (H12AffineFastState.compose env19626 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound19626 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19627 : List Nat := [2,4,8,16,16,17,8,5,1,20,17,0,8,1,16,19,0,17,20,17,1,0,16,2,8,16,16,1,1,16,21,0,5,16,1,1]

theorem envBound19627 : H12AffineFastState.Bounded env19627 := by
  intro p hp
  have h : env19627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19626_19627 : H12AffineEnvironment.transform 4 16 env19626 = env19627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env19626 == env19627) = true)

def env19628 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,129,1296,32768,65536,1297,262144,1024,32769,1296,4194304,16,16777216,9,16,21331968,1296,1296,1073741824,16876544,4194440,256,16777250,1296,512]

theorem envBound19628 : H12AffineFastState.Bounded env19628 := by
  intro p hp
  have h : env19628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19577_19628 : H12AffineEnvironment.transform 12 129 env19577 = env19628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 129 env19577 == env19628) = true)

theorem identity19628 : scanCanonicalize (H12AffineFastState.compose env19628 (packedSelected [3,5,24] rootPS)) = affineNative (2^(8+1) ^^^ 396) := by decide +kernel

theorem selectedBound19628 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env19629 : List Nat := [2,4,8,16,32,17,128,256,396,1024,2048,1297,129,1296,32768,65536,1297,262144,1024,32769,1296,4194304,16,16777216,9,16,21331968,1296,1296,1073741824,16876544,4194440,256,16777250,1296,396]

theorem envBound19629 : H12AffineFastState.Bounded env19629 := by
  intro p hp
  have h : env19629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19628_19629 : H12AffineEnvironment.transform 8 396 env19628 = env19629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 396 env19628 == env19629) = true)

def env19630 : List Nat := [2,4,8,16,32,17,128,256,396,1024,2048,1297,129,1296,32768,65536,1297,262144,1024,32769,1296,4194304,16,16777216,9,16,21331968,1296,1296,21071872,16876544,4194440,256,16777250,1296,396]

theorem envBound19630 : H12AffineFastState.Bounded env19630 := by
  intro p hp
  have h : env19630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19629_19630 : H12AffineEnvironment.transform 29 21071872 env19629 = env19630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 21071872 env19629 == env19630) = true)

theorem identity19630 : scanCanonicalize (H12AffineFastState.compose env19630 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(23+1) ^^^ 330157) := by decide +kernel

theorem selectedBound19630 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env19631 : List Nat := [2,4,8,16,32,17,128,256,396,1024,2048,1297,129,1296,32768,65536,1297,262144,1024,32769,1296,4194304,16,330157,9,16,4229549,1296,1296,4489645,298413,4194440,256,330127,1296,396]

end H12CloudChart2