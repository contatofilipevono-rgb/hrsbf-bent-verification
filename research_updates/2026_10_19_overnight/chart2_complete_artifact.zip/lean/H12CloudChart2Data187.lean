import H12CloudChart2Data186

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans46943_46944 : H12AffineEnvironment.transform 10 1070 env46943 = env46944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1070 env46943 == env46944) = true)

theorem identity46944 : scanCanonicalize (H12AffineFastState.compose env46944 (packedSelected [1,5,10,13] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound46944 : packedSelected [1,5,10,13] rootPS < 2^1333 := by decide +kernel

def env46945 : List Nat := [2,4,8,16,32,64,105,68,512,1024,1070,1028,73,1109,80,34,1028,75,1025,81,1029,113,17,1078,41,65,1150,1109,1108,1102,69,1092,68,64,1029,512]

theorem envBound46945 : H12AffineFastState.Bounded env46945 := by
  intro p hp
  have h : env46945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46944_46945 : H12AffineEnvironment.transform 6 105 env46944 = env46945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env46944 == env46945) = true)

theorem identity46945 : scanCanonicalize (H12AffineFastState.compose env46945 (packedSelected [1,4,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound46945 : packedSelected [1,4,7,8] rootPS < 2^1333 := by decide +kernel

def env46946 : List Nat := [2,4,8,16,32,10,35,14,512,1024,1070,1028,3,1055,26,34,1028,1,1025,27,1029,59,17,1078,41,11,1076,1055,1054,1028,15,1038,14,10,1029,512]

theorem envBound46946 : H12AffineFastState.Bounded env46946 := by
  intro p hp
  have h : env46946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46945_46946 : H12AffineEnvironment.transform 5 10 env46945 = env46946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env46945 == env46946) = true)

theorem identity46946 : scanCanonicalize (H12AffineFastState.compose env46946 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound46946 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env46947 : List Nat := [2,4,8,16,10,10,9,14,512,1024,1028,1028,3,1055,26,8,1028,1,1025,27,1029,17,17,1052,3,11,1054,1055,1054,1028,15,1038,14,10,1029,512]

theorem envBound46947 : H12AffineFastState.Bounded env46947 := by
  intro p hp
  have h : env46947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46946_46947 : H12AffineEnvironment.transform 4 10 env46946 = env46947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env46946 == env46947) = true)

theorem identity46947 : scanCanonicalize (H12AffineFastState.compose env46947 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound46947 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46948 : List Nat := [2,4,8,16,10,10,9,14,26,1024,1028,1028,3,1055,26,8,1028,1,1025,27,1029,17,17,1052,3,11,1054,1055,1054,1028,15,1038,14,10,1029,26]

theorem envBound46948 : H12AffineFastState.Bounded env46948 := by
  intro p hp
  have h : env46948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46947_46948 : H12AffineEnvironment.transform 8 26 env46947 = env46948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env46947 == env46948) = true)

theorem identity46948 : scanCanonicalize (H12AffineFastState.compose env46948 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound46948 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env46949 : List Nat := [2,4,8,11,10,10,9,14,1,1024,1028,1028,3,1028,1,8,1028,1,1025,0,1029,10,10,1031,3,11,1029,1028,1029,1028,15,1038,14,10,1029,1]

theorem envBound46949 : H12AffineFastState.Bounded env46949 := by
  intro p hp
  have h : env46949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46948_46949 : H12AffineEnvironment.transform 3 11 env46948 = env46949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env46948 == env46949) = true)

theorem identity46949 : scanCanonicalize (H12AffineFastState.compose env46949 (packedSelected [0,1] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound46949 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env46950 : List Nat := [2,4,8,11,10,10,9,14,1,4,0,0,3,0,1,8,0,1,5,0,1,10,10,3,3,11,1,0,1,0,15,10,14,10,1,1]

theorem envBound46950 : H12AffineFastState.Bounded env46950 := by
  intro p hp
  have h : env46950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46949_46950 : H12AffineEnvironment.transform 9 4 env46949 = env46950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env46949 == env46950) = true)

theorem identity46950 : scanCanonicalize (H12AffineFastState.compose env46950 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound46950 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46951 : List Nat := [2,2,8,11,10,10,9,8,1,2,0,0,3,0,1,8,0,1,3,0,1,10,10,3,3,11,1,0,1,0,9,10,8,10,1,1]

theorem envBound46951 : H12AffineFastState.Bounded env46951 := by
  intro p hp
  have h : env46951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46950_46951 : H12AffineEnvironment.transform 1 2 env46950 = env46951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env46950 == env46951) = true)

def env46952 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74863,65665,4417,13340,4097,476,74046,69648,13769,78894,4415,74814,1296,81227,8204,74799,256,8201,1345,5952]

theorem envBound46952 : H12AffineFastState.Bounded env46952 := by
  intro p hp
  have h : env46952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46925_46952 : H12AffineEnvironment.transform 17 65665 env46925 = env46952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env46925 == env46952) = true)

theorem identity46952 : scanCanonicalize (H12AffineFastState.compose env46952 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5159) := by decide +kernel

theorem selectedBound46952 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env46953 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,5159,12360,5286,4417,13340,4097,476,13593,1079,13769,8201,4415,12313,1296,10604,8204,12296,256,8201,1345,5952]

theorem envBound46953 : H12AffineFastState.Bounded env46953 := by
  intro p hp
  have h : env46953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46952_46953 : H12AffineEnvironment.transform 15 5159 env46952 = env46953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5159 env46952 == env46953) = true)

def env46954 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5384,1297,277,5159,1344,5286,4417,276,4097,476,17,1079,193,5377,4415,1297,1296,7268,5380,1280,256,5377,1345,5952]

theorem envBound46954 : H12AffineFastState.Bounded env46954 := by
  intro p hp
  have h : env46954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46953_46954 : H12AffineEnvironment.transform 12 5384 env46953 = env46954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5384 env46953 == env46954) = true)

theorem identity46954 : scanCanonicalize (H12AffineFastState.compose env46954 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound46954 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env46955 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1029,269,1297,277,34,1344,163,1348,276,1028,476,17,1079,193,260,1338,1297,1296,2145,257,1280,256,260,1345,837]

theorem envBound46955 : H12AffineFastState.Bounded env46955 := by
  intro p hp
  have h : env46955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46954_46955 : H12AffineEnvironment.transform 11 1029 env46954 = env46955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env46954 == env46955) = true)

theorem identity46955 : scanCanonicalize (H12AffineFastState.compose env46955 (packedSelected [2,5,8,10,11,20] rootPS)) = affineNative (2^(9+1) ^^^ 880) := by decide +kernel

theorem selectedBound46955 : packedSelected [2,5,8,10,11,20] rootPS < 2^1333 := by decide +kernel

def env46956 : List Nat := [2,4,8,16,32,64,128,256,512,880,2048,885,269,609,277,34,560,163,564,276,884,476,17,839,193,260,586,609,608,2145,257,624,256,260,561,837]

theorem envBound46956 : H12AffineFastState.Bounded env46956 := by
  intro p hp
  have h : env46956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46955_46956 : H12AffineEnvironment.transform 9 880 env46955 = env46956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 880 env46955 == env46956) = true)

theorem identity46956 : scanCanonicalize (H12AffineFastState.compose env46956 (packedSelected [1,2,3,4,9,10,13,17,23] rootPS)) = affineNative (2^(10+1) ^^^ 862) := by decide +kernel

theorem selectedBound46956 : packedSelected [1,2,3,4,9,10,13,17,23] rootPS < 2^1333 := by decide +kernel

def env46957 : List Nat := [2,4,8,16,32,64,128,256,512,880,862,885,269,609,277,34,560,163,564,276,884,476,17,839,193,260,586,609,608,831,257,624,256,260,561,837]

theorem envBound46957 : H12AffineFastState.Bounded env46957 := by
  intro p hp
  have h : env46957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46956_46957 : H12AffineEnvironment.transform 10 862 env46956 = env46957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 862 env46956 == env46957) = true)

theorem identity46957 : scanCanonicalize (H12AffineFastState.compose env46957 (packedSelected [1,2,3,4,5,8,9,10,11,12,15] rootPS)) = affineNative (2^(8+1) ^^^ 413) := by decide +kernel

theorem selectedBound46957 : packedSelected [1,2,3,4,5,8,9,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env46958 : List Nat := [2,4,8,16,32,64,128,256,413,237,195,232,269,508,277,34,429,163,425,276,233,476,17,218,193,260,471,508,509,162,257,493,256,260,428,216]

theorem envBound46958 : H12AffineFastState.Bounded env46958 := by
  intro p hp
  have h : env46958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46957_46958 : H12AffineEnvironment.transform 8 413 env46957 = env46958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 413 env46957 == env46958) = true)

theorem identity46958 : scanCanonicalize (H12AffineFastState.compose env46958 (packedSelected [1,2,4,5,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound46958 : packedSelected [1,2,4,5,9] rootPS < 2^1333 := by decide +kernel

def env46959 : List Nat := [2,4,8,16,32,64,9,256,276,100,74,97,269,373,277,34,292,42,288,276,96,341,17,83,72,260,350,373,372,43,257,356,256,260,293,81]

theorem envBound46959 : H12AffineFastState.Bounded env46959 := by
  intro p hp
  have h : env46959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46958_46959 : H12AffineEnvironment.transform 6 9 env46958 = env46959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env46958 == env46959) = true)

theorem identity46959 : scanCanonicalize (H12AffineFastState.compose env46959 (packedSelected [0,7,10] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound46959 : packedSelected [0,7,10] rootPS < 2^1333 := by decide +kernel

def env46960 : List Nat := [2,4,8,16,10,64,9,256,276,78,74,75,269,351,277,8,270,0,266,276,74,341,17,83,72,260,350,351,350,1,257,334,256,260,271,81]

theorem envBound46960 : H12AffineFastState.Bounded env46960 := by
  intro p hp
  have h : env46960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46959_46960 : H12AffineEnvironment.transform 4 10 env46959 = env46960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env46959 == env46960) = true)

theorem identity46960 : scanCanonicalize (H12AffineFastState.compose env46960 (packedSelected [1,2,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 95) := by decide +kernel

theorem selectedBound46960 : packedSelected [1,2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env46961 : List Nat := [2,4,8,16,10,64,9,95,75,78,74,75,82,0,74,8,81,0,85,75,74,10,17,83,72,91,1,0,1,1,94,17,95,91,80,81]

theorem envBound46961 : H12AffineFastState.Bounded env46961 := by
  intro p hp
  have h : env46961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46960_46961 : H12AffineEnvironment.transform 7 95 env46960 = env46961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 95 env46960 == env46961) = true)

theorem identity46961 : scanCanonicalize (H12AffineFastState.compose env46961 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound46961 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env46962 : List Nat := [2,4,8,16,10,16,9,15,27,30,26,27,2,0,26,8,1,0,5,27,26,10,17,3,24,11,1,0,1,1,14,17,15,11,0,1]

theorem envBound46962 : H12AffineFastState.Bounded env46962 := by
  intro p hp
  have h : env46962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46961_46962 : H12AffineEnvironment.transform 5 16 env46961 = env46962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46961 == env46962) = true)

def env46963 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5385,1297,276,5159,1345,5286,4417,277,4097,476,16,1079,192,5376,4415,1296,1296,7269,5381,1281,256,5376,1345,5952]

theorem envBound46963 : H12AffineFastState.Bounded env46963 := by
  intro p hp
  have h : env46963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46953_46963 : H12AffineEnvironment.transform 12 5385 env46953 = env46963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5385 env46953 == env46963) = true)

theorem identity46963 : scanCanonicalize (H12AffineFastState.compose env46963 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound46963 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env46964 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,4120,0,276,4406,80,4535,4417,277,4097,476,16,294,192,4113,4415,1,1,6516,4116,16,256,4113,80,4689]

theorem envBound46964 : H12AffineFastState.Bounded env46964 := by
  intro p hp
  have h : env46964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46963_46964 : H12AffineEnvironment.transform 9 273 env46963 = env46964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env46963 == env46964) = true)

theorem identity46964 : scanCanonicalize (H12AffineFastState.compose env46964 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound46964 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env46965 : List Nat := [2,4,8,16,32,64,128,172,512,189,2048,4096,4120,0,184,4250,80,4123,4333,185,4097,112,16,138,192,4113,4243,1,1,6360,4116,16,172,4113,80,4689]

theorem envBound46965 : H12AffineFastState.Bounded env46965 := by
  intro p hp
  have h : env46965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46964_46965 : H12AffineEnvironment.transform 7 172 env46964 = env46965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env46964 == env46965) = true)

theorem identity46965 : scanCanonicalize (H12AffineFastState.compose env46965 (packedSelected [0,2,3,4,5,7,9,10,11,12,15,17,18] rootPS)) = affineNative (2^(11+1) ^^^ 2634) := by decide +kernel

theorem selectedBound46965 : packedSelected [0,2,3,4,5,7,9,10,11,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env46966 : List Nat := [2,4,8,16,32,64,128,172,512,189,2048,2634,2642,0,184,2768,80,2641,2727,185,2635,112,16,138,192,2651,2777,1,1,658,2654,16,172,2651,80,2075]

theorem envBound46966 : H12AffineFastState.Bounded env46966 := by
  intro p hp
  have h : env46966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46965_46966 : H12AffineEnvironment.transform 11 2634 env46965 = env46966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2634 env46965 == env46966) = true)

theorem identity46966 : scanCanonicalize (H12AffineFastState.compose env46966 (packedSelected [0,2,3,7,8,10,16,17] rootPS)) = affineNative (2^(10+1) ^^^ 729) := by decide +kernel

theorem selectedBound46966 : packedSelected [0,2,3,7,8,10,16,17] rootPS < 2^1333 := by decide +kernel

def env46967 : List Nat := [2,4,8,16,32,64,128,172,512,189,729,147,139,0,184,9,80,136,126,185,146,112,16,138,192,130,0,1,1,658,135,16,172,130,80,706]

theorem envBound46967 : H12AffineFastState.Bounded env46967 := by
  intro p hp
  have h : env46967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46966_46967 : H12AffineEnvironment.transform 10 729 env46966 = env46967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 729 env46966 == env46967) = true)

theorem identity46967 : scanCanonicalize (H12AffineFastState.compose env46967 (packedSelected [2,10,12] rootPS)) = affineNative (2^(6+1) ^^^ 67) := by decide +kernel

theorem selectedBound46967 : packedSelected [2,10,12] rootPS < 2^1333 := by decide +kernel

def env46968 : List Nat := [2,4,8,16,32,64,67,111,512,126,538,80,72,0,123,9,80,75,126,122,81,112,16,73,3,65,0,1,1,593,68,16,111,65,80,513]

theorem envBound46968 : H12AffineFastState.Bounded env46968 := by
  intro p hp
  have h : env46968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46967_46968 : H12AffineEnvironment.transform 6 67 env46967 = env46968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 67 env46967 == env46968) = true)

theorem identity46968 : scanCanonicalize (H12AffineFastState.compose env46968 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 42) := by decide +kernel

theorem selectedBound46968 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env46969 : List Nat := [2,4,8,16,32,42,41,5,512,20,538,58,34,0,17,9,58,33,20,16,59,26,16,35,3,43,0,1,1,571,46,16,5,43,58,513]

theorem envBound46969 : H12AffineFastState.Bounded env46969 := by
  intro p hp
  have h : env46969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46968_46969 : H12AffineEnvironment.transform 5 42 env46968 = env46969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 42 env46968 == env46969) = true)

theorem identity46969 : scanCanonicalize (H12AffineFastState.compose env46969 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 44) := by decide +kernel

theorem selectedBound46969 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env46970 : List Nat := [2,4,8,16,32,42,41,5,44,20,54,58,34,0,17,9,58,33,20,16,59,26,16,35,3,43,0,1,1,23,46,16,5,43,58,45]

theorem envBound46970 : H12AffineFastState.Bounded env46970 := by
  intro p hp
  have h : env46970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46969_46970 : H12AffineEnvironment.transform 8 44 env46969 = env46970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 44 env46969 == env46970) = true)

theorem identity46970 : scanCanonicalize (H12AffineFastState.compose env46970 (packedSelected [2,8] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound46970 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env46971 : List Nat := [2,4,8,16,12,6,5,5,0,20,26,22,14,0,17,9,22,13,20,16,23,26,16,15,3,7,0,1,1,23,2,16,5,7,22,1]

theorem envBound46971 : H12AffineFastState.Bounded env46971 := by
  intro p hp
  have h : env46971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46970_46971 : H12AffineEnvironment.transform 4 12 env46970 = env46971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env46970 == env46971) = true)

theorem identity46971 : scanCanonicalize (H12AffineFastState.compose env46971 (packedSelected [1,2,5] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound46971 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env46972 : List Nat := [2,4,8,12,12,6,5,5,0,8,6,10,14,0,13,9,10,13,8,12,11,6,12,15,3,7,0,1,1,11,2,12,5,7,10,1]

theorem envBound46972 : H12AffineFastState.Bounded env46972 := by
  intro p hp
  have h : env46972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46971_46972 : H12AffineEnvironment.transform 3 12 env46971 = env46972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env46971 == env46972) = true)

theorem identity46972 : scanCanonicalize (H12AffineFastState.compose env46972 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound46972 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46973 : List Nat := [2,4,1,5,5,6,5,5,0,1,6,3,7,0,4,0,3,4,1,5,2,6,5,6,3,7,0,1,1,2,2,5,5,7,3,1]

theorem envBound46973 : H12AffineFastState.Bounded env46973 := by
  intro p hp
  have h : env46973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46972_46973 : H12AffineEnvironment.transform 2 1 env46972 = env46973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env46972 == env46973) = true)

theorem identity46973 : scanCanonicalize (H12AffineFastState.compose env46973 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound46973 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46974 : List Nat := [2,2,1,3,3,0,3,3,0,1,0,3,1,0,2,0,3,2,1,3,2,0,3,0,3,1,0,1,1,2,2,3,3,1,3,1]

theorem envBound46974 : H12AffineFastState.Bounded env46974 := by
  intro p hp
  have h : env46974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46973_46974 : H12AffineEnvironment.transform 1 2 env46973 = env46974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env46973 == env46974) = true)

theorem identity46974 : scanCanonicalize (H12AffineFastState.compose env46974 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound46974 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46975 : List Nat := [1,1,1,0,0,0,0,0,0,1,0,0,1,0,1,0,0,1,1,0,1,0,0,0,0,1,0,1,1,1,1,0,0,1,0,1]

theorem envBound46975 : H12AffineFastState.Bounded env46975 := by
  intro p hp
  have h : env46975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46974_46975 : H12AffineEnvironment.transform 0 1 env46974 = env46975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env46974 == env46975) = true)

def env46976 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21585,32769,4097,61648,91183,123164,28889,78895,385202,90415,1297,96346,25885,74798,256,25880,1345,21072]

theorem envBound46976 : H12AffineFastState.Bounded env46976 := by
  intro p hp
  have h : env46976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46879_46976 : H12AffineEnvironment.transform 18 21585 env46879 = env46976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env46879 == env46976) = true)

theorem identity46976 : scanCanonicalize (H12AffineFastState.compose env46976 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25676) := by decide +kernel

theorem selectedBound46976 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env46977 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25676,65536,74863,262144,21585,25677,4097,5276,91183,66896,28889,78895,328958,90415,1297,96346,25885,74798,256,25880,1345,21072]

theorem envBound46977 : H12AffineFastState.Bounded env46977 := by
  intro p hp
  have h : env46977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46976_46977 : H12AffineEnvironment.transform 14 25676 env46976 = env46977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25676 env46976 == env46977) = true)

def env46978 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74863,262144,4417,8541,4097,5276,74047,66896,13769,78895,328958,74815,1297,81226,8205,74798,256,8200,1345,5952]

theorem envBound46978 : H12AffineFastState.Bounded env46978 := by
  intro p hp
  have h : env46978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46977_46978 : H12AffineEnvironment.transform 13 1296 env46977 = env46978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env46977 == env46978) = true)

def env46979 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74863,65664,4417,8541,4097,5276,74047,66896,13769,78895,1150,74815,1297,81226,8205,74798,256,8200,1345,5952]

theorem envBound46979 : H12AffineFastState.Bounded env46979 := by
  intro p hp
  have h : env46979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46978_46979 : H12AffineEnvironment.transform 17 65664 env46978 = env46979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env46978 == env46979) = true)

theorem identity46979 : scanCanonicalize (H12AffineFastState.compose env46979 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12591) := by decide +kernel

theorem selectedBound46979 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env46980 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,12591,5440,12719,4417,8541,4097,5276,4112,13439,13769,1280,1150,5392,1297,3173,8205,5377,256,8200,1345,5952]

theorem envBound46980 : H12AffineFastState.Bounded env46980 := by
  intro p hp
  have h : env46980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46979_46980 : H12AffineEnvironment.transform 15 12591 env46979 = env46980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12591 env46979 == env46980) = true)

def env46981 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1296,8540,8495,1344,8623,321,8541,1,1180,16,9343,9673,1280,1150,1296,1297,3173,8205,1281,256,8200,1345,1856]

theorem envBound46981 : H12AffineFastState.Bounded env46981 := by
  intro p hp
  have h : env46981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46980_46981 : H12AffineEnvironment.transform 11 0 env46980 = env46981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env46980 == env46981) = true)

theorem identity46981 : scanCanonicalize (H12AffineFastState.compose env46981 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound46981 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env46982 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,24,1296,324,311,1344,439,321,325,1,1180,16,1127,1489,1280,1150,1296,1297,3173,21,1281,256,16,1345,1856]

theorem envBound46982 : H12AffineFastState.Bounded env46982 := by
  intro p hp
  have h : env46982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46981_46982 : H12AffineEnvironment.transform 12 24 env46981 = env46982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env46981 == env46982) = true)

theorem identity46982 : scanCanonicalize (H12AffineFastState.compose env46982 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,16,18,20] rootPS)) = affineNative (2^(9+1) ^^^ 969) := by decide +kernel

theorem selectedBound46982 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,16,18,20] rootPS < 2^1333 := by decide +kernel

def env46983 : List Nat := [2,4,8,16,32,64,128,256,512,969,2048,0,24,729,324,311,649,439,321,325,1,853,16,942,536,713,951,729,728,2988,21,712,256,16,648,137]

theorem envBound46983 : H12AffineFastState.Bounded env46983 := by
  intro p hp
  have h : env46983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46982_46983 : H12AffineEnvironment.transform 9 969 env46982 = env46983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 969 env46982 == env46983) = true)

theorem identity46983 : scanCanonicalize (H12AffineFastState.compose env46983 (packedSelected [0,1,2,3,7,8,10,11,12,13,15,16,23,24] rootPS)) = affineNative (2^(8+1) ^^^ 461) := by decide +kernel

theorem selectedBound46983 : packedSelected [0,1,2,3,7,8,10,11,12,13,15,16,23,24] rootPS < 2^1333 := by decide +kernel

def env46984 : List Nat := [2,4,8,16,32,64,128,256,461,4,2048,0,24,276,324,311,324,439,321,325,1,152,16,99,469,260,122,276,277,2145,21,261,256,16,325,137]

theorem envBound46984 : H12AffineFastState.Bounded env46984 := by
  intro p hp
  have h : env46984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46983_46984 : H12AffineEnvironment.transform 8 461 env46983 = env46984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 461 env46983 == env46984) = true)

theorem identity46984 : scanCanonicalize (H12AffineFastState.compose env46984 (packedSelected [0,3,5,7,11,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 461) := by decide +kernel

theorem selectedBound46984 : packedSelected [0,3,5,7,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env46985 : List Nat := [2,4,8,16,32,64,128,256,461,4,461,0,24,276,324,311,324,439,321,325,1,152,16,99,469,260,122,276,277,428,21,261,256,16,325,137]

theorem envBound46985 : H12AffineFastState.Bounded env46985 := by
  intro p hp
  have h : env46985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46984_46985 : H12AffineEnvironment.transform 10 461 env46984 = env46985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 461 env46984 == env46985) = true)

theorem identity46985 : scanCanonicalize (H12AffineFastState.compose env46985 (packedSelected [0,2,3,7,8,11] rootPS)) = affineNative (2^(7+1) ^^^ 134) := by decide +kernel

theorem selectedBound46985 : packedSelected [0,2,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env46986 : List Nat := [2,4,8,16,32,64,128,134,75,4,75,0,24,146,194,177,194,49,199,195,1,152,16,99,83,130,122,146,147,42,21,131,134,16,195,137]

theorem envBound46986 : H12AffineFastState.Bounded env46986 := by
  intro p hp
  have h : env46986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46985_46986 : H12AffineEnvironment.transform 7 134 env46985 = env46986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 134 env46985 == env46986) = true)

theorem identity46986 : scanCanonicalize (H12AffineFastState.compose env46986 (packedSelected [0,1,3,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound46986 : packedSelected [0,1,3,9,10] rootPS < 2^1333 := by decide +kernel

def env46987 : List Nat := [2,4,8,16,32,64,18,20,75,4,75,0,24,0,80,35,80,49,85,81,1,10,16,99,83,16,122,0,1,42,21,17,20,16,81,27]

theorem envBound46987 : H12AffineFastState.Bounded env46987 := by
  intro p hp
  have h : env46987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46986_46987 : H12AffineEnvironment.transform 6 18 env46986 = env46987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env46986 == env46987) = true)

theorem identity46987 : scanCanonicalize (H12AffineFastState.compose env46987 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound46987 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env46988 : List Nat := [2,4,8,16,23,64,18,20,75,4,75,0,24,0,80,20,80,6,85,81,1,10,16,84,83,16,77,0,1,29,21,17,20,16,81,27]

theorem envBound46988 : H12AffineFastState.Bounded env46988 := by
  intro p hp
  have h : env46988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46987_46988 : H12AffineEnvironment.transform 4 23 env46987 = env46988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env46987 == env46988) = true)

theorem identity46988 : scanCanonicalize (H12AffineFastState.compose env46988 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound46988 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env46989 : List Nat := [2,4,8,16,23,10,18,20,1,4,1,0,24,0,26,20,26,6,31,27,1,10,16,30,25,16,7,0,1,29,21,17,20,16,27,27]

theorem envBound46989 : H12AffineFastState.Bounded env46989 := by
  intro p hp
  have h : env46989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46988_46989 : H12AffineEnvironment.transform 5 10 env46988 = env46989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env46988 == env46989) = true)

theorem identity46989 : scanCanonicalize (H12AffineFastState.compose env46989 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound46989 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env46990 : List Nat := [2,4,8,11,12,10,9,15,1,4,1,0,3,0,1,15,1,6,4,0,1,10,11,5,2,11,7,0,1,6,14,10,15,11,0,0]

theorem envBound46990 : H12AffineFastState.Bounded env46990 := by
  intro p hp
  have h : env46990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46989_46990 : H12AffineEnvironment.transform 3 11 env46989 = env46990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env46989 == env46990) = true)

theorem identity46990 : scanCanonicalize (H12AffineFastState.compose env46990 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound46990 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46991 : List Nat := [2,4,0,3,4,2,1,7,1,4,1,0,3,0,1,7,1,6,4,0,1,2,3,5,2,3,7,0,1,6,6,2,7,3,0,0]

theorem envBound46991 : H12AffineFastState.Bounded env46991 := by
  intro p hp
  have h : env46991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46990_46991 : H12AffineEnvironment.transform 2 0 env46990 = env46991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env46990 == env46991) = true)

theorem identity46991 : scanCanonicalize (H12AffineFastState.compose env46991 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound46991 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env46992 : List Nat := [1,4,0,0,4,1,1,4,1,4,1,0,0,0,1,4,1,5,4,0,1,1,0,5,1,0,4,0,1,5,5,1,4,0,0,0]

theorem envBound46992 : H12AffineFastState.Bounded env46992 := by
  intro p hp
  have h : env46992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46991_46992 : H12AffineEnvironment.transform 0 1 env46991 = env46992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env46991 == env46992) = true)

theorem identity46992 : scanCanonicalize (H12AffineFastState.compose env46992 (packedSelected [7] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound46992 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env46993 : List Nat := [1,1,0,0,1,1,1,1,1,1,1,0,0,0,1,1,1,0,1,0,1,1,0,0,1,0,1,0,1,0,0,1,1,0,0,0]

theorem envBound46993 : H12AffineFastState.Bounded env46993 := by
  intro p hp
  have h : env46993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46992_46993 : H12AffineEnvironment.transform 1 1 env46992 = env46993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env46992 == env46993) = true)

def env46994 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1296,8540,8494,1345,8622,320,8541,0,1181,17,9342,9672,1280,1150,1297,1297,3173,8205,1280,256,8200,1345,1857]

theorem envBound46994 : H12AffineFastState.Bounded env46994 := by
  intro p hp
  have h : env46994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46980_46994 : H12AffineEnvironment.transform 11 1 env46980 = env46994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env46980 == env46994) = true)

theorem identity46994 : scanCanonicalize (H12AffineFastState.compose env46994 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound46994 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env46995 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,1100,1296,1296,1378,1345,1506,320,1297,0,1181,17,50,388,1280,1150,1297,1297,3173,1089,1280,256,1092,1345,1857]

theorem envBound46995 : H12AffineFastState.Bounded env46995 := by
  intro p hp
  have h : env46995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46994_46995 : H12AffineEnvironment.transform 12 1100 env46994 = env46995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env46994 == env46995) = true)

theorem identity46995 : scanCanonicalize (H12AffineFastState.compose env46995 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound46995 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env46996 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,269,81,81,35,0,163,320,80,0,476,17,50,388,65,319,80,80,2340,256,65,256,261,0,512]

theorem envBound46996 : H12AffineFastState.Bounded env46996 := by
  intro p hp
  have h : env46996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46995_46996 : H12AffineEnvironment.transform 9 321 env46995 = env46996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env46995 == env46996) = true)

theorem identity46996 : scanCanonicalize (H12AffineFastState.compose env46996 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound46996 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env46997 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,269,1,1,35,0,163,272,0,0,396,17,50,388,17,319,0,0,2340,256,17,256,261,0,512]

theorem envBound46997 : H12AffineFastState.Bounded env46997 := by
  intro p hp
  have h : env46997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46996_46997 : H12AffineEnvironment.transform 5 16 env46996 = env46997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46996 == env46997) = true)

theorem identity46997 : scanCanonicalize (H12AffineFastState.compose env46997 (packedSelected [1,2,5] rootPS)) = affineNative (2^(10+1) ^^^ 925) := by decide +kernel

theorem selectedBound46997 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env46998 : List Nat := [2,4,8,16,32,16,128,256,512,273,925,1,269,1,1,35,0,163,272,0,0,396,17,50,388,17,319,0,0,697,256,17,256,261,0,512]

theorem envBound46998 : H12AffineFastState.Bounded env46998 := by
  intro p hp
  have h : env46998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46997_46998 : H12AffineEnvironment.transform 10 925 env46997 = env46998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 925 env46997 == env46998) = true)

theorem identity46998 : scanCanonicalize (H12AffineFastState.compose env46998 (packedSelected [3,8] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound46998 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env46999 : List Nat := [2,4,8,16,32,16,128,256,49,273,428,1,269,1,1,35,0,163,272,0,0,396,17,50,388,17,319,0,0,136,256,17,256,261,0,49]

theorem envBound46999 : H12AffineFastState.Bounded env46999 := by
  intro p hp
  have h : env46999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46998_46999 : H12AffineEnvironment.transform 8 49 env46998 = env46999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env46998 == env46999) = true)

theorem identity46999 : scanCanonicalize (H12AffineFastState.compose env46999 (packedSelected [1,2,3,10] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound46999 : packedSelected [1,2,3,10] rootPS < 2^1333 := by decide +kernel

def env47000 : List Nat := [2,4,8,16,32,16,128,172,49,189,0,1,161,1,1,35,0,163,188,0,0,32,17,50,40,17,147,0,0,136,172,17,172,169,0,49]

theorem envBound47000 : H12AffineFastState.Bounded env47000 := by
  intro p hp
  have h : env47000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46999_47000 : H12AffineEnvironment.transform 7 172 env46999 = env47000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env46999 == env47000) = true)

theorem identity47000 : scanCanonicalize (H12AffineFastState.compose env47000 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound47000 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env47001 : List Nat := [2,4,8,16,32,16,9,37,49,52,0,1,40,1,1,35,0,42,53,0,0,32,17,50,40,17,26,0,0,1,37,17,37,32,0,49]

theorem envBound47001 : H12AffineFastState.Bounded env47001 := by
  intro p hp
  have h : env47001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47000_47001 : H12AffineEnvironment.transform 6 9 env47000 = env47001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47000 == env47001) = true)

def env47002 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74863,65665,4417,8541,4097,5276,74047,66896,13769,78895,1151,74815,1297,81226,8205,74798,256,8200,1345,5952]

theorem envBound47002 : H12AffineFastState.Bounded env47002 := by
  intro p hp
  have h : env47002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46978_47002 : H12AffineEnvironment.transform 17 65665 env46978 = env47002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env46978 == env47002) = true)

theorem identity47002 : scanCanonicalize (H12AffineFastState.compose env47002 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9326) := by decide +kernel

theorem selectedBound47002 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env47003 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,9326,1,9455,4417,8541,4097,5276,1361,8510,13769,4161,1151,81,1297,6436,8205,64,256,8200,1345,5952]

theorem envBound47003 : H12AffineFastState.Bounded env47003 := by
  intro p hp
  have h : env47003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47002_47003 : H12AffineEnvironment.transform 15 9326 env47002 = env47003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9326 env47002 == env47003) = true)

def env47004 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,80,8540,8494,1,8623,4417,8541,4097,4572,17,8510,12425,4161,319,81,81,6436,8205,64,256,8200,1,4608]

theorem envBound47004 : H12AffineFastState.Bounded env47004 := by
  intro p hp
  have h : env47004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47003_47004 : H12AffineEnvironment.transform 9 320 env47003 = env47004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env47003 == env47004) = true)

theorem identity47004 : scanCanonicalize (H12AffineFastState.compose env47004 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 4365) := by decide +kernel

theorem selectedBound47004 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env47005 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,4365,80,4177,4131,1,4258,4417,4176,4097,4572,17,4147,388,4161,319,81,81,6436,4352,64,256,4357,1,4608]

theorem envBound47005 : H12AffineFastState.Bounded env47005 := by
  intro p hp
  have h : env47005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47004_47005 : H12AffineEnvironment.transform 12 4365 env47004 = env47005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4365 env47004 == env47005) = true)

theorem identity47005 : scanCanonicalize (H12AffineFastState.compose env47005 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound47005 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env47006 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,0,269,80,81,35,1,162,321,80,1,476,17,51,388,65,319,81,81,2340,256,64,256,261,1,512]

theorem envBound47006 : H12AffineFastState.Bounded env47006 := by
  intro p hp
  have h : env47006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47005_47006 : H12AffineEnvironment.transform 11 0 env47005 = env47006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env47005 == env47006) = true)

theorem identity47006 : scanCanonicalize (H12AffineFastState.compose env47006 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound47006 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env47007 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,269,0,1,35,1,162,273,0,1,396,17,51,388,17,319,1,1,2340,256,16,256,261,1,512]

theorem envBound47007 : H12AffineFastState.Bounded env47007 := by
  intro p hp
  have h : env47007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47006_47007 : H12AffineEnvironment.transform 5 16 env47006 = env47007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47006 == env47007) = true)

theorem identity47007 : scanCanonicalize (H12AffineFastState.compose env47007 (packedSelected [1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 162) := by decide +kernel

theorem selectedBound47007 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env47008 : List Nat := [2,4,8,16,32,16,128,256,162,272,2048,0,269,0,1,35,1,162,273,0,1,396,17,51,388,17,319,1,1,2340,256,16,256,261,1,162]

theorem envBound47008 : H12AffineFastState.Bounded env47008 := by
  intro p hp
  have h : env47008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47007_47008 : H12AffineEnvironment.transform 8 162 env47007 = env47008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 162 env47007 == env47008) = true)

theorem identity47008 : scanCanonicalize (H12AffineFastState.compose env47008 (packedSelected [3,8] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound47008 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env47009 : List Nat := [2,4,8,16,11,16,128,256,137,272,2048,0,269,0,1,8,1,137,273,0,1,396,17,24,388,17,276,1,1,2319,256,16,256,261,1,137]

theorem envBound47009 : H12AffineFastState.Bounded env47009 := by
  intro p hp
  have h : env47009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47008_47009 : H12AffineEnvironment.transform 4 11 env47008 = env47009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env47008 == env47009) = true)

theorem identity47009 : scanCanonicalize (H12AffineFastState.compose env47009 (packedSelected [3,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound47009 : packedSelected [3,7] rootPS < 2^1333 := by decide +kernel

def env47010 : List Nat := [2,4,8,10,11,10,128,256,137,266,2048,0,269,0,1,8,1,137,267,0,1,396,11,2,388,11,270,1,1,2319,256,10,256,261,1,137]

theorem envBound47010 : H12AffineFastState.Bounded env47010 := by
  intro p hp
  have h : env47010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47009_47010 : H12AffineEnvironment.transform 3 10 env47009 = env47010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env47009 == env47010) = true)

theorem identity47010 : scanCanonicalize (H12AffineFastState.compose env47010 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound47010 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env47011 : List Nat := [2,4,8,10,11,10,9,256,0,266,2048,0,269,0,1,8,1,0,267,0,1,261,11,2,269,11,270,1,1,2319,256,10,256,261,1,0]

theorem envBound47011 : H12AffineFastState.Bounded env47011 := by
  intro p hp
  have h : env47011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47010_47011 : H12AffineEnvironment.transform 6 9 env47010 = env47011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47010 == env47011) = true)

theorem identity47011 : scanCanonicalize (H12AffineFastState.compose env47011 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound47011 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47012 : List Nat := [2,4,8,10,11,10,9,256,0,266,1,0,269,0,1,8,1,0,267,0,1,261,11,2,269,11,270,1,1,270,256,10,256,261,1,0]

theorem envBound47012 : H12AffineFastState.Bounded env47012 := by
  intro p hp
  have h : env47012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47011_47012 : H12AffineEnvironment.transform 10 1 env47011 = env47012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env47011 == env47012) = true)

theorem identity47012 : scanCanonicalize (H12AffineFastState.compose env47012 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound47012 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env47013 : List Nat := [2,4,8,10,11,10,9,15,0,5,1,0,2,0,1,8,1,0,4,0,1,10,11,2,2,11,1,1,1,1,15,10,15,10,1,0]

theorem envBound47013 : H12AffineFastState.Bounded env47013 := by
  intro p hp
  have h : env47013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47012_47013 : H12AffineEnvironment.transform 7 15 env47012 = env47013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env47012 == env47013) = true)

theorem identity47013 : scanCanonicalize (H12AffineFastState.compose env47013 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound47013 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47014 : List Nat := [2,4,4,6,7,6,5,3,0,5,1,0,2,0,1,4,1,0,4,0,1,6,7,2,2,7,1,1,1,1,3,6,3,6,1,0]

theorem envBound47014 : H12AffineFastState.Bounded env47014 := by
  intro p hp
  have h : env47014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47013_47014 : H12AffineEnvironment.transform 2 4 env47013 = env47014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env47013 == env47014) = true)

def env47015 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,81,8540,8495,1,8622,4417,8541,4097,4573,16,8510,12424,4161,318,81,80,6436,8205,64,256,8200,0,4609]

theorem envBound47015 : H12AffineFastState.Bounded env47015 := by
  intro p hp
  have h : env47015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47003_47015 : H12AffineEnvironment.transform 9 321 env47003 = env47015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env47003 == env47015) = true)

theorem identity47015 : scanCanonicalize (H12AffineFastState.compose env47015 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 4120) := by decide +kernel

theorem selectedBound47015 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env47016 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,4120,81,4420,4407,1,4534,4417,4421,4097,4573,16,4390,144,4161,318,81,80,6436,4117,64,256,4112,0,4609]

theorem envBound47016 : H12AffineFastState.Bounded env47016 := by
  intro p hp
  have h : env47016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47015_47016 : H12AffineEnvironment.transform 12 4120 env47015 = env47016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4120 env47015 == env47016) = true)

theorem identity47016 : scanCanonicalize (H12AffineFastState.compose env47016 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,16,18,20] rootPS)) = affineNative (2^(11+1) ^^^ 648) := by decide +kernel

theorem selectedBound47016 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,16,18,20] rootPS < 2^1333 := by decide +kernel

def env47017 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,648,656,81,972,959,1,830,969,973,649,853,16,942,144,713,318,81,80,2988,669,64,256,664,0,137]

theorem envBound47017 : H12AffineFastState.Bounded env47017 := by
  intro p hp
  have h : env47017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47016_47017 : H12AffineEnvironment.transform 11 648 env47016 = env47017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 648 env47016 == env47017) = true)

theorem identity47017 : scanCanonicalize (H12AffineFastState.compose env47017 (packedSelected [0,1,2,3,7,8,10,11,12,13,15,16,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound47017 : packedSelected [0,1,2,3,7,8,10,11,12,13,15,16,23,24] rootPS < 2^1333 := by decide +kernel

def env47018 : List Nat := [2,4,8,16,32,64,128,69,512,4,2048,648,656,81,649,762,1,635,652,648,649,528,16,747,144,713,123,81,80,2793,669,64,69,664,0,137]

theorem envBound47018 : H12AffineFastState.Bounded env47018 := by
  intro p hp
  have h : env47018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47017_47018 : H12AffineEnvironment.transform 7 69 env47017 = env47018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env47017 == env47018) = true)

theorem identity47018 : scanCanonicalize (H12AffineFastState.compose env47018 (packedSelected [0,1,2,3,7,10,11,12,13] rootPS)) = affineNative (2^(8+1) ^^^ 233) := by decide +kernel

theorem selectedBound47018 : packedSelected [0,1,2,3,7,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env47019 : List Nat := [2,4,8,16,32,64,128,69,233,4,2048,97,121,81,96,19,1,146,101,97,96,249,16,2,144,32,123,81,80,2048,116,64,69,113,0,137]

theorem envBound47019 : H12AffineFastState.Bounded env47019 := by
  intro p hp
  have h : env47019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47018_47019 : H12AffineEnvironment.transform 8 233 env47018 = env47019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 233 env47018 == env47019) = true)

theorem identity47019 : scanCanonicalize (H12AffineFastState.compose env47019 (packedSelected [1,2,8,10,15] rootPS)) = affineNative (2^(6+1) ^^^ 114) := by decide +kernel

theorem selectedBound47019 : packedSelected [1,2,8,10,15] rootPS < 2^1333 := by decide +kernel

def env47020 : List Nat := [2,4,8,16,32,64,114,69,27,4,2048,97,121,81,96,19,1,96,101,97,96,11,16,2,98,32,123,81,80,2048,116,64,69,113,0,123]

theorem envBound47020 : H12AffineFastState.Bounded env47020 := by
  intro p hp
  have h : env47020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47019_47020 : H12AffineEnvironment.transform 6 114 env47019 = env47020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 114 env47019 == env47020) = true)

theorem identity47020 : scanCanonicalize (H12AffineFastState.compose env47020 (packedSelected [0,1,2,3,5,7,8,10] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound47020 : packedSelected [0,1,2,3,5,7,8,10] rootPS < 2^1333 := by decide +kernel

def env47021 : List Nat := [2,4,8,16,32,59,9,62,27,4,2048,26,2,42,27,19,1,27,30,26,27,11,16,2,25,32,0,42,43,2048,15,59,62,10,0,0]

theorem envBound47021 : H12AffineFastState.Bounded env47021 := by
  intro p hp
  have h : env47021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47020_47021 : H12AffineEnvironment.transform 5 59 env47020 = env47021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env47020 == env47021) = true)

def env47022 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74863,262144,4416,8540,4097,5276,74046,66896,13768,78895,328958,74814,1297,81227,8204,74798,256,8201,1345,5953]

theorem envBound47022 : H12AffineFastState.Bounded env47022 := by
  intro p hp
  have h : env47022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46977_47022 : H12AffineEnvironment.transform 13 1297 env46977 = env47022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env46977 == env47022) = true)

def env47023 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74863,65664,4416,8540,4097,5276,74046,66896,13768,78895,1150,74814,1297,81227,8204,74798,256,8201,1345,5953]

theorem envBound47023 : H12AffineFastState.Bounded env47023 := by
  intro p hp
  have h : env47023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47022_47023 : H12AffineEnvironment.transform 17 65664 env47022 = env47023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env47022 == env47023) = true)

theorem identity47023 : scanCanonicalize (H12AffineFastState.compose env47023 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 359) := by decide +kernel

theorem selectedBound47023 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env47024 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,359,9480,487,4416,8540,4097,5276,8281,1079,13768,13640,1150,9561,1297,15404,8204,9545,256,8201,1345,5953]

theorem envBound47024 : H12AffineFastState.Bounded env47024 := by
  intro p hp
  have h : env47024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47023_47024 : H12AffineEnvironment.transform 15 359 env47023 = env47024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 359 env47023 == env47024) = true)

def env47025 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,72,1297,277,359,1344,487,4416,276,4097,5276,17,1079,5504,5376,1150,1297,1297,7268,68,1281,256,65,1345,5953]

theorem envBound47025 : H12AffineFastState.Bounded env47025 := by
  intro p hp
  have h : env47025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47024_47025 : H12AffineEnvironment.transform 12 72 env47024 = env47025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env47024 == env47025) = true)

theorem identity47025 : scanCanonicalize (H12AffineFastState.compose env47025 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound47025 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env47026 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,72,0,277,359,81,487,4416,276,4097,4493,17,294,4241,4113,367,0,0,6517,68,16,256,65,80,4688]

theorem envBound47026 : H12AffineFastState.Bounded env47026 := by
  intro p hp
  have h : env47026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47025_47026 : H12AffineEnvironment.transform 9 273 env47025 = env47026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env47025 == env47026) = true)

theorem identity47026 : scanCanonicalize (H12AffineFastState.compose env47026 (packedSelected [0,2,3,5,7,10,11,12,15,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 755) := by decide +kernel

theorem selectedBound47026 : packedSelected [0,2,3,5,7,10,11,12,15,17,18,20] rootPS < 2^1333 := by decide +kernel

def env47027 : List Nat := [2,4,8,16,32,64,128,256,512,273,755,4096,72,0,277,359,81,487,4416,276,4097,4493,17,294,4241,4113,367,0,0,4998,68,16,256,65,80,4688]

theorem envBound47027 : H12AffineFastState.Bounded env47027 := by
  intro p hp
  have h : env47027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47026_47027 : H12AffineEnvironment.transform 10 755 env47026 = env47027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 755 env47026 == env47027) = true)

theorem identity47027 : scanCanonicalize (H12AffineFastState.compose env47027 (packedSelected [1,5,8,13,28] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound47027 : packedSelected [1,5,8,13,28] rootPS < 2^1333 := by decide +kernel

def env47028 : List Nat := [2,4,8,16,32,64,128,256,512,273,755,184,72,0,277,359,81,487,504,276,185,309,17,294,41,169,367,0,0,830,68,16,256,65,80,744]

theorem envBound47028 : H12AffineFastState.Bounded env47028 := by
  intro p hp
  have h : env47028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47027_47028 : H12AffineEnvironment.transform 11 184 env47027 = env47028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env47027 == env47028) = true)

theorem identity47028 : scanCanonicalize (H12AffineFastState.compose env47028 (packedSelected [2,4,5,8,9,10,11,12,13,15,17] rootPS)) = affineNative (2^(8+1) ^^^ 373) := by decide +kernel

theorem selectedBound47028 : packedSelected [2,4,5,8,9,10,11,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env47029 : List Nat := [2,4,8,16,32,64,128,256,373,273,390,184,72,0,277,359,81,487,504,276,185,309,17,294,41,169,367,0,0,75,68,16,256,65,80,413]

theorem envBound47029 : H12AffineFastState.Bounded env47029 := by
  intro p hp
  have h : env47029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47028_47029 : H12AffineEnvironment.transform 8 373 env47028 = env47029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 373 env47028 == env47029) = true)

theorem identity47029 : scanCanonicalize (H12AffineFastState.compose env47029 (packedSelected [0,1,2,7,8,11] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound47029 : packedSelected [0,1,2,7,8,11] rootPS < 2^1333 := by decide +kernel

def env47030 : List Nat := [2,4,8,16,32,64,128,173,216,188,43,184,72,0,184,202,81,74,85,185,185,152,17,139,41,169,194,0,0,75,68,16,173,65,80,48]

theorem envBound47030 : H12AffineFastState.Bounded env47030 := by
  intro p hp
  have h : env47030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47029_47030 : H12AffineEnvironment.transform 7 173 env47029 = env47030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env47029 == env47030) = true)

theorem identity47030 : scanCanonicalize (H12AffineFastState.compose env47030 (packedSelected [1,3,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound47030 : packedSelected [1,3,7,9] rootPS < 2^1333 := by decide +kernel

def env47031 : List Nat := [2,4,8,16,16,64,128,157,216,140,27,136,72,0,136,202,81,74,85,137,137,152,17,139,25,153,194,0,0,75,68,16,157,65,80,0]

theorem envBound47031 : H12AffineFastState.Bounded env47031 := by
  intro p hp
  have h : env47031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47030_47031 : H12AffineEnvironment.transform 4 16 env47030 = env47031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env47030 == env47031) = true)

theorem identity47031 : scanCanonicalize (H12AffineFastState.compose env47031 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound47031 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env47032 : List Nat := [2,4,8,16,16,64,19,14,75,31,27,27,72,0,27,89,81,74,85,26,26,11,17,24,25,10,81,0,0,75,68,16,14,65,80,0]

theorem envBound47032 : H12AffineFastState.Bounded env47032 := by
  intro p hp
  have h : env47032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47031_47032 : H12AffineEnvironment.transform 6 19 env47031 = env47032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env47031 == env47032) = true)

theorem identity47032 : scanCanonicalize (H12AffineFastState.compose env47032 (packedSelected [1,2,5] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound47032 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env47033 : List Nat := [2,4,8,16,16,10,19,14,1,31,27,27,2,0,27,19,27,0,31,26,26,11,17,24,25,10,27,0,0,1,14,16,14,11,26,0]

theorem envBound47033 : H12AffineFastState.Bounded env47033 := by
  intro p hp
  have h : env47033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47032_47033 : H12AffineEnvironment.transform 5 10 env47032 = env47033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env47032 == env47033) = true)

theorem identity47033 : scanCanonicalize (H12AffineFastState.compose env47033 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound47033 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env47034 : List Nat := [2,4,0,16,16,2,19,6,1,23,19,19,2,0,19,19,19,0,23,18,18,3,17,16,17,2,19,0,0,1,6,16,6,3,18,0]

theorem envBound47034 : H12AffineFastState.Bounded env47034 := by
  intro p hp
  have h : env47034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47033_47034 : H12AffineEnvironment.transform 2 0 env47033 = env47034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env47033 == env47034) = true)

theorem identity47034 : scanCanonicalize (H12AffineFastState.compose env47034 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound47034 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env47035 : List Nat := [2,4,0,0,0,2,3,6,1,7,3,3,2,0,3,3,3,0,7,2,2,3,1,0,1,2,3,0,0,1,6,0,6,3,2,0]

theorem envBound47035 : H12AffineFastState.Bounded env47035 := by
  intro p hp
  have h : env47035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47034_47035 : H12AffineEnvironment.transform 3 0 env47034 = env47035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env47034 == env47035) = true)

theorem identity47035 : scanCanonicalize (H12AffineFastState.compose env47035 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound47035 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47036 : List Nat := [2,2,0,0,0,2,3,0,1,1,3,3,2,0,3,3,3,0,1,2,2,3,1,0,1,2,3,0,0,1,0,0,0,3,2,0]

theorem envBound47036 : H12AffineFastState.Bounded env47036 := by
  intro p hp
  have h : env47036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47035_47036 : H12AffineEnvironment.transform 1 2 env47035 = env47036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env47035 == env47036) = true)

def env47037 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,73,1297,276,359,1345,487,4416,277,4097,5276,16,1079,5505,5377,1150,1296,1297,7269,69,1280,256,64,1345,5953]

theorem envBound47037 : H12AffineFastState.Bounded env47037 := by
  intro p hp
  have h : env47037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47024_47037 : H12AffineEnvironment.transform 12 73 env47024 = env47037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env47024 == env47037) = true)

theorem identity47037 : scanCanonicalize (H12AffineFastState.compose env47037 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound47037 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env47038 : List Nat := [2,4,8,16,32,64,128,69,512,1024,2048,4096,73,1108,81,34,1028,162,4101,80,4097,5276,16,1079,5316,5188,1150,1109,1108,7269,69,1093,69,64,1028,5636]

theorem envBound47038 : H12AffineFastState.Bounded env47038 := by
  intro p hp
  have h : env47038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47037_47038 : H12AffineEnvironment.transform 7 69 env47037 = env47038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env47037 == env47038) = true)

theorem identity47038 : scanCanonicalize (H12AffineFastState.compose env47038 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound47038 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env47039 : List Nat := [2,4,8,16,32,64,128,69,512,1024,2048,1028,73,1108,81,34,1028,162,1025,80,1029,152,16,1079,192,64,1150,1109,1108,2145,69,1093,69,64,1028,512]

theorem envBound47039 : H12AffineFastState.Bounded env47039 := by
  intro p hp
  have h : env47039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47038_47039 : H12AffineEnvironment.transform 11 1028 env47038 = env47039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env47038 == env47039) = true)

theorem identity47039 : scanCanonicalize (H12AffineFastState.compose env47039 (packedSelected [0,2,5,7,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 1222) := by decide +kernel

theorem selectedBound47039 : packedSelected [0,2,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env47040 : List Nat := [2,4,8,16,32,64,128,69,512,1024,1222,1028,73,1108,81,34,1028,162,1025,80,1029,152,16,1079,192,64,1150,1109,1108,1191,69,1093,69,64,1028,512]

theorem envBound47040 : H12AffineFastState.Bounded env47040 := by
  intro p hp
  have h : env47040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47039_47040 : H12AffineEnvironment.transform 10 1222 env47039 = env47040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1222 env47039 == env47040) = true)

theorem identity47040 : scanCanonicalize (H12AffineFastState.compose env47040 (packedSelected [0,1,2,3,4,5,7,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound47040 : packedSelected [0,1,2,3,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env47041 : List Nat := [2,4,8,16,32,64,105,69,512,1024,1071,1028,73,1108,81,34,1028,75,1025,80,1029,113,16,1079,41,64,1150,1109,1108,1102,69,1093,69,64,1028,512]

theorem envBound47041 : H12AffineFastState.Bounded env47041 := by
  intro p hp
  have h : env47041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47040_47041 : H12AffineEnvironment.transform 6 105 env47040 = env47041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env47040 == env47041) = true)

theorem identity47041 : scanCanonicalize (H12AffineFastState.compose env47041 (packedSelected [1,4,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound47041 : packedSelected [1,4,7,8] rootPS < 2^1333 := by decide +kernel

def env47042 : List Nat := [2,4,8,16,17,64,88,69,512,1024,1054,1028,73,1108,81,19,1028,75,1025,80,1029,64,16,1030,24,64,1103,1109,1108,1102,69,1093,69,64,1028,512]

theorem envBound47042 : H12AffineFastState.Bounded env47042 := by
  intro p hp
  have h : env47042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47041_47042 : H12AffineEnvironment.transform 4 17 env47041 = env47042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env47041 == env47042) = true)

theorem identity47042 : scanCanonicalize (H12AffineFastState.compose env47042 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 543) := by decide +kernel

theorem selectedBound47042 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47043 : List Nat := [2,4,8,16,17,64,88,69,512,543,513,539,73,587,81,19,539,75,542,80,538,64,16,537,24,64,592,586,587,593,69,602,69,64,539,512]

theorem envBound47043 : H12AffineFastState.Bounded env47043 := by
  intro p hp
  have h : env47043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47042_47043 : H12AffineEnvironment.transform 9 543 env47042 = env47043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 543 env47042 == env47043) = true)

theorem identity47043 : scanCanonicalize (H12AffineFastState.compose env47043 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound47043 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env47044 : List Nat := [2,4,8,16,17,11,19,14,512,543,513,539,2,512,26,19,539,0,542,27,538,11,16,537,24,11,539,513,512,538,14,529,14,11,539,512]

theorem envBound47044 : H12AffineFastState.Bounded env47044 := by
  intro p hp
  have h : env47044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47043_47044 : H12AffineEnvironment.transform 5 11 env47043 = env47044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env47043 == env47044) = true)

theorem identity47044 : scanCanonicalize (H12AffineFastState.compose env47044 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound47044 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env47045 : List Nat := [2,4,8,16,17,11,19,14,1,30,0,26,2,1,26,19,26,0,31,27,27,11,16,24,24,11,26,0,1,27,14,16,14,11,26,1]

theorem envBound47045 : H12AffineFastState.Bounded env47045 := by
  intro p hp
  have h : env47045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47044_47045 : H12AffineEnvironment.transform 8 1 env47044 = env47045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env47044 == env47045) = true)

def env47046 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74863,65665,4416,8540,4097,5276,74046,66896,13768,78895,1151,74814,1297,81227,8204,74798,256,8201,1345,5953]

theorem envBound47046 : H12AffineFastState.Bounded env47046 := by
  intro p hp
  have h : env47046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47022_47046 : H12AffineEnvironment.transform 17 65665 env47022 = env47046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env47022 == env47046) = true)

theorem identity47046 : scanCanonicalize (H12AffineFastState.compose env47046 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5159) := by decide +kernel

theorem selectedBound47046 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env47047 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,5159,12360,5286,4416,8540,4097,5276,13593,4471,13768,8200,1151,12313,1297,10604,8204,12297,256,8201,1345,5953]

theorem envBound47047 : H12AffineFastState.Bounded env47047 := by
  intro p hp
  have h : env47047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47046_47047 : H12AffineEnvironment.transform 15 5159 env47046 = env47047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5159 env47046 == env47047) = true)

def env47048 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5384,1297,5205,5159,1344,5286,4416,5204,4097,5276,17,4471,192,5376,1151,1297,1297,7268,5380,1281,256,5377,1345,5953]

theorem envBound47048 : H12AffineFastState.Bounded env47048 := by
  intro p hp
  have h : env47048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47047_47048 : H12AffineEnvironment.transform 12 5384 env47047 = env47048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5384 env47047 == env47048) = true)

theorem identity47048 : scanCanonicalize (H12AffineFastState.compose env47048 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound47048 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env47049 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,1369,1297,1028,1142,1344,1271,273,1029,80,1229,17,294,192,1361,1151,1297,1297,3125,1365,1281,256,1360,1345,1808]

theorem envBound47049 : H12AffineFastState.Bounded env47049 := by
  intro p hp
  have h : env47049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47048_47049 : H12AffineEnvironment.transform 11 81 env47048 = env47049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env47048 == env47049) = true)

theorem identity47049 : scanCanonicalize (H12AffineFastState.compose env47049 (packedSelected [0,2,3,5,7,10,11,12,15,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 754) := by decide +kernel

theorem selectedBound47049 : packedSelected [0,2,3,5,7,10,11,12,15,17,18,20] rootPS < 2^1333 := by decide +kernel

def env47050 : List Nat := [2,4,8,16,32,64,128,256,512,1024,754,81,1369,1297,1028,1142,1344,1271,273,1029,80,1229,17,294,192,1361,1151,1297,1297,1735,1365,1281,256,1360,1345,1808]

theorem envBound47050 : H12AffineFastState.Bounded env47050 := by
  intro p hp
  have h : env47050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47049_47050 : H12AffineEnvironment.transform 10 754 env47049 = env47050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 754 env47049 == env47050) = true)

theorem identity47050 : scanCanonicalize (H12AffineFastState.compose env47050 (packedSelected [1,5,8,13,28] rootPS)) = affineNative (2^(9+1) ^^^ 505) := by decide +kernel

theorem selectedBound47050 : packedSelected [1,5,8,13,28] rootPS < 2^1333 := by decide +kernel

def env47051 : List Nat := [2,4,8,16,32,64,128,256,512,505,754,81,160,232,509,399,185,270,273,508,80,308,17,294,192,168,390,232,232,830,172,248,256,169,184,745]

theorem envBound47051 : H12AffineFastState.Bounded env47051 := by
  intro p hp
  have h : env47051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47050_47051 : H12AffineEnvironment.transform 9 505 env47050 = env47051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 505 env47050 == env47051) = true)

theorem identity47051 : scanCanonicalize (H12AffineFastState.compose env47051 (packedSelected [3,8,11,12,13,16,17] rootPS)) = affineNative (2^(8+1) ^^^ 217) := by decide +kernel

theorem selectedBound47051 : packedSelected [3,8,11,12,13,16,17] rootPS < 2^1333 := by decide +kernel

def env47052 : List Nat := [2,4,8,16,32,64,128,256,217,505,43,81,160,232,509,399,185,270,273,508,80,308,17,294,192,168,390,232,232,487,172,248,256,169,184,48]

theorem envBound47052 : H12AffineFastState.Bounded env47052 := by
  intro p hp
  have h : env47052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47051_47052 : H12AffineEnvironment.transform 8 217 env47051 = env47052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env47051 == env47052) = true)

theorem identity47052 : scanCanonicalize (H12AffineFastState.compose env47052 (packedSelected [1,2,5,10,12] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound47052 : packedSelected [1,2,5,10,12] rootPS < 2^1333 := by decide +kernel

def env47053 : List Nat := [2,4,8,16,32,64,105,256,48,272,43,81,73,1,276,358,80,270,273,277,80,308,17,294,41,65,367,1,1,270,69,17,256,64,81,48]

theorem envBound47053 : H12AffineFastState.Bounded env47053 := by
  intro p hp
  have h : env47053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47052_47053 : H12AffineEnvironment.transform 6 105 env47052 = env47053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env47052 == env47053) = true)

theorem identity47053 : scanCanonicalize (H12AffineFastState.compose env47053 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound47053 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env47054 : List Nat := [2,4,8,16,32,58,19,256,48,272,43,43,51,1,276,284,42,270,273,277,42,308,17,294,41,59,277,1,1,270,63,17,256,58,43,48]

theorem envBound47054 : H12AffineFastState.Bounded env47054 := by
  intro p hp
  have h : env47054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47053_47054 : H12AffineEnvironment.transform 5 58 env47053 = env47054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env47053 == env47054) = true)

theorem identity47054 : scanCanonicalize (H12AffineFastState.compose env47054 (packedSelected [3,4] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound47054 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env47055 : List Nat := [2,4,8,16,17,11,19,256,1,272,26,26,2,1,276,284,27,270,273,277,27,261,17,279,24,10,277,1,1,270,14,17,256,11,26,1]

theorem envBound47055 : H12AffineFastState.Bounded env47055 := by
  intro p hp
  have h : env47055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47054_47055 : H12AffineEnvironment.transform 4 17 env47054 = env47055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env47054 == env47055) = true)

theorem identity47055 : scanCanonicalize (H12AffineFastState.compose env47055 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound47055 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47056 : List Nat := [2,4,8,16,17,11,19,20,1,4,26,26,2,1,0,8,27,26,5,1,27,17,17,3,24,10,1,1,1,26,14,17,20,11,26,1]

theorem envBound47056 : H12AffineFastState.Bounded env47056 := by
  intro p hp
  have h : env47056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47055_47056 : H12AffineEnvironment.transform 7 20 env47055 = env47056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env47055 == env47056) = true)

def env47057 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5385,1297,5204,5159,1345,5286,4416,5205,4097,5276,16,4471,193,5377,1151,1296,1297,7269,5381,1280,256,5376,1345,5953]

theorem envBound47057 : H12AffineFastState.Bounded env47057 := by
  intro p hp
  have h : env47057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47047_47057 : H12AffineEnvironment.transform 12 5385 env47047 = env47057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5385 env47047 == env47057) = true)

theorem identity47057 : scanCanonicalize (H12AffineFastState.compose env47057 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound47057 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env47058 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1029,268,1297,81,34,1345,163,1349,80,1028,153,16,1394,193,260,1151,1296,1297,2144,256,1280,256,261,1345,836]

theorem envBound47058 : H12AffineFastState.Bounded env47058 := by
  intro p hp
  have h : env47058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47057_47058 : H12AffineEnvironment.transform 11 1029 env47057 = env47058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env47057 == env47058) = true)

theorem identity47058 : scanCanonicalize (H12AffineFastState.compose env47058 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound47058 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env47059 : List Nat := [2,4,8,16,32,64,128,68,512,1024,2048,1029,72,1109,81,34,1029,163,1025,80,1028,153,16,1078,193,64,1151,1108,1109,2144,68,1092,68,65,1029,512]

theorem envBound47059 : H12AffineFastState.Bounded env47059 := by
  intro p hp
  have h : env47059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47058_47059 : H12AffineEnvironment.transform 7 68 env47058 = env47059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env47058 == env47059) = true)

theorem identity47059 : scanCanonicalize (H12AffineFastState.compose env47059 (packedSelected [0,2,5,7,8,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound47059 : packedSelected [0,2,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env47060 : List Nat := [2,4,8,16,32,17,128,21,512,1024,2048,1029,25,1028,0,34,1029,163,1025,1,1028,153,16,1078,144,17,1070,1029,1028,2097,21,1045,21,16,1029,512]

theorem envBound47060 : H12AffineFastState.Bounded env47060 := by
  intro p hp
  have h : env47060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47059_47060 : H12AffineEnvironment.transform 5 17 env47059 = env47060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47059 == env47060) = true)

theorem identity47060 : scanCanonicalize (H12AffineFastState.compose env47060 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 167) := by decide +kernel

theorem selectedBound47060 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env47061 : List Nat := [2,4,8,16,32,17,128,21,512,167,2048,162,25,163,0,34,162,163,166,1,163,153,16,145,144,17,137,162,163,2097,21,178,21,16,162,512]

theorem envBound47061 : H12AffineFastState.Bounded env47061 := by
  intro p hp
  have h : env47061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47060_47061 : H12AffineEnvironment.transform 9 167 env47060 = env47061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 167 env47060 == env47061) = true)

theorem identity47061 : scanCanonicalize (H12AffineFastState.compose env47061 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound47061 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env47062 : List Nat := [2,4,8,16,32,17,128,21,137,167,2048,162,25,163,0,34,162,163,166,1,163,153,16,145,144,17,137,162,163,2097,21,178,21,16,162,137]

theorem envBound47062 : H12AffineFastState.Bounded env47062 := by
  intro p hp
  have h : env47062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47061_47062 : H12AffineEnvironment.transform 8 137 env47061 = env47062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env47061 == env47062) = true)

theorem identity47062 : scanCanonicalize (H12AffineFastState.compose env47062 (packedSelected [1,2,3,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound47062 : packedSelected [1,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env47063 : List Nat := [2,4,8,16,32,17,35,21,42,4,2048,1,25,0,0,34,1,0,5,1,0,58,16,50,51,17,42,1,0,2097,21,17,21,16,1,42]

theorem envBound47063 : H12AffineFastState.Bounded env47063 := by
  intro p hp
  have h : env47063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47062_47063 : H12AffineEnvironment.transform 6 35 env47062 = env47063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env47062 == env47063) = true)

theorem identity47063 : scanCanonicalize (H12AffineFastState.compose env47063 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound47063 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47064 : List Nat := [2,4,8,16,22,17,21,21,28,4,2048,1,25,0,0,20,1,0,5,1,0,12,16,4,5,17,28,1,0,2055,21,17,21,16,1,28]

theorem envBound47064 : H12AffineFastState.Bounded env47064 := by
  intro p hp
  have h : env47064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47063_47064 : H12AffineEnvironment.transform 4 22 env47063 = env47064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env47063 == env47064) = true)

theorem identity47064 : scanCanonicalize (H12AffineFastState.compose env47064 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 6) := by decide +kernel

theorem selectedBound47064 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47065 : List Nat := [2,4,8,16,22,17,21,21,28,4,6,1,25,0,0,20,1,0,5,1,0,12,16,4,5,17,28,1,0,1,21,17,21,16,1,28]

theorem envBound47065 : H12AffineFastState.Bounded env47065 := by
  intro p hp
  have h : env47065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47064_47065 : H12AffineEnvironment.transform 10 6 env47064 = env47065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 6 env47064 == env47065) = true)

theorem identity47065 : scanCanonicalize (H12AffineFastState.compose env47065 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound47065 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47066 : List Nat := [2,4,8,10,12,11,15,15,6,4,6,1,3,0,0,14,1,0,5,1,0,12,10,4,5,11,6,1,0,1,15,11,15,10,1,6]

theorem envBound47066 : H12AffineFastState.Bounded env47066 := by
  intro p hp
  have h : env47066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47065_47066 : H12AffineEnvironment.transform 3 10 env47065 = env47066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env47065 == env47066) = true)

theorem identity47066 : scanCanonicalize (H12AffineFastState.compose env47066 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound47066 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env47067 : List Nat := [2,2,8,10,10,11,9,9,0,2,0,1,3,0,0,8,1,0,3,1,0,10,10,2,3,11,0,1,0,1,9,11,9,10,1,0]

theorem envBound47067 : H12AffineFastState.Bounded env47067 := by
  intro p hp
  have h : env47067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47066_47067 : H12AffineEnvironment.transform 1 2 env47066 = env47067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env47066 == env47067) = true)

def env47068 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,524288,32769,4097,61648,91183,123165,533640,614526,385203,90415,545088,96346,25884,618623,256,25881,1345,525825]

theorem envBound47068 : H12AffineFastState.Bounded env47068 := by
  intro p hp
  have h : env47068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46878_47068 : H12AffineEnvironment.transform 23 123165 env46878 = env47068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123165 env46878 == env47068) = true)

def env47069 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21584,32769,4097,61648,91183,123165,28888,78894,385203,90415,1296,96346,25884,74799,256,25881,1345,21073]

theorem envBound47069 : H12AffineFastState.Bounded env47069 := by
  intro p hp
  have h : env47069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47068_47069 : H12AffineEnvironment.transform 18 21584 env47068 = env47069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env47068 == env47069) = true)

theorem identity47069 : scanCanonicalize (H12AffineFastState.compose env47069 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound47069 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env47070 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13341,65536,74863,262144,21584,13340,4097,17613,91183,87296,28888,78894,349358,90415,1296,96346,25884,74799,256,25881,1345,21073]

theorem envBound47070 : H12AffineFastState.Bounded env47070 := by
  intro p hp
  have h : env47070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47069_47070 : H12AffineEnvironment.transform 14 13341 env47069 = env47070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env47069 == env47070) = true)

def env47071 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74863,262144,4416,13340,4097,477,74047,69648,13768,78894,332222,74815,1296,81226,8204,74799,256,8201,1345,5953]

theorem envBound47071 : H12AffineFastState.Bounded env47071 := by
  intro p hp
  have h : env47071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47070_47071 : H12AffineEnvironment.transform 13 1296 env47070 = env47071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env47070 == env47071) = true)

def env47072 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74863,65664,4416,13340,4097,477,74047,69648,13768,78894,4414,74815,1296,81226,8204,74799,256,8201,1345,5953]

theorem envBound47072 : H12AffineFastState.Bounded env47072 := by
  intro p hp
  have h : env47072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47071_47072 : H12AffineEnvironment.transform 17 65664 env47071 = env47072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env47071 == env47072) = true)

theorem identity47072 : scanCanonicalize (H12AffineFastState.compose env47072 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound47072 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env47073 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1296,9244,65536,74863,65664,321,9245,0,477,74047,65553,9673,74799,319,74815,1296,77131,8204,74799,256,8201,1345,1856]

theorem envBound47073 : H12AffineFastState.Bounded env47073 := by
  intro p hp
  have h : env47073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47072_47073 : H12AffineEnvironment.transform 11 1 env47072 = env47073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env47072 == env47073) = true)

def env47074 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,1,8192,1296,9244,65536,74863,65664,321,9245,0,477,74047,65553,9673,74799,319,74815,1296,77131,8204,74799,256,8201,1345,1044]

theorem envBound47074 : H12AffineFastState.Bounded env47074 := by
  intro p hp
  have h : env47074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47073_47074 : H12AffineEnvironment.transform 8 340 env47073 = env47074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env47073 == env47074) = true)

def env47075 : List Nat := [2,4,8,0,32,64,128,256,324,1024,2048,1,8192,1280,9228,65536,74863,65664,321,9229,0,461,74031,65537,9673,74799,303,74799,1280,77131,8204,74799,256,8201,1345,1028]

theorem envBound47075 : H12AffineFastState.Bounded env47075 := by
  intro p hp
  have h : env47075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47074_47075 : H12AffineEnvironment.transform 3 0 env47074 = env47075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env47074 == env47075) = true)

theorem identity47075 : scanCanonicalize (H12AffineFastState.compose env47075 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8457) := by decide +kernel

theorem selectedBound47075 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env47076 : List Nat := [2,4,8,0,32,64,128,256,324,1024,2048,1,8192,1280,9228,8457,1382,8585,321,9229,0,461,38,8456,9673,1318,303,1318,1280,3138,8204,1318,256,8201,1345,1028]

theorem envBound47076 : H12AffineFastState.Bounded env47076 := by
  intro p hp
  have h : env47076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47075_47076 : H12AffineEnvironment.transform 15 8457 env47075 = env47076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8457 env47075 == env47076) = true)

def env47077 : List Nat := [2,4,8,0,32,64,128,4,64,1024,2048,1,8192,1028,9228,8205,1122,8333,69,9229,0,201,38,8204,9421,1058,43,1058,1028,3138,8204,1058,4,8201,1093,1028]

theorem envBound47077 : H12AffineFastState.Bounded env47077 := by
  intro p hp
  have h : env47077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47076_47077 : H12AffineEnvironment.transform 7 4 env47076 = env47077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env47076 == env47077) = true)

theorem identity47077 : scanCanonicalize (H12AffineFastState.compose env47077 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 35) := by decide +kernel

theorem selectedBound47077 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env47078 : List Nat := [2,4,8,0,32,64,128,4,64,35,2048,1,8192,39,8239,8205,65,8333,69,8238,0,201,38,8204,8430,1,43,1,39,2145,8204,1,4,8201,102,39]

theorem envBound47078 : H12AffineFastState.Bounded env47078 := by
  intro p hp
  have h : env47078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47077_47078 : H12AffineEnvironment.transform 9 35 env47077 = env47078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 35 env47077 == env47078) = true)

theorem identity47078 : scanCanonicalize (H12AffineFastState.compose env47078 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 110) := by decide +kernel

theorem selectedBound47078 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env47079 : List Nat := [2,4,8,0,32,64,128,4,64,35,2048,1,110,39,65,99,65,227,69,64,0,201,38,98,128,1,43,1,39,2145,98,1,4,103,102,39]

theorem envBound47079 : H12AffineFastState.Bounded env47079 := by
  intro p hp
  have h : env47079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47078_47079 : H12AffineEnvironment.transform 12 110 env47078 = env47079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 110 env47078 == env47079) = true)

theorem identity47079 : scanCanonicalize (H12AffineFastState.compose env47079 (packedSelected [0,1,7,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 64) := by decide +kernel

theorem selectedBound47079 : packedSelected [0,1,7,8,11] rootPS < 2^1333 := by decide +kernel

def env47080 : List Nat := [2,4,8,0,32,64,128,4,64,35,64,1,110,39,65,99,65,227,69,64,0,201,38,98,128,1,43,1,39,33,98,1,4,103,102,39]

theorem envBound47080 : H12AffineFastState.Bounded env47080 := by
  intro p hp
  have h : env47080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47079_47080 : H12AffineEnvironment.transform 10 64 env47079 = env47080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 64 env47079 == env47080) = true)

theorem identity47080 : scanCanonicalize (H12AffineFastState.compose env47080 (packedSelected [1,3,8] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound47080 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env47081 : List Nat := [2,4,8,0,7,64,128,4,64,4,64,1,73,0,65,68,65,196,69,64,0,201,1,69,128,1,12,1,0,6,69,1,4,64,65,0]

theorem envBound47081 : H12AffineFastState.Bounded env47081 := by
  intro p hp
  have h : env47081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47080_47081 : H12AffineEnvironment.transform 4 7 env47080 = env47081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env47080 == env47081) = true)

theorem identity47081 : scanCanonicalize (H12AffineFastState.compose env47081 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound47081 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env47082 : List Nat := [2,4,8,0,7,64,5,4,64,4,64,1,73,0,65,68,65,65,69,64,0,76,1,69,5,1,12,1,0,6,69,1,4,64,65,0]

theorem envBound47082 : H12AffineFastState.Bounded env47082 := by
  intro p hp
  have h : env47082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47081_47082 : H12AffineEnvironment.transform 6 5 env47081 = env47082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env47081 == env47082) = true)

theorem identity47082 : scanCanonicalize (H12AffineFastState.compose env47082 (packedSelected [1,2] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound47082 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env47083 : List Nat := [2,4,8,0,7,12,5,4,12,4,12,1,5,0,13,8,13,13,9,12,0,0,1,9,5,1,12,1,0,6,9,1,4,12,13,0]

theorem envBound47083 : H12AffineFastState.Bounded env47083 := by
  intro p hp
  have h : env47083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47082_47083 : H12AffineEnvironment.transform 5 12 env47082 = env47083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env47082 == env47083) = true)

theorem identity47083 : scanCanonicalize (H12AffineFastState.compose env47083 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound47083 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env47084 : List Nat := [2,4,2,0,7,6,5,4,6,4,6,1,5,0,7,2,7,7,3,6,0,0,1,3,5,1,6,1,0,6,3,1,4,6,7,0]

theorem envBound47084 : H12AffineFastState.Bounded env47084 := by
  intro p hp
  have h : env47084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47083_47084 : H12AffineEnvironment.transform 2 2 env47083 = env47084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env47083 == env47084) = true)

def env47085 : List Nat := [2,4,8,0,32,64,128,5,65,1024,2048,1,8192,1029,9228,8204,1123,8332,68,9229,0,200,38,8205,9420,1059,42,1059,1029,3138,8204,1059,5,8201,1092,1028]

theorem envBound47085 : H12AffineFastState.Bounded env47085 := by
  intro p hp
  have h : env47085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47076_47085 : H12AffineEnvironment.transform 7 5 env47076 = env47085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env47076 == env47085) = true)

theorem identity47085 : scanCanonicalize (H12AffineFastState.compose env47085 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound47085 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env47086 : List Nat := [2,4,8,0,32,64,128,5,65,1024,2048,1,8,1029,1028,4,1123,132,68,1029,0,200,38,5,1220,1059,42,1059,1029,3138,4,1059,5,1,1092,1028]

theorem envBound47086 : H12AffineFastState.Bounded env47086 := by
  intro p hp
  have h : env47086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47085_47086 : H12AffineEnvironment.transform 12 8 env47085 = env47086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env47085 == env47086) = true)

theorem identity47086 : scanCanonicalize (H12AffineFastState.compose env47086 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound47086 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env47087 : List Nat := [2,4,8,0,32,64,128,5,65,69,2048,1,8,64,65,4,38,132,68,64,0,200,38,5,129,102,42,102,64,2055,4,102,5,1,1,65]

theorem envBound47087 : H12AffineFastState.Bounded env47087 := by
  intro p hp
  have h : env47087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47086_47087 : H12AffineEnvironment.transform 9 69 env47086 = env47087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env47086 == env47087) = true)

theorem identity47087 : scanCanonicalize (H12AffineFastState.compose env47087 (packedSelected [0,1,2,3,7,8,10,11,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 13) := by decide +kernel

theorem selectedBound47087 : packedSelected [0,1,2,3,7,8,10,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env47088 : List Nat := [2,4,8,0,32,64,128,5,65,69,13,1,8,64,65,4,38,132,68,64,0,200,38,5,129,102,42,102,64,10,4,102,5,1,1,65]

theorem envBound47088 : H12AffineFastState.Bounded env47088 := by
  intro p hp
  have h : env47088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47087_47088 : H12AffineEnvironment.transform 10 13 env47087 = env47088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 13 env47087 == env47088) = true)

theorem identity47088 : scanCanonicalize (H12AffineFastState.compose env47088 (packedSelected [0,1,2,5,7,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound47088 : packedSelected [0,1,2,5,7,11,12] rootPS < 2^1333 := by decide +kernel

def env47089 : List Nat := [2,4,8,0,32,64,14,5,65,69,13,1,8,64,65,4,38,10,68,64,0,70,38,5,15,102,42,102,64,10,4,102,5,1,1,65]

theorem envBound47089 : H12AffineFastState.Bounded env47089 := by
  intro p hp
  have h : env47089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47088_47089 : H12AffineEnvironment.transform 6 14 env47088 = env47089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env47088 == env47089) = true)

theorem identity47089 : scanCanonicalize (H12AffineFastState.compose env47089 (packedSelected [0,1,3,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 45) := by decide +kernel

theorem selectedBound47089 : packedSelected [0,1,3,4,5] rootPS < 2^1333 := by decide +kernel

def env47090 : List Nat := [2,4,8,0,32,45,14,5,44,40,13,1,8,45,44,4,38,10,41,45,0,43,38,5,15,11,42,11,45,10,4,11,5,1,1,44]

theorem envBound47090 : H12AffineFastState.Bounded env47090 := by
  intro p hp
  have h : env47090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47089_47090 : H12AffineEnvironment.transform 5 45 env47089 = env47090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 45 env47089 == env47090) = true)

theorem identity47090 : scanCanonicalize (H12AffineFastState.compose env47090 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound47090 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env47091 : List Nat := [2,4,8,0,0,13,14,5,12,8,13,1,8,13,12,4,6,10,9,13,0,11,6,5,15,11,10,11,13,10,4,11,5,1,1,12]

theorem envBound47091 : H12AffineFastState.Bounded env47091 := by
  intro p hp
  have h : env47091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47090_47091 : H12AffineEnvironment.transform 4 0 env47090 = env47091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env47090 == env47091) = true)

def env47092 : List Nat := [2,4,8,1,32,64,128,256,325,1024,2048,1,8192,1281,9229,65536,74863,65664,321,9228,0,460,74030,65536,9673,74799,302,74798,1281,77131,8204,74799,256,8201,1345,1029]

theorem envBound47092 : H12AffineFastState.Bounded env47092 := by
  intro p hp
  have h : env47092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47074_47092 : H12AffineEnvironment.transform 3 1 env47074 = env47092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env47074 == env47092) = true)

theorem identity47092 : scanCanonicalize (H12AffineFastState.compose env47092 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 1025) := by decide +kernel

theorem selectedBound47092 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env47093 : List Nat := [2,4,8,1,32,64,128,256,325,1024,2048,1,8192,1281,9229,1025,8302,1153,321,9228,0,460,9519,1025,9673,8238,302,8239,1281,10570,8204,8238,256,8201,1345,1029]

theorem envBound47093 : H12AffineFastState.Bounded env47093 := by
  intro p hp
  have h : env47093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47092_47093 : H12AffineEnvironment.transform 15 1025 env47092 = env47093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1025 env47092 == env47093) = true)

def env47094 : List Nat := [2,4,8,1,32,64,128,256,325,1024,2048,1,1320,1281,293,1025,1350,1153,321,292,0,460,7,1025,225,1286,302,1287,1281,3170,1316,1286,256,1313,1345,1029]

theorem envBound47094 : H12AffineFastState.Bounded env47094 := by
  intro p hp
  have h : env47094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47093_47094 : H12AffineEnvironment.transform 12 1320 env47093 = env47094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1320 env47093 == env47094) = true)

theorem identity47094 : scanCanonicalize (H12AffineFastState.compose env47094 (packedSelected [0,4,5,7,9,13,15,16,20,21,41] rootPS)) = affineNative (2^(9+1) ^^^ 294) := by decide +kernel

theorem selectedBound47094 : packedSelected [0,4,5,7,9,13,15,16,20,21,41] rootPS < 2^1333 := by decide +kernel

def env47095 : List Nat := [2,4,8,1,32,64,128,256,325,294,2048,1,14,39,293,295,96,423,321,292,0,460,7,295,225,32,302,33,39,2372,2,32,256,7,103,291]

theorem envBound47095 : H12AffineFastState.Bounded env47095 := by
  intro p hp
  have h : env47095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47094_47095 : H12AffineEnvironment.transform 9 294 env47094 = env47095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 294 env47094 == env47095) = true)

theorem identity47095 : scanCanonicalize (H12AffineFastState.compose env47095 (packedSelected [2,3,5,10,11,12,13,15,18] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound47095 : packedSelected [2,3,5,10,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env47096 : List Nat := [2,4,8,1,32,0,128,256,261,294,2048,1,14,39,293,295,32,423,257,292,0,396,7,295,161,32,302,33,39,2308,2,32,256,7,39,291]

theorem envBound47096 : H12AffineFastState.Bounded env47096 := by
  intro p hp
  have h : env47096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47095_47096 : H12AffineEnvironment.transform 5 0 env47095 = env47096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env47095 == env47096) = true)

theorem identity47096 : scanCanonicalize (H12AffineFastState.compose env47096 (packedSelected [1,3,4,9,13,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound47096 : packedSelected [1,3,4,9,13,15,16] rootPS < 2^1333 := by decide +kernel

def env47097 : List Nat := [2,4,8,1,32,0,128,256,261,294,43,1,14,39,293,295,32,423,257,292,0,396,7,295,161,32,302,33,39,303,2,32,256,7,39,291]

theorem envBound47097 : H12AffineFastState.Bounded env47097 := by
  intro p hp
  have h : env47097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47096_47097 : H12AffineEnvironment.transform 10 43 env47096 = env47097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env47096 == env47097) = true)

theorem identity47097 : scanCanonicalize (H12AffineFastState.compose env47097 (packedSelected [0,1,7,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 36) := by decide +kernel

theorem selectedBound47097 : packedSelected [0,1,7,10,11] rootPS < 2^1333 := by decide +kernel

def env47098 : List Nat := [2,4,8,1,32,0,36,256,261,294,43,1,14,39,293,295,32,259,257,292,0,296,7,295,5,32,302,33,39,303,2,32,256,7,39,291]

theorem envBound47098 : H12AffineFastState.Bounded env47098 := by
  intro p hp
  have h : env47098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47097_47098 : H12AffineEnvironment.transform 6 36 env47097 = env47098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 36 env47097 == env47098) = true)

theorem identity47098 : scanCanonicalize (H12AffineFastState.compose env47098 (packedSelected [0,1,4] rootPS)) = affineNative (2^(7+1) ^^^ 8) := by decide +kernel

theorem selectedBound47098 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env47099 : List Nat := [2,4,8,1,32,0,36,8,13,46,43,1,14,39,45,47,32,11,9,44,0,32,7,47,5,32,38,33,39,39,2,32,8,7,39,43]

theorem envBound47099 : H12AffineFastState.Bounded env47099 := by
  intro p hp
  have h : env47099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47098_47099 : H12AffineEnvironment.transform 7 8 env47098 = env47099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 8 env47098 == env47099) = true)

theorem identity47099 : scanCanonicalize (H12AffineFastState.compose env47099 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound47099 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env47100 : List Nat := [2,4,8,1,6,0,2,8,13,8,13,1,14,1,11,9,6,11,9,10,0,6,7,9,5,6,0,7,1,1,2,6,8,7,1,13]

theorem envBound47100 : H12AffineFastState.Bounded env47100 := by
  intro p hp
  have h : env47100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47099_47100 : H12AffineEnvironment.transform 4 6 env47099 = env47100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env47099 == env47100) = true)

theorem identity47100 : scanCanonicalize (H12AffineFastState.compose env47100 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound47100 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47101 : List Nat := [2,2,8,1,0,0,2,8,11,8,11,1,8,1,11,9,0,11,9,10,0,0,1,9,3,0,0,1,1,1,2,0,8,1,1,11]

theorem envBound47101 : H12AffineFastState.Bounded env47101 := by
  intro p hp
  have h : env47101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47100_47101 : H12AffineEnvironment.transform 1 2 env47100 = env47101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env47100 == env47101) = true)

theorem identity47101 : scanCanonicalize (H12AffineFastState.compose env47101 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound47101 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47102 : List Nat := [2,2,2,1,0,0,2,2,1,2,1,1,2,1,1,3,0,1,3,0,0,0,1,3,3,0,0,1,1,1,2,0,2,1,1,1]

theorem envBound47102 : H12AffineFastState.Bounded env47102 := by
  intro p hp
  have h : env47102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47101_47102 : H12AffineEnvironment.transform 2 2 env47101 = env47102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env47101 == env47102) = true)

def env47103 : List Nat := [2,4,8,1,32,64,128,256,325,1024,2048,1,1321,1281,292,1025,1351,1153,321,293,0,460,6,1025,224,1287,302,1286,1281,3171,1317,1287,256,1312,1345,1029]

theorem envBound47103 : H12AffineFastState.Bounded env47103 := by
  intro p hp
  have h : env47103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47093_47103 : H12AffineEnvironment.transform 12 1321 env47093 = env47103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1321 env47093 == env47103) = true)

theorem identity47103 : scanCanonicalize (H12AffineFastState.compose env47103 (packedSelected [0,4,5,7,9,13,15,16,20,21,41] rootPS)) = affineNative (2^(9+1) ^^^ 289) := by decide +kernel

theorem selectedBound47103 : packedSelected [0,4,5,7,9,13,15,16,20,21,41] rootPS < 2^1333 := by decide +kernel

def env47104 : List Nat := [2,4,8,1,32,64,128,256,325,289,2048,1,8,32,292,288,102,416,321,293,0,460,6,288,224,38,302,39,32,2370,4,38,256,1,96,292]

theorem envBound47104 : H12AffineFastState.Bounded env47104 := by
  intro p hp
  have h : env47104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47103_47104 : H12AffineEnvironment.transform 9 289 env47103 = env47104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 289 env47103 == env47104) = true)

theorem identity47104 : scanCanonicalize (H12AffineFastState.compose env47104 (packedSelected [1,2,3,10,11,13,15,16,17,19,20,23] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound47104 : packedSelected [1,2,3,10,11,13,15,16,17,19,20,23] rootPS < 2^1333 := by decide +kernel

def env47105 : List Nat := [2,4,8,1,32,64,3,256,325,289,2048,1,8,32,292,288,102,291,321,293,0,335,6,288,99,38,302,39,32,2370,4,38,256,1,96,292]

theorem envBound47105 : H12AffineFastState.Bounded env47105 := by
  intro p hp
  have h : env47105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47104_47105 : H12AffineEnvironment.transform 6 3 env47104 = env47105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env47104 == env47105) = true)

theorem identity47105 : scanCanonicalize (H12AffineFastState.compose env47105 (packedSelected [5,11,12,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 111) := by decide +kernel

theorem selectedBound47105 : packedSelected [5,11,12,13,17] rootPS < 2^1333 := by decide +kernel

def env47106 : List Nat := [2,4,8,1,32,64,3,111,42,78,2048,1,8,32,75,79,102,76,46,74,0,32,6,79,99,38,65,39,32,2093,4,38,111,1,96,75]

theorem envBound47106 : H12AffineFastState.Bounded env47106 := by
  intro p hp
  have h : env47106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47105_47106 : H12AffineEnvironment.transform 7 111 env47105 = env47106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 111 env47105 == env47106) = true)

theorem identity47106 : scanCanonicalize (H12AffineFastState.compose env47106 (packedSelected [0,3,4,8,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 42) := by decide +kernel

theorem selectedBound47106 : packedSelected [0,3,4,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env47107 : List Nat := [2,4,8,1,32,42,3,5,42,36,2048,1,8,32,33,37,12,38,46,32,0,32,6,37,9,38,43,39,32,2093,4,38,5,1,10,33]

theorem envBound47107 : H12AffineFastState.Bounded env47107 := by
  intro p hp
  have h : env47107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47106_47107 : H12AffineEnvironment.transform 5 42 env47106 = env47107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 42 env47106 == env47107) = true)

theorem identity47107 : scanCanonicalize (H12AffineFastState.compose env47107 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound47107 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env47108 : List Nat := [2,4,8,1,32,42,3,5,42,36,42,1,8,32,33,37,12,38,46,32,0,32,6,37,9,38,43,39,32,7,4,38,5,1,10,33]

theorem envBound47108 : H12AffineFastState.Bounded env47108 := by
  intro p hp
  have h : env47108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47107_47108 : H12AffineEnvironment.transform 10 42 env47107 = env47108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env47107 == env47108) = true)

theorem identity47108 : scanCanonicalize (H12AffineFastState.compose env47108 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound47108 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env47109 : List Nat := [2,4,8,1,6,12,3,5,12,2,12,1,8,6,7,3,12,0,8,6,0,6,6,3,9,0,13,1,6,7,4,0,5,1,10,7]

theorem envBound47109 : H12AffineFastState.Bounded env47109 := by
  intro p hp
  have h : env47109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47108_47109 : H12AffineEnvironment.transform 4 6 env47108 = env47109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env47108 == env47109) = true)

theorem identity47109 : scanCanonicalize (H12AffineFastState.compose env47109 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound47109 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47110 : List Nat := [2,2,8,1,0,10,3,3,10,2,10,1,8,0,1,3,10,0,8,0,0,0,0,3,9,0,11,1,0,1,2,0,3,1,10,1]

theorem envBound47110 : H12AffineFastState.Bounded env47110 := by
  intro p hp
  have h : env47110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47109_47110 : H12AffineEnvironment.transform 1 2 env47109 = env47110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env47109 == env47110) = true)

def env47111 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,1,8192,1296,9244,65536,74863,65664,321,9245,0,477,74047,65553,9673,74799,319,74815,1296,77131,8204,74799,256,8201,1345,1045]

theorem envBound47111 : H12AffineFastState.Bounded env47111 := by
  intro p hp
  have h : env47111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47073_47111 : H12AffineEnvironment.transform 8 341 env47073 = env47111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env47073 == env47111) = true)

def env47112 : List Nat := [2,4,8,0,32,64,128,256,325,1024,2048,1,8192,1280,9228,65536,74863,65664,321,9229,0,461,74031,65537,9673,74799,303,74799,1280,77131,8204,74799,256,8201,1345,1029]

theorem envBound47112 : H12AffineFastState.Bounded env47112 := by
  intro p hp
  have h : env47112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47111_47112 : H12AffineEnvironment.transform 3 0 env47111 = env47112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env47111 == env47112) = true)

theorem identity47112 : scanCanonicalize (H12AffineFastState.compose env47112 (packedSelected [1,8,28] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound47112 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env47113 : List Nat := [2,4,8,0,6,64,128,256,325,1024,2048,1,8192,1280,9228,65536,74825,65664,321,9229,0,461,73993,65537,9673,74761,265,74761,1280,77131,8204,74761,256,8201,1345,1029]

theorem envBound47113 : H12AffineFastState.Bounded env47113 := by
  intro p hp
  have h : env47113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47112_47113 : H12AffineEnvironment.transform 4 6 env47112 = env47113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env47112 == env47113) = true)

def env47114 : List Nat := [2,4,8,0,6,64,128,256,325,1024,2048,1,8192,1280,9228,8456,1345,8584,321,9229,0,461,1,8457,9673,1281,265,1281,1280,3139,8204,1281,256,8201,1345,1029]

theorem envBound47114 : H12AffineFastState.Bounded env47114 := by
  intro p hp
  have h : env47114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47113_47114 : H12AffineEnvironment.transform 15 8456 env47113 = env47114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8456 env47113 == env47114) = true)

theorem identity47114 : scanCanonicalize (H12AffineFastState.compose env47114 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 1352) := by decide +kernel

theorem selectedBound47114 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env47115 : List Nat := [2,4,8,0,6,64,128,256,325,1024,2048,1,1352,1280,324,1088,1345,1216,321,325,0,461,1,1089,129,1281,265,1281,1280,3139,1348,1281,256,1345,1345,1029]

theorem envBound47115 : H12AffineFastState.Bounded env47115 := by
  intro p hp
  have h : env47115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47114_47115 : H12AffineEnvironment.transform 12 1352 env47114 = env47115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1352 env47114 == env47115) = true)

theorem identity47115 : scanCanonicalize (H12AffineFastState.compose env47115 (packedSelected [0,1,4,7,8,9,10,12,13,16,20] rootPS)) = affineNative (2^(10+1) ^^^ 1412) := by decide +kernel

theorem selectedBound47115 : packedSelected [0,1,4,7,8,9,10,12,13,16,20] rootPS < 2^1333 := by decide +kernel

def env47116 : List Nat := [2,4,8,0,6,64,128,256,325,1024,1412,1,1352,1280,324,1088,1345,1216,321,325,0,461,1,1089,129,1281,265,1281,1280,455,1348,1281,256,1345,1345,1029]

theorem envBound47116 : H12AffineFastState.Bounded env47116 := by
  intro p hp
  have h : env47116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47115_47116 : H12AffineEnvironment.transform 10 1412 env47115 = env47116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1412 env47115 == env47116) = true)

theorem identity47116 : scanCanonicalize (H12AffineFastState.compose env47116 (packedSelected [13,15] rootPS)) = affineNative (2^(9+1) ^^^ 399) := by decide +kernel

theorem selectedBound47116 : packedSelected [13,15] rootPS < 2^1333 := by decide +kernel

def env47117 : List Nat := [2,4,8,0,6,64,128,256,325,399,11,1,199,143,324,463,206,335,321,325,0,461,1,462,129,142,265,142,143,455,203,142,256,206,206,394]

theorem envBound47117 : H12AffineFastState.Bounded env47117 := by
  intro p hp
  have h : env47117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47116_47117 : H12AffineEnvironment.transform 9 399 env47116 = env47117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 399 env47116 == env47117) = true)

theorem identity47117 : scanCanonicalize (H12AffineFastState.compose env47117 (packedSelected [1,2,3,4,5,9,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound47117 : packedSelected [1,2,3,4,5,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env47118 : List Nat := [2,4,8,0,6,0,128,256,261,399,11,1,135,143,260,399,142,271,257,261,0,397,1,398,129,142,265,142,143,391,139,142,256,142,142,394]

theorem envBound47118 : H12AffineFastState.Bounded env47118 := by
  intro p hp
  have h : env47118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47117_47118 : H12AffineEnvironment.transform 5 0 env47117 = env47118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env47117 == env47118) = true)

theorem identity47118 : scanCanonicalize (H12AffineFastState.compose env47118 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 135) := by decide +kernel

theorem selectedBound47118 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env47119 : List Nat := [2,4,8,0,6,0,128,135,130,8,11,1,135,143,131,8,142,136,134,130,0,10,1,9,129,142,142,142,143,0,139,142,135,142,142,13]

theorem envBound47119 : H12AffineFastState.Bounded env47119 := by
  intro p hp
  have h : env47119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47118_47119 : H12AffineEnvironment.transform 7 135 env47118 = env47119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 135 env47118 == env47119) = true)

theorem identity47119 : scanCanonicalize (H12AffineFastState.compose env47119 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound47119 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47120 : List Nat := [2,4,8,0,6,0,4,3,6,8,11,1,3,11,7,8,10,12,2,6,0,10,1,9,5,10,10,10,11,0,15,10,3,10,10,13]

theorem envBound47120 : H12AffineFastState.Bounded env47120 := by
  intro p hp
  have h : env47120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47119_47120 : H12AffineEnvironment.transform 6 4 env47119 = env47120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env47119 == env47120) = true)

theorem identity47120 : scanCanonicalize (H12AffineFastState.compose env47120 (packedSelected [0,2,4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound47120 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env47121 : List Nat := [2,4,2,0,6,0,4,3,6,2,1,1,3,1,7,2,0,6,2,6,0,0,1,3,5,0,0,0,1,0,5,0,3,0,0,7]

theorem envBound47121 : H12AffineFastState.Bounded env47121 := by
  intro p hp
  have h : env47121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47120_47121 : H12AffineEnvironment.transform 2 2 env47120 = env47121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env47120 == env47121) = true)

theorem identity47121 : scanCanonicalize (H12AffineFastState.compose env47121 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound47121 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47122 : List Nat := [1,4,1,0,5,0,4,0,5,1,1,1,0,1,4,1,0,5,1,5,0,0,1,0,5,0,0,0,1,0,5,0,0,0,0,4]

theorem envBound47122 : H12AffineFastState.Bounded env47122 := by
  intro p hp
  have h : env47122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47121_47122 : H12AffineEnvironment.transform 0 1 env47121 = env47122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env47121 == env47122) = true)

theorem identity47122 : scanCanonicalize (H12AffineFastState.compose env47122 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound47122 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47123 : List Nat := [1,1,1,0,0,0,1,0,0,1,1,1,0,1,1,1,0,0,1,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,0,1]

theorem envBound47123 : H12AffineFastState.Bounded env47123 := by
  intro p hp
  have h : env47123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47122_47123 : H12AffineEnvironment.transform 1 1 env47122 = env47123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env47122 == env47123) = true)

def env47124 : List Nat := [2,4,8,0,6,64,128,256,325,1024,2048,1,8192,1280,9228,8457,1344,8585,321,9229,0,461,0,8456,9673,1280,265,1280,1280,3138,8204,1280,256,8201,1345,1029]

theorem envBound47124 : H12AffineFastState.Bounded env47124 := by
  intro p hp
  have h : env47124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47113_47124 : H12AffineEnvironment.transform 15 8457 env47113 = env47124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8457 env47113 == env47124) = true)

theorem identity47124 : scanCanonicalize (H12AffineFastState.compose env47124 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound47124 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env47125 : List Nat := [2,4,8,0,6,64,128,256,325,1024,2048,1,1101,1280,65,1348,1344,1476,321,64,0,461,0,1349,388,1280,265,1280,1280,3138,1089,1280,256,1092,1345,1029]

theorem envBound47125 : H12AffineFastState.Bounded env47125 := by
  intro p hp
  have h : env47125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47124_47125 : H12AffineEnvironment.transform 12 1101 env47124 = env47125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env47124 == env47125) = true)

theorem identity47125 : scanCanonicalize (H12AffineFastState.compose env47125 (packedSelected [0,1,3,7,8,10,17,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound47125 : packedSelected [0,1,3,7,8,10,17,19,20] rootPS < 2^1333 := by decide +kernel

def env47126 : List Nat := [2,4,8,0,6,64,128,5,64,1024,2048,1,1101,1029,65,1089,1093,1217,68,64,0,200,0,1088,129,1029,12,1029,1029,3138,1089,1029,5,1092,1092,1029]

theorem envBound47126 : H12AffineFastState.Bounded env47126 := by
  intro p hp
  have h : env47126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47125_47126 : H12AffineEnvironment.transform 7 5 env47125 = env47126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env47125 == env47126) = true)

theorem identity47126 : scanCanonicalize (H12AffineFastState.compose env47126 (packedSelected [1,2,3,5,15] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound47126 : packedSelected [1,2,3,5,15] rootPS < 2^1333 := by decide +kernel

def env47127 : List Nat := [2,4,8,0,6,0,128,5,0,1024,2048,1,1037,1029,1,1025,1029,1153,4,0,0,136,0,1024,129,1029,12,1029,1029,3074,1025,1029,5,1028,1028,1029]

theorem envBound47127 : H12AffineFastState.Bounded env47127 := by
  intro p hp
  have h : env47127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47126_47127 : H12AffineEnvironment.transform 5 0 env47126 = env47127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env47126 == env47127) = true)

theorem identity47127 : scanCanonicalize (H12AffineFastState.compose env47127 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound47127 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env47128 : List Nat := [2,4,5,0,6,0,128,5,0,1024,2048,1,1024,1029,1,1025,1029,1153,4,0,0,133,0,1024,129,1029,1,1029,1029,3074,1025,1029,5,1028,1028,1029]

theorem envBound47128 : H12AffineFastState.Bounded env47128 := by
  intro p hp
  have h : env47128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47127_47128 : H12AffineEnvironment.transform 2 5 env47127 = env47128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env47127 == env47128) = true)

theorem identity47128 : scanCanonicalize (H12AffineFastState.compose env47128 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1152) := by decide +kernel

theorem selectedBound47128 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env47129 : List Nat := [2,4,5,0,6,0,128,5,0,1024,1152,1,1024,1029,1,1025,1029,1153,4,0,0,133,0,1024,129,1029,1,1029,1029,130,1025,1029,5,1028,1028,1029]

theorem envBound47129 : H12AffineFastState.Bounded env47129 := by
  intro p hp
  have h : env47129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47128_47129 : H12AffineEnvironment.transform 10 1152 env47128 = env47129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1152 env47128 == env47129) = true)

theorem identity47129 : scanCanonicalize (H12AffineFastState.compose env47129 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound47129 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47130 : List Nat := [2,4,5,0,6,0,4,5,0,1024,1028,1,1024,1029,1,1025,1029,1029,4,0,0,1,0,1024,5,1029,1,1029,1029,6,1025,1029,5,1028,1028,1029]

theorem envBound47130 : H12AffineFastState.Bounded env47130 := by
  intro p hp
  have h : env47130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47129_47130 : H12AffineEnvironment.transform 6 4 env47129 = env47130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env47129 == env47130) = true)

theorem identity47130 : scanCanonicalize (H12AffineFastState.compose env47130 (packedSelected [0,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 3) := by decide +kernel

theorem selectedBound47130 : packedSelected [0,5,7] rootPS < 2^1333 := by decide +kernel

def env47131 : List Nat := [2,4,5,0,6,0,4,5,0,3,7,1,3,6,1,2,6,6,4,0,0,1,0,3,5,6,1,6,6,6,2,6,5,7,7,6]

theorem envBound47131 : H12AffineFastState.Bounded env47131 := by
  intro p hp
  have h : env47131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47130_47131 : H12AffineEnvironment.transform 9 3 env47130 = env47131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 3 env47130 == env47131) = true)

def env47132 : List Nat := [2,4,8,1,32,64,128,256,324,1024,2048,1,8192,1281,9229,65536,74863,65664,321,9228,0,460,74030,65536,9673,74799,302,74798,1281,77131,8204,74799,256,8201,1345,1028]

theorem envBound47132 : H12AffineFastState.Bounded env47132 := by
  intro p hp
  have h : env47132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47111_47132 : H12AffineEnvironment.transform 3 1 env47111 = env47132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env47111 == env47132) = true)

theorem identity47132 : scanCanonicalize (H12AffineFastState.compose env47132 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 1326) := by decide +kernel

theorem selectedBound47132 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env47133 : List Nat := [2,4,8,1,32,64,128,256,324,1024,2048,1,1326,1281,291,65536,65857,65664,321,290,0,460,66560,65536,231,65793,302,65792,1281,67685,1314,65793,256,1319,1345,1028]

theorem envBound47133 : H12AffineFastState.Bounded env47133 := by
  intro p hp
  have h : env47133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47132_47133 : H12AffineEnvironment.transform 12 1326 env47132 = env47133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1326 env47132 == env47133) = true)

def env47134 : List Nat := [2,4,8,1,32,64,128,256,324,320,2048,1,110,65,291,65536,65857,65664,321,290,0,460,65856,65536,231,65793,302,65792,65,67685,98,65793,256,103,1,324]

theorem envBound47134 : H12AffineFastState.Bounded env47134 := by
  intro p hp
  have h : env47134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47133_47134 : H12AffineEnvironment.transform 9 320 env47133 = env47134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env47133 == env47134) = true)

theorem identity47134 : scanCanonicalize (H12AffineFastState.compose env47134 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 98) := by decide +kernel

theorem selectedBound47134 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env47135 : List Nat := [2,4,8,1,32,64,128,256,324,320,2048,1,110,65,291,98,291,226,321,290,0,460,290,98,231,355,302,354,65,2055,98,355,256,103,1,324]

theorem envBound47135 : H12AffineFastState.Bounded env47135 := by
  intro p hp
  have h : env47135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47134_47135 : H12AffineEnvironment.transform 15 98 env47134 = env47135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 98 env47134 == env47135) = true)

theorem identity47135 : scanCanonicalize (H12AffineFastState.compose env47135 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 99) := by decide +kernel

theorem selectedBound47135 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env47136 : List Nat := [2,4,8,1,32,64,128,99,39,35,2048,1,110,65,64,98,64,226,34,65,0,175,65,98,231,0,77,1,65,2055,98,0,99,103,1,39]

theorem envBound47136 : H12AffineFastState.Bounded env47136 := by
  intro p hp
  have h : env47136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47135_47136 : H12AffineEnvironment.transform 7 99 env47135 = env47136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 99 env47135 == env47136) = true)

theorem identity47136 : scanCanonicalize (H12AffineFastState.compose env47136 (packedSelected [5,10] rootPS)) = affineNative (2^(10+1) ^^^ 65) := by decide +kernel

theorem selectedBound47136 : packedSelected [5,10] rootPS < 2^1333 := by decide +kernel

def env47137 : List Nat := [2,4,8,1,32,64,128,99,39,35,65,1,110,65,64,98,64,226,34,65,0,175,65,98,231,0,77,1,65,70,98,0,99,103,1,39]

theorem envBound47137 : H12AffineFastState.Bounded env47137 := by
  intro p hp
  have h : env47137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47136_47137 : H12AffineEnvironment.transform 10 65 env47136 = env47137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 65 env47136 == env47137) = true)

theorem identity47137 : scanCanonicalize (H12AffineFastState.compose env47137 (packedSelected [0,1,12] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound47137 : packedSelected [0,1,12] rootPS < 2^1333 := by decide +kernel

def env47138 : List Nat := [2,4,4,1,32,64,128,99,39,35,65,1,98,65,64,98,64,226,34,65,0,163,65,98,231,0,65,1,65,70,98,0,99,103,1,39]

theorem envBound47138 : H12AffineFastState.Bounded env47138 := by
  intro p hp
  have h : env47138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47137_47138 : H12AffineEnvironment.transform 2 4 env47137 = env47138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env47137 == env47138) = true)

theorem identity47138 : scanCanonicalize (H12AffineFastState.compose env47138 (packedSelected [7] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound47138 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env47139 : List Nat := [2,4,4,1,32,64,5,99,39,35,65,1,98,65,64,98,64,103,34,65,0,38,65,98,98,0,65,1,65,70,98,0,99,103,1,39]

theorem envBound47139 : H12AffineFastState.Bounded env47139 := by
  intro p hp
  have h : env47139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47138_47139 : H12AffineEnvironment.transform 6 5 env47138 = env47139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env47138 == env47139) = true)

theorem identity47139 : scanCanonicalize (H12AffineFastState.compose env47139 (packedSelected [1,2] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound47139 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env47140 : List Nat := [2,4,4,1,32,1,5,34,39,35,0,1,35,0,1,35,1,38,34,0,0,38,0,35,35,0,0,1,0,7,35,0,34,38,1,39]

theorem envBound47140 : H12AffineFastState.Bounded env47140 := by
  intro p hp
  have h : env47140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47139_47140 : H12AffineEnvironment.transform 5 1 env47139 = env47140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env47139 == env47140) = true)

theorem identity47140 : scanCanonicalize (H12AffineFastState.compose env47140 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound47140 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env47141 : List Nat := [2,4,4,1,7,1,5,5,0,4,0,1,4,0,1,4,1,1,5,0,0,1,0,4,4,0,0,1,0,7,4,0,5,1,1,0]

theorem envBound47141 : H12AffineFastState.Bounded env47141 := by
  intro p hp
  have h : env47141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47140_47141 : H12AffineEnvironment.transform 4 7 env47140 = env47141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env47140 == env47141) = true)

def env47142 : List Nat := [2,4,8,1,32,64,128,256,324,321,2048,1,111,64,291,65536,65857,65664,321,290,0,460,65857,65536,231,65793,302,65792,64,67685,99,65793,256,102,0,325]

theorem envBound47142 : H12AffineFastState.Bounded env47142 := by
  intro p hp
  have h : env47142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47133_47142 : H12AffineEnvironment.transform 9 321 env47133 = env47142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env47133 == env47142) = true)

theorem identity47142 : scanCanonicalize (H12AffineFastState.compose env47142 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 99) := by decide +kernel

theorem selectedBound47142 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env47143 : List Nat := [2,4,8,1,32,64,128,99,39,34,2048,1,111,64,64,65536,65570,65664,34,65,0,175,65570,65536,231,65634,77,65635,64,67685,99,65634,99,102,0,38]

theorem envBound47143 : H12AffineFastState.Bounded env47143 := by
  intro p hp
  have h : env47143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47142_47143 : H12AffineEnvironment.transform 7 99 env47142 = env47143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 99 env47142 == env47143) = true)

theorem identity47143 : scanCanonicalize (H12AffineFastState.compose env47143 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 69) := by decide +kernel

theorem selectedBound47143 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env47144 : List Nat := [2,4,8,1,32,64,128,99,39,34,2048,1,111,64,64,69,103,197,34,65,0,175,103,69,231,39,77,38,64,2080,99,39,99,102,0,38]

theorem envBound47144 : H12AffineFastState.Bounded env47144 := by
  intro p hp
  have h : env47144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47143_47144 : H12AffineEnvironment.transform 15 69 env47143 = env47144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 69 env47143 == env47144) = true)

theorem identity47144 : scanCanonicalize (H12AffineFastState.compose env47144 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound47144 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env47145 : List Nat := [2,4,8,1,32,1,128,34,39,34,2048,1,46,1,1,4,38,132,34,0,0,175,38,4,166,39,12,38,1,2080,34,39,34,39,0,38]

theorem envBound47145 : H12AffineFastState.Bounded env47145 := by
  intro p hp
  have h : env47145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47144_47145 : H12AffineEnvironment.transform 5 1 env47144 = env47145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env47144 == env47145) = true)

theorem identity47145 : scanCanonicalize (H12AffineFastState.compose env47145 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound47145 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47146 : List Nat := [2,4,8,1,0,1,128,2,7,2,2048,1,14,1,1,4,6,132,2,0,0,143,6,4,134,7,12,6,1,2048,2,7,2,7,0,6]

theorem envBound47146 : H12AffineFastState.Bounded env47146 := by
  intro p hp
  have h : env47146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47145_47146 : H12AffineEnvironment.transform 4 0 env47145 = env47146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env47145 == env47146) = true)

theorem identity47146 : scanCanonicalize (H12AffineFastState.compose env47146 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 138) := by decide +kernel

theorem selectedBound47146 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47147 : List Nat := [2,4,8,1,0,1,128,2,7,2,138,1,14,1,1,4,6,132,2,0,0,143,6,4,134,7,12,6,1,138,2,7,2,7,0,6]

theorem envBound47147 : H12AffineFastState.Bounded env47147 := by
  intro p hp
  have h : env47147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47146_47147 : H12AffineEnvironment.transform 10 138 env47146 = env47147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 138 env47146 == env47147) = true)

theorem identity47147 : scanCanonicalize (H12AffineFastState.compose env47147 (packedSelected [1,3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound47147 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env47148 : List Nat := [1,4,8,1,0,1,128,1,4,1,137,1,13,1,1,4,5,132,1,0,0,140,5,4,133,4,12,5,1,137,1,4,1,4,0,5]

theorem envBound47148 : H12AffineFastState.Bounded env47148 := by
  intro p hp
  have h : env47148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47147_47148 : H12AffineEnvironment.transform 0 1 env47147 = env47148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env47147 == env47148) = true)

theorem identity47148 : scanCanonicalize (H12AffineFastState.compose env47148 (packedSelected [1,4,7] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound47148 : packedSelected [1,4,7] rootPS < 2^1333 := by decide +kernel

def env47149 : List Nat := [1,4,8,1,0,1,9,1,4,1,0,1,13,1,1,4,5,13,1,0,0,5,5,4,12,4,12,5,1,0,1,4,1,4,0,5]

theorem envBound47149 : H12AffineFastState.Bounded env47149 := by
  intro p hp
  have h : env47149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47148_47149 : H12AffineEnvironment.transform 6 9 env47148 = env47149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47148 == env47149) = true)

theorem identity47149 : scanCanonicalize (H12AffineFastState.compose env47149 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound47149 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47150 : List Nat := [1,4,0,1,0,1,1,1,4,1,0,1,5,1,1,4,5,5,1,0,0,5,5,4,4,4,4,5,1,0,1,4,1,4,0,5]

theorem envBound47150 : H12AffineFastState.Bounded env47150 := by
  intro p hp
  have h : env47150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47149_47150 : H12AffineEnvironment.transform 2 0 env47149 = env47150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env47149 == env47150) = true)

theorem identity47150 : scanCanonicalize (H12AffineFastState.compose env47150 (packedSelected [8] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound47150 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env47151 : List Nat := [1,1,0,1,0,1,1,1,1,1,0,1,0,1,1,1,0,0,1,0,0,0,0,1,1,1,1,0,1,0,1,1,1,1,0,0]

theorem envBound47151 : H12AffineFastState.Bounded env47151 := by
  intro p hp
  have h : env47151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47150_47151 : H12AffineEnvironment.transform 1 1 env47150 = env47151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env47150 == env47151) = true)

def env47152 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74863,65665,4416,13340,4097,477,74047,69648,13768,78894,4415,74815,1296,81226,8204,74799,256,8201,1345,5953]

theorem envBound47152 : H12AffineFastState.Bounded env47152 := by
  intro p hp
  have h : env47152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47071_47152 : H12AffineEnvironment.transform 17 65665 env47071 = env47152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env47071 == env47152) = true)

theorem identity47152 : scanCanonicalize (H12AffineFastState.compose env47152 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound47152 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env47153 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,81,12636,65536,74030,65665,4416,12637,4097,477,74047,69648,12425,78191,4415,74110,81,79883,8204,74094,256,8201,0,4608]

theorem envBound47153 : H12AffineFastState.Bounded env47153 := by
  intro p hp
  have h : env47153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47152_47153 : H12AffineEnvironment.transform 9 321 env47152 = env47153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env47152 == env47153) = true)

def env47154 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,4096,8192,81,12636,65536,74030,65665,4416,12637,4097,477,74047,69648,12425,78191,4415,74110,81,79883,8204,74094,256,8201,0,4436]

theorem envBound47154 : H12AffineFastState.Bounded env47154 := by
  intro p hp
  have h : env47154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47153_47154 : H12AffineEnvironment.transform 8 340 env47153 = env47154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env47153 == env47154) = true)

def env47155 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,16,8192,81,8524,65536,74030,65665,336,8525,17,477,74047,65536,8345,74111,303,74110,81,75803,8204,74094,256,8201,0,324]

theorem envBound47155 : H12AffineFastState.Bounded env47155 := by
  intro p hp
  have h : env47155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47154_47155 : H12AffineEnvironment.transform 11 16 env47154 = env47155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env47154 == env47155) = true)

theorem identity47155 : scanCanonicalize (H12AffineFastState.compose env47155 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 337) := by decide +kernel

theorem selectedBound47155 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env47156 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,16,8192,81,8524,337,8319,464,336,8525,17,477,8302,337,8345,8238,303,8239,81,10570,8204,8255,256,8201,0,324]

theorem envBound47156 : H12AffineFastState.Bounded env47156 := by
  intro p hp
  have h : env47156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47155_47156 : H12AffineEnvironment.transform 15 337 env47155 = env47156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 337 env47155 == env47156) = true)

def env47157 : List Nat := [2,4,8,0,32,64,128,256,324,321,2048,0,8192,65,8524,321,8303,448,320,8525,1,461,8302,321,8329,8238,303,8239,65,10570,8204,8239,256,8201,0,324]

theorem envBound47157 : H12AffineFastState.Bounded env47157 := by
  intro p hp
  have h : env47157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47156_47157 : H12AffineEnvironment.transform 3 0 env47156 = env47157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env47156 == env47157) = true)

theorem identity47157 : scanCanonicalize (H12AffineFastState.compose env47157 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 34) := by decide +kernel

theorem selectedBound47157 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env47158 : List Nat := [2,4,8,0,32,64,128,34,102,99,2048,0,8192,65,8302,99,8303,226,98,8303,1,239,8302,99,8329,8238,13,8239,65,10344,8204,8239,34,8201,0,102]

theorem envBound47158 : H12AffineFastState.Bounded env47158 := by
  intro p hp
  have h : env47158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47157_47158 : H12AffineEnvironment.transform 7 34 env47157 = env47158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 34 env47157 == env47158) = true)

theorem identity47158 : scanCanonicalize (H12AffineFastState.compose env47158 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 47) := by decide +kernel

theorem selectedBound47158 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env47159 : List Nat := [2,4,8,0,32,64,128,34,102,99,2048,0,47,65,65,99,64,226,98,64,1,239,65,99,166,1,13,0,65,2119,35,0,34,38,0,102]

theorem envBound47159 : H12AffineFastState.Bounded env47159 := by
  intro p hp
  have h : env47159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47158_47159 : H12AffineEnvironment.transform 12 47 env47158 = env47159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 47 env47158 == env47159) = true)

theorem identity47159 : scanCanonicalize (H12AffineFastState.compose env47159 (packedSelected [5,10] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound47159 : packedSelected [5,10] rootPS < 2^1333 := by decide +kernel

def env47160 : List Nat := [2,4,5,0,32,64,128,34,102,99,2048,0,34,65,65,99,64,226,98,64,1,226,65,99,166,1,0,0,65,2119,35,0,34,38,0,102]

theorem envBound47160 : H12AffineFastState.Bounded env47160 := by
  intro p hp
  have h : env47160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47159_47160 : H12AffineEnvironment.transform 2 5 env47159 = env47160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env47159 == env47160) = true)

theorem identity47160 : scanCanonicalize (H12AffineFastState.compose env47160 (packedSelected [7,8] rootPS)) = affineNative (2^(10+1) ^^^ 131) := by decide +kernel

theorem selectedBound47160 : packedSelected [7,8] rootPS < 2^1333 := by decide +kernel

def env47161 : List Nat := [2,4,5,0,32,64,128,34,102,99,131,0,34,65,65,99,64,226,98,64,1,226,65,99,166,1,0,0,65,196,35,0,34,38,0,102]

theorem envBound47161 : H12AffineFastState.Bounded env47161 := by
  intro p hp
  have h : env47161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47160_47161 : H12AffineEnvironment.transform 10 131 env47160 = env47161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 131 env47160 == env47161) = true)

theorem identity47161 : scanCanonicalize (H12AffineFastState.compose env47161 (packedSelected [2,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 37) := by decide +kernel

theorem selectedBound47161 : packedSelected [2,4,5] rootPS < 2^1333 := by decide +kernel

def env47162 : List Nat := [2,4,5,0,32,64,37,34,102,99,38,0,34,65,65,99,64,71,98,64,1,71,65,99,3,1,0,0,65,97,35,0,34,38,0,102]

theorem envBound47162 : H12AffineFastState.Bounded env47162 := by
  intro p hp
  have h : env47162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47161_47162 : H12AffineEnvironment.transform 6 37 env47161 = env47162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 37 env47161 == env47162) = true)

theorem identity47162 : scanCanonicalize (H12AffineFastState.compose env47162 (packedSelected [0,1,3] rootPS)) = affineNative (2^(5+1) ^^^ 7) := by decide +kernel

theorem selectedBound47162 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env47163 : List Nat := [2,4,5,0,32,7,37,34,33,36,38,0,34,6,6,36,7,0,37,7,1,0,6,36,3,1,0,0,6,38,35,0,34,38,0,33]

theorem envBound47163 : H12AffineFastState.Bounded env47163 := by
  intro p hp
  have h : env47163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47162_47163 : H12AffineEnvironment.transform 5 7 env47162 = env47163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 7 env47162 == env47163) = true)

def env47164 : List Nat := [2,4,8,1,32,64,128,256,325,321,2048,1,8192,64,8524,320,8302,449,321,8525,0,460,8302,320,8328,8238,303,8239,64,10570,8204,8238,256,8201,0,324]

theorem envBound47164 : H12AffineFastState.Bounded env47164 := by
  intro p hp
  have h : env47164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47156_47164 : H12AffineEnvironment.transform 3 1 env47156 = env47164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env47156 == env47164) = true)

theorem identity47164 : scanCanonicalize (H12AffineFastState.compose env47164 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound47164 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env47165 : List Nat := [2,4,8,1,32,64,128,256,325,321,2048,1,268,64,64,320,354,449,321,65,0,460,354,320,388,290,303,291,64,2118,256,290,256,261,0,324]

theorem envBound47165 : H12AffineFastState.Bounded env47165 := by
  intro p hp
  have h : env47165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47164_47165 : H12AffineEnvironment.transform 12 268 env47164 = env47165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env47164 == env47165) = true)

theorem identity47165 : scanCanonicalize (H12AffineFastState.compose env47165 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(5+1) ^^^ 38) := by decide +kernel

theorem selectedBound47165 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env47166 : List Nat := [2,4,8,1,32,38,128,256,291,295,2048,1,268,38,38,294,260,423,295,39,0,426,260,294,388,290,303,291,38,2080,256,290,256,261,0,290]

theorem envBound47166 : H12AffineFastState.Bounded env47166 := by
  intro p hp
  have h : env47166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47165_47166 : H12AffineEnvironment.transform 5 38 env47165 = env47166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 38 env47165 == env47166) = true)

theorem identity47166 : scanCanonicalize (H12AffineFastState.compose env47166 (packedSelected [3,5,10] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound47166 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env47167 : List Nat := [2,4,8,1,7,1,128,256,260,256,2048,1,268,1,1,257,260,384,256,0,0,397,260,257,388,261,264,260,1,2055,256,261,256,261,0,261]

theorem envBound47167 : H12AffineFastState.Bounded env47167 := by
  intro p hp
  have h : env47167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47166_47167 : H12AffineEnvironment.transform 4 7 env47166 = env47167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env47166 == env47167) = true)

theorem identity47167 : scanCanonicalize (H12AffineFastState.compose env47167 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound47167 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47168 : List Nat := [2,2,8,1,1,1,128,256,258,256,2048,1,266,1,1,257,258,384,256,0,0,395,258,257,386,259,264,258,1,2049,256,259,256,259,0,259]

theorem envBound47168 : H12AffineFastState.Bounded env47168 := by
  intro p hp
  have h : env47168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47167_47168 : H12AffineEnvironment.transform 1 2 env47167 = env47168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env47167 == env47168) = true)

theorem identity47168 : scanCanonicalize (H12AffineFastState.compose env47168 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 136) := by decide +kernel

theorem selectedBound47168 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47169 : List Nat := [2,2,8,1,1,1,128,136,138,136,2048,1,130,1,1,137,138,8,136,0,0,3,138,137,10,139,128,138,1,2049,136,139,136,139,0,139]

theorem envBound47169 : H12AffineFastState.Bounded env47169 := by
  intro p hp
  have h : env47169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47168_47169 : H12AffineEnvironment.transform 7 136 env47168 = env47169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 136 env47168 == env47169) = true)

theorem identity47169 : scanCanonicalize (H12AffineFastState.compose env47169 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 2) := by decide +kernel

theorem selectedBound47169 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env47170 : List Nat := [2,2,8,1,1,1,128,136,138,136,2,1,130,1,1,137,138,8,136,0,0,3,138,137,10,139,128,138,1,3,136,139,136,139,0,139]

theorem envBound47170 : H12AffineFastState.Bounded env47170 := by
  intro p hp
  have h : env47170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47169_47170 : H12AffineEnvironment.transform 10 2 env47169 = env47170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 2 env47169 == env47170) = true)

theorem identity47170 : scanCanonicalize (H12AffineFastState.compose env47170 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound47170 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env47171 : List Nat := [2,2,1,1,1,1,128,129,131,129,2,1,130,1,1,128,131,1,129,0,0,3,131,128,3,130,128,131,1,3,129,130,129,130,0,130]

theorem envBound47171 : H12AffineFastState.Bounded env47171 := by
  intro p hp
  have h : env47171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47170_47171 : H12AffineEnvironment.transform 2 1 env47170 = env47171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env47170 == env47171) = true)

theorem identity47171 : scanCanonicalize (H12AffineFastState.compose env47171 (packedSelected [1,4] rootPS)) = affineNative (2^(6+1) ^^^ 0) := by decide +kernel

theorem selectedBound47171 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env47172 : List Nat := [2,2,1,1,1,1,0,1,3,1,2,1,2,1,1,0,3,1,1,0,0,3,3,0,3,2,0,3,1,3,1,2,1,2,0,2]

theorem envBound47172 : H12AffineFastState.Bounded env47172 := by
  intro p hp
  have h : env47172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47171_47172 : H12AffineEnvironment.transform 6 0 env47171 = env47172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 0 env47171 == env47172) = true)

def env47173 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,17,8192,81,8525,65536,74030,65665,337,8524,16,477,74047,65537,8344,74110,302,74110,81,75802,8204,74094,256,8201,0,325]

theorem envBound47173 : H12AffineFastState.Bounded env47173 := by
  intro p hp
  have h : env47173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47154_47173 : H12AffineEnvironment.transform 11 17 env47154 = env47173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env47154 == env47173) = true)

theorem identity47173 : scanCanonicalize (H12AffineFastState.compose env47173 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8473) := by decide +kernel

theorem selectedBound47173 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env47174 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,17,8192,81,8525,8473,55,8600,337,8524,16,477,38,8472,8344,103,302,103,81,2307,8204,119,256,8201,0,325]

theorem envBound47174 : H12AffineFastState.Bounded env47174 := by
  intro p hp
  have h : env47174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47173_47174 : H12AffineEnvironment.transform 15 8473 env47173 = env47174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8473 env47173 == env47174) = true)

def env47175 : List Nat := [2,4,8,0,32,64,128,256,324,321,2048,1,8192,65,8525,8457,39,8584,321,8524,0,461,38,8456,8328,103,302,103,65,2307,8204,103,256,8201,0,325]

theorem envBound47175 : H12AffineFastState.Bounded env47175 := by
  intro p hp
  have h : env47175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47174_47175 : H12AffineEnvironment.transform 3 0 env47174 = env47175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env47174 == env47175) = true)

theorem identity47175 : scanCanonicalize (H12AffineFastState.compose env47175 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound47175 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env47176 : List Nat := [2,4,8,0,32,64,128,256,324,321,2048,1,268,65,65,5,39,132,321,64,0,461,38,4,388,103,302,103,65,2307,256,103,256,261,0,325]

theorem envBound47176 : H12AffineFastState.Bounded env47176 := by
  intro p hp
  have h : env47176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47175_47176 : H12AffineEnvironment.transform 12 268 env47175 = env47176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env47175 == env47176) = true)

theorem identity47176 : scanCanonicalize (H12AffineFastState.compose env47176 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 34) := by decide +kernel

theorem selectedBound47176 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env47177 : List Nat := [2,4,8,0,32,64,128,34,102,99,2048,1,46,65,65,5,39,132,99,64,0,239,38,4,166,103,12,103,65,2081,34,103,34,39,0,103]

theorem envBound47177 : H12AffineFastState.Bounded env47177 := by
  intro p hp
  have h : env47177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47176_47177 : H12AffineEnvironment.transform 7 34 env47176 = env47177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 34 env47176 == env47177) = true)

theorem identity47177 : scanCanonicalize (H12AffineFastState.compose env47177 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound47177 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env47178 : List Nat := [2,4,8,0,32,1,128,34,39,34,2048,1,46,0,0,5,39,132,34,1,0,174,38,4,166,38,12,38,0,2081,34,38,34,39,0,38]

theorem envBound47178 : H12AffineFastState.Bounded env47178 := by
  intro p hp
  have h : env47178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47177_47178 : H12AffineEnvironment.transform 5 1 env47177 = env47178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env47177 == env47178) = true)

theorem identity47178 : scanCanonicalize (H12AffineFastState.compose env47178 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound47178 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47179 : List Nat := [2,4,8,0,7,1,128,5,0,5,2048,1,9,0,0,5,0,132,5,1,0,137,1,4,129,1,12,1,0,2054,5,1,5,0,0,1]

theorem envBound47179 : H12AffineFastState.Bounded env47179 := by
  intro p hp
  have h : env47179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47178_47179 : H12AffineEnvironment.transform 4 7 env47178 = env47179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env47178 == env47179) = true)

theorem identity47179 : scanCanonicalize (H12AffineFastState.compose env47179 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound47179 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47180 : List Nat := [2,4,8,0,7,1,128,5,0,5,0,1,9,0,0,5,0,132,5,1,0,137,1,4,129,1,12,1,0,6,5,1,5,0,0,1]

theorem envBound47180 : H12AffineFastState.Bounded env47180 := by
  intro p hp
  have h : env47180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47179_47180 : H12AffineEnvironment.transform 10 0 env47179 = env47180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env47179 == env47180) = true)

theorem identity47180 : scanCanonicalize (H12AffineFastState.compose env47180 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound47180 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47181 : List Nat := [2,0,8,0,3,1,128,1,0,1,0,1,9,0,0,1,0,128,1,1,0,137,1,0,129,1,8,1,0,2,1,1,1,0,0,1]

theorem envBound47181 : H12AffineFastState.Bounded env47181 := by
  intro p hp
  have h : env47181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47180_47181 : H12AffineEnvironment.transform 1 0 env47180 = env47181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env47180 == env47181) = true)

theorem identity47181 : scanCanonicalize (H12AffineFastState.compose env47181 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound47181 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env47182 : List Nat := [2,0,1,0,3,1,128,1,0,1,0,1,0,0,0,1,0,128,1,1,0,128,1,0,129,1,1,1,0,2,1,1,1,0,0,1]

theorem envBound47182 : H12AffineFastState.Bounded env47182 := by
  intro p hp
  have h : env47182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47181_47182 : H12AffineEnvironment.transform 2 1 env47181 = env47182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env47181 == env47182) = true)

theorem identity47182 : scanCanonicalize (H12AffineFastState.compose env47182 (packedSelected [7] rootPS)) = affineNative (2^(6+1) ^^^ 0) := by decide +kernel

theorem selectedBound47182 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env47183 : List Nat := [2,0,1,0,3,1,0,1,0,1,0,1,0,0,0,1,0,0,1,1,0,0,1,0,1,1,1,1,0,2,1,1,1,0,0,1]

theorem envBound47183 : H12AffineFastState.Bounded env47183 := by
  intro p hp
  have h : env47183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47182_47183 : H12AffineEnvironment.transform 6 0 env47182 = env47183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 0 env47182 == env47183) = true)

theorem identity47183 : scanCanonicalize (H12AffineFastState.compose env47183 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound47183 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env47184 : List Nat := [1,0,1,0,0,1,0,1,0,1,0,1,0,0,0,1,0,0,1,1,0,0,1,0,1,1,1,1,0,1,1,1,1,0,0,1]

theorem envBound47184 : H12AffineFastState.Bounded env47184 := by
  intro p hp
  have h : env47184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47183_47184 : H12AffineEnvironment.transform 0 1 env47183 = env47184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env47183 == env47184) = true)

def env47185 : List Nat := [2,4,8,1,32,64,128,256,325,321,2048,0,8192,64,8525,8456,38,8585,320,8524,1,460,38,8457,8329,103,302,103,64,2307,8204,102,256,8201,0,325]

theorem envBound47185 : H12AffineFastState.Bounded env47185 := by
  intro p hp
  have h : env47185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47174_47185 : H12AffineEnvironment.transform 3 1 env47174 = env47185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env47174 == env47185) = true)

theorem identity47185 : scanCanonicalize (H12AffineFastState.compose env47185 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 362) := by decide +kernel

theorem selectedBound47185 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env47186 : List Nat := [2,4,8,1,32,64,128,256,325,321,2048,0,362,64,39,98,38,227,320,38,1,460,38,99,483,103,302,103,64,2307,358,102,256,355,0,325]

theorem envBound47186 : H12AffineFastState.Bounded env47186 := by
  intro p hp
  have h : env47186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47185_47186 : H12AffineEnvironment.transform 12 362 env47185 = env47186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 362 env47185 == env47186) = true)

theorem identity47186 : scanCanonicalize (H12AffineFastState.compose env47186 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 39) := by decide +kernel

theorem selectedBound47186 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env47187 : List Nat := [2,4,8,1,32,39,128,256,290,294,2048,0,269,39,39,5,38,132,295,38,1,427,38,4,388,0,302,0,39,2307,257,1,256,260,0,290]

theorem envBound47187 : H12AffineFastState.Bounded env47187 := by
  intro p hp
  have h : env47187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47186_47187 : H12AffineEnvironment.transform 5 39 env47186 = env47187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 39 env47186 == env47187) = true)

theorem identity47187 : scanCanonicalize (H12AffineFastState.compose env47187 (packedSelected [5,10] rootPS)) = affineNative (2^(7+1) ^^^ 8) := by decide +kernel

theorem selectedBound47187 : packedSelected [5,10] rootPS < 2^1333 := by decide +kernel

def env47188 : List Nat := [2,4,8,1,32,39,128,8,42,46,2048,0,5,39,39,5,38,132,47,38,1,163,38,4,140,0,38,0,39,2059,9,1,8,12,0,42]

theorem envBound47188 : H12AffineFastState.Bounded env47188 := by
  intro p hp
  have h : env47188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47187_47188 : H12AffineEnvironment.transform 7 8 env47187 = env47188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 8 env47187 == env47188) = true)

theorem identity47188 : scanCanonicalize (H12AffineFastState.compose env47188 (packedSelected [7] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound47188 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env47189 : List Nat := [2,4,8,1,32,39,34,8,42,46,2048,0,5,39,39,5,38,38,47,38,1,1,38,4,46,0,38,0,39,2059,9,1,8,12,0,42]

theorem envBound47189 : H12AffineFastState.Bounded env47189 := by
  intro p hp
  have h : env47189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47188_47189 : H12AffineEnvironment.transform 6 34 env47188 = env47189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env47188 == env47189) = true)

theorem identity47189 : scanCanonicalize (H12AffineFastState.compose env47189 (packedSelected [1,4] rootPS)) = affineNative (2^(10+1) ^^^ 44) := by decide +kernel

theorem selectedBound47189 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env47190 : List Nat := [2,4,8,1,32,39,34,8,42,46,44,0,5,39,39,5,38,38,47,38,1,1,38,4,46,0,38,0,39,39,9,1,8,12,0,42]

theorem envBound47190 : H12AffineFastState.Bounded env47190 := by
  intro p hp
  have h : env47190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47189_47190 : H12AffineEnvironment.transform 10 44 env47189 = env47190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 44 env47189 == env47190) = true)

theorem identity47190 : scanCanonicalize (H12AffineFastState.compose env47190 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound47190 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env47191 : List Nat := [2,4,8,1,6,1,4,8,12,8,10,0,5,1,1,5,0,0,9,0,1,1,0,4,8,0,0,0,1,1,9,1,8,12,0,12]

theorem envBound47191 : H12AffineFastState.Bounded env47191 := by
  intro p hp
  have h : env47191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47190_47191 : H12AffineEnvironment.transform 4 6 env47190 = env47191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env47190 == env47191) = true)

theorem identity47191 : scanCanonicalize (H12AffineFastState.compose env47191 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound47191 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47192 : List Nat := [2,4,3,1,6,1,4,3,7,3,1,0,5,1,1,5,0,0,2,0,1,1,0,4,3,0,0,0,1,1,2,1,3,7,0,7]

theorem envBound47192 : H12AffineFastState.Bounded env47192 := by
  intro p hp
  have h : env47192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47191_47192 : H12AffineEnvironment.transform 2 3 env47191 = env47192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env47191 == env47192) = true)

theorem identity47192 : scanCanonicalize (H12AffineFastState.compose env47192 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound47192 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47193 : List Nat := [2,2,3,1,0,1,2,3,1,3,1,0,3,1,1,3,0,0,2,0,1,1,0,2,3,0,0,0,1,1,2,1,3,1,0,1]

theorem envBound47193 : H12AffineFastState.Bounded env47193 := by
  intro p hp
  have h : env47193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47192_47193 : H12AffineEnvironment.transform 1 2 env47192 = env47193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env47192 == env47193) = true)

def env47194 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,4096,8192,81,12636,65536,74030,65665,4416,12637,4097,477,74047,69648,12425,78191,4415,74110,81,79883,8204,74094,256,8201,0,4437]

theorem envBound47194 : H12AffineFastState.Bounded env47194 := by
  intro p hp
  have h : env47194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47153_47194 : H12AffineEnvironment.transform 8 341 env47153 = env47194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env47153 == env47194) = true)

def env47195 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,16,8192,81,8524,65536,74030,65665,336,8525,17,477,74047,65536,8345,74111,303,74110,81,75803,8204,74094,256,8201,0,325]

theorem envBound47195 : H12AffineFastState.Bounded env47195 := by
  intro p hp
  have h : env47195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47194_47195 : H12AffineEnvironment.transform 11 16 env47194 = env47195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env47194 == env47195) = true)

theorem identity47195 : scanCanonicalize (H12AffineFastState.compose env47195 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 126) := by decide +kernel

theorem selectedBound47195 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env47196 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,16,126,81,306,65536,65872,65665,336,307,17,477,65857,65536,231,65793,303,65792,81,67685,114,65808,256,119,0,325]

theorem envBound47196 : H12AffineFastState.Bounded env47196 := by
  intro p hp
  have h : env47196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47195_47196 : H12AffineEnvironment.transform 12 126 env47195 = env47196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 126 env47195 == env47196) = true)

def env47197 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,16,126,81,306,256,80,385,336,307,17,477,65,256,231,1,303,0,81,2405,114,16,256,119,0,325]

theorem envBound47197 : H12AffineFastState.Bounded env47197 := by
  intro p hp
  have h : env47197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47196_47197 : H12AffineEnvironment.transform 15 256 env47196 = env47197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 256 env47196 == env47197) = true)

theorem identity47197 : scanCanonicalize (H12AffineFastState.compose env47197 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 99) := by decide +kernel

theorem selectedBound47197 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env47198 : List Nat := [2,4,8,16,32,64,128,99,54,34,2048,16,126,81,81,99,80,226,51,80,17,190,65,99,231,1,76,0,81,2054,114,16,99,119,0,38]

theorem envBound47198 : H12AffineFastState.Bounded env47198 := by
  intro p hp
  have h : env47198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47197_47198 : H12AffineEnvironment.transform 7 99 env47197 = env47198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 99 env47197 == env47198) = true)

theorem identity47198 : scanCanonicalize (H12AffineFastState.compose env47198 (packedSelected [1,3,8,19] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound47198 : packedSelected [1,3,8,19] rootPS < 2^1333 := by decide +kernel

def env47199 : List Nat := [2,4,8,12,32,64,128,99,42,34,2048,12,98,77,77,99,76,226,47,76,13,162,65,99,231,1,76,0,77,2054,110,12,99,107,0,38]

theorem envBound47199 : H12AffineFastState.Bounded env47199 := by
  intro p hp
  have h : env47199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47198_47199 : H12AffineEnvironment.transform 3 12 env47198 = env47199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env47198 == env47199) = true)

theorem identity47199 : scanCanonicalize (H12AffineFastState.compose env47199 (packedSelected [2,8,10,11,17,18] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound47199 : packedSelected [2,8,10,11,17,18] rootPS < 2^1333 := by decide +kernel

def env47200 : List Nat := [2,4,5,1,32,64,128,99,39,34,2048,1,98,64,64,99,65,226,34,65,0,162,65,99,231,1,65,0,64,2054,99,1,99,102,0,38]

theorem envBound47200 : H12AffineFastState.Bounded env47200 := by
  intro p hp
  have h : env47200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47199_47200 : H12AffineEnvironment.transform 2 5 env47199 = env47200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env47199 == env47200) = true)

theorem identity47200 : scanCanonicalize (H12AffineFastState.compose env47200 (packedSelected [7] rootPS)) = affineNative (2^(6+1) ^^^ 64) := by decide +kernel

theorem selectedBound47200 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env47201 : List Nat := [2,4,5,1,32,64,64,99,39,34,2048,1,98,64,64,99,65,34,34,65,0,98,65,99,39,1,65,0,64,2054,99,1,99,102,0,38]

theorem envBound47201 : H12AffineFastState.Bounded env47201 := by
  intro p hp
  have h : env47201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47200_47201 : H12AffineEnvironment.transform 6 64 env47200 = env47201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 64 env47200 == env47201) = true)

theorem identity47201 : scanCanonicalize (H12AffineFastState.compose env47201 (packedSelected [5,10] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound47201 : packedSelected [5,10] rootPS < 2^1333 := by decide +kernel

def env47202 : List Nat := [2,4,5,1,6,64,64,69,1,4,2048,1,68,64,64,69,65,4,4,65,0,68,65,69,1,1,65,0,64,2054,69,1,69,64,0,0]

theorem envBound47202 : H12AffineFastState.Bounded env47202 := by
  intro p hp
  have h : env47202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47201_47202 : H12AffineEnvironment.transform 4 6 env47201 = env47202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env47201 == env47202) = true)

theorem identity47202 : scanCanonicalize (H12AffineFastState.compose env47202 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound47202 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env47203 : List Nat := [2,4,5,1,6,1,1,4,1,4,2048,1,5,1,1,4,0,4,4,0,0,5,0,4,1,1,0,0,1,2054,4,1,4,1,0,0]

end H12CloudChart2