import H12CloudChart2Data192

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity48497 : scanCanonicalize (H12AffineFastState.compose env48497 (packedSelected [0,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound48497 : packedSelected [0,7,8] rootPS < 2^1333 := by decide +kernel

def env48498 : List Nat := [2,4,8,0,32,12,5,4,1,8,1,13,5,13,0,46,1,42,5,1,13,13,0,47,5,0,42,12,13,45,8,13,4,12,1,13]

theorem envBound48498 : H12AffineFastState.Bounded env48498 := by
  intro p hp
  have h : env48498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48497_48498 : H12AffineEnvironment.transform 5 12 env48497 = env48498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env48497 == env48498) = true)

theorem identity48498 : scanCanonicalize (H12AffineFastState.compose env48498 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound48498 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env48499 : List Nat := [2,4,8,0,6,12,5,4,1,8,1,13,5,13,0,8,1,12,5,1,13,13,0,9,5,0,12,12,13,11,8,13,4,12,1,13]

theorem envBound48499 : H12AffineFastState.Bounded env48499 := by
  intro p hp
  have h : env48499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48498_48499 : H12AffineEnvironment.transform 4 6 env48498 = env48499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env48498 == env48499) = true)

theorem identity48499 : scanCanonicalize (H12AffineFastState.compose env48499 (packedSelected [0,4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound48499 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env48500 : List Nat := [2,2,8,0,0,10,3,2,1,8,1,11,3,11,0,8,1,10,3,1,11,11,0,9,3,0,10,10,11,11,8,11,2,10,1,11]

theorem envBound48500 : H12AffineFastState.Bounded env48500 := by
  intro p hp
  have h : env48500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48499_48500 : H12AffineEnvironment.transform 1 2 env48499 = env48500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env48499 == env48500) = true)

theorem identity48500 : scanCanonicalize (H12AffineFastState.compose env48500 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound48500 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48501 : List Nat := [2,2,3,0,0,1,3,2,1,3,1,0,3,0,0,3,1,1,3,1,0,0,0,2,3,0,1,1,0,0,3,0,2,1,1,0]

theorem envBound48501 : H12AffineFastState.Bounded env48501 := by
  intro p hp
  have h : env48501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48500_48501 : H12AffineEnvironment.transform 2 3 env48500 = env48501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env48500 == env48501) = true)

theorem identity48501 : scanCanonicalize (H12AffineFastState.compose env48501 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound48501 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48502 : List Nat := [0,0,1,0,0,1,1,0,1,1,1,0,1,0,0,1,1,1,1,1,0,0,0,0,1,0,1,1,0,0,1,0,0,1,1,0]

theorem envBound48502 : H12AffineFastState.Bounded env48502 := by
  intro p hp
  have h : env48502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48501_48502 : H12AffineEnvironment.transform 0 0 env48501 = env48502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env48501 == env48502) = true)

def env48503 : List Nat := [2,4,8,16,32,64,128,89,77,9,2048,80,88,65,92,65536,65599,65665,73,93,80,196,65598,65537,144,65583,119,65646,65,67602,85,65663,89,81,17,12]

theorem envBound48503 : H12AffineFastState.Bounded env48503 := by
  intro p hp
  have h : env48503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48492_48503 : H12AffineEnvironment.transform 7 89 env48492 = env48503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 89 env48492 == env48503) = true)

theorem identity48503 : scanCanonicalize (H12AffineFastState.compose env48503 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 51) := by decide +kernel

theorem selectedBound48503 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env48504 : List Nat := [2,4,8,16,32,64,128,89,77,9,2048,80,88,65,92,51,12,178,73,93,80,196,13,50,144,28,119,93,65,2081,85,76,89,81,17,12]

theorem envBound48504 : H12AffineFastState.Bounded env48504 := by
  intro p hp
  have h : env48504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48503_48504 : H12AffineEnvironment.transform 15 51 env48503 = env48504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 51 env48503 == env48504) = true)

theorem identity48504 : scanCanonicalize (H12AffineFastState.compose env48504 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound48504 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env48505 : List Nat := [2,4,8,16,32,1,128,24,12,9,2048,17,25,0,29,51,12,178,8,28,17,133,13,50,144,28,54,28,0,2081,20,13,24,16,17,12]

theorem envBound48505 : H12AffineFastState.Bounded env48505 := by
  intro p hp
  have h : env48505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48504_48505 : H12AffineEnvironment.transform 5 1 env48504 = env48505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env48504 == env48505) = true)

theorem identity48505 : scanCanonicalize (H12AffineFastState.compose env48505 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound48505 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env48506 : List Nat := [2,4,8,16,32,1,4,24,12,9,2048,17,25,0,29,51,12,54,8,28,17,1,13,50,20,28,54,28,0,2081,20,13,24,16,17,12]

theorem envBound48506 : H12AffineFastState.Bounded env48506 := by
  intro p hp
  have h : env48506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48505_48506 : H12AffineEnvironment.transform 6 4 env48505 = env48506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env48505 == env48506) = true)

theorem identity48506 : scanCanonicalize (H12AffineFastState.compose env48506 (packedSelected [0,2,3,5,7,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 55) := by decide +kernel

theorem selectedBound48506 : packedSelected [0,2,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env48507 : List Nat := [2,4,8,16,32,1,4,24,12,9,55,17,25,0,29,51,12,54,8,28,17,1,13,50,20,28,54,28,0,22,20,13,24,16,17,12]

theorem envBound48507 : H12AffineFastState.Bounded env48507 := by
  intro p hp
  have h : env48507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48506_48507 : H12AffineEnvironment.transform 10 55 env48506 = env48507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 55 env48506 == env48507) = true)

theorem identity48507 : scanCanonicalize (H12AffineFastState.compose env48507 (packedSelected [2,4] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound48507 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env48508 : List Nat := [2,4,4,16,32,1,4,20,0,5,55,17,21,0,17,51,0,54,4,16,17,1,1,50,20,16,54,16,0,22,20,1,20,16,17,0]

theorem envBound48508 : H12AffineFastState.Bounded env48508 := by
  intro p hp
  have h : env48508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48507_48508 : H12AffineEnvironment.transform 2 4 env48507 = env48508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env48507 == env48508) = true)

theorem identity48508 : scanCanonicalize (H12AffineFastState.compose env48508 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound48508 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48509 : List Nat := [2,4,4,16,6,1,4,20,0,5,17,17,21,0,17,21,0,16,4,16,17,1,1,20,20,16,16,16,0,22,20,1,20,16,17,0]

theorem envBound48509 : H12AffineFastState.Bounded env48509 := by
  intro p hp
  have h : env48509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48508_48509 : H12AffineEnvironment.transform 4 6 env48508 = env48509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env48508 == env48509) = true)

theorem identity48509 : scanCanonicalize (H12AffineFastState.compose env48509 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound48509 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env48510 : List Nat := [2,4,4,7,6,1,4,3,0,5,6,6,2,0,6,2,0,7,4,7,6,1,1,3,3,7,7,7,0,1,3,1,3,7,6,0]

theorem envBound48510 : H12AffineFastState.Bounded env48510 := by
  intro p hp
  have h : env48510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48509_48510 : H12AffineEnvironment.transform 3 7 env48509 = env48510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env48509 == env48510) = true)

def env48511 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,837,844,64,529,65536,66163,65665,517,528,837,649,66163,65536,144,65910,303,66082,64,67602,833,66099,256,837,16,341]

theorem envBound48511 : H12AffineFastState.Bounded env48511 := by
  intro p hp
  have h : env48511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48490_48511 : H12AffineEnvironment.transform 9 337 env48490 = env48511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env48490 == env48511) = true)

theorem identity48511 : scanCanonicalize (H12AffineFastState.compose env48511 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 89) := by decide +kernel

theorem selectedBound48511 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env48512 : List Nat := [2,4,8,16,32,64,128,89,512,8,2048,540,533,64,529,65536,66163,65665,517,528,540,649,66163,65536,144,65583,118,66082,64,67602,536,66099,89,540,16,12]

theorem envBound48512 : H12AffineFastState.Bounded env48512 := by
  intro p hp
  have h : env48512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48511_48512 : H12AffineEnvironment.transform 7 89 env48511 = env48512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 89 env48511 == env48512) = true)

def env48513 : List Nat := [2,4,8,16,32,64,128,89,76,8,2048,80,89,64,93,65536,65599,65665,73,92,80,197,65599,65536,144,65583,118,65646,64,67602,84,65663,89,80,16,12]

theorem envBound48513 : H12AffineFastState.Bounded env48513 := by
  intro p hp
  have h : env48513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48512_48513 : H12AffineEnvironment.transform 8 76 env48512 = env48513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 76 env48512 == env48513) = true)

theorem identity48513 : scanCanonicalize (H12AffineFastState.compose env48513 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 50) := by decide +kernel

theorem selectedBound48513 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env48514 : List Nat := [2,4,8,16,32,64,128,89,76,8,2048,80,89,64,93,50,13,179,73,92,80,197,13,50,144,29,118,92,64,2080,84,77,89,80,16,12]

theorem envBound48514 : H12AffineFastState.Bounded env48514 := by
  intro p hp
  have h : env48514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48513_48514 : H12AffineEnvironment.transform 15 50 env48513 = env48514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50 env48513 == env48514) = true)

theorem identity48514 : scanCanonicalize (H12AffineFastState.compose env48514 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound48514 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env48515 : List Nat := [2,4,8,16,32,0,128,25,12,8,2048,16,25,0,29,50,13,179,9,28,16,133,13,50,144,29,54,28,0,2080,20,13,25,16,16,12]

theorem envBound48515 : H12AffineFastState.Bounded env48515 := by
  intro p hp
  have h : env48515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48514_48515 : H12AffineEnvironment.transform 5 0 env48514 = env48515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env48514 == env48515) = true)

theorem identity48515 : scanCanonicalize (H12AffineFastState.compose env48515 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound48515 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env48516 : List Nat := [2,4,8,16,32,0,4,25,12,8,2048,16,25,0,29,50,13,55,9,28,16,1,13,50,20,29,54,28,0,2080,20,13,25,16,16,12]

theorem envBound48516 : H12AffineFastState.Bounded env48516 := by
  intro p hp
  have h : env48516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48515_48516 : H12AffineEnvironment.transform 6 4 env48515 = env48516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env48515 == env48516) = true)

theorem identity48516 : scanCanonicalize (H12AffineFastState.compose env48516 (packedSelected [0,2,3,5,7,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 59) := by decide +kernel

theorem selectedBound48516 : packedSelected [0,2,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env48517 : List Nat := [2,4,8,16,32,0,4,25,12,8,59,16,25,0,29,50,13,55,9,28,16,1,13,50,20,29,54,28,0,27,20,13,25,16,16,12]

theorem envBound48517 : H12AffineFastState.Bounded env48517 := by
  intro p hp
  have h : env48517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48516_48517 : H12AffineEnvironment.transform 10 59 env48516 = env48517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 59 env48516 == env48517) = true)

theorem identity48517 : scanCanonicalize (H12AffineFastState.compose env48517 (packedSelected [2,3,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound48517 : packedSelected [2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env48518 : List Nat := [2,4,8,16,23,0,4,25,12,8,12,16,25,0,29,5,13,0,9,28,16,1,13,5,20,29,1,28,0,27,20,13,25,16,16,12]

theorem envBound48518 : H12AffineFastState.Bounded env48518 := by
  intro p hp
  have h : env48518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48517_48518 : H12AffineEnvironment.transform 4 23 env48517 = env48518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env48517 == env48518) = true)

theorem identity48518 : scanCanonicalize (H12AffineFastState.compose env48518 (packedSelected [0,1,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound48518 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env48519 : List Nat := [2,4,3,16,23,0,4,18,7,3,7,16,18,0,22,5,6,0,2,23,16,1,6,5,20,22,1,23,0,16,20,6,18,16,16,7]

theorem envBound48519 : H12AffineFastState.Bounded env48519 := by
  intro p hp
  have h : env48519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48518_48519 : H12AffineEnvironment.transform 2 3 env48518 = env48519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env48518 == env48519) = true)

def env48520 : List Nat := [2,4,8,16,32,64,128,89,77,8,2048,81,88,64,92,65536,65598,65665,72,93,81,196,65598,65536,144,65583,118,65647,64,67602,85,65662,89,81,16,12]

theorem envBound48520 : H12AffineFastState.Bounded env48520 := by
  intro p hp
  have h : env48520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48512_48520 : H12AffineEnvironment.transform 8 77 env48512 = env48520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 77 env48512 == env48520) = true)

theorem identity48520 : scanCanonicalize (H12AffineFastState.compose env48520 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound48520 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env48521 : List Nat := [2,4,8,16,32,64,128,89,77,8,2048,81,88,64,92,114,76,243,72,93,81,196,76,114,144,93,118,29,64,2144,85,12,89,81,16,12]

theorem envBound48521 : H12AffineFastState.Bounded env48521 := by
  intro p hp
  have h : env48521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48520_48521 : H12AffineEnvironment.transform 15 114 env48520 = env48521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env48520 == env48521) = true)

theorem identity48521 : scanCanonicalize (H12AffineFastState.compose env48521 (packedSelected [1,2,5,12,17] rootPS)) = affineNative (2^(10+1) ^^^ 149) := by decide +kernel

theorem selectedBound48521 : packedSelected [1,2,5,12,17] rootPS < 2^1333 := by decide +kernel

def env48522 : List Nat := [2,4,8,16,32,64,128,89,77,8,149,81,88,64,92,114,76,243,72,93,81,196,76,114,144,93,118,29,64,245,85,12,89,81,16,12]

theorem envBound48522 : H12AffineFastState.Bounded env48522 := by
  intro p hp
  have h : env48522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48521_48522 : H12AffineEnvironment.transform 10 149 env48521 = env48522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 149 env48521 == env48522) = true)

theorem identity48522 : scanCanonicalize (H12AffineFastState.compose env48522 (packedSelected [0,2,4,5,7,9,11,13,15,16] rootPS)) = affineNative (2^(6+1) ^^^ 84) := by decide +kernel

theorem selectedBound48522 : packedSelected [0,2,4,5,7,9,11,13,15,16] rootPS < 2^1333 := by decide +kernel

def env48523 : List Nat := [2,4,8,16,32,64,84,89,77,8,65,81,88,64,92,114,76,39,72,93,81,16,76,114,68,93,118,29,64,33,85,12,89,81,16,12]

theorem envBound48523 : H12AffineFastState.Bounded env48523 := by
  intro p hp
  have h : env48523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48522_48523 : H12AffineEnvironment.transform 6 84 env48522 = env48523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 84 env48522 == env48523) = true)

theorem identity48523 : scanCanonicalize (H12AffineFastState.compose env48523 (packedSelected [0,2,3,5,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 6) := by decide +kernel

theorem selectedBound48523 : packedSelected [0,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env48524 : List Nat := [2,4,8,16,32,6,18,31,11,8,7,23,30,6,26,52,10,39,14,27,23,16,10,52,2,27,48,29,6,33,19,12,31,23,16,12]

theorem envBound48524 : H12AffineFastState.Bounded env48524 := by
  intro p hp
  have h : env48524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48523_48524 : H12AffineEnvironment.transform 5 6 env48523 = env48524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 6 env48523 == env48524) = true)

theorem identity48524 : scanCanonicalize (H12AffineFastState.compose env48524 (packedSelected [2,3] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound48524 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env48525 : List Nat := [2,4,8,16,27,6,18,31,11,8,7,23,30,6,26,15,10,28,14,27,23,16,10,15,2,27,11,29,6,26,19,12,31,23,16,12]

theorem envBound48525 : H12AffineFastState.Bounded env48525 := by
  intro p hp
  have h : env48525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48524_48525 : H12AffineEnvironment.transform 4 27 env48524 = env48525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env48524 == env48525) = true)

theorem identity48525 : scanCanonicalize (H12AffineFastState.compose env48525 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound48525 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env48526 : List Nat := [2,4,3,16,16,6,18,20,0,3,7,23,21,6,17,4,1,23,5,16,23,16,1,4,2,16,0,22,6,17,19,7,20,23,16,7]

theorem envBound48526 : H12AffineFastState.Bounded env48526 := by
  intro p hp
  have h : env48526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48525_48526 : H12AffineEnvironment.transform 2 3 env48525 = env48526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env48525 == env48526) = true)

theorem identity48526 : scanCanonicalize (H12AffineFastState.compose env48526 (packedSelected [1,2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound48526 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env48527 : List Nat := [2,3,3,16,16,1,18,19,0,3,0,16,18,1,17,3,1,16,2,16,16,16,1,3,2,16,0,17,1,17,19,0,19,16,16,0]

theorem envBound48527 : H12AffineFastState.Bounded env48527 := by
  intro p hp
  have h : env48527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48526_48527 : H12AffineEnvironment.transform 1 3 env48526 = env48527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env48526 == env48527) = true)

def env48528 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1557,845,1297,528,65536,67363,65665,1877,529,1557,648,66162,66897,144,65910,1150,67442,1297,67602,832,67427,256,836,1345,340]

theorem envBound48528 : H12AffineFastState.Bounded env48528 := by
  intro p hp
  have h : env48528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48489_48528 : H12AffineEnvironment.transform 11 1557 env48489 = env48528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env48489 == env48528) = true)

def env48529 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,837,845,65,528,65536,66163,65665,517,529,837,648,66162,65537,144,65910,302,66082,65,67602,832,66099,256,836,17,340]

theorem envBound48529 : H12AffineFastState.Bounded env48529 := by
  intro p hp
  have h : env48529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48528_48529 : H12AffineEnvironment.transform 9 336 env48528 = env48529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env48528 == env48529) = true)

theorem identity48529 : scanCanonicalize (H12AffineFastState.compose env48529 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 47) := by decide +kernel

theorem selectedBound48529 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env48530 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,837,845,65,528,47,604,174,517,529,837,648,605,46,144,345,302,525,65,2109,832,540,256,836,17,340]

theorem envBound48530 : H12AffineFastState.Bounded env48530 := by
  intro p hp
  have h : env48530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48529_48530 : H12AffineEnvironment.transform 15 47 env48529 = env48530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 47 env48529 == env48530) = true)

def env48531 : List Nat := [2,4,8,16,32,64,128,256,276,336,2048,81,89,65,260,47,328,174,273,261,81,412,329,46,144,345,302,281,65,2109,84,264,256,80,17,340]

theorem envBound48531 : H12AffineFastState.Bounded env48531 := by
  intro p hp
  have h : env48531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48530_48531 : H12AffineEnvironment.transform 8 276 env48530 = env48531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env48530 == env48531) = true)

theorem identity48531 : scanCanonicalize (H12AffineFastState.compose env48531 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(5+1) ^^^ 29) := by decide +kernel

theorem selectedBound48531 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env48532 : List Nat := [2,4,8,16,32,29,128,256,276,269,2048,12,4,28,260,47,277,174,273,261,12,412,276,46,144,260,302,281,28,2109,9,264,256,13,17,265]

theorem envBound48532 : H12AffineFastState.Bounded env48532 := by
  intro p hp
  have h : env48532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48531_48532 : H12AffineEnvironment.transform 5 29 env48531 = env48532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 29 env48531 == env48532) = true)

theorem identity48532 : scanCanonicalize (H12AffineFastState.compose env48532 (packedSelected [1,2,5,12,17] rootPS)) = affineNative (2^(10+1) ^^^ 396) := by decide +kernel

theorem selectedBound48532 : packedSelected [1,2,5,12,17] rootPS < 2^1333 := by decide +kernel

def env48533 : List Nat := [2,4,8,16,32,29,128,256,276,269,396,12,4,28,260,47,277,174,273,261,12,412,276,46,144,260,302,281,28,433,9,264,256,13,17,265]

theorem envBound48533 : H12AffineFastState.Bounded env48533 := by
  intro p hp
  have h : env48533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48532_48533 : H12AffineEnvironment.transform 10 396 env48532 = env48533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 396 env48532 == env48533) = true)

theorem identity48533 : scanCanonicalize (H12AffineFastState.compose env48533 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound48533 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env48534 : List Nat := [2,4,8,0,32,13,128,256,260,269,396,12,4,12,260,47,261,174,257,261,12,396,260,46,128,260,302,265,12,417,9,264,256,13,1,265]

theorem envBound48534 : H12AffineFastState.Bounded env48534 := by
  intro p hp
  have h : env48534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48533_48534 : H12AffineEnvironment.transform 3 0 env48533 = env48534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env48533 == env48534) = true)

theorem identity48534 : scanCanonicalize (H12AffineFastState.compose env48534 (packedSelected [0,3,5,7,10,11] rootPS)) = affineNative (2^(7+1) ^^^ 129) := by decide +kernel

theorem selectedBound48534 : packedSelected [0,3,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env48535 : List Nat := [2,4,8,0,32,13,128,129,133,140,13,12,4,12,133,47,132,174,128,132,12,13,133,46,128,133,175,136,12,32,9,137,129,13,1,136]

theorem envBound48535 : H12AffineFastState.Bounded env48535 := by
  intro p hp
  have h : env48535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48534_48535 : H12AffineEnvironment.transform 7 129 env48534 = env48535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 129 env48534 == env48535) = true)

theorem identity48535 : scanCanonicalize (H12AffineFastState.compose env48535 (packedSelected [2,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound48535 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env48536 : List Nat := [2,4,8,0,10,13,128,129,133,140,13,12,4,12,133,5,132,132,128,132,12,13,133,4,128,133,133,136,12,10,9,137,129,13,1,136]

theorem envBound48536 : H12AffineFastState.Bounded env48536 := by
  intro p hp
  have h : env48536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48535_48536 : H12AffineEnvironment.transform 4 10 env48535 = env48536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env48535 == env48536) = true)

theorem identity48536 : scanCanonicalize (H12AffineFastState.compose env48536 (packedSelected [0,2,4,5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound48536 : packedSelected [0,2,4,5] rootPS < 2^1333 := by decide +kernel

def env48537 : List Nat := [2,4,2,0,0,7,128,129,133,134,7,6,4,6,133,5,132,132,128,132,6,7,133,4,128,133,133,130,6,0,3,131,129,7,1,130]

theorem envBound48537 : H12AffineFastState.Bounded env48537 := by
  intro p hp
  have h : env48537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48536_48537 : H12AffineEnvironment.transform 2 2 env48536 = env48537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env48536 == env48537) = true)

theorem identity48537 : scanCanonicalize (H12AffineFastState.compose env48537 (packedSelected [0,1,4] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound48537 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env48538 : List Nat := [2,4,2,0,0,7,3,2,6,5,7,6,4,6,6,5,7,7,3,7,6,7,6,4,3,6,6,1,6,0,3,0,2,7,1,1]

theorem envBound48538 : H12AffineFastState.Bounded env48538 := by
  intro p hp
  have h : env48538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48537_48538 : H12AffineEnvironment.transform 6 3 env48537 = env48538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env48537 == env48538) = true)

theorem identity48538 : scanCanonicalize (H12AffineFastState.compose env48538 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound48538 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48539 : List Nat := [2,3,2,0,0,0,3,2,1,2,0,1,3,1,1,2,0,0,3,0,1,0,1,3,3,1,1,1,1,0,3,0,2,0,1,1]

theorem envBound48539 : H12AffineFastState.Bounded env48539 := by
  intro p hp
  have h : env48539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48538_48539 : H12AffineEnvironment.transform 1 3 env48538 = env48539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env48538 == env48539) = true)

def env48540 : List Nat := [2,4,8,16,32,64,128,256,277,336,2048,80,88,65,261,47,329,174,272,260,80,413,328,46,144,345,302,280,65,2109,85,265,256,81,17,340]

theorem envBound48540 : H12AffineFastState.Bounded env48540 := by
  intro p hp
  have h : env48540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48530_48540 : H12AffineEnvironment.transform 8 277 env48530 = env48540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env48530 == env48540) = true)

theorem identity48540 : scanCanonicalize (H12AffineFastState.compose env48540 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound48540 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env48541 : List Nat := [2,4,8,12,32,64,128,256,265,332,2048,76,68,65,261,47,329,174,268,260,76,385,328,46,140,325,302,260,65,2081,73,265,256,77,13,328]

theorem envBound48541 : H12AffineFastState.Bounded env48541 := by
  intro p hp
  have h : env48541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48540_48541 : H12AffineEnvironment.transform 3 12 env48540 = env48541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env48540 == env48541) = true)

theorem identity48541 : scanCanonicalize (H12AffineFastState.compose env48541 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound48541 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env48542 : List Nat := [2,4,8,12,32,1,128,256,265,269,2048,13,5,0,261,47,264,174,268,260,13,385,265,46,140,260,302,260,0,2081,8,265,256,12,13,265]

theorem envBound48542 : H12AffineFastState.Bounded env48542 := by
  intro p hp
  have h : env48542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48541_48542 : H12AffineEnvironment.transform 5 1 env48541 = env48542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env48541 == env48542) = true)

theorem identity48542 : scanCanonicalize (H12AffineFastState.compose env48542 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 129) := by decide +kernel

theorem selectedBound48542 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env48543 : List Nat := [2,4,8,12,32,1,128,129,136,140,2048,13,5,0,132,47,137,174,141,133,13,0,136,46,140,133,175,133,0,2081,8,136,129,12,13,136]

theorem envBound48543 : H12AffineFastState.Bounded env48543 := by
  intro p hp
  have h : env48543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48542_48543 : H12AffineEnvironment.transform 7 129 env48542 = env48543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 129 env48542 == env48543) = true)

theorem identity48543 : scanCanonicalize (H12AffineFastState.compose env48543 (packedSelected [0,2,3,5,7,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 38) := by decide +kernel

theorem selectedBound48543 : packedSelected [0,2,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env48544 : List Nat := [2,4,8,12,32,1,128,129,136,140,38,13,5,0,132,47,137,174,141,133,13,0,136,46,140,133,175,133,0,7,8,136,129,12,13,136]

theorem envBound48544 : H12AffineFastState.Bounded env48544 := by
  intro p hp
  have h : env48544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48543_48544 : H12AffineEnvironment.transform 10 38 env48543 = env48544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 38 env48543 == env48544) = true)

theorem identity48544 : scanCanonicalize (H12AffineFastState.compose env48544 (packedSelected [2,3,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 46) := by decide +kernel

theorem selectedBound48544 : packedSelected [2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env48545 : List Nat := [2,4,8,12,32,1,46,47,38,34,38,13,5,0,42,47,39,0,35,43,13,0,38,46,34,43,1,43,0,7,8,38,47,12,13,38]

theorem envBound48545 : H12AffineFastState.Bounded env48545 := by
  intro p hp
  have h : env48545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48544_48545 : H12AffineEnvironment.transform 6 46 env48544 = env48545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 46 env48544 == env48545) = true)

theorem identity48545 : scanCanonicalize (H12AffineFastState.compose env48545 (packedSelected [0,1,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound48545 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env48546 : List Nat := [2,4,2,6,32,1,36,37,38,34,38,7,5,0,32,37,39,0,35,33,7,0,38,36,34,33,1,33,0,7,2,38,37,6,7,38]

theorem envBound48546 : H12AffineFastState.Bounded env48546 := by
  intro p hp
  have h : env48546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48545_48546 : H12AffineEnvironment.transform 2 2 env48545 = env48546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env48545 == env48546) = true)

def env48547 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,836,845,64,528,65536,66162,65665,516,529,836,648,66162,65536,144,65910,303,66083,64,67602,832,66098,256,836,16,340]

theorem envBound48547 : H12AffineFastState.Bounded env48547 := by
  intro p hp
  have h : env48547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48528_48547 : H12AffineEnvironment.transform 9 337 env48528 = env48547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env48528 == env48547) = true)

theorem identity48547 : scanCanonicalize (H12AffineFastState.compose env48547 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 826) := by decide +kernel

theorem selectedBound48547 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env48548 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,836,845,64,528,826,328,955,516,529,836,648,328,826,144,588,303,281,64,2856,832,264,256,836,16,340]

theorem envBound48548 : H12AffineFastState.Bounded env48548 := by
  intro p hp
  have h : env48548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48547_48548 : H12AffineEnvironment.transform 15 826 env48547 = env48548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 826 env48547 == env48548) = true)

def env48549 : List Nat := [2,4,8,16,32,64,128,256,276,337,2048,80,89,64,260,46,328,175,272,261,80,412,328,46,144,344,303,281,64,2108,84,264,256,80,16,340]

theorem envBound48549 : H12AffineFastState.Bounded env48549 := by
  intro p hp
  have h : env48549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48548_48549 : H12AffineEnvironment.transform 8 276 env48548 = env48549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env48548 == env48549) = true)

theorem identity48549 : scanCanonicalize (H12AffineFastState.compose env48549 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound48549 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env48550 : List Nat := [2,4,8,12,32,64,128,256,264,333,2048,76,69,64,260,46,328,175,268,261,76,384,328,46,140,324,303,261,64,2080,72,264,256,76,12,328]

theorem envBound48550 : H12AffineFastState.Bounded env48550 := by
  intro p hp
  have h : env48550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48549_48550 : H12AffineEnvironment.transform 3 12 env48549 = env48550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env48549 == env48550) = true)

theorem identity48550 : scanCanonicalize (H12AffineFastState.compose env48550 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound48550 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env48551 : List Nat := [2,4,8,12,32,0,128,256,264,269,2048,12,5,0,260,46,264,175,268,261,12,384,264,46,140,260,303,261,0,2080,8,264,256,12,12,264]

theorem envBound48551 : H12AffineFastState.Bounded env48551 := by
  intro p hp
  have h : env48551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48550_48551 : H12AffineEnvironment.transform 5 0 env48550 = env48551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env48550 == env48551) = true)

theorem identity48551 : scanCanonicalize (H12AffineFastState.compose env48551 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 128) := by decide +kernel

theorem selectedBound48551 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env48552 : List Nat := [2,4,8,12,32,0,128,128,136,141,2048,12,5,0,132,46,136,175,140,133,12,0,136,46,140,132,175,133,0,2080,8,136,128,12,12,136]

theorem envBound48552 : H12AffineFastState.Bounded env48552 := by
  intro p hp
  have h : env48552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48551_48552 : H12AffineEnvironment.transform 7 128 env48551 = env48552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 128 env48551 == env48552) = true)

theorem identity48552 : scanCanonicalize (H12AffineFastState.compose env48552 (packedSelected [0,2,3,5,7,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 174) := by decide +kernel

theorem selectedBound48552 : packedSelected [0,2,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env48553 : List Nat := [2,4,8,12,32,0,128,128,136,141,174,12,5,0,132,46,136,175,140,133,12,0,136,46,140,132,175,133,0,142,8,136,128,12,12,136]

theorem envBound48553 : H12AffineFastState.Bounded env48553 := by
  intro p hp
  have h : env48553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48552_48553 : H12AffineEnvironment.transform 10 174 env48552 = env48553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 174 env48552 == env48553) = true)

theorem identity48553 : scanCanonicalize (H12AffineFastState.compose env48553 (packedSelected [2,4] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound48553 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env48554 : List Nat := [2,4,8,12,32,0,8,8,0,5,38,12,5,0,12,46,0,39,4,13,12,0,0,46,4,12,39,13,0,6,8,0,8,12,12,0]

theorem envBound48554 : H12AffineFastState.Bounded env48554 := by
  intro p hp
  have h : env48554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48553_48554 : H12AffineEnvironment.transform 6 8 env48553 = env48554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48553 == env48554) = true)

theorem identity48554 : scanCanonicalize (H12AffineFastState.compose env48554 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound48554 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48555 : List Nat := [2,4,8,12,10,0,8,8,0,5,12,12,5,0,12,4,0,13,4,13,12,0,0,4,4,12,13,13,0,6,8,0,8,12,12,0]

theorem envBound48555 : H12AffineFastState.Bounded env48555 := by
  intro p hp
  have h : env48555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48554_48555 : H12AffineEnvironment.transform 4 10 env48554 = env48555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env48554 == env48555) = true)

theorem identity48555 : scanCanonicalize (H12AffineFastState.compose env48555 (packedSelected [0,2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound48555 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env48556 : List Nat := [2,3,8,11,10,0,8,8,0,2,11,11,2,0,11,3,0,10,3,10,11,0,0,3,3,11,10,10,0,1,8,0,8,11,11,0]

theorem envBound48556 : H12AffineFastState.Bounded env48556 := by
  intro p hp
  have h : env48556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48555_48556 : H12AffineEnvironment.transform 1 3 env48555 = env48556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env48555 == env48556) = true)

def env48557 : List Nat := [2,4,8,16,32,64,128,256,277,337,2048,81,88,64,261,47,328,174,273,260,81,413,328,47,144,345,303,281,64,2109,85,264,256,81,16,340]

theorem envBound48557 : H12AffineFastState.Bounded env48557 := by
  intro p hp
  have h : env48557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48548_48557 : H12AffineEnvironment.transform 8 277 env48548 = env48557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env48548 == env48557) = true)

theorem identity48557 : scanCanonicalize (H12AffineFastState.compose env48557 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(5+1) ^^^ 29) := by decide +kernel

theorem selectedBound48557 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env48558 : List Nat := [2,4,8,16,32,29,128,256,277,268,2048,12,5,29,261,47,277,174,273,260,12,413,277,47,144,260,303,281,29,2109,8,264,256,12,16,265]

theorem envBound48558 : H12AffineFastState.Bounded env48558 := by
  intro p hp
  have h : env48558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48557_48558 : H12AffineEnvironment.transform 5 29 env48557 = env48558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 29 env48557 == env48558) = true)

theorem identity48558 : scanCanonicalize (H12AffineFastState.compose env48558 (packedSelected [1,2,5,12,17] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound48558 : packedSelected [1,2,5,12,17] rootPS < 2^1333 := by decide +kernel

def env48559 : List Nat := [2,4,8,16,32,29,128,256,277,268,136,12,5,29,261,47,277,174,273,260,12,413,277,47,144,260,303,281,29,181,8,264,256,12,16,265]

theorem envBound48559 : H12AffineFastState.Bounded env48559 := by
  intro p hp
  have h : env48559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48558_48559 : H12AffineEnvironment.transform 10 136 env48558 = env48559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env48558 == env48559) = true)

theorem identity48559 : scanCanonicalize (H12AffineFastState.compose env48559 (packedSelected [0,2,4,5,7,9,11,13,15,16] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound48559 : packedSelected [0,2,4,5,7,9,11,13,15,16] rootPS < 2^1333 := by decide +kernel

def env48560 : List Nat := [2,4,8,16,32,29,9,256,277,268,1,12,5,29,261,47,277,39,273,260,12,276,277,47,25,260,303,281,29,60,8,264,256,12,16,265]

theorem envBound48560 : H12AffineFastState.Bounded env48560 := by
  intro p hp
  have h : env48560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48559_48560 : H12AffineEnvironment.transform 6 9 env48559 = env48560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48559 == env48560) = true)

theorem identity48560 : scanCanonicalize (H12AffineFastState.compose env48560 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound48560 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env48561 : List Nat := [2,4,8,0,32,13,9,256,261,268,1,12,5,13,261,47,261,39,257,260,12,260,261,47,9,260,303,265,13,44,8,264,256,12,0,265]

theorem envBound48561 : H12AffineFastState.Bounded env48561 := by
  intro p hp
  have h : env48561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48560_48561 : H12AffineEnvironment.transform 3 0 env48560 = env48561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env48560 == env48561) = true)

theorem identity48561 : scanCanonicalize (H12AffineFastState.compose env48561 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound48561 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48562 : List Nat := [2,4,8,0,0,13,9,256,261,268,1,12,5,13,261,15,261,7,257,260,12,260,261,15,9,260,271,265,13,12,8,264,256,12,0,265]

theorem envBound48562 : H12AffineFastState.Bounded env48562 := by
  intro p hp
  have h : env48562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48561_48562 : H12AffineEnvironment.transform 4 0 env48561 = env48562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env48561 == env48562) = true)

theorem identity48562 : scanCanonicalize (H12AffineFastState.compose env48562 (packedSelected [0,1,4] rootPS)) = affineNative (2^(7+1) ^^^ 9) := by decide +kernel

theorem selectedBound48562 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env48563 : List Nat := [2,4,8,0,0,13,9,9,12,5,1,12,5,13,12,15,12,7,8,13,12,13,12,15,9,13,6,0,13,12,8,1,9,12,0,0]

theorem envBound48563 : H12AffineFastState.Bounded env48563 := by
  intro p hp
  have h : env48563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48562_48563 : H12AffineEnvironment.transform 7 9 env48562 = env48563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 9 env48562 == env48563) = true)

theorem identity48563 : scanCanonicalize (H12AffineFastState.compose env48563 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound48563 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48564 : List Nat := [2,4,5,0,0,0,4,4,1,5,1,1,5,0,1,2,1,7,5,0,1,0,1,2,4,0,6,0,0,1,5,1,4,1,0,0]

theorem envBound48564 : H12AffineFastState.Bounded env48564 := by
  intro p hp
  have h : env48564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48563_48564 : H12AffineEnvironment.transform 2 5 env48563 = env48564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env48563 == env48564) = true)

theorem identity48564 : scanCanonicalize (H12AffineFastState.compose env48564 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound48564 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48565 : List Nat := [2,1,0,0,0,0,1,1,1,0,1,1,0,0,1,2,1,2,0,0,1,0,1,2,1,0,3,0,0,1,0,1,1,1,0,0]

theorem envBound48565 : H12AffineFastState.Bounded env48565 := by
  intro p hp
  have h : env48565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48564_48565 : H12AffineEnvironment.transform 1 1 env48564 = env48565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env48564 == env48565) = true)

theorem identity48565 : scanCanonicalize (H12AffineFastState.compose env48565 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound48565 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env48566 : List Nat := [0,1,0,0,0,0,1,1,1,0,1,1,0,0,1,0,1,0,0,0,1,0,1,0,1,0,1,0,0,1,0,1,1,1,0,0]

theorem envBound48566 : H12AffineFastState.Bounded env48566 := by
  intro p hp
  have h : env48566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48565_48566 : H12AffineEnvironment.transform 0 0 env48565 = env48566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env48565 == env48566) = true)

def env48567 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,533640,672785,17245633,148800,545088,96347,16876545,618623,256,16876549,1344,525825]

theorem envBound48567 : H12AffineFastState.Bounded env48567 := by
  intro p hp
  have h : env48567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47785_48567 : H12AffineEnvironment.transform 26 17245633 env47785 = env48567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env47785 == env48567) = true)

theorem identity48567 : scanCanonicalize (H12AffineFastState.compose env48567 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(18+1) ^^^ 95615) := by decide +kernel

theorem selectedBound48567 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env48568 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95615,32769,4096,61649,147520,16777216,86519,209262,17245633,148800,74815,96347,16876545,1280,256,16876549,1344,95102]

theorem envBound48568 : H12AffineFastState.Bounded env48568 := by
  intro p hp
  have h : env48568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48567_48568 : H12AffineEnvironment.transform 18 95615 env48567 = env48568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 95615 env48567 == env48568) = true)

def env48569 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95615,32769,4096,61649,147520,284032,86519,209262,225345,148800,74815,96347,381313,1280,256,381317,1344,95102]

theorem envBound48569 : H12AffineFastState.Bounded env48569 := by
  intro p hp
  have h : env48569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48568_48569 : H12AffineEnvironment.transform 23 284032 env48568 = env48569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284032 env48568 == env48569) = true)

def env48570 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16464,262144,95615,32769,4096,61649,16,284032,86519,94526,77841,1296,74815,96347,381313,1280,256,381317,1344,95102]

theorem envBound48570 : H12AffineFastState.Bounded env48570 := by
  intro p hp
  have h : env48570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48569_48570 : H12AffineEnvironment.transform 16 16464 env48569 = env48570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16464 env48569 == env48570) = true)

def env48571 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1344,262144,77935,32769,4096,46529,16,266384,70887,78894,77841,1296,74815,81227,365713,1280,256,365717,1344,79470]

theorem envBound48571 : H12AffineFastState.Bounded env48571 := by
  intro p hp
  have h : env48571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48570_48571 : H12AffineEnvironment.transform 13 1296 env48570 = env48571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env48570 == env48571) = true)

theorem identity48571 : scanCanonicalize (H12AffineFastState.compose env48571 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound48571 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env48572 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1344,262144,77935,13340,4096,476,16,266384,70887,78894,77841,1296,74815,81227,336012,1280,256,336008,1344,79470]

theorem envBound48572 : H12AffineFastState.Bounded env48572 := by
  intro p hp
  have h : env48572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48571_48572 : H12AffineEnvironment.transform 14 13341 env48571 = env48572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env48571 == env48572) = true)

def env48573 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1344,65664,77935,13340,4096,476,16,69648,70887,78894,77841,1296,74815,81227,8204,1280,256,8200,1344,79470]

theorem envBound48573 : H12AffineFastState.Bounded env48573 := by
  intro p hp
  have h : env48573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48572_48573 : H12AffineEnvironment.transform 17 65664 env48572 = env48573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env48572 == env48573) = true)

theorem identity48573 : scanCanonicalize (H12AffineFastState.compose env48573 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5238) := by decide +kernel

theorem selectedBound48573 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env48574 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,5238,1344,5366,9241,13340,4096,476,16,1126,145,8280,9319,1296,12361,10557,8204,1280,256,8200,1344,8728]

theorem envBound48574 : H12AffineFastState.Bounded env48574 := by
  intro p hp
  have h : env48574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48573_48574 : H12AffineEnvironment.transform 15 5238 env48573 = env48574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5238 env48573 == env48574) = true)

def env48575 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,1296,13341,5158,1296,5286,9241,13340,4096,396,16,1078,145,8200,9271,1296,12313,10557,8204,1280,256,8200,1296,8728]

theorem envBound48575 : H12AffineFastState.Bounded env48575 := by
  intro p hp
  have h : env48575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48574_48575 : H12AffineEnvironment.transform 5 16 env48574 = env48575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48574 == env48575) = true)

theorem identity48575 : scanCanonicalize (H12AffineFastState.compose env48575 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 5148) := by decide +kernel

theorem selectedBound48575 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env48576 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5148,1296,1,5158,1296,5286,4101,0,4096,396,16,1078,145,5140,4139,1296,1029,7457,5136,1280,256,5140,1296,5636]

theorem envBound48576 : H12AffineFastState.Bounded env48576 := by
  intro p hp
  have h : env48576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48575_48576 : H12AffineEnvironment.transform 12 5148 env48575 = env48576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5148 env48575 == env48576) = true)

theorem identity48576 : scanCanonicalize (H12AffineFastState.compose env48576 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound48576 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env48577 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,269,1296,1,311,1296,439,1300,0,1297,396,16,1078,145,261,1338,1296,1029,2096,257,1280,256,261,1296,789]

theorem envBound48577 : H12AffineFastState.Bounded env48577 := by
  intro p hp
  have h : env48577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48576_48577 : H12AffineEnvironment.transform 11 1297 env48576 = env48577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env48576 == env48577) = true)

theorem identity48577 : scanCanonicalize (H12AffineFastState.compose env48577 (packedSelected [0,2,7,10,12,13,15,18,19] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound48577 : packedSelected [0,2,7,10,12,13,15,18,19] rootPS < 2^1333 := by decide +kernel

def env48578 : List Nat := [2,4,8,16,32,16,128,256,277,1024,2048,1297,269,1296,1,311,1296,439,1300,0,1297,396,16,1078,145,261,1338,1296,1029,2096,257,1280,256,261,1296,0]

theorem envBound48578 : H12AffineFastState.Bounded env48578 := by
  intro p hp
  have h : env48578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48577_48578 : H12AffineEnvironment.transform 8 277 env48577 = env48578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env48577 == env48578) = true)

theorem identity48578 : scanCanonicalize (H12AffineFastState.compose env48578 (packedSelected [2,3,5,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound48578 : packedSelected [2,3,5,12,15] rootPS < 2^1333 := by decide +kernel

def env48579 : List Nat := [2,4,8,16,32,16,128,14,27,1024,2048,1055,3,1054,1,57,1054,185,1050,0,1055,130,16,1078,145,11,1076,1054,1029,2096,15,1038,14,11,1054,0]

theorem envBound48579 : H12AffineFastState.Bounded env48579 := by
  intro p hp
  have h : env48579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48578_48579 : H12AffineEnvironment.transform 7 14 env48578 = env48579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env48578 == env48579) = true)

def env48580 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1296,13341,5159,1297,5287,9241,13340,4096,397,16,1079,145,8201,9270,1296,12312,10557,8204,1280,256,8200,1297,8728]

theorem envBound48580 : H12AffineFastState.Bounded env48580 := by
  intro p hp
  have h : env48580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48574_48580 : H12AffineEnvironment.transform 5 17 env48574 = env48580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env48574 == env48580) = true)

theorem identity48580 : scanCanonicalize (H12AffineFastState.compose env48580 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound48580 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env48581 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1028,8192,1296,8217,35,1297,163,9241,8216,1028,397,16,1079,145,8201,9270,1296,9244,10557,8204,1280,256,8200,1297,8728]

theorem envBound48581 : H12AffineFastState.Bounded env48581 := by
  intro p hp
  have h : env48581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48580_48581 : H12AffineEnvironment.transform 11 1028 env48580 = env48581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env48580 == env48581) = true)

theorem identity48581 : scanCanonicalize (H12AffineFastState.compose env48581 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound48581 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env48582 : List Nat := [2,4,8,16,32,17,128,21,512,1024,2048,1028,8192,1029,8217,35,1028,163,9241,8216,1028,152,16,1079,145,8201,9270,1029,9244,10280,8204,1045,21,8200,1028,8728]

theorem envBound48582 : H12AffineFastState.Bounded env48582 := by
  intro p hp
  have h : env48582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48581_48582 : H12AffineEnvironment.transform 7 21 env48581 = env48582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env48581 == env48582) = true)

theorem identity48582 : scanCanonicalize (H12AffineFastState.compose env48582 (packedSelected [0,1,3,5,7,8,11,12,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 3126) := by decide +kernel

theorem selectedBound48582 : packedSelected [0,1,3,5,7,8,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env48583 : List Nat := [2,4,8,16,32,17,128,21,512,1024,2048,1028,3126,1029,3119,35,1028,163,2095,3118,1028,152,16,1079,145,3135,2048,1029,2090,1054,3130,1045,21,3134,1028,3630]

theorem envBound48583 : H12AffineFastState.Bounded env48583 := by
  intro p hp
  have h : env48583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48582_48583 : H12AffineEnvironment.transform 12 3126 env48582 = env48583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3126 env48582 == env48583) = true)

theorem identity48583 : scanCanonicalize (H12AffineFastState.compose env48583 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound48583 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env48584 : List Nat := [2,4,8,16,32,17,57,21,512,1024,2048,1028,3126,1029,3119,35,1028,26,2095,3118,1028,33,16,1079,40,3135,2048,1029,2090,1054,3130,1045,21,3134,1028,3630]

theorem envBound48584 : H12AffineFastState.Bounded env48584 := by
  intro p hp
  have h : env48584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48583_48584 : H12AffineEnvironment.transform 6 57 env48583 = env48584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env48583 == env48584) = true)

theorem identity48584 : scanCanonicalize (H12AffineFastState.compose env48584 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound48584 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env48585 : List Nat := [2,4,8,16,32,17,57,21,512,1024,513,1028,1591,1029,1582,35,1028,26,558,1583,1028,33,16,1079,40,1598,513,1029,555,1054,1595,1045,21,1599,1028,1071]

theorem envBound48585 : H12AffineFastState.Bounded env48585 := by
  intro p hp
  have h : env48585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48584_48585 : H12AffineEnvironment.transform 10 513 env48584 = env48585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env48584 == env48585) = true)

theorem identity48585 : scanCanonicalize (H12AffineFastState.compose env48585 (packedSelected [0,1,5,7,11] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound48585 : packedSelected [0,1,5,7,11] rootPS < 2^1333 := by decide +kernel

def env48586 : List Nat := [2,4,8,16,32,17,57,21,512,46,513,42,537,43,512,35,42,26,558,513,42,33,16,25,40,528,513,43,555,48,533,59,21,529,42,1]

theorem envBound48586 : H12AffineFastState.Bounded env48586 := by
  intro p hp
  have h : env48586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48585_48586 : H12AffineEnvironment.transform 9 46 env48585 = env48586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env48585 == env48586) = true)

theorem identity48586 : scanCanonicalize (H12AffineFastState.compose env48586 (packedSelected [1,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound48586 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env48587 : List Nat := [2,4,8,16,11,17,18,21,512,5,513,1,537,0,512,8,1,26,517,513,1,10,16,25,3,528,513,0,512,27,533,16,21,529,1,1]

theorem envBound48587 : H12AffineFastState.Bounded env48587 := by
  intro p hp
  have h : env48587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48586_48587 : H12AffineEnvironment.transform 4 11 env48586 = env48587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env48586 == env48587) = true)

theorem identity48587 : scanCanonicalize (H12AffineFastState.compose env48587 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound48587 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env48588 : List Nat := [2,4,8,11,11,10,9,14,512,5,513,1,514,0,512,8,1,1,517,513,1,10,11,2,3,523,513,0,512,0,526,11,14,522,1,1]

theorem envBound48588 : H12AffineFastState.Bounded env48588 := by
  intro p hp
  have h : env48588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48587_48588 : H12AffineEnvironment.transform 3 11 env48587 = env48588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env48587 == env48588) = true)

theorem identity48588 : scanCanonicalize (H12AffineFastState.compose env48588 (packedSelected [0,1,4] rootPS)) = affineNative (2^(8+1) ^^^ 13) := by decide +kernel

theorem selectedBound48588 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env48589 : List Nat := [2,4,8,11,11,10,9,14,13,5,12,1,15,0,13,8,1,1,8,12,1,10,11,2,3,6,12,0,13,0,3,11,14,7,1,1]

theorem envBound48589 : H12AffineFastState.Bounded env48589 := by
  intro p hp
  have h : env48589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48588_48589 : H12AffineEnvironment.transform 8 13 env48588 = env48589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 13 env48588 == env48589) = true)

theorem identity48589 : scanCanonicalize (H12AffineFastState.compose env48589 (packedSelected [0,1,9] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound48589 : packedSelected [0,1,9] rootPS < 2^1333 := by decide +kernel

def env48590 : List Nat := [2,4,4,7,7,6,5,2,1,5,0,1,3,0,1,4,1,1,4,0,1,6,7,2,3,6,0,0,1,0,3,7,2,7,1,1]

theorem envBound48590 : H12AffineFastState.Bounded env48590 := by
  intro p hp
  have h : env48590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48589_48590 : H12AffineEnvironment.transform 2 4 env48589 = env48590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env48589 == env48590) = true)

def env48591 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1344,65665,77935,13340,4096,476,16,69649,70887,78894,77841,1296,74815,81227,8205,1280,256,8201,1344,79470]

theorem envBound48591 : H12AffineFastState.Bounded env48591 := by
  intro p hp
  have h : env48591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48572_48591 : H12AffineEnvironment.transform 17 65665 env48572 = env48591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env48572 == env48591) = true)

theorem identity48591 : scanCanonicalize (H12AffineFastState.compose env48591 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 310) := by decide +kernel

theorem selectedBound48591 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env48592 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,310,1344,439,12633,13340,4096,476,16,4391,5585,13592,12583,1296,9481,15485,8205,1280,256,8201,1344,14168]

theorem envBound48592 : H12AffineFastState.Bounded env48592 := by
  intro p hp
  have h : env48592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48591_48592 : H12AffineEnvironment.transform 15 310 env48591 = env48592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 310 env48591 == env48592) = true)

def env48593 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,24,1296,5125,310,1344,439,4417,5124,4096,476,16,4391,5585,5376,4415,1296,1297,7269,21,1280,256,17,1344,5952]

theorem envBound48593 : H12AffineFastState.Bounded env48593 := by
  intro p hp
  have h : env48593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48592_48593 : H12AffineEnvironment.transform 12 24 env48592 = env48593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env48592 == env48593) = true)

theorem identity48593 : scanCanonicalize (H12AffineFastState.compose env48593 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound48593 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env48594 : List Nat := [2,4,8,16,32,64,128,20,512,1024,2048,4096,24,1028,5125,34,1108,163,4181,5124,4096,200,16,4147,5317,5140,4139,1028,1029,7269,21,1044,20,17,1108,5716]

theorem envBound48594 : H12AffineFastState.Bounded env48594 := by
  intro p hp
  have h : env48594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48593_48594 : H12AffineEnvironment.transform 7 20 env48593 = env48594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env48593 == env48594) = true)

theorem identity48594 : scanCanonicalize (H12AffineFastState.compose env48594 (packedSelected [3,4,9,10,13,17,18,19,20,23,24] rootPS)) = affineNative (2^(11+1) ^^^ 2195) := by decide +kernel

theorem selectedBound48594 : packedSelected [3,4,9,10,13,17,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env48595 : List Nat := [2,4,8,16,32,64,128,20,512,1024,2048,2195,24,1028,3222,34,1108,163,2246,3223,2195,200,16,2208,3158,3207,2232,1028,1029,1270,21,1044,20,17,1108,3783]

theorem envBound48595 : H12AffineFastState.Bounded env48595 := by
  intro p hp
  have h : env48595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48594_48595 : H12AffineEnvironment.transform 11 2195 env48594 = env48595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2195 env48594 == env48595) = true)

theorem identity48595 : scanCanonicalize (H12AffineFastState.compose env48595 (packedSelected [1,3,4,5,8,9,11,12,13,15,16,18] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound48595 : packedSelected [1,3,4,5,8,9,11,12,13,15,16,18] rootPS < 2^1333 := by decide +kernel

def env48596 : List Nat := [2,4,8,16,17,64,128,20,512,1024,2048,2195,24,1028,3222,19,1108,146,2246,3223,2195,200,16,2193,3158,3207,2185,1028,1029,1223,21,1044,20,17,1108,3783]

theorem envBound48596 : H12AffineFastState.Bounded env48596 := by
  intro p hp
  have h : env48596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48595_48596 : H12AffineEnvironment.transform 4 17 env48595 = env48596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env48595 == env48596) = true)

theorem identity48596 : scanCanonicalize (H12AffineFastState.compose env48596 (packedSelected [5,8,10,11,12,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 1174) := by decide +kernel

theorem selectedBound48596 : packedSelected [5,8,10,11,12,15,16] rootPS < 2^1333 := by decide +kernel

def env48597 : List Nat := [2,4,8,16,17,64,128,20,512,1024,1174,1029,24,1028,0,19,1108,146,1104,1,1029,200,16,1031,192,17,1055,1028,1029,1223,21,1044,20,17,1108,593]

theorem envBound48597 : H12AffineFastState.Bounded env48597 := by
  intro p hp
  have h : env48597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48596_48597 : H12AffineEnvironment.transform 10 1174 env48596 = env48597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1174 env48596 == env48597) = true)

theorem identity48597 : scanCanonicalize (H12AffineFastState.compose env48597 (packedSelected [0,2,3,7,8,11] rootPS)) = affineNative (2^(8+1) ^^^ 194) := by decide +kernel

theorem selectedBound48597 : packedSelected [0,2,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env48598 : List Nat := [2,4,8,16,17,64,128,20,194,1024,1174,1029,24,1028,0,19,1108,146,1104,1,1029,200,16,1031,192,17,1055,1028,1029,1223,21,1044,20,17,1108,147]

theorem envBound48598 : H12AffineFastState.Bounded env48598 := by
  intro p hp
  have h : env48598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48597_48598 : H12AffineEnvironment.transform 8 194 env48597 = env48598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 194 env48597 == env48598) = true)

theorem identity48598 : scanCanonicalize (H12AffineFastState.compose env48598 (packedSelected [0,1,4,5,7,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound48598 : packedSelected [0,1,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env48599 : List Nat := [2,4,8,16,17,11,128,20,137,1024,1174,1029,24,1028,0,19,1055,146,1051,1,1029,131,16,1031,139,17,1055,1028,1029,1164,21,1044,20,17,1055,147]

theorem envBound48599 : H12AffineFastState.Bounded env48599 := by
  intro p hp
  have h : env48599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48598_48599 : H12AffineEnvironment.transform 5 11 env48598 = env48599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env48598 == env48599) = true)

theorem identity48599 : scanCanonicalize (H12AffineFastState.compose env48599 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound48599 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env48600 : List Nat := [2,4,8,11,10,11,128,15,137,1024,1165,1029,3,1028,0,8,1028,137,1024,1,1029,131,11,1031,139,10,1028,1028,1029,1164,14,1039,15,10,1028,136]

theorem envBound48600 : H12AffineFastState.Bounded env48600 := by
  intro p hp
  have h : env48600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48599_48600 : H12AffineEnvironment.transform 3 11 env48599 = env48600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env48599 == env48600) = true)

theorem identity48600 : scanCanonicalize (H12AffineFastState.compose env48600 (packedSelected [0,1,2] rootPS)) = affineNative (2^(9+1) ^^^ 13) := by decide +kernel

theorem selectedBound48600 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env48601 : List Nat := [2,4,8,11,10,11,128,15,137,13,128,8,3,9,0,8,9,137,13,1,8,131,11,10,139,10,9,9,8,129,14,2,15,10,9,136]

theorem envBound48601 : H12AffineFastState.Bounded env48601 := by
  intro p hp
  have h : env48601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48600_48601 : H12AffineEnvironment.transform 9 13 env48600 = env48601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 13 env48600 == env48601) = true)

theorem identity48601 : scanCanonicalize (H12AffineFastState.compose env48601 (packedSelected [0,3] rootPS)) = affineNative (2^(6+1) ^^^ 1) := by decide +kernel

theorem selectedBound48601 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env48602 : List Nat := [2,4,8,11,10,11,1,15,8,13,1,8,3,9,0,8,9,8,13,1,8,2,11,10,10,10,9,9,8,0,14,2,15,10,9,9]

theorem envBound48602 : H12AffineFastState.Bounded env48602 := by
  intro p hp
  have h : env48602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48601_48602 : H12AffineEnvironment.transform 6 1 env48601 = env48602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 1 env48601 == env48602) = true)

theorem identity48602 : scanCanonicalize (H12AffineFastState.compose env48602 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound48602 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env48603 : List Nat := [2,4,0,3,2,3,1,7,0,5,1,0,3,1,0,0,1,0,5,1,0,2,3,2,2,2,1,1,0,0,6,2,7,2,1,1]

theorem envBound48603 : H12AffineFastState.Bounded env48603 := by
  intro p hp
  have h : env48603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48602_48603 : H12AffineEnvironment.transform 2 0 env48602 = env48603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env48602 == env48603) = true)

theorem identity48603 : scanCanonicalize (H12AffineFastState.compose env48603 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound48603 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48604 : List Nat := [2,0,0,3,2,3,1,3,0,1,1,0,3,1,0,0,1,0,1,1,0,2,3,2,2,2,1,1,0,0,2,2,3,2,1,1]

theorem envBound48604 : H12AffineFastState.Bounded env48604 := by
  intro p hp
  have h : env48604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48603_48604 : H12AffineEnvironment.transform 1 0 env48603 = env48604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env48603 == env48604) = true)

theorem identity48604 : scanCanonicalize (H12AffineFastState.compose env48604 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound48604 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env48605 : List Nat := [1,0,0,0,1,0,1,0,0,1,1,0,0,1,0,0,1,0,1,1,0,1,0,1,1,1,1,1,0,0,1,1,0,1,1,1]

theorem envBound48605 : H12AffineFastState.Bounded env48605 := by
  intro p hp
  have h : env48605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48604_48605 : H12AffineEnvironment.transform 0 1 env48604 = env48605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env48604 == env48605) = true)

def env48606 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,25,1296,5124,310,1344,439,4416,5125,4096,476,16,4391,5585,5377,4414,1296,1296,7268,20,1280,256,16,1344,5953]

theorem envBound48606 : H12AffineFastState.Bounded env48606 := by
  intro p hp
  have h : env48606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48592_48606 : H12AffineEnvironment.transform 12 25 env48592 = env48606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env48592 == env48606) = true)

theorem identity48606 : scanCanonicalize (H12AffineFastState.compose env48606 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound48606 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env48607 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,25,80,4420,310,0,439,4416,4421,4096,476,16,4391,4241,4161,4414,80,80,6436,20,64,256,16,0,4609]

theorem envBound48607 : H12AffineFastState.Bounded env48607 := by
  intro p hp
  have h : env48607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48606_48607 : H12AffineEnvironment.transform 9 320 env48606 = env48607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env48606 == env48607) = true)

theorem identity48607 : scanCanonicalize (H12AffineFastState.compose env48607 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(10+1) ^^^ 318) := by decide +kernel

theorem selectedBound48607 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env48608 : List Nat := [2,4,8,16,32,64,128,256,512,320,318,4096,25,80,4420,310,0,439,4416,4421,4096,476,16,4391,4241,4161,4414,80,80,4122,20,64,256,16,0,4609]

theorem envBound48608 : H12AffineFastState.Bounded env48608 := by
  intro p hp
  have h : env48608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48607_48608 : H12AffineEnvironment.transform 10 318 env48607 = env48608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 318 env48607 == env48608) = true)

theorem identity48608 : scanCanonicalize (H12AffineFastState.compose env48608 (packedSelected [1,3,10,11,16] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound48608 : packedSelected [1,3,10,11,16] rootPS < 2^1333 := by decide +kernel

def env48609 : List Nat := [2,4,8,16,32,64,128,256,81,320,318,4096,25,80,4420,310,0,439,4416,4421,4096,476,16,4391,4241,4161,4414,80,80,4122,20,64,256,16,0,4176]

theorem envBound48609 : H12AffineFastState.Bounded env48609 := by
  intro p hp
  have h : env48609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48608_48609 : H12AffineEnvironment.transform 8 81 env48608 = env48609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env48608 == env48609) = true)

theorem identity48609 : scanCanonicalize (H12AffineFastState.compose env48609 (packedSelected [1,3,4,9,10,11,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound48609 : packedSelected [1,3,4,9,10,11,13,17] rootPS < 2^1333 := by decide +kernel

def env48610 : List Nat := [2,4,8,16,32,64,128,69,81,5,123,4096,25,80,4097,115,0,242,4101,4096,4096,153,16,4194,4241,4161,4219,80,80,4122,20,64,69,16,0,4176]

theorem envBound48610 : H12AffineFastState.Bounded env48610 := by
  intro p hp
  have h : env48610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48609_48610 : H12AffineEnvironment.transform 7 69 env48609 = env48610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env48609 == env48610) = true)

theorem identity48610 : scanCanonicalize (H12AffineFastState.compose env48610 (packedSelected [2,4,5,8,9,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 146) := by decide +kernel

theorem selectedBound48610 : packedSelected [2,4,5,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env48611 : List Nat := [2,4,8,16,32,64,128,69,81,5,123,146,25,80,147,115,0,242,151,146,146,153,16,240,3,211,233,80,80,136,20,64,69,16,0,194]

theorem envBound48611 : H12AffineFastState.Bounded env48611 := by
  intro p hp
  have h : env48611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48610_48611 : H12AffineEnvironment.transform 11 146 env48610 = env48611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 146 env48610 == env48611) = true)

theorem identity48611 : scanCanonicalize (H12AffineFastState.compose env48611 (packedSelected [1,2,3,4,5,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound48611 : packedSelected [1,2,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env48612 : List Nat := [2,4,8,16,32,59,128,62,42,5,0,146,25,43,147,8,0,137,151,146,146,153,16,139,3,168,146,43,43,136,20,59,62,16,0,185]

theorem envBound48612 : H12AffineFastState.Bounded env48612 := by
  intro p hp
  have h : env48612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48611_48612 : H12AffineEnvironment.transform 5 59 env48611 = env48612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env48611 == env48612) = true)

theorem identity48612 : scanCanonicalize (H12AffineFastState.compose env48612 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound48612 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48613 : List Nat := [2,4,8,16,16,11,128,14,26,5,0,146,25,27,147,8,0,137,151,146,146,153,16,139,3,152,146,27,27,136,20,11,14,16,0,137]

theorem envBound48613 : H12AffineFastState.Bounded env48613 := by
  intro p hp
  have h : env48613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48612_48613 : H12AffineEnvironment.transform 4 16 env48612 = env48613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env48612 == env48613) = true)

def env48614 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1345,262144,77934,32769,4096,46528,16,266385,70886,78895,77841,1296,74815,81226,365712,1280,256,365716,1344,79471]

theorem envBound48614 : H12AffineFastState.Bounded env48614 := by
  intro p hp
  have h : env48614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48570_48614 : H12AffineEnvironment.transform 13 1297 env48570 = env48614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env48570 == env48614) = true)

theorem identity48614 : scanCanonicalize (H12AffineFastState.compose env48614 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32883) := by decide +kernel

theorem selectedBound48614 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env48615 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,32883,1345,262144,45085,32769,4096,46528,16,266385,38037,46172,45154,1296,42060,48441,267491,1280,256,267495,1344,46620]

theorem envBound48615 : H12AffineFastState.Bounded env48615 := by
  intro p hp
  have h : env48615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48614_48615 : H12AffineEnvironment.transform 15 32883 env48614 = env48615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32883 env48614 == env48615) = true)

def env48616 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32883,1345,262144,42333,32769,1344,41088,16,263633,33237,41244,42274,1296,42060,43129,262563,1280,256,262567,1344,41820]

theorem envBound48616 : H12AffineFastState.Bounded env48616 := by
  intro p hp
  have h : env48616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48615_48616 : H12AffineEnvironment.transform 11 1344 env48615 = env48616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env48615 == env48616) = true)

theorem identity48616 : scanCanonicalize (H12AffineFastState.compose env48616 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 9406) := by decide +kernel

theorem selectedBound48616 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env48617 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32883,1345,9406,42333,32769,1344,41088,16,8559,33237,41244,42274,1296,42060,43129,9501,1280,256,9497,1344,41820]

theorem envBound48617 : H12AffineFastState.Bounded env48617 := by
  intro p hp
  have h : env48617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48616_48617 : H12AffineEnvironment.transform 17 9406 env48616 = env48617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 9406 env48616 == env48617) = true)

theorem identity48617 : scanCanonicalize (H12AffineFastState.compose env48617 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 9173) := by decide +kernel

theorem selectedBound48617 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env48618 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,9173,9126,1345,9406,1672,9172,1344,853,16,8559,8704,713,1783,1296,1945,2988,9501,1280,256,9497,1344,137]

theorem envBound48618 : H12AffineFastState.Bounded env48618 := by
  intro p hp
  have h : env48618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48617_48618 : H12AffineEnvironment.transform 14 9173 env48617 = env48618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9173 env48617 == env48618) = true)

def env48619 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32883,1345,262144,42332,32769,1345,41089,16,263632,33236,41245,42275,1296,42060,43128,262562,1280,256,262566,1344,41821]

theorem envBound48619 : H12AffineFastState.Bounded env48619 := by
  intro p hp
  have h : env48619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48615_48619 : H12AffineEnvironment.transform 11 1345 env48615 = env48619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env48615 == env48619) = true)

theorem identity48619 : scanCanonicalize (H12AffineFastState.compose env48619 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 9293) := by decide +kernel

theorem selectedBound48619 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env48620 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,9293,9278,1345,262144,273,9292,1345,1228,16,263632,9625,1360,366,1296,1,3125,262562,1280,256,262566,1344,1808]

theorem envBound48620 : H12AffineFastState.Bounded env48620 := by
  intro p hp
  have h : env48620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48619_48620 : H12AffineEnvironment.transform 14 9293 env48619 = env48620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9293 env48619 == env48620) = true)

theorem identity48620 : scanCanonicalize (H12AffineFastState.compose env48620 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound48620 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env48621 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,81,8192,1,8541,8494,81,262144,273,8540,81,476,16,262336,8329,64,366,0,1,2341,262562,16,256,262566,80,512]

theorem envBound48621 : H12AffineFastState.Bounded env48621 := by
  intro p hp
  have h : env48621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48620_48621 : H12AffineEnvironment.transform 9 272 env48620 = env48621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env48620 == env48621) = true)

theorem identity48621 : scanCanonicalize (H12AffineFastState.compose env48621 (packedSelected [4,9,16] rootPS)) = affineNative (2^(17+1) ^^^ 243) := by decide +kernel

theorem selectedBound48621 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env48622 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,81,8192,1,8541,8494,81,243,273,8540,81,476,16,51,8329,64,366,0,1,2341,337,16,256,341,80,512]

theorem envBound48622 : H12AffineFastState.Bounded env48622 := by
  intro p hp
  have h : env48622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48621_48622 : H12AffineEnvironment.transform 17 243 env48621 = env48622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 243 env48621 == env48622) = true)

theorem identity48622 : scanCanonicalize (H12AffineFastState.compose env48622 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 981) := by decide +kernel

theorem selectedBound48622 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env48623 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,81,981,1,648,763,81,243,273,649,81,476,16,51,860,64,366,0,1,2341,337,16,256,341,80,512]

theorem envBound48623 : H12AffineFastState.Bounded env48623 := by
  intro p hp
  have h : env48623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48622_48623 : H12AffineEnvironment.transform 12 981 env48622 = env48623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 981 env48622 == env48623) = true)

theorem identity48623 : scanCanonicalize (H12AffineFastState.compose env48623 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound48623 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env48624 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,1,901,1,648,683,1,163,273,649,1,396,16,51,780,16,318,0,1,2341,257,16,256,261,0,512]

theorem envBound48624 : H12AffineFastState.Bounded env48624 := by
  intro p hp
  have h : env48624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48623_48624 : H12AffineEnvironment.transform 5 16 env48623 = env48624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48623 == env48624) = true)

theorem identity48624 : scanCanonicalize (H12AffineFastState.compose env48624 (packedSelected [1,3,13] rootPS)) = affineNative (2^(10+1) ^^^ 391) := by decide +kernel

theorem selectedBound48624 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env48625 : List Nat := [2,4,8,16,32,16,128,256,512,272,391,1,901,1,648,683,1,163,273,649,1,396,16,51,780,16,318,0,1,162,257,16,256,261,0,512]

theorem envBound48625 : H12AffineFastState.Bounded env48625 := by
  intro p hp
  have h : env48625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48624_48625 : H12AffineEnvironment.transform 10 391 env48624 = env48625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 391 env48624 == env48625) = true)

theorem identity48625 : scanCanonicalize (H12AffineFastState.compose env48625 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound48625 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env48626 : List Nat := [2,4,8,16,32,16,128,21,512,5,146,1,656,1,648,683,1,163,4,649,1,153,16,51,537,16,43,0,1,162,20,16,21,16,0,512]

theorem envBound48626 : H12AffineFastState.Bounded env48626 := by
  intro p hp
  have h : env48626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48625_48626 : H12AffineEnvironment.transform 7 21 env48625 = env48626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env48625 == env48626) = true)

theorem identity48626 : scanCanonicalize (H12AffineFastState.compose env48626 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound48626 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48627 : List Nat := [2,4,8,16,32,16,15,21,512,5,29,1,543,1,519,548,1,44,4,518,1,22,16,51,537,16,43,0,1,45,20,16,21,16,0,512]

theorem envBound48627 : H12AffineFastState.Bounded env48627 := by
  intro p hp
  have h : env48627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48626_48627 : H12AffineEnvironment.transform 6 15 env48626 = env48627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env48626 == env48627) = true)

theorem identity48627 : scanCanonicalize (H12AffineFastState.compose env48627 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound48627 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env48628 : List Nat := [2,4,8,16,16,16,15,21,512,5,29,1,543,1,519,532,1,28,4,518,1,22,16,3,537,16,27,0,1,29,20,16,21,16,0,512]

theorem envBound48628 : H12AffineFastState.Bounded env48628 := by
  intro p hp
  have h : env48628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48627_48628 : H12AffineEnvironment.transform 4 16 env48627 = env48628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env48627 == env48628) = true)

theorem identity48628 : scanCanonicalize (H12AffineFastState.compose env48628 (packedSelected [0,2] rootPS)) = affineNative (2^(8+1) ^^^ 29) := by decide +kernel

theorem selectedBound48628 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env48629 : List Nat := [2,4,8,16,16,16,15,21,29,5,29,1,2,1,26,9,1,28,4,27,1,22,16,3,4,16,27,0,1,29,20,16,21,16,0,29]

theorem envBound48629 : H12AffineFastState.Bounded env48629 := by
  intro p hp
  have h : env48629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48628_48629 : H12AffineEnvironment.transform 8 29 env48628 = env48629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 29 env48628 == env48629) = true)

theorem identity48629 : scanCanonicalize (H12AffineFastState.compose env48629 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound48629 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env48630 : List Nat := [2,4,8,12,12,12,15,9,1,5,1,1,2,1,6,9,1,0,4,7,1,10,12,3,4,12,7,0,1,1,8,12,9,12,0,1]

theorem envBound48630 : H12AffineFastState.Bounded env48630 := by
  intro p hp
  have h : env48630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48629_48630 : H12AffineEnvironment.transform 3 12 env48629 = env48630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env48629 == env48630) = true)

def env48631 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16465,262144,95615,32769,4096,61649,17,284032,86519,94527,77840,1297,74815,96347,381313,1280,256,381317,1344,95102]

theorem envBound48631 : H12AffineFastState.Bounded env48631 := by
  intro p hp
  have h : env48631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48569_48631 : H12AffineEnvironment.transform 16 16465 env48569 = env48631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16465 env48569 == env48631) = true)

def env48632 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1345,262144,77935,32769,4096,46529,17,266384,70887,78895,77840,1297,74815,81227,365713,1280,256,365717,1344,79470]

theorem envBound48632 : H12AffineFastState.Bounded env48632 := by
  intro p hp
  have h : env48632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48631_48632 : H12AffineEnvironment.transform 13 1296 env48631 = env48632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env48631 == env48632) = true)

theorem identity48632 : scanCanonicalize (H12AffineFastState.compose env48632 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32882) := by decide +kernel

theorem selectedBound48632 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env48633 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,32882,1345,262144,45085,32769,4096,46529,17,266384,38037,46173,45154,1297,42061,48441,267491,1280,256,267495,1344,46620]

theorem envBound48633 : H12AffineFastState.Bounded env48633 := by
  intro p hp
  have h : env48633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48632_48633 : H12AffineEnvironment.transform 15 32882 env48632 = env48633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32882 env48632 == env48633) = true)

def env48634 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32882,1345,262144,42333,32769,1344,41089,17,263632,33237,41245,42274,1297,42061,43129,262563,1280,256,262567,1344,41820]

theorem envBound48634 : H12AffineFastState.Bounded env48634 := by
  intro p hp
  have h : env48634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48633_48634 : H12AffineEnvironment.transform 11 1344 env48633 = env48634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env48633 == env48634) = true)

theorem identity48634 : scanCanonicalize (H12AffineFastState.compose env48634 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 41195) := by decide +kernel

theorem selectedBound48634 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env48635 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32882,1345,41195,42333,32769,1344,41089,17,42299,33237,41245,42274,1297,42061,43129,41288,1280,256,41292,1344,41820]

theorem envBound48635 : H12AffineFastState.Bounded env48635 := by
  intro p hp
  have h : env48635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48634_48635 : H12AffineEnvironment.transform 17 41195 env48634 = env48635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 41195 env48634 == env48635) = true)

theorem identity48635 : scanCanonicalize (H12AffineFastState.compose env48635 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound48635 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env48636 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,8540,8494,1345,439,1025,8541,1344,477,17,1127,8329,65,1150,1297,1297,2341,20,1280,256,16,1344,512]

theorem envBound48636 : H12AffineFastState.Bounded env48636 := by
  intro p hp
  have h : env48636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48635_48636 : H12AffineEnvironment.transform 14 8540 env48635 = env48636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env48635 == env48636) = true)

theorem identity48636 : scanCanonicalize (H12AffineFastState.compose env48636 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound48636 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env48637 : List Nat := [2,4,8,16,32,64,128,69,512,1024,2048,1029,8192,1109,8217,8299,1028,242,1025,8216,1029,152,17,1127,8329,65,1150,1108,1108,2144,20,1093,69,16,1029,512]

theorem envBound48637 : H12AffineFastState.Bounded env48637 := by
  intro p hp
  have h : env48637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48636_48637 : H12AffineEnvironment.transform 7 69 env48636 = env48637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env48636 == env48637) = true)

theorem identity48637 : scanCanonicalize (H12AffineFastState.compose env48637 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 656) := by decide +kernel

theorem selectedBound48637 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env48638 : List Nat := [2,4,8,16,32,64,128,69,512,1024,2048,1029,656,1109,649,763,1028,242,1025,648,1029,152,17,1127,537,65,1150,1108,1108,2144,20,1093,69,16,1029,512]

theorem envBound48638 : H12AffineFastState.Bounded env48638 := by
  intro p hp
  have h : env48638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48637_48638 : H12AffineEnvironment.transform 12 656 env48637 = env48638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 656 env48637 == env48638) = true)

theorem identity48638 : scanCanonicalize (H12AffineFastState.compose env48638 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound48638 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env48639 : List Nat := [2,4,8,16,32,16,128,21,512,1024,2048,1029,656,1029,649,683,1028,162,1025,648,1029,152,17,1079,537,17,1070,1028,1028,2096,20,1045,21,16,1029,512]

theorem envBound48639 : H12AffineFastState.Bounded env48639 := by
  intro p hp
  have h : env48639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48638_48639 : H12AffineEnvironment.transform 5 16 env48638 = env48639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48638 == env48639) = true)

theorem identity48639 : scanCanonicalize (H12AffineFastState.compose env48639 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1175) := by decide +kernel

theorem selectedBound48639 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env48640 : List Nat := [2,4,8,16,32,16,128,21,512,1024,1175,1029,656,1029,649,683,1028,162,1025,648,1029,152,17,1079,537,17,1070,1028,1028,1191,20,1045,21,16,1029,512]

theorem envBound48640 : H12AffineFastState.Bounded env48640 := by
  intro p hp
  have h : env48640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48639_48640 : H12AffineEnvironment.transform 10 1175 env48639 = env48640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1175 env48639 == env48640) = true)

theorem identity48640 : scanCanonicalize (H12AffineFastState.compose env48640 (packedSelected [0,1,2,5,7,11] rootPS)) = affineNative (2^(8+1) ^^^ 163) := by decide +kernel

theorem selectedBound48640 : packedSelected [0,1,2,5,7,11] rootPS < 2^1333 := by decide +kernel

def env48641 : List Nat := [2,4,8,16,32,16,128,21,163,1024,1175,1029,51,1029,42,8,1028,162,1025,43,1029,152,17,1079,186,17,1070,1028,1028,1191,20,1045,21,16,1029,163]

theorem envBound48641 : H12AffineFastState.Bounded env48641 := by
  intro p hp
  have h : env48641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48640_48641 : H12AffineEnvironment.transform 8 163 env48640 = env48641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 163 env48640 == env48641) = true)

theorem identity48641 : scanCanonicalize (H12AffineFastState.compose env48641 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound48641 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env48642 : List Nat := [2,4,8,16,32,16,128,21,163,52,163,49,51,49,42,8,48,162,53,43,49,152,17,3,186,17,26,48,48,147,20,33,21,16,49,163]

theorem envBound48642 : H12AffineFastState.Bounded env48642 := by
  intro p hp
  have h : env48642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48641_48642 : H12AffineEnvironment.transform 9 52 env48641 = env48642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env48641 == env48642) = true)

theorem identity48642 : scanCanonicalize (H12AffineFastState.compose env48642 (packedSelected [3,4] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound48642 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env48643 : List Nat := [2,4,8,16,32,16,19,21,48,52,48,49,51,49,42,8,48,49,53,43,49,11,17,3,41,17,26,48,48,0,20,33,21,16,49,48]

theorem envBound48643 : H12AffineFastState.Bounded env48643 := by
  intro p hp
  have h : env48643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48642_48643 : H12AffineEnvironment.transform 6 19 env48642 = env48643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env48642 == env48643) = true)

theorem identity48643 : scanCanonicalize (H12AffineFastState.compose env48643 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound48643 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env48644 : List Nat := [2,4,8,16,10,16,19,21,26,30,26,27,25,27,0,8,26,27,31,1,27,11,17,3,3,17,26,26,26,0,20,11,21,16,27,26]

theorem envBound48644 : H12AffineFastState.Bounded env48644 := by
  intro p hp
  have h : env48644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48643_48644 : H12AffineEnvironment.transform 4 10 env48643 = env48644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env48643 == env48644) = true)

def env48645 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32882,1345,262144,42332,32769,1345,41088,17,263633,33236,41244,42275,1297,42061,43128,262562,1280,256,262566,1344,41821]

theorem envBound48645 : H12AffineFastState.Bounded env48645 := by
  intro p hp
  have h : env48645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48633_48645 : H12AffineEnvironment.transform 11 1345 env48633 = env48645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env48633 == env48645) = true)

theorem identity48645 : scanCanonicalize (H12AffineFastState.compose env48645 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound48645 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env48646 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,25,1296,32768,32882,1345,262144,34117,32769,1345,32921,17,263633,33236,33029,34106,1297,33876,34913,262562,1280,256,262566,1344,33604]

theorem envBound48646 : H12AffineFastState.Bounded env48646 := by
  intro p hp
  have h : env48646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48645_48646 : H12AffineEnvironment.transform 12 25 env48645 = env48646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env48645 == env48646) = true)

theorem identity48646 : scanCanonicalize (H12AffineFastState.compose env48646 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 973) := by decide +kernel

theorem selectedBound48646 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env48647 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,25,1296,973,959,1345,262144,1672,972,1345,852,17,263633,537,712,1783,1297,1945,2988,262562,1280,256,262566,1344,137]

theorem envBound48647 : H12AffineFastState.Bounded env48647 := by
  intro p hp
  have h : env48647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48646_48647 : H12AffineEnvironment.transform 14 973 env48646 = env48647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 973 env48646 == env48647) = true)

def env48648 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1344,262144,77934,32769,4096,46528,17,266385,70886,78894,77840,1297,74815,81226,365712,1280,256,365716,1344,79471]

theorem envBound48648 : H12AffineFastState.Bounded env48648 := by
  intro p hp
  have h : env48648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48631_48648 : H12AffineEnvironment.transform 13 1297 env48631 = env48648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env48631 == env48648) = true)

theorem identity48648 : scanCanonicalize (H12AffineFastState.compose env48648 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound48648 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env48649 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1344,262144,77934,13340,4096,477,17,266385,70886,78894,77840,1297,74815,81226,336013,1280,256,336009,1344,79471]

theorem envBound48649 : H12AffineFastState.Bounded env48649 := by
  intro p hp
  have h : env48649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48648_48649 : H12AffineEnvironment.transform 14 13341 env48648 = env48649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env48648 == env48649) = true)

def env48650 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1344,65664,77934,13340,4096,477,17,69649,70886,78894,77840,1297,74815,81226,8205,1280,256,8201,1344,79471]

theorem envBound48650 : H12AffineFastState.Bounded env48650 := by
  intro p hp
  have h : env48650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48649_48650 : H12AffineEnvironment.transform 17 65664 env48649 = env48650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env48649 == env48650) = true)

theorem identity48650 : scanCanonicalize (H12AffineFastState.compose env48650 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9278) := by decide +kernel

theorem selectedBound48650 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env48651 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,9278,1344,9406,5200,13340,4096,477,17,13359,12504,4112,5166,1297,1,6516,8205,1280,256,8201,1344,4689]

theorem envBound48651 : H12AffineFastState.Bounded env48651 := by
  intro p hp
  have h : env48651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48650_48651 : H12AffineEnvironment.transform 15 9278 env48650 = env48651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9278 env48650 == env48651) = true)

def env48652 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1297,9245,9278,1344,9406,1104,9244,0,477,17,9263,8408,16,1070,1297,1,2420,8205,1280,256,8201,1344,593]

theorem envBound48652 : H12AffineFastState.Bounded env48652 := by
  intro p hp
  have h : env48652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48651_48652 : H12AffineEnvironment.transform 11 0 env48651 = env48652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env48651 == env48652) = true)

theorem identity48652 : scanCanonicalize (H12AffineFastState.compose env48652 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound48652 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env48653 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,1101,1297,80,115,1344,243,1104,81,0,477,17,98,1173,16,1070,1297,1,2420,1088,1280,256,1092,1344,593]

theorem envBound48653 : H12AffineFastState.Bounded env48653 := by
  intro p hp
  have h : env48653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48652_48653 : H12AffineEnvironment.transform 12 1101 env48652 = env48653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env48652 == env48653) = true)

theorem identity48653 : scanCanonicalize (H12AffineFastState.compose env48653 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound48653 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env48654 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,0,268,80,80,115,1,243,273,81,0,477,17,98,468,16,367,80,1,2420,257,65,256,261,1,593]

theorem envBound48654 : H12AffineFastState.Bounded env48654 := by
  intro p hp
  have h : env48654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48653_48654 : H12AffineEnvironment.transform 9 321 env48653 = env48654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env48653 == env48654) = true)

theorem identity48654 : scanCanonicalize (H12AffineFastState.compose env48654 (packedSelected [1,2,3,5,8,11,13,17,18] rootPS)) = affineNative (2^(8+1) ^^^ 486) := by decide +kernel

theorem selectedBound48654 : packedSelected [1,2,3,5,8,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env48655 : List Nat := [2,4,8,16,32,64,128,256,486,321,2048,0,268,80,80,115,1,243,273,81,0,477,17,98,468,16,367,80,1,2420,257,65,256,261,1,439]

theorem envBound48655 : H12AffineFastState.Bounded env48655 := by
  intro p hp
  have h : env48655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48654_48655 : H12AffineEnvironment.transform 8 486 env48654 = env48655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 486 env48654 == env48655) = true)

theorem identity48655 : scanCanonicalize (H12AffineFastState.compose env48655 (packedSelected [2,3,8,13,17] rootPS)) = affineNative (2^(10+1) ^^^ 195) := by decide +kernel

theorem selectedBound48655 : packedSelected [2,3,8,13,17] rootPS < 2^1333 := by decide +kernel

def env48656 : List Nat := [2,4,8,16,32,64,128,256,486,321,195,0,268,80,80,115,1,243,273,81,0,477,17,98,468,16,367,80,1,439,257,65,256,261,1,439]

theorem envBound48656 : H12AffineFastState.Bounded env48656 := by
  intro p hp
  have h : env48656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48655_48656 : H12AffineEnvironment.transform 10 195 env48655 = env48656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 195 env48655 == env48656) = true)

theorem identity48656 : scanCanonicalize (H12AffineFastState.compose env48656 (packedSelected [1,2,5] rootPS)) = affineNative (2^(6+1) ^^^ 66) := by decide +kernel

theorem selectedBound48656 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env48657 : List Nat := [2,4,8,16,32,64,66,256,292,321,1,0,268,80,80,115,1,49,273,81,0,287,17,98,278,16,367,80,1,373,257,65,256,261,1,373]

theorem envBound48657 : H12AffineFastState.Bounded env48657 := by
  intro p hp
  have h : env48657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48656_48657 : H12AffineEnvironment.transform 6 66 env48656 = env48657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 66 env48656 == env48657) = true)

theorem identity48657 : scanCanonicalize (H12AffineFastState.compose env48657 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(7+1) ^^^ 95) := by decide +kernel

theorem selectedBound48657 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env48658 : List Nat := [2,4,8,16,32,64,66,95,123,30,1,0,83,80,80,115,1,49,78,81,0,64,17,98,73,16,48,80,1,42,94,65,95,90,1,42]

theorem envBound48658 : H12AffineFastState.Bounded env48658 := by
  intro p hp
  have h : env48658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48657_48658 : H12AffineEnvironment.transform 7 95 env48657 = env48658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 95 env48657 == env48658) = true)

theorem identity48658 : scanCanonicalize (H12AffineFastState.compose env48658 (packedSelected [1,4,8,9] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound48658 : packedSelected [1,4,8,9] rootPS < 2^1333 := by decide +kernel

def env48659 : List Nat := [2,4,8,10,32,64,66,69,97,4,1,0,73,74,74,105,1,43,78,75,0,64,11,98,73,10,42,74,1,42,68,65,69,64,1,42]

theorem envBound48659 : H12AffineFastState.Bounded env48659 := by
  intro p hp
  have h : env48659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48658_48659 : H12AffineEnvironment.transform 3 10 env48658 = env48659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env48658 == env48659) = true)

theorem identity48659 : scanCanonicalize (H12AffineFastState.compose env48659 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound48659 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48660 : List Nat := [2,4,8,10,11,64,66,69,74,4,1,0,73,74,74,66,1,0,78,75,0,64,11,73,73,10,1,74,1,1,68,65,69,64,1,1]

theorem envBound48660 : H12AffineFastState.Bounded env48660 := by
  intro p hp
  have h : env48660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48659_48660 : H12AffineEnvironment.transform 4 11 env48659 = env48660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env48659 == env48660) = true)

theorem identity48660 : scanCanonicalize (H12AffineFastState.compose env48660 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound48660 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48661 : List Nat := [2,4,8,10,11,13,15,8,7,4,1,0,4,7,7,15,1,0,3,6,0,13,11,4,4,10,1,7,1,1,9,12,8,13,1,1]

theorem envBound48661 : H12AffineFastState.Bounded env48661 := by
  intro p hp
  have h : env48661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48660_48661 : H12AffineEnvironment.transform 5 13 env48660 = env48661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env48660 == env48661) = true)

theorem identity48661 : scanCanonicalize (H12AffineFastState.compose env48661 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound48661 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env48662 : List Nat := [2,3,8,10,11,10,8,8,0,3,1,0,3,0,0,8,1,0,3,1,0,10,11,3,3,10,1,0,1,1,9,11,8,10,1,1]

theorem envBound48662 : H12AffineFastState.Bounded env48662 := by
  intro p hp
  have h : env48662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48661_48662 : H12AffineEnvironment.transform 1 3 env48661 = env48662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env48661 == env48662) = true)

theorem identity48662 : scanCanonicalize (H12AffineFastState.compose env48662 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound48662 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48663 : List Nat := [2,3,1,3,2,3,1,1,0,3,1,0,3,0,0,1,1,0,3,1,0,3,2,3,3,3,1,0,1,1,0,2,1,3,1,1]

theorem envBound48663 : H12AffineFastState.Bounded env48663 := by
  intro p hp
  have h : env48663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48662_48663 : H12AffineEnvironment.transform 2 1 env48662 = env48663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env48662 == env48663) = true)

theorem identity48663 : scanCanonicalize (H12AffineFastState.compose env48663 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound48663 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env48664 : List Nat := [1,0,1,0,1,0,1,1,0,0,1,0,0,0,0,1,1,0,0,1,0,0,1,0,0,0,1,0,1,1,0,1,1,0,1,1]

theorem envBound48664 : H12AffineFastState.Bounded env48664 := by
  intro p hp
  have h : env48664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48663_48664 : H12AffineEnvironment.transform 0 1 env48663 = env48664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env48663 == env48664) = true)

def env48665 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1297,9244,9278,1344,9406,1105,9245,1,477,17,9262,8409,17,1071,1297,1,2421,8205,1280,256,8201,1344,592]

theorem envBound48665 : H12AffineFastState.Bounded env48665 := by
  intro p hp
  have h : env48665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48651_48665 : H12AffineEnvironment.transform 11 1 env48651 = env48665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env48651 == env48665) = true)

theorem identity48665 : scanCanonicalize (H12AffineFastState.compose env48665 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound48665 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env48666 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,1053,1297,1,35,1344,163,1105,0,1,477,17,51,1220,17,1071,1297,1,2421,1040,1280,256,1044,1344,592]

theorem envBound48666 : H12AffineFastState.Bounded env48666 := by
  intro p hp
  have h : env48666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48665_48666 : H12AffineEnvironment.transform 12 1053 env48665 = env48666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env48665 == env48666) = true)

theorem identity48666 : scanCanonicalize (H12AffineFastState.compose env48666 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound48666 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env48667 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,348,80,1,35,1,163,272,0,1,477,17,51,389,17,366,80,1,2421,337,65,256,341,1,592]

theorem envBound48667 : H12AffineFastState.Bounded env48667 := by
  intro p hp
  have h : env48667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48666_48667 : H12AffineEnvironment.transform 9 321 env48666 = env48667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env48666 == env48667) = true)

theorem identity48667 : scanCanonicalize (H12AffineFastState.compose env48667 (packedSelected [1,2,3,11,13,18] rootPS)) = affineNative (2^(8+1) ^^^ 461) := by decide +kernel

theorem selectedBound48667 : packedSelected [1,2,3,11,13,18] rootPS < 2^1333 := by decide +kernel

def env48668 : List Nat := [2,4,8,16,32,64,128,256,461,321,2048,1,348,80,1,35,1,163,272,0,1,477,17,51,389,17,366,80,1,2421,337,65,256,341,1,413]

theorem envBound48668 : H12AffineFastState.Bounded env48668 := by
  intro p hp
  have h : env48668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48667_48668 : H12AffineEnvironment.transform 8 461 env48667 = env48668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 461 env48667 == env48668) = true)

theorem identity48668 : scanCanonicalize (H12AffineFastState.compose env48668 (packedSelected [3,8] rootPS)) = affineNative (2^(10+1) ^^^ 97) := by decide +kernel

theorem selectedBound48668 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env48669 : List Nat := [2,4,8,16,32,64,128,256,461,321,97,1,348,80,1,35,1,163,272,0,1,477,17,51,389,17,366,80,1,276,337,65,256,341,1,413]

theorem envBound48669 : H12AffineFastState.Bounded env48669 := by
  intro p hp
  have h : env48669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48668_48669 : H12AffineEnvironment.transform 10 97 env48668 = env48669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 97 env48668 == env48669) = true)

theorem identity48669 : scanCanonicalize (H12AffineFastState.compose env48669 (packedSelected [0,1,2,3,7,10,11,13,15] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound48669 : packedSelected [0,1,2,3,7,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env48670 : List Nat := [2,4,8,16,32,64,18,256,351,321,97,1,348,80,1,35,1,49,272,0,1,335,17,51,279,17,366,80,1,276,337,65,256,341,1,271]

theorem envBound48670 : H12AffineFastState.Bounded env48670 := by
  intro p hp
  have h : env48670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48669_48670 : H12AffineEnvironment.transform 6 18 env48669 = env48670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env48669 == env48670) = true)

theorem identity48670 : scanCanonicalize (H12AffineFastState.compose env48670 (packedSelected [0,2,4,11] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound48670 : packedSelected [0,2,4,11] rootPS < 2^1333 := by decide +kernel

def env48671 : List Nat := [2,4,8,16,32,64,18,116,43,53,97,1,40,80,1,35,1,49,100,0,1,59,17,51,99,17,26,80,1,96,37,65,116,33,1,123]

theorem envBound48671 : H12AffineFastState.Bounded env48671 := by
  intro p hp
  have h : env48671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48670_48671 : H12AffineEnvironment.transform 7 116 env48670 = env48671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env48670 == env48671) = true)

theorem identity48671 : scanCanonicalize (H12AffineFastState.compose env48671 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound48671 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48672 : List Nat := [2,4,8,16,32,58,18,14,43,53,27,1,40,42,1,35,1,49,30,0,1,59,17,51,25,17,26,42,1,26,37,59,14,33,1,1]

theorem envBound48672 : H12AffineFastState.Bounded env48672 := by
  intro p hp
  have h : env48672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48671_48672 : H12AffineEnvironment.transform 5 58 env48671 = env48672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env48671 == env48672) = true)

theorem identity48672 : scanCanonicalize (H12AffineFastState.compose env48672 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound48672 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48673 : List Nat := [2,4,8,10,32,32,8,14,43,47,1,1,40,42,1,35,1,43,4,0,1,33,11,41,3,11,0,42,1,0,37,33,14,33,1,1]

theorem envBound48673 : H12AffineFastState.Bounded env48673 := by
  intro p hp
  have h : env48673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48672_48673 : H12AffineEnvironment.transform 3 10 env48672 = env48673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env48672 == env48673) = true)

theorem identity48673 : scanCanonicalize (H12AffineFastState.compose env48673 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound48673 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48674 : List Nat := [2,4,5,7,32,32,5,3,38,34,1,1,37,39,1,35,1,38,4,0,1,33,6,36,3,6,0,39,1,0,37,33,3,33,1,1]

theorem envBound48674 : H12AffineFastState.Bounded env48674 := by
  intro p hp
  have h : env48674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48673_48674 : H12AffineEnvironment.transform 2 5 env48673 = env48674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env48673 == env48674) = true)

theorem identity48674 : scanCanonicalize (H12AffineFastState.compose env48674 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound48674 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env48675 : List Nat := [2,4,5,7,6,6,5,3,0,4,1,1,3,1,1,5,1,0,4,0,1,7,6,2,3,6,0,1,1,0,3,7,3,7,1,1]

theorem envBound48675 : H12AffineFastState.Bounded env48675 := by
  intro p hp
  have h : env48675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48674_48675 : H12AffineEnvironment.transform 4 6 env48674 = env48675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env48674 == env48675) = true)

theorem identity48675 : scanCanonicalize (H12AffineFastState.compose env48675 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound48675 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48676 : List Nat := [2,0,1,3,2,2,1,3,0,0,1,1,3,1,1,1,1,0,0,0,1,3,2,2,3,2,0,1,1,0,3,3,3,3,1,1]

theorem envBound48676 : H12AffineFastState.Bounded env48676 := by
  intro p hp
  have h : env48676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48675_48676 : H12AffineEnvironment.transform 1 0 env48675 = env48676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env48675 == env48676) = true)

theorem identity48676 : scanCanonicalize (H12AffineFastState.compose env48676 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound48676 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env48677 : List Nat := [1,0,1,0,1,1,1,0,0,0,1,1,0,1,1,1,1,0,0,0,1,0,1,1,0,1,0,1,1,0,0,0,0,0,1,1]

theorem envBound48677 : H12AffineFastState.Bounded env48677 := by
  intro p hp
  have h : env48677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48676_48677 : H12AffineEnvironment.transform 0 1 env48676 = env48677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env48676 == env48677) = true)

def env48678 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1344,65665,77934,13340,4096,477,17,69648,70886,78894,77840,1297,74815,81226,8204,1280,256,8200,1344,79471]

theorem envBound48678 : H12AffineFastState.Bounded env48678 := by
  intro p hp
  have h : env48678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48649_48678 : H12AffineEnvironment.transform 17 65665 env48649 = env48678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env48649 == env48678) = true)

theorem identity48678 : scanCanonicalize (H12AffineFastState.compose env48678 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12670) := by decide +kernel

theorem selectedBound48678 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env48679 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,12670,1344,12799,272,13340,4096,477,17,8558,9624,1360,366,1297,5441,3124,8204,1280,256,8200,1344,1809]

theorem envBound48679 : H12AffineFastState.Bounded env48679 := by
  intro p hp
  have h : env48679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48678_48679 : H12AffineEnvironment.transform 15 12670 env48678 = env48679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12670 env48678 == env48679) = true)

def env48680 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,81,12637,12670,0,12799,272,12636,4096,477,17,8558,8408,16,366,81,4097,2420,8204,64,256,8200,0,593]

theorem envBound48680 : H12AffineFastState.Bounded env48680 := by
  intro p hp
  have h : env48680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48679_48680 : H12AffineEnvironment.transform 9 320 env48679 = env48680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env48679 == env48680) = true)

theorem identity48680 : scanCanonicalize (H12AffineFastState.compose env48680 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 4364) := by decide +kernel

theorem selectedBound48680 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env48681 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,4364,81,81,114,0,243,272,80,4096,477,17,4194,4564,16,366,81,4097,2420,4352,64,256,4356,0,593]

theorem envBound48681 : H12AffineFastState.Bounded env48681 := by
  intro p hp
  have h : env48681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48680_48681 : H12AffineEnvironment.transform 12 4364 env48680 = env48681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4364 env48680 == env48681) = true)

theorem identity48681 : scanCanonicalize (H12AffineFastState.compose env48681 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound48681 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env48682 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,80,348,81,81,114,0,243,272,80,80,477,17,50,388,16,366,81,81,2420,336,64,256,340,0,593]

theorem envBound48682 : H12AffineFastState.Bounded env48682 := by
  intro p hp
  have h : env48682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48681_48682 : H12AffineEnvironment.transform 11 80 env48681 = env48682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env48681 == env48682) = true)

theorem identity48682 : scanCanonicalize (H12AffineFastState.compose env48682 (packedSelected [0,1,2,5,7,12,15,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 972) := by decide +kernel

theorem selectedBound48682 : packedSelected [0,1,2,5,7,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env48683 : List Nat := [2,4,8,16,32,64,128,256,512,320,972,80,348,81,81,114,0,243,272,80,80,477,17,50,388,16,366,81,81,696,336,64,256,340,0,593]

theorem envBound48683 : H12AffineFastState.Bounded env48683 := by
  intro p hp
  have h : env48683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48682_48683 : H12AffineEnvironment.transform 10 972 env48682 = env48683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 972 env48682 == env48683) = true)

theorem identity48683 : scanCanonicalize (H12AffineFastState.compose env48683 (packedSelected [1,3,10,17,19] rootPS)) = affineNative (2^(8+1) ^^^ 486) := by decide +kernel

theorem selectedBound48683 : packedSelected [1,3,10,17,19] rootPS < 2^1333 := by decide +kernel

def env48684 : List Nat := [2,4,8,16,32,64,128,256,486,320,42,80,348,81,81,114,0,243,272,80,80,477,17,50,388,16,366,81,81,350,336,64,256,340,0,439]

theorem envBound48684 : H12AffineFastState.Bounded env48684 := by
  intro p hp
  have h : env48684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48683_48684 : H12AffineEnvironment.transform 8 486 env48683 = env48684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 486 env48683 == env48684) = true)

theorem identity48684 : scanCanonicalize (H12AffineFastState.compose env48684 (packedSelected [0,3,4,7,8,9,10,13] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound48684 : packedSelected [0,3,4,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env48685 : List Nat := [2,4,8,16,32,64,105,256,271,320,42,80,348,81,81,114,0,26,272,80,80,308,17,50,365,16,366,81,81,350,336,64,256,340,0,350]

theorem envBound48685 : H12AffineFastState.Bounded env48685 := by
  intro p hp
  have h : env48685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48684_48685 : H12AffineEnvironment.transform 6 105 env48684 = env48685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env48684 == env48685) = true)

theorem identity48685 : scanCanonicalize (H12AffineFastState.compose env48685 (packedSelected [1,3,4,9] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound48685 : packedSelected [1,3,4,9] rootPS < 2^1333 := by decide +kernel

def env48686 : List Nat := [2,4,8,16,32,59,18,256,271,315,42,43,295,42,42,9,0,26,272,43,43,308,17,50,278,16,277,42,42,293,299,59,256,303,0,293]

theorem envBound48686 : H12AffineFastState.Bounded env48686 := by
  intro p hp
  have h : env48686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48685_48686 : H12AffineEnvironment.transform 5 59 env48685 = env48686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env48685 == env48686) = true)

theorem identity48686 : scanCanonicalize (H12AffineFastState.compose env48686 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound48686 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env48687 : List Nat := [2,4,8,10,32,33,8,256,271,289,42,43,295,42,42,9,0,0,266,43,43,302,11,40,268,10,271,42,42,293,299,33,256,303,0,293]

theorem envBound48687 : H12AffineFastState.Bounded env48687 := by
  intro p hp
  have h : env48687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48686_48687 : H12AffineEnvironment.transform 3 10 env48686 = env48687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env48686 == env48687) = true)

theorem identity48687 : scanCanonicalize (H12AffineFastState.compose env48687 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound48687 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48688 : List Nat := [2,4,8,10,32,33,8,36,43,5,42,43,3,42,42,9,0,0,46,43,43,10,11,40,40,10,43,42,42,1,15,33,36,11,0,1]

theorem envBound48688 : H12AffineFastState.Bounded env48688 := by
  intro p hp
  have h : env48688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48687_48688 : H12AffineEnvironment.transform 7 36 env48687 = env48688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env48687 == env48688) = true)

def env48689 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,80,12636,12670,1,12799,272,12637,4096,477,17,8558,8409,17,366,80,4096,2421,8204,65,256,8200,1,592]

theorem envBound48689 : H12AffineFastState.Bounded env48689 := by
  intro p hp
  have h : env48689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48679_48689 : H12AffineEnvironment.transform 9 321 env48679 = env48689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env48679 == env48689) = true)

theorem identity48689 : scanCanonicalize (H12AffineFastState.compose env48689 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 4444) := by decide +kernel

theorem selectedBound48689 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env48690 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,4444,80,0,34,1,163,272,1,4096,477,17,4146,4485,17,366,80,4096,2421,4432,65,256,4436,1,592]

theorem envBound48690 : H12AffineFastState.Bounded env48690 := by
  intro p hp
  have h : env48690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48689_48690 : H12AffineEnvironment.transform 12 4444 env48689 = env48690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4444 env48689 == env48690) = true)

theorem identity48690 : scanCanonicalize (H12AffineFastState.compose env48690 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound48690 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env48691 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,81,269,80,0,34,1,163,272,1,81,477,17,99,468,17,366,80,81,2421,257,65,256,261,1,592]

theorem envBound48691 : H12AffineFastState.Bounded env48691 := by
  intro p hp
  have h : env48691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48690_48691 : H12AffineEnvironment.transform 11 81 env48690 = env48691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env48690 == env48691) = true)

theorem identity48691 : scanCanonicalize (H12AffineFastState.compose env48691 (packedSelected [10,11,18,19] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound48691 : packedSelected [10,11,18,19] rootPS < 2^1333 := by decide +kernel

def env48692 : List Nat := [2,4,8,16,32,64,128,15,512,78,2048,81,2,80,0,34,1,163,31,1,81,210,17,99,219,17,97,80,81,2170,14,65,15,10,1,592]

theorem envBound48692 : H12AffineFastState.Bounded env48692 := by
  intro p hp
  have h : env48692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48691_48692 : H12AffineEnvironment.transform 7 15 env48691 = env48692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env48691 == env48692) = true)

theorem identity48692 : scanCanonicalize (H12AffineFastState.compose env48692 (packedSelected [3,5,10,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound48692 : packedSelected [3,5,10,13,15] rootPS < 2^1333 := by decide +kernel

def env48693 : List Nat := [2,4,8,16,32,64,128,15,512,78,1,81,2,80,0,34,1,163,31,1,81,210,17,99,219,17,97,80,81,123,14,65,15,10,1,592]

theorem envBound48693 : H12AffineFastState.Bounded env48693 := by
  intro p hp
  have h : env48693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48692_48693 : H12AffineEnvironment.transform 10 1 env48692 = env48693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env48692 == env48693) = true)

theorem identity48693 : scanCanonicalize (H12AffineFastState.compose env48693 (packedSelected [1,2,5,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound48693 : packedSelected [1,2,5,7,9] rootPS < 2^1333 := by decide +kernel

def env48694 : List Nat := [2,4,8,16,11,64,128,15,512,78,1,81,2,80,0,9,1,136,31,1,81,210,17,72,219,17,74,80,81,80,14,65,15,10,1,592]

theorem envBound48694 : H12AffineFastState.Bounded env48694 := by
  intro p hp
  have h : env48694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48693_48694 : H12AffineEnvironment.transform 4 11 env48693 = env48694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env48693 == env48694) = true)

theorem identity48694 : scanCanonicalize (H12AffineFastState.compose env48694 (packedSelected [1,2,3,4,5,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound48694 : packedSelected [1,2,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env48695 : List Nat := [2,4,8,16,11,64,128,15,81,78,1,81,2,80,0,9,1,136,31,1,81,210,17,72,219,17,74,80,81,80,14,65,15,10,1,1]

theorem envBound48695 : H12AffineFastState.Bounded env48695 := by
  intro p hp
  have h : env48695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48694_48695 : H12AffineEnvironment.transform 8 81 env48694 = env48695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env48694 == env48695) = true)

theorem identity48695 : scanCanonicalize (H12AffineFastState.compose env48695 (packedSelected [2,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound48695 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env48696 : List Nat := [2,4,8,16,11,11,128,15,26,5,1,26,2,27,0,9,1,136,31,1,26,153,17,3,144,17,1,27,26,27,14,10,15,10,1,1]

theorem envBound48696 : H12AffineFastState.Bounded env48696 := by
  intro p hp
  have h : env48696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48695_48696 : H12AffineEnvironment.transform 5 11 env48695 = env48696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env48695 == env48696) = true)

theorem identity48696 : scanCanonicalize (H12AffineFastState.compose env48696 (packedSelected [1,2] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound48696 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env48697 : List Nat := [2,4,8,7,11,11,128,15,13,5,1,13,2,12,0,9,1,136,8,1,13,142,6,3,135,6,1,12,13,12,14,10,15,10,1,1]

theorem envBound48697 : H12AffineFastState.Bounded env48697 := by
  intro p hp
  have h : env48697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48696_48697 : H12AffineEnvironment.transform 3 7 env48696 = env48697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env48696 == env48697) = true)

theorem identity48697 : scanCanonicalize (H12AffineFastState.compose env48697 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound48697 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env48698 : List Nat := [2,4,8,7,11,11,8,15,13,5,1,13,2,12,0,9,1,0,8,1,13,6,6,3,15,6,1,12,13,12,14,10,15,10,1,1]

theorem envBound48698 : H12AffineFastState.Bounded env48698 := by
  intro p hp
  have h : env48698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48697_48698 : H12AffineEnvironment.transform 6 8 env48697 = env48698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env48697 == env48698) = true)

theorem identity48698 : scanCanonicalize (H12AffineFastState.compose env48698 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound48698 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48699 : List Nat := [2,4,4,7,7,7,4,3,1,5,1,1,2,0,0,5,1,0,4,1,1,6,6,3,3,6,1,0,1,0,2,6,3,6,1,1]

theorem envBound48699 : H12AffineFastState.Bounded env48699 := by
  intro p hp
  have h : env48699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48698_48699 : H12AffineEnvironment.transform 2 4 env48698 = env48699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env48698 == env48699) = true)

def env48700 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95615,32769,4096,61649,147520,284033,86519,209262,225344,148800,74815,96347,381312,1280,256,381316,1344,95102]

theorem envBound48700 : H12AffineFastState.Bounded env48700 := by
  intro p hp
  have h : env48700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48568_48700 : H12AffineEnvironment.transform 23 284033 env48568 = env48700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284033 env48568 == env48700) = true)

def env48701 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16464,262144,95615,32769,4096,61649,16,284033,86519,94526,77840,1296,74815,96347,381312,1280,256,381316,1344,95102]

theorem envBound48701 : H12AffineFastState.Bounded env48701 := by
  intro p hp
  have h : env48701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48700_48701 : H12AffineEnvironment.transform 16 16464 env48700 = env48701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16464 env48700 == env48701) = true)

def env48702 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1344,262144,77935,32769,4096,46529,16,266385,70887,78894,77840,1296,74815,81227,365712,1280,256,365716,1344,79470]

theorem envBound48702 : H12AffineFastState.Bounded env48702 := by
  intro p hp
  have h : env48702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48701_48702 : H12AffineEnvironment.transform 13 1296 env48701 = env48702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env48701 == env48702) = true)

theorem identity48702 : scanCanonicalize (H12AffineFastState.compose env48702 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound48702 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env48703 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1344,262144,77935,13340,4096,476,16,266385,70887,78894,77840,1296,74815,81227,336013,1280,256,336009,1344,79470]

theorem envBound48703 : H12AffineFastState.Bounded env48703 := by
  intro p hp
  have h : env48703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48702_48703 : H12AffineEnvironment.transform 14 13341 env48702 = env48703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env48702 == env48703) = true)

def env48704 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1344,65664,77935,13340,4096,476,16,69649,70887,78894,77840,1296,74815,81227,8205,1280,256,8201,1344,79470]

theorem envBound48704 : H12AffineFastState.Bounded env48704 := by
  intro p hp
  have h : env48704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48703_48704 : H12AffineEnvironment.transform 17 65664 env48703 = env48704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env48703 == env48704) = true)

theorem identity48704 : scanCanonicalize (H12AffineFastState.compose env48704 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5465) := by decide +kernel

theorem selectedBound48704 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env48705 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5465,1296,324,65536,1344,65664,66870,325,4096,476,16,69649,70887,65911,66889,1296,69990,67602,5460,1280,256,5456,1344,66359]

theorem envBound48705 : H12AffineFastState.Bounded env48705 := by
  intro p hp
  have h : env48705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48704_48705 : H12AffineEnvironment.transform 12 5465 env48704 = env48705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5465 env48704 == env48705) = true)

def env48706 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5385,1296,276,65536,1296,65664,66870,277,4096,396,16,69649,70839,65831,66841,1296,69942,67602,5380,1280,256,5376,1296,66359]

theorem envBound48706 : H12AffineFastState.Bounded env48706 := by
  intro p hp
  have h : env48706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48705_48706 : H12AffineEnvironment.transform 5 16 env48705 = env48706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48705 == env48706) = true)

theorem identity48706 : scanCanonicalize (H12AffineFastState.compose env48706 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound48706 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env48707 : List Nat := [2,4,8,16,32,16,128,20,512,1024,2048,4096,5149,1028,0,65536,1028,65664,66594,1,4096,152,16,69649,70839,65587,66573,1028,69666,67602,5136,1044,20,5140,1028,66083]

theorem envBound48707 : H12AffineFastState.Bounded env48707 := by
  intro p hp
  have h : env48707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48706_48707 : H12AffineEnvironment.transform 7 20 env48706 = env48707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env48706 == env48707) = true)

theorem identity48707 : scanCanonicalize (H12AffineFastState.compose env48707 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 5158) := by decide +kernel

theorem selectedBound48707 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env48708 : List Nat := [2,4,8,16,32,16,128,20,512,1024,2048,4096,5149,1028,0,5158,1028,5286,4100,1,4096,152,16,1079,145,5141,4139,1028,1028,7220,5136,1044,20,5140,1028,5637]

theorem envBound48708 : H12AffineFastState.Bounded env48708 := by
  intro p hp
  have h : env48708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48707_48708 : H12AffineEnvironment.transform 15 5158 env48707 = env48708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5158 env48707 == env48708) = true)

theorem identity48708 : scanCanonicalize (H12AffineFastState.compose env48708 (packedSelected [10,11,13,17,18,19] rootPS)) = affineNative (2^(11+1) ^^^ 1190) := by decide +kernel

theorem selectedBound48708 : packedSelected [10,11,13,17,18,19] rootPS < 2^1333 := by decide +kernel

def env48709 : List Nat := [2,4,8,16,32,16,128,20,512,1024,2048,1190,187,1028,0,128,1028,0,1186,1,1190,152,16,1079,145,179,1165,1028,1028,2194,182,1044,20,178,1028,675]

theorem envBound48709 : H12AffineFastState.Bounded env48709 := by
  intro p hp
  have h : env48709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48708_48709 : H12AffineEnvironment.transform 11 1190 env48708 = env48709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1190 env48708 == env48709) = true)

theorem identity48709 : scanCanonicalize (H12AffineFastState.compose env48709 (packedSelected [2,13,17] rootPS)) = affineNative (2^(10+1) ^^^ 674) := by decide +kernel

theorem selectedBound48709 : packedSelected [2,13,17] rootPS < 2^1333 := by decide +kernel

def env48710 : List Nat := [2,4,8,16,32,16,128,20,512,1024,674,1190,187,1028,0,128,1028,0,1186,1,1190,152,16,1079,145,179,1165,1028,1028,560,182,1044,20,178,1028,675]

theorem envBound48710 : H12AffineFastState.Bounded env48710 := by
  intro p hp
  have h : env48710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48709_48710 : H12AffineEnvironment.transform 10 674 env48709 = env48710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 674 env48709 == env48710) = true)

theorem identity48710 : scanCanonicalize (H12AffineFastState.compose env48710 (packedSelected [0,2,3,5,7,11,13] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound48710 : packedSelected [0,2,3,5,7,11,13] rootPS < 2^1333 := by decide +kernel

def env48711 : List Nat := [2,4,8,16,32,16,128,20,26,1024,184,1190,187,1028,0,128,1028,0,1186,1,1190,152,16,1079,145,179,1165,1028,1028,42,182,1044,20,178,1028,185]

theorem envBound48711 : H12AffineFastState.Bounded env48711 := by
  intro p hp
  have h : env48711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48710_48711 : H12AffineEnvironment.transform 8 26 env48710 = env48711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env48710 == env48711) = true)

theorem identity48711 : scanCanonicalize (H12AffineFastState.compose env48711 (packedSelected [1,8] rootPS)) = affineNative (2^(9+1) ^^^ 166) := by decide +kernel

theorem selectedBound48711 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env48712 : List Nat := [2,4,8,16,32,16,128,20,26,166,184,0,187,162,0,128,162,0,4,1,0,152,16,145,145,179,43,162,162,42,182,178,20,178,162,185]

theorem envBound48712 : H12AffineFastState.Bounded env48712 := by
  intro p hp
  have h : env48712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48711_48712 : H12AffineEnvironment.transform 9 166 env48711 = env48712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 166 env48711 == env48712) = true)

theorem identity48712 : scanCanonicalize (H12AffineFastState.compose env48712 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound48712 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env48713 : List Nat := [2,4,8,16,32,16,18,20,26,52,42,0,41,48,0,18,48,0,4,1,0,10,16,3,3,33,43,48,48,42,36,32,20,32,48,43]

theorem envBound48713 : H12AffineFastState.Bounded env48713 := by
  intro p hp
  have h : env48713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48712_48713 : H12AffineEnvironment.transform 6 18 env48712 = env48713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env48712 == env48713) = true)

theorem identity48713 : scanCanonicalize (H12AffineFastState.compose env48713 (packedSelected [4,7] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound48713 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env48714 : List Nat := [2,4,8,16,11,16,18,20,26,31,1,0,2,27,0,18,27,0,4,1,0,10,16,3,3,10,0,27,27,1,15,11,20,11,27,0]

theorem envBound48714 : H12AffineFastState.Bounded env48714 := by
  intro p hp
  have h : env48714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48713_48714 : H12AffineEnvironment.transform 4 11 env48713 = env48714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env48713 == env48714) = true)

theorem identity48714 : scanCanonicalize (H12AffineFastState.compose env48714 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound48714 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env48715 : List Nat := [2,4,4,16,7,16,18,20,22,19,1,0,2,23,0,18,23,0,4,1,0,6,16,3,3,6,0,23,23,1,3,7,20,7,23,0]

theorem envBound48715 : H12AffineFastState.Bounded env48715 := by
  intro p hp
  have h : env48715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48714_48715 : H12AffineEnvironment.transform 2 4 env48714 = env48715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env48714 == env48715) = true)

def env48716 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,5384,1296,277,65536,1297,65664,66870,276,4096,397,16,69649,70838,65830,66840,1296,69943,67602,5381,1280,256,5377,1297,66359]

theorem envBound48716 : H12AffineFastState.Bounded env48716 := by
  intro p hp
  have h : env48716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48705_48716 : H12AffineEnvironment.transform 5 17 env48705 = env48716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env48705 == env48716) = true)

theorem identity48716 : scanCanonicalize (H12AffineFastState.compose env48716 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound48716 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env48717 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,5384,1296,277,34,1297,162,1300,276,4096,397,16,4147,5268,260,1338,1296,4373,2096,5381,1280,256,5377,1297,789]

theorem envBound48717 : H12AffineFastState.Bounded env48717 := by
  intro p hp
  have h : env48717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48716_48717 : H12AffineEnvironment.transform 15 34 env48716 = env48717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env48716 == env48717) = true)

theorem identity48717 : scanCanonicalize (H12AffineFastState.compose env48717 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound48717 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env48718 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1028,268,1296,277,34,1297,162,1300,276,1028,397,16,1079,144,260,1338,1296,1297,2096,257,1280,256,261,1297,789]

theorem envBound48718 : H12AffineFastState.Bounded env48718 := by
  intro p hp
  have h : env48718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48717_48718 : H12AffineEnvironment.transform 11 1028 env48717 = env48718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env48717 == env48718) = true)

theorem identity48718 : scanCanonicalize (H12AffineFastState.compose env48718 (packedSelected [0,1,2,5,7,10,11,19] rootPS)) = affineNative (2^(8+1) ^^^ 147) := by decide +kernel

theorem selectedBound48718 : packedSelected [0,1,2,5,7,10,11,19] rootPS < 2^1333 := by decide +kernel

def env48719 : List Nat := [2,4,8,16,32,17,128,256,147,1024,2048,1028,268,1296,277,34,1297,162,1300,276,1028,397,16,1079,144,260,1338,1296,1297,2096,257,1280,256,261,1297,390]

theorem envBound48719 : H12AffineFastState.Bounded env48719 := by
  intro p hp
  have h : env48719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48718_48719 : H12AffineEnvironment.transform 8 147 env48718 = env48719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 147 env48718 == env48719) = true)

theorem identity48719 : scanCanonicalize (H12AffineFastState.compose env48719 (packedSelected [5,8,13] rootPS)) = affineNative (2^(10+1) ^^^ 1071) := by decide +kernel

theorem selectedBound48719 : packedSelected [5,8,13] rootPS < 2^1333 := by decide +kernel

def env48720 : List Nat := [2,4,8,16,32,17,128,256,147,1024,1071,1028,268,1296,277,34,1297,162,1300,276,1028,397,16,1079,144,260,1338,1296,1297,1055,257,1280,256,261,1297,390]

theorem envBound48720 : H12AffineFastState.Bounded env48720 := by
  intro p hp
  have h : env48720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48719_48720 : H12AffineEnvironment.transform 10 1071 env48719 = env48720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1071 env48719 == env48720) = true)

theorem identity48720 : scanCanonicalize (H12AffineFastState.compose env48720 (packedSelected [2,4,9,10,11,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound48720 : packedSelected [2,4,9,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env48721 : List Nat := [2,4,8,16,32,17,128,172,147,1024,1071,1028,160,1212,185,34,1213,162,1208,184,1028,33,16,1079,144,168,1174,1212,1213,1055,173,1196,172,169,1213,42]

theorem envBound48721 : H12AffineFastState.Bounded env48721 := by
  intro p hp
  have h : env48721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48720_48721 : H12AffineEnvironment.transform 7 172 env48720 = env48721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env48720 == env48721) = true)

theorem identity48721 : scanCanonicalize (H12AffineFastState.compose env48721 (packedSelected [2,4,5,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound48721 : packedSelected [2,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env48722 : List Nat := [2,4,8,16,16,17,128,156,147,1024,1055,1028,144,1164,137,18,1165,146,1160,136,1028,17,16,1031,144,152,1174,1164,1165,1055,157,1180,156,153,1165,26]

theorem envBound48722 : H12AffineFastState.Bounded env48722 := by
  intro p hp
  have h : env48722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48721_48722 : H12AffineEnvironment.transform 4 16 env48721 = env48722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env48721 == env48722) = true)

theorem identity48722 : scanCanonicalize (H12AffineFastState.compose env48722 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 30) := by decide +kernel

theorem selectedBound48722 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env48723 : List Nat := [2,4,8,16,16,17,128,156,147,30,1,26,144,146,137,18,147,146,150,136,26,17,16,25,144,152,136,146,147,1,157,130,156,153,147,26]

theorem envBound48723 : H12AffineFastState.Bounded env48723 := by
  intro p hp
  have h : env48723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48722_48723 : H12AffineEnvironment.transform 9 30 env48722 = env48723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 30 env48722 == env48723) = true)

theorem identity48723 : scanCanonicalize (H12AffineFastState.compose env48723 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound48723 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env48724 : List Nat := [2,4,8,16,16,17,9,21,26,30,1,26,25,27,0,18,26,27,31,1,26,17,16,25,25,17,1,27,26,1,20,11,21,16,26,26]

theorem envBound48724 : H12AffineFastState.Bounded env48724 := by
  intro p hp
  have h : env48724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48723_48724 : H12AffineEnvironment.transform 6 9 env48723 = env48724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env48723 == env48724) = true)

theorem identity48724 : scanCanonicalize (H12AffineFastState.compose env48724 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound48724 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env48725 : List Nat := [2,4,8,11,11,10,9,14,1,5,1,1,2,0,0,9,1,0,4,1,1,10,11,2,2,10,1,0,1,1,15,11,14,11,1,1]

theorem envBound48725 : H12AffineFastState.Bounded env48725 := by
  intro p hp
  have h : env48725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48724_48725 : H12AffineEnvironment.transform 3 11 env48724 = env48725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env48724 == env48725) = true)

theorem identity48725 : scanCanonicalize (H12AffineFastState.compose env48725 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound48725 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env48726 : List Nat := [2,4,4,7,7,6,5,2,1,5,1,1,2,0,0,5,1,0,4,1,1,6,7,2,2,6,1,0,1,1,3,7,2,7,1,1]

theorem envBound48726 : H12AffineFastState.Bounded env48726 := by
  intro p hp
  have h : env48726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48725_48726 : H12AffineEnvironment.transform 2 4 env48725 = env48726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env48725 == env48726) = true)

def env48727 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1344,65665,77935,13340,4096,476,16,69648,70887,78894,77840,1296,74815,81227,8204,1280,256,8200,1344,79470]

theorem envBound48727 : H12AffineFastState.Bounded env48727 := by
  intro p hp
  have h : env48727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48703_48727 : H12AffineEnvironment.transform 17 65665 env48703 = env48727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env48703 == env48727) = true)

theorem identity48727 : scanCanonicalize (H12AffineFastState.compose env48727 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound48727 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env48728 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,25,1296,5124,65536,1344,65665,69750,5125,4096,476,16,69648,70887,70711,69641,1296,66598,73042,21,1280,256,17,1344,71287]

theorem envBound48728 : H12AffineFastState.Bounded env48728 := by
  intro p hp
  have h : env48728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48727_48728 : H12AffineEnvironment.transform 12 25 env48727 = env48728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env48727 == env48728) = true)

def env48729 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,25,1296,5124,65536,1296,65665,69670,5125,4096,396,16,69648,70839,70711,69641,1296,66598,72962,21,1280,256,17,1296,71207]

theorem envBound48729 : H12AffineFastState.Bounded env48729 := by
  intro p hp
  have h : env48729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48728_48729 : H12AffineEnvironment.transform 5 16 env48728 = env48729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env48728 == env48729) = true)

theorem identity48729 : scanCanonicalize (H12AffineFastState.compose env48729 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound48729 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env48730 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1029,25,1296,1,65536,1296,65665,66595,0,1029,396,16,66581,65714,65586,66572,1296,66598,67847,21,1280,256,17,1296,66082]

theorem envBound48730 : H12AffineFastState.Bounded env48730 := by
  intro p hp
  have h : env48730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48729_48730 : H12AffineEnvironment.transform 11 1029 env48729 = env48730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env48729 == env48730) = true)

theorem identity48730 : scanCanonicalize (H12AffineFastState.compose env48730 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound48730 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env48731 : List Nat := [2,4,8,16,32,16,128,20,512,1024,2048,1029,25,1028,1,65536,1028,65665,66595,0,1029,152,16,66581,65714,65586,66572,1028,66598,67603,21,1044,20,17,1028,66082]

theorem envBound48731 : H12AffineFastState.Bounded env48731 := by
  intro p hp
  have h : env48731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48730_48731 : H12AffineEnvironment.transform 7 20 env48730 = env48731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env48730 == env48731) = true)

theorem identity48731 : scanCanonicalize (H12AffineFastState.compose env48731 (packedSelected [0,2,5,7,8,12,15,18] rootPS)) = affineNative (2^(15+1) ^^^ 1574) := by decide +kernel

theorem selectedBound48731 : packedSelected [0,2,5,7,8,12,15,18] rootPS < 2^1333 := by decide +kernel

def env48732 : List Nat := [2,4,8,16,32,16,128,20,512,1024,2048,1029,25,1028,1,1574,1028,1703,517,0,1029,152,16,563,1684,1556,554,1028,512,3637,21,1044,20,17,1028,1028]

theorem envBound48732 : H12AffineFastState.Bounded env48732 := by
  intro p hp
  have h : env48732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48731_48732 : H12AffineEnvironment.transform 15 1574 env48731 = env48732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1574 env48731 == env48732) = true)

theorem identity48732 : scanCanonicalize (H12AffineFastState.compose env48732 (packedSelected [0,2,3,7,8,11] rootPS)) = affineNative (2^(8+1) ^^^ 147) := by decide +kernel

theorem selectedBound48732 : packedSelected [0,2,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env48733 : List Nat := [2,4,8,16,32,16,128,20,147,1024,2048,1029,25,1028,1,1205,1028,1076,150,0,1029,152,16,160,1031,1159,185,1028,147,3238,21,1044,20,17,1028,1028]

theorem envBound48733 : H12AffineFastState.Bounded env48733 := by
  intro p hp
  have h : env48733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48732_48733 : H12AffineEnvironment.transform 8 147 env48732 = env48733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 147 env48732 == env48733) = true)

theorem identity48733 : scanCanonicalize (H12AffineFastState.compose env48733 (packedSelected [5,8,10,13,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound48733 : packedSelected [5,8,10,13,15,17] rootPS < 2^1333 := by decide +kernel

def env48734 : List Nat := [2,4,8,16,32,16,128,20,147,1024,48,1029,25,1028,1,1205,1028,1076,150,0,1029,152,16,160,1031,1159,185,1028,147,1174,21,1044,20,17,1028,1028]

theorem envBound48734 : H12AffineFastState.Bounded env48734 := by
  intro p hp
  have h : env48734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48733_48734 : H12AffineEnvironment.transform 10 48 env48733 = env48734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env48733 == env48734) = true)

theorem identity48734 : scanCanonicalize (H12AffineFastState.compose env48734 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound48734 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env48735 : List Nat := [2,4,8,16,32,16,18,20,1,1024,48,1029,25,1028,1,1063,1028,1076,4,0,1029,10,16,50,1031,1045,43,1028,1,1028,21,1044,20,17,1028,1028]

theorem envBound48735 : H12AffineFastState.Bounded env48735 := by
  intro p hp
  have h : env48735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48734_48735 : H12AffineEnvironment.transform 6 18 env48734 = env48735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env48734 == env48735) = true)

theorem identity48735 : scanCanonicalize (H12AffineFastState.compose env48735 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound48735 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env48736 : List Nat := [2,4,8,11,32,11,9,15,1,1024,43,1029,2,1028,1,1063,1028,1071,4,0,1029,10,11,41,1031,1038,43,1028,1,1028,14,1039,15,10,1028,1028]

theorem envBound48736 : H12AffineFastState.Bounded env48736 := by
  intro p hp
  have h : env48736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48735_48736 : H12AffineEnvironment.transform 3 11 env48735 = env48736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env48735 == env48736) = true)

theorem identity48736 : scanCanonicalize (H12AffineFastState.compose env48736 (packedSelected [0,1,4] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound48736 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env48737 : List Nat := [2,4,8,11,6,11,9,15,1,1024,13,1029,2,1028,1,1025,1028,1033,4,0,1029,10,11,15,1031,1038,13,1028,1,1028,14,1039,15,10,1028,1028]

theorem envBound48737 : H12AffineFastState.Bounded env48737 := by
  intro p hp
  have h : env48737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48736_48737 : H12AffineEnvironment.transform 4 6 env48736 = env48737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env48736 == env48737) = true)

theorem identity48737 : scanCanonicalize (H12AffineFastState.compose env48737 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound48737 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env48738 : List Nat := [2,4,8,11,6,11,9,15,1,5,13,0,2,1,1,4,1,12,4,0,0,10,11,15,2,11,13,1,1,1,14,10,15,10,1,1]

theorem envBound48738 : H12AffineFastState.Bounded env48738 := by
  intro p hp
  have h : env48738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48737_48738 : H12AffineEnvironment.transform 9 5 env48737 = env48738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env48737 == env48738) = true)

theorem identity48738 : scanCanonicalize (H12AffineFastState.compose env48738 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound48738 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env48739 : List Nat := [2,4,4,7,6,7,5,3,1,5,1,0,2,1,1,4,1,0,4,0,0,6,7,3,2,7,1,1,1,1,2,6,3,6,1,1]

theorem envBound48739 : H12AffineFastState.Bounded env48739 := by
  intro p hp
  have h : env48739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48738_48739 : H12AffineEnvironment.transform 2 4 env48738 = env48739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env48738 == env48739) = true)

def env48740 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,25,1296,5124,65536,1297,65665,69671,5125,4096,397,16,69648,70838,70711,69641,1296,66598,72963,21,1280,256,17,1297,71206]

theorem envBound48740 : H12AffineFastState.Bounded env48740 := by
  intro p hp
  have h : env48740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48728_48740 : H12AffineEnvironment.transform 5 17 env48728 = env48740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env48728 == env48740) = true)

theorem identity48740 : scanCanonicalize (H12AffineFastState.compose env48740 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound48740 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env48741 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,25,1296,5124,35,1297,162,4100,5125,4096,397,16,4147,5269,5140,4138,1296,1029,7456,21,1280,256,17,1297,5637]

theorem envBound48741 : H12AffineFastState.Bounded env48741 := by
  intro p hp
  have h : env48741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48740_48741 : H12AffineEnvironment.transform 15 35 env48740 = env48741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env48740 == env48741) = true)

theorem identity48741 : scanCanonicalize (H12AffineFastState.compose env48741 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound48741 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env48742 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,25,1296,277,35,1297,162,1301,276,1297,397,16,1314,388,261,1339,1296,1029,2097,21,1280,256,17,1297,788]

theorem envBound48742 : H12AffineFastState.Bounded env48742 := by
  intro p hp
  have h : env48742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48741_48742 : H12AffineEnvironment.transform 11 1297 env48741 = env48742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env48741 == env48742) = true)

theorem identity48742 : scanCanonicalize (H12AffineFastState.compose env48742 (packedSelected [0,1,3,7,10,11,12,15,19] rootPS)) = affineNative (2^(10+1) ^^^ 1970) := by decide +kernel

theorem selectedBound48742 : packedSelected [0,1,3,7,10,11,12,15,19] rootPS < 2^1333 := by decide +kernel

def env48743 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1970,1297,25,1296,277,35,1297,162,1301,276,1297,397,16,1314,388,261,1339,1296,1029,1923,21,1280,256,17,1297,788]

theorem envBound48743 : H12AffineFastState.Bounded env48743 := by
  intro p hp
  have h : env48743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48742_48743 : H12AffineEnvironment.transform 10 1970 env48742 = env48743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1970 env48742 == env48743) = true)

theorem identity48743 : scanCanonicalize (H12AffineFastState.compose env48743 (packedSelected [0,3,5,7,13,18] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound48743 : packedSelected [0,3,5,7,13,18] rootPS < 2^1333 := by decide +kernel

def env48744 : List Nat := [2,4,8,16,32,17,128,256,137,1024,1339,1297,25,1296,277,35,1297,162,1301,276,1297,397,16,1314,388,261,1339,1296,1029,1290,21,1280,256,17,1297,413]

theorem envBound48744 : H12AffineFastState.Bounded env48744 := by
  intro p hp
  have h : env48744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48743_48744 : H12AffineEnvironment.transform 8 137 env48743 = env48744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env48743 == env48744) = true)

theorem identity48744 : scanCanonicalize (H12AffineFastState.compose env48744 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound48744 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env48745 : List Nat := [2,4,8,16,32,17,128,172,137,1024,1175,1213,25,1212,185,35,1213,162,1209,184,1213,33,16,1166,40,169,1175,1212,1029,1190,21,1196,172,17,1213,49]

theorem envBound48745 : H12AffineFastState.Bounded env48745 := by
  intro p hp
  have h : env48745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48744_48745 : H12AffineEnvironment.transform 7 172 env48744 = env48745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env48744 == env48745) = true)

theorem identity48745 : scanCanonicalize (H12AffineFastState.compose env48745 (packedSelected [2,3,8] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound48745 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env48746 : List Nat := [2,4,8,16,32,17,128,172,137,4,147,185,25,184,185,35,185,162,189,184,185,33,16,138,40,169,147,184,1,162,21,168,172,17,185,49]

theorem envBound48746 : H12AffineFastState.Bounded env48746 := by
  intro p hp
  have h : env48746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48745_48746 : H12AffineEnvironment.transform 9 4 env48745 = env48746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env48745 == env48746) = true)

theorem identity48746 : scanCanonicalize (H12AffineFastState.compose env48746 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound48746 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env48747 : List Nat := [2,4,8,16,11,17,128,135,137,4,147,146,25,147,146,8,146,137,150,147,146,10,16,138,3,130,147,147,1,137,21,131,135,17,146,26]

theorem envBound48747 : H12AffineFastState.Bounded env48747 := by
  intro p hp
  have h : env48747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48746_48747 : H12AffineEnvironment.transform 4 11 env48746 = env48747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env48746 == env48747) = true)

theorem identity48747 : scanCanonicalize (H12AffineFastState.compose env48747 (packedSelected [0,1,4] rootPS)) = affineNative (2^(6+1) ^^^ 20) := by decide +kernel

theorem selectedBound48747 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env48748 : List Nat := [2,4,8,16,11,17,20,19,29,4,7,6,25,7,6,8,6,29,2,7,6,10,16,30,3,22,7,7,1,29,21,23,19,17,6,26]

theorem envBound48748 : H12AffineFastState.Bounded env48748 := by
  intro p hp
  have h : env48748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48747_48748 : H12AffineEnvironment.transform 6 20 env48747 = env48748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 20 env48747 == env48748) = true)

theorem identity48748 : scanCanonicalize (H12AffineFastState.compose env48748 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound48748 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env48749 : List Nat := [2,4,8,13,11,12,9,14,0,4,7,6,4,7,6,8,6,0,2,7,6,10,13,3,3,11,7,7,1,0,8,10,14,12,6,7]

theorem envBound48749 : H12AffineFastState.Bounded env48749 := by
  intro p hp
  have h : env48749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48748_48749 : H12AffineEnvironment.transform 3 13 env48748 = env48749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env48748 == env48749) = true)

theorem identity48749 : scanCanonicalize (H12AffineFastState.compose env48749 (packedSelected [0,1,9] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound48749 : packedSelected [0,1,9] rootPS < 2^1333 := by decide +kernel

def env48750 : List Nat := [2,3,8,10,11,11,9,9,0,3,0,1,3,0,1,8,1,0,2,0,1,10,10,3,3,11,0,0,1,0,8,10,9,11,1,0]

theorem envBound48750 : H12AffineFastState.Bounded env48750 := by
  intro p hp
  have h : env48750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48749_48750 : H12AffineEnvironment.transform 1 3 env48749 = env48750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env48749 == env48750) = true)

def env48751 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1345,262144,77934,32769,4096,46528,16,266384,70886,78895,77840,1296,74815,81226,365713,1280,256,365717,1344,79471]

theorem envBound48751 : H12AffineFastState.Bounded env48751 := by
  intro p hp
  have h : env48751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48701_48751 : H12AffineEnvironment.transform 13 1297 env48701 = env48751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env48701 == env48751) = true)

theorem identity48751 : scanCanonicalize (H12AffineFastState.compose env48751 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32883) := by decide +kernel

theorem selectedBound48751 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env48752 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,32883,1345,262144,45085,32769,4096,46528,16,266384,38037,46172,45155,1296,42060,48441,267490,1280,256,267494,1344,46620]

theorem envBound48752 : H12AffineFastState.Bounded env48752 := by
  intro p hp
  have h : env48752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48751_48752 : H12AffineEnvironment.transform 15 32883 env48751 = env48752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32883 env48751 == env48752) = true)

def env48753 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32883,1345,262144,42333,32769,1344,41088,16,263632,33237,41244,42275,1296,42060,43129,262562,1280,256,262566,1344,41820]

theorem envBound48753 : H12AffineFastState.Bounded env48753 := by
  intro p hp
  have h : env48753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48752_48753 : H12AffineEnvironment.transform 11 1344 env48752 = env48753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env48752 == env48753) = true)

theorem identity48753 : scanCanonicalize (H12AffineFastState.compose env48753 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 34274) := by decide +kernel

theorem selectedBound48753 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env48754 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32883,1345,34274,42333,32769,1344,41088,16,32818,33237,41244,42275,1296,42060,43129,33856,1280,256,33860,1344,41820]

theorem envBound48754 : H12AffineFastState.Bounded env48754 := by
  intro p hp
  have h : env48754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48753_48754 : H12AffineEnvironment.transform 17 34274 env48753 = env48754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 34274 env48753 == env48754) = true)

theorem identity48754 : scanCanonicalize (H12AffineFastState.compose env48754 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 9172) := by decide +kernel

theorem selectedBound48754 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env48755 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,9172,9127,1345,9782,1673,9173,1344,852,16,9190,8705,712,1783,1296,1944,2989,10132,1280,256,10128,1344,136]

theorem envBound48755 : H12AffineFastState.Bounded env48755 := by
  intro p hp
  have h : env48755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans48754_48755 : H12AffineEnvironment.transform 14 9172 env48754 = env48755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9172 env48754 == env48755) = true)

def env48756 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32883,1345,262144,42332,32769,1345,41089,16,263633,33236,41245,42274,1296,42060,43128,262563,1280,256,262567,1344,41821]

theorem envBound48756 : H12AffineFastState.Bounded env48756 := by
  intro p hp
  have h : env48756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart2