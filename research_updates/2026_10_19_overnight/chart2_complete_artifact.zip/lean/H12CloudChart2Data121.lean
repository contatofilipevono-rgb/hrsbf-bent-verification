import H12CloudChart2Data120

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans29851_29878 : H12AffineEnvironment.transform 17 65665 env29851 = env29878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env29851 == env29878) = true)

theorem identity29878 : scanCanonicalize (H12AffineFastState.compose env29878 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound29878 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env29879 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1296,9245,65536,1344,65665,73838,9244,1,477,16,65553,66791,74798,73745,1296,74814,77130,8205,8200,257,1280,1344,75374]

theorem envBound29879 : H12AffineFastState.Bounded env29879 := by
  intro p hp
  have h : env29879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29878_29879 : H12AffineEnvironment.transform 11 1 env29878 = env29879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env29878 == env29879) = true)

def env29880 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1,8192,1296,9245,65536,1296,65665,73790,9244,1,397,16,65553,66743,74798,73745,1296,74814,77082,8205,8200,257,1280,1296,75326]

theorem envBound29880 : H12AffineFastState.Bounded env29880 := by
  intro p hp
  have h : env29880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29879_29880 : H12AffineEnvironment.transform 5 16 env29879 = env29880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29879 == env29880) = true)

theorem identity29880 : scanCanonicalize (H12AffineFastState.compose env29880 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound29880 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env29881 : List Nat := [2,4,8,16,32,16,128,20,512,1024,2048,1,8192,1028,9245,65536,1028,65665,73790,9244,1,153,16,65553,66743,74798,73745,1028,74814,76814,8205,8200,21,1044,1028,75326]

theorem envBound29881 : H12AffineFastState.Bounded env29881 := by
  intro p hp
  have h : env29881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29880_29881 : H12AffineEnvironment.transform 7 20 env29880 = env29881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env29880 == env29881) = true)

theorem identity29881 : scanCanonicalize (H12AffineFastState.compose env29881 (packedSelected [1,2,3,5,8,10,19,23,32] rootPS)) = affineNative (2^(9+1) ^^^ 653) := by decide +kernel

theorem selectedBound29881 : packedSelected [1,2,3,5,8,10,19,23,32] rootPS < 2^1333 := by decide +kernel

def env29882 : List Nat := [2,4,8,16,32,16,128,20,512,653,2048,1,8192,649,8848,65536,649,65665,73790,8849,1,153,16,65553,66106,74403,73745,649,74419,76419,8205,8200,21,665,649,73907]

theorem envBound29882 : H12AffineFastState.Bounded env29882 := by
  intro p hp
  have h : env29882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29881_29882 : H12AffineEnvironment.transform 9 653 env29881 = env29882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 653 env29881 == env29882) = true)

theorem identity29882 : scanCanonicalize (H12AffineFastState.compose env29882 (packedSelected [0,1,4,7,8,9,18,19,21,23,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 10785) := by decide +kernel

theorem selectedBound29882 : packedSelected [0,1,4,7,8,9,18,19,21,23,24,28] rootPS < 2^1333 := by decide +kernel

def env29883 : List Nat := [2,4,8,16,32,16,128,20,512,653,2048,1,8192,649,8848,10785,649,10912,2591,8849,1,153,16,10800,10267,2178,2608,649,2194,162,8205,8200,21,665,649,2706]

theorem envBound29883 : H12AffineFastState.Bounded env29883 := by
  intro p hp
  have h : env29883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29882_29883 : H12AffineEnvironment.transform 15 10785 env29882 = env29883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 10785 env29882 == env29883) = true)

theorem identity29883 : scanCanonicalize (H12AffineFastState.compose env29883 (packedSelected [5,8,10,12,15,17,19,21] rootPS)) = affineNative (2^(12+1) ^^^ 2747) := by decide +kernel

theorem selectedBound29883 : packedSelected [5,8,10,12,15,17,19,21] rootPS < 2^1333 := by decide +kernel

def env29884 : List Nat := [2,4,8,16,32,16,128,20,512,653,2048,1,2747,649,2091,154,649,27,2591,2090,1,153,16,139,672,2178,2608,649,2194,162,2742,2739,21,665,649,2706]

theorem envBound29884 : H12AffineFastState.Bounded env29884 := by
  intro p hp
  have h : env29884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29883_29884 : H12AffineEnvironment.transform 12 2747 env29883 = env29884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2747 env29883 == env29884) = true)

theorem identity29884 : scanCanonicalize (H12AffineFastState.compose env29884 (packedSelected [2,3,5,7,9,11,12,13] rootPS)) = affineNative (2^(10+1) ^^^ 27) := by decide +kernel

theorem selectedBound29884 : packedSelected [2,3,5,7,9,11,12,13] rootPS < 2^1333 := by decide +kernel

def env29885 : List Nat := [2,4,8,16,32,16,128,20,512,653,27,1,672,649,48,154,649,27,516,49,1,153,16,139,672,153,555,649,137,162,685,680,21,665,649,649]

theorem envBound29885 : H12AffineFastState.Bounded env29885 := by
  intro p hp
  have h : env29885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29884_29885 : H12AffineEnvironment.transform 10 27 env29884 = env29885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 27 env29884 == env29885) = true)

theorem identity29885 : scanCanonicalize (H12AffineFastState.compose env29885 (packedSelected [2,3,8] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound29885 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env29886 : List Nat := [2,4,8,16,32,16,35,20,512,558,27,1,515,554,48,57,554,27,516,49,1,58,16,40,515,58,555,554,42,1,526,523,21,570,554,554]

theorem envBound29886 : H12AffineFastState.Bounded env29886 := by
  intro p hp
  have h : env29886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29885_29886 : H12AffineEnvironment.transform 6 35 env29885 = env29886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env29885 == env29886) = true)

theorem identity29886 : scanCanonicalize (H12AffineFastState.compose env29886 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound29886 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env29887 : List Nat := [2,4,8,16,32,16,35,20,27,53,27,1,24,49,48,57,49,27,31,49,1,58,16,40,24,58,48,49,42,1,21,16,21,33,49,49]

theorem envBound29887 : H12AffineFastState.Bounded env29887 := by
  intro p hp
  have h : env29887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29886_29887 : H12AffineEnvironment.transform 8 27 env29886 = env29887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env29886 == env29887) = true)

theorem identity29887 : scanCanonicalize (H12AffineFastState.compose env29887 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound29887 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env29888 : List Nat := [2,4,8,10,32,10,35,14,1,47,1,1,2,43,42,35,43,1,5,43,1,32,10,40,2,32,42,43,42,1,15,10,15,33,43,43]

theorem envBound29888 : H12AffineFastState.Bounded env29888 := by
  intro p hp
  have h : env29888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29887_29888 : H12AffineEnvironment.transform 3 10 env29887 = env29888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env29887 == env29888) = true)

def env29889 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1,8192,1296,9245,65536,1297,65665,73791,9244,1,396,16,65553,66742,74798,73745,1296,74814,77083,8205,8200,257,1280,1297,75327]

theorem envBound29889 : H12AffineFastState.Bounded env29889 := by
  intro p hp
  have h : env29889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29879_29889 : H12AffineEnvironment.transform 5 17 env29879 = env29889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env29879 == env29889) = true)

theorem identity29889 : scanCanonicalize (H12AffineFastState.compose env29889 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 9515) := by decide +kernel

theorem selectedBound29889 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env29890 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1,8192,1296,9245,9515,1297,9642,1300,9244,1,396,16,9530,8605,261,1338,1296,277,2096,8205,8200,257,1280,1297,788]

theorem envBound29890 : H12AffineFastState.Bounded env29890 := by
  intro p hp
  have h : env29890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29889_29890 : H12AffineEnvironment.transform 15 9515 env29889 = env29890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9515 env29889 == env29890) = true)

def env29891 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1345,262144,77934,32769,4096,46528,16,266384,70887,78894,77840,1296,74814,81226,365713,365716,257,1280,1344,79470]

theorem envBound29891 : H12AffineFastState.Bounded env29891 := by
  intro p hp
  have h : env29891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29849_29891 : H12AffineEnvironment.transform 13 1297 env29849 = env29891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env29849 == env29891) = true)

theorem identity29891 : scanCanonicalize (H12AffineFastState.compose env29891 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32883) := by decide +kernel

theorem selectedBound29891 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env29892 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,32883,1345,262144,45085,32769,4096,46528,16,266384,38036,46173,45155,1296,42061,48441,267490,267495,257,1280,1344,46621]

theorem envBound29892 : H12AffineFastState.Bounded env29892 := by
  intro p hp
  have h : env29892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29891_29892 : H12AffineEnvironment.transform 15 32883 env29891 = env29892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32883 env29891 == env29892) = true)

def env29893 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32883,1345,262144,42333,32769,1344,41088,16,263632,33236,41245,42275,1296,42061,43129,262562,262567,257,1280,1344,41821]

theorem envBound29893 : H12AffineFastState.Bounded env29893 := by
  intro p hp
  have h : env29893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29892_29893 : H12AffineEnvironment.transform 11 1344 env29892 = env29893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env29892 == env29893) = true)

theorem identity29893 : scanCanonicalize (H12AffineFastState.compose env29893 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 276) := by decide +kernel

theorem selectedBound29893 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env29894 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,276,359,1345,262144,9289,277,1344,8596,16,263632,192,8201,9271,1296,9561,10605,262562,262567,257,1280,1344,8777]

theorem envBound29894 : H12AffineFastState.Bounded env29894 := by
  intro p hp
  have h : env29894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29893_29894 : H12AffineEnvironment.transform 14 276 env29893 = env29894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 276 env29893 == env29894) = true)

theorem identity29894 : scanCanonicalize (H12AffineFastState.compose env29894 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(10+1) ^^^ 1782) := by decide +kernel

theorem selectedBound29894 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env29895 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1782,1344,8192,1297,276,359,1345,262144,9289,277,1344,8596,16,263632,192,8201,9271,1296,9561,10139,262562,262567,257,1280,1344,8777]

theorem envBound29895 : H12AffineFastState.Bounded env29895 := by
  intro p hp
  have h : env29895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29894_29895 : H12AffineEnvironment.transform 10 1782 env29894 = env29895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1782 env29894 == env29895) = true)

def env29896 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32883,1345,262144,42332,32769,1345,41089,16,263633,33237,41244,42274,1296,42061,43128,262563,262566,257,1280,1344,41820]

theorem envBound29896 : H12AffineFastState.Bounded env29896 := by
  intro p hp
  have h : env29896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29892_29896 : H12AffineEnvironment.transform 11 1345 env29892 = env29896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env29892 == env29896) = true)

theorem identity29896 : scanCanonicalize (H12AffineFastState.compose env29896 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 487) := by decide +kernel

theorem selectedBound29896 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env29897 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32883,1345,487,42332,32769,1345,41089,16,1078,33237,41244,42274,1296,42061,43128,68,65,257,1280,1344,41820]

theorem envBound29897 : H12AffineFastState.Bounded env29897 := by
  intro p hp
  have h : env29897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29896_29897 : H12AffineEnvironment.transform 17 487 env29896 = env29897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 487 env29896 == env29897) = true)

theorem identity29897 : scanCanonicalize (H12AffineFastState.compose env29897 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound29897 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env29898 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,8540,8495,1345,487,1024,8541,1345,477,16,1078,8329,64,1150,1296,1297,2340,68,65,257,1280,1344,512]

theorem envBound29898 : H12AffineFastState.Bounded env29898 := by
  intro p hp
  have h : env29898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29897_29898 : H12AffineEnvironment.transform 14 8540 env29897 = env29898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env29897 == env29898) = true)

theorem identity29898 : scanCanonicalize (H12AffineFastState.compose env29898 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound29898 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env29899 : List Nat := [2,4,8,16,32,64,128,256,512,84,2048,277,8192,325,8540,8495,277,487,84,8541,277,477,16,98,8329,64,42,324,325,2340,68,65,257,340,276,512]

theorem envBound29899 : H12AffineFastState.Bounded env29899 := by
  intro p hp
  have h : env29899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29898_29899 : H12AffineEnvironment.transform 9 84 env29898 = env29899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env29898 == env29899) = true)

theorem identity29899 : scanCanonicalize (H12AffineFastState.compose env29899 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 705) := by decide +kernel

theorem selectedBound29899 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env29900 : List Nat := [2,4,8,16,32,64,128,256,512,84,2048,277,705,325,925,1006,277,487,84,924,277,477,16,98,584,64,42,324,325,2340,68,65,257,340,276,512]

theorem envBound29900 : H12AffineFastState.Bounded env29900 := by
  intro p hp
  have h : env29900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29899_29900 : H12AffineEnvironment.transform 12 705 env29899 = env29900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 705 env29899 == env29900) = true)

theorem identity29900 : scanCanonicalize (H12AffineFastState.compose env29900 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound29900 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env29901 : List Nat := [2,4,8,16,32,16,128,256,512,4,2048,277,657,277,925,958,277,439,4,924,277,397,16,50,536,16,42,276,277,2340,20,17,257,260,276,512]

theorem envBound29901 : H12AffineFastState.Bounded env29901 := by
  intro p hp
  have h : env29901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29900_29901 : H12AffineEnvironment.transform 5 16 env29900 = env29901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29900 == env29901) = true)

theorem identity29901 : scanCanonicalize (H12AffineFastState.compose env29901 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 438) := by decide +kernel

theorem selectedBound29901 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env29902 : List Nat := [2,4,8,16,32,16,128,256,512,4,438,277,657,277,925,958,277,439,4,924,277,397,16,50,536,16,42,276,277,146,20,17,257,260,276,512]

theorem envBound29902 : H12AffineFastState.Bounded env29902 := by
  intro p hp
  have h : env29902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29901_29902 : H12AffineEnvironment.transform 10 438 env29901 = env29902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 438 env29901 == env29902) = true)

theorem identity29902 : scanCanonicalize (H12AffineFastState.compose env29902 (packedSelected [1,3,13] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound29902 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env29903 : List Nat := [2,4,8,16,32,16,57,256,512,4,271,277,552,277,804,775,277,270,4,805,277,308,16,50,536,16,42,276,277,43,20,17,257,260,276,512]

theorem envBound29903 : H12AffineFastState.Bounded env29903 := by
  intro p hp
  have h : env29903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29902_29903 : H12AffineEnvironment.transform 6 57 env29902 = env29903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env29902 == env29903) = true)

theorem identity29903 : scanCanonicalize (H12AffineFastState.compose env29903 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 318) := by decide +kernel

theorem selectedBound29903 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29904 : List Nat := [2,4,8,16,32,16,57,256,318,4,271,277,278,277,26,57,277,270,4,27,277,308,16,50,294,16,42,276,277,43,20,17,257,260,276,318]

theorem envBound29904 : H12AffineFastState.Bounded env29904 := by
  intro p hp
  have h : env29904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29903_29904 : H12AffineEnvironment.transform 8 318 env29903 = env29904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 318 env29903 == env29904) = true)

theorem identity29904 : scanCanonicalize (H12AffineFastState.compose env29904 (packedSelected [0,1,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound29904 : packedSelected [0,1,3,5] rootPS < 2^1333 := by decide +kernel

def env29905 : List Nat := [2,4,8,16,32,16,57,20,42,4,27,1,2,1,26,57,1,26,4,27,1,32,16,50,50,16,42,0,1,43,20,17,21,16,0,42]

theorem envBound29905 : H12AffineFastState.Bounded env29905 := by
  intro p hp
  have h : env29905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29904_29905 : H12AffineEnvironment.transform 7 20 env29904 = env29905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env29904 == env29905) = true)

theorem identity29905 : scanCanonicalize (H12AffineFastState.compose env29905 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound29905 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29906 : List Nat := [2,4,5,16,32,16,52,20,39,4,22,1,2,1,23,52,1,23,4,22,1,32,16,50,50,16,39,0,1,38,20,17,21,16,0,39]

theorem envBound29906 : H12AffineFastState.Bounded env29906 := by
  intro p hp
  have h : env29906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29905_29906 : H12AffineEnvironment.transform 2 5 env29905 = env29906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env29905 == env29906) = true)

theorem identity29906 : scanCanonicalize (H12AffineFastState.compose env29906 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound29906 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29907 : List Nat := [2,4,5,6,32,6,34,2,39,4,0,1,2,1,1,34,1,1,4,0,1,32,6,36,36,6,39,0,1,38,2,7,3,6,0,39]

theorem envBound29907 : H12AffineFastState.Bounded env29907 := by
  intro p hp
  have h : env29907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29906_29907 : H12AffineEnvironment.transform 3 6 env29906 = env29907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env29906 == env29907) = true)

theorem identity29907 : scanCanonicalize (H12AffineFastState.compose env29907 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound29907 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env29908 : List Nat := [2,4,5,6,7,6,5,2,0,4,0,1,2,1,1,5,1,1,4,0,1,7,6,3,3,6,0,0,1,1,2,7,3,6,0,0]

theorem envBound29908 : H12AffineFastState.Bounded env29908 := by
  intro p hp
  have h : env29908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29907_29908 : H12AffineEnvironment.transform 4 7 env29907 = env29908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env29907 == env29908) = true)

def env29909 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16465,262144,95615,32769,4096,61649,17,284033,86518,94526,77841,1297,74814,96347,381312,381317,257,1280,1344,95103]

theorem envBound29909 : H12AffineFastState.Bounded env29909 := by
  intro p hp
  have h : env29909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29848_29909 : H12AffineEnvironment.transform 16 16465 env29848 = env29909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16465 env29848 == env29909) = true)

def env29910 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1345,262144,77935,32769,4096,46529,17,266385,70886,78894,77841,1297,74814,81227,365712,365717,257,1280,1344,79471]

theorem envBound29910 : H12AffineFastState.Bounded env29910 := by
  intro p hp
  have h : env29910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29909_29910 : H12AffineEnvironment.transform 13 1296 env29909 = env29910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env29909 == env29910) = true)

theorem identity29910 : scanCanonicalize (H12AffineFastState.compose env29910 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32882) := by decide +kernel

theorem selectedBound29910 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env29911 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,32882,1345,262144,45085,32769,4096,46529,17,266385,38036,46172,45155,1297,42060,48441,267490,267495,257,1280,1344,46621]

theorem envBound29911 : H12AffineFastState.Bounded env29911 := by
  intro p hp
  have h : env29911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29910_29911 : H12AffineEnvironment.transform 15 32882 env29910 = env29911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32882 env29910 == env29911) = true)

def env29912 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32882,1345,262144,42333,32769,1344,41089,17,263633,33236,41244,42275,1297,42060,43129,262562,262567,257,1280,1344,41821]

theorem envBound29912 : H12AffineFastState.Bounded env29912 := by
  intro p hp
  have h : env29912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29911_29912 : H12AffineEnvironment.transform 11 1344 env29911 = env29912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env29911 == env29912) = true)

theorem identity29912 : scanCanonicalize (H12AffineFastState.compose env29912 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound29912 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env29913 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,0,8192,80,32768,32882,1,262144,40989,32769,0,41089,17,262289,33236,41244,41059,81,41228,43129,262562,262567,257,64,0,41821]

theorem envBound29913 : H12AffineFastState.Bounded env29913 := by
  intro p hp
  have h : env29913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29912_29913 : H12AffineEnvironment.transform 9 320 env29912 = env29913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env29912 == env29913) = true)

theorem identity29913 : scanCanonicalize (H12AffineFastState.compose env29913 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound29913 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env29914 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,0,8192,80,8541,8495,1,262144,320,8540,0,476,17,262289,8329,65,318,81,81,2340,262562,262567,257,64,0,512]

theorem envBound29914 : H12AffineFastState.Bounded env29914 := by
  intro p hp
  have h : env29914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29913_29914 : H12AffineEnvironment.transform 14 8541 env29913 = env29914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env29913 == env29914) = true)

theorem identity29914 : scanCanonicalize (H12AffineFastState.compose env29914 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound29914 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env29915 : List Nat := [2,4,8,16,32,64,128,20,512,84,2048,0,8192,80,8265,8251,1,262144,84,8264,0,200,17,262289,8329,65,42,81,81,2096,262326,262323,21,64,0,512]

theorem envBound29915 : H12AffineFastState.Bounded env29915 := by
  intro p hp
  have h : env29915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29914_29915 : H12AffineEnvironment.transform 7 20 env29914 = env29915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env29914 == env29915) = true)

theorem identity29915 : scanCanonicalize (H12AffineFastState.compose env29915 (packedSelected [3,5,10] rootPS)) = affineNative (2^(17+1) ^^^ 8755) := by decide +kernel

theorem selectedBound29915 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env29916 : List Nat := [2,4,8,16,32,64,128,20,512,84,2048,0,8192,80,8265,8251,1,8755,84,8264,0,200,17,8866,8329,65,42,81,81,2096,8837,8832,21,64,0,512]

theorem envBound29916 : H12AffineFastState.Bounded env29916 := by
  intro p hp
  have h : env29916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29915_29916 : H12AffineEnvironment.transform 17 8755 env29915 = env29916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8755 env29915 == env29916) = true)

theorem identity29916 : scanCanonicalize (H12AffineFastState.compose env29916 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound29916 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env29917 : List Nat := [2,4,8,16,32,16,128,20,512,4,2048,0,8192,0,8217,8251,1,8755,4,8216,0,152,17,8866,8329,17,42,1,1,2096,8837,8832,21,16,0,512]

theorem envBound29917 : H12AffineFastState.Bounded env29917 := by
  intro p hp
  have h : env29917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29916_29917 : H12AffineEnvironment.transform 5 16 env29916 = env29917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29916 == env29917) = true)

theorem identity29917 : scanCanonicalize (H12AffineFastState.compose env29917 (packedSelected [1,3,13] rootPS)) = affineNative (2^(12+1) ^^^ 2562) := by decide +kernel

theorem selectedBound29917 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env29918 : List Nat := [2,4,8,16,32,16,128,20,512,4,2048,0,2562,0,2587,2617,1,2097,4,2586,0,152,17,2208,2699,17,42,1,1,2096,2183,2178,21,16,0,512]

theorem envBound29918 : H12AffineFastState.Bounded env29918 := by
  intro p hp
  have h : env29918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29917_29918 : H12AffineEnvironment.transform 12 2562 env29917 = env29918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2562 env29917 == env29918) = true)

theorem identity29918 : scanCanonicalize (H12AffineFastState.compose env29918 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 146) := by decide +kernel

theorem selectedBound29918 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env29919 : List Nat := [2,4,8,16,32,16,128,20,512,4,146,0,656,0,649,683,1,163,4,648,0,152,17,50,537,17,42,1,1,162,21,16,21,16,0,512]

theorem envBound29919 : H12AffineFastState.Bounded env29919 := by
  intro p hp
  have h : env29919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29918_29919 : H12AffineEnvironment.transform 10 146 env29918 = env29919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 146 env29918 == env29919) = true)

theorem identity29919 : scanCanonicalize (H12AffineFastState.compose env29919 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 142) := by decide +kernel

theorem selectedBound29919 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29920 : List Nat := [2,4,8,16,32,16,128,20,142,4,146,0,30,0,7,37,1,163,4,6,0,152,17,50,151,17,42,1,1,162,21,16,21,16,0,142]

theorem envBound29920 : H12AffineFastState.Bounded env29920 := by
  intro p hp
  have h : env29920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29919_29920 : H12AffineEnvironment.transform 8 142 env29919 = env29920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 142 env29919 == env29920) = true)

theorem identity29920 : scanCanonicalize (H12AffineFastState.compose env29920 (packedSelected [5] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound29920 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env29921 : List Nat := [2,4,8,16,32,16,56,20,54,4,42,0,30,0,7,37,1,27,4,6,0,32,17,50,47,17,42,1,1,26,21,16,21,16,0,54]

theorem envBound29921 : H12AffineFastState.Bounded env29921 := by
  intro p hp
  have h : env29921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29920_29921 : H12AffineEnvironment.transform 6 56 env29920 = env29921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env29920 == env29921) = true)

theorem identity29921 : scanCanonicalize (H12AffineFastState.compose env29921 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound29921 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29922 : List Nat := [2,4,8,11,32,11,35,15,45,4,42,0,5,0,7,37,1,0,4,6,0,32,10,41,47,10,42,1,1,1,14,11,14,11,0,45]

theorem envBound29922 : H12AffineFastState.Bounded env29922 := by
  intro p hp
  have h : env29922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29921_29922 : H12AffineEnvironment.transform 3 11 env29921 = env29922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env29921 == env29922) = true)

theorem identity29922 : scanCanonicalize (H12AffineFastState.compose env29922 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound29922 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env29923 : List Nat := [2,4,8,11,13,11,14,15,0,4,7,0,5,0,7,8,1,0,4,6,0,13,10,4,2,10,7,1,1,1,14,11,14,11,0,0]

theorem envBound29923 : H12AffineFastState.Bounded env29923 := by
  intro p hp
  have h : env29923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29922_29923 : H12AffineEnvironment.transform 4 13 env29922 = env29923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env29922 == env29923) = true)

theorem identity29923 : scanCanonicalize (H12AffineFastState.compose env29923 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound29923 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29924 : List Nat := [2,3,8,11,10,11,9,8,0,3,0,0,2,0,0,8,1,0,3,1,0,10,10,3,2,10,0,1,1,1,9,11,9,11,0,0]

theorem envBound29924 : H12AffineFastState.Bounded env29924 := by
  intro p hp
  have h : env29924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29923_29924 : H12AffineEnvironment.transform 1 3 env29923 = env29924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env29923 == env29924) = true)

def env29925 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32882,1345,262144,42332,32769,1345,41088,17,263632,33237,41245,42274,1297,42060,43128,262563,262566,257,1280,1344,41820]

theorem envBound29925 : H12AffineFastState.Bounded env29925 := by
  intro p hp
  have h : env29925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29911_29925 : H12AffineEnvironment.transform 11 1345 env29911 = env29925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env29911 == env29925) = true)

theorem identity29925 : scanCanonicalize (H12AffineFastState.compose env29925 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 34226) := by decide +kernel

theorem selectedBound29925 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env29926 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32882,1345,34226,42332,32769,1345,41088,17,32866,33237,41245,42274,1297,42060,43128,33809,33812,257,1280,1344,41820]

theorem envBound29926 : H12AffineFastState.Bounded env29926 := by
  intro p hp
  have h : env29926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29925_29926 : H12AffineEnvironment.transform 17 34226 env29925 = env29926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 34226 env29925 == env29926) = true)

theorem identity29926 : scanCanonicalize (H12AffineFastState.compose env29926 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(10+1) ^^^ 1782) := by decide +kernel

theorem selectedBound29926 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env29927 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1782,1345,8192,1296,32768,32882,1345,34226,42332,32769,1345,41088,17,32866,33237,41245,42274,1297,42060,42638,33809,33812,257,1280,1344,41820]

theorem envBound29927 : H12AffineFastState.Bounded env29927 := by
  intro p hp
  have h : env29927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29926_29927 : H12AffineEnvironment.transform 10 1782 env29926 = env29927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1782 env29926 == env29927) = true)

def env29928 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1344,262144,77934,32769,4096,46528,17,266384,70887,78895,77841,1297,74814,81226,365713,365716,257,1280,1344,79470]

theorem envBound29928 : H12AffineFastState.Bounded env29928 := by
  intro p hp
  have h : env29928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29909_29928 : H12AffineEnvironment.transform 13 1297 env29909 = env29928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env29909 == env29928) = true)

theorem identity29928 : scanCanonicalize (H12AffineFastState.compose env29928 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound29928 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env29929 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1344,262144,77934,13341,4096,476,17,266384,70887,78895,77841,1297,74814,81226,336013,336008,257,1280,1344,79470]

theorem envBound29929 : H12AffineFastState.Bounded env29929 := by
  intro p hp
  have h : env29929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29928_29929 : H12AffineEnvironment.transform 14 13340 env29928 = env29929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env29928 == env29929) = true)

def env29930 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1344,65664,77934,13341,4096,476,17,69648,70887,78895,77841,1297,74814,81226,8205,8200,257,1280,1344,79470]

theorem envBound29930 : H12AffineFastState.Bounded env29930 := by
  intro p hp
  have h : env29930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29929_29930 : H12AffineEnvironment.transform 17 65664 env29929 = env29930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env29929 == env29930) = true)

theorem identity29930 : scanCanonicalize (H12AffineFastState.compose env29930 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5384) := by decide +kernel

theorem selectedBound29930 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env29931 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5384,1297,276,65536,1344,65664,66918,277,4096,476,17,69648,70887,65831,66841,1297,69942,67650,5381,5376,257,1280,1344,66406]

theorem envBound29931 : H12AffineFastState.Bounded env29931 := by
  intro p hp
  have h : env29931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29930_29931 : H12AffineEnvironment.transform 12 5384 env29930 = env29931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5384 env29930 == env29931) = true)

def env29932 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5384,1297,276,65536,1296,65664,66870,277,4096,396,17,69648,70839,65831,66841,1297,69942,67602,5381,5376,257,1280,1296,66358]

theorem envBound29932 : H12AffineFastState.Bounded env29932 := by
  intro p hp
  have h : env29932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29931_29932 : H12AffineEnvironment.transform 5 16 env29931 = env29932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29931 == env29932) = true)

theorem identity29932 : scanCanonicalize (H12AffineFastState.compose env29932 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 4130) := by decide +kernel

theorem selectedBound29932 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env29933 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5384,1297,276,4130,1296,4258,5396,277,4096,396,17,50,1173,4357,5435,1297,276,6192,5381,5376,257,1280,1296,4884]

theorem envBound29933 : H12AffineFastState.Bounded env29933 := by
  intro p hp
  have h : env29933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29932_29933 : H12AffineEnvironment.transform 15 4130 env29932 = env29933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4130 env29932 == env29933) = true)

theorem identity29933 : scanCanonicalize (H12AffineFastState.compose env29933 (packedSelected [2,3,10,13,21,23,24,26,32] rootPS)) = affineNative (2^(9+1) ^^^ 652) := by decide +kernel

theorem selectedBound29933 : packedSelected [2,3,10,13,21,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env29934 : List Nat := [2,4,8,16,32,16,128,256,512,652,2048,4096,4996,925,276,4130,924,4258,5016,277,4096,396,17,50,537,4357,5047,925,276,6192,5001,5004,257,908,924,4884]

theorem envBound29934 : H12AffineFastState.Bounded env29934 := by
  intro p hp
  have h : env29934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29933_29934 : H12AffineEnvironment.transform 9 652 env29933 = env29934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 652 env29933 == env29934) = true)

theorem identity29934 : scanCanonicalize (H12AffineFastState.compose env29934 (packedSelected [0,1,3,4,7,8,9,10,13,18,19,23,26,28] rootPS)) = affineNative (2^(10+1) ^^^ 390) := by decide +kernel

theorem selectedBound29934 : packedSelected [0,1,3,4,7,8,9,10,13,18,19,23,26,28] rootPS < 2^1333 := by decide +kernel

def env29935 : List Nat := [2,4,8,16,32,16,128,256,512,652,390,4096,4996,925,276,4130,924,4258,5016,277,4096,396,17,50,537,4357,5047,925,276,4534,5001,5004,257,908,924,4884]

theorem envBound29935 : H12AffineFastState.Bounded env29935 := by
  intro p hp
  have h : env29935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29934_29935 : H12AffineEnvironment.transform 10 390 env29934 = env29935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 390 env29934 == env29935) = true)

theorem identity29935 : scanCanonicalize (H12AffineFastState.compose env29935 (packedSelected [5,8,10,12,15,17,19,21] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound29935 : packedSelected [5,8,10,12,15,17,19,21] rootPS < 2^1333 := by decide +kernel

def env29936 : List Nat := [2,4,8,16,32,16,56,256,512,564,318,4096,4924,805,276,4130,804,4122,4896,277,4096,308,17,50,537,4357,4879,805,276,4366,4913,4916,257,820,804,4884]

theorem envBound29936 : H12AffineFastState.Bounded env29936 := by
  intro p hp
  have h : env29936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29935_29936 : H12AffineEnvironment.transform 6 56 env29935 = env29936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env29935 == env29936) = true)

theorem identity29936 : scanCanonicalize (H12AffineFastState.compose env29936 (packedSelected [1,4,7,8,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 783) := by decide +kernel

theorem selectedBound29936 : packedSelected [1,4,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env29937 : List Nat := [2,4,8,16,32,16,56,256,512,564,318,783,51,805,276,813,804,789,47,277,783,308,17,50,537,522,0,805,276,513,62,59,257,820,804,27]

theorem envBound29937 : H12AffineFastState.Bounded env29937 := by
  intro p hp
  have h : env29937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29936_29937 : H12AffineEnvironment.transform 11 783 env29936 = env29937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 783 env29936 == env29937) = true)

theorem identity29937 : scanCanonicalize (H12AffineFastState.compose env29937 (packedSelected [0,1,5,7,10] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound29937 : packedSelected [0,1,5,7,10] rootPS < 2^1333 := by decide +kernel

def env29938 : List Nat := [2,4,8,16,32,16,56,256,49,5,318,318,51,276,276,284,277,292,47,277,318,308,17,50,40,59,0,276,276,48,62,59,257,261,277,27]

theorem envBound29938 : H12AffineFastState.Bounded env29938 := by
  intro p hp
  have h : env29938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29937_29938 : H12AffineEnvironment.transform 8 49 env29937 = env29938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env29937 == env29938) = true)

theorem identity29938 : scanCanonicalize (H12AffineFastState.compose env29938 (packedSelected [1,2,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound29938 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env29939 : List Nat := [2,4,8,11,32,11,35,256,42,5,293,293,40,271,271,263,270,292,47,270,293,303,10,41,40,32,0,271,271,43,37,32,257,261,270,0]

theorem envBound29939 : H12AffineFastState.Bounded env29939 := by
  intro p hp
  have h : env29939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29938_29939 : H12AffineEnvironment.transform 3 11 env29938 = env29939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env29938 == env29939) = true)

theorem identity29939 : scanCanonicalize (H12AffineFastState.compose env29939 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound29939 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29940 : List Nat := [2,4,8,11,32,11,35,14,42,5,43,43,40,1,1,9,0,42,47,0,43,33,10,41,40,32,0,1,1,43,37,32,15,11,0,0]

theorem envBound29940 : H12AffineFastState.Bounded env29940 := by
  intro p hp
  have h : env29940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29939_29940 : H12AffineEnvironment.transform 7 14 env29939 = env29940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env29939 == env29940) = true)

def env29941 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,5384,1297,276,65536,1297,65664,66871,277,4096,397,17,69648,70838,65831,66841,1297,69942,67603,5381,5376,257,1280,1297,66359]

theorem envBound29941 : H12AffineFastState.Bounded env29941 := by
  intro p hp
  have h : env29941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29931_29941 : H12AffineEnvironment.transform 5 17 env29931 = env29941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env29931 == env29941) = true)

theorem identity29941 : scanCanonicalize (H12AffineFastState.compose env29941 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound29941 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env29942 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,276,1052,1297,276,65536,1297,65664,66871,277,276,397,17,65796,66978,65831,66841,1297,65570,67603,1041,1044,257,1280,1297,66359]

theorem envBound29942 : H12AffineFastState.Bounded env29942 := by
  intro p hp
  have h : env29942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29941_29942 : H12AffineEnvironment.transform 11 276 env29941 = env29942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env29941 == env29942) = true)

def env29943 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,1344,65665,77934,13341,4096,476,17,69649,70887,78895,77841,1297,74814,81226,8204,8201,257,1280,1344,79470]

theorem envBound29943 : H12AffineFastState.Bounded env29943 := by
  intro p hp
  have h : env29943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29929_29943 : H12AffineEnvironment.transform 17 65665 env29929 = env29943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env29929 == env29943) = true)

theorem identity29943 : scanCanonicalize (H12AffineFastState.compose env29943 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 73) := by decide +kernel

theorem selectedBound29943 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env29944 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,73,1297,5205,65536,1344,65665,69671,5204,4096,476,17,69649,70887,70758,69720,1297,66679,72963,69,64,257,1280,1344,71207]

theorem envBound29944 : H12AffineFastState.Bounded env29944 := by
  intro p hp
  have h : env29944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29943_29944 : H12AffineEnvironment.transform 12 73 env29943 = env29944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env29943 == env29944) = true)

def env29945 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,25,1297,5125,65536,1296,65665,69671,5124,4096,396,17,69649,70839,70710,69640,1297,66599,72963,21,16,257,1280,1296,71207]

theorem envBound29945 : H12AffineFastState.Bounded env29945 := by
  intro p hp
  have h : env29945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29944_29945 : H12AffineEnvironment.transform 5 16 env29944 = env29945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29944 == env29945) = true)

theorem identity29945 : scanCanonicalize (H12AffineFastState.compose env29945 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 1331) := by decide +kernel

theorem selectedBound29945 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env29946 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,25,1297,5125,1331,1296,1458,5396,5124,4096,396,17,5410,4484,4357,5435,1297,276,6192,21,16,257,1280,1296,4884]

theorem envBound29946 : H12AffineFastState.Bounded env29946 := by
  intro p hp
  have h : env29946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29945_29946 : H12AffineEnvironment.transform 15 1331 env29945 = env29946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1331 env29945 == env29946) = true)

theorem identity29946 : scanCanonicalize (H12AffineFastState.compose env29946 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound29946 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env29947 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,276,25,1297,1297,1331,1296,1458,1024,1296,276,396,17,1078,144,17,1071,1297,276,2340,21,16,257,1280,1296,512]

theorem envBound29947 : H12AffineFastState.Bounded env29947 := by
  intro p hp
  have h : env29947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29946_29947 : H12AffineEnvironment.transform 11 276 env29946 = env29947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env29946 == env29947) = true)

theorem identity29947 : scanCanonicalize (H12AffineFastState.compose env29947 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 277) := by decide +kernel

theorem selectedBound29947 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env29948 : List Nat := [2,4,8,16,32,16,128,256,512,1024,277,276,25,1297,1297,1331,1296,1458,1024,1296,276,396,17,1078,144,17,1071,1297,276,49,21,16,257,1280,1296,512]

theorem envBound29948 : H12AffineFastState.Bounded env29948 := by
  intro p hp
  have h : env29948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29947_29948 : H12AffineEnvironment.transform 10 277 env29947 = env29948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 277 env29947 == env29948) = true)

theorem identity29948 : scanCanonicalize (H12AffineFastState.compose env29948 (packedSelected [0,7,11] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound29948 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env29949 : List Nat := [2,4,8,16,32,16,9,256,512,1024,277,276,25,1297,1297,1331,1296,1339,1024,1296,276,261,17,1078,25,17,1071,1297,276,49,21,16,257,1280,1296,512]

theorem envBound29949 : H12AffineFastState.Bounded env29949 := by
  intro p hp
  have h : env29949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29948_29949 : H12AffineEnvironment.transform 6 9 env29948 = env29949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29948 == env29949) = true)

theorem identity29949 : scanCanonicalize (H12AffineFastState.compose env29949 (packedSelected [0,1,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 289) := by decide +kernel

theorem selectedBound29949 : packedSelected [0,1,7,8] rootPS < 2^1333 := by decide +kernel

def env29950 : List Nat := [2,4,8,16,32,16,9,256,512,289,277,276,25,48,48,18,49,26,289,49,276,261,17,279,25,17,270,48,276,49,21,16,257,33,49,512]

theorem envBound29950 : H12AffineFastState.Bounded env29950 := by
  intro p hp
  have h : env29950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29949_29950 : H12AffineEnvironment.transform 9 289 env29949 = env29950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 289 env29949 == env29950) = true)

theorem identity29950 : scanCanonicalize (H12AffineFastState.compose env29950 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound29950 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env29951 : List Nat := [2,4,8,16,32,16,9,14,512,47,27,26,25,48,48,18,49,26,47,49,26,11,17,25,25,17,0,48,26,49,21,16,15,33,49,512]

theorem envBound29951 : H12AffineFastState.Bounded env29951 := by
  intro p hp
  have h : env29951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29950_29951 : H12AffineEnvironment.transform 7 14 env29950 = env29951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env29950 == env29951) = true)

theorem identity29951 : scanCanonicalize (H12AffineFastState.compose env29951 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound29951 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env29952 : List Nat := [2,4,8,16,32,16,9,14,26,47,27,26,25,48,48,18,49,26,47,49,26,11,17,25,25,17,0,48,26,49,21,16,15,33,49,26]

theorem envBound29952 : H12AffineFastState.Bounded env29952 := by
  intro p hp
  have h : env29952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29951_29952 : H12AffineEnvironment.transform 8 26 env29951 = env29952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env29951 == env29952) = true)

theorem identity29952 : scanCanonicalize (H12AffineFastState.compose env29952 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound29952 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env29953 : List Nat := [2,4,8,16,16,16,9,14,26,31,27,26,25,0,0,18,1,26,31,1,26,11,17,25,25,17,0,0,26,1,21,16,15,17,1,26]

theorem envBound29953 : H12AffineFastState.Bounded env29953 := by
  intro p hp
  have h : env29953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29952_29953 : H12AffineEnvironment.transform 4 16 env29952 = env29953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env29952 == env29953) = true)

theorem identity29953 : scanCanonicalize (H12AffineFastState.compose env29953 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound29953 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29954 : List Nat := [2,4,8,13,13,13,9,14,7,2,6,7,4,0,0,15,1,7,2,1,7,11,12,4,4,12,0,0,7,1,8,13,15,12,1,7]

theorem envBound29954 : H12AffineFastState.Bounded env29954 := by
  intro p hp
  have h : env29954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29953_29954 : H12AffineEnvironment.transform 3 13 env29953 = env29954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env29953 == env29954) = true)

def env29955 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,24,1297,5124,65536,1297,65665,69671,5125,4096,397,17,69649,70838,70711,69641,1297,66598,72963,20,17,257,1280,1297,71207]

theorem envBound29955 : H12AffineFastState.Bounded env29955 := by
  intro p hp
  have h : env29955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29944_29955 : H12AffineEnvironment.transform 5 17 env29944 = env29955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env29944 == env29955) = true)

theorem identity29955 : scanCanonicalize (H12AffineFastState.compose env29955 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound29955 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env29956 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,276,24,1297,1296,65536,1297,65665,65843,1297,276,397,17,65797,66978,66851,65821,1297,66598,68631,20,17,257,1280,1297,67379]

theorem envBound29956 : H12AffineFastState.Bounded env29956 := by
  intro p hp
  have h : env29956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29955_29956 : H12AffineEnvironment.transform 11 276 env29955 = env29956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env29955 == env29956) = true)

theorem identity29956 : scanCanonicalize (H12AffineFastState.compose env29956 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 1330) := by decide +kernel

theorem selectedBound29956 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env29957 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,276,24,1297,1296,1330,1297,1459,1025,1297,276,397,17,1079,144,17,1071,1297,276,2341,20,17,257,1280,1297,513]

theorem envBound29957 : H12AffineFastState.Bounded env29957 := by
  intro p hp
  have h : env29957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29956_29957 : H12AffineEnvironment.transform 15 1330 env29956 = env29957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1330 env29956 == env29957) = true)

theorem identity29957 : scanCanonicalize (H12AffineFastState.compose env29957 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 549) := by decide +kernel

theorem selectedBound29957 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env29958 : List Nat := [2,4,8,16,32,17,128,256,512,549,2048,276,24,820,821,791,820,918,548,820,276,397,17,530,144,17,522,820,276,2341,20,17,257,805,820,513]

theorem envBound29958 : H12AffineFastState.Bounded env29958 := by
  intro p hp
  have h : env29958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29957_29958 : H12AffineEnvironment.transform 9 549 env29957 = env29958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 549 env29957 == env29958) = true)

theorem identity29958 : scanCanonicalize (H12AffineFastState.compose env29958 (packedSelected [0,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 799) := by decide +kernel

theorem selectedBound29958 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env29959 : List Nat := [2,4,8,16,32,17,128,256,512,549,799,276,24,820,821,791,820,918,548,820,276,397,17,530,144,17,522,820,276,570,20,17,257,805,820,513]

theorem envBound29959 : H12AffineFastState.Bounded env29959 := by
  intro p hp
  have h : env29959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29958_29959 : H12AffineEnvironment.transform 10 799 env29958 = env29959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 799 env29958 == env29959) = true)

theorem identity29959 : scanCanonicalize (H12AffineFastState.compose env29959 (packedSelected [12,13,15] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound29959 : packedSelected [12,13,15] rootPS < 2^1333 := by decide +kernel

def env29960 : List Nat := [2,4,8,16,32,17,128,20,512,549,523,0,24,544,545,515,544,642,548,544,0,153,17,530,144,17,522,544,0,570,20,17,21,561,544,513]

theorem envBound29960 : H12AffineFastState.Bounded env29960 := by
  intro p hp
  have h : env29960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29959_29960 : H12AffineEnvironment.transform 7 20 env29959 = env29960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env29959 == env29960) = true)

theorem identity29960 : scanCanonicalize (H12AffineFastState.compose env29960 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound29960 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29961 : List Nat := [2,4,8,1,32,0,128,5,512,549,523,0,9,544,545,515,544,642,548,544,0,136,0,515,129,0,522,544,0,555,5,0,4,544,544,513]

theorem envBound29961 : H12AffineFastState.Bounded env29961 := by
  intro p hp
  have h : env29961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29960_29961 : H12AffineEnvironment.transform 3 1 env29960 = env29961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env29960 == env29961) = true)

theorem identity29961 : scanCanonicalize (H12AffineFastState.compose env29961 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound29961 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29962 : List Nat := [2,4,3,1,32,0,128,5,512,549,512,0,2,544,545,515,544,642,548,544,0,131,0,515,129,0,513,544,0,544,5,0,4,544,544,513]

theorem envBound29962 : H12AffineFastState.Bounded env29962 := by
  intro p hp
  have h : env29962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29961_29962 : H12AffineEnvironment.transform 2 3 env29961 = env29962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env29961 == env29962) = true)

theorem identity29962 : scanCanonicalize (H12AffineFastState.compose env29962 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 3) := by decide +kernel

theorem selectedBound29962 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env29963 : List Nat := [2,4,3,1,32,0,128,5,3,38,3,0,2,35,34,0,35,129,39,35,0,131,0,0,129,0,2,35,0,35,5,0,4,35,35,2]

theorem envBound29963 : H12AffineFastState.Bounded env29963 := by
  intro p hp
  have h : env29963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29962_29963 : H12AffineEnvironment.transform 8 3 env29962 = env29963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 3 env29962 == env29963) = true)

theorem identity29963 : scanCanonicalize (H12AffineFastState.compose env29963 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound29963 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env29964 : List Nat := [2,4,3,1,32,0,2,5,3,38,3,0,2,35,34,0,35,3,39,35,0,1,0,0,3,0,2,35,0,35,5,0,4,35,35,2]

theorem envBound29964 : H12AffineFastState.Bounded env29964 := by
  intro p hp
  have h : env29964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29963_29964 : H12AffineEnvironment.transform 6 2 env29963 = env29964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env29963 == env29964) = true)

theorem identity29964 : scanCanonicalize (H12AffineFastState.compose env29964 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound29964 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env29965 : List Nat := [2,4,3,1,7,0,2,5,3,1,3,0,2,4,5,0,4,3,0,4,0,1,0,0,3,0,2,4,0,4,5,0,4,4,4,2]

theorem envBound29965 : H12AffineFastState.Bounded env29965 := by
  intro p hp
  have h : env29965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29964_29965 : H12AffineEnvironment.transform 4 7 env29964 = env29965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env29964 == env29965) = true)

theorem identity29965 : scanCanonicalize (H12AffineFastState.compose env29965 (packedSelected [0,8] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound29965 : packedSelected [0,8] rootPS < 2^1333 := by decide +kernel

def env29966 : List Nat := [2,0,3,1,3,0,2,1,3,1,3,0,2,0,1,0,0,3,0,0,0,1,0,0,3,0,2,0,0,0,1,0,0,0,0,2]

theorem envBound29966 : H12AffineFastState.Bounded env29966 := by
  intro p hp
  have h : env29966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29965_29966 : H12AffineEnvironment.transform 1 0 env29965 = env29966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env29965 == env29966) = true)

def env29967 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,33554432,672784,134217728,148800,33584584,96346,50962568,4294967296,34088328,4345352435,151462017,33563273]

theorem envBound29967 : H12AffineFastState.Bounded env29967 := by
  intro p hp
  have h : env29967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28771_29967 : H12AffineEnvironment.transform 20 4097 env28771 = env29967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env28771 == env29967) = true)

theorem identity29967 : scanCanonicalize (H12AffineFastState.compose env29967 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 135123451) := by decide +kernel

theorem selectedBound29967 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env29968 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,33554432,672784,134217728,148800,33584584,96346,50962568,135123451,34088328,185401608,151462017,33563273]

theorem envBound29968 : H12AffineFastState.Bounded env29968 := by
  intro p hp
  have h : env29968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29967_29968 : H12AffineEnvironment.transform 31 135123451 env29967 = env29968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 135123451 env29967 == env29968) = true)

def env29969 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,533640,672784,134217728,148800,545088,96346,16876544,135123451,256,151332224,151462017,525825]

theorem envBound29969 : H12AffineFastState.Bounded env29969 := by
  intro p hp
  have h : env29969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29968_29969 : H12AffineEnvironment.transform 24 533640 env29968 = env29969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533640 env29968 == env29969) = true)

def env29970 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,533640,672784,17245632,148800,545088,96346,16876544,17495099,256,131136,1345,525825]

theorem envBound29970 : H12AffineFastState.Bounded env29970 := by
  intro p hp
  have h : env29970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29969_29970 : H12AffineEnvironment.transform 26 17245632 env29969 = env29970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env29969 == env29970) = true)

theorem identity29970 : scanCanonicalize (H12AffineFastState.compose env29970 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 41003) := by decide +kernel

theorem selectedBound29970 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env29971 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,41003,533640,672784,493035,148800,545088,96346,74795,676880,256,131136,1345,525825]

theorem envBound29971 : H12AffineFastState.Bounded env29971 := by
  intro p hp
  have h : env29971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29970_29971 : H12AffineEnvironment.transform 23 41003 env29970 = env29971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41003 env29970 == env29971) = true)

def env29972 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147520,41003,143496,20496,493035,148800,148800,96346,74795,16400,256,131136,1345,135681]

theorem envBound29972 : H12AffineFastState.Bounded env29972 := by
  intro p hp
  have h : env29972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29971_29972 : H12AffineEnvironment.transform 18 136192 env29971 = env29972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env29971 == env29972) = true)

def env29973 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147520,41003,143496,20496,492615,148716,148716,96346,74795,16400,172,131136,1261,135681]

theorem envBound29973 : H12AffineFastState.Bounded env29973 := by
  intro p hp
  have h : env29973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29972_29973 : H12AffineEnvironment.transform 7 172 env29972 = env29973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env29972 == env29973) = true)

def env29974 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61568,147472,41003,143496,20496,492567,148668,148668,96266,74795,16400,172,131088,1213,135681]

theorem envBound29974 : H12AffineFastState.Bounded env29974 := by
  intro p hp
  have h : env29974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29973_29974 : H12AffineEnvironment.transform 5 16 env29973 = env29974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29973 == env29974) = true)

theorem identity29974 : scanCanonicalize (H12AffineFastState.compose env29974 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 223242) := by decide +kernel

theorem selectedBound29974 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env29975 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,223242,136192,32769,4097,61568,147472,41003,143496,20496,60445,148668,148668,96266,74795,16400,172,131088,1213,135681]

theorem envBound29975 : H12AffineFastState.Bounded env29975 := by
  intro p hp
  have h : env29975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29974_29975 : H12AffineEnvironment.transform 17 223242 env29974 = env29975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223242 env29974 == env29975) = true)

theorem identity29975 : scanCanonicalize (H12AffineFastState.compose env29975 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 28802) := by decide +kernel

theorem selectedBound29975 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env29976 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,28802,131072,137352,136192,32769,4097,61568,147472,41003,143496,20496,60445,148668,148668,2184,21673,16400,172,131088,1213,135681]

theorem envBound29976 : H12AffineFastState.Bounded env29976 := by
  intro p hp
  have h : env29976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29975_29976 : H12AffineEnvironment.transform 15 28802 env29975 = env29976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28802 env29975 == env29976) = true)

theorem identity29976 : scanCanonicalize (H12AffineFastState.compose env29976 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(16+1) ^^^ 40984) := by decide +kernel

theorem selectedBound29976 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env29977 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,28802,40984,47248,46104,32769,4097,61568,57352,41003,37008,20496,60445,58532,58532,2184,21673,16400,172,40968,1213,45593]

theorem envBound29977 : H12AffineFastState.Bounded env29977 := by
  intro p hp
  have h : env29977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29976_29977 : H12AffineEnvironment.transform 16 40984 env29976 = env29977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 40984 env29976 == env29977) = true)

theorem identity29977 : scanCanonicalize (H12AffineFastState.compose env29977 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound29977 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env29978 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1213,32768,13375,40984,47248,46104,32769,4097,46141,42165,41003,37008,5293,43168,40985,40985,2184,4116,1197,172,40968,1213,45593]

theorem envBound29978 : H12AffineFastState.Bounded env29978 := by
  intro p hp
  have h : env29978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29977_29978 : H12AffineEnvironment.transform 13 1213 env29977 = env29978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env29977 == env29978) = true)

theorem identity29978 : scanCanonicalize (H12AffineFastState.compose env29978 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(12+1) ^^^ 6283) := by decide +kernel

theorem selectedBound29978 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env29979 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,6283,1213,32768,3252,39059,32795,35987,32769,4097,36022,39998,39072,37008,5293,36907,39058,39058,2184,4116,1197,172,39043,1213,35474]

theorem envBound29979 : H12AffineFastState.Bounded env29979 := by
  intro p hp
  have h : env29979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29978_29979 : H12AffineEnvironment.transform 12 6283 env29978 = env29979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6283 env29978 == env29979) = true)

theorem identity29979 : scanCanonicalize (H12AffineFastState.compose env29979 (packedSelected [0,4,5,7,8,9,10,17] rootPS)) = affineNative (2^(14+1) ^^^ 3222) := by decide +kernel

theorem selectedBound29979 : packedSelected [0,4,5,7,8,9,10,17] rootPS < 2^1333 := by decide +kernel

def env29980 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,6283,1213,3222,3252,5125,3213,5,3223,4097,32,4264,5174,7174,5293,7357,5124,5124,2184,4116,1197,172,5141,1213,1540]

theorem envBound29980 : H12AffineFastState.Bounded env29980 := by
  intro p hp
  have h : env29980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29979_29980 : H12AffineEnvironment.transform 14 3222 env29979 = env29980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3222 env29979 == env29980) = true)

theorem identity29980 : scanCanonicalize (H12AffineFastState.compose env29980 (packedSelected [1,2,3,6,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 697) := by decide +kernel

theorem selectedBound29980 : packedSelected [1,2,3,6,10,11] rootPS < 2^1333 := by decide +kernel

def env29981 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,697,2610,1213,3222,3252,1724,3213,5,3223,696,32,529,1679,3775,1556,3588,1725,1725,2184,685,1197,172,1708,1213,1540]

theorem envBound29981 : H12AffineFastState.Bounded env29981 := by
  intro p hp
  have h : env29981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29980_29981 : H12AffineEnvironment.transform 11 697 env29980 = env29981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 697 env29980 == env29981) = true)

theorem identity29981 : scanCanonicalize (H12AffineFastState.compose env29981 (packedSelected [5,6,7,9,12] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound29981 : packedSelected [5,6,7,9,12] rootPS < 2^1333 := by decide +kernel

def env29982 : List Nat := [2,4,8,16,6,16,128,138,512,1024,2048,671,2580,1179,3222,3218,1690,3213,5,3223,670,6,529,1679,3737,1556,3588,1691,1691,2184,651,1163,138,1674,1179,1540]

theorem envBound29982 : H12AffineFastState.Bounded env29982 := by
  intro p hp
  have h : env29982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29981_29982 : H12AffineEnvironment.transform 4 6 env29981 = env29982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env29981 == env29982) = true)

theorem identity29982 : scanCanonicalize (H12AffineFastState.compose env29982 (packedSelected [0,4,5,10,15] rootPS)) = affineNative (2^(10+1) ^^^ 645) := by decide +kernel

theorem selectedBound29982 : packedSelected [0,4,5,10,15] rootPS < 2^1333 := by decide +kernel

def env29983 : List Nat := [2,4,8,16,6,16,128,138,512,1024,645,671,145,1179,1555,1559,1690,1544,5,1554,670,6,529,1679,1052,1556,1153,1691,1691,525,651,1163,138,1674,1179,1540]

theorem envBound29983 : H12AffineFastState.Bounded env29983 := by
  intro p hp
  have h : env29983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29982_29983 : H12AffineEnvironment.transform 10 645 env29982 = env29983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 645 env29982 == env29983) = true)

theorem identity29983 : scanCanonicalize (H12AffineFastState.compose env29983 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound29983 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env29984 : List Nat := [2,4,8,16,6,16,128,138,512,517,645,671,145,670,22,18,159,13,5,23,670,6,529,138,537,17,644,158,158,525,651,654,138,143,670,1]

theorem envBound29984 : H12AffineFastState.Bounded env29984 := by
  intro p hp
  have h : env29984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29983_29984 : H12AffineEnvironment.transform 9 517 env29983 = env29984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env29983 == env29984) = true)

theorem identity29984 : scanCanonicalize (H12AffineFastState.compose env29984 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(8+1) ^^^ 147) := by decide +kernel

theorem selectedBound29984 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env29985 : List Nat := [2,4,8,16,6,16,128,138,147,150,22,12,145,13,22,18,159,13,5,23,13,6,130,138,138,17,23,158,158,158,24,29,138,143,13,1]

theorem envBound29985 : H12AffineFastState.Bounded env29985 := by
  intro p hp
  have h : env29985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29984_29985 : H12AffineEnvironment.transform 8 147 env29984 = env29985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 147 env29984 == env29985) = true)

def env29986 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61569,147473,41003,143496,20496,492566,148669,148669,96267,74795,16400,172,131089,1212,135681]

theorem envBound29986 : H12AffineFastState.Bounded env29986 := by
  intro p hp
  have h : env29986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29973_29986 : H12AffineEnvironment.transform 5 17 env29973 = env29986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env29973 == env29986) = true)

theorem identity29986 : scanCanonicalize (H12AffineFastState.compose env29986 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 114723) := by decide +kernel

theorem selectedBound29986 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env29987 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,114723,262144,119843,32769,4097,61569,98354,41003,127147,20496,279605,99486,99486,96267,74795,16400,172,114738,1212,119330]

theorem envBound29987 : H12AffineFastState.Bounded env29987 := by
  intro p hp
  have h : env29987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29986_29987 : H12AffineEnvironment.transform 16 114723 env29986 = env29987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114723 env29986 == env29987) = true)

theorem identity29987 : scanCanonicalize (H12AffineFastState.compose env29987 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 47249) := by decide +kernel

theorem selectedBound29987 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env29988 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,114723,47249,119843,32769,4097,61569,98354,41003,127147,20496,64676,99486,99486,96267,74795,16400,172,114738,1212,119330]

theorem envBound29988 : H12AffineFastState.Bounded env29988 := by
  intro p hp
  have h : env29988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29987_29988 : H12AffineEnvironment.transform 17 47249 env29987 = env29988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 47249 env29987 == env29988) = true)

theorem identity29988 : scanCanonicalize (H12AffineFastState.compose env29988 (packedSelected [7,16,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound29988 : packedSelected [7,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env29989 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,53282,4097,47249,1025,32769,4097,61569,20496,41003,8329,20496,64676,21692,21692,43049,62473,16400,172,4112,1212,512]

theorem envBound29989 : H12AffineFastState.Bounded env29989 := by
  intro p hp
  have h : env29989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29988_29989 : H12AffineEnvironment.transform 15 53282 env29988 = env29989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env29988 == env29989) = true)

theorem identity29989 : scanCanonicalize (H12AffineFastState.compose env29989 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound29989 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env29990 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,5124,32768,33830,4097,47249,1025,32769,4097,42117,1044,41003,8329,1044,43168,184,184,43049,40973,5140,172,4112,1212,512]

theorem envBound29990 : H12AffineFastState.Bounded env29990 := by
  intro p hp
  have h : env29990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29989_29990 : H12AffineEnvironment.transform 13 5124 env29989 = env29990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env29989 == env29990) = true)

theorem identity29990 : scanCanonicalize (H12AffineFastState.compose env29990 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 5773) := by decide +kernel

theorem selectedBound29990 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env29991 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,5124,5773,4779,4097,11804,1025,5772,4097,12808,1044,13990,8329,1044,15917,184,184,16036,13952,5140,172,4112,1212,512]

theorem envBound29991 : H12AffineFastState.Bounded env29991 := by
  intro p hp
  have h : env29991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29990_29991 : H12AffineEnvironment.transform 14 5773 env29990 = env29991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5773 env29990 == env29991) = true)

theorem identity29991 : scanCanonicalize (H12AffineFastState.compose env29991 (packedSelected [0,3,4,8,13] rootPS)) = affineNative (2^(12+1) ^^^ 5175) := by decide +kernel

theorem selectedBound29991 : packedSelected [0,3,4,8,13] rootPS < 2^1333 := by decide +kernel

def env29992 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,5175,5124,5773,4779,4097,6699,1025,5772,4097,1599,1044,657,5310,1044,2586,184,184,2707,695,5140,172,4112,1212,512]

theorem envBound29992 : H12AffineFastState.Bounded env29992 := by
  intro p hp
  have h : env29992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29991_29992 : H12AffineEnvironment.transform 12 5175 env29991 = env29992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5175 env29991 == env29992) = true)

theorem identity29992 : scanCanonicalize (H12AffineFastState.compose env29992 (packedSelected [2,4,5,8,9,11,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 1213) := by decide +kernel

theorem selectedBound29992 : packedSelected [2,4,5,8,9,11,12,15] rootPS < 2^1333 := by decide +kernel

def env29993 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1213,4096,5175,5124,5773,4779,4097,5782,1025,5772,4097,1599,1044,657,5310,1044,1703,184,184,1582,695,5140,172,4112,1212,512]

theorem envBound29993 : H12AffineFastState.Bounded env29993 := by
  intro p hp
  have h : env29993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29992_29993 : H12AffineEnvironment.transform 10 1213 env29992 = env29993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1213 env29992 == env29993) = true)

theorem identity29993 : scanCanonicalize (H12AffineFastState.compose env29993 (packedSelected [0,3,4,5,7,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 1589) := by decide +kernel

theorem selectedBound29993 : packedSelected [0,3,4,5,7,9,11] rootPS < 2^1333 := by decide +kernel

def env29994 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1213,1589,514,561,184,1182,1588,163,1025,185,1588,1599,1044,657,651,1044,1703,184,184,1582,695,545,172,1573,1212,512]

theorem envBound29994 : H12AffineFastState.Bounded env29994 := by
  intro p hp
  have h : env29994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29993_29994 : H12AffineEnvironment.transform 11 1589 env29993 = env29994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1589 env29993 == env29994) = true)

theorem identity29994 : scanCanonicalize (H12AffineFastState.compose env29994 (packedSelected [0,3,5,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 140) := by decide +kernel

theorem selectedBound29994 : packedSelected [0,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env29995 : List Nat := [2,4,8,16,32,17,128,172,512,140,49,697,514,561,184,18,696,163,141,185,696,691,152,657,651,152,555,184,184,674,695,545,172,681,48,512]

theorem envBound29995 : H12AffineFastState.Bounded env29995 := by
  intro p hp
  have h : env29995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29994_29995 : H12AffineEnvironment.transform 9 140 env29994 = env29995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 140 env29994 == env29995) = true)

theorem identity29995 : scanCanonicalize (H12AffineFastState.compose env29995 (packedSelected [2,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound29995 : packedSelected [2,3,4] rootPS < 2^1333 := by decide +kernel

def env29996 : List Nat := [2,4,8,16,32,17,128,172,136,140,49,49,138,185,184,18,48,163,141,185,48,59,152,25,3,152,163,184,184,42,63,169,172,33,48,136]

theorem envBound29996 : H12AffineFastState.Bounded env29996 := by
  intro p hp
  have h : env29996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29995_29996 : H12AffineEnvironment.transform 8 136 env29995 = env29996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env29995 == env29996) = true)

theorem identity29996 : scanCanonicalize (H12AffineFastState.compose env29996 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound29996 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env29997 : List Nat := [2,4,8,16,32,17,9,37,1,5,49,49,3,48,49,18,48,42,4,48,48,59,17,25,3,17,42,49,49,42,63,32,37,33,48,1]

theorem envBound29997 : H12AffineFastState.Bounded env29997 := by
  intro p hp
  have h : env29997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29996_29997 : H12AffineEnvironment.transform 6 9 env29996 = env29997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29996 == env29997) = true)

theorem identity29997 : scanCanonicalize (H12AffineFastState.compose env29997 (packedSelected [0,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound29997 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env29998 : List Nat := [2,4,8,16,17,17,9,20,1,5,0,0,3,1,0,18,1,27,4,1,1,10,17,25,3,17,27,0,0,27,14,17,20,16,1,1]

theorem envBound29998 : H12AffineFastState.Bounded env29998 := by
  intro p hp
  have h : env29998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29997_29998 : H12AffineEnvironment.transform 4 17 env29997 = env29998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env29997 == env29998) = true)

theorem identity29998 : scanCanonicalize (H12AffineFastState.compose env29998 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound29998 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29999 : List Nat := [2,4,8,11,10,10,9,15,1,5,0,0,3,1,0,9,1,0,4,1,1,10,10,2,3,10,0,0,0,0,14,10,15,11,1,1]

theorem envBound29999 : H12AffineFastState.Bounded env29999 := by
  intro p hp
  have h : env29999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29998_29999 : H12AffineEnvironment.transform 3 11 env29998 = env29999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env29998 == env29999) = true)

theorem identity29999 : scanCanonicalize (H12AffineFastState.compose env29999 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound29999 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30000 : List Nat := [2,4,4,7,6,6,5,3,1,5,0,0,3,1,0,5,1,0,4,1,1,6,6,2,3,6,0,0,0,0,2,6,3,7,1,1]

theorem envBound30000 : H12AffineFastState.Bounded env30000 := by
  intro p hp
  have h : env30000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29999_30000 : H12AffineEnvironment.transform 2 4 env29999 = env30000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env29999 == env30000) = true)

def env30001 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147520,41003,143496,20496,492614,148717,148717,96346,74795,16400,173,131136,1260,135681]

theorem envBound30001 : H12AffineFastState.Bounded env30001 := by
  intro p hp
  have h : env30001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29972_30001 : H12AffineEnvironment.transform 7 173 env29972 = env30001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env29972 == env30001) = true)

def env30002 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61568,147472,41003,143496,20496,492566,148669,148669,96266,74795,16400,173,131088,1212,135681]

theorem envBound30002 : H12AffineFastState.Bounded env30002 := by
  intro p hp
  have h : env30002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30001_30002 : H12AffineEnvironment.transform 5 16 env30001 = env30002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env30001 == env30002) = true)

theorem identity30002 : scanCanonicalize (H12AffineFastState.compose env30002 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 137353) := by decide +kernel

theorem selectedBound30002 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env30003 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,137353,136192,32769,4097,61568,147472,41003,143496,20496,105631,148669,148669,96266,74795,16400,173,131088,1212,135681]

theorem envBound30003 : H12AffineFastState.Bounded env30003 := by
  intro p hp
  have h : env30003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30002_30003 : H12AffineEnvironment.transform 17 137353 env30002 = env30003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137353 env30002 == env30003) = true)

theorem identity30003 : scanCanonicalize (H12AffineFastState.compose env30003 (packedSelected [1,5,8,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 13374) := by decide +kernel

theorem selectedBound30003 : packedSelected [1,5,8,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env30004 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,13374,131072,137353,136192,32769,4097,61568,147472,41003,143496,20496,43169,148669,148669,19508,4117,16400,173,131088,1212,135681]

theorem envBound30004 : H12AffineFastState.Bounded env30004 := by
  intro p hp
  have h : env30004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30003_30004 : H12AffineEnvironment.transform 15 13374 env30003 = env30004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13374 env30003 == env30004) = true)

theorem identity30004 : scanCanonicalize (H12AffineFastState.compose env30004 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound30004 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env30005 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1212,32768,13374,131072,137353,136192,32769,4097,46140,132268,41003,143496,5292,43169,131073,131073,2184,4117,1196,173,131088,1212,135681]

theorem envBound30005 : H12AffineFastState.Bounded env30005 := by
  intro p hp
  have h : env30005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30004_30005 : H12AffineEnvironment.transform 13 1212 env30004 = env30005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env30004 == env30005) = true)

theorem identity30005 : scanCanonicalize (H12AffineFastState.compose env30005 (packedSelected [13,17] rootPS)) = affineNative (2^(14+1) ^^^ 9380) := by decide +kernel

theorem selectedBound30005 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env30006 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1212,9380,13374,131072,137353,136192,9381,4097,4248,132268,1167,143496,5292,3077,131073,131073,2184,4117,1196,173,131088,1212,135681]

theorem envBound30006 : H12AffineFastState.Bounded env30006 := by
  intro p hp
  have h : env30006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30005_30006 : H12AffineEnvironment.transform 14 9380 env30005 = env30006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9380 env30005 == env30006) = true)

theorem identity30006 : scanCanonicalize (H12AffineFastState.compose env30006 (packedSelected [6,12,13,15] rootPS)) = affineNative (2^(16+1) ^^^ 5124) := by decide +kernel

theorem selectedBound30006 : packedSelected [6,12,13,15] rootPS < 2^1333 := by decide +kernel

def env30007 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1212,9380,13374,5124,3213,4,9381,4097,4248,4264,1167,9356,5292,3077,5125,5125,2184,4117,1196,173,5140,1212,1541]

theorem envBound30007 : H12AffineFastState.Bounded env30007 := by
  intro p hp
  have h : env30007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30006_30007 : H12AffineEnvironment.transform 16 5124 env30006 = env30007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5124 env30006 == env30007) = true)

theorem identity30007 : scanCanonicalize (H12AffineFastState.compose env30007 (packedSelected [2,3,6,7,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 3223) := by decide +kernel

theorem selectedBound30007 : packedSelected [2,3,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env30008 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,3223,8192,1212,9380,10409,2195,3213,4,9381,3222,3087,3135,1167,9356,2107,3077,2194,2194,2184,3202,1196,173,2179,1212,1541]

theorem envBound30008 : H12AffineFastState.Bounded env30008 := by
  intro p hp
  have h : env30008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30007_30008 : H12AffineEnvironment.transform 11 3223 env30007 = env30008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3223 env30007 == env30008) = true)

theorem identity30008 : scanCanonicalize (H12AffineFastState.compose env30008 (packedSelected [2,3,4,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 1055) := by decide +kernel

theorem selectedBound30008 : packedSelected [2,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env30009 : List Nat := [2,4,8,16,32,16,128,173,512,1024,1055,136,8192,1212,9380,9398,1164,146,4,9381,137,16,32,1167,9356,1060,26,1165,1165,1175,157,1196,173,1180,1212,1541]

theorem envBound30009 : H12AffineFastState.Bounded env30009 := by
  intro p hp
  have h : env30009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30008_30009 : H12AffineEnvironment.transform 10 1055 env30008 = env30009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1055 env30008 == env30009) = true)

theorem identity30009 : scanCanonicalize (H12AffineFastState.compose env30009 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound30009 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env30010 : List Nat := [2,4,8,16,32,16,128,173,512,1024,1055,136,41,1212,1165,1183,1164,146,4,1164,137,16,32,1167,1189,1060,26,1165,1165,1175,157,1196,173,1180,1212,1541]

theorem envBound30010 : H12AffineFastState.Bounded env30010 := by
  intro p hp
  have h : env30010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30009_30010 : H12AffineEnvironment.transform 12 41 env30009 = env30010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env30009 == env30010) = true)

theorem identity30010 : scanCanonicalize (H12AffineFastState.compose env30010 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound30010 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env30011 : List Nat := [2,4,8,16,32,16,128,173,43,1024,1055,136,41,1212,1165,1183,1164,146,4,1164,137,16,32,1167,1189,1060,26,1165,1165,1175,157,1196,173,1180,1212,1070]

theorem envBound30011 : H12AffineFastState.Bounded env30011 := by
  intro p hp
  have h : env30011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30010_30011 : H12AffineEnvironment.transform 8 43 env30010 = env30011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env30010 == env30011) = true)

theorem identity30011 : scanCanonicalize (H12AffineFastState.compose env30011 (packedSelected [1,3,6] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound30011 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env30012 : List Nat := [2,4,8,16,32,16,34,15,43,1024,1055,42,41,1054,1071,1085,1070,48,4,1070,43,16,32,1069,1031,1060,26,1071,1071,1077,63,1038,15,1086,1054,1070]

theorem envBound30012 : H12AffineFastState.Bounded env30012 := by
  intro p hp
  have h : env30012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30011_30012 : H12AffineEnvironment.transform 6 34 env30011 = env30012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env30011 == env30012) = true)

theorem identity30012 : scanCanonicalize (H12AffineFastState.compose env30012 (packedSelected [2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound30012 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env30013 : List Nat := [2,4,8,16,10,16,8,15,1,1024,1055,0,3,1054,1029,1047,1028,26,4,1028,1,16,10,1031,1031,1038,26,1029,1029,1055,21,1038,15,1044,1054,1028]

theorem envBound30013 : H12AffineFastState.Bounded env30013 := by
  intro p hp
  have h : env30013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30012_30013 : H12AffineEnvironment.transform 4 10 env30012 = env30013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env30012 == env30013) = true)

theorem identity30013 : scanCanonicalize (H12AffineFastState.compose env30013 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 30) := by decide +kernel

theorem selectedBound30013 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env30014 : List Nat := [2,4,8,16,10,16,8,15,1,30,1,0,3,0,27,9,26,26,4,26,1,16,10,25,25,16,26,27,27,1,21,16,15,10,0,26]

theorem envBound30014 : H12AffineFastState.Bounded env30014 := by
  intro p hp
  have h : env30014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30013_30014 : H12AffineEnvironment.transform 9 30 env30013 = env30014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 30 env30013 == env30014) = true)

def env30015 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61569,147473,41003,143496,20496,492567,148668,148668,96267,74795,16400,173,131089,1213,135681]

theorem envBound30015 : H12AffineFastState.Bounded env30015 := by
  intro p hp
  have h : env30015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30001_30015 : H12AffineEnvironment.transform 5 17 env30001 = env30015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30001 == env30015) = true)

theorem identity30015 : scanCanonicalize (H12AffineFastState.compose env30015 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound30015 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env30016 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,45217,262144,42145,32769,4097,61569,61616,41003,32809,20496,341174,62493,62493,96267,74795,16400,173,45232,1213,41632]

theorem envBound30016 : H12AffineFastState.Bounded env30016 := by
  intro p hp
  have h : env30016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30015_30016 : H12AffineEnvironment.transform 16 45217 env30015 = env30016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env30015 == env30016) = true)

theorem identity30016 : scanCanonicalize (H12AffineFastState.compose env30016 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound30016 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env30017 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1212,32768,65536,45217,262144,42145,32769,4097,46141,46092,41003,32809,5292,341174,45217,45217,81079,74795,1196,173,45232,1213,41632]

theorem envBound30017 : H12AffineFastState.Bounded env30017 := by
  intro p hp
  have h : env30017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30016_30017 : H12AffineEnvironment.transform 13 1212 env30016 = env30017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env30016 == env30017) = true)

theorem identity30017 : scanCanonicalize (H12AffineFastState.compose env30017 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 9350) := by decide +kernel

theorem selectedBound30017 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env30018 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1212,32768,9350,45217,262144,42145,32769,4097,46141,46092,41003,32809,5292,266288,45217,45217,6193,173,1196,173,45232,1213,41632]

theorem envBound30018 : H12AffineFastState.Bounded env30018 := by
  intro p hp
  have h : env30018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30017_30018 : H12AffineEnvironment.transform 15 9350 env30017 = env30018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9350 env30017 == env30018) = true)

theorem identity30018 : scanCanonicalize (H12AffineFastState.compose env30018 (packedSelected [4,9,20] rootPS)) = affineNative (2^(14+1) ^^^ 12312) := by decide +kernel

theorem selectedBound30018 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env30019 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1212,12312,9350,185,262144,5305,12313,4097,1061,1044,4147,12337,5292,266288,185,185,6193,173,1196,173,168,1213,4792]

theorem envBound30019 : H12AffineFastState.Bounded env30019 := by
  intro p hp
  have h : env30019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30018_30019 : H12AffineEnvironment.transform 14 12312 env30018 = env30019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12312 env30018 == env30019) = true)

theorem identity30019 : scanCanonicalize (H12AffineFastState.compose env30019 (packedSelected [1,3,6,10,12,13,17] rootPS)) = affineNative (2^(12+1) ^^^ 7311) := by decide +kernel

theorem selectedBound30019 : packedSelected [1,3,6,10,12,13,17] rootPS < 2^1333 := by decide +kernel

def env30020 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,7311,1212,3223,6153,185,262144,5305,3222,4097,1061,1044,4147,3262,5292,266288,185,185,6193,173,1196,173,168,1213,4792]

theorem envBound30020 : H12AffineFastState.Bounded env30020 := by
  intro p hp
  have h : env30020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30019_30020 : H12AffineEnvironment.transform 12 7311 env30019 = env30020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7311 env30019 == env30020) = true)

theorem identity30020 : scanCanonicalize (H12AffineFastState.compose env30020 (packedSelected [2,6,11,18] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound30020 : packedSelected [2,6,11,18] rootPS < 2^1333 := by decide +kernel

def env30021 : List Nat := [2,4,8,16,32,17,128,173,137,1024,2048,4096,7311,1212,3223,6153,185,262144,5305,3222,4097,1061,1044,4147,3262,5292,266288,185,185,6193,173,1196,173,168,1213,4145]

theorem envBound30021 : H12AffineFastState.Bounded env30021 := by
  intro p hp
  have h : env30021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30020_30021 : H12AffineEnvironment.transform 8 137 env30020 = env30021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env30020 == env30021) = true)

theorem identity30021 : scanCanonicalize (H12AffineFastState.compose env30021 (packedSelected [10,12,13] rootPS)) = affineNative (2^(17+1) ^^^ 4122) := by decide +kernel

theorem selectedBound30021 : packedSelected [10,12,13] rootPS < 2^1333 := by decide +kernel

def env30022 : List Nat := [2,4,8,16,32,17,128,173,137,1024,2048,4096,7311,1212,3223,6153,185,4122,5305,3222,4097,1061,1044,4147,3262,5292,42,185,185,6193,173,1196,173,168,1213,4145]

theorem envBound30022 : H12AffineFastState.Bounded env30022 := by
  intro p hp
  have h : env30022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30021_30022 : H12AffineEnvironment.transform 17 4122 env30021 = env30022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4122 env30021 == env30022) = true)

theorem identity30022 : scanCanonicalize (H12AffineFastState.compose env30022 (packedSelected [0,3,4,5,6,7,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 2194) := by decide +kernel

theorem selectedBound30022 : packedSelected [0,3,4,5,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env30023 : List Nat := [2,4,8,16,32,17,128,173,137,1024,2048,2194,1053,1212,3223,155,185,2184,3115,3222,2195,1061,1044,2209,3262,3134,42,185,185,163,173,1196,173,168,1213,2211]

theorem envBound30023 : H12AffineFastState.Bounded env30023 := by
  intro p hp
  have h : env30023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30022_30023 : H12AffineEnvironment.transform 11 2194 env30022 = env30023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2194 env30022 == env30023) = true)

theorem identity30023 : scanCanonicalize (H12AffineFastState.compose env30023 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound30023 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env30024 : List Nat := [2,4,8,16,16,17,128,157,137,1024,2048,2194,1053,1164,3223,155,137,2184,3099,3222,2195,1045,1044,2193,3214,3086,26,137,137,147,157,1180,157,152,1165,2195]

theorem envBound30024 : H12AffineFastState.Bounded env30024 := by
  intro p hp
  have h : env30024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30023_30024 : H12AffineEnvironment.transform 4 16 env30023 = env30024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env30023 == env30024) = true)

theorem identity30024 : scanCanonicalize (H12AffineFastState.compose env30024 (packedSelected [1,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 30) := by decide +kernel

theorem selectedBound30024 : packedSelected [1,5,6] rootPS < 2^1333 := by decide +kernel

def env30025 : List Nat := [2,4,8,16,16,17,128,157,137,30,2048,2194,3,146,2185,155,137,2184,2053,2184,2195,11,10,2193,2192,2064,26,137,137,147,157,130,157,152,147,2195]

theorem envBound30025 : H12AffineFastState.Bounded env30025 := by
  intro p hp
  have h : env30025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30024_30025 : H12AffineEnvironment.transform 9 30 env30024 = env30025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 30 env30024 == env30025) = true)

theorem identity30025 : scanCanonicalize (H12AffineFastState.compose env30025 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound30025 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env30026 : List Nat := [2,4,8,16,16,17,128,157,137,30,137,27,3,146,0,155,137,1,140,1,26,11,10,24,25,153,26,137,137,147,157,130,157,152,147,26]

theorem envBound30026 : H12AffineFastState.Bounded env30026 := by
  intro p hp
  have h : env30026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30025_30026 : H12AffineEnvironment.transform 10 137 env30025 = env30026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env30025 == env30026) = true)

theorem identity30026 : scanCanonicalize (H12AffineFastState.compose env30026 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound30026 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30027 : List Nat := [2,4,5,16,16,17,128,144,132,19,132,22,3,146,0,150,132,1,129,1,23,6,7,21,20,148,23,132,132,147,144,130,144,149,147,23]

theorem envBound30027 : H12AffineFastState.Bounded env30027 := by
  intro p hp
  have h : env30027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30026_30027 : H12AffineEnvironment.transform 2 5 env30026 = env30027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env30026 == env30027) = true)

theorem identity30027 : scanCanonicalize (H12AffineFastState.compose env30027 (packedSelected [8] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound30027 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env30028 : List Nat := [2,4,5,16,16,17,18,2,22,19,22,22,3,0,0,4,22,1,19,1,23,6,7,21,20,6,23,22,22,1,2,16,2,7,1,23]

theorem envBound30028 : H12AffineFastState.Bounded env30028 := by
  intro p hp
  have h : env30028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30027_30028 : H12AffineEnvironment.transform 6 18 env30027 = env30028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env30027 == env30028) = true)

theorem identity30028 : scanCanonicalize (H12AffineFastState.compose env30028 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound30028 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30029 : List Nat := [2,4,5,2,2,3,0,2,4,1,4,4,3,0,0,4,4,1,1,1,5,6,7,7,6,6,5,4,4,1,2,2,2,7,1,5]

theorem envBound30029 : H12AffineFastState.Bounded env30029 := by
  intro p hp
  have h : env30029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30028_30029 : H12AffineEnvironment.transform 3 2 env30028 = env30029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env30028 == env30029) = true)

def env30030 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147520,41003,143497,20497,493035,148800,148801,96346,74795,16401,256,131136,1345,135680]

theorem envBound30030 : H12AffineFastState.Bounded env30030 := by
  intro p hp
  have h : env30030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29971_30030 : H12AffineEnvironment.transform 18 136193 env29971 = env30030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env29971 == env30030) = true)

def env30031 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147520,41003,143497,20497,492615,148716,148717,96346,74795,16401,172,131136,1261,135680]

theorem envBound30031 : H12AffineFastState.Bounded env30031 := by
  intro p hp
  have h : env30031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30030_30031 : H12AffineEnvironment.transform 7 172 env30030 = env30031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env30030 == env30031) = true)

def env30032 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61568,147472,41003,143497,20497,492567,148668,148669,96266,74795,16401,172,131088,1213,135680]

theorem envBound30032 : H12AffineFastState.Bounded env30032 := by
  intro p hp
  have h : env30032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30031_30032 : H12AffineEnvironment.transform 5 16 env30031 = env30032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env30031 == env30032) = true)

theorem identity30032 : scanCanonicalize (H12AffineFastState.compose env30032 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 114723) := by decide +kernel

theorem selectedBound30032 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env30033 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,114723,262144,119842,32769,4097,61568,98355,41003,127146,20497,279604,99487,99486,96266,74795,16401,172,114739,1213,119331]

theorem envBound30033 : H12AffineFastState.Bounded env30033 := by
  intro p hp
  have h : env30033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30032_30033 : H12AffineEnvironment.transform 16 114723 env30032 = env30033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114723 env30032 == env30033) = true)

theorem identity30033 : scanCanonicalize (H12AffineFastState.compose env30033 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 47248) := by decide +kernel

theorem selectedBound30033 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env30034 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,114723,47248,119842,32769,4097,61568,98355,41003,127146,20497,64676,99487,99486,96266,74795,16401,172,114739,1213,119331]

theorem envBound30034 : H12AffineFastState.Bounded env30034 := by
  intro p hp
  have h : env30034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30033_30034 : H12AffineEnvironment.transform 17 47248 env30033 = env30034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 47248 env30033 == env30034) = true)

theorem identity30034 : scanCanonicalize (H12AffineFastState.compose env30034 (packedSelected [7,16,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound30034 : packedSelected [7,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env30035 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,53283,4096,47248,1025,32769,4097,61568,20496,41003,8329,20497,64676,21692,21693,43049,62472,16401,172,4112,1213,512]

theorem envBound30035 : H12AffineFastState.Bounded env30035 := by
  intro p hp
  have h : env30035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30034_30035 : H12AffineEnvironment.transform 15 53283 env30034 = env30035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env30034 == env30035) = true)

theorem identity30035 : scanCanonicalize (H12AffineFastState.compose env30035 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound30035 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env30036 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,5124,32768,33831,4096,47248,1025,32769,4097,42116,1044,41003,8329,1045,43168,184,185,43049,40972,5141,172,4112,1213,512]

theorem envBound30036 : H12AffineFastState.Bounded env30036 := by
  intro p hp
  have h : env30036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30035_30036 : H12AffineEnvironment.transform 13 5124 env30035 = env30036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env30035 == env30036) = true)

theorem identity30036 : scanCanonicalize (H12AffineFastState.compose env30036 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 5676) := by decide +kernel

theorem selectedBound30036 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env30037 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,5676,5124,32768,33831,4096,36540,1025,32769,4097,37544,1044,38407,5797,1045,40588,184,185,40453,38432,5141,172,4112,1213,512]

theorem envBound30037 : H12AffineFastState.Bounded env30037 := by
  intro p hp
  have h : env30037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30036_30037 : H12AffineEnvironment.transform 12 5676 env30036 = env30037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5676 env30036 == env30037) = true)

theorem identity30037 : scanCanonicalize (H12AffineFastState.compose env30037 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(14+1) ^^^ 5271) := by decide +kernel

theorem selectedBound30037 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env30038 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,5676,5124,5271,4272,4096,6699,1025,5270,4097,1599,1044,656,5797,1045,2587,184,185,2706,695,5141,172,4112,1213,512]

theorem envBound30038 : H12AffineFastState.Bounded env30038 := by
  intro p hp
  have h : env30038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30037_30038 : H12AffineEnvironment.transform 14 5271 env30037 = env30038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5271 env30037 == env30038) = true)

def env30039 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61569,147473,41003,143497,20497,492566,148669,148668,96267,74795,16401,172,131089,1212,135680]

theorem envBound30039 : H12AffineFastState.Bounded env30039 := by
  intro p hp
  have h : env30039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30031_30039 : H12AffineEnvironment.transform 5 17 env30031 = env30039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30031 == env30039) = true)

theorem identity30039 : scanCanonicalize (H12AffineFastState.compose env30039 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 223242) := by decide +kernel

theorem selectedBound30039 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env30040 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,223242,136193,32769,4097,61569,147473,41003,143497,20497,60444,148669,148668,96267,74795,16401,172,131089,1212,135680]

theorem envBound30040 : H12AffineFastState.Bounded env30040 := by
  intro p hp
  have h : env30040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30039_30040 : H12AffineEnvironment.transform 17 223242 env30039 = env30040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223242 env30039 == env30040) = true)

theorem identity30040 : scanCanonicalize (H12AffineFastState.compose env30040 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 28803) := by decide +kernel

theorem selectedBound30040 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env30041 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,28803,131072,137353,136193,32769,4097,61569,147473,41003,143497,20497,60444,148669,148668,2184,21672,16401,172,131089,1212,135680]

theorem envBound30041 : H12AffineFastState.Bounded env30041 := by
  intro p hp
  have h : env30041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30040_30041 : H12AffineEnvironment.transform 15 28803 env30040 = env30041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28803 env30040 == env30041) = true)

theorem identity30041 : scanCanonicalize (H12AffineFastState.compose env30041 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(16+1) ^^^ 40984) := by decide +kernel

theorem selectedBound30041 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env30042 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,28803,40984,47249,46105,32769,4097,61569,57353,41003,37009,20497,60444,58533,58532,2184,21672,16401,172,40969,1212,45592]

theorem envBound30042 : H12AffineFastState.Bounded env30042 := by
  intro p hp
  have h : env30042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30041_30042 : H12AffineEnvironment.transform 16 40984 env30041 = env30042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 40984 env30041 == env30042) = true)

theorem identity30042 : scanCanonicalize (H12AffineFastState.compose env30042 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound30042 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env30043 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1212,32768,13375,40984,47249,46105,32769,4097,46141,42165,41003,37009,5293,43168,40985,40984,2184,4116,1197,172,40969,1212,45592]

theorem envBound30043 : H12AffineFastState.Bounded env30043 := by
  intro p hp
  have h : env30043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30042_30043 : H12AffineEnvironment.transform 13 1212 env30042 = env30043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env30042 == env30043) = true)

theorem identity30043 : scanCanonicalize (H12AffineFastState.compose env30043 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(14+1) ^^^ 6187) := by decide +kernel

theorem selectedBound30043 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env30044 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1212,6187,13375,14387,8378,11314,6186,4097,11286,15518,14336,2234,5293,12427,14386,14387,2184,4116,1197,172,14370,1212,10803]

theorem envBound30044 : H12AffineFastState.Bounded env30044 := by
  intro p hp
  have h : env30044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30043_30044 : H12AffineEnvironment.transform 14 6187 env30043 = env30044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 6187 env30043 == env30044) = true)

theorem identity30044 : scanCanonicalize (H12AffineFastState.compose env30044 (packedSelected [0,4,5,7,8,9,10,17] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound30044 : packedSelected [0,4,5,7,8,9,10,17] rootPS < 2^1333 := by decide +kernel

def env30045 : List Nat := [2,4,8,16,32,17,128,172,512,4,2048,4096,8192,184,6187,12347,14387,8378,10294,6186,4097,10258,14490,14336,2234,4265,12427,14386,14387,2184,4116,169,172,14370,184,10803]

theorem envBound30045 : H12AffineFastState.Bounded env30045 := by
  intro p hp
  have h : env30045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30044_30045 : H12AffineEnvironment.transform 9 4 env30044 = env30045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env30044 == env30045) = true)

theorem identity30045 : scanCanonicalize (H12AffineFastState.compose env30045 (packedSelected [0,1,2,3,4,5,7,8,9,11,12,15] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound30045 : packedSelected [0,1,2,3,4,5,7,8,9,11,12,15] rootPS < 2^1333 := by decide +kernel

def env30046 : List Nat := [2,4,8,16,32,17,128,172,1,4,2048,4096,8192,184,6187,12347,14387,8378,10294,6186,4097,10258,14490,14336,2234,4265,12427,14386,14387,2184,4116,169,172,14370,184,10290]

theorem envBound30046 : H12AffineFastState.Bounded env30046 := by
  intro p hp
  have h : env30046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30045_30046 : H12AffineEnvironment.transform 8 1 env30045 = env30046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env30045 == env30046) = true)

theorem identity30046 : scanCanonicalize (H12AffineFastState.compose env30046 (packedSelected [1,2,3,5,6,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 163) := by decide +kernel

theorem selectedBound30046 : packedSelected [1,2,3,5,6,8,10,11] rootPS < 2^1333 := by decide +kernel

def env30047 : List Nat := [2,4,8,16,32,17,128,172,1,4,163,4096,8192,184,4232,12347,12432,8378,8341,4233,4097,8369,12345,12451,25,4265,12427,12433,12432,43,4116,169,172,12417,184,8337]

theorem envBound30047 : H12AffineFastState.Bounded env30047 := by
  intro p hp
  have h : env30047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30046_30047 : H12AffineEnvironment.transform 10 163 env30046 = env30047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 163 env30046 == env30047) = true)

theorem identity30047 : scanCanonicalize (H12AffineFastState.compose env30047 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(11+1) ^^^ 42) := by decide +kernel

theorem selectedBound30047 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env30048 : List Nat := [2,4,8,16,32,17,128,172,1,4,163,42,8192,184,162,8209,8378,8378,8341,163,43,8369,8211,8329,25,131,8353,8379,8378,43,62,169,172,8363,184,8337]

theorem envBound30048 : H12AffineFastState.Bounded env30048 := by
  intro p hp
  have h : env30048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30047_30048 : H12AffineEnvironment.transform 11 42 env30047 = env30048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 42 env30047 == env30048) = true)

theorem identity30048 : scanCanonicalize (H12AffineFastState.compose env30048 (packedSelected [1,8] rootPS)) = affineNative (2^(12+1) ^^^ 144) := by decide +kernel

theorem selectedBound30048 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env30049 : List Nat := [2,4,8,16,32,17,128,172,1,4,163,42,144,184,162,129,42,42,5,163,43,33,131,25,25,131,49,43,42,43,62,169,172,59,184,1]

theorem envBound30049 : H12AffineFastState.Bounded env30049 := by
  intro p hp
  have h : env30049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30048_30049 : H12AffineEnvironment.transform 12 144 env30048 = env30049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 144 env30048 == env30049) = true)

theorem identity30049 : scanCanonicalize (H12AffineFastState.compose env30049 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound30049 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30050 : List Nat := [2,4,5,16,32,17,128,161,1,4,163,39,144,181,162,129,39,39,5,163,38,33,131,20,20,131,49,38,39,38,51,164,161,54,181,1]

theorem envBound30050 : H12AffineFastState.Bounded env30050 := by
  intro p hp
  have h : env30050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30049_30050 : H12AffineEnvironment.transform 2 5 env30049 = env30050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env30049 == env30050) = true)

theorem identity30050 : scanCanonicalize (H12AffineFastState.compose env30050 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound30050 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env30051 : List Nat := [2,4,5,16,32,17,19,50,1,4,48,39,3,38,49,18,39,39,5,48,38,33,16,20,20,16,49,38,39,38,51,55,50,54,38,1]

theorem envBound30051 : H12AffineFastState.Bounded env30051 := by
  intro p hp
  have h : env30051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30050_30051 : H12AffineEnvironment.transform 6 19 env30050 = env30051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env30050 == env30051) = true)

theorem identity30051 : scanCanonicalize (H12AffineFastState.compose env30051 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound30051 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30052 : List Nat := [2,4,5,6,32,7,5,36,1,4,38,39,3,38,39,4,39,39,5,38,38,33,6,2,2,6,39,38,39,38,37,33,36,32,38,1]

theorem envBound30052 : H12AffineFastState.Bounded env30052 := by
  intro p hp
  have h : env30052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30051_30052 : H12AffineEnvironment.transform 3 6 env30051 = env30052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env30051 == env30052) = true)

theorem identity30052 : scanCanonicalize (H12AffineFastState.compose env30052 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound30052 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30053 : List Nat := [2,4,5,6,6,7,5,2,1,4,0,1,3,0,1,4,1,1,5,0,0,7,6,2,2,6,1,0,1,0,3,7,2,6,0,1]

theorem envBound30053 : H12AffineFastState.Bounded env30053 := by
  intro p hp
  have h : env30053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30052_30053 : H12AffineEnvironment.transform 4 6 env30052 = env30053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env30052 == env30053) = true)

def env30054 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147520,41003,143497,20497,492614,148717,148716,96346,74795,16401,173,131136,1260,135680]

theorem envBound30054 : H12AffineFastState.Bounded env30054 := by
  intro p hp
  have h : env30054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30030_30054 : H12AffineEnvironment.transform 7 173 env30030 = env30054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env30030 == env30054) = true)

def env30055 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61568,147472,41003,143497,20497,492566,148669,148668,96266,74795,16401,173,131088,1212,135680]

theorem envBound30055 : H12AffineFastState.Bounded env30055 := by
  intro p hp
  have h : env30055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30054_30055 : H12AffineEnvironment.transform 5 16 env30054 = env30055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env30054 == env30055) = true)

theorem identity30055 : scanCanonicalize (H12AffineFastState.compose env30055 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound30055 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env30056 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,45216,262144,42145,32769,4097,61568,61616,41003,32809,20497,341174,62493,62492,96266,74795,16401,173,45232,1212,41632]

theorem envBound30056 : H12AffineFastState.Bounded env30056 := by
  intro p hp
  have h : env30056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30055_30056 : H12AffineEnvironment.transform 16 45216 env30055 = env30056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env30055 == env30056) = true)

theorem identity30056 : scanCanonicalize (H12AffineFastState.compose env30056 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound30056 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env30057 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1213,32768,65536,45216,262144,42145,32769,4097,46141,46093,41003,32809,5292,341174,45216,45217,81079,74795,1196,173,45232,1212,41632]

theorem envBound30057 : H12AffineFastState.Bounded env30057 := by
  intro p hp
  have h : env30057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30056_30057 : H12AffineEnvironment.transform 13 1213 env30056 = env30057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env30056 == env30057) = true)

theorem identity30057 : scanCanonicalize (H12AffineFastState.compose env30057 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 9351) := by decide +kernel

theorem selectedBound30057 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env30058 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1213,32768,9351,45216,262144,42145,32769,4097,46141,46093,41003,32809,5292,266289,45216,45217,6192,172,1196,173,45232,1212,41632]

theorem envBound30058 : H12AffineFastState.Bounded env30058 := by
  intro p hp
  have h : env30058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30057_30058 : H12AffineEnvironment.transform 15 9351 env30057 = env30058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9351 env30057 == env30058) = true)

theorem identity30058 : scanCanonicalize (H12AffineFastState.compose env30058 (packedSelected [4,9,20] rootPS)) = affineNative (2^(14+1) ^^^ 12313) := by decide +kernel

theorem selectedBound30058 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env30059 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1213,12313,9351,185,262144,5304,12312,4097,1060,1044,4146,12336,5292,266289,185,184,6192,172,1196,173,169,1212,4793]

theorem envBound30059 : H12AffineFastState.Bounded env30059 := by
  intro p hp
  have h : env30059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30058_30059 : H12AffineEnvironment.transform 14 12313 env30058 = env30059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12313 env30058 == env30059) = true)

theorem identity30059 : scanCanonicalize (H12AffineFastState.compose env30059 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound30059 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env30060 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,185,8192,1213,8352,9351,185,262144,1025,8353,184,1060,1044,139,8329,1045,262280,185,184,2185,172,1196,173,169,1212,512]

theorem envBound30060 : H12AffineFastState.Bounded env30060 := by
  intro p hp
  have h : env30060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30059_30060 : H12AffineEnvironment.transform 11 185 env30059 = env30060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env30059 == env30060) = true)

theorem identity30060 : scanCanonicalize (H12AffineFastState.compose env30060 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2601) := by decide +kernel

theorem selectedBound30060 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30061 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,185,2601,1213,2697,3758,185,262144,1025,2696,184,1060,1044,139,2720,1045,262280,185,184,2185,172,1196,173,169,1212,512]

theorem envBound30061 : H12AffineFastState.Bounded env30061 := by
  intro p hp
  have h : env30061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30060_30061 : H12AffineEnvironment.transform 12 2601 env30060 = env30061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2601 env30060 == env30061) = true)

theorem identity30061 : scanCanonicalize (H12AffineFastState.compose env30061 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 2706) := by decide +kernel

theorem selectedBound30061 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env30062 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,185,2601,1213,2697,3758,185,2706,1025,2696,184,1060,1044,139,2720,1045,2586,185,184,2185,172,1196,173,169,1212,512]

theorem envBound30062 : H12AffineFastState.Bounded env30062 := by
  intro p hp
  have h : env30062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30061_30062 : H12AffineEnvironment.transform 17 2706 env30061 = env30062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2706 env30061 == env30062) = true)

theorem identity30062 : scanCanonicalize (H12AffineFastState.compose env30062 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1213) := by decide +kernel

theorem selectedBound30062 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env30063 : List Nat := [2,4,8,16,32,16,128,173,512,1024,1213,185,1684,1213,1588,531,185,1583,1025,1589,184,1060,1044,139,1565,1045,1703,185,184,1076,172,1196,173,169,1212,512]

theorem envBound30063 : H12AffineFastState.Bounded env30063 := by
  intro p hp
  have h : env30063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30062_30063 : H12AffineEnvironment.transform 10 1213 env30062 = env30063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1213 env30062 == env30063) = true)

theorem identity30063 : scanCanonicalize (H12AffineFastState.compose env30063 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound30063 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env30064 : List Nat := [2,4,8,11,32,11,128,173,512,1024,1190,162,1679,1190,1583,520,162,1583,1025,1582,163,1060,1039,139,1542,1038,1703,162,163,1071,172,1196,173,169,1191,512]

theorem envBound30064 : H12AffineFastState.Bounded env30064 := by
  intro p hp
  have h : env30064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30063_30064 : H12AffineEnvironment.transform 3 11 env30063 = env30064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env30063 == env30064) = true)

theorem identity30064 : scanCanonicalize (H12AffineFastState.compose env30064 (packedSelected [0,1,4,7] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound30064 : packedSelected [0,1,4,7] rootPS < 2^1333 := by decide +kernel

def env30065 : List Nat := [2,4,8,11,32,11,128,173,1,1024,1190,162,1166,1190,1070,9,162,1070,1025,1071,163,1060,1039,139,1031,1038,1190,162,163,1071,172,1196,173,169,1191,1]

theorem envBound30065 : H12AffineFastState.Bounded env30065 := by
  intro p hp
  have h : env30065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30064_30065 : H12AffineEnvironment.transform 8 1 env30064 = env30065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env30064 == env30065) = true)

theorem identity30065 : scanCanonicalize (H12AffineFastState.compose env30065 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound30065 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env30066 : List Nat := [2,4,8,11,10,11,128,135,1,1024,1164,136,1166,1164,1028,9,136,1028,1025,1029,137,1038,1039,139,1031,1038,1164,136,137,1029,134,1158,135,131,1165,1]

theorem envBound30066 : H12AffineFastState.Bounded env30066 := by
  intro p hp
  have h : env30066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30065_30066 : H12AffineEnvironment.transform 4 10 env30065 = env30066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env30065 == env30066) = true)

theorem identity30066 : scanCanonicalize (H12AffineFastState.compose env30066 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 9) := by decide +kernel

theorem selectedBound30066 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30067 : List Nat := [2,4,8,11,10,11,128,135,1,9,133,136,135,133,13,9,136,13,8,12,137,7,6,139,14,7,133,136,137,12,134,143,135,131,132,1]

theorem envBound30067 : H12AffineFastState.Bounded env30067 := by
  intro p hp
  have h : env30067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30066_30067 : H12AffineEnvironment.transform 9 9 env30066 = env30067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 9 env30066 == env30067) = true)

theorem identity30067 : scanCanonicalize (H12AffineFastState.compose env30067 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound30067 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env30068 : List Nat := [2,4,8,11,10,11,5,2,1,9,0,13,2,0,13,9,13,13,8,12,12,7,6,14,14,7,0,13,12,12,3,10,2,6,1,1]

theorem envBound30068 : H12AffineFastState.Bounded env30068 := by
  intro p hp
  have h : env30068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30067_30068 : H12AffineEnvironment.transform 6 5 env30067 = env30068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env30067 == env30068) = true)

theorem identity30068 : scanCanonicalize (H12AffineFastState.compose env30068 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound30068 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env30069 : List Nat := [2,4,5,6,7,6,5,2,1,4,0,0,2,0,0,4,0,0,5,1,1,7,6,3,3,7,0,0,1,1,3,7,2,6,1,1]

theorem envBound30069 : H12AffineFastState.Bounded env30069 := by
  intro p hp
  have h : env30069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30068_30069 : H12AffineEnvironment.transform 2 5 env30068 = env30069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env30068 == env30069) = true)

def env30070 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61569,147473,41003,143497,20497,492567,148668,148669,96267,74795,16401,173,131089,1213,135680]

theorem envBound30070 : H12AffineFastState.Bounded env30070 := by
  intro p hp
  have h : env30070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30054_30070 : H12AffineEnvironment.transform 5 17 env30054 = env30070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30054 == env30070) = true)

theorem identity30070 : scanCanonicalize (H12AffineFastState.compose env30070 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 137352) := by decide +kernel

theorem selectedBound30070 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env30071 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,137352,136193,32769,4097,61569,147473,41003,143497,20497,105631,148668,148669,96267,74795,16401,173,131089,1213,135680]

theorem envBound30071 : H12AffineFastState.Bounded env30071 := by
  intro p hp
  have h : env30071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30070_30071 : H12AffineEnvironment.transform 17 137352 env30070 = env30071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137352 env30070 == env30071) = true)

theorem identity30071 : scanCanonicalize (H12AffineFastState.compose env30071 (packedSelected [1,5,8,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 13374) := by decide +kernel

theorem selectedBound30071 : packedSelected [1,5,8,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env30072 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,13374,131072,137352,136193,32769,4097,61569,147473,41003,143497,20497,43169,148668,148669,19509,4117,16401,173,131089,1213,135680]

theorem envBound30072 : H12AffineFastState.Bounded env30072 := by
  intro p hp
  have h : env30072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30071_30072 : H12AffineEnvironment.transform 15 13374 env30071 = env30072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13374 env30071 == env30072) = true)

theorem identity30072 : scanCanonicalize (H12AffineFastState.compose env30072 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound30072 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env30073 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1213,32768,13374,131072,137352,136193,32769,4097,46140,132268,41003,143497,5292,43169,131073,131072,2184,4117,1196,173,131089,1213,135680]

theorem envBound30073 : H12AffineFastState.Bounded env30073 := by
  intro p hp
  have h : env30073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30072_30073 : H12AffineEnvironment.transform 13 1213 env30072 = env30073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env30072 == env30073) = true)

theorem identity30073 : scanCanonicalize (H12AffineFastState.compose env30073 (packedSelected [13,17] rootPS)) = affineNative (2^(16+1) ^^^ 46244) := by decide +kernel

theorem selectedBound30073 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env30074 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1213,32768,13374,46244,44076,41125,32769,4097,46140,45064,41003,33837,5292,43169,46245,46244,2184,4117,1196,173,46261,1213,42660]

theorem envBound30074 : H12AffineFastState.Bounded env30074 := by
  intro p hp
  have h : env30074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30073_30074 : H12AffineEnvironment.transform 16 46244 env30073 = env30074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46244 env30073 == env30074) = true)

theorem identity30074 : scanCanonicalize (H12AffineFastState.compose env30074 (packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 15550) := by decide +kernel

theorem selectedBound30074 : packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env30075 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1213,15550,13374,2074,4242,7195,15551,4097,2178,3254,7317,14483,5292,5151,2075,2074,2184,4117,1196,173,2059,1213,6682]

theorem envBound30075 : H12AffineFastState.Bounded env30075 := by
  intro p hp
  have h : env30075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30074_30075 : H12AffineEnvironment.transform 14 15550 env30074 = env30075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 15550 env30074 == env30075) = true)

theorem identity30075 : scanCanonicalize (H12AffineFastState.compose env30075 (packedSelected [1,5] rootPS)) = affineNative (2^(12+1) ^^^ 5284) := by decide +kernel

theorem selectedBound30075 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env30076 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,5284,1213,2074,154,2074,4242,7195,2075,4097,2178,3254,7317,3127,5292,5151,2075,2074,2184,4117,1196,173,2059,1213,6682]

theorem envBound30076 : H12AffineFastState.Bounded env30076 := by
  intro p hp
  have h : env30076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30075_30076 : H12AffineEnvironment.transform 12 5284 env30075 = env30076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5284 env30075 == env30076) = true)

theorem identity30076 : scanCanonicalize (H12AffineFastState.compose env30076 (packedSelected [0,4,11,13] rootPS)) = affineNative (2^(11+1) ^^^ 2706) := by decide +kernel

theorem selectedBound30076 : packedSelected [0,4,11,13] rootPS < 2^1333 := by decide +kernel

def env30077 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,2706,3638,1213,2074,154,2074,2560,1673,2075,2707,2178,3254,1543,3127,3646,3725,2075,2074,2184,2695,1196,173,2059,1213,136]

theorem envBound30077 : H12AffineFastState.Bounded env30077 := by
  intro p hp
  have h : env30077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30076_30077 : H12AffineEnvironment.transform 11 2706 env30076 = env30077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2706 env30076 == env30077) = true)

theorem identity30077 : scanCanonicalize (H12AffineFastState.compose env30077 (packedSelected [0,2,4,10] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound30077 : packedSelected [0,2,4,10] rootPS < 2^1333 := by decide +kernel

def env30078 : List Nat := [2,4,8,16,32,17,128,173,512,5,2048,2706,2611,184,2074,154,2074,2560,652,2075,2707,2178,2227,514,2098,2619,2696,2075,2074,2184,2695,169,173,2059,184,136]

theorem envBound30078 : H12AffineFastState.Bounded env30078 := by
  intro p hp
  have h : env30078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30077_30078 : H12AffineEnvironment.transform 9 5 env30077 = env30078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env30077 == env30078) = true)

theorem identity30078 : scanCanonicalize (H12AffineFastState.compose env30078 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 146) := by decide +kernel

theorem selectedBound30078 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env30079 : List Nat := [2,4,8,16,32,17,128,173,512,5,146,512,673,184,136,154,136,658,652,137,513,16,33,514,160,681,538,137,136,26,533,169,173,153,184,136]

theorem envBound30079 : H12AffineFastState.Bounded env30079 := by
  intro p hp
  have h : env30079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30078_30079 : H12AffineEnvironment.transform 10 146 env30078 = env30079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 146 env30078 == env30079) = true)

theorem identity30079 : scanCanonicalize (H12AffineFastState.compose env30079 (packedSelected [0,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound30079 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env30080 : List Nat := [2,4,8,12,32,13,128,173,512,5,142,512,673,164,136,134,136,654,652,137,513,12,33,514,160,681,518,137,136,6,521,169,173,133,164,136]

theorem envBound30080 : H12AffineFastState.Bounded env30080 := by
  intro p hp
  have h : env30080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30079_30080 : H12AffineEnvironment.transform 3 12 env30079 = env30080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env30079 == env30080) = true)

theorem identity30080 : scanCanonicalize (H12AffineFastState.compose env30080 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 36) := by decide +kernel

theorem selectedBound30080 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env30081 : List Nat := [2,4,8,12,32,13,36,9,512,5,42,512,517,0,44,34,44,554,552,45,513,12,33,514,4,525,518,45,44,6,521,13,9,33,0,44]

theorem envBound30081 : H12AffineFastState.Bounded env30081 := by
  intro p hp
  have h : env30081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30080_30081 : H12AffineEnvironment.transform 6 36 env30080 = env30081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 36 env30080 == env30081) = true)

theorem identity30081 : scanCanonicalize (H12AffineFastState.compose env30081 (packedSelected [1,8] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound30081 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env30082 : List Nat := [2,4,8,12,32,13,36,9,0,5,42,0,5,0,44,34,44,42,40,45,1,12,33,2,4,13,6,45,44,6,9,13,9,33,0,44]

theorem envBound30082 : H12AffineFastState.Bounded env30082 := by
  intro p hp
  have h : env30082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30081_30082 : H12AffineEnvironment.transform 8 0 env30081 = env30082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env30081 == env30082) = true)

theorem identity30082 : scanCanonicalize (H12AffineFastState.compose env30082 (packedSelected [1,2,3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound30082 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env30083 : List Nat := [2,3,8,11,32,10,35,9,0,2,42,0,2,0,43,34,43,42,40,42,1,11,33,2,3,10,1,42,43,1,9,10,9,33,0,43]

theorem envBound30083 : H12AffineFastState.Bounded env30083 := by
  intro p hp
  have h : env30083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30082_30083 : H12AffineEnvironment.transform 1 3 env30082 = env30083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env30082 == env30083) = true)

theorem identity30083 : scanCanonicalize (H12AffineFastState.compose env30083 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound30083 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30084 : List Nat := [2,3,8,11,11,10,8,9,0,2,1,0,2,0,0,9,0,1,3,1,1,11,10,2,3,10,1,1,0,1,9,10,9,10,0,0]

theorem envBound30084 : H12AffineFastState.Bounded env30084 := by
  intro p hp
  have h : env30084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30083_30084 : H12AffineEnvironment.transform 4 11 env30083 = env30084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env30083 == env30084) = true)

def env30085 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,16777216,533640,672784,17245633,148800,545088,96346,16876544,17495098,256,131137,1344,525825]

theorem envBound30085 : H12AffineFastState.Bounded env30085 := by
  intro p hp
  have h : env30085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29969_30085 : H12AffineEnvironment.transform 26 17245633 env29969 = env30085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env29969 == env30085) = true)

theorem identity30085 : scanCanonicalize (H12AffineFastState.compose env30085 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 717114) := by decide +kernel

theorem selectedBound30085 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env30086 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,61648,147520,717114,533640,672784,906491,148800,545088,96346,750906,1280,256,131137,1344,525825]

theorem envBound30086 : H12AffineFastState.Bounded env30086 := by
  intro p hp
  have h : env30086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30085_30086 : H12AffineEnvironment.transform 23 717114 env30085 = env30086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 717114 env30085 == env30086) = true)

def env30087 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147520,58682,143496,20496,508155,148800,148800,96346,90426,1280,256,131137,1344,135681]

theorem envBound30087 : H12AffineFastState.Bounded env30087 := by
  intro p hp
  have h : env30087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30086_30087 : H12AffineEnvironment.transform 18 136192 env30086 = env30087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env30086 == env30087) = true)

def env30088 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147520,58518,143496,20496,508155,148716,148716,96346,90262,1196,172,131137,1260,135681]

theorem envBound30088 : H12AffineFastState.Bounded env30088 := by
  intro p hp
  have h : env30088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30087_30088 : H12AffineEnvironment.transform 7 172 env30087 = env30088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env30087 == env30088) = true)

def env30089 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61568,147472,58518,143496,20496,508075,148668,148668,96266,90262,1196,172,131089,1212,135681]

theorem envBound30089 : H12AffineFastState.Bounded env30089 := by
  intro p hp
  have h : env30089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30088_30089 : H12AffineEnvironment.transform 5 16 env30088 = env30089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env30088 == env30089) = true)

theorem identity30089 : scanCanonicalize (H12AffineFastState.compose env30089 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 208055) := by decide +kernel

theorem selectedBound30089 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env30090 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,208055,136192,32769,4097,61568,147472,58518,143496,20496,60444,148668,148668,96266,90262,1196,172,131089,1212,135681]

theorem envBound30090 : H12AffineFastState.Bounded env30090 := by
  intro p hp
  have h : env30090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30089_30090 : H12AffineEnvironment.transform 17 208055 env30089 = env30090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 208055 env30089 == env30090) = true)

theorem identity30090 : scanCanonicalize (H12AffineFastState.compose env30090 (packedSelected [1,3,5,7,8,10,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound30090 : packedSelected [1,3,5,7,8,10,20,26,27] rootPS < 2^1333 := by decide +kernel

def env30091 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,53282,131072,195733,136192,32769,4097,61568,147472,58518,143496,20496,60444,148668,148668,43048,45236,1196,172,131089,1212,135681]

theorem envBound30091 : H12AffineFastState.Bounded env30091 := by
  intro p hp
  have h : env30091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30090_30091 : H12AffineEnvironment.transform 15 53282 env30090 = env30091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env30090 == env30091) = true)

theorem identity30091 : scanCanonicalize (H12AffineFastState.compose env30091 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 21693) := by decide +kernel

theorem selectedBound30091 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env30092 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,53282,21693,43048,16573,32769,4097,61568,5293,58518,25653,20496,60444,4097,4097,43048,45236,1196,172,21676,1212,18108]

theorem envBound30092 : H12AffineFastState.Bounded env30092 := by
  intro p hp
  have h : env30092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30091_30092 : H12AffineEnvironment.transform 16 21693 env30091 = env30092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21693 env30091 == env30092) = true)

theorem identity30092 : scanCanonicalize (H12AffineFastState.compose env30092 (packedSelected [4,9,20] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound30092 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env30093 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,185,8192,16384,32768,49307,17412,43048,16573,32769,184,57401,1044,58518,25653,16553,60444,184,184,43048,40973,1196,172,17429,1212,18108]

theorem envBound30093 : H12AffineFastState.Bounded env30093 := by
  intro p hp
  have h : env30093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30092_30093 : H12AffineEnvironment.transform 11 185 env30092 = env30093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env30092 == env30093) = true)

theorem identity30093 : scanCanonicalize (H12AffineFastState.compose env30093 (packedSelected [0,2,3,5,6,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 1700) := by decide +kernel

theorem selectedBound30093 : packedSelected [0,2,3,5,6,9,11] rootPS < 2^1333 := by decide +kernel

def env30094 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,185,1700,16384,32768,49307,17412,36492,16573,32769,184,50845,1044,49714,17041,16553,51896,184,184,36492,34473,1196,172,17429,1212,18108]

theorem envBound30094 : H12AffineFastState.Bounded env30094 := by
  intro p hp
  have h : env30094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30093_30094 : H12AffineEnvironment.transform 12 1700 env30093 = env30094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1700 env30093 == env30094) = true)

theorem identity30094 : scanCanonicalize (H12AffineFastState.compose env30094 (packedSelected [0,1,2,5,7,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 146) := by decide +kernel

theorem selectedBound30094 : packedSelected [0,1,2,5,7,15,17] rootPS < 2^1333 := by decide +kernel

def env30095 : List Nat := [2,4,8,16,32,16,128,172,512,1024,146,185,1700,16384,32768,49307,17412,34334,16573,32769,184,50845,1044,49714,17041,16553,49706,184,184,34334,34473,1196,172,17429,1212,18108]

theorem envBound30095 : H12AffineFastState.Bounded env30095 := by
  intro p hp
  have h : env30095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30094_30095 : H12AffineEnvironment.transform 10 146 env30094 = env30095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 146 env30094 == env30095) = true)

theorem identity30095 : scanCanonicalize (H12AffineFastState.compose env30095 (packedSelected [1,3,4,9,13,16] rootPS)) = affineNative (2^(14+1) ^^^ 17032) := by decide +kernel

theorem selectedBound30095 : packedSelected [1,3,4,9,13,16] rootPS < 2^1333 := by decide +kernel

def env30096 : List Nat := [2,4,8,16,32,16,128,172,512,1024,146,185,1700,16384,17032,531,17412,17558,16573,17033,184,1045,1044,186,17041,16553,162,184,184,17558,17441,1196,172,17429,1212,18108]

theorem envBound30096 : H12AffineFastState.Bounded env30096 := by
  intro p hp
  have h : env30096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30095_30096 : H12AffineEnvironment.transform 14 17032 env30095 = env30096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 17032 env30095 == env30096) = true)

theorem identity30096 : scanCanonicalize (H12AffineFastState.compose env30096 (packedSelected [2,3,4,6,7,8,10,12] rootPS)) = affineNative (2^(13+1) ^^^ 1191) := by decide +kernel

theorem selectedBound30096 : packedSelected [2,3,4,6,7,8,10,12] rootPS < 2^1333 := by decide +kernel

def env30097 : List Nat := [2,4,8,16,32,16,128,172,512,1024,146,185,1700,1191,1583,531,163,49,1050,1582,184,1045,1044,186,1590,1038,162,184,184,49,134,1196,172,178,1212,539]

theorem envBound30097 : H12AffineFastState.Bounded env30097 := by
  intro p hp
  have h : env30097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30096_30097 : H12AffineEnvironment.transform 13 1191 env30096 = env30097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1191 env30096 == env30097) = true)

theorem identity30097 : scanCanonicalize (H12AffineFastState.compose env30097 (packedSelected [0,2,4,5,6,7,8,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 558) := by decide +kernel

theorem selectedBound30097 : packedSelected [0,2,4,5,6,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env30098 : List Nat := [2,4,8,16,32,16,128,172,512,558,146,185,138,649,1,531,163,49,564,0,184,571,570,186,24,544,162,184,184,49,134,642,172,178,658,539]

theorem envBound30098 : H12AffineFastState.Bounded env30098 := by
  intro p hp
  have h : env30098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30097_30098 : H12AffineEnvironment.transform 9 558 env30097 = env30098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 558 env30097 == env30098) = true)

theorem identity30098 : scanCanonicalize (H12AffineFastState.compose env30098 (packedSelected [2,3,6,8] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound30098 : packedSelected [2,3,6,8] rootPS < 2^1333 := by decide +kernel

def env30099 : List Nat := [2,4,8,16,10,16,128,134,512,516,146,147,138,649,1,531,137,27,542,0,146,529,528,144,24,522,136,146,146,27,134,642,134,152,658,539]

theorem envBound30099 : H12AffineFastState.Bounded env30099 := by
  intro p hp
  have h : env30099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30098_30099 : H12AffineEnvironment.transform 4 10 env30098 = env30099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env30098 == env30099) = true)

theorem identity30099 : scanCanonicalize (H12AffineFastState.compose env30099 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 149) := by decide +kernel

theorem selectedBound30099 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env30100 : List Nat := [2,4,8,16,10,16,128,134,149,145,146,147,138,28,1,134,137,27,139,0,146,132,133,144,24,159,136,146,146,27,134,23,134,152,7,142]

theorem envBound30100 : H12AffineFastState.Bounded env30100 := by
  intro p hp
  have h : env30100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30099_30100 : H12AffineEnvironment.transform 8 149 env30099 = env30100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 149 env30099 == env30100) = true)

theorem identity30100 : scanCanonicalize (H12AffineFastState.compose env30100 (packedSelected [2,3,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound30100 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env30101 : List Nat := [2,4,8,10,10,10,128,134,143,139,136,137,138,6,1,134,137,1,139,0,136,132,133,138,2,133,136,136,136,1,134,13,134,130,7,142]

theorem envBound30101 : H12AffineFastState.Bounded env30101 := by
  intro p hp
  have h : env30101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30100_30101 : H12AffineEnvironment.transform 3 10 env30100 = env30101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env30100 == env30101) = true)

theorem identity30101 : scanCanonicalize (H12AffineFastState.compose env30101 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound30101 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30102 : List Nat := [1,4,8,9,9,9,128,133,140,136,136,137,137,5,1,133,137,1,136,0,136,132,133,137,1,133,136,136,136,1,133,13,133,129,4,141]

theorem envBound30102 : H12AffineFastState.Bounded env30102 := by
  intro p hp
  have h : env30102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30101_30102 : H12AffineEnvironment.transform 0 1 env30101 = env30102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env30101 == env30102) = true)

theorem identity30102 : scanCanonicalize (H12AffineFastState.compose env30102 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound30102 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env30103 : List Nat := [1,4,1,0,0,0,128,133,133,129,129,128,128,5,1,133,128,1,129,0,129,132,133,128,1,133,129,129,129,1,133,4,133,129,4,132]

theorem envBound30103 : H12AffineFastState.Bounded env30103 := by
  intro p hp
  have h : env30103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30102_30103 : H12AffineEnvironment.transform 2 1 env30102 = env30103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env30102 == env30103) = true)

theorem identity30103 : scanCanonicalize (H12AffineFastState.compose env30103 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound30103 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env30104 : List Nat := [1,0,1,0,0,0,128,129,129,129,129,128,128,1,1,129,128,1,129,0,129,128,129,128,1,129,129,129,129,1,129,0,129,129,0,128]

theorem envBound30104 : H12AffineFastState.Bounded env30104 := by
  intro p hp
  have h : env30104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30103_30104 : H12AffineEnvironment.transform 1 0 env30103 = env30104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env30103 == env30104) = true)

def env30105 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61569,147473,58518,143496,20496,508074,148669,148669,96267,90262,1196,172,131088,1213,135681]

theorem envBound30105 : H12AffineFastState.Bounded env30105 := by
  intro p hp
  have h : env30105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30088_30105 : H12AffineEnvironment.transform 5 17 env30088 = env30105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30088 == env30105) = true)

theorem identity30105 : scanCanonicalize (H12AffineFastState.compose env30105 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 99486) := by decide +kernel

theorem selectedBound30105 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env30106 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,99486,262144,102558,32769,4097,61569,115855,58518,111638,20496,279604,114723,114723,96267,90262,1196,172,99470,1213,104095]

theorem envBound30106 : H12AffineFastState.Bounded env30106 := by
  intro p hp
  have h : env30106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30105_30106 : H12AffineEnvironment.transform 16 99486 env30105 = env30106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 99486 env30105 == env30106) = true)

theorem identity30106 : scanCanonicalize (H12AffineFastState.compose env30106 (packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound30106 : packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env30107 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,5124,32768,65536,99486,262144,102558,32769,4097,42117,102539,45202,111638,1044,266288,103463,103463,76815,78994,1196,172,99470,1213,104095]

theorem envBound30107 : H12AffineFastState.Bounded env30107 := by
  intro p hp
  have h : env30107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30106_30107 : H12AffineEnvironment.transform 13 5124 env30106 = env30107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env30106 == env30107) = true)

theorem identity30107 : scanCanonicalize (H12AffineFastState.compose env30107 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 38047) := by decide +kernel

theorem selectedBound30107 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env30108 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,5124,32768,38047,4097,262144,1025,32769,4097,42117,1044,45202,8329,1044,266288,184,184,47248,40973,1196,172,4113,1213,512]

theorem envBound30108 : H12AffineFastState.Bounded env30108 := by
  intro p hp
  have h : env30108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30107_30108 : H12AffineEnvironment.transform 15 38047 env30107 = env30108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38047 env30107 == env30108) = true)

theorem identity30108 : scanCanonicalize (H12AffineFastState.compose env30108 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound30108 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env30109 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,184,8192,1212,32768,33831,185,262144,1025,32769,185,42117,1044,41002,8329,1044,262280,184,184,43048,40973,1196,172,169,1213,512]

theorem envBound30109 : H12AffineFastState.Bounded env30109 := by
  intro p hp
  have h : env30109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30108_30109 : H12AffineEnvironment.transform 11 184 env30108 = env30109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env30108 == env30109) = true)

theorem identity30109 : scanCanonicalize (H12AffineFastState.compose env30109 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 560) := by decide +kernel

theorem selectedBound30109 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env30110 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,184,8192,1212,560,1559,185,262144,1025,561,185,9909,1044,8730,8329,1044,262280,184,184,10776,8765,1196,172,169,1213,512]

theorem envBound30110 : H12AffineFastState.Bounded env30110 := by
  intro p hp
  have h : env30110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30109_30110 : H12AffineEnvironment.transform 14 560 env30109 = env30110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 560 env30109 == env30110) = true)

theorem identity30110 : scanCanonicalize (H12AffineFastState.compose env30110 (packedSelected [1,3,13] rootPS)) = affineNative (2^(12+1) ^^^ 1684) := by decide +kernel

theorem selectedBound30110 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env30111 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,184,1684,1212,560,1559,185,262144,1025,561,185,33,1044,1166,1565,1044,262280,184,184,3212,1193,1196,172,169,1213,512]

theorem envBound30111 : H12AffineFastState.Bounded env30111 := by
  intro p hp
  have h : env30111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30110_30111 : H12AffineEnvironment.transform 12 1684 env30110 = env30111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1684 env30110 == env30111) = true)

theorem identity30111 : scanCanonicalize (H12AffineFastState.compose env30111 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 555) := by decide +kernel

theorem selectedBound30111 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env30112 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,184,1684,1212,560,1559,185,555,1025,561,185,33,1044,1166,1565,1044,675,184,184,3212,1193,1196,172,169,1213,512]

theorem envBound30112 : H12AffineFastState.Bounded env30112 := by
  intro p hp
  have h : env30112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30111_30112 : H12AffineEnvironment.transform 17 555 env30111 = env30112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 555 env30111 == env30112) = true)

def env30113 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61648,147520,58519,143496,20496,508155,148717,148717,96346,90263,1197,173,131137,1261,135681]

theorem envBound30113 : H12AffineFastState.Bounded env30113 := by
  intro p hp
  have h : env30113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30087_30113 : H12AffineEnvironment.transform 7 173 env30087 = env30113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env30087 == env30113) = true)

def env30114 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61568,147472,58519,143496,20496,508075,148669,148669,96266,90263,1197,173,131089,1213,135681]

theorem envBound30114 : H12AffineFastState.Bounded env30114 := by
  intro p hp
  have h : env30114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30113_30114 : H12AffineEnvironment.transform 5 16 env30113 = env30114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env30113 == env30114) = true)

theorem identity30114 : scanCanonicalize (H12AffineFastState.compose env30114 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 137353) := by decide +kernel

theorem selectedBound30114 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env30115 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,137353,136192,32769,4097,61568,147472,58519,143496,20496,120866,148669,148669,96266,90263,1197,173,131089,1213,135681]

theorem envBound30115 : H12AffineFastState.Bounded env30115 := by
  intro p hp
  have h : env30115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30114_30115 : H12AffineEnvironment.transform 17 137353 env30114 = env30115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137353 env30114 == env30115) = true)

theorem identity30115 : scanCanonicalize (H12AffineFastState.compose env30115 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(16+1) ^^^ 62493) := by decide +kernel

theorem selectedBound30115 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env30116 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,62493,60564,57373,32769,4097,61568,46093,58519,50325,20496,120866,45216,45216,96266,90263,1197,173,62476,1213,58908]

theorem envBound30116 : H12AffineFastState.Bounded env30116 := by
  intro p hp
  have h : env30116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30115_30116 : H12AffineEnvironment.transform 16 62493 env30115 = env30116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 62493 env30115 == env30116) = true)

theorem identity30116 : scanCanonicalize (H12AffineFastState.compose env30116 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 24635) := by decide +kernel

theorem selectedBound30116 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env30117 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,24635,62493,60564,57373,32769,4097,61568,46093,58519,50325,20496,47129,45216,45216,6193,172,1197,173,62476,1213,58908]

theorem envBound30117 : H12AffineFastState.Bounded env30117 := by
  intro p hp
  have h : env30117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30116_30117 : H12AffineEnvironment.transform 15 24635 env30116 = env30117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24635 env30116 == env30117) = true)

theorem identity30117 : scanCanonicalize (H12AffineFastState.compose env30117 (packedSelected [0,1,2,4,6,7,8,9,13,17,18,19,21,23] rootPS)) = affineNative (2^(12+1) ^^^ 3629) := by decide +kernel

theorem selectedBound30117 : packedSelected [0,1,2,4,6,7,8,9,13,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env30118 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,3629,16384,32768,19990,55856,49849,52784,32769,4097,57005,39456,51898,50325,20496,38452,40589,40589,6193,172,1197,173,55841,1213,51249]

theorem envBound30118 : H12AffineFastState.Bounded env30118 := by
  intro p hp
  have h : env30118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30117_30118 : H12AffineEnvironment.transform 12 3629 env30117 = env30118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3629 env30117 == env30118) = true)

theorem identity30118 : scanCanonicalize (H12AffineFastState.compose env30118 (packedSelected [0,1,2,4,6,7,8,9,13,26] rootPS)) = affineNative (2^(14+1) ^^^ 7733) := by decide +kernel

theorem selectedBound30118 : packedSelected [0,1,2,4,6,7,8,9,13,26] rootPS < 2^1333 := by decide +kernel

def env30119 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,3629,16384,7733,19990,17413,23692,20485,7732,4097,16536,1045,21647,23200,20496,2049,184,184,6193,172,1197,173,17428,1213,22020]

theorem envBound30119 : H12AffineFastState.Bounded env30119 := by
  intro p hp
  have h : env30119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30118_30119 : H12AffineEnvironment.transform 14 7733 env30118 = env30119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7733 env30118 == env30119) = true)

theorem identity30119 : scanCanonicalize (H12AffineFastState.compose env30119 (packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound30119 : packedSelected [0,2,3,4,5,6,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env30120 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,3629,5124,7733,6674,4097,2184,1025,7732,4097,5276,1045,139,3748,1044,2049,184,184,6193,172,1197,173,4112,1213,512]

theorem envBound30120 : H12AffineFastState.Bounded env30120 := by
  intro p hp
  have h : env30120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30119_30120 : H12AffineEnvironment.transform 13 5124 env30119 = env30120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env30119 == env30120) = true)

theorem identity30120 : scanCanonicalize (H12AffineFastState.compose env30120 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 1076) := by decide +kernel

theorem selectedBound30120 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env30121 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,1076,3629,48,2561,3622,1077,2184,1025,2560,1077,168,1045,139,3748,1044,2049,184,184,3077,172,1197,173,1060,1213,512]

theorem envBound30121 : H12AffineFastState.Bounded env30121 := by
  intro p hp
  have h : env30121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30120_30121 : H12AffineEnvironment.transform 11 1076 env30120 = env30121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1076 env30120 == env30121) = true)

theorem identity30121 : scanCanonicalize (H12AffineFastState.compose env30121 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound30121 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env30122 : List Nat := [2,4,8,16,32,16,128,173,26,1024,2048,1076,3127,48,2075,3132,1077,2184,1025,2074,1077,168,1045,139,3262,1044,2049,184,184,3077,172,1197,173,1060,1213,26]

theorem envBound30122 : H12AffineFastState.Bounded env30122 := by
  intro p hp
  have h : env30122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30121_30122 : H12AffineEnvironment.transform 8 26 env30121 = env30122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env30121 == env30122) = true)

theorem identity30122 : scanCanonicalize (H12AffineFastState.compose env30122 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 1071) := by decide +kernel

theorem selectedBound30122 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env30123 : List Nat := [2,4,8,16,32,16,128,173,26,1024,1071,1076,24,48,1076,19,1077,1191,1025,1077,1077,168,1045,139,145,1044,1070,184,184,42,172,1197,173,1060,1213,26]

theorem envBound30123 : H12AffineFastState.Bounded env30123 := by
  intro p hp
  have h : env30123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30122_30123 : H12AffineEnvironment.transform 10 1071 env30122 = env30123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1071 env30122 == env30123) = true)

theorem identity30123 : scanCanonicalize (H12AffineFastState.compose env30123 (packedSelected [3,7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound30123 : packedSelected [3,7] rootPS < 2^1333 := by decide +kernel

def env30124 : List Nat := [2,4,8,11,32,11,128,173,1,1024,1071,1071,3,43,1071,8,1070,1191,1025,1070,1070,168,1038,139,138,1039,1070,163,163,42,172,1197,173,1060,1190,1]

theorem envBound30124 : H12AffineFastState.Bounded env30124 := by
  intro p hp
  have h : env30124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30123_30124 : H12AffineEnvironment.transform 3 11 env30123 = env30124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env30123 == env30124) = true)

theorem identity30124 : scanCanonicalize (H12AffineFastState.compose env30124 (packedSelected [2,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound30124 : packedSelected [2,3,4] rootPS < 2^1333 := by decide +kernel

def env30125 : List Nat := [2,4,8,11,32,11,128,173,1,5,42,42,3,43,42,8,43,162,4,43,43,168,11,139,138,10,43,163,163,42,172,168,173,33,163,1]

theorem envBound30125 : H12AffineFastState.Bounded env30125 := by
  intro p hp
  have h : env30125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30124_30125 : H12AffineEnvironment.transform 9 5 env30124 = env30125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env30124 == env30125) = true)

theorem identity30125 : scanCanonicalize (H12AffineFastState.compose env30125 (packedSelected [0,2,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound30125 : packedSelected [0,2,9] rootPS < 2^1333 := by decide +kernel

def env30126 : List Nat := [2,4,8,11,32,11,8,37,1,5,42,42,3,43,42,8,43,42,4,43,43,32,11,3,2,10,43,43,43,42,36,32,37,33,43,1]

theorem envBound30126 : H12AffineFastState.Bounded env30126 := by
  intro p hp
  have h : env30126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30125_30126 : H12AffineEnvironment.transform 6 8 env30125 = env30126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env30125 == env30126) = true)

theorem identity30126 : scanCanonicalize (H12AffineFastState.compose env30126 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound30126 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env30127 : List Nat := [2,2,8,11,32,11,8,35,1,3,42,42,3,43,42,8,43,42,2,43,43,32,11,3,2,10,43,43,43,42,34,32,35,33,43,1]

theorem envBound30127 : H12AffineFastState.Bounded env30127 := by
  intro p hp
  have h : env30127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30126_30127 : H12AffineEnvironment.transform 1 2 env30126 = env30127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env30126 == env30127) = true)

def env30128 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4097,61569,147473,58519,143496,20496,508074,148668,148668,96267,90263,1197,173,131088,1212,135681]

theorem envBound30128 : H12AffineFastState.Bounded env30128 := by
  intro p hp
  have h : env30128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30113_30128 : H12AffineEnvironment.transform 5 17 env30113 = env30128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env30113 == env30128) = true)

theorem identity30128 : scanCanonicalize (H12AffineFastState.compose env30128 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound30128 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env30129 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,45217,262144,42145,32769,4097,61569,61616,58519,32809,20496,356363,62493,62493,96267,90263,1197,173,45233,1212,41632]

theorem envBound30129 : H12AffineFastState.Bounded env30129 := by
  intro p hp
  have h : env30129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30128_30129 : H12AffineEnvironment.transform 16 45217 env30128 = env30129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env30128 == env30129) = true)

theorem identity30129 : scanCanonicalize (H12AffineFastState.compose env30129 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound30129 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env30130 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,45217,2185,42145,32769,4097,61569,61616,58519,32809,20496,96386,62493,62493,96267,90263,1197,173,45233,1212,41632]

theorem envBound30130 : H12AffineFastState.Bounded env30130 := by
  intro p hp
  have h : env30130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30129_30130 : H12AffineEnvironment.transform 17 2185 env30129 = env30130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env30129 == env30130) = true)

theorem identity30130 : scanCanonicalize (H12AffineFastState.compose env30130 (packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS)) = affineNative (2^(14+1) ^^^ 12312) := by decide +kernel

theorem selectedBound30130 : packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env30131 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,12312,65536,185,2185,5305,12313,4097,16537,16552,21647,12337,20496,96386,17413,17413,96267,90263,1197,173,169,1212,4792]

theorem envBound30131 : H12AffineFastState.Bounded env30131 := by
  intro p hp
  have h : env30131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30130_30131 : H12AffineEnvironment.transform 14 12312 env30130 = env30131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12312 env30130 == env30131) = true)

theorem identity30131 : scanCanonicalize (H12AffineFastState.compose env30131 (packedSelected [1,4,5,8,9,16,17,21,24] rootPS)) = affineNative (2^(15+1) ^^^ 13375) := by decide +kernel

theorem selectedBound30131 : packedSelected [1,4,5,8,9,16,17,21,24] rootPS < 2^1333 := by decide +kernel

def env30132 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,12312,13375,185,2185,5305,12313,4097,16537,16552,21647,12337,20496,19645,17413,17413,19508,21672,1197,173,169,1212,4792]

theorem envBound30132 : H12AffineFastState.Bounded env30132 := by
  intro p hp
  have h : env30132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30131_30132 : H12AffineEnvironment.transform 15 13375 env30131 = env30132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13375 env30131 == env30132) = true)

theorem identity30132 : scanCanonicalize (H12AffineFastState.compose env30132 (packedSelected [2,3,5,6,10,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 7845) := by decide +kernel

theorem selectedBound30132 : packedSelected [2,3,5,6,10,15,17] rootPS < 2^1333 := by decide +kernel

def env30133 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,7845,16384,3773,2714,185,2185,5305,3772,4097,16537,16552,21647,3732,20496,19645,17413,17413,19508,21672,1197,173,169,1212,4792]

theorem envBound30133 : H12AffineFastState.Bounded env30133 := by
  intro p hp
  have h : env30133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30132_30133 : H12AffineEnvironment.transform 12 7845 env30132 = env30133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7845 env30132 == env30133) = true)

theorem identity30133 : scanCanonicalize (H12AffineFastState.compose env30133 (packedSelected [3,4,5,6,7,12,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 3773) := by decide +kernel

theorem selectedBound30133 : packedSelected [3,4,5,6,7,12,15,16] rootPS < 2^1333 := by decide +kernel

def env30134 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,7845,3773,3773,2714,185,2185,5305,3772,4097,3620,3605,6706,3732,7853,512,2744,2744,649,6677,1197,173,169,1212,4792]

theorem envBound30134 : H12AffineFastState.Bounded env30134 := by
  intro p hp
  have h : env30134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans30133_30134 : H12AffineEnvironment.transform 13 3773 env30133 = env30134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3773 env30133 == env30134) = true)

theorem identity30134 : scanCanonicalize (H12AffineFastState.compose env30134 (packedSelected [0,4,11] rootPS)) = affineNative (2^(11+1) ^^^ 3212) := by decide +kernel

end H12CloudChart2