import H12CloudChart2Data128

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans31947_31948 : H12AffineEnvironment.transform 3 10 env31947 = env31948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env31947 == env31948) = true)

theorem identity31948 : scanCanonicalize (H12AffineFastState.compose env31948 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound31948 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env31949 : List Nat := [2,4,8,10,32,10,14,2,39,40,6,10,3,33,38,46,32,33,2,39,10,1,10,46,46,32,44,32,33,11,15,10,3,43,32,13]

theorem envBound31949 : H12AffineFastState.Bounded env31949 := by
  intro p hp
  have h : env31949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31948_31949 : H12AffineEnvironment.transform 5 10 env31948 = env31949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env31948 == env31949) = true)

theorem identity31949 : scanCanonicalize (H12AffineFastState.compose env31949 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound31949 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env31950 : List Nat := [2,4,8,10,13,10,14,2,10,5,6,10,3,12,11,3,13,12,2,10,10,1,10,3,3,13,1,13,12,11,15,10,3,6,13,13]

theorem envBound31950 : H12AffineFastState.Bounded env31950 := by
  intro p hp
  have h : env31950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31949_31950 : H12AffineEnvironment.transform 4 13 env31949 = env31950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env31949 == env31950) = true)

theorem identity31950 : scanCanonicalize (H12AffineFastState.compose env31950 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound31950 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31951 : List Nat := [2,4,4,6,1,6,2,2,6,5,6,6,3,0,7,3,1,0,2,6,6,1,6,3,3,1,1,1,0,7,3,6,3,6,1,1]

theorem envBound31951 : H12AffineFastState.Bounded env31951 := by
  intro p hp
  have h : env31951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31950_31951 : H12AffineEnvironment.transform 2 4 env31950 = env31951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env31950 == env31951) = true)

def env31952 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,25,1297,5124,1053,107,1180,4416,5125,4096,477,1339,5133,5584,4139,4414,59,1297,6478,21,1339,257,1281,1344,5952]

theorem envBound31952 : H12AffineFastState.Bounded env31952 := by
  intro p hp
  have h : env31952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31917_31952 : H12AffineEnvironment.transform 15 1053 env31917 = env31952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1053 env31917 == env31952) = true)

theorem identity31952 : scanCanonicalize (H12AffineFastState.compose env31952 (packedSelected [0,1,2,4,7,9,10,11,15,17,19,21,23,24,28] rootPS)) = affineNative (2^(11+1) ^^^ 3641) := by decide +kernel

theorem selectedBound31952 : packedSelected [0,1,2,4,7,9,10,11,15,17,19,21,23,24,28] rootPS < 2^1333 := by decide +kernel

def env31953 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3641,25,1297,2621,1053,107,1180,3961,2620,3641,477,1339,2612,3049,3602,3847,59,1297,1911,21,1339,257,1281,1344,2425]

theorem envBound31953 : H12AffineFastState.Bounded env31953 := by
  intro p hp
  have h : env31953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31952_31953 : H12AffineEnvironment.transform 11 3641 env31952 = env31953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3641 env31952 == env31953) = true)

def env31954 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,3437,25,1297,2409,1053,107,1180,3117,2408,3437,477,1339,2400,2237,3398,3155,59,1297,1059,21,1339,257,1281,1344,2425]

theorem envBound31954 : H12AffineFastState.Bounded env31954 := by
  intro p hp
  have h : env31954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31953_31954 : H12AffineEnvironment.transform 8 340 env31953 = env31954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env31953 == env31954) = true)

def env31955 : List Nat := [2,4,8,16,32,64,128,256,340,272,2048,2173,25,1,2409,269,107,396,2365,2408,2173,477,43,2400,2237,2134,2371,59,1,307,21,43,257,17,80,2425]

theorem envBound31955 : H12AffineFastState.Bounded env31955 := by
  intro p hp
  have h : env31955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31954_31955 : H12AffineEnvironment.transform 9 272 env31954 = env31955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env31954 == env31955) = true)

theorem identity31955 : scanCanonicalize (H12AffineFastState.compose env31955 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 126) := by decide +kernel

theorem selectedBound31955 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env31956 : List Nat := [2,4,8,16,32,64,128,126,42,110,2048,2173,25,1,2071,115,107,242,2115,2070,2173,163,43,2078,2237,2134,2109,59,1,77,21,43,127,17,80,2055]

theorem envBound31956 : H12AffineFastState.Bounded env31956 := by
  intro p hp
  have h : env31956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31955_31956 : H12AffineEnvironment.transform 7 126 env31955 = env31956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 126 env31955 == env31956) = true)

theorem identity31956 : scanCanonicalize (H12AffineFastState.compose env31956 (packedSelected [0,1,4,5,7,8,9,12,16,17,20] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound31956 : packedSelected [0,1,4,5,7,8,9,12,16,17,20] rootPS < 2^1333 := by decide +kernel

def env31957 : List Nat := [2,4,8,16,1,64,128,95,11,79,2048,2140,25,1,2071,82,74,211,2115,2070,2140,130,10,2078,2204,2134,2076,26,1,77,21,10,94,17,80,2055]

theorem envBound31957 : H12AffineFastState.Bounded env31957 := by
  intro p hp
  have h : env31957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31956_31957 : H12AffineEnvironment.transform 4 1 env31956 = env31957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env31956 == env31957) = true)

theorem identity31957 : scanCanonicalize (H12AffineFastState.compose env31957 (packedSelected [0,3,5,7,10,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 77) := by decide +kernel

theorem selectedBound31957 : packedSelected [0,3,5,7,10,13,17,18] rootPS < 2^1333 := by decide +kernel

def env31958 : List Nat := [2,4,8,16,1,64,128,95,11,79,77,17,25,1,90,82,74,211,14,91,17,130,10,83,209,27,81,26,1,77,21,10,94,17,80,74]

theorem envBound31958 : H12AffineFastState.Bounded env31958 := by
  intro p hp
  have h : env31958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31957_31958 : H12AffineEnvironment.transform 10 77 env31957 = env31958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 77 env31957 == env31958) = true)

theorem identity31958 : scanCanonicalize (H12AffineFastState.compose env31958 (packedSelected [1,2,3,7,8,9,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 94) := by decide +kernel

theorem selectedBound31958 : packedSelected [1,2,3,7,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env31959 : List Nat := [2,4,8,16,1,64,94,95,11,79,77,17,25,1,90,82,74,13,14,91,17,92,10,83,15,27,81,26,1,77,21,10,94,17,80,74]

theorem envBound31959 : H12AffineFastState.Bounded env31959 := by
  intro p hp
  have h : env31959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31958_31959 : H12AffineEnvironment.transform 6 94 env31958 = env31959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 94 env31958 == env31959) = true)

theorem identity31959 : scanCanonicalize (H12AffineFastState.compose env31959 (packedSelected [0,1,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound31959 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env31960 : List Nat := [2,3,8,16,1,64,89,88,11,72,74,17,25,1,90,82,74,10,9,91,17,91,10,83,8,27,81,26,1,74,18,10,89,17,80,74]

theorem envBound31960 : H12AffineFastState.Bounded env31960 := by
  intro p hp
  have h : env31960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31959_31960 : H12AffineEnvironment.transform 1 3 env31959 = env31960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env31959 == env31960) = true)

theorem identity31960 : scanCanonicalize (H12AffineFastState.compose env31960 (packedSelected [2,3,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound31960 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env31961 : List Nat := [2,3,8,10,1,64,67,66,11,72,74,11,3,1,64,72,74,10,9,65,11,65,10,73,8,1,75,0,1,74,8,10,67,11,74,74]

theorem envBound31961 : H12AffineFastState.Bounded env31961 := by
  intro p hp
  have h : env31961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31960_31961 : H12AffineEnvironment.transform 3 10 env31960 = env31961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env31960 == env31961) = true)

theorem identity31961 : scanCanonicalize (H12AffineFastState.compose env31961 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound31961 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31962 : List Nat := [2,3,3,1,1,64,67,66,0,67,65,0,3,1,64,67,65,1,2,65,0,65,1,66,3,1,64,0,1,65,3,1,67,0,65,65]

theorem envBound31962 : H12AffineFastState.Bounded env31962 := by
  intro p hp
  have h : env31962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31961_31962 : H12AffineEnvironment.transform 2 3 env31961 = env31962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env31961 == env31962) = true)

theorem identity31962 : scanCanonicalize (H12AffineFastState.compose env31962 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound31962 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31963 : List Nat := [2,3,3,1,1,0,3,2,0,3,1,0,3,1,0,3,1,1,2,1,0,1,1,2,3,1,0,0,1,1,3,1,3,0,1,1]

theorem envBound31963 : H12AffineFastState.Bounded env31963 := by
  intro p hp
  have h : env31963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31962_31963 : H12AffineEnvironment.transform 5 0 env31962 = env31963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env31962 == env31963) = true)

theorem identity31963 : scanCanonicalize (H12AffineFastState.compose env31963 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound31963 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31964 : List Nat := [1,0,0,1,1,0,0,1,0,0,1,0,0,1,0,0,1,1,1,1,0,1,1,1,0,1,0,0,1,1,0,1,0,0,1,1]

theorem envBound31964 : H12AffineFastState.Bounded env31964 := by
  intro p hp
  have h : env31964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31963_31964 : H12AffineEnvironment.transform 0 1 env31963 = env31964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env31963 == env31964) = true)

def env31965 : List Nat := [2,4,8,16,32,64,128,256,340,273,2048,2172,25,0,2409,268,107,397,2364,2408,2172,477,42,2400,2237,2135,2370,59,0,306,21,42,257,16,81,2425]

theorem envBound31965 : H12AffineFastState.Bounded env31965 := by
  intro p hp
  have h : env31965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31954_31965 : H12AffineEnvironment.transform 9 273 env31954 = env31965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env31954 == env31965) = true)

theorem identity31965 : scanCanonicalize (H12AffineFastState.compose env31965 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 339) := by decide +kernel

theorem selectedBound31965 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env31966 : List Nat := [2,4,8,16,32,64,128,256,340,273,339,303,25,0,58,268,107,397,111,59,303,477,42,51,494,260,17,59,0,306,21,42,257,16,81,42]

theorem envBound31966 : H12AffineFastState.Bounded env31966 := by
  intro p hp
  have h : env31966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31965_31966 : H12AffineEnvironment.transform 10 339 env31965 = env31966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 339 env31965 == env31966) = true)

theorem identity31966 : scanCanonicalize (H12AffineFastState.compose env31966 (packedSelected [1,3,4,8,9,10,12,16,17] rootPS)) = affineNative (2^(7+1) ^^^ 51) := by decide +kernel

theorem selectedBound31966 : packedSelected [1,3,4,8,9,10,12,16,17] rootPS < 2^1333 := by decide +kernel

def env31967 : List Nat := [2,4,8,16,32,64,128,51,103,34,96,28,25,0,58,63,107,190,111,59,28,238,42,51,221,55,17,59,0,1,21,42,50,16,81,42]

theorem envBound31967 : H12AffineFastState.Bounded env31967 := by
  intro p hp
  have h : env31967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31966_31967 : H12AffineEnvironment.transform 7 51 env31966 = env31967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 51 env31966 == env31967) = true)

theorem identity31967 : scanCanonicalize (H12AffineFastState.compose env31967 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound31967 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env31968 : List Nat := [2,4,8,16,7,64,128,20,64,5,71,28,25,0,29,24,76,153,72,28,28,201,13,20,221,16,17,28,0,1,21,13,21,16,81,13]

theorem envBound31968 : H12AffineFastState.Bounded env31968 := by
  intro p hp
  have h : env31968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31967_31968 : H12AffineEnvironment.transform 4 7 env31967 = env31968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env31967 == env31968) = true)

theorem identity31968 : scanCanonicalize (H12AffineFastState.compose env31968 (packedSelected [0,5,7,8,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 22) := by decide +kernel

theorem selectedBound31968 : packedSelected [0,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env31969 : List Nat := [2,4,8,16,7,22,128,20,22,5,17,28,25,0,29,24,26,153,30,28,28,159,13,20,139,16,17,28,0,1,21,13,21,16,7,13]

theorem envBound31969 : H12AffineFastState.Bounded env31969 := by
  intro p hp
  have h : env31969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31968_31969 : H12AffineEnvironment.transform 5 22 env31968 = env31969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 22 env31968 == env31969) = true)

theorem identity31969 : scanCanonicalize (H12AffineFastState.compose env31969 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound31969 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env31970 : List Nat := [2,4,8,1,7,7,128,5,7,5,0,13,8,0,12,9,11,136,15,13,13,142,13,5,139,1,0,13,0,1,4,13,4,1,7,13]

theorem envBound31970 : H12AffineFastState.Bounded env31970 := by
  intro p hp
  have h : env31970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31969_31970 : H12AffineEnvironment.transform 3 1 env31969 = env31970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env31969 == env31970) = true)

theorem identity31970 : scanCanonicalize (H12AffineFastState.compose env31970 (packedSelected [2,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound31970 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env31971 : List Nat := [2,4,3,1,7,7,128,5,7,5,0,6,3,0,7,2,0,131,4,6,6,133,6,5,128,1,0,6,0,1,4,6,4,1,7,6]

theorem envBound31971 : H12AffineFastState.Bounded env31971 := by
  intro p hp
  have h : env31971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31970_31971 : H12AffineEnvironment.transform 2 3 env31970 = env31971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env31970 == env31971) = true)

theorem identity31971 : scanCanonicalize (H12AffineFastState.compose env31971 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound31971 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31972 : List Nat := [2,4,3,1,7,7,4,5,7,5,0,6,3,0,7,2,0,7,4,6,6,1,6,5,4,1,0,6,0,1,4,6,4,1,7,6]

theorem envBound31972 : H12AffineFastState.Bounded env31972 := by
  intro p hp
  have h : env31972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31971_31972 : H12AffineEnvironment.transform 6 4 env31971 = env31972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env31971 == env31972) = true)

theorem identity31972 : scanCanonicalize (H12AffineFastState.compose env31972 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound31972 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31973 : List Nat := [2,0,3,1,3,3,0,1,3,1,0,2,3,0,3,2,0,3,0,2,2,1,2,1,0,1,0,2,0,1,0,2,0,1,3,2]

theorem envBound31973 : H12AffineFastState.Bounded env31973 := by
  intro p hp
  have h : env31973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31972_31973 : H12AffineEnvironment.transform 1 0 env31972 = env31973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env31972 == env31973) = true)

theorem identity31973 : scanCanonicalize (H12AffineFastState.compose env31973 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound31973 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31974 : List Nat := [0,0,1,1,1,1,0,1,1,1,0,0,1,0,1,0,0,1,0,0,0,1,0,1,0,1,0,0,0,1,0,0,0,1,1,0]

theorem envBound31974 : H12AffineFastState.Bounded env31974 := by
  intro p hp
  have h : env31974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31973_31974 : H12AffineEnvironment.transform 0 0 env31973 = env31974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env31973 == env31974) = true)

def env31975 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,3436,25,1297,2408,1053,107,1180,3116,2409,3436,477,1339,2401,2236,3399,3154,59,1297,1058,21,1339,257,1281,1344,2425]

theorem envBound31975 : H12AffineFastState.Bounded env31975 := by
  intro p hp
  have h : env31975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31953_31975 : H12AffineEnvironment.transform 8 341 env31953 = env31975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env31953 == env31975) = true)

def env31976 : List Nat := [2,4,8,16,32,64,128,256,341,272,2048,2172,25,1,2408,269,107,396,2364,2409,2172,477,43,2401,2236,2135,2370,59,1,306,21,43,257,17,80,2425]

theorem envBound31976 : H12AffineFastState.Bounded env31976 := by
  intro p hp
  have h : env31976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31975_31976 : H12AffineEnvironment.transform 9 272 env31975 = env31976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env31975 == env31976) = true)

theorem identity31976 : scanCanonicalize (H12AffineFastState.compose env31976 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 126) := by decide +kernel

theorem selectedBound31976 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env31977 : List Nat := [2,4,8,16,32,64,128,126,43,110,2048,2172,25,1,2070,115,107,242,2114,2071,2172,163,43,2079,2236,2135,2108,59,1,76,21,43,127,17,80,2055]

theorem envBound31977 : H12AffineFastState.Bounded env31977 := by
  intro p hp
  have h : env31977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31976_31977 : H12AffineEnvironment.transform 7 126 env31976 = env31977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 126 env31976 == env31977) = true)

theorem identity31977 : scanCanonicalize (H12AffineFastState.compose env31977 (packedSelected [0,1,4,5,7,8,9,12,16,17,20] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound31977 : packedSelected [0,1,4,5,7,8,9,12,16,17,20] rootPS < 2^1333 := by decide +kernel

def env31978 : List Nat := [2,4,8,16,0,64,128,94,11,78,2048,2140,25,1,2070,83,75,210,2114,2071,2140,131,11,2079,2204,2135,2076,27,1,76,21,11,95,17,80,2055]

theorem envBound31978 : H12AffineFastState.Bounded env31978 := by
  intro p hp
  have h : env31978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31977_31978 : H12AffineEnvironment.transform 4 0 env31977 = env31978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env31977 == env31978) = true)

theorem identity31978 : scanCanonicalize (H12AffineFastState.compose env31978 (packedSelected [0,3,5,7,10,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 29) := by decide +kernel

theorem selectedBound31978 : packedSelected [0,3,5,7,10,13,17,18] rootPS < 2^1333 := by decide +kernel

def env31979 : List Nat := [2,4,8,16,0,64,128,94,11,78,29,65,25,1,11,83,75,210,95,10,65,131,11,2,129,74,1,27,1,76,21,11,95,17,80,26]

theorem envBound31979 : H12AffineFastState.Bounded env31979 := by
  intro p hp
  have h : env31979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31978_31979 : H12AffineEnvironment.transform 10 29 env31978 = env31979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 29 env31978 == env31979) = true)

theorem identity31979 : scanCanonicalize (H12AffineFastState.compose env31979 (packedSelected [0,2,3,7,12] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound31979 : packedSelected [0,2,3,7,12] rootPS < 2^1333 := by decide +kernel

def env31980 : List Nat := [2,4,4,16,0,64,128,82,7,66,17,65,21,1,7,83,71,210,83,6,65,131,7,2,129,70,1,23,1,64,21,7,83,17,80,22]

theorem envBound31980 : H12AffineFastState.Bounded env31980 := by
  intro p hp
  have h : env31980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31979_31980 : H12AffineEnvironment.transform 2 4 env31979 = env31980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env31979 == env31980) = true)

theorem identity31980 : scanCanonicalize (H12AffineFastState.compose env31980 (packedSelected [0,2,7] rootPS)) = affineNative (2^(6+1) ^^^ 85) := by decide +kernel

theorem selectedBound31980 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env31981 : List Nat := [2,4,4,16,0,64,85,82,7,66,17,65,21,1,7,83,71,7,83,6,65,86,7,2,84,70,1,23,1,64,21,7,83,17,80,22]

theorem envBound31981 : H12AffineFastState.Bounded env31981 := by
  intro p hp
  have h : env31981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31980_31981 : H12AffineEnvironment.transform 6 85 env31980 = env31981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 85 env31980 == env31981) = true)

theorem identity31981 : scanCanonicalize (H12AffineFastState.compose env31981 (packedSelected [0,2,4] rootPS)) = affineNative (2^(5+1) ^^^ 7) := by decide +kernel

theorem selectedBound31981 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env31982 : List Nat := [2,4,4,16,0,7,18,21,7,5,17,6,21,1,7,20,0,7,20,6,6,17,7,2,19,1,1,23,1,7,21,7,20,17,23,22]

theorem envBound31982 : H12AffineFastState.Bounded env31982 := by
  intro p hp
  have h : env31982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31981_31982 : H12AffineEnvironment.transform 5 7 env31981 = env31982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 7 env31981 == env31982) = true)

theorem identity31982 : scanCanonicalize (H12AffineFastState.compose env31982 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound31982 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env31983 : List Nat := [2,3,3,16,0,0,18,18,0,2,17,1,18,1,0,19,0,0,19,1,1,17,0,2,19,1,1,16,1,0,18,0,19,17,16,17]

theorem envBound31983 : H12AffineFastState.Bounded env31983 := by
  intro p hp
  have h : env31983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31982_31983 : H12AffineEnvironment.transform 1 3 env31982 = env31983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env31982 == env31983) = true)

def env31984 : List Nat := [2,4,8,16,32,64,128,256,341,273,2048,2173,25,0,2408,268,107,397,2365,2409,2173,477,42,2401,2236,2134,2371,59,0,307,21,42,257,16,81,2425]

theorem envBound31984 : H12AffineFastState.Bounded env31984 := by
  intro p hp
  have h : env31984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31975_31984 : H12AffineEnvironment.transform 9 273 env31975 = env31984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env31975 == env31984) = true)

theorem identity31984 : scanCanonicalize (H12AffineFastState.compose env31984 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 338) := by decide +kernel

theorem selectedBound31984 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env31985 : List Nat := [2,4,8,16,32,64,128,256,341,273,338,303,25,0,58,268,107,397,111,59,303,477,42,51,494,260,17,59,0,307,21,42,257,16,81,43]

theorem envBound31985 : H12AffineFastState.Bounded env31985 := by
  intro p hp
  have h : env31985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31984_31985 : H12AffineEnvironment.transform 10 338 env31984 = env31985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 338 env31984 == env31985) = true)

theorem identity31985 : scanCanonicalize (H12AffineFastState.compose env31985 (packedSelected [1,3,4,8,9,10,12,16,17] rootPS)) = affineNative (2^(7+1) ^^^ 51) := by decide +kernel

theorem selectedBound31985 : packedSelected [1,3,4,8,9,10,12,16,17] rootPS < 2^1333 := by decide +kernel

def env31986 : List Nat := [2,4,8,16,32,64,128,51,102,34,97,28,25,0,58,63,107,190,111,59,28,238,42,51,221,55,17,59,0,0,21,42,50,16,81,43]

theorem envBound31986 : H12AffineFastState.Bounded env31986 := by
  intro p hp
  have h : env31986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31985_31986 : H12AffineEnvironment.transform 7 51 env31985 = env31986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 51 env31985 == env31986) = true)

theorem identity31986 : scanCanonicalize (H12AffineFastState.compose env31986 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound31986 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env31987 : List Nat := [2,4,8,16,7,64,128,20,65,5,70,28,25,0,29,24,76,153,72,28,28,201,13,20,221,16,17,28,0,0,21,13,21,16,81,12]

theorem envBound31987 : H12AffineFastState.Bounded env31987 := by
  intro p hp
  have h : env31987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31986_31987 : H12AffineEnvironment.transform 4 7 env31986 = env31987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env31986 == env31987) = true)

theorem identity31987 : scanCanonicalize (H12AffineFastState.compose env31987 (packedSelected [0,5,7,8,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 22) := by decide +kernel

theorem selectedBound31987 : packedSelected [0,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env31988 : List Nat := [2,4,8,16,7,22,128,20,23,5,16,28,25,0,29,24,26,153,30,28,28,159,13,20,139,16,17,28,0,0,21,13,21,16,7,12]

theorem envBound31988 : H12AffineFastState.Bounded env31988 := by
  intro p hp
  have h : env31988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31987_31988 : H12AffineEnvironment.transform 5 22 env31987 = env31988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 22 env31987 == env31988) = true)

theorem identity31988 : scanCanonicalize (H12AffineFastState.compose env31988 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound31988 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env31989 : List Nat := [2,4,8,16,7,22,4,20,23,5,16,28,25,0,29,24,26,29,30,28,28,27,13,20,15,16,17,28,0,0,21,13,21,16,7,12]

theorem envBound31989 : H12AffineFastState.Bounded env31989 := by
  intro p hp
  have h : env31989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31988_31989 : H12AffineEnvironment.transform 6 4 env31988 = env31989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env31988 == env31989) = true)

def env31990 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,524288,32769,4096,61649,91182,123165,533641,614526,385202,90414,545088,96347,25884,82998,257,545104,1344,525824]

theorem envBound31990 : H12AffineFastState.Bounded env31990 := by
  intro p hp
  have h : env31990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31452_31990 : H12AffineEnvironment.transform 23 123165 env31452 = env31990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123165 env31452 == env31990) = true)

def env31991 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21584,32769,4096,61649,91182,123165,28889,78894,385202,90414,1296,96347,25884,82998,257,1280,1344,21072]

theorem envBound31991 : H12AffineFastState.Bounded env31991 := by
  intro p hp
  have h : env31991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31990_31991 : H12AffineEnvironment.transform 18 21584 env31990 = env31991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env31990 == env31991) = true)

theorem identity31991 : scanCanonicalize (H12AffineFastState.compose env31991 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25676) := by decide +kernel

theorem selectedBound31991 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env31992 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25676,65536,74863,262144,21584,25677,4096,5277,91182,66897,28889,78894,328958,90414,1296,96347,25884,82998,257,1280,1344,21072]

theorem envBound31992 : H12AffineFastState.Bounded env31992 := by
  intro p hp
  have h : env31992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31991_31992 : H12AffineEnvironment.transform 14 25676 env31991 = env31992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25676 env31991 == env31992) = true)

def env31993 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74863,262144,4416,8541,4096,5277,74046,66897,13769,78894,328958,74814,1296,81227,8204,65830,257,1280,1344,5952]

theorem envBound31993 : H12AffineFastState.Bounded env31993 := by
  intro p hp
  have h : env31993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31992_31993 : H12AffineEnvironment.transform 13 1296 env31992 = env31993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env31992 == env31993) = true)

def env31994 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74863,65664,4416,8541,4096,5277,74046,66897,13769,78894,1150,74814,1296,81227,8204,65830,257,1280,1344,5952]

theorem envBound31994 : H12AffineFastState.Bounded env31994 := by
  intro p hp
  have h : env31994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31993_31994 : H12AffineEnvironment.transform 17 65664 env31993 = env31994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env31993 == env31994) = true)

theorem identity31994 : scanCanonicalize (H12AffineFastState.compose env31994 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12670) := by decide +kernel

theorem selectedBound31994 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env31995 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,12670,5393,12798,4416,8541,4096,5277,4160,13359,13769,1360,1150,5440,1296,3125,8204,12376,257,1280,1344,5952]

theorem envBound31995 : H12AffineFastState.Bounded env31995 := by
  intro p hp
  have h : env31995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31994_31995 : H12AffineEnvironment.transform 15 12670 env31994 = env31995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12670 env31994 == env31995) = true)

def env31996 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1296,8540,8494,1345,8622,272,8541,80,1229,16,9343,9625,1360,1150,1296,1296,3125,8204,8200,257,1280,1344,1808]

theorem envBound31996 : H12AffineFastState.Bounded env31996 := by
  intro p hp
  have h : env31996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31995_31996 : H12AffineEnvironment.transform 11 80 env31995 = env31996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env31995 == env31996) = true)

theorem identity31996 : scanCanonicalize (H12AffineFastState.compose env31996 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound31996 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env31997 : List Nat := [2,4,8,16,32,64,128,21,512,1024,2048,80,8192,1029,8265,8251,1108,8379,5,8264,80,1229,16,9343,9356,1093,1150,1029,1029,3125,8204,8200,20,1045,1109,1541]

theorem envBound31997 : H12AffineFastState.Bounded env31997 := by
  intro p hp
  have h : env31997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31996_31997 : H12AffineEnvironment.transform 7 21 env31996 = env31997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env31996 == env31997) = true)

theorem identity31997 : scanCanonicalize (H12AffineFastState.compose env31997 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound31997 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env31998 : List Nat := [2,4,8,16,32,64,128,21,512,5,2048,80,8192,0,8265,8251,81,8379,5,8264,80,200,16,8314,8329,64,123,0,0,2096,8204,8200,20,16,80,512]

theorem envBound31998 : H12AffineFastState.Bounded env31998 := by
  intro p hp
  have h : env31998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31997_31998 : H12AffineEnvironment.transform 9 5 env31997 = env31998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env31997 == env31998) = true)

theorem identity31998 : scanCanonicalize (H12AffineFastState.compose env31998 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound31998 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env31999 : List Nat := [2,4,8,16,32,17,128,21,512,5,2048,1,8192,0,8216,8251,0,8379,5,8217,1,153,16,8235,8329,17,42,0,0,2096,8204,8200,20,16,1,512]

theorem envBound31999 : H12AffineFastState.Bounded env31999 := by
  intro p hp
  have h : env31999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31998_31999 : H12AffineEnvironment.transform 5 17 env31998 = env31999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31998 == env31999) = true)

theorem identity31999 : scanCanonicalize (H12AffineFastState.compose env31999 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound31999 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32000 : List Nat := [2,4,8,16,32,17,128,21,512,5,513,1,8192,0,8216,8251,0,8379,5,8217,1,153,16,8235,8329,17,42,0,0,561,8204,8200,20,16,1,512]

theorem envBound32000 : H12AffineFastState.Bounded env32000 := by
  intro p hp
  have h : env32000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31999_32000 : H12AffineEnvironment.transform 10 513 env31999 = env32000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env31999 == env32000) = true)

theorem identity32000 : scanCanonicalize (H12AffineFastState.compose env32000 (packedSelected [3,8] rootPS)) = affineNative (2^(12+1) ^^^ 139) := by decide +kernel

theorem selectedBound32000 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env32001 : List Nat := [2,4,8,16,32,17,128,21,512,5,513,1,139,0,147,176,0,48,5,146,1,153,16,160,2,17,42,0,0,561,135,131,20,16,1,512]

theorem envBound32001 : H12AffineFastState.Bounded env32001 := by
  intro p hp
  have h : env32001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32000_32001 : H12AffineEnvironment.transform 12 139 env32000 = env32001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 139 env32000 == env32001) = true)

theorem identity32001 : scanCanonicalize (H12AffineFastState.compose env32001 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound32001 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32002 : List Nat := [2,4,8,16,32,17,128,21,136,5,137,1,139,0,147,176,0,48,5,146,1,153,16,160,2,17,42,0,0,185,135,131,20,16,1,136]

theorem envBound32002 : H12AffineFastState.Bounded env32002 := by
  intro p hp
  have h : env32002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32001_32002 : H12AffineEnvironment.transform 8 136 env32001 = env32002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env32001 == env32002) = true)

theorem identity32002 : scanCanonicalize (H12AffineFastState.compose env32002 (packedSelected [1,4] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound32002 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env32003 : List Nat := [2,4,8,16,10,17,128,21,136,5,137,1,139,0,147,154,0,26,5,146,1,153,16,138,2,17,0,0,0,147,135,131,20,16,1,136]

theorem envBound32003 : H12AffineFastState.Bounded env32003 := by
  intro p hp
  have h : env32003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32002_32003 : H12AffineEnvironment.transform 4 10 env32002 = env32003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env32002 == env32003) = true)

theorem identity32003 : scanCanonicalize (H12AffineFastState.compose env32003 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound32003 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env32004 : List Nat := [2,4,8,16,10,17,8,21,0,5,1,1,3,0,27,18,0,26,5,26,1,17,16,2,2,17,0,0,0,27,15,11,20,16,1,0]

theorem envBound32004 : H12AffineFastState.Bounded env32004 := by
  intro p hp
  have h : env32004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32003_32004 : H12AffineEnvironment.transform 6 8 env32003 = env32004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32003 == env32004) = true)

theorem identity32004 : scanCanonicalize (H12AffineFastState.compose env32004 (packedSelected [0,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound32004 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env32005 : List Nat := [2,4,8,11,10,10,8,14,0,5,1,1,3,0,0,9,0,1,5,1,1,10,11,2,2,10,0,0,0,0,15,11,15,11,1,0]

theorem envBound32005 : H12AffineFastState.Bounded env32005 := by
  intro p hp
  have h : env32005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32004_32005 : H12AffineEnvironment.transform 3 11 env32004 = env32005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env32004 == env32005) = true)

theorem identity32005 : scanCanonicalize (H12AffineFastState.compose env32005 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound32005 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32006 : List Nat := [2,4,4,7,6,6,4,2,0,5,1,1,3,0,0,5,0,1,5,1,1,6,7,2,2,6,0,0,0,0,3,7,3,7,1,0]

theorem envBound32006 : H12AffineFastState.Bounded env32006 := by
  intro p hp
  have h : env32006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32005_32006 : H12AffineEnvironment.transform 2 4 env32005 = env32006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env32005 == env32006) = true)

def env32007 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1296,8540,8495,1344,8623,273,8541,81,1228,17,9342,9624,1360,1150,1297,1296,3125,8204,8201,257,1280,1344,1809]

theorem envBound32007 : H12AffineFastState.Bounded env32007 := by
  intro p hp
  have h : env32007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31995_32007 : H12AffineEnvironment.transform 11 81 env31995 = env32007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env31995 == env32007) = true)

theorem identity32007 : scanCanonicalize (H12AffineFastState.compose env32007 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 72) := by decide +kernel

theorem selectedBound32007 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env32008 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,72,1296,276,359,1344,487,273,277,81,1228,17,1078,1488,1360,1150,1297,1296,3125,68,65,257,1280,1344,1809]

theorem envBound32008 : H12AffineFastState.Bounded env32008 := by
  intro p hp
  have h : env32008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32007_32008 : H12AffineEnvironment.transform 12 72 env32007 = env32008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env32007 == env32008) = true)

theorem identity32008 : scanCanonicalize (H12AffineFastState.compose env32008 (packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS)) = affineNative (2^(9+1) ^^^ 733) := by decide +kernel

theorem selectedBound32008 : packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS < 2^1333 := by decide +kernel

def env32009 : List Nat := [2,4,8,16,32,64,128,256,512,733,2048,81,72,973,276,359,925,487,273,277,81,529,17,747,781,909,675,972,973,2792,68,65,257,989,925,460]

theorem envBound32009 : H12AffineFastState.Bounded env32009 := by
  intro p hp
  have h : env32009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32008_32009 : H12AffineEnvironment.transform 9 733 env32008 = env32009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 733 env32008 == env32009) = true)

theorem identity32009 : scanCanonicalize (H12AffineFastState.compose env32009 (packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound32009 : packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS < 2^1333 := by decide +kernel

def env32010 : List Nat := [2,4,8,16,32,64,128,256,136,85,2048,81,72,325,276,359,277,487,273,277,81,153,17,99,389,261,43,324,325,2144,68,65,257,341,277,460]

theorem envBound32010 : H12AffineFastState.Bounded env32010 := by
  intro p hp
  have h : env32010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32009_32010 : H12AffineEnvironment.transform 8 136 env32009 = env32010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env32009 == env32010) = true)

theorem identity32010 : scanCanonicalize (H12AffineFastState.compose env32010 (packedSelected [0,3,4,5,7,9,11,13,16,17] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound32010 : packedSelected [0,3,4,5,7,9,11,13,16,17] rootPS < 2^1333 := by decide +kernel

def env32011 : List Nat := [2,4,8,11,32,64,128,256,136,78,2048,74,72,325,271,359,270,487,266,270,74,130,10,99,389,261,43,324,325,2144,68,65,257,334,270,460]

theorem envBound32011 : H12AffineFastState.Bounded env32011 := by
  intro p hp
  have h : env32011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32010_32011 : H12AffineEnvironment.transform 3 11 env32010 = env32011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env32010 == env32011) = true)

theorem identity32011 : scanCanonicalize (H12AffineFastState.compose env32011 (packedSelected [0,2,7,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 486) := by decide +kernel

theorem selectedBound32011 : packedSelected [0,2,7,11,13] rootPS < 2^1333 := by decide +kernel

def env32012 : List Nat := [2,4,8,11,32,64,128,256,136,78,486,74,72,325,271,359,270,487,266,270,74,130,10,99,389,261,43,324,325,390,68,65,257,334,270,460]

theorem envBound32012 : H12AffineFastState.Bounded env32012 := by
  intro p hp
  have h : env32012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32011_32012 : H12AffineEnvironment.transform 10 486 env32011 = env32012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 486 env32011 == env32012) = true)

theorem identity32012 : scanCanonicalize (H12AffineFastState.compose env32012 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound32012 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env32013 : List Nat := [2,4,8,11,32,64,105,256,97,78,271,74,72,325,271,359,270,270,266,270,74,107,10,99,364,261,43,324,325,367,68,65,257,334,270,293]

theorem envBound32013 : H12AffineFastState.Bounded env32013 := by
  intro p hp
  have h : env32013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32012_32013 : H12AffineEnvironment.transform 6 105 env32012 = env32013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env32012 == env32013) = true)

theorem identity32013 : scanCanonicalize (H12AffineFastState.compose env32013 (packedSelected [1,2,8] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound32013 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env32014 : List Nat := [2,4,8,11,10,64,67,256,75,78,271,74,72,325,271,333,270,270,266,270,74,65,10,73,326,261,1,324,325,325,68,65,257,334,270,271]

theorem envBound32014 : H12AffineFastState.Bounded env32014 := by
  intro p hp
  have h : env32014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32013_32014 : H12AffineEnvironment.transform 4 10 env32013 = env32014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env32013 == env32014) = true)

def env32015 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74863,65665,4416,8541,4096,5277,74046,66897,13769,78894,1151,74814,1296,81227,8204,65830,257,1280,1344,5952]

theorem envBound32015 : H12AffineFastState.Bounded env32015 := by
  intro p hp
  have h : env32015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31993_32015 : H12AffineEnvironment.transform 17 65665 env31993 = env32015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env31993 == env32015) = true)

theorem identity32015 : scanCanonicalize (H12AffineFastState.compose env32015 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9279) := by decide +kernel

theorem selectedBound32015 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env32016 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,9279,80,9406,4416,8541,4096,5277,1281,8558,13769,4113,1151,1,1296,6516,8204,9497,257,1280,1344,5952]

theorem envBound32016 : H12AffineFastState.Bounded env32016 := by
  intro p hp
  have h : env32016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32015_32016 : H12AffineEnvironment.transform 15 9279 env32015 = env32016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9279 env32015 == env32016) = true)

def env32017 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,0,8540,8495,80,8622,4416,8541,4096,4493,17,8558,12505,4113,367,1,0,6516,8204,8201,257,16,80,4688]

theorem envBound32017 : H12AffineFastState.Bounded env32017 := by
  intro p hp
  have h : env32017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32016_32017 : H12AffineEnvironment.transform 9 272 env32016 = env32017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env32016 == env32017) = true)

theorem identity32017 : scanCanonicalize (H12AffineFastState.compose env32017 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 4121) := by decide +kernel

theorem selectedBound32017 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env32018 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,4121,0,4421,4406,80,4535,4416,4420,4096,4493,17,4471,192,4113,367,1,0,6516,4117,4112,257,16,80,4688]

theorem envBound32018 : H12AffineFastState.Bounded env32018 := by
  intro p hp
  have h : env32018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32017_32018 : H12AffineEnvironment.transform 12 4121 env32017 = env32018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4121 env32017 == env32018) = true)

theorem identity32018 : scanCanonicalize (H12AffineFastState.compose env32018 (packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS)) = affineNative (2^(8+1) ^^^ 461) := by decide +kernel

theorem selectedBound32018 : packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS < 2^1333 := by decide +kernel

def env32019 : List Nat := [2,4,8,16,32,64,128,256,461,272,2048,4096,4121,0,4421,4406,80,4535,4416,4420,4096,4493,17,4471,192,4113,367,1,0,6516,4117,4112,257,16,80,4509]

theorem envBound32019 : H12AffineFastState.Bounded env32019 := by
  intro p hp
  have h : env32019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32018_32019 : H12AffineEnvironment.transform 8 461 env32018 = env32019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 461 env32018 == env32019) = true)

theorem identity32019 : scanCanonicalize (H12AffineFastState.compose env32019 (packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound32019 : packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS < 2^1333 := by decide +kernel

def env32020 : List Nat := [2,4,8,16,32,64,128,69,136,85,2048,4096,4121,0,4096,4211,80,4338,4101,4097,4096,4296,17,4146,192,4113,42,1,0,6193,4117,4112,68,16,80,4312]

theorem envBound32020 : H12AffineFastState.Bounded env32020 := by
  intro p hp
  have h : env32020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32019_32020 : H12AffineEnvironment.transform 7 69 env32019 = env32020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env32019 == env32020) = true)

theorem identity32020 : scanCanonicalize (H12AffineFastState.compose env32020 (packedSelected [0,3,5,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound32020 : packedSelected [0,3,5,7,11] rootPS < 2^1333 := by decide +kernel

def env32021 : List Nat := [2,4,8,16,32,64,128,69,136,85,48,4096,4121,0,4096,4211,80,4338,4101,4097,4096,4296,17,4146,192,4113,42,1,0,4097,4117,4112,68,16,80,4312]

theorem envBound32021 : H12AffineFastState.Bounded env32021 := by
  intro p hp
  have h : env32021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32020_32021 : H12AffineEnvironment.transform 10 48 env32020 = env32021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env32020 == env32021) = true)

theorem identity32021 : scanCanonicalize (H12AffineFastState.compose env32021 (packedSelected [1,2,4,5,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 96) := by decide +kernel

theorem selectedBound32021 : packedSelected [1,2,4,5,9,16] rootPS < 2^1333 := by decide +kernel

def env32022 : List Nat := [2,4,8,16,32,64,128,69,136,85,48,96,121,0,96,19,80,146,101,97,96,168,17,82,192,113,42,1,0,97,117,112,68,16,80,184]

theorem envBound32022 : H12AffineFastState.Bounded env32022 := by
  intro p hp
  have h : env32022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32021_32022 : H12AffineEnvironment.transform 11 96 env32021 = env32022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 96 env32021 == env32022) = true)

theorem identity32022 : scanCanonicalize (H12AffineFastState.compose env32022 (packedSelected [1,2,3,4,5,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound32022 : packedSelected [1,2,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env32023 : List Nat := [2,4,8,16,32,16,128,21,136,5,48,48,41,0,48,19,0,146,53,49,48,168,17,2,144,33,42,1,0,49,37,32,20,16,0,184]

theorem envBound32023 : H12AffineFastState.Bounded env32023 := by
  intro p hp
  have h : env32023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32022_32023 : H12AffineEnvironment.transform 5 16 env32022 = env32023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32022 == env32023) = true)

theorem identity32023 : scanCanonicalize (H12AffineFastState.compose env32023 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound32023 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env32024 : List Nat := [2,4,5,16,32,16,128,21,133,5,48,48,36,0,48,19,0,146,53,49,48,165,17,2,144,33,39,1,0,49,37,32,20,16,0,181]

theorem envBound32024 : H12AffineFastState.Bounded env32024 := by
  intro p hp
  have h : env32024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32023_32024 : H12AffineEnvironment.transform 2 5 env32023 = env32024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env32023 == env32024) = true)

theorem identity32024 : scanCanonicalize (H12AffineFastState.compose env32024 (packedSelected [1,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound32024 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env32025 : List Nat := [2,4,5,16,16,16,128,21,133,5,0,0,20,0,0,19,0,146,5,1,0,149,17,2,144,17,23,1,0,1,21,16,20,16,0,133]

theorem envBound32025 : H12AffineFastState.Bounded env32025 := by
  intro p hp
  have h : env32025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32024_32025 : H12AffineEnvironment.transform 4 16 env32024 = env32025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env32024 == env32025) = true)

theorem identity32025 : scanCanonicalize (H12AffineFastState.compose env32025 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound32025 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32026 : List Nat := [2,4,5,7,7,7,128,2,133,5,0,0,3,0,0,4,0,133,5,1,0,130,6,2,135,6,0,1,0,1,2,7,3,7,0,133]

theorem envBound32026 : H12AffineFastState.Bounded env32026 := by
  intro p hp
  have h : env32026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32025_32026 : H12AffineEnvironment.transform 3 7 env32025 = env32026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env32025 == env32026) = true)

theorem identity32026 : scanCanonicalize (H12AffineFastState.compose env32026 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound32026 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32027 : List Nat := [2,4,5,7,7,7,4,2,1,5,0,0,3,0,0,4,0,1,5,1,0,6,6,2,3,6,0,1,0,1,2,7,3,7,0,1]

theorem envBound32027 : H12AffineFastState.Bounded env32027 := by
  intro p hp
  have h : env32027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32026_32027 : H12AffineEnvironment.transform 6 4 env32026 = env32027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env32026 == env32027) = true)

def env32028 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,1,8540,8494,80,8623,4416,8541,4096,4492,16,8558,12504,4113,366,1,1,6516,8204,8200,257,17,81,4689]

theorem envBound32028 : H12AffineFastState.Bounded env32028 := by
  intro p hp
  have h : env32028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32016_32028 : H12AffineEnvironment.transform 9 273 env32016 = env32028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env32016 == env32028) = true)

theorem identity32028 : scanCanonicalize (H12AffineFastState.compose env32028 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 325) := by decide +kernel

theorem selectedBound32028 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env32029 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,325,8192,1,8540,8494,80,8623,5,8541,325,201,16,8558,8605,340,366,1,1,2097,8204,8200,257,17,81,788]

theorem envBound32029 : H12AffineFastState.Bounded env32029 := by
  intro p hp
  have h : env32029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32028_32029 : H12AffineEnvironment.transform 11 325 env32028 = env32029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 325 env32028 == env32029) = true)

theorem identity32029 : scanCanonicalize (H12AffineFastState.compose env32029 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound32029 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env32030 : List Nat := [2,4,8,16,32,64,128,20,512,5,2048,81,8192,1,8264,8250,80,8379,5,8265,81,201,16,8314,8329,64,122,1,1,2097,8204,8200,21,17,81,512]

theorem envBound32030 : H12AffineFastState.Bounded env32030 := by
  intro p hp
  have h : env32030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32029_32030 : H12AffineEnvironment.transform 7 20 env32029 = env32030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env32029 == env32030) = true)

theorem identity32030 : scanCanonicalize (H12AffineFastState.compose env32030 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound32030 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env32031 : List Nat := [2,4,8,16,32,17,128,20,512,5,2048,0,8192,1,8217,8250,1,8379,5,8216,0,152,16,8235,8329,17,43,1,1,2097,8204,8200,21,17,0,512]

theorem envBound32031 : H12AffineFastState.Bounded env32031 := by
  intro p hp
  have h : env32031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32030_32031 : H12AffineEnvironment.transform 5 17 env32030 = env32031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32030 == env32031) = true)

theorem identity32031 : scanCanonicalize (H12AffineFastState.compose env32031 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound32031 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32032 : List Nat := [2,4,8,16,32,17,128,20,512,5,512,0,8192,1,8217,8250,1,8379,5,8216,0,152,16,8235,8329,17,43,1,1,561,8204,8200,21,17,0,512]

theorem envBound32032 : H12AffineFastState.Bounded env32032 := by
  intro p hp
  have h : env32032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32031_32032 : H12AffineEnvironment.transform 10 512 env32031 = env32032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env32031 == env32032) = true)

theorem identity32032 : scanCanonicalize (H12AffineFastState.compose env32032 (packedSelected [3,8] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound32032 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env32033 : List Nat := [2,4,8,16,32,17,128,20,1,5,1,0,8192,1,8217,8250,1,8379,5,8216,0,152,16,8235,8329,17,43,1,1,48,8204,8200,21,17,0,1]

theorem envBound32033 : H12AffineFastState.Bounded env32033 := by
  intro p hp
  have h : env32033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32032_32033 : H12AffineEnvironment.transform 8 1 env32032 = env32033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env32032 == env32033) = true)

theorem identity32033 : scanCanonicalize (H12AffineFastState.compose env32033 (packedSelected [0,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound32033 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env32034 : List Nat := [2,4,8,16,16,17,128,20,1,5,1,0,8192,1,8217,8202,1,8331,5,8216,0,152,16,8219,8329,17,27,1,1,0,8204,8200,21,17,0,1]

theorem envBound32034 : H12AffineFastState.Bounded env32034 := by
  intro p hp
  have h : env32034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32033_32034 : H12AffineEnvironment.transform 4 16 env32033 = env32034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env32033 == env32034) = true)

theorem identity32034 : scanCanonicalize (H12AffineFastState.compose env32034 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 144) := by decide +kernel

theorem selectedBound32034 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32035 : List Nat := [2,4,8,16,16,17,128,20,1,5,1,0,144,1,137,154,1,27,5,136,0,152,16,139,25,17,27,1,1,0,156,152,21,17,0,1]

theorem envBound32035 : H12AffineFastState.Bounded env32035 := by
  intro p hp
  have h : env32035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32034_32035 : H12AffineEnvironment.transform 12 144 env32034 = env32035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 144 env32034 == env32035) = true)

theorem identity32035 : scanCanonicalize (H12AffineFastState.compose env32035 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound32035 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env32036 : List Nat := [2,4,8,16,16,17,9,20,1,5,1,0,25,1,0,19,1,27,5,1,0,17,16,2,25,17,27,1,1,0,21,17,21,17,0,1]

theorem envBound32036 : H12AffineFastState.Bounded env32036 := by
  intro p hp
  have h : env32036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32035_32036 : H12AffineEnvironment.transform 6 9 env32035 = env32036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32035 == env32036) = true)

theorem identity32036 : scanCanonicalize (H12AffineFastState.compose env32036 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound32036 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32037 : List Nat := [2,4,4,16,16,17,5,20,1,5,1,0,21,1,0,19,1,23,5,1,0,17,16,2,21,17,23,1,1,0,21,17,21,17,0,1]

theorem envBound32037 : H12AffineFastState.Bounded env32037 := by
  intro p hp
  have h : env32037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32036_32037 : H12AffineEnvironment.transform 2 4 env32036 = env32037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env32036 == env32037) = true)

def env32038 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74863,262144,4417,8540,4096,5277,74047,66897,13768,78894,328958,74815,1296,81226,8205,65831,257,1280,1344,5953]

theorem envBound32038 : H12AffineFastState.Bounded env32038 := by
  intro p hp
  have h : env32038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31992_32038 : H12AffineEnvironment.transform 13 1297 env31992 = env32038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env31992 == env32038) = true)

def env32039 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74863,65664,4417,8540,4096,5277,74047,66897,13768,78894,1150,74815,1296,81226,8205,65831,257,1280,1344,5953]

theorem envBound32039 : H12AffineFastState.Bounded env32039 := by
  intro p hp
  have h : env32039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32038_32039 : H12AffineEnvironment.transform 17 65664 env32038 = env32039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env32038 == env32039) = true)

theorem identity32039 : scanCanonicalize (H12AffineFastState.compose env32039 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 311) := by decide +kernel

theorem selectedBound32039 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env32040 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,311,9560,439,4417,8540,4096,5277,8200,1126,13768,13593,1150,9480,1296,15485,8205,16,257,1280,1344,5953]

theorem envBound32040 : H12AffineFastState.Bounded env32040 := by
  intro p hp
  have h : env32040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32039_32040 : H12AffineEnvironment.transform 15 311 env32039 = env32040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 311 env32039 == env32040) = true)

def env32041 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,8541,311,9560,439,1025,8540,1344,477,8200,1126,8328,8281,1150,9480,1296,10557,8205,16,257,1280,1344,513]

theorem envBound32041 : H12AffineFastState.Bounded env32041 := by
  intro p hp
  have h : env32041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32040_32041 : H12AffineEnvironment.transform 11 1344 env32040 = env32041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env32040 == env32041) = true)

theorem identity32041 : scanCanonicalize (H12AffineFastState.compose env32041 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound32041 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env32042 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,325,8192,276,8541,311,8541,439,4,8540,325,477,8200,99,8328,8281,123,8461,277,10557,8205,16,257,261,325,513]

theorem envBound32042 : H12AffineFastState.Bounded env32042 := by
  intro p hp
  have h : env32042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32041_32042 : H12AffineEnvironment.transform 9 5 env32041 = env32042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env32041 == env32042) = true)

theorem identity32042 : scanCanonicalize (H12AffineFastState.compose env32042 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound32042 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env32043 : List Nat := [2,4,8,16,32,64,128,69,512,5,2048,0,8192,81,8216,114,8216,242,4,8217,0,152,8200,99,8328,8281,123,8264,80,10360,8205,16,68,64,0,513]

theorem envBound32043 : H12AffineFastState.Bounded env32043 := by
  intro p hp
  have h : env32043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32042_32043 : H12AffineEnvironment.transform 7 69 env32042 = env32043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env32042 == env32043) = true)

theorem identity32043 : scanCanonicalize (H12AffineFastState.compose env32043 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 89) := by decide +kernel

theorem selectedBound32043 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32044 : List Nat := [2,4,8,16,32,64,128,69,512,5,2048,0,89,81,65,114,65,242,4,64,0,152,81,99,209,0,123,17,80,2081,84,16,68,64,0,513]

theorem envBound32044 : H12AffineFastState.Bounded env32044 := by
  intro p hp
  have h : env32044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32043_32044 : H12AffineEnvironment.transform 12 89 env32043 = env32044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 89 env32043 == env32044) = true)

theorem identity32044 : scanCanonicalize (H12AffineFastState.compose env32044 (packedSelected [0,1,5,7,8,11,12,17] rootPS)) = affineNative (2^(8+1) ^^^ 197) := by decide +kernel

theorem selectedBound32044 : packedSelected [0,1,5,7,8,11,12,17] rootPS < 2^1333 := by decide +kernel

def env32045 : List Nat := [2,4,8,16,32,64,128,69,197,5,2048,0,89,81,65,114,65,242,4,64,0,152,81,99,209,0,123,17,80,2081,84,16,68,64,0,196]

theorem envBound32045 : H12AffineFastState.Bounded env32045 := by
  intro p hp
  have h : env32045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32044_32045 : H12AffineEnvironment.transform 8 197 env32044 = env32045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 197 env32044 == env32045) = true)

theorem identity32045 : scanCanonicalize (H12AffineFastState.compose env32045 (packedSelected [2,11,12,13,15,18] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound32045 : packedSelected [2,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env32046 : List Nat := [2,4,8,16,32,12,128,9,137,5,2048,0,21,29,13,62,13,190,4,12,0,152,29,47,157,0,55,17,28,2081,24,16,8,12,0,136]

theorem envBound32046 : H12AffineFastState.Bounded env32046 := by
  intro p hp
  have h : env32046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32045_32046 : H12AffineEnvironment.transform 5 12 env32045 = env32046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env32045 == env32046) = true)

theorem identity32046 : scanCanonicalize (H12AffineFastState.compose env32046 (packedSelected [1,2,3,12] rootPS)) = affineNative (2^(10+1) ^^^ 39) := by decide +kernel

theorem selectedBound32046 : packedSelected [1,2,3,12] rootPS < 2^1333 := by decide +kernel

def env32047 : List Nat := [2,4,8,16,32,12,128,9,137,5,39,0,21,29,13,62,13,190,4,12,0,152,29,47,157,0,55,17,28,6,24,16,8,12,0,136]

theorem envBound32047 : H12AffineFastState.Bounded env32047 := by
  intro p hp
  have h : env32047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32046_32047 : H12AffineEnvironment.transform 10 39 env32046 = env32047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 39 env32046 == env32047) = true)

def env32048 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,8541,311,9560,439,1024,8540,1345,476,8200,1126,8329,8280,1150,9480,1296,10556,8205,16,257,1280,1344,512]

theorem envBound32048 : H12AffineFastState.Bounded env32048 := by
  intro p hp
  have h : env32048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32040_32048 : H12AffineEnvironment.transform 11 1345 env32040 = env32048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env32040 == env32048) = true)

theorem identity32048 : scanCanonicalize (H12AffineFastState.compose env32048 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound32048 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env32049 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,1101,1297,1296,311,277,439,1024,1297,1345,476,1093,1126,1220,1045,1150,325,1296,3441,1088,16,257,1280,1344,512]

theorem envBound32049 : H12AffineFastState.Bounded env32049 := by
  intro p hp
  have h : env32049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32048_32049 : H12AffineEnvironment.transform 12 1101 env32048 = env32049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env32048 == env32049) = true)

theorem identity32049 : scanCanonicalize (H12AffineFastState.compose env32049 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound32049 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env32050 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,1052,1297,1296,311,277,439,1024,1297,1296,397,1044,1079,1173,1045,1071,276,1296,3360,1041,16,257,1280,1297,512]

theorem envBound32050 : H12AffineFastState.Bounded env32050 := by
  intro p hp
  have h : env32050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32049_32050 : H12AffineEnvironment.transform 5 17 env32049 = env32050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32049 == env32050) = true)

theorem identity32050 : scanCanonicalize (H12AffineFastState.compose env32050 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 428) := by decide +kernel

theorem selectedBound32050 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env32051 : List Nat := [2,4,8,16,32,17,128,256,512,1024,428,1296,1052,1297,1296,311,277,439,1024,1297,1296,397,1044,1079,1173,1045,1071,276,1296,1164,1041,16,257,1280,1297,512]

theorem envBound32051 : H12AffineFastState.Bounded env32051 := by
  intro p hp
  have h : env32051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32050_32051 : H12AffineEnvironment.transform 10 428 env32050 = env32051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 428 env32050 == env32051) = true)

theorem identity32051 : scanCanonicalize (H12AffineFastState.compose env32051 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(9+1) ^^^ 827) := by decide +kernel

theorem selectedBound32051 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env32052 : List Nat := [2,4,8,16,32,17,128,256,512,827,428,555,807,554,555,311,277,439,827,554,555,397,815,780,942,814,788,276,555,951,810,16,257,571,554,512]

theorem envBound32052 : H12AffineFastState.Bounded env32052 := by
  intro p hp
  have h : env32052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32051_32052 : H12AffineEnvironment.transform 9 827 env32051 = env32052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 827 env32051 == env32052) = true)

theorem identity32052 : scanCanonicalize (H12AffineFastState.compose env32052 (packedSelected [0,1,2,3,5,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound32052 : packedSelected [0,1,2,3,5,7,9] rootPS < 2^1333 := by decide +kernel

def env32053 : List Nat := [2,4,8,16,32,17,34,256,512,827,270,555,807,554,555,311,277,277,827,554,555,303,815,780,780,814,788,276,555,789,810,16,257,571,554,512]

theorem envBound32053 : H12AffineFastState.Bounded env32053 := by
  intro p hp
  have h : env32053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32052_32053 : H12AffineEnvironment.transform 6 34 env32052 = env32053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env32052 == env32053) = true)

theorem identity32053 : scanCanonicalize (H12AffineFastState.compose env32053 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound32053 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env32054 : List Nat := [2,4,8,16,32,17,34,256,27,288,270,48,316,49,48,311,277,277,288,49,48,303,308,279,279,309,271,276,48,270,305,16,257,32,49,27]

theorem envBound32054 : H12AffineFastState.Bounded env32054 := by
  intro p hp
  have h : env32054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32053_32054 : H12AffineEnvironment.transform 8 27 env32053 = env32054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env32053 == env32054) = true)

theorem identity32054 : scanCanonicalize (H12AffineFastState.compose env32054 (packedSelected [0,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound32054 : packedSelected [0,2,5] rootPS < 2^1333 := by decide +kernel

def env32055 : List Nat := [2,4,8,16,16,17,18,256,27,272,270,0,268,1,0,263,277,277,272,1,0,287,260,279,279,261,271,276,0,270,257,16,257,16,1,27]

theorem envBound32055 : H12AffineFastState.Bounded env32055 := by
  intro p hp
  have h : env32055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32054_32055 : H12AffineEnvironment.transform 4 16 env32054 = env32055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env32054 == env32055) = true)

theorem identity32055 : scanCanonicalize (H12AffineFastState.compose env32055 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 2) := by decide +kernel

theorem selectedBound32055 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32056 : List Nat := [2,4,8,16,16,17,18,2,27,18,12,0,14,1,0,5,23,23,18,1,0,29,6,21,21,7,13,22,0,12,3,16,3,16,1,27]

theorem envBound32056 : H12AffineFastState.Bounded env32056 := by
  intro p hp
  have h : env32056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32055_32056 : H12AffineEnvironment.transform 7 2 env32055 = env32056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 2 env32055 == env32056) = true)

def env32057 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74863,65665,4417,8540,4096,5277,74047,66897,13768,78894,1151,74815,1296,81226,8205,65831,257,1280,1344,5953]

theorem envBound32057 : H12AffineFastState.Bounded env32057 := by
  intro p hp
  have h : env32057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32038_32057 : H12AffineEnvironment.transform 17 65665 env32038 = env32057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env32038 == env32057) = true)

theorem identity32057 : scanCanonicalize (H12AffineFastState.compose env32057 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5239) := by decide +kernel

theorem selectedBound32057 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env32058 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,5239,12312,5366,4417,8540,4096,5277,13640,4390,13768,8281,1151,12360,1296,10557,8205,5456,257,1280,1344,5953]

theorem envBound32058 : H12AffineFastState.Bounded env32058 := by
  intro p hp
  have h : env32058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32057_32058 : H12AffineEnvironment.transform 15 5239 env32057 = env32058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5239 env32057 == env32058) = true)

def env32059 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5464,1297,5125,5239,1344,5366,4417,5124,4096,5277,16,4390,144,5377,1151,1296,1296,7269,5461,5456,257,1280,1344,5953]

theorem envBound32059 : H12AffineFastState.Bounded env32059 := by
  intro p hp
  have h : env32059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32058_32059 : H12AffineEnvironment.transform 12 5464 env32058 = env32059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5464 env32058 == env32059) = true)

theorem identity32059 : scanCanonicalize (H12AffineFastState.compose env32059 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound32059 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env32060 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,1368,1297,1029,1143,1344,1270,321,1028,0,1181,16,294,144,1281,1151,1296,1296,3173,1365,1360,257,1280,1344,1857]

theorem envBound32060 : H12AffineFastState.Bounded env32060 := by
  intro p hp
  have h : env32060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32059_32060 : H12AffineEnvironment.transform 11 0 env32059 = env32060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env32059 == env32060) = true)

theorem identity32060 : scanCanonicalize (H12AffineFastState.compose env32060 (packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 1783) := by decide +kernel

theorem selectedBound32060 : packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env32061 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1783,0,1368,1297,1029,1143,1344,1270,321,1028,0,1181,16,294,144,1281,1151,1296,1296,658,1365,1360,257,1280,1344,1857]

theorem envBound32061 : H12AffineFastState.Bounded env32061 := by
  intro p hp
  have h : env32061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32060_32061 : H12AffineEnvironment.transform 10 1783 env32060 = env32061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1783 env32060 == env32061) = true)

theorem identity32061 : scanCanonicalize (H12AffineFastState.compose env32061 (packedSelected [0,1,2,4,5,7,9,10,11,13,23] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound32061 : packedSelected [0,1,2,4,5,7,9,10,11,13,23] rootPS < 2^1333 := by decide +kernel

def env32062 : List Nat := [2,4,8,16,32,64,128,172,512,1024,1783,0,1268,1213,1029,1143,1260,1270,237,1028,0,1181,16,138,144,1197,1151,1212,1212,658,1273,1276,173,1196,1260,1773]

theorem envBound32062 : H12AffineFastState.Bounded env32062 := by
  intro p hp
  have h : env32062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32061_32062 : H12AffineEnvironment.transform 7 172 env32061 = env32062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env32061 == env32062) = true)

theorem identity32062 : scanCanonicalize (H12AffineFastState.compose env32062 (packedSelected [0,1,2,3,4,7,9,15,17] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound32062 : packedSelected [0,1,2,3,4,7,9,15,17] rootPS < 2^1333 := by decide +kernel

def env32063 : List Nat := [2,4,8,16,32,64,128,172,512,565,194,0,705,648,560,578,729,707,237,561,0,680,16,138,144,664,586,649,649,658,716,713,173,665,729,216]

theorem envBound32063 : H12AffineFastState.Bounded env32063 := by
  intro p hp
  have h : env32063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32062_32063 : H12AffineEnvironment.transform 9 565 env32062 = env32063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env32062 == env32063) = true)

theorem identity32063 : scanCanonicalize (H12AffineFastState.compose env32063 (packedSelected [0,1,3,5,8,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound32063 : packedSelected [0,1,3,5,8,9,10] rootPS < 2^1333 := by decide +kernel

def env32064 : List Nat := [2,4,8,16,32,64,56,20,512,565,122,0,633,560,560,578,609,635,85,561,0,528,16,50,40,544,586,561,561,554,628,625,21,545,609,96]

theorem envBound32064 : H12AffineFastState.Bounded env32064 := by
  intro p hp
  have h : env32064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32063_32064 : H12AffineEnvironment.transform 6 56 env32063 = env32064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env32063 == env32064) = true)

theorem identity32064 : scanCanonicalize (H12AffineFastState.compose env32064 (packedSelected [1,2,7,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound32064 : packedSelected [1,2,7,8,9] rootPS < 2^1333 := by decide +kernel

def env32065 : List Nat := [2,4,8,16,32,64,56,20,48,5,122,0,73,0,0,114,81,75,85,1,0,32,16,50,40,16,122,1,1,26,68,65,21,17,81,96]

theorem envBound32065 : H12AffineFastState.Bounded env32065 := by
  intro p hp
  have h : env32065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32064_32065 : H12AffineEnvironment.transform 8 48 env32064 = env32065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env32064 == env32065) = true)

theorem identity32065 : scanCanonicalize (H12AffineFastState.compose env32065 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound32065 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env32066 : List Nat := [2,4,8,16,10,64,18,20,26,5,80,0,73,0,0,88,81,75,85,1,0,10,16,24,2,16,80,1,1,26,68,65,21,17,81,74]

theorem envBound32066 : H12AffineFastState.Bounded env32066 := by
  intro p hp
  have h : env32066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32065_32066 : H12AffineEnvironment.transform 4 10 env32065 = env32066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env32065 == env32066) = true)

theorem identity32066 : scanCanonicalize (H12AffineFastState.compose env32066 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound32066 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env32067 : List Nat := [2,4,8,6,10,64,4,2,12,5,70,0,73,0,0,78,71,75,67,1,0,10,6,14,2,6,70,1,1,12,68,65,3,7,71,74]

theorem envBound32067 : H12AffineFastState.Bounded env32067 := by
  intro p hp
  have h : env32067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32066_32067 : H12AffineEnvironment.transform 3 6 env32066 = env32067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env32066 == env32067) = true)

theorem identity32067 : scanCanonicalize (H12AffineFastState.compose env32067 (packedSelected [1,2,5] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound32067 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env32068 : List Nat := [2,4,8,6,10,11,4,2,12,5,13,0,2,0,0,5,12,0,8,1,0,10,6,14,2,6,13,1,1,12,15,10,3,7,12,1]

theorem envBound32068 : H12AffineFastState.Bounded env32068 := by
  intro p hp
  have h : env32068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32067_32068 : H12AffineEnvironment.transform 5 11 env32067 = env32068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env32067 == env32068) = true)

theorem identity32068 : scanCanonicalize (H12AffineFastState.compose env32068 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound32068 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32069 : List Nat := [2,4,4,6,6,7,4,2,0,5,1,0,2,0,0,5,0,0,4,1,0,6,6,2,2,6,1,1,1,0,3,6,3,7,0,1]

theorem envBound32069 : H12AffineFastState.Bounded env32069 := by
  intro p hp
  have h : env32069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32068_32069 : H12AffineEnvironment.transform 2 4 env32068 = env32069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env32068 == env32069) = true)

theorem identity32069 : scanCanonicalize (H12AffineFastState.compose env32069 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound32069 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32070 : List Nat := [0,4,4,4,4,5,4,0,0,5,1,0,0,0,0,5,0,0,4,1,0,4,4,0,0,4,1,1,1,0,1,4,1,5,0,1]

theorem envBound32070 : H12AffineFastState.Bounded env32070 := by
  intro p hp
  have h : env32070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32069_32070 : H12AffineEnvironment.transform 0 0 env32069 = env32070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env32069 == env32070) = true)

theorem identity32070 : scanCanonicalize (H12AffineFastState.compose env32070 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound32070 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32071 : List Nat := [0,1,1,1,1,0,1,0,0,0,1,0,0,0,0,0,0,0,1,1,0,1,1,0,0,1,1,1,1,0,1,1,1,0,0,1]

theorem envBound32071 : H12AffineFastState.Bounded env32071 := by
  intro p hp
  have h : env32071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32070_32071 : H12AffineEnvironment.transform 1 1 env32070 = env32071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env32070 == env32071) = true)

def env32072 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5465,1297,5124,5239,1345,5366,4417,5125,4096,5277,17,4390,145,5376,1151,1297,1296,7268,5460,5456,257,1280,1344,5953]

theorem envBound32072 : H12AffineFastState.Bounded env32072 := by
  intro p hp
  have h : env32072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32058_32072 : H12AffineEnvironment.transform 12 5465 env32058 = env32072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5465 env32058 == env32072) = true)

theorem identity32072 : scanCanonicalize (H12AffineFastState.compose env32072 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound32072 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env32073 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,4096,4444,276,4097,4210,324,4339,4417,4096,4096,4248,17,4390,145,4357,122,276,277,6241,4433,4437,257,261,325,4932]

theorem envBound32073 : H12AffineFastState.Bounded env32073 := by
  intro p hp
  have h : env32073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32072_32073 : H12AffineEnvironment.transform 9 5 env32072 = env32073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env32072 == env32073) = true)

theorem identity32073 : scanCanonicalize (H12AffineFastState.compose env32073 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 324) := by decide +kernel

theorem selectedBound32073 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env32074 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,324,24,276,325,310,324,439,5,324,324,476,17,98,145,65,122,276,277,2341,21,17,257,261,325,512]

theorem envBound32074 : H12AffineFastState.Bounded env32074 := by
  intro p hp
  have h : env32074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32073_32074 : H12AffineEnvironment.transform 11 324 env32073 = env32074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 324 env32073 == env32074) = true)

theorem identity32074 : scanCanonicalize (H12AffineFastState.compose env32074 (packedSelected [2,5,8,13] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound32074 : packedSelected [2,5,8,13] rootPS < 2^1333 := by decide +kernel

def env32075 : List Nat := [2,4,8,16,32,64,128,69,512,5,2048,1,24,81,0,115,1,242,5,1,1,153,17,98,145,65,122,81,80,2144,21,17,68,64,0,512]

theorem envBound32075 : H12AffineFastState.Bounded env32075 := by
  intro p hp
  have h : env32075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32074_32075 : H12AffineEnvironment.transform 7 69 env32074 = env32075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env32074 == env32075) = true)

theorem identity32075 : scanCanonicalize (H12AffineFastState.compose env32075 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 217) := by decide +kernel

theorem selectedBound32075 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32076 : List Nat := [2,4,8,16,32,64,128,69,217,5,2048,1,24,81,0,115,1,242,5,1,1,153,17,98,145,65,122,81,80,2144,21,17,68,64,0,217]

theorem envBound32076 : H12AffineFastState.Bounded env32076 := by
  intro p hp
  have h : env32076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32075_32076 : H12AffineEnvironment.transform 8 217 env32075 = env32076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env32075 == env32076) = true)

theorem identity32076 : scanCanonicalize (H12AffineFastState.compose env32076 (packedSelected [0,2,3,7,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound32076 : packedSelected [0,2,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env32077 : List Nat := [2,4,8,16,32,64,128,69,217,5,43,1,24,81,0,115,1,242,5,1,1,153,17,98,145,65,122,81,80,75,21,17,68,64,0,217]

theorem envBound32077 : H12AffineFastState.Bounded env32077 := by
  intro p hp
  have h : env32077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32076_32077 : H12AffineEnvironment.transform 10 43 env32076 = env32077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env32076 == env32077) = true)

theorem identity32077 : scanCanonicalize (H12AffineFastState.compose env32077 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound32077 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env32078 : List Nat := [2,4,8,16,32,16,128,21,137,5,43,1,24,1,0,35,1,162,5,1,1,153,17,50,145,17,42,1,0,27,21,17,20,16,0,137]

theorem envBound32078 : H12AffineFastState.Bounded env32078 := by
  intro p hp
  have h : env32078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32077_32078 : H12AffineEnvironment.transform 5 16 env32077 = env32078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32077 == env32078) = true)

theorem identity32078 : scanCanonicalize (H12AffineFastState.compose env32078 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 63) := by decide +kernel

theorem selectedBound32078 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32079 : List Nat := [2,4,8,16,32,16,63,21,54,5,43,1,24,1,0,35,1,29,5,1,1,38,17,50,46,17,42,1,0,27,21,17,20,16,0,54]

theorem envBound32079 : H12AffineFastState.Bounded env32079 := by
  intro p hp
  have h : env32079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32078_32079 : H12AffineEnvironment.transform 6 63 env32078 = env32079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 63 env32078 == env32079) = true)

theorem identity32079 : scanCanonicalize (H12AffineFastState.compose env32079 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound32079 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32080 : List Nat := [2,4,8,10,32,10,37,15,44,5,43,1,2,1,0,35,1,7,5,1,1,38,11,40,46,11,42,1,0,1,15,11,14,10,0,44]

theorem envBound32080 : H12AffineFastState.Bounded env32080 := by
  intro p hp
  have h : env32080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32079_32080 : H12AffineEnvironment.transform 3 10 env32079 = env32080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env32079 == env32080) = true)

theorem identity32080 : scanCanonicalize (H12AffineFastState.compose env32080 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound32080 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32081 : List Nat := [2,4,8,10,13,10,8,15,1,5,6,1,2,1,0,14,1,7,5,1,1,11,11,5,3,11,7,1,0,1,15,11,14,10,0,1]

theorem envBound32081 : H12AffineFastState.Bounded env32081 := by
  intro p hp
  have h : env32081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32080_32081 : H12AffineEnvironment.transform 4 13 env32080 = env32081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env32080 == env32081) = true)

theorem identity32081 : scanCanonicalize (H12AffineFastState.compose env32081 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound32081 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env32082 : List Nat := [2,3,8,10,10,10,8,8,1,2,1,1,2,1,0,9,1,0,2,1,1,11,11,2,3,11,0,1,0,1,8,11,9,10,0,1]

theorem envBound32082 : H12AffineFastState.Bounded env32082 := by
  intro p hp
  have h : env32082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32081_32082 : H12AffineEnvironment.transform 1 3 env32081 = env32082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env32081 == env32082) = true)

def env32083 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21585,32769,4096,61649,91182,123165,28888,78895,385202,90414,1297,96347,25884,82998,257,1281,1344,21073]

theorem envBound32083 : H12AffineFastState.Bounded env32083 := by
  intro p hp
  have h : env32083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31990_32083 : H12AffineEnvironment.transform 18 21585 env31990 = env32083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env31990 == env32083) = true)

theorem identity32083 : scanCanonicalize (H12AffineFastState.compose env32083 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound32083 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env32084 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13341,65536,74863,262144,21585,13340,4096,17612,91182,87296,28888,78895,349359,90414,1297,96347,25884,82998,257,1281,1344,21073]

theorem envBound32084 : H12AffineFastState.Bounded env32084 := by
  intro p hp
  have h : env32084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32083_32084 : H12AffineEnvironment.transform 14 13341 env32083 = env32084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env32083 == env32084) = true)

def env32085 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74863,262144,4417,13340,4096,476,74046,69648,13768,78895,332223,74814,1297,81227,8204,65830,257,1281,1344,5953]

theorem envBound32085 : H12AffineFastState.Bounded env32085 := by
  intro p hp
  have h : env32085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32084_32085 : H12AffineEnvironment.transform 13 1296 env32084 = env32085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env32084 == env32085) = true)

def env32086 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74863,65664,4417,13340,4096,476,74046,69648,13768,78895,4415,74814,1297,81227,8204,65830,257,1281,1344,5953]

theorem envBound32086 : H12AffineFastState.Bounded env32086 := by
  intro p hp
  have h : env32086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32085_32086 : H12AffineEnvironment.transform 17 65664 env32085 = env32086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env32085 == env32086) = true)

theorem identity32086 : scanCanonicalize (H12AffineFastState.compose env32086 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9278) := by decide +kernel

theorem selectedBound32086 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env32087 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,9278,81,9406,4417,13340,4096,476,1280,13358,13768,4113,4415,0,1297,6517,8204,9496,257,1281,1344,5953]

theorem envBound32087 : H12AffineFastState.Bounded env32087 := by
  intro p hp
  have h : env32087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32086_32087 : H12AffineEnvironment.transform 15 9278 env32086 = env32087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9278 env32086 == env32087) = true)

def env32088 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,24,1296,5125,1062,81,1190,4417,5124,4096,476,1280,5174,5584,4113,4415,0,1297,6517,20,1280,257,1281,1344,5953]

theorem envBound32088 : H12AffineFastState.Bounded env32088 := by
  intro p hp
  have h : env32088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32087_32088 : H12AffineEnvironment.transform 12 24 env32087 = env32088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env32087 == env32088) = true)

theorem identity32088 : scanCanonicalize (H12AffineFastState.compose env32088 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound32088 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env32089 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,4096,24,277,4096,35,81,163,4417,4097,4096,476,261,4147,4565,4113,4415,0,276,6517,20,261,257,260,325,4932]

theorem envBound32089 : H12AffineFastState.Bounded env32089 := by
  intro p hp
  have h : env32089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32088_32089 : H12AffineEnvironment.transform 9 5 env32088 = env32089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env32088 == env32089) = true)

theorem identity32089 : scanCanonicalize (H12AffineFastState.compose env32089 (packedSelected [0,1,4,7,8,9,12,13,15,18,19,23] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound32089 : packedSelected [0,1,4,7,8,9,12,13,15,18,19,23] rootPS < 2^1333 := by decide +kernel

def env32090 : List Nat := [2,4,8,16,32,64,128,172,512,5,2048,4096,24,185,4096,35,81,163,4333,4097,4096,112,169,4147,4217,4113,4243,0,184,6361,20,169,173,168,233,4840]

theorem envBound32090 : H12AffineFastState.Bounded env32090 := by
  intro p hp
  have h : env32090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32089_32090 : H12AffineEnvironment.transform 7 172 env32089 = env32090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env32089 == env32090) = true)

theorem identity32090 : scanCanonicalize (H12AffineFastState.compose env32090 (packedSelected [0,1,2,5,7,8,11,13,17] rootPS)) = affineNative (2^(11+1) ^^^ 175) := by decide +kernel

theorem selectedBound32090 : packedSelected [0,1,2,5,7,8,11,13,17] rootPS < 2^1333 := by decide +kernel

def env32091 : List Nat := [2,4,8,16,32,64,128,172,512,5,2048,175,24,185,175,35,81,163,66,174,175,112,169,156,214,190,60,0,184,2166,20,169,173,168,233,583]

theorem envBound32091 : H12AffineFastState.Bounded env32091 := by
  intro p hp
  have h : env32091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32090_32091 : H12AffineEnvironment.transform 11 175 env32090 = env32091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 175 env32090 == env32091) = true)

theorem identity32091 : scanCanonicalize (H12AffineFastState.compose env32091 (packedSelected [0,1,2,5,7,8,11,15,16,18] rootPS)) = affineNative (2^(10+1) ^^^ 27) := by decide +kernel

theorem selectedBound32091 : packedSelected [0,1,2,5,7,8,11,15,16,18] rootPS < 2^1333 := by decide +kernel

def env32092 : List Nat := [2,4,8,16,32,64,128,172,512,5,27,175,24,185,175,35,81,163,66,174,175,112,169,156,214,190,60,0,184,109,20,169,173,168,233,583]

theorem envBound32092 : H12AffineFastState.Bounded env32092 := by
  intro p hp
  have h : env32092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32091_32092 : H12AffineEnvironment.transform 10 27 env32091 = env32092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 27 env32091 == env32092) = true)

theorem identity32092 : scanCanonicalize (H12AffineFastState.compose env32092 (packedSelected [2,4,9,13,16] rootPS)) = affineNative (2^(8+1) ^^^ 13) := by decide +kernel

theorem selectedBound32092 : packedSelected [2,4,9,13,16] rootPS < 2^1333 := by decide +kernel

def env32093 : List Nat := [2,4,8,16,32,64,128,172,13,5,27,175,24,185,175,35,81,163,66,174,175,112,169,156,214,190,60,0,184,109,20,169,173,168,233,74]

theorem envBound32093 : H12AffineFastState.Bounded env32093 := by
  intro p hp
  have h : env32093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32092_32093 : H12AffineEnvironment.transform 8 13 env32092 = env32093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 13 env32092 == env32093) = true)

theorem identity32093 : scanCanonicalize (H12AffineFastState.compose env32093 (packedSelected [0,3,5,7,8,10,11,12,13] rootPS)) = affineNative (2^(6+1) ^^^ 67) := by decide +kernel

theorem selectedBound32093 : packedSelected [0,3,5,7,8,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env32094 : List Nat := [2,4,8,16,32,64,67,111,13,5,27,108,24,122,108,35,81,96,66,109,108,112,106,95,21,125,60,0,123,109,20,106,110,107,42,74]

theorem envBound32094 : H12AffineFastState.Bounded env32094 := by
  intro p hp
  have h : env32094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32093_32094 : H12AffineEnvironment.transform 6 67 env32093 = env32094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 67 env32093 == env32094) = true)

theorem identity32094 : scanCanonicalize (H12AffineFastState.compose env32094 (packedSelected [4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 45) := by decide +kernel

theorem selectedBound32094 : packedSelected [4,5,7] rootPS < 2^1333 := by decide +kernel

def env32095 : List Nat := [2,4,8,16,32,45,46,2,13,5,27,1,24,23,1,35,60,13,47,0,1,29,7,50,21,16,60,0,22,0,20,7,3,6,42,39]

theorem envBound32095 : H12AffineFastState.Bounded env32095 := by
  intro p hp
  have h : env32095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32094_32095 : H12AffineEnvironment.transform 5 45 env32094 = env32095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 45 env32094 == env32095) = true)

theorem identity32095 : scanCanonicalize (H12AffineFastState.compose env32095 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound32095 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env32096 : List Nat := [2,4,8,16,16,29,30,2,13,5,27,1,24,23,1,19,12,13,31,0,1,29,7,2,21,16,12,0,22,0,20,7,3,6,26,23]

theorem envBound32096 : H12AffineFastState.Bounded env32096 := by
  intro p hp
  have h : env32096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32095_32096 : H12AffineEnvironment.transform 4 16 env32095 = env32096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env32095 == env32096) = true)

theorem identity32096 : scanCanonicalize (H12AffineFastState.compose env32096 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound32096 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env32097 : List Nat := [2,4,8,10,10,7,4,2,13,5,1,1,2,13,1,9,12,13,5,0,1,7,7,2,15,10,12,0,12,0,14,7,3,6,0,13]

theorem envBound32097 : H12AffineFastState.Bounded env32097 := by
  intro p hp
  have h : env32097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32096_32097 : H12AffineEnvironment.transform 3 10 env32096 = env32097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env32096 == env32097) = true)

theorem identity32097 : scanCanonicalize (H12AffineFastState.compose env32097 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound32097 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32098 : List Nat := [2,4,4,6,6,7,4,2,1,5,1,1,2,1,1,5,0,1,5,0,1,7,7,2,3,6,0,0,0,0,2,7,3,6,0,1]

theorem envBound32098 : H12AffineFastState.Bounded env32098 := by
  intro p hp
  have h : env32098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32097_32098 : H12AffineEnvironment.transform 2 4 env32097 = env32098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env32097 == env32098) = true)

def env32099 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,25,1296,5124,1063,81,1191,4417,5125,4096,476,1280,5175,5585,4113,4415,0,1297,6517,21,1281,257,1281,1344,5953]

theorem envBound32099 : H12AffineFastState.Bounded env32099 := by
  intro p hp
  have h : env32099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32087_32099 : H12AffineEnvironment.transform 12 25 env32087 = env32099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env32087 == env32099) = true)

theorem identity32099 : scanCanonicalize (H12AffineFastState.compose env32099 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound32099 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env32100 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,25,1296,1028,1063,81,1191,321,1029,0,476,1280,1079,1489,17,319,0,1297,2421,21,1281,257,1281,1344,1857]

theorem envBound32100 : H12AffineFastState.Bounded env32100 := by
  intro p hp
  have h : env32100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32099_32100 : H12AffineEnvironment.transform 11 0 env32099 = env32100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env32099 == env32100) = true)

theorem identity32100 : scanCanonicalize (H12AffineFastState.compose env32100 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound32100 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env32101 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,0,25,277,1,34,81,162,321,0,0,476,261,50,468,17,319,0,276,2421,21,260,257,260,325,836]

theorem envBound32101 : H12AffineFastState.Bounded env32101 := by
  intro p hp
  have h : env32101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32100_32101 : H12AffineEnvironment.transform 9 5 env32100 = env32101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env32100 == env32101) = true)

theorem identity32101 : scanCanonicalize (H12AffineFastState.compose env32101 (packedSelected [0,1,7,8,15,18,19] rootPS)) = affineNative (2^(10+1) ^^^ 460) := by decide +kernel

theorem selectedBound32101 : packedSelected [0,1,7,8,15,18,19] rootPS < 2^1333 := by decide +kernel

def env32102 : List Nat := [2,4,8,16,32,64,128,256,512,5,460,0,25,277,1,34,81,162,321,0,0,476,261,50,468,17,319,0,276,185,21,260,257,260,325,836]

theorem envBound32102 : H12AffineFastState.Bounded env32102 := by
  intro p hp
  have h : env32102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32101_32102 : H12AffineEnvironment.transform 10 460 env32101 = env32102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 460 env32101 == env32102) = true)

theorem identity32102 : scanCanonicalize (H12AffineFastState.compose env32102 (packedSelected [0,1,2,3,5,7,8,11] rootPS)) = affineNative (2^(8+1) ^^^ 461) := by decide +kernel

theorem selectedBound32102 : packedSelected [0,1,2,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env32103 : List Nat := [2,4,8,16,32,64,128,256,461,5,460,0,25,277,1,34,81,162,321,0,0,476,261,50,468,17,319,0,276,185,21,260,257,260,325,137]

theorem envBound32103 : H12AffineFastState.Bounded env32103 := by
  intro p hp
  have h : env32103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32102_32103 : H12AffineEnvironment.transform 8 461 env32102 = env32103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 461 env32102 == env32103) = true)

theorem identity32103 : scanCanonicalize (H12AffineFastState.compose env32103 (packedSelected [1,2,3,5,8,10,12,13] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound32103 : packedSelected [1,2,3,5,8,10,12,13] rootPS < 2^1333 := by decide +kernel

def env32104 : List Nat := [2,4,8,16,11,64,128,256,461,5,460,0,25,277,1,9,81,137,321,0,0,476,261,25,468,17,276,0,276,146,21,260,257,260,325,137]

theorem envBound32104 : H12AffineFastState.Bounded env32104 := by
  intro p hp
  have h : env32104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32103_32104 : H12AffineEnvironment.transform 4 11 env32103 = env32104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env32103 == env32104) = true)

theorem identity32104 : scanCanonicalize (H12AffineFastState.compose env32104 (packedSelected [4,5,9] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound32104 : packedSelected [4,5,9] rootPS < 2^1333 := by decide +kernel

def env32105 : List Nat := [2,4,8,16,11,13,128,256,384,5,385,0,25,277,1,9,28,137,268,0,0,401,261,25,409,17,276,0,276,146,21,260,257,260,264,137]

theorem envBound32105 : H12AffineFastState.Bounded env32105 := by
  intro p hp
  have h : env32105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32104_32105 : H12AffineEnvironment.transform 5 13 env32104 = env32105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env32104 == env32105) = true)

theorem identity32105 : scanCanonicalize (H12AffineFastState.compose env32105 (packedSelected [0,1,4,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 157) := by decide +kernel

theorem selectedBound32105 : packedSelected [0,1,4,5,10] rootPS < 2^1333 := by decide +kernel

def env32106 : List Nat := [2,4,8,16,11,13,128,157,29,5,28,0,25,136,1,9,28,137,145,0,0,12,152,25,4,17,137,0,137,146,21,153,156,153,149,137]

theorem envBound32106 : H12AffineFastState.Bounded env32106 := by
  intro p hp
  have h : env32106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32105_32106 : H12AffineEnvironment.transform 7 157 env32105 = env32106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 157 env32105 == env32106) = true)

theorem identity32106 : scanCanonicalize (H12AffineFastState.compose env32106 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound32106 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env32107 : List Nat := [2,4,8,11,11,13,128,134,6,5,7,0,2,136,1,9,7,137,138,0,0,12,131,2,4,10,137,0,137,137,14,130,135,130,142,137]

theorem envBound32107 : H12AffineFastState.Bounded env32107 := by
  intro p hp
  have h : env32107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32106_32107 : H12AffineEnvironment.transform 3 11 env32106 = env32107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env32106 == env32107) = true)

theorem identity32107 : scanCanonicalize (H12AffineFastState.compose env32107 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound32107 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32108 : List Nat := [2,2,8,11,11,11,128,128,0,3,1,0,2,136,1,9,1,137,138,0,0,10,131,2,2,10,137,0,137,137,8,130,129,130,136,137]

theorem envBound32108 : H12AffineFastState.Bounded env32108 := by
  intro p hp
  have h : env32108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32107_32108 : H12AffineEnvironment.transform 1 2 env32107 = env32108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env32107 == env32108) = true)

theorem identity32108 : scanCanonicalize (H12AffineFastState.compose env32108 (packedSelected [5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound32108 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env32109 : List Nat := [2,2,8,11,11,11,9,9,0,3,1,0,2,1,1,9,1,0,3,0,0,10,10,2,2,10,0,0,0,0,8,11,8,11,1,0]

theorem envBound32109 : H12AffineFastState.Bounded env32109 := by
  intro p hp
  have h : env32109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32108_32109 : H12AffineEnvironment.transform 6 9 env32108 = env32109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32108 == env32109) = true)

def env32110 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74863,65665,4417,13340,4096,476,74046,69648,13768,78895,4414,74814,1297,81227,8204,65830,257,1281,1344,5953]

theorem envBound32110 : H12AffineFastState.Bounded env32110 := by
  intro p hp
  have h : env32110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32085_32110 : H12AffineEnvironment.transform 17 65665 env32085 = env32110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env32085 == env32110) = true)

theorem identity32110 : scanCanonicalize (H12AffineFastState.compose env32110 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12670) := by decide +kernel

theorem selectedBound32110 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env32111 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,12670,5393,12799,4417,13340,4096,476,4160,8558,13768,1361,4414,5440,1297,3125,8204,12376,257,1281,1344,5953]

theorem envBound32111 : H12AffineFastState.Bounded env32111 := by
  intro p hp
  have h : env32111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32110_32111 : H12AffineEnvironment.transform 15 12670 env32110 = env32111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12670 env32110 == env32111) = true)

def env32112 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1296,9293,8494,1345,8623,273,9292,80,476,16,8558,9624,1361,366,1296,1297,3125,8204,8200,257,1281,1344,1809]

theorem envBound32112 : H12AffineFastState.Bounded env32112 := by
  intro p hp
  have h : env32112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32111_32112 : H12AffineEnvironment.transform 11 80 env32111 = env32112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env32111 == env32112) = true)

theorem identity32112 : scanCanonicalize (H12AffineFastState.compose env32112 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 1368) := by decide +kernel

theorem selectedBound32112 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env32113 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,1368,1296,277,1142,1345,1271,273,276,80,476,16,1078,192,1361,366,1296,1297,3125,1364,1360,257,1281,1344,1809]

theorem envBound32113 : H12AffineFastState.Bounded env32113 := by
  intro p hp
  have h : env32113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32112_32113 : H12AffineEnvironment.transform 12 1368 env32112 = env32113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1368 env32112 == env32113) = true)

theorem identity32113 : scanCanonicalize (H12AffineFastState.compose env32113 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound32113 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env32114 : List Nat := [2,4,8,16,32,64,128,256,512,188,2048,80,484,428,277,202,509,75,273,276,80,476,16,138,192,493,366,428,429,2185,488,492,257,445,508,941]

theorem envBound32114 : H12AffineFastState.Bounded env32114 := by
  intro p hp
  have h : env32114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32113_32114 : H12AffineEnvironment.transform 9 188 env32113 = env32114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env32113 == env32114) = true)

theorem identity32114 : scanCanonicalize (H12AffineFastState.compose env32114 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 372) := by decide +kernel

theorem selectedBound32114 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env32115 : List Nat := [2,4,8,16,32,64,128,256,372,188,2048,80,484,428,277,202,509,75,273,276,80,476,16,138,192,493,366,428,429,2185,488,492,257,445,508,217]

theorem envBound32115 : H12AffineFastState.Bounded env32115 := by
  intro p hp
  have h : env32115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32114_32115 : H12AffineEnvironment.transform 8 372 env32114 = env32115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 372 env32114 == env32115) = true)

theorem identity32115 : scanCanonicalize (H12AffineFastState.compose env32115 (packedSelected [0,2,3,7,8,10,13,16] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound32115 : packedSelected [0,2,3,7,8,10,13,16] rootPS < 2^1333 := by decide +kernel

def env32116 : List Nat := [2,4,8,16,32,64,18,256,372,46,2048,80,374,318,277,88,367,75,273,276,80,334,16,24,82,383,366,318,319,2075,378,382,257,303,366,75]

theorem envBound32116 : H12AffineFastState.Bounded env32116 := by
  intro p hp
  have h : env32116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32115_32116 : H12AffineEnvironment.transform 6 18 env32115 = env32116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env32115 == env32116) = true)

theorem identity32116 : scanCanonicalize (H12AffineFastState.compose env32116 (packedSelected [1,3,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 351) := by decide +kernel

theorem selectedBound32116 : packedSelected [1,3,7,9] rootPS < 2^1333 := by decide +kernel

def env32117 : List Nat := [2,4,8,16,32,64,18,256,372,46,351,80,374,318,277,88,367,75,273,276,80,334,16,24,82,383,366,318,319,324,378,382,257,303,366,75]

theorem envBound32117 : H12AffineFastState.Bounded env32117 := by
  intro p hp
  have h : env32117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32116_32117 : H12AffineEnvironment.transform 10 351 env32116 = env32117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 351 env32116 == env32117) = true)

theorem identity32117 : scanCanonicalize (H12AffineFastState.compose env32117 (packedSelected [2,10,11] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound32117 : packedSelected [2,10,11] rootPS < 2^1333 := by decide +kernel

def env32118 : List Nat := [2,4,8,11,32,64,9,256,367,46,324,75,365,293,270,67,367,75,266,271,75,334,11,3,73,356,366,293,292,324,353,357,257,303,366,75]

theorem envBound32118 : H12AffineFastState.Bounded env32118 := by
  intro p hp
  have h : env32118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32117_32118 : H12AffineEnvironment.transform 3 11 env32117 = env32118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env32117 == env32118) = true)

theorem identity32118 : scanCanonicalize (H12AffineFastState.compose env32118 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound32118 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env32119 : List Nat := [2,4,8,11,32,33,9,256,270,46,293,42,268,293,270,34,270,42,266,271,42,303,11,3,40,261,271,293,292,293,256,260,257,303,271,42]

theorem envBound32119 : H12AffineFastState.Bounded env32119 := by
  intro p hp
  have h : env32119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32118_32119 : H12AffineEnvironment.transform 5 33 env32118 = env32119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env32118 == env32119) = true)

theorem identity32119 : scanCanonicalize (H12AffineFastState.compose env32119 (packedSelected [1,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound32119 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env32120 : List Nat := [2,4,8,11,11,10,9,256,270,5,270,1,268,270,270,9,270,1,266,271,1,260,11,3,3,261,271,270,271,270,256,260,257,260,271,1]

theorem envBound32120 : H12AffineFastState.Bounded env32120 := by
  intro p hp
  have h : env32120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32119_32120 : H12AffineEnvironment.transform 4 11 env32119 = env32120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env32119 == env32120) = true)

theorem identity32120 : scanCanonicalize (H12AffineFastState.compose env32120 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 9) := by decide +kernel

theorem selectedBound32120 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32121 : List Nat := [2,4,8,11,11,10,9,9,7,5,7,1,5,7,7,9,7,1,3,6,1,13,11,3,3,12,6,7,6,7,9,13,8,13,6,1]

theorem envBound32121 : H12AffineFastState.Bounded env32121 := by
  intro p hp
  have h : env32121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32120_32121 : H12AffineEnvironment.transform 7 9 env32120 = env32121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 9 env32120 == env32121) = true)

def env32122 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1296,9292,8495,1344,8622,272,9293,81,476,17,8558,9625,1361,367,1297,1297,3125,8204,8201,257,1281,1344,1808]

theorem envBound32122 : H12AffineFastState.Bounded env32122 := by
  intro p hp
  have h : env32122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32111_32122 : H12AffineEnvironment.transform 11 81 env32111 = env32122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env32111 == env32122) = true)

theorem identity32122 : scanCanonicalize (H12AffineFastState.compose env32122 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound32122 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env32123 : List Nat := [2,4,8,16,32,64,128,21,512,1024,2048,81,8192,1029,9292,8250,1109,8379,5,9293,81,201,17,8315,9356,1092,122,1028,1028,3125,8204,8201,20,1044,1109,1541]

theorem envBound32123 : H12AffineFastState.Bounded env32123 := by
  intro p hp
  have h : env32123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32122_32123 : H12AffineEnvironment.transform 7 21 env32122 = env32123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env32122 == env32123) = true)

theorem identity32123 : scanCanonicalize (H12AffineFastState.compose env32123 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound32123 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env32124 : List Nat := [2,4,8,16,32,64,128,21,512,5,2048,81,8192,0,8265,8250,80,8379,5,8264,81,201,17,8315,8329,65,122,1,1,2096,8204,8201,20,17,80,512]

theorem envBound32124 : H12AffineFastState.Bounded env32124 := by
  intro p hp
  have h : env32124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32123_32124 : H12AffineEnvironment.transform 9 5 env32123 = env32124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env32123 == env32124) = true)

theorem identity32124 : scanCanonicalize (H12AffineFastState.compose env32124 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound32124 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env32125 : List Nat := [2,4,8,16,32,16,128,21,512,5,2048,1,8192,0,8217,8250,0,8379,5,8216,1,153,17,8235,8329,17,42,1,1,2096,8204,8201,20,17,0,512]

theorem envBound32125 : H12AffineFastState.Bounded env32125 := by
  intro p hp
  have h : env32125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32124_32125 : H12AffineEnvironment.transform 5 16 env32124 = env32125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32124 == env32125) = true)

theorem identity32125 : scanCanonicalize (H12AffineFastState.compose env32125 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2705) := by decide +kernel

theorem selectedBound32125 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32126 : List Nat := [2,4,8,16,32,16,128,21,512,5,2048,1,2705,0,2696,2731,0,2602,5,2697,1,153,17,2746,2584,17,42,1,1,2096,2717,2712,20,17,0,512]

theorem envBound32126 : H12AffineFastState.Bounded env32126 := by
  intro p hp
  have h : env32126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32125_32126 : H12AffineEnvironment.transform 12 2705 env32125 = env32126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2705 env32125 == env32126) = true)

theorem identity32126 : scanCanonicalize (H12AffineFastState.compose env32126 (packedSelected [3,8] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound32126 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env32127 : List Nat := [2,4,8,16,32,16,128,21,42,5,2048,1,2235,0,2210,2177,0,2048,5,2211,1,153,17,2192,2098,17,42,1,1,2096,2231,2226,20,17,0,42]

theorem envBound32127 : H12AffineFastState.Bounded env32127 := by
  intro p hp
  have h : env32127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32126_32127 : H12AffineEnvironment.transform 8 42 env32126 = env32127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env32126 == env32127) = true)

theorem identity32127 : scanCanonicalize (H12AffineFastState.compose env32127 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound32127 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32128 : List Nat := [2,4,8,16,32,16,34,21,42,5,2048,1,2073,0,2048,2083,0,2048,5,2049,1,59,17,2098,2098,17,42,1,1,2096,2069,2064,20,17,0,42]

theorem envBound32128 : H12AffineFastState.Bounded env32128 := by
  intro p hp
  have h : env32128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32127_32128 : H12AffineEnvironment.transform 6 34 env32127 = env32128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env32127 == env32128) = true)

def env32129 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74863,262144,4416,13340,4096,477,74047,69649,13769,78895,332222,74815,1297,81226,8205,65831,257,1281,1344,5952]

theorem envBound32129 : H12AffineFastState.Bounded env32129 := by
  intro p hp
  have h : env32129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32084_32129 : H12AffineEnvironment.transform 13 1297 env32084 = env32129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env32084 == env32129) = true)

def env32130 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74863,65664,4416,13340,4096,477,74047,69649,13769,78895,4414,74815,1297,81226,8205,65831,257,1281,1344,5952]

theorem envBound32130 : H12AffineFastState.Bounded env32130 := by
  intro p hp
  have h : env32130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32129_32130 : H12AffineEnvironment.transform 17 65664 env32129 = env32130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env32129 == env32130) = true)

theorem identity32130 : scanCanonicalize (H12AffineFastState.compose env32130 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5238) := by decide +kernel

theorem selectedBound32130 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env32131 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,5238,12313,5366,4416,13340,4096,477,13641,1127,13769,8281,4414,12361,1297,10556,8205,5457,257,1281,1344,5952]

theorem envBound32131 : H12AffineFastState.Bounded env32131 := by
  intro p hp
  have h : env32131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32130_32131 : H12AffineEnvironment.transform 15 5238 env32130 = env32131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5238 env32130 == env32131) = true)

def env32132 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5464,1297,325,5238,1345,5366,4416,324,4096,477,17,1127,145,5377,4414,1297,1297,7268,5461,5457,257,1281,1344,5952]

theorem envBound32132 : H12AffineFastState.Bounded env32132 := by
  intro p hp
  have h : env32132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32131_32132 : H12AffineEnvironment.transform 12 5464 env32131 = env32132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5464 env32131 == env32132) = true)

theorem identity32132 : scanCanonicalize (H12AffineFastState.compose env32132 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound32132 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env32133 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,4121,80,325,4407,0,4535,4416,324,4096,477,17,294,145,4160,4414,80,80,6437,4116,4112,257,64,1,4609]

theorem envBound32133 : H12AffineFastState.Bounded env32133 := by
  intro p hp
  have h : env32133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32132_32133 : H12AffineEnvironment.transform 9 321 env32132 = env32133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env32132 == env32133) = true)

theorem identity32133 : scanCanonicalize (H12AffineFastState.compose env32133 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound32133 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env32134 : List Nat := [2,4,8,16,32,64,128,172,512,237,2048,4096,4121,80,233,4251,0,4123,4332,232,4096,113,17,138,145,4160,4242,80,80,6281,4116,4112,173,64,1,4609]

theorem envBound32134 : H12AffineFastState.Bounded env32134 := by
  intro p hp
  have h : env32134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32133_32134 : H12AffineEnvironment.transform 7 172 env32133 = env32134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env32133 == env32134) = true)

theorem identity32134 : scanCanonicalize (H12AffineFastState.compose env32134 (packedSelected [0,2,3,5,7,10,11,12,15,16,17,18] rootPS)) = affineNative (2^(11+1) ^^^ 2802) := by decide +kernel

theorem selectedBound32134 : packedSelected [0,2,3,5,7,10,11,12,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env32135 : List Nat := [2,4,8,16,32,64,128,172,512,237,2048,2802,2795,80,233,2665,0,2793,2590,232,2802,113,17,138,145,2738,2656,80,80,635,2790,2786,173,64,1,2291]

theorem envBound32135 : H12AffineFastState.Bounded env32135 := by
  intro p hp
  have h : env32135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32134_32135 : H12AffineEnvironment.transform 11 2802 env32134 = env32135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2802 env32134 == env32135) = true)

theorem identity32135 : scanCanonicalize (H12AffineFastState.compose env32135 (packedSelected [0,2,3,7,8,10,12,15,16] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound32135 : packedSelected [0,2,3,7,8,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env32136 : List Nat := [2,4,8,16,10,64,128,134,512,199,2048,2776,2753,80,195,2627,0,2755,2590,194,2776,91,17,138,145,2712,2634,80,80,593,2764,2760,135,64,1,2265]

theorem envBound32136 : H12AffineFastState.Bounded env32136 := by
  intro p hp
  have h : env32136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32135_32136 : H12AffineEnvironment.transform 4 10 env32135 = env32136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env32135 == env32136) = true)

theorem identity32136 : scanCanonicalize (H12AffineFastState.compose env32136 (packedSelected [0,2,3,4,7,8,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound32136 : packedSelected [0,2,3,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env32137 : List Nat := [2,4,8,16,10,64,88,94,512,31,2048,2560,2585,80,27,2627,0,2587,2590,26,2560,91,17,82,73,2624,2634,80,80,593,2580,2576,95,64,1,2049]

theorem envBound32137 : H12AffineFastState.Bounded env32137 := by
  intro p hp
  have h : env32137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32136_32137 : H12AffineEnvironment.transform 6 88 env32136 = env32137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env32136 == env32137) = true)

theorem identity32137 : scanCanonicalize (H12AffineFastState.compose env32137 (packedSelected [1,8] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound32137 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env32138 : List Nat := [2,4,8,16,10,64,88,94,1,31,2048,2049,2072,80,27,2114,0,2074,2079,26,2049,91,17,82,73,2113,2123,80,80,80,2069,2065,95,64,1,2049]

theorem envBound32138 : H12AffineFastState.Bounded env32138 := by
  intro p hp
  have h : env32138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32137_32138 : H12AffineEnvironment.transform 8 1 env32137 = env32138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env32137 == env32138) = true)

theorem identity32138 : scanCanonicalize (H12AffineFastState.compose env32138 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound32138 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env32139 : List Nat := [2,4,8,16,10,64,88,94,1,31,81,80,73,80,27,19,0,75,78,26,80,91,17,82,73,16,26,80,80,80,68,64,95,64,1,80]

theorem envBound32139 : H12AffineFastState.Bounded env32139 := by
  intro p hp
  have h : env32139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32138_32139 : H12AffineEnvironment.transform 10 81 env32138 = env32139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env32138 == env32139) = true)

theorem identity32139 : scanCanonicalize (H12AffineFastState.compose env32139 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 22) := by decide +kernel

theorem selectedBound32139 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env32140 : List Nat := [2,4,8,16,10,22,14,8,1,31,7,6,31,6,27,19,0,29,24,26,6,13,17,4,31,16,26,6,6,6,18,22,9,22,1,6]

theorem envBound32140 : H12AffineFastState.Bounded env32140 := by
  intro p hp
  have h : env32140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32139_32140 : H12AffineEnvironment.transform 5 22 env32139 = env32140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 22 env32139 == env32140) = true)

theorem identity32140 : scanCanonicalize (H12AffineFastState.compose env32140 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound32140 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env32141 : List Nat := [2,4,8,12,10,10,14,8,1,3,7,6,3,6,7,15,0,1,4,6,6,13,13,4,3,12,6,6,6,6,14,10,9,10,1,6]

theorem envBound32141 : H12AffineFastState.Bounded env32141 := by
  intro p hp
  have h : env32141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32140_32141 : H12AffineEnvironment.transform 3 12 env32140 = env32141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env32140 == env32141) = true)

theorem identity32141 : scanCanonicalize (H12AffineFastState.compose env32141 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound32141 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32142 : List Nat := [2,3,8,11,10,10,9,8,1,3,0,1,3,1,0,8,0,1,3,1,1,10,10,3,3,11,1,1,1,1,9,10,9,10,1,1]

theorem envBound32142 : H12AffineFastState.Bounded env32142 := by
  intro p hp
  have h : env32142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32141_32142 : H12AffineEnvironment.transform 1 3 env32141 = env32142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env32141 == env32142) = true)

def env32143 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5465,1297,324,5238,1344,5366,4416,325,4096,477,16,1127,144,5376,4414,1296,1297,7269,5460,5457,257,1281,1344,5952]

theorem envBound32143 : H12AffineFastState.Bounded env32143 := by
  intro p hp
  have h : env32143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32131_32143 : H12AffineEnvironment.transform 12 5465 env32131 = env32143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5465 env32131 == env32143) = true)

theorem identity32143 : scanCanonicalize (H12AffineFastState.compose env32143 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound32143 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env32144 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,4096,4444,276,324,4211,325,4339,4416,325,4096,477,16,98,144,4357,4414,277,276,6240,4433,4436,257,260,325,4933]

theorem envBound32144 : H12AffineFastState.Bounded env32144 := by
  intro p hp
  have h : env32144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32143_32144 : H12AffineEnvironment.transform 9 5 env32143 = env32144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env32143 == env32144) = true)

theorem identity32144 : scanCanonicalize (H12AffineFastState.compose env32144 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 325) := by decide +kernel

theorem selectedBound32144 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env32145 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,325,25,276,324,310,325,438,5,325,325,477,16,98,144,64,123,277,276,2341,20,17,257,260,325,512]

theorem envBound32145 : H12AffineFastState.Bounded env32145 := by
  intro p hp
  have h : env32145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32144_32145 : H12AffineEnvironment.transform 11 325 env32144 = env32145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 325 env32144 == env32145) = true)

theorem identity32145 : scanCanonicalize (H12AffineFastState.compose env32145 (packedSelected [2,5,8,13] rootPS)) = affineNative (2^(10+1) ^^^ 470) := by decide +kernel

theorem selectedBound32145 : packedSelected [2,5,8,13] rootPS < 2^1333 := by decide +kernel

def env32146 : List Nat := [2,4,8,16,32,64,128,256,512,5,470,325,25,276,324,310,325,438,5,325,325,477,16,98,144,64,123,277,276,243,20,17,257,260,325,512]

theorem envBound32146 : H12AffineFastState.Bounded env32146 := by
  intro p hp
  have h : env32146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32145_32146 : H12AffineEnvironment.transform 10 470 env32145 = env32146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 470 env32145 == env32146) = true)

theorem identity32146 : scanCanonicalize (H12AffineFastState.compose env32146 (packedSelected [0,2,5,7,8,10,11] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound32146 : packedSelected [0,2,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env32147 : List Nat := [2,4,8,16,32,64,128,21,512,5,195,80,25,1,81,35,80,163,5,80,80,200,16,98,144,64,123,0,1,243,20,17,20,17,80,512]

theorem envBound32147 : H12AffineFastState.Bounded env32147 := by
  intro p hp
  have h : env32147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32146_32147 : H12AffineEnvironment.transform 7 21 env32146 = env32147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env32146 == env32147) = true)

theorem identity32147 : scanCanonicalize (H12AffineFastState.compose env32147 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound32147 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env32148 : List Nat := [2,4,8,16,32,58,128,21,512,5,185,42,25,1,43,35,42,163,5,42,42,178,16,24,144,58,1,0,1,137,20,17,20,17,42,512]

theorem envBound32148 : H12AffineFastState.Bounded env32148 := by
  intro p hp
  have h : env32148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32147_32148 : H12AffineEnvironment.transform 5 58 env32147 = env32148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env32147 == env32148) = true)

theorem identity32148 : scanCanonicalize (H12AffineFastState.compose env32148 (packedSelected [1,2] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound32148 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env32149 : List Nat := [2,4,8,12,32,38,128,9,512,5,165,42,5,1,43,35,42,163,5,42,42,174,12,4,140,38,1,0,1,137,8,13,8,13,42,512]

theorem envBound32149 : H12AffineFastState.Bounded env32149 := by
  intro p hp
  have h : env32149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32148_32149 : H12AffineEnvironment.transform 3 12 env32148 = env32149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env32148 == env32149) = true)

theorem identity32149 : scanCanonicalize (H12AffineFastState.compose env32149 (packedSelected [1,5] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound32149 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env32150 : List Nat := [2,4,8,12,32,38,8,9,512,5,45,42,5,1,43,35,42,43,5,42,42,38,12,4,4,38,1,0,1,1,8,13,8,13,42,512]

theorem envBound32150 : H12AffineFastState.Bounded env32150 := by
  intro p hp
  have h : env32150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32149_32150 : H12AffineEnvironment.transform 6 8 env32149 = env32150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32149 == env32150) = true)

theorem identity32150 : scanCanonicalize (H12AffineFastState.compose env32150 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound32150 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32151 : List Nat := [2,4,8,12,32,38,8,9,43,5,45,42,5,1,43,35,42,43,5,42,42,38,12,4,4,38,1,0,1,1,8,13,8,13,42,43]

theorem envBound32151 : H12AffineFastState.Bounded env32151 := by
  intro p hp
  have h : env32151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32150_32151 : H12AffineEnvironment.transform 8 43 env32150 = env32151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env32150 == env32151) = true)

theorem identity32151 : scanCanonicalize (H12AffineFastState.compose env32151 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound32151 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32152 : List Nat := [2,4,8,12,12,10,8,9,7,5,1,6,5,1,7,15,6,7,5,6,6,10,12,4,4,10,1,0,1,1,8,13,8,13,6,7]

theorem envBound32152 : H12AffineFastState.Bounded env32152 := by
  intro p hp
  have h : env32152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32151_32152 : H12AffineEnvironment.transform 4 12 env32151 = env32152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env32151 == env32152) = true)

theorem identity32152 : scanCanonicalize (H12AffineFastState.compose env32152 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound32152 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env32153 : List Nat := [2,2,8,10,10,10,8,9,1,3,1,0,3,1,1,9,0,1,3,0,0,10,10,2,2,10,1,0,1,1,8,11,8,11,0,1]

theorem envBound32153 : H12AffineFastState.Bounded env32153 := by
  intro p hp
  have h : env32153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32152_32153 : H12AffineEnvironment.transform 1 2 env32152 = env32153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env32152 == env32153) = true)

def env32154 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74863,65665,4416,13340,4096,477,74047,69649,13769,78895,4415,74815,1297,81226,8205,65831,257,1281,1344,5952]

theorem envBound32154 : H12AffineFastState.Bounded env32154 := by
  intro p hp
  have h : env32154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32129_32154 : H12AffineEnvironment.transform 17 65665 env32129 = env32154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env32129 == env32154) = true)

theorem identity32154 : scanCanonicalize (H12AffineFastState.compose env32154 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 311) := by decide +kernel

theorem selectedBound32154 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env32155 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,311,9560,438,4416,13340,4096,477,8200,4390,13769,13592,4415,9480,1297,15485,8205,16,257,1281,1344,5952]

theorem envBound32155 : H12AffineFastState.Bounded env32155 := by
  intro p hp
  have h : env32155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32154_32155 : H12AffineEnvironment.transform 15 311 env32154 = env32155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 311 env32154 == env32155) = true)

def env32156 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,1,12557,311,8264,438,4416,12556,4096,477,8200,4390,12505,12296,4415,8216,1,14701,8205,16,257,17,80,4688]

theorem envBound32156 : H12AffineFastState.Bounded env32156 := by
  intro p hp
  have h : env32156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32155_32156 : H12AffineEnvironment.transform 9 272 env32155 = env32156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env32155 == env32156) = true)

theorem identity32156 : scanCanonicalize (H12AffineFastState.compose env32156 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 325) := by decide +kernel

theorem selectedBound32156 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env32157 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,325,8192,1,8264,311,8264,438,5,8265,325,477,8200,99,8604,8525,122,8216,1,10280,8205,16,257,17,80,789]

theorem envBound32157 : H12AffineFastState.Bounded env32157 := by
  intro p hp
  have h : env32157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32156_32157 : H12AffineEnvironment.transform 11 325 env32156 = env32157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 325 env32156 == env32157) = true)

theorem identity32157 : scanCanonicalize (H12AffineFastState.compose env32157 (packedSelected [0,3,4,5,7,9,10,12,13,15,18,23] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound32157 : packedSelected [0,3,4,5,7,9,10,12,13,15,18,23] rootPS < 2^1333 := by decide +kernel

def env32158 : List Nat := [2,4,8,16,32,64,128,173,512,189,2048,232,8192,1,8264,154,8264,27,5,8265,232,112,8200,99,8241,8416,122,8216,1,10280,8205,16,172,17,80,696]

theorem envBound32158 : H12AffineFastState.Bounded env32158 := by
  intro p hp
  have h : env32158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32157_32158 : H12AffineEnvironment.transform 7 173 env32157 = env32158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env32157 == env32158) = true)

theorem identity32158 : scanCanonicalize (H12AffineFastState.compose env32158 (packedSelected [0,3,5,7,10,12,13,18] rootPS)) = affineNative (2^(12+1) ^^^ 2235) := by decide +kernel

theorem selectedBound32158 : packedSelected [0,3,5,7,10,12,13,18] rootPS < 2^1333 := by decide +kernel

def env32159 : List Nat := [2,4,8,16,32,64,128,173,512,189,2048,232,2235,1,2291,154,2291,27,5,2290,232,112,2227,99,2186,2139,122,2211,1,147,2230,16,172,17,80,696]

theorem envBound32159 : H12AffineFastState.Bounded env32159 := by
  intro p hp
  have h : env32159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32158_32159 : H12AffineEnvironment.transform 12 2235 env32158 = env32159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2235 env32158 == env32159) = true)

theorem identity32159 : scanCanonicalize (H12AffineFastState.compose env32159 (packedSelected [0,1,3,4,5,7,8,9,15,16] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound32159 : packedSelected [0,1,3,4,5,7,8,9,15,16] rootPS < 2^1333 := by decide +kernel

def env32160 : List Nat := [2,4,8,10,32,64,128,173,512,167,2048,232,2209,1,2281,128,2281,1,5,2280,232,106,2217,99,2186,2113,96,2211,1,137,2220,10,172,11,74,674]

theorem envBound32160 : H12AffineFastState.Bounded env32160 := by
  intro p hp
  have h : env32160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32159_32160 : H12AffineEnvironment.transform 3 10 env32159 = env32160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env32159 == env32160) = true)

theorem identity32160 : scanCanonicalize (H12AffineFastState.compose env32160 (packedSelected [1,4,5,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 133) := by decide +kernel

theorem selectedBound32160 : packedSelected [1,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env32161 : List Nat := [2,4,8,10,32,64,128,173,512,167,133,232,36,1,108,128,108,1,5,109,232,106,44,99,15,196,96,38,1,137,41,10,172,11,74,674]

theorem envBound32161 : H12AffineFastState.Bounded env32161 := by
  intro p hp
  have h : env32161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32160_32161 : H12AffineEnvironment.transform 10 133 env32160 = env32161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 133 env32160 == env32161) = true)

theorem identity32161 : scanCanonicalize (H12AffineFastState.compose env32161 (packedSelected [1,8,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound32161 : packedSelected [1,8,10,11] rootPS < 2^1333 := by decide +kernel

def env32162 : List Nat := [2,4,8,10,32,64,34,15,512,5,39,74,36,1,108,34,108,1,5,109,74,106,44,99,15,102,96,38,1,43,41,10,14,11,74,512]

theorem envBound32162 : H12AffineFastState.Bounded env32162 := by
  intro p hp
  have h : env32162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32161_32162 : H12AffineEnvironment.transform 6 34 env32161 = env32162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env32161 == env32162) = true)

theorem identity32162 : scanCanonicalize (H12AffineFastState.compose env32162 (packedSelected [0,1,3,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound32162 : packedSelected [0,1,3,4,5] rootPS < 2^1333 := by decide +kernel

def env32163 : List Nat := [2,4,8,10,32,33,34,15,512,5,39,43,36,1,13,34,13,1,5,12,43,11,44,2,15,7,1,38,1,43,41,10,14,11,43,512]

theorem envBound32163 : H12AffineFastState.Bounded env32163 := by
  intro p hp
  have h : env32163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32162_32163 : H12AffineEnvironment.transform 5 33 env32162 = env32163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env32162 == env32163) = true)

theorem identity32163 : scanCanonicalize (H12AffineFastState.compose env32163 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound32163 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env32164 : List Nat := [2,4,8,10,6,7,4,15,512,5,1,13,2,1,13,4,13,1,5,12,13,11,10,2,15,7,1,0,1,13,15,10,14,11,13,512]

theorem envBound32164 : H12AffineFastState.Bounded env32164 := by
  intro p hp
  have h : env32164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32163_32164 : H12AffineEnvironment.transform 4 6 env32163 = env32164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env32163 == env32164) = true)

theorem identity32164 : scanCanonicalize (H12AffineFastState.compose env32164 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 13) := by decide +kernel

theorem selectedBound32164 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32165 : List Nat := [2,4,8,10,6,7,4,15,13,5,1,13,2,1,13,4,13,1,5,12,13,11,10,2,15,7,1,0,1,13,15,10,14,11,13,13]

theorem envBound32165 : H12AffineFastState.Bounded env32165 := by
  intro p hp
  have h : env32165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32164_32165 : H12AffineEnvironment.transform 8 13 env32164 = env32165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 13 env32164 == env32165) = true)

theorem identity32165 : scanCanonicalize (H12AffineFastState.compose env32165 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound32165 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32166 : List Nat := [2,4,4,6,6,7,4,3,1,5,1,1,2,1,1,4,1,1,5,0,1,7,6,2,3,7,1,0,1,1,3,6,2,7,1,1]

theorem envBound32166 : H12AffineFastState.Bounded env32166 := by
  intro p hp
  have h : env32166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32165_32166 : H12AffineEnvironment.transform 2 4 env32165 = env32166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env32165 == env32166) = true)

def env32167 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,0,12556,311,8265,438,4416,12557,4096,477,8200,4390,12504,12297,4415,8217,0,14700,8205,16,257,16,81,4689]

theorem envBound32167 : H12AffineFastState.Bounded env32167 := by
  intro p hp
  have h : env32167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32155_32167 : H12AffineEnvironment.transform 9 273 env32155 = env32167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env32155 == env32167) = true)

theorem identity32167 : scanCanonicalize (H12AffineFastState.compose env32167 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 72) := by decide +kernel

theorem selectedBound32167 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env32168 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,72,0,4420,311,1,438,4416,4421,4096,477,64,4390,4240,4161,4415,81,0,6436,69,16,257,16,81,4689]

theorem envBound32168 : H12AffineFastState.Bounded env32168 := by
  intro p hp
  have h : env32168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32167_32168 : H12AffineEnvironment.transform 12 72 env32167 = env32168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env32167 == env32168) = true)

theorem identity32168 : scanCanonicalize (H12AffineFastState.compose env32168 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 325) := by decide +kernel

theorem selectedBound32168 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env32169 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,325,72,0,1,311,1,438,5,0,325,477,64,99,469,260,122,81,0,2145,69,16,257,16,81,788]

theorem envBound32169 : H12AffineFastState.Bounded env32169 := by
  intro p hp
  have h : env32169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32168_32169 : H12AffineEnvironment.transform 11 325 env32168 = env32169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 325 env32168 == env32169) = true)

theorem identity32169 : scanCanonicalize (H12AffineFastState.compose env32169 (packedSelected [0,2,3,7,10,11,12,13,15,19] rootPS)) = affineNative (2^(10+1) ^^^ 541) := by decide +kernel

theorem selectedBound32169 : packedSelected [0,2,3,7,10,11,12,13,15,19] rootPS < 2^1333 := by decide +kernel

def env32170 : List Nat := [2,4,8,16,32,64,128,256,512,273,541,325,72,0,1,311,1,438,5,0,325,477,64,99,469,260,122,81,0,636,69,16,257,16,81,788]

theorem envBound32170 : H12AffineFastState.Bounded env32170 := by
  intro p hp
  have h : env32170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32169_32170 : H12AffineEnvironment.transform 10 541 env32169 = env32170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 541 env32169 == env32170) = true)

theorem identity32170 : scanCanonicalize (H12AffineFastState.compose env32170 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound32170 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env32171 : List Nat := [2,4,8,16,32,64,128,20,512,5,541,81,72,0,1,35,1,162,5,0,81,201,64,99,193,16,122,81,0,636,69,16,21,16,81,512]

theorem envBound32171 : H12AffineFastState.Bounded env32171 := by
  intro p hp
  have h : env32171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32170_32171 : H12AffineEnvironment.transform 7 20 env32170 = env32171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env32170 == env32171) = true)

theorem identity32171 : scanCanonicalize (H12AffineFastState.compose env32171 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 216) := by decide +kernel

theorem selectedBound32171 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32172 : List Nat := [2,4,8,16,32,64,128,20,216,5,197,81,72,0,1,35,1,162,5,0,81,201,64,99,193,16,122,81,0,164,69,16,21,16,81,216]

theorem envBound32172 : H12AffineFastState.Bounded env32172 := by
  intro p hp
  have h : env32172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32171_32172 : H12AffineEnvironment.transform 8 216 env32171 = env32172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env32171 == env32172) = true)

theorem identity32172 : scanCanonicalize (H12AffineFastState.compose env32172 (packedSelected [1,2,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound32172 : packedSelected [1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env32173 : List Nat := [2,4,8,16,32,13,128,20,149,5,136,28,5,0,1,35,1,162,5,0,28,132,13,46,140,16,55,28,0,164,8,16,21,16,28,149]

theorem envBound32173 : H12AffineFastState.Bounded env32173 := by
  intro p hp
  have h : env32173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32172_32173 : H12AffineEnvironment.transform 5 13 env32172 = env32173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env32172 == env32173) = true)

theorem identity32173 : scanCanonicalize (H12AffineFastState.compose env32173 (packedSelected [0,3,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound32173 : packedSelected [0,3,4,7] rootPS < 2^1333 := by decide +kernel

def env32174 : List Nat := [2,4,8,16,12,13,128,20,149,5,136,28,5,0,1,15,1,142,5,0,28,132,13,2,140,16,27,28,0,136,8,16,21,16,28,149]

theorem envBound32174 : H12AffineFastState.Bounded env32174 := by
  intro p hp
  have h : env32174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32173_32174 : H12AffineEnvironment.transform 4 12 env32173 = env32174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env32173 == env32174) = true)

theorem identity32174 : scanCanonicalize (H12AffineFastState.compose env32174 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 20) := by decide +kernel

theorem selectedBound32174 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32175 : List Nat := [2,4,8,16,12,13,20,20,1,5,28,28,5,0,1,15,1,26,5,0,28,16,13,2,24,16,27,28,0,28,8,16,21,16,28,1]

theorem envBound32175 : H12AffineFastState.Bounded env32175 := by
  intro p hp
  have h : env32175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32174_32175 : H12AffineEnvironment.transform 6 20 env32174 = env32175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 20 env32174 == env32175) = true)

theorem identity32175 : scanCanonicalize (H12AffineFastState.compose env32175 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound32175 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32176 : List Nat := [2,4,8,12,12,13,8,8,1,5,0,0,5,0,1,15,1,6,5,0,0,12,13,2,4,12,7,0,0,0,8,12,9,12,0,1]

theorem envBound32176 : H12AffineFastState.Bounded env32176 := by
  intro p hp
  have h : env32176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32175_32176 : H12AffineEnvironment.transform 3 12 env32175 = env32176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env32175 == env32176) = true)

theorem identity32176 : scanCanonicalize (H12AffineFastState.compose env32176 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound32176 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env32177 : List Nat := [2,3,8,11,11,10,8,8,1,2,0,0,2,0,1,8,1,1,2,0,0,11,10,2,3,11,0,0,0,0,8,11,9,11,0,1]

theorem envBound32177 : H12AffineFastState.Bounded env32177 := by
  intro p hp
  have h : env32177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32176_32177 : H12AffineEnvironment.transform 1 3 env32176 = env32177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env32176 == env32177) = true)

def env32178 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,16777216,533641,672785,17245633,148801,545088,96347,16876545,16819499,257,545104,1345,525824]

theorem envBound32178 : H12AffineFastState.Bounded env32178 := by
  intro p hp
  have h : env32178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31450_32178 : H12AffineEnvironment.transform 26 17245633 env31450 = env32178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env31450 == env32178) = true)

theorem identity32178 : scanCanonicalize (H12AffineFastState.compose env32178 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(18+1) ^^^ 95615) := by decide +kernel

theorem selectedBound32178 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env32179 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95615,32769,4096,61649,147521,16777216,86518,209262,17245633,148801,74815,96347,16876545,16819499,257,74799,1345,95103]

theorem envBound32179 : H12AffineFastState.Bounded env32179 := by
  intro p hp
  have h : env32179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32178_32179 : H12AffineEnvironment.transform 18 95615 env32178 = env32179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 95615 env32178 == env32179) = true)

def env32180 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95615,32769,4096,61649,147521,284032,86518,209262,225345,148801,74815,96347,381313,323755,257,74799,1345,95103]

theorem envBound32180 : H12AffineFastState.Bounded env32180 := by
  intro p hp
  have h : env32180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32179_32180 : H12AffineEnvironment.transform 23 284032 env32179 = env32180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284032 env32179 == env32180) = true)

def env32181 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16464,262144,95615,32769,4096,61649,17,284032,86518,94526,77841,1297,74815,96347,381313,323755,257,74799,1345,95103]

theorem envBound32181 : H12AffineFastState.Bounded env32181 := by
  intro p hp
  have h : env32181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32180_32181 : H12AffineEnvironment.transform 16 16464 env32180 = env32181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16464 env32180 == env32181) = true)

def env32182 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1344,262144,77935,32769,4096,46529,17,266384,70886,78894,77841,1297,74815,81227,365713,308667,257,74799,1345,79471]

theorem envBound32182 : H12AffineFastState.Bounded env32182 := by
  intro p hp
  have h : env32182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32181_32182 : H12AffineEnvironment.transform 13 1296 env32181 = env32182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env32181 == env32182) = true)

theorem identity32182 : scanCanonicalize (H12AffineFastState.compose env32182 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound32182 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env32183 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1344,262144,77935,13340,4096,476,17,266384,70886,78894,77841,1297,74815,81227,336012,262566,257,74799,1345,79471]

theorem envBound32183 : H12AffineFastState.Bounded env32183 := by
  intro p hp
  have h : env32183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32182_32183 : H12AffineEnvironment.transform 14 13341 env32182 = env32183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env32182 == env32183) = true)

def env32184 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1344,65664,77935,13340,4096,476,17,69648,70886,78894,77841,1297,74815,81227,8204,65830,257,74799,1345,79471]

theorem envBound32184 : H12AffineFastState.Bounded env32184 := by
  intro p hp
  have h : env32184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32183_32184 : H12AffineEnvironment.transform 17 65664 env32183 = env32184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env32183 == env32184) = true)

theorem identity32184 : scanCanonicalize (H12AffineFastState.compose env32184 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5465) := by decide +kernel

theorem selectedBound32184 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env32185 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5465,1296,324,65536,1344,65664,66870,325,4096,476,17,69648,70886,65911,66888,1297,69990,67602,5461,65830,257,70006,1345,66358]

theorem envBound32185 : H12AffineFastState.Bounded env32185 := by
  intro p hp
  have h : env32185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32184_32185 : H12AffineEnvironment.transform 12 5465 env32184 = env32185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5465 env32184 == env32185) = true)

def env32186 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5385,1296,276,65536,1296,65664,66870,277,4096,396,17,69648,70838,65831,66840,1297,69942,67602,5381,65830,257,69926,1297,66358]

theorem envBound32186 : H12AffineFastState.Bounded env32186 := by
  intro p hp
  have h : env32186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32185_32186 : H12AffineEnvironment.transform 5 16 env32185 = env32186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32185 == env32186) = true)

theorem identity32186 : scanCanonicalize (H12AffineFastState.compose env32186 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound32186 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env32187 : List Nat := [2,4,8,16,32,16,128,256,512,4,2048,4096,4365,276,276,65536,276,65664,65842,277,4096,396,17,69648,69810,65831,65820,277,69942,67602,4353,65830,257,69926,277,66358]

theorem envBound32187 : H12AffineFastState.Bounded env32187 := by
  intro p hp
  have h : env32187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32186_32187 : H12AffineEnvironment.transform 9 4 env32186 = env32187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env32186 == env32187) = true)

theorem identity32187 : scanCanonicalize (H12AffineFastState.compose env32187 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 4130) := by decide +kernel

theorem selectedBound32187 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env32188 : List Nat := [2,4,8,16,32,16,128,256,512,4,2048,4096,4365,276,276,4130,276,4258,4368,277,4096,396,17,50,144,4357,4414,277,276,6192,4353,4356,257,260,277,4884]

theorem envBound32188 : H12AffineFastState.Bounded env32188 := by
  intro p hp
  have h : env32188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32187_32188 : H12AffineEnvironment.transform 15 4130 env32187 = env32188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4130 env32187 == env32188) = true)

theorem identity32188 : scanCanonicalize (H12AffineFastState.compose env32188 (packedSelected [0,2,3,7,8,10,12,15,17,18,19] rootPS)) = affineNative (2^(8+1) ^^^ 438) := by decide +kernel

theorem selectedBound32188 : packedSelected [0,2,3,7,8,10,12,15,17,18,19] rootPS < 2^1333 := by decide +kernel

def env32189 : List Nat := [2,4,8,16,32,16,128,256,438,4,2048,4096,4365,276,276,4130,276,4258,4368,277,4096,396,17,50,144,4357,4414,277,276,6192,4353,4356,257,260,277,4258]

theorem envBound32189 : H12AffineFastState.Bounded env32189 := by
  intro p hp
  have h : env32189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32188_32189 : H12AffineEnvironment.transform 8 438 env32188 = env32189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 438 env32188 == env32189) = true)

theorem identity32189 : scanCanonicalize (H12AffineFastState.compose env32189 (packedSelected [2,3,5,12,13,15,17] rootPS)) = affineNative (2^(11+1) ^^^ 2097) := by decide +kernel

theorem selectedBound32189 : packedSelected [2,3,5,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env32190 : List Nat := [2,4,8,16,32,16,128,256,438,4,2048,2097,2364,276,276,2067,276,2195,2337,277,2097,396,17,50,144,2356,2319,277,276,1,2352,2357,257,260,277,2195]

theorem envBound32190 : H12AffineFastState.Bounded env32190 := by
  intro p hp
  have h : env32190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32189_32190 : H12AffineEnvironment.transform 11 2097 env32189 = env32190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2097 env32189 == env32190) = true)

theorem identity32190 : scanCanonicalize (H12AffineFastState.compose env32190 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 183) := by decide +kernel

theorem selectedBound32190 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32191 : List Nat := [2,4,8,16,32,16,128,183,1,4,2048,2097,2187,163,163,2067,163,2195,2198,162,2097,59,17,50,144,2179,2232,162,163,1,2183,2178,182,179,162,2195]

theorem envBound32191 : H12AffineFastState.Bounded env32191 := by
  intro p hp
  have h : env32191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32190_32191 : H12AffineEnvironment.transform 7 183 env32190 = env32191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 183 env32190 == env32191) = true)

theorem identity32191 : scanCanonicalize (H12AffineFastState.compose env32191 (packedSelected [0,1,4,7,8,9,10] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound32191 : packedSelected [0,1,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env32192 : List Nat := [2,4,8,10,32,10,128,173,1,4,2048,2091,2187,163,163,2057,163,2185,2188,162,2091,33,11,40,138,2179,2210,162,163,1,2183,2178,172,169,162,2185]

theorem envBound32192 : H12AffineFastState.Bounded env32192 := by
  intro p hp
  have h : env32192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32191_32192 : H12AffineEnvironment.transform 3 10 env32191 = env32192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env32191 == env32192) = true)

theorem identity32192 : scanCanonicalize (H12AffineFastState.compose env32192 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 162) := by decide +kernel

theorem selectedBound32192 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env32193 : List Nat := [2,4,8,10,32,10,128,173,1,4,162,137,41,163,163,171,163,43,46,162,137,33,11,40,138,33,0,162,163,1,37,32,172,169,162,43]

theorem envBound32193 : H12AffineFastState.Bounded env32193 := by
  intro p hp
  have h : env32193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32192_32193 : H12AffineEnvironment.transform 10 162 env32192 = env32193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 162 env32192 == env32193) = true)

theorem identity32193 : scanCanonicalize (H12AffineFastState.compose env32193 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound32193 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32194 : List Nat := [2,4,8,10,32,10,8,37,1,4,42,1,41,43,43,35,43,43,46,42,1,33,11,40,2,33,0,42,43,1,37,32,36,33,42,43]

theorem envBound32194 : H12AffineFastState.Bounded env32194 := by
  intro p hp
  have h : env32194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32193_32194 : H12AffineEnvironment.transform 6 8 env32193 = env32194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32193 == env32194) = true)

theorem identity32194 : scanCanonicalize (H12AffineFastState.compose env32194 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound32194 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32195 : List Nat := [2,4,8,10,12,10,8,9,1,4,6,1,5,7,7,15,7,7,2,6,1,13,11,4,2,13,0,6,7,1,9,12,8,13,6,7]

theorem envBound32195 : H12AffineFastState.Bounded env32195 := by
  intro p hp
  have h : env32195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32194_32195 : H12AffineEnvironment.transform 4 12 env32194 = env32195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env32194 == env32195) = true)

def env32196 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,5384,1296,277,65536,1297,65664,66870,276,4096,397,17,69648,70839,65830,66841,1297,69943,67602,5380,65830,257,69927,1296,66358]

theorem envBound32196 : H12AffineFastState.Bounded env32196 := by
  intro p hp
  have h : env32196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32185_32196 : H12AffineEnvironment.transform 5 17 env32185 = env32196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32185 == env32196) = true)

theorem identity32196 : scanCanonicalize (H12AffineFastState.compose env32196 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 1331) := by decide +kernel

theorem selectedBound32196 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env32197 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,5384,1296,277,1331,1297,1459,5,276,4096,397,17,5411,4484,1045,42,1297,5124,3361,5380,1045,257,5140,1296,1541]

theorem envBound32197 : H12AffineFastState.Bounded env32197 := by
  intro p hp
  have h : env32197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32196_32197 : H12AffineEnvironment.transform 15 1331 env32196 = env32197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1331 env32196 == env32197) = true)

theorem identity32197 : scanCanonicalize (H12AffineFastState.compose env32197 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound32197 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env32198 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,277,1053,1296,277,1331,1297,1459,5,276,277,397,17,1078,145,1045,42,1297,1297,3361,1041,1045,257,1281,1296,1541]

theorem envBound32198 : H12AffineFastState.Bounded env32198 := by
  intro p hp
  have h : env32198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32197_32198 : H12AffineEnvironment.transform 11 277 env32197 = env32198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env32197 == env32198) = true)

theorem identity32198 : scanCanonicalize (H12AffineFastState.compose env32198 (packedSelected [0,2,3,7,8,11,12,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 185) := by decide +kernel

theorem selectedBound32198 : packedSelected [0,2,3,7,8,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env32199 : List Nat := [2,4,8,16,32,17,128,256,512,1024,185,277,1053,1296,277,1331,1297,1459,5,276,277,397,17,1078,145,1045,42,1297,1297,1432,1041,1045,257,1281,1296,1541]

theorem envBound32199 : H12AffineFastState.Bounded env32199 := by
  intro p hp
  have h : env32199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32198_32199 : H12AffineEnvironment.transform 10 185 env32198 = env32199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 185 env32198 == env32199) = true)

theorem identity32199 : scanCanonicalize (H12AffineFastState.compose env32199 (packedSelected [1,2,8,10,15] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound32199 : packedSelected [1,2,8,10,15] rootPS < 2^1333 := by decide +kernel

def env32200 : List Nat := [2,4,8,16,32,17,128,256,1,1024,185,277,1053,1296,277,1331,1297,1459,5,276,277,397,17,1078,145,1045,42,1297,1297,1432,1041,1045,257,1281,1296,1028]

theorem envBound32200 : H12AffineFastState.Bounded env32200 := by
  intro p hp
  have h : env32200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32199_32200 : H12AffineEnvironment.transform 8 1 env32199 = env32200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env32199 == env32200) = true)

theorem identity32200 : scanCanonicalize (H12AffineFastState.compose env32200 (packedSelected [1,3,11,13,18] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound32200 : packedSelected [1,3,11,13,18] rootPS < 2^1333 := by decide +kernel

def env32201 : List Nat := [2,4,8,16,32,17,128,36,1,1024,185,49,1053,1076,49,1047,1077,1175,5,48,49,169,17,1078,145,1045,42,1077,1077,1212,1041,1045,37,1061,1076,1028]

theorem envBound32201 : H12AffineFastState.Bounded env32201 := by
  intro p hp
  have h : env32201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32200_32201 : H12AffineEnvironment.transform 7 36 env32200 = env32201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env32200 == env32201) = true)

theorem identity32201 : scanCanonicalize (H12AffineFastState.compose env32201 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound32201 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env32202 : List Nat := [2,4,8,16,32,17,35,36,1,1024,26,49,1053,1076,49,1047,1077,1076,5,48,49,10,17,1078,50,1045,42,1077,1077,1055,1041,1045,37,1061,1076,1028]

theorem envBound32202 : H12AffineFastState.Bounded env32202 := by
  intro p hp
  have h : env32202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32201_32202 : H12AffineEnvironment.transform 6 35 env32201 = env32202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env32201 == env32202) = true)

theorem identity32202 : scanCanonicalize (H12AffineFastState.compose env32202 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound32202 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env32203 : List Nat := [2,4,8,16,32,17,35,36,1,4,26,49,25,48,49,19,49,48,5,48,49,10,17,50,50,17,42,49,49,27,21,17,37,33,48,0]

theorem envBound32203 : H12AffineFastState.Bounded env32203 := by
  intro p hp
  have h : env32203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32202_32203 : H12AffineEnvironment.transform 9 4 env32202 = env32203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env32202 == env32203) = true)

theorem identity32203 : scanCanonicalize (H12AffineFastState.compose env32203 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound32203 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env32204 : List Nat := [2,4,8,16,3,17,0,7,1,4,26,18,25,19,18,19,18,19,5,19,18,10,17,17,17,17,9,18,18,27,21,17,6,2,19,0]

theorem envBound32204 : H12AffineFastState.Bounded env32204 := by
  intro p hp
  have h : env32204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32203_32204 : H12AffineEnvironment.transform 4 3 env32203 = env32204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env32203 == env32204) = true)

theorem identity32204 : scanCanonicalize (H12AffineFastState.compose env32204 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound32204 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32205 : List Nat := [2,4,8,3,3,2,0,7,1,4,9,1,10,0,1,0,1,0,5,0,1,10,2,2,2,2,9,1,1,8,6,2,6,2,0,0]

theorem envBound32205 : H12AffineFastState.Bounded env32205 := by
  intro p hp
  have h : env32205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32204_32205 : H12AffineEnvironment.transform 3 3 env32204 = env32205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env32204 == env32205) = true)

theorem identity32205 : scanCanonicalize (H12AffineFastState.compose env32205 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound32205 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32206 : List Nat := [2,0,8,3,3,2,0,3,1,0,9,1,10,0,1,0,1,0,1,0,1,10,2,2,2,2,9,1,1,8,2,2,2,2,0,0]

theorem envBound32206 : H12AffineFastState.Bounded env32206 := by
  intro p hp
  have h : env32206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart2