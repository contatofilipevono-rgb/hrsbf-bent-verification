import H12CloudChart2Data146

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity36597 : scanCanonicalize (H12AffineFastState.compose env36597 (packedSelected [7] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound36597 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env36598 : List Nat := [2,1,1,2,2,2,3,3,2,1,1,0,2,1,1,0,0,2,0,0,0,0,3,2,0,2,1,0,0,0,3,3,2,2,0,3]

theorem envBound36598 : H12AffineFastState.Bounded env36598 := by
  intro p hp
  have h : env36598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36597_36598 : H12AffineEnvironment.transform 3 2 env36597 = env36598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env36597 == env36598) = true)

def env36599 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,4096,73,80,4372,65536,65895,65665,4417,4373,4096,476,65911,69648,4288,69927,4414,65847,81,71746,68,65,257,65831,1,4436]

theorem envBound36599 : H12AffineFastState.Bounded env36599 := by
  intro p hp
  have h : env36599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36587_36599 : H12AffineEnvironment.transform 9 321 env36587 = env36599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env36587 == env36599) = true)

theorem identity36599 : scanCanonicalize (H12AffineFastState.compose env36599 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound36599 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env36600 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,277,73,80,1,65536,65895,65665,84,0,277,476,65911,65797,469,65586,43,65847,81,67927,68,65,257,65831,1,65]

theorem envBound36600 : H12AffineFastState.Bounded env36600 := by
  intro p hp
  have h : env36600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36599_36600 : H12AffineEnvironment.transform 11 277 env36599 = env36600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env36599 == env36600) = true)

theorem identity36600 : scanCanonicalize (H12AffineFastState.compose env36600 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 334) := by decide +kernel

theorem selectedBound36600 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env36601 : List Nat := [2,4,8,16,32,64,128,256,340,321,334,277,73,80,1,65536,65895,65665,84,0,277,476,65911,65797,469,65586,43,65847,81,65561,68,65,257,65831,1,65]

theorem envBound36601 : H12AffineFastState.Bounded env36601 := by
  intro p hp
  have h : env36601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36600_36601 : H12AffineEnvironment.transform 10 334 env36600 = env36601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 334 env36600 == env36601) = true)

theorem identity36601 : scanCanonicalize (H12AffineFastState.compose env36601 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound36601 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env36602 : List Nat := [2,4,8,16,32,64,128,256,340,321,334,277,73,80,1,34,325,163,84,0,277,476,341,295,469,16,43,277,81,59,68,65,257,261,1,65]

theorem envBound36602 : H12AffineFastState.Bounded env36602 := by
  intro p hp
  have h : env36602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36601_36602 : H12AffineEnvironment.transform 15 34 env36601 = env36602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env36601 == env36602) = true)

theorem identity36602 : scanCanonicalize (H12AffineFastState.compose env36602 (packedSelected [0,1,2,5,7,8,11,12,13] rootPS)) = affineNative (2^(7+1) ^^^ 234) := by decide +kernel

theorem selectedBound36602 : packedSelected [0,1,2,5,7,8,11,12,13] rootPS < 2^1333 := by decide +kernel

def env36603 : List Nat := [2,4,8,16,32,64,128,234,190,171,164,255,73,80,1,34,175,163,84,0,255,54,191,205,63,16,43,255,81,59,68,65,235,239,1,65]

theorem envBound36603 : H12AffineFastState.Bounded env36603 := by
  intro p hp
  have h : env36603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36602_36603 : H12AffineEnvironment.transform 7 234 env36602 = env36603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 234 env36602 == env36603) = true)

theorem identity36603 : scanCanonicalize (H12AffineFastState.compose env36603 (packedSelected [2,5,12,15,17] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound36603 : packedSelected [2,5,12,15,17] rootPS < 2^1333 := by decide +kernel

def env36604 : List Nat := [2,4,8,16,32,17,128,187,190,171,164,174,24,1,1,34,175,163,5,0,174,54,191,156,63,16,43,174,0,59,21,16,186,190,1,16]

theorem envBound36604 : H12AffineFastState.Bounded env36604 := by
  intro p hp
  have h : env36604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36603_36604 : H12AffineEnvironment.transform 5 17 env36603 = env36604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env36603 == env36604) = true)

theorem identity36604 : scanCanonicalize (H12AffineFastState.compose env36604 (packedSelected [2,3,8] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound36604 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env36605 : List Nat := [2,4,2,16,32,17,128,177,180,161,164,164,18,1,1,34,165,163,5,0,164,54,181,150,53,16,33,164,0,49,21,16,176,180,1,16]

theorem envBound36605 : H12AffineFastState.Bounded env36605 := by
  intro p hp
  have h : env36605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36604_36605 : H12AffineEnvironment.transform 2 2 env36604 = env36605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env36604 == env36605) = true)

theorem identity36605 : scanCanonicalize (H12AffineFastState.compose env36605 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound36605 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env36606 : List Nat := [2,4,2,16,0,17,128,145,148,129,132,132,18,1,1,2,133,131,5,0,132,22,149,150,21,16,1,132,0,17,21,16,144,148,1,16]

theorem envBound36606 : H12AffineFastState.Bounded env36606 := by
  intro p hp
  have h : env36606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36605_36606 : H12AffineEnvironment.transform 4 0 env36605 = env36606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env36605 == env36606) = true)

theorem identity36606 : scanCanonicalize (H12AffineFastState.compose env36606 (packedSelected [1,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 21) := by decide +kernel

theorem selectedBound36606 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env36607 : List Nat := [2,4,2,16,0,17,21,4,1,20,17,17,18,1,1,2,16,22,5,0,17,22,0,3,21,16,1,17,0,17,21,16,5,1,1,16]

theorem envBound36607 : H12AffineFastState.Bounded env36607 := by
  intro p hp
  have h : env36607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36606_36607 : H12AffineEnvironment.transform 6 21 env36606 = env36607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 21 env36606 == env36607) = true)

theorem identity36607 : scanCanonicalize (H12AffineFastState.compose env36607 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound36607 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36608 : List Nat := [2,4,2,6,0,7,3,4,1,2,7,7,4,1,1,2,6,0,5,0,7,0,0,3,3,6,1,7,0,7,3,6,5,1,1,6]

theorem envBound36608 : H12AffineFastState.Bounded env36608 := by
  intro p hp
  have h : env36608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36607_36608 : H12AffineEnvironment.transform 3 6 env36607 = env36608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env36607 == env36608) = true)

theorem identity36608 : scanCanonicalize (H12AffineFastState.compose env36608 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound36608 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env36609 : List Nat := [2,3,2,1,0,0,3,3,1,2,0,0,3,1,1,2,1,0,2,0,0,0,0,3,3,1,1,0,0,0,3,1,2,1,1,1]

theorem envBound36609 : H12AffineFastState.Bounded env36609 := by
  intro p hp
  have h : env36609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36608_36609 : H12AffineEnvironment.transform 1 3 env36608 = env36609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env36608 == env36609) = true)

def env36610 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,4096,73,1297,5205,65536,66598,65665,4417,5204,4096,476,65911,69648,5505,70758,4414,66678,1296,72963,68,65,257,66662,1344,5140]

theorem envBound36610 : H12AffineFastState.Bounded env36610 := by
  intro p hp
  have h : env36610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36586_36610 : H12AffineEnvironment.transform 8 341 env36586 = env36610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env36586 == env36610) = true)

def env36611 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,4096,73,81,4373,65536,65894,65665,4417,4372,4096,476,65911,69648,4289,69926,4414,65846,80,71747,68,65,257,65830,0,4436]

theorem envBound36611 : H12AffineFastState.Bounded env36611 := by
  intro p hp
  have h : env36611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36610_36611 : H12AffineEnvironment.transform 9 320 env36610 = env36611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env36610 == env36611) = true)

theorem identity36611 : scanCanonicalize (H12AffineFastState.compose env36611 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound36611 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env36612 : List Nat := [2,4,8,16,32,64,128,20,65,84,2048,4096,73,81,4097,65536,65650,65665,4181,4096,4096,200,65635,69648,4289,69682,4138,65570,80,71747,68,65,21,65586,0,4160]

theorem envBound36612 : H12AffineFastState.Bounded env36612 := by
  intro p hp
  have h : env36612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36611_36612 : H12AffineEnvironment.transform 7 20 env36611 = env36612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env36611 == env36612) = true)

theorem identity36612 : scanCanonicalize (H12AffineFastState.compose env36612 (packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 179) := by decide +kernel

theorem selectedBound36612 : packedSelected [0,2,3,5,7,10,11,13,17,18,20] rootPS < 2^1333 := by decide +kernel

def env36613 : List Nat := [2,4,8,16,32,64,128,20,65,84,179,4096,73,81,4097,65536,65650,65665,4181,4096,4096,200,65635,69648,4289,69682,4138,65570,80,69872,68,65,21,65586,0,4160]

theorem envBound36613 : H12AffineFastState.Bounded env36613 := by
  intro p hp
  have h : env36613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36612_36613 : H12AffineEnvironment.transform 10 179 env36612 = env36613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 179 env36612 == env36613) = true)

theorem identity36613 : scanCanonicalize (H12AffineFastState.compose env36613 (packedSelected [2,11,17,18,21] rootPS)) = affineNative (2^(15+1) ^^^ 4210) := by decide +kernel

theorem selectedBound36613 : packedSelected [2,11,17,18,21] rootPS < 2^1333 := by decide +kernel

def env36614 : List Nat := [2,4,8,16,32,64,128,20,65,84,179,4096,73,81,4097,4210,4096,4339,4181,4096,4096,200,4113,98,4289,64,4138,4176,80,130,68,65,21,4160,0,4160]

theorem envBound36614 : H12AffineFastState.Bounded env36614 := by
  intro p hp
  have h : env36614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36613_36614 : H12AffineEnvironment.transform 15 4210 env36613 = env36614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4210 env36613 == env36614) = true)

theorem identity36614 : scanCanonicalize (H12AffineFastState.compose env36614 (packedSelected [2,5] rootPS)) = affineNative (2^(11+1) ^^^ 222) := by decide +kernel

theorem selectedBound36614 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env36615 : List Nat := [2,4,8,16,32,64,128,20,65,84,179,222,73,81,223,172,222,45,139,222,222,200,207,98,31,64,244,142,80,130,68,65,21,158,0,158]

theorem envBound36615 : H12AffineFastState.Bounded env36615 := by
  intro p hp
  have h : env36615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36614_36615 : H12AffineEnvironment.transform 11 222 env36614 = env36615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 222 env36614 == env36615) = true)

theorem identity36615 : scanCanonicalize (H12AffineFastState.compose env36615 (packedSelected [1,4,9,12,13,16] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound36615 : packedSelected [1,4,9,12,13,16] rootPS < 2^1333 := by decide +kernel

def env36616 : List Nat := [2,4,5,16,32,64,128,20,65,84,179,211,68,81,210,161,211,32,134,211,211,197,194,98,18,64,244,131,80,130,68,65,21,147,0,147]

theorem envBound36616 : H12AffineFastState.Bounded env36616 := by
  intro p hp
  have h : env36616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36615_36616 : H12AffineEnvironment.transform 2 5 env36615 = env36616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env36615 == env36616) = true)

theorem identity36616 : scanCanonicalize (H12AffineFastState.compose env36616 (packedSelected [1,2,3,8,10,12] rootPS)) = affineNative (2^(6+1) ^^^ 100) := by decide +kernel

theorem selectedBound36616 : packedSelected [1,2,3,8,10,12] rootPS < 2^1333 := by decide +kernel

def env36617 : List Nat := [2,4,5,16,32,64,100,20,65,84,87,55,68,81,54,69,55,32,98,55,55,33,38,98,18,64,16,103,80,102,68,65,21,119,0,119]

theorem envBound36617 : H12AffineFastState.Bounded env36617 := by
  intro p hp
  have h : env36617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36616_36617 : H12AffineEnvironment.transform 6 100 env36616 = env36617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 100 env36616 == env36617) = true)

theorem identity36617 : scanCanonicalize (H12AffineFastState.compose env36617 (packedSelected [3,8] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound36617 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env36618 : List Nat := [2,4,5,16,32,33,5,20,32,53,54,55,37,48,54,36,55,32,3,55,55,33,38,3,18,33,16,6,49,7,37,32,21,22,0,22]

theorem envBound36618 : H12AffineFastState.Bounded env36618 := by
  intro p hp
  have h : env36618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36617_36618 : H12AffineEnvironment.transform 5 33 env36617 = env36618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env36617 == env36618) = true)

theorem identity36618 : scanCanonicalize (H12AffineFastState.compose env36618 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound36618 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36619 : List Nat := [2,4,5,1,32,33,5,5,32,36,39,38,37,33,39,36,38,32,3,38,38,33,38,3,3,33,1,6,32,7,37,32,4,7,0,7]

theorem envBound36619 : H12AffineFastState.Bounded env36619 := by
  intro p hp
  have h : env36619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36618_36619 : H12AffineEnvironment.transform 3 1 env36618 = env36619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env36618 == env36619) = true)

theorem identity36619 : scanCanonicalize (H12AffineFastState.compose env36619 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound36619 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36620 : List Nat := [2,4,5,1,0,1,5,5,0,4,7,6,5,1,7,4,6,0,3,6,6,1,6,3,3,1,1,6,0,7,5,0,4,7,0,7]

theorem envBound36620 : H12AffineFastState.Bounded env36620 := by
  intro p hp
  have h : env36620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36619_36620 : H12AffineEnvironment.transform 4 0 env36619 = env36620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env36619 == env36620) = true)

def env36621 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,4096,73,80,4372,65536,65895,65665,4417,4373,4096,476,65911,69648,4288,69927,4414,65847,81,71746,68,65,257,65831,1,4437]

theorem envBound36621 : H12AffineFastState.Bounded env36621 := by
  intro p hp
  have h : env36621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36610_36621 : H12AffineEnvironment.transform 9 321 env36610 = env36621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env36610 == env36621) = true)

theorem identity36621 : scanCanonicalize (H12AffineFastState.compose env36621 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound36621 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env36622 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,277,73,80,1,65536,65895,65665,84,0,277,476,65911,65797,469,65586,43,65847,81,67927,68,65,257,65831,1,64]

theorem envBound36622 : H12AffineFastState.Bounded env36622 := by
  intro p hp
  have h : env36622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36621_36622 : H12AffineEnvironment.transform 11 277 env36621 = env36622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env36621 == env36622) = true)

theorem identity36622 : scanCanonicalize (H12AffineFastState.compose env36622 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 335) := by decide +kernel

theorem selectedBound36622 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env36623 : List Nat := [2,4,8,16,32,64,128,256,341,321,335,277,73,80,1,65536,65895,65665,84,0,277,476,65911,65797,469,65586,43,65847,81,65560,68,65,257,65831,1,64]

theorem envBound36623 : H12AffineFastState.Bounded env36623 := by
  intro p hp
  have h : env36623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36622_36623 : H12AffineEnvironment.transform 10 335 env36622 = env36623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 335 env36622 == env36623) = true)

theorem identity36623 : scanCanonicalize (H12AffineFastState.compose env36623 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound36623 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env36624 : List Nat := [2,4,8,16,32,64,128,256,341,321,335,277,73,80,1,34,325,163,84,0,277,476,341,295,469,16,43,277,81,58,68,65,257,261,1,64]

theorem envBound36624 : H12AffineFastState.Bounded env36624 := by
  intro p hp
  have h : env36624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36623_36624 : H12AffineEnvironment.transform 15 34 env36623 = env36624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env36623 == env36624) = true)

theorem identity36624 : scanCanonicalize (H12AffineFastState.compose env36624 (packedSelected [0,1,2,5,7,8,11,12,13] rootPS)) = affineNative (2^(7+1) ^^^ 186) := by decide +kernel

theorem selectedBound36624 : packedSelected [0,1,2,5,7,8,11,12,13] rootPS < 2^1333 := by decide +kernel

def env36625 : List Nat := [2,4,8,16,32,64,128,186,239,251,245,175,73,80,1,34,255,163,84,0,175,102,239,157,111,16,43,175,81,58,68,65,187,191,1,64]

theorem envBound36625 : H12AffineFastState.Bounded env36625 := by
  intro p hp
  have h : env36625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36624_36625 : H12AffineEnvironment.transform 7 186 env36624 = env36625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 186 env36624 == env36625) = true)

theorem identity36625 : scanCanonicalize (H12AffineFastState.compose env36625 (packedSelected [2,5,12,15,17] rootPS)) = affineNative (2^(6+1) ^^^ 126) := by decide +kernel

theorem selectedBound36625 : packedSelected [2,5,12,15,17] rootPS < 2^1333 := by decide +kernel

def env36626 : List Nat := [2,4,8,16,32,64,126,68,17,5,11,81,73,80,1,34,1,93,84,0,81,102,17,99,111,16,43,81,81,58,68,65,69,65,1,64]

theorem envBound36626 : H12AffineFastState.Bounded env36626 := by
  intro p hp
  have h : env36626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36625_36626 : H12AffineEnvironment.transform 6 126 env36625 = env36626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 126 env36625 == env36626) = true)

theorem identity36626 : scanCanonicalize (H12AffineFastState.compose env36626 (packedSelected [5,8] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound36626 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env36627 : List Nat := [2,4,8,16,17,64,79,68,17,5,11,81,73,80,1,19,1,93,84,0,81,87,17,82,94,16,26,81,81,11,68,65,69,65,1,64]

theorem envBound36627 : H12AffineFastState.Bounded env36627 := by
  intro p hp
  have h : env36627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36626_36627 : H12AffineEnvironment.transform 4 17 env36626 = env36627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env36626 == env36627) = true)

theorem identity36627 : scanCanonicalize (H12AffineFastState.compose env36627 (packedSelected [2,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound36627 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env36628 : List Nat := [2,4,8,0,1,64,79,68,1,5,11,65,73,64,1,3,1,77,68,0,65,71,1,66,78,0,10,65,65,11,68,65,69,65,1,64]

theorem envBound36628 : H12AffineFastState.Bounded env36628 := by
  intro p hp
  have h : env36628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36627_36628 : H12AffineEnvironment.transform 3 0 env36627 = env36628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env36627 == env36628) = true)

theorem identity36628 : scanCanonicalize (H12AffineFastState.compose env36628 (packedSelected [1,2,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound36628 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env36629 : List Nat := [2,4,3,0,1,64,68,68,1,5,0,65,66,64,1,3,1,70,68,0,65,71,1,66,69,0,1,65,65,0,68,65,69,65,1,64]

theorem envBound36629 : H12AffineFastState.Bounded env36629 := by
  intro p hp
  have h : env36629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36628_36629 : H12AffineEnvironment.transform 2 3 env36628 = env36629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env36628 == env36629) = true)

def env36630 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21585,32769,4096,61649,91183,123165,28888,78894,385202,90414,1297,96347,25884,25880,257,74799,1344,21073]

theorem envBound36630 : H12AffineFastState.Bounded env36630 := by
  intro p hp
  have h : env36630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36389_36630 : H12AffineEnvironment.transform 18 21585 env36389 = env36630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env36389 == env36630) = true)

theorem identity36630 : scanCanonicalize (H12AffineFastState.compose env36630 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25676) := by decide +kernel

theorem selectedBound36630 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env36631 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25676,65536,74863,262144,21585,25677,4096,5277,91183,66897,28888,78894,328958,90414,1297,96347,25884,25880,257,74799,1344,21073]

theorem envBound36631 : H12AffineFastState.Bounded env36631 := by
  intro p hp
  have h : env36631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36630_36631 : H12AffineEnvironment.transform 14 25676 env36630 = env36631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25676 env36630 == env36631) = true)

def env36632 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74863,262144,4417,8541,4096,5277,74047,66897,13768,78894,328958,74814,1297,81227,8204,8200,257,74799,1344,5953]

theorem envBound36632 : H12AffineFastState.Bounded env36632 := by
  intro p hp
  have h : env36632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36631_36632 : H12AffineEnvironment.transform 13 1296 env36631 = env36632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env36631 == env36632) = true)

def env36633 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74863,65664,4417,8541,4096,5277,74047,66897,13768,78894,1150,74814,1297,81227,8204,8200,257,74799,1344,5953]

theorem envBound36633 : H12AffineFastState.Bounded env36633 := by
  intro p hp
  have h : env36633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36632_36633 : H12AffineEnvironment.transform 17 65664 env36632 = env36633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env36632 == env36633) = true)

theorem identity36633 : scanCanonicalize (H12AffineFastState.compose env36633 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound36633 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env36634 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,80,8540,65536,74031,65664,4417,8541,4096,4573,74047,65553,12424,78190,318,74110,81,79883,8204,8200,257,74095,0,4609]

theorem envBound36634 : H12AffineFastState.Bounded env36634 := by
  intro p hp
  have h : env36634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36633_36634 : H12AffineEnvironment.transform 9 320 env36633 = env36634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env36633 == env36634) = true)

def env36635 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,852,8192,80,8540,65536,74031,65664,533,8541,852,649,74047,65553,9180,74298,318,74110,81,76639,8204,8200,257,74095,0,341]

theorem envBound36635 : H12AffineFastState.Bounded env36635 := by
  intro p hp
  have h : env36635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36634_36635 : H12AffineEnvironment.transform 11 852 env36634 = env36635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 852 env36634 == env36635) = true)

def env36636 : List Nat := [2,4,8,0,32,64,128,256,512,320,2048,836,8192,64,8524,65536,74031,65664,517,8525,836,649,74031,65537,9164,74282,302,74094,65,76623,8204,8200,257,74095,0,325]

theorem envBound36636 : H12AffineFastState.Bounded env36636 := by
  intro p hp
  have h : env36636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36635_36636 : H12AffineEnvironment.transform 3 0 env36635 = env36636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env36635 == env36636) = true)

theorem identity36636 : scanCanonicalize (H12AffineFastState.compose env36636 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 167) := by decide +kernel

theorem selectedBound36636 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env36637 : List Nat := [2,4,8,0,32,64,128,256,512,320,2048,836,8192,64,8524,167,8584,39,517,8525,836,649,8584,166,9164,8845,302,8649,65,11240,8204,8200,257,8648,0,325]

theorem envBound36637 : H12AffineFastState.Bounded env36637 := by
  intro p hp
  have h : env36637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36636_36637 : H12AffineEnvironment.transform 15 167 env36636 = env36637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 167 env36636 == env36637) = true)

def env36638 : List Nat := [2,4,8,0,32,64,128,256,512,320,2048,836,72,64,260,167,448,39,517,261,836,649,448,166,900,709,302,385,65,2976,68,64,257,384,0,325]

theorem envBound36638 : H12AffineFastState.Bounded env36638 := by
  intro p hp
  have h : env36638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36637_36638 : H12AffineEnvironment.transform 12 72 env36637 = env36638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env36637 == env36638) = true)

theorem identity36638 : scanCanonicalize (H12AffineFastState.compose env36638 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound36638 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env36639 : List Nat := [2,4,8,0,32,64,128,5,512,69,2048,577,72,64,1,167,197,39,517,0,577,649,197,166,641,709,43,132,65,2725,68,64,4,133,0,64]

theorem envBound36639 : H12AffineFastState.Bounded env36639 := by
  intro p hp
  have h : env36639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36638_36639 : H12AffineEnvironment.transform 7 5 env36638 = env36639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env36638 == env36639) = true)

theorem identity36639 : scanCanonicalize (H12AffineFastState.compose env36639 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound36639 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env36640 : List Nat := [2,4,8,0,32,1,128,5,512,4,2048,512,9,1,1,167,132,39,517,0,512,649,132,166,641,644,43,132,0,2725,5,1,4,133,0,1]

theorem envBound36640 : H12AffineFastState.Bounded env36640 := by
  intro p hp
  have h : env36640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36639_36640 : H12AffineEnvironment.transform 5 1 env36639 = env36640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env36639 == env36640) = true)

theorem identity36640 : scanCanonicalize (H12AffineFastState.compose env36640 (packedSelected [1,2,5,8] rootPS)) = affineNative (2^(8+1) ^^^ 44) := by decide +kernel

theorem selectedBound36640 : packedSelected [1,2,5,8] rootPS < 2^1333 := by decide +kernel

def env36641 : List Nat := [2,4,8,0,32,1,128,5,44,4,2048,44,9,1,1,167,132,39,41,0,44,165,132,166,173,168,43,132,0,2185,5,1,4,133,0,1]

theorem envBound36641 : H12AffineFastState.Bounded env36641 := by
  intro p hp
  have h : env36641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36640_36641 : H12AffineEnvironment.transform 8 44 env36640 = env36641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 44 env36640 == env36641) = true)

theorem identity36641 : scanCanonicalize (H12AffineFastState.compose env36641 (packedSelected [2,4,5,9,10,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 130) := by decide +kernel

theorem selectedBound36641 : packedSelected [2,4,5,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env36642 : List Nat := [2,4,8,0,32,1,128,5,44,4,130,44,9,1,1,167,132,39,41,0,44,165,132,166,173,168,43,132,0,11,5,1,4,133,0,1]

theorem envBound36642 : H12AffineFastState.Bounded env36642 := by
  intro p hp
  have h : env36642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36641_36642 : H12AffineEnvironment.transform 10 130 env36641 = env36642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 130 env36641 == env36642) = true)

theorem identity36642 : scanCanonicalize (H12AffineFastState.compose env36642 (packedSelected [0,2,3,5,9] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound36642 : packedSelected [0,2,3,5,9] rootPS < 2^1333 := by decide +kernel

def env36643 : List Nat := [2,4,8,0,32,1,4,5,44,4,6,44,9,1,1,35,0,39,41,0,44,33,0,34,41,44,43,0,0,11,5,1,4,1,0,1]

theorem envBound36643 : H12AffineFastState.Bounded env36643 := by
  intro p hp
  have h : env36643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36642_36643 : H12AffineEnvironment.transform 6 4 env36642 = env36643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env36642 == env36643) = true)

theorem identity36643 : scanCanonicalize (H12AffineFastState.compose env36643 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound36643 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env36644 : List Nat := [2,4,8,0,7,1,4,5,11,4,6,11,9,1,1,4,0,0,14,0,11,6,0,5,14,11,12,0,0,11,5,1,4,1,0,1]

theorem envBound36644 : H12AffineFastState.Bounded env36644 := by
  intro p hp
  have h : env36644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36643_36644 : H12AffineEnvironment.transform 4 7 env36643 = env36644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env36643 == env36644) = true)

theorem identity36644 : scanCanonicalize (H12AffineFastState.compose env36644 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound36644 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36645 : List Nat := [2,4,2,0,7,1,4,5,1,4,6,1,3,1,1,4,0,0,4,0,1,6,0,5,4,1,6,0,0,1,5,1,4,1,0,1]

theorem envBound36645 : H12AffineFastState.Bounded env36645 := by
  intro p hp
  have h : env36645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36644_36645 : H12AffineEnvironment.transform 2 2 env36644 = env36645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env36644 == env36645) = true)

theorem identity36645 : scanCanonicalize (H12AffineFastState.compose env36645 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound36645 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36646 : List Nat := [2,2,2,0,1,1,2,3,1,2,0,1,3,1,1,2,0,0,2,0,1,0,0,3,2,1,0,0,0,1,3,1,2,1,0,1]

theorem envBound36646 : H12AffineFastState.Bounded env36646 := by
  intro p hp
  have h : env36646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36645_36646 : H12AffineEnvironment.transform 1 2 env36645 = env36646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env36645 == env36646) = true)

def env36647 : List Nat := [2,4,8,0,32,64,128,256,512,320,2048,836,73,64,261,167,449,39,517,260,836,649,449,166,901,708,302,384,65,2977,69,65,257,385,0,325]

theorem envBound36647 : H12AffineFastState.Bounded env36647 := by
  intro p hp
  have h : env36647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36637_36647 : H12AffineEnvironment.transform 12 73 env36637 = env36647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env36637 == env36647) = true)

theorem identity36647 : scanCanonicalize (H12AffineFastState.compose env36647 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound36647 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env36648 : List Nat := [2,4,8,0,32,64,128,256,64,320,2048,260,73,64,261,167,449,39,69,260,260,201,449,166,453,132,302,384,65,2529,69,65,257,385,0,325]

theorem envBound36648 : H12AffineFastState.Bounded env36648 := by
  intro p hp
  have h : env36648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36647_36648 : H12AffineEnvironment.transform 8 64 env36647 = env36648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env36647 == env36648) = true)

theorem identity36648 : scanCanonicalize (H12AffineFastState.compose env36648 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 193) := by decide +kernel

theorem selectedBound36648 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env36649 : List Nat := [2,4,8,0,32,64,128,193,64,129,2048,197,73,64,196,167,0,39,69,197,197,201,0,166,4,132,239,65,65,2080,69,65,192,64,0,132]

theorem envBound36649 : H12AffineFastState.Bounded env36649 := by
  intro p hp
  have h : env36649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36648_36649 : H12AffineEnvironment.transform 7 193 env36648 = env36649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 193 env36648 == env36649) = true)

theorem identity36649 : scanCanonicalize (H12AffineFastState.compose env36649 (packedSelected [8,13] rootPS)) = affineNative (2^(6+1) ^^^ 46) := by decide +kernel

theorem selectedBound36649 : packedSelected [8,13] rootPS < 2^1333 := by decide +kernel

def env36650 : List Nat := [2,4,8,0,32,64,46,111,64,47,2048,107,73,64,106,9,0,39,69,107,107,103,0,8,4,42,65,65,65,2080,69,65,110,64,0,42]

theorem envBound36650 : H12AffineFastState.Bounded env36650 := by
  intro p hp
  have h : env36650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36649_36650 : H12AffineEnvironment.transform 6 46 env36649 = env36650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 46 env36649 == env36650) = true)

theorem identity36650 : scanCanonicalize (H12AffineFastState.compose env36650 (packedSelected [0,1,2,3,7,8,10,11,12] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound36650 : packedSelected [0,1,2,3,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env36651 : List Nat := [2,4,2,0,32,64,36,101,64,37,2048,97,67,64,96,3,0,39,69,97,97,103,0,2,4,32,65,65,65,2080,69,65,100,64,0,32]

theorem envBound36651 : H12AffineFastState.Bounded env36651 := by
  intro p hp
  have h : env36651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36650_36651 : H12AffineEnvironment.transform 2 2 env36650 = env36651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env36650 == env36651) = true)

theorem identity36651 : scanCanonicalize (H12AffineFastState.compose env36651 (packedSelected [0,3,5,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound36651 : packedSelected [0,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env36652 : List Nat := [2,4,2,0,1,64,5,68,64,4,2048,64,67,64,65,3,0,6,69,64,64,70,0,2,4,1,65,65,65,2049,69,65,69,64,0,1]

theorem envBound36652 : H12AffineFastState.Bounded env36652 := by
  intro p hp
  have h : env36652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36651_36652 : H12AffineEnvironment.transform 4 1 env36651 = env36652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env36651 == env36652) = true)

def env36653 : List Nat := [2,4,8,1,32,64,128,256,512,320,2048,837,8192,65,8525,65536,74031,65664,516,8524,837,649,74030,65536,9165,74283,303,74095,64,76622,8204,8200,257,74095,0,324]

theorem envBound36653 : H12AffineFastState.Bounded env36653 := by
  intro p hp
  have h : env36653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36635_36653 : H12AffineEnvironment.transform 3 1 env36635 = env36653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env36635 == env36653) = true)

theorem identity36653 : scanCanonicalize (H12AffineFastState.compose env36653 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8430) := by decide +kernel

theorem selectedBound36653 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env36654 : List Nat := [2,4,8,1,32,64,128,256,512,320,2048,837,8192,65,8525,8430,449,8302,516,8524,837,649,448,8430,9165,709,303,385,64,2976,8204,8200,257,385,0,324]

theorem envBound36654 : H12AffineFastState.Bounded env36654 := by
  intro p hp
  have h : env36654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36653_36654 : H12AffineEnvironment.transform 15 8430 env36653 = env36654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8430 env36653 == env36654) = true)

def env36655 : List Nat := [2,4,8,1,32,64,128,256,512,320,2048,837,8,65,325,230,449,102,516,324,837,649,448,230,965,709,303,385,64,2976,4,0,257,385,0,324]

theorem envBound36655 : H12AffineFastState.Bounded env36655 := by
  intro p hp
  have h : env36655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36654_36655 : H12AffineEnvironment.transform 12 8 env36654 = env36655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env36654 == env36655) = true)

theorem identity36655 : scanCanonicalize (H12AffineFastState.compose env36655 (packedSelected [1,3,5,7,8,10,19,20,27] rootPS)) = affineNative (2^(8+1) ^^^ 324) := by decide +kernel

theorem selectedBound36655 : packedSelected [1,3,5,7,8,10,19,20,27] rootPS < 2^1333 := by decide +kernel

def env36656 : List Nat := [2,4,8,1,32,64,128,256,324,320,2048,1,8,65,325,230,449,102,320,324,1,461,448,230,129,385,303,385,64,2276,4,0,257,385,0,324]

theorem envBound36656 : H12AffineFastState.Bounded env36656 := by
  intro p hp
  have h : env36656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36655_36656 : H12AffineEnvironment.transform 8 324 env36655 = env36656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 324 env36655 == env36656) = true)

theorem identity36656 : scanCanonicalize (H12AffineFastState.compose env36656 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound36656 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env36657 : List Nat := [2,4,8,1,32,64,128,4,64,68,2048,1,8,65,65,230,197,102,68,64,1,201,196,230,129,133,43,133,64,2276,4,0,5,133,0,64]

theorem envBound36657 : H12AffineFastState.Bounded env36657 := by
  intro p hp
  have h : env36657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36656_36657 : H12AffineEnvironment.transform 7 4 env36656 = env36657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env36656 == env36657) = true)

theorem identity36657 : scanCanonicalize (H12AffineFastState.compose env36657 (packedSelected [0,1,2,5,7,8,11,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound36657 : packedSelected [0,1,2,5,7,8,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env36658 : List Nat := [2,4,8,1,32,64,128,4,64,68,10,1,8,65,65,230,197,102,68,64,1,201,196,230,129,133,43,133,64,238,4,0,5,133,0,64]

theorem envBound36658 : H12AffineFastState.Bounded env36658 := by
  intro p hp
  have h : env36658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36657_36658 : H12AffineEnvironment.transform 10 10 env36657 = env36658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env36657 == env36658) = true)

theorem identity36658 : scanCanonicalize (H12AffineFastState.compose env36658 (packedSelected [0,1,2,3,4,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound36658 : packedSelected [0,1,2,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env36659 : List Nat := [2,4,8,1,32,32,128,4,32,36,10,1,8,33,33,134,165,6,36,32,1,169,164,134,129,133,43,133,32,142,4,0,5,133,0,32]

theorem envBound36659 : H12AffineFastState.Bounded env36659 := by
  intro p hp
  have h : env36659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36658_36659 : H12AffineEnvironment.transform 5 32 env36658 = env36659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env36658 == env36659) = true)

theorem identity36659 : scanCanonicalize (H12AffineFastState.compose env36659 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound36659 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env36660 : List Nat := [2,4,8,1,13,13,128,4,13,9,10,1,8,12,12,134,136,6,9,13,1,132,137,134,129,133,6,133,13,142,4,0,5,133,0,13]

theorem envBound36660 : H12AffineFastState.Bounded env36660 := by
  intro p hp
  have h : env36660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36659_36660 : H12AffineEnvironment.transform 4 13 env36659 = env36660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env36659 == env36660) = true)

theorem identity36660 : scanCanonicalize (H12AffineFastState.compose env36660 (packedSelected [0,3] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound36660 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env36661 : List Nat := [2,4,8,1,13,13,5,4,13,9,10,1,8,12,12,3,13,6,9,13,1,1,12,3,4,0,6,0,13,11,4,0,5,0,0,13]

theorem envBound36661 : H12AffineFastState.Bounded env36661 := by
  intro p hp
  have h : env36661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36660_36661 : H12AffineEnvironment.transform 6 5 env36660 = env36661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env36660 == env36661) = true)

theorem identity36661 : scanCanonicalize (H12AffineFastState.compose env36661 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound36661 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36662 : List Nat := [2,4,4,1,1,1,5,4,1,5,6,1,4,0,0,3,1,6,5,1,1,1,0,3,4,0,6,0,1,7,4,0,5,0,0,1]

theorem envBound36662 : H12AffineFastState.Bounded env36662 := by
  intro p hp
  have h : env36662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36661_36662 : H12AffineEnvironment.transform 2 4 env36661 = env36662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env36661 == env36662) = true)

theorem identity36662 : scanCanonicalize (H12AffineFastState.compose env36662 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound36662 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36663 : List Nat := [2,3,3,1,1,1,2,3,1,2,1,1,3,0,0,3,1,1,2,1,1,1,0,3,3,0,1,0,1,0,3,0,2,0,0,1]

theorem envBound36663 : H12AffineFastState.Bounded env36663 := by
  intro p hp
  have h : env36663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36662_36663 : H12AffineEnvironment.transform 1 3 env36662 = env36663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env36662 == env36663) = true)

def env36664 : List Nat := [2,4,8,1,32,64,128,256,512,320,2048,837,9,65,324,231,449,103,516,325,837,649,448,231,964,709,303,385,64,2976,5,1,257,385,0,324]

theorem envBound36664 : H12AffineFastState.Bounded env36664 := by
  intro p hp
  have h : env36664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36654_36664 : H12AffineEnvironment.transform 12 9 env36654 = env36664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env36654 == env36664) = true)

theorem identity36664 : scanCanonicalize (H12AffineFastState.compose env36664 (packedSelected [0,1,2,4,7,8,9,12,13,16,19,20,23,32,38] rootPS)) = affineNative (2^(7+1) ^^^ 9) := by decide +kernel

theorem selectedBound36664 : packedSelected [0,1,2,4,7,8,9,12,13,16,19,20,23,32,38] rootPS < 2^1333 := by decide +kernel

def env36665 : List Nat := [2,4,8,1,32,64,128,9,512,73,2048,588,9,65,77,231,200,103,516,76,588,649,201,231,717,709,38,136,64,2729,5,1,8,136,0,77]

theorem envBound36665 : H12AffineFastState.Bounded env36665 := by
  intro p hp
  have h : env36665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36664_36665 : H12AffineEnvironment.transform 7 9 env36664 = env36665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 9 env36664 == env36665) = true)

theorem identity36665 : scanCanonicalize (H12AffineFastState.compose env36665 (packedSelected [0,1,3,7,12,15,16,18,23] rootPS)) = affineNative (2^(10+1) ^^^ 175) := by decide +kernel

theorem selectedBound36665 : packedSelected [0,1,3,7,12,15,16,18,23] rootPS < 2^1333 := by decide +kernel

def env36666 : List Nat := [2,4,8,1,32,64,128,9,512,73,175,588,9,65,77,231,200,103,516,76,588,649,201,231,717,709,38,136,64,518,5,1,8,136,0,77]

theorem envBound36666 : H12AffineFastState.Bounded env36666 := by
  intro p hp
  have h : env36666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36665_36666 : H12AffineEnvironment.transform 10 175 env36665 = env36666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 175 env36665 == env36666) = true)

theorem identity36666 : scanCanonicalize (H12AffineFastState.compose env36666 (packedSelected [0,2,3,9,10,11,13,15,16] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound36666 : packedSelected [0,2,3,9,10,11,13,15,16] rootPS < 2^1333 := by decide +kernel

def env36667 : List Nat := [2,4,8,1,6,64,128,9,512,73,137,588,9,65,77,193,200,65,516,76,588,649,201,193,717,709,0,136,64,518,5,1,8,136,0,77]

theorem envBound36667 : H12AffineFastState.Bounded env36667 := by
  intro p hp
  have h : env36667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36666_36667 : H12AffineEnvironment.transform 4 6 env36666 = env36667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env36666 == env36667) = true)

theorem identity36667 : scanCanonicalize (H12AffineFastState.compose env36667 (packedSelected [0,3,5,7,8,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 72) := by decide +kernel

theorem selectedBound36667 : packedSelected [0,3,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env36668 : List Nat := [2,4,8,1,6,64,72,9,512,73,65,588,9,65,77,9,0,65,516,76,588,577,1,9,517,525,0,64,64,518,5,1,8,64,0,77]

theorem envBound36668 : H12AffineFastState.Bounded env36668 := by
  intro p hp
  have h : env36668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36667_36668 : H12AffineEnvironment.transform 6 72 env36667 = env36668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 72 env36667 == env36668) = true)

theorem identity36668 : scanCanonicalize (H12AffineFastState.compose env36668 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound36668 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env36669 : List Nat := [2,4,8,1,6,0,8,9,512,9,1,524,9,1,13,9,0,1,516,12,524,513,1,9,517,525,0,0,0,518,5,1,8,0,0,13]

theorem envBound36669 : H12AffineFastState.Bounded env36669 := by
  intro p hp
  have h : env36669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36668_36669 : H12AffineEnvironment.transform 5 0 env36668 = env36669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env36668 == env36669) = true)

theorem identity36669 : scanCanonicalize (H12AffineFastState.compose env36669 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound36669 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env36670 : List Nat := [2,4,5,1,6,0,5,4,512,4,1,513,4,1,0,4,0,1,516,1,513,513,1,4,517,512,0,0,0,518,5,1,5,0,0,0]

theorem envBound36670 : H12AffineFastState.Bounded env36670 := by
  intro p hp
  have h : env36670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36669_36670 : H12AffineEnvironment.transform 2 5 env36669 = env36670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env36669 == env36670) = true)

theorem identity36670 : scanCanonicalize (H12AffineFastState.compose env36670 (packedSelected [1,2] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound36670 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env36671 : List Nat := [2,4,5,1,6,0,5,4,1,4,1,0,4,1,0,4,0,1,5,1,0,0,1,4,4,1,0,0,0,7,5,1,5,0,0,0]

theorem envBound36671 : H12AffineFastState.Bounded env36671 := by
  intro p hp
  have h : env36671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36670_36671 : H12AffineEnvironment.transform 8 1 env36670 = env36671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env36670 == env36671) = true)

theorem identity36671 : scanCanonicalize (H12AffineFastState.compose env36671 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound36671 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36672 : List Nat := [0,4,5,1,4,0,5,4,1,4,1,0,4,1,0,4,0,1,5,1,0,0,1,4,4,1,0,0,0,5,5,1,5,0,0,0]

theorem envBound36672 : H12AffineFastState.Bounded env36672 := by
  intro p hp
  have h : env36672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36671_36672 : H12AffineEnvironment.transform 0 0 env36671 = env36672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env36671 == env36672) = true)

theorem identity36672 : scanCanonicalize (H12AffineFastState.compose env36672 (packedSelected [7] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound36672 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env36673 : List Nat := [0,0,1,1,0,0,1,0,1,0,1,0,0,1,0,0,0,1,1,1,0,0,1,0,0,1,0,0,0,1,1,1,1,0,0,0]

theorem envBound36673 : H12AffineFastState.Bounded env36673 := by
  intro p hp
  have h : env36673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36672_36673 : H12AffineEnvironment.transform 1 0 env36672 = env36673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env36672 == env36673) = true)

def env36674 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,853,8192,80,8540,65536,74031,65664,532,8541,853,648,74047,65553,9181,74299,318,74110,81,76638,8204,8200,257,74095,0,340]

theorem envBound36674 : H12AffineFastState.Bounded env36674 := by
  intro p hp
  have h : env36674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36634_36674 : H12AffineEnvironment.transform 11 853 env36634 = env36674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 853 env36634 == env36674) = true)

def env36675 : List Nat := [2,4,8,0,32,64,128,256,512,320,2048,837,8192,64,8524,65536,74031,65664,516,8525,837,648,74031,65537,9165,74283,302,74094,65,76622,8204,8200,257,74095,0,324]

theorem envBound36675 : H12AffineFastState.Bounded env36675 := by
  intro p hp
  have h : env36675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36674_36675 : H12AffineEnvironment.transform 3 0 env36674 = env36675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env36674 == env36675) = true)

theorem identity36675 : scanCanonicalize (H12AffineFastState.compose env36675 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 393) := by decide +kernel

theorem selectedBound36675 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env36676 : List Nat := [2,4,8,0,32,64,128,256,512,320,2048,837,393,64,197,65536,65702,65664,516,196,837,648,65702,65537,580,66466,302,65767,65,68295,389,385,257,65766,0,324]

theorem envBound36676 : H12AffineFastState.Bounded env36676 := by
  intro p hp
  have h : env36676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36675_36676 : H12AffineEnvironment.transform 12 393 env36675 = env36676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 393 env36675 == env36676) = true)

def env36677 : List Nat := [2,4,8,0,32,64,128,192,512,128,2048,645,73,64,197,65536,65702,65664,516,196,645,648,65702,65537,580,66146,238,65767,65,68295,69,65,193,65766,0,132]

theorem envBound36677 : H12AffineFastState.Bounded env36677 := by
  intro p hp
  have h : env36677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36676_36677 : H12AffineEnvironment.transform 7 192 env36676 = env36677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 192 env36676 == env36677) = true)

theorem identity36677 : scanCanonicalize (H12AffineFastState.compose env36677 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 65) := by decide +kernel

theorem selectedBound36677 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env36678 : List Nat := [2,4,8,0,32,64,128,192,65,128,2048,196,73,64,197,65536,65702,65664,69,196,196,201,65702,65537,5,65571,238,65767,65,67718,69,65,193,65766,0,132]

theorem envBound36678 : H12AffineFastState.Bounded env36678 := by
  intro p hp
  have h : env36678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36677_36678 : H12AffineEnvironment.transform 8 65 env36677 = env36678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env36677 == env36678) = true)

theorem identity36678 : scanCanonicalize (H12AffineFastState.compose env36678 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(15+1) ^^^ 166) := by decide +kernel

theorem selectedBound36678 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env36679 : List Nat := [2,4,8,0,32,64,128,192,65,128,2048,196,73,64,197,166,0,38,69,196,196,201,0,167,5,133,238,65,65,2080,69,65,193,64,0,132]

theorem envBound36679 : H12AffineFastState.Bounded env36679 := by
  intro p hp
  have h : env36679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36678_36679 : H12AffineEnvironment.transform 15 166 env36678 = env36679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 166 env36678 == env36679) = true)

theorem identity36679 : scanCanonicalize (H12AffineFastState.compose env36679 (packedSelected [8,13] rootPS)) = affineNative (2^(6+1) ^^^ 47) := by decide +kernel

theorem selectedBound36679 : packedSelected [8,13] rootPS < 2^1333 := by decide +kernel

def env36680 : List Nat := [2,4,8,0,32,64,47,111,65,47,2048,107,73,64,106,9,0,38,69,107,107,102,0,8,5,42,65,65,65,2080,69,65,110,64,0,43]

theorem envBound36680 : H12AffineFastState.Bounded env36680 := by
  intro p hp
  have h : env36680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36679_36680 : H12AffineEnvironment.transform 6 47 env36679 = env36680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 47 env36679 == env36680) = true)

theorem identity36680 : scanCanonicalize (H12AffineFastState.compose env36680 (packedSelected [0,1,2,3,7,8,10,11,12] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound36680 : packedSelected [0,1,2,3,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env36681 : List Nat := [2,4,3,0,32,64,36,100,65,36,2048,96,66,64,97,2,0,38,69,96,96,102,0,3,5,33,65,65,65,2080,69,65,101,64,0,32]

theorem envBound36681 : H12AffineFastState.Bounded env36681 := by
  intro p hp
  have h : env36681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36680_36681 : H12AffineEnvironment.transform 2 3 env36680 = env36681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env36680 == env36681) = true)

theorem identity36681 : scanCanonicalize (H12AffineFastState.compose env36681 (packedSelected [0,3,5,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 97) := by decide +kernel

theorem selectedBound36681 : packedSelected [0,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env36682 : List Nat := [2,4,3,0,32,64,36,100,65,36,97,96,66,64,97,2,0,38,69,96,96,102,0,3,5,33,65,65,65,65,69,65,101,64,0,32]

theorem envBound36682 : H12AffineFastState.Bounded env36682 := by
  intro p hp
  have h : env36682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36681_36682 : H12AffineEnvironment.transform 10 97 env36681 = env36682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 97 env36681 == env36682) = true)

theorem identity36682 : scanCanonicalize (H12AffineFastState.compose env36682 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound36682 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36683 : List Nat := [2,4,3,0,6,64,2,66,65,2,71,70,66,64,71,2,0,0,69,70,70,64,0,3,5,7,65,65,65,65,69,65,67,64,0,6]

theorem envBound36683 : H12AffineFastState.Bounded env36683 := by
  intro p hp
  have h : env36683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36682_36683 : H12AffineEnvironment.transform 4 6 env36682 = env36683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env36682 == env36683) = true)

theorem identity36683 : scanCanonicalize (H12AffineFastState.compose env36683 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound36683 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36684 : List Nat := [2,4,3,0,6,0,2,2,1,2,7,6,2,0,7,2,0,0,5,6,6,0,0,3,5,7,1,1,1,1,5,1,3,0,0,6]

theorem envBound36684 : H12AffineFastState.Bounded env36684 := by
  intro p hp
  have h : env36684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36683_36684 : H12AffineEnvironment.transform 5 0 env36683 = env36684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env36683 == env36684) = true)

theorem identity36684 : scanCanonicalize (H12AffineFastState.compose env36684 (packedSelected [0,4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound36684 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env36685 : List Nat := [2,2,3,0,0,0,2,2,1,2,1,0,2,0,1,2,0,0,3,0,0,0,0,3,3,1,1,1,1,1,3,1,3,0,0,0]

theorem envBound36685 : H12AffineFastState.Bounded env36685 := by
  intro p hp
  have h : env36685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36684_36685 : H12AffineEnvironment.transform 1 2 env36684 = env36685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env36684 == env36685) = true)

theorem identity36685 : scanCanonicalize (H12AffineFastState.compose env36685 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound36685 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36686 : List Nat := [1,1,0,0,0,0,1,1,1,1,1,0,1,0,1,1,0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,1,0,0,0,0]

theorem envBound36686 : H12AffineFastState.Bounded env36686 := by
  intro p hp
  have h : env36686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36685_36686 : H12AffineEnvironment.transform 0 1 env36685 = env36686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env36685 == env36686) = true)

def env36687 : List Nat := [2,4,8,0,32,64,128,193,512,129,2048,644,72,64,197,65536,65702,65664,516,196,644,648,65702,65537,580,66147,239,65767,65,68295,68,64,192,65766,0,133]

theorem envBound36687 : H12AffineFastState.Bounded env36687 := by
  intro p hp
  have h : env36687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36676_36687 : H12AffineEnvironment.transform 7 193 env36676 = env36687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 193 env36676 == env36687) = true)

theorem identity36687 : scanCanonicalize (H12AffineFastState.compose env36687 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 68) := by decide +kernel

theorem selectedBound36687 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env36688 : List Nat := [2,4,8,0,32,64,68,5,512,69,2048,576,72,64,1,65536,65634,65604,516,0,576,588,65634,65537,580,66147,43,65571,65,68099,68,64,4,65570,0,65]

theorem envBound36688 : H12AffineFastState.Bounded env36688 := by
  intro p hp
  have h : env36688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36687_36688 : H12AffineEnvironment.transform 6 68 env36687 = env36688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 68 env36687 == env36688) = true)

theorem identity36688 : scanCanonicalize (H12AffineFastState.compose env36688 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound36688 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env36689 : List Nat := [2,4,8,0,32,1,5,5,512,4,2048,513,9,1,1,65536,65571,65541,516,0,513,525,65571,65537,517,66082,43,65571,0,68099,5,1,4,65570,0,0]

theorem envBound36689 : H12AffineFastState.Bounded env36689 := by
  intro p hp
  have h : env36689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36688_36689 : H12AffineEnvironment.transform 5 1 env36688 = env36689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env36688 == env36689) = true)

theorem identity36689 : scanCanonicalize (H12AffineFastState.compose env36689 (packedSelected [1,2,5,8] rootPS)) = affineNative (2^(8+1) ^^^ 45) := by decide +kernel

theorem selectedBound36689 : packedSelected [1,2,5,8] rootPS < 2^1333 := by decide +kernel

def env36690 : List Nat := [2,4,8,0,32,1,5,5,45,4,2048,44,9,1,1,65536,65571,65541,41,0,44,32,65571,65537,40,65551,43,65571,0,67630,5,1,4,65570,0,0]

theorem envBound36690 : H12AffineFastState.Bounded env36690 := by
  intro p hp
  have h : env36690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36689_36690 : H12AffineEnvironment.transform 8 45 env36689 = env36690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 45 env36689 == env36690) = true)

theorem identity36690 : scanCanonicalize (H12AffineFastState.compose env36690 (packedSelected [0,1,2,5,7,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 15) := by decide +kernel

theorem selectedBound36690 : packedSelected [0,1,2,5,7,11,12] rootPS < 2^1333 := by decide +kernel

def env36691 : List Nat := [2,4,8,0,32,1,5,5,45,4,2048,44,9,1,1,15,44,10,41,0,44,32,44,14,40,0,43,44,0,2081,5,1,4,45,0,0]

theorem envBound36691 : H12AffineFastState.Bounded env36691 := by
  intro p hp
  have h : env36691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36690_36691 : H12AffineEnvironment.transform 15 15 env36690 = env36691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 15 env36690 == env36691) = true)

theorem identity36691 : scanCanonicalize (H12AffineFastState.compose env36691 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 12) := by decide +kernel

theorem selectedBound36691 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env36692 : List Nat := [2,4,8,0,32,1,5,5,45,4,12,44,9,1,1,15,44,10,41,0,44,32,44,14,40,0,43,44,0,45,5,1,4,45,0,0]

theorem envBound36692 : H12AffineFastState.Bounded env36692 := by
  intro p hp
  have h : env36692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36691_36692 : H12AffineEnvironment.transform 10 12 env36691 = env36692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 12 env36691 == env36692) = true)

theorem identity36692 : scanCanonicalize (H12AffineFastState.compose env36692 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound36692 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env36693 : List Nat := [2,4,8,0,7,1,5,5,10,4,12,11,9,1,1,15,11,10,14,0,11,7,11,14,15,0,12,11,0,10,5,1,4,10,0,0]

theorem envBound36693 : H12AffineFastState.Bounded env36693 := by
  intro p hp
  have h : env36693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36692_36693 : H12AffineEnvironment.transform 4 7 env36692 = env36693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env36692 == env36693) = true)

theorem identity36693 : scanCanonicalize (H12AffineFastState.compose env36693 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound36693 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36694 : List Nat := [2,4,2,0,7,1,5,5,0,4,6,1,3,1,1,5,1,0,4,0,1,7,1,4,5,0,6,1,0,0,5,1,4,0,0,0]

theorem envBound36694 : H12AffineFastState.Bounded env36694 := by
  intro p hp
  have h : env36694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36693_36694 : H12AffineEnvironment.transform 2 2 env36693 = env36694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env36693 == env36694) = true)

theorem identity36694 : scanCanonicalize (H12AffineFastState.compose env36694 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound36694 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36695 : List Nat := [2,2,2,0,1,1,3,3,0,2,0,1,3,1,1,3,1,0,2,0,1,1,1,2,3,0,0,1,0,0,3,1,2,0,0,0]

theorem envBound36695 : H12AffineFastState.Bounded env36695 := by
  intro p hp
  have h : env36695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36694_36695 : H12AffineEnvironment.transform 1 2 env36694 = env36695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env36694 == env36695) = true)

def env36696 : List Nat := [2,4,8,1,32,64,128,256,512,320,2048,836,8192,65,8525,65536,74031,65664,517,8524,836,648,74030,65536,9164,74282,303,74095,64,76623,8204,8200,257,74095,0,325]

theorem envBound36696 : H12AffineFastState.Bounded env36696 := by
  intro p hp
  have h : env36696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36674_36696 : H12AffineEnvironment.transform 3 1 env36674 = env36696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env36674 == env36696) = true)

theorem identity36696 : scanCanonicalize (H12AffineFastState.compose env36696 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 192) := by decide +kernel

theorem selectedBound36696 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env36697 : List Nat := [2,4,8,1,32,64,128,192,512,128,2048,644,8192,65,8333,65536,73967,65664,517,8332,644,648,73966,65536,8716,74282,239,73903,64,76431,8204,8200,193,73903,0,133]

theorem envBound36697 : H12AffineFastState.Bounded env36697 := by
  intro p hp
  have h : env36697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36696_36697 : H12AffineEnvironment.transform 7 192 env36696 = env36697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 192 env36696 == env36697) = true)

def env36698 : List Nat := [2,4,8,1,32,64,128,192,512,128,2048,644,8192,65,8333,8360,71,8232,517,8332,644,648,70,8360,8716,642,239,7,64,2599,8204,8200,193,7,0,133]

theorem envBound36698 : H12AffineFastState.Bounded env36698 := by
  intro p hp
  have h : env36698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36697_36698 : H12AffineEnvironment.transform 15 8360 env36697 = env36698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8360 env36697 == env36698) = true)

theorem identity36698 : scanCanonicalize (H12AffineFastState.compose env36698 (packedSelected [0,3,8,10,11,17,18,19,21,23,27,32] rootPS)) = affineNative (2^(12+1) ^^^ 2701) := by decide +kernel

theorem selectedBound36698 : packedSelected [0,3,8,10,11,17,18,19,21,23,27,32] rootPS < 2^1333 := by decide +kernel

def env36699 : List Nat := [2,4,8,1,32,64,128,192,512,128,2048,644,2701,65,2560,2597,71,2725,517,2561,644,648,70,2597,2177,642,239,7,64,2599,2689,2693,193,7,0,133]

theorem envBound36699 : H12AffineFastState.Bounded env36699 := by
  intro p hp
  have h : env36699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36698_36699 : H12AffineEnvironment.transform 12 2701 env36698 = env36699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2701 env36698 == env36699) = true)

theorem identity36699 : scanCanonicalize (H12AffineFastState.compose env36699 (packedSelected [1,2,7,8,12,13,16,18,19,20,24,27] rootPS)) = affineNative (2^(8+1) ^^^ 108) := by decide +kernel

theorem selectedBound36699 : packedSelected [1,2,7,8,12,13,16,18,19,20,24,27] rootPS < 2^1333 := by decide +kernel

def env36700 : List Nat := [2,4,8,1,32,64,128,192,108,128,2048,232,2273,65,2156,2121,71,2249,105,2157,232,228,70,2121,2177,238,239,7,64,2123,2285,2281,193,7,0,133]

theorem envBound36700 : H12AffineFastState.Bounded env36700 := by
  intro p hp
  have h : env36700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36699_36700 : H12AffineEnvironment.transform 8 108 env36699 = env36700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 108 env36699 == env36700) = true)

theorem identity36700 : scanCanonicalize (H12AffineFastState.compose env36700 (packedSelected [0,1,2,5,7,13,17,18] rootPS)) = affineNative (2^(6+1) ^^^ 78) := by decide +kernel

theorem selectedBound36700 : packedSelected [0,1,2,5,7,13,17,18] rootPS < 2^1333 := by decide +kernel

def env36701 : List Nat := [2,4,8,1,32,64,78,14,108,78,2048,38,2095,65,2156,2121,71,2055,105,2157,38,42,70,2121,2127,32,33,7,64,2123,2083,2087,15,7,0,75]

theorem envBound36701 : H12AffineFastState.Bounded env36701 := by
  intro p hp
  have h : env36701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36700_36701 : H12AffineEnvironment.transform 6 78 env36700 = env36701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 78 env36700 == env36701) = true)

theorem identity36701 : scanCanonicalize (H12AffineFastState.compose env36701 (packedSelected [1,4,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 45) := by decide +kernel

theorem selectedBound36701 : packedSelected [1,4,7,8] rootPS < 2^1333 := by decide +kernel

def env36702 : List Nat := [2,4,8,1,32,64,78,14,108,78,45,38,2,65,65,100,71,42,105,64,38,42,70,100,98,32,33,7,64,102,14,10,15,7,0,75]

theorem envBound36702 : H12AffineFastState.Bounded env36702 := by
  intro p hp
  have h : env36702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36701_36702 : H12AffineEnvironment.transform 10 45 env36701 = env36702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 45 env36701 == env36702) = true)

theorem identity36702 : scanCanonicalize (H12AffineFastState.compose env36702 (packedSelected [1,2,4,9] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound36702 : packedSelected [1,2,4,9] rootPS < 2^1333 := by decide +kernel

def env36703 : List Nat := [2,4,8,1,32,1,15,14,45,15,45,38,2,0,0,37,6,42,40,1,38,42,7,37,35,32,33,7,1,39,14,10,15,7,0,10]

theorem envBound36703 : H12AffineFastState.Bounded env36703 := by
  intro p hp
  have h : env36703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36702_36703 : H12AffineEnvironment.transform 5 1 env36702 = env36703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env36702 == env36703) = true)

theorem identity36703 : scanCanonicalize (H12AffineFastState.compose env36703 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound36703 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env36704 : List Nat := [2,4,8,1,12,1,15,14,1,15,1,10,2,0,0,9,6,6,4,1,10,6,7,9,15,12,13,7,1,11,14,10,15,7,0,10]

theorem envBound36704 : H12AffineFastState.Bounded env36704 := by
  intro p hp
  have h : env36704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36703_36704 : H12AffineEnvironment.transform 4 12 env36703 = env36704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env36703 == env36704) = true)

theorem identity36704 : scanCanonicalize (H12AffineFastState.compose env36704 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound36704 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36705 : List Nat := [2,2,8,1,10,1,9,8,1,9,1,10,2,0,0,9,0,0,2,1,10,0,1,9,9,10,11,1,1,11,8,10,9,1,0,10]

theorem envBound36705 : H12AffineFastState.Bounded env36705 := by
  intro p hp
  have h : env36705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36704_36705 : H12AffineEnvironment.transform 1 2 env36704 = env36705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env36704 == env36705) = true)

theorem identity36705 : scanCanonicalize (H12AffineFastState.compose env36705 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound36705 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36706 : List Nat := [2,2,3,1,1,1,2,3,1,2,1,1,2,0,0,2,0,0,2,1,1,0,1,2,2,1,0,1,1,0,3,1,2,1,0,1]

theorem envBound36706 : H12AffineFastState.Bounded env36706 := by
  intro p hp
  have h : env36706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36705_36706 : H12AffineEnvironment.transform 2 3 env36705 = env36706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env36705 == env36706) = true)

def env36707 : List Nat := [2,4,8,1,32,64,128,192,512,128,2048,644,8192,65,8333,8361,70,8233,517,8332,644,648,71,8361,8716,643,239,6,64,2598,8204,8200,193,6,0,133]

theorem envBound36707 : H12AffineFastState.Bounded env36707 := by
  intro p hp
  have h : env36707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36697_36707 : H12AffineEnvironment.transform 15 8361 env36697 = env36707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8361 env36697 == env36707) = true)

theorem identity36707 : scanCanonicalize (H12AffineFastState.compose env36707 (packedSelected [0,3,8,10,11,17,18,19,21,23,27,32] rootPS)) = affineNative (2^(12+1) ^^^ 2698) := by decide +kernel

theorem selectedBound36707 : packedSelected [0,3,8,10,11,17,18,19,21,23,27,32] rootPS < 2^1333 := by decide +kernel

def env36708 : List Nat := [2,4,8,1,32,64,128,192,512,128,2048,644,2698,65,2567,2595,70,2723,517,2566,644,648,71,2595,2182,643,239,6,64,2598,2694,2690,193,6,0,133]

theorem envBound36708 : H12AffineFastState.Bounded env36708 := by
  intro p hp
  have h : env36708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36707_36708 : H12AffineEnvironment.transform 12 2698 env36707 = env36708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2698 env36707 == env36708) = true)

theorem identity36708 : scanCanonicalize (H12AffineFastState.compose env36708 (packedSelected [0,1,3,5,7,8,11,16,17,20,21,24] rootPS)) = affineNative (2^(10+1) ^^^ 619) := by decide +kernel

theorem selectedBound36708 : packedSelected [0,1,3,5,7,8,11,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env36709 : List Nat := [2,4,8,1,32,64,128,192,512,128,619,644,225,65,108,72,70,200,517,109,644,648,71,72,749,643,239,6,64,77,237,233,193,6,0,133]

theorem envBound36709 : H12AffineFastState.Bounded env36709 := by
  intro p hp
  have h : env36709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36708_36709 : H12AffineEnvironment.transform 10 619 env36708 = env36709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 619 env36708 == env36709) = true)

theorem identity36709 : scanCanonicalize (H12AffineFastState.compose env36709 (packedSelected [0,2,4,5,7,8,9,10,12,13,15] rootPS)) = affineNative (2^(8+1) ^^^ 108) := by decide +kernel

theorem selectedBound36709 : packedSelected [0,2,4,5,7,8,9,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env36710 : List Nat := [2,4,8,1,32,64,128,192,108,128,7,232,225,65,108,72,70,200,105,109,232,228,71,72,129,239,239,6,64,77,237,233,193,6,0,133]

theorem envBound36710 : H12AffineFastState.Bounded env36710 := by
  intro p hp
  have h : env36710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36709_36710 : H12AffineEnvironment.transform 8 108 env36709 = env36710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 108 env36709 == env36710) = true)

theorem identity36710 : scanCanonicalize (H12AffineFastState.compose env36710 (packedSelected [2,3,8] rootPS)) = affineNative (2^(6+1) ^^^ 110) := by decide +kernel

theorem selectedBound36710 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env36711 : List Nat := [2,4,8,1,32,64,110,46,108,110,7,6,15,65,108,72,70,38,105,109,6,10,71,72,111,1,1,6,64,77,3,7,47,6,0,107]

theorem envBound36711 : H12AffineFastState.Bounded env36711 := by
  intro p hp
  have h : env36711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36710_36711 : H12AffineEnvironment.transform 6 110 env36710 = env36711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 110 env36710 == env36711) = true)

theorem identity36711 : scanCanonicalize (H12AffineFastState.compose env36711 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 7) := by decide +kernel

theorem selectedBound36711 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env36712 : List Nat := [2,4,8,1,32,7,41,46,43,41,7,6,15,6,43,15,1,38,46,42,6,10,0,15,40,1,1,6,7,10,3,7,47,6,0,44]

theorem envBound36712 : H12AffineFastState.Bounded env36712 := by
  intro p hp
  have h : env36712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36711_36712 : H12AffineEnvironment.transform 5 7 env36711 = env36712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 7 env36711 == env36712) = true)

theorem identity36712 : scanCanonicalize (H12AffineFastState.compose env36712 (packedSelected [2,5] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound36712 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env36713 : List Nat := [2,4,8,1,13,7,4,3,6,4,7,6,15,6,6,15,1,11,3,7,6,10,0,15,5,1,1,6,7,10,3,7,2,6,0,1]

theorem envBound36713 : H12AffineFastState.Bounded env36713 := by
  intro p hp
  have h : env36713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36712_36713 : H12AffineEnvironment.transform 4 13 env36712 = env36713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env36712 == env36713) = true)

theorem identity36713 : scanCanonicalize (H12AffineFastState.compose env36713 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound36713 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36714 : List Nat := [2,4,4,1,1,7,4,3,6,4,7,6,3,6,6,3,1,7,3,7,6,6,0,3,5,1,1,6,7,6,3,7,2,6,0,1]

theorem envBound36714 : H12AffineFastState.Bounded env36714 := by
  intro p hp
  have h : env36714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36713_36714 : H12AffineEnvironment.transform 2 4 env36713 = env36714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env36713 == env36714) = true)

theorem identity36714 : scanCanonicalize (H12AffineFastState.compose env36714 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound36714 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36715 : List Nat := [2,2,2,1,1,1,2,3,0,2,1,0,3,0,0,3,1,1,3,1,0,0,0,3,3,1,1,0,1,0,3,1,2,0,0,1]

theorem envBound36715 : H12AffineFastState.Bounded env36715 := by
  intro p hp
  have h : env36715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36714_36715 : H12AffineEnvironment.transform 1 2 env36714 = env36715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env36714 == env36715) = true)

theorem identity36715 : scanCanonicalize (H12AffineFastState.compose env36715 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound36715 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36716 : List Nat := [1,1,1,1,1,1,1,0,0,1,1,0,0,0,0,0,1,1,0,1,0,0,0,0,0,1,1,0,1,0,0,1,1,0,0,1]

theorem envBound36716 : H12AffineFastState.Bounded env36716 := by
  intro p hp
  have h : env36716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36715_36716 : H12AffineEnvironment.transform 0 1 env36715 = env36716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env36715 == env36716) = true)

def env36717 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74863,65665,4417,8541,4096,5277,74047,66897,13768,78894,1151,74814,1297,81227,8204,8200,257,74799,1344,5953]

theorem envBound36717 : H12AffineFastState.Bounded env36717 := by
  intro p hp
  have h : env36717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36632_36717 : H12AffineEnvironment.transform 17 65665 env36632 = env36717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env36632 == env36717) = true)

theorem identity36717 : scanCanonicalize (H12AffineFastState.compose env36717 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound36717 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env36718 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1296,8540,65536,74863,65665,321,8541,0,1181,74047,66897,9672,74798,1151,74814,1297,77131,8204,8200,257,74799,1344,1857]

theorem envBound36718 : H12AffineFastState.Bounded env36718 := by
  intro p hp
  have h : env36718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36717_36718 : H12AffineEnvironment.transform 11 0 env36717 = env36718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env36717 == env36718) = true)

def env36719 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,0,8192,80,8540,65536,74031,65665,321,8541,0,477,74047,65553,8328,74094,319,74110,81,75787,8204,8200,257,74095,0,513]

theorem envBound36719 : H12AffineFastState.Bounded env36719 := by
  intro p hp
  have h : env36719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36718_36719 : H12AffineEnvironment.transform 9 320 env36718 = env36719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env36718 == env36719) = true)

theorem identity36719 : scanCanonicalize (H12AffineFastState.compose env36719 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 8299) := by decide +kernel

theorem selectedBound36719 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env36720 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,0,8192,80,8540,8299,324,8426,321,8541,0,477,340,8314,8328,261,319,277,81,2144,8204,8200,257,260,0,513]

theorem envBound36720 : H12AffineFastState.Bounded env36720 := by
  intro p hp
  have h : env36720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36719_36720 : H12AffineEnvironment.transform 15 8299 env36719 = env36720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8299 env36719 == env36720) = true)

theorem identity36720 : scanCanonicalize (H12AffineFastState.compose env36720 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound36720 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env36721 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,0,349,80,1,310,324,439,321,0,0,477,340,295,469,261,319,277,81,2144,337,341,257,260,0,513]

theorem envBound36721 : H12AffineFastState.Bounded env36721 := by
  intro p hp
  have h : env36721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36720_36721 : H12AffineEnvironment.transform 12 349 env36720 = env36721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env36720 == env36721) = true)

theorem identity36721 : scanCanonicalize (H12AffineFastState.compose env36721 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound36721 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env36722 : List Nat := [2,4,8,16,32,64,128,4,512,68,2048,0,89,80,1,50,64,179,69,0,0,217,80,35,209,1,59,17,81,2144,85,81,5,0,0,513]

theorem envBound36722 : H12AffineFastState.Bounded env36722 := by
  intro p hp
  have h : env36722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36721_36722 : H12AffineEnvironment.transform 7 4 env36721 = env36722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env36721 == env36722) = true)

theorem identity36722 : scanCanonicalize (H12AffineFastState.compose env36722 (packedSelected [0,1,7,8,11,13,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 195) := by decide +kernel

theorem selectedBound36722 : packedSelected [0,1,7,8,11,13,15,17] rootPS < 2^1333 := by decide +kernel

def env36723 : List Nat := [2,4,8,16,32,64,128,4,512,68,195,0,89,80,1,50,64,179,69,0,0,217,80,35,209,1,59,17,81,163,85,81,5,0,0,513]

theorem envBound36723 : H12AffineFastState.Bounded env36723 := by
  intro p hp
  have h : env36723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36722_36723 : H12AffineEnvironment.transform 10 195 env36722 = env36723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 195 env36722 == env36723) = true)

theorem identity36723 : scanCanonicalize (H12AffineFastState.compose env36723 (packedSelected [0,4,5,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 119) := by decide +kernel

theorem selectedBound36723 : packedSelected [0,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env36724 : List Nat := [2,4,8,16,32,64,128,4,119,68,195,0,89,80,1,50,64,179,69,0,0,217,80,35,209,1,59,17,81,163,85,81,5,0,0,118]

theorem envBound36724 : H12AffineFastState.Bounded env36724 := by
  intro p hp
  have h : env36724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36723_36724 : H12AffineEnvironment.transform 8 119 env36723 = env36724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 119 env36723 == env36724) = true)

theorem identity36724 : scanCanonicalize (H12AffineFastState.compose env36724 (packedSelected [0,1,5,7,8,11,12,13] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound36724 : packedSelected [0,1,5,7,8,11,12,13] rootPS < 2^1333 := by decide +kernel

def env36725 : List Nat := [2,4,8,16,32,64,40,4,119,68,107,0,89,80,1,50,64,27,69,0,0,113,80,35,121,1,59,17,81,11,85,81,5,0,0,118]

theorem envBound36725 : H12AffineFastState.Bounded env36725 := by
  intro p hp
  have h : env36725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36724_36725 : H12AffineEnvironment.transform 6 40 env36724 = env36725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env36724 == env36725) = true)

theorem identity36725 : scanCanonicalize (H12AffineFastState.compose env36725 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 44) := by decide +kernel

theorem selectedBound36725 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env36726 : List Nat := [2,4,8,16,32,44,40,4,27,40,7,0,53,60,1,50,44,27,41,0,0,29,60,35,21,1,59,17,61,11,57,61,5,0,0,26]

theorem envBound36726 : H12AffineFastState.Bounded env36726 := by
  intro p hp
  have h : env36726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36725_36726 : H12AffineEnvironment.transform 5 44 env36725 = env36726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 44 env36725 == env36726) = true)

theorem identity36726 : scanCanonicalize (H12AffineFastState.compose env36726 (packedSelected [0,1,3,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound36726 : packedSelected [0,1,3,7,8] rootPS < 2^1333 := by decide +kernel

def env36727 : List Nat := [2,4,8,16,1,13,9,4,27,9,7,0,20,29,1,19,13,27,8,0,0,29,29,2,21,1,26,17,28,11,24,28,5,0,0,26]

theorem envBound36727 : H12AffineFastState.Bounded env36727 := by
  intro p hp
  have h : env36727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36726_36727 : H12AffineEnvironment.transform 4 1 env36726 = env36727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env36726 == env36727) = true)

theorem identity36727 : scanCanonicalize (H12AffineFastState.compose env36727 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound36727 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36728 : List Nat := [2,3,8,16,1,10,9,3,27,9,0,0,19,26,1,19,10,27,8,0,0,26,26,2,18,1,26,17,27,11,24,27,2,0,0,26]

theorem envBound36728 : H12AffineFastState.Bounded env36728 := by
  intro p hp
  have h : env36728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36727_36728 : H12AffineEnvironment.transform 1 3 env36727 = env36728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env36727 == env36728) = true)

theorem identity36728 : scanCanonicalize (H12AffineFastState.compose env36728 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound36728 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36729 : List Nat := [2,3,2,16,1,0,3,3,17,3,0,0,19,16,1,19,0,17,2,0,0,16,16,2,18,1,16,17,17,1,18,17,2,0,0,16]

theorem envBound36729 : H12AffineFastState.Bounded env36729 := by
  intro p hp
  have h : env36729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36728_36729 : H12AffineEnvironment.transform 2 2 env36728 = env36729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env36728 == env36729) = true)

theorem identity36729 : scanCanonicalize (H12AffineFastState.compose env36729 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound36729 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36730 : List Nat := [2,3,2,3,1,0,3,3,2,3,0,0,0,3,1,0,0,2,2,0,0,3,3,2,1,1,3,2,2,1,1,2,2,0,0,3]

theorem envBound36730 : H12AffineFastState.Bounded env36730 := by
  intro p hp
  have h : env36730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36729_36730 : H12AffineEnvironment.transform 3 3 env36729 = env36730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env36729 == env36730) = true)

theorem identity36730 : scanCanonicalize (H12AffineFastState.compose env36730 (packedSelected [7] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound36730 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env36731 : List Nat := [0,1,0,1,1,0,1,1,0,1,0,0,0,1,1,0,0,0,0,0,0,1,1,0,1,1,1,0,0,1,1,0,0,0,0,1]

theorem envBound36731 : H12AffineFastState.Bounded env36731 := by
  intro p hp
  have h : env36731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36730_36731 : H12AffineEnvironment.transform 0 0 env36730 = env36731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env36730 == env36731) = true)

def env36732 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,0,8192,81,8540,65536,74030,65665,321,8541,0,476,74047,65552,8329,74095,318,74111,80,75786,8204,8200,257,74094,1,512]

theorem envBound36732 : H12AffineFastState.Bounded env36732 := by
  intro p hp
  have h : env36732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36718_36732 : H12AffineEnvironment.transform 9 321 env36718 = env36732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env36718 == env36732) = true)

theorem identity36732 : scanCanonicalize (H12AffineFastState.compose env36732 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound36732 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env36733 : List Nat := [2,4,8,16,32,64,128,20,512,85,2048,0,8192,81,8264,65536,73786,65665,85,8265,0,200,73771,65552,8329,73851,42,73835,80,75786,8204,8200,21,73850,1,512]

theorem envBound36733 : H12AffineFastState.Bounded env36733 := by
  intro p hp
  have h : env36733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36732_36733 : H12AffineEnvironment.transform 7 20 env36732 = env36733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env36732 == env36733) = true)

theorem identity36733 : scanCanonicalize (H12AffineFastState.compose env36733 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound36733 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env36734 : List Nat := [2,4,8,16,32,17,128,20,512,4,2048,0,8192,0,8217,65536,73786,65665,4,8216,0,153,73771,65552,8329,73770,42,73786,1,75786,8204,8200,21,73771,1,512]

theorem envBound36734 : H12AffineFastState.Bounded env36734 := by
  intro p hp
  have h : env36734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36733_36734 : H12AffineEnvironment.transform 5 17 env36733 = env36734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env36733 == env36734) = true)

theorem identity36734 : scanCanonicalize (H12AffineFastState.compose env36734 (packedSelected [2,11,18] rootPS)) = affineNative (2^(12+1) ^^^ 2747) := by decide +kernel

theorem selectedBound36734 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env36735 : List Nat := [2,4,8,16,32,17,128,20,512,4,2048,0,2747,0,2722,65536,68225,65665,4,2723,0,153,68240,65552,2610,68241,42,68225,1,66225,2743,2739,21,68240,1,512]

theorem envBound36735 : H12AffineFastState.Bounded env36735 := by
  intro p hp
  have h : env36735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36734_36735 : H12AffineEnvironment.transform 12 2747 env36734 = env36735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2747 env36734 == env36735) = true)

theorem identity36735 : scanCanonicalize (H12AffineFastState.compose env36735 (packedSelected [1,3,13] rootPS)) = affineNative (2^(15+1) ^^^ 2224) := by decide +kernel

theorem selectedBound36735 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env36736 : List Nat := [2,4,8,16,32,17,128,20,512,4,2048,0,2747,0,2722,2224,561,2097,4,2723,0,153,544,2208,2610,545,42,561,1,2561,2743,2739,21,544,1,512]

theorem envBound36736 : H12AffineFastState.Bounded env36736 := by
  intro p hp
  have h : env36736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36735_36736 : H12AffineEnvironment.transform 15 2224 env36735 = env36736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2224 env36735 == env36736) = true)

theorem identity36736 : scanCanonicalize (H12AffineFastState.compose env36736 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound36736 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env36737 : List Nat := [2,4,8,16,32,17,128,20,42,4,2048,0,2193,0,2184,2224,27,2097,4,2185,0,153,10,2208,2072,11,42,27,1,2091,2205,2201,21,10,1,42]

theorem envBound36737 : H12AffineFastState.Bounded env36737 := by
  intro p hp
  have h : env36737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36736_36737 : H12AffineEnvironment.transform 8 42 env36736 = env36737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env36736 == env36737) = true)

theorem identity36737 : scanCanonicalize (H12AffineFastState.compose env36737 (packedSelected [0,1,4,5,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound36737 : packedSelected [0,1,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env36738 : List Nat := [2,4,8,16,32,17,34,20,42,4,2048,0,2099,0,2090,2066,27,2097,4,2091,0,59,10,2050,2072,11,42,27,1,2091,2111,2107,21,10,1,42]

theorem envBound36738 : H12AffineFastState.Bounded env36738 := by
  intro p hp
  have h : env36738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36737_36738 : H12AffineEnvironment.transform 6 34 env36737 = env36738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env36737 == env36738) = true)

theorem identity36738 : scanCanonicalize (H12AffineFastState.compose env36738 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound36738 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36739 : List Nat := [2,4,8,11,32,10,34,15,42,4,2048,0,2088,0,2090,2057,0,2090,4,2091,0,32,10,2050,2051,11,42,0,1,2091,2084,2080,14,10,1,42]

theorem envBound36739 : H12AffineFastState.Bounded env36739 := by
  intro p hp
  have h : env36739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36738_36739 : H12AffineEnvironment.transform 3 11 env36738 = env36739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env36738 == env36739) = true)

theorem identity36739 : scanCanonicalize (H12AffineFastState.compose env36739 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound36739 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env36740 : List Nat := [2,4,8,11,10,10,8,15,0,4,2048,0,2050,0,2048,2057,0,2048,4,2049,0,10,10,2050,2051,11,0,0,1,2049,2062,2058,14,10,1,0]

theorem envBound36740 : H12AffineFastState.Bounded env36740 := by
  intro p hp
  have h : env36740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36739_36740 : H12AffineEnvironment.transform 4 10 env36739 = env36740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env36739 == env36740) = true)

def env36741 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74863,262144,4416,8540,4096,5277,74046,66897,13769,78894,328958,74815,1297,81226,8205,8201,257,74799,1344,5952]

theorem envBound36741 : H12AffineFastState.Bounded env36741 := by
  intro p hp
  have h : env36741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36631_36741 : H12AffineEnvironment.transform 13 1297 env36631 = env36741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env36631 == env36741) = true)

def env36742 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74863,65664,4416,8540,4096,5277,74046,66897,13769,78894,1150,74815,1297,81226,8205,8201,257,74799,1344,5952]

theorem envBound36742 : H12AffineFastState.Bounded env36742 := by
  intro p hp
  have h : env36742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36741_36742 : H12AffineEnvironment.transform 17 65664 env36741 = env36742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env36741 == env36742) = true)

theorem identity36742 : scanCanonicalize (H12AffineFastState.compose env36742 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5384) := by decide +kernel

theorem selectedBound36742 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env36743 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5384,1297,5205,65536,69991,65664,4416,5204,4096,5277,70710,66897,193,65830,1150,69943,1297,67650,5381,5377,257,69927,1344,5952]

theorem envBound36743 : H12AffineFastState.Bounded env36743 := by
  intro p hp
  have h : env36743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36742_36743 : H12AffineEnvironment.transform 12 5384 env36742 = env36743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5384 env36742 == env36743) = true)

def env36744 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1556,796,1297,577,65536,67443,65664,1876,576,1556,649,66082,66897,193,65830,1150,67363,1297,67650,785,789,257,67379,1344,340]

theorem envBound36744 : H12AffineFastState.Bounded env36744 := by
  intro p hp
  have h : env36744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36743_36744 : H12AffineEnvironment.transform 11 1556 env36743 = env36744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env36743 == env36744) = true)

def env36745 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,836,796,65,577,65536,66083,65664,516,576,836,649,66082,65537,193,65830,302,66163,65,67650,785,789,257,66147,16,340]

theorem envBound36745 : H12AffineFastState.Bounded env36745 := by
  intro p hp
  have h : env36745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36744_36745 : H12AffineEnvironment.transform 9 336 env36744 = env36745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env36744 == env36745) = true)

theorem identity36745 : scanCanonicalize (H12AffineFastState.compose env36745 (packedSelected [1,8,28] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound36745 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env36746 : List Nat := [2,4,5,16,32,64,128,256,512,336,2048,836,785,65,577,65536,66083,65664,516,576,836,644,66082,65537,193,65830,291,66163,65,67650,785,789,257,66147,16,340]

theorem envBound36746 : H12AffineFastState.Bounded env36746 := by
  intro p hp
  have h : env36746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36745_36746 : H12AffineEnvironment.transform 2 5 env36745 = env36746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env36745 == env36746) = true)

def env36747 : List Nat := [2,4,5,0,32,64,128,256,512,320,2048,836,769,65,577,65536,66083,65664,516,576,836,644,66082,65537,193,65830,291,66147,65,67650,769,773,257,66147,0,324]

theorem envBound36747 : H12AffineFastState.Bounded env36747 := by
  intro p hp
  have h : env36747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36746_36747 : H12AffineEnvironment.transform 3 0 env36746 = env36747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env36746 == env36747) = true)

theorem identity36747 : scanCanonicalize (H12AffineFastState.compose env36747 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound36747 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env36748 : List Nat := [2,4,5,0,32,64,128,5,512,69,2048,577,516,65,577,65536,66083,65664,516,576,577,644,66082,65537,193,65571,38,66147,65,67650,516,512,4,66147,0,65]

theorem envBound36748 : H12AffineFastState.Bounded env36748 := by
  intro p hp
  have h : env36748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36747_36748 : H12AffineEnvironment.transform 7 5 env36747 = env36748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env36747 == env36748) = true)

theorem identity36748 : scanCanonicalize (H12AffineFastState.compose env36748 (packedSelected [2,4,9,11,13,16,17,18] rootPS)) = affineNative (2^(15+1) ^^^ 2688) := by decide +kernel

theorem selectedBound36748 : packedSelected [2,4,9,11,13,16,17,18] rootPS < 2^1333 := by decide +kernel

def env36749 : List Nat := [2,4,5,0,32,64,128,5,512,69,2048,577,516,65,577,2688,2211,2560,516,576,577,644,2210,2689,193,2723,38,2275,65,706,516,512,4,2275,0,65]

theorem envBound36749 : H12AffineFastState.Bounded env36749 := by
  intro p hp
  have h : env36749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36748_36749 : H12AffineEnvironment.transform 15 2688 env36748 = env36749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2688 env36748 == env36749) = true)

theorem identity36749 : scanCanonicalize (H12AffineFastState.compose env36749 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound36749 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env36750 : List Nat := [2,4,5,0,32,64,128,5,0,69,2048,65,4,65,65,2176,2211,2048,4,64,65,132,2210,2177,193,2211,38,2275,65,194,4,0,4,2275,0,65]

theorem envBound36750 : H12AffineFastState.Bounded env36750 := by
  intro p hp
  have h : env36750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36749_36750 : H12AffineEnvironment.transform 8 0 env36749 = env36750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env36749 == env36750) = true)

theorem identity36750 : scanCanonicalize (H12AffineFastState.compose env36750 (packedSelected [1,2,8] rootPS)) = affineNative (2^(10+1) ^^^ 197) := by decide +kernel

theorem selectedBound36750 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env36751 : List Nat := [2,4,5,0,32,64,128,5,0,69,197,65,4,65,65,69,102,197,4,64,65,132,103,68,193,102,38,38,65,194,4,0,4,38,0,65]

theorem envBound36751 : H12AffineFastState.Bounded env36751 := by
  intro p hp
  have h : env36751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36750_36751 : H12AffineEnvironment.transform 10 197 env36750 = env36751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 197 env36750 == env36751) = true)

theorem identity36751 : scanCanonicalize (H12AffineFastState.compose env36751 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound36751 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env36752 : List Nat := [2,4,5,0,6,64,128,5,0,69,197,65,4,65,65,69,64,197,4,64,65,132,65,68,193,64,0,0,65,194,4,0,4,0,0,65]

theorem envBound36752 : H12AffineFastState.Bounded env36752 := by
  intro p hp
  have h : env36752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36751_36752 : H12AffineEnvironment.transform 4 6 env36751 = env36752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env36751 == env36752) = true)

theorem identity36752 : scanCanonicalize (H12AffineFastState.compose env36752 (packedSelected [1,2,3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound36752 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env36753 : List Nat := [2,2,3,0,0,64,128,3,0,67,195,65,2,65,65,67,64,195,2,64,65,130,65,66,193,64,0,0,65,194,2,0,2,0,0,65]

theorem envBound36753 : H12AffineFastState.Bounded env36753 := by
  intro p hp
  have h : env36753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36752_36753 : H12AffineEnvironment.transform 1 2 env36752 = env36753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env36752 == env36753) = true)

theorem identity36753 : scanCanonicalize (H12AffineFastState.compose env36753 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 67) := by decide +kernel

theorem selectedBound36753 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36754 : List Nat := [2,2,3,0,0,64,67,3,0,67,0,65,2,65,65,67,64,0,2,64,65,65,65,66,2,64,0,0,65,1,2,0,2,0,0,65]

theorem envBound36754 : H12AffineFastState.Bounded env36754 := by
  intro p hp
  have h : env36754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36753_36754 : H12AffineEnvironment.transform 6 67 env36753 = env36754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 67 env36753 == env36754) = true)

theorem identity36754 : scanCanonicalize (H12AffineFastState.compose env36754 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound36754 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36755 : List Nat := [2,2,3,0,0,1,2,3,0,2,0,0,2,0,0,2,1,0,2,1,0,0,0,3,2,1,0,0,0,1,2,0,2,0,0,0]

theorem envBound36755 : H12AffineFastState.Bounded env36755 := by
  intro p hp
  have h : env36755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36754_36755 : H12AffineEnvironment.transform 5 1 env36754 = env36755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env36754 == env36755) = true)

def env36756 : List Nat := [2,4,5,1,32,64,128,256,512,321,2048,836,768,65,577,65536,66083,65664,516,576,836,644,66082,65537,193,65830,291,66146,65,67650,768,772,257,66147,1,325]

theorem envBound36756 : H12AffineFastState.Bounded env36756 := by
  intro p hp
  have h : env36756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36746_36756 : H12AffineEnvironment.transform 3 1 env36746 = env36756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env36746 == env36756) = true)

theorem identity36756 : scanCanonicalize (H12AffineFastState.compose env36756 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound36756 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env36757 : List Nat := [2,4,5,1,32,64,128,256,64,321,2048,260,320,65,1,65536,65635,65664,68,0,260,196,65634,65537,193,65830,291,65570,65,67650,320,324,257,65571,1,325]

theorem envBound36757 : H12AffineFastState.Bounded env36757 := by
  intro p hp
  have h : env36757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36756_36757 : H12AffineEnvironment.transform 8 64 env36756 = env36757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env36756 == env36757) = true)

theorem identity36757 : scanCanonicalize (H12AffineFastState.compose env36757 (packedSelected [0,2,3,4,5,7,9,10,11,13,16,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 70) := by decide +kernel

theorem selectedBound36757 : packedSelected [0,2,3,4,5,7,9,10,11,13,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env36758 : List Nat := [2,4,5,1,32,64,128,256,64,321,70,260,320,65,1,65536,65635,65664,68,0,260,196,65634,65537,193,65830,291,65570,65,65540,320,324,257,65571,1,325]

theorem envBound36758 : H12AffineFastState.Bounded env36758 := by
  intro p hp
  have h : env36758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36757_36758 : H12AffineEnvironment.transform 10 70 env36757 = env36758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 70 env36757 == env36758) = true)

theorem identity36758 : scanCanonicalize (H12AffineFastState.compose env36758 (packedSelected [1,4,9,13,15,16] rootPS)) = affineNative (2^(15+1) ^^^ 452) := by decide +kernel

theorem selectedBound36758 : packedSelected [1,4,9,13,15,16] rootPS < 2^1333 := by decide +kernel

def env36759 : List Nat := [2,4,5,1,32,64,128,256,64,321,70,260,320,65,1,452,423,324,68,0,260,196,422,453,193,226,291,486,65,448,320,324,257,487,1,325]

theorem envBound36759 : H12AffineFastState.Bounded env36759 := by
  intro p hp
  have h : env36759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36758_36759 : H12AffineEnvironment.transform 15 452 env36758 = env36759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 452 env36758 == env36759) = true)

theorem identity36759 : scanCanonicalize (H12AffineFastState.compose env36759 (packedSelected [1,2,3,4,5,9,12] rootPS)) = affineNative (2^(7+1) ^^^ 101) := by decide +kernel

theorem selectedBound36759 : packedSelected [1,2,3,4,5,9,12] rootPS < 2^1333 := by decide +kernel

def env36760 : List Nat := [2,4,5,1,32,64,128,101,64,36,70,97,37,65,1,161,194,33,68,0,97,196,195,160,193,226,70,131,65,165,37,33,100,130,1,32]

theorem envBound36760 : H12AffineFastState.Bounded env36760 := by
  intro p hp
  have h : env36760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36759_36760 : H12AffineEnvironment.transform 7 101 env36759 = env36760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 101 env36759 == env36760) = true)

theorem identity36760 : scanCanonicalize (H12AffineFastState.compose env36760 (packedSelected [2,3,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 100) := by decide +kernel

theorem selectedBound36760 : packedSelected [2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env36761 : List Nat := [2,4,5,1,32,64,100,101,64,36,70,97,37,65,1,69,38,33,68,0,97,32,39,68,37,6,70,103,65,65,37,33,100,102,1,32]

theorem envBound36761 : H12AffineFastState.Bounded env36761 := by
  intro p hp
  have h : env36761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36760_36761 : H12AffineEnvironment.transform 6 100 env36760 = env36761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 100 env36760 == env36761) = true)

theorem identity36761 : scanCanonicalize (H12AffineFastState.compose env36761 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound36761 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env36762 : List Nat := [2,4,5,1,1,64,69,68,64,5,70,64,4,65,1,69,7,0,68,0,64,1,6,68,4,6,70,70,65,65,4,0,69,71,1,1]

theorem envBound36762 : H12AffineFastState.Bounded env36762 := by
  intro p hp
  have h : env36762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36761_36762 : H12AffineEnvironment.transform 4 1 env36761 = env36762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env36761 == env36762) = true)

theorem identity36762 : scanCanonicalize (H12AffineFastState.compose env36762 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound36762 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36763 : List Nat := [2,2,3,1,1,64,67,66,64,3,64,64,2,65,1,67,1,0,66,0,64,1,0,66,2,0,64,64,65,65,2,0,67,65,1,1]

theorem envBound36763 : H12AffineFastState.Bounded env36763 := by
  intro p hp
  have h : env36763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36762_36763 : H12AffineEnvironment.transform 1 2 env36762 = env36763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env36762 == env36763) = true)

theorem identity36763 : scanCanonicalize (H12AffineFastState.compose env36763 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound36763 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env36764 : List Nat := [2,2,3,1,1,1,2,3,1,3,1,1,2,0,1,2,1,0,3,0,1,1,0,3,2,0,1,1,0,0,2,0,2,0,1,1]

theorem envBound36764 : H12AffineFastState.Bounded env36764 := by
  intro p hp
  have h : env36764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36763_36764 : H12AffineEnvironment.transform 5 1 env36763 = env36764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env36763 == env36764) = true)

def env36765 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,837,796,64,577,65536,66082,65664,517,576,837,649,66082,65536,193,65830,303,66162,64,67650,785,789,257,66146,17,340]

theorem envBound36765 : H12AffineFastState.Bounded env36765 := by
  intro p hp
  have h : env36765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36744_36765 : H12AffineEnvironment.transform 9 337 env36744 = env36765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env36744 == env36765) = true)

theorem identity36765 : scanCanonicalize (H12AffineFastState.compose env36765 (packedSelected [1,8,28] rootPS)) = affineNative (2^(8+1) ^^^ 329) := by decide +kernel

theorem selectedBound36765 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env36766 : List Nat := [2,4,8,16,32,64,128,256,329,337,2048,12,85,64,264,65536,65899,65664,332,265,12,448,65899,65536,193,65830,303,65851,64,67650,88,92,257,65835,17,340]

theorem envBound36766 : H12AffineFastState.Bounded env36766 := by
  intro p hp
  have h : env36766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36765_36766 : H12AffineEnvironment.transform 8 329 env36765 = env36766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 329 env36765 == env36766) = true)

def env36767 : List Nat := [2,4,8,12,32,64,128,256,329,333,2048,12,73,64,264,65536,65899,65664,332,265,12,448,65899,65536,193,65830,303,65831,64,67650,68,64,257,65835,13,328]

theorem envBound36767 : H12AffineFastState.Bounded env36767 := by
  intro p hp
  have h : env36767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36766_36767 : H12AffineEnvironment.transform 3 12 env36766 = env36767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env36766 == env36767) = true)

theorem identity36767 : scanCanonicalize (H12AffineFastState.compose env36767 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 46) := by decide +kernel

theorem selectedBound36767 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env36768 : List Nat := [2,4,8,12,32,64,128,256,329,333,2048,12,73,64,264,46,325,174,332,265,12,448,325,46,193,264,303,265,64,2156,68,64,257,261,13,328]

theorem envBound36768 : H12AffineFastState.Bounded env36768 := by
  intro p hp
  have h : env36768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36767_36768 : H12AffineEnvironment.transform 15 46 env36767 = env36768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 46 env36767 == env36768) = true)

theorem identity36768 : scanCanonicalize (H12AffineFastState.compose env36768 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 9) := by decide +kernel

theorem selectedBound36768 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env36769 : List Nat := [2,4,8,12,32,64,128,9,64,68,2048,12,73,64,1,46,76,174,69,0,12,201,76,46,193,1,38,0,64,2156,68,64,8,12,13,65]

theorem envBound36769 : H12AffineFastState.Bounded env36769 := by
  intro p hp
  have h : env36769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36768_36769 : H12AffineEnvironment.transform 7 9 env36768 = env36769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 9 env36768 == env36769) = true)

theorem identity36769 : scanCanonicalize (H12AffineFastState.compose env36769 (packedSelected [3,5,10] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound36769 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env36770 : List Nat := [2,4,4,0,32,64,128,5,64,68,2048,0,69,64,1,34,64,162,69,0,0,197,64,34,193,1,38,0,64,2144,68,64,4,0,1,65]

theorem envBound36770 : H12AffineFastState.Bounded env36770 := by
  intro p hp
  have h : env36770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36769_36770 : H12AffineEnvironment.transform 2 4 env36769 = env36770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env36769 == env36770) = true)

theorem identity36770 : scanCanonicalize (H12AffineFastState.compose env36770 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 67) := by decide +kernel

theorem selectedBound36770 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env36771 : List Nat := [2,4,4,0,32,64,67,5,64,68,2048,0,69,64,1,34,64,97,69,0,0,6,64,34,2,1,38,0,64,2144,68,64,4,0,1,65]

theorem envBound36771 : H12AffineFastState.Bounded env36771 := by
  intro p hp
  have h : env36771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36770_36771 : H12AffineEnvironment.transform 6 67 env36770 = env36771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 67 env36770 == env36771) = true)

theorem identity36771 : scanCanonicalize (H12AffineFastState.compose env36771 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 38) := by decide +kernel

theorem selectedBound36771 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env36772 : List Nat := [2,4,4,0,32,38,37,5,38,34,2048,0,35,38,1,34,38,7,35,0,0,6,38,34,2,1,38,0,38,2054,34,38,4,0,1,39]

theorem envBound36772 : H12AffineFastState.Bounded env36772 := by
  intro p hp
  have h : env36772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36771_36772 : H12AffineEnvironment.transform 5 38 env36771 = env36772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 38 env36771 == env36772) = true)

theorem identity36772 : scanCanonicalize (H12AffineFastState.compose env36772 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound36772 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env36773 : List Nat := [2,4,4,0,32,38,37,5,38,34,33,0,35,38,1,34,38,7,35,0,0,6,38,34,2,1,38,0,38,39,34,38,4,0,1,39]

theorem envBound36773 : H12AffineFastState.Bounded env36773 := by
  intro p hp
  have h : env36773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36772_36773 : H12AffineEnvironment.transform 10 33 env36772 = env36773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env36772 == env36773) = true)

theorem identity36773 : scanCanonicalize (H12AffineFastState.compose env36773 (packedSelected [0,1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound36773 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env36774 : List Nat := [2,0,0,0,32,34,33,1,34,34,33,0,35,34,1,34,34,3,35,0,0,2,34,34,2,1,34,0,34,35,34,34,0,0,1,35]

theorem envBound36774 : H12AffineFastState.Bounded env36774 := by
  intro p hp
  have h : env36774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36773_36774 : H12AffineEnvironment.transform 1 0 env36773 = env36774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env36773 == env36774) = true)

theorem identity36774 : scanCanonicalize (H12AffineFastState.compose env36774 (packedSelected [0,2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound36774 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env36775 : List Nat := [2,0,0,0,1,3,0,1,3,3,0,0,2,3,1,3,3,3,2,0,0,2,3,3,2,1,3,0,3,2,3,3,0,0,1,2]

theorem envBound36775 : H12AffineFastState.Bounded env36775 := by
  intro p hp
  have h : env36775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36774_36775 : H12AffineEnvironment.transform 4 1 env36774 = env36775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env36774 == env36775) = true)

def env36776 : List Nat := [2,4,8,13,32,64,128,256,329,332,2048,12,72,64,264,65536,65899,65664,332,265,12,448,65899,65536,193,65830,303,65830,64,67650,69,65,257,65835,12,329]

theorem envBound36776 : H12AffineFastState.Bounded env36776 := by
  intro p hp
  have h : env36776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36766_36776 : H12AffineEnvironment.transform 3 13 env36766 = env36776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env36766 == env36776) = true)

theorem identity36776 : scanCanonicalize (H12AffineFastState.compose env36776 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound36776 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env36777 : List Nat := [2,4,8,13,32,64,128,4,77,72,2048,12,72,64,12,65536,65647,65664,72,13,12,196,65647,65536,193,65570,43,65570,64,67650,69,65,5,65583,12,77]

theorem envBound36777 : H12AffineFastState.Bounded env36777 := by
  intro p hp
  have h : env36777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36776_36777 : H12AffineEnvironment.transform 7 4 env36776 = env36777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env36776 == env36777) = true)

theorem identity36777 : scanCanonicalize (H12AffineFastState.compose env36777 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound36777 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env36778 : List Nat := [2,4,8,13,32,12,128,4,1,4,2048,12,4,12,12,65536,65571,65664,4,13,12,136,65571,65536,141,65570,43,65570,12,67598,9,13,5,65583,12,1]

theorem envBound36778 : H12AffineFastState.Bounded env36778 := by
  intro p hp
  have h : env36778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36777_36778 : H12AffineEnvironment.transform 5 12 env36777 = env36778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env36777 == env36778) = true)

theorem identity36778 : scanCanonicalize (H12AffineFastState.compose env36778 (packedSelected [0,1,2,5,7,8,11,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 174) := by decide +kernel

theorem selectedBound36778 : packedSelected [0,1,2,5,7,8,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env36779 : List Nat := [2,4,8,13,32,12,128,4,1,4,174,12,4,12,12,65536,65571,65664,4,13,12,136,65571,65536,141,65570,43,65570,12,65696,9,13,5,65583,12,1]

theorem envBound36779 : H12AffineFastState.Bounded env36779 := by
  intro p hp
  have h : env36779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36778_36779 : H12AffineEnvironment.transform 10 174 env36778 = env36779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 174 env36778 == env36779) = true)

theorem identity36779 : scanCanonicalize (H12AffineFastState.compose env36779 (packedSelected [0,3,7,8,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 37) := by decide +kernel

theorem selectedBound36779 : packedSelected [0,3,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env36780 : List Nat := [2,4,8,13,32,12,37,4,1,4,11,12,4,12,12,65536,65571,65573,4,13,12,45,65571,65536,40,65570,43,65570,12,65541,9,13,5,65583,12,1]

theorem envBound36780 : H12AffineFastState.Bounded env36780 := by
  intro p hp
  have h : env36780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36779_36780 : H12AffineEnvironment.transform 6 37 env36779 = env36780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 37 env36779 == env36780) = true)

theorem identity36780 : scanCanonicalize (H12AffineFastState.compose env36780 (packedSelected [1,4,5] rootPS)) = affineNative (2^(15+1) ^^^ 15) := by decide +kernel

theorem selectedBound36780 : packedSelected [1,4,5] rootPS < 2^1333 := by decide +kernel

def env36781 : List Nat := [2,4,8,13,32,12,37,4,1,4,11,12,4,12,12,15,44,42,4,13,12,45,44,15,40,45,43,45,12,10,9,13,5,32,12,1]

theorem envBound36781 : H12AffineFastState.Bounded env36781 := by
  intro p hp
  have h : env36781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36780_36781 : H12AffineEnvironment.transform 15 15 env36780 = env36781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 15 env36780 == env36781) = true)

def env36782 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1557,797,1297,576,65536,67442,65664,1877,577,1557,648,66083,66897,193,65830,1150,67362,1297,67650,784,788,257,67378,1344,341]

theorem envBound36782 : H12AffineFastState.Bounded env36782 := by
  intro p hp
  have h : env36782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36743_36782 : H12AffineEnvironment.transform 11 1557 env36743 = env36782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env36743 == env36782) = true)

def env36783 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,837,797,65,576,65536,66082,65664,517,577,837,648,66083,65537,193,65830,302,66162,65,67650,784,788,257,66146,16,341]

theorem envBound36783 : H12AffineFastState.Bounded env36783 := by
  intro p hp
  have h : env36783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36782_36783 : H12AffineEnvironment.transform 9 336 env36782 = env36783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env36782 == env36783) = true)

theorem identity36783 : scanCanonicalize (H12AffineFastState.compose env36783 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 575) := by decide +kernel

theorem selectedBound36783 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env36784 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,837,797,65,576,575,29,703,517,577,837,648,28,574,193,793,302,77,65,2685,784,788,257,93,16,341]

theorem envBound36784 : H12AffineFastState.Bounded env36784 := by
  intro p hp
  have h : env36784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36783_36784 : H12AffineEnvironment.transform 15 575 env36783 = env36784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 575 env36783 == env36784) = true)

def env36785 : List Nat := [2,4,8,16,32,64,128,256,64,336,2048,261,349,65,0,127,29,255,69,1,261,200,28,126,193,345,302,77,65,2109,336,340,257,93,16,341]

theorem envBound36785 : H12AffineFastState.Bounded env36785 := by
  intro p hp
  have h : env36785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36784_36785 : H12AffineEnvironment.transform 8 64 env36784 = env36785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env36784 == env36785) = true)

theorem identity36785 : scanCanonicalize (H12AffineFastState.compose env36785 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 89) := by decide +kernel

theorem selectedBound36785 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env36786 : List Nat := [2,4,8,16,32,64,128,89,64,9,2048,92,4,65,0,127,29,255,69,1,92,200,28,126,193,0,119,77,65,2109,9,13,88,93,16,12]

theorem envBound36786 : H12AffineFastState.Bounded env36786 := by
  intro p hp
  have h : env36786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36785_36786 : H12AffineEnvironment.transform 7 89 env36785 = env36786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 89 env36785 == env36786) = true)

theorem identity36786 : scanCanonicalize (H12AffineFastState.compose env36786 (packedSelected [0,2,4,7,9,15,16,20] rootPS)) = affineNative (2^(10+1) ^^^ 71) := by decide +kernel

theorem selectedBound36786 : packedSelected [0,2,4,7,9,15,16,20] rootPS < 2^1333 := by decide +kernel

def env36787 : List Nat := [2,4,8,16,32,64,128,89,64,9,71,92,4,65,0,127,29,255,69,1,92,200,28,126,193,0,119,77,65,122,9,13,88,93,16,12]

theorem envBound36787 : H12AffineFastState.Bounded env36787 := by
  intro p hp
  have h : env36787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36786_36787 : H12AffineEnvironment.transform 10 71 env36786 = env36787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 71 env36786 == env36787) = true)

theorem identity36787 : scanCanonicalize (H12AffineFastState.compose env36787 (packedSelected [0,3,4,7,8,9,11,13,16,17] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound36787 : packedSelected [0,3,4,7,8,9,11,13,16,17] rootPS < 2^1333 := by decide +kernel

def env36788 : List Nat := [2,4,8,16,23,64,128,89,64,9,71,92,4,65,0,72,29,200,69,1,92,200,28,73,193,0,64,77,65,77,9,13,88,93,16,12]

theorem envBound36788 : H12AffineFastState.Bounded env36788 := by
  intro p hp
  have h : env36788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36787_36788 : H12AffineEnvironment.transform 4 23 env36787 = env36788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env36787 == env36788) = true)

theorem identity36788 : scanCanonicalize (H12AffineFastState.compose env36788 (packedSelected [0,4,5,8,11] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound36788 : packedSelected [0,4,5,8,11] rootPS < 2^1333 := by decide +kernel

def env36789 : List Nat := [2,4,8,16,23,12,128,21,12,9,11,16,4,13,0,4,29,132,9,1,16,132,28,5,141,0,12,1,13,1,9,13,20,17,16,12]

theorem envBound36789 : H12AffineFastState.Bounded env36789 := by
  intro p hp
  have h : env36789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36788_36789 : H12AffineEnvironment.transform 5 12 env36788 = env36789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env36788 == env36789) = true)

theorem identity36789 : scanCanonicalize (H12AffineFastState.compose env36789 (packedSelected [0,3] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound36789 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env36790 : List Nat := [2,4,8,16,23,12,14,21,12,9,11,16,4,13,0,4,29,10,9,1,16,10,28,5,3,0,12,1,13,1,9,13,20,17,16,12]

theorem envBound36790 : H12AffineFastState.Bounded env36790 := by
  intro p hp
  have h : env36790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36789_36790 : H12AffineEnvironment.transform 6 14 env36789 = env36790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env36789 == env36790) = true)

def env36791 : List Nat := [2,4,8,16,32,64,128,256,65,336,2048,260,348,65,1,126,29,254,68,0,260,201,28,127,193,344,302,77,65,2108,337,341,257,93,16,341]

theorem envBound36791 : H12AffineFastState.Bounded env36791 := by
  intro p hp
  have h : env36791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36784_36791 : H12AffineEnvironment.transform 8 65 env36784 = env36791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env36784 == env36791) = true)

theorem identity36791 : scanCanonicalize (H12AffineFastState.compose env36791 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound36791 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env36792 : List Nat := [2,4,8,16,32,64,128,84,65,4,2048,80,8,65,1,126,29,254,68,0,80,201,28,127,193,12,122,77,65,2108,5,1,85,93,16,1]

theorem envBound36792 : H12AffineFastState.Bounded env36792 := by
  intro p hp
  have h : env36792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36791_36792 : H12AffineEnvironment.transform 7 84 env36791 = env36792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env36791 == env36792) = true)

theorem identity36792 : scanCanonicalize (H12AffineFastState.compose env36792 (packedSelected [1,3,4,9,10,12,13,16,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 65) := by decide +kernel

theorem selectedBound36792 : packedSelected [1,3,4,9,10,12,13,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env36793 : List Nat := [2,4,8,16,32,64,128,84,65,4,65,80,8,65,1,126,29,254,68,0,80,201,28,127,193,12,122,77,65,125,5,1,85,93,16,1]

theorem envBound36793 : H12AffineFastState.Bounded env36793 := by
  intro p hp
  have h : env36793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36792_36793 : H12AffineEnvironment.transform 10 65 env36792 = env36793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 65 env36792 == env36793) = true)

theorem identity36793 : scanCanonicalize (H12AffineFastState.compose env36793 (packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 39) := by decide +kernel

theorem selectedBound36793 : packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env36794 : List Nat := [2,4,8,16,32,39,128,51,38,4,38,55,8,38,1,25,29,153,35,0,55,174,28,24,166,12,29,42,38,26,5,1,50,58,16,1]

theorem envBound36794 : H12AffineFastState.Bounded env36794 := by
  intro p hp
  have h : env36794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36793_36794 : H12AffineEnvironment.transform 5 39 env36793 = env36794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 39 env36793 == env36794) = true)

theorem identity36794 : scanCanonicalize (H12AffineFastState.compose env36794 (packedSelected [0,1,4,7,8,9,11] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound36794 : packedSelected [0,1,4,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env36795 : List Nat := [2,4,8,16,13,10,128,30,11,4,11,26,8,11,1,25,29,153,14,0,26,131,28,24,139,12,29,7,11,26,5,1,31,23,16,1]

theorem envBound36795 : H12AffineFastState.Bounded env36795 := by
  intro p hp
  have h : env36795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36794_36795 : H12AffineEnvironment.transform 4 13 env36794 = env36795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env36794 == env36795) = true)

theorem identity36795 : scanCanonicalize (H12AffineFastState.compose env36795 (packedSelected [0,1,2,3,4,5] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound36795 : packedSelected [0,1,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env36796 : List Nat := [2,2,8,16,11,10,128,24,11,2,11,26,8,11,1,25,27,153,8,0,26,131,26,24,139,10,27,1,11,26,3,1,25,17,16,1]

theorem envBound36796 : H12AffineFastState.Bounded env36796 := by
  intro p hp
  have h : env36796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36795_36796 : H12AffineEnvironment.transform 1 2 env36795 = env36796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env36795 == env36796) = true)

theorem identity36796 : scanCanonicalize (H12AffineFastState.compose env36796 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound36796 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env36797 : List Nat := [2,2,8,16,11,10,18,24,11,2,11,26,8,11,1,25,27,11,8,0,26,17,26,24,25,10,27,1,11,26,3,1,25,17,16,1]

theorem envBound36797 : H12AffineFastState.Bounded env36797 := by
  intro p hp
  have h : env36797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36796_36797 : H12AffineEnvironment.transform 6 18 env36796 = env36797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env36796 == env36797) = true)

theorem identity36797 : scanCanonicalize (H12AffineFastState.compose env36797 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound36797 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36798 : List Nat := [2,2,8,10,11,10,8,2,11,2,11,0,8,11,1,3,1,11,8,0,0,11,0,2,3,10,1,1,11,0,3,1,3,11,10,1]

theorem envBound36798 : H12AffineFastState.Bounded env36798 := by
  intro p hp
  have h : env36798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36797_36798 : H12AffineEnvironment.transform 3 10 env36797 = env36798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env36797 == env36798) = true)

theorem identity36798 : scanCanonicalize (H12AffineFastState.compose env36798 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound36798 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36799 : List Nat := [2,2,2,0,1,0,2,2,1,2,1,0,2,1,1,3,1,1,2,0,0,1,0,2,3,0,1,1,1,0,3,1,3,1,0,1]

theorem envBound36799 : H12AffineFastState.Bounded env36799 := by
  intro p hp
  have h : env36799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36798_36799 : H12AffineEnvironment.transform 2 2 env36798 = env36799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env36798 == env36799) = true)

def env36800 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,836,797,64,576,65536,66083,65664,516,577,836,648,66083,65536,193,65830,303,66163,64,67650,784,788,257,66147,17,341]

theorem envBound36800 : H12AffineFastState.Bounded env36800 := by
  intro p hp
  have h : env36800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36782_36800 : H12AffineEnvironment.transform 9 337 env36782 = env36800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env36782 == env36800) = true)

theorem identity36800 : scanCanonicalize (H12AffineFastState.compose env36800 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 378) := by decide +kernel

theorem selectedBound36800 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env36801 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,836,797,64,576,378,857,506,516,577,836,648,857,378,193,92,303,777,64,2360,784,788,257,793,17,341]

theorem envBound36801 : H12AffineFastState.Bounded env36801 := by
  intro p hp
  have h : env36801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36800_36801 : H12AffineEnvironment.transform 15 378 env36800 = env36801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 378 env36800 == env36801) = true)

def env36802 : List Nat := [2,4,8,16,32,64,128,8,512,89,2048,588,533,64,576,114,593,242,516,577,588,648,593,114,193,92,39,513,64,2096,536,540,9,529,17,93]

theorem envBound36802 : H12AffineFastState.Bounded env36802 := by
  intro p hp
  have h : env36802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36801_36802 : H12AffineEnvironment.transform 7 8 env36801 = env36802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 8 env36801 == env36802) = true)

theorem identity36802 : scanCanonicalize (H12AffineFastState.compose env36802 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound36802 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env36803 : List Nat := [2,4,8,16,32,64,128,8,0,89,2048,76,21,64,64,114,81,242,4,65,76,136,81,114,193,92,39,1,64,2096,24,28,9,17,17,93]

theorem envBound36803 : H12AffineFastState.Bounded env36803 := by
  intro p hp
  have h : env36803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36802_36803 : H12AffineEnvironment.transform 8 0 env36802 = env36803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env36802 == env36803) = true)

theorem identity36803 : scanCanonicalize (H12AffineFastState.compose env36803 (packedSelected [0,1,4,5,7,8,9,11,12,16,17] rootPS)) = affineNative (2^(6+1) ^^^ 21) := by decide +kernel

theorem selectedBound36803 : packedSelected [0,1,4,5,7,8,9,11,12,16,17] rootPS < 2^1333 := by decide +kernel

def env36804 : List Nat := [2,4,8,16,32,64,21,8,0,89,2048,76,21,64,64,114,81,103,4,65,76,29,81,114,84,92,39,1,64,2096,24,28,9,17,17,93]

theorem envBound36804 : H12AffineFastState.Bounded env36804 := by
  intro p hp
  have h : env36804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36803_36804 : H12AffineEnvironment.transform 6 21 env36803 = env36804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 21 env36803 == env36804) = true)

theorem identity36804 : scanCanonicalize (H12AffineFastState.compose env36804 (packedSelected [2,11,12,13,18] rootPS)) = affineNative (2^(10+1) ^^^ 109) := by decide +kernel

theorem selectedBound36804 : packedSelected [2,11,12,13,18] rootPS < 2^1333 := by decide +kernel

def env36805 : List Nat := [2,4,8,16,32,64,21,8,0,89,109,76,21,64,64,114,81,103,4,65,76,29,81,114,84,92,39,1,64,93,24,28,9,17,17,93]

theorem envBound36805 : H12AffineFastState.Bounded env36805 := by
  intro p hp
  have h : env36805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36804_36805 : H12AffineEnvironment.transform 10 109 env36804 = env36805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 109 env36804 == env36805) = true)

theorem identity36805 : scanCanonicalize (H12AffineFastState.compose env36805 (packedSelected [2,3,5,7,9,10,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound36805 : packedSelected [2,3,5,7,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env36806 : List Nat := [2,4,8,16,17,64,21,8,0,89,92,76,21,64,64,67,81,86,4,65,76,29,81,67,84,92,22,1,64,93,24,28,9,17,17,93]

theorem envBound36806 : H12AffineFastState.Bounded env36806 := by
  intro p hp
  have h : env36806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36805_36806 : H12AffineEnvironment.transform 4 17 env36805 = env36806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env36805 == env36806) = true)

theorem identity36806 : scanCanonicalize (H12AffineFastState.compose env36806 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound36806 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env36807 : List Nat := [2,4,8,16,17,0,21,8,0,25,28,12,21,0,0,3,17,22,4,1,12,29,17,3,20,28,22,1,0,29,24,28,9,17,17,29]

theorem envBound36807 : H12AffineFastState.Bounded env36807 := by
  intro p hp
  have h : env36807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36806_36807 : H12AffineEnvironment.transform 5 0 env36806 = env36807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env36806 == env36807) = true)

theorem identity36807 : scanCanonicalize (H12AffineFastState.compose env36807 (packedSelected [0,1,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound36807 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env36808 : List Nat := [2,4,3,16,17,0,21,3,0,18,23,7,21,0,0,3,17,22,4,1,7,22,17,3,20,23,22,1,0,22,19,23,2,17,17,22]

theorem envBound36808 : H12AffineFastState.Bounded env36808 := by
  intro p hp
  have h : env36808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36807_36808 : H12AffineEnvironment.transform 2 3 env36807 = env36808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env36807 == env36808) = true)

theorem identity36808 : scanCanonicalize (H12AffineFastState.compose env36808 (packedSelected [1,2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound36808 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env36809 : List Nat := [2,2,3,16,17,0,19,3,0,18,17,1,19,0,0,3,17,16,2,1,1,16,17,3,18,17,16,1,0,16,19,17,2,17,17,16]

theorem envBound36809 : H12AffineFastState.Bounded env36809 := by
  intro p hp
  have h : env36809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36808_36809 : H12AffineEnvironment.transform 1 2 env36808 = env36809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env36808 == env36809) = true)

def env36810 : List Nat := [2,4,8,16,32,64,128,9,512,88,2048,589,532,64,576,115,592,243,516,577,589,648,592,115,193,92,38,512,64,2097,537,541,8,528,17,92]

theorem envBound36810 : H12AffineFastState.Bounded env36810 := by
  intro p hp
  have h : env36810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36801_36810 : H12AffineEnvironment.transform 7 9 env36801 = env36810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 9 env36801 == env36810) = true)

theorem identity36810 : scanCanonicalize (H12AffineFastState.compose env36810 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(8+1) ^^^ 13) := by decide +kernel

theorem selectedBound36810 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env36811 : List Nat := [2,4,8,16,32,64,128,9,13,88,2048,64,25,64,77,115,93,243,9,76,64,133,93,115,193,92,38,13,64,2097,20,16,8,29,17,92]

theorem envBound36811 : H12AffineFastState.Bounded env36811 := by
  intro p hp
  have h : env36811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36810_36811 : H12AffineEnvironment.transform 8 13 env36810 = env36811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 13 env36810 == env36811) = true)

theorem identity36811 : scanCanonicalize (H12AffineFastState.compose env36811 (packedSelected [13,21] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound36811 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env36812 : List Nat := [2,4,8,0,32,64,128,9,13,72,2048,64,9,64,77,99,77,227,9,76,64,133,77,99,193,76,38,13,64,2081,4,0,8,13,1,76]

theorem envBound36812 : H12AffineFastState.Bounded env36812 := by
  intro p hp
  have h : env36812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36811_36812 : H12AffineEnvironment.transform 3 0 env36811 = env36812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env36811 == env36812) = true)

theorem identity36812 : scanCanonicalize (H12AffineFastState.compose env36812 (packedSelected [0,1,5,7,11,12,13] rootPS)) = affineNative (2^(10+1) ^^^ 7) := by decide +kernel

theorem selectedBound36812 : packedSelected [0,1,5,7,11,12,13] rootPS < 2^1333 := by decide +kernel

def env36813 : List Nat := [2,4,8,0,32,64,128,9,13,72,7,64,9,64,77,99,77,227,9,76,64,133,77,99,193,76,38,13,64,38,4,0,8,13,1,76]

theorem envBound36813 : H12AffineFastState.Bounded env36813 := by
  intro p hp
  have h : env36813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36812_36813 : H12AffineEnvironment.transform 10 7 env36812 = env36813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 7 env36812 == env36813) = true)

theorem identity36813 : scanCanonicalize (H12AffineFastState.compose env36813 (packedSelected [1,5,8,10,12] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound36813 : packedSelected [1,5,8,10,12] rootPS < 2^1333 := by decide +kernel

def env36814 : List Nat := [2,4,8,0,6,64,128,9,13,72,7,64,9,64,77,69,77,197,9,76,64,133,77,69,193,76,0,13,64,0,4,0,8,13,1,76]

theorem envBound36814 : H12AffineFastState.Bounded env36814 := by
  intro p hp
  have h : env36814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36813_36814 : H12AffineEnvironment.transform 4 6 env36813 = env36814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env36813 == env36814) = true)

theorem identity36814 : scanCanonicalize (H12AffineFastState.compose env36814 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 73) := by decide +kernel

theorem selectedBound36814 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env36815 : List Nat := [2,4,8,0,6,64,73,9,13,72,7,64,9,64,77,69,77,12,9,76,64,76,77,69,8,76,0,13,64,0,4,0,8,13,1,76]

theorem envBound36815 : H12AffineFastState.Bounded env36815 := by
  intro p hp
  have h : env36815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36814_36815 : H12AffineEnvironment.transform 6 73 env36814 = env36815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 73 env36814 == env36815) = true)

theorem identity36815 : scanCanonicalize (H12AffineFastState.compose env36815 (packedSelected [1,2] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound36815 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env36816 : List Nat := [2,4,8,0,6,13,4,9,13,5,7,13,9,13,0,8,0,12,9,1,13,1,0,8,8,1,0,13,13,0,4,0,8,13,1,1]

theorem envBound36816 : H12AffineFastState.Bounded env36816 := by
  intro p hp
  have h : env36816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36815_36816 : H12AffineEnvironment.transform 5 13 env36815 = env36816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env36815 == env36816) = true)

theorem identity36816 : scanCanonicalize (H12AffineFastState.compose env36816 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound36816 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36817 : List Nat := [2,4,2,0,6,7,4,3,7,5,7,7,3,7,0,2,0,6,3,1,7,1,0,2,2,1,0,7,7,0,4,0,2,7,1,1]

theorem envBound36817 : H12AffineFastState.Bounded env36817 := by
  intro p hp
  have h : env36817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36816_36817 : H12AffineEnvironment.transform 2 2 env36816 = env36817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env36816 == env36817) = true)

theorem identity36817 : scanCanonicalize (H12AffineFastState.compose env36817 (packedSelected [0,7] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound36817 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env36818 : List Nat := [2,3,2,0,1,0,3,3,0,2,0,0,3,0,0,2,0,1,3,1,0,1,0,2,2,1,0,0,0,0,3,0,2,0,1,1]

theorem envBound36818 : H12AffineFastState.Bounded env36818 := by
  intro p hp
  have h : env36818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36817_36818 : H12AffineEnvironment.transform 1 3 env36817 = env36818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env36817 == env36818) = true)

theorem identity36818 : scanCanonicalize (H12AffineFastState.compose env36818 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound36818 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36819 : List Nat := [1,0,1,0,1,0,0,0,0,1,0,0,0,0,0,1,0,1,0,1,0,1,0,1,1,1,0,0,0,0,0,0,1,0,1,1]

theorem envBound36819 : H12AffineFastState.Bounded env36819 := by
  intro p hp
  have h : env36819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36818_36819 : H12AffineEnvironment.transform 0 1 env36818 = env36819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env36818 == env36819) = true)

def env36820 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74863,65665,4416,8540,4096,5277,74046,66897,13769,78894,1151,74815,1297,81226,8205,8201,257,74799,1344,5952]

theorem envBound36820 : H12AffineFastState.Bounded env36820 := by
  intro p hp
  have h : env36820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36741_36820 : H12AffineEnvironment.transform 17 65665 env36741 = env36820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env36741 == env36820) = true)

theorem identity36820 : scanCanonicalize (H12AffineFastState.compose env36820 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 73) := by decide +kernel

theorem selectedBound36820 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env36821 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,73,1297,276,65536,66598,65665,4416,277,4096,5277,65911,66897,5504,70759,1151,66678,1297,72963,68,64,257,66662,1344,5952]

theorem envBound36821 : H12AffineFastState.Bounded env36821 := by
  intro p hp
  have h : env36821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36820_36821 : H12AffineEnvironment.transform 12 73 env36820 = env36821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env36820 == env36821) = true)

def env36822 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1556,73,1297,276,65536,66598,65665,1876,277,1556,649,65911,66897,916,66163,1151,66678,1297,68375,68,64,257,66662,1344,340]

theorem envBound36822 : H12AffineFastState.Bounded env36822 := by
  intro p hp
  have h : env36822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36821_36822 : H12AffineEnvironment.transform 11 1556 env36821 = env36822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env36821 == env36822) = true)

def env36823 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,852,73,81,276,65536,65894,65665,532,277,852,649,65911,65553,916,66163,319,65846,81,68375,68,64,257,65830,0,340]

theorem envBound36823 : H12AffineFastState.Bounded env36823 := by
  intro p hp
  have h : env36823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36822_36823 : H12AffineEnvironment.transform 9 320 env36822 = env36823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env36822 == env36823) = true)

theorem identity36823 : scanCanonicalize (H12AffineFastState.compose env36823 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound36823 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env36824 : List Nat := [2,4,8,16,32,64,128,21,512,85,2048,577,73,81,1,65536,65651,65665,532,0,577,649,65634,65553,641,66163,42,65571,81,68098,68,64,20,65587,0,65]

theorem envBound36824 : H12AffineFastState.Bounded env36824 := by
  intro p hp
  have h : env36824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36823_36824 : H12AffineEnvironment.transform 7 21 env36823 = env36824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env36823 == env36824) = true)

theorem identity36824 : scanCanonicalize (H12AffineFastState.compose env36824 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound36824 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env36825 : List Nat := [2,4,8,16,32,64,128,21,16,85,2048,81,73,81,1,65536,65651,65665,4,0,81,153,65634,65553,145,65635,42,65571,81,67602,68,64,20,65587,0,65]

theorem envBound36825 : H12AffineFastState.Bounded env36825 := by
  intro p hp
  have h : env36825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36824_36825 : H12AffineEnvironment.transform 8 16 env36824 = env36825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env36824 == env36825) = true)

theorem identity36825 : scanCanonicalize (H12AffineFastState.compose env36825 (packedSelected [0,2,4,7,9,11,13,16] rootPS)) = affineNative (2^(15+1) ^^^ 83) := by decide +kernel

theorem selectedBound36825 : packedSelected [0,2,4,7,9,11,13,16] rootPS < 2^1333 := by decide +kernel

def env36826 : List Nat := [2,4,8,16,32,64,128,21,16,85,2048,81,73,81,1,83,32,210,4,0,81,153,49,66,145,48,42,112,81,2113,68,64,20,96,0,65]

theorem envBound36826 : H12AffineFastState.Bounded env36826 := by
  intro p hp
  have h : env36826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36825_36826 : H12AffineEnvironment.transform 15 83 env36825 = env36826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 83 env36825 == env36826) = true)

theorem identity36826 : scanCanonicalize (H12AffineFastState.compose env36826 (packedSelected [2,3,10,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 60) := by decide +kernel

theorem selectedBound36826 : packedSelected [2,3,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env36827 : List Nat := [2,4,8,16,32,64,128,21,16,85,60,81,73,81,1,83,32,210,4,0,81,153,49,66,145,48,42,112,81,125,68,64,20,96,0,65]

theorem envBound36827 : H12AffineFastState.Bounded env36827 := by
  intro p hp
  have h : env36827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36826_36827 : H12AffineEnvironment.transform 10 60 env36826 = env36827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 60 env36826 == env36827) = true)

theorem identity36827 : scanCanonicalize (H12AffineFastState.compose env36827 (packedSelected [0,3,7,8,10,11,12,17] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound36827 : packedSelected [0,3,7,8,10,11,12,17] rootPS < 2^1333 := by decide +kernel

def env36828 : List Nat := [2,4,8,7,32,64,128,2,7,66,43,70,73,70,1,68,32,197,4,0,70,142,38,66,134,39,42,103,70,106,68,64,3,96,0,65]

theorem envBound36828 : H12AffineFastState.Bounded env36828 := by
  intro p hp
  have h : env36828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36827_36828 : H12AffineEnvironment.transform 3 7 env36827 = env36828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env36827 == env36828) = true)

theorem identity36828 : scanCanonicalize (H12AffineFastState.compose env36828 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound36828 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env36829 : List Nat := [2,4,8,7,0,64,128,2,7,66,11,70,73,70,1,68,0,197,4,0,70,142,6,66,134,7,10,71,70,74,68,64,3,64,0,65]

theorem envBound36829 : H12AffineFastState.Bounded env36829 := by
  intro p hp
  have h : env36829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36828_36829 : H12AffineEnvironment.transform 4 0 env36828 = env36829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env36828 == env36829) = true)

theorem identity36829 : scanCanonicalize (H12AffineFastState.compose env36829 (packedSelected [2,3] rootPS)) = affineNative (2^(6+1) ^^^ 67) := by decide +kernel

theorem selectedBound36829 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env36830 : List Nat := [2,4,8,7,0,64,67,2,7,66,11,70,73,70,1,68,0,6,4,0,70,77,6,66,69,7,10,71,70,74,68,64,3,64,0,65]

theorem envBound36830 : H12AffineFastState.Bounded env36830 := by
  intro p hp
  have h : env36830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36829_36830 : H12AffineEnvironment.transform 6 67 env36829 = env36830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 67 env36829 == env36830) = true)

theorem identity36830 : scanCanonicalize (H12AffineFastState.compose env36830 (packedSelected [1,2,5] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound36830 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env36831 : List Nat := [2,3,8,0,0,64,67,2,0,66,11,65,73,65,1,67,0,1,3,0,65,74,1,66,66,0,10,64,65,74,67,64,3,64,0,65]

theorem envBound36831 : H12AffineFastState.Bounded env36831 := by
  intro p hp
  have h : env36831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36830_36831 : H12AffineEnvironment.transform 1 3 env36830 = env36831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env36830 == env36831) = true)

def env36832 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,853,73,80,276,65536,65895,65665,533,277,853,649,65911,65552,916,66163,318,65847,80,68375,68,64,257,65831,1,340]

theorem envBound36832 : H12AffineFastState.Bounded env36832 := by
  intro p hp
  have h : env36832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36822_36832 : H12AffineEnvironment.transform 9 321 env36822 = env36832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env36822 == env36832) = true)

theorem identity36832 : scanCanonicalize (H12AffineFastState.compose env36832 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound36832 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env36833 : List Nat := [2,4,8,16,32,64,128,256,64,321,2048,277,73,80,276,65536,65895,65665,85,277,277,201,65911,65552,468,65587,318,65847,80,67927,68,64,257,65831,1,340]

theorem envBound36833 : H12AffineFastState.Bounded env36833 := by
  intro p hp
  have h : env36833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36832_36833 : H12AffineEnvironment.transform 8 64 env36832 = env36833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env36832 == env36833) = true)

theorem identity36833 : scanCanonicalize (H12AffineFastState.compose env36833 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(15+1) ^^^ 358) := by decide +kernel

theorem selectedBound36833 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env36834 : List Nat := [2,4,8,16,32,64,128,256,64,321,2048,277,73,80,276,358,1,487,85,277,277,201,17,374,468,341,318,81,80,2097,68,64,257,65,1,340]

theorem envBound36834 : H12AffineFastState.Bounded env36834 := by
  intro p hp
  have h : env36834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36833_36834 : H12AffineEnvironment.transform 15 358 env36833 = env36834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 358 env36833 == env36834) = true)

theorem identity36834 : scanCanonicalize (H12AffineFastState.compose env36834 (packedSelected [8,13] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound36834 : packedSelected [8,13] rootPS < 2^1333 := by decide +kernel

def env36835 : List Nat := [2,4,8,16,23,64,128,256,64,321,2048,277,73,80,276,337,1,464,85,277,277,201,17,321,468,341,265,81,80,2054,68,64,257,65,1,340]

theorem envBound36835 : H12AffineFastState.Bounded env36835 := by
  intro p hp
  have h : env36835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36834_36835 : H12AffineEnvironment.transform 4 23 env36834 = env36835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env36834 == env36835) = true)

theorem identity36835 : scanCanonicalize (H12AffineFastState.compose env36835 (packedSelected [1,3,4,5,8,9,12,15,16] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound36835 : packedSelected [1,3,4,5,8,9,12,15,16] rootPS < 2^1333 := by decide +kernel

def env36836 : List Nat := [2,4,8,16,23,64,18,256,64,321,2048,277,73,80,276,337,1,322,85,277,277,91,17,321,326,341,265,81,80,2054,68,64,257,65,1,340]

theorem envBound36836 : H12AffineFastState.Bounded env36836 := by
  intro p hp
  have h : env36836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36835_36836 : H12AffineEnvironment.transform 6 18 env36835 = env36836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env36835 == env36836) = true)

theorem identity36836 : scanCanonicalize (H12AffineFastState.compose env36836 (packedSelected [0,1,7,8,10,11,15] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound36836 : packedSelected [0,1,7,8,10,11,15] rootPS < 2^1333 := by decide +kernel

def env36837 : List Nat := [2,4,8,10,13,64,8,256,64,321,2048,271,73,74,270,331,1,322,79,271,271,65,11,321,326,335,265,75,74,2054,68,64,257,65,1,334]

theorem envBound36837 : H12AffineFastState.Bounded env36837 := by
  intro p hp
  have h : env36837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36836_36837 : H12AffineEnvironment.transform 3 10 env36836 = env36837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env36836 == env36837) = true)

theorem identity36837 : scanCanonicalize (H12AffineFastState.compose env36837 (packedSelected [0,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound36837 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env36838 : List Nat := [2,4,8,10,13,64,8,14,64,79,2048,1,73,74,0,69,1,76,79,1,1,65,11,79,72,65,7,75,74,2054,68,64,15,65,1,64]

theorem envBound36838 : H12AffineFastState.Bounded env36838 := by
  intro p hp
  have h : env36838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36837_36838 : H12AffineEnvironment.transform 7 14 env36837 = env36838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env36837 == env36838) = true)

def env36839 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1557,73,1297,276,65536,66598,65665,1877,277,1557,648,65911,66897,917,66162,1151,66678,1297,68374,68,64,257,66662,1344,341]

theorem envBound36839 : H12AffineFastState.Bounded env36839 := by
  intro p hp
  have h : env36839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36821_36839 : H12AffineEnvironment.transform 11 1557 env36821 = env36839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env36821 == env36839) = true)

def env36840 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,853,73,81,276,65536,65894,65665,533,277,853,648,65911,65553,917,66162,319,65846,81,68374,68,64,257,65830,0,341]

theorem envBound36840 : H12AffineFastState.Bounded env36840 := by
  intro p hp
  have h : env36840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36839_36840 : H12AffineEnvironment.transform 9 320 env36839 = env36840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env36839 == env36840) = true)

theorem identity36840 : scanCanonicalize (H12AffineFastState.compose env36840 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound36840 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env36841 : List Nat := [2,4,8,16,32,64,128,21,512,85,2048,576,73,81,1,65536,65651,65665,533,0,576,648,65634,65553,640,66162,42,65571,81,68099,68,64,20,65587,0,64]

theorem envBound36841 : H12AffineFastState.Bounded env36841 := by
  intro p hp
  have h : env36841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36840_36841 : H12AffineEnvironment.transform 7 21 env36840 = env36841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env36840 == env36841) = true)

theorem identity36841 : scanCanonicalize (H12AffineFastState.compose env36841 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound36841 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env36842 : List Nat := [2,4,8,16,32,64,128,21,17,85,2048,81,73,81,1,65536,65651,65665,4,0,81,153,65634,65553,145,65635,42,65571,81,67602,68,64,20,65587,0,64]

theorem envBound36842 : H12AffineFastState.Bounded env36842 := by
  intro p hp
  have h : env36842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36841_36842 : H12AffineEnvironment.transform 8 17 env36841 = env36842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env36841 == env36842) = true)

theorem identity36842 : scanCanonicalize (H12AffineFastState.compose env36842 (packedSelected [0,2,4,7,9,11,13,16] rootPS)) = affineNative (2^(15+1) ^^^ 82) := by decide +kernel

theorem selectedBound36842 : packedSelected [0,2,4,7,9,11,13,16] rootPS < 2^1333 := by decide +kernel

def env36843 : List Nat := [2,4,8,16,32,64,128,21,17,85,2048,81,73,81,1,82,33,211,4,0,81,153,48,67,145,49,42,113,81,2112,68,64,20,97,0,64]

theorem envBound36843 : H12AffineFastState.Bounded env36843 := by
  intro p hp
  have h : env36843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36842_36843 : H12AffineEnvironment.transform 15 82 env36842 = env36843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 82 env36842 == env36843) = true)

theorem identity36843 : scanCanonicalize (H12AffineFastState.compose env36843 (packedSelected [2,3,10,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 76) := by decide +kernel

theorem selectedBound36843 : packedSelected [2,3,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env36844 : List Nat := [2,4,8,16,32,64,128,21,17,85,76,81,73,81,1,82,33,211,4,0,81,153,48,67,145,49,42,113,81,12,68,64,20,97,0,64]

theorem envBound36844 : H12AffineFastState.Bounded env36844 := by
  intro p hp
  have h : env36844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36843_36844 : H12AffineEnvironment.transform 10 76 env36843 = env36844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 76 env36843 == env36844) = true)

theorem identity36844 : scanCanonicalize (H12AffineFastState.compose env36844 (packedSelected [0,3,7,8,10,11,12,17] rootPS)) = affineNative (2^(5+1) ^^^ 39) := by decide +kernel

theorem selectedBound36844 : packedSelected [0,3,7,8,10,11,12,17] rootPS < 2^1333 := by decide +kernel

def env36845 : List Nat := [2,4,8,16,32,39,128,21,17,50,43,54,46,54,1,53,33,180,4,0,54,153,48,36,145,49,42,22,54,12,35,39,20,6,0,39]

theorem envBound36845 : H12AffineFastState.Bounded env36845 := by
  intro p hp
  have h : env36845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36844_36845 : H12AffineEnvironment.transform 5 39 env36844 = env36845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 39 env36844 == env36845) = true)

theorem identity36845 : scanCanonicalize (H12AffineFastState.compose env36845 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound36845 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env36846 : List Nat := [2,4,8,16,1,6,128,21,17,19,10,23,15,23,1,20,0,149,4,0,23,153,17,5,145,16,11,22,23,12,2,6,20,6,0,6]

theorem envBound36846 : H12AffineFastState.Bounded env36846 := by
  intro p hp
  have h : env36846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36845_36846 : H12AffineEnvironment.transform 4 1 env36845 = env36846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env36845 == env36846) = true)

theorem identity36846 : scanCanonicalize (H12AffineFastState.compose env36846 (packedSelected [2,3] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound36846 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env36847 : List Nat := [2,4,8,16,1,6,18,21,17,19,10,23,15,23,1,20,0,7,4,0,23,11,17,5,3,16,11,22,23,12,2,6,20,6,0,6]

theorem envBound36847 : H12AffineFastState.Bounded env36847 := by
  intro p hp
  have h : env36847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36846_36847 : H12AffineEnvironment.transform 6 18 env36846 = env36847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env36846 == env36847) = true)

theorem identity36847 : scanCanonicalize (H12AffineFastState.compose env36847 (packedSelected [1,2,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound36847 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env36848 : List Nat := [2,4,8,1,1,6,3,4,0,2,10,6,15,6,1,5,0,7,4,0,6,11,0,5,3,1,11,7,6,12,2,6,5,6,0,6]

theorem envBound36848 : H12AffineFastState.Bounded env36848 := by
  intro p hp
  have h : env36848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36847_36848 : H12AffineEnvironment.transform 3 1 env36847 = env36848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env36847 == env36848) = true)

def env36849 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,852,73,80,276,65536,65895,65665,532,277,852,648,65911,65552,917,66162,318,65847,80,68374,68,64,257,65831,1,341]

theorem envBound36849 : H12AffineFastState.Bounded env36849 := by
  intro p hp
  have h : env36849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36839_36849 : H12AffineEnvironment.transform 9 321 env36839 = env36849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env36839 == env36849) = true)

theorem identity36849 : scanCanonicalize (H12AffineFastState.compose env36849 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 65) := by decide +kernel

theorem selectedBound36849 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env36850 : List Nat := [2,4,8,16,32,64,128,256,65,321,2048,277,73,80,276,65536,65895,65665,85,277,277,201,65911,65552,468,65587,318,65847,80,67927,68,64,257,65831,1,341]

theorem envBound36850 : H12AffineFastState.Bounded env36850 := by
  intro p hp
  have h : env36850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36849_36850 : H12AffineEnvironment.transform 8 65 env36849 = env36850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env36849 == env36850) = true)

theorem identity36850 : scanCanonicalize (H12AffineFastState.compose env36850 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(15+1) ^^^ 358) := by decide +kernel

theorem selectedBound36850 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env36851 : List Nat := [2,4,8,16,32,64,128,256,65,321,2048,277,73,80,276,358,1,487,85,277,277,201,17,374,468,341,318,81,80,2097,68,64,257,65,1,341]

theorem envBound36851 : H12AffineFastState.Bounded env36851 := by
  intro p hp
  have h : env36851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36850_36851 : H12AffineEnvironment.transform 15 358 env36850 = env36851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 358 env36850 == env36851) = true)

theorem identity36851 : scanCanonicalize (H12AffineFastState.compose env36851 (packedSelected [8,13] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound36851 : packedSelected [8,13] rootPS < 2^1333 := by decide +kernel

def env36852 : List Nat := [2,4,8,16,23,64,128,256,65,321,2048,277,73,80,276,337,1,464,85,277,277,201,17,321,468,341,265,81,80,2054,68,64,257,65,1,341]

theorem envBound36852 : H12AffineFastState.Bounded env36852 := by
  intro p hp
  have h : env36852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36851_36852 : H12AffineEnvironment.transform 4 23 env36851 = env36852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env36851 == env36852) = true)

theorem identity36852 : scanCanonicalize (H12AffineFastState.compose env36852 (packedSelected [1,3,4,5,8,9,12,15,16] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound36852 : packedSelected [1,3,4,5,8,9,12,15,16] rootPS < 2^1333 := by decide +kernel

def env36853 : List Nat := [2,4,8,16,23,64,18,256,65,321,2048,277,73,80,276,337,1,322,85,277,277,91,17,321,326,341,265,81,80,2054,68,64,257,65,1,341]

theorem envBound36853 : H12AffineFastState.Bounded env36853 := by
  intro p hp
  have h : env36853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36852_36853 : H12AffineEnvironment.transform 6 18 env36852 = env36853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env36852 == env36853) = true)

theorem identity36853 : scanCanonicalize (H12AffineFastState.compose env36853 (packedSelected [0,1,7,8,10,11,15] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound36853 : packedSelected [0,1,7,8,10,11,15] rootPS < 2^1333 := by decide +kernel

def env36854 : List Nat := [2,4,8,10,13,64,8,256,65,321,2048,271,73,74,270,331,1,322,79,271,271,65,11,321,326,335,265,75,74,2054,68,64,257,65,1,335]

theorem envBound36854 : H12AffineFastState.Bounded env36854 := by
  intro p hp
  have h : env36854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36853_36854 : H12AffineEnvironment.transform 3 10 env36853 = env36854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env36853 == env36854) = true)

theorem identity36854 : scanCanonicalize (H12AffineFastState.compose env36854 (packedSelected [3,5,10] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound36854 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env36855 : List Nat := [2,4,2,0,7,64,2,256,65,321,2048,261,67,64,260,321,1,322,69,261,261,65,1,321,326,325,259,65,64,2054,68,64,257,65,1,325]

theorem envBound36855 : H12AffineFastState.Bounded env36855 := by
  intro p hp
  have h : env36855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36854_36855 : H12AffineEnvironment.transform 2 2 env36854 = env36855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env36854 == env36855) = true)

theorem identity36855 : scanCanonicalize (H12AffineFastState.compose env36855 (packedSelected [1,2,8] rootPS)) = affineNative (2^(7+1) ^^^ 66) := by decide +kernel

theorem selectedBound36855 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env36856 : List Nat := [2,4,2,0,7,64,2,66,65,3,2048,71,67,64,70,3,1,0,69,71,71,65,1,3,4,7,65,65,64,2054,68,64,67,65,1,7]

theorem envBound36856 : H12AffineFastState.Bounded env36856 := by
  intro p hp
  have h : env36856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart2