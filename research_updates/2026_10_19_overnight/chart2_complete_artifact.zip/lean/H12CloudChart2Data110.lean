import H12CloudChart2Data109

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env27030 : List Nat := [2,4,8,16,32,64,128,110,59,85,227,0,50,43,122,145,152,16,46,123,0,178,243,128,192,216,81,200,42,48,63,59,111,216,122,64]

theorem envBound27030 : H12AffineFastState.Bounded env27030 := by
  intro p hp
  have h : env27030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27029_27030 : H12AffineEnvironment.transform 7 110 env27029 = env27030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 110 env27029 == env27030) = true)

theorem identity27030 : scanCanonicalize (H12AffineFastState.compose env27030 (packedSelected [1,2,3,4,5,8,9,10] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound27030 : packedSelected [1,2,3,4,5,8,9,10] rootPS < 2^1333 := by decide +kernel

def env27031 : List Nat := [2,4,3,16,32,64,128,101,48,85,227,0,50,32,113,145,147,16,37,112,0,178,243,128,192,211,81,195,33,48,52,48,100,211,113,64]

theorem envBound27031 : H12AffineFastState.Bounded env27031 := by
  intro p hp
  have h : env27031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27030_27031 : H12AffineEnvironment.transform 2 3 env27030 = env27031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env27030 == env27031) = true)

theorem identity27031 : scanCanonicalize (H12AffineFastState.compose env27031 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound27031 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env27032 : List Nat := [2,4,3,16,32,16,128,53,48,5,179,0,50,32,33,145,147,16,37,32,0,178,163,128,144,131,1,147,33,48,52,48,52,131,33,16]

theorem envBound27032 : H12AffineFastState.Bounded env27032 := by
  intro p hp
  have h : env27032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27031_27032 : H12AffineEnvironment.transform 5 16 env27031 = env27032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env27031 == env27032) = true)

theorem identity27032 : scanCanonicalize (H12AffineFastState.compose env27032 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound27032 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env27033 : List Nat := [2,4,3,16,32,16,5,53,48,5,54,0,50,32,33,20,22,16,37,32,0,55,38,5,21,6,1,22,33,48,52,48,52,6,33,16]

theorem envBound27033 : H12AffineFastState.Bounded env27033 := by
  intro p hp
  have h : env27033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27032_27033 : H12AffineEnvironment.transform 6 5 env27032 = env27033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env27032 == env27033) = true)

theorem identity27033 : scanCanonicalize (H12AffineFastState.compose env27033 (packedSelected [1,3,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound27033 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env27034 : List Nat := [2,4,3,1,32,1,5,36,33,5,39,0,35,32,33,5,7,1,37,32,0,38,38,5,4,6,1,7,33,33,37,33,37,6,33,1]

theorem envBound27034 : H12AffineFastState.Bounded env27034 := by
  intro p hp
  have h : env27034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27033_27034 : H12AffineEnvironment.transform 3 1 env27033 = env27034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env27033 == env27034) = true)

theorem identity27034 : scanCanonicalize (H12AffineFastState.compose env27034 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound27034 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27035 : List Nat := [2,4,3,1,7,1,5,3,6,5,0,0,4,7,6,5,7,1,2,7,0,1,1,5,4,6,1,7,6,6,2,6,2,6,6,1]

theorem envBound27035 : H12AffineFastState.Bounded env27035 := by
  intro p hp
  have h : env27035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27034_27035 : H12AffineEnvironment.transform 4 7 env27034 = env27035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env27034 == env27035) = true)

theorem identity27035 : scanCanonicalize (H12AffineFastState.compose env27035 (packedSelected [0,7] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound27035 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env27036 : List Nat := [2,3,3,1,0,1,2,3,1,2,0,0,3,0,1,2,0,1,2,0,0,1,1,2,3,1,1,0,1,1,2,1,2,1,1,1]

theorem envBound27036 : H12AffineFastState.Bounded env27036 := by
  intro p hp
  have h : env27036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27035_27036 : H12AffineEnvironment.transform 1 3 env27035 = env27036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env27035 == env27036) = true)

def env27037 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,1,1288,1296,276,65536,65894,65665,321,277,1,476,66614,65552,192,65831,318,65846,1297,67650,1285,1281,257,65830,1345,1044]

theorem envBound27037 : H12AffineFastState.Bounded env27037 := by
  intro p hp
  have h : env27037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27025_27037 : H12AffineEnvironment.transform 11 1 env27025 = env27037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env27025 == env27037) = true)

theorem identity27037 : scanCanonicalize (H12AffineFastState.compose env27037 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound27037 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env27038 : List Nat := [2,4,8,16,32,64,128,20,65,1024,2048,1,1052,1028,0,65536,65650,65665,85,1,1,200,66614,65552,192,65587,42,65570,1029,67650,1041,1045,21,65586,1109,1044]

theorem envBound27038 : H12AffineFastState.Bounded env27038 := by
  intro p hp
  have h : env27038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27037_27038 : H12AffineEnvironment.transform 7 20 env27037 = env27038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env27037 == env27038) = true)

theorem identity27038 : scanCanonicalize (H12AffineFastState.compose env27038 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 1142) := by decide +kernel

theorem selectedBound27038 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env27039 : List Nat := [2,4,8,16,32,64,128,20,65,1024,2048,1,1052,1028,0,1142,1028,1271,85,1,1,200,64,1126,192,1093,42,1108,1029,3124,1041,1045,21,1092,1109,1044]

theorem envBound27039 : H12AffineFastState.Bounded env27039 := by
  intro p hp
  have h : env27039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27038_27039 : H12AffineEnvironment.transform 15 1142 env27038 = env27039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1142 env27038 == env27039) = true)

theorem identity27039 : scanCanonicalize (H12AffineFastState.compose env27039 (packedSelected [0,2,3,5,7,8,10,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 1080) := by decide +kernel

theorem selectedBound27039 : packedSelected [0,2,3,5,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env27040 : List Nat := [2,4,8,16,32,64,128,20,65,1024,1080,1,1052,1028,0,1142,1028,1271,85,1,1,200,64,1126,192,1093,42,1108,1029,12,1041,1045,21,1092,1109,1044]

theorem envBound27040 : H12AffineFastState.Bounded env27040 := by
  intro p hp
  have h : env27040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27039_27040 : H12AffineEnvironment.transform 10 1080 env27039 = env27040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1080 env27039 == env27040) = true)

theorem identity27040 : scanCanonicalize (H12AffineFastState.compose env27040 (packedSelected [1,2,3,5,15] rootPS)) = affineNative (2^(9+1) ^^^ 183) := by decide +kernel

theorem selectedBound27040 : packedSelected [1,2,3,5,15] rootPS < 2^1333 := by decide +kernel

def env27041 : List Nat := [2,4,8,16,32,64,128,20,65,183,143,1,171,179,0,193,179,64,85,1,1,200,64,209,192,242,42,227,178,12,166,162,21,243,226,163]

theorem envBound27041 : H12AffineFastState.Bounded env27041 := by
  intro p hp
  have h : env27041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27040_27041 : H12AffineEnvironment.transform 9 183 env27040 = env27041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 183 env27040 == env27041) = true)

theorem identity27041 : scanCanonicalize (H12AffineFastState.compose env27041 (packedSelected [4,9,16] rootPS)) = affineNative (2^(6+1) ^^^ 98) := by decide +kernel

theorem selectedBound27041 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env27042 : List Nat := [2,4,8,16,32,64,98,20,65,85,109,1,73,81,0,35,81,64,85,1,1,42,64,51,34,16,42,1,80,12,68,64,21,17,0,65]

theorem envBound27042 : H12AffineFastState.Bounded env27042 := by
  intro p hp
  have h : env27042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27041_27042 : H12AffineEnvironment.transform 6 98 env27041 = env27042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 98 env27041 == env27042) = true)

theorem identity27042 : scanCanonicalize (H12AffineFastState.compose env27042 (packedSelected [1,3,5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound27042 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env27043 : List Nat := [2,4,2,16,32,64,98,20,65,85,103,1,67,81,0,35,81,64,85,1,1,32,64,51,34,16,32,1,80,6,68,64,21,17,0,65]

theorem envBound27043 : H12AffineFastState.Bounded env27043 := by
  intro p hp
  have h : env27043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27042_27043 : H12AffineEnvironment.transform 2 2 env27042 = env27043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env27042 == env27043) = true)

theorem identity27043 : scanCanonicalize (H12AffineFastState.compose env27043 (packedSelected [3,8] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound27043 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env27044 : List Nat := [2,4,2,16,23,64,85,20,65,85,80,1,67,81,0,20,81,64,85,1,1,23,64,4,21,16,23,1,80,6,68,64,21,17,0,65]

theorem envBound27044 : H12AffineFastState.Bounded env27044 := by
  intro p hp
  have h : env27044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27043_27044 : H12AffineEnvironment.transform 4 23 env27043 = env27044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env27043 == env27044) = true)

theorem identity27044 : scanCanonicalize (H12AffineFastState.compose env27044 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 6) := by decide +kernel

theorem selectedBound27044 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env27045 : List Nat := [2,4,2,16,23,6,19,20,7,19,22,1,5,23,0,20,23,6,19,1,1,23,6,4,21,16,23,1,22,6,2,6,21,17,0,7]

theorem envBound27045 : H12AffineFastState.Bounded env27045 := by
  intro p hp
  have h : env27045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27044_27045 : H12AffineEnvironment.transform 5 6 env27044 = env27045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 6 env27044 == env27045) = true)

theorem identity27045 : scanCanonicalize (H12AffineFastState.compose env27045 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound27045 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27046 : List Nat := [2,4,2,0,7,6,3,4,7,3,6,1,5,7,0,4,7,6,3,1,1,7,6,4,5,0,7,1,6,6,2,6,5,1,0,7]

theorem envBound27046 : H12AffineFastState.Bounded env27046 := by
  intro p hp
  have h : env27046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27045_27046 : H12AffineEnvironment.transform 3 0 env27045 = env27046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env27045 == env27046) = true)

theorem identity27046 : scanCanonicalize (H12AffineFastState.compose env27046 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound27046 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env27047 : List Nat := [2,2,2,0,1,0,3,2,1,3,0,1,3,1,0,2,1,0,3,1,1,1,0,2,3,0,1,1,0,0,2,0,3,1,0,1]

theorem envBound27047 : H12AffineFastState.Bounded env27047 := by
  intro p hp
  have h : env27047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27046_27047 : H12AffineEnvironment.transform 1 2 env27046 = env27047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env27046 == env27047) = true)

def env27048 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74862,262144,4417,13340,4096,477,74047,69648,13768,78894,332223,74815,1297,81226,8204,8200,257,74798,1345,5953]

theorem envBound27048 : H12AffineFastState.Bounded env27048 := by
  intro p hp
  have h : env27048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26951_27048 : H12AffineEnvironment.transform 13 1297 env26951 = env27048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env26951 == env27048) = true)

def env27049 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74862,65664,4417,13340,4096,477,74047,69648,13768,78894,4415,74815,1297,81226,8204,8200,257,74798,1345,5953]

theorem envBound27049 : H12AffineFastState.Bounded env27049 := by
  intro p hp
  have h : env27049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27048_27049 : H12AffineEnvironment.transform 17 65664 env27048 = env27049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env27048 == env27049) = true)

theorem identity27049 : scanCanonicalize (H12AffineFastState.compose env27049 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound27049 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env27050 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1297,9245,65536,74862,65664,321,9244,0,477,74047,65552,9672,74798,319,74815,1297,77130,8204,8200,257,74798,1345,1857]

theorem envBound27050 : H12AffineFastState.Bounded env27050 := by
  intro p hp
  have h : env27050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27049_27050 : H12AffineEnvironment.transform 11 0 env27049 = env27050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env27049 == env27050) = true)

def env27051 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,0,8192,1297,9245,65536,74862,65664,321,9244,0,477,74047,65552,9672,74798,319,74815,1297,77130,8204,8200,257,74798,1345,1045]

theorem envBound27051 : H12AffineFastState.Bounded env27051 := by
  intro p hp
  have h : env27051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27050_27051 : H12AffineEnvironment.transform 8 340 env27050 = env27051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env27050 == env27051) = true)

def env27052 : List Nat := [2,4,8,0,32,64,128,256,324,1024,2048,0,8192,1281,9229,65536,74862,65664,321,9228,0,461,74031,65536,9672,74798,303,74799,1281,77130,8204,8200,257,74798,1345,1029]

theorem envBound27052 : H12AffineFastState.Bounded env27052 := by
  intro p hp
  have h : env27052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27051_27052 : H12AffineEnvironment.transform 3 0 env27051 = env27052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env27051 == env27052) = true)

theorem identity27052 : scanCanonicalize (H12AffineFastState.compose env27052 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8619) := by decide +kernel

theorem selectedBound27052 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env27053 : List Nat := [2,4,8,0,32,64,128,256,324,1024,2048,0,8192,1281,9229,8619,1477,8491,321,9228,0,461,132,8619,9672,1413,303,1412,1281,3297,8204,8200,257,1413,1345,1029]

theorem envBound27053 : H12AffineFastState.Bounded env27053 := by
  intro p hp
  have h : env27053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27052_27053 : H12AffineEnvironment.transform 15 8619 env27052 = env27053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8619 env27052 == env27053) = true)

def env27054 : List Nat := [2,4,8,0,32,64,128,256,324,1024,2048,0,1420,1281,385,1063,1477,1191,321,384,0,461,132,1063,68,1413,303,1412,1281,3297,1408,1412,257,1413,1345,1029]

theorem envBound27054 : H12AffineFastState.Bounded env27054 := by
  intro p hp
  have h : env27054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27053_27054 : H12AffineEnvironment.transform 12 1420 env27053 = env27054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1420 env27053 == env27054) = true)

theorem identity27054 : scanCanonicalize (H12AffineFastState.compose env27054 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 128) := by decide +kernel

theorem selectedBound27054 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env27055 : List Nat := [2,4,8,0,32,64,128,256,324,128,2048,0,268,385,385,167,325,39,321,384,0,461,132,167,68,261,303,260,385,2145,256,260,257,261,449,133]

theorem envBound27055 : H12AffineFastState.Bounded env27055 := by
  intro p hp
  have h : env27055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27054_27055 : H12AffineEnvironment.transform 9 128 env27054 = env27055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 128 env27054 == env27055) = true)

theorem identity27055 : scanCanonicalize (H12AffineFastState.compose env27055 (packedSelected [1,8,11,12,17,18] rootPS)) = affineNative (2^(7+1) ^^^ 46) := by decide +kernel

theorem selectedBound27055 : packedSelected [1,8,11,12,17,18] rootPS < 2^1333 := by decide +kernel

def env27056 : List Nat := [2,4,8,0,32,64,128,46,106,128,2048,0,34,175,175,167,107,39,111,174,0,227,132,167,68,43,1,42,175,2145,46,42,47,43,239,133]

theorem envBound27056 : H12AffineFastState.Bounded env27056 := by
  intro p hp
  have h : env27056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27055_27056 : H12AffineEnvironment.transform 7 46 env27055 = env27056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 46 env27055 == env27056) = true)

theorem identity27056 : scanCanonicalize (H12AffineFastState.compose env27056 (packedSelected [2,5,10,13,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 196) := by decide +kernel

theorem selectedBound27056 : packedSelected [2,5,10,13,15,17] rootPS < 2^1333 := by decide +kernel

def env27057 : List Nat := [2,4,8,0,32,64,128,46,106,128,196,0,34,175,175,167,107,39,111,174,0,227,132,167,68,43,1,42,175,165,46,42,47,43,239,133]

theorem envBound27057 : H12AffineFastState.Bounded env27057 := by
  intro p hp
  have h : env27057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27056_27057 : H12AffineEnvironment.transform 10 196 env27056 = env27057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 196 env27056 == env27057) = true)

theorem identity27057 : scanCanonicalize (H12AffineFastState.compose env27057 (packedSelected [0,2,3,5,7,8,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 101) := by decide +kernel

theorem selectedBound27057 : packedSelected [0,2,3,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env27058 : List Nat := [2,4,8,0,32,64,101,46,106,101,33,0,34,74,74,66,107,39,111,75,0,6,97,66,68,43,1,42,74,64,46,42,47,43,10,96]

theorem envBound27058 : H12AffineFastState.Bounded env27058 := by
  intro p hp
  have h : env27058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27057_27058 : H12AffineEnvironment.transform 6 101 env27057 = env27058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 101 env27057 == env27058) = true)

theorem identity27058 : scanCanonicalize (H12AffineFastState.compose env27058 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound27058 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env27059 : List Nat := [2,4,8,0,7,64,66,9,77,66,6,0,5,74,74,66,76,0,72,75,0,6,70,66,68,12,1,13,74,64,9,13,8,12,10,71]

theorem envBound27059 : H12AffineFastState.Bounded env27059 := by
  intro p hp
  have h : env27059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27058_27059 : H12AffineEnvironment.transform 4 7 env27058 = env27059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env27058 == env27059) = true)

theorem identity27059 : scanCanonicalize (H12AffineFastState.compose env27059 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound27059 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env27060 : List Nat := [2,4,3,0,7,64,66,2,70,66,6,0,5,65,65,66,71,0,67,64,0,6,70,66,68,7,1,6,65,64,2,6,3,7,1,71]

theorem envBound27060 : H12AffineFastState.Bounded env27060 := by
  intro p hp
  have h : env27060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27059_27060 : H12AffineEnvironment.transform 2 3 env27059 = env27060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env27059 == env27060) = true)

def env27061 : List Nat := [2,4,8,0,32,64,128,256,324,1024,2048,0,1421,1281,384,1062,1477,1190,321,385,0,461,132,1062,69,1413,303,1412,1281,3297,1409,1413,257,1413,1345,1029]

theorem envBound27061 : H12AffineFastState.Bounded env27061 := by
  intro p hp
  have h : env27061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27053_27061 : H12AffineEnvironment.transform 12 1421 env27053 = env27061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1421 env27053 == env27061) = true)

theorem identity27061 : scanCanonicalize (H12AffineFastState.compose env27061 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 388) := by decide +kernel

theorem selectedBound27061 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env27062 : List Nat := [2,4,8,0,32,64,128,256,324,388,2048,0,9,133,384,418,65,290,321,385,0,461,132,418,69,1,303,0,133,2405,5,1,257,1,197,385]

theorem envBound27062 : H12AffineFastState.Bounded env27062 := by
  intro p hp
  have h : env27062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27061_27062 : H12AffineEnvironment.transform 9 388 env27061 = env27062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 388 env27061 == env27062) = true)

theorem identity27062 : scanCanonicalize (H12AffineFastState.compose env27062 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 193) := by decide +kernel

theorem selectedBound27062 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env27063 : List Nat := [2,4,8,0,32,64,128,193,133,69,2048,0,9,133,65,99,65,227,128,64,0,12,132,99,69,1,238,0,133,2212,5,1,192,1,197,64]

theorem envBound27063 : H12AffineFastState.Bounded env27063 := by
  intro p hp
  have h : env27063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27062_27063 : H12AffineEnvironment.transform 7 193 env27062 = env27063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 193 env27062 == env27063) = true)

theorem identity27063 : scanCanonicalize (H12AffineFastState.compose env27063 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound27063 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env27064 : List Nat := [2,4,8,0,32,64,8,73,13,69,2048,0,9,13,65,99,65,107,8,64,0,12,12,99,69,1,102,0,13,2092,5,1,72,1,77,64]

theorem envBound27064 : H12AffineFastState.Bounded env27064 := by
  intro p hp
  have h : env27064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27063_27064 : H12AffineEnvironment.transform 6 8 env27063 = env27064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env27063 == env27064) = true)

theorem identity27064 : scanCanonicalize (H12AffineFastState.compose env27064 (packedSelected [0,2,3,5,7,8,10,11,13] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound27064 : packedSelected [0,2,3,5,7,8,10,11,13] rootPS < 2^1333 := by decide +kernel

def env27065 : List Nat := [2,3,8,0,32,64,8,73,10,66,2048,0,9,10,65,99,65,107,8,64,0,11,11,99,66,1,97,0,10,2091,2,1,72,1,74,64]

theorem envBound27065 : H12AffineFastState.Bounded env27065 := by
  intro p hp
  have h : env27065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27064_27065 : H12AffineEnvironment.transform 1 3 env27064 = env27065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env27064 == env27065) = true)

theorem identity27065 : scanCanonicalize (H12AffineFastState.compose env27065 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound27065 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env27066 : List Nat := [2,3,8,0,32,64,8,73,10,66,0,0,9,10,65,99,65,107,8,64,0,11,11,99,66,1,97,0,10,43,2,1,72,1,74,64]

theorem envBound27066 : H12AffineFastState.Bounded env27066 := by
  intro p hp
  have h : env27066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27065_27066 : H12AffineEnvironment.transform 10 0 env27065 = env27066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env27065 == env27066) = true)

theorem identity27066 : scanCanonicalize (H12AffineFastState.compose env27066 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound27066 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27067 : List Nat := [2,3,3,0,32,64,3,66,1,66,0,0,2,1,65,99,65,96,3,64,0,0,0,99,66,1,97,0,1,32,2,1,67,1,65,64]

theorem envBound27067 : H12AffineFastState.Bounded env27067 := by
  intro p hp
  have h : env27067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27066_27067 : H12AffineEnvironment.transform 2 3 env27066 = env27067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env27066 == env27067) = true)

theorem identity27067 : scanCanonicalize (H12AffineFastState.compose env27067 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound27067 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27068 : List Nat := [2,3,3,0,32,1,3,3,1,3,0,0,2,1,0,34,0,33,3,1,0,0,0,34,3,1,32,0,1,32,2,1,2,1,0,1]

theorem envBound27068 : H12AffineFastState.Bounded env27068 := by
  intro p hp
  have h : env27068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27067_27068 : H12AffineEnvironment.transform 5 1 env27067 = env27068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env27067 == env27068) = true)

theorem identity27068 : scanCanonicalize (H12AffineFastState.compose env27068 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound27068 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27069 : List Nat := [2,3,3,0,0,1,3,3,1,3,0,0,2,1,0,2,0,1,3,1,0,0,0,2,3,1,0,0,1,0,2,1,2,1,0,1]

theorem envBound27069 : H12AffineFastState.Bounded env27069 := by
  intro p hp
  have h : env27069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27068_27069 : H12AffineEnvironment.transform 4 0 env27068 = env27069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env27068 == env27069) = true)

def env27070 : List Nat := [2,4,8,1,32,64,128,256,325,1024,2048,0,8192,1280,9228,65536,74862,65664,321,9229,0,460,74030,65537,9672,74798,302,74798,1280,77130,8204,8200,257,74798,1345,1028]

theorem envBound27070 : H12AffineFastState.Bounded env27070 := by
  intro p hp
  have h : env27070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27051_27070 : H12AffineEnvironment.transform 3 1 env27051 = env27070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env27051 == env27070) = true)

theorem identity27070 : scanCanonicalize (H12AffineFastState.compose env27070 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 1186) := by decide +kernel

theorem selectedBound27070 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env27071 : List Nat := [2,4,8,1,32,64,128,256,325,1024,2048,0,8192,1280,9228,1186,8396,1058,321,9229,0,460,9612,1187,9672,8332,302,8332,1280,10728,8204,8200,257,8332,1345,1028]

theorem envBound27071 : H12AffineFastState.Bounded env27071 := by
  intro p hp
  have h : env27071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27070_27071 : H12AffineEnvironment.transform 15 1186 env27070 = env27071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1186 env27070 == env27071) = true)

def env27072 : List Nat := [2,4,8,1,32,64,128,256,325,1024,2048,0,1288,1280,260,1186,1476,1058,321,261,0,460,132,1187,192,1412,302,1412,1280,3296,1284,1280,257,1412,1345,1028]

theorem envBound27072 : H12AffineFastState.Bounded env27072 := by
  intro p hp
  have h : env27072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27071_27072 : H12AffineEnvironment.transform 12 1288 env27071 = env27072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1288 env27071 == env27072) = true)

theorem identity27072 : scanCanonicalize (H12AffineFastState.compose env27072 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound27072 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env27073 : List Nat := [2,4,8,1,32,64,128,256,325,68,2048,0,332,324,260,230,384,102,321,261,0,460,132,231,192,448,302,448,324,2212,320,324,257,448,261,64]

theorem envBound27073 : H12AffineFastState.Bounded env27073 := by
  intro p hp
  have h : env27073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27072_27073 : H12AffineEnvironment.transform 9 68 env27072 = env27073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env27072 == env27073) = true)

theorem identity27073 : scanCanonicalize (H12AffineFastState.compose env27073 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 163) := by decide +kernel

theorem selectedBound27073 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env27074 : List Nat := [2,4,8,1,32,64,128,256,325,68,163,0,332,324,260,230,384,102,321,261,0,460,132,231,192,448,302,448,324,7,320,324,257,448,261,64]

theorem envBound27074 : H12AffineFastState.Bounded env27074 := by
  intro p hp
  have h : env27074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27073_27074 : H12AffineEnvironment.transform 10 163 env27073 = env27074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 163 env27073 == env27074) = true)

theorem identity27074 : scanCanonicalize (H12AffineFastState.compose env27074 (packedSelected [0,1,3,4,5,7,9,10,12,13,16,20] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound27074 : packedSelected [0,1,3,4,5,7,9,10,12,13,16,20] rootPS < 2^1333 := by decide +kernel

def env27075 : List Nat := [2,4,8,1,32,64,105,256,325,68,74,0,332,324,260,15,361,102,321,261,0,293,109,14,41,297,302,297,324,7,320,324,257,297,261,64]

theorem envBound27075 : H12AffineFastState.Bounded env27075 := by
  intro p hp
  have h : env27075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27074_27075 : H12AffineEnvironment.transform 6 105 env27074 = env27075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env27074 == env27075) = true)

theorem identity27075 : scanCanonicalize (H12AffineFastState.compose env27075 (packedSelected [1,3,8,10,11] rootPS)) = affineNative (2^(7+1) ^^^ 67) := by decide +kernel

theorem selectedBound27075 : packedSelected [1,3,8,10,11] rootPS < 2^1333 := by decide +kernel

def env27076 : List Nat := [2,4,8,1,32,64,105,67,6,68,74,0,15,7,71,15,42,102,2,70,0,102,109,14,41,106,109,106,7,7,3,7,66,106,70,64]

theorem envBound27076 : H12AffineFastState.Bounded env27076 := by
  intro p hp
  have h : env27076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27075_27076 : H12AffineEnvironment.transform 7 67 env27075 = env27076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 67 env27075 == env27076) = true)

theorem identity27076 : scanCanonicalize (H12AffineFastState.compose env27076 (packedSelected [0,1,2,4,5,8] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound27076 : packedSelected [0,1,2,4,5,8] rootPS < 2^1333 := by decide +kernel

def env27077 : List Nat := [2,4,8,1,11,64,66,67,6,68,74,0,15,7,71,15,1,77,2,70,0,77,70,14,2,65,70,65,7,7,3,7,66,65,70,64]

theorem envBound27077 : H12AffineFastState.Bounded env27077 := by
  intro p hp
  have h : env27077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27076_27077 : H12AffineEnvironment.transform 4 11 env27076 = env27077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env27076 == env27077) = true)

theorem identity27077 : scanCanonicalize (H12AffineFastState.compose env27077 (packedSelected [0,1,7] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound27077 : packedSelected [0,1,7] rootPS < 2^1333 := by decide +kernel

def env27078 : List Nat := [2,4,2,1,1,64,66,67,6,68,64,0,5,7,71,5,1,71,2,70,0,71,70,4,2,65,70,65,7,7,3,7,66,65,70,64]

theorem envBound27078 : H12AffineFastState.Bounded env27078 := by
  intro p hp
  have h : env27078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27077_27078 : H12AffineEnvironment.transform 2 2 env27077 = env27078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env27077 == env27078) = true)

theorem identity27078 : scanCanonicalize (H12AffineFastState.compose env27078 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 7) := by decide +kernel

theorem selectedBound27078 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env27079 : List Nat := [2,4,2,1,1,7,5,4,6,3,7,0,5,7,0,5,1,0,2,1,0,0,1,4,2,6,1,6,7,7,3,7,5,6,1,7]

theorem envBound27079 : H12AffineFastState.Bounded env27079 := by
  intro p hp
  have h : env27079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27078_27079 : H12AffineEnvironment.transform 5 7 env27078 = env27079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 7 env27078 == env27079) = true)

theorem identity27079 : scanCanonicalize (H12AffineFastState.compose env27079 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound27079 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27080 : List Nat := [2,1,2,1,1,2,0,1,3,3,2,0,0,2,0,0,1,0,2,1,0,0,1,1,2,3,1,3,2,2,3,2,0,3,1,2]

theorem envBound27080 : H12AffineFastState.Bounded env27080 := by
  intro p hp
  have h : env27080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27079_27080 : H12AffineEnvironment.transform 1 1 env27079 = env27080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env27079 == env27080) = true)

theorem identity27080 : scanCanonicalize (H12AffineFastState.compose env27080 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound27080 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27081 : List Nat := [0,1,0,1,1,0,0,1,1,1,0,0,0,0,0,0,1,0,0,1,0,0,1,1,0,1,1,1,0,0,1,0,0,1,1,0]

theorem envBound27081 : H12AffineFastState.Bounded env27081 := by
  intro p hp
  have h : env27081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27080_27081 : H12AffineEnvironment.transform 0 0 env27080 = env27081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env27080 == env27081) = true)

def env27082 : List Nat := [2,4,8,1,32,64,128,256,325,1024,2048,0,1289,1280,261,1186,1477,1058,321,260,0,460,133,1187,193,1413,302,1413,1280,3297,1285,1281,257,1413,1345,1028]

theorem envBound27082 : H12AffineFastState.Bounded env27082 := by
  intro p hp
  have h : env27082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27071_27082 : H12AffineEnvironment.transform 12 1289 env27071 = env27082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1289 env27071 == env27082) = true)

theorem identity27082 : scanCanonicalize (H12AffineFastState.compose env27082 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound27082 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env27083 : List Nat := [2,4,8,1,32,64,128,5,64,1024,2048,0,1036,1029,0,1186,1216,1058,68,1,0,201,133,1187,193,1152,43,1152,1029,3297,1024,1028,4,1152,1092,1028]

theorem envBound27083 : H12AffineFastState.Bounded env27083 := by
  intro p hp
  have h : env27083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27082_27083 : H12AffineEnvironment.transform 7 5 env27082 = env27083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env27082 == env27083) = true)

theorem identity27083 : scanCanonicalize (H12AffineFastState.compose env27083 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 128) := by decide +kernel

theorem selectedBound27083 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env27084 : List Nat := [2,4,8,1,32,64,128,5,64,128,2048,0,140,133,0,34,64,162,68,1,0,201,133,35,193,0,43,0,133,2145,128,132,4,0,196,132]

theorem envBound27084 : H12AffineFastState.Bounded env27084 := by
  intro p hp
  have h : env27084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27083_27084 : H12AffineEnvironment.transform 9 128 env27083 = env27084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 128 env27083 == env27084) = true)

theorem identity27084 : scanCanonicalize (H12AffineFastState.compose env27084 (packedSelected [0,1,2,3,7,8,11,12,13,15] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound27084 : packedSelected [0,1,2,3,7,8,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env27085 : List Nat := [2,2,8,1,32,64,128,3,64,128,2048,0,138,131,0,34,64,162,66,1,0,201,131,35,193,0,43,0,131,2145,128,130,2,0,194,130]

theorem envBound27085 : H12AffineFastState.Bounded env27085 := by
  intro p hp
  have h : env27085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27084_27085 : H12AffineEnvironment.transform 1 2 env27084 = env27085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env27084 == env27085) = true)

theorem identity27085 : scanCanonicalize (H12AffineFastState.compose env27085 (packedSelected [0,5,7,11] rootPS)) = affineNative (2^(6+1) ^^^ 99) := by decide +kernel

theorem selectedBound27085 : packedSelected [0,5,7,11] rootPS < 2^1333 := by decide +kernel

def env27086 : List Nat := [2,2,8,1,32,64,99,3,64,99,2048,0,105,96,0,34,64,65,66,1,0,42,96,35,34,0,43,0,96,2145,99,97,2,0,33,97]

theorem envBound27086 : H12AffineFastState.Bounded env27086 := by
  intro p hp
  have h : env27086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27085_27086 : H12AffineEnvironment.transform 6 99 env27085 = env27086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 99 env27085 == env27086) = true)

theorem identity27086 : scanCanonicalize (H12AffineFastState.compose env27086 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound27086 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env27087 : List Nat := [2,2,8,1,0,64,67,3,64,67,2048,0,73,64,0,2,64,65,66,1,0,10,64,3,2,0,11,0,64,2113,67,65,2,0,1,65]

theorem envBound27087 : H12AffineFastState.Bounded env27087 := by
  intro p hp
  have h : env27087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27086_27087 : H12AffineEnvironment.transform 4 0 env27086 = env27087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env27086 == env27087) = true)

theorem identity27087 : scanCanonicalize (H12AffineFastState.compose env27087 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 8) := by decide +kernel

theorem selectedBound27087 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env27088 : List Nat := [2,2,8,1,0,8,11,3,8,11,2048,0,1,8,0,2,8,9,10,1,0,10,8,3,2,0,11,0,8,2057,11,9,2,0,1,9]

theorem envBound27088 : H12AffineFastState.Bounded env27088 := by
  intro p hp
  have h : env27088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27087_27088 : H12AffineEnvironment.transform 5 8 env27087 = env27088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 8 env27087 == env27088) = true)

theorem identity27088 : scanCanonicalize (H12AffineFastState.compose env27088 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound27088 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env27089 : List Nat := [2,2,3,1,0,3,0,3,3,0,2048,0,1,3,0,2,3,2,1,1,0,1,3,3,2,0,0,0,3,2050,0,2,2,0,1,2]

theorem envBound27089 : H12AffineFastState.Bounded env27089 := by
  intro p hp
  have h : env27089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27088_27089 : H12AffineEnvironment.transform 2 3 env27088 = env27089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env27088 == env27089) = true)

theorem identity27089 : scanCanonicalize (H12AffineFastState.compose env27089 (packedSelected [0,5] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound27089 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env27090 : List Nat := [2,2,3,1,0,3,0,3,3,0,1,0,1,3,0,2,3,2,1,1,0,1,3,3,2,0,0,0,3,3,0,2,2,0,1,2]

theorem envBound27090 : H12AffineFastState.Bounded env27090 := by
  intro p hp
  have h : env27090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27089_27090 : H12AffineEnvironment.transform 10 1 env27089 = env27090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env27089 == env27090) = true)

theorem identity27090 : scanCanonicalize (H12AffineFastState.compose env27090 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound27090 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27091 : List Nat := [1,1,0,1,0,0,0,0,0,0,1,0,1,0,0,1,0,1,1,1,0,1,0,0,1,0,0,0,0,0,0,1,1,0,1,1]

theorem envBound27091 : H12AffineFastState.Bounded env27091 := by
  intro p hp
  have h : env27091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27090_27091 : H12AffineEnvironment.transform 0 1 env27090 = env27091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env27090 == env27091) = true)

def env27092 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,0,8192,1297,9245,65536,74862,65664,321,9244,0,477,74047,65552,9672,74798,319,74815,1297,77130,8204,8200,257,74798,1345,1044]

theorem envBound27092 : H12AffineFastState.Bounded env27092 := by
  intro p hp
  have h : env27092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27050_27092 : H12AffineEnvironment.transform 8 341 env27050 = env27092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env27050 == env27092) = true)

def env27093 : List Nat := [2,4,8,0,32,64,128,256,325,1024,2048,0,8192,1281,9229,65536,74862,65664,321,9228,0,461,74031,65536,9672,74798,303,74799,1281,77130,8204,8200,257,74798,1345,1028]

theorem envBound27093 : H12AffineFastState.Bounded env27093 := by
  intro p hp
  have h : env27093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27092_27093 : H12AffineEnvironment.transform 3 0 env27092 = env27093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env27092 == env27093) = true)

theorem identity27093 : scanCanonicalize (H12AffineFastState.compose env27093 (packedSelected [1,8,28] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound27093 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env27094 : List Nat := [2,4,8,0,32,64,5,256,325,1024,2048,0,8192,1281,9229,65536,74862,65541,321,9228,0,328,74031,65536,9549,74798,303,74799,1281,77130,8204,8200,257,74798,1345,1028]

theorem envBound27094 : H12AffineFastState.Bounded env27094 := by
  intro p hp
  have h : env27094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27093_27094 : H12AffineEnvironment.transform 6 5 env27093 = env27094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env27093 == env27094) = true)

def env27095 : List Nat := [2,4,8,0,32,64,5,256,325,1024,2048,0,8192,1281,9229,1056,8270,1061,321,9228,0,328,9487,1056,9549,8206,303,8207,1281,10602,8204,8200,257,8206,1345,1028]

theorem envBound27095 : H12AffineFastState.Bounded env27095 := by
  intro p hp
  have h : env27095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27094_27095 : H12AffineEnvironment.transform 15 1056 env27094 = env27095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1056 env27094 == env27095) = true)

theorem identity27095 : scanCanonicalize (H12AffineFastState.compose env27095 (packedSelected [1,2,3,15,17,19,21,23,32] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound27095 : packedSelected [1,2,3,15,17,19,21,23,32] rootPS < 2^1333 := by decide +kernel

def env27096 : List Nat := [2,4,8,0,32,64,5,256,325,46,2048,0,8192,303,8227,14,8270,11,321,8226,0,328,8481,14,8547,8206,303,8207,303,10602,8204,8200,257,8206,367,42]

theorem envBound27096 : H12AffineFastState.Bounded env27096 := by
  intro p hp
  have h : env27096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27095_27096 : H12AffineEnvironment.transform 9 46 env27095 = env27096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env27095 == env27096) = true)

theorem identity27096 : scanCanonicalize (H12AffineFastState.compose env27096 (packedSelected [0,4,5,8,17,18,19,21,23] rootPS)) = affineNative (2^(12+1) ^^^ 2052) := by decide +kernel

theorem selectedBound27096 : packedSelected [0,4,5,8,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env27097 : List Nat := [2,4,8,0,32,64,5,256,325,46,2048,0,2052,303,2087,14,2122,11,321,2086,0,328,2341,14,2407,2058,303,2059,303,366,2056,2060,257,2058,367,42]

theorem envBound27097 : H12AffineFastState.Bounded env27097 := by
  intro p hp
  have h : env27097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27096_27097 : H12AffineEnvironment.transform 12 2052 env27096 = env27097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2052 env27096 == env27097) = true)

theorem identity27097 : scanCanonicalize (H12AffineFastState.compose env27097 (packedSelected [1,2,3,4,9,10,12,13,17] rootPS)) = affineNative (2^(10+1) ^^^ 258) := by decide +kernel

theorem selectedBound27097 : packedSelected [1,2,3,4,9,10,12,13,17] rootPS < 2^1333 := by decide +kernel

def env27098 : List Nat := [2,4,8,0,32,64,5,256,325,46,258,0,262,303,293,14,328,11,321,292,0,328,39,14,101,264,303,265,303,366,266,270,257,264,367,42]

theorem envBound27098 : H12AffineFastState.Bounded env27098 := by
  intro p hp
  have h : env27098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27097_27098 : H12AffineEnvironment.transform 10 258 env27097 = env27098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 258 env27097 == env27098) = true)

theorem identity27098 : scanCanonicalize (H12AffineFastState.compose env27098 (packedSelected [1,5,7,9,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 35) := by decide +kernel

theorem selectedBound27098 : packedSelected [1,5,7,9,11,12] rootPS < 2^1333 := by decide +kernel

def env27099 : List Nat := [2,4,8,0,32,64,5,35,102,46,33,0,37,12,6,14,107,11,98,7,0,107,39,14,101,43,12,42,12,77,41,45,34,43,76,42]

theorem envBound27099 : H12AffineFastState.Bounded env27099 := by
  intro p hp
  have h : env27099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27098_27099 : H12AffineEnvironment.transform 7 35 env27098 = env27099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 35 env27098 == env27099) = true)

theorem identity27099 : scanCanonicalize (H12AffineFastState.compose env27099 (packedSelected [0,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 42) := by decide +kernel

theorem selectedBound27099 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env27100 : List Nat := [2,4,8,0,32,42,5,35,12,46,33,0,37,12,6,14,1,11,8,7,0,1,39,14,15,43,12,42,12,39,41,45,34,43,38,42]

theorem envBound27100 : H12AffineFastState.Bounded env27100 := by
  intro p hp
  have h : env27100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27099_27100 : H12AffineEnvironment.transform 5 42 env27099 = env27100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 42 env27099 == env27100) = true)

theorem identity27100 : scanCanonicalize (H12AffineFastState.compose env27100 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound27100 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27101 : List Nat := [2,4,8,0,0,10,5,3,12,14,1,0,5,12,6,14,1,11,8,7,0,1,7,14,15,11,12,10,12,7,9,13,2,11,6,10]

theorem envBound27101 : H12AffineFastState.Bounded env27101 := by
  intro p hp
  have h : env27101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27100_27101 : H12AffineEnvironment.transform 4 0 env27100 = env27101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env27100 == env27101) = true)

theorem identity27101 : scanCanonicalize (H12AffineFastState.compose env27101 (packedSelected [1,3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound27101 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27102 : List Nat := [2,2,8,0,0,10,3,3,10,8,1,0,3,10,0,8,1,11,8,1,0,1,1,8,9,11,10,10,10,1,9,11,2,11,0,10]

theorem envBound27102 : H12AffineFastState.Bounded env27102 := by
  intro p hp
  have h : env27102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27101_27102 : H12AffineEnvironment.transform 1 2 env27101 = env27102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env27101 == env27102) = true)

def env27103 : List Nat := [2,4,8,0,32,64,5,256,325,1024,2048,0,8192,1281,9229,1057,8271,1060,321,9228,0,328,9486,1057,9549,8207,303,8206,1281,10603,8204,8200,257,8207,1345,1028]

theorem envBound27103 : H12AffineFastState.Bounded env27103 := by
  intro p hp
  have h : env27103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27094_27103 : H12AffineEnvironment.transform 15 1057 env27094 = env27103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1057 env27094 == env27103) = true)

theorem identity27103 : scanCanonicalize (H12AffineFastState.compose env27103 (packedSelected [1,2,3,15,17,19,21,23,32] rootPS)) = affineNative (2^(9+1) ^^^ 41) := by decide +kernel

theorem selectedBound27103 : packedSelected [1,2,3,15,17,19,21,23,32] rootPS < 2^1333 := by decide +kernel

def env27104 : List Nat := [2,4,8,0,32,64,5,256,325,41,2048,0,8192,296,8228,8,8271,13,321,8229,0,328,8487,8,8548,8207,303,8206,296,10603,8204,8200,257,8207,360,45]

theorem envBound27104 : H12AffineFastState.Bounded env27104 := by
  intro p hp
  have h : env27104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27103_27104 : H12AffineEnvironment.transform 9 41 env27103 = env27104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 41 env27103 == env27104) = true)

theorem identity27104 : scanCanonicalize (H12AffineFastState.compose env27104 (packedSelected [3,5,8,10,11,12,21,23,24] rootPS)) = affineNative (2^(12+1) ^^^ 2053) := by decide +kernel

theorem selectedBound27104 : packedSelected [3,5,8,10,11,12,21,23,24] rootPS < 2^1333 := by decide +kernel

def env27105 : List Nat := [2,4,8,0,32,64,5,256,325,41,2048,0,2053,296,2081,8,2122,13,321,2080,0,328,2338,8,2401,2058,303,2059,296,366,2057,2061,257,2058,360,45]

theorem envBound27105 : H12AffineFastState.Bounded env27105 := by
  intro p hp
  have h : env27105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27104_27105 : H12AffineEnvironment.transform 12 2053 env27104 = env27105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2053 env27104 == env27105) = true)

theorem identity27105 : scanCanonicalize (H12AffineFastState.compose env27105 (packedSelected [2,3,4,7,8,10,11,15,16,17,18] rootPS)) = affineNative (2^(5+1) ^^^ 39) := by decide +kernel

theorem selectedBound27105 : packedSelected [2,3,4,7,8,10,11,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env27106 : List Nat := [2,4,8,0,32,39,5,256,290,41,2048,0,2053,296,2081,8,2093,13,294,2080,0,303,2338,8,2310,2058,303,2059,296,265,2057,2061,257,2058,271,45]

theorem envBound27106 : H12AffineFastState.Bounded env27106 := by
  intro p hp
  have h : env27106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27105_27106 : H12AffineEnvironment.transform 5 39 env27105 = env27106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 39 env27105 == env27106) = true)

theorem identity27106 : scanCanonicalize (H12AffineFastState.compose env27106 (packedSelected [1,5,12] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound27106 : packedSelected [1,5,12] rootPS < 2^1333 := by decide +kernel

def env27107 : List Nat := [2,4,8,0,13,10,5,256,271,4,2048,0,2053,261,2060,8,2048,13,267,2061,0,258,2319,8,2310,2058,258,2059,261,265,2057,2061,257,2058,271,0]

theorem envBound27107 : H12AffineFastState.Bounded env27107 := by
  intro p hp
  have h : env27107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27106_27107 : H12AffineEnvironment.transform 4 13 env27106 = env27107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env27106 == env27107) = true)

theorem identity27107 : scanCanonicalize (H12AffineFastState.compose env27107 (packedSelected [0,3,4,5,8] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound27107 : packedSelected [0,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env27108 : List Nat := [2,4,2,0,7,0,5,256,261,4,2048,0,2053,261,2054,2,2048,7,257,2055,0,258,2309,2,2310,2048,258,2049,261,259,2051,2055,257,2048,261,0]

theorem envBound27108 : H12AffineFastState.Bounded env27108 := by
  intro p hp
  have h : env27108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27107_27108 : H12AffineEnvironment.transform 2 2 env27107 = env27108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env27107 == env27108) = true)

theorem identity27108 : scanCanonicalize (H12AffineFastState.compose env27108 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 7) := by decide +kernel

theorem selectedBound27108 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env27109 : List Nat := [2,4,2,0,7,0,5,256,261,4,7,0,2,261,1,2,7,7,257,0,0,258,258,2,257,7,258,6,261,259,4,0,257,7,261,0]

theorem envBound27109 : H12AffineFastState.Bounded env27109 := by
  intro p hp
  have h : env27109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27108_27109 : H12AffineEnvironment.transform 10 7 env27108 = env27109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 7 env27108 == env27109) = true)

theorem identity27109 : scanCanonicalize (H12AffineFastState.compose env27109 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 2) := by decide +kernel

theorem selectedBound27109 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27110 : List Nat := [2,4,2,0,7,0,5,2,7,4,7,0,2,7,1,2,7,7,3,0,0,0,0,2,3,7,0,6,7,1,4,0,3,7,7,0]

theorem envBound27110 : H12AffineFastState.Bounded env27110 := by
  intro p hp
  have h : env27110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27109_27110 : H12AffineEnvironment.transform 7 2 env27109 = env27110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 2 env27109 == env27110) = true)

theorem identity27110 : scanCanonicalize (H12AffineFastState.compose env27110 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound27110 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env27111 : List Nat := [2,3,2,0,0,0,2,2,0,3,0,0,2,0,1,2,0,0,3,0,0,0,0,2,3,0,0,1,0,1,3,0,3,0,0,0]

theorem envBound27111 : H12AffineFastState.Bounded env27111 := by
  intro p hp
  have h : env27111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27110_27111 : H12AffineEnvironment.transform 1 3 env27110 = env27111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env27110 == env27111) = true)

def env27112 : List Nat := [2,4,8,1,32,64,128,256,324,1024,2048,0,8192,1280,9228,65536,74862,65664,321,9229,0,460,74030,65537,9672,74798,302,74798,1280,77130,8204,8200,257,74798,1345,1029]

theorem envBound27112 : H12AffineFastState.Bounded env27112 := by
  intro p hp
  have h : env27112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27092_27112 : H12AffineEnvironment.transform 3 1 env27092 = env27112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env27092 == env27112) = true)

theorem identity27112 : scanCanonicalize (H12AffineFastState.compose env27112 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 1420) := by decide +kernel

theorem selectedBound27112 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env27113 : List Nat := [2,4,8,1,32,64,128,256,324,1024,2048,0,1420,1280,384,65536,66018,65664,321,385,0,460,66722,65537,68,65954,302,65954,1280,67782,1408,1412,257,65954,1345,1029]

theorem envBound27113 : H12AffineFastState.Bounded env27113 := by
  intro p hp
  have h : env27113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27112_27113 : H12AffineEnvironment.transform 12 1420 env27112 = env27113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1420 env27112 == env27113) = true)

def env27114 : List Nat := [2,4,8,1,32,64,4,256,324,1024,2048,0,1288,1280,260,65536,65894,65540,321,261,0,328,66598,65537,68,65830,302,65830,1280,67650,1284,1280,257,65830,1345,1029]

theorem envBound27114 : H12AffineFastState.Bounded env27114 := by
  intro p hp
  have h : env27114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27113_27114 : H12AffineEnvironment.transform 6 4 env27113 = env27114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env27113 == env27114) = true)

theorem identity27114 : scanCanonicalize (H12AffineFastState.compose env27114 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound27114 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env27115 : List Nat := [2,4,8,1,32,64,4,256,324,68,2048,0,332,324,260,65536,65894,65540,321,261,0,328,65634,65537,68,65830,302,65830,324,67650,320,324,257,65830,261,65]

theorem envBound27115 : H12AffineFastState.Bounded env27115 := by
  intro p hp
  have h : env27115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27114_27115 : H12AffineEnvironment.transform 9 68 env27114 = env27115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env27114 == env27115) = true)

theorem identity27115 : scanCanonicalize (H12AffineFastState.compose env27115 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 38) := by decide +kernel

theorem selectedBound27115 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env27116 : List Nat := [2,4,8,1,32,64,4,256,324,68,38,0,332,324,260,65536,65894,65540,321,261,0,328,65634,65537,68,65830,302,65830,324,65636,320,324,257,65830,261,65]

theorem envBound27116 : H12AffineFastState.Bounded env27116 := by
  intro p hp
  have h : env27116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27115_27116 : H12AffineEnvironment.transform 10 38 env27115 = env27116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 38 env27115 == env27116) = true)

theorem identity27116 : scanCanonicalize (H12AffineFastState.compose env27116 (packedSelected [0,1,3,4,5,7,9,10,12,13,16,20] rootPS)) = affineNative (2^(15+1) ^^^ 14) := by decide +kernel

theorem selectedBound27116 : packedSelected [0,1,3,4,5,7,9,10,12,13,16,20] rootPS < 2^1333 := by decide +kernel

def env27117 : List Nat := [2,4,8,1,32,64,4,256,324,68,38,0,332,324,260,14,360,10,321,261,0,328,108,15,68,296,302,296,324,106,320,324,257,296,261,65]

theorem envBound27117 : H12AffineFastState.Bounded env27117 := by
  intro p hp
  have h : env27117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27116_27117 : H12AffineEnvironment.transform 15 14 env27116 = env27117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 14 env27116 == env27117) = true)

theorem identity27117 : scanCanonicalize (H12AffineFastState.compose env27117 (packedSelected [1,4,8,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 7) := by decide +kernel

theorem selectedBound27117 : packedSelected [1,4,8,9,11] rootPS < 2^1333 := by decide +kernel

def env27118 : List Nat := [2,4,8,1,32,7,4,256,259,3,38,0,267,259,260,14,303,10,262,261,0,271,43,15,3,296,302,296,259,45,263,259,257,296,261,6]

theorem envBound27118 : H12AffineFastState.Bounded env27118 := by
  intro p hp
  have h : env27118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27117_27118 : H12AffineEnvironment.transform 5 7 env27117 = env27118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 7 env27117 == env27118) = true)

theorem identity27118 : scanCanonicalize (H12AffineFastState.compose env27118 (packedSelected [1,2,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound27118 : packedSelected [1,2,5,8] rootPS < 2^1333 := by decide +kernel

def env27119 : List Nat := [2,4,8,1,32,7,4,15,12,3,38,0,4,12,11,14,32,10,9,10,0,0,43,15,3,39,33,39,12,45,8,12,14,39,10,6]

theorem envBound27119 : H12AffineFastState.Bounded env27119 := by
  intro p hp
  have h : env27119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27118_27119 : H12AffineEnvironment.transform 7 15 env27118 = env27119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env27118 == env27119) = true)

theorem identity27119 : scanCanonicalize (H12AffineFastState.compose env27119 (packedSelected [0,3,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound27119 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env27120 : List Nat := [2,4,3,1,32,7,4,4,7,3,38,0,4,7,0,5,32,1,2,1,0,0,32,4,3,39,33,39,7,38,3,7,5,39,1,6]

theorem envBound27120 : H12AffineFastState.Bounded env27120 := by
  intro p hp
  have h : env27120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27119_27120 : H12AffineEnvironment.transform 2 3 env27119 = env27120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env27119 == env27120) = true)

theorem identity27120 : scanCanonicalize (H12AffineFastState.compose env27120 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 4) := by decide +kernel

theorem selectedBound27120 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env27121 : List Nat := [2,4,3,1,4,7,4,4,7,3,2,0,4,7,0,5,4,1,2,1,0,0,4,4,3,3,5,3,7,2,3,7,5,3,1,6]

theorem envBound27121 : H12AffineFastState.Bounded env27121 := by
  intro p hp
  have h : env27121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27120_27121 : H12AffineEnvironment.transform 4 4 env27120 = env27121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 4 env27120 == env27121) = true)

theorem identity27121 : scanCanonicalize (H12AffineFastState.compose env27121 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound27121 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27122 : List Nat := [2,2,3,1,2,1,2,2,1,3,2,0,2,1,0,3,2,1,2,1,0,0,2,2,3,3,3,3,1,2,3,1,3,3,1,0]

theorem envBound27122 : H12AffineFastState.Bounded env27122 := by
  intro p hp
  have h : env27122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27121_27122 : H12AffineEnvironment.transform 1 2 env27121 = env27122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env27121 == env27122) = true)

theorem identity27122 : scanCanonicalize (H12AffineFastState.compose env27122 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound27122 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27123 : List Nat := [1,1,0,1,1,1,1,1,1,0,1,0,1,1,0,0,1,1,1,1,0,0,1,1,0,0,0,0,1,1,0,1,0,0,1,0]

theorem envBound27123 : H12AffineFastState.Bounded env27123 := by
  intro p hp
  have h : env27123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27122_27123 : H12AffineEnvironment.transform 0 1 env27122 = env27123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env27122 == env27123) = true)

def env27124 : List Nat := [2,4,8,1,32,64,5,256,324,1024,2048,0,1289,1280,261,65536,65895,65541,321,260,0,329,66599,65537,68,65831,302,65831,1280,67651,1285,1281,257,65831,1345,1029]

theorem envBound27124 : H12AffineFastState.Bounded env27124 := by
  intro p hp
  have h : env27124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27113_27124 : H12AffineEnvironment.transform 6 5 env27113 = env27124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env27113 == env27124) = true)

theorem identity27124 : scanCanonicalize (H12AffineFastState.compose env27124 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound27124 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env27125 : List Nat := [2,4,8,1,32,64,5,5,65,1024,2048,0,1036,1029,0,65536,65634,65541,68,1,0,76,66599,65537,68,65570,43,65570,1029,67651,1024,1028,4,65570,1092,1029]

theorem envBound27125 : H12AffineFastState.Bounded env27125 := by
  intro p hp
  have h : env27125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27124_27125 : H12AffineEnvironment.transform 7 5 env27124 = env27125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env27124 == env27125) = true)

theorem identity27125 : scanCanonicalize (H12AffineFastState.compose env27125 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound27125 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env27126 : List Nat := [2,4,8,1,32,64,5,5,65,1024,2048,0,1036,1029,0,34,64,39,68,1,0,76,1029,35,68,0,43,0,1029,2145,1024,1028,4,0,1092,1029]

theorem envBound27126 : H12AffineFastState.Bounded env27126 := by
  intro p hp
  have h : env27126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27125_27126 : H12AffineEnvironment.transform 15 34 env27125 = env27126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env27125 == env27126) = true)

theorem identity27126 : scanCanonicalize (H12AffineFastState.compose env27126 (packedSelected [0,1,2,3,7,8,11,12,13,15] rootPS)) = affineNative (2^(9+1) ^^^ 66) := by decide +kernel

theorem selectedBound27126 : packedSelected [0,1,2,3,7,8,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env27127 : List Nat := [2,4,8,1,32,64,5,5,65,66,2048,0,78,71,0,34,64,39,68,1,0,76,71,35,68,0,43,0,71,2145,66,70,4,0,6,71]

theorem envBound27127 : H12AffineFastState.Bounded env27127 := by
  intro p hp
  have h : env27127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27126_27127 : H12AffineEnvironment.transform 9 66 env27126 = env27127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 66 env27126 == env27127) = true)

theorem identity27127 : scanCanonicalize (H12AffineFastState.compose env27127 (packedSelected [2,3,5,8,12] rootPS)) = affineNative (2^(10+1) ^^^ 107) := by decide +kernel

theorem selectedBound27127 : packedSelected [2,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env27128 : List Nat := [2,4,8,1,32,64,5,5,65,66,107,0,78,71,0,34,64,39,68,1,0,76,71,35,68,0,43,0,71,10,66,70,4,0,6,71]

theorem envBound27128 : H12AffineFastState.Bounded env27128 := by
  intro p hp
  have h : env27128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27127_27128 : H12AffineEnvironment.transform 10 107 env27127 = env27128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 107 env27127 == env27128) = true)

theorem identity27128 : scanCanonicalize (H12AffineFastState.compose env27128 (packedSelected [0,2,3,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound27128 : packedSelected [0,2,3,7] rootPS < 2^1333 := by decide +kernel

def env27129 : List Nat := [2,4,8,1,0,64,5,5,65,66,75,0,78,71,0,2,64,7,68,1,0,76,71,3,68,0,11,0,71,10,66,70,4,0,6,71]

theorem envBound27129 : H12AffineFastState.Bounded env27129 := by
  intro p hp
  have h : env27129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27128_27129 : H12AffineEnvironment.transform 4 0 env27128 = env27129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env27128 == env27129) = true)

theorem identity27129 : scanCanonicalize (H12AffineFastState.compose env27129 (packedSelected [1,2,3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound27129 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env27130 : List Nat := [2,4,5,1,0,64,5,5,65,66,70,0,67,71,0,2,64,7,68,1,0,65,71,3,68,0,6,0,71,7,66,70,4,0,6,71]

theorem envBound27130 : H12AffineFastState.Bounded env27130 := by
  intro p hp
  have h : env27130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27129_27130 : H12AffineEnvironment.transform 2 5 env27129 = env27130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env27129 == env27130) = true)

theorem identity27130 : scanCanonicalize (H12AffineFastState.compose env27130 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 6) := by decide +kernel

theorem selectedBound27130 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27131 : List Nat := [2,4,5,1,0,6,5,5,7,4,0,0,5,1,0,2,6,7,2,1,0,7,1,3,2,0,6,0,1,7,4,0,4,0,6,1]

theorem envBound27131 : H12AffineFastState.Bounded env27131 := by
  intro p hp
  have h : env27131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27130_27131 : H12AffineEnvironment.transform 5 6 env27130 = env27131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 6 env27130 == env27131) = true)

theorem identity27131 : scanCanonicalize (H12AffineFastState.compose env27131 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound27131 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27132 : List Nat := [2,2,3,1,0,0,3,3,1,2,0,0,3,1,0,2,0,1,2,1,0,1,1,3,2,0,0,0,1,1,2,0,2,0,0,1]

theorem envBound27132 : H12AffineFastState.Bounded env27132 := by
  intro p hp
  have h : env27132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27131_27132 : H12AffineEnvironment.transform 1 2 env27131 = env27132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env27131 == env27132) = true)

def env27133 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74862,65665,4417,13340,4096,477,74047,69648,13768,78894,4414,74815,1297,81226,8204,8200,257,74798,1345,5953]

theorem envBound27133 : H12AffineFastState.Bounded env27133 := by
  intro p hp
  have h : env27133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27048_27133 : H12AffineEnvironment.transform 17 65665 env27048 = env27133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env27048 == env27133) = true)

theorem identity27133 : scanCanonicalize (H12AffineFastState.compose env27133 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound27133 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env27134 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,81,12637,65536,74030,65665,4417,12636,4096,477,74047,69648,12424,78190,4414,74111,81,79882,8204,8200,257,74094,1,4609]

theorem envBound27134 : H12AffineFastState.Bounded env27134 := by
  intro p hp
  have h : env27134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27133_27134 : H12AffineEnvironment.transform 9 320 env27133 = env27134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env27133 == env27134) = true)

def env27135 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,4096,8192,81,12637,65536,74030,65665,4417,12636,4096,477,74047,69648,12424,78190,4414,74111,81,79882,8204,8200,257,74094,1,4437]

theorem envBound27135 : H12AffineFastState.Bounded env27135 := by
  intro p hp
  have h : env27135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27134_27135 : H12AffineEnvironment.transform 8 340 env27134 = env27135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env27134 == env27135) = true)

def env27136 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,16,8192,81,8525,65536,74030,65665,337,8524,16,477,74047,65536,8344,74110,302,74111,81,75802,8204,8200,257,74094,1,325]

theorem envBound27136 : H12AffineFastState.Bounded env27136 := by
  intro p hp
  have h : env27136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27135_27136 : H12AffineEnvironment.transform 11 16 env27135 = env27136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env27135 == env27136) = true)

theorem identity27136 : scanCanonicalize (H12AffineFastState.compose env27136 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8634) := by decide +kernel

theorem selectedBound27136 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env27137 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,16,8192,81,8525,8634,148,8507,337,8524,16,477,133,8634,8344,196,302,197,81,2464,8204,8200,257,212,1,325]

theorem envBound27137 : H12AffineFastState.Bounded env27137 := by
  intro p hp
  have h : env27137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27136_27137 : H12AffineEnvironment.transform 15 8634 env27136 = env27137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8634 env27136 == env27137) = true)

def env27138 : List Nat := [2,4,8,0,32,64,128,256,324,320,2048,0,8192,65,8525,8618,132,8491,321,8524,0,461,133,8618,8328,196,302,197,65,2464,8204,8200,257,196,1,325]

theorem envBound27138 : H12AffineFastState.Bounded env27138 := by
  intro p hp
  have h : env27138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27137_27138 : H12AffineEnvironment.transform 3 0 env27137 = env27138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env27137 == env27138) = true)

theorem identity27138 : scanCanonicalize (H12AffineFastState.compose env27138 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 192) := by decide +kernel

theorem selectedBound27138 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env27139 : List Nat := [2,4,8,0,32,64,128,192,132,128,2048,0,8192,65,8333,8298,132,8427,129,8332,0,13,133,8298,8328,196,238,197,65,2144,8204,8200,193,196,1,133]

theorem envBound27139 : H12AffineFastState.Bounded env27139 := by
  intro p hp
  have h : env27139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27138_27139 : H12AffineEnvironment.transform 7 192 env27138 = env27139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 192 env27138 == env27139) = true)

theorem identity27139 : scanCanonicalize (H12AffineFastState.compose env27139 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 141) := by decide +kernel

theorem selectedBound27139 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env27140 : List Nat := [2,4,8,0,32,64,128,192,132,128,2048,0,141,65,0,231,132,102,129,1,0,13,133,231,5,196,238,197,65,2144,129,133,193,196,1,133]

theorem envBound27140 : H12AffineFastState.Bounded env27140 := by
  intro p hp
  have h : env27140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27139_27140 : H12AffineEnvironment.transform 12 141 env27139 = env27140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 141 env27139 == env27140) = true)

def env27141 : List Nat := [2,4,8,1,32,64,128,256,325,320,2048,1,8192,64,8525,8619,133,8490,320,8524,1,460,133,8619,8329,196,302,197,64,2464,8204,8200,257,197,1,325]

theorem envBound27141 : H12AffineFastState.Bounded env27141 := by
  intro p hp
  have h : env27141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27137_27141 : H12AffineEnvironment.transform 3 1 env27137 = env27141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env27137 == env27141) = true)

theorem identity27141 : scanCanonicalize (H12AffineFastState.compose env27141 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound27141 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env27142 : List Nat := [2,4,8,1,32,64,128,4,65,68,2048,1,8192,64,8265,8367,133,8238,68,8264,1,200,133,8367,8329,196,42,197,64,2212,8204,8200,5,197,1,65]

theorem envBound27142 : H12AffineFastState.Bounded env27142 := by
  intro p hp
  have h : env27142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27141_27142 : H12AffineEnvironment.transform 7 4 env27141 = env27142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env27141 == env27142) = true)

theorem identity27142 : scanCanonicalize (H12AffineFastState.compose env27142 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(6+1) ^^^ 68) := by decide +kernel

theorem selectedBound27142 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env27143 : List Nat := [2,4,8,1,32,64,68,4,65,68,2048,1,8192,64,8265,8299,65,8238,68,8264,1,12,65,8299,8269,0,42,1,64,2144,8204,8200,5,1,1,65]

theorem envBound27143 : H12AffineFastState.Bounded env27143 := by
  intro p hp
  have h : env27143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27142_27143 : H12AffineEnvironment.transform 6 68 env27142 = env27143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 68 env27142 == env27143) = true)

theorem identity27143 : scanCanonicalize (H12AffineFastState.compose env27143 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 77) := by decide +kernel

theorem selectedBound27143 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env27144 : List Nat := [2,4,8,1,32,64,68,4,65,68,77,1,8192,64,8265,8299,65,8238,68,8264,1,12,65,8299,8269,0,42,1,64,45,8204,8200,5,1,1,65]

theorem envBound27144 : H12AffineFastState.Bounded env27144 := by
  intro p hp
  have h : env27144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27143_27144 : H12AffineEnvironment.transform 10 77 env27143 = env27144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 77 env27143 == env27144) = true)

theorem identity27144 : scanCanonicalize (H12AffineFastState.compose env27144 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound27144 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env27145 : List Nat := [2,4,8,1,32,64,68,4,65,68,77,1,9,64,64,98,65,39,68,65,1,12,65,98,68,0,42,1,64,45,5,1,5,1,1,65]

theorem envBound27145 : H12AffineFastState.Bounded env27145 := by
  intro p hp
  have h : env27145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27144_27145 : H12AffineEnvironment.transform 12 9 env27144 = env27145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env27144 == env27145) = true)

theorem identity27145 : scanCanonicalize (H12AffineFastState.compose env27145 (packedSelected [0,4,5,7] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound27145 : packedSelected [0,4,5,7] rootPS < 2^1333 := by decide +kernel

def env27146 : List Nat := [2,4,5,1,32,64,68,4,65,68,64,1,4,64,64,98,65,39,68,65,1,1,65,98,68,0,39,1,64,32,5,1,5,1,1,65]

theorem envBound27146 : H12AffineFastState.Bounded env27146 := by
  intro p hp
  have h : env27146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27145_27146 : H12AffineEnvironment.transform 2 5 env27145 = env27146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env27145 == env27146) = true)

def env27147 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,17,8192,81,8524,65536,74030,65665,336,8525,17,477,74047,65537,8345,74111,303,74111,81,75803,8204,8200,257,74094,1,324]

theorem envBound27147 : H12AffineFastState.Bounded env27147 := by
  intro p hp
  have h : env27147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27135_27147 : H12AffineEnvironment.transform 11 17 env27135 = env27147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env27135 == env27147) = true)

theorem identity27147 : scanCanonicalize (H12AffineFastState.compose env27147 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 498) := by decide +kernel

theorem selectedBound27147 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env27148 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,17,8192,81,8524,498,8412,371,336,8525,17,477,8397,499,8345,8333,303,8333,81,10729,8204,8200,257,8348,1,324]

theorem envBound27148 : H12AffineFastState.Bounded env27148 := by
  intro p hp
  have h : env27148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27147_27148 : H12AffineEnvironment.transform 15 498 env27147 = env27148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 498 env27147 == env27148) = true)

def env27149 : List Nat := [2,4,8,0,32,64,128,256,324,320,2048,1,8192,65,8524,482,8396,355,320,8525,1,461,8397,483,8329,8333,303,8333,65,10729,8204,8200,257,8332,1,324]

theorem envBound27149 : H12AffineFastState.Bounded env27149 := by
  intro p hp
  have h : env27149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27148_27149 : H12AffineEnvironment.transform 3 0 env27148 = env27149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env27148 == env27149) = true)

theorem identity27149 : scanCanonicalize (H12AffineFastState.compose env27149 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound27149 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env27150 : List Nat := [2,4,8,0,32,64,128,5,65,69,2048,1,8192,65,8265,231,8396,102,69,8264,1,200,8397,230,8329,8333,42,8333,65,10476,8204,8200,4,8332,1,65]

theorem envBound27150 : H12AffineFastState.Bounded env27150 := by
  intro p hp
  have h : env27150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27149_27150 : H12AffineEnvironment.transform 7 5 env27149 = env27150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env27149 == env27150) = true)

theorem identity27150 : scanCanonicalize (H12AffineFastState.compose env27150 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 140) := by decide +kernel

theorem selectedBound27150 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env27151 : List Nat := [2,4,8,0,32,64,128,5,65,69,2048,1,140,65,197,231,64,102,69,196,1,200,65,230,5,1,42,1,65,2144,128,132,4,0,1,65]

theorem envBound27151 : H12AffineFastState.Bounded env27151 := by
  intro p hp
  have h : env27151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27150_27151 : H12AffineEnvironment.transform 12 140 env27150 = env27151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 140 env27150 == env27151) = true)

theorem identity27151 : scanCanonicalize (H12AffineFastState.compose env27151 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 201) := by decide +kernel

theorem selectedBound27151 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env27152 : List Nat := [2,4,8,0,32,64,128,5,65,69,201,1,140,65,197,231,64,102,69,196,1,200,65,230,5,1,42,1,65,169,128,132,4,0,1,65]

theorem envBound27152 : H12AffineFastState.Bounded env27152 := by
  intro p hp
  have h : env27152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27151_27152 : H12AffineEnvironment.transform 10 201 env27151 = env27152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 201 env27151 == env27152) = true)

theorem identity27152 : scanCanonicalize (H12AffineFastState.compose env27152 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(6+1) ^^^ 69) := by decide +kernel

theorem selectedBound27152 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env27153 : List Nat := [2,4,8,0,32,64,69,5,65,69,12,1,73,65,0,34,64,102,69,1,1,13,65,35,5,1,42,1,65,108,69,65,4,0,1,65]

theorem envBound27153 : H12AffineFastState.Bounded env27153 := by
  intro p hp
  have h : env27153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27152_27153 : H12AffineEnvironment.transform 6 69 env27152 = env27153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 69 env27152 == env27153) = true)

theorem identity27153 : scanCanonicalize (H12AffineFastState.compose env27153 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound27153 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env27154 : List Nat := [2,4,8,0,12,64,69,5,65,69,12,1,73,65,0,14,64,74,69,1,1,13,65,15,5,1,6,1,65,64,69,65,4,0,1,65]

theorem envBound27154 : H12AffineFastState.Bounded env27154 := by
  intro p hp
  have h : env27154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27153_27154 : H12AffineEnvironment.transform 4 12 env27153 = env27154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env27153 == env27154) = true)

theorem identity27154 : scanCanonicalize (H12AffineFastState.compose env27154 (packedSelected [0,2] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound27154 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env27155 : List Nat := [2,4,8,0,12,12,9,5,13,9,12,1,5,13,0,14,12,6,9,1,1,13,13,15,5,1,6,1,13,12,9,13,4,0,1,13]

theorem envBound27155 : H12AffineFastState.Bounded env27155 := by
  intro p hp
  have h : env27155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27154_27155 : H12AffineEnvironment.transform 5 12 env27154 = env27155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env27154 == env27155) = true)

def env27156 : List Nat := [2,4,8,1,32,64,128,256,325,320,2048,0,8192,64,8524,483,8397,354,321,8525,0,460,8397,482,8328,8333,303,8333,64,10729,8204,8200,257,8333,1,324]

theorem envBound27156 : H12AffineFastState.Bounded env27156 := by
  intro p hp
  have h : env27156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27148_27156 : H12AffineEnvironment.transform 3 1 env27148 = env27156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env27148 == env27156) = true)

theorem identity27156 : scanCanonicalize (H12AffineFastState.compose env27156 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 393) := by decide +kernel

theorem selectedBound27156 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env27157 : List Nat := [2,4,8,1,32,64,128,256,325,320,2048,0,393,64,197,483,324,354,321,196,0,460,324,482,257,260,303,260,64,2144,389,385,257,260,1,324]

theorem envBound27157 : H12AffineFastState.Bounded env27157 := by
  intro p hp
  have h : env27157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27156_27157 : H12AffineEnvironment.transform 12 393 env27156 = env27157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 393 env27156 == env27157) = true)

theorem identity27157 : scanCanonicalize (H12AffineFastState.compose env27157 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 69) := by decide +kernel

theorem selectedBound27157 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env27158 : List Nat := [2,4,8,1,32,64,69,256,325,320,2048,0,332,64,0,294,324,354,321,1,0,265,324,295,257,260,303,260,64,2144,320,324,257,260,1,324]

theorem envBound27158 : H12AffineFastState.Bounded env27158 := by
  intro p hp
  have h : env27158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27157_27158 : H12AffineEnvironment.transform 6 69 env27157 = env27158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 69 env27157 == env27158) = true)

theorem identity27158 : scanCanonicalize (H12AffineFastState.compose env27158 (packedSelected [0,1,7,8,11,13,15,17] rootPS)) = affineNative (2^(7+1) ^^^ 9) := by decide +kernel

theorem selectedBound27158 : packedSelected [0,1,7,8,11,13,15,17] rootPS < 2^1333 := by decide +kernel

def env27159 : List Nat := [2,4,8,1,32,64,69,9,76,73,2048,0,69,64,0,47,77,107,72,1,0,0,77,46,8,13,38,13,64,2144,73,77,8,13,1,77]

theorem envBound27159 : H12AffineFastState.Bounded env27159 := by
  intro p hp
  have h : env27159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27158_27159 : H12AffineEnvironment.transform 7 9 env27158 = env27159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 9 env27158 == env27159) = true)

theorem identity27159 : scanCanonicalize (H12AffineFastState.compose env27159 (packedSelected [2,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 9) := by decide +kernel

theorem selectedBound27159 : packedSelected [2,7,8] rootPS < 2^1333 := by decide +kernel

def env27160 : List Nat := [2,4,8,1,32,64,69,9,76,73,9,0,69,64,0,47,77,107,72,1,0,0,77,46,8,13,38,13,64,105,73,77,8,13,1,77]

theorem envBound27160 : H12AffineFastState.Bounded env27160 := by
  intro p hp
  have h : env27160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27159_27160 : H12AffineEnvironment.transform 10 9 env27159 = env27160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 9 env27159 == env27160) = true)

theorem identity27160 : scanCanonicalize (H12AffineFastState.compose env27160 (packedSelected [5,13] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound27160 : packedSelected [5,13] rootPS < 2^1333 := by decide +kernel

def env27161 : List Nat := [2,4,8,1,32,33,36,9,45,40,9,0,36,33,0,47,44,10,41,1,0,0,44,46,8,13,38,13,33,8,40,44,8,13,1,44]

theorem envBound27161 : H12AffineFastState.Bounded env27161 := by
  intro p hp
  have h : env27161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27160_27161 : H12AffineEnvironment.transform 5 33 env27160 = env27161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env27160 == env27161) = true)

theorem identity27161 : scanCanonicalize (H12AffineFastState.compose env27161 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound27161 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27162 : List Nat := [2,4,1,1,32,33,36,0,36,33,0,0,36,33,0,38,37,3,32,1,0,0,37,39,1,4,38,4,33,1,33,37,1,4,1,37]

theorem envBound27162 : H12AffineFastState.Bounded env27162 := by
  intro p hp
  have h : env27162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27161_27162 : H12AffineEnvironment.transform 2 1 env27161 = env27162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env27161 == env27162) = true)

theorem identity27162 : scanCanonicalize (H12AffineFastState.compose env27162 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound27162 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env27163 : List Nat := [2,1,1,1,32,33,33,0,33,33,0,0,33,33,0,35,32,3,32,1,0,0,32,34,1,1,35,1,33,1,33,32,1,1,1,32]

theorem envBound27163 : H12AffineFastState.Bounded env27163 := by
  intro p hp
  have h : env27163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27162_27163 : H12AffineEnvironment.transform 1 1 env27162 = env27163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env27162 == env27163) = true)

def env27164 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,4096,8192,81,12637,65536,74030,65665,4417,12636,4096,477,74047,69648,12424,78190,4414,74111,81,79882,8204,8200,257,74094,1,4436]

theorem envBound27164 : H12AffineFastState.Bounded env27164 := by
  intro p hp
  have h : env27164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27134_27164 : H12AffineEnvironment.transform 8 341 env27134 = env27164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env27134 == env27164) = true)

def env27165 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,16,8192,81,8525,65536,74030,65665,337,8524,16,477,74047,65536,8344,74110,302,74111,81,75802,8204,8200,257,74094,1,324]

theorem envBound27165 : H12AffineFastState.Bounded env27165 := by
  intro p hp
  have h : env27165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27164_27165 : H12AffineEnvironment.transform 11 16 env27164 = env27165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env27164 == env27165) = true)

theorem identity27165 : scanCanonicalize (H12AffineFastState.compose env27165 (packedSelected [1,8,28] rootPS)) = affineNative (2^(6+1) ^^^ 20) := by decide +kernel

theorem selectedBound27165 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env27166 : List Nat := [2,4,8,16,32,64,20,256,341,320,2048,16,8192,81,8525,65536,74030,65557,337,8524,16,329,74047,65536,8204,74110,302,74111,81,75802,8204,8200,257,74094,1,324]

theorem envBound27166 : H12AffineFastState.Bounded env27166 := by
  intro p hp
  have h : env27166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27165_27166 : H12AffineEnvironment.transform 6 20 env27165 = env27166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 20 env27165 == env27166) = true)

def env27167 : List Nat := [2,4,8,0,32,64,4,256,325,320,2048,0,8192,65,8525,65536,74030,65541,321,8524,0,329,74031,65536,8204,74094,302,74095,65,75786,8204,8200,257,74094,1,324]

theorem envBound27167 : H12AffineFastState.Bounded env27167 := by
  intro p hp
  have h : env27167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27166_27167 : H12AffineEnvironment.transform 3 0 env27166 = env27167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env27166 == env27167) = true)

theorem identity27167 : scanCanonicalize (H12AffineFastState.compose env27167 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 8298) := by decide +kernel

theorem selectedBound27167 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env27168 : List Nat := [2,4,8,0,32,64,4,256,325,320,2048,0,8192,65,8525,8298,324,8303,321,8524,0,329,325,8298,8204,260,302,261,65,2144,8204,8200,257,260,1,324]

theorem envBound27168 : H12AffineFastState.Bounded env27168 := by
  intro p hp
  have h : env27168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27167_27168 : H12AffineEnvironment.transform 15 8298 env27167 = env27168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8298 env27167 == env27168) = true)

theorem identity27168 : scanCanonicalize (H12AffineFastState.compose env27168 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 333) := by decide +kernel

theorem selectedBound27168 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env27169 : List Nat := [2,4,8,0,32,64,4,256,325,320,2048,0,333,65,0,295,324,290,321,1,0,329,325,295,321,260,302,261,65,2144,321,325,257,260,1,324]

theorem envBound27169 : H12AffineFastState.Bounded env27169 := by
  intro p hp
  have h : env27169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27168_27169 : H12AffineEnvironment.transform 12 333 env27168 = env27169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 333 env27168 == env27169) = true)

def env27170 : List Nat := [2,4,8,1,32,64,5,256,324,320,2048,1,8192,64,8525,65536,74030,65540,320,8524,1,329,74030,65536,8204,74095,302,74094,64,75787,8204,8200,257,74094,1,324]

theorem envBound27170 : H12AffineFastState.Bounded env27170 := by
  intro p hp
  have h : env27170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27166_27170 : H12AffineEnvironment.transform 3 1 env27166 = env27170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env27166 == env27170) = true)

theorem identity27170 : scanCanonicalize (H12AffineFastState.compose env27170 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound27170 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env27171 : List Nat := [2,4,8,1,32,64,5,4,64,68,2048,1,8192,64,8265,65536,73770,65540,68,8264,1,77,73770,65536,8204,73835,42,73834,64,75787,8204,8200,5,73834,1,64]

theorem envBound27171 : H12AffineFastState.Bounded env27171 := by
  intro p hp
  have h : env27171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27170_27171 : H12AffineEnvironment.transform 7 4 env27170 = env27171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env27170 == env27171) = true)

theorem identity27171 : scanCanonicalize (H12AffineFastState.compose env27171 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 8299) := by decide +kernel

theorem selectedBound27171 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env27172 : List Nat := [2,4,8,1,32,64,5,4,64,68,2048,1,8192,64,8265,8299,65,8303,68,8264,1,77,65,8299,8204,0,42,1,64,2144,8204,8200,5,1,1,64]

theorem envBound27172 : H12AffineFastState.Bounded env27172 := by
  intro p hp
  have h : env27172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27171_27172 : H12AffineEnvironment.transform 15 8299 env27171 = env27172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8299 env27171 == env27172) = true)

theorem identity27172 : scanCanonicalize (H12AffineFastState.compose env27172 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 77) := by decide +kernel

theorem selectedBound27172 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env27173 : List Nat := [2,4,8,1,32,64,5,4,64,68,77,1,8192,64,8265,8299,65,8303,68,8264,1,77,65,8299,8204,0,42,1,64,45,8204,8200,5,1,1,64]

theorem envBound27173 : H12AffineFastState.Bounded env27173 := by
  intro p hp
  have h : env27173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27172_27173 : H12AffineEnvironment.transform 10 77 env27172 = env27173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 77 env27172 == env27173) = true)

theorem identity27173 : scanCanonicalize (H12AffineFastState.compose env27173 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(12+1) ^^^ 73) := by decide +kernel

theorem selectedBound27173 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env27174 : List Nat := [2,4,8,1,32,64,5,4,64,68,77,1,73,64,0,34,65,38,68,1,1,77,65,34,69,0,42,1,64,45,69,65,5,1,1,64]

theorem envBound27174 : H12AffineFastState.Bounded env27174 := by
  intro p hp
  have h : env27174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27173_27174 : H12AffineEnvironment.transform 12 73 env27173 = env27174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env27173 == env27174) = true)

theorem identity27174 : scanCanonicalize (H12AffineFastState.compose env27174 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 44) := by decide +kernel

theorem selectedBound27174 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env27175 : List Nat := [2,4,8,1,32,44,5,4,44,40,33,1,37,44,0,34,45,38,40,1,1,33,45,34,41,0,42,1,44,45,41,45,5,1,1,44]

theorem envBound27175 : H12AffineFastState.Bounded env27175 := by
  intro p hp
  have h : env27175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27174_27175 : H12AffineEnvironment.transform 5 44 env27174 = env27175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 44 env27174 == env27175) = true)

theorem identity27175 : scanCanonicalize (H12AffineFastState.compose env27175 (packedSelected [0,2] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound27175 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env27176 : List Nat := [2,4,4,1,32,32,5,4,32,36,33,1,37,32,0,34,33,38,36,1,1,33,33,34,37,0,38,1,32,33,37,33,5,1,1,32]

theorem envBound27176 : H12AffineFastState.Bounded env27176 := by
  intro p hp
  have h : env27176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27175_27176 : H12AffineEnvironment.transform 2 4 env27175 = env27176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env27175 == env27176) = true)

def env27177 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,17,8192,81,8524,65536,74030,65665,336,8525,17,477,74047,65537,8345,74111,303,74111,81,75803,8204,8200,257,74094,1,325]

theorem envBound27177 : H12AffineFastState.Bounded env27177 := by
  intro p hp
  have h : env27177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27164_27177 : H12AffineEnvironment.transform 11 17 env27164 = env27177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env27164 == env27177) = true)

theorem identity27177 : scanCanonicalize (H12AffineFastState.compose env27177 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 220) := by decide +kernel

theorem selectedBound27177 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env27178 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,17,220,81,400,65536,66034,65665,336,401,17,477,66019,65537,69,65955,303,65955,81,67783,208,212,257,65970,1,325]

theorem envBound27178 : H12AffineFastState.Bounded env27178 := by
  intro p hp
  have h : env27178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27177_27178 : H12AffineEnvironment.transform 12 220 env27177 = env27178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 220 env27177 == env27178) = true)

def env27179 : List Nat := [2,4,8,0,32,64,128,256,325,320,2048,1,204,65,384,65536,66018,65665,320,385,1,461,66019,65537,69,65955,303,65955,65,67783,192,196,257,65954,1,325]

theorem envBound27179 : H12AffineFastState.Bounded env27179 := by
  intro p hp
  have h : env27179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27178_27179 : H12AffineEnvironment.transform 3 0 env27178 = env27179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env27178 == env27179) = true)

theorem identity27179 : scanCanonicalize (H12AffineFastState.compose env27179 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound27179 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env27180 : List Nat := [2,4,8,0,32,64,128,5,64,69,2048,1,204,65,133,65536,65767,65665,69,132,1,200,65766,65537,69,65702,42,65702,65,67783,192,196,4,65703,1,64]

theorem envBound27180 : H12AffineFastState.Bounded env27180 := by
  intro p hp
  have h : env27180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27179_27180 : H12AffineEnvironment.transform 7 5 env27179 = env27180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env27179 == env27180) = true)

theorem identity27180 : scanCanonicalize (H12AffineFastState.compose env27180 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 167) := by decide +kernel

theorem selectedBound27180 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env27181 : List Nat := [2,4,8,0,32,64,128,5,64,69,2048,1,204,65,133,167,64,38,69,132,1,200,65,166,69,1,42,1,65,2144,192,196,4,0,1,64]

theorem envBound27181 : H12AffineFastState.Bounded env27181 := by
  intro p hp
  have h : env27181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27180_27181 : H12AffineEnvironment.transform 15 167 env27180 = env27181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 167 env27180 == env27181) = true)

theorem identity27181 : scanCanonicalize (H12AffineFastState.compose env27181 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound27181 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env27182 : List Nat := [2,4,8,0,32,64,128,5,64,69,137,1,204,65,133,167,64,38,69,132,1,200,65,166,69,1,42,1,65,233,192,196,4,0,1,64]

theorem envBound27182 : H12AffineFastState.Bounded env27182 := by
  intro p hp
  have h : env27182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27181_27182 : H12AffineEnvironment.transform 10 137 env27181 = env27182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env27181 == env27182) = true)

theorem identity27182 : scanCanonicalize (H12AffineFastState.compose env27182 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(6+1) ^^^ 68) := by decide +kernel

theorem selectedBound27182 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env27183 : List Nat := [2,4,8,0,32,64,68,5,64,69,77,1,8,65,65,99,64,38,69,64,1,12,65,98,69,1,42,1,65,45,4,0,4,0,1,64]

theorem envBound27183 : H12AffineFastState.Bounded env27183 := by
  intro p hp
  have h : env27183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27182_27183 : H12AffineEnvironment.transform 6 68 env27182 = env27183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 68 env27182 == env27183) = true)

theorem identity27183 : scanCanonicalize (H12AffineFastState.compose env27183 (packedSelected [0,4,5,7] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound27183 : packedSelected [0,4,5,7] rootPS < 2^1333 := by decide +kernel

def env27184 : List Nat := [2,4,4,0,32,64,68,5,64,69,65,1,4,65,65,99,64,38,69,64,1,0,65,98,69,1,38,1,65,33,4,0,4,0,1,64]

theorem envBound27184 : H12AffineFastState.Bounded env27184 := by
  intro p hp
  have h : env27184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27183_27184 : H12AffineEnvironment.transform 2 4 env27183 = env27184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env27183 == env27184) = true)

def env27185 : List Nat := [2,4,8,1,32,64,128,256,324,320,2048,0,205,64,385,65536,66019,65665,321,384,0,460,66019,65537,69,65955,303,65955,64,67783,193,197,257,65955,1,325]

theorem envBound27185 : H12AffineFastState.Bounded env27185 := by
  intro p hp
  have h : env27185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27178_27185 : H12AffineEnvironment.transform 3 1 env27178 = env27185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env27178 == env27185) = true)

theorem identity27185 : scanCanonicalize (H12AffineFastState.compose env27185 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 167) := by decide +kernel

theorem selectedBound27185 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env27186 : List Nat := [2,4,8,1,32,64,128,256,324,320,2048,0,205,64,385,167,324,38,321,384,0,460,324,166,69,260,303,260,64,2144,193,197,257,260,1,325]

theorem envBound27186 : H12AffineFastState.Bounded env27186 := by
  intro p hp
  have h : env27186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27185_27186 : H12AffineEnvironment.transform 15 167 env27185 = env27186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 167 env27185 == env27186) = true)

theorem identity27186 : scanCanonicalize (H12AffineFastState.compose env27186 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 129) := by decide +kernel

theorem selectedBound27186 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env27187 : List Nat := [2,4,8,1,32,64,128,129,197,193,2048,0,205,64,0,167,197,38,192,1,0,77,197,166,69,133,174,133,64,2144,193,197,128,133,1,196]

theorem envBound27187 : H12AffineFastState.Bounded env27187 := by
  intro p hp
  have h : env27187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27186_27187 : H12AffineEnvironment.transform 7 129 env27186 = env27187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 129 env27186 == env27187) = true)

theorem identity27187 : scanCanonicalize (H12AffineFastState.compose env27187 (packedSelected [0,1,7,8,11,13,15,17] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound27187 : packedSelected [0,1,7,8,11,13,15,17] rootPS < 2^1333 := by decide +kernel

def env27188 : List Nat := [2,4,8,1,32,13,128,129,136,140,2048,0,128,13,0,167,136,38,141,1,0,0,136,166,8,133,174,133,13,2093,140,136,128,133,1,137]

theorem envBound27188 : H12AffineFastState.Bounded env27188 := by
  intro p hp
  have h : env27188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27187_27188 : H12AffineEnvironment.transform 5 13 env27187 = env27188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env27187 == env27188) = true)

theorem identity27188 : scanCanonicalize (H12AffineFastState.compose env27188 (packedSelected [2,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 128) := by decide +kernel

theorem selectedBound27188 : packedSelected [2,7,8] rootPS < 2^1333 := by decide +kernel

def env27189 : List Nat := [2,4,8,1,32,13,128,129,136,140,128,0,128,13,0,167,136,38,141,1,0,0,136,166,8,133,174,133,13,173,140,136,128,133,1,137]

theorem envBound27189 : H12AffineFastState.Bounded env27189 := by
  intro p hp
  have h : env27189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27188_27189 : H12AffineEnvironment.transform 10 128 env27188 = env27189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 128 env27188 == env27189) = true)

theorem identity27189 : scanCanonicalize (H12AffineFastState.compose env27189 (packedSelected [5,13] rootPS)) = affineNative (2^(6+1) ^^^ 36) := by decide +kernel

theorem selectedBound27189 : packedSelected [5,13] rootPS < 2^1333 := by decide +kernel

def env27190 : List Nat := [2,4,8,1,32,13,36,37,44,40,36,0,36,13,0,3,44,38,41,1,0,0,44,2,8,33,10,33,13,9,40,44,36,33,1,45]

theorem envBound27190 : H12AffineFastState.Bounded env27190 := by
  intro p hp
  have h : env27190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27189_27190 : H12AffineEnvironment.transform 6 36 env27189 = env27190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 36 env27189 == env27190) = true)

theorem identity27190 : scanCanonicalize (H12AffineFastState.compose env27190 (packedSelected [0,2,5,7] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound27190 : packedSelected [0,2,5,7] rootPS < 2^1333 := by decide +kernel

def env27191 : List Nat := [2,4,6,1,32,3,36,37,34,38,36,0,36,3,0,3,34,38,39,1,0,0,34,2,6,33,4,33,3,7,38,34,36,33,1,35]

theorem envBound27191 : H12AffineFastState.Bounded env27191 := by
  intro p hp
  have h : env27191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27190_27191 : H12AffineEnvironment.transform 2 6 env27190 = env27191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env27190 == env27191) = true)

theorem identity27191 : scanCanonicalize (H12AffineFastState.compose env27191 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound27191 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27192 : List Nat := [2,4,6,1,7,3,3,2,5,1,3,0,3,3,0,3,5,1,0,1,0,0,5,2,6,6,4,6,3,7,1,5,3,6,1,4]

theorem envBound27192 : H12AffineFastState.Bounded env27192 := by
  intro p hp
  have h : env27192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27191_27192 : H12AffineEnvironment.transform 4 7 env27191 = env27192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env27191 == env27192) = true)

theorem identity27192 : scanCanonicalize (H12AffineFastState.compose env27192 (packedSelected [0,1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound27192 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env27193 : List Nat := [1,4,5,1,4,0,0,1,5,1,0,0,0,0,0,0,5,1,0,1,0,0,5,1,5,5,4,5,0,4,1,5,0,5,1,4]

theorem envBound27193 : H12AffineFastState.Bounded env27193 := by
  intro p hp
  have h : env27193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27192_27193 : H12AffineEnvironment.transform 0 1 env27192 = env27193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env27192 == env27193) = true)

def env27194 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,21585,32769,4096,61649,91182,123164,28888,78895,385203,90414,1296,96347,25885,25880,257,74798,1345,21073]

theorem envBound27194 : H12AffineFastState.Bounded env27194 := by
  intro p hp
  have h : env27194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans26949_27194 : H12AffineEnvironment.transform 18 21585 env26949 = env27194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env26949 == env27194) = true)

theorem identity27194 : scanCanonicalize (H12AffineFastState.compose env27194 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25677) := by decide +kernel

theorem selectedBound27194 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env27195 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25677,65536,74862,262144,21585,25676,4096,5276,91182,66897,28888,78895,328958,90414,1296,96347,25885,25880,257,74798,1345,21073]

theorem envBound27195 : H12AffineFastState.Bounded env27195 := by
  intro p hp
  have h : env27195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27194_27195 : H12AffineEnvironment.transform 14 25677 env27194 = env27195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25677 env27194 == env27195) = true)

def env27196 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74862,262144,4417,8540,4096,5276,74046,66897,13768,78895,328958,74814,1296,81227,8205,8200,257,74798,1345,5953]

theorem envBound27196 : H12AffineFastState.Bounded env27196 := by
  intro p hp
  have h : env27196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27195_27196 : H12AffineEnvironment.transform 13 1296 env27195 = env27196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env27195 == env27196) = true)

def env27197 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74862,65664,4417,8540,4096,5276,74046,66897,13768,78895,1150,74814,1296,81227,8205,8200,257,74798,1345,5953]

theorem envBound27197 : H12AffineFastState.Bounded env27197 := by
  intro p hp
  have h : env27197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27196_27197 : H12AffineEnvironment.transform 17 65664 env27196 = env27197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env27196 == env27197) = true)

theorem identity27197 : scanCanonicalize (H12AffineFastState.compose env27197 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 72) := by decide +kernel

theorem selectedBound27197 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env27198 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,72,1296,277,65536,66598,65664,4417,276,4096,5276,65910,66897,5504,70759,1150,66678,1296,72963,69,64,257,66662,1345,5953]

theorem envBound27198 : H12AffineFastState.Bounded env27198 := by
  intro p hp
  have h : env27198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27197_27198 : H12AffineEnvironment.transform 12 72 env27197 = env27198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env27197 == env27198) = true)

def env27199 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1556,72,1296,277,65536,66598,65664,1877,276,1556,648,65910,66897,916,66163,1150,66678,1296,68375,69,64,257,66662,1345,341]

theorem envBound27199 : H12AffineFastState.Bounded env27199 := by
  intro p hp
  have h : env27199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27198_27199 : H12AffineEnvironment.transform 11 1556 env27198 = env27199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env27198 == env27199) = true)

def env27200 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,852,72,80,277,65536,65894,65664,533,276,852,648,65910,65553,916,66163,318,65846,80,68375,69,64,257,65830,1,341]

theorem envBound27200 : H12AffineFastState.Bounded env27200 := by
  intro p hp
  have h : env27200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27199_27200 : H12AffineEnvironment.transform 9 320 env27199 = env27200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env27199 == env27200) = true)

theorem identity27200 : scanCanonicalize (H12AffineFastState.compose env27200 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 65) := by decide +kernel

theorem selectedBound27200 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env27201 : List Nat := [2,4,8,16,32,64,128,256,65,320,2048,277,72,80,277,65536,65894,65664,84,276,277,201,65910,65553,469,65586,318,65846,80,67926,69,64,257,65830,1,341]

theorem envBound27201 : H12AffineFastState.Bounded env27201 := by
  intro p hp
  have h : env27201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27200_27201 : H12AffineEnvironment.transform 8 65 env27200 = env27201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env27200 == env27201) = true)

theorem identity27201 : scanCanonicalize (H12AffineFastState.compose env27201 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound27201 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env27202 : List Nat := [2,4,8,16,32,64,128,256,65,320,2048,277,72,80,277,115,277,243,84,276,277,201,261,98,469,65,318,325,80,2341,69,64,257,341,1,341]

theorem envBound27202 : H12AffineFastState.Bounded env27202 := by
  intro p hp
  have h : env27202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27201_27202 : H12AffineEnvironment.transform 15 115 env27201 = env27202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env27201 == env27202) = true)

theorem identity27202 : scanCanonicalize (H12AffineFastState.compose env27202 (packedSelected [0,2,5,7,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 187) := by decide +kernel

theorem selectedBound27202 : packedSelected [0,2,5,7,11,12] rootPS < 2^1333 := by decide +kernel

def env27203 : List Nat := [2,4,8,16,32,64,128,187,65,251,2048,174,72,80,174,115,174,243,84,175,174,201,190,98,110,65,133,254,80,2206,69,64,186,238,1,238]

theorem envBound27203 : H12AffineFastState.Bounded env27203 := by
  intro p hp
  have h : env27203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27202_27203 : H12AffineEnvironment.transform 7 187 env27202 = env27203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 187 env27202 == env27203) = true)

theorem identity27203 : scanCanonicalize (H12AffineFastState.compose env27203 (packedSelected [0,1,7,10,11,13,15] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound27203 : packedSelected [0,1,7,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env27204 : List Nat := [2,4,8,12,32,64,128,167,65,231,2048,174,72,76,174,111,174,239,72,175,174,201,162,98,110,65,133,226,76,2178,69,64,166,238,1,238]

theorem envBound27204 : H12AffineFastState.Bounded env27204 := by
  intro p hp
  have h : env27204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27203_27204 : H12AffineEnvironment.transform 3 12 env27203 = env27204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env27203 == env27204) = true)

theorem identity27204 : scanCanonicalize (H12AffineFastState.compose env27204 (packedSelected [0,1,3,5,7,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 165) := by decide +kernel

theorem selectedBound27204 : packedSelected [0,1,3,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env27205 : List Nat := [2,4,8,12,32,64,128,167,65,231,165,174,72,76,174,111,174,239,72,175,174,201,162,98,110,65,133,226,76,39,69,64,166,238,1,238]

theorem envBound27205 : H12AffineFastState.Bounded env27205 := by
  intro p hp
  have h : env27205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27204_27205 : H12AffineEnvironment.transform 10 165 env27204 = env27205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 165 env27204 == env27205) = true)

theorem identity27205 : scanCanonicalize (H12AffineFastState.compose env27205 (packedSelected [2,5,8,10] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound27205 : packedSelected [2,5,8,10] rootPS < 2^1333 := by decide +kernel

def env27206 : List Nat := [2,4,8,12,32,32,128,167,33,135,165,174,40,44,174,15,174,143,40,175,174,169,162,2,14,33,133,130,44,39,37,32,166,142,1,142]

theorem envBound27206 : H12AffineFastState.Bounded env27206 := by
  intro p hp
  have h : env27206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27205_27206 : H12AffineEnvironment.transform 5 32 env27205 = env27206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env27205 == env27206) = true)

theorem identity27206 : scanCanonicalize (H12AffineFastState.compose env27206 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound27206 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env27207 : List Nat := [2,4,8,12,13,13,128,138,12,135,136,131,5,1,131,15,131,143,5,130,131,132,143,2,14,12,133,130,1,10,8,13,139,142,1,142]

theorem envBound27207 : H12AffineFastState.Bounded env27207 := by
  intro p hp
  have h : env27207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27206_27207 : H12AffineEnvironment.transform 4 13 env27206 = env27207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env27206 == env27207) = true)

theorem identity27207 : scanCanonicalize (H12AffineFastState.compose env27207 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound27207 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env27208 : List Nat := [2,4,5,1,0,0,128,135,1,135,133,131,5,1,131,2,131,130,5,130,131,132,130,2,3,1,133,130,1,7,5,0,134,131,1,131]

theorem envBound27208 : H12AffineFastState.Bounded env27208 := by
  intro p hp
  have h : env27208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27207_27208 : H12AffineEnvironment.transform 2 5 env27207 = env27208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env27207 == env27208) = true)

theorem identity27208 : scanCanonicalize (H12AffineFastState.compose env27208 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound27208 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27209 : List Nat := [2,2,3,1,0,0,128,129,1,129,131,131,3,1,131,2,131,130,3,130,131,130,130,2,3,1,131,130,1,1,3,0,128,131,1,131]

theorem envBound27209 : H12AffineFastState.Bounded env27209 := by
  intro p hp
  have h : env27209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27208_27209 : H12AffineEnvironment.transform 1 2 env27208 = env27209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env27208 == env27209) = true)

theorem identity27209 : scanCanonicalize (H12AffineFastState.compose env27209 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound27209 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env27210 : List Nat := [2,2,3,1,0,0,3,2,1,2,0,0,3,1,0,2,0,1,3,1,0,1,1,2,3,1,0,1,1,1,3,0,3,0,1,0]

theorem envBound27210 : H12AffineFastState.Bounded env27210 := by
  intro p hp
  have h : env27210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27209_27210 : H12AffineEnvironment.transform 6 3 env27209 = env27210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env27209 == env27210) = true)

theorem identity27210 : scanCanonicalize (H12AffineFastState.compose env27210 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound27210 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27211 : List Nat := [1,1,0,1,0,0,0,1,1,1,0,0,0,1,0,1,0,1,0,1,0,1,1,1,0,1,0,1,1,1,0,0,0,0,1,0]

theorem envBound27211 : H12AffineFastState.Bounded env27211 := by
  intro p hp
  have h : env27211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27210_27211 : H12AffineEnvironment.transform 0 1 env27210 = env27211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env27210 == env27211) = true)

def env27212 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,853,72,81,277,65536,65895,65664,532,276,853,648,65910,65552,916,66163,319,65847,81,68375,69,64,257,65831,0,341]

theorem envBound27212 : H12AffineFastState.Bounded env27212 := by
  intro p hp
  have h : env27212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27199_27212 : H12AffineEnvironment.transform 9 321 env27199 = env27212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env27199 == env27212) = true)

theorem identity27212 : scanCanonicalize (H12AffineFastState.compose env27212 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound27212 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env27213 : List Nat := [2,4,8,16,32,64,128,21,512,84,2048,576,72,81,0,65536,65650,65664,532,1,576,648,65635,65552,641,66163,42,65570,81,68098,69,64,20,65586,0,64]

theorem envBound27213 : H12AffineFastState.Bounded env27213 := by
  intro p hp
  have h : env27213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27212_27213 : H12AffineEnvironment.transform 7 21 env27212 = env27213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env27212 == env27213) = true)

theorem identity27213 : scanCanonicalize (H12AffineFastState.compose env27213 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound27213 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env27214 : List Nat := [2,4,8,16,32,17,128,21,512,5,2048,529,25,0,0,65536,65571,65664,532,1,529,648,65586,65552,641,66082,42,65570,0,68098,20,17,20,65586,0,17]

theorem envBound27214 : H12AffineFastState.Bounded env27214 := by
  intro p hp
  have h : env27214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27213_27214 : H12AffineEnvironment.transform 5 17 env27213 = env27214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27213 == env27214) = true)

theorem identity27214 : scanCanonicalize (H12AffineFastState.compose env27214 (packedSelected [2,3,5,10,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 657) := by decide +kernel

theorem selectedBound27214 : packedSelected [2,3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env27215 : List Nat := [2,4,8,16,32,17,128,21,512,5,2048,529,25,0,0,657,690,529,532,1,529,648,675,641,641,179,42,691,0,2195,20,17,20,675,0,17]

theorem envBound27215 : H12AffineFastState.Bounded env27215 := by
  intro p hp
  have h : env27215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27214_27215 : H12AffineEnvironment.transform 15 657 env27214 = env27215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 657 env27214 == env27215) = true)

theorem identity27215 : scanCanonicalize (H12AffineFastState.compose env27215 (packedSelected [2,3,4,5,8,9,10,12,13,16] rootPS)) = affineNative (2^(10+1) ^^^ 142) := by decide +kernel

theorem selectedBound27215 : packedSelected [2,3,4,5,8,9,10,12,13,16] rootPS < 2^1333 := by decide +kernel

def env27216 : List Nat := [2,4,8,16,32,17,128,21,512,5,142,529,25,0,0,657,690,529,532,1,529,648,675,641,641,179,42,691,0,29,20,17,20,675,0,17]

theorem envBound27216 : H12AffineFastState.Bounded env27216 := by
  intro p hp
  have h : env27216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27215_27216 : H12AffineEnvironment.transform 10 142 env27215 = env27216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 142 env27215 == env27216) = true)

theorem identity27216 : scanCanonicalize (H12AffineFastState.compose env27216 (packedSelected [0,1,3,5,7,8,11,12,17] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound27216 : packedSelected [0,1,3,5,7,8,11,12,17] rootPS < 2^1333 := by decide +kernel

def env27217 : List Nat := [2,4,8,16,32,17,128,21,26,5,142,11,25,0,0,139,168,11,14,1,11,146,185,155,155,179,42,169,0,29,20,17,20,185,0,17]

theorem envBound27217 : H12AffineFastState.Bounded env27217 := by
  intro p hp
  have h : env27217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27216_27217 : H12AffineEnvironment.transform 8 26 env27216 = env27217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env27216 == env27217) = true)

theorem identity27217 : scanCanonicalize (H12AffineFastState.compose env27217 (packedSelected [0,2,5,7,8,11] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound27217 : packedSelected [0,2,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env27218 : List Nat := [2,4,8,16,32,17,3,21,26,5,13,11,25,0,0,8,43,11,14,1,11,17,58,24,24,48,42,42,0,29,20,17,20,58,0,17]

theorem envBound27218 : H12AffineFastState.Bounded env27218 := by
  intro p hp
  have h : env27218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27217_27218 : H12AffineEnvironment.transform 6 3 env27217 = env27218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env27217 == env27218) = true)

theorem identity27218 : scanCanonicalize (H12AffineFastState.compose env27218 (packedSelected [2,3,4,5,7,8] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound27218 : packedSelected [2,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env27219 : List Nat := [2,4,8,11,32,10,3,14,1,5,13,11,2,0,0,8,43,11,14,1,11,10,33,3,3,43,42,42,0,6,15,10,15,33,0,10]

theorem envBound27219 : H12AffineFastState.Bounded env27219 := by
  intro p hp
  have h : env27219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27218_27219 : H12AffineEnvironment.transform 3 11 env27218 = env27219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env27218 == env27219) = true)

def env27220 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1557,72,1296,277,65536,66598,65664,1876,276,1557,649,65910,66897,917,66162,1150,66678,1296,68374,69,64,257,66662,1345,340]

theorem envBound27220 : H12AffineFastState.Bounded env27220 := by
  intro p hp
  have h : env27220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27198_27220 : H12AffineEnvironment.transform 11 1557 env27198 = env27220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env27198 == env27220) = true)

def env27221 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,853,72,80,277,65536,65894,65664,532,276,853,649,65910,65553,917,66162,318,65846,80,68374,69,64,257,65830,1,340]

theorem envBound27221 : H12AffineFastState.Bounded env27221 := by
  intro p hp
  have h : env27221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27220_27221 : H12AffineEnvironment.transform 9 320 env27220 = env27221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env27220 == env27221) = true)

theorem identity27221 : scanCanonicalize (H12AffineFastState.compose env27221 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound27221 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env27222 : List Nat := [2,4,8,16,32,64,128,256,64,320,2048,277,72,80,277,65536,65894,65664,84,276,277,201,65910,65553,469,65586,318,65846,80,67926,69,64,257,65830,1,340]

theorem envBound27222 : H12AffineFastState.Bounded env27222 := by
  intro p hp
  have h : env27222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27221_27222 : H12AffineEnvironment.transform 8 64 env27221 = env27222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env27221 == env27222) = true)

theorem identity27222 : scanCanonicalize (H12AffineFastState.compose env27222 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound27222 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env27223 : List Nat := [2,4,8,16,32,64,128,256,64,320,2048,277,72,80,277,115,277,243,84,276,277,201,261,98,469,65,318,325,80,2341,69,64,257,341,1,340]

theorem envBound27223 : H12AffineFastState.Bounded env27223 := by
  intro p hp
  have h : env27223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27222_27223 : H12AffineEnvironment.transform 15 115 env27222 = env27223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env27222 == env27223) = true)

theorem identity27223 : scanCanonicalize (H12AffineFastState.compose env27223 (packedSelected [0,2,5,7,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 186) := by decide +kernel

theorem selectedBound27223 : packedSelected [0,2,5,7,11,12] rootPS < 2^1333 := by decide +kernel

def env27224 : List Nat := [2,4,8,16,32,64,128,186,64,250,2048,175,72,80,175,115,175,243,84,174,175,201,191,98,111,65,132,255,80,2207,69,64,187,239,1,238]

theorem envBound27224 : H12AffineFastState.Bounded env27224 := by
  intro p hp
  have h : env27224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27223_27224 : H12AffineEnvironment.transform 7 186 env27223 = env27224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 186 env27223 == env27224) = true)

theorem identity27224 : scanCanonicalize (H12AffineFastState.compose env27224 (packedSelected [0,1,7,10,11,13,15] rootPS)) = affineNative (2^(6+1) ^^^ 50) := by decide +kernel

theorem selectedBound27224 : packedSelected [0,1,7,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env27225 : List Nat := [2,4,8,16,32,64,50,8,64,72,2048,29,72,80,29,115,29,65,84,28,29,123,13,98,111,65,54,77,80,2093,69,64,9,93,1,92]

theorem envBound27225 : H12AffineFastState.Bounded env27225 := by
  intro p hp
  have h : env27225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27224_27225 : H12AffineEnvironment.transform 6 50 env27224 = env27225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 50 env27224 == env27225) = true)

theorem identity27225 : scanCanonicalize (H12AffineFastState.compose env27225 (packedSelected [0,1,3,5,7,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound27225 : packedSelected [0,1,3,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env27226 : List Nat := [2,4,8,16,32,64,50,8,64,72,11,29,72,80,29,115,29,65,84,28,29,123,13,98,111,65,54,77,80,38,69,64,9,93,1,92]

theorem envBound27226 : H12AffineFastState.Bounded env27226 := by
  intro p hp
  have h : env27226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27225_27226 : H12AffineEnvironment.transform 10 11 env27225 = env27226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env27225 == env27226) = true)

theorem identity27226 : scanCanonicalize (H12AffineFastState.compose env27226 (packedSelected [2,5,8,10] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound27226 : packedSelected [2,5,8,10] rootPS < 2^1333 := by decide +kernel

def env27227 : List Nat := [2,4,8,16,32,32,50,8,32,40,11,29,40,48,29,19,29,33,52,28,29,27,13,2,15,33,54,45,48,38,37,32,9,61,1,60]

theorem envBound27227 : H12AffineFastState.Bounded env27227 := by
  intro p hp
  have h : env27227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27226_27227 : H12AffineEnvironment.transform 5 32 env27226 = env27227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env27226 == env27227) = true)

theorem identity27227 : scanCanonicalize (H12AffineFastState.compose env27227 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound27227 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env27228 : List Nat := [2,4,8,16,13,13,31,8,13,5,11,29,5,29,29,19,29,12,25,28,29,27,13,2,15,12,27,0,29,11,8,13,9,16,1,17]

theorem envBound27228 : H12AffineFastState.Bounded env27228 := by
  intro p hp
  have h : env27228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27227_27228 : H12AffineEnvironment.transform 4 13 env27227 = env27228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env27227 == env27228) = true)

theorem identity27228 : scanCanonicalize (H12AffineFastState.compose env27228 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound27228 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27229 : List Nat := [2,4,8,10,13,13,5,8,13,5,11,7,5,7,7,9,7,12,3,6,7,1,13,2,15,12,1,0,7,11,8,13,9,10,1,11]

theorem envBound27229 : H12AffineFastState.Bounded env27229 := by
  intro p hp
  have h : env27229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27228_27229 : H12AffineEnvironment.transform 3 10 env27228 = env27229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env27228 == env27229) = true)

theorem identity27229 : scanCanonicalize (H12AffineFastState.compose env27229 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound27229 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env27230 : List Nat := [2,2,8,10,11,11,3,8,11,3,11,1,3,1,1,9,1,10,3,0,1,1,11,2,9,10,1,0,1,11,8,11,9,10,1,11]

theorem envBound27230 : H12AffineFastState.Bounded env27230 := by
  intro p hp
  have h : env27230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27229_27230 : H12AffineEnvironment.transform 1 2 env27229 = env27230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env27229 == env27230) = true)

theorem identity27230 : scanCanonicalize (H12AffineFastState.compose env27230 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound27230 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27231 : List Nat := [2,2,2,0,1,1,3,2,1,3,1,1,3,1,1,3,1,0,3,0,1,1,1,2,3,0,1,0,1,1,2,1,3,0,1,1]

theorem envBound27231 : H12AffineFastState.Bounded env27231 := by
  intro p hp
  have h : env27231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27230_27231 : H12AffineEnvironment.transform 2 2 env27230 = env27231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env27230 == env27231) = true)

def env27232 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,852,72,81,277,65536,65895,65664,533,276,852,649,65910,65552,917,66162,319,65847,81,68374,69,64,257,65831,0,340]

theorem envBound27232 : H12AffineFastState.Bounded env27232 := by
  intro p hp
  have h : env27232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27220_27232 : H12AffineEnvironment.transform 9 321 env27220 = env27232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env27220 == env27232) = true)

theorem identity27232 : scanCanonicalize (H12AffineFastState.compose env27232 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound27232 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env27233 : List Nat := [2,4,8,16,32,64,128,21,512,84,2048,577,72,81,0,65536,65650,65664,533,1,577,649,65635,65552,640,66162,42,65570,81,68099,69,64,20,65586,0,65]

theorem envBound27233 : H12AffineFastState.Bounded env27233 := by
  intro p hp
  have h : env27233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27232_27233 : H12AffineEnvironment.transform 7 21 env27232 = env27233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env27232 == env27233) = true)

theorem identity27233 : scanCanonicalize (H12AffineFastState.compose env27233 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound27233 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env27234 : List Nat := [2,4,8,16,32,17,128,21,512,5,2048,528,25,0,0,65536,65571,65664,533,1,528,649,65586,65552,640,66083,42,65570,0,68099,20,17,20,65586,0,16]

theorem envBound27234 : H12AffineFastState.Bounded env27234 := by
  intro p hp
  have h : env27234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27233_27234 : H12AffineEnvironment.transform 5 17 env27233 = env27234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27233 == env27234) = true)

theorem identity27234 : scanCanonicalize (H12AffineFastState.compose env27234 (packedSelected [2,3,5,10,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 128) := by decide +kernel

theorem selectedBound27234 : packedSelected [2,3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env27235 : List Nat := [2,4,8,16,32,17,128,21,512,5,2048,528,25,0,0,128,163,0,533,1,528,649,178,144,640,675,42,162,0,2691,20,17,20,178,0,16]

theorem envBound27235 : H12AffineFastState.Bounded env27235 := by
  intro p hp
  have h : env27235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27234_27235 : H12AffineEnvironment.transform 15 128 env27234 = env27235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 128 env27234 == env27235) = true)

theorem identity27235 : scanCanonicalize (H12AffineFastState.compose env27235 (packedSelected [2,3,4,5,8,9,10,12,13,16] rootPS)) = affineNative (2^(10+1) ^^^ 572) := by decide +kernel

theorem selectedBound27235 : packedSelected [2,3,4,5,8,9,10,12,13,16] rootPS < 2^1333 := by decide +kernel

def env27236 : List Nat := [2,4,8,16,32,17,128,21,512,5,572,528,25,0,0,128,163,0,533,1,528,649,178,144,640,675,42,162,0,191,20,17,20,178,0,16]

theorem envBound27236 : H12AffineFastState.Bounded env27236 := by
  intro p hp
  have h : env27236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27235_27236 : H12AffineEnvironment.transform 10 572 env27235 = env27236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 572 env27235 == env27236) = true)

theorem identity27236 : scanCanonicalize (H12AffineFastState.compose env27236 (packedSelected [0,1,3,5,7,8,11,12,17] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound27236 : packedSelected [0,1,3,5,7,8,11,12,17] rootPS < 2^1333 := by decide +kernel

def env27237 : List Nat := [2,4,2,16,32,17,128,21,512,5,566,528,19,0,0,128,163,0,533,1,528,643,178,144,640,675,32,162,0,181,20,17,20,178,0,16]

theorem envBound27237 : H12AffineFastState.Bounded env27237 := by
  intro p hp
  have h : env27237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27236_27237 : H12AffineEnvironment.transform 2 2 env27236 = env27237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env27236 == env27237) = true)

theorem identity27237 : scanCanonicalize (H12AffineFastState.compose env27237 (packedSelected [2,3,12] rootPS)) = affineNative (2^(8+1) ^^^ 39) := by decide +kernel

theorem selectedBound27237 : packedSelected [2,3,12] rootPS < 2^1333 := by decide +kernel

def env27238 : List Nat := [2,4,2,16,32,17,128,21,39,5,17,55,19,0,0,128,163,0,50,1,55,164,178,144,167,132,32,162,0,181,20,17,20,178,0,16]

theorem envBound27238 : H12AffineFastState.Bounded env27238 := by
  intro p hp
  have h : env27238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27237_27238 : H12AffineEnvironment.transform 8 39 env27237 = env27238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 39 env27237 == env27238) = true)

theorem identity27238 : scanCanonicalize (H12AffineFastState.compose env27238 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 36) := by decide +kernel

theorem selectedBound27238 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env27239 : List Nat := [2,4,2,16,32,17,36,21,39,5,17,55,19,0,0,36,7,0,50,1,55,0,22,52,3,32,32,6,0,17,20,17,20,22,0,16]

theorem envBound27239 : H12AffineFastState.Bounded env27239 := by
  intro p hp
  have h : env27239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27238_27239 : H12AffineEnvironment.transform 6 36 env27238 = env27239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 36 env27238 == env27239) = true)

def env27240 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74862,65665,4417,8540,4096,5276,74046,66897,13768,78895,1151,74814,1296,81227,8205,8200,257,74798,1345,5953]

theorem envBound27240 : H12AffineFastState.Bounded env27240 := by
  intro p hp
  have h : env27240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27196_27240 : H12AffineEnvironment.transform 17 65665 env27196 = env27240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env27196 == env27240) = true)

theorem identity27240 : scanCanonicalize (H12AffineFastState.compose env27240 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5384) := by decide +kernel

theorem selectedBound27240 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env27241 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5384,1296,5205,65536,69990,65665,4417,5204,4096,5276,70710,66897,192,65831,1151,69942,1296,67651,5381,5376,257,69926,1345,5953]

theorem envBound27241 : H12AffineFastState.Bounded env27241 := by
  intro p hp
  have h : env27241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27240_27241 : H12AffineEnvironment.transform 12 5384 env27240 = env27241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5384 env27240 == env27241) = true)

def env27242 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1556,796,1296,577,65536,67442,65665,1877,576,1556,648,66082,66897,192,65831,1151,67362,1296,67651,785,788,257,67378,1345,341]

theorem envBound27242 : H12AffineFastState.Bounded env27242 := by
  intro p hp
  have h : env27242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27241_27242 : H12AffineEnvironment.transform 11 1556 env27241 = env27242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env27241 == env27242) = true)

def env27243 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,836,796,64,577,65536,66082,65665,517,576,836,648,66082,65537,192,65831,303,66162,64,67651,785,788,257,66146,17,341]

theorem envBound27243 : H12AffineFastState.Bounded env27243 := by
  intro p hp
  have h : env27243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27242_27243 : H12AffineEnvironment.transform 9 336 env27242 = env27243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env27242 == env27243) = true)

theorem identity27243 : scanCanonicalize (H12AffineFastState.compose env27243 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 419) := by decide +kernel

theorem selectedBound27243 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env27244 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,836,796,64,577,419,897,290,517,576,836,648,897,418,192,132,303,977,64,2528,785,788,257,961,17,341]

theorem envBound27244 : H12AffineFastState.Bounded env27244 := by
  intro p hp
  have h : env27244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27243_27244 : H12AffineEnvironment.transform 15 419 env27243 = env27244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 419 env27243 == env27244) = true)

def env27245 : List Nat := [2,4,8,16,32,64,128,256,324,336,2048,0,88,64,261,419,197,290,321,260,0,460,197,418,192,132,303,149,64,2528,85,80,257,133,17,341]

theorem envBound27245 : H12AffineFastState.Bounded env27245 := by
  intro p hp
  have h : env27245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27244_27245 : H12AffineEnvironment.transform 8 324 env27244 = env27245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 324 env27244 == env27245) = true)

theorem identity27245 : scanCanonicalize (H12AffineFastState.compose env27245 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound27245 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env27246 : List Nat := [2,4,8,16,32,64,128,21,81,69,2048,0,88,64,16,182,197,55,84,17,0,217,197,183,192,132,58,149,64,2293,85,80,20,133,17,64]

theorem envBound27246 : H12AffineFastState.Bounded env27246 := by
  intro p hp
  have h : env27246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27245_27246 : H12AffineEnvironment.transform 7 21 env27245 = env27246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env27245 == env27246) = true)

theorem identity27246 : scanCanonicalize (H12AffineFastState.compose env27246 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(6+1) ^^^ 69) := by decide +kernel

theorem selectedBound27246 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env27247 : List Nat := [2,4,8,16,32,64,69,21,81,69,2048,0,88,64,16,115,0,55,84,17,0,28,0,114,5,65,58,80,64,2096,85,80,20,64,17,64]

theorem envBound27247 : H12AffineFastState.Bounded env27247 := by
  intro p hp
  have h : env27247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27246_27247 : H12AffineEnvironment.transform 6 69 env27246 = env27247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 69 env27246 == env27247) = true)

theorem identity27247 : scanCanonicalize (H12AffineFastState.compose env27247 (packedSelected [0,3,5,7,11,12,15] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound27247 : packedSelected [0,3,5,7,11,12,15] rootPS < 2^1333 := by decide +kernel

def env27248 : List Nat := [2,4,8,16,0,64,69,21,81,69,2048,0,88,64,16,83,0,23,84,17,0,28,0,82,5,65,26,80,64,2064,85,80,20,64,17,64]

theorem envBound27248 : H12AffineFastState.Bounded env27248 := by
  intro p hp
  have h : env27248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27247_27248 : H12AffineEnvironment.transform 4 0 env27247 = env27248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env27247 == env27248) = true)

theorem identity27248 : scanCanonicalize (H12AffineFastState.compose env27248 (packedSelected [0,1,2,3,5,7,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 70) := by decide +kernel

theorem selectedBound27248 : packedSelected [0,1,2,3,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env27249 : List Nat := [2,4,8,16,0,64,69,21,81,69,70,0,88,64,16,83,0,23,84,17,0,28,0,82,5,65,26,80,64,86,85,80,20,64,17,64]

theorem envBound27249 : H12AffineFastState.Bounded env27249 := by
  intro p hp
  have h : env27249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27248_27249 : H12AffineEnvironment.transform 10 70 env27248 = env27249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 70 env27248 == env27249) = true)

theorem identity27249 : scanCanonicalize (H12AffineFastState.compose env27249 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound27249 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env27250 : List Nat := [2,4,5,16,0,64,69,21,81,69,70,0,85,64,16,83,0,23,84,17,0,17,0,82,5,65,23,80,64,86,85,80,20,64,17,64]

theorem envBound27250 : H12AffineFastState.Bounded env27250 := by
  intro p hp
  have h : env27250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27249_27250 : H12AffineEnvironment.transform 2 5 env27249 = env27250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env27249 == env27250) = true)

def env27251 : List Nat := [2,4,8,16,32,64,128,256,325,336,2048,1,89,64,260,419,196,290,320,261,1,461,196,418,192,132,303,148,64,2528,84,81,257,132,17,341]

theorem envBound27251 : H12AffineFastState.Bounded env27251 := by
  intro p hp
  have h : env27251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27244_27251 : H12AffineEnvironment.transform 8 325 env27244 = env27251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 325 env27244 == env27251) = true)

theorem identity27251 : scanCanonicalize (H12AffineFastState.compose env27251 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound27251 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env27252 : List Nat := [2,4,8,16,32,64,128,4,65,84,2048,1,89,64,0,167,196,38,68,1,1,201,196,166,192,132,43,148,64,2276,84,81,5,132,17,81]

theorem envBound27252 : H12AffineFastState.Bounded env27252 := by
  intro p hp
  have h : env27252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27251_27252 : H12AffineEnvironment.transform 7 4 env27251 = env27252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env27251 == env27252) = true)

theorem identity27252 : scanCanonicalize (H12AffineFastState.compose env27252 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound27252 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env27253 : List Nat := [2,4,8,16,32,17,128,4,16,5,2048,1,8,17,0,167,149,38,21,1,1,152,149,166,145,132,43,148,17,2229,5,0,5,132,17,0]

theorem envBound27253 : H12AffineFastState.Bounded env27253 := by
  intro p hp
  have h : env27253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27252_27253 : H12AffineEnvironment.transform 5 17 env27252 = env27253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27252 == env27253) = true)

theorem identity27253 : scanCanonicalize (H12AffineFastState.compose env27253 (packedSelected [0,2,3,7,8,11,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 20) := by decide +kernel

theorem selectedBound27253 : packedSelected [0,2,3,7,8,11,12,15] rootPS < 2^1333 := by decide +kernel

def env27254 : List Nat := [2,4,8,16,32,17,20,4,16,5,2048,1,8,17,0,51,1,38,21,1,1,12,1,50,5,16,43,0,17,2081,5,0,5,16,17,0]

theorem envBound27254 : H12AffineFastState.Bounded env27254 := by
  intro p hp
  have h : env27254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27253_27254 : H12AffineEnvironment.transform 6 20 env27253 = env27254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 20 env27253 == env27254) = true)

theorem identity27254 : scanCanonicalize (H12AffineFastState.compose env27254 (packedSelected [1,2,3,8] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound27254 : packedSelected [1,2,3,8] rootPS < 2^1333 := by decide +kernel

def env27255 : List Nat := [2,4,8,16,17,17,20,4,16,5,2048,1,8,17,0,2,1,23,21,1,1,12,1,3,5,16,26,0,17,2064,5,0,5,16,17,0]

theorem envBound27255 : H12AffineFastState.Bounded env27255 := by
  intro p hp
  have h : env27255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27254_27255 : H12AffineEnvironment.transform 4 17 env27254 = env27255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env27254 == env27255) = true)

theorem identity27255 : scanCanonicalize (H12AffineFastState.compose env27255 (packedSelected [2,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound27255 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env27256 : List Nat := [2,4,3,16,17,17,20,4,16,5,2048,1,3,17,0,2,1,23,21,1,1,7,1,3,5,16,17,0,17,2064,5,0,5,16,17,0]

theorem envBound27256 : H12AffineFastState.Bounded env27256 := by
  intro p hp
  have h : env27256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27255_27256 : H12AffineEnvironment.transform 2 3 env27255 = env27256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env27255 == env27256) = true)

theorem identity27256 : scanCanonicalize (H12AffineFastState.compose env27256 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 7) := by decide +kernel

theorem selectedBound27256 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27257 : List Nat := [2,4,3,16,17,17,20,4,16,5,7,1,3,17,0,2,1,23,21,1,1,7,1,3,5,16,17,0,17,23,5,0,5,16,17,0]

theorem envBound27257 : H12AffineFastState.Bounded env27257 := by
  intro p hp
  have h : env27257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27256_27257 : H12AffineEnvironment.transform 10 7 env27256 = env27257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 7 env27256 == env27257) = true)

theorem identity27257 : scanCanonicalize (H12AffineFastState.compose env27257 (packedSelected [1,2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound27257 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env27258 : List Nat := [2,4,3,1,0,0,5,4,1,5,7,1,3,0,0,2,1,6,4,1,1,7,1,3,5,1,0,0,0,6,5,0,5,1,0,0]

theorem envBound27258 : H12AffineFastState.Bounded env27258 := by
  intro p hp
  have h : env27258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27257_27258 : H12AffineEnvironment.transform 3 1 env27257 = env27258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env27257 == env27258) = true)

theorem identity27258 : scanCanonicalize (H12AffineFastState.compose env27258 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound27258 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27259 : List Nat := [0,4,1,1,0,0,5,4,1,5,5,1,1,0,0,0,1,4,4,1,1,5,1,1,5,1,0,0,0,4,5,0,5,1,0,0]

theorem envBound27259 : H12AffineFastState.Bounded env27259 := by
  intro p hp
  have h : env27259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27258_27259 : H12AffineEnvironment.transform 0 0 env27258 = env27259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env27258 == env27259) = true)

def env27260 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,837,796,65,577,65536,66083,65665,516,576,837,648,66082,65536,192,65831,302,66163,65,67651,785,788,257,66147,16,341]

theorem envBound27260 : H12AffineFastState.Bounded env27260 := by
  intro p hp
  have h : env27260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27242_27260 : H12AffineEnvironment.transform 9 337 env27242 = env27260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env27242 == env27260) = true)

theorem identity27260 : scanCanonicalize (H12AffineFastState.compose env27260 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 742) := by decide +kernel

theorem selectedBound27260 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env27261 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,837,796,65,577,742,197,615,516,576,837,648,196,742,192,961,302,149,65,2725,785,788,257,133,16,341]

theorem envBound27261 : H12AffineFastState.Bounded env27261 := by
  intro p hp
  have h : env27261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27260_27261 : H12AffineEnvironment.transform 15 742 env27260 = env27261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 742 env27260 == env27261) = true)

def env27262 : List Nat := [2,4,8,16,32,64,128,256,324,337,2048,1,88,65,261,418,197,291,320,260,1,460,196,418,192,133,302,149,65,2529,85,80,257,133,16,341]

theorem envBound27262 : H12AffineFastState.Bounded env27262 := by
  intro p hp
  have h : env27262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27261_27262 : H12AffineEnvironment.transform 8 324 env27261 = env27262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 324 env27261 == env27262) = true)

theorem identity27262 : scanCanonicalize (H12AffineFastState.compose env27262 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound27262 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env27263 : List Nat := [2,4,8,16,32,64,128,5,65,84,2048,1,88,65,0,167,197,38,69,1,1,201,196,167,192,133,43,149,65,2276,85,80,4,133,16,80]

theorem envBound27263 : H12AffineFastState.Bounded env27263 := by
  intro p hp
  have h : env27263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27262_27263 : H12AffineEnvironment.transform 7 5 env27262 = env27263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env27262 == env27263) = true)

theorem identity27263 : scanCanonicalize (H12AffineFastState.compose env27263 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound27263 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env27264 : List Nat := [2,4,8,16,32,17,128,5,16,5,2048,1,9,16,0,167,148,38,20,1,1,152,149,167,145,133,43,149,16,2229,4,1,4,133,16,1]

theorem envBound27264 : H12AffineFastState.Bounded env27264 := by
  intro p hp
  have h : env27264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27263_27264 : H12AffineEnvironment.transform 5 17 env27263 = env27264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env27263 == env27264) = true)

theorem identity27264 : scanCanonicalize (H12AffineFastState.compose env27264 (packedSelected [0,2,3,7,8,11,12,15] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound27264 : packedSelected [0,2,3,7,8,11,12,15] rootPS < 2^1333 := by decide +kernel

def env27265 : List Nat := [2,4,8,0,32,1,128,5,0,5,2048,1,9,0,0,167,132,38,4,1,1,136,133,167,129,133,43,133,0,2213,4,1,4,133,0,1]

theorem envBound27265 : H12AffineFastState.Bounded env27265 := by
  intro p hp
  have h : env27265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27264_27265 : H12AffineEnvironment.transform 3 0 env27264 = env27265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env27264 == env27265) = true)

theorem identity27265 : scanCanonicalize (H12AffineFastState.compose env27265 (packedSelected [1,2,5,8] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound27265 : packedSelected [1,2,5,8] rootPS < 2^1333 := by decide +kernel

def env27266 : List Nat := [2,4,8,0,11,1,128,5,0,5,2048,1,9,0,0,140,132,13,4,1,1,136,133,140,129,133,0,133,0,2190,4,1,4,133,0,1]

theorem envBound27266 : H12AffineFastState.Bounded env27266 := by
  intro p hp
  have h : env27266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27265_27266 : H12AffineEnvironment.transform 4 11 env27265 = env27266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env27265 == env27266) = true)

theorem identity27266 : scanCanonicalize (H12AffineFastState.compose env27266 (packedSelected [1,2,5] rootPS)) = affineNative (2^(10+1) ^^^ 13) := by decide +kernel

theorem selectedBound27266 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env27267 : List Nat := [2,4,8,0,11,1,128,5,0,5,13,1,9,0,0,140,132,13,4,1,1,136,133,140,129,133,0,133,0,131,4,1,4,133,0,1]

theorem envBound27267 : H12AffineFastState.Bounded env27267 := by
  intro p hp
  have h : env27267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27266_27267 : H12AffineEnvironment.transform 10 13 env27266 = env27267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 13 env27266 == env27267) = true)

theorem identity27267 : scanCanonicalize (H12AffineFastState.compose env27267 (packedSelected [1,2] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound27267 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env27268 : List Nat := [2,4,8,0,11,1,15,5,0,5,13,1,9,0,0,3,11,13,4,1,1,7,10,3,14,10,0,10,0,12,4,1,4,10,0,1]

theorem envBound27268 : H12AffineFastState.Bounded env27268 := by
  intro p hp
  have h : env27268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27267_27268 : H12AffineEnvironment.transform 6 15 env27267 = env27268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env27267 == env27268) = true)

theorem identity27268 : scanCanonicalize (H12AffineFastState.compose env27268 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound27268 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env27269 : List Nat := [0,4,8,0,9,1,13,5,0,5,13,1,9,0,0,1,9,13,4,1,1,5,8,1,12,8,0,8,0,12,4,1,4,8,0,1]

theorem envBound27269 : H12AffineFastState.Bounded env27269 := by
  intro p hp
  have h : env27269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27268_27269 : H12AffineEnvironment.transform 0 0 env27268 = env27269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env27268 == env27269) = true)

theorem identity27269 : scanCanonicalize (H12AffineFastState.compose env27269 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound27269 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env27270 : List Nat := [0,4,0,0,1,1,5,5,0,5,5,1,1,0,0,1,1,5,4,1,1,5,0,1,4,0,0,0,0,4,4,1,4,0,0,1]

theorem envBound27270 : H12AffineFastState.Bounded env27270 := by
  intro p hp
  have h : env27270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27269_27270 : H12AffineEnvironment.transform 2 0 env27269 = env27270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env27269 == env27270) = true)

theorem identity27270 : scanCanonicalize (H12AffineFastState.compose env27270 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound27270 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env27271 : List Nat := [0,1,0,0,1,1,0,0,0,0,0,1,1,0,0,1,1,0,1,1,1,0,0,1,1,0,0,0,0,1,1,1,1,0,0,1]

theorem envBound27271 : H12AffineFastState.Bounded env27271 := by
  intro p hp
  have h : env27271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27270_27271 : H12AffineEnvironment.transform 1 1 env27270 = env27271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env27270 == env27271) = true)

def env27272 : List Nat := [2,4,8,16,32,64,128,256,325,337,2048,0,89,65,260,419,197,290,321,261,0,461,196,419,192,132,302,149,65,2528,84,81,257,133,16,341]

theorem envBound27272 : H12AffineFastState.Bounded env27272 := by
  intro p hp
  have h : env27272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27261_27272 : H12AffineEnvironment.transform 8 325 env27261 = env27272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 325 env27261 == env27272) = true)

theorem identity27272 : scanCanonicalize (H12AffineFastState.compose env27272 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound27272 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env27273 : List Nat := [2,4,8,16,32,64,128,21,80,68,2048,0,89,65,17,182,197,55,84,16,0,216,196,182,192,132,59,149,65,2293,84,81,20,133,16,64]

theorem envBound27273 : H12AffineFastState.Bounded env27273 := by
  intro p hp
  have h : env27273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27272_27273 : H12AffineEnvironment.transform 7 21 env27272 = env27273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env27272 == env27273) = true)

theorem identity27273 : scanCanonicalize (H12AffineFastState.compose env27273 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(6+1) ^^^ 69) := by decide +kernel

theorem selectedBound27273 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env27274 : List Nat := [2,4,8,16,32,64,69,21,80,68,2048,0,89,65,17,115,0,55,84,16,0,29,1,115,5,65,59,80,65,2096,84,81,20,64,16,64]

theorem envBound27274 : H12AffineFastState.Bounded env27274 := by
  intro p hp
  have h : env27274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27273_27274 : H12AffineEnvironment.transform 6 69 env27273 = env27274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 69 env27273 == env27274) = true)

theorem identity27274 : scanCanonicalize (H12AffineFastState.compose env27274 (packedSelected [0,3,5,7,11,12,15] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound27274 : packedSelected [0,3,5,7,11,12,15] rootPS < 2^1333 := by decide +kernel

def env27275 : List Nat := [2,4,8,16,16,64,69,21,80,68,2048,0,89,65,17,67,0,7,84,16,0,29,1,67,5,65,11,80,65,2048,84,81,20,64,16,64]

theorem envBound27275 : H12AffineFastState.Bounded env27275 := by
  intro p hp
  have h : env27275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27274_27275 : H12AffineEnvironment.transform 4 16 env27274 = env27275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env27274 == env27275) = true)

theorem identity27275 : scanCanonicalize (H12AffineFastState.compose env27275 (packedSelected [0,1,5,7,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound27275 : packedSelected [0,1,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env27276 : List Nat := [2,4,8,16,16,64,69,21,80,68,17,0,89,65,17,67,0,7,84,16,0,29,1,67,5,65,11,80,65,17,84,81,20,64,16,64]

theorem envBound27276 : H12AffineFastState.Bounded env27276 := by
  intro p hp
  have h : env27276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27275_27276 : H12AffineEnvironment.transform 10 17 env27275 = env27276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env27275 == env27276) = true)

theorem identity27276 : scanCanonicalize (H12AffineFastState.compose env27276 (packedSelected [0,4,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 29) := by decide +kernel

theorem selectedBound27276 : packedSelected [0,4,5,8] rootPS < 2^1333 := by decide +kernel

def env27277 : List Nat := [2,4,8,16,16,29,24,21,13,25,17,0,4,28,17,30,0,7,9,16,0,29,1,30,5,28,11,13,28,17,9,12,20,29,16,29]

theorem envBound27277 : H12AffineFastState.Bounded env27277 := by
  intro p hp
  have h : env27277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27276_27277 : H12AffineEnvironment.transform 5 29 env27276 = env27277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 29 env27276 == env27277) = true)

def env27278 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1557,797,1296,576,65536,67443,65665,1876,577,1557,649,66083,66897,192,65831,1151,67363,1296,67651,784,789,257,67379,1345,340]

theorem envBound27278 : H12AffineFastState.Bounded env27278 := by
  intro p hp
  have h : env27278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27241_27278 : H12AffineEnvironment.transform 11 1557 env27241 = env27278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env27241 == env27278) = true)

def env27279 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,837,797,64,576,65536,66083,65665,516,577,837,649,66083,65537,192,65831,303,66163,64,67651,784,789,257,66147,17,340]

theorem envBound27279 : H12AffineFastState.Bounded env27279 := by
  intro p hp
  have h : env27279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27278_27279 : H12AffineEnvironment.transform 9 336 env27278 = env27279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env27278 == env27279) = true)

theorem identity27279 : scanCanonicalize (H12AffineFastState.compose env27279 (packedSelected [1,8,28] rootPS)) = affineNative (2^(8+1) ^^^ 401) := by decide +kernel

theorem selectedBound27279 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env27280 : List Nat := [2,4,8,16,32,64,128,256,401,336,2048,212,140,64,465,65536,65970,65665,405,464,212,280,65970,65537,192,65831,303,66018,64,67651,129,132,257,66034,17,340]

theorem envBound27280 : H12AffineFastState.Bounded env27280 := by
  intro p hp
  have h : env27280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27279_27280 : H12AffineEnvironment.transform 8 401 env27279 = env27280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 401 env27279 == env27280) = true)

def env27281 : List Nat := [2,4,8,0,32,64,128,256,385,320,2048,196,140,64,449,65536,65954,65665,389,448,196,264,65954,65537,192,65831,303,66018,64,67651,129,132,257,66018,1,324]

theorem envBound27281 : H12AffineFastState.Bounded env27281 := by
  intro p hp
  have h : env27281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27280_27281 : H12AffineEnvironment.transform 3 0 env27280 = env27281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env27280 == env27281) = true)

theorem identity27281 : scanCanonicalize (H12AffineFastState.compose env27281 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 193) := by decide +kernel

theorem selectedBound27281 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env27282 : List Nat := [2,4,8,0,32,64,128,193,64,129,2048,196,140,64,0,65536,65635,65665,68,1,196,201,65635,65537,192,65766,238,65571,64,67651,129,132,192,65571,1,133]

theorem envBound27282 : H12AffineFastState.Bounded env27282 := by
  intro p hp
  have h : env27282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27281_27282 : H12AffineEnvironment.transform 7 193 env27281 = env27282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 193 env27281 == env27282) = true)

theorem identity27282 : scanCanonicalize (H12AffineFastState.compose env27282 (packedSelected [0,2,3,4,5,7,9,10,11,13,16,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 143) := by decide +kernel

theorem selectedBound27282 : packedSelected [0,2,3,4,5,7,9,10,11,13,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env27283 : List Nat := [2,4,8,0,32,64,128,193,64,129,143,196,140,64,0,65536,65635,65665,68,1,196,201,65635,65537,192,65766,238,65571,64,65740,129,132,192,65571,1,133]

theorem envBound27283 : H12AffineFastState.Bounded env27283 := by
  intro p hp
  have h : env27283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27282_27283 : H12AffineEnvironment.transform 10 143 env27282 = env27283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 143 env27282 == env27283) = true)

theorem identity27283 : scanCanonicalize (H12AffineFastState.compose env27283 (packedSelected [1,13,15] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound27283 : packedSelected [1,13,15] rootPS < 2^1333 := by decide +kernel

def env27284 : List Nat := [2,2,8,0,32,64,128,193,64,129,137,194,138,64,0,65536,65635,65665,66,1,194,201,65635,65537,192,65760,232,65571,64,65738,129,130,192,65571,1,131]

theorem envBound27284 : H12AffineFastState.Bounded env27284 := by
  intro p hp
  have h : env27284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27283_27284 : H12AffineEnvironment.transform 1 2 env27283 = env27284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env27283 == env27284) = true)

theorem identity27284 : scanCanonicalize (H12AffineFastState.compose env27284 (packedSelected [0,1,2,7,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 43) := by decide +kernel

theorem selectedBound27284 : packedSelected [0,1,2,7,10,11] rootPS < 2^1333 := by decide +kernel

def env27285 : List Nat := [2,2,8,0,32,43,128,170,43,129,137,169,138,43,0,65536,65544,65665,41,1,169,162,65544,65537,171,65675,131,65571,43,65697,129,130,171,65571,1,131]

theorem envBound27285 : H12AffineFastState.Bounded env27285 := by
  intro p hp
  have h : env27285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27284_27285 : H12AffineEnvironment.transform 5 43 env27284 = env27285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 43 env27284 == env27285) = true)

theorem identity27285 : scanCanonicalize (H12AffineFastState.compose env27285 (packedSelected [0,1,3,4,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound27285 : packedSelected [0,1,3,4,8] rootPS < 2^1333 := by decide +kernel

def env27286 : List Nat := [2,2,8,0,1,10,128,139,10,129,137,136,138,10,0,65536,65544,65665,8,1,136,131,65544,65537,138,65675,131,65538,10,65664,129,130,138,65538,1,131]

theorem envBound27286 : H12AffineFastState.Bounded env27286 := by
  intro p hp
  have h : env27286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27285_27286 : H12AffineEnvironment.transform 4 1 env27285 = env27286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env27285 == env27286) = true)

theorem identity27286 : scanCanonicalize (H12AffineFastState.compose env27286 (packedSelected [2,3] rootPS)) = affineNative (2^(15+1) ^^^ 8) := by decide +kernel

theorem selectedBound27286 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env27287 : List Nat := [2,2,8,0,1,10,128,139,10,129,137,136,138,10,0,8,0,137,8,1,136,131,0,9,138,131,131,10,10,136,129,130,138,10,1,131]

theorem envBound27287 : H12AffineFastState.Bounded env27287 := by
  intro p hp
  have h : env27287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27286_27287 : H12AffineEnvironment.transform 15 8 env27286 = env27287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8 env27286 == env27287) = true)

theorem identity27287 : scanCanonicalize (H12AffineFastState.compose env27287 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound27287 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env27288 : List Nat := [2,2,3,0,1,1,128,128,1,129,130,131,129,1,0,3,0,130,3,1,131,131,0,2,129,131,131,1,1,131,129,130,129,1,1,131]

theorem envBound27288 : H12AffineFastState.Bounded env27288 := by
  intro p hp
  have h : env27288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27287_27288 : H12AffineEnvironment.transform 2 3 env27287 = env27288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env27287 == env27288) = true)

theorem identity27288 : scanCanonicalize (H12AffineFastState.compose env27288 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound27288 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env27289 : List Nat := [2,2,3,0,1,1,2,2,1,3,0,1,3,1,0,3,0,0,3,1,1,1,0,2,3,1,1,1,1,1,3,0,3,1,1,1]

theorem envBound27289 : H12AffineFastState.Bounded env27289 := by
  intro p hp
  have h : env27289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27288_27289 : H12AffineEnvironment.transform 6 2 env27288 = env27289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env27288 == env27289) = true)

def env27290 : List Nat := [2,4,8,1,32,64,128,256,384,321,2048,197,140,64,448,65536,65955,65665,388,449,197,265,65955,65537,192,65831,303,66018,64,67651,129,132,257,66019,0,325]

theorem envBound27290 : H12AffineFastState.Bounded env27290 := by
  intro p hp
  have h : env27290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27280_27290 : H12AffineEnvironment.transform 3 1 env27280 = env27290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env27280 == env27290) = true)

theorem identity27290 : scanCanonicalize (H12AffineFastState.compose env27290 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound27290 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env27291 : List Nat := [2,4,8,1,32,64,128,4,132,69,2048,197,140,64,196,65536,65703,65665,128,197,197,13,65703,65537,192,65571,43,65766,64,67651,129,132,5,65767,0,65]

end H12CloudChart2