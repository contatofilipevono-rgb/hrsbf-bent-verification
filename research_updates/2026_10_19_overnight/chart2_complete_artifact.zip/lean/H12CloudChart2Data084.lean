import H12CloudChart2Data083

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env20600 : List Nat := [2,4,8,16,32,17,128,172,136,1024,0,1212,161,1212,137,170,1213,1,1025,136,1212,169,16,139,41,17,1,1212,1213,0,1193,137,173,1,1213,136]

theorem envBound20600 : H12AffineFastState.Bounded env20600 := by
  intro p hp
  have h : env20600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20599_20600 : H12AffineEnvironment.transform 12 161 env20599 = env20600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env20599 == env20600) = true)

def env20601 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,4096,8192,4177,136,263,1344,8353,1025,137,4096,8200,5457,139,8328,5377,428,4177,1297,8461,1285,13461,257,5308,1344,137]

theorem envBound20601 : H12AffineFastState.Bounded env20601 := by
  intro p hp
  have h : env20601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20591_20601 : H12AffineEnvironment.transform 8 137 env20591 = env20601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env20591 == env20601) = true)

theorem identity20601 : scanCanonicalize (H12AffineFastState.compose env20601 (packedSelected [2,4] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound20601 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env20602 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,4096,121,4177,136,263,1344,216,1025,137,4096,113,5457,139,241,5377,428,4177,1297,372,1285,5356,257,5308,1344,137]

theorem envBound20602 : H12AffineFastState.Bounded env20602 := by
  intro p hp
  have h : env20602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20601_20602 : H12AffineEnvironment.transform 12 121 env20601 = env20602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env20601 == env20602) = true)

theorem identity20602 : scanCanonicalize (H12AffineFastState.compose env20602 (packedSelected [1,3,5] rootPS)) = affineNative (2^(11+1) ^^^ 1344) := by decide +kernel

theorem selectedBound20602 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env20603 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,1344,121,1297,136,263,1344,216,1025,137,1344,113,17,139,241,65,428,1297,1297,372,1285,428,257,508,1344,137]

theorem envBound20603 : H12AffineFastState.Bounded env20603 := by
  intro p hp
  have h : env20603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20602_20603 : H12AffineEnvironment.transform 11 1344 env20602 = env20603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env20602 == env20603) = true)

theorem identity20603 : scanCanonicalize (H12AffineFastState.compose env20603 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound20603 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20604 : List Nat := [2,4,8,16,32,64,128,172,137,1024,0,1260,121,1213,136,171,1260,216,1025,137,1260,113,17,139,241,65,0,1213,1213,216,1193,0,173,80,1260,137]

theorem envBound20604 : H12AffineFastState.Bounded env20604 := by
  intro p hp
  have h : env20604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20603_20604 : H12AffineEnvironment.transform 7 172 env20603 = env20604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env20603 == env20604) = true)

theorem identity20604 : scanCanonicalize (H12AffineFastState.compose env20604 (packedSelected [7] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound20604 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env20605 : List Nat := [2,4,8,16,32,64,88,116,81,1024,0,1076,121,1125,80,115,1076,0,1025,81,1076,113,17,83,41,65,0,1125,1125,0,1137,0,117,80,1076,81]

theorem envBound20605 : H12AffineFastState.Bounded env20605 := by
  intro p hp
  have h : env20605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20604_20605 : H12AffineEnvironment.transform 6 88 env20604 = env20605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env20604 == env20605) = true)

def env20606 : List Nat := [2,4,8,16,0,64,88,84,81,1024,0,1044,89,1093,80,83,1044,0,1025,81,1044,81,17,83,9,65,0,1093,1093,0,1105,0,85,80,1044,81]

theorem envBound20606 : H12AffineFastState.Bounded env20606 := by
  intro p hp
  have h : env20606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20605_20606 : H12AffineEnvironment.transform 4 0 env20605 = env20606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20605 == env20606) = true)

def leafEnv20606 : List Nat := [2,4,8,16,0,64,88,84,81,1024,0,1044,89,1093,80,83,1044,0,1025,81,1044,81,17,83,1104,9,1,65,0,1093,1093,0,1105,0,85,80,5,2,1044,81,0,1093,1]

def active20606 : List Nat := [0,1,2,3,5,9]

def tree20606 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20606 : H12WitnessSearch.Good tree20606 := H12GlobalWitnessIndex.good

theorem leafIdentity20606 : H12AffineFastState.composeSystem env20606 rootObs = leafEnv20606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20606 rootObs == leafEnv20606) = true)

theorem terminalChecked20606 : H12PackedTerminal.terminalCheckFast leafEnv20606 active20606 tree20606 = true := by decide +kernel

def env20607 : List Nat := [2,4,8,16,1,64,88,85,81,1024,0,1045,88,1092,80,82,1045,0,1025,81,1045,80,17,83,8,65,0,1092,1092,0,1104,0,84,80,1045,81]

theorem envBound20607 : H12AffineFastState.Bounded env20607 := by
  intro p hp
  have h : env20607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20605_20607 : H12AffineEnvironment.transform 4 1 env20605 = env20607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env20605 == env20607) = true)

theorem identity20607 : scanCanonicalize (H12AffineFastState.compose env20607 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound20607 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20608 : List Nat := [2,4,8,16,1,16,8,5,1,1024,0,1045,8,1044,0,2,1045,0,1025,1,1045,0,17,3,8,17,0,1044,1044,0,1024,0,4,0,1045,1]

theorem envBound20608 : H12AffineFastState.Bounded env20608 := by
  intro p hp
  have h : env20608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20607_20608 : H12AffineEnvironment.transform 5 16 env20607 = env20608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20607 == env20608) = true)

def leafEnv20608 : List Nat := [2,4,8,16,1,16,8,5,1,1024,0,1045,8,1044,0,2,1045,0,1025,1,1045,0,17,3,1025,8,1,17,0,1044,1044,0,1024,0,4,0,5,3,1045,1,0,1044,1]

def active20608 : List Nat := [0,1,2,3,9]

def tree20608 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20608 : H12WitnessSearch.Good tree20608 := H12GlobalWitnessIndex.good

theorem leafIdentity20608 : H12AffineFastState.composeSystem env20608 rootObs = leafEnv20608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20608 rootObs == leafEnv20608) = true)

theorem terminalChecked20608 : H12PackedTerminal.terminalCheckFast leafEnv20608 active20608 tree20608 = true := by decide +kernel

def env20609 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1344,262144,304169,32769,4096,8200,17664,98564,8328,320888,33061,16384,324968,8460,1285,4294967296,257,4295074214,1344,512]

theorem envBound20609 : H12AffineFastState.Bounded env20609 := by
  intro p hp
  have h : env20609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20570_20609 : H12AffineEnvironment.transform 18 304169 env20570 = env20609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 304169 env20570 == env20609) = true)

theorem identity20609 : scanCanonicalize (H12AffineFastState.compose env20609 (packedSelected [4,9,18] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound20609 : packedSelected [4,9,18] rootPS < 2^1333 := by decide +kernel

def env20610 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,268,16384,32768,65536,1344,262144,296229,32769,4096,260,17664,98564,388,312436,33061,16384,316516,0,1285,4294967296,257,4295065770,1344,512]

theorem envBound20610 : H12AffineFastState.Bounded env20610 := by
  intro p hp
  have h : env20610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20609_20610 : H12AffineEnvironment.transform 12 268 env20609 = env20610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env20609 == env20610) = true)

theorem identity20610 : scanCanonicalize (H12AffineFastState.compose env20610 (packedSelected [20,23] rootPS)) = affineNative (2^(17+1) ^^^ 0) := by decide +kernel

theorem selectedBound20610 : packedSelected [20,23] rootPS < 2^1333 := by decide +kernel

def env20611 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,268,16384,32768,65536,1344,0,34085,32769,4096,260,17664,98564,388,50292,33061,16384,54372,0,1285,4294967296,257,4295065770,1344,512]

theorem envBound20611 : H12AffineFastState.Bounded env20611 := by
  intro p hp
  have h : env20611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20610_20611 : H12AffineEnvironment.transform 17 0 env20610 = env20611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 0 env20610 == env20611) = true)

def env20612 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1345,262144,524288,32769,4096,8200,17665,98565,8328,541008,795917,16384,545088,1073741824,1284,4294967296,257,4295074215,1344,512]

theorem envBound20612 : H12AffineFastState.Bounded env20612 := by
  intro p hp
  have h : env20612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20568_20612 : H12AffineEnvironment.transform 16 1345 env20568 = env20612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env20568 == env20612) = true)

theorem identity20612 : scanCanonicalize (H12AffineFastState.compose env20612 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 820596) := by decide +kernel

theorem selectedBound20612 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env20613 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1345,262144,524288,32769,4096,8200,17665,98565,8328,541008,795917,16384,545088,820596,1284,4294967296,257,4295074215,1344,512]

theorem envBound20613 : H12AffineFastState.Bounded env20613 := by
  intro p hp
  have h : env20613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20612_20613 : H12AffineEnvironment.transform 29 820596 env20612 = env20613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 820596 env20612 == env20613) = true)

theorem identity20613 : scanCanonicalize (H12AffineFastState.compose env20613 (packedSelected [4,9,16] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound20613 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env20614 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1345,262144,1025,32769,4096,8200,17665,98565,8328,17745,270604,16384,21825,295285,1284,4294967296,257,4295074215,1344,512]

theorem envBound20614 : H12AffineFastState.Bounded env20614 := by
  intro p hp
  have h : env20614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20613_20614 : H12AffineEnvironment.transform 18 1025 env20613 = env20614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env20613 == env20614) = true)

theorem identity20614 : scanCanonicalize (H12AffineFastState.compose env20614 (packedSelected [1,5,8,15,17,21,24,38] rootPS)) = affineNative (2^(17+1) ^^^ 74231) := by decide +kernel

theorem selectedBound20614 : packedSelected [1,5,8,15,17,21,24,38] rootPS < 2^1333 := by decide +kernel

def env20615 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1345,74231,1025,32769,4096,8200,17665,98565,8328,17745,65787,16384,21825,106626,1284,4294967296,257,4295074215,1344,512]

theorem envBound20615 : H12AffineFastState.Bounded env20615 := by
  intro p hp
  have h : env20615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20614_20615 : H12AffineEnvironment.transform 17 74231 env20614 = env20615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 74231 env20614 == env20615) = true)

theorem identity20615 : scanCanonicalize (H12AffineFastState.compose env20615 (packedSelected [13,21] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound20615 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env20616 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,4177,32768,65536,1345,74231,1025,32769,4096,8200,5456,98565,8328,5376,65787,4177,1296,106626,1284,4294967296,257,4295074215,1344,512]

theorem envBound20616 : H12AffineFastState.Bounded env20616 := by
  intro p hp
  have h : env20616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20615_20616 : H12AffineEnvironment.transform 13 4177 env20615 = env20616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env20615 == env20616) = true)

theorem identity20616 : scanCanonicalize (H12AffineFastState.compose env20616 (packedSelected [3,5,10] rootPS)) = affineNative (2^(31+1) ^^^ 8320) := by decide +kernel

theorem selectedBound20616 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env20617 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,4177,32768,65536,1345,74231,1025,32769,4096,8200,5456,98565,8328,5376,65787,4177,1296,106626,1284,8320,257,98599,1344,512]

theorem envBound20617 : H12AffineFastState.Bounded env20617 := by
  intro p hp
  have h : env20617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20616_20617 : H12AffineEnvironment.transform 31 8320 env20616 = env20617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 8320 env20616 == env20617) = true)

theorem identity20617 : scanCanonicalize (H12AffineFastState.compose env20617 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound20617 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env20618 : List Nat := [2,4,8,16,32,17,128,256,512,1024,0,4096,8192,4096,32768,65536,1296,74150,1025,32769,4096,8200,5377,98565,8328,5376,65706,4096,1296,106626,1284,8320,257,98599,1297,512]

theorem envBound20618 : H12AffineFastState.Bounded env20618 := by
  intro p hp
  have h : env20618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20617_20618 : H12AffineEnvironment.transform 5 17 env20617 = env20618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20617 == env20618) = true)

theorem identity20618 : scanCanonicalize (H12AffineFastState.compose env20618 (packedSelected [3,8,12,13] rootPS)) = affineNative (2^(15+1) ^^^ 13715) := by decide +kernel

theorem selectedBound20618 : packedSelected [3,8,12,13] rootPS < 2^1333 := by decide +kernel

def env20619 : List Nat := [2,4,8,16,32,17,128,256,512,1024,0,4096,8192,4096,32768,13715,1296,5173,1025,32769,4096,8200,5377,46230,8328,5376,13625,4096,1296,38161,1284,8320,257,46260,1297,512]

theorem envBound20619 : H12AffineFastState.Bounded env20619 := by
  intro p hp
  have h : env20619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20618_20619 : H12AffineEnvironment.transform 15 13715 env20618 = env20619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13715 env20618 == env20619) = true)

theorem identity20619 : scanCanonicalize (H12AffineFastState.compose env20619 (packedSelected [3,5,12,17] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound20619 : packedSelected [3,5,12,17] rootPS < 2^1333 := by decide +kernel

def env20620 : List Nat := [2,4,8,16,32,17,128,256,512,1024,0,4096,8192,4096,136,13715,1296,5173,1025,137,4096,8200,5377,13342,8328,5376,13625,4096,1296,5529,1284,8320,257,13372,1297,512]

theorem envBound20620 : H12AffineFastState.Bounded env20620 := by
  intro p hp
  have h : env20620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20619_20620 : H12AffineEnvironment.transform 14 136 env20619 = env20620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env20619 == env20620) = true)

theorem identity20620 : scanCanonicalize (H12AffineFastState.compose env20620 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 1464) := by decide +kernel

theorem selectedBound20620 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env20621 : List Nat := [2,4,8,16,32,17,128,256,512,1024,0,1464,8192,1464,136,8235,1296,397,1025,137,1464,8200,185,8614,8328,184,8321,1464,1296,33,1284,8320,257,8580,1297,512]

theorem envBound20621 : H12AffineFastState.Bounded env20621 := by
  intro p hp
  have h : env20621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20620_20621 : H12AffineEnvironment.transform 11 1464 env20620 = env20621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1464 env20620 == env20621) = true)

theorem identity20621 : scanCanonicalize (H12AffineFastState.compose env20621 (packedSelected [1,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound20621 : packedSelected [1,8,12] rootPS < 2^1333 := by decide +kernel

def env20622 : List Nat := [2,4,8,16,32,17,128,256,512,1024,0,1464,388,1464,136,431,1296,397,1025,137,1464,396,185,34,268,184,261,1464,1296,33,1284,260,257,0,1297,512]

theorem envBound20622 : H12AffineFastState.Bounded env20622 := by
  intro p hp
  have h : env20622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20621_20622 : H12AffineEnvironment.transform 12 388 env20621 = env20622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env20621 == env20622) = true)

theorem identity20622 : scanCanonicalize (H12AffineFastState.compose env20622 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 188) := by decide +kernel

theorem selectedBound20622 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20623 : List Nat := [2,4,8,16,32,17,128,188,512,1024,0,1028,56,1028,136,19,1196,49,1025,137,1028,48,185,34,176,184,185,1028,1196,33,1208,184,189,0,1197,512]

theorem envBound20623 : H12AffineFastState.Bounded env20623 := by
  intro p hp
  have h : env20623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20622_20623 : H12AffineEnvironment.transform 7 188 env20622 = env20623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 188 env20622 == env20623) = true)

theorem identity20623 : scanCanonicalize (H12AffineFastState.compose env20623 (packedSelected [4,7] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound20623 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env20624 : List Nat := [2,4,8,16,32,17,128,188,16,1024,0,1028,56,1028,136,19,1196,49,1025,137,1028,48,185,34,176,184,185,1028,1196,33,1208,184,189,0,1197,16]

theorem envBound20624 : H12AffineFastState.Bounded env20624 := by
  intro p hp
  have h : env20624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20623_20624 : H12AffineEnvironment.transform 8 16 env20623 = env20624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env20623 == env20624) = true)

theorem identity20624 : scanCanonicalize (H12AffineFastState.compose env20624 (packedSelected [3] rootPS)) = affineNative (2^(9+1) ^^^ 157) := by decide +kernel

theorem selectedBound20624 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env20625 : List Nat := [2,4,8,16,32,17,128,188,16,157,0,153,56,153,136,19,49,49,156,137,153,48,185,34,176,184,185,153,49,33,37,184,189,0,48,16]

theorem envBound20625 : H12AffineFastState.Bounded env20625 := by
  intro p hp
  have h : env20625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20624_20625 : H12AffineEnvironment.transform 9 157 env20624 = env20625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 157 env20624 == env20625) = true)

theorem identity20625 : scanCanonicalize (H12AffineFastState.compose env20625 (packedSelected [2,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound20625 : packedSelected [2,4,5] rootPS < 2^1333 := by decide +kernel

def env20626 : List Nat := [2,4,8,16,32,17,8,52,16,21,0,17,56,17,0,19,49,49,20,1,17,48,49,34,56,48,49,17,49,33,37,48,53,0,48,16]

theorem envBound20626 : H12AffineFastState.Bounded env20626 := by
  intro p hp
  have h : env20626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20625_20626 : H12AffineEnvironment.transform 6 8 env20625 = env20626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20625 == env20626) = true)

theorem identity20626 : scanCanonicalize (H12AffineFastState.compose env20626 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound20626 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20627 : List Nat := [2,4,8,16,1,17,8,21,16,21,0,17,25,17,0,19,16,16,20,1,17,17,16,3,25,17,16,17,16,0,4,17,20,0,17,16]

theorem envBound20627 : H12AffineFastState.Bounded env20627 := by
  intro p hp
  have h : env20627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20626_20627 : H12AffineEnvironment.transform 4 1 env20626 = env20627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env20626 == env20627) = true)

theorem identity20627 : scanCanonicalize (H12AffineFastState.compose env20627 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound20627 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20628 : List Nat := [2,4,8,0,1,1,8,5,0,5,0,1,9,1,0,3,0,0,4,1,1,1,0,3,9,1,0,1,0,0,4,1,4,0,1,0]

theorem envBound20628 : H12AffineFastState.Bounded env20628 := by
  intro p hp
  have h : env20628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20627_20628 : H12AffineEnvironment.transform 3 0 env20627 = env20628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env20627 == env20628) = true)

def env20629 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,8201,147520,230468,8328,672785,925773,16384,676865,1073741824,131141,4294967296,257,4295206119,1344,512]

theorem envBound20629 : H12AffineFastState.Bounded env20629 := by
  intro p hp
  have h : env20629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20567_20629 : H12AffineEnvironment.transform 10 1 env20567 = env20629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env20567 == env20629) = true)

def env20630 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1344,262144,524288,32769,4096,8201,17664,98564,8328,541009,795917,16384,545089,1073741824,1285,4294967296,257,4295074215,1344,512]

theorem envBound20630 : H12AffineFastState.Bounded env20630 := by
  intro p hp
  have h : env20630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20629_20630 : H12AffineEnvironment.transform 16 1344 env20629 = env20630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env20629 == env20630) = true)

theorem identity20630 : scanCanonicalize (H12AffineFastState.compose env20630 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 8461) := by decide +kernel

theorem selectedBound20630 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env20631 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1344,262144,524288,32769,4096,8201,17664,98564,8328,541009,795917,16384,545089,8461,1285,4294967296,257,4295074215,1344,512]

theorem envBound20631 : H12AffineFastState.Bounded env20631 := by
  intro p hp
  have h : env20631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20630_20631 : H12AffineEnvironment.transform 29 8461 env20630 = env20631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 8461 env20630 == env20631) = true)

def env20632 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1344,262144,304168,32769,4096,8201,17664,98564,8328,320889,33061,16384,324969,8461,1285,4294967296,257,4295074215,1344,512]

theorem envBound20632 : H12AffineFastState.Bounded env20632 := by
  intro p hp
  have h : env20632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20631_20632 : H12AffineEnvironment.transform 18 304168 env20631 = env20632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 304168 env20631 == env20632) = true)

theorem identity20632 : scanCanonicalize (H12AffineFastState.compose env20632 (packedSelected [4,9,18] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound20632 : packedSelected [4,9,18] rootPS < 2^1333 := by decide +kernel

def env20633 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,268,16384,32768,65536,1344,262144,296228,32769,4096,261,17664,98564,388,312437,33061,16384,316517,1,1285,4294967296,257,4295065771,1344,512]

theorem envBound20633 : H12AffineFastState.Bounded env20633 := by
  intro p hp
  have h : env20633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20632_20633 : H12AffineEnvironment.transform 12 268 env20632 = env20633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env20632 == env20633) = true)

theorem identity20633 : scanCanonicalize (H12AffineFastState.compose env20633 (packedSelected [20,23] rootPS)) = affineNative (2^(17+1) ^^^ 1) := by decide +kernel

theorem selectedBound20633 : packedSelected [20,23] rootPS < 2^1333 := by decide +kernel

def env20634 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,268,16384,32768,65536,1344,1,34085,32769,4096,261,17664,98564,388,50292,33061,16384,54372,1,1285,4294967296,257,4295065771,1344,512]

theorem envBound20634 : H12AffineFastState.Bounded env20634 := by
  intro p hp
  have h : env20634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20633_20634 : H12AffineEnvironment.transform 17 1 env20633 = env20634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1 env20633 == env20634) = true)

def env20635 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1344,262144,304169,32769,4096,8201,17664,98564,8328,320888,33060,16384,324968,8461,1285,4294967296,257,4295074215,1344,512]

theorem envBound20635 : H12AffineFastState.Bounded env20635 := by
  intro p hp
  have h : env20635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20631_20635 : H12AffineEnvironment.transform 18 304169 env20631 = env20635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 304169 env20631 == env20635) = true)

theorem identity20635 : scanCanonicalize (H12AffineFastState.compose env20635 (packedSelected [3,10,17,19,21,24] rootPS)) = affineNative (2^(17+1) ^^^ 41000) := by decide +kernel

theorem selectedBound20635 : packedSelected [3,10,17,19,21,24] rootPS < 2^1333 := by decide +kernel

def env20636 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1344,41000,1025,32769,4096,8201,17664,98564,8328,17744,33060,16384,21824,8461,1285,4294967296,257,4295074215,1344,512]

theorem envBound20636 : H12AffineFastState.Bounded env20636 := by
  intro p hp
  have h : env20636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20635_20636 : H12AffineEnvironment.transform 17 41000 env20635 = env20636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 41000 env20635 == env20636) = true)

theorem identity20636 : scanCanonicalize (H12AffineFastState.compose env20636 (packedSelected [1,3,10,13,15] rootPS)) = affineNative (2^(15+1) ^^^ 33167) := by decide +kernel

theorem selectedBound20636 : packedSelected [1,3,10,13,15] rootPS < 2^1333 := by decide +kernel

def env20637 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,33167,1344,41000,1025,32769,4096,8201,17664,139,8328,17744,33060,16384,21824,8461,1285,4294967296,257,4294975528,1344,512]

theorem envBound20637 : H12AffineFastState.Bounded env20637 := by
  intro p hp
  have h : env20637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20636_20637 : H12AffineEnvironment.transform 15 33167 env20636 = env20637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33167 env20636 == env20637) = true)

theorem identity20637 : scanCanonicalize (H12AffineFastState.compose env20637 (packedSelected [5,8,10,12,13] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound20637 : packedSelected [5,8,10,12,13] rootPS < 2^1333 := by decide +kernel

def env20638 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4177,32768,33167,1344,41000,1025,32769,4096,8201,5457,139,8328,5377,33060,4177,1297,8461,1285,4294967296,257,4294975528,1344,512]

theorem envBound20638 : H12AffineFastState.Bounded env20638 := by
  intro p hp
  have h : env20638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20637_20638 : H12AffineEnvironment.transform 13 4177 env20637 = env20638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env20637 == env20638) = true)

def env20639 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4177,512,911,1344,8744,1025,513,4096,8201,5457,139,8328,5377,804,4177,1297,8461,1285,4294967296,257,4294975528,1344,512]

theorem envBound20639 : H12AffineFastState.Bounded env20639 := by
  intro p hp
  have h : env20639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20638_20639 : H12AffineEnvironment.transform 14 512 env20638 = env20639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 512 env20638 == env20639) = true)

theorem identity20639 : scanCanonicalize (H12AffineFastState.compose env20639 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 13853) := by decide +kernel

theorem selectedBound20639 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20640 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4177,512,911,1344,8744,1025,513,4096,8201,5457,139,8328,5377,804,4177,1297,8461,1285,13853,257,5685,1344,512]

theorem envBound20640 : H12AffineFastState.Bounded env20640 := by
  intro p hp
  have h : env20640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20639_20640 : H12AffineEnvironment.transform 31 13853 env20639 = env20640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 13853 env20639 == env20640) = true)

def env20641 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,4096,8192,4177,136,263,1344,8352,1025,137,4096,8201,5457,139,8328,5377,428,4177,1297,8461,1285,13461,257,5309,1344,136]

theorem envBound20641 : H12AffineFastState.Bounded env20641 := by
  intro p hp
  have h : env20641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20640_20641 : H12AffineEnvironment.transform 8 136 env20640 = env20641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env20640 == env20641) = true)

theorem identity20641 : scanCanonicalize (H12AffineFastState.compose env20641 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound20641 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env20642 : List Nat := [2,4,8,16,32,64,128,253,136,1024,1,4096,8192,4177,136,250,1213,8352,1025,137,4096,8201,5292,139,8328,5372,81,4177,1260,8432,1272,13461,252,5309,1213,136]

theorem envBound20642 : H12AffineFastState.Bounded env20642 := by
  intro p hp
  have h : env20642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20641_20642 : H12AffineEnvironment.transform 7 253 env20641 = env20642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env20641 == env20642) = true)

def env20643 : List Nat := [2,4,8,16,32,16,128,173,136,1024,1,4096,8192,4097,136,170,1213,8352,1025,137,4096,8201,5292,139,8328,5292,1,4097,1212,8352,1192,13461,172,5309,1213,136]

theorem envBound20643 : H12AffineFastState.Bounded env20643 := by
  intro p hp
  have h : env20643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20642_20643 : H12AffineEnvironment.transform 5 16 env20642 = env20643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20642 == env20643) = true)

theorem identity20643 : scanCanonicalize (H12AffineFastState.compose env20643 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound20643 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20644 : List Nat := [2,4,8,16,32,16,128,173,136,1024,1,4096,41,4097,136,170,1213,137,1025,137,4096,32,5292,139,161,5292,1,4097,1212,137,1192,5308,172,5309,1213,136]

theorem envBound20644 : H12AffineFastState.Bounded env20644 := by
  intro p hp
  have h : env20644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20643_20644 : H12AffineEnvironment.transform 12 41 env20643 = env20644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env20643 == env20644) = true)

theorem identity20644 : scanCanonicalize (H12AffineFastState.compose env20644 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound20644 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20645 : List Nat := [2,4,8,16,1,16,128,140,136,1024,1,4096,8,4097,136,139,1180,137,1025,137,4096,1,5261,139,128,5261,1,4097,1181,137,1161,5277,141,5276,1180,136]

theorem envBound20645 : H12AffineFastState.Bounded env20645 := by
  intro p hp
  have h : env20645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20644_20645 : H12AffineEnvironment.transform 4 1 env20644 = env20645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env20644 == env20645) = true)

theorem identity20645 : scanCanonicalize (H12AffineFastState.compose env20645 (packedSelected [7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound20645 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env20646 : List Nat := [2,4,8,16,1,16,8,4,0,1024,1,4096,8,4097,0,3,1044,1,1025,1,4096,1,5125,3,8,5125,1,4097,1045,1,1025,5141,5,5140,1044,0]

theorem envBound20646 : H12AffineFastState.Bounded env20646 := by
  intro p hp
  have h : env20646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20645_20646 : H12AffineEnvironment.transform 6 8 env20645 = env20646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20645 == env20646) = true)

def leafEnv20646 : List Nat := [2,4,8,16,1,16,8,4,0,1024,1,4096,8,4097,0,3,1044,1,1025,1,4096,1,5125,3,1024,8,1,5125,1,4097,1045,1,1025,5141,5,5140,5,2,1044,0,0,1045,1]

def active20646 : List Nat := [0,1,2,3,9,11]

def tree20646 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20646 : H12WitnessSearch.Good tree20646 := H12GlobalWitnessIndex.good

theorem leafIdentity20646 : H12AffineFastState.composeSystem env20646 rootObs = leafEnv20646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20646 rootObs == leafEnv20646) = true)

theorem terminalChecked20646 : H12PackedTerminal.terminalCheckFast leafEnv20646 active20646 tree20646 = true := by decide +kernel

def env20647 : List Nat := [2,4,8,16,32,17,128,172,136,1024,1,4096,8192,4096,136,171,1213,8352,1025,137,4096,8201,5292,139,8328,5293,0,4096,1213,8353,1193,13461,173,5309,1213,136]

theorem envBound20647 : H12AffineFastState.Bounded env20647 := by
  intro p hp
  have h : env20647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20642_20647 : H12AffineEnvironment.transform 5 17 env20642 = env20647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20642 == env20647) = true)

theorem identity20647 : scanCanonicalize (H12AffineFastState.compose env20647 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 1212) := by decide +kernel

theorem selectedBound20647 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20648 : List Nat := [2,4,8,16,32,17,128,172,136,1024,1,1212,8192,1212,136,171,1213,8352,1025,137,1212,8201,16,139,8328,17,0,1212,1213,8353,1193,8233,173,1,1213,136]

theorem envBound20648 : H12AffineFastState.Bounded env20648 := by
  intro p hp
  have h : env20648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20647_20648 : H12AffineEnvironment.transform 11 1212 env20647 = env20648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1212 env20647 == env20648) = true)

theorem identity20648 : scanCanonicalize (H12AffineFastState.compose env20648 (packedSelected [3] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound20648 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env20649 : List Nat := [2,4,8,16,32,17,128,172,136,1024,1,1212,160,1212,136,171,1213,0,1025,137,1212,169,16,139,40,17,0,1212,1213,1,1193,137,173,1,1213,136]

theorem envBound20649 : H12AffineFastState.Bounded env20649 := by
  intro p hp
  have h : env20649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20648_20649 : H12AffineEnvironment.transform 12 160 env20648 = env20649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env20648 == env20649) = true)

def env20650 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,4096,8192,4177,137,262,1344,8353,1025,136,4096,8201,5457,139,8328,5377,429,4177,1297,8461,1285,13460,257,5308,1344,137]

theorem envBound20650 : H12AffineFastState.Bounded env20650 := by
  intro p hp
  have h : env20650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20640_20650 : H12AffineEnvironment.transform 8 137 env20640 = env20650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env20640 == env20650) = true)

theorem identity20650 : scanCanonicalize (H12AffineFastState.compose env20650 (packedSelected [2,4] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound20650 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env20651 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,4096,120,4177,137,262,1344,217,1025,136,4096,113,5457,139,240,5377,429,4177,1297,373,1285,5356,257,5308,1344,137]

theorem envBound20651 : H12AffineFastState.Bounded env20651 := by
  intro p hp
  have h : env20651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20650_20651 : H12AffineEnvironment.transform 12 120 env20650 = env20651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env20650 == env20651) = true)

theorem identity20651 : scanCanonicalize (H12AffineFastState.compose env20651 (packedSelected [1,3,5] rootPS)) = affineNative (2^(11+1) ^^^ 1344) := by decide +kernel

theorem selectedBound20651 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env20652 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,1344,120,1297,137,262,1344,217,1025,136,1344,113,17,139,240,65,429,1297,1297,373,1285,428,257,508,1344,137]

theorem envBound20652 : H12AffineFastState.Bounded env20652 := by
  intro p hp
  have h : env20652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20651_20652 : H12AffineEnvironment.transform 11 1344 env20651 = env20652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env20651 == env20652) = true)

theorem identity20652 : scanCanonicalize (H12AffineFastState.compose env20652 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound20652 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20653 : List Nat := [2,4,8,16,32,64,128,172,137,1024,1,1260,120,1213,137,170,1260,217,1025,136,1260,113,17,139,240,65,1,1213,1213,217,1193,0,173,80,1260,137]

theorem envBound20653 : H12AffineFastState.Bounded env20653 := by
  intro p hp
  have h : env20653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20652_20653 : H12AffineEnvironment.transform 7 172 env20652 = env20653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env20652 == env20653) = true)

theorem identity20653 : scanCanonicalize (H12AffineFastState.compose env20653 (packedSelected [7] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound20653 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env20654 : List Nat := [2,4,8,16,32,64,88,116,81,1024,1,1076,120,1125,81,114,1076,1,1025,80,1076,113,17,83,40,65,1,1125,1125,1,1137,0,117,80,1076,81]

theorem envBound20654 : H12AffineFastState.Bounded env20654 := by
  intro p hp
  have h : env20654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20653_20654 : H12AffineEnvironment.transform 6 88 env20653 = env20654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env20653 == env20654) = true)

def env20655 : List Nat := [2,4,8,16,0,64,88,84,81,1024,1,1044,88,1093,81,82,1044,1,1025,80,1044,81,17,83,8,65,1,1093,1093,1,1105,0,85,80,1044,81]

theorem envBound20655 : H12AffineFastState.Bounded env20655 := by
  intro p hp
  have h : env20655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20654_20655 : H12AffineEnvironment.transform 4 0 env20654 = env20655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20654 == env20655) = true)

def leafEnv20655 : List Nat := [2,4,8,16,0,64,88,84,81,1024,1,1044,88,1093,81,82,1044,1,1025,80,1044,81,17,83,1104,8,1,65,1,1093,1093,1,1105,0,85,80,5,3,1044,81,0,1093,1]

def active20655 : List Nat := [0,1,2,3,5,9]

def tree20655 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20655 : H12WitnessSearch.Good tree20655 := H12GlobalWitnessIndex.good

theorem leafIdentity20655 : H12AffineFastState.composeSystem env20655 rootObs = leafEnv20655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20655 rootObs == leafEnv20655) = true)

theorem terminalChecked20655 : H12PackedTerminal.terminalCheckFast leafEnv20655 active20655 tree20655 = true := by decide +kernel

def env20656 : List Nat := [2,4,8,16,1,64,88,85,81,1024,1,1045,89,1092,81,83,1045,1,1025,80,1045,80,17,83,9,65,1,1092,1092,1,1104,0,84,80,1045,81]

theorem envBound20656 : H12AffineFastState.Bounded env20656 := by
  intro p hp
  have h : env20656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20654_20656 : H12AffineEnvironment.transform 4 1 env20654 = env20656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env20654 == env20656) = true)

theorem identity20656 : scanCanonicalize (H12AffineFastState.compose env20656 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound20656 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20657 : List Nat := [2,4,8,16,1,16,8,5,1,1024,1,1045,9,1044,1,3,1045,1,1025,0,1045,0,17,3,9,17,1,1044,1044,1,1024,0,4,0,1045,1]

theorem envBound20657 : H12AffineFastState.Bounded env20657 := by
  intro p hp
  have h : env20657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20656_20657 : H12AffineEnvironment.transform 5 16 env20656 = env20657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20656 == env20657) = true)

def leafEnv20657 : List Nat := [2,4,8,16,1,16,8,5,1,1024,1,1045,9,1044,1,3,1045,1,1025,0,1045,0,17,3,1025,9,1,17,1,1044,1044,1,1024,0,4,0,5,2,1045,1,0,1044,1]

def active20657 : List Nat := [0,1,2,3,9]

def tree20657 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20657 : H12WitnessSearch.Good tree20657 := H12GlobalWitnessIndex.good

theorem leafIdentity20657 : H12AffineFastState.composeSystem env20657 rootObs = leafEnv20657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20657 rootObs == leafEnv20657) = true)

theorem terminalChecked20657 : H12PackedTerminal.terminalCheckFast leafEnv20657 active20657 tree20657 = true := by decide +kernel

def env20658 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4177,513,910,1344,8745,1025,512,4096,8201,5457,139,8328,5377,805,4177,1297,8461,1285,4294967296,257,4294975528,1344,512]

theorem envBound20658 : H12AffineFastState.Bounded env20658 := by
  intro p hp
  have h : env20658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20638_20658 : H12AffineEnvironment.transform 14 513 env20638 = env20658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 513 env20638 == env20658) = true)

theorem identity20658 : scanCanonicalize (H12AffineFastState.compose env20658 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 6040) := by decide +kernel

theorem selectedBound20658 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20659 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4177,513,910,1344,8745,1025,512,4096,8201,5457,139,8328,5377,805,4177,1297,8461,1285,6040,257,14256,1344,512]

theorem envBound20659 : H12AffineFastState.Bounded env20659 := by
  intro p hp
  have h : env20659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20658_20659 : H12AffineEnvironment.transform 31 6040 env20658 = env20659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 6040 env20658 == env20659) = true)

def env20660 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,4096,8192,4177,137,262,1344,8353,1025,136,4096,8201,5457,139,8328,5377,429,4177,1297,8461,1285,5392,257,13624,1344,136]

theorem envBound20660 : H12AffineFastState.Bounded env20660 := by
  intro p hp
  have h : env20660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20659_20660 : H12AffineEnvironment.transform 8 136 env20659 = env20660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env20659 == env20660) = true)

theorem identity20660 : scanCanonicalize (H12AffineFastState.compose env20660 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound20660 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env20661 : List Nat := [2,4,8,16,32,64,128,252,136,1024,1,4096,8192,4177,137,250,1212,8353,1025,136,4096,8201,5293,139,8328,5373,81,4177,1261,8433,1273,5356,253,13508,1212,136]

theorem envBound20661 : H12AffineFastState.Bounded env20661 := by
  intro p hp
  have h : env20661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20660_20661 : H12AffineEnvironment.transform 7 252 env20660 = env20661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env20660 == env20661) = true)

def env20662 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,4096,8192,4177,136,263,1344,8352,1025,137,4096,8201,5457,139,8328,5377,428,4177,1297,8461,1285,5393,257,13625,1344,137]

theorem envBound20662 : H12AffineFastState.Bounded env20662 := by
  intro p hp
  have h : env20662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20659_20662 : H12AffineEnvironment.transform 8 137 env20659 = env20662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env20659 == env20662) = true)

theorem identity20662 : scanCanonicalize (H12AffineFastState.compose env20662 (packedSelected [2,4] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound20662 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env20663 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,4096,121,4177,136,263,1344,217,1025,137,4096,112,5457,139,241,5377,428,4177,1297,372,1285,5393,257,5440,1344,137]

theorem envBound20663 : H12AffineFastState.Bounded env20663 := by
  intro p hp
  have h : env20663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20662_20663 : H12AffineEnvironment.transform 12 121 env20662 = env20663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env20662 == env20663) = true)

theorem identity20663 : scanCanonicalize (H12AffineFastState.compose env20663 (packedSelected [1,3,5] rootPS)) = affineNative (2^(11+1) ^^^ 1345) := by decide +kernel

theorem selectedBound20663 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env20664 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,1345,121,1296,136,263,1344,217,1025,137,1345,112,16,139,241,64,428,1296,1297,372,1285,80,257,1,1344,137]

theorem envBound20664 : H12AffineFastState.Bounded env20664 := by
  intro p hp
  have h : env20664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20663_20664 : H12AffineEnvironment.transform 11 1345 env20663 = env20664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env20663 == env20664) = true)

def env20665 : List Nat := [2,4,8,16,32,16,128,256,137,1024,1,1297,41,1296,136,263,1296,137,1025,137,1297,32,16,139,161,16,428,1296,1297,292,1285,0,257,1,1296,137]

theorem envBound20665 : H12AffineFastState.Bounded env20665 := by
  intro p hp
  have h : env20665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20664_20665 : H12AffineEnvironment.transform 5 16 env20664 = env20665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20664 == env20665) = true)

theorem identity20665 : scanCanonicalize (H12AffineFastState.compose env20665 (packedSelected [2,7] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound20665 : packedSelected [2,7] rootPS < 2^1333 := by decide +kernel

def env20666 : List Nat := [2,4,8,16,32,16,40,256,33,1024,1,1297,41,1296,32,263,1296,33,1025,33,1297,32,16,35,9,16,260,1296,1297,292,1285,0,257,1,1296,33]

theorem envBound20666 : H12AffineFastState.Bounded env20666 := by
  intro p hp
  have h : env20666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20665_20666 : H12AffineEnvironment.transform 6 40 env20665 = env20666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env20665 == env20666) = true)

def env20667 : List Nat := [2,4,8,16,0,16,8,256,1,1024,1,1297,9,1296,0,263,1296,1,1025,1,1297,0,16,3,9,16,260,1296,1297,260,1285,0,257,1,1296,1]

theorem envBound20667 : H12AffineFastState.Bounded env20667 := by
  intro p hp
  have h : env20667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20666_20667 : H12AffineEnvironment.transform 4 0 env20666 = env20667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20666 == env20667) = true)

def leafEnv20667 : List Nat := [2,4,8,16,0,16,8,256,1,1024,1,1297,9,1296,0,263,1296,1,1025,1,1297,0,16,3,1284,9,1,16,260,1296,1297,260,1285,0,257,1,5,262,1296,1,0,1297,1]

def active20667 : List Nat := [0,1,2,3,7,9]

def tree20667 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20667 : H12WitnessSearch.Good tree20667 := H12GlobalWitnessIndex.good

theorem leafIdentity20667 : H12AffineFastState.composeSystem env20667 rootObs = leafEnv20667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20667 rootObs == leafEnv20667) = true)

theorem terminalChecked20667 : H12PackedTerminal.terminalCheckFast leafEnv20667 active20667 tree20667 = true := by decide +kernel

def env20668 : List Nat := [2,4,8,16,1,16,9,256,0,1024,1,1297,8,1296,1,263,1296,0,1025,0,1297,1,16,2,9,16,260,1296,1297,261,1285,0,257,1,1296,0]

theorem envBound20668 : H12AffineFastState.Bounded env20668 := by
  intro p hp
  have h : env20668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20666_20668 : H12AffineEnvironment.transform 4 1 env20666 = env20668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env20666 == env20668) = true)

theorem identity20668 : scanCanonicalize (H12AffineFastState.compose env20668 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound20668 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20669 : List Nat := [2,4,8,16,1,16,9,4,0,1024,1,1045,8,1044,1,3,1044,0,1025,0,1045,1,16,2,9,16,0,1044,1045,1,1025,0,5,1,1044,0]

theorem envBound20669 : H12AffineFastState.Bounded env20669 := by
  intro p hp
  have h : env20669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20668_20669 : H12AffineEnvironment.transform 7 4 env20668 = env20669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env20668 == env20669) = true)

def leafEnv20669 : List Nat := [2,4,8,16,1,16,9,4,0,1024,1,1045,8,1044,1,3,1044,0,1025,0,1045,1,16,2,1024,9,1,16,0,1044,1045,1,1025,0,5,1,5,3,1044,0,0,1045,1]

def active20669 : List Nat := [0,1,2,3,9]

def tree20669 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20669 : H12WitnessSearch.Good tree20669 := H12GlobalWitnessIndex.good

theorem leafIdentity20669 : H12AffineFastState.composeSystem env20669 rootObs = leafEnv20669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20669 rootObs == leafEnv20669) = true)

theorem terminalChecked20669 : H12PackedTerminal.terminalCheckFast leafEnv20669 active20669 tree20669 = true := by decide +kernel

def env20670 : List Nat := [2,4,8,16,32,17,128,256,137,1024,1,1296,40,1296,136,263,1297,136,1025,137,1296,33,16,139,160,17,428,1296,1297,293,1285,1,257,1,1297,137]

theorem envBound20670 : H12AffineFastState.Bounded env20670 := by
  intro p hp
  have h : env20670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20664_20670 : H12AffineEnvironment.transform 5 17 env20664 = env20670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20664 == env20670) = true)

theorem identity20670 : scanCanonicalize (H12AffineFastState.compose env20670 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound20670 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env20671 : List Nat := [2,4,8,16,32,17,128,36,137,1024,1,1076,40,1076,136,35,1077,136,1025,137,1076,33,16,139,160,17,136,1076,1077,1,1057,1,37,1,1077,137]

theorem envBound20671 : H12AffineFastState.Bounded env20671 := by
  intro p hp
  have h : env20671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20670_20671 : H12AffineEnvironment.transform 7 36 env20670 = env20671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env20670 == env20671) = true)

theorem identity20671 : scanCanonicalize (H12AffineFastState.compose env20671 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound20671 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20672 : List Nat := [2,4,8,16,32,17,9,36,0,1024,1,1076,40,1076,1,35,1077,1,1025,0,1076,33,16,2,41,17,1,1076,1077,1,1057,1,37,1,1077,0]

theorem envBound20672 : H12AffineFastState.Bounded env20672 := by
  intro p hp
  have h : env20672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20671_20672 : H12AffineEnvironment.transform 6 9 env20671 = env20672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20671 == env20672) = true)

def leafEnv20672 : List Nat := [2,4,8,16,32,17,9,36,0,1024,1,1076,40,1076,1,35,1077,1,1025,0,1076,33,16,2,1056,41,1,17,1,1076,1077,1,1057,1,37,1,5,35,1077,0,0,1077,1]

def active20672 : List Nat := [0,1,2,3,4,9]

def tree20672 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20672 : H12WitnessSearch.Good tree20672 := H12GlobalWitnessIndex.good

theorem leafIdentity20672 : H12AffineFastState.composeSystem env20672 rootObs = leafEnv20672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20672 rootObs == leafEnv20672) = true)

theorem terminalChecked20672 : H12PackedTerminal.terminalCheckFast leafEnv20672 active20672 tree20672 = true := by decide +kernel

def env20673 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1345,262144,524288,32769,4096,8201,17665,98565,8328,541008,795916,16384,545088,1073741824,1284,4294967296,257,4295074214,1344,512]

theorem envBound20673 : H12AffineFastState.Bounded env20673 := by
  intro p hp
  have h : env20673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20629_20673 : H12AffineEnvironment.transform 16 1345 env20629 = env20673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env20629 == env20673) = true)

theorem identity20673 : scanCanonicalize (H12AffineFastState.compose env20673 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 8540) := by decide +kernel

theorem selectedBound20673 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env20674 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1345,262144,524288,32769,4096,8201,17665,98565,8328,541008,795916,16384,545088,8540,1284,4294967296,257,4295074214,1344,512]

theorem envBound20674 : H12AffineFastState.Bounded env20674 := by
  intro p hp
  have h : env20674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20673_20674 : H12AffineEnvironment.transform 29 8540 env20673 = env20674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 8540 env20673 == env20674) = true)

theorem identity20674 : scanCanonicalize (H12AffineFastState.compose env20674 (packedSelected [4,9,16] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound20674 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env20675 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1345,262144,1025,32769,4096,8201,17665,98565,8328,17745,270605,16384,21825,8540,1284,4294967296,257,4295074214,1344,512]

theorem envBound20675 : H12AffineFastState.Bounded env20675 := by
  intro p hp
  have h : env20675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20674_20675 : H12AffineEnvironment.transform 18 1025 env20674 = env20675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env20674 == env20675) = true)

theorem identity20675 : scanCanonicalize (H12AffineFastState.compose env20675 (packedSelected [1,5,8,15,17,21,24,38] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound20675 : packedSelected [1,5,8,15,17,21,24,38] rootPS < 2^1333 := by decide +kernel

def env20676 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,33246,1345,262144,1025,32769,4096,8201,17665,219,8328,17745,270605,16384,21825,8540,1284,4294967296,257,4294975608,1344,512]

theorem envBound20676 : H12AffineFastState.Bounded env20676 := by
  intro p hp
  have h : env20676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20675_20676 : H12AffineEnvironment.transform 15 33246 env20675 = env20676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env20675 == env20676) = true)

theorem identity20676 : scanCanonicalize (H12AffineFastState.compose env20676 (packedSelected [13,21] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound20676 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env20677 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4177,32768,33246,1345,262144,1025,32769,4096,8201,5456,219,8328,5376,270605,4177,1296,8540,1284,4294967296,257,4294975608,1344,512]

theorem envBound20677 : H12AffineFastState.Bounded env20677 := by
  intro p hp
  have h : env20677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20676_20677 : H12AffineEnvironment.transform 13 4177 env20676 = env20677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env20676 == env20677) = true)

theorem identity20677 : scanCanonicalize (H12AffineFastState.compose env20677 (packedSelected [3,5,10] rootPS)) = affineNative (2^(31+1) ^^^ 8321) := by decide +kernel

theorem selectedBound20677 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env20678 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4177,32768,33246,1345,262144,1025,32769,4096,8201,5456,219,8328,5376,270605,4177,1296,8540,1284,8321,257,249,1344,512]

theorem envBound20678 : H12AffineFastState.Bounded env20678 := by
  intro p hp
  have h : env20678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20677_20678 : H12AffineEnvironment.transform 31 8321 env20677 = env20678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 8321 env20677 == env20678) = true)

theorem identity20678 : scanCanonicalize (H12AffineFastState.compose env20678 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 41081) := by decide +kernel

theorem selectedBound20678 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env20679 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4177,32768,33246,1345,41081,1025,32769,4096,8201,5456,219,8328,5376,33140,4177,1296,8540,1284,8321,257,249,1344,512]

theorem envBound20679 : H12AffineFastState.Bounded env20679 := by
  intro p hp
  have h : env20679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20678_20679 : H12AffineEnvironment.transform 17 41081 env20678 = env20679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 41081 env20678 == env20679) = true)

theorem identity20679 : scanCanonicalize (H12AffineFastState.compose env20679 (packedSelected [3,8,12,13] rootPS)) = affineNative (2^(14+1) ^^^ 13389) := by decide +kernel

theorem selectedBound20679 : packedSelected [3,8,12,13] rootPS < 2^1333 := by decide +kernel

def env20680 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4177,13389,13715,1345,5172,1025,13388,4096,8201,5456,219,8328,5376,13625,4177,1296,8540,1284,8321,257,249,1344,512]

theorem envBound20680 : H12AffineFastState.Bounded env20680 := by
  intro p hp
  have h : env20680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20679_20680 : H12AffineEnvironment.transform 14 13389 env20679 = env20680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13389 env20679 == env20680) = true)

theorem identity20680 : scanCanonicalize (H12AffineFastState.compose env20680 (packedSelected [3,5,12,17] rootPS)) = affineNative (2^(12+1) ^^^ 5316) := by decide +kernel

theorem selectedBound20680 : packedSelected [3,5,12,17] rootPS < 2^1333 := by decide +kernel

def env20681 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,5316,4177,137,343,1345,5172,1025,136,4096,5325,5456,219,5196,5376,509,4177,1296,5528,1284,5189,257,249,1344,512]

theorem envBound20681 : H12AffineFastState.Bounded env20681 := by
  intro p hp
  have h : env20681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20680_20681 : H12AffineEnvironment.transform 12 5316 env20680 = env20681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5316 env20680 == env20681) = true)

theorem identity20681 : scanCanonicalize (H12AffineFastState.compose env20681 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 1464) := by decide +kernel

theorem selectedBound20681 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env20682 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1464,380,1513,137,343,1345,396,1025,136,1464,373,232,219,500,184,509,1513,1296,32,1284,509,257,249,1344,512]

theorem envBound20682 : H12AffineFastState.Bounded env20682 := by
  intro p hp
  have h : env20682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20681_20682 : H12AffineEnvironment.transform 11 1464 env20681 = env20682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1464 env20681 == env20682) = true)

theorem identity20682 : scanCanonicalize (H12AffineFastState.compose env20682 (packedSelected [0,1,3,8] rootPS)) = affineNative (2^(7+1) ^^^ 237) := by decide +kernel

theorem selectedBound20682 : packedSelected [0,1,3,8] rootPS < 2^1333 := by decide +kernel

def env20683 : List Nat := [2,4,8,16,32,64,128,237,512,1024,1,1109,145,1028,137,186,1196,97,1025,136,1109,152,232,219,25,184,16,1028,1277,32,1257,16,236,249,1197,512]

theorem envBound20683 : H12AffineFastState.Bounded env20683 := by
  intro p hp
  have h : env20683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20682_20683 : H12AffineEnvironment.transform 7 237 env20682 = env20683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 237 env20682 == env20683) = true)

theorem identity20683 : scanCanonicalize (H12AffineFastState.compose env20683 (packedSelected [0,2,9,18] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound20683 : packedSelected [0,2,9,18] rootPS < 2^1333 := by decide +kernel

def env20684 : List Nat := [2,4,8,16,32,64,88,53,512,1024,1,1109,73,1028,81,98,1140,97,1025,80,1109,64,48,3,25,96,16,1028,1061,32,1073,16,52,33,1141,512]

theorem envBound20684 : H12AffineFastState.Bounded env20684 := by
  intro p hp
  have h : env20684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20683_20684 : H12AffineEnvironment.transform 6 88 env20683 = env20684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env20683 == env20684) = true)

theorem identity20684 : scanCanonicalize (H12AffineFastState.compose env20684 (packedSelected [1,2,3,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound20684 : packedSelected [1,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env20685 : List Nat := [2,4,8,16,32,48,40,53,512,1024,1,1061,57,1028,33,18,1028,17,1025,32,1061,48,48,3,25,16,16,1028,1061,32,1073,16,52,33,1029,512]

theorem envBound20685 : H12AffineFastState.Bounded env20685 := by
  intro p hp
  have h : env20685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20684_20685 : H12AffineEnvironment.transform 5 48 env20684 = env20685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env20684 == env20685) = true)

theorem identity20685 : scanCanonicalize (H12AffineFastState.compose env20685 (packedSelected [0,3] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound20685 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env20686 : List Nat := [2,4,8,16,32,48,40,53,512,20,1,49,57,16,33,18,16,17,21,32,49,48,48,3,25,16,16,16,49,32,37,16,52,33,17,512]

theorem envBound20686 : H12AffineFastState.Bounded env20686 := by
  intro p hp
  have h : env20686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20685_20686 : H12AffineEnvironment.transform 9 20 env20685 = env20686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env20685 == env20686) = true)

theorem identity20686 : scanCanonicalize (H12AffineFastState.compose env20686 (packedSelected [0,1,2] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound20686 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env20687 : List Nat := [2,4,8,16,32,48,40,53,33,20,1,49,57,16,33,18,16,17,21,32,49,48,48,3,25,16,16,16,49,32,37,16,52,33,17,33]

theorem envBound20687 : H12AffineFastState.Bounded env20687 := by
  intro p hp
  have h : env20687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20686_20687 : H12AffineEnvironment.transform 8 33 env20686 = env20687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env20686 == env20687) = true)

theorem identity20687 : scanCanonicalize (H12AffineFastState.compose env20687 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound20687 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20688 : List Nat := [2,4,8,16,0,16,8,21,1,20,1,17,25,16,1,18,16,17,21,0,17,16,16,3,25,16,16,16,17,0,5,16,20,1,17,1]

theorem envBound20688 : H12AffineFastState.Bounded env20688 := by
  intro p hp
  have h : env20688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20687_20688 : H12AffineEnvironment.transform 4 0 env20687 = env20688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20687 == env20688) = true)

theorem identity20688 : scanCanonicalize (H12AffineFastState.compose env20688 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound20688 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20689 : List Nat := [2,4,8,1,0,1,8,4,1,5,1,0,8,1,1,3,1,0,4,0,0,1,1,3,8,1,1,1,0,0,5,1,5,1,0,1]

theorem envBound20689 : H12AffineFastState.Bounded env20689 := by
  intro p hp
  have h : env20689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20688_20689 : H12AffineEnvironment.transform 3 1 env20688 = env20689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env20688 == env20689) = true)

def env20690 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,10249,147520,230468,8328,672785,927821,16384,676865,1073741824,131141,4294967296,257,4295208167,1344,512]

theorem envBound20690 : H12AffineFastState.Bounded env20690 := by
  intro p hp
  have h : env20690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20566_20690 : H12AffineEnvironment.transform 21 10249 env20566 = env20690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10249 env20566 == env20690) = true)

def env20691 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,8201,147520,230468,8328,672785,925773,16384,676865,1073741824,131141,4294967296,257,4295206119,1344,512]

theorem envBound20691 : H12AffineFastState.Bounded env20691 := by
  intro p hp
  have h : env20691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20690_20691 : H12AffineEnvironment.transform 10 0 env20690 = env20691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env20690 == env20691) = true)

def env20692 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1344,262144,524288,32769,4096,8201,17664,98564,8328,541009,795917,16384,545089,1073741824,1285,4294967296,257,4295074215,1344,512]

theorem envBound20692 : H12AffineFastState.Bounded env20692 := by
  intro p hp
  have h : env20692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20691_20692 : H12AffineEnvironment.transform 16 1344 env20691 = env20692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env20691 == env20692) = true)

theorem identity20692 : scanCanonicalize (H12AffineFastState.compose env20692 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 41000) := by decide +kernel

theorem selectedBound20692 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env20693 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1344,262144,524288,32769,4096,8201,17664,98564,8328,541009,795917,16384,545089,41000,1285,4294967296,257,4295074215,1344,512]

theorem envBound20693 : H12AffineFastState.Bounded env20693 := by
  intro p hp
  have h : env20693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20692_20693 : H12AffineEnvironment.transform 29 41000 env20692 = env20693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 41000 env20692 == env20693) = true)

def env20694 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1344,262144,304168,32769,4096,8201,17664,98564,8328,320889,33061,16384,324969,41000,1285,4294967296,257,4295074215,1344,512]

theorem envBound20694 : H12AffineFastState.Bounded env20694 := by
  intro p hp
  have h : env20694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20693_20694 : H12AffineEnvironment.transform 18 304168 env20693 = env20694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 304168 env20693 == env20694) = true)

theorem identity20694 : scanCanonicalize (H12AffineFastState.compose env20694 (packedSelected [4,9,18] rootPS)) = affineNative (2^(17+1) ^^^ 8461) := by decide +kernel

theorem selectedBound20694 : packedSelected [4,9,18] rootPS < 2^1333 := by decide +kernel

def env20695 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1344,8461,34085,32769,4096,8201,17664,98564,8328,50292,33061,16384,54372,41000,1285,4294967296,257,4295074215,1344,512]

theorem envBound20695 : H12AffineFastState.Bounded env20695 := by
  intro p hp
  have h : env20695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20694_20695 : H12AffineEnvironment.transform 17 8461 env20694 = env20695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8461 env20694 == env20695) = true)

theorem identity20695 : scanCanonicalize (H12AffineFastState.compose env20695 (packedSelected [5,8,13,15,19] rootPS)) = affineNative (2^(15+1) ^^^ 33167) := by decide +kernel

theorem selectedBound20695 : packedSelected [5,8,13,15,19] rootPS < 2^1333 := by decide +kernel

def env20696 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,33167,1344,8461,34085,32769,4096,8201,17664,139,8328,50292,33061,16384,54372,41000,1285,4294967296,257,4294975528,1344,512]

theorem envBound20696 : H12AffineFastState.Bounded env20696 := by
  intro p hp
  have h : env20696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20695_20696 : H12AffineEnvironment.transform 15 33167 env20695 = env20696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33167 env20695 == env20696) = true)

def env20697 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,18376,17991,1344,8461,17133,18377,4096,8201,17664,139,8328,956,18157,16384,5036,26592,1285,4294967296,257,4294975528,1344,512]

theorem envBound20697 : H12AffineFastState.Bounded env20697 := by
  intro p hp
  have h : env20697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20696_20697 : H12AffineEnvironment.transform 14 18376 env20696 = env20697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 18376 env20696 == env20697) = true)

theorem identity20697 : scanCanonicalize (H12AffineFastState.compose env20697 (packedSelected [1,3,10,13] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound20697 : packedSelected [1,3,10,13] rootPS < 2^1333 := by decide +kernel

def env20698 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,4177,6041,5654,1344,8461,4796,6040,4096,8201,5457,139,8328,956,5820,4177,5036,14257,1285,4294967296,257,4294975528,1344,512]

theorem envBound20698 : H12AffineFastState.Bounded env20698 := by
  intro p hp
  have h : env20698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20697_20698 : H12AffineEnvironment.transform 13 4177 env20697 = env20698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env20697 == env20698) = true)

theorem identity20698 : scanCanonicalize (H12AffineFastState.compose env20698 (packedSelected [4,5,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 1725) := by decide +kernel

theorem selectedBound20698 : packedSelected [4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env20699 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1725,8192,1772,292,171,1344,8461,1025,293,1725,8201,1004,139,8328,956,1,1772,1297,8460,1285,4294967296,257,4294975528,1344,512]

theorem envBound20699 : H12AffineFastState.Bounded env20699 := by
  intro p hp
  have h : env20699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20698_20699 : H12AffineEnvironment.transform 11 1725 env20698 = env20699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1725 env20698 == env20699) = true)

def env20700 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1725,672,1772,292,171,1344,941,1025,293,1725,681,1004,139,552,956,1,1772,1297,940,1285,4294967296,257,4294967944,1344,512]

theorem envBound20700 : H12AffineFastState.Bounded env20700 := by
  intro p hp
  have h : env20700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20699_20700 : H12AffineEnvironment.transform 12 672 env20699 = env20700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 672 env20699 == env20700) = true)

theorem identity20700 : scanCanonicalize (H12AffineFastState.compose env20700 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 429) := by decide +kernel

theorem selectedBound20700 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20701 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1725,672,1772,292,171,1344,941,1025,293,1725,681,1004,139,552,956,1,1772,1297,940,1285,429,257,805,1344,512]

theorem envBound20701 : H12AffineFastState.Bounded env20701 := by
  intro p hp
  have h : env20701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20700_20701 : H12AffineEnvironment.transform 31 429 env20700 = env20701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 429 env20700 == env20701) = true)

theorem identity20701 : scanCanonicalize (H12AffineFastState.compose env20701 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 428) := by decide +kernel

theorem selectedBound20701 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20702 : List Nat := [2,4,8,16,32,64,128,256,428,1024,0,1297,268,1344,292,171,1344,1,1025,293,1297,261,64,139,388,16,1,1344,1297,0,1285,429,257,137,1344,428]

theorem envBound20702 : H12AffineFastState.Bounded env20702 := by
  intro p hp
  have h : env20702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20701_20702 : H12AffineEnvironment.transform 8 428 env20701 = env20702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 428 env20701 == env20702) = true)

theorem identity20702 : scanCanonicalize (H12AffineFastState.compose env20702 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound20702 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20703 : List Nat := [2,4,8,16,32,64,9,256,293,1024,0,1297,268,1344,292,34,1344,1,1025,293,1297,261,64,2,269,16,1,1344,1297,0,1285,292,257,0,1344,293]

theorem envBound20703 : H12AffineFastState.Bounded env20703 := by
  intro p hp
  have h : env20703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20702_20703 : H12AffineEnvironment.transform 6 9 env20702 = env20703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20702 == env20703) = true)

theorem identity20703 : scanCanonicalize (H12AffineFastState.compose env20703 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound20703 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env20704 : List Nat := [2,4,8,16,32,64,9,116,81,1024,0,1125,120,1076,80,34,1076,1,1025,81,1125,113,64,2,121,16,1,1076,1125,0,1137,80,117,0,1076,81]

theorem envBound20704 : H12AffineFastState.Bounded env20704 := by
  intro p hp
  have h : env20704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20703_20704 : H12AffineEnvironment.transform 7 116 env20703 = env20704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env20703 == env20704) = true)

def env20705 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1725,673,1772,292,171,1344,940,1025,293,1725,680,1004,139,553,956,1,1772,1297,941,1285,4294967296,257,4294967945,1344,512]

theorem envBound20705 : H12AffineFastState.Bounded env20705 := by
  intro p hp
  have h : env20705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20699_20705 : H12AffineEnvironment.transform 12 673 env20699 = env20705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 673 env20699 == env20705) = true)

theorem identity20705 : scanCanonicalize (H12AffineFastState.compose env20705 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 649) := by decide +kernel

theorem selectedBound20705 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20706 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1725,673,1772,292,171,1344,940,1025,293,1725,680,1004,139,553,956,1,1772,1297,941,1285,649,257,0,1344,512]

theorem envBound20706 : H12AffineFastState.Bounded env20706 := by
  intro p hp
  have h : env20706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20705_20706 : H12AffineEnvironment.transform 31 649 env20705 = env20706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 649 env20705 == env20706) = true)

def env20707 : List Nat := [2,4,8,16,32,64,8,256,512,1024,0,1589,553,1636,292,35,1344,804,1025,293,1589,544,868,3,553,820,1,1636,1297,805,1285,513,257,0,1344,512]

theorem envBound20707 : H12AffineFastState.Bounded env20707 := by
  intro p hp
  have h : env20707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20706_20707 : H12AffineEnvironment.transform 6 8 env20706 = env20707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20706 == env20707) = true)

theorem identity20707 : scanCanonicalize (H12AffineFastState.compose env20707 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound20707 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20708 : List Nat := [2,4,8,16,32,16,8,256,512,1024,0,1589,553,1588,292,35,1296,804,1025,293,1589,544,820,3,553,820,1,1588,1297,805,1285,513,257,0,1296,512]

theorem envBound20708 : H12AffineFastState.Bounded env20708 := by
  intro p hp
  have h : env20708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20707_20708 : H12AffineEnvironment.transform 5 16 env20707 = env20708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20707 == env20708) = true)

def env20709 : List Nat := [2,4,8,16,32,64,9,256,512,1024,0,1588,552,1637,292,34,1344,805,1025,293,1588,545,869,2,553,821,1,1637,1297,804,1285,512,257,0,1344,512]

theorem envBound20709 : H12AffineFastState.Bounded env20709 := by
  intro p hp
  have h : env20709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20706_20709 : H12AffineEnvironment.transform 6 9 env20706 = env20709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20706 == env20709) = true)

theorem identity20709 : scanCanonicalize (H12AffineFastState.compose env20709 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 372) := by decide +kernel

theorem selectedBound20709 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20710 : List Nat := [2,4,8,16,32,64,9,256,372,1024,0,1344,348,1297,292,34,1344,81,1025,293,1344,341,17,2,349,65,1,1297,1297,80,1285,372,257,0,1344,372]

theorem envBound20710 : H12AffineFastState.Bounded env20710 := by
  intro p hp
  have h : env20710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20709_20710 : H12AffineEnvironment.transform 8 372 env20709 = env20710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 372 env20709 == env20710) = true)

theorem identity20710 : scanCanonicalize (H12AffineFastState.compose env20710 (packedSelected [5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound20710 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env20711 : List Nat := [2,4,8,16,32,16,9,256,292,1024,0,1296,268,1297,292,34,1296,1,1025,293,1296,261,17,2,269,17,1,1297,1297,0,1285,292,257,0,1296,292]

theorem envBound20711 : H12AffineFastState.Bounded env20711 := by
  intro p hp
  have h : env20711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20710_20711 : H12AffineEnvironment.transform 5 16 env20710 = env20711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20710 == env20711) = true)

theorem identity20711 : scanCanonicalize (H12AffineFastState.compose env20711 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound20711 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env20712 : List Nat := [2,4,8,16,32,16,9,37,1,1024,0,1077,41,1076,1,34,1077,1,1025,0,1077,32,17,2,40,17,1,1076,1076,0,1056,1,36,0,1077,1]

theorem envBound20712 : H12AffineFastState.Bounded env20712 := by
  intro p hp
  have h : env20712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20711_20712 : H12AffineEnvironment.transform 7 37 env20711 = env20712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env20711 == env20712) = true)

theorem identity20712 : scanCanonicalize (H12AffineFastState.compose env20712 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound20712 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20713 : List Nat := [2,4,8,16,0,16,9,5,1,1024,0,1045,9,1044,1,2,1045,1,1025,0,1045,0,17,2,8,17,1,1044,1044,0,1024,1,4,0,1045,1]

theorem envBound20713 : H12AffineFastState.Bounded env20713 := by
  intro p hp
  have h : env20713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20712_20713 : H12AffineEnvironment.transform 4 0 env20712 = env20713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20712 == env20713) = true)

def leafEnv20713 : List Nat := [2,4,8,16,0,16,9,5,1,1024,0,1045,9,1044,1,2,1045,1,1025,0,1045,0,17,2,1025,8,1,17,1,1044,1044,0,1024,1,4,0,5,2,1045,1,0,1044,1]

def active20713 : List Nat := [0,1,2,3,9]

def tree20713 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20713 : H12WitnessSearch.Good tree20713 := H12GlobalWitnessIndex.good

theorem leafIdentity20713 : H12AffineFastState.composeSystem env20713 rootObs = leafEnv20713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20713 rootObs == leafEnv20713) = true)

theorem terminalChecked20713 : H12PackedTerminal.terminalCheckFast leafEnv20713 active20713 tree20713 = true := by decide +kernel

def env20714 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,18377,17990,1344,8461,17132,18376,4096,8201,17664,139,8328,957,18156,16384,5037,26593,1285,4294967296,257,4294975528,1344,512]

theorem envBound20714 : H12AffineFastState.Bounded env20714 := by
  intro p hp
  have h : env20714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20696_20714 : H12AffineEnvironment.transform 14 18377 env20696 = env20714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 18377 env20696 == env20714) = true)

theorem identity20714 : scanCanonicalize (H12AffineFastState.compose env20714 (packedSelected [1,3,10,13] rootPS)) = affineNative (2^(11+1) ^^^ 1724) := by decide +kernel

theorem selectedBound20714 : packedSelected [1,3,10,13] rootPS < 2^1333 := by decide +kernel

def env20715 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1724,8192,16384,18377,17990,1344,8461,17132,18376,1724,8201,17664,139,8328,957,18156,16384,1297,26593,1285,4294967296,257,4294975528,1344,512]

theorem envBound20715 : H12AffineFastState.Bounded env20715 := by
  intro p hp
  have h : env20715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20714_20715 : H12AffineEnvironment.transform 11 1724 env20714 = env20715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1724 env20714 == env20715) = true)

theorem identity20715 : scanCanonicalize (H12AffineFastState.compose env20715 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 1773) := by decide +kernel

theorem selectedBound20715 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env20716 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1724,8192,1773,292,171,1344,8461,1025,293,1724,8201,1005,139,8328,957,1,1773,1297,8460,1285,4294967296,257,4294975528,1344,512]

theorem envBound20716 : H12AffineFastState.Bounded env20716 := by
  intro p hp
  have h : env20716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20715_20716 : H12AffineEnvironment.transform 13 1773 env20715 = env20716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1773 env20715 == env20716) = true)

def env20717 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1724,672,1773,292,171,1344,941,1025,293,1724,681,1005,139,552,957,1,1773,1297,940,1285,4294967296,257,4294967944,1344,512]

theorem envBound20717 : H12AffineFastState.Bounded env20717 := by
  intro p hp
  have h : env20717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20716_20717 : H12AffineEnvironment.transform 12 672 env20716 = env20717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 672 env20716 == env20717) = true)

theorem identity20717 : scanCanonicalize (H12AffineFastState.compose env20717 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 428) := by decide +kernel

theorem selectedBound20717 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20718 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1724,672,1773,292,171,1344,941,1025,293,1724,681,1005,139,552,957,1,1773,1297,940,1285,428,257,804,1344,512]

theorem envBound20718 : H12AffineFastState.Bounded env20718 := by
  intro p hp
  have h : env20718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20717_20718 : H12AffineEnvironment.transform 31 428 env20717 = env20718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 428 env20717 == env20718) = true)

def env20719 : List Nat := [2,4,8,16,32,64,8,256,512,1024,0,1588,552,1637,292,35,1344,805,1025,293,1588,545,869,3,552,821,1,1637,1297,804,1285,292,257,804,1344,512]

theorem envBound20719 : H12AffineFastState.Bounded env20719 := by
  intro p hp
  have h : env20719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20718_20719 : H12AffineEnvironment.transform 6 8 env20718 = env20719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20718 == env20719) = true)

theorem identity20719 : scanCanonicalize (H12AffineFastState.compose env20719 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound20719 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20720 : List Nat := [2,4,8,16,32,64,8,256,293,1024,0,1297,269,1344,292,35,1344,0,1025,293,1297,260,64,3,269,16,1,1344,1297,1,1285,292,257,1,1344,293]

theorem envBound20720 : H12AffineFastState.Bounded env20720 := by
  intro p hp
  have h : env20720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20719_20720 : H12AffineEnvironment.transform 8 293 env20719 = env20720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env20719 == env20720) = true)

theorem identity20720 : scanCanonicalize (H12AffineFastState.compose env20720 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound20720 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env20721 : List Nat := [2,4,8,16,32,64,8,116,81,1024,0,1125,121,1076,80,35,1076,0,1025,81,1125,112,64,3,121,16,1,1076,1125,1,1137,80,117,1,1076,81]

theorem envBound20721 : H12AffineFastState.Bounded env20721 := by
  intro p hp
  have h : env20721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20720_20721 : H12AffineEnvironment.transform 7 116 env20720 = env20721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env20720 == env20721) = true)

theorem identity20721 : scanCanonicalize (H12AffineFastState.compose env20721 (packedSelected [5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound20721 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env20722 : List Nat := [2,4,8,16,32,16,8,36,1,1024,0,1077,41,1076,0,35,1076,0,1025,1,1077,32,16,3,41,16,1,1076,1077,1,1057,0,37,1,1076,1]

theorem envBound20722 : H12AffineFastState.Bounded env20722 := by
  intro p hp
  have h : env20722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20721_20722 : H12AffineEnvironment.transform 5 16 env20721 = env20722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20721 == env20722) = true)

theorem identity20722 : scanCanonicalize (H12AffineFastState.compose env20722 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound20722 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20723 : List Nat := [2,4,8,16,0,16,8,4,1,1024,0,1045,9,1044,0,3,1044,0,1025,1,1045,0,16,3,9,16,1,1044,1045,1,1025,0,5,1,1044,1]

theorem envBound20723 : H12AffineFastState.Bounded env20723 := by
  intro p hp
  have h : env20723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20722_20723 : H12AffineEnvironment.transform 4 0 env20722 = env20723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20722 == env20723) = true)

def leafEnv20723 : List Nat := [2,4,8,16,0,16,8,4,1,1024,0,1045,9,1044,0,3,1044,0,1025,1,1045,0,16,3,1024,9,1,16,1,1044,1045,1,1025,0,5,1,5,2,1044,1,0,1045,1]

def active20723 : List Nat := [0,1,2,3,9]

def tree20723 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20723 : H12WitnessSearch.Good tree20723 := H12GlobalWitnessIndex.good

theorem leafIdentity20723 : H12AffineFastState.composeSystem env20723 rootObs = leafEnv20723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20723 rootObs == leafEnv20723) = true)

theorem terminalChecked20723 : H12PackedTerminal.terminalCheckFast leafEnv20723 active20723 tree20723 = true := by decide +kernel

def env20724 : List Nat := [2,4,8,16,32,64,9,256,512,1024,0,1589,553,1636,292,34,1344,804,1025,293,1589,544,868,2,552,820,1,1636,1297,805,1285,293,257,804,1344,512]

theorem envBound20724 : H12AffineFastState.Bounded env20724 := by
  intro p hp
  have h : env20724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20718_20724 : H12AffineEnvironment.transform 6 9 env20718 = env20724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20718 == env20724) = true)

def env20725 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1724,673,1773,292,171,1344,940,1025,293,1724,680,1005,139,553,957,1,1773,1297,941,1285,4294967296,257,4294967945,1344,512]

theorem envBound20725 : H12AffineFastState.Bounded env20725 := by
  intro p hp
  have h : env20725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20716_20725 : H12AffineEnvironment.transform 12 673 env20716 = env20725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 673 env20716 == env20725) = true)

theorem identity20725 : scanCanonicalize (H12AffineFastState.compose env20725 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 648) := by decide +kernel

theorem selectedBound20725 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20726 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1724,673,1773,292,171,1344,940,1025,293,1724,680,1005,139,553,957,1,1773,1297,941,1285,648,257,1,1344,512]

theorem envBound20726 : H12AffineFastState.Bounded env20726 := by
  intro p hp
  have h : env20726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20725_20726 : H12AffineEnvironment.transform 31 648 env20725 = env20726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 648 env20725 == env20726) = true)

theorem identity20726 : scanCanonicalize (H12AffineFastState.compose env20726 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 429) := by decide +kernel

theorem selectedBound20726 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20727 : List Nat := [2,4,8,16,32,64,128,256,429,1024,0,1297,268,1344,292,171,1344,1,1025,293,1297,261,64,139,388,16,1,1344,1297,0,1285,293,257,1,1344,429]

theorem envBound20727 : H12AffineFastState.Bounded env20727 := by
  intro p hp
  have h : env20727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20726_20727 : H12AffineEnvironment.transform 8 429 env20726 = env20727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 429 env20726 == env20727) = true)

theorem identity20727 : scanCanonicalize (H12AffineFastState.compose env20727 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound20727 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20728 : List Nat := [2,4,8,16,32,64,89,256,372,1024,0,1297,268,1344,292,114,1344,1,1025,293,1297,261,64,82,349,16,1,1344,1297,0,1285,293,257,1,1344,372]

theorem envBound20728 : H12AffineFastState.Bounded env20728 := by
  intro p hp
  have h : env20728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20727_20728 : H12AffineEnvironment.transform 6 89 env20727 = env20728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env20727 == env20728) = true)

def env20729 : List Nat := [2,4,8,16,0,64,89,256,340,1024,0,1297,268,1344,260,82,1344,1,1025,261,1297,261,64,82,349,16,1,1344,1297,0,1285,261,257,1,1344,340]

theorem envBound20729 : H12AffineFastState.Bounded env20729 := by
  intro p hp
  have h : env20729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20728_20729 : H12AffineEnvironment.transform 4 0 env20728 = env20729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20728 == env20729) = true)

def env20730 : List Nat := [2,4,8,16,0,16,9,256,260,1024,0,1297,268,1296,260,2,1296,1,1025,261,1297,261,16,2,269,16,1,1296,1297,0,1285,261,257,1,1296,260]

theorem envBound20730 : H12AffineFastState.Bounded env20730 := by
  intro p hp
  have h : env20730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20729_20730 : H12AffineEnvironment.transform 5 16 env20729 = env20730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20729 == env20730) = true)

theorem identity20730 : scanCanonicalize (H12AffineFastState.compose env20730 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound20730 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env20731 : List Nat := [2,4,8,16,0,16,9,5,1,1024,0,1044,9,1045,1,2,1045,1,1025,0,1044,0,16,2,8,16,1,1045,1044,0,1024,0,4,1,1045,1]

theorem envBound20731 : H12AffineFastState.Bounded env20731 := by
  intro p hp
  have h : env20731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20730_20731 : H12AffineEnvironment.transform 7 5 env20730 = env20731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env20730 == env20731) = true)

def leafEnv20731 : List Nat := [2,4,8,16,0,16,9,5,1,1024,0,1044,9,1045,1,2,1045,1,1025,0,1044,0,16,2,1025,8,1,16,1,1045,1044,0,1024,0,4,1,5,2,1045,1,0,1044,1]

def active20731 : List Nat := [0,1,2,3,9]

def tree20731 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20731 : H12WitnessSearch.Good tree20731 := H12GlobalWitnessIndex.good

theorem leafIdentity20731 : H12AffineFastState.composeSystem env20731 rootObs = leafEnv20731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20731 rootObs == leafEnv20731) = true)

theorem terminalChecked20731 : H12PackedTerminal.terminalCheckFast leafEnv20731 active20731 tree20731 = true := by decide +kernel

def env20732 : List Nat := [2,4,8,16,0,17,8,256,261,1024,0,1297,268,1297,260,3,1297,1,1025,261,1297,261,17,3,268,16,1,1297,1297,0,1285,261,257,1,1297,261]

theorem envBound20732 : H12AffineFastState.Bounded env20732 := by
  intro p hp
  have h : env20732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20729_20732 : H12AffineEnvironment.transform 5 17 env20729 = env20732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20729 == env20732) = true)

def env20733 : List Nat := [2,4,8,16,1,64,89,256,341,1024,0,1297,268,1344,261,83,1344,1,1025,260,1297,261,64,82,349,16,1,1344,1297,0,1285,260,257,1,1344,341]

theorem envBound20733 : H12AffineFastState.Bounded env20733 := by
  intro p hp
  have h : env20733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20728_20733 : H12AffineEnvironment.transform 4 1 env20728 = env20733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env20728 == env20733) = true)

theorem identity20733 : scanCanonicalize (H12AffineFastState.compose env20733 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound20733 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20734 : List Nat := [2,4,8,16,1,64,89,5,80,1024,0,1044,9,1093,0,83,1093,1,1025,1,1044,0,64,82,88,16,1,1093,1044,0,1024,1,4,1,1093,80]

theorem envBound20734 : H12AffineFastState.Bounded env20734 := by
  intro p hp
  have h : env20734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20733_20734 : H12AffineEnvironment.transform 7 5 env20733 = env20734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env20733 == env20734) = true)

def env20735 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1344,262144,304169,32769,4096,8201,17664,98564,8328,320888,33060,16384,324968,41000,1285,4294967296,257,4295074215,1344,512]

theorem envBound20735 : H12AffineFastState.Bounded env20735 := by
  intro p hp
  have h : env20735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20693_20735 : H12AffineEnvironment.transform 18 304169 env20693 = env20735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 304169 env20693 == env20735) = true)

theorem identity20735 : scanCanonicalize (H12AffineFastState.compose env20735 (packedSelected [4,9,18] rootPS)) = affineNative (2^(17+1) ^^^ 33060) := by decide +kernel

theorem selectedBound20735 : packedSelected [4,9,18] rootPS < 2^1333 := by decide +kernel

def env20736 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1344,33060,9485,32769,4096,8201,17664,98564,8328,25692,33060,16384,29772,41000,1285,4294967296,257,4295074215,1344,512]

theorem envBound20736 : H12AffineFastState.Bounded env20736 := by
  intro p hp
  have h : env20736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20735_20736 : H12AffineEnvironment.transform 17 33060 env20735 = env20736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 33060 env20735 == env20736) = true)

theorem identity20736 : scanCanonicalize (H12AffineFastState.compose env20736 (packedSelected [20,23] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound20736 : packedSelected [20,23] rootPS < 2^1333 := by decide +kernel

def env20737 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,268,16384,32768,65536,1344,33060,1025,32769,4096,261,17664,98564,388,17744,33060,16384,21824,33060,1285,4294967296,257,4295065771,1344,512]

theorem envBound20737 : H12AffineFastState.Bounded env20737 := by
  intro p hp
  have h : env20737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20736_20737 : H12AffineEnvironment.transform 12 268 env20736 = env20737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env20736 == env20737) = true)

theorem identity20737 : scanCanonicalize (H12AffineFastState.compose env20737 (packedSelected [0,7] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound20737 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env20738 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,268,16384,293,65536,1344,1,1025,292,4096,261,17664,65569,388,17744,1,16384,21824,1,1285,4294967296,257,4295033230,1344,512]

theorem envBound20738 : H12AffineFastState.Bounded env20738 := by
  intro p hp
  have h : env20738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20737_20738 : H12AffineEnvironment.transform 14 293 env20737 = env20738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env20737 == env20738) = true)

theorem identity20738 : scanCanonicalize (H12AffineFastState.compose env20738 (packedSelected [1,3,10,12,13] rootPS)) = affineNative (2^(15+1) ^^^ 16555) := by decide +kernel

theorem selectedBound20738 : packedSelected [1,3,10,12,13] rootPS < 2^1333 := by decide +kernel

def env20739 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,268,16384,293,16555,1344,1,1025,292,4096,261,17664,16522,388,17744,1,16384,21824,1,1285,4294967296,257,4294983973,1344,512]

theorem envBound20739 : H12AffineFastState.Bounded env20739 := by
  intro p hp
  have h : env20739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20738_20739 : H12AffineEnvironment.transform 15 16555 env20738 = env20739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 16555 env20738 == env20739) = true)

theorem identity20739 : scanCanonicalize (H12AffineFastState.compose env20739 (packedSelected [12,15] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound20739 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env20740 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,81,268,16384,293,16555,1344,1,1025,292,81,261,17664,16522,388,17744,1,16384,17681,1,1285,4294967296,257,4294983973,1344,512]

theorem envBound20740 : H12AffineFastState.Bounded env20740 := by
  intro p hp
  have h : env20740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20739_20740 : H12AffineEnvironment.transform 11 81 env20739 = env20740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env20739 == env20740) = true)

theorem identity20740 : scanCanonicalize (H12AffineFastState.compose env20740 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 1) := by decide +kernel

theorem selectedBound20740 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env20741 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,81,268,1,293,170,1344,1,1025,292,81,261,1281,139,388,1361,1,1,1296,1,1285,4294967296,257,4294967588,1344,512]

theorem envBound20741 : H12AffineFastState.Bounded env20741 := by
  intro p hp
  have h : env20741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20740_20741 : H12AffineEnvironment.transform 13 1 env20740 = env20741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1 env20740 == env20741) = true)

theorem identity20741 : scanCanonicalize (H12AffineFastState.compose env20741 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound20741 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20742 : List Nat := [2,4,8,16,32,64,128,256,512,53,0,81,268,1,293,170,373,1,52,292,81,261,308,139,388,356,1,1,293,1,304,4294967296,257,4294967588,373,512]

theorem envBound20742 : H12AffineFastState.Bounded env20742 := by
  intro p hp
  have h : env20742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20741_20742 : H12AffineEnvironment.transform 9 53 env20741 = env20742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env20741 == env20742) = true)

theorem identity20742 : scanCanonicalize (H12AffineFastState.compose env20742 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound20742 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env20743 : List Nat := [2,4,8,16,32,64,128,256,136,53,0,81,268,1,293,170,373,1,52,292,81,261,308,139,388,356,1,1,293,1,304,4294967296,257,4294967588,373,136]

theorem envBound20743 : H12AffineFastState.Bounded env20743 := by
  intro p hp
  have h : env20743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20742_20743 : H12AffineEnvironment.transform 8 136 env20742 = env20743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env20742 == env20743) = true)

theorem identity20743 : scanCanonicalize (H12AffineFastState.compose env20743 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 101) := by decide +kernel

theorem selectedBound20743 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env20744 : List Nat := [2,4,8,16,32,64,128,101,136,53,0,81,105,1,64,170,16,1,52,65,81,96,81,139,225,1,1,1,64,1,85,4294967296,100,4294967361,16,136]

theorem envBound20744 : H12AffineFastState.Bounded env20744 := by
  intro p hp
  have h : env20744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20743_20744 : H12AffineEnvironment.transform 7 101 env20743 = env20744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 101 env20743 == env20744) = true)

theorem identity20744 : scanCanonicalize (H12AffineFastState.compose env20744 (packedSelected [5] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound20744 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env20745 : List Nat := [2,4,8,16,32,64,35,101,43,53,0,81,105,1,64,9,16,1,52,65,81,96,81,40,66,1,1,1,64,1,85,4294967296,100,4294967361,16,43]

theorem envBound20745 : H12AffineFastState.Bounded env20745 := by
  intro p hp
  have h : env20745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20744_20745 : H12AffineEnvironment.transform 6 35 env20744 = env20745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env20744 == env20745) = true)

theorem identity20745 : scanCanonicalize (H12AffineFastState.compose env20745 (packedSelected [8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound20745 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env20746 : List Nat := [2,4,8,16,32,17,35,52,43,53,0,0,56,1,17,9,16,1,52,16,0,49,0,40,19,1,1,1,17,1,4,4294967296,53,4294967312,16,43]

theorem envBound20746 : H12AffineFastState.Bounded env20746 := by
  intro p hp
  have h : env20746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20745_20746 : H12AffineEnvironment.transform 5 17 env20745 = env20746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20745 == env20746) = true)

theorem identity20746 : scanCanonicalize (H12AffineFastState.compose env20746 (packedSelected [0,1] rootPS)) = affineNative (2^(31+1) ^^^ 11) := by decide +kernel

theorem selectedBound20746 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env20747 : List Nat := [2,4,8,16,32,17,35,52,43,53,0,0,56,1,17,9,16,1,52,16,0,49,0,40,19,1,1,1,17,1,4,11,53,27,16,43]

theorem envBound20747 : H12AffineFastState.Bounded env20747 := by
  intro p hp
  have h : env20747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20746_20747 : H12AffineEnvironment.transform 31 11 env20746 = env20747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 11 env20746 == env20747) = true)

def env20748 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1345,262144,524288,32769,4096,8201,17665,98565,8328,541008,795916,16384,545088,1073741824,1284,4294967296,257,4295074214,1344,512]

theorem envBound20748 : H12AffineFastState.Bounded env20748 := by
  intro p hp
  have h : env20748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20691_20748 : H12AffineEnvironment.transform 16 1345 env20691 = env20748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env20691 == env20748) = true)

theorem identity20748 : scanCanonicalize (H12AffineFastState.compose env20748 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 41080) := by decide +kernel

theorem selectedBound20748 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env20749 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1345,262144,524288,32769,4096,8201,17665,98565,8328,541008,795916,16384,545088,41080,1284,4294967296,257,4295074214,1344,512]

theorem envBound20749 : H12AffineFastState.Bounded env20749 := by
  intro p hp
  have h : env20749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20748_20749 : H12AffineEnvironment.transform 29 41080 env20748 = env20749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 41080 env20748 == env20749) = true)

theorem identity20749 : scanCanonicalize (H12AffineFastState.compose env20749 (packedSelected [4,9,16] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound20749 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env20750 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,1345,262144,1025,32769,4096,8201,17665,98565,8328,17745,270605,16384,21825,41080,1284,4294967296,257,4295074214,1344,512]

theorem envBound20750 : H12AffineFastState.Bounded env20750 := by
  intro p hp
  have h : env20750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20749_20750 : H12AffineEnvironment.transform 18 1025 env20749 = env20750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env20749 == env20750) = true)

theorem identity20750 : scanCanonicalize (H12AffineFastState.compose env20750 (packedSelected [1,5,8,15,17,21,24,38] rootPS)) = affineNative (2^(15+1) ^^^ 251) := by decide +kernel

theorem selectedBound20750 : packedSelected [1,5,8,15,17,21,24,38] rootPS < 2^1333 := by decide +kernel

def env20751 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,251,1345,262144,1025,32769,4096,8201,17665,33278,8328,17745,270605,16384,21825,41080,1284,4294967296,257,4295008605,1344,512]

theorem envBound20751 : H12AffineFastState.Bounded env20751 := by
  intro p hp
  have h : env20751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20750_20751 : H12AffineEnvironment.transform 15 251 env20750 = env20751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 251 env20750 == env20751) = true)

theorem identity20751 : scanCanonicalize (H12AffineFastState.compose env20751 (packedSelected [13,21] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound20751 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env20752 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,4177,32768,251,1345,262144,1025,32769,4096,8201,5456,33278,8328,5376,270605,4177,1296,41080,1284,4294967296,257,4295008605,1344,512]

theorem envBound20752 : H12AffineFastState.Bounded env20752 := by
  intro p hp
  have h : env20752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20751_20752 : H12AffineEnvironment.transform 13 4177 env20751 = env20752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env20751 == env20752) = true)

theorem identity20752 : scanCanonicalize (H12AffineFastState.compose env20752 (packedSelected [3,5,10] rootPS)) = affineNative (2^(31+1) ^^^ 8321) := by decide +kernel

theorem selectedBound20752 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env20753 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,4177,32768,251,1345,262144,1025,32769,4096,8201,5456,33278,8328,5376,270605,4177,1296,41080,1284,8321,257,33244,1344,512]

theorem envBound20753 : H12AffineFastState.Bounded env20753 := by
  intro p hp
  have h : env20753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20752_20753 : H12AffineEnvironment.transform 31 8321 env20752 = env20753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 8321 env20752 == env20753) = true)

theorem identity20753 : scanCanonicalize (H12AffineFastState.compose env20753 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 8541) := by decide +kernel

theorem selectedBound20753 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env20754 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,4177,32768,251,1345,8541,1025,32769,4096,8201,5456,33278,8328,5376,80,4177,1296,41080,1284,8321,257,33244,1344,512]

theorem envBound20754 : H12AffineFastState.Bounded env20754 := by
  intro p hp
  have h : env20754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20753_20754 : H12AffineEnvironment.transform 17 8541 env20753 = env20754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8541 env20753 == env20754) = true)

theorem identity20754 : scanCanonicalize (H12AffineFastState.compose env20754 (packedSelected [3,8,12,13] rootPS)) = affineNative (2^(12+1) ^^^ 5480) := by decide +kernel

theorem selectedBound20754 : packedSelected [3,8,12,13] rootPS < 2^1333 := by decide +kernel

def env20755 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,5480,4177,32768,251,1345,5173,1025,32769,4096,5473,5456,33278,5600,5376,80,4177,1296,38160,1284,5609,257,33244,1344,512]

theorem envBound20755 : H12AffineFastState.Bounded env20755 := by
  intro p hp
  have h : env20755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20754_20755 : H12AffineEnvironment.transform 12 5480 env20754 = env20755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5480 env20754 == env20755) = true)

theorem identity20755 : scanCanonicalize (H12AffineFastState.compose env20755 (packedSelected [3,5,12,17] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound20755 : packedSelected [3,5,12,17] rootPS < 2^1333 := by decide +kernel

def env20756 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,5480,4177,137,251,1345,5173,1025,136,4096,5473,5456,375,5600,5376,80,4177,1296,5529,1284,5609,257,341,1344,512]

theorem envBound20756 : H12AffineFastState.Bounded env20756 := by
  intro p hp
  have h : env20756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20755_20756 : H12AffineEnvironment.transform 14 137 env20755 = env20756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env20755 == env20756) = true)

theorem identity20756 : scanCanonicalize (H12AffineFastState.compose env20756 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 1464) := by decide +kernel

theorem selectedBound20756 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env20757 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1464,208,1513,137,251,1345,397,1025,136,1464,217,232,375,88,184,80,1513,1296,33,1284,81,257,341,1344,512]

theorem envBound20757 : H12AffineFastState.Bounded env20757 := by
  intro p hp
  have h : env20757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20756_20757 : H12AffineEnvironment.transform 11 1464 env20756 = env20757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1464 env20756 == env20757) = true)

theorem identity20757 : scanCanonicalize (H12AffineFastState.compose env20757 (packedSelected [0,9] rootPS)) = affineNative (2^(8+1) ^^^ 341) := by decide +kernel

theorem selectedBound20757 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env20758 : List Nat := [2,4,8,16,32,64,128,256,341,1024,0,1464,208,1513,137,251,1345,397,1025,136,1464,217,232,375,88,184,80,1513,1296,33,1284,81,257,341,1344,341]

theorem envBound20758 : H12AffineFastState.Bounded env20758 := by
  intro p hp
  have h : env20758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20757_20758 : H12AffineEnvironment.transform 8 341 env20757 = env20758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env20757 == env20758) = true)

theorem identity20758 : scanCanonicalize (H12AffineFastState.compose env20758 (packedSelected [1,2,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 141) := by decide +kernel

theorem selectedBound20758 : packedSelected [1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env20759 : List Nat := [2,4,8,16,32,64,128,256,341,141,0,309,208,356,137,251,460,397,140,136,309,217,232,375,88,184,80,356,413,33,393,81,257,341,461,341]

theorem envBound20759 : H12AffineFastState.Bounded env20759 := by
  intro p hp
  have h : env20759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20758_20759 : H12AffineEnvironment.transform 9 141 env20758 = env20759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 141 env20758 == env20759) = true)

theorem identity20759 : scanCanonicalize (H12AffineFastState.compose env20759 (packedSelected [0,1,2,3,4,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 104) := by decide +kernel

theorem selectedBound20759 : packedSelected [0,1,2,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env20760 : List Nat := [2,4,8,16,32,64,104,256,341,101,0,309,56,356,97,19,292,357,100,96,309,49,0,375,88,80,80,356,373,33,353,81,257,341,293,341]

theorem envBound20760 : H12AffineFastState.Bounded env20760 := by
  intro p hp
  have h : env20760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20759_20760 : H12AffineEnvironment.transform 6 104 env20759 = env20760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 104 env20759 == env20760) = true)

theorem identity20760 : scanCanonicalize (H12AffineFastState.compose env20760 (packedSelected [1,4] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound20760 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env20761 : List Nat := [2,4,8,16,32,32,8,256,309,5,0,309,56,260,1,19,292,261,4,0,309,49,0,279,56,48,48,260,277,33,257,49,257,309,293,309]

theorem envBound20761 : H12AffineFastState.Bounded env20761 := by
  intro p hp
  have h : env20761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20760_20761 : H12AffineEnvironment.transform 5 32 env20760 = env20761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env20760 == env20761) = true)

theorem identity20761 : scanCanonicalize (H12AffineFastState.compose env20761 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound20761 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20762 : List Nat := [2,4,8,16,17,17,8,256,260,5,0,260,9,260,1,19,277,261,4,0,260,0,0,279,9,1,1,260,277,16,257,0,257,260,276,260]

theorem envBound20762 : H12AffineFastState.Bounded env20762 := by
  intro p hp
  have h : env20762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20761_20762 : H12AffineEnvironment.transform 4 17 env20761 = env20762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env20761 == env20762) = true)

theorem identity20762 : scanCanonicalize (H12AffineFastState.compose env20762 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound20762 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20763 : List Nat := [2,4,8,16,17,17,8,4,0,5,0,0,9,0,1,19,17,1,4,0,0,0,0,19,9,1,1,0,17,16,5,0,5,0,16,0]

theorem envBound20763 : H12AffineFastState.Bounded env20763 := by
  intro p hp
  have h : env20763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20762_20763 : H12AffineEnvironment.transform 7 4 env20762 = env20763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env20762 == env20763) = true)

theorem identity20763 : scanCanonicalize (H12AffineFastState.compose env20763 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound20763 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20764 : List Nat := [2,4,8,1,0,0,8,4,0,5,0,0,9,0,1,2,0,1,4,0,0,0,0,2,9,1,1,0,0,1,5,0,5,0,1,0]

theorem envBound20764 : H12AffineFastState.Bounded env20764 := by
  intro p hp
  have h : env20764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20763_20764 : H12AffineEnvironment.transform 3 1 env20763 = env20764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env20763 == env20764) = true)

def env20765 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,8200,147520,230468,8328,672785,925772,16384,676865,1073741824,131141,4294967296,257,4295206118,1344,512]

theorem envBound20765 : H12AffineFastState.Bounded env20765 := by
  intro p hp
  have h : env20765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20690_20765 : H12AffineEnvironment.transform 10 1 env20690 = env20765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env20690 == env20765) = true)

def env20766 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1344,262144,524288,32769,4096,8200,17664,98564,8328,541009,795916,16384,545089,1073741824,1285,4294967296,257,4295074214,1344,512]

theorem envBound20766 : H12AffineFastState.Bounded env20766 := by
  intro p hp
  have h : env20766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20765_20766 : H12AffineEnvironment.transform 16 1344 env20765 = env20766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env20765 == env20766) = true)

theorem identity20766 : scanCanonicalize (H12AffineFastState.compose env20766 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 787456) := by decide +kernel

theorem selectedBound20766 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env20767 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1344,262144,524288,32769,4096,8200,17664,98564,8328,541009,795916,16384,545089,787456,1285,4294967296,257,4295074214,1344,512]

theorem envBound20767 : H12AffineFastState.Bounded env20767 := by
  intro p hp
  have h : env20767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20766_20767 : H12AffineEnvironment.transform 29 787456 env20766 = env20767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 787456 env20766 == env20767) = true)

def env20768 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1344,262144,304168,32769,4096,8200,17664,98564,8328,320889,33060,16384,324969,41000,1285,4294967296,257,4295074214,1344,512]

theorem envBound20768 : H12AffineFastState.Bounded env20768 := by
  intro p hp
  have h : env20768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20767_20768 : H12AffineEnvironment.transform 18 304168 env20767 = env20768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 304168 env20767 == env20768) = true)

theorem identity20768 : scanCanonicalize (H12AffineFastState.compose env20768 (packedSelected [4,9,18] rootPS)) = affineNative (2^(17+1) ^^^ 33060) := by decide +kernel

theorem selectedBound20768 : packedSelected [4,9,18] rootPS < 2^1333 := by decide +kernel

def env20769 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1344,33060,9484,32769,4096,8200,17664,98564,8328,25693,33060,16384,29773,41000,1285,4294967296,257,4295074214,1344,512]

theorem envBound20769 : H12AffineFastState.Bounded env20769 := by
  intro p hp
  have h : env20769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20768_20769 : H12AffineEnvironment.transform 17 33060 env20768 = env20769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 33060 env20768 == env20769) = true)

theorem identity20769 : scanCanonicalize (H12AffineFastState.compose env20769 (packedSelected [20,23] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound20769 : packedSelected [20,23] rootPS < 2^1333 := by decide +kernel

def env20770 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,268,16384,32768,65536,1344,33060,1024,32769,4096,260,17664,98564,388,17745,33060,16384,21825,33060,1285,4294967296,257,4295065770,1344,512]

theorem envBound20770 : H12AffineFastState.Bounded env20770 := by
  intro p hp
  have h : env20770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20769_20770 : H12AffineEnvironment.transform 12 268 env20769 = env20770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env20769 == env20770) = true)

theorem identity20770 : scanCanonicalize (H12AffineFastState.compose env20770 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 4176) := by decide +kernel

theorem selectedBound20770 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env20771 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,268,4176,32768,65536,1344,33060,1024,32769,4096,260,5456,98564,388,5377,33060,4176,1297,33060,1285,4294967296,257,4295065770,1344,512]

theorem envBound20771 : H12AffineFastState.Bounded env20771 := by
  intro p hp
  have h : env20771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20770_20771 : H12AffineEnvironment.transform 13 4176 env20770 = env20771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env20770 == env20771) = true)

theorem identity20771 : scanCanonicalize (H12AffineFastState.compose env20771 (packedSelected [1,3,5,8,10,13,15] rootPS)) = affineNative (2^(15+1) ^^^ 38422) := by decide +kernel

theorem selectedBound20771 : packedSelected [1,3,5,8,10,13,15] rootPS < 2^1333 := by decide +kernel

def env20772 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,268,4176,32768,38422,1344,33060,1024,32769,4096,260,5456,5906,388,5377,33060,4176,1297,33060,1285,4294967296,257,4294973116,1344,512]

theorem envBound20772 : H12AffineFastState.Bounded env20772 := by
  intro p hp
  have h : env20772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20771_20772 : H12AffineEnvironment.transform 15 38422 env20771 = env20772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38422 env20771 == env20772) = true)

theorem identity20772 : scanCanonicalize (H12AffineFastState.compose env20772 (packedSelected [5,8,10,12,17] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound20772 : packedSelected [5,8,10,12,17] rootPS < 2^1333 := by decide +kernel

def env20773 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,4096,268,4176,32768,38047,1344,33060,1024,32769,4096,260,5456,5531,388,5377,33060,4176,1297,33060,1285,4294967296,257,4294972469,1344,137]

theorem envBound20773 : H12AffineFastState.Bounded env20773 := by
  intro p hp
  have h : env20773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20772_20773 : H12AffineEnvironment.transform 8 137 env20772 = env20773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env20772 == env20773) = true)

theorem identity20773 : scanCanonicalize (H12AffineFastState.compose env20773 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound20773 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env20774 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,4096,268,4176,292,5563,1344,0,1024,293,4096,260,5456,5531,388,5377,0,4176,1297,0,1285,4294967296,257,4294972469,1344,137]

theorem envBound20774 : H12AffineFastState.Bounded env20774 := by
  intro p hp
  have h : env20774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20773_20774 : H12AffineEnvironment.transform 14 292 env20773 = env20774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env20773 == env20774) = true)

theorem identity20774 : scanCanonicalize (H12AffineFastState.compose env20774 (packedSelected [1,3,5] rootPS)) = affineNative (2^(11+1) ^^^ 1213) := by decide +kernel

theorem selectedBound20774 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env20775 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,1213,268,1261,292,262,1344,0,1024,293,1213,260,493,294,388,444,0,1261,1297,0,1285,4294967296,257,4294967432,1344,137]

theorem envBound20775 : H12AffineFastState.Bounded env20775 := by
  intro p hp
  have h : env20775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20774_20775 : H12AffineEnvironment.transform 11 1213 env20774 = env20775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1213 env20774 == env20775) = true)

theorem identity20775 : scanCanonicalize (H12AffineFastState.compose env20775 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 216) := by decide +kernel

theorem selectedBound20775 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20776 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,1213,268,1261,292,262,1344,0,1024,293,1213,260,493,294,388,444,0,1261,1297,0,1285,216,257,80,1344,137]

theorem envBound20776 : H12AffineFastState.Bounded env20776 := by
  intro p hp
  have h : env20776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20775_20776 : H12AffineEnvironment.transform 31 216 env20775 = env20776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 216 env20775 == env20776) = true)

def env20777 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1344,262144,304169,32769,4096,8200,17664,98564,8328,320888,33061,16384,324968,41001,1285,4294967296,257,4295074214,1344,512]

theorem envBound20777 : H12AffineFastState.Bounded env20777 := by
  intro p hp
  have h : env20777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20767_20777 : H12AffineEnvironment.transform 18 304169 env20767 = env20777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 304169 env20767 == env20777) = true)

theorem identity20777 : scanCanonicalize (H12AffineFastState.compose env20777 (packedSelected [4,9,18] rootPS)) = affineNative (2^(17+1) ^^^ 8461) := by decide +kernel

theorem selectedBound20777 : packedSelected [4,9,18] rootPS < 2^1333 := by decide +kernel

def env20778 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1344,8461,34084,32769,4096,8200,17664,98564,8328,50293,33061,16384,54373,41001,1285,4294967296,257,4295074214,1344,512]

theorem envBound20778 : H12AffineFastState.Bounded env20778 := by
  intro p hp
  have h : env20778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20777_20778 : H12AffineEnvironment.transform 17 8461 env20777 = env20778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8461 env20777 == env20778) = true)

theorem identity20778 : scanCanonicalize (H12AffineFastState.compose env20778 (packedSelected [5,8,13,15,19] rootPS)) = affineNative (2^(15+1) ^^^ 33167) := by decide +kernel

theorem selectedBound20778 : packedSelected [5,8,13,15,19] rootPS < 2^1333 := by decide +kernel

def env20779 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,33167,1344,8461,34084,32769,4096,8200,17664,139,8328,50293,33061,16384,54373,41001,1285,4294967296,257,4294975529,1344,512]

theorem envBound20779 : H12AffineFastState.Bounded env20779 := by
  intro p hp
  have h : env20779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20778_20779 : H12AffineEnvironment.transform 15 33167 env20778 = env20779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33167 env20778 == env20779) = true)

def env20780 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,18376,17991,1344,8461,17132,18377,4096,8200,17664,139,8328,957,18157,16384,5037,26593,1285,4294967296,257,4294975529,1344,512]

theorem envBound20780 : H12AffineFastState.Bounded env20780 := by
  intro p hp
  have h : env20780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20779_20780 : H12AffineEnvironment.transform 14 18376 env20779 = env20780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 18376 env20779 == env20780) = true)

theorem identity20780 : scanCanonicalize (H12AffineFastState.compose env20780 (packedSelected [1,3,10,13] rootPS)) = affineNative (2^(11+1) ^^^ 1724) := by decide +kernel

theorem selectedBound20780 : packedSelected [1,3,10,13] rootPS < 2^1333 := by decide +kernel

def env20781 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1724,8192,16384,18376,17991,1344,8461,17132,18377,1724,8200,17664,139,8328,957,18157,16384,1297,26593,1285,4294967296,257,4294975529,1344,512]

theorem envBound20781 : H12AffineFastState.Bounded env20781 := by
  intro p hp
  have h : env20781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20780_20781 : H12AffineEnvironment.transform 11 1724 env20780 = env20781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1724 env20780 == env20781) = true)

theorem identity20781 : scanCanonicalize (H12AffineFastState.compose env20781 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 1773) := by decide +kernel

theorem selectedBound20781 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env20782 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1724,8192,1773,293,170,1344,8461,1025,292,1724,8200,1005,139,8328,957,0,1773,1297,8460,1285,4294967296,257,4294975529,1344,512]

theorem envBound20782 : H12AffineFastState.Bounded env20782 := by
  intro p hp
  have h : env20782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20781_20782 : H12AffineEnvironment.transform 13 1773 env20781 = env20782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1773 env20781 == env20782) = true)

def env20783 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1724,672,1773,293,170,1344,941,1025,292,1724,680,1005,139,552,957,0,1773,1297,940,1285,4294967296,257,4294967945,1344,512]

theorem envBound20783 : H12AffineFastState.Bounded env20783 := by
  intro p hp
  have h : env20783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20782_20783 : H12AffineEnvironment.transform 12 672 env20782 = env20783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 672 env20782 == env20783) = true)

theorem identity20783 : scanCanonicalize (H12AffineFastState.compose env20783 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 648) := by decide +kernel

theorem selectedBound20783 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20784 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1724,672,1773,293,170,1344,941,1025,292,1724,680,1005,139,552,957,0,1773,1297,940,1285,648,257,1,1344,512]

theorem envBound20784 : H12AffineFastState.Bounded env20784 := by
  intro p hp
  have h : env20784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20783_20784 : H12AffineEnvironment.transform 31 648 env20783 = env20784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 648 env20783 == env20784) = true)

theorem identity20784 : scanCanonicalize (H12AffineFastState.compose env20784 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 429) := by decide +kernel

theorem selectedBound20784 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20785 : List Nat := [2,4,8,16,32,64,128,256,429,1024,1,1297,269,1344,293,170,1344,0,1025,292,1297,261,64,139,389,16,0,1344,1297,1,1285,293,257,1,1344,429]

theorem envBound20785 : H12AffineFastState.Bounded env20785 := by
  intro p hp
  have h : env20785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20784_20785 : H12AffineEnvironment.transform 8 429 env20784 = env20785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 429 env20784 == env20785) = true)

theorem identity20785 : scanCanonicalize (H12AffineFastState.compose env20785 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound20785 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20786 : List Nat := [2,4,8,16,32,64,89,256,372,1024,1,1297,269,1344,293,115,1344,0,1025,292,1297,261,64,82,348,16,0,1344,1297,1,1285,293,257,1,1344,372]

theorem envBound20786 : H12AffineFastState.Bounded env20786 := by
  intro p hp
  have h : env20786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20785_20786 : H12AffineEnvironment.transform 6 89 env20785 = env20786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env20785 == env20786) = true)

def env20787 : List Nat := [2,4,8,16,0,64,89,256,340,1024,1,1297,269,1344,261,83,1344,0,1025,260,1297,261,64,82,348,16,0,1344,1297,1,1285,261,257,1,1344,340]

theorem envBound20787 : H12AffineFastState.Bounded env20787 := by
  intro p hp
  have h : env20787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20786_20787 : H12AffineEnvironment.transform 4 0 env20786 = env20787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20786 == env20787) = true)

def env20788 : List Nat := [2,4,8,16,0,16,9,256,260,1024,1,1297,269,1296,261,3,1296,0,1025,260,1297,261,16,2,268,16,0,1296,1297,1,1285,261,257,1,1296,260]

theorem envBound20788 : H12AffineFastState.Bounded env20788 := by
  intro p hp
  have h : env20788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20787_20788 : H12AffineEnvironment.transform 5 16 env20787 = env20788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20787 == env20788) = true)

theorem identity20788 : scanCanonicalize (H12AffineFastState.compose env20788 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound20788 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env20789 : List Nat := [2,4,8,16,0,16,9,5,1,1024,1,1044,8,1045,0,3,1045,0,1025,1,1044,0,16,2,9,16,0,1045,1044,1,1024,0,4,1,1045,1]

theorem envBound20789 : H12AffineFastState.Bounded env20789 := by
  intro p hp
  have h : env20789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20788_20789 : H12AffineEnvironment.transform 7 5 env20788 = env20789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env20788 == env20789) = true)

def leafEnv20789 : List Nat := [2,4,8,16,0,16,9,5,1,1024,1,1044,8,1045,0,3,1045,0,1025,1,1044,0,16,2,1025,9,1,16,0,1045,1044,1,1024,0,4,1,5,3,1045,1,0,1044,1]

def active20789 : List Nat := [0,1,2,3,9]

def tree20789 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20789 : H12WitnessSearch.Good tree20789 := H12GlobalWitnessIndex.good

theorem leafIdentity20789 : H12AffineFastState.composeSystem env20789 rootObs = leafEnv20789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20789 rootObs == leafEnv20789) = true)

theorem terminalChecked20789 : H12PackedTerminal.terminalCheckFast leafEnv20789 active20789 tree20789 = true := by decide +kernel

def env20790 : List Nat := [2,4,8,16,0,17,8,256,261,1024,1,1297,269,1297,261,2,1297,0,1025,260,1297,261,17,3,269,16,0,1297,1297,1,1285,261,257,1,1297,261]

theorem envBound20790 : H12AffineFastState.Bounded env20790 := by
  intro p hp
  have h : env20790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20787_20790 : H12AffineEnvironment.transform 5 17 env20787 = env20790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20787 == env20790) = true)

def env20791 : List Nat := [2,4,8,16,1,64,89,256,341,1024,1,1297,269,1344,260,82,1344,0,1025,261,1297,261,64,82,348,16,0,1344,1297,1,1285,260,257,1,1344,341]

theorem envBound20791 : H12AffineFastState.Bounded env20791 := by
  intro p hp
  have h : env20791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20786_20791 : H12AffineEnvironment.transform 4 1 env20786 = env20791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env20786 == env20791) = true)

theorem identity20791 : scanCanonicalize (H12AffineFastState.compose env20791 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound20791 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20792 : List Nat := [2,4,8,16,1,64,89,5,80,1024,1,1044,8,1093,1,82,1093,0,1025,0,1044,0,64,82,89,16,0,1093,1044,1,1024,1,4,1,1093,80]

theorem envBound20792 : H12AffineFastState.Bounded env20792 := by
  intro p hp
  have h : env20792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20791_20792 : H12AffineEnvironment.transform 7 5 env20791 = env20792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env20791 == env20792) = true)

def env20793 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1724,673,1773,293,170,1344,940,1025,292,1724,681,1005,139,553,957,0,1773,1297,941,1285,4294967296,257,4294967944,1344,512]

theorem envBound20793 : H12AffineFastState.Bounded env20793 := by
  intro p hp
  have h : env20793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20782_20793 : H12AffineEnvironment.transform 12 673 env20782 = env20793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 673 env20782 == env20793) = true)

theorem identity20793 : scanCanonicalize (H12AffineFastState.compose env20793 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 428) := by decide +kernel

theorem selectedBound20793 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20794 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1724,673,1773,293,170,1344,940,1025,292,1724,681,1005,139,553,957,0,1773,1297,941,1285,428,257,804,1344,512]

theorem envBound20794 : H12AffineFastState.Bounded env20794 := by
  intro p hp
  have h : env20794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20793_20794 : H12AffineEnvironment.transform 31 428 env20793 = env20794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 428 env20793 == env20794) = true)

def env20795 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1,1588,553,1637,293,34,1344,804,1025,292,1588,545,869,3,553,821,0,1637,1297,805,1285,292,257,804,1344,512]

theorem envBound20795 : H12AffineFastState.Bounded env20795 := by
  intro p hp
  have h : env20795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20794_20795 : H12AffineEnvironment.transform 6 8 env20794 = env20795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20794 == env20795) = true)

theorem identity20795 : scanCanonicalize (H12AffineFastState.compose env20795 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound20795 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20796 : List Nat := [2,4,8,16,32,64,8,256,293,1024,1,1297,268,1344,293,34,1344,1,1025,292,1297,260,64,3,268,16,0,1344,1297,0,1285,292,257,1,1344,293]

theorem envBound20796 : H12AffineFastState.Bounded env20796 := by
  intro p hp
  have h : env20796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20795_20796 : H12AffineEnvironment.transform 8 293 env20795 = env20796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env20795 == env20796) = true)

theorem identity20796 : scanCanonicalize (H12AffineFastState.compose env20796 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound20796 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env20797 : List Nat := [2,4,8,16,32,64,8,116,81,1024,1,1125,120,1076,81,34,1076,1,1025,80,1125,112,64,3,120,16,0,1076,1125,0,1137,80,117,1,1076,81]

theorem envBound20797 : H12AffineFastState.Bounded env20797 := by
  intro p hp
  have h : env20797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20796_20797 : H12AffineEnvironment.transform 7 116 env20796 = env20797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env20796 == env20797) = true)

theorem identity20797 : scanCanonicalize (H12AffineFastState.compose env20797 (packedSelected [5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound20797 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env20798 : List Nat := [2,4,8,16,32,16,8,36,1,1024,1,1077,40,1076,1,34,1076,1,1025,0,1077,32,16,3,40,16,0,1076,1077,0,1057,0,37,1,1076,1]

theorem envBound20798 : H12AffineFastState.Bounded env20798 := by
  intro p hp
  have h : env20798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20797_20798 : H12AffineEnvironment.transform 5 16 env20797 = env20798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20797 == env20798) = true)

theorem identity20798 : scanCanonicalize (H12AffineFastState.compose env20798 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound20798 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20799 : List Nat := [2,4,8,16,0,16,8,4,1,1024,1,1045,8,1044,1,2,1044,1,1025,0,1045,0,16,3,8,16,0,1044,1045,0,1025,0,5,1,1044,1]

theorem envBound20799 : H12AffineFastState.Bounded env20799 := by
  intro p hp
  have h : env20799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20798_20799 : H12AffineEnvironment.transform 4 0 env20798 = env20799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20798 == env20799) = true)

def leafEnv20799 : List Nat := [2,4,8,16,0,16,8,4,1,1024,1,1045,8,1044,1,2,1044,1,1025,0,1045,0,16,3,1024,8,1,16,0,1044,1045,0,1025,0,5,1,5,3,1044,1,0,1045,1]

def active20799 : List Nat := [0,1,2,3,9]

def tree20799 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20799 : H12WitnessSearch.Good tree20799 := H12GlobalWitnessIndex.good

theorem leafIdentity20799 : H12AffineFastState.composeSystem env20799 rootObs = leafEnv20799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20799 rootObs == leafEnv20799) = true)

theorem terminalChecked20799 : H12PackedTerminal.terminalCheckFast leafEnv20799 active20799 tree20799 = true := by decide +kernel

def env20800 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1,1589,552,1636,293,35,1344,805,1025,292,1589,544,868,2,553,820,0,1636,1297,804,1285,293,257,804,1344,512]

theorem envBound20800 : H12AffineFastState.Bounded env20800 := by
  intro p hp
  have h : env20800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20794_20800 : H12AffineEnvironment.transform 6 9 env20794 = env20800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20794 == env20800) = true)

def env20801 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,18377,17990,1344,8461,17133,18376,4096,8200,17664,139,8328,956,18156,16384,5036,26592,1285,4294967296,257,4294975529,1344,512]

theorem envBound20801 : H12AffineFastState.Bounded env20801 := by
  intro p hp
  have h : env20801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20779_20801 : H12AffineEnvironment.transform 14 18377 env20779 = env20801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 18377 env20779 == env20801) = true)

theorem identity20801 : scanCanonicalize (H12AffineFastState.compose env20801 (packedSelected [1,3,10,13] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound20801 : packedSelected [1,3,10,13] rootPS < 2^1333 := by decide +kernel

def env20802 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4177,6040,5655,1344,8461,4796,6041,4096,8200,5457,139,8328,956,5821,4177,5036,14257,1285,4294967296,257,4294975529,1344,512]

theorem envBound20802 : H12AffineFastState.Bounded env20802 := by
  intro p hp
  have h : env20802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20801_20802 : H12AffineEnvironment.transform 13 4177 env20801 = env20802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env20801 == env20802) = true)

theorem identity20802 : scanCanonicalize (H12AffineFastState.compose env20802 (packedSelected [4,5,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 1725) := by decide +kernel

theorem selectedBound20802 : packedSelected [4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env20803 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1725,8192,1772,293,170,1344,8461,1025,292,1725,8200,1004,139,8328,956,0,1772,1297,8460,1285,4294967296,257,4294975529,1344,512]

theorem envBound20803 : H12AffineFastState.Bounded env20803 := by
  intro p hp
  have h : env20803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20802_20803 : H12AffineEnvironment.transform 11 1725 env20802 = env20803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1725 env20802 == env20803) = true)

def env20804 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1725,672,1772,293,170,1344,941,1025,292,1725,680,1004,139,552,956,0,1772,1297,940,1285,4294967296,257,4294967945,1344,512]

theorem envBound20804 : H12AffineFastState.Bounded env20804 := by
  intro p hp
  have h : env20804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20803_20804 : H12AffineEnvironment.transform 12 672 env20803 = env20804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 672 env20803 == env20804) = true)

theorem identity20804 : scanCanonicalize (H12AffineFastState.compose env20804 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 649) := by decide +kernel

theorem selectedBound20804 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20805 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1725,672,1772,293,170,1344,941,1025,292,1725,680,1004,139,552,956,0,1772,1297,940,1285,649,257,0,1344,512]

theorem envBound20805 : H12AffineFastState.Bounded env20805 := by
  intro p hp
  have h : env20805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20804_20805 : H12AffineEnvironment.transform 31 649 env20804 = env20805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 649 env20804 == env20805) = true)

def env20806 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1,1589,552,1636,293,34,1344,805,1025,292,1589,544,868,3,552,820,0,1636,1297,804,1285,513,257,0,1344,512]

theorem envBound20806 : H12AffineFastState.Bounded env20806 := by
  intro p hp
  have h : env20806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20805_20806 : H12AffineEnvironment.transform 6 8 env20805 = env20806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20805 == env20806) = true)

theorem identity20806 : scanCanonicalize (H12AffineFastState.compose env20806 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound20806 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20807 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1,1589,552,1588,293,34,1296,805,1025,292,1589,544,820,3,552,820,0,1588,1297,804,1285,513,257,0,1296,512]

theorem envBound20807 : H12AffineFastState.Bounded env20807 := by
  intro p hp
  have h : env20807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20806_20807 : H12AffineEnvironment.transform 5 16 env20806 = env20807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20806 == env20807) = true)

def env20808 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1,1588,553,1637,293,35,1344,804,1025,292,1588,545,869,2,552,821,0,1637,1297,805,1285,512,257,0,1344,512]

theorem envBound20808 : H12AffineFastState.Bounded env20808 := by
  intro p hp
  have h : env20808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20805_20808 : H12AffineEnvironment.transform 6 9 env20805 = env20808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20805 == env20808) = true)

theorem identity20808 : scanCanonicalize (H12AffineFastState.compose env20808 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 372) := by decide +kernel

theorem selectedBound20808 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20809 : List Nat := [2,4,8,16,32,64,9,256,372,1024,1,1344,349,1297,293,35,1344,80,1025,292,1344,341,17,2,348,65,0,1297,1297,81,1285,372,257,0,1344,372]

theorem envBound20809 : H12AffineFastState.Bounded env20809 := by
  intro p hp
  have h : env20809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20808_20809 : H12AffineEnvironment.transform 8 372 env20808 = env20809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 372 env20808 == env20809) = true)

theorem identity20809 : scanCanonicalize (H12AffineFastState.compose env20809 (packedSelected [5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound20809 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env20810 : List Nat := [2,4,8,16,32,16,9,256,292,1024,1,1296,269,1297,293,35,1296,0,1025,292,1296,261,17,2,268,17,0,1297,1297,1,1285,292,257,0,1296,292]

theorem envBound20810 : H12AffineFastState.Bounded env20810 := by
  intro p hp
  have h : env20810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20809_20810 : H12AffineEnvironment.transform 5 16 env20809 = env20810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20809 == env20810) = true)

theorem identity20810 : scanCanonicalize (H12AffineFastState.compose env20810 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound20810 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env20811 : List Nat := [2,4,8,16,32,16,9,37,1,1024,1,1077,40,1076,0,35,1077,0,1025,1,1077,32,17,2,41,17,0,1076,1076,1,1056,1,36,0,1077,1]

theorem envBound20811 : H12AffineFastState.Bounded env20811 := by
  intro p hp
  have h : env20811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20810_20811 : H12AffineEnvironment.transform 7 37 env20810 = env20811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env20810 == env20811) = true)

theorem identity20811 : scanCanonicalize (H12AffineFastState.compose env20811 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound20811 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20812 : List Nat := [2,4,8,16,0,16,9,5,1,1024,1,1045,8,1044,0,3,1045,0,1025,1,1045,0,17,2,9,17,0,1044,1044,1,1024,1,4,0,1045,1]

theorem envBound20812 : H12AffineFastState.Bounded env20812 := by
  intro p hp
  have h : env20812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20811_20812 : H12AffineEnvironment.transform 4 0 env20811 = env20812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20811 == env20812) = true)

def leafEnv20812 : List Nat := [2,4,8,16,0,16,9,5,1,1024,1,1045,8,1044,0,3,1045,0,1025,1,1045,0,17,2,1025,9,1,17,0,1044,1044,1,1024,1,4,0,5,3,1045,1,0,1044,1]

def active20812 : List Nat := [0,1,2,3,9]

def tree20812 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood20812 : H12WitnessSearch.Good tree20812 := H12GlobalWitnessIndex.good

theorem leafIdentity20812 : H12AffineFastState.composeSystem env20812 rootObs = leafEnv20812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env20812 rootObs == leafEnv20812) = true)

theorem terminalChecked20812 : H12PackedTerminal.terminalCheckFast leafEnv20812 active20812 tree20812 = true := by decide +kernel

def env20813 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1725,673,1772,293,170,1344,940,1025,292,1725,681,1004,139,553,956,0,1772,1297,941,1285,4294967296,257,4294967944,1344,512]

theorem envBound20813 : H12AffineFastState.Bounded env20813 := by
  intro p hp
  have h : env20813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20803_20813 : H12AffineEnvironment.transform 12 673 env20803 = env20813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 673 env20803 == env20813) = true)

theorem identity20813 : scanCanonicalize (H12AffineFastState.compose env20813 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 429) := by decide +kernel

theorem selectedBound20813 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20814 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1725,673,1772,293,170,1344,940,1025,292,1725,681,1004,139,553,956,0,1772,1297,941,1285,429,257,805,1344,512]

theorem envBound20814 : H12AffineFastState.Bounded env20814 := by
  intro p hp
  have h : env20814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20813_20814 : H12AffineEnvironment.transform 31 429 env20813 = env20814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 429 env20813 == env20814) = true)

theorem identity20814 : scanCanonicalize (H12AffineFastState.compose env20814 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 428) := by decide +kernel

theorem selectedBound20814 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20815 : List Nat := [2,4,8,16,32,64,128,256,428,1024,1,1297,269,1344,293,170,1344,0,1025,292,1297,261,64,139,389,16,0,1344,1297,1,1285,429,257,137,1344,428]

theorem envBound20815 : H12AffineFastState.Bounded env20815 := by
  intro p hp
  have h : env20815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20814_20815 : H12AffineEnvironment.transform 8 428 env20814 = env20815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 428 env20814 == env20815) = true)

theorem identity20815 : scanCanonicalize (H12AffineFastState.compose env20815 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound20815 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20816 : List Nat := [2,4,8,16,32,64,9,256,293,1024,1,1297,269,1344,293,35,1344,0,1025,292,1297,261,64,2,268,16,0,1344,1297,1,1285,292,257,0,1344,293]

theorem envBound20816 : H12AffineFastState.Bounded env20816 := by
  intro p hp
  have h : env20816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20815_20816 : H12AffineEnvironment.transform 6 9 env20815 = env20816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20815 == env20816) = true)

theorem identity20816 : scanCanonicalize (H12AffineFastState.compose env20816 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound20816 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env20817 : List Nat := [2,4,8,16,32,64,9,116,81,1024,1,1125,121,1076,81,35,1076,0,1025,80,1125,113,64,2,120,16,0,1076,1125,1,1137,80,117,0,1076,81]

theorem envBound20817 : H12AffineFastState.Bounded env20817 := by
  intro p hp
  have h : env20817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20816_20817 : H12AffineEnvironment.transform 7 116 env20816 = env20817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env20816 == env20817) = true)

def env20818 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1345,262144,524288,32769,4096,8200,17665,98565,8328,541008,795917,16384,545088,1073741824,1284,4294967296,257,4295074215,1344,512]

theorem envBound20818 : H12AffineFastState.Bounded env20818 := by
  intro p hp
  have h : env20818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20765_20818 : H12AffineEnvironment.transform 16 1345 env20765 = env20818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env20765 == env20818) = true)

theorem identity20818 : scanCanonicalize (H12AffineFastState.compose env20818 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 787536) := by decide +kernel

theorem selectedBound20818 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env20819 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1345,262144,524288,32769,4096,8200,17665,98565,8328,541008,795917,16384,545088,787536,1284,4294967296,257,4295074215,1344,512]

theorem envBound20819 : H12AffineFastState.Bounded env20819 := by
  intro p hp
  have h : env20819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20818_20819 : H12AffineEnvironment.transform 29 787536 env20818 = env20819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 787536 env20818 == env20819) = true)

theorem identity20819 : scanCanonicalize (H12AffineFastState.compose env20819 (packedSelected [4,9,16] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound20819 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env20820 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1345,262144,1025,32769,4096,8200,17665,98565,8328,17745,270604,16384,21825,262225,1284,4294967296,257,4295074215,1344,512]

theorem envBound20820 : H12AffineFastState.Bounded env20820 := by
  intro p hp
  have h : env20820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20819_20820 : H12AffineEnvironment.transform 18 1025 env20819 = env20820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env20819 == env20820) = true)

theorem identity20820 : scanCanonicalize (H12AffineFastState.compose env20820 (packedSelected [1,5,8,15,17,21,24,38] rootPS)) = affineNative (2^(17+1) ^^^ 106706) := by decide +kernel

theorem selectedBound20820 : packedSelected [1,5,8,15,17,21,24,38] rootPS < 2^1333 := by decide +kernel

def env20821 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,1345,106706,1025,32769,4096,8200,17665,98565,8328,17745,98782,16384,21825,106627,1284,4294967296,257,4295074215,1344,512]

theorem envBound20821 : H12AffineFastState.Bounded env20821 := by
  intro p hp
  have h : env20821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20820_20821 : H12AffineEnvironment.transform 17 106706 env20820 = env20821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 106706 env20820 == env20821) = true)

theorem identity20821 : scanCanonicalize (H12AffineFastState.compose env20821 (packedSelected [13,21] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound20821 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env20822 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4177,32768,65536,1345,106706,1025,32769,4096,8200,5456,98565,8328,5376,98782,4177,1296,106627,1284,4294967296,257,4295074215,1344,512]

theorem envBound20822 : H12AffineFastState.Bounded env20822 := by
  intro p hp
  have h : env20822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20821_20822 : H12AffineEnvironment.transform 13 4177 env20821 = env20822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env20821 == env20822) = true)

theorem identity20822 : scanCanonicalize (H12AffineFastState.compose env20822 (packedSelected [3,5,10] rootPS)) = affineNative (2^(31+1) ^^^ 8320) := by decide +kernel

theorem selectedBound20822 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env20823 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4177,32768,65536,1345,106706,1025,32769,4096,8200,5456,98565,8328,5376,98782,4177,1296,106627,1284,8320,257,98599,1344,512]

theorem envBound20823 : H12AffineFastState.Bounded env20823 := by
  intro p hp
  have h : env20823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20822_20823 : H12AffineEnvironment.transform 31 8320 env20822 = env20823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 8320 env20822 == env20823) = true)

theorem identity20823 : scanCanonicalize (H12AffineFastState.compose env20823 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 373) := by decide +kernel

theorem selectedBound20823 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env20824 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4177,373,65536,1345,74151,1025,372,4096,8200,5456,65648,8328,5376,65707,4177,1296,74230,1284,8320,257,65618,1344,512]

theorem envBound20824 : H12AffineFastState.Bounded env20824 := by
  intro p hp
  have h : env20824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20823_20824 : H12AffineEnvironment.transform 14 373 env20823 = env20824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 373 env20823 == env20824) = true)

theorem identity20824 : scanCanonicalize (H12AffineFastState.compose env20824 (packedSelected [3,8,12,13] rootPS)) = affineNative (2^(15+1) ^^^ 13715) := by decide +kernel

theorem selectedBound20824 : packedSelected [3,8,12,13] rootPS < 2^1333 := by decide +kernel

def env20825 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,4177,373,13715,1345,5172,1025,372,4096,8200,5456,13795,8328,5376,13624,4177,1296,5221,1284,8320,257,13761,1344,512]

theorem envBound20825 : H12AffineFastState.Bounded env20825 := by
  intro p hp
  have h : env20825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20824_20825 : H12AffineEnvironment.transform 15 13715 env20824 = env20825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13715 env20824 == env20825) = true)

theorem identity20825 : scanCanonicalize (H12AffineFastState.compose env20825 (packedSelected [3,5,12,17] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound20825 : packedSelected [3,5,12,17] rootPS < 2^1333 := by decide +kernel

def env20826 : List Nat := [2,4,8,16,32,64,128,253,512,1024,1,4096,8192,4177,136,13422,1212,5172,1025,137,4096,8200,5293,13342,8328,5373,13509,4177,1261,5221,1273,8320,252,13372,1213,512]

theorem envBound20826 : H12AffineFastState.Bounded env20826 := by
  intro p hp
  have h : env20826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20825_20826 : H12AffineEnvironment.transform 7 253 env20825 = env20826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env20825 == env20826) = true)

theorem identity20826 : scanCanonicalize (H12AffineFastState.compose env20826 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 1093) := by decide +kernel

theorem selectedBound20826 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env20827 : List Nat := [2,4,8,16,32,64,128,253,512,1024,1,1093,8192,1044,136,8235,1212,113,1025,137,1093,8200,232,8283,8328,184,8320,1044,1261,32,1273,8320,252,8313,1213,512]

theorem envBound20827 : H12AffineFastState.Bounded env20827 := by
  intro p hp
  have h : env20827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20826_20827 : H12AffineEnvironment.transform 11 1093 env20826 = env20827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1093 env20826 == env20827) = true)

theorem identity20827 : scanCanonicalize (H12AffineFastState.compose env20827 (packedSelected [0,5,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound20827 : packedSelected [0,5,8,9] rootPS < 2^1333 := by decide +kernel

def env20828 : List Nat := [2,4,8,16,32,64,128,253,0,1024,1,1093,8192,1044,136,8235,1212,113,1025,137,1093,8200,232,8283,8328,184,8320,1044,1261,32,1273,8320,252,8313,1213,0]

theorem envBound20828 : H12AffineFastState.Bounded env20828 := by
  intro p hp
  have h : env20828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20827_20828 : H12AffineEnvironment.transform 8 0 env20827 = env20828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env20827 == env20828) = true)

theorem identity20828 : scanCanonicalize (H12AffineFastState.compose env20828 (packedSelected [1,2,4,8] rootPS)) = affineNative (2^(9+1) ^^^ 140) := by decide +kernel

theorem selectedBound20828 : packedSelected [1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env20829 : List Nat := [2,4,8,16,32,64,128,253,0,140,1,201,8192,152,136,8235,48,113,141,137,201,8200,232,8283,8328,184,8320,152,97,32,117,8320,252,8313,49,0]

theorem envBound20829 : H12AffineFastState.Bounded env20829 := by
  intro p hp
  have h : env20829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20828_20829 : H12AffineEnvironment.transform 9 140 env20828 = env20829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 140 env20828 == env20829) = true)

theorem identity20829 : scanCanonicalize (H12AffineFastState.compose env20829 (packedSelected [1,2,3,4,5,7,12] rootPS)) = affineNative (2^(12+1) ^^^ 225) := by decide +kernel

theorem selectedBound20829 : packedSelected [1,2,3,4,5,7,12] rootPS < 2^1333 := by decide +kernel

def env20830 : List Nat := [2,4,8,16,32,64,128,253,0,140,1,201,225,152,136,202,48,113,141,137,201,233,232,186,105,184,97,152,97,32,117,97,252,152,49,0]

theorem envBound20830 : H12AffineFastState.Bounded env20830 := by
  intro p hp
  have h : env20830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20829_20830 : H12AffineEnvironment.transform 12 225 env20829 = env20830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 225 env20829 == env20830) = true)

theorem identity20830 : scanCanonicalize (H12AffineFastState.compose env20830 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound20830 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env20831 : List Nat := [2,4,8,16,32,64,24,101,0,20,1,81,121,0,16,82,48,113,21,17,81,113,112,34,105,32,97,0,97,32,117,97,100,0,49,0]

theorem envBound20831 : H12AffineFastState.Bounded env20831 := by
  intro p hp
  have h : env20831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20830_20831 : H12AffineEnvironment.transform 6 24 env20830 = env20831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env20830 == env20831) = true)

theorem identity20831 : scanCanonicalize (H12AffineFastState.compose env20831 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound20831 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20832 : List Nat := [2,4,8,16,16,64,24,85,0,20,1,81,73,0,16,82,0,65,21,17,81,65,64,18,89,16,81,0,81,16,69,81,84,0,1,0]

theorem envBound20832 : H12AffineFastState.Bounded env20832 := by
  intro p hp
  have h : env20832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20831_20832 : H12AffineEnvironment.transform 4 16 env20831 = env20832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env20831 == env20832) = true)

theorem identity20832 : scanCanonicalize (H12AffineFastState.compose env20832 (packedSelected [1,2] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound20832 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env20833 : List Nat := [2,4,8,16,16,1,24,20,0,20,1,16,8,0,16,19,0,0,21,17,16,0,1,18,24,16,16,0,16,16,4,16,21,0,1,0]

theorem envBound20833 : H12AffineFastState.Bounded env20833 := by
  intro p hp
  have h : env20833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20832_20833 : H12AffineEnvironment.transform 5 1 env20832 = env20833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env20832 == env20833) = true)

theorem identity20833 : scanCanonicalize (H12AffineFastState.compose env20833 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound20833 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20834 : List Nat := [2,4,8,1,1,1,9,5,0,5,1,1,8,0,1,2,0,0,4,0,1,0,1,3,9,1,1,0,1,1,4,1,4,0,1,0]

theorem envBound20834 : H12AffineFastState.Bounded env20834 := by
  intro p hp
  have h : env20834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20833_20834 : H12AffineEnvironment.transform 3 1 env20833 = env20834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env20833 == env20834) = true)

def env20835 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,4194304,147520,16777216,8328,672785,21857281,16384,676865,1073741824,16876545,4294967296,257,4315938986,1345,512]

theorem envBound20835 : H12AffineFastState.Bounded env20835 := by
  intro p hp
  have h : env20835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20564_20835 : H12AffineEnvironment.transform 26 21857281 env20564 = env20835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21857281 env20564 == env20835) = true)

theorem identity20835 : scanCanonicalize (H12AffineFastState.compose env20835 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound20835 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env20836 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4096,4194304,147520,16777216,8328,147472,21331968,16384,151552,1073741824,16876545,4294967296,257,4315938986,1345,512]

theorem envBound20836 : H12AffineFastState.Bounded env20836 := by
  intro p hp
  have h : env20836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20835_20836 : H12AffineEnvironment.transform 18 1025 env20835 = env20836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env20835 == env20836) = true)

theorem identity20836 : scanCanonicalize (H12AffineFastState.compose env20836 (packedSelected [7,20,27] rootPS)) = affineNative (2^(23+1) ^^^ 98564) := by decide +kernel

theorem selectedBound20836 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env20837 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4096,4194304,147520,98564,8328,147472,4456708,16384,151552,1073741824,1285,4294967296,257,4299260334,1345,512]

theorem envBound20837 : H12AffineFastState.Bounded env20837 := by
  intro p hp
  have h : env20837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20836_20837 : H12AffineEnvironment.transform 23 98564 env20836 = env20837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98564 env20836 == env20837) = true)

def env20838 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16384,262144,1025,32769,4096,4194304,64,98564,8328,16,4456708,16384,4096,1073741824,1285,4294967296,257,4299260334,1345,512]

theorem envBound20838 : H12AffineFastState.Bounded env20838 := by
  intro p hp
  have h : env20838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20837_20838 : H12AffineEnvironment.transform 16 16384 env20837 = env20838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16384 env20837 == env20838) = true)

theorem identity20838 : scanCanonicalize (H12AffineFastState.compose env20838 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 4096) := by decide +kernel

theorem selectedBound20838 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env20839 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4096,32768,65536,4096,262144,1025,32769,4096,4194304,64,98564,8328,16,4456708,4096,4096,1073741824,1285,4294967296,257,4299260334,1345,512]

theorem envBound20839 : H12AffineFastState.Bounded env20839 := by
  intro p hp
  have h : env20839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20838_20839 : H12AffineEnvironment.transform 13 4096 env20838 = env20839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env20838 == env20839) = true)

theorem identity20839 : scanCanonicalize (H12AffineFastState.compose env20839 (packedSelected [17,21] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound20839 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env20840 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4096,32768,33166,4096,262144,1025,32769,4096,4194304,64,138,8328,16,4456708,4096,4096,1073741824,1285,4294967296,257,4299161632,1345,512]

theorem envBound20840 : H12AffineFastState.Bounded env20840 := by
  intro p hp
  have h : env20840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20839_20840 : H12AffineEnvironment.transform 15 33166 env20839 = env20840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env20839 == env20840) = true)

theorem identity20840 : scanCanonicalize (H12AffineFastState.compose env20840 (packedSelected [12,15,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 41261) := by decide +kernel

theorem selectedBound20840 : packedSelected [12,15,38,41] rootPS < 2^1333 := by decide +kernel

def env20841 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4096,32768,33166,4096,262144,1025,32769,4096,41261,64,138,8328,16,303145,4096,4096,1073741824,1285,4294967296,257,4295008525,1345,512]

theorem envBound20841 : H12AffineFastState.Bounded env20841 := by
  intro p hp
  have h : env20841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20840_20841 : H12AffineEnvironment.transform 21 41261 env20840 = env20841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41261 env20840 == env20841) = true)

theorem identity20841 : scanCanonicalize (H12AffineFastState.compose env20841 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 48489) := by decide +kernel

theorem selectedBound20841 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env20842 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4096,32768,33166,4096,48489,1025,32769,4096,41261,64,138,8328,16,7488,4096,4096,1073741824,1285,4294967296,257,4295008525,1345,512]

theorem envBound20842 : H12AffineFastState.Bounded env20842 := by
  intro p hp
  have h : env20842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20841_20842 : H12AffineEnvironment.transform 17 48489 env20841 = env20842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 48489 env20841 == env20842) = true)

def env20843 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16385,262144,1025,32769,4096,4194304,65,98564,8328,17,4456708,16384,4097,1073741824,1285,4294967296,257,4299260334,1345,512]

theorem envBound20843 : H12AffineFastState.Bounded env20843 := by
  intro p hp
  have h : env20843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20837_20843 : H12AffineEnvironment.transform 16 16385 env20837 = env20843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16385 env20837 == env20843) = true)

theorem identity20843 : scanCanonicalize (H12AffineFastState.compose env20843 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound20843 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env20844 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,16385,262144,1025,32769,4096,4194304,17,98564,8328,17,4456708,16384,4097,1073741824,1285,4294967296,257,4299260334,1297,512]

theorem envBound20844 : H12AffineFastState.Bounded env20844 := by
  intro p hp
  have h : env20844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20843_20844 : H12AffineEnvironment.transform 5 16 env20843 = env20844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20843 == env20844) = true)

theorem identity20844 : scanCanonicalize (H12AffineFastState.compose env20844 (packedSelected [13,17] rootPS)) = affineNative (2^(31+1) ^^^ 4214920) := by decide +kernel

theorem selectedBound20844 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env20845 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,16385,262144,1025,32769,4096,4194304,17,98564,8328,17,4456708,16384,4097,1073741824,1285,4214920,257,119078,1297,512]

theorem envBound20845 : H12AffineFastState.Bounded env20845 := by
  intro p hp
  have h : env20845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20844_20845 : H12AffineEnvironment.transform 31 4214920 env20844 = env20845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4214920 env20844 == env20845) = true)

def env20846 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,8388608,16777216,8328,8914001,134217728,8519744,676864,1073741824,25412672,4294967296,8536384,4315938986,164610304,512]

theorem envBound20846 : H12AffineFastState.Bounded env20846 := by
  intro p hp
  have h : env20846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20562_20846 : H12AffineEnvironment.transform 20 4097 env20562 = env20846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env20562 == env20846) = true)

theorem identity20846 : scanCanonicalize (H12AffineFastState.compose env20846 (packedSelected [14] rootPS)) = affineNative (2^(26+1) ^^^ 30393409) := by decide +kernel

theorem selectedBound20846 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env20847 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,8388608,16777216,8328,8914001,30393409,8519744,676864,1073741824,25412672,4294967296,8536384,4315938986,1345,512]

theorem envBound20847 : H12AffineFastState.Bounded env20847 := by
  intro p hp
  have h : env20847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20846_20847 : H12AffineEnvironment.transform 26 30393409 env20846 = env20847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393409 env20846 == env20847) = true)

def env20848 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,147520,16777216,8328,672785,21857281,16384,676864,1073741824,16876544,4294967296,256,4315938986,1345,512]

theorem envBound20848 : H12AffineFastState.Bounded env20848 := by
  intro p hp
  have h : env20848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20847_20848 : H12AffineEnvironment.transform 22 147520 env20847 = env20848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147520 env20847 == env20848) = true)

def env20849 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,147521,16777216,8328,672784,21857280,16385,676864,1073741824,16876545,4294967296,257,4315938986,1345,512]

theorem envBound20849 : H12AffineFastState.Bounded env20849 := by
  intro p hp
  have h : env20849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20847_20849 : H12AffineEnvironment.transform 22 147521 env20847 = env20849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147521 env20847 == env20849) = true)

theorem identity20849 : scanCanonicalize (H12AffineFastState.compose env20849 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(23+1) ^^^ 230468) := by decide +kernel

theorem selectedBound20849 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env20850 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,4194304,147521,230468,8328,672784,5111876,16385,676864,1073741824,131141,4294967296,257,4299392238,1345,512]

theorem envBound20850 : H12AffineFastState.Bounded env20850 := by
  intro p hp
  have h : env20850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20849_20850 : H12AffineEnvironment.transform 23 230468 env20849 = env20850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 230468 env20849 == env20850) = true)

def env20851 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4097,10248,147521,230468,8328,672784,927820,16385,676864,1073741824,131141,4294967296,257,4295208166,1345,512]

end H12CloudChart2