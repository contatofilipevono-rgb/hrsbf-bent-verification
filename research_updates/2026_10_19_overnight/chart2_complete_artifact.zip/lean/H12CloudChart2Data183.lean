import H12CloudChart2Data182

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound45914 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env45915 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,0,12556,65536,74111,65665,4417,12557,4096,477,74047,69648,12505,78143,4415,74031,1,79963,8205,17,256,65830,81,4688]

theorem envBound45915 : H12AffineFastState.Bounded env45915 := by
  intro p hp
  have h : env45915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45914_45915 : H12AffineEnvironment.transform 9 272 env45914 = env45915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env45914 == env45915) = true)

def env45916 : List Nat := [2,4,8,16,32,64,128,256,340,272,2048,4096,8192,0,12556,65536,74111,65665,4417,12557,4096,477,74047,69648,12505,78143,4415,74031,1,79963,8205,17,256,65830,81,4356]

theorem envBound45916 : H12AffineFastState.Bounded env45916 := by
  intro p hp
  have h : env45916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45915_45916 : H12AffineEnvironment.transform 8 340 env45915 = env45916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env45915 == env45916) = true)

def env45917 : List Nat := [2,4,8,16,32,64,128,256,340,272,2048,16,8192,0,8476,65536,74111,65665,337,8477,16,477,74047,65536,8393,74031,303,74031,1,75851,8205,17,256,65830,81,276]

theorem envBound45917 : H12AffineFastState.Bounded env45917 := by
  intro p hp
  have h : env45917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45916_45917 : H12AffineEnvironment.transform 11 16 env45916 = env45917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env45916 == env45917) = true)

theorem identity45917 : scanCanonicalize (H12AffineFastState.compose env45917 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 393) := by decide +kernel

theorem selectedBound45917 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env45918 : List Nat := [2,4,8,16,32,64,128,256,340,272,2048,16,8192,0,8476,393,8438,264,337,8477,16,477,8374,393,8393,8358,303,8358,1,10690,8205,17,256,175,81,276]

theorem envBound45918 : H12AffineFastState.Bounded env45918 := by
  intro p hp
  have h : env45918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45917_45918 : H12AffineEnvironment.transform 15 393 env45917 = env45918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 393 env45917 == env45918) = true)

def env45919 : List Nat := [2,4,8,16,32,64,128,256,340,272,2048,16,160,0,444,393,86,264,337,445,16,477,22,393,105,6,303,6,1,2402,173,17,256,175,81,276]

theorem envBound45919 : H12AffineFastState.Bounded env45919 := by
  intro p hp
  have h : env45919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45918_45919 : H12AffineEnvironment.transform 12 160 env45918 = env45919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env45918 == env45919) = true)

theorem identity45919 : scanCanonicalize (H12AffineFastState.compose env45919 (packedSelected [3,4,9,10,13,17,18,19,20,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound45919 : packedSelected [3,4,9,10,13,17,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env45920 : List Nat := [2,4,8,16,32,64,128,172,248,188,2048,16,160,0,16,37,86,164,253,17,16,113,22,37,105,6,131,6,1,2254,173,17,172,175,81,184]

theorem envBound45920 : H12AffineFastState.Bounded env45920 := by
  intro p hp
  have h : env45920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45919_45920 : H12AffineEnvironment.transform 7 172 env45919 = env45920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env45919 == env45920) = true)

theorem identity45920 : scanCanonicalize (H12AffineFastState.compose env45920 (packedSelected [2,4,5,9,11,12,15,17,18,19,23] rootPS)) = affineNative (2^(10+1) ^^^ 92) := by decide +kernel

theorem selectedBound45920 : packedSelected [2,4,5,9,11,12,15,17,18,19,23] rootPS < 2^1333 := by decide +kernel

def env45921 : List Nat := [2,4,8,16,32,64,128,172,248,188,92,16,160,0,16,37,86,164,253,17,16,113,22,37,105,6,131,6,1,146,173,17,172,175,81,184]

theorem envBound45921 : H12AffineFastState.Bounded env45921 := by
  intro p hp
  have h : env45921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45920_45921 : H12AffineEnvironment.transform 10 92 env45920 = env45921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 92 env45920 == env45921) = true)

theorem identity45921 : scanCanonicalize (H12AffineFastState.compose env45921 (packedSelected [1,8,11,12,13,15,16] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound45921 : packedSelected [1,8,11,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env45922 : List Nat := [2,4,8,16,27,64,128,151,195,135,92,16,155,0,16,30,86,159,198,17,16,74,22,30,82,6,131,6,1,146,150,17,151,148,81,131]

theorem envBound45922 : H12AffineFastState.Bounded env45922 := by
  intro p hp
  have h : env45922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45921_45922 : H12AffineEnvironment.transform 4 27 env45921 = env45922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env45921 == env45922) = true)

theorem identity45922 : scanCanonicalize (H12AffineFastState.compose env45922 (packedSelected [2,3,4,5,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 28) := by decide +kernel

theorem selectedBound45922 : packedSelected [2,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env45923 : List Nat := [2,4,8,16,27,28,128,151,159,135,0,16,155,0,16,30,10,159,154,17,16,22,22,30,14,6,131,6,1,146,150,17,151,148,13,131]

theorem envBound45923 : H12AffineFastState.Bounded env45923 := by
  intro p hp
  have h : env45923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45922_45923 : H12AffineEnvironment.transform 5 28 env45922 = env45923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 28 env45922 == env45923) = true)

theorem identity45923 : scanCanonicalize (H12AffineFastState.compose env45923 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 21) := by decide +kernel

theorem selectedBound45923 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env45924 : List Nat := [2,4,8,16,27,28,21,2,10,18,0,16,14,0,16,30,10,10,15,17,16,22,22,30,14,6,22,6,1,7,3,17,2,1,13,22]

theorem envBound45924 : H12AffineFastState.Bounded env45924 := by
  intro p hp
  have h : env45924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45923_45924 : H12AffineEnvironment.transform 6 21 env45923 = env45924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 21 env45923 == env45924) = true)

theorem identity45924 : scanCanonicalize (H12AffineFastState.compose env45924 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound45924 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env45925 : List Nat := [2,4,5,16,22,17,21,2,7,18,0,16,3,0,16,19,7,7,2,17,16,22,22,19,3,6,22,6,1,7,3,17,2,1,0,22]

theorem envBound45925 : H12AffineFastState.Bounded env45925 := by
  intro p hp
  have h : env45925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45924_45925 : H12AffineEnvironment.transform 2 5 env45924 = env45925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env45924 == env45925) = true)

theorem identity45925 : scanCanonicalize (H12AffineFastState.compose env45925 (packedSelected [1,2] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound45925 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env45926 : List Nat := [2,4,5,6,0,7,3,2,7,4,0,6,3,0,6,5,7,7,2,7,6,0,0,5,3,6,0,6,1,7,3,7,2,1,0,0]

theorem envBound45926 : H12AffineFastState.Bounded env45926 := by
  intro p hp
  have h : env45926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45925_45926 : H12AffineEnvironment.transform 3 6 env45925 = env45926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env45925 == env45926) = true)

theorem identity45926 : scanCanonicalize (H12AffineFastState.compose env45926 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound45926 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45927 : List Nat := [2,2,3,0,0,1,3,2,1,2,0,0,3,0,0,3,1,1,2,1,0,0,0,3,3,0,0,0,1,1,3,1,2,1,0,0]

theorem envBound45927 : H12AffineFastState.Bounded env45927 := by
  intro p hp
  have h : env45927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45926_45927 : H12AffineEnvironment.transform 1 2 env45926 = env45927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env45926 == env45927) = true)

theorem identity45927 : scanCanonicalize (H12AffineFastState.compose env45927 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound45927 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45928 : List Nat := [1,1,0,0,0,1,0,1,1,1,0,0,0,0,0,0,1,1,1,1,0,0,0,0,0,0,0,0,1,1,0,1,1,1,0,0]

theorem envBound45928 : H12AffineFastState.Bounded env45928 := by
  intro p hp
  have h : env45928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45927_45928 : H12AffineEnvironment.transform 0 1 env45927 = env45928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env45927 == env45928) = true)

def env45929 : List Nat := [2,4,8,16,32,64,128,256,340,272,2048,16,161,0,445,393,87,264,337,444,16,477,23,393,104,7,303,7,1,2403,172,17,256,175,81,276]

theorem envBound45929 : H12AffineFastState.Bounded env45929 := by
  intro p hp
  have h : env45929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45918_45929 : H12AffineEnvironment.transform 12 161 env45918 = env45929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env45918 == env45929) = true)

theorem identity45929 : scanCanonicalize (H12AffineFastState.compose env45929 (packedSelected [3,4,9,10,13,17,18,19,20,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 170) := by decide +kernel

theorem selectedBound45929 : packedSelected [3,4,9,10,13,17,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env45930 : List Nat := [2,4,8,16,32,64,128,170,254,186,2048,16,161,0,23,35,87,162,251,22,16,119,23,35,104,7,133,7,1,2249,172,17,170,175,81,190]

theorem envBound45930 : H12AffineFastState.Bounded env45930 := by
  intro p hp
  have h : env45930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45929_45930 : H12AffineEnvironment.transform 7 170 env45929 = env45930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 170 env45929 == env45930) = true)

theorem identity45930 : scanCanonicalize (H12AffineFastState.compose env45930 (packedSelected [0,2,3,4,7,8,9,11,12,15,16,17] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound45930 : packedSelected [0,2,3,4,7,8,9,11,12,15,16,17] rootPS < 2^1333 := by decide +kernel

def env45931 : List Nat := [2,4,8,16,32,64,88,114,38,98,2048,16,121,0,23,35,87,122,35,22,16,119,23,35,104,7,93,7,1,2065,116,17,114,119,81,102]

theorem envBound45931 : H12AffineFastState.Bounded env45931 := by
  intro p hp
  have h : env45931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45930_45931 : H12AffineEnvironment.transform 6 88 env45930 = env45931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env45930 == env45931) = true)

theorem identity45931 : scanCanonicalize (H12AffineFastState.compose env45931 (packedSelected [1,5,10,16,18,19] rootPS)) = affineNative (2^(10+1) ^^^ 106) := by decide +kernel

theorem selectedBound45931 : packedSelected [1,5,10,16,18,19] rootPS < 2^1333 := by decide +kernel

def env45932 : List Nat := [2,4,8,16,32,64,88,114,38,98,106,16,121,0,23,35,87,122,35,22,16,119,23,35,104,7,93,7,1,123,116,17,114,119,81,102]

theorem envBound45932 : H12AffineFastState.Bounded env45932 := by
  intro p hp
  have h : env45932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45931_45932 : H12AffineEnvironment.transform 10 106 env45931 = env45932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 106 env45931 == env45932) = true)

theorem identity45932 : scanCanonicalize (H12AffineFastState.compose env45932 (packedSelected [1,4,5,7,10,12] rootPS)) = affineNative (2^(5+1) ^^^ 54) := by decide +kernel

theorem selectedBound45932 : packedSelected [1,4,5,7,10,12] rootPS < 2^1333 := by decide +kernel

def env45933 : List Nat := [2,4,8,16,32,54,46,4,38,20,28,16,15,0,23,35,33,12,35,22,16,1,23,35,30,7,43,7,1,13,2,17,4,1,39,16]

theorem envBound45933 : H12AffineFastState.Bounded env45933 := by
  intro p hp
  have h : env45933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45932_45933 : H12AffineEnvironment.transform 5 54 env45932 = env45933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 54 env45932 == env45933) = true)

theorem identity45933 : scanCanonicalize (H12AffineFastState.compose env45933 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound45933 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env45934 : List Nat := [2,4,8,16,12,26,2,4,10,20,28,16,15,0,23,15,13,12,15,22,16,1,23,15,30,7,7,7,1,13,2,17,4,1,11,16]

theorem envBound45934 : H12AffineFastState.Bounded env45934 := by
  intro p hp
  have h : env45934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45933_45934 : H12AffineEnvironment.transform 4 12 env45933 = env45934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env45933 == env45934) = true)

theorem identity45934 : scanCanonicalize (H12AffineFastState.compose env45934 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound45934 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env45935 : List Nat := [2,4,8,11,12,1,2,4,10,15,7,11,15,0,12,15,13,12,15,13,11,1,12,15,5,7,7,7,1,13,2,10,4,1,11,11]

theorem envBound45935 : H12AffineFastState.Bounded env45935 := by
  intro p hp
  have h : env45935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45934_45935 : H12AffineEnvironment.transform 3 11 env45934 = env45935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env45934 == env45935) = true)

theorem identity45935 : scanCanonicalize (H12AffineFastState.compose env45935 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound45935 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env45936 : List Nat := [2,4,6,5,2,1,2,4,4,1,7,5,1,0,2,1,3,2,1,3,5,1,2,1,5,7,7,7,1,3,2,4,4,1,5,5]

theorem envBound45936 : H12AffineFastState.Bounded env45936 := by
  intro p hp
  have h : env45936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45935_45936 : H12AffineEnvironment.transform 2 6 env45935 = env45936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env45935 == env45936) = true)

theorem identity45936 : scanCanonicalize (H12AffineFastState.compose env45936 (packedSelected [0,2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound45936 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env45937 : List Nat := [2,2,0,3,2,1,2,2,2,1,1,3,1,0,2,1,3,2,1,3,3,1,2,1,3,1,1,1,1,3,2,2,2,1,3,3]

theorem envBound45937 : H12AffineFastState.Bounded env45937 := by
  intro p hp
  have h : env45937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45936_45937 : H12AffineEnvironment.transform 1 2 env45936 = env45937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env45936 == env45937) = true)

theorem identity45937 : scanCanonicalize (H12AffineFastState.compose env45937 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound45937 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45938 : List Nat := [0,0,0,1,0,1,0,0,0,1,1,1,1,0,0,1,1,0,1,1,1,1,0,1,1,1,1,1,1,1,0,0,0,1,1,1]

theorem envBound45938 : H12AffineFastState.Bounded env45938 := by
  intro p hp
  have h : env45938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45937_45938 : H12AffineEnvironment.transform 0 0 env45937 = env45938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env45937 == env45938) = true)

def env45939 : List Nat := [2,4,8,16,32,64,128,256,340,272,2048,17,8192,0,8477,65536,74111,65665,336,8476,17,477,74047,65537,8392,74030,302,74031,1,75850,8205,17,256,65830,81,277]

theorem envBound45939 : H12AffineFastState.Bounded env45939 := by
  intro p hp
  have h : env45939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45916_45939 : H12AffineEnvironment.transform 11 17 env45916 = env45939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env45916 == env45939) = true)

theorem identity45939 : scanCanonicalize (H12AffineFastState.compose env45939 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8593) := by decide +kernel

theorem selectedBound45939 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env45940 : List Nat := [2,4,8,16,32,64,128,256,340,272,2048,17,8192,0,8477,8593,238,8464,336,8476,17,477,174,8592,8392,191,302,190,1,2523,8205,17,256,8375,81,277]

theorem envBound45940 : H12AffineFastState.Bounded env45940 := by
  intro p hp
  have h : env45940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45939_45940 : H12AffineEnvironment.transform 15 8593 env45939 = env45940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8593 env45939 == env45940) = true)

def env45941 : List Nat := [2,4,8,16,32,64,128,256,340,272,2048,17,24,0,261,393,238,264,336,260,17,477,174,392,208,191,302,190,1,2523,21,17,256,175,81,277]

theorem envBound45941 : H12AffineFastState.Bounded env45941 := by
  intro p hp
  have h : env45941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45940_45941 : H12AffineEnvironment.transform 12 24 env45940 = env45941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env45940 == env45941) = true)

theorem identity45941 : scanCanonicalize (H12AffineFastState.compose env45941 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound45941 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env45942 : List Nat := [2,4,8,16,32,64,128,69,17,85,2048,17,24,0,64,204,238,77,21,65,17,152,174,205,208,191,107,190,1,2206,21,17,69,175,81,80]

theorem envBound45942 : H12AffineFastState.Bounded env45942 := by
  intro p hp
  have h : env45942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45941_45942 : H12AffineEnvironment.transform 7 69 env45941 = env45942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env45941 == env45942) = true)

theorem identity45942 : scanCanonicalize (H12AffineFastState.compose env45942 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(6+1) ^^^ 62) := by decide +kernel

theorem selectedBound45942 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env45943 : List Nat := [2,4,8,16,32,64,62,69,17,85,2048,17,24,0,64,114,80,77,21,65,17,38,16,115,110,1,107,0,1,2080,21,17,69,17,81,80]

theorem envBound45943 : H12AffineFastState.Bounded env45943 := by
  intro p hp
  have h : env45943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45942_45943 : H12AffineEnvironment.transform 6 62 env45942 = env45943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 62 env45942 == env45943) = true)

theorem identity45943 : scanCanonicalize (H12AffineFastState.compose env45943 (packedSelected [1,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound45943 : packedSelected [1,8,12] rootPS < 2^1333 := by decide +kernel

def env45944 : List Nat := [2,4,8,16,32,11,62,14,17,30,2048,17,24,0,11,57,27,6,21,10,17,38,16,56,37,1,32,0,1,2080,21,17,14,17,26,27]

theorem envBound45944 : H12AffineFastState.Bounded env45944 := by
  intro p hp
  have h : env45944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45943_45944 : H12AffineEnvironment.transform 5 11 env45943 = env45944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env45943 == env45944) = true)

theorem identity45944 : scanCanonicalize (H12AffineFastState.compose env45944 (packedSelected [0,2,3,5,7,10,11] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound45944 : packedSelected [0,2,3,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env45945 : List Nat := [2,4,8,16,12,11,18,14,17,30,2048,17,24,0,11,21,27,6,21,10,17,10,16,20,9,1,12,0,1,2060,21,17,14,17,26,27]

theorem envBound45945 : H12AffineFastState.Bounded env45945 := by
  intro p hp
  have h : env45945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45944_45945 : H12AffineEnvironment.transform 4 12 env45944 = env45945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env45944 == env45945) = true)

theorem identity45945 : scanCanonicalize (H12AffineFastState.compose env45945 (packedSelected [0,2,3,4,5,8] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound45945 : packedSelected [0,2,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env45946 : List Nat := [2,4,8,12,12,11,14,14,13,2,2048,13,4,0,11,9,7,6,9,10,13,10,12,8,9,1,12,0,1,2060,9,13,14,13,6,7]

theorem envBound45946 : H12AffineFastState.Bounded env45946 := by
  intro p hp
  have h : env45946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45945_45946 : H12AffineEnvironment.transform 3 12 env45945 = env45946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env45945 == env45946) = true)

theorem identity45946 : scanCanonicalize (H12AffineFastState.compose env45946 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 13) := by decide +kernel

theorem selectedBound45946 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env45947 : List Nat := [2,4,8,12,12,11,14,14,13,2,13,13,4,0,11,9,7,6,9,10,13,10,12,8,9,1,12,0,1,1,9,13,14,13,6,7]

theorem envBound45947 : H12AffineFastState.Bounded env45947 := by
  intro p hp
  have h : env45947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45946_45947 : H12AffineEnvironment.transform 10 13 env45946 = env45947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 13 env45946 == env45947) = true)

theorem identity45947 : scanCanonicalize (H12AffineFastState.compose env45947 (packedSelected [0,1,4] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound45947 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env45948 : List Nat := [2,4,5,1,1,6,3,3,0,2,0,0,4,0,6,4,7,6,4,7,0,7,1,5,4,1,1,0,1,1,4,0,3,0,6,7]

theorem envBound45948 : H12AffineFastState.Bounded env45948 := by
  intro p hp
  have h : env45948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45947_45948 : H12AffineEnvironment.transform 2 5 env45947 = env45948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env45947 == env45948) = true)

theorem identity45948 : scanCanonicalize (H12AffineFastState.compose env45948 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound45948 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45949 : List Nat := [2,3,2,1,1,1,3,3,0,2,0,0,3,0,1,3,0,1,3,0,0,0,1,2,3,1,1,0,1,1,3,0,3,0,1,0]

theorem envBound45949 : H12AffineFastState.Bounded env45949 := by
  intro p hp
  have h : env45949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45948_45949 : H12AffineEnvironment.transform 1 3 env45948 = env45949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env45948 == env45949) = true)

def env45950 : List Nat := [2,4,8,16,32,64,128,256,340,272,2048,17,25,0,260,392,238,265,336,261,17,477,174,393,209,191,302,190,1,2523,20,17,256,174,81,277]

theorem envBound45950 : H12AffineFastState.Bounded env45950 := by
  intro p hp
  have h : env45950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45940_45950 : H12AffineEnvironment.transform 12 25 env45940 = env45950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env45940 == env45950) = true)

theorem identity45950 : scanCanonicalize (H12AffineFastState.compose env45950 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound45950 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env45951 : List Nat := [2,4,8,16,32,64,128,5,81,21,2048,17,25,0,1,141,238,12,85,0,17,216,174,140,209,191,43,190,1,2270,20,17,5,174,81,16]

theorem envBound45951 : H12AffineFastState.Bounded env45951 := by
  intro p hp
  have h : env45951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45950_45951 : H12AffineEnvironment.transform 7 5 env45950 = env45951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env45950 == env45951) = true)

theorem identity45951 : scanCanonicalize (H12AffineFastState.compose env45951 (packedSelected [0,1,2,4,7,8,9,10,12,13,16,18] rootPS)) = affineNative (2^(10+1) ^^^ 212) := by decide +kernel

theorem selectedBound45951 : packedSelected [0,1,2,4,7,8,9,10,12,13,16,18] rootPS < 2^1333 := by decide +kernel

def env45952 : List Nat := [2,4,8,16,32,64,128,5,81,21,212,17,25,0,1,141,238,12,85,0,17,216,174,140,209,191,43,190,1,10,20,17,5,174,81,16]

theorem envBound45952 : H12AffineFastState.Bounded env45952 := by
  intro p hp
  have h : env45952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45951_45952 : H12AffineEnvironment.transform 10 212 env45951 = env45952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 212 env45951 == env45952) = true)

theorem identity45952 : scanCanonicalize (H12AffineFastState.compose env45952 (packedSelected [4,8,9,11,12,13] rootPS)) = affineNative (2^(6+1) ^^^ 78) := by decide +kernel

theorem selectedBound45952 : packedSelected [4,8,9,11,12,13] rootPS < 2^1333 := by decide +kernel

def env45953 : List Nat := [2,4,8,16,32,64,78,5,81,21,26,17,25,0,1,67,32,12,85,0,17,22,96,66,31,113,43,112,1,10,20,17,5,96,81,16]

theorem envBound45953 : H12AffineFastState.Bounded env45953 := by
  intro p hp
  have h : env45953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45952_45953 : H12AffineEnvironment.transform 6 78 env45952 = env45953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 78 env45952 == env45953) = true)

theorem identity45953 : scanCanonicalize (H12AffineFastState.compose env45953 (packedSelected [0,1,5,8,9,10] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound45953 : packedSelected [0,1,5,8,9,10] rootPS < 2^1333 := by decide +kernel

def env45954 : List Nat := [2,4,8,16,22,64,78,5,81,21,26,17,25,0,1,67,22,12,85,0,17,22,86,66,31,71,29,70,1,10,20,17,5,86,81,16]

theorem envBound45954 : H12AffineFastState.Bounded env45954 := by
  intro p hp
  have h : env45954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45953_45954 : H12AffineEnvironment.transform 4 22 env45953 = env45954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env45953 == env45954) = true)

theorem identity45954 : scanCanonicalize (H12AffineFastState.compose env45954 (packedSelected [0,1,3,5,7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound45954 : packedSelected [0,1,3,5,7] rootPS < 2^1333 := by decide +kernel

def env45955 : List Nat := [2,4,8,11,13,64,78,5,74,14,1,10,2,0,1,67,13,12,78,0,10,13,77,66,4,71,6,70,1,10,15,10,5,77,74,11]

theorem envBound45955 : H12AffineFastState.Bounded env45955 := by
  intro p hp
  have h : env45955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45954_45955 : H12AffineEnvironment.transform 3 11 env45954 = env45955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env45954 == env45955) = true)

theorem identity45955 : scanCanonicalize (H12AffineFastState.compose env45955 (packedSelected [1,2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound45955 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env45956 : List Nat := [2,2,8,11,11,64,72,3,74,8,1,10,2,0,1,67,11,10,72,0,10,11,75,66,2,65,0,64,1,10,9,10,3,75,74,11]

theorem envBound45956 : H12AffineFastState.Bounded env45956 := by
  intro p hp
  have h : env45956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45955_45956 : H12AffineEnvironment.transform 1 2 env45955 = env45956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env45955 == env45956) = true)

theorem identity45956 : scanCanonicalize (H12AffineFastState.compose env45956 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound45956 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45957 : List Nat := [2,2,8,11,11,0,8,3,10,8,1,10,2,0,1,3,11,10,8,0,10,11,11,2,2,1,0,0,1,10,9,10,3,11,10,11]

theorem envBound45957 : H12AffineFastState.Bounded env45957 := by
  intro p hp
  have h : env45957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45956_45957 : H12AffineEnvironment.transform 5 0 env45956 = env45957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env45956 == env45957) = true)

theorem identity45957 : scanCanonicalize (H12AffineFastState.compose env45957 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound45957 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45958 : List Nat := [0,0,8,9,9,0,8,1,8,8,1,8,0,0,1,1,9,8,8,0,8,9,9,0,0,1,0,0,1,8,9,8,1,9,8,9]

theorem envBound45958 : H12AffineFastState.Bounded env45958 := by
  intro p hp
  have h : env45958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45957_45958 : H12AffineEnvironment.transform 0 0 env45957 = env45958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env45957 == env45958) = true)

def env45959 : List Nat := [2,4,8,16,32,64,128,256,341,272,2048,4096,8192,0,12556,65536,74111,65665,4417,12557,4096,477,74047,69648,12505,78143,4415,74031,1,79963,8205,17,256,65830,81,4357]

theorem envBound45959 : H12AffineFastState.Bounded env45959 := by
  intro p hp
  have h : env45959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45915_45959 : H12AffineEnvironment.transform 8 341 env45915 = env45959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env45915 == env45959) = true)

def env45960 : List Nat := [2,4,8,16,32,64,128,256,341,272,2048,16,8192,0,8476,65536,74111,65665,337,8477,16,477,74047,65536,8393,74031,303,74031,1,75851,8205,17,256,65830,81,277]

theorem envBound45960 : H12AffineFastState.Bounded env45960 := by
  intro p hp
  have h : env45960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45959_45960 : H12AffineEnvironment.transform 11 16 env45959 = env45960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env45959 == env45960) = true)

theorem identity45960 : scanCanonicalize (H12AffineFastState.compose env45960 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 166) := by decide +kernel

theorem selectedBound45960 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env45961 : List Nat := [2,4,8,16,32,64,128,256,341,272,2048,16,166,0,442,65536,66009,65665,337,443,16,477,65945,65536,111,65929,303,65929,1,67821,171,17,256,65830,81,277]

theorem envBound45961 : H12AffineFastState.Bounded env45961 := by
  intro p hp
  have h : env45961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45960_45961 : H12AffineEnvironment.transform 12 166 env45960 = env45961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 166 env45960 == env45961) = true)

def env45962 : List Nat := [2,4,8,16,32,64,128,256,341,272,2048,16,166,0,442,392,81,265,337,443,16,477,17,392,111,1,303,1,1,2405,171,17,256,174,81,277]

theorem envBound45962 : H12AffineFastState.Bounded env45962 := by
  intro p hp
  have h : env45962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45961_45962 : H12AffineEnvironment.transform 15 392 env45961 = env45962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 392 env45961 == env45962) = true)

theorem identity45962 : scanCanonicalize (H12AffineFastState.compose env45962 (packedSelected [13,21] rootPS)) = affineNative (2^(6+1) ^^^ 46) := by decide +kernel

theorem selectedBound45962 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env45963 : List Nat := [2,4,8,16,32,64,46,256,341,272,2048,16,8,0,276,294,81,265,337,277,16,371,17,294,111,1,303,1,1,2405,5,17,256,0,81,277]

theorem envBound45963 : H12AffineFastState.Bounded env45963 := by
  intro p hp
  have h : env45963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45962_45963 : H12AffineEnvironment.transform 6 46 env45962 = env45963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 46 env45962 == env45963) = true)

theorem identity45963 : scanCanonicalize (H12AffineFastState.compose env45963 (packedSelected [0,2,5,7,8,11,15,18,20] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound45963 : packedSelected [0,2,5,7,8,11,15,18,20] rootPS < 2^1333 := by decide +kernel

def env45964 : List Nat := [2,4,8,16,32,64,46,62,107,46,2048,16,8,0,42,24,81,55,111,43,16,77,17,24,111,1,17,1,1,2139,5,17,62,0,81,43]

theorem envBound45964 : H12AffineFastState.Bounded env45964 := by
  intro p hp
  have h : env45964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45963_45964 : H12AffineEnvironment.transform 7 62 env45963 = env45964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env45963 == env45964) = true)

theorem identity45964 : scanCanonicalize (H12AffineFastState.compose env45964 (packedSelected [4,9,16,17] rootPS)) = affineNative (2^(10+1) ^^^ 91) := by decide +kernel

theorem selectedBound45964 : packedSelected [4,9,16,17] rootPS < 2^1333 := by decide +kernel

def env45965 : List Nat := [2,4,8,16,32,64,46,62,107,46,91,16,8,0,42,24,81,55,111,43,16,77,17,24,111,1,17,1,1,0,5,17,62,0,81,43]

theorem envBound45965 : H12AffineFastState.Bounded env45965 := by
  intro p hp
  have h : env45965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45964_45965 : H12AffineEnvironment.transform 10 91 env45964 = env45965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 91 env45964 == env45965) = true)

theorem identity45965 : scanCanonicalize (H12AffineFastState.compose env45965 (packedSelected [2,3,4,5,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 29) := by decide +kernel

theorem selectedBound45965 : packedSelected [2,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env45966 : List Nat := [2,4,8,16,29,64,19,3,86,19,91,16,8,0,23,24,81,10,82,22,16,77,17,24,82,1,17,1,1,0,5,17,3,0,81,22]

theorem envBound45966 : H12AffineFastState.Bounded env45966 := by
  intro p hp
  have h : env45966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45965_45966 : H12AffineEnvironment.transform 4 29 env45965 = env45966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env45965 == env45966) = true)

theorem identity45966 : scanCanonicalize (H12AffineFastState.compose env45966 (packedSelected [0,2,3,7] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound45966 : packedSelected [0,2,3,7] rootPS < 2^1333 := by decide +kernel

def env45967 : List Nat := [2,4,3,16,22,64,19,3,86,19,80,16,3,0,23,19,81,1,82,22,16,70,17,19,82,1,17,1,1,0,5,17,3,0,81,22]

theorem envBound45967 : H12AffineFastState.Bounded env45967 := by
  intro p hp
  have h : env45967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45966_45967 : H12AffineEnvironment.transform 2 3 env45966 = env45967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env45966 == env45967) = true)

theorem identity45967 : scanCanonicalize (H12AffineFastState.compose env45967 (packedSelected [1,3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound45967 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env45968 : List Nat := [2,2,3,16,16,64,19,3,80,19,80,16,3,0,17,19,81,1,82,16,16,64,17,19,82,1,17,1,1,0,3,17,3,0,81,16]

theorem envBound45968 : H12AffineFastState.Bounded env45968 := by
  intro p hp
  have h : env45968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45967_45968 : H12AffineEnvironment.transform 1 2 env45967 = env45968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env45967 == env45968) = true)

theorem identity45968 : scanCanonicalize (H12AffineFastState.compose env45968 (packedSelected [0,2,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound45968 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env45969 : List Nat := [2,2,3,16,16,16,19,3,0,19,0,16,3,0,17,19,1,1,2,16,16,16,17,19,2,1,17,1,1,0,3,17,3,0,1,16]

theorem envBound45969 : H12AffineFastState.Bounded env45969 := by
  intro p hp
  have h : env45969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45968_45969 : H12AffineEnvironment.transform 5 16 env45968 = env45969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env45968 == env45969) = true)

theorem identity45969 : scanCanonicalize (H12AffineFastState.compose env45969 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound45969 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45970 : List Nat := [2,2,3,1,1,1,2,3,0,2,0,1,3,0,0,2,1,1,2,1,1,1,0,2,2,1,0,1,1,0,3,0,3,0,1,1]

theorem envBound45970 : H12AffineFastState.Bounded env45970 := by
  intro p hp
  have h : env45970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45969_45970 : H12AffineEnvironment.transform 3 1 env45969 = env45970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env45969 == env45970) = true)

theorem identity45970 : scanCanonicalize (H12AffineFastState.compose env45970 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound45970 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45971 : List Nat := [1,1,0,1,1,1,1,0,0,1,0,1,0,0,0,1,1,1,1,1,1,1,0,1,1,1,0,1,1,0,0,0,0,0,1,1]

theorem envBound45971 : H12AffineFastState.Bounded env45971 := by
  intro p hp
  have h : env45971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45970_45971 : H12AffineEnvironment.transform 0 1 env45970 = env45971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env45970 == env45971) = true)

def env45972 : List Nat := [2,4,8,16,32,64,128,256,341,272,2048,16,166,0,442,393,80,264,337,443,16,477,16,393,111,0,303,0,1,2404,171,17,256,175,81,277]

theorem envBound45972 : H12AffineFastState.Bounded env45972 := by
  intro p hp
  have h : env45972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45961_45972 : H12AffineEnvironment.transform 15 393 env45961 = env45972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 393 env45961 == env45972) = true)

theorem identity45972 : scanCanonicalize (H12AffineFastState.compose env45972 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 170) := by decide +kernel

theorem selectedBound45972 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env45973 : List Nat := [2,4,8,16,32,64,128,170,255,186,2048,16,166,0,16,35,80,162,251,17,16,119,16,35,111,0,133,0,1,2254,171,17,170,175,81,191]

theorem envBound45973 : H12AffineFastState.Bounded env45973 := by
  intro p hp
  have h : env45973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45972_45973 : H12AffineEnvironment.transform 7 170 env45972 = env45973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 170 env45972 == env45973) = true)

theorem identity45973 : scanCanonicalize (H12AffineFastState.compose env45973 (packedSelected [0,1,3,7,8,10,17,19,20] rootPS)) = affineNative (2^(5+1) ^^^ 6) := by decide +kernel

theorem selectedBound45973 : packedSelected [0,1,3,7,8,10,17,19,20] rootPS < 2^1333 := by decide +kernel

def env45974 : List Nat := [2,4,8,16,32,6,128,170,185,186,2048,16,166,0,16,35,22,162,189,17,16,49,16,35,41,0,133,0,1,2184,171,17,170,175,23,191]

theorem envBound45974 : H12AffineFastState.Bounded env45974 := by
  intro p hp
  have h : env45974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45973_45974 : H12AffineEnvironment.transform 5 6 env45973 = env45974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 6 env45973 == env45974) = true)

theorem identity45974 : scanCanonicalize (H12AffineFastState.compose env45974 (packedSelected [2,5,8,10,11,16] rootPS)) = affineNative (2^(10+1) ^^^ 29) := by decide +kernel

theorem selectedBound45974 : packedSelected [2,5,8,10,11,16] rootPS < 2^1333 := by decide +kernel

def env45975 : List Nat := [2,4,8,16,32,6,128,170,185,186,29,16,166,0,16,35,22,162,189,17,16,49,16,35,41,0,133,0,1,149,171,17,170,175,23,191]

theorem envBound45975 : H12AffineFastState.Bounded env45975 := by
  intro p hp
  have h : env45975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45974_45975 : H12AffineEnvironment.transform 10 29 env45974 = env45975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 29 env45974 == env45975) = true)

theorem identity45975 : scanCanonicalize (H12AffineFastState.compose env45975 (packedSelected [0,1,3,4,7,8,9] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound45975 : packedSelected [0,1,3,4,7,8,9] rootPS < 2^1333 := by decide +kernel

def env45976 : List Nat := [2,4,8,16,26,6,128,144,131,128,29,16,156,0,16,25,22,152,135,17,16,11,16,25,19,0,133,0,1,149,145,17,144,149,23,133]

theorem envBound45976 : H12AffineFastState.Bounded env45976 := by
  intro p hp
  have h : env45976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45975_45976 : H12AffineEnvironment.transform 4 26 env45975 = env45976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env45975 == env45976) = true)

theorem identity45976 : scanCanonicalize (H12AffineFastState.compose env45976 (packedSelected [1,3,4,5,7,11] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound45976 : packedSelected [1,3,4,5,7,11] rootPS < 2^1333 := by decide +kernel

def env45977 : List Nat := [2,4,8,6,12,6,128,134,131,128,11,6,138,0,6,15,0,142,135,7,6,11,6,15,5,0,133,0,1,131,135,7,134,131,1,133]

theorem envBound45977 : H12AffineFastState.Bounded env45977 := by
  intro p hp
  have h : env45977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45976_45977 : H12AffineEnvironment.transform 3 6 env45976 = env45977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env45976 == env45977) = true)

theorem identity45977 : scanCanonicalize (H12AffineFastState.compose env45977 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound45977 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45978 : List Nat := [2,4,8,6,12,6,15,9,12,15,11,6,5,0,6,15,0,1,8,7,6,11,6,15,5,0,10,0,1,12,8,7,9,12,1,10]

theorem envBound45978 : H12AffineFastState.Bounded env45978 := by
  intro p hp
  have h : env45978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45977_45978 : H12AffineEnvironment.transform 6 15 env45977 = env45978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env45977 == env45978) = true)

theorem identity45978 : scanCanonicalize (H12AffineFastState.compose env45978 (packedSelected [0,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound45978 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env45979 : List Nat := [2,3,8,1,11,1,8,9,11,8,11,1,2,0,1,8,0,1,8,0,1,11,1,8,2,0,10,0,1,11,8,0,9,11,1,10]

theorem envBound45979 : H12AffineFastState.Bounded env45979 := by
  intro p hp
  have h : env45979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45978_45979 : H12AffineEnvironment.transform 1 3 env45978 = env45979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env45978 == env45979) = true)

theorem identity45979 : scanCanonicalize (H12AffineFastState.compose env45979 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound45979 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45980 : List Nat := [2,3,1,1,2,1,1,0,2,1,2,1,2,0,1,1,0,1,1,0,1,2,1,1,2,0,3,0,1,2,1,0,0,2,1,3]

theorem envBound45980 : H12AffineFastState.Bounded env45980 := by
  intro p hp
  have h : env45980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45979_45980 : H12AffineEnvironment.transform 2 1 env45979 = env45980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env45979 == env45980) = true)

def env45981 : List Nat := [2,4,8,16,32,64,128,256,341,272,2048,17,8192,0,8477,65536,74111,65665,336,8476,17,477,74047,65537,8392,74030,302,74031,1,75850,8205,17,256,65830,81,276]

theorem envBound45981 : H12AffineFastState.Bounded env45981 := by
  intro p hp
  have h : env45981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45959_45981 : H12AffineEnvironment.transform 11 17 env45959 = env45981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env45959 == env45981) = true)

theorem identity45981 : scanCanonicalize (H12AffineFastState.compose env45981 (packedSelected [1,8,28] rootPS)) = affineNative (2^(6+1) ^^^ 62) := by decide +kernel

theorem selectedBound45981 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env45982 : List Nat := [2,4,8,16,32,64,62,256,341,272,2048,17,8192,0,8477,65536,74111,65599,336,8476,17,355,74047,65537,8310,74030,302,74031,1,75850,8205,17,256,65830,81,276]

theorem envBound45982 : H12AffineFastState.Bounded env45982 := by
  intro p hp
  have h : env45982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45981_45982 : H12AffineEnvironment.transform 6 62 env45981 = env45982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 62 env45981 == env45982) = true)

def env45983 : List Nat := [2,4,8,16,32,64,62,256,341,272,2048,17,8192,0,8477,304,8271,271,336,8476,17,355,8207,305,8310,8222,302,8223,1,10618,8205,17,256,22,81,276]

theorem envBound45983 : H12AffineFastState.Bounded env45983 := by
  intro p hp
  have h : env45983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45982_45983 : H12AffineEnvironment.transform 15 304 env45982 = env45983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 304 env45982 == env45983) = true)

theorem identity45983 : scanCanonicalize (H12AffineFastState.compose env45983 (packedSelected [3,4,9,10,13,17,18,19,20,23,24] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound45983 : packedSelected [3,4,9,10,13,17,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env45984 : List Nat := [2,4,8,16,32,64,62,256,341,272,2048,17,268,0,17,304,323,271,336,16,17,355,259,305,378,274,302,275,1,2166,257,17,256,22,81,276]

theorem envBound45984 : H12AffineFastState.Bounded env45984 := by
  intro p hp
  have h : env45984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45983_45984 : H12AffineEnvironment.transform 12 268 env45983 = env45984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env45983 == env45984) = true)

theorem identity45984 : scanCanonicalize (H12AffineFastState.compose env45984 (packedSelected [2,4,9,11,12,15,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 281) := by decide +kernel

theorem selectedBound45984 : packedSelected [2,4,9,11,12,15,17,18,20] rootPS < 2^1333 := by decide +kernel

def env45985 : List Nat := [2,4,8,16,32,64,62,256,341,272,281,17,268,0,17,304,323,271,336,16,17,355,259,305,378,274,302,275,1,367,257,17,256,22,81,276]

theorem envBound45985 : H12AffineFastState.Bounded env45985 := by
  intro p hp
  have h : env45985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45984_45985 : H12AffineEnvironment.transform 10 281 env45984 = env45985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 281 env45984 == env45985) = true)

theorem identity45985 : scanCanonicalize (H12AffineFastState.compose env45985 (packedSelected [0,1,3,5,7,12] rootPS)) = affineNative (2^(7+1) ^^^ 35) := by decide +kernel

theorem selectedBound45985 : packedSelected [0,1,3,5,7,12] rootPS < 2^1333 := by decide +kernel

def env45986 : List Nat := [2,4,8,16,32,64,62,35,118,51,58,17,47,0,17,19,96,44,115,16,17,64,32,18,89,49,13,48,1,76,34,17,35,22,81,55]

theorem envBound45986 : H12AffineFastState.Bounded env45986 := by
  intro p hp
  have h : env45986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45985_45986 : H12AffineEnvironment.transform 7 35 env45985 = env45986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 35 env45985 == env45986) = true)

theorem identity45986 : scanCanonicalize (H12AffineFastState.compose env45986 (packedSelected [2,4,5,8,9,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound45986 : packedSelected [2,4,5,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env45987 : List Nat := [2,4,8,16,32,32,62,35,22,51,58,17,47,0,17,19,0,44,19,16,17,32,32,18,57,49,13,48,1,44,34,17,35,22,49,55]

theorem envBound45987 : H12AffineFastState.Bounded env45987 := by
  intro p hp
  have h : env45987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45986_45987 : H12AffineEnvironment.transform 5 32 env45986 = env45987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env45986 == env45987) = true)

theorem identity45987 : scanCanonicalize (H12AffineFastState.compose env45987 (packedSelected [0,1,4] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound45987 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env45988 : List Nat := [2,4,8,16,27,27,5,24,22,8,1,17,20,0,17,19,0,23,19,16,17,27,27,18,2,10,13,11,1,23,25,17,24,22,10,12]

theorem envBound45988 : H12AffineFastState.Bounded env45988 := by
  intro p hp
  have h : env45988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45987_45988 : H12AffineEnvironment.transform 4 27 env45987 = env45988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env45987 == env45988) = true)

theorem identity45988 : scanCanonicalize (H12AffineFastState.compose env45988 (packedSelected [3,5] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound45988 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env45989 : List Nat := [2,3,8,16,27,27,2,24,17,8,1,17,19,0,17,19,0,16,19,16,17,27,27,18,2,10,10,11,1,16,25,17,24,17,10,11]

theorem envBound45989 : H12AffineFastState.Bounded env45989 := by
  intro p hp
  have h : env45989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45988_45989 : H12AffineEnvironment.transform 1 3 env45988 = env45989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env45988 == env45989) = true)

theorem identity45989 : scanCanonicalize (H12AffineFastState.compose env45989 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound45989 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env45990 : List Nat := [2,3,8,0,11,11,2,8,1,8,1,1,3,0,1,3,0,0,3,0,1,11,11,2,2,10,10,11,1,0,9,1,8,1,10,11]

theorem envBound45990 : H12AffineFastState.Bounded env45990 := by
  intro p hp
  have h : env45990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45989_45990 : H12AffineEnvironment.transform 3 0 env45989 = env45990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env45989 == env45990) = true)

theorem identity45990 : scanCanonicalize (H12AffineFastState.compose env45990 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound45990 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env45991 : List Nat := [2,3,3,0,0,0,2,3,1,3,1,1,3,0,1,3,0,0,3,0,1,0,0,2,2,1,1,0,1,0,2,1,3,1,1,0]

theorem envBound45991 : H12AffineFastState.Bounded env45991 := by
  intro p hp
  have h : env45991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45990_45991 : H12AffineEnvironment.transform 2 3 env45990 = env45991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env45990 == env45991) = true)

theorem identity45991 : scanCanonicalize (H12AffineFastState.compose env45991 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound45991 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env45992 : List Nat := [0,1,1,0,0,0,0,1,1,1,1,1,1,0,1,1,0,0,1,0,1,0,0,0,0,1,1,0,1,0,0,1,1,1,1,0]

theorem envBound45992 : H12AffineFastState.Bounded env45992 := by
  intro p hp
  have h : env45992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45991_45992 : H12AffineEnvironment.transform 0 0 env45991 = env45992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env45991 == env45992) = true)

def env45993 : List Nat := [2,4,8,16,32,64,62,256,341,272,2048,17,8192,0,8477,305,8270,270,336,8476,17,355,8206,304,8310,8223,302,8222,1,10619,8205,17,256,23,81,276]

theorem envBound45993 : H12AffineFastState.Bounded env45993 := by
  intro p hp
  have h : env45993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45982_45993 : H12AffineEnvironment.transform 15 305 env45982 = env45993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 305 env45982 == env45993) = true)

theorem identity45993 : scanCanonicalize (H12AffineFastState.compose env45993 (packedSelected [3,4,9,10,13,17,18,19,20,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 18) := by decide +kernel

theorem selectedBound45993 : packedSelected [3,4,9,10,13,17,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env45994 : List Nat := [2,4,8,16,32,64,62,18,71,2,2048,17,8192,0,8207,35,8270,28,66,8206,17,113,8206,34,8310,8223,60,8222,1,10345,8205,17,18,23,81,6]

theorem envBound45994 : H12AffineFastState.Bounded env45994 := by
  intro p hp
  have h : env45994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45993_45994 : H12AffineEnvironment.transform 7 18 env45993 = env45994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 18 env45993 == env45994) = true)

theorem identity45994 : scanCanonicalize (H12AffineFastState.compose env45994 (packedSelected [0,1,2,7,8,11,17,18,19,20,21] rootPS)) = affineNative (2^(10+1) ^^^ 92) := by decide +kernel

theorem selectedBound45994 : packedSelected [0,1,2,7,8,11,17,18,19,20,21] rootPS < 2^1333 := by decide +kernel

def env45995 : List Nat := [2,4,8,16,32,64,62,18,71,2,92,17,8192,0,8207,35,8270,28,66,8206,17,113,8206,34,8310,8223,60,8222,1,8245,8205,17,18,23,81,6]

theorem envBound45995 : H12AffineFastState.Bounded env45995 := by
  intro p hp
  have h : env45995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45994_45995 : H12AffineEnvironment.transform 10 92 env45994 = env45995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 92 env45994 == env45995) = true)

theorem identity45995 : scanCanonicalize (H12AffineFastState.compose env45995 (packedSelected [0,1,2,7,8,18] rootPS)) = affineNative (2^(12+1) ^^^ 101) := by decide +kernel

theorem selectedBound45995 : packedSelected [0,1,2,7,8,18] rootPS < 2^1333 := by decide +kernel

def env45996 : List Nat := [2,4,8,16,32,64,62,18,71,2,92,17,101,0,106,35,43,28,66,107,17,113,107,34,19,122,60,123,1,80,104,17,18,23,81,6]

theorem envBound45996 : H12AffineFastState.Bounded env45996 := by
  intro p hp
  have h : env45996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45995_45996 : H12AffineEnvironment.transform 12 101 env45995 = env45996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 101 env45995 == env45996) = true)

theorem identity45996 : scanCanonicalize (H12AffineFastState.compose env45996 (packedSelected [0,2,9,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 38) := by decide +kernel

theorem selectedBound45996 : packedSelected [0,2,9,10,11] rootPS < 2^1333 := by decide +kernel

def env45997 : List Nat := [2,4,8,16,32,38,62,18,33,2,58,17,3,0,12,35,43,28,36,13,17,23,13,34,19,28,60,29,1,54,14,17,18,23,55,6]

theorem envBound45997 : H12AffineFastState.Bounded env45997 := by
  intro p hp
  have h : env45997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45996_45997 : H12AffineEnvironment.transform 5 38 env45996 = env45997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 38 env45996 == env45997) = true)

theorem identity45997 : scanCanonicalize (H12AffineFastState.compose env45997 (packedSelected [0,1,4] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound45997 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env45998 : List Nat := [2,4,8,16,26,28,4,18,27,2,0,17,3,0,12,25,17,28,30,13,17,23,13,24,19,28,6,29,1,12,14,17,18,23,13,6]

theorem envBound45998 : H12AffineFastState.Bounded env45998 := by
  intro p hp
  have h : env45998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45997_45998 : H12AffineEnvironment.transform 4 26 env45997 = env45998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env45997 == env45998) = true)

theorem identity45998 : scanCanonicalize (H12AffineFastState.compose env45998 (packedSelected [2,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound45998 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env45999 : List Nat := [2,4,8,0,10,12,4,2,11,2,0,1,3,0,12,9,1,12,14,13,1,7,13,8,3,12,6,13,1,12,14,1,2,7,13,6]

theorem envBound45999 : H12AffineFastState.Bounded env45999 := by
  intro p hp
  have h : env45999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45998_45999 : H12AffineEnvironment.transform 3 0 env45998 = env45999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env45998 == env45999) = true)

theorem identity45999 : scanCanonicalize (H12AffineFastState.compose env45999 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound45999 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46000 : List Nat := [2,4,2,0,0,6,4,2,1,2,0,1,3,0,6,3,1,6,4,7,1,7,7,2,3,6,6,7,1,6,4,1,2,7,7,6]

theorem envBound46000 : H12AffineFastState.Bounded env46000 := by
  intro p hp
  have h : env46000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45999_46000 : H12AffineEnvironment.transform 2 2 env45999 = env46000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env45999 == env46000) = true)

theorem identity46000 : scanCanonicalize (H12AffineFastState.compose env46000 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound46000 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46001 : List Nat := [2,2,2,0,0,0,2,2,1,2,0,1,3,0,0,3,1,0,2,1,1,1,1,2,3,0,0,1,1,0,2,1,2,1,1,0]

theorem envBound46001 : H12AffineFastState.Bounded env46001 := by
  intro p hp
  have h : env46001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46000_46001 : H12AffineEnvironment.transform 1 2 env46000 = env46001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env46000 == env46001) = true)

theorem identity46001 : scanCanonicalize (H12AffineFastState.compose env46001 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound46001 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46002 : List Nat := [0,0,0,0,0,0,0,0,1,0,0,1,1,0,0,1,1,0,0,1,1,1,1,0,1,0,0,1,1,0,0,1,0,1,1,0]

theorem envBound46002 : H12AffineFastState.Bounded env46002 := by
  intro p hp
  have h : env46002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46001_46002 : H12AffineEnvironment.transform 0 0 env46001 = env46002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env46001 == env46002) = true)

def env46003 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74863,262144,4416,13341,4096,476,74046,69649,13768,78895,332223,74814,1297,81226,8204,1281,256,65831,1345,5953]

theorem envBound46003 : H12AffineFastState.Bounded env46003 := by
  intro p hp
  have h : env46003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45831_46003 : H12AffineEnvironment.transform 13 1297 env45831 = env46003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env45831 == env46003) = true)

def env46004 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74863,65664,4416,13341,4096,476,74046,69649,13768,78895,4415,74814,1297,81226,8204,1281,256,65831,1345,5953]

theorem envBound46004 : H12AffineFastState.Bounded env46004 := by
  intro p hp
  have h : env46004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46003_46004 : H12AffineEnvironment.transform 17 65664 env46003 = env46004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env46003 == env46004) = true)

theorem identity46004 : scanCanonicalize (H12AffineFastState.compose env46004 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound46004 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env46005 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,25,1297,5125,65536,66678,65664,4416,5124,4096,476,65831,69649,5585,70710,4415,66599,1297,73043,21,1281,256,65831,1345,5953]

theorem envBound46005 : H12AffineFastState.Bounded env46005 := by
  intro p hp
  have h : env46005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46004_46005 : H12AffineEnvironment.transform 12 25 env46004 = env46005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env46004 == env46005) = true)

def env46006 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,4096,25,1297,5125,65536,66678,65664,4416,5124,4096,476,65831,69649,5585,70710,4415,66599,1297,73043,21,1281,256,65831,1345,5141]

theorem envBound46006 : H12AffineFastState.Bounded env46006 := by
  intro p hp
  have h : env46006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46005_46006 : H12AffineEnvironment.transform 8 340 env46005 = env46006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env46005 == env46006) = true)

def env46007 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,1280,25,1297,261,65536,66678,65664,1088,260,1280,476,65831,66833,209,65846,1087,66599,1297,67667,21,1281,256,65831,1345,277]

theorem envBound46007 : H12AffineFastState.Bounded env46007 := by
  intro p hp
  have h : env46007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46006_46007 : H12AffineEnvironment.transform 11 1280 env46006 = env46007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env46006 == env46007) = true)

theorem identity46007 : scanCanonicalize (H12AffineFastState.compose env46007 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 1348) := by decide +kernel

theorem selectedBound46007 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env46008 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,1280,25,1297,261,1348,306,1476,1088,260,1280,476,1123,85,209,1138,1087,355,1297,3351,21,1281,256,1123,1345,277]

theorem envBound46008 : H12AffineFastState.Bounded env46008 := by
  intro p hp
  have h : env46008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46007_46008 : H12AffineEnvironment.transform 15 1348 env46007 = env46008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1348 env46007 == env46008) = true)

def env46009 : List Nat := [2,4,8,16,32,64,128,256,340,272,2048,16,25,1,261,84,306,212,336,260,16,476,371,85,209,354,303,355,1,2055,21,17,256,371,81,277]

theorem envBound46009 : H12AffineFastState.Bounded env46009 := by
  intro p hp
  have h : env46009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46008_46009 : H12AffineEnvironment.transform 9 272 env46008 = env46009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env46008 == env46009) = true)

theorem identity46009 : scanCanonicalize (H12AffineFastState.compose env46009 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound46009 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env46010 : List Nat := [2,4,8,16,32,64,128,69,17,85,2048,16,25,1,64,84,119,212,21,65,16,153,54,85,209,39,106,38,1,2055,21,17,69,54,81,80]

theorem envBound46010 : H12AffineFastState.Bounded env46010 := by
  intro p hp
  have h : env46010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46009_46010 : H12AffineEnvironment.transform 7 69 env46009 = env46010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env46009 == env46010) = true)

theorem identity46010 : scanCanonicalize (H12AffineFastState.compose env46010 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound46010 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env46011 : List Nat := [2,4,8,16,7,64,128,69,17,85,2048,16,25,1,64,84,80,212,21,65,16,153,17,85,209,0,77,1,1,2055,21,17,69,17,81,80]

theorem envBound46011 : H12AffineFastState.Bounded env46011 := by
  intro p hp
  have h : env46011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46010_46011 : H12AffineEnvironment.transform 4 7 env46010 = env46011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env46010 == env46011) = true)

theorem identity46011 : scanCanonicalize (H12AffineFastState.compose env46011 (packedSelected [1,8,12] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound46011 : packedSelected [1,8,12] rootPS < 2^1333 := by decide +kernel

def env46012 : List Nat := [2,4,8,10,7,64,128,69,11,79,2048,10,3,1,64,78,74,206,15,65,10,131,11,79,203,0,77,1,1,2055,15,11,69,11,75,74]

theorem envBound46012 : H12AffineFastState.Bounded env46012 := by
  intro p hp
  have h : env46012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46011_46012 : H12AffineEnvironment.transform 3 10 env46011 = env46012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env46011 == env46012) = true)

theorem identity46012 : scanCanonicalize (H12AffineFastState.compose env46012 (packedSelected [0,2,3,5,7,8,10,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 76) := by decide +kernel

theorem selectedBound46012 : packedSelected [0,2,3,5,7,8,10,11,13] rootPS < 2^1333 := by decide +kernel

def env46013 : List Nat := [2,4,8,10,7,64,128,69,11,79,76,10,3,1,64,78,74,206,15,65,10,131,11,79,203,0,77,1,1,75,15,11,69,11,75,74]

theorem envBound46013 : H12AffineFastState.Bounded env46013 := by
  intro p hp
  have h : env46013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46012_46013 : H12AffineEnvironment.transform 10 76 env46012 = env46013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 76 env46012 == env46013) = true)

theorem identity46013 : scanCanonicalize (H12AffineFastState.compose env46013 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound46013 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46014 : List Nat := [2,3,8,10,0,64,128,66,11,72,75,10,3,1,64,73,74,201,8,65,10,131,11,72,203,0,74,1,1,75,8,11,66,11,75,74]

theorem envBound46014 : H12AffineFastState.Bounded env46014 := by
  intro p hp
  have h : env46014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46013_46014 : H12AffineEnvironment.transform 1 3 env46013 = env46014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env46013 == env46014) = true)

def env46015 : List Nat := [2,4,8,16,32,64,128,256,340,273,2048,17,25,0,261,85,306,213,337,260,17,476,370,85,209,355,302,355,0,2054,21,16,256,370,80,277]

theorem envBound46015 : H12AffineFastState.Bounded env46015 := by
  intro p hp
  have h : env46015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46008_46015 : H12AffineEnvironment.transform 9 273 env46008 = env46015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env46008 == env46015) = true)

theorem identity46015 : scanCanonicalize (H12AffineFastState.compose env46015 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound46015 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env46016 : List Nat := [2,4,8,16,32,64,128,4,80,21,2048,17,25,0,1,85,54,213,85,0,17,216,118,85,209,103,42,103,0,2054,21,16,4,118,80,17]

theorem envBound46016 : H12AffineFastState.Bounded env46016 := by
  intro p hp
  have h : env46016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46015_46016 : H12AffineEnvironment.transform 7 4 env46015 = env46016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env46015 == env46016) = true)

theorem identity46016 : scanCanonicalize (H12AffineFastState.compose env46016 (packedSelected [0,1,2,4,7,8,9,10,12,13,16,18] rootPS)) = affineNative (2^(6+1) ^^^ 104) := by decide +kernel

theorem selectedBound46016 : packedSelected [0,1,2,4,7,8,9,10,12,13,16,18] rootPS < 2^1333 := by decide +kernel

def env46017 : List Nat := [2,4,8,16,32,64,104,4,80,21,2048,17,25,0,1,85,54,61,85,0,17,48,118,85,57,103,42,103,0,2054,21,16,4,118,80,17]

theorem envBound46017 : H12AffineFastState.Bounded env46017 := by
  intro p hp
  have h : env46017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46016_46017 : H12AffineEnvironment.transform 6 104 env46016 = env46017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 104 env46016 == env46017) = true)

theorem identity46017 : scanCanonicalize (H12AffineFastState.compose env46017 (packedSelected [0,3,4,7,9,12] rootPS)) = affineNative (2^(10+1) ^^^ 118) := by decide +kernel

theorem selectedBound46017 : packedSelected [0,3,4,7,9,12] rootPS < 2^1333 := by decide +kernel

def env46018 : List Nat := [2,4,8,16,32,64,104,4,80,21,118,17,25,0,1,85,54,61,85,0,17,48,118,85,57,103,42,103,0,112,21,16,4,118,80,17]

theorem envBound46018 : H12AffineFastState.Bounded env46018 := by
  intro p hp
  have h : env46018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46017_46018 : H12AffineEnvironment.transform 10 118 env46017 = env46018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 118 env46017 == env46018) = true)

theorem identity46018 : scanCanonicalize (H12AffineFastState.compose env46018 (packedSelected [0,1,7,8,10,11,13] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound46018 : packedSelected [0,1,7,8,10,11,13] rootPS < 2^1333 := by decide +kernel

def env46019 : List Nat := [2,4,8,16,12,64,68,4,80,21,90,17,25,0,1,85,26,17,85,0,17,28,90,85,21,75,6,75,0,92,21,16,4,90,80,17]

theorem envBound46019 : H12AffineFastState.Bounded env46019 := by
  intro p hp
  have h : env46019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46018_46019 : H12AffineEnvironment.transform 4 12 env46018 = env46019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env46018 == env46019) = true)

theorem identity46019 : scanCanonicalize (H12AffineFastState.compose env46019 (packedSelected [3,5] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound46019 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env46020 : List Nat := [2,4,8,12,12,64,68,4,76,9,70,13,5,0,1,73,6,13,73,0,13,0,70,73,9,75,6,75,0,64,9,12,4,70,76,13]

theorem envBound46020 : H12AffineFastState.Bounded env46020 := by
  intro p hp
  have h : env46020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46019_46020 : H12AffineEnvironment.transform 3 12 env46019 = env46020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env46019 == env46020) = true)

theorem identity46020 : scanCanonicalize (H12AffineFastState.compose env46020 (packedSelected [0,3,4] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound46020 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env46021 : List Nat := [2,4,4,0,0,64,68,4,64,5,70,1,5,0,1,69,6,1,69,0,1,0,70,69,5,71,6,71,0,64,5,0,4,70,64,1]

theorem envBound46021 : H12AffineFastState.Bounded env46021 := by
  intro p hp
  have h : env46021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46020_46021 : H12AffineEnvironment.transform 2 4 env46020 = env46021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env46020 == env46021) = true)

theorem identity46021 : scanCanonicalize (H12AffineFastState.compose env46021 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound46021 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46022 : List Nat := [2,4,4,0,0,0,4,4,0,5,6,1,5,0,1,5,6,1,5,0,1,0,6,5,5,7,6,7,0,0,5,0,4,6,0,1]

theorem envBound46022 : H12AffineFastState.Bounded env46022 := by
  intro p hp
  have h : env46022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46021_46022 : H12AffineEnvironment.transform 5 0 env46021 = env46022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env46021 == env46022) = true)

theorem identity46022 : scanCanonicalize (H12AffineFastState.compose env46022 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound46022 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46023 : List Nat := [0,4,4,0,0,0,4,4,0,5,4,1,5,0,1,5,4,1,5,0,1,0,4,5,5,5,4,5,0,0,5,0,4,4,0,1]

theorem envBound46023 : H12AffineFastState.Bounded env46023 := by
  intro p hp
  have h : env46023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46022_46023 : H12AffineEnvironment.transform 0 0 env46022 = env46023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env46022 == env46023) = true)

theorem identity46023 : scanCanonicalize (H12AffineFastState.compose env46023 (packedSelected [7] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound46023 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env46024 : List Nat := [0,1,1,0,0,0,1,1,0,0,1,1,0,0,1,0,1,1,0,0,1,0,1,0,0,0,1,0,0,0,0,0,1,1,0,1]

theorem envBound46024 : H12AffineFastState.Bounded env46024 := by
  intro p hp
  have h : env46024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46023_46024 : H12AffineEnvironment.transform 1 1 env46023 = env46024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env46023 == env46024) = true)

def env46025 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,1281,25,1297,260,65536,66678,65664,1089,261,1281,476,65831,66832,208,65847,1086,66599,1297,67666,21,1281,256,65831,1345,276]

theorem envBound46025 : H12AffineFastState.Bounded env46025 := by
  intro p hp
  have h : env46025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46006_46025 : H12AffineEnvironment.transform 11 1281 env46006 = env46025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env46006 == env46025) = true)

theorem identity46025 : scanCanonicalize (H12AffineFastState.compose env46025 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 84) := by decide +kernel

theorem selectedBound46025 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env46026 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,1281,25,1297,260,84,1058,212,1089,261,1281,476,371,1348,208,355,1086,1139,1297,2054,21,1281,256,371,1345,276]

theorem envBound46026 : H12AffineFastState.Bounded env46026 := by
  intro p hp
  have h : env46026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46025_46026 : H12AffineEnvironment.transform 15 84 env46025 = env46026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 84 env46025 == env46026) = true)

def env46027 : List Nat := [2,4,8,16,32,64,128,100,48,1024,2048,1125,25,1141,96,84,1058,212,1089,97,1125,184,23,1056,208,7,1086,1139,1141,2054,21,1125,100,23,1061,112]

theorem envBound46027 : H12AffineFastState.Bounded env46027 := by
  intro p hp
  have h : env46027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46026_46027 : H12AffineEnvironment.transform 7 100 env46026 = env46027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 100 env46026 == env46027) = true)

theorem identity46027 : scanCanonicalize (H12AffineFastState.compose env46027 (packedSelected [0,1,3,8,10,15,19,27,41] rootPS)) = affineNative (2^(6+1) ^^^ 72) := by decide +kernel

theorem selectedBound46027 : packedSelected [0,1,3,8,10,15,19,27,41] rootPS < 2^1333 := by decide +kernel

def env46028 : List Nat := [2,4,8,16,32,64,72,100,48,1024,2048,1125,25,1141,96,84,1058,28,1089,97,1125,112,23,1056,24,7,1086,1139,1141,2054,21,1125,100,23,1061,112]

theorem envBound46028 : H12AffineFastState.Bounded env46028 := by
  intro p hp
  have h : env46028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46027_46028 : H12AffineEnvironment.transform 6 72 env46027 = env46028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 72 env46027 == env46028) = true)

theorem identity46028 : scanCanonicalize (H12AffineFastState.compose env46028 (packedSelected [0,1,7,10,12,15,16,19,24] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound46028 : packedSelected [0,1,7,10,12,15,16,19,24] rootPS < 2^1333 := by decide +kernel

def env46029 : List Nat := [2,4,8,16,16,64,72,84,0,1024,2048,1109,25,1093,80,84,1042,28,1089,81,1109,64,23,1040,24,7,1038,1091,1093,2054,21,1109,84,23,1045,64]

theorem envBound46029 : H12AffineFastState.Bounded env46029 := by
  intro p hp
  have h : env46029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46028_46029 : H12AffineEnvironment.transform 4 16 env46028 = env46029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env46028 == env46029) = true)

theorem identity46029 : scanCanonicalize (H12AffineFastState.compose env46029 (packedSelected [1,3,5,8,11,13,15,16,18] rootPS)) = affineNative (2^(5+1) ^^^ 28) := by decide +kernel

theorem selectedBound46029 : packedSelected [1,3,5,8,11,13,15,16,18] rootPS < 2^1333 := by decide +kernel

def env46030 : List Nat := [2,4,8,16,16,28,20,8,0,1024,2048,1033,25,1049,12,8,1042,28,1053,13,1033,28,23,1040,24,7,1038,1055,1049,2054,21,1033,8,23,1045,28]

theorem envBound46030 : H12AffineFastState.Bounded env46030 := by
  intro p hp
  have h : env46030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46029_46030 : H12AffineEnvironment.transform 5 28 env46029 = env46030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 28 env46029 == env46030) = true)

theorem identity46030 : scanCanonicalize (H12AffineFastState.compose env46030 (packedSelected [1,3,4,5,7,8,12] rootPS)) = affineNative (2^(9+1) ^^^ 30) := by decide +kernel

theorem selectedBound46030 : packedSelected [1,3,4,5,7,8,12] rootPS < 2^1333 := by decide +kernel

def env46031 : List Nat := [2,4,8,16,16,28,20,8,0,30,2048,23,25,7,12,8,12,28,3,13,23,28,23,14,24,7,16,1,7,2054,21,23,8,23,11,28]

theorem envBound46031 : H12AffineFastState.Bounded env46031 := by
  intro p hp
  have h : env46031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46030_46031 : H12AffineEnvironment.transform 9 30 env46030 = env46031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 30 env46030 == env46031) = true)

theorem identity46031 : scanCanonicalize (H12AffineFastState.compose env46031 (packedSelected [2,8] rootPS)) = affineNative (2^(10+1) ^^^ 13) := by decide +kernel

theorem selectedBound46031 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env46032 : List Nat := [2,4,8,16,16,28,20,8,0,30,13,23,25,7,12,8,12,28,3,13,23,28,23,14,24,7,16,1,7,11,21,23,8,23,11,28]

theorem envBound46032 : H12AffineFastState.Bounded env46032 := by
  intro p hp
  have h : env46032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46031_46032 : H12AffineEnvironment.transform 10 13 env46031 = env46032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 13 env46031 == env46032) = true)

theorem identity46032 : scanCanonicalize (H12AffineFastState.compose env46032 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound46032 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46033 : List Nat := [2,4,8,13,13,1,9,8,0,3,13,10,4,7,12,8,12,1,3,13,10,1,10,14,5,7,13,1,7,11,8,10,8,10,11,1]

theorem envBound46033 : H12AffineFastState.Bounded env46033 := by
  intro p hp
  have h : env46033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46032_46033 : H12AffineEnvironment.transform 3 13 env46032 = env46033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env46032 == env46033) = true)

theorem identity46033 : scanCanonicalize (H12AffineFastState.compose env46033 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound46033 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46034 : List Nat := [2,4,0,5,5,1,1,0,0,3,5,2,4,7,4,0,4,1,3,5,2,1,2,6,5,7,5,1,7,3,0,2,0,2,3,1]

theorem envBound46034 : H12AffineFastState.Bounded env46034 := by
  intro p hp
  have h : env46034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46033_46034 : H12AffineEnvironment.transform 2 0 env46033 = env46034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env46033 == env46034) = true)

def env46035 : List Nat := [2,4,8,16,32,64,128,101,49,1024,2048,1124,25,1140,97,84,1058,212,1089,96,1124,185,22,1057,208,6,1086,1139,1140,2054,21,1124,101,22,1060,113]

theorem envBound46035 : H12AffineFastState.Bounded env46035 := by
  intro p hp
  have h : env46035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46026_46035 : H12AffineEnvironment.transform 7 101 env46026 = env46035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 101 env46026 == env46035) = true)

theorem identity46035 : scanCanonicalize (H12AffineFastState.compose env46035 (packedSelected [0,1,3,8,10,15,19,27,41] rootPS)) = affineNative (2^(6+1) ^^^ 78) := by decide +kernel

theorem selectedBound46035 : packedSelected [0,1,3,8,10,15,19,27,41] rootPS < 2^1333 := by decide +kernel

def env46036 : List Nat := [2,4,8,16,32,64,78,101,49,1024,2048,1124,25,1140,97,84,1058,26,1089,96,1124,119,22,1057,30,6,1086,1139,1140,2054,21,1124,101,22,1060,113]

theorem envBound46036 : H12AffineFastState.Bounded env46036 := by
  intro p hp
  have h : env46036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46035_46036 : H12AffineEnvironment.transform 6 78 env46035 = env46036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 78 env46035 == env46036) = true)

theorem identity46036 : scanCanonicalize (H12AffineFastState.compose env46036 (packedSelected [0,1,2,3,5,7,12,13,17,21] rootPS)) = affineNative (2^(9+1) ^^^ 83) := by decide +kernel

theorem selectedBound46036 : packedSelected [0,1,2,3,5,7,12,13,17,21] rootPS < 2^1333 := by decide +kernel

def env46037 : List Nat := [2,4,8,16,32,64,78,101,49,83,2048,55,25,39,97,84,113,26,18,96,55,119,22,114,30,6,109,32,39,2054,21,55,101,22,119,113]

theorem envBound46037 : H12AffineFastState.Bounded env46037 := by
  intro p hp
  have h : env46037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46036_46037 : H12AffineEnvironment.transform 9 83 env46036 = env46037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 83 env46036 == env46037) = true)

theorem identity46037 : scanCanonicalize (H12AffineFastState.compose env46037 (packedSelected [0,2,5,7,8,10,11,12,16] rootPS)) = affineNative (2^(10+1) ^^^ 65) := by decide +kernel

theorem selectedBound46037 : packedSelected [0,2,5,7,8,10,11,12,16] rootPS < 2^1333 := by decide +kernel

def env46038 : List Nat := [2,4,8,16,32,64,78,101,49,83,65,55,25,39,97,84,113,26,18,96,55,119,22,114,30,6,109,32,39,71,21,55,101,22,119,113]

theorem envBound46038 : H12AffineFastState.Bounded env46038 := by
  intro p hp
  have h : env46038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46037_46038 : H12AffineEnvironment.transform 10 65 env46037 = env46038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 65 env46037 == env46038) = true)

theorem identity46038 : scanCanonicalize (H12AffineFastState.compose env46038 (packedSelected [1,2,4,7,8,10,12] rootPS)) = affineNative (2^(5+1) ^^^ 55) := by decide +kernel

theorem selectedBound46038 : packedSelected [1,2,4,7,8,10,12] rootPS < 2^1333 := by decide +kernel

def env46039 : List Nat := [2,4,8,16,32,55,57,18,49,36,54,55,25,39,22,35,6,26,18,23,55,0,22,5,30,6,26,32,39,48,21,55,18,22,0,6]

theorem envBound46039 : H12AffineFastState.Bounded env46039 := by
  intro p hp
  have h : env46039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46038_46039 : H12AffineEnvironment.transform 5 55 env46038 = env46039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 55 env46038 == env46039) = true)

theorem identity46039 : scanCanonicalize (H12AffineFastState.compose env46039 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound46039 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env46040 : List Nat := [2,4,8,16,28,11,5,18,13,24,10,11,25,27,22,31,6,26,18,23,11,0,22,5,30,6,26,28,27,12,21,11,18,22,0,6]

theorem envBound46040 : H12AffineFastState.Bounded env46040 := by
  intro p hp
  have h : env46040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46039_46040 : H12AffineEnvironment.transform 4 28 env46039 = env46040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env46039 == env46040) = true)

theorem identity46040 : scanCanonicalize (H12AffineFastState.compose env46040 (packedSelected [1,2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound46040 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env46041 : List Nat := [2,4,8,10,6,11,5,8,13,2,10,11,3,1,12,5,6,0,8,13,11,0,12,5,4,6,0,6,1,12,15,11,8,12,0,6]

theorem envBound46041 : H12AffineFastState.Bounded env46041 := by
  intro p hp
  have h : env46041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46040_46041 : H12AffineEnvironment.transform 3 10 env46040 = env46041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env46040 == env46041) = true)

theorem identity46041 : scanCanonicalize (H12AffineFastState.compose env46041 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound46041 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env46042 : List Nat := [2,4,5,7,6,6,5,5,0,2,7,6,3,1,1,5,6,0,5,0,6,0,1,5,4,6,0,6,1,1,2,6,5,1,0,6]

theorem envBound46042 : H12AffineFastState.Bounded env46042 := by
  intro p hp
  have h : env46042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46041_46042 : H12AffineEnvironment.transform 2 5 env46041 = env46042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env46041 == env46042) = true)

def env46043 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,4096,25,1297,5125,65536,66678,65664,4416,5124,4096,476,65831,69649,5585,70710,4415,66599,1297,73043,21,1281,256,65831,1345,5140]

theorem envBound46043 : H12AffineFastState.Bounded env46043 := by
  intro p hp
  have h : env46043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46005_46043 : H12AffineEnvironment.transform 8 341 env46005 = env46043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env46005 == env46043) = true)

def env46044 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,1280,25,1297,261,65536,66678,65664,1088,260,1280,476,65831,66833,209,65846,1087,66599,1297,67667,21,1281,256,65831,1345,276]

theorem envBound46044 : H12AffineFastState.Bounded env46044 := by
  intro p hp
  have h : env46044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46043_46044 : H12AffineEnvironment.transform 11 1280 env46043 = env46044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env46043 == env46044) = true)

theorem identity46044 : scanCanonicalize (H12AffineFastState.compose env46044 (packedSelected [1,8,28] rootPS)) = affineNative (2^(9+1) ^^^ 115) := by decide +kernel

theorem selectedBound46044 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env46045 : List Nat := [2,4,8,16,32,64,128,256,341,115,2048,371,25,354,261,65536,65541,65664,51,260,371,476,65831,65890,209,65846,76,65620,354,67667,21,370,256,65831,306,276]

theorem envBound46045 : H12AffineFastState.Bounded env46045 := by
  intro p hp
  have h : env46045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46044_46045 : H12AffineEnvironment.transform 9 115 env46044 = env46045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 115 env46044 == env46045) = true)

def env46046 : List Nat := [2,4,8,16,32,64,128,104,61,115,2048,27,25,10,109,65536,65541,65664,51,108,27,180,65615,65546,209,65630,76,65620,10,67667,21,26,104,65615,90,124]

theorem envBound46046 : H12AffineFastState.Bounded env46046 := by
  intro p hp
  have h : env46046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46045_46046 : H12AffineEnvironment.transform 7 104 env46045 = env46046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 104 env46045 == env46046) = true)

theorem identity46046 : scanCanonicalize (H12AffineFastState.compose env46046 (packedSelected [0,8,13,15,24,27] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound46046 : packedSelected [0,8,13,15,24,27] rootPS < 2^1333 := by decide +kernel

def env46047 : List Nat := [2,4,8,16,32,64,128,104,61,115,2048,27,25,10,109,170,175,42,51,108,27,180,229,160,209,244,76,254,10,2297,21,26,104,229,90,124]

theorem envBound46047 : H12AffineFastState.Bounded env46047 := by
  intro p hp
  have h : env46047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46046_46047 : H12AffineEnvironment.transform 15 170 env46046 = env46047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env46046 == env46047) = true)

theorem identity46047 : scanCanonicalize (H12AffineFastState.compose env46047 (packedSelected [0,2,8,9,10,11,12,13,16,17,20,23,24] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound46047 : packedSelected [0,2,8,9,10,11,12,13,16,17,20,23,24] rootPS < 2^1333 := by decide +kernel

def env46048 : List Nat := [2,4,8,16,32,64,128,104,61,115,137,27,25,10,109,170,175,42,51,108,27,180,229,160,209,244,76,254,10,112,21,26,104,229,90,124]

theorem envBound46048 : H12AffineFastState.Bounded env46048 := by
  intro p hp
  have h : env46048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46047_46048 : H12AffineEnvironment.transform 10 137 env46047 = env46048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env46047 == env46048) = true)

theorem identity46048 : scanCanonicalize (H12AffineFastState.compose env46048 (packedSelected [0,1,4,7,9,12,13,15,17] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound46048 : packedSelected [0,1,4,7,9,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env46049 : List Nat := [2,4,8,16,13,64,128,69,16,94,137,27,25,10,64,135,130,7,30,65,27,153,200,141,209,217,76,211,10,93,21,26,69,200,90,81]

theorem envBound46049 : H12AffineFastState.Bounded env46049 := by
  intro p hp
  have h : env46049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46048_46049 : H12AffineEnvironment.transform 4 13 env46048 = env46049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env46048 == env46049) = true)

theorem identity46049 : scanCanonicalize (H12AffineFastState.compose env46049 (packedSelected [0,3,8,9,10] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound46049 : packedSelected [0,3,8,9,10] rootPS < 2^1333 := by decide +kernel

def env46050 : List Nat := [2,2,8,16,11,64,128,67,16,88,137,27,25,10,64,129,130,1,24,65,27,153,200,139,209,217,74,211,10,91,19,26,67,200,90,81]

theorem envBound46050 : H12AffineFastState.Bounded env46050 := by
  intro p hp
  have h : env46050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46049_46050 : H12AffineEnvironment.transform 1 2 env46049 = env46050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env46049 == env46050) = true)

theorem identity46050 : scanCanonicalize (H12AffineFastState.compose env46050 (packedSelected [2,4,7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound46050 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env46051 : List Nat := [2,2,8,1,11,64,128,67,1,73,137,10,8,10,64,129,130,1,9,65,10,136,200,139,192,200,74,194,10,74,2,11,67,200,75,64]

theorem envBound46051 : H12AffineFastState.Bounded env46051 := by
  intro p hp
  have h : env46051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46050_46051 : H12AffineEnvironment.transform 3 1 env46050 = env46051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env46050 == env46051) = true)

theorem identity46051 : scanCanonicalize (H12AffineFastState.compose env46051 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound46051 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env46052 : List Nat := [2,2,8,1,11,1,128,2,1,8,137,10,8,10,1,129,130,1,9,0,10,136,137,139,129,137,11,131,10,11,2,11,2,137,10,1]

theorem envBound46052 : H12AffineFastState.Bounded env46052 := by
  intro p hp
  have h : env46052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46051_46052 : H12AffineEnvironment.transform 5 1 env46051 = env46052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env46051 == env46052) = true)

theorem identity46052 : scanCanonicalize (H12AffineFastState.compose env46052 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound46052 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46053 : List Nat := [2,2,8,1,11,1,3,2,1,8,10,10,8,10,1,2,1,1,9,0,10,11,10,8,2,10,11,0,10,11,2,11,2,10,10,1]

theorem envBound46053 : H12AffineFastState.Bounded env46053 := by
  intro p hp
  have h : env46053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46052_46053 : H12AffineEnvironment.transform 6 3 env46052 = env46053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env46052 == env46053) = true)

def env46054 : List Nat := [2,4,8,16,32,64,128,105,60,115,2048,26,25,11,108,65536,65541,65664,51,109,26,181,65614,65547,209,65631,76,65620,11,67667,21,27,105,65614,91,125]

theorem envBound46054 : H12AffineFastState.Bounded env46054 := by
  intro p hp
  have h : env46054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46045_46054 : H12AffineEnvironment.transform 7 105 env46045 = env46054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 105 env46045 == env46054) = true)

theorem identity46054 : scanCanonicalize (H12AffineFastState.compose env46054 (packedSelected [0,8,13,15,24,27] rootPS)) = affineNative (2^(15+1) ^^^ 160) := by decide +kernel

theorem selectedBound46054 : packedSelected [0,8,13,15,24,27] rootPS < 2^1333 := by decide +kernel

def env46055 : List Nat := [2,4,8,16,32,64,128,105,60,115,2048,26,25,11,108,160,165,32,51,109,26,181,238,171,209,255,76,244,11,2291,21,27,105,238,91,125]

theorem envBound46055 : H12AffineFastState.Bounded env46055 := by
  intro p hp
  have h : env46055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46054_46055 : H12AffineEnvironment.transform 15 160 env46054 = env46055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 160 env46054 == env46055) = true)

theorem identity46055 : scanCanonicalize (H12AffineFastState.compose env46055 (packedSelected [2,3,4,5,7,10,11,12,13,15,16,18,20,21,23] rootPS)) = affineNative (2^(10+1) ^^^ 159) := by decide +kernel

theorem selectedBound46055 : packedSelected [2,3,4,5,7,10,11,12,13,15,16,18,20,21,23] rootPS < 2^1333 := by decide +kernel

def env46056 : List Nat := [2,4,8,16,32,64,128,105,60,115,159,26,25,11,108,160,165,32,51,109,26,181,238,171,209,255,76,244,11,108,21,27,105,238,91,125]

theorem envBound46056 : H12AffineFastState.Bounded env46056 := by
  intro p hp
  have h : env46056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46055_46056 : H12AffineEnvironment.transform 10 159 env46055 = env46056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 159 env46055 == env46056) = true)

theorem identity46056 : scanCanonicalize (H12AffineFastState.compose env46056 (packedSelected [3,4,8,9,15,18] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound46056 : packedSelected [3,4,8,9,15,18] rootPS < 2^1333 := by decide +kernel

def env46057 : List Nat := [2,4,8,16,27,64,128,82,7,72,159,26,25,11,87,155,158,27,8,86,26,142,213,144,209,196,76,207,11,87,21,27,82,213,91,70]

theorem envBound46057 : H12AffineFastState.Bounded env46057 := by
  intro p hp
  have h : env46057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46056_46057 : H12AffineEnvironment.transform 4 27 env46056 = env46057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env46056 == env46057) = true)

theorem identity46057 : scanCanonicalize (H12AffineFastState.compose env46057 (packedSelected [0,3,7,8,11] rootPS)) = affineNative (2^(6+1) ^^^ 84) := by decide +kernel

theorem selectedBound46057 : packedSelected [0,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env46058 : List Nat := [2,4,8,16,27,64,84,82,7,72,75,26,25,11,87,79,74,27,8,86,26,90,1,68,5,16,76,27,11,87,21,27,82,1,91,70]

theorem envBound46058 : H12AffineFastState.Bounded env46058 := by
  intro p hp
  have h : env46058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46057_46058 : H12AffineEnvironment.transform 6 84 env46057 = env46058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 84 env46057 == env46058) = true)

theorem identity46058 : scanCanonicalize (H12AffineFastState.compose env46058 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 26) := by decide +kernel

theorem selectedBound46058 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env46059 : List Nat := [2,4,8,16,27,26,14,8,7,18,17,26,25,11,13,21,16,27,8,12,26,0,1,30,5,16,22,27,11,13,21,27,8,1,1,28]

theorem envBound46059 : H12AffineFastState.Bounded env46059 := by
  intro p hp
  have h : env46059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46058_46059 : H12AffineEnvironment.transform 5 26 env46058 = env46059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 26 env46058 == env46059) = true)

theorem identity46059 : scanCanonicalize (H12AffineFastState.compose env46059 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound46059 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env46060 : List Nat := [2,4,8,10,1,0,14,8,7,8,11,0,3,11,13,15,10,1,8,12,0,0,1,4,5,10,12,1,11,13,15,1,8,1,1,6]

theorem envBound46060 : H12AffineFastState.Bounded env46060 := by
  intro p hp
  have h : env46060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46059_46060 : H12AffineEnvironment.transform 3 10 env46059 = env46060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env46059 == env46060) = true)

theorem identity46060 : scanCanonicalize (H12AffineFastState.compose env46060 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound46060 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46061 : List Nat := [2,4,3,1,1,0,5,3,7,3,0,0,3,0,6,4,1,1,3,7,0,0,1,4,5,1,7,1,0,6,4,1,3,1,1,6]

theorem envBound46061 : H12AffineFastState.Bounded env46061 := by
  intro p hp
  have h : env46061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46060_46061 : H12AffineEnvironment.transform 2 3 env46060 = env46061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env46060 == env46061) = true)

theorem identity46061 : scanCanonicalize (H12AffineFastState.compose env46061 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound46061 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46062 : List Nat := [1,4,0,1,1,0,5,0,4,0,0,0,0,0,5,4,1,1,0,4,0,0,1,4,5,1,4,1,0,5,4,1,0,1,1,5]

theorem envBound46062 : H12AffineFastState.Bounded env46062 := by
  intro p hp
  have h : env46062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46061_46062 : H12AffineEnvironment.transform 0 1 env46061 = env46062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env46061 == env46062) = true)

def env46063 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,1281,25,1297,260,65536,66678,65664,1089,261,1281,476,65831,66832,208,65847,1086,66599,1297,67666,21,1281,256,65831,1345,277]

theorem envBound46063 : H12AffineFastState.Bounded env46063 := by
  intro p hp
  have h : env46063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46043_46063 : H12AffineEnvironment.transform 11 1281 env46043 = env46063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env46043 == env46063) = true)

theorem identity46063 : scanCanonicalize (H12AffineFastState.compose env46063 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 99) := by decide +kernel

theorem selectedBound46063 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env46064 : List Nat := [2,4,8,16,32,64,128,99,54,1024,2048,1122,25,1138,103,65536,66678,65664,1089,102,1122,191,65604,66675,208,65620,1086,66599,1138,67666,21,1122,99,65604,1058,118]

theorem envBound46064 : H12AffineFastState.Bounded env46064 := by
  intro p hp
  have h : env46064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46063_46064 : H12AffineEnvironment.transform 7 99 env46063 = env46064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 99 env46063 == env46064) = true)

def env46065 : List Nat := [2,4,8,16,32,64,128,99,54,1024,2048,1122,25,1138,103,84,1058,212,1089,102,1122,191,16,1063,208,0,1086,1139,1138,2054,21,1122,99,16,1058,118]

theorem envBound46065 : H12AffineFastState.Bounded env46065 := by
  intro p hp
  have h : env46065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46064_46065 : H12AffineEnvironment.transform 15 84 env46064 = env46065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 84 env46064 == env46065) = true)

theorem identity46065 : scanCanonicalize (H12AffineFastState.compose env46065 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 35) := by decide +kernel

theorem selectedBound46065 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env46066 : List Nat := [2,4,8,16,32,64,128,99,54,35,2048,65,25,81,103,84,1,212,98,102,65,191,16,4,208,0,29,80,81,2054,21,65,99,16,1,118]

theorem envBound46066 : H12AffineFastState.Bounded env46066 := by
  intro p hp
  have h : env46066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46065_46066 : H12AffineEnvironment.transform 9 35 env46065 = env46066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 35 env46065 == env46066) = true)

theorem identity46066 : scanCanonicalize (H12AffineFastState.compose env46066 (packedSelected [0,1,4,7,8,9,10,12,16,17,20] rootPS)) = affineNative (2^(6+1) ^^^ 47) := by decide +kernel

theorem selectedBound46066 : packedSelected [0,1,4,7,8,9,10,12,16,17,20] rootPS < 2^1333 := by decide +kernel

def env46067 : List Nat := [2,4,8,16,32,64,47,99,54,35,2048,65,25,81,103,84,1,123,98,102,65,16,16,4,127,0,29,80,81,2054,21,65,99,16,1,118]

theorem envBound46067 : H12AffineFastState.Bounded env46067 := by
  intro p hp
  have h : env46067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46066_46067 : H12AffineEnvironment.transform 6 47 env46066 = env46067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 47 env46066 == env46067) = true)

theorem identity46067 : scanCanonicalize (H12AffineFastState.compose env46067 (packedSelected [1,8,10,12,17] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound46067 : packedSelected [1,8,10,12,17] rootPS < 2^1333 := by decide +kernel

def env46068 : List Nat := [2,4,8,1,32,64,47,99,39,35,2048,65,8,64,103,69,1,106,98,102,65,1,1,4,110,0,12,65,64,2054,4,65,99,1,1,103]

theorem envBound46068 : H12AffineFastState.Bounded env46068 := by
  intro p hp
  have h : env46068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46067_46068 : H12AffineEnvironment.transform 3 1 env46067 = env46068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env46067 == env46068) = true)

theorem identity46068 : scanCanonicalize (H12AffineFastState.compose env46068 (packedSelected [3,8] rootPS)) = affineNative (2^(10+1) ^^^ 6) := by decide +kernel

theorem selectedBound46068 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env46069 : List Nat := [2,4,8,1,32,64,47,99,39,35,6,65,8,64,103,69,1,106,98,102,65,1,1,4,110,0,12,65,64,0,4,65,99,1,1,103]

theorem envBound46069 : H12AffineFastState.Bounded env46069 := by
  intro p hp
  have h : env46069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46068_46069 : H12AffineEnvironment.transform 10 6 env46068 = env46069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 6 env46068 == env46069) = true)

theorem identity46069 : scanCanonicalize (H12AffineFastState.compose env46069 (packedSelected [0,1,3,9] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound46069 : packedSelected [0,1,3,9] rootPS < 2^1333 := by decide +kernel

def env46070 : List Nat := [2,4,8,1,32,13,47,46,39,35,6,12,8,13,42,8,1,39,47,43,12,1,1,4,35,0,12,12,13,0,4,12,46,1,1,42]

theorem envBound46070 : H12AffineFastState.Bounded env46070 := by
  intro p hp
  have h : env46070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46069_46070 : H12AffineEnvironment.transform 5 13 env46069 = env46070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env46069 == env46070) = true)

theorem identity46070 : scanCanonicalize (H12AffineFastState.compose env46070 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound46070 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env46071 : List Nat := [2,4,8,1,11,13,4,5,12,8,6,12,8,13,1,8,1,12,4,0,12,1,1,4,8,0,12,12,13,0,4,12,5,1,1,1]

theorem envBound46071 : H12AffineFastState.Bounded env46071 := by
  intro p hp
  have h : env46071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46070_46071 : H12AffineEnvironment.transform 4 11 env46070 = env46071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env46070 == env46071) = true)

theorem identity46071 : scanCanonicalize (H12AffineFastState.compose env46071 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound46071 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46072 : List Nat := [2,3,8,1,11,10,3,2,11,8,1,11,8,10,1,8,1,11,3,0,11,1,1,3,8,0,11,11,10,0,3,11,2,1,1,1]

theorem envBound46072 : H12AffineFastState.Bounded env46072 := by
  intro p hp
  have h : env46072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46071_46072 : H12AffineEnvironment.transform 1 3 env46071 = env46072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env46071 == env46072) = true)

theorem identity46072 : scanCanonicalize (H12AffineFastState.compose env46072 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound46072 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env46073 : List Nat := [2,3,3,1,0,1,3,2,0,3,1,0,3,1,1,3,1,0,3,0,0,1,1,3,3,0,0,0,1,0,3,0,2,1,1,1]

theorem envBound46073 : H12AffineFastState.Bounded env46073 := by
  intro p hp
  have h : env46073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46072_46073 : H12AffineEnvironment.transform 2 3 env46072 = env46073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env46072 == env46073) = true)

theorem identity46073 : scanCanonicalize (H12AffineFastState.compose env46073 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound46073 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46074 : List Nat := [0,1,1,1,0,1,1,0,0,1,1,0,1,1,1,1,1,0,1,0,0,1,1,1,1,0,0,0,1,0,1,0,0,1,1,1]

theorem envBound46074 : H12AffineFastState.Bounded env46074 := by
  intro p hp
  have h : env46074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46073_46074 : H12AffineEnvironment.transform 0 0 env46073 = env46074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env46073 == env46074) = true)

def env46075 : List Nat := [2,4,8,16,32,64,128,99,54,1024,2048,1122,25,1138,103,85,1059,213,1089,102,1122,191,17,1062,208,1,1086,1138,1138,2055,21,1122,99,17,1058,118]

theorem envBound46075 : H12AffineFastState.Bounded env46075 := by
  intro p hp
  have h : env46075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46064_46075 : H12AffineEnvironment.transform 15 85 env46064 = env46075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 85 env46064 == env46075) = true)

theorem identity46075 : scanCanonicalize (H12AffineFastState.compose env46075 (packedSelected [13,21] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound46075 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env46076 : List Nat := [2,4,8,16,23,64,128,84,1,1024,2048,1109,25,1093,80,85,1044,213,1089,81,1109,136,17,1041,208,1,1033,1093,1093,2055,21,1109,84,17,1045,65]

theorem envBound46076 : H12AffineFastState.Bounded env46076 := by
  intro p hp
  have h : env46076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46075_46076 : H12AffineEnvironment.transform 4 23 env46075 = env46076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env46075 == env46076) = true)

theorem identity46076 : scanCanonicalize (H12AffineFastState.compose env46076 (packedSelected [0,5,7,17,20] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound46076 : packedSelected [0,5,7,17,20] rootPS < 2^1333 := by decide +kernel

def env46077 : List Nat := [2,4,8,16,23,64,14,84,1,1024,2048,1109,25,1093,80,85,1044,91,1089,81,1109,6,17,1041,94,1,1033,1093,1093,2055,21,1109,84,17,1045,65]

theorem envBound46077 : H12AffineFastState.Bounded env46077 := by
  intro p hp
  have h : env46077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46076_46077 : H12AffineEnvironment.transform 6 14 env46076 = env46077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env46076 == env46077) = true)

theorem identity46077 : scanCanonicalize (H12AffineFastState.compose env46077 (packedSelected [0,1,2,4,5,7,8,9,11,16] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound46077 : packedSelected [0,1,2,4,5,7,8,9,11,16] rootPS < 2^1333 := by decide +kernel

def env46078 : List Nat := [2,4,8,6,1,64,14,66,1,1024,2048,1091,15,1093,70,67,1026,77,1089,71,1091,6,7,1031,72,1,1033,1093,1093,2055,3,1091,66,7,1027,65]

theorem envBound46078 : H12AffineFastState.Bounded env46078 := by
  intro p hp
  have h : env46078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46077_46078 : H12AffineEnvironment.transform 3 6 env46077 = env46078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env46077 == env46078) = true)

def env46079 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74863,65665,4416,13341,4096,476,74046,69649,13768,78895,4414,74814,1297,81226,8204,1281,256,65831,1345,5953]

theorem envBound46079 : H12AffineFastState.Bounded env46079 := by
  intro p hp
  have h : env46079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46003_46079 : H12AffineEnvironment.transform 17 65665 env46003 = env46079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env46003 == env46079) = true)

theorem identity46079 : scanCanonicalize (H12AffineFastState.compose env46079 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5465) := by decide +kernel

theorem selectedBound46079 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env46080 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5465,1297,325,65536,69942,65665,4416,324,4096,476,70759,69649,145,65910,4414,69991,1297,67603,5461,1281,256,65831,1345,5953]

theorem envBound46080 : H12AffineFastState.Bounded env46080 := by
  intro p hp
  have h : env46080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46079_46080 : H12AffineEnvironment.transform 12 5465 env46079 = env46080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5465 env46079 == env46080) = true)

def env46081 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,4096,5465,1297,325,65536,69942,65665,4416,324,4096,476,70759,69649,145,65910,4414,69991,1297,67603,5461,1281,256,65831,1345,5141]

theorem envBound46081 : H12AffineFastState.Bounded env46081 := by
  intro p hp
  have h : env46081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46080_46081 : H12AffineEnvironment.transform 8 340 env46080 = env46081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env46080 == env46081) = true)

def env46082 : List Nat := [2,4,8,16,32,0,128,256,276,1024,2048,4096,5401,1297,261,65536,69942,65665,4352,260,4096,412,70695,69649,145,65846,4414,69927,1297,67603,5397,1281,256,65831,1281,5141]

theorem envBound46082 : H12AffineFastState.Bounded env46082 := by
  intro p hp
  have h : env46082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46081_46082 : H12AffineEnvironment.transform 5 0 env46081 = env46082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env46081 == env46082) = true)

theorem identity46082 : scanCanonicalize (H12AffineFastState.compose env46082 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 1285) := by decide +kernel

theorem selectedBound46082 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env46083 : List Nat := [2,4,8,16,32,0,128,256,276,1024,2048,4096,5401,1297,261,1285,5171,1412,4352,260,4096,412,4386,5396,145,1075,4414,5154,1297,3350,5397,1281,256,1058,1281,5141]

theorem envBound46083 : H12AffineFastState.Bounded env46083 := by
  intro p hp
  have h : env46083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46082_46083 : H12AffineEnvironment.transform 15 1285 env46082 = env46083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1285 env46082 == env46083) = true)

def env46084 : List Nat := [2,4,8,16,32,0,128,256,276,1024,2048,308,1069,1297,261,1285,1287,1412,52,260,308,412,22,1056,145,1075,10,1302,1297,3350,1057,1281,256,1058,1281,1313]

theorem envBound46084 : H12AffineFastState.Bounded env46084 := by
  intro p hp
  have h : env46084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46083_46084 : H12AffineEnvironment.transform 11 308 env46083 = env46084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env46083 == env46084) = true)

theorem identity46084 : scanCanonicalize (H12AffineFastState.compose env46084 (packedSelected [0,1,3,4,8,9,10,12,16,17,19,21,27,38] rootPS)) = affineNative (2^(9+1) ^^^ 156) := by decide +kernel

theorem selectedBound46084 : packedSelected [0,1,3,4,8,9,10,12,16,17,19,21,27,38] rootPS < 2^1333 := by decide +kernel

def env46085 : List Nat := [2,4,8,16,32,0,128,256,276,156,2048,308,177,397,261,409,411,280,52,260,308,412,22,188,145,175,10,394,397,2442,189,413,256,190,413,445]

theorem envBound46085 : H12AffineFastState.Bounded env46085 := by
  intro p hp
  have h : env46085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46084_46085 : H12AffineEnvironment.transform 9 156 env46084 = env46085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 156 env46084 == env46085) = true)

theorem identity46085 : scanCanonicalize (H12AffineFastState.compose env46085 (packedSelected [1,2,3,4,7,8,9,10,11,16,18,19,20,21,27] rootPS)) = affineNative (2^(10+1) ^^^ 280) := by decide +kernel

theorem selectedBound46085 : packedSelected [1,2,3,4,7,8,9,10,11,16,18,19,20,21,27] rootPS < 2^1333 := by decide +kernel

def env46086 : List Nat := [2,4,8,16,32,0,128,256,276,156,280,308,177,397,261,409,411,280,52,260,308,412,22,188,145,175,10,394,397,146,189,413,256,190,413,445]

theorem envBound46086 : H12AffineFastState.Bounded env46086 := by
  intro p hp
  have h : env46086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46085_46086 : H12AffineEnvironment.transform 10 280 env46085 = env46086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 280 env46085 == env46086) = true)

theorem identity46086 : scanCanonicalize (H12AffineFastState.compose env46086 (packedSelected [7,9,15,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 187) := by decide +kernel

theorem selectedBound46086 : packedSelected [7,9,15,16,18] rootPS < 2^1333 := by decide +kernel

def env46087 : List Nat := [2,4,8,16,32,0,128,187,175,156,163,143,177,54,190,34,32,163,52,191,143,39,22,188,145,175,10,49,54,146,189,38,187,190,38,6]

theorem envBound46087 : H12AffineFastState.Bounded env46087 := by
  intro p hp
  have h : env46087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46086_46087 : H12AffineEnvironment.transform 7 187 env46086 = env46087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 187 env46086 == env46087) = true)

theorem identity46087 : scanCanonicalize (H12AffineFastState.compose env46087 (packedSelected [0,1,2,3,7,8,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 46) := by decide +kernel

theorem selectedBound46087 : packedSelected [0,1,2,3,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env46088 : List Nat := [2,4,8,16,32,0,46,21,1,50,13,33,31,54,16,34,32,13,52,17,33,39,22,18,63,1,10,49,54,60,19,38,21,16,38,6]

theorem envBound46088 : H12AffineFastState.Bounded env46088 := by
  intro p hp
  have h : env46088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46087_46088 : H12AffineEnvironment.transform 6 46 env46087 = env46088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 46 env46087 == env46088) = true)

theorem identity46088 : scanCanonicalize (H12AffineFastState.compose env46088 (packedSelected [1,3,5] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound46088 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env46089 : List Nat := [2,2,8,16,32,0,40,19,1,50,11,33,25,48,16,34,32,11,50,17,33,33,16,18,57,1,10,49,48,58,19,32,19,16,32,0]

theorem envBound46089 : H12AffineFastState.Bounded env46089 := by
  intro p hp
  have h : env46089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46088_46089 : H12AffineEnvironment.transform 1 2 env46088 = env46089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env46088 == env46089) = true)

theorem identity46089 : scanCanonicalize (H12AffineFastState.compose env46089 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound46089 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46090 : List Nat := [2,2,8,1,32,0,40,2,1,35,11,33,8,33,1,34,32,11,35,0,33,33,1,3,40,1,10,32,33,43,2,32,2,1,32,0]

theorem envBound46090 : H12AffineFastState.Bounded env46090 := by
  intro p hp
  have h : env46090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46089_46090 : H12AffineEnvironment.transform 3 1 env46089 = env46090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env46089 == env46090) = true)

def env46091 : List Nat := [2,4,8,16,32,0,128,256,276,1024,2048,309,1068,1297,261,1285,1286,1412,53,260,309,412,23,1057,145,1075,11,1303,1297,3350,1056,1281,256,1058,1281,1312]

theorem envBound46091 : H12AffineFastState.Bounded env46091 := by
  intro p hp
  have h : env46091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46083_46091 : H12AffineEnvironment.transform 11 309 env46083 = env46091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env46083 == env46091) = true)

theorem identity46091 : scanCanonicalize (H12AffineFastState.compose env46091 (packedSelected [0,1,3,4,8,9,10,12,16,17,19,21,27,38] rootPS)) = affineNative (2^(9+1) ^^^ 155) := by decide +kernel

theorem selectedBound46091 : packedSelected [0,1,3,4,8,9,10,12,16,17,19,21,27,38] rootPS < 2^1333 := by decide +kernel

def env46092 : List Nat := [2,4,8,16,32,0,128,256,276,155,2048,309,183,394,261,414,413,287,53,260,309,412,23,186,145,168,11,396,394,2445,187,410,256,185,410,443]

theorem envBound46092 : H12AffineFastState.Bounded env46092 := by
  intro p hp
  have h : env46092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46091_46092 : H12AffineEnvironment.transform 9 155 env46091 = env46092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 155 env46091 == env46092) = true)

theorem identity46092 : scanCanonicalize (H12AffineFastState.compose env46092 (packedSelected [0,1,2,3,7,8,10,11,18,19,20,21] rootPS)) = affineNative (2^(10+1) ^^^ 318) := by decide +kernel

theorem selectedBound46092 : packedSelected [0,1,2,3,7,8,10,11,18,19,20,21] rootPS < 2^1333 := by decide +kernel

def env46093 : List Nat := [2,4,8,16,32,0,128,256,276,155,318,309,183,394,261,414,413,287,53,260,309,412,23,186,145,168,11,396,394,179,187,410,256,185,410,443]

theorem envBound46093 : H12AffineFastState.Bounded env46093 := by
  intro p hp
  have h : env46093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46092_46093 : H12AffineEnvironment.transform 10 318 env46092 = env46093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 318 env46092 == env46093) = true)

theorem identity46093 : scanCanonicalize (H12AffineFastState.compose env46093 (packedSelected [0,9,10,11,15,16,17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound46093 : packedSelected [0,9,10,11,15,16,17] rootPS < 2^1333 := by decide +kernel

def env46094 : List Nat := [2,4,8,16,32,0,8,256,276,19,318,309,63,258,261,278,277,287,53,260,309,276,23,50,25,32,11,260,258,59,51,274,256,49,274,307]

theorem envBound46094 : H12AffineFastState.Bounded env46094 := by
  intro p hp
  have h : env46094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46093_46094 : H12AffineEnvironment.transform 6 8 env46093 = env46094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46093 == env46094) = true)

theorem identity46094 : scanCanonicalize (H12AffineFastState.compose env46094 (packedSelected [1,2,4,5,8,9,11] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound46094 : packedSelected [1,2,4,5,8,9,11] rootPS < 2^1333 := by decide +kernel

def env46095 : List Nat := [2,4,8,16,32,0,8,5,17,19,59,48,63,7,0,19,16,26,53,1,48,17,23,50,25,32,11,1,7,59,51,23,5,49,23,54]

theorem envBound46095 : H12AffineFastState.Bounded env46095 := by
  intro p hp
  have h : env46095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46094_46095 : H12AffineEnvironment.transform 7 5 env46094 = env46095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env46094 == env46095) = true)

theorem identity46095 : scanCanonicalize (H12AffineFastState.compose env46095 (packedSelected [0,2,3,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound46095 : packedSelected [0,2,3,7,8] rootPS < 2^1333 := by decide +kernel

def env46096 : List Nat := [2,4,8,16,7,0,8,5,17,19,28,23,24,7,0,19,16,26,18,1,23,17,23,21,25,7,11,1,7,28,20,23,5,22,23,17]

theorem envBound46096 : H12AffineFastState.Bounded env46096 := by
  intro p hp
  have h : env46096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46095_46096 : H12AffineEnvironment.transform 4 7 env46095 = env46096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env46095 == env46096) = true)

theorem identity46096 : scanCanonicalize (H12AffineFastState.compose env46096 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound46096 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46097 : List Nat := [2,4,8,6,7,0,8,5,7,5,10,1,14,7,0,5,6,12,4,1,1,7,1,3,15,7,11,1,7,10,2,1,5,0,1,7]

theorem envBound46097 : H12AffineFastState.Bounded env46097 := by
  intro p hp
  have h : env46097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46096_46097 : H12AffineEnvironment.transform 3 6 env46096 = env46097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env46096 == env46097) = true)

theorem identity46097 : scanCanonicalize (H12AffineFastState.compose env46097 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound46097 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46098 : List Nat := [2,4,5,6,7,0,5,5,7,5,7,1,3,7,0,5,6,1,4,1,1,7,1,3,2,7,6,1,7,7,2,1,5,0,1,7]

theorem envBound46098 : H12AffineFastState.Bounded env46098 := by
  intro p hp
  have h : env46098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46097_46098 : H12AffineEnvironment.transform 2 5 env46097 = env46098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env46097 == env46098) = true)

def env46099 : List Nat := [2,4,8,16,32,1,128,256,277,1024,2048,4096,5400,1297,260,65536,69942,65665,4353,261,4096,413,70694,69649,145,65847,4414,69926,1297,67603,5396,1281,256,65831,1280,5141]

theorem envBound46099 : H12AffineFastState.Bounded env46099 := by
  intro p hp
  have h : env46099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46081_46099 : H12AffineEnvironment.transform 5 1 env46081 = env46099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env46081 == env46099) = true)

theorem identity46099 : scanCanonicalize (H12AffineFastState.compose env46099 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 5397) := by decide +kernel

theorem selectedBound46099 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env46100 : List Nat := [2,4,8,16,32,1,128,256,277,1024,2048,4096,5400,1297,260,5397,1059,5524,4353,261,4096,413,307,1284,145,5154,4414,1075,1297,7430,5396,1281,256,5170,1280,5141]

theorem envBound46100 : H12AffineFastState.Bounded env46100 := by
  intro p hp
  have h : env46100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46099_46100 : H12AffineEnvironment.transform 15 5397 env46099 = env46100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5397 env46099 == env46100) = true)

def env46101 : List Nat := [2,4,8,16,32,1,128,36,49,1024,2048,4096,5180,1077,32,5169,1059,5296,4133,33,4096,185,23,1056,145,5154,4122,1075,1077,7202,5168,1061,36,5170,1060,5141]

theorem envBound46101 : H12AffineFastState.Bounded env46101 := by
  intro p hp
  have h : env46101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46100_46101 : H12AffineEnvironment.transform 7 36 env46100 = env46101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env46100 == env46101) = true)

theorem identity46101 : scanCanonicalize (H12AffineFastState.compose env46101 (packedSelected [0,1,3,4,7,8,9,10,15,16,19,20,41] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound46101 : packedSelected [0,1,3,4,7,8,9,10,15,16,19,20,41] rootPS < 2^1333 := by decide +kernel

def env46102 : List Nat := [2,4,8,16,32,1,8,36,49,1024,2048,4096,5180,1077,32,5169,1059,5176,4133,33,4096,49,23,1056,25,5154,4122,1075,1077,7202,5168,1061,36,5170,1060,5141]

theorem envBound46102 : H12AffineFastState.Bounded env46102 := by
  intro p hp
  have h : env46102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46101_46102 : H12AffineEnvironment.transform 6 8 env46101 = env46102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46101 == env46102) = true)

theorem identity46102 : scanCanonicalize (H12AffineFastState.compose env46102 (packedSelected [1,2,3,8,10,11,13,16,20,21,23,24] rootPS)) = affineNative (2^(11+1) ^^^ 3129) := by decide +kernel

theorem selectedBound46102 : packedSelected [1,2,3,8,10,11,13,16,20,21,23,24] rootPS < 2^1333 := by decide +kernel

def env46103 : List Nat := [2,4,8,16,32,1,8,36,49,1024,2048,3129,2053,1077,32,2056,1059,2049,3100,33,3129,49,23,1056,25,2075,3107,1075,1077,27,2057,1061,36,2059,1060,2092]

theorem envBound46103 : H12AffineFastState.Bounded env46103 := by
  intro p hp
  have h : env46103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46102_46103 : H12AffineEnvironment.transform 11 3129 env46102 = env46103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3129 env46102 == env46103) = true)

theorem identity46103 : scanCanonicalize (H12AffineFastState.compose env46103 (packedSelected [0,1,3,7,8,10,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 1028) := by decide +kernel

theorem selectedBound46103 : packedSelected [0,1,3,7,8,10,11,13] rootPS < 2^1333 := by decide +kernel

def env46104 : List Nat := [2,4,8,16,32,1,8,36,49,1024,1028,61,1025,1077,32,1036,1059,1029,24,33,61,49,23,1056,25,1055,39,1075,1077,27,1037,1061,36,1039,1060,1064]

theorem envBound46104 : H12AffineFastState.Bounded env46104 := by
  intro p hp
  have h : env46104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46103_46104 : H12AffineEnvironment.transform 10 1028 env46103 = env46104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1028 env46103 == env46104) = true)

theorem identity46104 : scanCanonicalize (H12AffineFastState.compose env46104 (packedSelected [3,4,7,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 63) := by decide +kernel

theorem selectedBound46104 : packedSelected [3,4,7,10,11] rootPS < 2^1333 := by decide +kernel

def env46105 : List Nat := [2,4,8,16,32,1,8,36,49,63,59,61,62,10,32,51,28,58,24,33,61,49,23,31,25,32,39,12,10,27,50,26,36,48,27,23]

theorem envBound46105 : H12AffineFastState.Bounded env46105 := by
  intro p hp
  have h : env46105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46104_46105 : H12AffineEnvironment.transform 9 63 env46104 = env46105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 63 env46104 == env46105) = true)

theorem identity46105 : scanCanonicalize (H12AffineFastState.compose env46105 (packedSelected [2,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound46105 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env46106 : List Nat := [2,4,8,16,12,1,8,8,29,19,23,17,18,10,12,31,28,22,24,13,17,29,23,31,25,12,11,12,10,27,30,26,8,28,27,23]

theorem envBound46106 : H12AffineFastState.Bounded env46106 := by
  intro p hp
  have h : env46106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46105_46106 : H12AffineEnvironment.transform 4 12 env46105 = env46106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env46105 == env46106) = true)

theorem identity46106 : scanCanonicalize (H12AffineFastState.compose env46106 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound46106 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env46107 : List Nat := [2,4,8,6,12,1,8,8,11,5,1,7,4,10,12,9,10,0,14,13,7,11,1,9,15,12,11,12,10,13,8,12,8,10,13,1]

theorem envBound46107 : H12AffineFastState.Bounded env46107 := by
  intro p hp
  have h : env46107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46106_46107 : H12AffineEnvironment.transform 3 6 env46106 = env46107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env46106 == env46107) = true)

theorem identity46107 : scanCanonicalize (H12AffineFastState.compose env46107 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound46107 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46108 : List Nat := [2,4,4,6,0,1,4,4,7,5,1,7,4,6,0,5,6,0,2,1,7,7,1,5,3,0,7,0,6,1,4,0,4,6,1,1]

theorem envBound46108 : H12AffineFastState.Bounded env46108 := by
  intro p hp
  have h : env46108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46107_46108 : H12AffineEnvironment.transform 2 4 env46107 = env46108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env46107 == env46108) = true)

theorem identity46108 : scanCanonicalize (H12AffineFastState.compose env46108 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound46108 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env46109 : List Nat := [2,2,2,0,0,1,2,2,1,3,1,1,2,0,0,3,0,0,2,1,1,1,1,3,3,0,1,0,0,1,2,0,2,0,1,1]

theorem envBound46109 : H12AffineFastState.Bounded env46109 := by
  intro p hp
  have h : env46109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46108_46109 : H12AffineEnvironment.transform 1 2 env46108 = env46109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env46108 == env46109) = true)

def env46110 : List Nat := [2,4,8,16,32,1,128,37,48,1024,2048,4096,5181,1076,33,5168,1059,5297,4132,32,4096,184,22,1057,145,5154,4123,1075,1076,7203,5169,1060,37,5170,1061,5141]

theorem envBound46110 : H12AffineFastState.Bounded env46110 := by
  intro p hp
  have h : env46110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46100_46110 : H12AffineEnvironment.transform 7 37 env46100 = env46110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env46100 == env46110) = true)

theorem identity46110 : scanCanonicalize (H12AffineFastState.compose env46110 (packedSelected [0,1,3,4,7,8,9,10,15,16,19,20,41] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound46110 : packedSelected [0,1,3,4,7,8,9,10,15,16,19,20,41] rootPS < 2^1333 := by decide +kernel

def env46111 : List Nat := [2,4,8,16,32,1,14,37,48,1024,2048,4096,5181,1076,33,5168,1059,5183,4132,32,4096,54,22,1057,31,5154,4123,1075,1076,7203,5169,1060,37,5170,1061,5141]

theorem envBound46111 : H12AffineFastState.Bounded env46111 := by
  intro p hp
  have h : env46111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46110_46111 : H12AffineEnvironment.transform 6 14 env46110 = env46111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env46110 == env46111) = true)

theorem identity46111 : scanCanonicalize (H12AffineFastState.compose env46111 (packedSelected [2,3,10,11,13,18] rootPS)) = affineNative (2^(11+1) ^^^ 3135) := by decide +kernel

theorem selectedBound46111 : packedSelected [2,3,10,11,13,18] rootPS < 2^1333 := by decide +kernel

def env46112 : List Nat := [2,4,8,16,32,1,14,37,48,1024,2048,3135,2050,1076,33,2063,1059,2048,3099,32,3135,54,22,1057,31,2077,3108,1075,1076,28,2062,1060,37,2061,1061,2090]

theorem envBound46112 : H12AffineFastState.Bounded env46112 := by
  intro p hp
  have h : env46112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46111_46112 : H12AffineEnvironment.transform 11 3135 env46111 = env46112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3135 env46111 == env46112) = true)

theorem identity46112 : scanCanonicalize (H12AffineFastState.compose env46112 (packedSelected [0,1,2,3,4,5,10,11,12,13,17] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound46112 : packedSelected [0,1,2,3,4,5,10,11,12,13,17] rootPS < 2^1333 := by decide +kernel

def env46113 : List Nat := [2,4,8,16,17,1,14,20,1,1024,2048,3086,2050,1029,16,2063,1042,2048,3099,17,3086,7,22,1040,31,2077,3093,1026,1029,28,2062,1045,20,2061,1044,2075]

theorem envBound46113 : H12AffineFastState.Bounded env46113 := by
  intro p hp
  have h : env46113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46112_46113 : H12AffineEnvironment.transform 4 17 env46112 = env46113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env46112 == env46113) = true)

theorem identity46113 : scanCanonicalize (H12AffineFastState.compose env46113 (packedSelected [1,3,7,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound46113 : packedSelected [1,3,7,8,9] rootPS < 2^1333 := by decide +kernel

def env46114 : List Nat := [2,4,8,16,17,1,14,20,1,1024,1,1039,3,1029,16,14,1042,1,1050,17,1039,7,22,1040,31,28,1044,1026,1029,28,15,1045,20,12,1044,26]

theorem envBound46114 : H12AffineFastState.Bounded env46114 := by
  intro p hp
  have h : env46114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46113_46114 : H12AffineEnvironment.transform 10 1 env46113 = env46114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env46113 == env46114) = true)

theorem identity46114 : scanCanonicalize (H12AffineFastState.compose env46114 (packedSelected [0,1,2,3,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound46114 : packedSelected [0,1,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env46115 : List Nat := [2,4,8,16,17,1,14,20,1,4,1,11,3,1,16,14,22,1,30,17,11,7,22,20,31,28,16,6,1,28,15,17,20,12,16,26]

theorem envBound46115 : H12AffineFastState.Bounded env46115 := by
  intro p hp
  have h : env46115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46114_46115 : H12AffineEnvironment.transform 9 4 env46114 = env46115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env46114 == env46115) = true)

theorem identity46115 : scanCanonicalize (H12AffineFastState.compose env46115 (packedSelected [1,2] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound46115 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env46116 : List Nat := [2,4,8,6,7,1,14,2,1,4,1,11,3,1,6,14,0,1,8,7,11,7,0,2,9,10,6,6,1,10,15,7,2,12,6,12]

theorem envBound46116 : H12AffineFastState.Bounded env46116 := by
  intro p hp
  have h : env46116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46115_46116 : H12AffineEnvironment.transform 3 6 env46115 = env46116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env46115 == env46116) = true)

def env46117 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,4096,5465,1297,325,65536,69942,65665,4416,324,4096,476,70759,69649,145,65910,4414,69991,1297,67603,5461,1281,256,65831,1345,5140]

theorem envBound46117 : H12AffineFastState.Bounded env46117 := by
  intro p hp
  have h : env46117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46080_46117 : H12AffineEnvironment.transform 8 341 env46080 = env46117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env46080 == env46117) = true)

def env46118 : List Nat := [2,4,8,16,32,0,128,256,277,1024,2048,4096,5401,1297,261,65536,69942,65665,4352,260,4096,412,70695,69649,145,65846,4414,69927,1297,67603,5397,1281,256,65831,1281,5140]

theorem envBound46118 : H12AffineFastState.Bounded env46118 := by
  intro p hp
  have h : env46118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46117_46118 : H12AffineEnvironment.transform 5 0 env46117 = env46118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env46117 == env46118) = true)

theorem identity46118 : scanCanonicalize (H12AffineFastState.compose env46118 (packedSelected [1,8,28] rootPS)) = affineNative (2^(11+1) ^^^ 306) := by decide +kernel

theorem selectedBound46118 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env46119 : List Nat := [2,4,8,16,32,0,128,256,277,1024,2048,306,1067,1297,261,65536,65540,65665,50,260,306,412,66837,65827,145,65846,12,65557,1297,67603,1063,1281,256,65831,1281,1318]

theorem envBound46119 : H12AffineFastState.Bounded env46119 := by
  intro p hp
  have h : env46119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46118_46119 : H12AffineEnvironment.transform 11 306 env46118 = env46119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 306 env46118 == env46119) = true)

def env46120 : List Nat := [2,4,8,16,32,0,128,40,61,1024,2048,26,1067,1081,45,65536,65540,65665,50,44,26,180,66621,65547,145,65566,12,65557,1081,67603,1063,1065,40,65551,1065,1038]

theorem envBound46120 : H12AffineFastState.Bounded env46120 := by
  intro p hp
  have h : env46120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46119_46120 : H12AffineEnvironment.transform 7 40 env46119 = env46120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 40 env46119 == env46120) = true)

theorem identity46120 : scanCanonicalize (H12AffineFastState.compose env46120 (packedSelected [0,8,13,15,24,27] rootPS)) = affineNative (2^(15+1) ^^^ 1177) := by decide +kernel

theorem selectedBound46120 : packedSelected [0,8,13,15,24,27] rootPS < 2^1333 := by decide +kernel

def env46121 : List Nat := [2,4,8,16,32,0,128,40,61,1024,2048,26,1067,1081,45,1177,1181,1048,50,44,26,180,164,1170,145,1159,12,1164,1081,3210,1063,1065,40,1174,1065,1038]

theorem envBound46121 : H12AffineFastState.Bounded env46121 := by
  intro p hp
  have h : env46121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46120_46121 : H12AffineEnvironment.transform 15 1177 env46120 = env46121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1177 env46120 == env46121) = true)

theorem identity46121 : scanCanonicalize (H12AffineFastState.compose env46121 (packedSelected [1,4,8,9,10,11,12,13,15,17,19,20,32] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound46121 : packedSelected [1,4,8,9,10,11,12,13,15,17,19,20,32] rootPS < 2^1333 := by decide +kernel

def env46122 : List Nat := [2,4,8,16,32,0,3,40,61,1024,2048,26,1067,1081,45,1050,1054,1048,50,44,26,55,39,1041,18,1028,12,1039,1081,3081,1063,1065,40,1045,1065,1038]

theorem envBound46122 : H12AffineFastState.Bounded env46122 := by
  intro p hp
  have h : env46122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46121_46122 : H12AffineEnvironment.transform 6 3 env46121 = env46122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env46121 == env46122) = true)

theorem identity46122 : scanCanonicalize (H12AffineFastState.compose env46122 (packedSelected [5,8,10,13,15,17] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound46122 : packedSelected [5,8,10,13,15,17] rootPS < 2^1333 := by decide +kernel

def env46123 : List Nat := [2,4,8,0,32,0,3,40,45,1024,2048,10,1067,1065,45,1034,1038,1032,34,44,10,39,39,1025,2,1028,12,1039,1065,3081,1063,1065,40,1029,1065,1038]

theorem envBound46123 : H12AffineFastState.Bounded env46123 := by
  intro p hp
  have h : env46123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46122_46123 : H12AffineEnvironment.transform 3 0 env46122 = env46123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env46122 == env46123) = true)

theorem identity46123 : scanCanonicalize (H12AffineFastState.compose env46123 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound46123 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env46124 : List Nat := [2,4,8,0,32,0,3,40,45,4,2048,10,47,45,45,14,10,12,34,44,10,39,39,5,2,0,12,11,45,2061,35,45,40,1,45,10]

theorem envBound46124 : H12AffineFastState.Bounded env46124 := by
  intro p hp
  have h : env46124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46123_46124 : H12AffineEnvironment.transform 9 4 env46123 = env46124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env46123 == env46124) = true)

theorem identity46124 : scanCanonicalize (H12AffineFastState.compose env46124 (packedSelected [0,2,9] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound46124 : packedSelected [0,2,9] rootPS < 2^1333 := by decide +kernel

def env46125 : List Nat := [2,4,8,0,32,0,3,40,45,4,1,10,47,45,45,14,10,12,34,44,10,39,39,5,2,0,12,11,45,12,35,45,40,1,45,10]

theorem envBound46125 : H12AffineFastState.Bounded env46125 := by
  intro p hp
  have h : env46125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46124_46125 : H12AffineEnvironment.transform 10 1 env46124 = env46125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env46124 == env46125) = true)

theorem identity46125 : scanCanonicalize (H12AffineFastState.compose env46125 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound46125 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46126 : List Nat := [2,4,8,0,7,0,3,15,10,4,1,10,8,10,10,14,10,12,5,11,10,0,0,5,2,0,12,11,10,12,4,10,15,1,10,10]

theorem envBound46126 : H12AffineFastState.Bounded env46126 := by
  intro p hp
  have h : env46126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46125_46126 : H12AffineEnvironment.transform 4 7 env46125 = env46126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env46125 == env46126) = true)

theorem identity46126 : scanCanonicalize (H12AffineFastState.compose env46126 (packedSelected [1,3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound46126 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env46127 : List Nat := [2,3,8,0,0,0,3,8,10,3,1,10,8,10,10,9,10,11,2,11,10,0,0,2,2,0,11,11,10,11,3,10,8,1,10,10]

theorem envBound46127 : H12AffineFastState.Bounded env46127 := by
  intro p hp
  have h : env46127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46126_46127 : H12AffineEnvironment.transform 1 3 env46126 = env46127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env46126 == env46127) = true)

theorem identity46127 : scanCanonicalize (H12AffineFastState.compose env46127 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound46127 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46128 : List Nat := [2,3,3,0,0,0,3,3,1,3,1,1,3,1,1,2,1,0,2,0,1,0,0,2,2,0,0,0,1,0,3,1,3,1,1,1]

theorem envBound46128 : H12AffineFastState.Bounded env46128 := by
  intro p hp
  have h : env46128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46127_46128 : H12AffineEnvironment.transform 2 3 env46127 = env46128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env46127 == env46128) = true)

def env46129 : List Nat := [2,4,8,16,32,0,128,41,60,1024,2048,27,1067,1080,44,65536,65540,65665,50,45,27,181,66620,65546,145,65567,12,65557,1080,67603,1063,1064,41,65550,1064,1039]

theorem envBound46129 : H12AffineFastState.Bounded env46129 := by
  intro p hp
  have h : env46129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46119_46129 : H12AffineEnvironment.transform 7 41 env46119 = env46129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 41 env46119 == env46129) = true)

theorem identity46129 : scanCanonicalize (H12AffineFastState.compose env46129 (packedSelected [0,8,13,15,24,27] rootPS)) = affineNative (2^(15+1) ^^^ 1170) := by decide +kernel

theorem selectedBound46129 : packedSelected [0,8,13,15,24,27] rootPS < 2^1333 := by decide +kernel

def env46130 : List Nat := [2,4,8,16,32,0,128,41,60,1024,2048,27,1067,1080,44,1170,1174,1043,50,45,27,181,174,1176,145,1165,12,1159,1080,3201,1063,1064,41,1180,1064,1039]

theorem envBound46130 : H12AffineFastState.Bounded env46130 := by
  intro p hp
  have h : env46130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46129_46130 : H12AffineEnvironment.transform 15 1170 env46129 = env46130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1170 env46129 == env46130) = true)

theorem identity46130 : scanCanonicalize (H12AffineFastState.compose env46130 (packedSelected [2,3,4,5,9,11,12,13,15,16,17,18,19,21,24] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound46130 : packedSelected [2,3,4,5,9,11,12,13,15,16,17,18,19,21,24] rootPS < 2^1333 := by decide +kernel

def env46131 : List Nat := [2,4,8,6,32,0,128,41,42,1024,2048,13,1067,1070,44,1156,1152,1029,36,45,13,163,174,1166,135,1165,12,1159,1070,3201,1063,1064,41,1162,1064,1039]

theorem envBound46131 : H12AffineFastState.Bounded env46131 := by
  intro p hp
  have h : env46131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46130_46131 : H12AffineEnvironment.transform 3 6 env46130 = env46131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env46130 == env46131) = true)

theorem identity46131 : scanCanonicalize (H12AffineFastState.compose env46131 (packedSelected [0,1,4,11,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 1153) := by decide +kernel

theorem selectedBound46131 : packedSelected [0,1,4,11,15,17] rootPS < 2^1333 := by decide +kernel

def env46132 : List Nat := [2,4,8,6,32,0,128,41,42,1024,1153,13,1067,1070,44,1156,1152,1029,36,45,13,163,174,1166,135,1165,12,1159,1070,0,1063,1064,41,1162,1064,1039]

theorem envBound46132 : H12AffineFastState.Bounded env46132 := by
  intro p hp
  have h : env46132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46131_46132 : H12AffineEnvironment.transform 10 1153 env46131 = env46132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1153 env46131 == env46132) = true)

theorem identity46132 : scanCanonicalize (H12AffineFastState.compose env46132 (packedSelected [0,2,4,5,7,8,9,10,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 36) := by decide +kernel

theorem selectedBound46132 : packedSelected [0,2,4,5,7,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env46133 : List Nat := [2,4,8,6,32,0,36,41,42,1024,1061,13,1067,1070,44,1056,1060,1029,36,45,13,7,10,1066,35,1065,12,1059,1070,0,1063,1064,41,1070,1064,1039]

theorem envBound46133 : H12AffineFastState.Bounded env46133 := by
  intro p hp
  have h : env46133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46132_46133 : H12AffineEnvironment.transform 6 36 env46132 = env46133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 36 env46132 == env46133) = true)

theorem identity46133 : scanCanonicalize (H12AffineFastState.compose env46133 (packedSelected [0,2,7] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound46133 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env46134 : List Nat := [2,4,8,6,11,0,15,2,1,1024,1038,13,1024,1029,7,1035,1039,1029,15,6,13,7,10,1025,8,1026,12,1032,1029,0,1036,1027,2,1029,1027,1039]

theorem envBound46134 : H12AffineFastState.Bounded env46134 := by
  intro p hp
  have h : env46134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46133_46134 : H12AffineEnvironment.transform 4 11 env46133 = env46134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env46133 == env46134) = true)

theorem identity46134 : scanCanonicalize (H12AffineFastState.compose env46134 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound46134 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env46135 : List Nat := [2,4,8,6,11,0,15,2,1,14,0,13,14,11,7,5,1,11,15,6,13,7,10,15,8,12,12,6,11,0,2,13,2,11,13,1]

theorem envBound46135 : H12AffineFastState.Bounded env46135 := by
  intro p hp
  have h : env46135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46134_46135 : H12AffineEnvironment.transform 9 14 env46134 = env46135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env46134 == env46135) = true)

theorem identity46135 : scanCanonicalize (H12AffineFastState.compose env46135 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound46135 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env46136 : List Nat := [2,4,4,6,7,0,3,2,1,2,0,1,2,7,7,5,1,7,3,6,1,7,6,3,4,0,0,6,7,0,2,1,2,7,1,1]

theorem envBound46136 : H12AffineFastState.Bounded env46136 := by
  intro p hp
  have h : env46136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46135_46136 : H12AffineEnvironment.transform 2 4 env46135 = env46136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env46135 == env46136) = true)

def env46137 : List Nat := [2,4,8,16,32,1,128,256,276,1024,2048,4096,5400,1297,260,65536,69942,65665,4353,261,4096,413,70694,69649,145,65847,4414,69926,1297,67603,5396,1281,256,65831,1280,5140]

theorem envBound46137 : H12AffineFastState.Bounded env46137 := by
  intro p hp
  have h : env46137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46117_46137 : H12AffineEnvironment.transform 5 1 env46117 = env46137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env46117 == env46137) = true)

theorem identity46137 : scanCanonicalize (H12AffineFastState.compose env46137 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 35) := by decide +kernel

theorem selectedBound46137 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env46138 : List Nat := [2,4,8,16,32,1,128,35,55,1024,2048,4096,5179,1074,39,65536,69653,65665,4130,38,4096,190,70694,69649,145,65556,4125,69637,1074,67603,5175,1058,35,65540,1059,5140]

theorem envBound46138 : H12AffineFastState.Bounded env46138 := by
  intro p hp
  have h : env46138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46137_46138 : H12AffineEnvironment.transform 7 35 env46137 = env46138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 35 env46137 == env46138) = true)

def env46139 : List Nat := [2,4,8,16,32,1,128,35,55,1024,2048,4096,5179,1074,39,5168,1061,5297,4130,38,4096,190,22,1057,145,5156,4125,1077,1074,7203,5175,1058,35,5172,1059,5140]

theorem envBound46139 : H12AffineFastState.Bounded env46139 := by
  intro p hp
  have h : env46139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46138_46139 : H12AffineEnvironment.transform 15 5168 env46138 = env46139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5168 env46138 == env46139) = true)

theorem identity46139 : scanCanonicalize (H12AffineFastState.compose env46139 (packedSelected [0,1,3,4,7,8,9,10,15,16,19,20,41] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound46139 : packedSelected [0,1,3,4,7,8,9,10,15,16,19,20,41] rootPS < 2^1333 := by decide +kernel

def env46140 : List Nat := [2,4,8,16,32,1,15,35,55,1024,2048,4096,5179,1074,39,5168,1061,5182,4130,38,4096,49,22,1057,30,5156,4125,1077,1074,7203,5175,1058,35,5172,1059,5140]

theorem envBound46140 : H12AffineFastState.Bounded env46140 := by
  intro p hp
  have h : env46140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46139_46140 : H12AffineEnvironment.transform 6 15 env46139 = env46140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env46139 == env46140) = true)

theorem identity46140 : scanCanonicalize (H12AffineFastState.compose env46140 (packedSelected [0,2,3,7,8,11,12,13,15,19,20,21,23] rootPS)) = affineNative (2^(11+1) ^^^ 3086) := by decide +kernel

theorem selectedBound46140 : packedSelected [0,2,3,7,8,11,12,13,15,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env46141 : List Nat := [2,4,8,16,32,1,15,35,55,1024,2048,3086,2101,1074,39,2110,1061,2096,3116,38,3086,49,22,1057,30,2090,3091,1077,1074,45,2105,1058,35,2106,1059,2074]

theorem envBound46141 : H12AffineFastState.Bounded env46141 := by
  intro p hp
  have h : env46141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46140_46141 : H12AffineEnvironment.transform 11 3086 env46140 = env46141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3086 env46140 == env46141) = true)

theorem identity46141 : scanCanonicalize (H12AffineFastState.compose env46141 (packedSelected [0,4,7,8,9,11,15,16,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound46141 : packedSelected [0,4,7,8,9,11,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env46142 : List Nat := [2,4,8,16,32,1,15,35,55,1024,1077,59,1024,1074,39,1035,1061,1029,25,38,59,49,22,1057,30,1055,38,1077,1074,45,1036,1058,35,1039,1059,1071]

theorem envBound46142 : H12AffineFastState.Bounded env46142 := by
  intro p hp
  have h : env46142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46141_46142 : H12AffineEnvironment.transform 10 1077 env46141 = env46142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env46141 == env46142) = true)

theorem identity46142 : scanCanonicalize (H12AffineFastState.compose env46142 (packedSelected [1,7,9,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 57) := by decide +kernel

theorem selectedBound46142 : packedSelected [1,7,9,10,11] rootPS < 2^1333 := by decide +kernel

def env46143 : List Nat := [2,4,8,16,32,1,15,35,55,57,12,59,57,11,39,50,28,60,25,38,59,49,22,24,30,38,38,12,11,45,53,27,35,54,26,22]

theorem envBound46143 : H12AffineFastState.Bounded env46143 := by
  intro p hp
  have h : env46143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46142_46143 : H12AffineEnvironment.transform 9 57 env46142 = env46143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 57 env46142 == env46143) = true)

theorem identity46143 : scanCanonicalize (H12AffineFastState.compose env46143 (packedSelected [0,1,4] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound46143 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env46144 : List Nat := [2,4,8,16,28,1,15,31,11,5,12,7,5,11,27,14,28,0,25,26,7,13,22,24,30,26,26,12,11,17,9,27,31,10,26,22]

theorem envBound46144 : H12AffineFastState.Bounded env46144 := by
  intro p hp
  have h : env46144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46143_46144 : H12AffineEnvironment.transform 4 28 env46143 = env46144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env46143 == env46144) = true)

theorem identity46144 : scanCanonicalize (H12AffineFastState.compose env46144 (packedSelected [1,2] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound46144 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env46145 : List Nat := [2,4,8,13,1,1,15,2,11,5,12,7,5,11,6,14,1,0,4,7,7,13,11,5,3,7,7,12,11,12,9,6,2,10,7,11]

theorem envBound46145 : H12AffineFastState.Bounded env46145 := by
  intro p hp
  have h : env46145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46144_46145 : H12AffineEnvironment.transform 3 13 env46144 = env46145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env46144 == env46145) = true)

def env46146 : List Nat := [2,4,8,16,32,1,128,35,55,1024,2048,4096,5179,1074,39,5169,1060,5296,4130,38,4096,190,23,1056,145,5157,4125,1076,1074,7202,5175,1058,35,5173,1059,5140]

theorem envBound46146 : H12AffineFastState.Bounded env46146 := by
  intro p hp
  have h : env46146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46138_46146 : H12AffineEnvironment.transform 15 5169 env46138 = env46146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5169 env46138 == env46146) = true)

theorem identity46146 : scanCanonicalize (H12AffineFastState.compose env46146 (packedSelected [0,1,3,4,7,8,9,10,15,16,19,20,41] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound46146 : packedSelected [0,1,3,4,7,8,9,10,15,16,19,20,41] rootPS < 2^1333 := by decide +kernel

def env46147 : List Nat := [2,4,8,16,32,1,9,35,55,1024,2048,4096,5179,1074,39,5169,1060,5177,4130,38,4096,55,23,1056,24,5157,4125,1076,1074,7202,5175,1058,35,5173,1059,5140]

theorem envBound46147 : H12AffineFastState.Bounded env46147 := by
  intro p hp
  have h : env46147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46146_46147 : H12AffineEnvironment.transform 6 9 env46146 = env46147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env46146 == env46147) = true)

theorem identity46147 : scanCanonicalize (H12AffineFastState.compose env46147 (packedSelected [2,3,10,11,13,18] rootPS)) = affineNative (2^(11+1) ^^^ 3128) := by decide +kernel

theorem selectedBound46147 : packedSelected [2,3,10,11,13,18] rootPS < 2^1333 := by decide +kernel

def env46148 : List Nat := [2,4,8,16,32,1,9,35,55,1024,2048,3128,2051,1074,39,2057,1060,2049,3098,38,3128,55,23,1056,24,2077,3109,1076,1074,26,2063,1058,35,2061,1059,2092]

theorem envBound46148 : H12AffineFastState.Bounded env46148 := by
  intro p hp
  have h : env46148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46147_46148 : H12AffineEnvironment.transform 11 3128 env46147 = env46148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3128 env46147 == env46148) = true)

theorem identity46148 : scanCanonicalize (H12AffineFastState.compose env46148 (packedSelected [1,2,3,8,10,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 1026) := by decide +kernel

theorem selectedBound46148 : packedSelected [1,2,3,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env46149 : List Nat := [2,4,8,16,32,1,9,35,55,1024,1026,58,1025,1074,39,1035,1060,1027,24,38,58,55,23,1056,24,1055,39,1076,1074,26,1037,1058,35,1039,1059,1070]

theorem envBound46149 : H12AffineFastState.Bounded env46149 := by
  intro p hp
  have h : env46149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46148_46149 : H12AffineEnvironment.transform 10 1026 env46148 = env46149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1026 env46148 == env46149) = true)

theorem identity46149 : scanCanonicalize (H12AffineFastState.compose env46149 (packedSelected [3,4,7,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 62) := by decide +kernel

theorem selectedBound46149 : packedSelected [3,4,7,10,11] rootPS < 2^1333 := by decide +kernel

def env46150 : List Nat := [2,4,8,16,32,1,9,35,55,62,60,58,63,12,39,53,26,61,24,38,58,55,23,30,24,33,39,10,12,26,51,28,35,49,29,16]

theorem envBound46150 : H12AffineFastState.Bounded env46150 := by
  intro p hp
  have h : env46150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46149_46150 : H12AffineEnvironment.transform 9 62 env46149 = env46150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 62 env46149 == env46150) = true)

theorem identity46150 : scanCanonicalize (H12AffineFastState.compose env46150 (packedSelected [1,2,3,4,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound46150 : packedSelected [1,2,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env46151 : List Nat := [2,4,8,16,26,1,9,25,13,4,6,0,5,12,29,15,26,7,24,28,0,13,23,30,24,27,29,10,12,26,9,28,25,11,29,16]

theorem envBound46151 : H12AffineFastState.Bounded env46151 := by
  intro p hp
  have h : env46151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46150_46151 : H12AffineEnvironment.transform 4 26 env46150 = env46151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env46150 == env46151) = true)

theorem identity46151 : scanCanonicalize (H12AffineFastState.compose env46151 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound46151 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46152 : List Nat := [2,4,8,6,12,1,9,15,13,4,6,0,5,12,11,15,12,7,14,10,0,13,1,8,14,13,11,10,12,12,9,10,15,11,11,6]

theorem envBound46152 : H12AffineFastState.Bounded env46152 := by
  intro p hp
  have h : env46152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46151_46152 : H12AffineEnvironment.transform 3 6 env46151 = env46152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env46151 == env46152) = true)

theorem identity46152 : scanCanonicalize (H12AffineFastState.compose env46152 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound46152 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46153 : List Nat := [2,4,2,6,6,1,3,5,7,4,6,0,5,6,1,5,6,7,4,0,0,7,1,2,4,7,1,0,6,6,3,0,5,1,1,6]

theorem envBound46153 : H12AffineFastState.Bounded env46153 := by
  intro p hp
  have h : env46153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46152_46153 : H12AffineEnvironment.transform 2 2 env46152 = env46153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env46152 == env46153) = true)

theorem identity46153 : scanCanonicalize (H12AffineFastState.compose env46153 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound46153 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46154 : List Nat := [2,1,2,3,3,1,3,0,2,1,3,0,0,3,1,0,3,2,1,0,0,2,1,2,1,2,1,0,3,3,3,0,0,1,1,3]

theorem envBound46154 : H12AffineFastState.Bounded env46154 := by
  intro p hp
  have h : env46154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46153_46154 : H12AffineEnvironment.transform 1 1 env46153 = env46154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env46153 == env46154) = true)

theorem identity46154 : scanCanonicalize (H12AffineFastState.compose env46154 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound46154 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env46155 : List Nat := [1,1,1,0,0,1,0,0,1,1,0,0,0,0,1,0,0,1,1,0,0,1,1,1,1,1,1,0,0,0,0,0,0,1,1,0]

theorem envBound46155 : H12AffineFastState.Bounded env46155 := by
  intro p hp
  have h : env46155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46154_46155 : H12AffineEnvironment.transform 0 1 env46154 = env46155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env46154 == env46155) = true)

def env46156 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,524288,32769,4096,61649,91183,123165,533640,614526,385203,90415,545088,96347,25884,545104,256,82999,1345,525825]

theorem envBound46156 : H12AffineFastState.Bounded env46156 := by
  intro p hp
  have h : env46156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45528_46156 : H12AffineEnvironment.transform 23 123165 env45528 = env46156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123165 env45528 == env46156) = true)

def env46157 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21584,32769,4096,61649,91183,123165,28888,78894,385203,90415,1296,96347,25884,1280,256,82999,1345,21073]

theorem envBound46157 : H12AffineFastState.Bounded env46157 := by
  intro p hp
  have h : env46157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46156_46157 : H12AffineEnvironment.transform 18 21584 env46156 = env46157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env46156 == env46157) = true)

theorem identity46157 : scanCanonicalize (H12AffineFastState.compose env46157 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25676) := by decide +kernel

theorem selectedBound46157 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env46158 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25676,65536,74863,262144,21584,25677,4096,5277,91183,66897,28888,78894,328959,90415,1296,96347,25884,1280,256,82999,1345,21073]

theorem envBound46158 : H12AffineFastState.Bounded env46158 := by
  intro p hp
  have h : env46158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46157_46158 : H12AffineEnvironment.transform 14 25676 env46157 = env46158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25676 env46157 == env46158) = true)

def env46159 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74863,262144,4416,8541,4096,5277,74047,66897,13768,78894,328959,74815,1296,81227,8204,1280,256,65831,1345,5953]

theorem envBound46159 : H12AffineFastState.Bounded env46159 := by
  intro p hp
  have h : env46159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46158_46159 : H12AffineEnvironment.transform 13 1296 env46158 = env46159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env46158 == env46159) = true)

def env46160 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74863,65664,4416,8541,4096,5277,74047,66897,13768,78894,1151,74815,1296,81227,8204,1280,256,65831,1345,5953]

theorem envBound46160 : H12AffineFastState.Bounded env46160 := by
  intro p hp
  have h : env46160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46159_46160 : H12AffineEnvironment.transform 17 65664 env46159 = env46160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env46159 == env46160) = true)

theorem identity46160 : scanCanonicalize (H12AffineFastState.compose env46160 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12670) := by decide +kernel

theorem selectedBound46160 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env46161 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,12670,5393,12798,4416,8541,4096,5277,4161,13359,13768,1360,1151,5441,1296,3125,8204,1280,256,12377,1345,5953]

theorem envBound46161 : H12AffineFastState.Bounded env46161 := by
  intro p hp
  have h : env46161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46160_46161 : H12AffineEnvironment.transform 15 12670 env46160 = env46161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12670 env46160 == env46161) = true)

def env46162 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1296,8540,8494,1345,8622,272,8541,80,1229,17,9343,9624,1360,1151,1297,1296,3125,8204,1280,256,8201,1345,1809]

theorem envBound46162 : H12AffineFastState.Bounded env46162 := by
  intro p hp
  have h : env46162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46161_46162 : H12AffineEnvironment.transform 11 80 env46161 = env46162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env46161 == env46162) = true)

theorem identity46162 : scanCanonicalize (H12AffineFastState.compose env46162 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound46162 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env46163 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,269,1296,81,35,1345,163,272,80,80,1229,17,1394,1173,1360,1151,1297,1296,3125,257,1280,256,260,1345,1809]

theorem envBound46163 : H12AffineFastState.Bounded env46163 := by
  intro p hp
  have h : env46163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46162_46163 : H12AffineEnvironment.transform 12 269 env46162 = env46163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env46162 == env46163) = true)

theorem identity46163 : scanCanonicalize (H12AffineFastState.compose env46163 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound46163 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env46164 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,80,269,1,81,35,80,163,272,80,80,476,17,99,388,65,366,0,1,2340,257,17,256,260,80,512]

theorem envBound46164 : H12AffineFastState.Bounded env46164 := by
  intro p hp
  have h : env46164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46163_46164 : H12AffineEnvironment.transform 9 273 env46163 = env46164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env46163 == env46164) = true)

theorem identity46164 : scanCanonicalize (H12AffineFastState.compose env46164 (packedSelected [2,5,8,13] rootPS)) = affineNative (2^(10+1) ^^^ 318) := by decide +kernel

theorem selectedBound46164 : packedSelected [2,5,8,13] rootPS < 2^1333 := by decide +kernel

def env46165 : List Nat := [2,4,8,16,32,64,128,256,512,273,318,80,269,1,81,35,80,163,272,80,80,476,17,99,388,65,366,0,1,26,257,17,256,260,80,512]

theorem envBound46165 : H12AffineFastState.Bounded env46165 := by
  intro p hp
  have h : env46165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46164_46165 : H12AffineEnvironment.transform 10 318 env46164 = env46165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 318 env46164 == env46165) = true)

theorem identity46165 : scanCanonicalize (H12AffineFastState.compose env46165 (packedSelected [1,2,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound46165 : packedSelected [1,2,8,10] rootPS < 2^1333 := by decide +kernel

def env46166 : List Nat := [2,4,8,16,32,64,128,68,512,85,122,80,73,1,81,35,80,163,84,80,80,152,17,99,192,65,42,0,1,26,69,17,68,64,80,512]

theorem envBound46166 : H12AffineFastState.Bounded env46166 := by
  intro p hp
  have h : env46166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46165_46166 : H12AffineEnvironment.transform 7 68 env46165 = env46166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env46165 == env46166) = true)

theorem identity46166 : scanCanonicalize (H12AffineFastState.compose env46166 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound46166 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env46167 : List Nat := [2,4,8,16,32,64,128,68,0,85,122,80,73,1,81,35,80,163,84,80,80,152,17,99,192,65,42,0,1,26,69,17,68,64,80,0]

theorem envBound46167 : H12AffineFastState.Bounded env46167 := by
  intro p hp
  have h : env46167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46166_46167 : H12AffineEnvironment.transform 8 0 env46166 = env46167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env46166 == env46167) = true)

theorem identity46167 : scanCanonicalize (H12AffineFastState.compose env46167 (packedSelected [2,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound46167 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env46168 : List Nat := [2,4,8,16,32,64,89,68,0,85,122,80,73,1,81,35,80,122,84,80,80,65,17,99,25,65,42,0,1,26,69,17,68,64,80,0]

theorem envBound46168 : H12AffineFastState.Bounded env46168 := by
  intro p hp
  have h : env46168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46167_46168 : H12AffineEnvironment.transform 6 89 env46167 = env46168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env46167 == env46168) = true)

theorem identity46168 : scanCanonicalize (H12AffineFastState.compose env46168 (packedSelected [4,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound46168 : packedSelected [4,5] rootPS < 2^1333 := by decide +kernel

def env46169 : List Nat := [2,4,8,10,32,64,67,68,0,79,96,74,73,1,75,35,74,96,78,74,74,65,11,99,3,65,42,0,1,0,69,11,68,64,74,0]

theorem envBound46169 : H12AffineFastState.Bounded env46169 := by
  intro p hp
  have h : env46169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46168_46169 : H12AffineEnvironment.transform 3 10 env46168 = env46169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env46168 == env46169) = true)

theorem identity46169 : scanCanonicalize (H12AffineFastState.compose env46169 (packedSelected [0,1,2] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound46169 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env46170 : List Nat := [2,4,8,10,32,10,9,14,0,5,42,0,3,1,1,35,0,42,4,0,0,11,11,41,3,11,42,0,1,0,15,11,14,10,0,0]

theorem envBound46170 : H12AffineFastState.Bounded env46170 := by
  intro p hp
  have h : env46170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46169_46170 : H12AffineEnvironment.transform 5 10 env46169 = env46170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env46169 == env46170) = true)

theorem identity46170 : scanCanonicalize (H12AffineFastState.compose env46170 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound46170 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46171 : List Nat := [2,3,8,10,32,10,9,9,0,2,42,0,3,1,1,35,0,42,3,0,0,11,11,41,3,11,42,0,1,0,8,11,9,10,0,0]

theorem envBound46171 : H12AffineFastState.Bounded env46171 := by
  intro p hp
  have h : env46171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46170_46171 : H12AffineEnvironment.transform 1 3 env46170 = env46171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env46170 == env46171) = true)

theorem identity46171 : scanCanonicalize (H12AffineFastState.compose env46171 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound46171 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46172 : List Nat := [2,3,8,10,11,10,9,9,0,2,1,0,3,1,1,8,0,1,3,0,0,11,11,2,3,11,1,0,1,0,8,11,9,10,0,0]

theorem envBound46172 : H12AffineFastState.Bounded env46172 := by
  intro p hp
  have h : env46172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46171_46172 : H12AffineEnvironment.transform 4 11 env46171 = env46172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env46171 == env46172) = true)

def env46173 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1296,8540,8495,1344,8623,273,8541,81,1228,16,9342,9625,1360,1151,1296,1296,3125,8204,1280,256,8200,1345,1808]

theorem envBound46173 : H12AffineFastState.Bounded env46173 := by
  intro p hp
  have h : env46173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46161_46173 : H12AffineEnvironment.transform 11 81 env46161 = env46173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env46161 == env46173) = true)

theorem identity46173 : scanCanonicalize (H12AffineFastState.compose env46173 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 1368) := by decide +kernel

theorem selectedBound46173 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env46174 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,1368,1296,1028,1143,1344,1271,273,1029,81,1228,16,294,193,1360,1151,1296,1296,3125,1364,1280,256,1360,1345,1808]

theorem envBound46174 : H12AffineFastState.Bounded env46174 := by
  intro p hp
  have h : env46174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46173_46174 : H12AffineEnvironment.transform 12 1368 env46173 = env46174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1368 env46173 == env46174) = true)

theorem identity46174 : scanCanonicalize (H12AffineFastState.compose env46174 (packedSelected [0,2,3,5,7,10,11,12,15,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 2018) := by decide +kernel

theorem selectedBound46174 : packedSelected [0,2,3,5,7,10,11,12,15,17,18,20] rootPS < 2^1333 := by decide +kernel

def env46175 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2018,81,1368,1296,1028,1143,1344,1271,273,1029,81,1228,16,294,193,1360,1151,1296,1296,983,1364,1280,256,1360,1345,1808]

end H12CloudChart2