import H12CloudChart2Data174

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans43839_43840 : H12AffineEnvironment.transform 10 136 env43839 = env43840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env43839 == env43840) = true)

theorem identity43840 : scanCanonicalize (H12AffineFastState.compose env43840 (packedSelected [0,1,2,3,5,7,8,10] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound43840 : packedSelected [0,1,2,3,5,7,8,10] rootPS < 2^1333 := by decide +kernel

def env43841 : List Nat := [2,4,8,16,32,64,19,68,123,4,27,80,25,81,1,115,1,97,84,0,80,91,17,98,83,17,123,80,80,43,21,17,69,65,1,43]

theorem envBound43841 : H12AffineFastState.Bounded env43841 := by
  intro p hp
  have h : env43841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43840_43841 : H12AffineEnvironment.transform 6 19 env43840 = env43841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env43840 == env43841) = true)

theorem identity43841 : scanCanonicalize (H12AffineFastState.compose env43841 (packedSelected [2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound43841 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env43842 : List Nat := [2,4,8,16,16,64,19,68,75,4,27,80,25,81,1,67,1,81,84,0,80,91,17,82,83,17,75,80,80,27,21,17,69,65,1,27]

theorem envBound43842 : H12AffineFastState.Bounded env43842 := by
  intro p hp
  have h : env43842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43841_43842 : H12AffineEnvironment.transform 4 16 env43841 = env43842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env43841 == env43842) = true)

theorem identity43842 : scanCanonicalize (H12AffineFastState.compose env43842 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound43842 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43843 : List Nat := [2,4,8,16,16,16,19,20,27,4,27,0,25,1,1,19,1,1,4,0,0,11,17,2,3,17,27,0,0,27,21,17,21,17,1,27]

theorem envBound43843 : H12AffineFastState.Bounded env43843 := by
  intro p hp
  have h : env43843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43842_43843 : H12AffineEnvironment.transform 5 16 env43842 = env43843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43842 == env43843) = true)

theorem identity43843 : scanCanonicalize (H12AffineFastState.compose env43843 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound43843 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43844 : List Nat := [2,4,4,16,16,16,19,20,23,4,23,0,21,1,1,19,1,1,4,0,0,7,17,2,3,17,23,0,0,23,21,17,21,17,1,23]

theorem envBound43844 : H12AffineFastState.Bounded env43844 := by
  intro p hp
  have h : env43844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43843_43844 : H12AffineEnvironment.transform 2 4 env43843 = env43844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env43843 == env43844) = true)

theorem identity43844 : scanCanonicalize (H12AffineFastState.compose env43844 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound43844 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43845 : List Nat := [2,4,4,6,6,6,5,2,1,4,1,0,3,1,1,5,1,1,4,0,0,7,7,2,3,7,1,0,0,1,3,7,3,7,1,1]

theorem envBound43845 : H12AffineFastState.Bounded env43845 := by
  intro p hp
  have h : env43845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43844_43845 : H12AffineEnvironment.transform 3 6 env43844 = env43845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env43844 == env43845) = true)

def env43846 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,80,8192,80,8540,65536,74030,65665,272,8541,80,397,74047,65552,8408,74046,318,74111,81,75867,8204,8200,257,74094,0,593]

theorem envBound43846 : H12AffineFastState.Bounded env43846 := by
  intro p hp
  have h : env43846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43834_43846 : H12AffineEnvironment.transform 9 321 env43834 = env43846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env43834 == env43846) = true)

theorem identity43846 : scanCanonicalize (H12AffineFastState.compose env43846 (packedSelected [7,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound43846 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env43847 : List Nat := [2,4,8,16,32,64,128,21,512,84,2048,80,8192,80,8265,65536,73787,65665,5,8264,80,152,73770,65552,8408,73771,43,73834,81,75867,8204,8200,20,73851,0,593]

theorem envBound43847 : H12AffineFastState.Bounded env43847 := by
  intro p hp
  have h : env43847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43846_43847 : H12AffineEnvironment.transform 7 21 env43846 = env43847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env43846 == env43847) = true)

theorem identity43847 : scanCanonicalize (H12AffineFastState.compose env43847 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 8299) := by decide +kernel

theorem selectedBound43847 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env43848 : List Nat := [2,4,8,16,32,64,128,21,512,84,2048,80,8192,80,8265,8299,80,8426,5,8264,80,152,65,8315,8408,64,43,1,81,2096,8204,8200,20,16,0,593]

theorem envBound43848 : H12AffineFastState.Bounded env43848 := by
  intro p hp
  have h : env43848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43847_43848 : H12AffineEnvironment.transform 15 8299 env43847 = env43848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8299 env43847 == env43848) = true)

theorem identity43848 : scanCanonicalize (H12AffineFastState.compose env43848 (packedSelected [10,13,17,19] rootPS)) = affineNative (2^(12+1) ^^^ 187) := by decide +kernel

theorem selectedBound43848 : packedSelected [10,13,17,19] rootPS < 2^1333 := by decide +kernel

def env43849 : List Nat := [2,4,8,16,32,64,128,21,512,84,2048,80,187,80,242,208,80,81,5,243,80,152,65,192,99,64,43,1,81,2096,183,179,20,16,0,593]

theorem envBound43849 : H12AffineFastState.Bounded env43849 := by
  intro p hp
  have h : env43849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43848_43849 : H12AffineEnvironment.transform 12 187 env43848 = env43849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 187 env43848 == env43849) = true)

theorem identity43849 : scanCanonicalize (H12AffineFastState.compose env43849 (packedSelected [1,2,3,13] rootPS)) = affineNative (2^(10+1) ^^^ 97) := by decide +kernel

theorem selectedBound43849 : packedSelected [1,2,3,13] rootPS < 2^1333 := by decide +kernel

def env43850 : List Nat := [2,4,8,16,32,64,128,21,512,84,97,80,187,80,242,208,80,81,5,243,80,152,65,192,99,64,43,1,81,81,183,179,20,16,0,593]

theorem envBound43850 : H12AffineFastState.Bounded env43850 := by
  intro p hp
  have h : env43850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43849_43850 : H12AffineEnvironment.transform 10 97 env43849 = env43850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 97 env43849 == env43850) = true)

theorem identity43850 : scanCanonicalize (H12AffineFastState.compose env43850 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound43850 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env43851 : List Nat := [2,4,8,16,32,64,128,21,42,84,97,80,187,80,242,208,80,81,5,243,80,152,65,192,99,64,43,1,81,81,183,179,20,16,0,123]

theorem envBound43851 : H12AffineFastState.Bounded env43851 := by
  intro p hp
  have h : env43851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43850_43851 : H12AffineEnvironment.transform 8 42 env43850 = env43851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env43850 == env43851) = true)

def env43852 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,524288,32769,4096,61649,91182,123165,533641,614526,385202,90415,545089,96347,25884,25880,257,618622,1345,525824]

theorem envBound43852 : H12AffineFastState.Bounded env43852 := by
  intro p hp
  have h : env43852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43385_43852 : H12AffineEnvironment.transform 23 123165 env43385 = env43852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123165 env43385 == env43852) = true)

def env43853 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21584,32769,4096,61649,91182,123165,28889,78894,385202,90415,1297,96347,25884,25880,257,74798,1345,21072]

theorem envBound43853 : H12AffineFastState.Bounded env43853 := by
  intro p hp
  have h : env43853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43852_43853 : H12AffineEnvironment.transform 18 21584 env43852 = env43853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env43852 == env43853) = true)

theorem identity43853 : scanCanonicalize (H12AffineFastState.compose env43853 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound43853 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env43854 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13341,65536,74863,262144,21584,13340,4096,17612,91182,87296,28889,78894,349359,90415,1297,96347,25884,25880,257,74798,1345,21072]

theorem envBound43854 : H12AffineFastState.Bounded env43854 := by
  intro p hp
  have h : env43854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43853_43854 : H12AffineEnvironment.transform 14 13341 env43853 = env43854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env43853 == env43854) = true)

def env43855 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74863,262144,4416,13340,4096,476,74046,69648,13769,78894,332223,74815,1297,81227,8204,8200,257,74798,1345,5952]

theorem envBound43855 : H12AffineFastState.Bounded env43855 := by
  intro p hp
  have h : env43855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43854_43855 : H12AffineEnvironment.transform 13 1296 env43854 = env43855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env43854 == env43855) = true)

def env43856 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74863,65664,4416,13340,4096,476,74046,69648,13769,78894,4415,74815,1297,81227,8204,8200,257,74798,1345,5952]

theorem envBound43856 : H12AffineFastState.Bounded env43856 := by
  intro p hp
  have h : env43856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43855_43856 : H12AffineEnvironment.transform 17 65664 env43855 = env43856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env43855 == env43856) = true)

theorem identity43856 : scanCanonicalize (H12AffineFastState.compose env43856 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5238) := by decide +kernel

theorem selectedBound43856 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env43857 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,5238,12313,5366,4416,13340,4096,476,13640,1126,13769,8280,4415,12361,1297,10557,8204,8200,257,12376,1345,5952]

theorem envBound43857 : H12AffineFastState.Bounded env43857 := by
  intro p hp
  have h : env43857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43856_43857 : H12AffineEnvironment.transform 15 5238 env43856 = env43857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5238 env43856 == env43857) = true)

def env43858 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5464,1296,325,5238,1345,5366,4416,324,4096,476,16,1126,145,5376,4415,1297,1297,7269,5460,5456,257,1280,1345,5952]

theorem envBound43858 : H12AffineFastState.Bounded env43858 := by
  intro p hp
  have h : env43858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43857_43858 : H12AffineEnvironment.transform 12 5464 env43857 = env43858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5464 env43857 == env43858) = true)

theorem identity43858 : scanCanonicalize (H12AffineFastState.compose env43858 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 324) := by decide +kernel

theorem selectedBound43858 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env43859 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,324,1052,1296,325,1330,1345,1458,4,324,324,476,16,1126,145,1092,123,1297,1297,3361,1040,1044,257,1280,1345,1540]

theorem envBound43859 : H12AffineFastState.Bounded env43859 := by
  intro p hp
  have h : env43859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43858_43859 : H12AffineEnvironment.transform 11 324 env43858 = env43859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 324 env43858 == env43859) = true)

theorem identity43859 : scanCanonicalize (H12AffineFastState.compose env43859 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound43859 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env43860 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,324,24,276,325,310,325,438,4,324,324,476,16,98,145,64,123,277,277,2341,20,16,257,260,325,512]

theorem envBound43860 : H12AffineFastState.Bounded env43860 := by
  intro p hp
  have h : env43860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43859_43860 : H12AffineEnvironment.transform 9 4 env43859 = env43860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env43859 == env43860) = true)

theorem identity43860 : scanCanonicalize (H12AffineFastState.compose env43860 (packedSelected [2,5,8,13] rootPS)) = affineNative (2^(10+1) ^^^ 367) := by decide +kernel

theorem selectedBound43860 : packedSelected [2,5,8,13] rootPS < 2^1333 := by decide +kernel

def env43861 : List Nat := [2,4,8,16,32,64,128,256,512,4,367,324,24,276,325,310,325,438,4,324,324,476,16,98,145,64,123,277,277,74,20,16,257,260,325,512]

theorem envBound43861 : H12AffineFastState.Bounded env43861 := by
  intro p hp
  have h : env43861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43860_43861 : H12AffineEnvironment.transform 10 367 env43860 = env43861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 367 env43860 == env43861) = true)

theorem identity43861 : scanCanonicalize (H12AffineFastState.compose env43861 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(8+1) ^^^ 97) := by decide +kernel

theorem selectedBound43861 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env43862 : List Nat := [2,4,8,16,32,64,128,256,97,4,367,324,24,276,325,310,325,438,4,324,324,476,16,98,145,64,123,277,277,74,20,16,257,260,325,97]

theorem envBound43862 : H12AffineFastState.Bounded env43862 := by
  intro p hp
  have h : env43862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43861_43862 : H12AffineEnvironment.transform 8 97 env43861 = env43862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env43861 == env43862) = true)

theorem identity43862 : scanCanonicalize (H12AffineFastState.compose env43862 (packedSelected [4,9,10,11,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound43862 : packedSelected [4,9,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env43863 : List Nat := [2,4,8,16,32,17,128,256,48,4,318,277,24,276,276,310,276,438,4,277,277,397,16,51,145,17,42,277,277,27,20,16,257,260,276,48]

theorem envBound43863 : H12AffineFastState.Bounded env43863 := by
  intro p hp
  have h : env43863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43862_43863 : H12AffineEnvironment.transform 5 17 env43862 = env43863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43862 == env43863) = true)

theorem identity43863 : scanCanonicalize (H12AffineFastState.compose env43863 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound43863 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43864 : List Nat := [2,4,8,16,32,17,128,62,48,4,0,43,24,42,42,8,42,136,4,43,43,179,16,51,145,17,42,43,43,27,20,16,63,58,42,48]

theorem envBound43864 : H12AffineFastState.Bounded env43864 := by
  intro p hp
  have h : env43864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43863_43864 : H12AffineEnvironment.transform 7 62 env43863 = env43864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env43863 == env43864) = true)

theorem identity43864 : scanCanonicalize (H12AffineFastState.compose env43864 (packedSelected [0,1,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound43864 : packedSelected [0,1,3,5] rootPS < 2^1333 := by decide +kernel

def env43865 : List Nat := [2,4,8,16,32,17,57,62,48,4,0,43,24,42,42,8,42,49,4,43,43,10,16,51,40,17,42,43,43,27,20,16,63,58,42,48]

theorem envBound43865 : H12AffineFastState.Bounded env43865 := by
  intro p hp
  have h : env43865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43864_43865 : H12AffineEnvironment.transform 6 57 env43864 = env43865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env43864 == env43865) = true)

theorem identity43865 : scanCanonicalize (H12AffineFastState.compose env43865 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound43865 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env43866 : List Nat := [2,4,8,11,32,10,34,37,43,4,0,43,3,42,42,8,42,42,4,43,43,10,11,40,40,10,42,43,43,0,15,11,36,33,42,43]

theorem envBound43866 : H12AffineFastState.Bounded env43866 := by
  intro p hp
  have h : env43866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43865_43866 : H12AffineEnvironment.transform 3 11 env43865 = env43866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env43865 == env43866) = true)

def env43867 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5465,1296,324,5238,1344,5366,4416,325,4096,476,17,1126,144,5377,4415,1296,1297,7268,5461,5457,257,1281,1345,5952]

theorem envBound43867 : H12AffineFastState.Bounded env43867 := by
  intro p hp
  have h : env43867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43857_43867 : H12AffineEnvironment.transform 12 5465 env43857 = env43867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5465 env43857 == env43867) = true)

theorem identity43867 : scanCanonicalize (H12AffineFastState.compose env43867 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound43867 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env43868 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,1369,1296,324,1142,1344,1270,320,325,0,476,17,1126,144,1281,319,1296,1297,3172,1365,1361,257,1281,1345,1856]

theorem envBound43868 : H12AffineFastState.Bounded env43868 := by
  intro p hp
  have h : env43868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43867_43868 : H12AffineEnvironment.transform 11 0 env43867 = env43868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env43867 == env43868) = true)

theorem identity43868 : scanCanonicalize (H12AffineFastState.compose env43868 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(9+1) ^^^ 236) := by decide +kernel

theorem selectedBound43868 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env43869 : List Nat := [2,4,8,16,32,64,128,256,512,236,2048,0,437,508,324,154,428,26,320,325,0,476,17,138,144,493,319,508,509,2184,441,445,257,493,429,940]

theorem envBound43869 : H12AffineFastState.Bounded env43869 := by
  intro p hp
  have h : env43869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43868_43869 : H12AffineEnvironment.transform 9 236 env43868 = env43869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 236 env43868 == env43869) = true)

theorem identity43869 : scanCanonicalize (H12AffineFastState.compose env43869 (packedSelected [0,2,3,5,7,10,11,12,13,15,16,18] rootPS)) = affineNative (2^(8+1) ^^^ 97) := by decide +kernel

theorem selectedBound43869 : packedSelected [0,2,3,5,7,10,11,12,13,15,16,18] rootPS < 2^1333 := by decide +kernel

def env43870 : List Nat := [2,4,8,16,32,64,128,256,97,236,2048,0,437,508,324,154,428,26,320,325,0,476,17,138,144,493,319,508,509,2184,441,445,257,493,429,461]

theorem envBound43870 : H12AffineFastState.Bounded env43870 := by
  intro p hp
  have h : env43870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43869_43870 : H12AffineEnvironment.transform 8 97 env43869 = env43870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env43869 == env43870) = true)

theorem identity43870 : scanCanonicalize (H12AffineFastState.compose env43870 (packedSelected [0,2,3,4,7,8,9,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 111) := by decide +kernel

theorem selectedBound43870 : packedSelected [0,2,3,4,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env43871 : List Nat := [2,4,8,16,32,64,128,111,97,236,2048,0,218,147,43,154,195,26,47,42,0,179,17,138,144,130,80,147,146,2184,214,210,110,130,194,162]

theorem envBound43871 : H12AffineFastState.Bounded env43871 := by
  intro p hp
  have h : env43871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43870_43871 : H12AffineEnvironment.transform 7 111 env43870 = env43871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 111 env43870 == env43871) = true)

theorem identity43871 : scanCanonicalize (H12AffineFastState.compose env43871 (packedSelected [3,7,8,9,10,12] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound43871 : packedSelected [3,7,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env43872 : List Nat := [2,4,8,10,32,64,128,111,97,236,2048,0,192,137,43,128,195,0,47,42,0,169,11,138,138,130,74,137,136,2184,204,200,110,130,194,162]

theorem envBound43872 : H12AffineFastState.Bounded env43872 := by
  intro p hp
  have h : env43872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43871_43872 : H12AffineEnvironment.transform 3 10 env43871 = env43872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env43871 == env43872) = true)

theorem identity43872 : scanCanonicalize (H12AffineFastState.compose env43872 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound43872 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env43873 : List Nat := [2,4,8,10,32,64,9,111,97,101,2048,0,73,0,43,9,74,0,47,42,0,32,11,3,3,11,74,0,1,2049,69,65,110,11,75,43]

theorem envBound43873 : H12AffineFastState.Bounded env43873 := by
  intro p hp
  have h : env43873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43872_43873 : H12AffineEnvironment.transform 6 9 env43872 = env43873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43872 == env43873) = true)

theorem identity43873 : scanCanonicalize (H12AffineFastState.compose env43873 (packedSelected [0,1,4] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound43873 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env43874 : List Nat := [2,4,8,10,32,13,9,34,44,40,2048,0,4,0,43,9,7,0,47,42,0,32,11,3,3,11,7,0,1,2049,8,12,35,11,6,43]

theorem envBound43874 : H12AffineFastState.Bounded env43874 := by
  intro p hp
  have h : env43874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43873_43874 : H12AffineEnvironment.transform 5 13 env43873 = env43874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env43873 == env43874) = true)

def env43875 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74863,65665,4416,13340,4096,476,74046,69648,13769,78894,4414,74815,1297,81227,8204,8200,257,74798,1345,5952]

theorem envBound43875 : H12AffineFastState.Bounded env43875 := by
  intro p hp
  have h : env43875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43855_43875 : H12AffineEnvironment.transform 17 65665 env43855 = env43875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env43855 == env43875) = true)

theorem identity43875 : scanCanonicalize (H12AffineFastState.compose env43875 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 311) := by decide +kernel

theorem selectedBound43875 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env43876 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,311,9560,438,4416,13340,4096,476,8201,4391,13769,13593,4414,9480,1297,15484,8204,8200,257,9497,1345,5952]

theorem envBound43876 : H12AffineFastState.Bounded env43876 := by
  intro p hp
  have h : env43876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43875_43876 : H12AffineEnvironment.transform 15 311 env43875 = env43876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 311 env43875 == env43876) = true)

def env43877 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,0,12557,311,8264,438,4416,12556,4096,476,8201,4391,12505,12297,4414,8216,1,14700,8204,8200,257,8201,81,4688]

theorem envBound43877 : H12AffineFastState.Bounded env43877 := by
  intro p hp
  have h : env43877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43876_43877 : H12AffineEnvironment.transform 9 272 env43876 = env43877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env43876 == env43877) = true)

theorem identity43877 : scanCanonicalize (H12AffineFastState.compose env43877 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound43877 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env43878 : List Nat := [2,4,8,16,32,64,128,20,512,4,2048,4096,8192,0,12313,35,8264,162,4180,12312,4096,200,8201,4147,12505,12297,4138,8216,1,14456,8204,8200,21,8201,81,4688]

theorem envBound43878 : H12AffineFastState.Bounded env43878 := by
  intro p hp
  have h : env43878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43877_43878 : H12AffineEnvironment.transform 7 20 env43877 = env43878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env43877 == env43878) = true)

theorem identity43878 : scanCanonicalize (H12AffineFastState.compose env43878 (packedSelected [0,1,4,7,8,9,12,13,15,18,19,23] rootPS)) = affineNative (2^(6+1) ^^^ 104) := by decide +kernel

theorem selectedBound43878 : packedSelected [0,1,4,7,8,9,12,13,15,18,19,23] rootPS < 2^1333 := by decide +kernel

def env43879 : List Nat := [2,4,8,16,32,64,104,20,512,4,2048,4096,8192,0,12313,35,8264,74,4180,12312,4096,32,8201,4147,12337,12297,4138,8216,1,14456,8204,8200,21,8201,81,4688]

theorem envBound43879 : H12AffineFastState.Bounded env43879 := by
  intro p hp
  have h : env43879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43878_43879 : H12AffineEnvironment.transform 6 104 env43878 = env43879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 104 env43878 == env43879) = true)

theorem identity43879 : scanCanonicalize (H12AffineFastState.compose env43879 (packedSelected [0,1,5,7,8,12,16,17] rootPS)) = affineNative (2^(11+1) ^^^ 524) := by decide +kernel

theorem selectedBound43879 : packedSelected [0,1,5,7,8,12,16,17] rootPS < 2^1333 := by decide +kernel

def env43880 : List Nat := [2,4,8,16,32,64,104,20,512,4,2048,524,8192,0,8725,35,8264,74,600,8724,524,32,8201,575,8765,8709,550,8216,1,10868,8204,8200,21,8201,81,92]

theorem envBound43880 : H12AffineFastState.Bounded env43880 := by
  intro p hp
  have h : env43880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43879_43880 : H12AffineEnvironment.transform 11 524 env43879 = env43880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 524 env43879 == env43880) = true)

theorem identity43880 : scanCanonicalize (H12AffineFastState.compose env43880 (packedSelected [0,1,2,5,7,8,11,12,13,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 2143) := by decide +kernel

theorem selectedBound43880 : packedSelected [0,1,2,5,7,8,11,12,13,16,18] rootPS < 2^1333 := by decide +kernel

def env43881 : List Nat := [2,4,8,16,32,64,104,20,512,4,2048,524,2143,0,2634,35,2071,74,600,2635,524,32,2134,575,2658,2650,550,2119,1,555,2131,2135,21,2134,81,92]

theorem envBound43881 : H12AffineFastState.Bounded env43881 := by
  intro p hp
  have h : env43881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43880_43881 : H12AffineEnvironment.transform 12 2143 env43880 = env43881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2143 env43880 == env43881) = true)

theorem identity43881 : scanCanonicalize (H12AffineFastState.compose env43881 (packedSelected [1,3,4,9,12,15,16] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound43881 : packedSelected [1,3,4,9,12,15,16] rootPS < 2^1333 := by decide +kernel

def env43882 : List Nat := [2,4,8,16,32,64,104,20,49,4,2048,61,2143,0,2171,35,2071,74,105,2170,61,32,2134,14,2131,2155,23,2119,1,26,2131,2135,21,2134,81,92]

theorem envBound43882 : H12AffineFastState.Bounded env43882 := by
  intro p hp
  have h : env43882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43881_43882 : H12AffineEnvironment.transform 8 49 env43881 = env43882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env43881 == env43882) = true)

def env43883 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,1,12556,311,8265,438,4416,12557,4096,476,8201,4391,12504,12296,4414,8217,0,14701,8204,8200,257,8200,80,4689]

theorem envBound43883 : H12AffineFastState.Bounded env43883 := by
  intro p hp
  have h : env43883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43876_43883 : H12AffineEnvironment.transform 9 273 env43876 = env43883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env43876 == env43883) = true)

theorem identity43883 : scanCanonicalize (H12AffineFastState.compose env43883 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound43883 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env43884 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,1,8192,1,8461,311,8265,438,321,8460,1,476,8201,294,8409,8201,319,8217,0,10604,8204,8200,257,8200,80,592]

theorem envBound43884 : H12AffineFastState.Bounded env43884 := by
  intro p hp
  have h : env43884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43883_43884 : H12AffineEnvironment.transform 11 1 env43883 = env43884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env43883 == env43884) = true)

theorem identity43884 : scanCanonicalize (H12AffineFastState.compose env43884 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound43884 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env43885 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,8192,1,8461,311,8217,438,273,8460,1,396,8201,294,8329,8201,319,8217,0,10556,8204,8200,257,8200,0,512]

theorem envBound43885 : H12AffineFastState.Bounded env43885 := by
  intro p hp
  have h : env43885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43884_43885 : H12AffineEnvironment.transform 5 16 env43884 = env43885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43884 == env43885) = true)

theorem identity43885 : scanCanonicalize (H12AffineFastState.compose env43885 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 900) := by decide +kernel

theorem selectedBound43885 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env43886 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,900,1,649,311,925,438,273,648,1,396,909,294,781,909,319,925,0,2744,904,908,257,908,0,512]

theorem envBound43886 : H12AffineFastState.Bounded env43886 := by
  intro p hp
  have h : env43886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43885_43886 : H12AffineEnvironment.transform 12 900 env43885 = env43886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 900 env43885 == env43886) = true)

theorem identity43886 : scanCanonicalize (H12AffineFastState.compose env43886 (packedSelected [3,8,13] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound43886 : packedSelected [3,8,13] rootPS < 2^1333 := by decide +kernel

def env43887 : List Nat := [2,4,8,16,32,16,128,256,512,273,137,1,900,1,649,311,925,438,273,648,1,396,909,294,781,909,319,925,0,561,904,908,257,908,0,512]

theorem envBound43887 : H12AffineFastState.Bounded env43887 := by
  intro p hp
  have h : env43887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43886_43887 : H12AffineEnvironment.transform 10 137 env43886 = env43887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env43886 == env43887) = true)

theorem identity43887 : scanCanonicalize (H12AffineFastState.compose env43887 (packedSelected [5,8] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound43887 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env43888 : List Nat := [2,4,8,16,32,16,128,256,0,273,137,1,388,1,137,311,413,438,273,136,1,396,397,294,269,397,319,413,0,49,392,396,257,396,0,0]

theorem envBound43888 : H12AffineFastState.Bounded env43888 := by
  intro p hp
  have h : env43888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43887_43888 : H12AffineEnvironment.transform 8 0 env43887 = env43888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env43887 == env43888) = true)

theorem identity43888 : scanCanonicalize (H12AffineFastState.compose env43888 (packedSelected [0,2] rootPS)) = affineNative (2^(7+1) ^^^ 9) := by decide +kernel

theorem selectedBound43888 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env43889 : List Nat := [2,4,8,16,32,16,128,9,0,24,137,1,141,1,137,62,148,191,24,136,1,133,132,47,4,132,54,148,0,49,129,133,8,133,0,0]

theorem envBound43889 : H12AffineFastState.Bounded env43889 := by
  intro p hp
  have h : env43889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43888_43889 : H12AffineEnvironment.transform 7 9 env43888 = env43889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 9 env43888 == env43889) = true)

theorem identity43889 : scanCanonicalize (H12AffineFastState.compose env43889 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound43889 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env43890 : List Nat := [2,4,8,16,23,16,128,9,0,24,137,1,141,1,137,9,148,136,24,136,1,133,132,24,4,132,1,148,0,6,129,133,8,133,0,0]

theorem envBound43890 : H12AffineFastState.Bounded env43890 := by
  intro p hp
  have h : env43890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43889_43890 : H12AffineEnvironment.transform 4 23 env43889 = env43890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env43889 == env43890) = true)

theorem identity43890 : scanCanonicalize (H12AffineFastState.compose env43890 (packedSelected [1,4] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound43890 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env43891 : List Nat := [2,4,8,16,23,16,19,9,0,24,26,1,30,1,26,9,7,27,24,27,1,22,23,24,4,23,1,7,0,6,18,22,8,22,0,0]

theorem envBound43891 : H12AffineFastState.Bounded env43891 := by
  intro p hp
  have h : env43891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43890_43891 : H12AffineEnvironment.transform 6 19 env43890 = env43891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env43890 == env43891) = true)

theorem identity43891 : scanCanonicalize (H12AffineFastState.compose env43891 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound43891 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env43892 : List Nat := [2,4,8,10,13,10,9,9,0,2,0,1,4,1,0,9,7,1,2,1,1,12,13,2,4,13,1,7,0,6,8,12,8,12,0,0]

theorem envBound43892 : H12AffineFastState.Bounded env43892 := by
  intro p hp
  have h : env43892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43891_43892 : H12AffineEnvironment.transform 3 10 env43891 = env43892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env43891 == env43892) = true)

theorem identity43892 : scanCanonicalize (H12AffineFastState.compose env43892 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound43892 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43893 : List Nat := [2,3,8,10,10,10,9,9,0,2,0,1,3,1,0,9,0,1,2,1,1,11,10,2,3,10,1,0,0,1,8,11,8,11,0,0]

theorem envBound43893 : H12AffineFastState.Bounded env43893 := by
  intro p hp
  have h : env43893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43892_43893 : H12AffineEnvironment.transform 1 3 env43892 = env43893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env43892 == env43893) = true)

def env43894 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74863,262144,4417,13340,4096,477,74047,69649,13768,78894,332222,74814,1297,81226,8205,8201,257,74798,1345,5953]

theorem envBound43894 : H12AffineFastState.Bounded env43894 := by
  intro p hp
  have h : env43894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43854_43894 : H12AffineEnvironment.transform 13 1297 env43854 = env43894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env43854 == env43894) = true)

def env43895 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74863,65664,4417,13340,4096,477,74047,69649,13768,78894,4414,74814,1297,81226,8205,8201,257,74798,1345,5953]

theorem envBound43895 : H12AffineFastState.Bounded env43895 := by
  intro p hp
  have h : env43895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43894_43895 : H12AffineEnvironment.transform 17 65664 env43894 = env43895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env43894 == env43895) = true)

theorem identity43895 : scanCanonicalize (H12AffineFastState.compose env43895 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9279) := by decide +kernel

theorem selectedBound43895 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env43896 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,9279,80,9407,4417,13340,4096,477,1280,13358,13768,4113,4414,1,1297,6517,8205,8201,257,17,1345,5953]

theorem envBound43896 : H12AffineFastState.Bounded env43896 := by
  intro p hp
  have h : env43896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43895_43896 : H12AffineEnvironment.transform 15 9279 env43895 = env43896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9279 env43895 == env43896) = true)

def env43897 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,24,1297,5125,1063,80,1191,4417,5124,4096,477,1280,5174,5584,4113,4414,1,1297,6517,21,17,257,17,1345,5953]

theorem envBound43897 : H12AffineFastState.Bounded env43897 := by
  intro p hp
  have h : env43897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43896_43897 : H12AffineEnvironment.transform 12 24 env43896 = env43897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env43896 == env43897) = true)

theorem identity43897 : scanCanonicalize (H12AffineFastState.compose env43897 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound43897 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env43898 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,24,1297,5125,1063,0,1191,4369,5124,4096,397,1280,5174,5504,4113,4414,1,1297,6437,21,17,257,17,1297,5905]

theorem envBound43898 : H12AffineFastState.Bounded env43898 := by
  intro p hp
  have h : env43898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43897_43898 : H12AffineEnvironment.transform 5 16 env43897 = env43898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43897 == env43898) = true)

theorem identity43898 : scanCanonicalize (H12AffineFastState.compose env43898 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound43898 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env43899 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,24,1297,276,1063,0,1191,1024,277,1297,397,1280,295,145,1280,1071,1,1297,3124,21,17,257,17,1297,512]

theorem envBound43899 : H12AffineFastState.Bounded env43899 := by
  intro p hp
  have h : env43899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43898_43899 : H12AffineEnvironment.transform 11 1297 env43898 = env43899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env43898 == env43899) = true)

theorem identity43899 : scanCanonicalize (H12AffineFastState.compose env43899 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 413) := by decide +kernel

theorem selectedBound43899 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env43900 : List Nat := [2,4,8,16,32,16,128,256,413,1024,2048,1297,24,1297,276,1063,0,1191,1024,277,1297,397,1280,295,145,1280,1071,1,1297,3124,21,17,257,17,1297,413]

theorem envBound43900 : H12AffineFastState.Bounded env43900 := by
  intro p hp
  have h : env43900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43899_43900 : H12AffineEnvironment.transform 8 413 env43899 = env43900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 413 env43899 == env43900) = true)

theorem identity43900 : scanCanonicalize (H12AffineFastState.compose env43900 (packedSelected [1,8,12,13] rootPS)) = affineNative (2^(7+1) ^^^ 183) := by decide +kernel

theorem selectedBound43900 : packedSelected [1,8,12,13] rootPS < 2^1333 := by decide +kernel

def env43901 : List Nat := [2,4,8,16,32,16,128,183,42,1024,2048,1190,24,1190,163,1063,0,1191,1024,162,1190,58,1207,144,145,1207,1071,1,1190,3124,21,17,182,17,1190,42]

theorem envBound43901 : H12AffineFastState.Bounded env43901 := by
  intro p hp
  have h : env43901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43900_43901 : H12AffineEnvironment.transform 7 183 env43900 = env43901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 183 env43900 == env43901) = true)

theorem identity43901 : scanCanonicalize (H12AffineFastState.compose env43901 (packedSelected [15] rootPS)) = affineNative (2^(9+1) ^^^ 150) := by decide +kernel

theorem selectedBound43901 : packedSelected [15] rootPS < 2^1333 := by decide +kernel

def env43902 : List Nat := [2,4,8,16,32,16,128,183,42,150,2048,48,24,48,163,177,0,49,150,162,48,58,33,144,145,33,185,1,48,2210,21,17,182,17,48,42]

theorem envBound43902 : H12AffineFastState.Bounded env43902 := by
  intro p hp
  have h : env43902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43901_43902 : H12AffineEnvironment.transform 9 150 env43901 = env43902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 150 env43901 == env43902) = true)

theorem identity43902 : scanCanonicalize (H12AffineFastState.compose env43902 (packedSelected [1,2,3,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound43902 : packedSelected [1,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env43903 : List Nat := [2,4,8,16,11,16,128,156,1,150,2048,27,24,27,136,154,0,26,150,137,27,17,10,144,145,10,146,1,27,2185,21,17,157,17,27,1]

theorem envBound43903 : H12AffineFastState.Bounded env43903 := by
  intro p hp
  have h : env43903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43902_43903 : H12AffineEnvironment.transform 4 11 env43902 = env43903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env43902 == env43903) = true)

theorem identity43903 : scanCanonicalize (H12AffineFastState.compose env43903 (packedSelected [1,2] rootPS)) = affineNative (2^(10+1) ^^^ 7) := by decide +kernel

theorem selectedBound43903 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env43904 : List Nat := [2,4,8,16,11,16,128,156,1,150,7,27,24,27,136,154,0,26,150,137,27,17,10,144,145,10,146,1,27,142,21,17,157,17,27,1]

theorem envBound43904 : H12AffineFastState.Bounded env43904 := by
  intro p hp
  have h : env43904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43903_43904 : H12AffineEnvironment.transform 10 7 env43903 = env43904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 7 env43903 == env43904) = true)

theorem identity43904 : scanCanonicalize (H12AffineFastState.compose env43904 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound43904 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env43905 : List Nat := [2,4,8,10,11,10,128,134,1,140,7,1,2,1,136,128,0,0,140,137,1,11,10,138,139,10,136,1,1,142,15,11,135,11,1,1]

theorem envBound43905 : H12AffineFastState.Bounded env43905 := by
  intro p hp
  have h : env43905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43904_43905 : H12AffineEnvironment.transform 3 10 env43904 = env43905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env43904 == env43905) = true)

theorem identity43905 : scanCanonicalize (H12AffineFastState.compose env43905 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound43905 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43906 : List Nat := [2,4,8,10,11,10,14,8,1,2,7,1,2,1,6,14,0,0,2,7,1,11,10,4,5,10,6,1,1,0,15,11,9,11,1,1]

theorem envBound43906 : H12AffineFastState.Bounded env43906 := by
  intro p hp
  have h : env43906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43905_43906 : H12AffineEnvironment.transform 6 14 env43905 = env43906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env43905 == env43906) = true)

def env43907 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,25,1297,5124,1062,80,1190,4417,5125,4096,477,1280,5175,5585,4113,4414,1,1297,6517,20,16,257,17,1345,5953]

theorem envBound43907 : H12AffineFastState.Bounded env43907 := by
  intro p hp
  have h : env43907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43896_43907 : H12AffineEnvironment.transform 12 25 env43896 = env43907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env43896 == env43907) = true)

theorem identity43907 : scanCanonicalize (H12AffineFastState.compose env43907 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 325) := by decide +kernel

theorem selectedBound43907 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env43908 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,325,25,1297,1345,1062,80,1190,4,1344,325,477,1280,1394,1172,340,123,1,1297,2096,20,16,257,17,1345,1540]

theorem envBound43908 : H12AffineFastState.Bounded env43908 := by
  intro p hp
  have h : env43908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43907_43908 : H12AffineEnvironment.transform 11 325 env43907 = env43908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 325 env43907 == env43908) = true)

theorem identity43908 : scanCanonicalize (H12AffineFastState.compose env43908 (packedSelected [0,3,4,5,7,9,10,12,13,15,18,23] rootPS)) = affineNative (2^(6+1) ^^^ 104) := by decide +kernel

theorem selectedBound43908 : packedSelected [0,3,4,5,7,9,10,12,13,15,18,23] rootPS < 2^1333 := by decide +kernel

def env43909 : List Nat := [2,4,8,16,32,64,104,256,512,1024,2048,325,25,1297,1345,1062,80,1102,4,1344,325,309,1280,1394,1148,340,123,1,1297,2096,20,16,257,17,1345,1540]

theorem envBound43909 : H12AffineFastState.Bounded env43909 := by
  intro p hp
  have h : env43909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43908_43909 : H12AffineEnvironment.transform 6 104 env43908 = env43909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 104 env43908 == env43909) = true)

theorem identity43909 : scanCanonicalize (H12AffineFastState.compose env43909 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 586) := by decide +kernel

theorem selectedBound43909 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env43910 : List Nat := [2,4,8,16,32,64,104,256,512,1024,586,325,25,1297,1345,1062,80,1102,4,1344,325,309,1280,1394,1148,340,123,1,1297,634,20,16,257,17,1345,1540]

theorem envBound43910 : H12AffineFastState.Bounded env43910 := by
  intro p hp
  have h : env43910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43909_43910 : H12AffineEnvironment.transform 10 586 env43909 = env43910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 586 env43909 == env43910) = true)

theorem identity43910 : scanCanonicalize (H12AffineFastState.compose env43910 (packedSelected [4,5,9,11,12,13] rootPS)) = affineNative (2^(7+1) ^^^ 51) := by decide +kernel

theorem selectedBound43910 : packedSelected [4,5,9,11,12,13] rootPS < 2^1333 := by decide +kernel

def env43911 : List Nat := [2,4,8,16,32,64,104,51,512,1024,586,118,25,1058,1138,1062,80,1102,4,1139,118,6,1075,1089,1148,103,123,1,1058,634,20,16,50,17,1138,1540]

theorem envBound43911 : H12AffineFastState.Bounded env43911 := by
  intro p hp
  have h : env43911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43910_43911 : H12AffineEnvironment.transform 7 51 env43910 = env43911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 51 env43910 == env43911) = true)

theorem identity43911 : scanCanonicalize (H12AffineFastState.compose env43911 (packedSelected [1,3,4,9,12,15,16] rootPS)) = affineNative (2^(9+1) ^^^ 530) := by decide +kernel

theorem selectedBound43911 : packedSelected [1,3,4,9,12,15,16] rootPS < 2^1333 := by decide +kernel

def env43912 : List Nat := [2,4,8,16,32,64,104,51,512,530,586,118,25,560,608,564,80,604,4,609,118,6,545,595,622,103,123,1,560,634,20,16,50,17,608,22]

theorem envBound43912 : H12AffineFastState.Bounded env43912 := by
  intro p hp
  have h : env43912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43911_43912 : H12AffineEnvironment.transform 9 530 env43911 = env43912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 530 env43911 == env43912) = true)

theorem identity43912 : scanCanonicalize (H12AffineFastState.compose env43912 (packedSelected [8,10,12] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound43912 : packedSelected [8,10,12] rootPS < 2^1333 := by decide +kernel

def env43913 : List Nat := [2,4,8,10,32,64,104,41,512,520,586,108,3,554,608,558,74,582,4,609,108,6,545,585,622,103,97,1,554,608,14,10,40,11,608,12]

theorem envBound43913 : H12AffineFastState.Bounded env43913 := by
  intro p hp
  have h : env43913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43912_43913 : H12AffineEnvironment.transform 3 10 env43912 = env43913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env43912 == env43913) = true)

theorem identity43913 : scanCanonicalize (H12AffineFastState.compose env43913 (packedSelected [1,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound43913 : packedSelected [1,4,7] rootPS < 2^1333 := by decide +kernel

def env43914 : List Nat := [2,4,8,10,11,64,67,2,512,520,586,71,3,513,587,517,74,582,4,586,71,6,522,585,581,76,74,1,513,587,14,10,3,11,587,12]

theorem envBound43914 : H12AffineFastState.Bounded env43914 := by
  intro p hp
  have h : env43914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43913_43914 : H12AffineEnvironment.transform 4 11 env43913 = env43914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env43913 == env43914) = true)

theorem identity43914 : scanCanonicalize (H12AffineFastState.compose env43914 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 7) := by decide +kernel

theorem selectedBound43914 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43915 : List Nat := [2,4,8,10,11,7,4,2,512,520,525,0,3,513,524,517,13,513,4,525,0,6,522,526,514,11,13,1,513,524,14,10,3,11,524,12]

theorem envBound43915 : H12AffineFastState.Bounded env43915 := by
  intro p hp
  have h : env43915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43914_43915 : H12AffineEnvironment.transform 5 7 env43914 = env43915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 7 env43914 == env43915) = true)

theorem identity43915 : scanCanonicalize (H12AffineFastState.compose env43915 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound43915 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env43916 : List Nat := [2,4,8,10,11,7,4,2,0,8,13,0,3,1,12,5,13,1,4,13,0,6,10,14,2,11,13,1,1,12,14,10,3,11,12,12]

theorem envBound43916 : H12AffineFastState.Bounded env43916 := by
  intro p hp
  have h : env43916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43915_43916 : H12AffineEnvironment.transform 8 0 env43915 = env43916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env43915 == env43916) = true)

theorem identity43916 : scanCanonicalize (H12AffineFastState.compose env43916 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound43916 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env43917 : List Nat := [2,4,5,7,6,7,4,2,0,5,0,0,3,1,1,5,0,1,4,0,0,6,7,3,2,6,0,1,1,1,3,7,3,6,1,1]

theorem envBound43917 : H12AffineFastState.Bounded env43917 := by
  intro p hp
  have h : env43917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43916_43917 : H12AffineEnvironment.transform 2 5 env43916 = env43917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env43916 == env43917) = true)

theorem identity43917 : scanCanonicalize (H12AffineFastState.compose env43917 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound43917 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43918 : List Nat := [2,1,0,2,3,2,1,2,0,0,0,0,3,1,1,0,0,1,1,0,0,3,2,3,2,3,0,1,1,1,3,2,3,3,1,1]

theorem envBound43918 : H12AffineFastState.Bounded env43918 := by
  intro p hp
  have h : env43918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43917_43918 : H12AffineEnvironment.transform 1 1 env43917 = env43918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env43917 == env43918) = true)

theorem identity43918 : scanCanonicalize (H12AffineFastState.compose env43918 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound43918 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env43919 : List Nat := [1,1,0,1,0,1,1,1,0,0,0,0,0,1,1,0,0,1,1,0,0,0,1,0,1,0,0,1,1,1,0,1,0,0,1,1]

theorem envBound43919 : H12AffineFastState.Bounded env43919 := by
  intro p hp
  have h : env43919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43918_43919 : H12AffineEnvironment.transform 0 1 env43918 = env43919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env43918 == env43919) = true)

def env43920 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74863,65665,4417,13340,4096,477,74047,69649,13768,78894,4415,74814,1297,81226,8205,8201,257,74798,1345,5953]

theorem envBound43920 : H12AffineFastState.Bounded env43920 := by
  intro p hp
  have h : env43920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43894_43920 : H12AffineEnvironment.transform 17 65665 env43894 = env43920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env43894 == env43920) = true)

theorem identity43920 : scanCanonicalize (H12AffineFastState.compose env43920 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12671) := by decide +kernel

theorem selectedBound43920 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env43921 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,12671,5392,12798,4417,13340,4096,477,4160,8558,13768,1361,4415,5441,1297,3125,8205,8201,257,5457,1345,5953]

theorem envBound43921 : H12AffineFastState.Bounded env43921 := by
  intro p hp
  have h : env43921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43920_43921 : H12AffineEnvironment.transform 15 12671 env43920 = env43921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12671 env43920 == env43921) = true)

def env43922 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1297,9293,8495,1344,8622,273,9292,80,477,16,8558,9624,1361,367,1297,1297,3125,8205,8201,257,1281,1345,1809]

theorem envBound43922 : H12AffineFastState.Bounded env43922 := by
  intro p hp
  have h : env43922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43921_43922 : H12AffineEnvironment.transform 11 80 env43921 = env43922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env43921 == env43922) = true)

theorem identity43922 : scanCanonicalize (H12AffineFastState.compose env43922 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 73) := by decide +kernel

theorem selectedBound43922 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env43923 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,73,1297,1028,358,1344,487,273,1029,80,477,16,295,1489,1361,367,1297,1297,3125,68,64,257,1281,1345,1809]

theorem envBound43923 : H12AffineFastState.Bounded env43923 := by
  intro p hp
  have h : env43923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43922_43923 : H12AffineEnvironment.transform 12 73 env43922 = env43923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env43922 == env43923) = true)

theorem identity43923 : scanCanonicalize (H12AffineFastState.compose env43923 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound43923 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env43924 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,80,73,1212,1028,203,1261,74,188,1029,80,112,16,138,1148,1276,194,1212,1212,3125,68,64,172,1196,1260,1724]

theorem envBound43924 : H12AffineFastState.Bounded env43924 := by
  intro p hp
  have h : env43924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43923_43924 : H12AffineEnvironment.transform 7 173 env43923 = env43924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env43923 == env43924) = true)

theorem identity43924 : scanCanonicalize (H12AffineFastState.compose env43924 (packedSelected [0,2,3,4,5,7,9,10,11,12,15,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 539) := by decide +kernel

theorem selectedBound43924 : packedSelected [0,2,3,4,5,7,9,10,11,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env43925 : List Nat := [2,4,8,16,32,64,128,173,512,1024,539,80,73,1212,1028,203,1261,74,188,1029,80,112,16,138,1148,1276,194,1212,1212,1582,68,64,172,1196,1260,1724]

theorem envBound43925 : H12AffineFastState.Bounded env43925 := by
  intro p hp
  have h : env43925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43924_43925 : H12AffineEnvironment.transform 10 539 env43924 = env43925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 539 env43924 == env43925) = true)

theorem identity43925 : scanCanonicalize (H12AffineFastState.compose env43925 (packedSelected [0,2,3,7,8,10,16,17] rootPS)) = affineNative (2^(8+1) ^^^ 74) := by decide +kernel

theorem selectedBound43925 : packedSelected [0,2,3,7,8,10,16,17] rootPS < 2^1333 := by decide +kernel

def env43926 : List Nat := [2,4,8,16,32,64,128,173,74,1024,81,80,73,1212,1028,203,1261,74,188,1029,80,112,16,138,1148,1276,194,1212,1212,1124,68,64,172,1196,1260,1270]

theorem envBound43926 : H12AffineFastState.Bounded env43926 := by
  intro p hp
  have h : env43926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43925_43926 : H12AffineEnvironment.transform 8 74 env43925 = env43926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 74 env43925 == env43926) = true)

theorem identity43926 : scanCanonicalize (H12AffineFastState.compose env43926 (packedSelected [13] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound43926 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env43927 : List Nat := [2,4,8,16,32,64,34,15,74,1024,81,80,73,1054,1028,105,1103,74,30,1029,80,112,16,40,1148,1118,96,1054,1054,1124,68,64,14,1038,1102,1108]

theorem envBound43927 : H12AffineFastState.Bounded env43927 := by
  intro p hp
  have h : env43927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43926_43927 : H12AffineEnvironment.transform 6 34 env43926 = env43927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env43926 == env43927) = true)

theorem identity43927 : scanCanonicalize (H12AffineFastState.compose env43927 (packedSelected [0,1,2,3,4,10] rootPS)) = affineNative (2^(9+1) ^^^ 31) := by decide +kernel

theorem selectedBound43927 : packedSelected [0,1,2,3,4,10] rootPS < 2^1333 := by decide +kernel

def env43928 : List Nat := [2,4,8,16,32,64,34,15,74,31,81,80,73,1,27,105,80,74,30,26,80,112,16,40,99,65,96,1,1,123,68,64,14,17,81,75]

theorem envBound43928 : H12AffineFastState.Bounded env43928 := by
  intro p hp
  have h : env43928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43927_43928 : H12AffineEnvironment.transform 9 31 env43927 = env43928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 31 env43927 == env43928) = true)

theorem identity43928 : scanCanonicalize (H12AffineFastState.compose env43928 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound43928 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env43929 : List Nat := [2,4,8,10,32,64,34,15,74,5,75,74,73,1,1,105,74,74,4,0,74,106,10,40,99,65,96,1,1,97,68,64,14,11,75,75]

theorem envBound43929 : H12AffineFastState.Bounded env43929 := by
  intro p hp
  have h : env43929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43928_43929 : H12AffineEnvironment.transform 3 10 env43928 = env43929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env43928 == env43929) = true)

theorem identity43929 : scanCanonicalize (H12AffineFastState.compose env43929 (packedSelected [0,1,2] rootPS)) = affineNative (2^(5+1) ^^^ 40) := by decide +kernel

theorem selectedBound43929 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env43930 : List Nat := [2,4,8,10,32,40,34,15,34,5,35,34,33,1,1,1,34,34,4,0,34,2,10,40,11,41,8,1,1,9,44,40,14,11,35,35]

theorem envBound43930 : H12AffineFastState.Bounded env43930 := by
  intro p hp
  have h : env43930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43929_43930 : H12AffineEnvironment.transform 5 40 env43929 = env43930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 40 env43929 == env43930) = true)

theorem identity43930 : scanCanonicalize (H12AffineFastState.compose env43930 (packedSelected [1,4] rootPS)) = affineNative (2^(4+1) ^^^ 9) := by decide +kernel

theorem selectedBound43930 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env43931 : List Nat := [2,4,8,10,9,1,11,15,11,5,10,11,8,1,1,1,11,11,4,0,11,2,10,1,11,0,8,1,1,9,5,1,14,11,10,10]

theorem envBound43931 : H12AffineFastState.Bounded env43931 := by
  intro p hp
  have h : env43931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43930_43931 : H12AffineEnvironment.transform 4 9 env43930 = env43931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 9 env43930 == env43931) = true)

theorem identity43931 : scanCanonicalize (H12AffineFastState.compose env43931 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound43931 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43932 : List Nat := [2,1,8,10,9,1,11,10,11,0,10,11,8,1,1,1,11,11,1,0,11,2,10,1,11,0,8,1,1,9,0,1,11,11,10,10]

theorem envBound43932 : H12AffineFastState.Bounded env43932 := by
  intro p hp
  have h : env43932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43931_43932 : H12AffineEnvironment.transform 1 1 env43931 = env43932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env43931 == env43932) = true)

def env43933 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1297,9292,8494,1345,8623,272,9293,81,477,17,8558,9625,1361,366,1296,1297,3125,8205,8201,257,1280,1345,1808]

theorem envBound43933 : H12AffineFastState.Bounded env43933 := by
  intro p hp
  have h : env43933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43921_43933 : H12AffineEnvironment.transform 11 81 env43921 = env43933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env43921 == env43933) = true)

theorem identity43933 : scanCanonicalize (H12AffineFastState.compose env43933 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound43933 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env43934 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,81,8192,277,8264,8494,325,8623,272,8265,81,477,17,8558,8605,341,366,276,277,2097,8205,8201,257,260,325,788]

theorem envBound43934 : H12AffineFastState.Bounded env43934 := by
  intro p hp
  have h : env43934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43933_43934 : H12AffineEnvironment.transform 9 4 env43933 = env43934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env43933 == env43934) = true)

theorem identity43934 : scanCanonicalize (H12AffineFastState.compose env43934 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound43934 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env43935 : List Nat := [2,4,8,16,32,64,128,20,512,4,2048,81,8192,1,8264,8250,81,8379,4,8265,81,201,17,8314,8329,65,122,0,1,2097,8205,8201,21,16,81,512]

theorem envBound43935 : H12AffineFastState.Bounded env43935 := by
  intro p hp
  have h : env43935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43934_43935 : H12AffineEnvironment.transform 7 20 env43934 = env43935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env43934 == env43935) = true)

theorem identity43935 : scanCanonicalize (H12AffineFastState.compose env43935 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound43935 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env43936 : List Nat := [2,4,8,16,32,16,128,20,512,4,2048,1,8192,1,8216,8250,1,8379,4,8217,1,153,17,8234,8329,17,42,0,1,2097,8205,8201,21,16,1,512]

theorem envBound43936 : H12AffineFastState.Bounded env43936 := by
  intro p hp
  have h : env43936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43935_43936 : H12AffineEnvironment.transform 5 16 env43935 = env43936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43935 == env43936) = true)

theorem identity43936 : scanCanonicalize (H12AffineFastState.compose env43936 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 648) := by decide +kernel

theorem selectedBound43936 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43937 : List Nat := [2,4,8,16,32,16,128,20,512,4,648,1,8192,1,8216,8250,1,8379,4,8217,1,153,17,8234,8329,17,42,0,1,697,8205,8201,21,16,1,512]

theorem envBound43937 : H12AffineFastState.Bounded env43937 := by
  intro p hp
  have h : env43937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43936_43937 : H12AffineEnvironment.transform 10 648 env43936 = env43937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 648 env43936 == env43937) = true)

theorem identity43937 : scanCanonicalize (H12AffineFastState.compose env43937 (packedSelected [3,8] rootPS)) = affineNative (2^(12+1) ^^^ 145) := by decide +kernel

theorem selectedBound43937 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env43938 : List Nat := [2,4,8,16,32,16,128,20,512,4,648,1,145,1,137,171,1,42,4,136,1,153,17,187,24,17,42,0,1,697,156,152,21,16,1,512]

theorem envBound43938 : H12AffineFastState.Bounded env43938 := by
  intro p hp
  have h : env43938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43937_43938 : H12AffineEnvironment.transform 12 145 env43937 = env43938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 145 env43937 == env43938) = true)

theorem identity43938 : scanCanonicalize (H12AffineFastState.compose env43938 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound43938 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env43939 : List Nat := [2,4,8,16,17,16,128,20,512,4,648,1,145,1,137,154,1,27,4,136,1,153,17,138,24,17,27,0,1,648,156,152,21,16,1,512]

theorem envBound43939 : H12AffineFastState.Bounded env43939 := by
  intro p hp
  have h : env43939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43938_43939 : H12AffineEnvironment.transform 4 17 env43938 = env43939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env43938 == env43939) = true)

theorem identity43939 : scanCanonicalize (H12AffineFastState.compose env43939 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound43939 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43940 : List Nat := [2,4,8,16,17,16,18,20,512,4,538,1,3,1,27,8,1,27,4,26,1,11,17,24,24,17,27,0,1,538,14,10,21,16,1,512]

theorem envBound43940 : H12AffineFastState.Bounded env43940 := by
  intro p hp
  have h : env43940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43939_43940 : H12AffineEnvironment.transform 6 18 env43939 = env43940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env43939 == env43940) = true)

theorem identity43940 : scanCanonicalize (H12AffineFastState.compose env43940 (packedSelected [1,4] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound43940 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env43941 : List Nat := [2,4,8,16,17,16,18,20,26,4,0,1,3,1,27,8,1,27,4,26,1,11,17,24,24,17,27,0,1,0,14,10,21,16,1,26]

theorem envBound43941 : H12AffineFastState.Bounded env43941 := by
  intro p hp
  have h : env43941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43940_43941 : H12AffineEnvironment.transform 8 26 env43940 = env43941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env43940 == env43941) = true)

def env43942 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21585,32769,4096,61649,91182,123165,28888,78895,385202,90415,1296,96347,25884,25880,257,74799,1345,21073]

theorem envBound43942 : H12AffineFastState.Bounded env43942 := by
  intro p hp
  have h : env43942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43852_43942 : H12AffineEnvironment.transform 18 21585 env43852 = env43942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env43852 == env43942) = true)

theorem identity43942 : scanCanonicalize (H12AffineFastState.compose env43942 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25677) := by decide +kernel

theorem selectedBound43942 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env43943 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25677,65536,74863,262144,21585,25676,4096,5276,91182,66896,28888,78895,328959,90415,1296,96347,25884,25880,257,74799,1345,21073]

theorem envBound43943 : H12AffineFastState.Bounded env43943 := by
  intro p hp
  have h : env43943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43942_43943 : H12AffineEnvironment.transform 14 25677 env43942 = env43943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25677 env43942 == env43943) = true)

def env43944 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74863,262144,4417,8540,4096,5276,74046,66896,13768,78895,328959,74815,1296,81227,8204,8200,257,74799,1345,5953]

theorem envBound43944 : H12AffineFastState.Bounded env43944 := by
  intro p hp
  have h : env43944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43943_43944 : H12AffineEnvironment.transform 13 1296 env43943 = env43944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env43943 == env43944) = true)

def env43945 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74863,65664,4417,8540,4096,5276,74046,66896,13768,78895,1151,74815,1296,81227,8204,8200,257,74799,1345,5953]

theorem envBound43945 : H12AffineFastState.Bounded env43945 := by
  intro p hp
  have h : env43945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43944_43945 : H12AffineEnvironment.transform 17 65664 env43944 = env43945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env43944 == env43945) = true)

theorem identity43945 : scanCanonicalize (H12AffineFastState.compose env43945 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5239) := by decide +kernel

theorem selectedBound43945 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env43946 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,5239,12312,5367,4417,8540,4096,5276,13641,4391,13768,8280,1151,12360,1296,10556,8204,8200,257,12376,1345,5953]

theorem envBound43946 : H12AffineFastState.Bounded env43946 := by
  intro p hp
  have h : env43946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43945_43946 : H12AffineEnvironment.transform 15 5239 env43945 = env43946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5239 env43945 == env43946) = true)

def env43947 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5464,1296,5125,5239,1344,5367,4417,5124,4096,5276,17,4391,144,5376,1151,1296,1296,7268,5460,5456,257,1280,1345,5953]

theorem envBound43947 : H12AffineFastState.Bounded env43947 := by
  intro p hp
  have h : env43947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43946_43947 : H12AffineEnvironment.transform 12 5464 env43946 = env43947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5464 env43946 == env43947) = true)

theorem identity43947 : scanCanonicalize (H12AffineFastState.compose env43947 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 324) := by decide +kernel

theorem selectedBound43947 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env43948 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,324,1052,1296,1345,1331,1344,1459,5,1344,324,1496,17,99,144,1092,1151,1296,1296,3360,1040,1044,257,1280,1345,1541]

theorem envBound43948 : H12AffineFastState.Bounded env43948 := by
  intro p hp
  have h : env43948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43947_43948 : H12AffineEnvironment.transform 11 324 env43947 = env43948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 324 env43947 == env43948) = true)

theorem identity43948 : scanCanonicalize (H12AffineFastState.compose env43948 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound43948 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env43949 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,324,25,277,324,310,325,438,5,325,324,477,17,99,144,65,122,277,277,2341,21,17,257,261,324,512]

theorem envBound43949 : H12AffineFastState.Bounded env43949 := by
  intro p hp
  have h : env43949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43948_43949 : H12AffineEnvironment.transform 9 5 env43948 = env43949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env43948 == env43949) = true)

theorem identity43949 : scanCanonicalize (H12AffineFastState.compose env43949 (packedSelected [2,5,8,13] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound43949 : packedSelected [2,5,8,13] rootPS < 2^1333 := by decide +kernel

def env43950 : List Nat := [2,4,8,16,32,64,128,20,512,5,2048,80,25,1,80,34,81,162,5,81,80,201,17,99,144,65,122,1,1,2097,21,17,21,17,80,512]

theorem envBound43950 : H12AffineFastState.Bounded env43950 := by
  intro p hp
  have h : env43950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43949_43950 : H12AffineEnvironment.transform 7 20 env43949 = env43950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env43949 == env43950) = true)

theorem identity43950 : scanCanonicalize (H12AffineFastState.compose env43950 (packedSelected [2,5] rootPS)) = affineNative (2^(5+1) ^^^ 6) := by decide +kernel

theorem selectedBound43950 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env43951 : List Nat := [2,4,8,16,32,6,128,20,512,5,2048,22,25,1,22,34,23,162,5,23,22,143,17,37,144,7,60,1,1,2097,21,17,21,17,22,512]

theorem envBound43951 : H12AffineFastState.Bounded env43951 := by
  intro p hp
  have h : env43951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43950_43951 : H12AffineEnvironment.transform 5 6 env43950 = env43951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 6 env43950 == env43951) = true)

theorem identity43951 : scanCanonicalize (H12AffineFastState.compose env43951 (packedSelected [2,3,10] rootPS)) = affineNative (2^(8+1) ^^^ 158) := by decide +kernel

theorem selectedBound43951 : packedSelected [2,3,10] rootPS < 2^1333 := by decide +kernel

def env43952 : List Nat := [2,4,8,16,32,6,128,20,158,5,2048,22,25,1,22,34,23,162,5,23,22,143,17,37,144,7,60,1,1,2097,21,17,21,17,22,158]

theorem envBound43952 : H12AffineFastState.Bounded env43952 := by
  intro p hp
  have h : env43952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43951_43952 : H12AffineEnvironment.transform 8 158 env43951 = env43952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 158 env43951 == env43952) = true)

theorem identity43952 : scanCanonicalize (H12AffineFastState.compose env43952 (packedSelected [0,1,7,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 38) := by decide +kernel

theorem selectedBound43952 : packedSelected [0,1,7,8,11] rootPS < 2^1333 := by decide +kernel

def env43953 : List Nat := [2,4,8,16,32,6,128,20,158,5,38,22,25,1,22,34,23,162,5,23,22,143,17,37,144,7,60,1,1,23,21,17,21,17,22,158]

theorem envBound43953 : H12AffineFastState.Bounded env43953 := by
  intro p hp
  have h : env43953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43952_43953 : H12AffineEnvironment.transform 10 38 env43952 = env43953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 38 env43952 == env43953) = true)

theorem identity43953 : scanCanonicalize (H12AffineFastState.compose env43953 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound43953 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43954 : List Nat := [2,4,8,16,32,6,9,20,23,5,38,22,25,1,22,34,23,43,5,23,22,6,17,37,25,7,60,1,1,23,21,17,21,17,22,23]

theorem envBound43954 : H12AffineFastState.Bounded env43954 := by
  intro p hp
  have h : env43954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43953_43954 : H12AffineEnvironment.transform 6 9 env43953 = env43954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43953 == env43954) = true)

theorem identity43954 : scanCanonicalize (H12AffineFastState.compose env43954 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound43954 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43955 : List Nat := [2,4,8,16,17,6,9,20,23,5,23,22,25,1,22,19,23,26,5,23,22,6,17,20,25,7,13,1,1,23,21,17,21,17,22,23]

theorem envBound43955 : H12AffineFastState.Bounded env43955 := by
  intro p hp
  have h : env43955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43954_43955 : H12AffineEnvironment.transform 4 17 env43954 = env43955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env43954 == env43955) = true)

theorem identity43955 : scanCanonicalize (H12AffineFastState.compose env43955 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound43955 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43956 : List Nat := [2,4,5,16,17,6,4,20,23,5,23,22,20,1,22,19,23,23,5,23,22,6,17,20,20,7,0,1,1,23,21,17,21,17,22,23]

theorem envBound43956 : H12AffineFastState.Bounded env43956 := by
  intro p hp
  have h : env43956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43955_43956 : H12AffineEnvironment.transform 2 5 env43955 = env43956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env43955 == env43956) = true)

theorem identity43956 : scanCanonicalize (H12AffineFastState.compose env43956 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound43956 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env43957 : List Nat := [2,4,5,7,6,6,4,3,0,5,0,1,3,1,1,4,0,0,5,0,1,6,6,3,3,7,0,1,1,0,2,6,2,6,1,0]

theorem envBound43957 : H12AffineFastState.Bounded env43957 := by
  intro p hp
  have h : env43957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43956_43957 : H12AffineEnvironment.transform 3 7 env43956 = env43957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env43956 == env43957) = true)

def env43958 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5465,1296,5124,5239,1345,5367,4417,5125,4096,5276,16,4391,145,5377,1151,1297,1296,7269,5461,5457,257,1281,1345,5953]

theorem envBound43958 : H12AffineFastState.Bounded env43958 := by
  intro p hp
  have h : env43958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43946_43958 : H12AffineEnvironment.transform 12 5465 env43946 = env43958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5465 env43946 == env43958) = true)

theorem identity43958 : scanCanonicalize (H12AffineFastState.compose env43958 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound43958 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env43959 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,4121,80,4420,4407,1,4535,4417,4421,4096,4572,16,4391,145,4161,319,81,80,6437,4117,4113,257,65,1,4609]

theorem envBound43959 : H12AffineFastState.Bounded env43959 := by
  intro p hp
  have h : env43959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43958_43959 : H12AffineEnvironment.transform 9 320 env43958 = env43959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env43958 == env43959) = true)

theorem identity43959 : scanCanonicalize (H12AffineFastState.compose env43959 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,16,18,20] rootPS)) = affineNative (2^(11+1) ^^^ 648) := by decide +kernel

theorem selectedBound43959 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,16,18,20] rootPS < 2^1333 := by decide +kernel

def env43960 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,648,657,80,972,959,1,831,969,973,648,852,16,943,145,713,319,81,80,2989,669,665,257,65,1,137]

theorem envBound43960 : H12AffineFastState.Bounded env43960 := by
  intro p hp
  have h : env43960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43959_43960 : H12AffineEnvironment.transform 11 648 env43959 = env43960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 648 env43959 == env43960) = true)

theorem identity43960 : scanCanonicalize (H12AffineFastState.compose env43960 (packedSelected [0,1,2,3,7,8,10,11,12,13,15,16,23,24] rootPS)) = affineNative (2^(8+1) ^^^ 413) := by decide +kernel

theorem selectedBound43960 : packedSelected [0,1,2,3,7,8,10,11,12,13,15,16,23,24] rootPS < 2^1333 := by decide +kernel

def env43961 : List Nat := [2,4,8,16,32,64,128,256,413,320,2048,277,268,80,81,34,1,162,84,80,277,201,16,50,145,340,319,81,80,2096,256,260,257,65,1,137]

theorem envBound43961 : H12AffineFastState.Bounded env43961 := by
  intro p hp
  have h : env43961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43960_43961 : H12AffineEnvironment.transform 8 413 env43960 = env43961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 413 env43960 == env43961) = true)

theorem identity43961 : scanCanonicalize (H12AffineFastState.compose env43961 (packedSelected [0,2,7,10,11,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 74) := by decide +kernel

theorem selectedBound43961 : packedSelected [0,2,7,10,11,15,17] rootPS < 2^1333 := by decide +kernel

def env43962 : List Nat := [2,4,8,16,32,64,128,256,413,320,74,277,268,80,81,34,1,162,84,80,277,201,16,50,145,340,319,81,80,122,256,260,257,65,1,137]

theorem envBound43962 : H12AffineFastState.Bounded env43962 := by
  intro p hp
  have h : env43962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43961_43962 : H12AffineEnvironment.transform 10 74 env43961 = env43962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 74 env43961 == env43962) = true)

theorem identity43962 : scanCanonicalize (H12AffineFastState.compose env43962 (packedSelected [0,5,7,8,10,11,12,13] rootPS)) = affineNative (2^(7+1) ^^^ 231) := by decide +kernel

theorem selectedBound43962 : packedSelected [0,5,7,8,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env43963 : List Nat := [2,4,8,16,32,64,128,231,122,167,74,242,235,80,81,34,1,162,84,80,242,201,16,50,145,179,216,81,80,122,231,227,230,65,1,137]

theorem envBound43963 : H12AffineFastState.Bounded env43963 := by
  intro p hp
  have h : env43963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43962_43963 : H12AffineEnvironment.transform 7 231 env43962 = env43963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 231 env43962 == env43963) = true)

theorem identity43963 : scanCanonicalize (H12AffineFastState.compose env43963 (packedSelected [2,3,8] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound43963 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env43964 : List Nat := [2,4,8,16,32,64,57,94,122,30,74,75,82,80,81,34,1,27,84,80,75,112,16,50,40,10,97,81,80,122,94,90,95,65,1,48]

theorem envBound43964 : H12AffineFastState.Bounded env43964 := by
  intro p hp
  have h : env43964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43963_43964 : H12AffineEnvironment.transform 6 57 env43963 = env43964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env43963 == env43964) = true)

theorem identity43964 : scanCanonicalize (H12AffineFastState.compose env43964 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound43964 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env43965 : List Nat := [2,4,8,16,11,64,18,94,81,30,74,75,82,80,81,9,1,27,84,80,75,91,16,25,3,10,74,81,80,81,94,90,95,65,1,27]

theorem envBound43965 : H12AffineFastState.Bounded env43965 := by
  intro p hp
  have h : env43965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43964_43965 : H12AffineEnvironment.transform 4 11 env43964 = env43965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env43964 == env43965) = true)

theorem identity43965 : scanCanonicalize (H12AffineFastState.compose env43965 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound43965 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43966 : List Nat := [2,4,8,11,11,64,9,69,74,5,74,75,73,75,74,9,1,0,79,75,75,64,11,2,3,10,74,74,75,74,69,65,68,65,1,0]

theorem envBound43966 : H12AffineFastState.Bounded env43966 := by
  intro p hp
  have h : env43966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43965_43966 : H12AffineEnvironment.transform 3 11 env43965 = env43966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env43965 == env43966) = true)

theorem identity43966 : scanCanonicalize (H12AffineFastState.compose env43966 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound43966 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43967 : List Nat := [2,4,5,6,6,64,4,69,71,5,71,70,68,70,71,4,1,0,66,70,70,64,6,2,3,7,71,71,70,71,69,65,68,65,1,0]

theorem envBound43967 : H12AffineFastState.Bounded env43967 := by
  intro p hp
  have h : env43967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43966_43967 : H12AffineEnvironment.transform 2 5 env43966 = env43967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env43966 == env43967) = true)

theorem identity43967 : scanCanonicalize (H12AffineFastState.compose env43967 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 6) := by decide +kernel

theorem selectedBound43967 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43968 : List Nat := [2,4,5,6,6,6,4,3,1,5,1,0,2,0,1,4,1,0,4,0,0,6,6,2,3,7,1,1,0,1,3,7,2,7,1,0]

theorem envBound43968 : H12AffineFastState.Bounded env43968 := by
  intro p hp
  have h : env43968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43967_43968 : H12AffineEnvironment.transform 5 6 env43967 = env43968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 6 env43967 == env43968) = true)

theorem identity43968 : scanCanonicalize (H12AffineFastState.compose env43968 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound43968 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43969 : List Nat := [2,0,1,2,2,2,0,3,1,1,1,0,2,0,1,0,1,0,0,0,0,2,2,2,3,3,1,1,0,1,3,3,2,3,1,0]

theorem envBound43969 : H12AffineFastState.Bounded env43969 := by
  intro p hp
  have h : env43969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43968_43969 : H12AffineEnvironment.transform 1 0 env43968 = env43969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env43968 == env43969) = true)

theorem identity43969 : scanCanonicalize (H12AffineFastState.compose env43969 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound43969 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env43970 : List Nat := [1,0,1,1,1,1,0,0,1,1,1,0,1,0,1,0,1,0,0,0,0,1,1,1,0,0,1,1,0,1,0,0,1,0,1,0]

theorem envBound43970 : H12AffineFastState.Bounded env43970 := by
  intro p hp
  have h : env43970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43969_43970 : H12AffineEnvironment.transform 0 1 env43969 = env43970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env43969 == env43970) = true)

def env43971 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74863,65665,4417,8540,4096,5276,74046,66896,13768,78895,1150,74815,1296,81227,8204,8200,257,74799,1345,5953]

theorem envBound43971 : H12AffineFastState.Bounded env43971 := by
  intro p hp
  have h : env43971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43944_43971 : H12AffineEnvironment.transform 17 65665 env43944 = env43971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env43944 == env43971) = true)

theorem identity43971 : scanCanonicalize (H12AffineFastState.compose env43971 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 311) := by decide +kernel

theorem selectedBound43971 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env43972 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,311,9560,438,4417,8540,4096,5276,8201,1127,13768,13592,1150,9480,1296,15484,8204,8200,257,9496,1345,5953]

theorem envBound43972 : H12AffineFastState.Bounded env43972 := by
  intro p hp
  have h : env43972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43971_43972 : H12AffineEnvironment.transform 15 311 env43971 = env43972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 311 env43971 == env43972) = true)

def env43973 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,24,1296,325,311,1344,438,4417,324,4096,5276,17,1127,5584,5376,1150,1296,1296,7268,20,16,257,1280,1345,5953]

theorem envBound43973 : H12AffineFastState.Bounded env43973 := by
  intro p hp
  have h : env43973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43972_43973 : H12AffineEnvironment.transform 12 24 env43972 = env43973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env43972 == env43973) = true)

theorem identity43973 : scanCanonicalize (H12AffineFastState.compose env43973 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 324) := by decide +kernel

theorem selectedBound43973 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env43974 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,324,24,1296,325,311,1344,438,5,324,324,1496,17,1127,1172,1092,1150,1296,1296,3360,20,16,257,1280,1345,1541]

theorem envBound43974 : H12AffineFastState.Bounded env43974 := by
  intro p hp
  have h : env43974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43973_43974 : H12AffineEnvironment.transform 11 324 env43973 = env43974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 324 env43973 == env43974) = true)

theorem identity43974 : scanCanonicalize (H12AffineFastState.compose env43974 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound43974 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env43975 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,324,24,277,325,311,325,438,5,324,324,477,17,98,145,65,123,277,277,2341,20,16,257,261,324,512]

theorem envBound43975 : H12AffineFastState.Bounded env43975 := by
  intro p hp
  have h : env43975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43974_43975 : H12AffineEnvironment.transform 9 5 env43974 = env43975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env43974 == env43975) = true)

theorem identity43975 : scanCanonicalize (H12AffineFastState.compose env43975 (packedSelected [2,5,8,13] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound43975 : packedSelected [2,5,8,13] rootPS < 2^1333 := by decide +kernel

def env43976 : List Nat := [2,4,8,16,32,64,128,252,512,5,2048,184,24,233,185,203,185,74,5,184,184,33,17,98,145,65,123,233,233,2265,20,16,253,249,184,512]

theorem envBound43976 : H12AffineFastState.Bounded env43976 := by
  intro p hp
  have h : env43976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43975_43976 : H12AffineEnvironment.transform 7 252 env43975 = env43976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env43975 == env43976) = true)

theorem identity43976 : scanCanonicalize (H12AffineFastState.compose env43976 (packedSelected [1,3,4,9,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 195) := by decide +kernel

theorem selectedBound43976 : packedSelected [1,3,4,9,10,11] rootPS < 2^1333 := by decide +kernel

def env43977 : List Nat := [2,4,8,16,32,64,128,252,512,5,195,184,24,233,185,203,185,74,5,184,184,33,17,98,145,65,123,233,233,26,20,16,253,249,184,512]

theorem envBound43977 : H12AffineFastState.Bounded env43977 := by
  intro p hp
  have h : env43977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43976_43977 : H12AffineEnvironment.transform 10 195 env43976 = env43977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 195 env43976 == env43977) = true)

theorem identity43977 : scanCanonicalize (H12AffineFastState.compose env43977 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(8+1) ^^^ 96) := by decide +kernel

theorem selectedBound43977 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env43978 : List Nat := [2,4,8,16,32,64,128,252,96,5,195,184,24,233,185,203,185,74,5,184,184,33,17,98,145,65,123,233,233,26,20,16,253,249,184,96]

theorem envBound43978 : H12AffineFastState.Bounded env43978 := by
  intro p hp
  have h : env43978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43977_43978 : H12AffineEnvironment.transform 8 96 env43977 = env43978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 96 env43977 == env43978) = true)

theorem identity43978 : scanCanonicalize (H12AffineFastState.compose env43978 (packedSelected [2,3,5,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound43978 : packedSelected [2,3,5,7,9] rootPS < 2^1333 := by decide +kernel

def env43979 : List Nat := [2,4,8,16,32,64,9,117,96,5,74,49,24,96,48,66,48,74,5,49,49,33,17,98,24,65,123,96,96,26,20,16,116,112,49,96]

theorem envBound43979 : H12AffineFastState.Bounded env43979 := by
  intro p hp
  have h : env43979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43978_43979 : H12AffineEnvironment.transform 6 9 env43978 = env43979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43978 == env43979) = true)

theorem identity43979 : scanCanonicalize (H12AffineFastState.compose env43979 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound43979 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env43980 : List Nat := [2,4,8,10,32,64,9,111,96,5,74,43,2,96,42,66,42,74,5,43,43,33,11,98,2,65,97,96,96,0,14,10,110,106,43,96]

theorem envBound43980 : H12AffineFastState.Bounded env43980 := by
  intro p hp
  have h : env43980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43979_43980 : H12AffineEnvironment.transform 3 10 env43979 = env43980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env43979 == env43980) = true)

def env43981 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,25,1296,324,311,1345,438,4417,325,4096,5276,16,1127,5585,5377,1150,1297,1296,7269,21,17,257,1281,1345,5953]

theorem envBound43981 : H12AffineFastState.Bounded env43981 := by
  intro p hp
  have h : env43981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43972_43981 : H12AffineEnvironment.transform 12 25 env43972 = env43981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env43972 == env43981) = true)

theorem identity43981 : scanCanonicalize (H12AffineFastState.compose env43981 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound43981 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env43982 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,25,1296,324,311,1345,438,321,325,0,1180,16,1127,1489,1281,1150,1297,1296,3173,21,17,257,1281,1345,1857]

theorem envBound43982 : H12AffineFastState.Bounded env43982 := by
  intro p hp
  have h : env43982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43981_43982 : H12AffineEnvironment.transform 11 0 env43981 = env43982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env43981 == env43982) = true)

theorem identity43982 : scanCanonicalize (H12AffineFastState.compose env43982 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,16,18,20] rootPS)) = affineNative (2^(9+1) ^^^ 968) := by decide +kernel

theorem selectedBound43982 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,16,18,20] rootPS < 2^1333 := by decide +kernel

def env43983 : List Nat := [2,4,8,16,32,64,128,256,512,968,2048,0,25,728,324,311,649,438,321,325,0,852,16,943,537,713,950,729,728,2989,21,17,257,713,649,137]

theorem envBound43983 : H12AffineFastState.Bounded env43983 := by
  intro p hp
  have h : env43983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43982_43983 : H12AffineEnvironment.transform 9 968 env43982 = env43983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 968 env43982 == env43983) = true)

theorem identity43983 : scanCanonicalize (H12AffineFastState.compose env43983 (packedSelected [0,1,2,3,7,8,10,11,12,13,15,16,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound43983 : packedSelected [0,1,2,3,7,8,10,11,12,13,15,16,23,24] rootPS < 2^1333 := by decide +kernel

def env43984 : List Nat := [2,4,8,16,32,64,128,21,512,733,2048,0,25,728,81,34,649,163,84,80,0,577,16,698,537,713,675,729,728,2744,21,17,20,713,649,137]

theorem envBound43984 : H12AffineFastState.Bounded env43984 := by
  intro p hp
  have h : env43984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43983_43984 : H12AffineEnvironment.transform 7 21 env43983 = env43984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env43983 == env43984) = true)

theorem identity43984 : scanCanonicalize (H12AffineFastState.compose env43984 (packedSelected [1,2,5,10,12,17] rootPS)) = affineNative (2^(10+1) ^^^ 185) := by decide +kernel

theorem selectedBound43984 : packedSelected [1,2,5,10,12,17] rootPS < 2^1333 := by decide +kernel

def env43985 : List Nat := [2,4,8,16,32,64,128,21,512,733,185,0,25,728,81,34,649,163,84,80,0,577,16,698,537,713,675,729,728,513,21,17,20,713,649,137]

theorem envBound43985 : H12AffineFastState.Bounded env43985 := by
  intro p hp
  have h : env43985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43984_43985 : H12AffineEnvironment.transform 10 185 env43984 = env43985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 185 env43984 == env43985) = true)

theorem identity43985 : scanCanonicalize (H12AffineFastState.compose env43985 (packedSelected [0,1,2,3,5,7,8,11] rootPS)) = affineNative (2^(8+1) ^^^ 232) := by decide +kernel

theorem selectedBound43985 : packedSelected [0,1,2,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env43986 : List Nat := [2,4,8,16,32,64,128,21,232,53,185,0,25,48,81,34,97,163,84,80,0,169,16,82,241,33,75,49,48,233,21,17,20,33,97,137]

theorem envBound43986 : H12AffineFastState.Bounded env43986 := by
  intro p hp
  have h : env43986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43985_43986 : H12AffineEnvironment.transform 8 232 env43985 = env43986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 232 env43985 == env43986) = true)

theorem identity43986 : scanCanonicalize (H12AffineFastState.compose env43986 (packedSelected [2,3,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound43986 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env43987 : List Nat := [2,4,8,11,32,64,128,14,232,46,162,0,2,43,74,34,97,163,79,75,0,169,11,73,234,33,75,42,43,233,14,10,15,33,97,137]

theorem envBound43987 : H12AffineFastState.Bounded env43987 := by
  intro p hp
  have h : env43987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43986_43987 : H12AffineEnvironment.transform 3 11 env43986 = env43987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env43986 == env43987) = true)

theorem identity43987 : scanCanonicalize (H12AffineFastState.compose env43987 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound43987 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env43988 : List Nat := [2,4,8,11,32,11,128,14,163,46,162,0,2,43,1,34,42,163,4,0,0,169,11,2,161,33,0,42,43,162,14,10,15,33,42,137]

theorem envBound43988 : H12AffineFastState.Bounded env43988 := by
  intro p hp
  have h : env43988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43987_43988 : H12AffineEnvironment.transform 5 11 env43987 = env43988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env43987 == env43988) = true)

theorem identity43988 : scanCanonicalize (H12AffineFastState.compose env43988 (packedSelected [0,1,4] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound43988 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env43989 : List Nat := [2,4,8,11,12,11,128,14,143,2,142,0,2,7,1,14,6,143,4,0,0,133,11,2,141,13,0,6,7,142,14,10,15,13,6,137]

theorem envBound43989 : H12AffineFastState.Bounded env43989 := by
  intro p hp
  have h : env43989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43988_43989 : H12AffineEnvironment.transform 4 12 env43988 = env43989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env43988 == env43989) = true)

theorem identity43989 : scanCanonicalize (H12AffineFastState.compose env43989 (packedSelected [1,8] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound43989 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env43990 : List Nat := [2,4,8,11,12,11,15,14,0,2,1,0,2,7,1,14,6,0,4,0,0,10,11,2,2,13,0,6,7,1,14,10,15,13,6,6]

theorem envBound43990 : H12AffineFastState.Bounded env43990 := by
  intro p hp
  have h : env43990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43989_43990 : H12AffineEnvironment.transform 6 15 env43989 = env43990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env43989 == env43990) = true)

def env43991 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74863,262144,4416,8541,4096,5276,74047,66896,13769,78895,328959,74814,1296,81226,8205,8201,257,74799,1345,5952]

theorem envBound43991 : H12AffineFastState.Bounded env43991 := by
  intro p hp
  have h : env43991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43943_43991 : H12AffineEnvironment.transform 13 1297 env43943 = env43991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env43943 == env43991) = true)

def env43992 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74863,65664,4416,8541,4096,5276,74047,66896,13769,78895,1151,74814,1296,81226,8205,8201,257,74799,1345,5952]

theorem envBound43992 : H12AffineFastState.Bounded env43992 := by
  intro p hp
  have h : env43992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43991_43992 : H12AffineEnvironment.transform 17 65664 env43991 = env43992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env43991 == env43992) = true)

theorem identity43992 : scanCanonicalize (H12AffineFastState.compose env43992 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9278) := by decide +kernel

theorem selectedBound43992 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env43993 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,9278,81,9406,4416,8541,4096,5276,1281,8558,13769,4113,1151,0,1296,6516,8205,8201,257,17,1345,5952]

theorem envBound43993 : H12AffineFastState.Bounded env43993 := by
  intro p hp
  have h : env43993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43992_43993 : H12AffineEnvironment.transform 15 9278 env43992 = env43993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9278 env43992 == env43993) = true)

def env43994 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,1,8540,8494,81,8622,4416,8541,4096,4492,17,8558,12505,4113,367,0,0,6516,8205,8201,257,17,81,4688]

theorem envBound43994 : H12AffineFastState.Bounded env43994 := by
  intro p hp
  have h : env43994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43993_43994 : H12AffineEnvironment.transform 9 272 env43993 = env43994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env43993 == env43994) = true)

theorem identity43994 : scanCanonicalize (H12AffineFastState.compose env43994 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 73) := by decide +kernel

theorem selectedBound43994 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env43995 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,73,1,277,359,81,487,4416,276,4096,4492,17,295,4240,4113,367,0,0,6516,68,64,257,17,81,4688]

theorem envBound43995 : H12AffineFastState.Bounded env43995 := by
  intro p hp
  have h : env43995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43994_43995 : H12AffineEnvironment.transform 12 73 env43994 = env43995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env43994 == env43995) = true)

theorem identity43995 : scanCanonicalize (H12AffineFastState.compose env43995 (packedSelected [0,2,3,5,7,10,11,12,15,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 674) := by decide +kernel

theorem selectedBound43995 : packedSelected [0,2,3,5,7,10,11,12,15,17,18,20] rootPS < 2^1333 := by decide +kernel

def env43996 : List Nat := [2,4,8,16,32,64,128,256,512,272,674,4096,73,1,277,359,81,487,4416,276,4096,4492,17,295,4240,4113,367,0,0,5078,68,64,257,17,81,4688]

theorem envBound43996 : H12AffineFastState.Bounded env43996 := by
  intro p hp
  have h : env43996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43995_43996 : H12AffineEnvironment.transform 10 674 env43995 = env43996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 674 env43995 == env43996) = true)

theorem identity43996 : scanCanonicalize (H12AffineFastState.compose env43996 (packedSelected [1,4,5,8,9,13,16,28] rootPS)) = affineNative (2^(11+1) ^^^ 560) := by decide +kernel

theorem selectedBound43996 : packedSelected [1,4,5,8,9,13,16,28] rootPS < 2^1333 := by decide +kernel

def env43997 : List Nat := [2,4,8,16,32,64,128,256,512,272,674,560,73,1,277,359,81,487,880,276,560,956,17,295,672,545,367,0,0,486,68,64,257,17,81,96]

theorem envBound43997 : H12AffineFastState.Bounded env43997 := by
  intro p hp
  have h : env43997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43996_43997 : H12AffineEnvironment.transform 11 560 env43996 = env43997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 560 env43996 == env43997) = true)

theorem identity43997 : scanCanonicalize (H12AffineFastState.compose env43997 (packedSelected [0,1,2,7,8,11,12,13,15] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound43997 : packedSelected [0,1,2,7,8,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env43998 : List Nat := [2,4,8,16,32,64,128,256,48,272,146,0,73,1,277,359,81,487,320,276,0,396,17,295,144,17,367,0,0,486,68,64,257,17,81,96]

theorem envBound43998 : H12AffineFastState.Bounded env43998 := by
  intro p hp
  have h : env43998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43997_43998 : H12AffineEnvironment.transform 8 48 env43997 = env43998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env43997 == env43998) = true)

theorem identity43998 : scanCanonicalize (H12AffineFastState.compose env43998 (packedSelected [1,3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 9) := by decide +kernel

theorem selectedBound43998 : packedSelected [1,3,5,10] rootPS < 2^1333 := by decide +kernel

def env43999 : List Nat := [2,4,8,16,32,64,128,9,48,25,146,0,73,1,28,110,81,238,73,29,0,133,17,46,144,17,102,0,0,239,68,64,8,17,81,96]

theorem envBound43999 : H12AffineFastState.Bounded env43999 := by
  intro p hp
  have h : env43999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43998_43999 : H12AffineEnvironment.transform 7 9 env43998 = env43999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 9 env43998 == env43999) = true)

theorem identity43999 : scanCanonicalize (H12AffineFastState.compose env43999 (packedSelected [2,4,8,9,11] rootPS)) = affineNative (2^(6+1) ^^^ 117) := by decide +kernel

theorem selectedBound43999 : packedSelected [2,4,8,9,11] rootPS < 2^1333 := by decide +kernel

def env44000 : List Nat := [2,4,8,16,32,64,117,9,48,25,103,0,73,1,28,110,81,27,73,29,0,112,17,46,101,17,102,0,0,26,68,64,8,17,81,96]

theorem envBound44000 : H12AffineFastState.Bounded env44000 := by
  intro p hp
  have h : env44000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43999_44000 : H12AffineEnvironment.transform 6 117 env43999 = env44000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 117 env43999 == env44000) = true)

theorem identity44000 : scanCanonicalize (H12AffineFastState.compose env44000 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound44000 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env44001 : List Nat := [2,4,8,16,32,10,63,9,48,25,45,0,3,1,28,36,27,27,3,29,0,58,17,46,47,17,44,0,0,26,14,10,8,17,27,42]

theorem envBound44001 : H12AffineFastState.Bounded env44001 := by
  intro p hp
  have h : env44001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44000_44001 : H12AffineEnvironment.transform 5 10 env44000 = env44001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env44000 == env44001) = true)

theorem identity44001 : scanCanonicalize (H12AffineFastState.compose env44001 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound44001 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44002 : List Nat := [2,4,8,16,16,10,15,9,0,25,29,0,3,1,28,20,27,27,3,29,0,10,17,30,31,17,28,0,0,26,14,10,8,17,27,26]

theorem envBound44002 : H12AffineFastState.Bounded env44002 := by
  intro p hp
  have h : env44002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44001_44002 : H12AffineEnvironment.transform 4 16 env44001 = env44002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env44001 == env44002) = true)

theorem identity44002 : scanCanonicalize (H12AffineFastState.compose env44002 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound44002 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env44003 : List Nat := [2,4,8,12,12,10,15,9,0,5,1,0,3,1,0,8,7,7,3,1,0,10,13,2,3,13,0,0,0,6,14,10,8,13,7,6]

theorem envBound44003 : H12AffineFastState.Bounded env44003 := by
  intro p hp
  have h : env44003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44002_44003 : H12AffineEnvironment.transform 3 12 env44002 = env44003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env44002 == env44003) = true)

theorem identity44003 : scanCanonicalize (H12AffineFastState.compose env44003 (packedSelected [0,1,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound44003 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env44004 : List Nat := [2,3,8,11,11,10,8,9,0,2,1,0,3,1,0,8,0,0,3,1,0,10,10,2,3,10,0,0,0,1,9,10,8,10,0,1]

theorem envBound44004 : H12AffineFastState.Bounded env44004 := by
  intro p hp
  have h : env44004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44003_44004 : H12AffineEnvironment.transform 1 3 env44003 = env44004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env44003 == env44004) = true)

theorem identity44004 : scanCanonicalize (H12AffineFastState.compose env44004 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound44004 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44005 : List Nat := [1,0,8,8,8,9,8,9,0,1,1,0,0,1,0,8,0,0,0,1,0,9,9,1,0,9,0,0,0,1,9,9,8,9,0,1]

theorem envBound44005 : H12AffineFastState.Bounded env44005 := by
  intro p hp
  have h : env44005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44004_44005 : H12AffineEnvironment.transform 0 1 env44004 = env44005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env44004 == env44005) = true)

theorem identity44005 : scanCanonicalize (H12AffineFastState.compose env44005 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound44005 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44006 : List Nat := [1,0,1,1,1,0,1,0,0,1,1,0,0,1,0,1,0,0,0,1,0,0,0,1,0,0,0,0,0,1,0,0,1,0,0,1]

theorem envBound44006 : H12AffineFastState.Bounded env44006 := by
  intro p hp
  have h : env44006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44005_44006 : H12AffineEnvironment.transform 2 1 env44005 = env44006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env44005 == env44006) = true)

def env44007 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,0,8540,8495,81,8623,4416,8541,4096,4493,16,8558,12504,4113,366,0,1,6516,8205,8201,257,17,80,4689]

theorem envBound44007 : H12AffineFastState.Bounded env44007 := by
  intro p hp
  have h : env44007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43993_44007 : H12AffineEnvironment.transform 9 273 env43993 = env44007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env43993 == env44007) = true)

theorem identity44007 : scanCanonicalize (H12AffineFastState.compose env44007 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound44007 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env44008 : List Nat := [2,4,8,16,32,64,128,20,512,5,2048,4096,8192,0,8264,8251,81,8379,4180,8265,4096,4249,16,8314,12504,4113,122,0,1,6240,8205,8201,21,17,80,4689]

theorem envBound44008 : H12AffineFastState.Bounded env44008 := by
  intro p hp
  have h : env44008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44007_44008 : H12AffineEnvironment.transform 7 20 env44007 = env44008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env44007 == env44008) = true)

theorem identity44008 : scanCanonicalize (H12AffineFastState.compose env44008 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound44008 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env44009 : List Nat := [2,4,8,16,32,64,128,20,512,5,2048,81,8192,0,8264,8251,81,8379,5,8265,81,200,16,8314,8329,64,122,0,1,2097,8205,8201,21,17,80,512]

theorem envBound44009 : H12AffineFastState.Bounded env44009 := by
  intro p hp
  have h : env44009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44008_44009 : H12AffineEnvironment.transform 11 81 env44008 = env44009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env44008 == env44009) = true)

theorem identity44009 : scanCanonicalize (H12AffineFastState.compose env44009 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound44009 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env44010 : List Nat := [2,4,8,16,32,17,128,20,512,5,2048,0,8192,0,8217,8251,0,8379,5,8216,0,153,16,8235,8329,17,43,0,1,2097,8205,8201,21,17,1,512]

theorem envBound44010 : H12AffineFastState.Bounded env44010 := by
  intro p hp
  have h : env44010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44009_44010 : H12AffineEnvironment.transform 5 17 env44009 = env44010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env44009 == env44010) = true)

theorem identity44010 : scanCanonicalize (H12AffineFastState.compose env44010 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 697) := by decide +kernel

theorem selectedBound44010 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44011 : List Nat := [2,4,8,16,32,17,128,20,512,5,697,0,8192,0,8217,8251,0,8379,5,8216,0,153,16,8235,8329,17,43,0,1,648,8205,8201,21,17,1,512]

theorem envBound44011 : H12AffineFastState.Bounded env44011 := by
  intro p hp
  have h : env44011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44010_44011 : H12AffineEnvironment.transform 10 697 env44010 = env44011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 697 env44010 == env44011) = true)

theorem identity44011 : scanCanonicalize (H12AffineFastState.compose env44011 (packedSelected [3,8] rootPS)) = affineNative (2^(12+1) ^^^ 50) := by decide +kernel

theorem selectedBound44011 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env44012 : List Nat := [2,4,8,16,32,17,128,20,512,5,697,0,50,0,43,9,0,137,5,42,0,153,16,25,187,17,43,0,1,648,63,59,21,17,1,512]

theorem envBound44012 : H12AffineFastState.Bounded env44012 := by
  intro p hp
  have h : env44012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44011_44012 : H12AffineEnvironment.transform 12 50 env44011 = env44012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 50 env44011 == env44012) = true)

theorem identity44012 : scanCanonicalize (H12AffineFastState.compose env44012 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 163) := by decide +kernel

theorem selectedBound44012 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env44013 : List Nat := [2,4,8,16,32,17,128,20,163,5,26,0,50,0,43,9,0,137,5,42,0,153,16,25,187,17,43,0,1,43,63,59,21,17,1,163]

theorem envBound44013 : H12AffineFastState.Bounded env44013 := by
  intro p hp
  have h : env44013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44012_44013 : H12AffineEnvironment.transform 8 163 env44012 = env44013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 163 env44012 == env44013) = true)

theorem identity44013 : scanCanonicalize (H12AffineFastState.compose env44013 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound44013 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env44014 : List Nat := [2,4,8,16,32,17,18,20,49,5,26,0,50,0,43,9,0,27,5,42,0,11,16,25,41,17,43,0,1,43,63,59,21,17,1,49]

theorem envBound44014 : H12AffineFastState.Bounded env44014 := by
  intro p hp
  have h : env44014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44013_44014 : H12AffineEnvironment.transform 6 18 env44013 = env44014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env44013 == env44014) = true)

theorem identity44014 : scanCanonicalize (H12AffineFastState.compose env44014 (packedSelected [3,4] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound44014 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env44015 : List Nat := [2,4,8,16,16,17,18,20,1,5,26,0,2,0,27,9,0,27,5,26,0,11,16,25,25,17,27,0,1,27,15,11,21,17,1,1]

theorem envBound44015 : H12AffineFastState.Bounded env44015 := by
  intro p hp
  have h : env44015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44014_44015 : H12AffineEnvironment.transform 4 16 env44014 = env44015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env44014 == env44015) = true)

def env44016 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74863,65665,4416,8541,4096,5276,74047,66896,13769,78895,1150,74814,1296,81226,8205,8201,257,74799,1345,5952]

theorem envBound44016 : H12AffineFastState.Bounded env44016 := by
  intro p hp
  have h : env44016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43991_44016 : H12AffineEnvironment.transform 17 65665 env43991 = env44016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env43991 == env44016) = true)

theorem identity44016 : scanCanonicalize (H12AffineFastState.compose env44016 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12671) := by decide +kernel

theorem selectedBound44016 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env44017 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,12671,5392,12798,4416,8541,4096,5276,4160,13359,13769,1360,1150,5441,1296,3125,8205,8201,257,5456,1345,5952]

theorem envBound44017 : H12AffineFastState.Bounded env44017 := by
  intro p hp
  have h : env44017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44016_44017 : H12AffineEnvironment.transform 15 12671 env44016 = env44017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12671 env44016 == env44017) = true)

def env44018 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1297,8540,8495,1344,8622,272,8541,80,1228,16,9343,9625,1360,1150,1297,1296,3125,8205,8201,257,1280,1345,1808]

theorem envBound44018 : H12AffineFastState.Bounded env44018 := by
  intro p hp
  have h : env44018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44017_44018 : H12AffineEnvironment.transform 11 80 env44017 = env44018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env44017 == env44018) = true)

theorem identity44018 : scanCanonicalize (H12AffineFastState.compose env44018 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound44018 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env44019 : List Nat := [2,4,8,16,32,64,128,256,512,5,2048,80,8192,276,8540,8495,325,8622,272,8541,80,201,16,8314,8604,341,123,276,277,2096,8205,8201,257,261,324,789]

theorem envBound44019 : H12AffineFastState.Bounded env44019 := by
  intro p hp
  have h : env44019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44018_44019 : H12AffineEnvironment.transform 9 5 env44018 = env44019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env44018 == env44019) = true)

theorem identity44019 : scanCanonicalize (H12AffineFastState.compose env44019 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound44019 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env44020 : List Nat := [2,4,8,16,32,64,128,21,512,5,2048,80,8192,1,8265,8250,80,8379,5,8264,80,201,16,8314,8329,64,123,1,0,2096,8205,8201,20,16,81,512]

theorem envBound44020 : H12AffineFastState.Bounded env44020 := by
  intro p hp
  have h : env44020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44019_44020 : H12AffineEnvironment.transform 7 21 env44019 = env44020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env44019 == env44020) = true)

theorem identity44020 : scanCanonicalize (H12AffineFastState.compose env44020 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound44020 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env44021 : List Nat := [2,4,8,16,32,17,128,21,512,5,2048,1,8192,1,8216,8250,1,8379,5,8217,1,152,16,8235,8329,17,42,1,0,2096,8205,8201,20,16,0,512]

theorem envBound44021 : H12AffineFastState.Bounded env44021 := by
  intro p hp
  have h : env44021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44020_44021 : H12AffineEnvironment.transform 5 17 env44020 = env44021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env44020 == env44021) = true)

theorem identity44021 : scanCanonicalize (H12AffineFastState.compose env44021 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 697) := by decide +kernel

theorem selectedBound44021 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44022 : List Nat := [2,4,8,16,32,17,128,21,512,5,697,1,8192,1,8216,8250,1,8379,5,8217,1,152,16,8235,8329,17,42,1,0,649,8205,8201,20,16,0,512]

theorem envBound44022 : H12AffineFastState.Bounded env44022 := by
  intro p hp
  have h : env44022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44021_44022 : H12AffineEnvironment.transform 10 697 env44021 = env44022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 697 env44021 == env44022) = true)

theorem identity44022 : scanCanonicalize (H12AffineFastState.compose env44022 (packedSelected [3,8] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound44022 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env44023 : List Nat := [2,4,8,16,32,17,128,21,1,5,184,1,8192,1,8216,8250,1,8379,5,8217,1,152,16,8235,8329,17,42,1,0,136,8205,8201,20,16,0,1]

theorem envBound44023 : H12AffineFastState.Bounded env44023 := by
  intro p hp
  have h : env44023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44022_44023 : H12AffineEnvironment.transform 8 1 env44022 = env44023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env44022 == env44023) = true)

theorem identity44023 : scanCanonicalize (H12AffineFastState.compose env44023 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 144) := by decide +kernel

theorem selectedBound44023 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env44024 : List Nat := [2,4,8,16,32,17,128,21,1,5,184,1,144,1,136,170,1,43,5,137,1,152,16,187,25,17,42,1,0,136,157,153,20,16,0,1]

theorem envBound44024 : H12AffineFastState.Bounded env44024 := by
  intro p hp
  have h : env44024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44023_44024 : H12AffineEnvironment.transform 12 144 env44023 = env44024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 144 env44023 == env44024) = true)

theorem identity44024 : scanCanonicalize (H12AffineFastState.compose env44024 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound44024 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env44025 : List Nat := [2,4,8,16,32,17,19,21,1,5,43,1,3,1,27,57,1,43,5,26,1,11,16,40,25,17,42,1,0,27,14,10,20,16,0,1]

theorem envBound44025 : H12AffineFastState.Bounded env44025 := by
  intro p hp
  have h : env44025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44024_44025 : H12AffineEnvironment.transform 6 19 env44024 = env44025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env44024 == env44025) = true)

theorem identity44025 : scanCanonicalize (H12AffineFastState.compose env44025 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound44025 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env44026 : List Nat := [2,4,8,16,10,17,19,21,1,5,1,1,3,1,27,19,1,1,5,26,1,11,16,2,25,17,0,1,0,27,14,10,20,16,0,1]

theorem envBound44026 : H12AffineFastState.Bounded env44026 := by
  intro p hp
  have h : env44026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44025_44026 : H12AffineEnvironment.transform 4 10 env44025 = env44026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env44025 == env44026) = true)

theorem identity44026 : scanCanonicalize (H12AffineFastState.compose env44026 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound44026 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env44027 : List Nat := [2,4,8,10,10,11,9,15,1,5,1,1,3,1,1,9,1,1,5,0,1,11,10,2,3,11,0,1,0,1,14,10,14,10,0,1]

theorem envBound44027 : H12AffineFastState.Bounded env44027 := by
  intro p hp
  have h : env44027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44026_44027 : H12AffineEnvironment.transform 3 10 env44026 = env44027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env44026 == env44027) = true)

theorem identity44027 : scanCanonicalize (H12AffineFastState.compose env44027 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound44027 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44028 : List Nat := [2,4,5,7,7,6,4,2,1,5,1,1,3,1,1,4,1,1,5,0,1,6,7,2,3,6,0,1,0,1,3,7,3,7,0,1]

theorem envBound44028 : H12AffineFastState.Bounded env44028 := by
  intro p hp
  have h : env44028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44027_44028 : H12AffineEnvironment.transform 2 5 env44027 = env44028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env44027 == env44028) = true)

def env44029 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1297,8540,8494,1345,8623,273,8541,81,1229,17,9342,9624,1360,1150,1296,1296,3125,8205,8201,257,1281,1345,1809]

theorem envBound44029 : H12AffineFastState.Bounded env44029 := by
  intro p hp
  have h : env44029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44017_44029 : H12AffineEnvironment.transform 11 81 env44017 = env44029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env44017 == env44029) = true)

theorem identity44029 : scanCanonicalize (H12AffineFastState.compose env44029 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 1369) := by decide +kernel

theorem selectedBound44029 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env44030 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,1369,1297,1029,1143,1345,1270,273,1028,81,1229,17,295,193,1360,1150,1296,1296,3125,1364,1360,257,1281,1345,1809]

theorem envBound44030 : H12AffineFastState.Bounded env44030 := by
  intro p hp
  have h : env44030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44029_44030 : H12AffineEnvironment.transform 12 1369 env44029 = env44030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1369 env44029 == env44030) = true)

theorem identity44030 : scanCanonicalize (H12AffineFastState.compose env44030 (packedSelected [0,2,3,5,7,10,11,12,15,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 675) := by decide +kernel

theorem selectedBound44030 : packedSelected [0,2,3,5,7,10,11,12,15,17,18,20] rootPS < 2^1333 := by decide +kernel

def env44031 : List Nat := [2,4,8,16,32,64,128,256,512,1024,675,81,1369,1297,1029,1143,1345,1270,273,1028,81,1229,17,295,193,1360,1150,1296,1296,1686,1364,1360,257,1281,1345,1809]

theorem envBound44031 : H12AffineFastState.Bounded env44031 := by
  intro p hp
  have h : env44031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44030_44031 : H12AffineEnvironment.transform 10 675 env44030 = env44031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 675 env44030 == env44031) = true)

theorem identity44031 : scanCanonicalize (H12AffineFastState.compose env44031 (packedSelected [1,4,5,8,9,13,16,28] rootPS)) = affineNative (2^(9+1) ^^^ 880) := by decide +kernel

theorem selectedBound44031 : packedSelected [1,4,5,8,9,13,16,28] rootPS < 2^1333 := by decide +kernel

def env44032 : List Nat := [2,4,8,16,32,64,128,256,512,880,675,81,553,609,885,775,561,902,273,884,81,957,17,295,193,544,782,608,608,486,548,544,257,625,561,97]

theorem envBound44032 : H12AffineFastState.Bounded env44032 := by
  intro p hp
  have h : env44032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44031_44032 : H12AffineEnvironment.transform 9 880 env44031 = env44032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 880 env44031 == env44032) = true)

theorem identity44032 : scanCanonicalize (H12AffineFastState.compose env44032 (packedSelected [0,2,3,4,7,8,9,11,16,17] rootPS)) = affineNative (2^(8+1) ^^^ 217) := by decide +kernel

theorem selectedBound44032 : packedSelected [0,2,3,4,7,8,9,11,16,17] rootPS < 2^1333 := by decide +kernel

def env44033 : List Nat := [2,4,8,16,32,64,128,256,217,425,122,81,240,184,428,478,232,351,273,429,81,356,17,295,193,249,471,185,185,486,253,249,257,168,232,97]

theorem envBound44033 : H12AffineFastState.Bounded env44033 := by
  intro p hp
  have h : env44033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44032_44033 : H12AffineEnvironment.transform 8 217 env44032 = env44033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env44032 == env44033) = true)

theorem identity44033 : scanCanonicalize (H12AffineFastState.compose env44033 (packedSelected [1,4,8,9,11,12,13] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound44033 : packedSelected [1,4,8,9,11,12,13] rootPS < 2^1333 := by decide +kernel

def env44034 : List Nat := [2,4,8,16,32,64,128,21,217,188,122,81,240,184,185,203,232,74,4,184,81,113,17,50,193,249,194,185,185,243,253,249,20,168,232,97]

theorem envBound44034 : H12AffineFastState.Bounded env44034 := by
  intro p hp
  have h : env44034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44033_44034 : H12AffineEnvironment.transform 7 21 env44033 = env44034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env44033 == env44034) = true)

theorem identity44034 : scanCanonicalize (H12AffineFastState.compose env44034 (packedSelected [7,9] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound44034 : packedSelected [7,9] rootPS < 2^1333 := by decide +kernel

def env44035 : List Nat := [2,4,8,16,16,64,128,21,217,140,74,81,192,136,137,203,216,74,4,136,81,65,17,2,193,201,194,137,137,195,205,201,20,152,216,81]

theorem envBound44035 : H12AffineFastState.Bounded env44035 := by
  intro p hp
  have h : env44035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44034_44035 : H12AffineEnvironment.transform 4 16 env44034 = env44035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env44034 == env44035) = true)

theorem identity44035 : scanCanonicalize (H12AffineFastState.compose env44035 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 67) := by decide +kernel

theorem selectedBound44035 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env44036 : List Nat := [2,4,8,16,16,64,67,21,26,79,74,81,3,75,74,8,27,74,4,75,81,65,17,2,2,10,1,74,74,0,14,10,20,91,27,81]

theorem envBound44036 : H12AffineFastState.Bounded env44036 := by
  intro p hp
  have h : env44036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44035_44036 : H12AffineEnvironment.transform 6 67 env44035 = env44036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 67 env44035 == env44036) = true)

theorem identity44036 : scanCanonicalize (H12AffineFastState.compose env44036 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound44036 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44037 : List Nat := [2,4,8,11,11,64,67,14,1,79,74,74,3,75,74,8,0,74,4,75,74,65,10,2,2,10,1,74,74,0,14,10,15,64,0,74]

theorem envBound44037 : H12AffineFastState.Bounded env44037 := by
  intro p hp
  have h : env44037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44036_44037 : H12AffineEnvironment.transform 3 11 env44036 = env44037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env44036 == env44037) = true)

theorem identity44037 : scanCanonicalize (H12AffineFastState.compose env44037 (packedSelected [0,1,4] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound44037 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env44038 : List Nat := [2,4,8,11,11,13,14,14,1,2,7,7,3,6,7,8,0,7,4,6,7,12,10,2,2,10,1,7,7,0,14,10,15,13,0,7]

theorem envBound44038 : H12AffineFastState.Bounded env44038 := by
  intro p hp
  have h : env44038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44037_44038 : H12AffineEnvironment.transform 5 13 env44037 = env44038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env44037 == env44038) = true)

theorem identity44038 : scanCanonicalize (H12AffineFastState.compose env44038 (packedSelected [0,1,7] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound44038 : packedSelected [0,1,7] rootPS < 2^1333 := by decide +kernel

def env44039 : List Nat := [2,2,8,11,11,11,8,8,1,2,1,1,3,0,1,8,0,1,2,0,1,10,10,2,2,10,1,1,1,0,8,10,9,11,0,1]

theorem envBound44039 : H12AffineFastState.Bounded env44039 := by
  intro p hp
  have h : env44039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44038_44039 : H12AffineEnvironment.transform 1 2 env44038 = env44039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env44038 == env44039) = true)

def env44040 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,16777216,533641,672785,17245633,148800,545089,96347,16876545,16949354,257,676881,1344,525824]

theorem envBound44040 : H12AffineFastState.Bounded env44040 := by
  intro p hp
  have h : env44040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43383_44040 : H12AffineEnvironment.transform 26 17245633 env43383 = env44040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env43383 == env44040) = true)

theorem identity44040 : scanCanonicalize (H12AffineFastState.compose env44040 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(18+1) ^^^ 95615) := by decide +kernel

theorem selectedBound44040 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env44041 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95615,32769,4096,61649,147521,16777216,86518,209262,17245633,148800,74814,96347,16876545,16949354,257,205166,1344,95103]

theorem envBound44041 : H12AffineFastState.Bounded env44041 := by
  intro p hp
  have h : env44041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44040_44041 : H12AffineEnvironment.transform 18 95615 env44040 = env44041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 95615 env44040 == env44041) = true)

def env44042 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95615,32769,4096,61649,147521,284032,86518,209262,225345,148800,74814,96347,381313,456170,257,205166,1344,95103]

theorem envBound44042 : H12AffineFastState.Bounded env44042 := by
  intro p hp
  have h : env44042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44041_44042 : H12AffineEnvironment.transform 23 284032 env44041 = env44042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284032 env44041 == env44042) = true)

def env44043 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16464,262144,95615,32769,4096,61649,17,284032,86518,94526,77841,1296,74814,96347,381313,308666,257,90430,1344,95103]

theorem envBound44043 : H12AffineFastState.Bounded env44043 := by
  intro p hp
  have h : env44043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44042_44043 : H12AffineEnvironment.transform 16 16464 env44042 = env44043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16464 env44042 == env44043) = true)

def env44044 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1344,262144,77935,32769,4096,46529,17,266384,70886,78894,77841,1296,74814,81227,365713,308666,257,74798,1344,79471]

theorem envBound44044 : H12AffineFastState.Bounded env44044 := by
  intro p hp
  have h : env44044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44043_44044 : H12AffineEnvironment.transform 13 1296 env44043 = env44044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env44043 == env44044) = true)

theorem identity44044 : scanCanonicalize (H12AffineFastState.compose env44044 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32883) := by decide +kernel

theorem selectedBound44044 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env44045 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,32883,1344,262144,45084,32769,4096,46529,17,266384,38037,46173,45154,1296,42061,48440,267490,308666,257,42077,1344,46620]

theorem envBound44045 : H12AffineFastState.Bounded env44045 := by
  intro p hp
  have h : env44045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44044_44045 : H12AffineEnvironment.transform 15 32883 env44044 = env44045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32883 env44044 == env44045) = true)

def env44046 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32883,1344,262144,42332,32769,1344,41089,17,263632,33237,41245,42274,1296,42061,43128,262562,303354,257,42077,1344,41820]

theorem envBound44046 : H12AffineFastState.Bounded env44046 := by
  intro p hp
  have h : env44046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44045_44046 : H12AffineEnvironment.transform 11 1344 env44045 = env44046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env44045 == env44046) = true)

theorem identity44046 : scanCanonicalize (H12AffineFastState.compose env44046 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 9406) := by decide +kernel

theorem selectedBound44046 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env44047 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32883,1344,9406,42332,32769,1344,41089,17,8558,33237,41245,42274,1296,42061,43128,9500,33860,257,42077,1344,41820]

theorem envBound44047 : H12AffineFastState.Bounded env44047 := by
  intro p hp
  have h : env44047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44046_44047 : H12AffineEnvironment.transform 17 9406 env44046 = env44047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 9406 env44046 == env44047) = true)

theorem identity44047 : scanCanonicalize (H12AffineFastState.compose env44047 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound44047 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env44048 : List Nat := [2,4,8,16,32,64,128,256,292,1024,2048,1344,8192,1296,32768,32883,1344,9406,42332,32769,1344,41089,17,8558,33237,41245,42274,1296,42061,43128,9500,33860,257,42077,1344,41080]

theorem envBound44048 : H12AffineFastState.Bounded env44048 := by
  intro p hp
  have h : env44048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44047_44048 : H12AffineEnvironment.transform 8 292 env44047 = env44048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env44047 == env44048) = true)

def env44049 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32883,1344,262144,42333,32769,1345,41088,17,263633,33236,41244,42275,1296,42061,43129,262563,303355,257,42077,1344,41821]

theorem envBound44049 : H12AffineFastState.Bounded env44049 := by
  intro p hp
  have h : env44049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44045_44049 : H12AffineEnvironment.transform 11 1345 env44045 = env44049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env44045 == env44049) = true)

theorem identity44049 : scanCanonicalize (H12AffineFastState.compose env44049 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 9292) := by decide +kernel

theorem selectedBound44049 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env44050 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,9292,9279,1344,262144,273,9293,1345,1228,17,263633,9624,1360,367,1296,1,3125,262563,263351,257,17,1344,1809]

theorem envBound44050 : H12AffineFastState.Bounded env44050 := by
  intro p hp
  have h : env44050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44049_44050 : H12AffineEnvironment.transform 14 9292 env44049 = env44050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9292 env44049 == env44050) = true)

theorem identity44050 : scanCanonicalize (H12AffineFastState.compose env44050 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound44050 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env44051 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,80,8192,1,8541,8494,81,262144,273,8540,80,477,17,262336,8329,65,367,1,1,2340,262563,262566,257,17,81,512]

theorem envBound44051 : H12AffineFastState.Bounded env44051 := by
  intro p hp
  have h : env44051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44050_44051 : H12AffineEnvironment.transform 9 273 env44050 = env44051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env44050 == env44051) = true)

theorem identity44051 : scanCanonicalize (H12AffineFastState.compose env44051 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound44051 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env44052 : List Nat := [2,4,8,16,32,64,128,68,512,85,2048,80,8192,1,8217,8298,81,262144,85,8216,80,153,17,262336,8329,65,43,1,1,2144,262375,262370,69,17,81,512]

theorem envBound44052 : H12AffineFastState.Bounded env44052 := by
  intro p hp
  have h : env44052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44051_44052 : H12AffineEnvironment.transform 7 68 env44051 = env44052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env44051 == env44052) = true)

theorem identity44052 : scanCanonicalize (H12AffineFastState.compose env44052 (packedSelected [3,5,10] rootPS)) = affineNative (2^(17+1) ^^^ 8755) := by decide +kernel

theorem selectedBound44052 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env44053 : List Nat := [2,4,8,16,32,64,128,68,512,85,2048,80,8192,1,8217,8298,81,8755,85,8216,80,153,17,8947,8329,65,43,1,1,2144,8916,8913,69,17,81,512]

theorem envBound44053 : H12AffineFastState.Bounded env44053 := by
  intro p hp
  have h : env44053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44052_44053 : H12AffineEnvironment.transform 17 8755 env44052 = env44053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8755 env44052 == env44053) = true)

theorem identity44053 : scanCanonicalize (H12AffineFastState.compose env44053 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound44053 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env44054 : List Nat := [2,4,8,16,32,16,128,20,512,5,2048,0,8192,1,8217,8250,1,8755,5,8216,0,153,17,8867,8329,17,43,1,1,2096,8836,8833,21,17,1,512]

theorem envBound44054 : H12AffineFastState.Bounded env44054 := by
  intro p hp
  have h : env44054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44053_44054 : H12AffineEnvironment.transform 5 16 env44053 = env44054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44053 == env44054) = true)

def env44055 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1345,262144,77934,32769,4096,46528,17,266385,70887,78895,77841,1296,74814,81226,365712,308666,257,74799,1344,79470]

theorem envBound44055 : H12AffineFastState.Bounded env44055 := by
  intro p hp
  have h : env44055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44043_44055 : H12AffineEnvironment.transform 13 1297 env44043 = env44055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env44043 == env44055) = true)

theorem identity44055 : scanCanonicalize (H12AffineFastState.compose env44055 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound44055 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env44056 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1345,262144,77934,13340,4096,477,17,266385,70887,78895,77841,1296,74814,81226,336013,262567,257,74799,1344,79470]

theorem envBound44056 : H12AffineFastState.Bounded env44056 := by
  intro p hp
  have h : env44056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44055_44056 : H12AffineEnvironment.transform 14 13341 env44055 = env44056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env44055 == env44056) = true)

def env44057 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1345,65664,77934,13340,4096,477,17,69649,70887,78895,77841,1296,74814,81226,8205,65831,257,74799,1344,79470]

theorem envBound44057 : H12AffineFastState.Bounded env44057 := by
  intro p hp
  have h : env44057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44056_44057 : H12AffineEnvironment.transform 17 65664 env44056 = env44057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env44056 == env44057) = true)

theorem identity44057 : scanCanonicalize (H12AffineFastState.compose env44057 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5465) := by decide +kernel

theorem selectedBound44057 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env44058 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5465,1297,324,65536,1345,65664,66871,325,4096,477,17,69649,70887,65910,66888,1296,69991,67603,5460,65831,257,70006,1344,66359]

theorem envBound44058 : H12AffineFastState.Bounded env44058 := by
  intro p hp
  have h : env44058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44057_44058 : H12AffineEnvironment.transform 12 5465 env44057 = env44058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5465 env44057 == env44058) = true)

def env44059 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5385,1297,276,65536,1297,65664,66871,277,4096,397,17,69649,70839,65830,66840,1296,69943,67603,5380,65831,257,69926,1296,66359]

theorem envBound44059 : H12AffineFastState.Bounded env44059 := by
  intro p hp
  have h : env44059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44058_44059 : H12AffineEnvironment.transform 5 16 env44058 = env44059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44058 == env44059) = true)

theorem identity44059 : scanCanonicalize (H12AffineFastState.compose env44059 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 1330) := by decide +kernel

theorem selectedBound44059 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env44060 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5385,1297,276,1330,1297,1458,5,277,4096,397,17,5411,4485,1044,42,1296,5125,3361,5380,1045,257,5140,1296,1541]

theorem envBound44060 : H12AffineFastState.Bounded env44060 := by
  intro p hp
  have h : env44060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44059_44060 : H12AffineEnvironment.transform 15 1330 env44059 = env44060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1330 env44059 == env44060) = true)

theorem identity44060 : scanCanonicalize (H12AffineFastState.compose env44060 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound44060 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env44061 : List Nat := [2,4,8,16,32,16,128,256,512,5,2048,4096,4364,276,276,311,276,439,5,277,4096,397,17,4390,4485,17,42,277,4096,2340,4353,16,257,4113,277,512]

theorem envBound44061 : H12AffineFastState.Bounded env44061 := by
  intro p hp
  have h : env44061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44060_44061 : H12AffineEnvironment.transform 9 5 env44060 = env44061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env44060 == env44061) = true)

theorem identity44061 : scanCanonicalize (H12AffineFastState.compose env44061 (packedSelected [2,11,18] rootPS)) = affineNative (2^(11+1) ^^^ 2830) := by decide +kernel

theorem selectedBound44061 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env44062 : List Nat := [2,4,8,16,32,16,128,256,512,5,2048,2830,2562,276,276,311,276,439,5,277,2830,397,17,2600,2699,17,42,277,2830,2340,2575,16,257,2847,277,512]

theorem envBound44062 : H12AffineFastState.Bounded env44062 := by
  intro p hp
  have h : env44062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44061_44062 : H12AffineEnvironment.transform 11 2830 env44061 = env44062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2830 env44061 == env44062) = true)

theorem identity44062 : scanCanonicalize (H12AffineFastState.compose env44062 (packedSelected [1,2,3,13] rootPS)) = affineNative (2^(10+1) ^^^ 429) := by decide +kernel

theorem selectedBound44062 : packedSelected [1,2,3,13] rootPS < 2^1333 := by decide +kernel

def env44063 : List Nat := [2,4,8,16,32,16,128,256,512,5,429,675,943,276,276,311,276,439,5,277,675,397,17,901,806,17,42,277,675,137,930,16,257,690,277,512]

theorem envBound44063 : H12AffineFastState.Bounded env44063 := by
  intro p hp
  have h : env44063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44062_44063 : H12AffineEnvironment.transform 10 429 env44062 = env44063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 429 env44062 == env44063) = true)

theorem identity44063 : scanCanonicalize (H12AffineFastState.compose env44063 (packedSelected [0,3,7,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound44063 : packedSelected [0,3,7,9,10] rootPS < 2^1333 := by decide +kernel

def env44064 : List Nat := [2,4,8,16,32,16,19,256,512,5,318,560,828,276,276,311,276,292,5,277,560,286,17,790,806,17,42,277,560,26,817,16,257,545,277,512]

theorem envBound44064 : H12AffineFastState.Bounded env44064 := by
  intro p hp
  have h : env44064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44063_44064 : H12AffineEnvironment.transform 6 19 env44063 = env44064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env44063 == env44064) = true)

theorem identity44064 : scanCanonicalize (H12AffineFastState.compose env44064 (packedSelected [0,1,2,3,4,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound44064 : packedSelected [0,1,2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env44065 : List Nat := [2,4,8,16,32,16,19,256,48,5,318,0,268,276,276,311,276,292,5,277,0,286,17,294,278,17,42,277,0,26,257,16,257,17,277,48]

theorem envBound44065 : H12AffineFastState.Bounded env44065 := by
  intro p hp
  have h : env44065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44064_44065 : H12AffineEnvironment.transform 8 48 env44064 = env44065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env44064 == env44065) = true)

theorem identity44065 : scanCanonicalize (H12AffineFastState.compose env44065 (packedSelected [2,3] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound44065 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env44066 : List Nat := [2,4,8,16,22,16,19,256,6,5,264,0,268,276,276,257,276,274,5,277,0,286,17,272,278,17,28,277,0,26,257,16,257,17,277,6]

theorem envBound44066 : H12AffineFastState.Bounded env44066 := by
  intro p hp
  have h : env44066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44065_44066 : H12AffineEnvironment.transform 4 22 env44065 = env44066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env44065 == env44066) = true)

theorem identity44066 : scanCanonicalize (H12AffineFastState.compose env44066 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 18) := by decide +kernel

theorem selectedBound44066 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env44067 : List Nat := [2,4,8,16,22,16,19,18,6,5,26,0,30,6,6,19,6,0,5,7,0,12,17,2,4,17,28,7,0,26,19,16,19,17,7,6]

theorem envBound44067 : H12AffineFastState.Bounded env44067 := by
  intro p hp
  have h : env44067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44066_44067 : H12AffineEnvironment.transform 7 18 env44066 = env44067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 18 env44066 == env44067) = true)

theorem identity44067 : scanCanonicalize (H12AffineFastState.compose env44067 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound44067 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44068 : List Nat := [2,3,8,16,17,16,19,18,1,2,26,0,25,1,1,19,1,0,2,0,0,11,17,2,3,17,27,0,0,26,19,16,19,17,0,1]

theorem envBound44068 : H12AffineFastState.Bounded env44068 := by
  intro p hp
  have h : env44068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44067_44068 : H12AffineEnvironment.transform 1 3 env44067 = env44068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env44067 == env44068) = true)

theorem identity44068 : scanCanonicalize (H12AffineFastState.compose env44068 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound44068 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44069 : List Nat := [2,3,8,11,10,11,8,9,1,2,1,0,2,1,1,8,1,0,2,0,0,11,10,2,3,10,0,0,0,1,8,11,8,10,0,1]

theorem envBound44069 : H12AffineFastState.Bounded env44069 := by
  intro p hp
  have h : env44069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44068_44069 : H12AffineEnvironment.transform 3 11 env44068 = env44069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env44068 == env44069) = true)

def env44070 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,5384,1297,277,65536,1296,65664,66871,276,4096,396,17,69649,70838,65831,66841,1296,69942,67603,5381,65831,257,69927,1297,66359]

theorem envBound44070 : H12AffineFastState.Bounded env44070 := by
  intro p hp
  have h : env44070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44058_44070 : H12AffineEnvironment.transform 5 17 env44058 = env44070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env44058 == env44070) = true)

theorem identity44070 : scanCanonicalize (H12AffineFastState.compose env44070 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound44070 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env44071 : List Nat := [2,4,8,16,32,17,128,256,512,4,2048,4096,4364,277,277,65536,276,65664,65843,276,4096,396,17,69649,69810,65831,65821,276,69942,67603,4353,65831,257,69927,277,66359]

theorem envBound44071 : H12AffineFastState.Bounded env44071 := by
  intro p hp
  have h : env44071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44070_44071 : H12AffineEnvironment.transform 9 4 env44070 = env44071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env44070 == env44071) = true)

def env44072 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1345,65665,77934,13340,4096,477,17,69648,70887,78895,77841,1296,74814,81226,8204,65830,257,74799,1344,79470]

theorem envBound44072 : H12AffineFastState.Bounded env44072 := by
  intro p hp
  have h : env44072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44056_44072 : H12AffineEnvironment.transform 17 65665 env44056 = env44072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env44056 == env44072) = true)

theorem identity44072 : scanCanonicalize (H12AffineFastState.compose env44072 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound44072 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env44073 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,25,1297,5124,65536,1345,65665,69751,5125,4096,477,17,69648,70887,70710,69640,1296,66599,73043,21,65830,257,66614,1344,71287]

theorem envBound44073 : H12AffineFastState.Bounded env44073 := by
  intro p hp
  have h : env44073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44072_44073 : H12AffineEnvironment.transform 12 25 env44072 = env44073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env44072 == env44073) = true)

def env44074 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,25,1297,5124,65536,1297,65665,69671,5125,4096,397,17,69648,70839,70710,69640,1296,66599,72963,21,65830,257,66614,1296,71207]

theorem envBound44074 : H12AffineFastState.Bounded env44074 := by
  intro p hp
  have h : env44074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44073_44074 : H12AffineEnvironment.transform 5 16 env44073 = env44074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44073 == env44074) = true)

theorem identity44074 : scanCanonicalize (H12AffineFastState.compose env44074 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 4130) := by decide +kernel

theorem selectedBound44074 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env44075 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,25,1297,5124,4130,1297,4259,5,5125,4096,397,17,50,1173,1044,42,1296,5125,3361,21,4356,257,5140,1296,1541]

theorem envBound44075 : H12AffineFastState.Bounded env44075 := by
  intro p hp
  have h : env44075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44074_44075 : H12AffineEnvironment.transform 15 4130 env44074 = env44075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4130 env44074 == env44075) = true)

theorem identity44075 : scanCanonicalize (H12AffineFastState.compose env44075 (packedSelected [2,13,21,23,32] rootPS)) = affineNative (2^(8+1) ^^^ 412) := by decide +kernel

theorem selectedBound44075 : packedSelected [2,13,21,23,32] rootPS < 2^1333 := by decide +kernel

def env44076 : List Nat := [2,4,8,16,32,16,128,256,412,1024,2048,4096,25,1297,5124,4130,1297,4259,5,5125,4096,397,17,50,1173,1044,42,1296,5125,3361,21,4356,257,5140,1296,1433]

theorem envBound44076 : H12AffineFastState.Bounded env44076 := by
  intro p hp
  have h : env44076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44075_44076 : H12AffineEnvironment.transform 8 412 env44075 = env44076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 412 env44075 == env44076) = true)

theorem identity44076 : scanCanonicalize (H12AffineFastState.compose env44076 (packedSelected [0,1,3,4,7,8,9,10,18,19,21,23,26,28] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound44076 : packedSelected [0,1,3,4,7,8,9,10,18,19,21,23,26,28] rootPS < 2^1333 := by decide +kernel

def env44077 : List Nat := [2,4,8,16,32,16,128,256,412,1024,2048,276,25,1297,1296,310,1297,439,5,1297,276,397,17,50,1173,1044,42,1296,1297,3361,21,16,257,1280,1296,1433]

theorem envBound44077 : H12AffineFastState.Bounded env44077 := by
  intro p hp
  have h : env44077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44076_44077 : H12AffineEnvironment.transform 11 276 env44076 = env44077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env44076 == env44077) = true)

theorem identity44077 : scanCanonicalize (H12AffineFastState.compose env44077 (packedSelected [5,8,11,13,18] rootPS)) = affineNative (2^(9+1) ^^^ 31) := by decide +kernel

theorem selectedBound44077 : packedSelected [5,8,11,13,18] rootPS < 2^1333 := by decide +kernel

def env44078 : List Nat := [2,4,8,16,32,16,128,256,412,31,2048,276,25,270,271,310,270,439,5,270,276,397,17,50,138,11,42,271,270,2366,21,16,257,287,271,390]

theorem envBound44078 : H12AffineFastState.Bounded env44078 := by
  intro p hp
  have h : env44078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44077_44078 : H12AffineEnvironment.transform 9 31 env44077 = env44078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 31 env44077 == env44078) = true)

theorem identity44078 : scanCanonicalize (H12AffineFastState.compose env44078 (packedSelected [0,2,3,5,7,10,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound44078 : packedSelected [0,2,3,5,7,10,11,12] rootPS < 2^1333 := by decide +kernel

def env44079 : List Nat := [2,4,8,16,32,16,128,256,412,31,292,276,25,270,271,310,270,439,5,270,276,397,17,50,138,11,42,271,270,26,21,16,257,287,271,390]

theorem envBound44079 : H12AffineFastState.Bounded env44079 := by
  intro p hp
  have h : env44079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44078_44079 : H12AffineEnvironment.transform 10 292 env44078 = env44079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env44078 == env44079) = true)

theorem identity44079 : scanCanonicalize (H12AffineFastState.compose env44079 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound44079 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env44080 : List Nat := [2,4,8,16,16,16,128,256,412,31,276,276,25,270,271,262,270,391,5,270,276,397,17,2,138,11,26,271,270,26,21,16,257,287,271,390]

theorem envBound44080 : H12AffineFastState.Bounded env44080 := by
  intro p hp
  have h : env44080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44079_44080 : H12AffineEnvironment.transform 4 16 env44079 = env44080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env44079 == env44080) = true)

theorem identity44080 : scanCanonicalize (H12AffineFastState.compose env44080 (packedSelected [3,5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound44080 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env44081 : List Nat := [2,4,8,16,16,16,9,256,277,31,276,276,25,270,271,262,270,270,5,270,276,260,17,2,3,11,26,271,270,26,21,16,257,287,271,271]

theorem envBound44081 : H12AffineFastState.Bounded env44081 := by
  intro p hp
  have h : env44081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44080_44081 : H12AffineEnvironment.transform 6 9 env44080 = env44081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44080 == env44081) = true)

theorem identity44081 : scanCanonicalize (H12AffineFastState.compose env44081 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound44081 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env44082 : List Nat := [2,4,8,16,16,16,9,21,0,31,1,1,25,27,26,19,27,27,5,27,1,17,17,2,3,11,26,26,27,26,21,16,20,10,26,26]

theorem envBound44082 : H12AffineFastState.Bounded env44082 := by
  intro p hp
  have h : env44082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44081_44082 : H12AffineEnvironment.transform 7 21 env44081 = env44082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env44081 == env44082) = true)

theorem identity44082 : scanCanonicalize (H12AffineFastState.compose env44082 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound44082 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44083 : List Nat := [2,4,8,10,10,10,9,15,0,5,1,1,3,1,0,9,1,1,5,1,1,11,11,2,3,11,0,0,1,0,15,10,14,10,0,0]

theorem envBound44083 : H12AffineFastState.Bounded env44083 := by
  intro p hp
  have h : env44083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44082_44083 : H12AffineEnvironment.transform 3 10 env44082 = env44083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env44082 == env44083) = true)

theorem identity44083 : scanCanonicalize (H12AffineFastState.compose env44083 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound44083 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44084 : List Nat := [2,4,5,7,7,7,4,2,0,5,1,1,3,1,0,4,1,1,5,1,1,6,6,2,3,6,0,0,1,0,2,7,3,7,0,0]

theorem envBound44084 : H12AffineFastState.Bounded env44084 := by
  intro p hp
  have h : env44084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44083_44084 : H12AffineEnvironment.transform 2 5 env44083 = env44084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env44083 == env44084) = true)

def env44085 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,25,1297,5124,65536,1296,65665,69670,5125,4096,396,17,69648,70838,70710,69640,1296,66599,72962,21,65830,257,66614,1297,71206]

theorem envBound44085 : H12AffineFastState.Bounded env44085 := by
  intro p hp
  have h : env44085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44073_44085 : H12AffineEnvironment.transform 5 17 env44073 = env44085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env44073 == env44085) = true)

theorem identity44085 : scanCanonicalize (H12AffineFastState.compose env44085 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound44085 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env44086 : List Nat := [2,4,8,16,32,17,128,256,512,4,2048,4096,25,277,4096,65536,276,65665,69670,4097,4096,396,17,69648,69810,69682,69640,276,65571,71942,21,65830,257,65586,277,70178]

theorem envBound44086 : H12AffineFastState.Bounded env44086 := by
  intro p hp
  have h : env44086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44085_44086 : H12AffineEnvironment.transform 9 4 env44085 = env44086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env44085 == env44086) = true)

theorem identity44086 : scanCanonicalize (H12AffineFastState.compose env44086 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 4131) := by decide +kernel

theorem selectedBound44086 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env44087 : List Nat := [2,4,8,16,32,17,128,256,512,4,2048,4096,25,277,4096,4131,276,4258,5,4097,4096,396,17,51,145,17,43,276,4096,2341,21,4357,257,4113,277,513]

theorem envBound44087 : H12AffineFastState.Bounded env44087 := by
  intro p hp
  have h : env44087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44086_44087 : H12AffineEnvironment.transform 15 4131 env44086 = env44087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4131 env44086 == env44087) = true)

theorem identity44087 : scanCanonicalize (H12AffineFastState.compose env44087 (packedSelected [2,11,18] rootPS)) = affineNative (2^(11+1) ^^^ 648) := by decide +kernel

theorem selectedBound44087 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env44088 : List Nat := [2,4,8,16,32,17,128,256,512,4,2048,648,25,277,648,683,276,554,5,649,648,396,17,51,145,17,43,276,648,2341,21,909,257,665,277,513]

theorem envBound44088 : H12AffineFastState.Bounded env44088 := by
  intro p hp
  have h : env44088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44087_44088 : H12AffineEnvironment.transform 11 648 env44087 = env44088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 648 env44087 == env44088) = true)

theorem identity44088 : scanCanonicalize (H12AffineFastState.compose env44088 (packedSelected [0,1,3,7,11,13] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound44088 : packedSelected [0,1,3,7,11,13] rootPS < 2^1333 := by decide +kernel

def env44089 : List Nat := [2,4,8,16,32,17,128,256,48,4,2048,184,25,277,184,155,276,26,5,185,184,396,17,51,145,17,43,276,184,2341,21,445,257,169,277,49]

theorem envBound44089 : H12AffineFastState.Bounded env44089 := by
  intro p hp
  have h : env44089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44088_44089 : H12AffineEnvironment.transform 8 48 env44088 = env44089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env44088 == env44089) = true)

def env44090 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16465,262144,95615,32769,4096,61649,16,284032,86518,94527,77840,1297,74814,96347,381313,308667,257,90431,1344,95103]

theorem envBound44090 : H12AffineFastState.Bounded env44090 := by
  intro p hp
  have h : env44090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44042_44090 : H12AffineEnvironment.transform 16 16465 env44042 = env44090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16465 env44042 == env44090) = true)

def env44091 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1345,262144,77935,32769,4096,46529,16,266384,70886,78895,77840,1297,74814,81227,365713,308667,257,74799,1344,79471]

theorem envBound44091 : H12AffineFastState.Bounded env44091 := by
  intro p hp
  have h : env44091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44090_44091 : H12AffineEnvironment.transform 13 1296 env44090 = env44091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env44090 == env44091) = true)

theorem identity44091 : scanCanonicalize (H12AffineFastState.compose env44091 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound44091 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env44092 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1345,262144,77935,13340,4096,476,16,266384,70886,78895,77840,1297,74814,81227,336012,262566,257,74799,1344,79471]

theorem envBound44092 : H12AffineFastState.Bounded env44092 := by
  intro p hp
  have h : env44092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44091_44092 : H12AffineEnvironment.transform 14 13341 env44091 = env44092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env44091 == env44092) = true)

def env44093 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1345,65664,77935,13340,4096,476,16,69648,70886,78895,77840,1297,74814,81227,8204,65830,257,74799,1344,79471]

theorem envBound44093 : H12AffineFastState.Bounded env44093 := by
  intro p hp
  have h : env44093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44092_44093 : H12AffineEnvironment.transform 17 65664 env44092 = env44093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env44092 == env44093) = true)

theorem identity44093 : scanCanonicalize (H12AffineFastState.compose env44093 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound44093 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env44094 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,1,12556,65536,80,65664,77935,12557,4096,476,16,69648,70135,78142,77840,0,74031,79962,8204,65830,257,74046,81,78718]

theorem envBound44094 : H12AffineFastState.Bounded env44094 := by
  intro p hp
  have h : env44094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44093_44094 : H12AffineEnvironment.transform 9 273 env44093 = env44094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env44093 == env44094) = true)

def env44095 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,4096,8192,1,12556,65536,0,65664,77887,12557,4096,396,16,69648,70055,78142,77840,0,74031,79882,8204,65830,257,74046,1,78638]

theorem envBound44095 : H12AffineFastState.Bounded env44095 := by
  intro p hp
  have h : env44095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44094_44095 : H12AffineEnvironment.transform 5 16 env44094 = env44095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44094 == env44095) = true)

theorem identity44095 : scanCanonicalize (H12AffineFastState.compose env44095 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound44095 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env44096 : List Nat := [2,4,8,16,32,16,128,20,512,5,2048,4096,8192,1,12312,65536,0,65664,77887,12313,4096,152,16,69648,69811,77866,77840,0,73787,79882,8204,65586,21,73770,1,78394]

theorem envBound44096 : H12AffineFastState.Bounded env44096 := by
  intro p hp
  have h : env44096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44095_44096 : H12AffineEnvironment.transform 7 20 env44095 = env44096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env44095 == env44096) = true)

theorem identity44096 : scanCanonicalize (H12AffineFastState.compose env44096 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 12346) := by decide +kernel

theorem selectedBound44096 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env44097 : List Nat := [2,4,8,16,32,16,128,20,512,5,2048,4096,8192,1,12312,12346,0,12474,5,12313,4096,152,16,8234,8329,16,42,0,4097,2096,8204,12296,21,4112,1,512]

theorem envBound44097 : H12AffineFastState.Bounded env44097 := by
  intro p hp
  have h : env44097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44096_44097 : H12AffineEnvironment.transform 15 12346 env44096 = env44097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12346 env44096 == env44097) = true)

theorem identity44097 : scanCanonicalize (H12AffineFastState.compose env44097 (packedSelected [2,3,5,10,11,18] rootPS)) = affineNative (2^(12+1) ^^^ 2099) := by decide +kernel

theorem selectedBound44097 : packedSelected [2,3,5,10,11,18] rootPS < 2^1333 := by decide +kernel

def env44098 : List Nat := [2,4,8,16,32,16,128,20,512,5,2048,4096,2099,1,6187,6153,0,6281,5,6186,4096,152,16,2073,2234,16,42,0,4097,2096,2111,6203,21,4112,1,512]

theorem envBound44098 : H12AffineFastState.Bounded env44098 := by
  intro p hp
  have h : env44098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44097_44098 : H12AffineEnvironment.transform 12 2099 env44097 = env44098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2099 env44097 == env44098) = true)

theorem identity44098 : scanCanonicalize (H12AffineFastState.compose env44098 (packedSelected [0,7,11] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound44098 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env44099 : List Nat := [2,4,8,16,32,16,9,20,512,5,2048,4096,2099,1,6187,6153,0,6144,5,6186,4096,17,16,2073,2099,16,42,0,4097,2096,2111,6203,21,4112,1,512]

theorem envBound44099 : H12AffineFastState.Bounded env44099 := by
  intro p hp
  have h : env44099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44098_44099 : H12AffineEnvironment.transform 6 9 env44098 = env44099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44098 == env44099) = true)

theorem identity44099 : scanCanonicalize (H12AffineFastState.compose env44099 (packedSelected [0,1,2,3,4,5,7,8,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 2049) := by decide +kernel

theorem selectedBound44099 : packedSelected [0,1,2,3,4,5,7,8,9,10] rootPS < 2^1333 := by decide +kernel

end H12CloudChart2