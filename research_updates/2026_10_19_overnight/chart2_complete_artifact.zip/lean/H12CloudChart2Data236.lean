import H12CloudChart2Data235

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env59606 : List Nat := [2,4,8,16,32,17,8,20,512,4,29,1,536,0,513,546,1,42,5,512,1,16,17,50,537,16,42,0,1,44,20,17,20,17,1,512]

theorem envBound59606 : H12AffineFastState.Bounded env59606 := by
  intro p hp
  have h : env59606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59605_59606 : H12AffineEnvironment.transform 10 29 env59605 = env59606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 29 env59605 == env59606) = true)

theorem identity59606 : scanCanonicalize (H12AffineFastState.compose env59606 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 28) := by decide +kernel

theorem selectedBound59606 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env59607 : List Nat := [2,4,8,16,32,17,8,20,28,4,29,1,4,0,29,62,1,42,5,28,1,16,17,50,5,16,42,0,1,44,20,17,20,17,1,28]

theorem envBound59607 : H12AffineFastState.Bounded env59607 := by
  intro p hp
  have h : env59607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59606_59607 : H12AffineEnvironment.transform 8 28 env59606 = env59607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 28 env59606 == env59607) = true)

theorem identity59607 : scanCanonicalize (H12AffineFastState.compose env59607 (packedSelected [0,2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound59607 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env59608 : List Nat := [2,4,8,16,17,17,8,20,28,4,29,1,4,0,29,15,1,27,5,28,1,16,17,3,5,16,27,0,1,29,20,17,20,17,1,28]

theorem envBound59608 : H12AffineFastState.Bounded env59608 := by
  intro p hp
  have h : env59608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59607_59608 : H12AffineEnvironment.transform 4 17 env59607 = env59608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env59607 == env59608) = true)

def env59609 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32882,1344,262144,42332,32769,1345,41088,17,263632,33236,41244,42274,1296,42061,43128,262563,42077,256,303354,1344,41821]

theorem envBound59609 : H12AffineFastState.Bounded env59609 := by
  intro p hp
  have h : env59609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59597_59609 : H12AffineEnvironment.transform 11 1345 env59597 = env59609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env59597 == env59609) = true)

theorem identity59609 : scanCanonicalize (H12AffineFastState.compose env59609 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 276) := by decide +kernel

theorem selectedBound59609 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env59610 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,276,358,1344,262144,9288,277,1345,8596,17,263632,192,8200,9270,1296,9561,10604,262563,9545,256,270830,1344,8777]

theorem envBound59610 : H12AffineFastState.Bounded env59610 := by
  intro p hp
  have h : env59610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59609_59610 : H12AffineEnvironment.transform 14 276 env59609 = env59610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 276 env59609 == env59610) = true)

theorem identity59610 : scanCanonicalize (H12AffineFastState.compose env59610 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(12+1) ^^^ 877) := by decide +kernel

theorem selectedBound59610 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env59611 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,877,1296,276,358,1344,262144,1829,277,1345,761,17,263632,192,869,1883,1296,1588,2561,262563,1572,256,262787,1344,292]

theorem envBound59611 : H12AffineFastState.Bounded env59611 := by
  intro p hp
  have h : env59611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59610_59611 : H12AffineEnvironment.transform 12 877 env59610 = env59611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 877 env59610 == env59611) = true)

def env59612 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1345,262144,77934,32769,4096,46528,17,266384,70886,78894,77841,1296,74815,81226,365713,74799,256,308666,1344,79471]

theorem envBound59612 : H12AffineFastState.Bounded env59612 := by
  intro p hp
  have h : env59612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59595_59612 : H12AffineEnvironment.transform 13 1297 env59595 = env59612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env59595 == env59612) = true)

theorem identity59612 : scanCanonicalize (H12AffineFastState.compose env59612 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound59612 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env59613 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1345,262144,77934,13340,4096,477,17,266384,70886,78894,77841,1296,74815,81226,336012,74799,256,262567,1344,79471]

theorem envBound59613 : H12AffineFastState.Bounded env59613 := by
  intro p hp
  have h : env59613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59612_59613 : H12AffineEnvironment.transform 14 13341 env59612 = env59613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env59612 == env59613) = true)

def env59614 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1345,65664,77934,13340,4096,477,17,69648,70886,78894,77841,1296,74815,81226,8204,74799,256,65831,1344,79471]

theorem envBound59614 : H12AffineFastState.Bounded env59614 := by
  intro p hp
  have h : env59614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59613_59614 : H12AffineEnvironment.transform 17 65664 env59613 = env59614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env59613 == env59614) = true)

theorem identity59614 : scanCanonicalize (H12AffineFastState.compose env59614 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound59614 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env59615 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1297,9245,65536,1345,65664,73838,9244,0,477,17,65552,66790,74798,73745,1296,74815,77130,8204,74799,256,65831,1344,75375]

theorem envBound59615 : H12AffineFastState.Bounded env59615 := by
  intro p hp
  have h : env59615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59614_59615 : H12AffineEnvironment.transform 11 0 env59614 = env59615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env59614 == env59615) = true)

def env59616 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,0,8192,1297,9245,65536,1297,65664,73790,9244,0,397,17,65552,66742,74798,73745,1296,74815,77082,8204,74799,256,65831,1296,75327]

theorem envBound59616 : H12AffineFastState.Bounded env59616 := by
  intro p hp
  have h : env59616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59615_59616 : H12AffineEnvironment.transform 5 16 env59615 = env59616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env59615 == env59616) = true)

theorem identity59616 : scanCanonicalize (H12AffineFastState.compose env59616 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound59616 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59617 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,0,268,1297,1297,65536,1297,65664,65842,1296,0,397,17,65552,66742,66850,65821,1296,66867,68630,256,66851,256,65831,1296,67379]

theorem envBound59617 : H12AffineFastState.Bounded env59617 := by
  intro p hp
  have h : env59617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59616_59617 : H12AffineEnvironment.transform 12 268 env59616 = env59617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env59616 == env59617) = true)

theorem identity59617 : scanCanonicalize (H12AffineFastState.compose env59617 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 1330) := by decide +kernel

theorem selectedBound59617 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env59618 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,0,268,1297,1297,1330,1297,1458,1024,1296,0,397,17,1314,388,16,1071,1296,1,2340,256,17,256,1045,1296,513]

theorem envBound59618 : H12AffineFastState.Bounded env59618 := by
  intro p hp
  have h : env59618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59617_59618 : H12AffineEnvironment.transform 15 1330 env59617 = env59618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1330 env59617 == env59618) = true)

theorem identity59618 : scanCanonicalize (H12AffineFastState.compose env59618 (packedSelected [2,13,17] rootPS)) = affineNative (2^(10+1) ^^^ 554) := by decide +kernel

theorem selectedBound59618 : packedSelected [2,13,17] rootPS < 2^1333 := by decide +kernel

def env59619 : List Nat := [2,4,8,16,32,16,128,256,512,1024,554,0,268,1297,1297,1330,1297,1458,1024,1296,0,397,17,1314,388,16,1071,1296,1,782,256,17,256,1045,1296,513]

theorem envBound59619 : H12AffineFastState.Bounded env59619 := by
  intro p hp
  have h : env59619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59618_59619 : H12AffineEnvironment.transform 10 554 env59618 = env59619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 554 env59618 == env59619) = true)

theorem identity59619 : scanCanonicalize (H12AffineFastState.compose env59619 (packedSelected [2,11,18] rootPS)) = affineNative (2^(9+1) ^^^ 800) := by decide +kernel

theorem selectedBound59619 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env59620 : List Nat := [2,4,8,16,32,16,128,256,512,800,554,0,268,561,561,530,561,658,800,560,0,397,17,514,388,16,783,560,1,782,256,17,256,821,560,513]

theorem envBound59620 : H12AffineFastState.Bounded env59620 := by
  intro p hp
  have h : env59620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59619_59620 : H12AffineEnvironment.transform 9 800 env59619 = env59620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 800 env59619 == env59620) = true)

theorem identity59620 : scanCanonicalize (H12AffineFastState.compose env59620 (packedSelected [1,4,5,8,11] rootPS)) = affineNative (2^(8+1) ^^^ 154) := by decide +kernel

theorem selectedBound59620 : packedSelected [1,4,5,8,11] rootPS < 2^1333 := by decide +kernel

def env59621 : List Nat := [2,4,8,16,32,16,128,256,154,442,176,0,268,171,171,136,171,8,442,170,0,397,17,152,388,16,405,170,1,404,256,17,256,431,170,155]

theorem envBound59621 : H12AffineFastState.Bounded env59621 := by
  intro p hp
  have h : env59621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59620_59621 : H12AffineEnvironment.transform 8 154 env59620 = env59621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 154 env59620 == env59621) = true)

theorem identity59621 : scanCanonicalize (H12AffineFastState.compose env59621 (packedSelected [0,1,3,4,5,7,13] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound59621 : packedSelected [0,1,3,4,5,7,13] rootPS < 2^1333 := by decide +kernel

def env59622 : List Nat := [2,4,8,16,32,16,128,37,154,159,176,0,41,171,171,136,171,8,159,170,0,168,17,152,161,16,176,170,1,177,37,17,37,138,170,155]

theorem envBound59622 : H12AffineFastState.Bounded env59622 := by
  intro p hp
  have h : env59622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59621_59622 : H12AffineEnvironment.transform 7 37 env59621 = env59622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env59621 == env59622) = true)

theorem identity59622 : scanCanonicalize (H12AffineFastState.compose env59622 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 24) := by decide +kernel

theorem selectedBound59622 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env59623 : List Nat := [2,4,8,16,24,16,128,29,154,159,136,0,17,147,147,136,147,8,159,146,0,144,17,152,153,16,136,146,1,137,29,17,29,138,146,155]

theorem envBound59623 : H12AffineFastState.Bounded env59623 := by
  intro p hp
  have h : env59623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59622_59623 : H12AffineEnvironment.transform 4 24 env59622 = env59623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 24 env59622 == env59623) = true)

theorem identity59623 : scanCanonicalize (H12AffineFastState.compose env59623 (packedSelected [1,4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound59623 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env59624 : List Nat := [0,4,8,16,24,16,128,29,152,157,136,0,17,145,145,136,145,8,157,144,0,144,17,152,153,16,136,144,1,137,29,17,29,136,144,153]

theorem envBound59624 : H12AffineFastState.Bounded env59624 := by
  intro p hp
  have h : env59624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59623_59624 : H12AffineEnvironment.transform 0 0 env59623 = env59624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env59623 == env59624) = true)

theorem identity59624 : scanCanonicalize (H12AffineFastState.compose env59624 (packedSelected [1,2] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound59624 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env59625 : List Nat := [0,1,8,16,24,16,128,24,152,152,136,0,17,145,145,136,145,8,152,144,0,144,17,152,153,16,136,144,1,137,24,17,24,136,144,153]

theorem envBound59625 : H12AffineFastState.Bounded env59625 := by
  intro p hp
  have h : env59625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59624_59625 : H12AffineEnvironment.transform 1 1 env59624 = env59625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env59624 == env59625) = true)

def env59626 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,0,8192,1297,9245,65536,1296,65664,73791,9244,0,396,17,65552,66743,74798,73745,1296,74815,77083,8204,74799,256,65831,1297,75326]

theorem envBound59626 : H12AffineFastState.Bounded env59626 := by
  intro p hp
  have h : env59626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59615_59626 : H12AffineEnvironment.transform 5 17 env59615 = env59626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env59615 == env59626) = true)

theorem identity59626 : scanCanonicalize (H12AffineFastState.compose env59626 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 1331) := by decide +kernel

theorem selectedBound59626 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59627 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,0,8192,1297,9245,1331,1296,1459,9484,9244,0,396,17,1315,388,8477,9506,1296,8460,10280,8204,8476,256,1044,1297,8973]

theorem envBound59627 : H12AffineFastState.Bounded env59627 := by
  intro p hp
  have h : env59627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59626_59627 : H12AffineEnvironment.transform 15 1331 env59626 = env59627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1331 env59626 == env59627) = true)

theorem identity59627 : scanCanonicalize (H12AffineFastState.compose env59627 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound59627 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env59628 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,0,269,1297,1296,1331,1296,1459,1025,1297,0,396,17,1315,388,16,1071,1296,1,2341,257,17,256,1044,1297,512]

theorem envBound59628 : H12AffineFastState.Bounded env59628 := by
  intro p hp
  have h : env59628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59627_59628 : H12AffineEnvironment.transform 12 269 env59627 = env59628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env59627 == env59628) = true)

theorem identity59628 : scanCanonicalize (H12AffineFastState.compose env59628 (packedSelected [2,13,17] rootPS)) = affineNative (2^(10+1) ^^^ 1961) := by decide +kernel

theorem selectedBound59628 : packedSelected [2,13,17] rootPS < 2^1333 := by decide +kernel

def env59629 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1961,0,269,1297,1296,1331,1296,1459,1025,1297,0,396,17,1315,388,16,1071,1296,1,1676,257,17,256,1044,1297,512]

theorem envBound59629 : H12AffineFastState.Bounded env59629 := by
  intro p hp
  have h : env59629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59628_59629 : H12AffineEnvironment.transform 10 1961 env59628 = env59629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1961 env59628 == env59629) = true)

theorem identity59629 : scanCanonicalize (H12AffineFastState.compose env59629 (packedSelected [2,11,18] rootPS)) = affineNative (2^(9+1) ^^^ 267) := by decide +kernel

theorem selectedBound59629 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env59630 : List Nat := [2,4,8,16,32,17,128,256,512,267,674,0,269,26,27,56,27,184,266,26,0,396,17,40,388,16,292,27,1,903,257,17,256,287,26,512]

theorem envBound59630 : H12AffineFastState.Bounded env59630 := by
  intro p hp
  have h : env59630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59629_59630 : H12AffineEnvironment.transform 9 267 env59629 = env59630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 267 env59629 == env59630) = true)

theorem identity59630 : scanCanonicalize (H12AffineFastState.compose env59630 (packedSelected [1,5,8,9,10,11] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound59630 : packedSelected [1,5,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env59631 : List Nat := [2,4,8,16,32,17,128,256,292,267,390,0,269,26,27,56,27,184,266,26,0,396,17,40,388,16,292,27,1,163,257,17,256,287,26,292]

theorem envBound59631 : H12AffineFastState.Bounded env59631 := by
  intro p hp
  have h : env59631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59630_59631 : H12AffineEnvironment.transform 8 292 env59630 = env59631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env59630 == env59631) = true)

theorem identity59631 : scanCanonicalize (H12AffineFastState.compose env59631 (packedSelected [0,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound59631 : packedSelected [0,4,5,7] rootPS < 2^1333 := by decide +kernel

def env59632 : List Nat := [2,4,8,16,32,17,8,256,292,267,270,0,269,26,27,56,27,48,266,26,0,260,17,40,268,16,292,27,1,43,257,17,256,287,26,292]

theorem envBound59632 : H12AffineFastState.Bounded env59632 := by
  intro p hp
  have h : env59632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59631_59632 : H12AffineEnvironment.transform 6 8 env59631 = env59632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env59631 == env59632) = true)

theorem identity59632 : scanCanonicalize (H12AffineFastState.compose env59632 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound59632 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env59633 : List Nat := [2,4,8,16,17,17,8,256,277,267,270,0,269,26,27,9,27,1,266,26,0,260,17,25,268,16,277,27,1,26,257,17,256,287,26,277]

theorem envBound59633 : H12AffineFastState.Bounded env59633 := by
  intro p hp
  have h : env59633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59632_59633 : H12AffineEnvironment.transform 4 17 env59632 = env59633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env59632 == env59633) = true)

theorem identity59633 : scanCanonicalize (H12AffineFastState.compose env59633 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound59633 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59634 : List Nat := [2,4,8,10,11,11,8,256,271,267,270,0,269,0,1,9,1,1,266,0,0,260,11,3,268,10,271,1,1,0,257,11,256,261,0,271]

theorem envBound59634 : H12AffineFastState.Bounded env59634 := by
  intro p hp
  have h : env59634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59633_59634 : H12AffineEnvironment.transform 3 10 env59633 = env59634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env59633 == env59634) = true)

theorem identity59634 : scanCanonicalize (H12AffineFastState.compose env59634 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound59634 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env59635 : List Nat := [2,4,8,10,11,11,8,14,1,5,0,0,3,0,1,9,1,1,4,0,0,10,11,3,2,10,1,1,1,0,15,11,14,11,0,1]

theorem envBound59635 : H12AffineFastState.Bounded env59635 := by
  intro p hp
  have h : env59635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59634_59635 : H12AffineEnvironment.transform 7 14 env59634 = env59635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env59634 == env59635) = true)

theorem identity59635 : scanCanonicalize (H12AffineFastState.compose env59635 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound59635 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59636 : List Nat := [2,4,4,6,7,7,4,2,1,5,0,0,3,0,1,5,1,1,4,0,0,6,7,3,2,6,1,1,1,0,3,7,2,7,0,1]

theorem envBound59636 : H12AffineFastState.Bounded env59636 := by
  intro p hp
  have h : env59636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59635_59636 : H12AffineEnvironment.transform 2 4 env59635 = env59636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env59635 == env59636) = true)

def env59637 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1345,65665,77934,13340,4096,477,17,69649,70886,78894,77841,1296,74815,81226,8205,74799,256,65830,1344,79471]

theorem envBound59637 : H12AffineFastState.Bounded env59637 := by
  intro p hp
  have h : env59637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59613_59637 : H12AffineEnvironment.transform 17 65665 env59613 = env59637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env59613 == env59637) = true)

theorem identity59637 : scanCanonicalize (H12AffineFastState.compose env59637 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound59637 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env59638 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,81,12637,65536,1,65665,77934,12636,4096,477,17,69649,70054,78190,77841,80,74111,79882,8205,74095,256,65830,0,78639]

theorem envBound59638 : H12AffineFastState.Bounded env59638 := by
  intro p hp
  have h : env59638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59637_59638 : H12AffineEnvironment.transform 9 320 env59637 = env59638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env59637 == env59638) = true)

def env59639 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,4096,8192,1,12557,65536,1,65665,77886,12556,4096,397,17,69649,70054,78142,77841,0,74031,79882,8205,74047,256,65830,0,78639]

theorem envBound59639 : H12AffineFastState.Bounded env59639 := by
  intro p hp
  have h : env59639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59638_59639 : H12AffineEnvironment.transform 5 16 env59638 = env59639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env59638 == env59639) = true)

theorem identity59639 : scanCanonicalize (H12AffineFastState.compose env59639 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound59639 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59640 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,4096,269,1,4096,65536,1,65665,69939,4097,4096,397,17,69649,70054,69683,69916,0,65570,71943,256,65586,256,65830,0,70178]

theorem envBound59640 : H12AffineFastState.Bounded env59640 := by
  intro p hp
  have h : env59640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59639_59640 : H12AffineEnvironment.transform 12 269 env59639 = env59640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env59639 == env59640) = true)

def env59641 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,4096,8192,0,12556,65536,1,65665,77887,12557,4096,396,17,69649,70054,78143,77841,1,74030,79882,8205,74046,256,65830,0,78639]

theorem envBound59641 : H12AffineFastState.Bounded env59641 := by
  intro p hp
  have h : env59641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59638_59641 : H12AffineEnvironment.transform 5 17 env59638 = env59641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env59638 == env59641) = true)

theorem identity59641 : scanCanonicalize (H12AffineFastState.compose env59641 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 4131) := by decide +kernel

theorem selectedBound59641 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59642 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,4096,8192,0,12556,4131,1,4258,8220,12557,4096,396,17,50,389,8476,8242,1,12557,10281,8205,12573,256,4357,0,8972]

theorem envBound59642 : H12AffineFastState.Bounded env59642 := by
  intro p hp
  have h : env59642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59641_59642 : H12AffineEnvironment.transform 15 4131 env59641 = env59642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4131 env59641 == env59642) = true)

theorem identity59642 : scanCanonicalize (H12AffineFastState.compose env59642 (packedSelected [2,13,21,23,32] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound59642 : packedSelected [2,13,21,23,32] rootPS < 2^1333 := by decide +kernel

def env59643 : List Nat := [2,4,8,16,32,17,128,256,136,273,2048,4096,8192,0,12556,4131,1,4258,8220,12557,4096,396,17,50,389,8476,8242,1,12557,10281,8205,12573,256,4357,0,8580]

theorem envBound59643 : H12AffineFastState.Bounded env59643 := by
  intro p hp
  have h : env59643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59642_59643 : H12AffineEnvironment.transform 8 136 env59642 = env59643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env59642 == env59643) = true)

theorem identity59643 : scanCanonicalize (H12AffineFastState.compose env59643 (packedSelected [0,1,3,4,7,8,9,10,13,18,19,23,26,28] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound59643 : packedSelected [0,1,3,4,7,8,9,10,13,18,19,23,26,28] rootPS < 2^1333 := by decide +kernel

def env59644 : List Nat := [2,4,8,16,32,17,128,256,136,273,2048,4096,268,0,4096,4131,1,4258,272,4097,4096,396,17,50,389,16,318,1,4097,2341,257,4113,256,4357,0,136]

theorem envBound59644 : H12AffineFastState.Bounded env59644 := by
  intro p hp
  have h : env59644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59643_59644 : H12AffineEnvironment.transform 12 268 env59643 = env59644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env59643 == env59644) = true)

theorem identity59644 : scanCanonicalize (H12AffineFastState.compose env59644 (packedSelected [0,1,5,7,10,11,12,15] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound59644 : packedSelected [0,1,5,7,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env59645 : List Nat := [2,4,8,16,16,17,128,256,136,273,2048,4096,268,0,4096,4115,1,4242,272,4097,4096,396,17,2,389,16,270,1,4097,2325,257,4113,256,4357,0,136]

theorem envBound59645 : H12AffineFastState.Bounded env59645 := by
  intro p hp
  have h : env59645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59644_59645 : H12AffineEnvironment.transform 4 16 env59644 = env59645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env59644 == env59645) = true)

theorem identity59645 : scanCanonicalize (H12AffineFastState.compose env59645 (packedSelected [0,8,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 2325) := by decide +kernel

theorem selectedBound59645 : packedSelected [0,8,10,12] rootPS < 2^1333 := by decide +kernel

def env59646 : List Nat := [2,4,8,16,16,17,128,256,136,273,2048,2325,268,0,2325,2310,1,2439,272,2324,2325,396,17,2,389,16,270,1,2324,2325,257,2308,256,2064,0,136]

theorem envBound59646 : H12AffineFastState.Bounded env59646 := by
  intro p hp
  have h : env59646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59645_59646 : H12AffineEnvironment.transform 11 2325 env59645 = env59646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2325 env59645 == env59646) = true)

theorem identity59646 : scanCanonicalize (H12AffineFastState.compose env59646 (packedSelected [2,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 157) := by decide +kernel

theorem selectedBound59646 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env59647 : List Nat := [2,4,8,16,16,17,128,157,136,140,2048,2184,145,0,2184,2203,1,2074,141,2185,2184,17,17,2,24,16,147,1,2185,2184,156,2201,157,2064,0,136]

theorem envBound59647 : H12AffineFastState.Bounded env59647 := by
  intro p hp
  have h : env59647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59646_59647 : H12AffineEnvironment.transform 7 157 env59646 = env59647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 157 env59646 == env59647) = true)

theorem identity59647 : scanCanonicalize (H12AffineFastState.compose env59647 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound59647 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59648 : List Nat := [2,4,8,16,16,17,128,157,136,140,0,136,145,0,136,155,1,26,141,137,136,17,17,2,24,16,147,1,137,136,156,153,157,16,0,136]

theorem envBound59648 : H12AffineFastState.Bounded env59648 := by
  intro p hp
  have h : env59648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59647_59648 : H12AffineEnvironment.transform 10 0 env59647 = env59648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env59647 == env59648) = true)

theorem identity59648 : scanCanonicalize (H12AffineFastState.compose env59648 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound59648 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env59649 : List Nat := [2,4,8,11,11,10,128,134,136,140,0,136,138,0,136,128,1,1,141,137,136,10,10,2,3,11,136,1,137,136,135,130,134,11,0,136]

theorem envBound59649 : H12AffineFastState.Bounded env59649 := by
  intro p hp
  have h : env59649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59648_59649 : H12AffineEnvironment.transform 3 11 env59648 = env59649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env59648 == env59649) = true)

theorem identity59649 : scanCanonicalize (H12AffineFastState.compose env59649 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound59649 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env59650 : List Nat := [2,4,8,11,11,10,8,14,0,4,0,0,2,0,0,8,1,1,5,1,0,10,10,2,3,11,0,1,1,0,15,10,14,11,0,0]

theorem envBound59650 : H12AffineFastState.Bounded env59650 := by
  intro p hp
  have h : env59650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59649_59650 : H12AffineEnvironment.transform 6 8 env59649 = env59650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env59649 == env59650) = true)

theorem identity59650 : scanCanonicalize (H12AffineFastState.compose env59650 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound59650 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59651 : List Nat := [2,3,8,11,11,10,8,9,0,3,0,0,2,0,0,8,1,1,2,1,0,10,10,2,3,11,0,1,1,0,8,10,9,11,0,0]

theorem envBound59651 : H12AffineFastState.Bounded env59651 := by
  intro p hp
  have h : env59651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59650_59651 : H12AffineEnvironment.transform 1 3 env59650 = env59651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env59650 == env59651) = true)

def env59652 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16465,262144,95615,32769,4096,61649,16,284033,86519,94526,77840,1297,74815,96347,381312,74799,256,323755,1344,95102]

theorem envBound59652 : H12AffineFastState.Bounded env59652 := by
  intro p hp
  have h : env59652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59594_59652 : H12AffineEnvironment.transform 16 16465 env59594 = env59652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16465 env59594 == env59652) = true)

def env59653 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1345,262144,77935,32769,4096,46529,16,266385,70887,78894,77840,1297,74815,81227,365712,74799,256,308667,1344,79470]

theorem envBound59653 : H12AffineFastState.Bounded env59653 := by
  intro p hp
  have h : env59653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59652_59653 : H12AffineEnvironment.transform 13 1296 env59652 = env59653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env59652 == env59653) = true)

theorem identity59653 : scanCanonicalize (H12AffineFastState.compose env59653 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound59653 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env59654 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1345,262144,77935,13340,4096,476,16,266385,70887,78894,77840,1297,74815,81227,336013,74799,256,262566,1344,79470]

theorem envBound59654 : H12AffineFastState.Bounded env59654 := by
  intro p hp
  have h : env59654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59653_59654 : H12AffineEnvironment.transform 14 13341 env59653 = env59654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env59653 == env59654) = true)

def env59655 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1345,65664,77935,13340,4096,476,16,69649,70887,78894,77840,1297,74815,81227,8205,74799,256,65830,1344,79470]

theorem envBound59655 : H12AffineFastState.Bounded env59655 := by
  intro p hp
  have h : env59655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59654_59655 : H12AffineEnvironment.transform 17 65664 env59654 = env59655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env59654 == env59655) = true)

theorem identity59655 : scanCanonicalize (H12AffineFastState.compose env59655 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 73) := by decide +kernel

theorem selectedBound59655 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env59656 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,73,1296,5204,65536,1345,65664,69670,5205,4096,476,16,69649,70887,70759,69721,1297,66678,72962,68,66662,256,65830,1344,71207]

theorem envBound59656 : H12AffineFastState.Bounded env59656 := by
  intro p hp
  have h : env59656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59655_59656 : H12AffineEnvironment.transform 12 73 env59655 = env59656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env59655 == env59656) = true)

def env59657 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,25,1296,5124,65536,1297,65664,69670,5125,4096,396,16,69649,70839,70711,69641,1297,66598,72962,20,66614,256,65830,1296,71207]

theorem envBound59657 : H12AffineFastState.Bounded env59657 := by
  intro p hp
  have h : env59657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59656_59657 : H12AffineEnvironment.transform 5 16 env59656 = env59657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env59656 == env59657) = true)

theorem identity59657 : scanCanonicalize (H12AffineFastState.compose env59657 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 5427) := by decide +kernel

theorem selectedBound59657 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59658 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,25,1296,5124,5427,1297,5555,1301,5125,4096,396,16,1314,388,260,1338,1297,4373,2097,20,4357,256,5141,1296,788]

theorem envBound59658 : H12AffineFastState.Bounded env59658 := by
  intro p hp
  have h : env59658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59657_59658 : H12AffineEnvironment.transform 15 5427 env59657 = env59658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5427 env59657 == env59658) = true)

def env59659 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,24,1296,5125,65536,1296,65664,69670,5124,4096,397,16,69649,70838,70710,69640,1297,66599,72962,21,66615,256,65830,1297,71207]

theorem envBound59659 : H12AffineFastState.Bounded env59659 := by
  intro p hp
  have h : env59659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59656_59659 : H12AffineEnvironment.transform 5 17 env59656 = env59659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env59656 == env59659) = true)

theorem identity59659 : scanCanonicalize (H12AffineFastState.compose env59659 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound59659 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59660 : List Nat := [2,4,8,16,32,17,128,20,512,1024,2048,4096,24,1028,5125,65536,1028,65664,69670,5124,4096,153,16,69649,70838,70710,69640,1029,66599,72726,21,66615,20,65586,1029,71207]

theorem envBound59660 : H12AffineFastState.Bounded env59660 := by
  intro p hp
  have h : env59660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59659_59660 : H12AffineEnvironment.transform 7 20 env59659 = env59660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env59659 == env59660) = true)

theorem identity59660 : scanCanonicalize (H12AffineFastState.compose env59660 (packedSelected [2,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 5806) := by decide +kernel

theorem selectedBound59660 : packedSelected [2,23,32] rootPS < 2^1333 := by decide +kernel

def env59661 : List Nat := [2,4,8,16,32,17,128,20,512,1024,2048,4096,24,1028,5125,5806,1028,5678,1672,5124,4096,153,16,1727,536,664,1702,1029,4745,2744,21,4761,20,5788,1029,137]

theorem envBound59661 : H12AffineFastState.Bounded env59661 := by
  intro p hp
  have h : env59661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59660_59661 : H12AffineEnvironment.transform 15 5806 env59660 = env59661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5806 env59660 == env59661) = true)

theorem identity59661 : scanCanonicalize (H12AffineFastState.compose env59661 (packedSelected [0,4,5,7,9,18,21,23,26,28] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound59661 : packedSelected [0,4,5,7,9,18,21,23,26,28] rootPS < 2^1333 := by decide +kernel

def env59662 : List Nat := [2,4,8,16,32,17,128,20,137,1024,2048,4096,24,1028,5125,5159,1028,5287,1025,5124,4096,153,16,1078,145,17,1071,1029,4096,2097,21,4112,20,5141,1029,137]

theorem envBound59662 : H12AffineFastState.Bounded env59662 := by
  intro p hp
  have h : env59662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59661_59662 : H12AffineEnvironment.transform 8 137 env59661 = env59662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env59661 == env59662) = true)

theorem identity59662 : scanCanonicalize (H12AffineFastState.compose env59662 (packedSelected [0,1,3,7,11,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 2185) := by decide +kernel

theorem selectedBound59662 : packedSelected [0,1,3,7,11,12,15] rootPS < 2^1333 := by decide +kernel

def env59663 : List Nat := [2,4,8,16,32,17,128,20,137,1024,2048,2185,24,1028,3212,3246,1028,3118,1025,3213,2185,153,16,1078,145,17,1071,1029,2185,2097,21,2201,20,3228,1029,137]

theorem envBound59663 : H12AffineFastState.Bounded env59663 := by
  intro p hp
  have h : env59663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59662_59663 : H12AffineEnvironment.transform 11 2185 env59662 = env59663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2185 env59662 == env59663) = true)

theorem identity59663 : scanCanonicalize (H12AffineFastState.compose env59663 (packedSelected [0,1,2,5,7,11] rootPS)) = affineNative (2^(9+1) ^^^ 167) := by decide +kernel

theorem selectedBound59663 : packedSelected [0,1,2,5,7,11] rootPS < 2^1333 := by decide +kernel

def env59664 : List Nat := [2,4,8,16,32,17,128,20,137,167,2048,2185,24,163,2091,2057,163,2185,166,2090,2185,153,16,145,145,17,136,162,2185,2097,21,2201,20,2107,162,137]

theorem envBound59664 : H12AffineFastState.Bounded env59664 := by
  intro p hp
  have h : env59664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59663_59664 : H12AffineEnvironment.transform 9 167 env59663 = env59664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 167 env59663 == env59664) = true)

theorem identity59664 : scanCanonicalize (H12AffineFastState.compose env59664 (packedSelected [1,2,5] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound59664 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env59665 : List Nat := [2,4,8,16,32,17,128,20,137,167,136,1,24,163,163,129,163,1,166,162,1,153,16,145,145,17,136,162,1,185,21,17,20,179,162,137]

theorem envBound59665 : H12AffineFastState.Bounded env59665 := by
  intro p hp
  have h : env59665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59664_59665 : H12AffineEnvironment.transform 10 136 env59664 = env59665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env59664 == env59665) = true)

theorem identity59665 : scanCanonicalize (H12AffineFastState.compose env59665 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound59665 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59666 : List Nat := [2,4,8,16,11,17,128,20,137,140,136,1,24,136,136,129,136,1,141,137,1,153,16,145,145,17,136,137,1,146,21,17,20,152,137,137]

theorem envBound59666 : H12AffineFastState.Bounded env59666 := by
  intro p hp
  have h : env59666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59665_59666 : H12AffineEnvironment.transform 4 11 env59665 = env59666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env59665 == env59666) = true)

def env59667 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1345,65665,77935,13340,4096,476,16,69648,70887,78894,77840,1297,74815,81227,8204,74799,256,65831,1344,79470]

theorem envBound59667 : H12AffineFastState.Bounded env59667 := by
  intro p hp
  have h : env59667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59654_59667 : H12AffineEnvironment.transform 17 65665 env59654 = env59667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env59654 == env59667) = true)

theorem identity59667 : scanCanonicalize (H12AffineFastState.compose env59667 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5385) := by decide +kernel

theorem selectedBound59667 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env59668 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5385,1296,276,65536,1345,65665,66918,277,4096,476,16,69648,70887,65831,66841,1297,69942,67650,5381,69926,256,65831,1344,66407]

theorem envBound59668 : H12AffineFastState.Bounded env59668 := by
  intro p hp
  have h : env59668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59667_59668 : H12AffineEnvironment.transform 12 5385 env59667 = env59668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5385 env59667 == env59668) = true)

def env59669 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5385,1296,276,65536,1297,65665,66870,277,4096,396,16,69648,70839,65831,66841,1297,69942,67602,5381,69926,256,65831,1296,66359]

theorem envBound59669 : H12AffineFastState.Bounded env59669 := by
  intro p hp
  have h : env59669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59668_59669 : H12AffineEnvironment.transform 5 16 env59668 = env59669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env59668 == env59669) = true)

theorem identity59669 : scanCanonicalize (H12AffineFastState.compose env59669 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 5426) := by decide +kernel

theorem selectedBound59669 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59670 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5385,1296,276,5426,1297,5555,4100,277,4096,396,16,1314,389,5141,4139,1297,1028,7456,5381,1044,256,5141,1296,5637]

theorem envBound59670 : H12AffineFastState.Bounded env59670 := by
  intro p hp
  have h : env59670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59669_59670 : H12AffineEnvironment.transform 15 5426 env59669 = env59670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5426 env59669 == env59670) = true)

theorem identity59670 : scanCanonicalize (H12AffineFastState.compose env59670 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound59670 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env59671 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1028,269,1296,276,310,1297,439,1024,277,1028,396,16,1314,389,17,1071,1297,1028,2340,257,1044,256,17,1296,513]

theorem envBound59671 : H12AffineFastState.Bounded env59671 := by
  intro p hp
  have h : env59671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59670_59671 : H12AffineEnvironment.transform 11 1028 env59670 = env59671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env59670 == env59671) = true)

theorem identity59671 : scanCanonicalize (H12AffineFastState.compose env59671 (packedSelected [2,13,17] rootPS)) = affineNative (2^(10+1) ^^^ 1702) := by decide +kernel

theorem selectedBound59671 : packedSelected [2,13,17] rootPS < 2^1333 := by decide +kernel

def env59672 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1702,1028,269,1296,276,310,1297,439,1024,277,1028,396,16,1314,389,17,1071,1297,1028,1922,257,1044,256,17,1296,513]

theorem envBound59672 : H12AffineFastState.Bounded env59672 := by
  intro p hp
  have h : env59672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59671_59672 : H12AffineEnvironment.transform 10 1702 env59671 = env59672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1702 env59671 == env59672) = true)

theorem identity59672 : scanCanonicalize (H12AffineFastState.compose env59672 (packedSelected [1,3,13] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound59672 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env59673 : List Nat := [2,4,8,16,32,16,56,256,512,1024,1566,1028,269,1296,276,310,1297,271,1024,277,1028,308,16,1314,317,17,1071,1297,1028,1850,257,1044,256,17,1296,513]

theorem envBound59673 : H12AffineFastState.Bounded env59673 := by
  intro p hp
  have h : env59673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59672_59673 : H12AffineEnvironment.transform 6 56 env59672 = env59673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env59672 == env59673) = true)

theorem identity59673 : scanCanonicalize (H12AffineFastState.compose env59673 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 309) := by decide +kernel

theorem selectedBound59673 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env59674 : List Nat := [2,4,8,16,32,16,56,256,309,1024,1323,1028,269,1296,276,310,1297,271,1024,277,1028,308,16,1314,317,17,1071,1297,1028,1039,257,1044,256,17,1296,308]

theorem envBound59674 : H12AffineFastState.Bounded env59674 := by
  intro p hp
  have h : env59674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59673_59674 : H12AffineEnvironment.transform 8 309 env59673 = env59674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 309 env59673 == env59674) = true)

theorem identity59674 : scanCanonicalize (H12AffineFastState.compose env59674 (packedSelected [1,2,4,5,8,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 50) := by decide +kernel

theorem selectedBound59674 : packedSelected [1,2,4,5,8,9,11] rootPS < 2^1333 := by decide +kernel

def env59675 : List Nat := [2,4,8,16,32,16,56,256,309,50,281,54,269,290,276,310,291,271,50,277,54,308,16,272,317,17,29,291,54,61,257,38,256,17,290,308]

theorem envBound59675 : H12AffineFastState.Bounded env59675 := by
  intro p hp
  have h : env59675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59674_59675 : H12AffineEnvironment.transform 9 50 env59674 = env59675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 50 env59674 == env59675) = true)

theorem identity59675 : scanCanonicalize (H12AffineFastState.compose env59675 (packedSelected [0,1,2,3,4,7,9,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 35) := by decide +kernel

theorem selectedBound59675 : packedSelected [0,1,2,3,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env59676 : List Nat := [2,4,8,16,32,16,56,35,22,50,58,54,46,1,55,21,0,44,50,54,54,23,16,51,30,17,29,0,54,61,34,38,35,17,1,23]

theorem envBound59676 : H12AffineFastState.Bounded env59676 := by
  intro p hp
  have h : env59676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59675_59676 : H12AffineEnvironment.transform 7 35 env59675 = env59676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 35 env59675 == env59676) = true)

theorem identity59676 : scanCanonicalize (H12AffineFastState.compose env59676 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound59676 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59677 : List Nat := [2,4,8,16,6,16,30,5,22,20,28,16,8,1,17,21,0,10,20,16,16,23,16,21,30,17,29,0,16,27,4,0,5,17,1,23]

theorem envBound59677 : H12AffineFastState.Bounded env59677 := by
  intro p hp
  have h : env59677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59676_59677 : H12AffineEnvironment.transform 4 6 env59676 = env59677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env59676 == env59677) = true)

theorem identity59677 : scanCanonicalize (H12AffineFastState.compose env59677 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound59677 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env59678 : List Nat := [2,4,4,16,6,16,18,5,22,20,16,16,4,1,17,21,0,6,20,16,16,23,16,21,18,17,17,0,16,23,4,0,5,17,1,23]

theorem envBound59678 : H12AffineFastState.Bounded env59678 := by
  intro p hp
  have h : env59678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59677_59678 : H12AffineEnvironment.transform 2 4 env59677 = env59678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env59677 == env59678) = true)

theorem identity59678 : scanCanonicalize (H12AffineFastState.compose env59678 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound59678 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env59679 : List Nat := [2,4,4,7,6,7,5,5,1,3,7,7,4,1,6,2,0,6,3,7,7,0,7,2,5,6,6,0,7,0,4,0,5,6,1,0]

theorem envBound59679 : H12AffineFastState.Bounded env59679 := by
  intro p hp
  have h : env59679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59678_59679 : H12AffineEnvironment.transform 3 7 env59678 = env59679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env59678 == env59679) = true)

theorem identity59679 : scanCanonicalize (H12AffineFastState.compose env59679 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound59679 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59680 : List Nat := [2,1,1,2,3,2,0,0,1,3,2,2,1,1,3,2,0,3,3,2,2,0,2,2,0,3,3,0,2,0,1,0,0,3,1,0]

theorem envBound59680 : H12AffineFastState.Bounded env59680 := by
  intro p hp
  have h : env59680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59679_59680 : H12AffineEnvironment.transform 1 1 env59679 = env59680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env59679 == env59680) = true)

theorem identity59680 : scanCanonicalize (H12AffineFastState.compose env59680 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound59680 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env59681 : List Nat := [0,1,1,0,1,0,0,0,1,1,0,0,1,1,1,0,0,1,1,0,0,0,0,0,0,1,1,0,0,0,1,0,0,1,1,0]

theorem envBound59681 : H12AffineFastState.Bounded env59681 := by
  intro p hp
  have h : env59681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59680_59681 : H12AffineEnvironment.transform 0 0 env59680 = env59681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env59680 == env59681) = true)

def env59682 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,5385,1296,276,65536,1296,65665,66871,277,4096,397,16,69648,70838,65831,66841,1297,69942,67603,5381,69926,256,65831,1297,66358]

theorem envBound59682 : H12AffineFastState.Bounded env59682 := by
  intro p hp
  have h : env59682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59668_59682 : H12AffineEnvironment.transform 5 17 env59668 = env59682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env59668 == env59682) = true)

theorem identity59682 : scanCanonicalize (H12AffineFastState.compose env59682 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound59682 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59683 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1028,269,1296,276,65536,1296,65665,66871,277,1028,397,16,66580,65714,65831,66841,1297,66866,67603,257,66850,256,65831,1297,66358]

theorem envBound59683 : H12AffineFastState.Bounded env59683 := by
  intro p hp
  have h : env59683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59682_59683 : H12AffineEnvironment.transform 11 1028 env59682 = env59683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env59682 == env59683) = true)

theorem identity59683 : scanCanonicalize (H12AffineFastState.compose env59683 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 310) := by decide +kernel

theorem selectedBound59683 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env59684 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1028,269,1296,276,310,1296,439,1025,277,1028,397,16,1314,388,17,1071,1297,1028,2341,257,1044,256,17,1297,512]

theorem envBound59684 : H12AffineFastState.Bounded env59684 := by
  intro p hp
  have h : env59684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59683_59684 : H12AffineEnvironment.transform 15 310 env59683 = env59684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 310 env59683 == env59684) = true)

theorem identity59684 : scanCanonicalize (H12AffineFastState.compose env59684 (packedSelected [2,13,17] rootPS)) = affineNative (2^(10+1) ^^^ 1944) := by decide +kernel

theorem selectedBound59684 : packedSelected [2,13,17] rootPS < 2^1333 := by decide +kernel

def env59685 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1944,1028,269,1296,276,310,1296,439,1025,277,1028,397,16,1314,388,17,1071,1297,1028,1725,257,1044,256,17,1297,512]

theorem envBound59685 : H12AffineFastState.Bounded env59685 := by
  intro p hp
  have h : env59685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59684_59685 : H12AffineEnvironment.transform 10 1944 env59684 = env59685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1944 env59684 == env59685) = true)

theorem identity59685 : scanCanonicalize (H12AffineFastState.compose env59685 (packedSelected [3,8,10,13] rootPS)) = affineNative (2^(9+1) ^^^ 937) := by decide +kernel

theorem selectedBound59685 : packedSelected [3,8,10,13] rootPS < 2^1333 := by decide +kernel

def env59686 : List Nat := [2,4,8,16,32,17,128,256,512,937,49,941,269,697,276,310,697,439,936,277,941,397,16,651,388,17,902,696,941,276,257,957,256,17,696,512]

theorem envBound59686 : H12AffineFastState.Bounded env59686 := by
  intro p hp
  have h : env59686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59685_59686 : H12AffineEnvironment.transform 9 937 env59685 = env59686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 937 env59685 == env59686) = true)

theorem identity59686 : scanCanonicalize (H12AffineFastState.compose env59686 (packedSelected [0,2,3,12] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound59686 : packedSelected [0,2,3,12] rootPS < 2^1333 := by decide +kernel

def env59687 : List Nat := [2,4,8,16,32,17,128,14,512,679,49,675,3,697,26,56,697,185,678,27,675,131,16,651,138,17,648,696,675,26,15,691,14,17,696,512]

theorem envBound59687 : H12AffineFastState.Bounded env59687 := by
  intro p hp
  have h : env59687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59686_59687 : H12AffineEnvironment.transform 7 14 env59686 = env59687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env59686 == env59687) = true)

theorem identity59687 : scanCanonicalize (H12AffineFastState.compose env59687 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(8+1) ^^^ 184) := by decide +kernel

theorem selectedBound59687 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env59688 : List Nat := [2,4,8,16,32,17,128,14,184,31,49,27,3,1,26,56,1,185,30,27,27,131,16,51,138,17,48,0,27,26,15,11,14,17,0,184]

theorem envBound59688 : H12AffineFastState.Bounded env59688 := by
  intro p hp
  have h : env59688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59687_59688 : H12AffineEnvironment.transform 8 184 env59687 = env59688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 184 env59687 == env59688) = true)

theorem identity59688 : scanCanonicalize (H12AffineFastState.compose env59688 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound59688 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59689 : List Nat := [2,4,8,16,32,17,35,14,27,31,49,27,3,1,26,56,1,26,30,27,27,32,16,51,41,17,48,0,27,26,15,11,14,17,0,27]

theorem envBound59689 : H12AffineFastState.Bounded env59689 := by
  intro p hp
  have h : env59689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59688_59689 : H12AffineEnvironment.transform 6 35 env59688 = env59689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env59688 == env59689) = true)

theorem identity59689 : scanCanonicalize (H12AffineFastState.compose env59689 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound59689 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env59690 : List Nat := [2,4,8,11,32,10,35,14,0,4,42,0,3,1,1,35,1,1,5,0,0,32,11,40,41,10,43,0,0,1,15,11,14,10,0,0]

theorem envBound59690 : H12AffineFastState.Bounded env59690 := by
  intro p hp
  have h : env59690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59689_59690 : H12AffineEnvironment.transform 3 11 env59689 = env59690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env59689 == env59690) = true)

theorem identity59690 : scanCanonicalize (H12AffineFastState.compose env59690 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound59690 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59691 : List Nat := [2,3,8,11,32,10,35,9,0,3,42,0,3,1,1,35,1,1,2,0,0,32,11,40,41,10,43,0,0,1,8,11,9,10,0,0]

theorem envBound59691 : H12AffineFastState.Bounded env59691 := by
  intro p hp
  have h : env59691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59690_59691 : H12AffineEnvironment.transform 1 3 env59690 = env59691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env59690 == env59691) = true)

theorem identity59691 : scanCanonicalize (H12AffineFastState.compose env59691 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound59691 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env59692 : List Nat := [2,3,8,11,10,10,9,9,0,3,0,0,3,1,1,9,1,1,2,0,0,10,11,2,3,10,1,0,0,1,8,11,9,10,0,0]

theorem envBound59692 : H12AffineFastState.Bounded env59692 := by
  intro p hp
  have h : env59692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59691_59692 : H12AffineEnvironment.transform 4 10 env59691 = env59692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env59691 == env59692) = true)

def env59693 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1344,262144,77934,32769,4096,46528,16,266384,70886,78895,77840,1297,74815,81226,365713,74799,256,308666,1344,79471]

theorem envBound59693 : H12AffineFastState.Bounded env59693 := by
  intro p hp
  have h : env59693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59652_59693 : H12AffineEnvironment.transform 13 1297 env59652 = env59693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env59652 == env59693) = true)

theorem identity59693 : scanCanonicalize (H12AffineFastState.compose env59693 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32883) := by decide +kernel

theorem selectedBound59693 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env59694 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,32883,1344,262144,45085,32769,4096,46528,16,266384,38037,46172,45155,1297,42060,48441,267490,42076,256,308666,1344,46620]

theorem envBound59694 : H12AffineFastState.Bounded env59694 := by
  intro p hp
  have h : env59694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59693_59694 : H12AffineEnvironment.transform 15 32883 env59693 = env59694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32883 env59693 == env59694) = true)

def env59695 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32883,1344,262144,42333,32769,1344,41088,16,263632,33237,41244,42275,1297,42060,43129,262562,42076,256,303354,1344,41820]

theorem envBound59695 : H12AffineFastState.Bounded env59695 := by
  intro p hp
  have h : env59695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59694_59695 : H12AffineEnvironment.transform 11 1344 env59694 = env59695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env59694 == env59695) = true)

theorem identity59695 : scanCanonicalize (H12AffineFastState.compose env59695 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 34226) := by decide +kernel

theorem selectedBound59695 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env59696 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32883,1344,34226,42333,32769,1344,41088,16,32866,33237,41244,42275,1297,42060,43129,33808,42076,256,9544,1344,41820]

theorem envBound59696 : H12AffineFastState.Bounded env59696 := by
  intro p hp
  have h : env59696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59695_59696 : H12AffineEnvironment.transform 17 34226 env59695 = env59696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 34226 env59695 == env59696) = true)

theorem identity59696 : scanCanonicalize (H12AffineFastState.compose env59696 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 8824) := by decide +kernel

theorem selectedBound59696 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env59697 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,8824,8715,1344,10186,1829,8825,1344,760,16,8730,9133,868,1883,1297,1588,2561,9832,1572,256,9544,1344,292]

theorem envBound59697 : H12AffineFastState.Bounded env59697 := by
  intro p hp
  have h : env59697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59696_59697 : H12AffineEnvironment.transform 14 8824 env59696 = env59697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8824 env59696 == env59697) = true)

def env59698 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32883,1344,262144,42332,32769,1345,41089,16,263633,33236,41245,42274,1297,42060,43128,262563,42076,256,303355,1344,41821]

theorem envBound59698 : H12AffineFastState.Bounded env59698 := by
  intro p hp
  have h : env59698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59694_59698 : H12AffineEnvironment.transform 11 1345 env59694 = env59698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env59694 == env59698) = true)

theorem identity59698 : scanCanonicalize (H12AffineFastState.compose env59698 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound59698 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env59699 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,8192,81,32768,32883,0,262144,40988,32769,1,41089,16,262289,33236,41245,41058,81,41228,43128,262563,41244,256,303355,0,41821]

theorem envBound59699 : H12AffineFastState.Bounded env59699 := by
  intro p hp
  have h : env59699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59698_59699 : H12AffineEnvironment.transform 9 320 env59698 = env59699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env59698 == env59699) = true)

theorem identity59699 : scanCanonicalize (H12AffineFastState.compose env59699 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound59699 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env59700 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,8192,81,8541,8494,0,262144,321,8540,1,476,16,262289,8329,64,319,81,81,2341,262563,65,256,262566,0,512]

theorem envBound59700 : H12AffineFastState.Bounded env59700 := by
  intro p hp
  have h : env59700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59699_59700 : H12AffineEnvironment.transform 14 8541 env59699 = env59700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env59699 == env59700) = true)

theorem identity59700 : scanCanonicalize (H12AffineFastState.compose env59700 (packedSelected [4,9,16] rootPS)) = affineNative (2^(17+1) ^^^ 242) := by decide +kernel

theorem selectedBound59700 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59701 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,8192,81,8541,8494,0,242,321,8540,1,476,16,99,8329,64,319,81,81,2341,337,65,256,340,0,512]

theorem envBound59701 : H12AffineFastState.Bounded env59701 := by
  intro p hp
  have h : env59701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59700_59701 : H12AffineEnvironment.transform 17 242 env59700 = env59701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 242 env59700 == env59701) = true)

theorem identity59701 : scanCanonicalize (H12AffineFastState.compose env59701 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 704) := by decide +kernel

theorem selectedBound59701 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env59702 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,704,81,925,1006,0,242,321,924,1,476,16,99,585,64,319,81,81,2341,337,65,256,340,0,512]

theorem envBound59702 : H12AffineFastState.Bounded env59702 := by
  intro p hp
  have h : env59702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59701_59702 : H12AffineEnvironment.transform 12 704 env59701 = env59702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 704 env59701 == env59702) = true)

theorem identity59702 : scanCanonicalize (H12AffineFastState.compose env59702 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound59702 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59703 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,657,0,925,959,0,163,272,924,1,397,16,50,536,17,319,0,0,2341,256,16,256,261,0,512]

theorem envBound59703 : H12AffineFastState.Bounded env59703 := by
  intro p hp
  have h : env59703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59702_59703 : H12AffineEnvironment.transform 5 17 env59702 = env59703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env59702 == env59703) = true)

theorem identity59703 : scanCanonicalize (H12AffineFastState.compose env59703 (packedSelected [5,8,17] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound59703 : packedSelected [5,8,17] rootPS < 2^1333 := by decide +kernel

def env59704 : List Nat := [2,4,8,16,32,17,57,256,512,273,2048,1,552,0,804,774,0,26,272,805,1,308,16,50,536,17,319,0,0,2341,256,16,256,261,0,512]

theorem envBound59704 : H12AffineFastState.Bounded env59704 := by
  intro p hp
  have h : env59704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59703_59704 : H12AffineEnvironment.transform 6 57 env59703 = env59704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env59703 == env59704) = true)

theorem identity59704 : scanCanonicalize (H12AffineFastState.compose env59704 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 788) := by decide +kernel

theorem selectedBound59704 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59705 : List Nat := [2,4,8,16,32,17,57,256,512,273,788,1,552,0,804,774,0,26,272,805,1,308,16,50,536,17,319,0,0,561,256,16,256,261,0,512]

theorem envBound59705 : H12AffineFastState.Bounded env59705 := by
  intro p hp
  have h : env59705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59704_59705 : H12AffineEnvironment.transform 10 788 env59704 = env59705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 788 env59704 == env59705) = true)

theorem identity59705 : scanCanonicalize (H12AffineFastState.compose env59705 (packedSelected [0,1,3,5] rootPS)) = affineNative (2^(8+1) ^^^ 270) := by decide +kernel

theorem selectedBound59705 : packedSelected [0,1,3,5] rootPS < 2^1333 := by decide +kernel

def env59706 : List Nat := [2,4,8,16,32,17,57,256,270,273,26,1,294,0,42,8,0,26,272,43,1,308,16,50,278,17,319,0,0,319,256,16,256,261,0,270]

theorem envBound59706 : H12AffineFastState.Bounded env59706 := by
  intro p hp
  have h : env59706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59705_59706 : H12AffineEnvironment.transform 8 270 env59705 = env59706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 270 env59705 == env59706) = true)

theorem identity59706 : scanCanonicalize (H12AffineFastState.compose env59706 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound59706 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env59707 : List Nat := [2,4,8,10,32,11,35,256,270,267,0,1,294,0,42,8,0,0,266,43,1,302,10,40,268,11,293,0,0,293,256,10,256,261,0,270]

theorem envBound59707 : H12AffineFastState.Bounded env59707 := by
  intro p hp
  have h : env59707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59706_59707 : H12AffineEnvironment.transform 3 10 env59706 = env59707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env59706 == env59707) = true)

theorem identity59707 : scanCanonicalize (H12AffineFastState.compose env59707 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound59707 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env59708 : List Nat := [2,4,8,10,32,11,35,36,42,47,0,1,2,0,42,8,0,0,46,43,1,10,10,40,40,11,1,0,0,1,36,10,36,33,0,42]

theorem envBound59708 : H12AffineFastState.Bounded env59708 := by
  intro p hp
  have h : env59708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59707_59708 : H12AffineEnvironment.transform 7 36 env59707 = env59708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env59707 == env59708) = true)

def env59709 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,16777216,533640,672784,17245633,148800,545088,96347,16876545,74799,256,17420373,1345,525825]

theorem envBound59709 : H12AffineFastState.Bounded env59709 := by
  intro p hp
  have h : env59709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59470_59709 : H12AffineEnvironment.transform 26 17245633 env59470 = env59709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env59470 == env59709) = true)

theorem identity59709 : scanCanonicalize (H12AffineFastState.compose env59709 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 74863) := by decide +kernel

theorem selectedBound59709 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env59710 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,524288,32769,4096,61649,91182,16777216,533640,614527,17039790,90415,545088,96347,16876545,74799,256,17420373,1345,525825]

theorem envBound59710 : H12AffineFastState.Bounded env59710 := by
  intro p hp
  have h : env59710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59709_59710 : H12AffineEnvironment.transform 16 74863 env59709 = env59710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 74863 env59709 == env59710) = true)

def env59711 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,524288,32769,4096,61649,91182,123164,533640,614527,385202,90415,545088,96347,25885,74799,256,536905,1345,525825]

theorem envBound59711 : H12AffineFastState.Bounded env59711 := by
  intro p hp
  have h : env59711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59710_59711 : H12AffineEnvironment.transform 23 123164 env59710 = env59711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123164 env59710 == env59711) = true)

def env59712 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21584,32769,4096,61649,91182,123164,28888,78895,385202,90415,1296,96347,25885,74799,256,25881,1345,21073]

theorem envBound59712 : H12AffineFastState.Bounded env59712 := by
  intro p hp
  have h : env59712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59711_59712 : H12AffineEnvironment.transform 18 21584 env59711 = env59712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env59711 == env59712) = true)

theorem identity59712 : scanCanonicalize (H12AffineFastState.compose env59712 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound59712 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env59713 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13341,65536,74863,262144,21584,13340,4096,17612,91182,87297,28888,78895,349359,90415,1296,96347,25885,74799,256,25881,1345,21073]

theorem envBound59713 : H12AffineFastState.Bounded env59713 := by
  intro p hp
  have h : env59713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59712_59713 : H12AffineEnvironment.transform 14 13341 env59712 = env59713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env59712 == env59713) = true)

def env59714 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74863,262144,4416,13340,4096,476,74046,69649,13768,78895,332223,74815,1296,81227,8205,74799,256,8201,1345,5953]

theorem envBound59714 : H12AffineFastState.Bounded env59714 := by
  intro p hp
  have h : env59714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59713_59714 : H12AffineEnvironment.transform 13 1296 env59713 = env59714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env59713 == env59714) = true)

def env59715 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74863,65664,4416,13340,4096,476,74046,69649,13768,78895,4415,74815,1296,81227,8205,74799,256,8201,1345,5953]

theorem envBound59715 : H12AffineFastState.Bounded env59715 := by
  intro p hp
  have h : env59715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59714_59715 : H12AffineEnvironment.transform 17 65664 env59714 = env59715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env59714 == env59715) = true)

theorem identity59715 : scanCanonicalize (H12AffineFastState.compose env59715 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12591) := by decide +kernel

theorem selectedBound59715 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env59716 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,12591,5440,12719,4416,13340,4096,476,4113,8510,13768,1280,4415,5392,1296,3172,8205,5376,256,8201,1345,5953]

theorem envBound59716 : H12AffineFastState.Bounded env59716 := by
  intro p hp
  have h : env59716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59715_59716 : H12AffineEnvironment.transform 15 12591 env59715 = env59716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12591 env59715 == env59716) = true)

def env59717 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1296,9245,8495,1344,8623,320,9244,0,476,17,8510,9672,1280,319,1296,1296,3172,8205,1280,256,8201,1345,1857]

theorem envBound59717 : H12AffineFastState.Bounded env59717 := by
  intro p hp
  have h : env59717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59716_59717 : H12AffineEnvironment.transform 11 0 env59716 = env59717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env59716 == env59717) = true)

theorem identity59717 : scanCanonicalize (H12AffineFastState.compose env59717 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound59717 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env59718 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,25,1296,1028,310,1344,438,320,1029,0,476,17,295,1489,1280,319,1296,1296,3172,20,1280,256,16,1345,1857]

theorem envBound59718 : H12AffineFastState.Bounded env59718 := by
  intro p hp
  have h : env59718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59717_59718 : H12AffineEnvironment.transform 12 25 env59717 = env59718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env59717 == env59718) = true)

theorem identity59718 : scanCanonicalize (H12AffineFastState.compose env59718 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound59718 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env59719 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,0,25,1213,1028,155,1261,27,237,1029,0,113,17,138,1148,1197,146,1213,1213,3172,20,1197,173,16,1260,1772]

theorem envBound59719 : H12AffineFastState.Bounded env59719 := by
  intro p hp
  have h : env59719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59718_59719 : H12AffineEnvironment.transform 7 173 env59718 = env59719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env59718 == env59719) = true)

theorem identity59719 : scanCanonicalize (H12AffineFastState.compose env59719 (packedSelected [0,2,3,5,7,10,11,12,15,16,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 674) := by decide +kernel

theorem selectedBound59719 : packedSelected [0,2,3,5,7,10,11,12,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env59720 : List Nat := [2,4,8,16,32,64,128,173,512,1024,674,0,25,1213,1028,155,1261,27,237,1029,0,113,17,138,1148,1197,146,1213,1213,1734,20,1197,173,16,1260,1772]

theorem envBound59720 : H12AffineFastState.Bounded env59720 := by
  intro p hp
  have h : env59720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59719_59720 : H12AffineEnvironment.transform 10 674 env59719 = env59720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 674 env59719 == env59720) = true)

theorem identity59720 : scanCanonicalize (H12AffineFastState.compose env59720 (packedSelected [0,2,3,4,7,8,9,10,12,15] rootPS)) = affineNative (2^(8+1) ^^^ 162) := by decide +kernel

theorem selectedBound59720 : packedSelected [0,2,3,4,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env59721 : List Nat := [2,4,8,16,32,64,128,173,162,1024,0,0,25,1213,1028,155,1261,27,237,1029,0,113,17,138,1148,1197,146,1213,1213,1124,20,1197,173,16,1260,1102]

theorem envBound59721 : H12AffineFastState.Bounded env59721 := by
  intro p hp
  have h : env59721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59720_59721 : H12AffineEnvironment.transform 8 162 env59720 = env59721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 162 env59720 == env59721) = true)

theorem identity59721 : scanCanonicalize (H12AffineFastState.compose env59721 (packedSelected [0,1,4,7,8,9,12,13] rootPS)) = affineNative (2^(9+1) ^^^ 141) := by decide +kernel

theorem selectedBound59721 : packedSelected [0,1,4,7,8,9,12,13] rootPS < 2^1333 := by decide +kernel

def env59722 : List Nat := [2,4,8,16,32,64,128,173,162,141,0,0,25,48,137,155,96,27,237,136,0,113,17,138,241,32,146,48,48,233,20,32,173,16,97,195]

theorem envBound59722 : H12AffineFastState.Bounded env59722 := by
  intro p hp
  have h : env59722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59721_59722 : H12AffineEnvironment.transform 9 141 env59721 = env59722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 141 env59721 == env59722) = true)

theorem identity59722 : scanCanonicalize (H12AffineFastState.compose env59722 (packedSelected [0,2,3,4,8,10] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound59722 : packedSelected [0,2,3,4,8,10] rootPS < 2^1333 := by decide +kernel

def env59723 : List Nat := [2,4,8,16,17,64,128,156,147,141,0,0,25,1,137,155,81,27,220,136,0,64,17,138,192,17,146,1,1,216,20,17,156,16,80,195]

theorem envBound59723 : H12AffineFastState.Bounded env59723 := by
  intro p hp
  have h : env59723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59722_59723 : H12AffineEnvironment.transform 4 17 env59722 = env59723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env59722 == env59723) = true)

theorem identity59723 : scanCanonicalize (H12AffineFastState.compose env59723 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound59723 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59724 : List Nat := [2,4,8,10,11,64,128,134,137,141,0,0,3,1,137,129,75,1,198,136,0,64,11,138,192,11,136,1,1,194,14,11,134,10,74,195]

theorem envBound59724 : H12AffineFastState.Bounded env59724 := by
  intro p hp
  have h : env59724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59723_59724 : H12AffineEnvironment.transform 3 10 env59723 = env59724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env59723 == env59724) = true)

theorem identity59724 : scanCanonicalize (H12AffineFastState.compose env59724 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound59724 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env59725 : List Nat := [2,4,4,6,7,64,128,134,133,129,0,0,3,1,133,129,71,1,198,132,0,64,7,134,192,7,132,1,1,194,2,7,134,6,70,195]

theorem envBound59725 : H12AffineFastState.Bounded env59725 := by
  intro p hp
  have h : env59725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59724_59725 : H12AffineEnvironment.transform 2 4 env59724 = env59725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env59724 == env59725) = true)

theorem identity59725 : scanCanonicalize (H12AffineFastState.compose env59725 (packedSelected [5] rootPS)) = affineNative (2^(5+1) ^^^ 6) := by decide +kernel

theorem selectedBound59725 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env59726 : List Nat := [2,4,4,6,7,6,128,134,133,129,0,0,3,1,133,129,1,1,128,132,0,6,7,134,134,7,132,1,1,132,2,7,134,6,0,133]

theorem envBound59726 : H12AffineFastState.Bounded env59726 := by
  intro p hp
  have h : env59726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59725_59726 : H12AffineEnvironment.transform 5 6 env59725 = env59726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 6 env59725 == env59726) = true)

theorem identity59726 : scanCanonicalize (H12AffineFastState.compose env59726 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound59726 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59727 : List Nat := [2,4,4,6,7,6,5,3,0,4,0,0,3,1,0,4,1,1,5,1,0,6,7,3,3,7,1,1,1,1,2,7,3,6,0,0]

theorem envBound59727 : H12AffineFastState.Bounded env59727 := by
  intro p hp
  have h : env59727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59726_59727 : H12AffineEnvironment.transform 6 5 env59726 = env59727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env59726 == env59727) = true)

def env59728 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1296,9244,8494,1345,8622,321,9245,1,476,16,8510,9673,1280,318,1297,1296,3172,8205,1281,256,8201,1345,1856]

theorem envBound59728 : H12AffineFastState.Bounded env59728 := by
  intro p hp
  have h : env59728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59716_59728 : H12AffineEnvironment.transform 11 1 env59716 = env59728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env59716 == env59728) = true)

theorem identity59728 : scanCanonicalize (H12AffineFastState.compose env59728 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound59728 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env59729 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,269,1296,1297,35,1345,163,321,1296,1,476,16,51,1220,1280,318,1297,1296,3172,256,1281,256,260,1345,1856]

theorem envBound59729 : H12AffineFastState.Bounded env59729 := by
  intro p hp
  have h : env59729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59728_59729 : H12AffineEnvironment.transform 12 269 env59728 = env59729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env59728 == env59729) = true)

theorem identity59729 : scanCanonicalize (H12AffineFastState.compose env59729 (packedSelected [1,2,3,10,12,15,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 950) := by decide +kernel

theorem selectedBound59729 : packedSelected [1,2,3,10,12,15,17,18,20] rootPS < 2^1333 := by decide +kernel

def env59730 : List Nat := [2,4,8,16,32,64,128,256,512,1024,950,1,269,1296,1297,35,1345,163,321,1296,1,476,16,51,1220,1280,318,1297,1296,2002,256,1281,256,260,1345,1856]

theorem envBound59730 : H12AffineFastState.Bounded env59730 := by
  intro p hp
  have h : env59730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59729_59730 : H12AffineEnvironment.transform 10 950 env59729 = env59730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 950 env59729 == env59730) = true)

theorem identity59730 : scanCanonicalize (H12AffineFastState.compose env59730 (packedSelected [1,3,12,15,16,17,19,23] rootPS)) = affineNative (2^(8+1) ^^^ 216) := by decide +kernel

theorem selectedBound59730 : packedSelected [1,3,12,15,16,17,19,23] rootPS < 2^1333 := by decide +kernel

def env59731 : List Nat := [2,4,8,16,32,64,128,256,216,1024,366,1,269,1296,1297,35,1345,163,321,1296,1,476,16,51,1220,1280,318,1297,1296,1290,256,1281,256,260,1345,1432]

theorem envBound59731 : H12AffineFastState.Bounded env59731 := by
  intro p hp
  have h : env59731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59730_59731 : H12AffineEnvironment.transform 8 216 env59730 = env59731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env59730 == env59731) = true)

theorem identity59731 : scanCanonicalize (H12AffineFastState.compose env59731 (packedSelected [1,2,3,4,5,8,9,12,13,15,16] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound59731 : packedSelected [1,2,3,4,5,8,9,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env59732 : List Nat := [2,4,8,16,32,64,128,256,216,189,366,1,269,429,428,35,508,163,321,429,1,476,16,51,121,445,318,428,429,439,256,444,256,260,508,293]

theorem envBound59732 : H12AffineFastState.Bounded env59732 := by
  intro p hp
  have h : env59732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59731_59732 : H12AffineEnvironment.transform 9 189 env59731 = env59732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env59731 == env59732) = true)

theorem identity59732 : scanCanonicalize (H12AffineFastState.compose env59732 (packedSelected [0,1,2,3,5,8,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 63) := by decide +kernel

theorem selectedBound59732 : packedSelected [0,1,2,3,5,8,9,10] rootPS < 2^1333 := by decide +kernel

def env59733 : List Nat := [2,4,8,16,32,64,128,63,216,189,81,1,50,146,147,35,195,163,126,146,1,227,16,51,121,130,1,147,146,136,63,131,63,59,195,26]

theorem envBound59733 : H12AffineFastState.Bounded env59733 := by
  intro p hp
  have h : env59733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59732_59733 : H12AffineEnvironment.transform 7 63 env59732 = env59733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env59732 == env59733) = true)

theorem identity59733 : scanCanonicalize (H12AffineFastState.compose env59733 (packedSelected [1,7,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound59733 : packedSelected [1,7,8,9] rootPS < 2^1333 := by decide +kernel

def env59734 : List Nat := [2,4,8,16,32,64,56,63,96,5,81,1,50,42,43,35,123,27,126,42,1,91,16,51,121,58,1,43,42,48,63,59,63,59,123,26]

theorem envBound59734 : H12AffineFastState.Bounded env59734 := by
  intro p hp
  have h : env59734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59733_59734 : H12AffineEnvironment.transform 6 56 env59733 = env59734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env59733 == env59734) = true)

theorem identity59734 : scanCanonicalize (H12AffineFastState.compose env59734 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound59734 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env59735 : List Nat := [2,4,8,16,11,64,19,20,75,5,81,1,25,1,0,8,80,27,85,1,1,91,16,24,82,17,1,0,1,27,20,16,20,16,80,26]

theorem envBound59735 : H12AffineFastState.Bounded env59735 := by
  intro p hp
  have h : env59735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59734_59735 : H12AffineEnvironment.transform 4 11 env59734 = env59735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env59734 == env59735) = true)

def env59736 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74863,65665,4416,13340,4096,476,74046,69649,13768,78895,4414,74815,1296,81227,8205,74799,256,8201,1345,5953]

theorem envBound59736 : H12AffineFastState.Bounded env59736 := by
  intro p hp
  have h : env59736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59714_59736 : H12AffineEnvironment.transform 17 65665 env59714 = env59736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env59714 == env59736) = true)

theorem identity59736 : scanCanonicalize (H12AffineFastState.compose env59736 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9327) := by decide +kernel

theorem selectedBound59736 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env59737 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,9327,0,9454,4416,13340,4096,476,1361,13438,13768,4160,4414,80,1296,6436,8205,64,256,8201,1345,5953]

theorem envBound59737 : H12AffineFastState.Bounded env59737 := by
  intro p hp
  have h : env59737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59736_59737 : H12AffineEnvironment.transform 15 9327 env59736 = env59737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9327 env59736 == env59737) = true)

def env59738 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,80,12637,8495,0,8622,4416,12636,4096,476,17,12606,12424,4160,4414,80,80,6436,8205,64,256,8201,1,4609]

theorem envBound59738 : H12AffineFastState.Bounded env59738 := by
  intro p hp
  have h : env59738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59737_59738 : H12AffineEnvironment.transform 9 320 env59737 = env59738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env59737 == env59738) = true)

theorem identity59738 : scanCanonicalize (H12AffineFastState.compose env59738 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 4121) := by decide +kernel

theorem selectedBound59738 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env59739 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,4121,80,324,4406,0,4535,4416,325,4096,476,17,295,145,4160,4414,80,80,6436,4116,64,256,4112,1,4609]

theorem envBound59739 : H12AffineFastState.Bounded env59739 := by
  intro p hp
  have h : env59739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59738_59739 : H12AffineEnvironment.transform 12 4121 env59738 = env59739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4121 env59738 == env59739) = true)

theorem identity59739 : scanCanonicalize (H12AffineFastState.compose env59739 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound59739 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env59740 : List Nat := [2,4,8,16,32,64,128,173,512,237,2048,4096,4121,80,233,4251,0,4122,4333,232,4096,113,17,138,145,4160,4243,80,80,6281,4116,64,173,4112,1,4609]

theorem envBound59740 : H12AffineFastState.Bounded env59740 := by
  intro p hp
  have h : env59740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59739_59740 : H12AffineEnvironment.transform 7 173 env59739 = env59740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env59739 == env59740) = true)

theorem identity59740 : scanCanonicalize (H12AffineFastState.compose env59740 (packedSelected [0,2,3,5,7,10,11,12,15,16,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 675) := by decide +kernel

theorem selectedBound59740 : packedSelected [0,2,3,5,7,10,11,12,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env59741 : List Nat := [2,4,8,16,32,64,128,173,512,237,675,4096,4121,80,233,4251,0,4122,4333,232,4096,113,17,138,145,4160,4243,80,80,4650,4116,64,173,4112,1,4609]

theorem envBound59741 : H12AffineFastState.Bounded env59741 := by
  intro p hp
  have h : env59741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59740_59741 : H12AffineEnvironment.transform 10 675 env59740 = env59741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 675 env59740 == env59741) = true)

theorem identity59741 : scanCanonicalize (H12AffineFastState.compose env59741 (packedSelected [0,2,3,4,7,8,9,10,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 674) := by decide +kernel

theorem selectedBound59741 : packedSelected [0,2,3,4,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env59742 : List Nat := [2,4,8,16,32,64,128,173,512,237,675,674,699,80,233,569,0,696,591,232,674,113,17,138,145,738,561,80,80,136,694,64,173,690,1,163]

theorem envBound59742 : H12AffineFastState.Bounded env59742 := by
  intro p hp
  have h : env59742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59741_59742 : H12AffineEnvironment.transform 11 674 env59741 = env59742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 674 env59741 == env59742) = true)

theorem identity59742 : scanCanonicalize (H12AffineFastState.compose env59742 (packedSelected [0,1,4,7,8,9,12] rootPS)) = affineNative (2^(6+1) ^^^ 67) := by decide +kernel

theorem selectedBound59742 : packedSelected [0,1,4,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env59743 : List Nat := [2,4,8,16,32,64,67,110,512,46,608,609,632,80,42,569,0,635,591,43,609,113,17,73,82,545,561,80,80,75,629,64,110,625,1,96]

theorem envBound59743 : H12AffineFastState.Bounded env59743 := by
  intro p hp
  have h : env59743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59742_59743 : H12AffineEnvironment.transform 6 67 env59742 = env59743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 67 env59742 == env59743) = true)

theorem identity59743 : scanCanonicalize (H12AffineFastState.compose env59743 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound59743 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env59744 : List Nat := [2,4,8,16,32,32,35,14,512,46,512,513,536,48,42,569,0,539,559,43,513,17,17,41,50,545,561,48,48,43,533,32,14,529,1,0]

theorem envBound59744 : H12AffineFastState.Bounded env59744 := by
  intro p hp
  have h : env59744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59743_59744 : H12AffineEnvironment.transform 5 32 env59743 = env59744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env59743 == env59744) = true)

theorem identity59744 : scanCanonicalize (H12AffineFastState.compose env59744 (packedSelected [1,2,8] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound59744 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env59745 : List Nat := [2,4,8,16,10,10,9,14,512,4,512,513,536,26,0,531,0,539,517,1,513,17,17,3,24,523,539,26,26,1,533,10,14,529,1,0]

theorem envBound59745 : H12AffineFastState.Bounded env59745 := by
  intro p hp
  have h : env59745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59744_59745 : H12AffineEnvironment.transform 4 10 env59744 = env59745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env59744 == env59745) = true)

theorem identity59745 : scanCanonicalize (H12AffineFastState.compose env59745 (packedSelected [1,2,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound59745 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env59746 : List Nat := [2,4,8,10,10,10,9,14,512,4,512,513,514,0,0,521,0,513,517,1,513,11,11,3,2,523,513,0,0,1,527,10,14,523,1,0]

theorem envBound59746 : H12AffineFastState.Bounded env59746 := by
  intro p hp
  have h : env59746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59745_59746 : H12AffineEnvironment.transform 3 10 env59745 = env59746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env59745 == env59746) = true)

theorem identity59746 : scanCanonicalize (H12AffineFastState.compose env59746 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound59746 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59747 : List Nat := [2,4,8,10,10,10,9,14,1,4,1,0,3,0,0,8,0,0,4,1,0,11,11,3,2,10,0,0,0,1,14,10,14,10,1,0]

theorem envBound59747 : H12AffineFastState.Bounded env59747 := by
  intro p hp
  have h : env59747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59746_59747 : H12AffineEnvironment.transform 8 1 env59746 = env59747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env59746 == env59747) = true)

theorem identity59747 : scanCanonicalize (H12AffineFastState.compose env59747 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound59747 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59748 : List Nat := [2,4,7,5,5,5,6,1,1,4,1,0,3,0,0,7,0,0,4,1,0,4,4,3,2,5,0,0,0,1,1,5,1,5,1,0]

theorem envBound59748 : H12AffineFastState.Bounded env59748 := by
  intro p hp
  have h : env59748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59747_59748 : H12AffineEnvironment.transform 2 7 env59747 = env59748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env59747 == env59748) = true)

theorem identity59748 : scanCanonicalize (H12AffineFastState.compose env59748 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound59748 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env59749 : List Nat := [2,3,0,2,2,2,1,1,1,3,1,0,3,0,0,0,0,0,3,1,0,3,3,3,2,2,0,0,0,1,1,2,1,2,1,0]

theorem envBound59749 : H12AffineFastState.Bounded env59749 := by
  intro p hp
  have h : env59749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59748_59749 : H12AffineEnvironment.transform 1 3 env59748 = env59749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env59748 == env59749) = true)

theorem identity59749 : scanCanonicalize (H12AffineFastState.compose env59749 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound59749 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env59750 : List Nat := [0,1,0,0,0,0,1,1,1,1,1,0,1,0,0,0,0,0,1,1,0,1,1,1,0,0,0,0,0,1,1,0,1,0,1,0]

theorem envBound59750 : H12AffineFastState.Bounded env59750 := by
  intro p hp
  have h : env59750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59749_59750 : H12AffineEnvironment.transform 0 0 env59749 = env59750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env59749 == env59750) = true)

def env59751 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,81,12636,8494,0,8623,4416,12637,4096,476,16,12607,12425,4160,4414,80,81,6436,8205,64,256,8201,0,4608]

theorem envBound59751 : H12AffineFastState.Bounded env59751 := by
  intro p hp
  have h : env59751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59737_59751 : H12AffineEnvironment.transform 9 321 env59737 = env59751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env59737 == env59751) = true)

theorem identity59751 : scanCanonicalize (H12AffineFastState.compose env59751 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound59751 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env59752 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,269,81,4177,35,0,162,4416,4176,4096,476,16,4146,4484,4160,4414,80,81,6436,256,64,256,260,0,4608]

theorem envBound59752 : H12AffineFastState.Bounded env59752 := by
  intro p hp
  have h : env59752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59751_59752 : H12AffineEnvironment.transform 12 269 env59751 = env59752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env59751 == env59752) = true)

theorem identity59752 : scanCanonicalize (H12AffineFastState.compose env59752 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound59752 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env59753 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,0,269,81,81,35,0,162,320,80,0,476,16,50,388,64,318,80,81,2340,256,64,256,260,0,512]

theorem envBound59753 : H12AffineFastState.Bounded env59753 := by
  intro p hp
  have h : env59753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59752_59753 : H12AffineEnvironment.transform 11 0 env59752 = env59753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env59752 == env59753) = true)

theorem identity59753 : scanCanonicalize (H12AffineFastState.compose env59753 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound59753 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59754 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,269,0,0,35,0,162,273,1,0,397,16,50,388,17,318,1,0,2340,256,17,256,260,0,512]

theorem envBound59754 : H12AffineFastState.Bounded env59754 := by
  intro p hp
  have h : env59754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59753_59754 : H12AffineEnvironment.transform 5 17 env59753 = env59754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env59753 == env59754) = true)

theorem identity59754 : scanCanonicalize (H12AffineFastState.compose env59754 (packedSelected [1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound59754 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env59755 : List Nat := [2,4,8,16,32,17,128,256,0,272,2048,0,269,0,0,35,0,162,273,1,0,397,16,50,388,17,318,1,0,2340,256,17,256,260,0,0]

theorem envBound59755 : H12AffineFastState.Bounded env59755 := by
  intro p hp
  have h : env59755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59754_59755 : H12AffineEnvironment.transform 8 0 env59754 = env59755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env59754 == env59755) = true)

theorem identity59755 : scanCanonicalize (H12AffineFastState.compose env59755 (packedSelected [3,8] rootPS)) = affineNative (2^(10+1) ^^^ 270) := by decide +kernel

theorem selectedBound59755 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env59756 : List Nat := [2,4,8,16,32,17,128,256,0,272,270,0,269,0,0,35,0,162,273,1,0,397,16,50,388,17,318,1,0,42,256,17,256,260,0,0]

theorem envBound59756 : H12AffineFastState.Bounded env59756 := by
  intro p hp
  have h : env59756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59755_59756 : H12AffineEnvironment.transform 10 270 env59755 = env59756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 270 env59755 == env59756) = true)

theorem identity59756 : scanCanonicalize (H12AffineFastState.compose env59756 (packedSelected [1,2,3,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound59756 : packedSelected [1,2,3,10] rootPS < 2^1333 := by decide +kernel

def env59757 : List Nat := [2,4,8,16,32,17,9,256,0,272,270,0,269,0,0,35,0,43,273,1,0,260,16,50,269,17,318,1,0,42,256,17,256,260,0,0]

theorem envBound59757 : H12AffineFastState.Bounded env59757 := by
  intro p hp
  have h : env59757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59756_59757 : H12AffineEnvironment.transform 6 9 env59756 = env59757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env59756 == env59757) = true)

theorem identity59757 : scanCanonicalize (H12AffineFastState.compose env59757 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 63) := by decide +kernel

theorem selectedBound59757 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env59758 : List Nat := [2,4,8,16,32,17,9,63,0,47,49,0,50,0,0,35,0,43,46,1,0,59,16,50,50,17,1,1,0,42,63,17,63,59,0,0]

theorem envBound59758 : H12AffineFastState.Bounded env59758 := by
  intro p hp
  have h : env59758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59757_59758 : H12AffineEnvironment.transform 7 63 env59757 = env59758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env59757 == env59758) = true)

theorem identity59758 : scanCanonicalize (H12AffineFastState.compose env59758 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound59758 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env59759 : List Nat := [2,4,8,16,10,17,9,21,0,5,27,0,24,0,0,9,0,1,4,1,0,17,16,24,24,17,1,1,0,0,21,17,21,17,0,0]

theorem envBound59759 : H12AffineFastState.Bounded env59759 := by
  intro p hp
  have h : env59759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59758_59759 : H12AffineEnvironment.transform 4 10 env59758 = env59759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env59758 == env59759) = true)

theorem identity59759 : scanCanonicalize (H12AffineFastState.compose env59759 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound59759 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59760 : List Nat := [2,4,8,12,10,13,9,9,0,5,7,0,4,0,0,9,0,1,4,1,0,13,12,4,4,13,1,1,0,0,9,13,9,13,0,0]

theorem envBound59760 : H12AffineFastState.Bounded env59760 := by
  intro p hp
  have h : env59760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59759_59760 : H12AffineEnvironment.transform 3 12 env59759 = env59760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env59759 == env59760) = true)

def env59761 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74863,262144,4417,13340,4096,477,74047,69648,13769,78895,332222,74814,1296,81226,8204,74799,256,8200,1345,5952]

theorem envBound59761 : H12AffineFastState.Bounded env59761 := by
  intro p hp
  have h : env59761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59713_59761 : H12AffineEnvironment.transform 13 1297 env59713 = env59761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env59713 == env59761) = true)

def env59762 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74863,65664,4417,13340,4096,477,74047,69648,13769,78895,4414,74814,1296,81226,8204,74799,256,8200,1345,5952]

theorem envBound59762 : H12AffineFastState.Bounded env59762 := by
  intro p hp
  have h : env59762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59761_59762 : H12AffineEnvironment.transform 17 65664 env59761 = env59762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env59761 == env59762) = true)

theorem identity59762 : scanCanonicalize (H12AffineFastState.compose env59762 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 359) := by decide +kernel

theorem selectedBound59762 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env59763 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,359,9480,487,4417,13340,4096,477,8280,4471,13769,13640,4414,9561,1296,15405,8204,9544,256,8200,1345,5952]

theorem envBound59763 : H12AffineFastState.Bounded env59763 := by
  intro p hp
  have h : env59763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59762_59763 : H12AffineEnvironment.transform 15 359 env59762 = env59763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 359 env59762 == env59763) = true)

def env59764 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,72,1297,5205,359,1344,487,4417,5204,4096,477,16,4471,5505,5376,4414,1297,1296,7269,68,1280,256,64,1345,5952]

theorem envBound59764 : H12AffineFastState.Bounded env59764 := by
  intro p hp
  have h : env59764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59763_59764 : H12AffineEnvironment.transform 12 72 env59763 = env59764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env59763 == env59764) = true)

theorem identity59764 : scanCanonicalize (H12AffineFastState.compose env59764 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound59764 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env59765 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,72,0,4420,359,81,487,4417,4421,4096,477,16,4471,4240,4113,4414,0,1,6516,68,17,256,64,80,4689]

theorem envBound59765 : H12AffineFastState.Bounded env59765 := by
  intro p hp
  have h : env59765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59764_59765 : H12AffineEnvironment.transform 9 273 env59764 = env59765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env59764 == env59765) = true)

theorem identity59765 : scanCanonicalize (H12AffineFastState.compose env59765 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(11+1) ^^^ 509) := by decide +kernel

theorem selectedBound59765 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env59766 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,509,72,0,185,359,81,487,188,184,509,477,16,138,365,492,195,0,1,2185,68,17,256,64,80,940]

theorem envBound59766 : H12AffineFastState.Bounded env59766 := by
  intro p hp
  have h : env59766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59765_59766 : H12AffineEnvironment.transform 11 509 env59765 = env59766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 509 env59765 == env59766) = true)

theorem identity59766 : scanCanonicalize (H12AffineFastState.compose env59766 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 373) := by decide +kernel

theorem selectedBound59766 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env59767 : List Nat := [2,4,8,16,32,64,128,256,373,273,2048,509,72,0,185,359,81,487,188,184,509,477,16,138,365,492,195,0,1,2185,68,17,256,64,80,217]

theorem envBound59767 : H12AffineFastState.Bounded env59767 := by
  intro p hp
  have h : env59767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59766_59767 : H12AffineEnvironment.transform 8 373 env59766 = env59767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 373 env59766 == env59767) = true)

theorem identity59767 : scanCanonicalize (H12AffineFastState.compose env59767 (packedSelected [0,2,3,7,8,10,13,16] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound59767 : packedSelected [0,2,3,7,8,10,13,16] rootPS < 2^1333 := by decide +kernel

def env59768 : List Nat := [2,4,8,16,32,64,128,256,373,273,1,509,72,0,185,359,81,487,188,184,509,477,16,138,365,492,195,0,1,136,68,17,256,64,80,217]

theorem envBound59768 : H12AffineFastState.Bounded env59768 := by
  intro p hp
  have h : env59768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59767_59768 : H12AffineEnvironment.transform 10 1 env59767 = env59768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env59767 == env59768) = true)

theorem identity59768 : scanCanonicalize (H12AffineFastState.compose env59768 (packedSelected [0,1,3,4,10] rootPS)) = affineNative (2^(7+1) ^^^ 205) := by decide +kernel

theorem selectedBound59768 : packedSelected [0,1,3,4,10] rootPS < 2^1333 := by decide +kernel

def env59769 : List Nat := [2,4,8,16,32,64,128,205,184,220,1,48,72,0,185,170,81,42,188,184,48,16,16,138,160,33,195,0,1,136,68,17,205,64,80,217]

theorem envBound59769 : H12AffineFastState.Bounded env59769 := by
  intro p hp
  have h : env59769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59768_59769 : H12AffineEnvironment.transform 7 205 env59768 = env59769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 205 env59768 == env59769) = true)

theorem identity59769 : scanCanonicalize (H12AffineFastState.compose env59769 (packedSelected [0,1,2,3,4,7,9,11] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound59769 : packedSelected [0,1,2,3,4,7,9,11] rootPS < 2^1333 := by decide +kernel

def env59770 : List Nat := [2,4,8,16,32,64,34,111,26,126,1,48,72,0,27,8,81,42,30,26,48,16,16,40,2,33,97,0,1,42,68,17,111,64,80,123]

theorem envBound59770 : H12AffineFastState.Bounded env59770 := by
  intro p hp
  have h : env59770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59769_59770 : H12AffineEnvironment.transform 6 34 env59769 = env59770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env59769 == env59770) = true)

theorem identity59770 : scanCanonicalize (H12AffineFastState.compose env59770 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound59770 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env59771 : List Nat := [2,4,8,16,16,64,18,95,26,78,1,0,72,0,27,8,81,26,30,26,0,16,16,24,2,17,81,0,1,26,68,17,95,64,80,75]

theorem envBound59771 : H12AffineFastState.Bounded env59771 := by
  intro p hp
  have h : env59771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59770_59771 : H12AffineEnvironment.transform 4 16 env59770 = env59771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env59770 == env59771) = true)

theorem identity59771 : scanCanonicalize (H12AffineFastState.compose env59771 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound59771 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env59772 : List Nat := [2,4,8,16,16,11,18,20,26,5,1,0,3,0,27,8,26,26,30,26,0,16,16,24,2,17,26,0,1,26,15,17,20,11,27,0]

theorem envBound59772 : H12AffineFastState.Bounded env59772 := by
  intro p hp
  have h : env59772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59771_59772 : H12AffineEnvironment.transform 5 11 env59771 = env59772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env59771 == env59772) = true)

theorem identity59772 : scanCanonicalize (H12AffineFastState.compose env59772 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound59772 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59773 : List Nat := [2,4,8,10,10,11,8,14,0,5,1,0,3,0,1,8,0,0,4,0,0,10,10,2,2,11,0,0,1,0,15,11,14,11,1,0]

theorem envBound59773 : H12AffineFastState.Bounded env59773 := by
  intro p hp
  have h : env59773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59772_59773 : H12AffineEnvironment.transform 3 10 env59772 = env59773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env59772 == env59773) = true)

theorem identity59773 : scanCanonicalize (H12AffineFastState.compose env59773 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound59773 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59774 : List Nat := [2,3,8,10,10,11,8,9,0,2,1,0,3,0,1,8,0,0,3,0,0,10,10,2,2,11,0,0,1,0,8,11,9,11,1,0]

theorem envBound59774 : H12AffineFastState.Bounded env59774 := by
  intro p hp
  have h : env59774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59773_59774 : H12AffineEnvironment.transform 1 3 env59773 = env59774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env59773 == env59774) = true)

def env59775 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,73,1297,5204,359,1345,487,4417,5205,4096,477,17,4471,5504,5377,4414,1296,1296,7268,69,1281,256,65,1345,5952]

theorem envBound59775 : H12AffineFastState.Bounded env59775 := by
  intro p hp
  have h : env59775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59763_59775 : H12AffineEnvironment.transform 12 73 env59763 = env59775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env59763 == env59775) = true)

theorem identity59775 : scanCanonicalize (H12AffineFastState.compose env59775 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound59775 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env59776 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1029,73,1297,81,359,1345,487,1348,80,1029,477,17,1394,389,260,1339,1296,1296,2145,69,1281,256,65,1345,837]

theorem envBound59776 : H12AffineFastState.Bounded env59776 := by
  intro p hp
  have h : env59776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59775_59776 : H12AffineEnvironment.transform 11 1029 env59775 = env59776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env59775 == env59776) = true)

theorem identity59776 : scanCanonicalize (H12AffineFastState.compose env59776 (packedSelected [1,2,3,11,19,20] rootPS)) = affineNative (2^(9+1) ^^^ 612) := by decide +kernel

theorem selectedBound59776 : packedSelected [1,2,3,11,19,20] rootPS < 2^1333 := by decide +kernel

def env59777 : List Nat := [2,4,8,16,32,64,128,256,512,612,2048,609,73,885,81,359,805,487,800,80,609,477,17,790,389,260,863,884,884,2145,69,869,256,65,805,837]

theorem envBound59777 : H12AffineFastState.Bounded env59777 := by
  intro p hp
  have h : env59777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59776_59777 : H12AffineEnvironment.transform 9 612 env59776 = env59777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 612 env59776 == env59777) = true)

theorem identity59777 : scanCanonicalize (H12AffineFastState.compose env59777 (packedSelected [2,4,5,8,9,13,17,19,23] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound59777 : packedSelected [2,4,5,8,9,13,17,19,23] rootPS < 2^1333 := by decide +kernel

def env59778 : List Nat := [2,4,8,16,32,64,57,256,512,612,2048,609,73,885,81,359,805,350,800,80,609,356,17,790,316,260,863,884,884,2145,69,869,256,65,805,837]

theorem envBound59778 : H12AffineFastState.Bounded env59778 := by
  intro p hp
  have h : env59778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59777_59778 : H12AffineEnvironment.transform 6 57 env59777 = env59778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env59777 == env59778) = true)

theorem identity59778 : scanCanonicalize (H12AffineFastState.compose env59778 (packedSelected [2,5,8,17] rootPS)) = affineNative (2^(10+1) ^^^ 863) := by decide +kernel

theorem selectedBound59778 : packedSelected [2,5,8,17] rootPS < 2^1333 := by decide +kernel

def env59779 : List Nat := [2,4,8,16,32,64,57,256,512,612,863,609,73,885,81,359,805,350,800,80,609,356,17,790,316,260,863,884,884,830,69,869,256,65,805,837]

theorem envBound59779 : H12AffineFastState.Bounded env59779 := by
  intro p hp
  have h : env59779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59778_59779 : H12AffineEnvironment.transform 10 863 env59778 = env59779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 863 env59778 == env59779) = true)

theorem identity59779 : scanCanonicalize (H12AffineFastState.compose env59779 (packedSelected [2,4,5,8,9,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound59779 : packedSelected [2,4,5,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env59780 : List Nat := [2,4,8,16,32,17,57,256,512,565,782,560,24,804,0,310,805,271,800,1,560,309,17,790,316,260,782,805,805,830,20,820,256,16,805,788]

theorem envBound59780 : H12AffineFastState.Bounded env59780 := by
  intro p hp
  have h : env59780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59779_59780 : H12AffineEnvironment.transform 5 17 env59779 = env59780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env59779 == env59780) = true)

theorem identity59780 : scanCanonicalize (H12AffineFastState.compose env59780 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound59780 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env59781 : List Nat := [2,4,8,16,32,17,57,62,512,565,560,560,24,538,0,8,539,49,542,1,560,11,17,552,2,58,560,539,539,512,20,522,62,16,539,554]

theorem envBound59781 : H12AffineFastState.Bounded env59781 := by
  intro p hp
  have h : env59781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59780_59781 : H12AffineEnvironment.transform 7 62 env59780 = env59781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env59780 == env59781) = true)

def env59782 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74863,65665,4417,13340,4096,477,74047,69648,13769,78895,4415,74814,1296,81226,8204,74799,256,8200,1345,5952]

theorem envBound59782 : H12AffineFastState.Bounded env59782 := by
  intro p hp
  have h : env59782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59761_59782 : H12AffineEnvironment.transform 17 65665 env59761 = env59782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env59761 == env59782) = true)

theorem identity59782 : scanCanonicalize (H12AffineFastState.compose env59782 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5158) := by decide +kernel

theorem selectedBound59782 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env59783 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,5158,12361,5287,4417,13340,4096,477,13593,1078,13769,8201,4415,12312,1296,10604,8204,12297,256,8200,1345,5952]

theorem envBound59783 : H12AffineFastState.Bounded env59783 := by
  intro p hp
  have h : env59783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59782_59783 : H12AffineEnvironment.transform 15 5158 env59782 = env59783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5158 env59782 == env59783) = true)

def env59784 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5384,1297,277,5158,1345,5287,4417,276,4096,477,17,1078,193,5377,4415,1296,1296,7268,5380,1281,256,5376,1345,5952]

theorem envBound59784 : H12AffineFastState.Bounded env59784 := by
  intro p hp
  have h : env59784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59783_59784 : H12AffineEnvironment.transform 12 5384 env59783 = env59784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5384 env59783 == env59784) = true)

theorem identity59784 : scanCanonicalize (H12AffineFastState.compose env59784 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound59784 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env59785 : List Nat := [2,4,8,16,32,64,128,68,512,1024,2048,4096,5196,1109,81,5158,1029,5287,4101,80,4096,153,17,1078,193,5189,4219,1108,1108,7268,5184,1093,68,5188,1029,5636]

theorem envBound59785 : H12AffineFastState.Bounded env59785 := by
  intro p hp
  have h : env59785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59784_59785 : H12AffineEnvironment.transform 7 68 env59784 = env59785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env59784 == env59785) = true)

theorem identity59785 : scanCanonicalize (H12AffineFastState.compose env59785 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound59785 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env59786 : List Nat := [2,4,8,16,32,64,128,68,512,1024,2048,1028,72,1109,81,34,1029,163,1025,80,1028,153,17,1078,193,65,1151,1108,1108,2144,68,1093,68,64,1029,512]

theorem envBound59786 : H12AffineFastState.Bounded env59786 := by
  intro p hp
  have h : env59786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59785_59786 : H12AffineEnvironment.transform 11 1028 env59785 = env59786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env59785 == env59786) = true)

theorem identity59786 : scanCanonicalize (H12AffineFastState.compose env59786 (packedSelected [0,2,5,7,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 123) := by decide +kernel

theorem selectedBound59786 : packedSelected [0,2,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env59787 : List Nat := [2,4,8,16,32,64,128,68,512,1024,123,1028,72,1109,81,34,1029,163,1025,80,1028,153,17,1078,193,65,1151,1108,1108,27,68,1093,68,64,1029,512]

theorem envBound59787 : H12AffineFastState.Bounded env59787 := by
  intro p hp
  have h : env59787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59786_59787 : H12AffineEnvironment.transform 10 123 env59786 = env59787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 123 env59786 == env59787) = true)

theorem identity59787 : scanCanonicalize (H12AffineFastState.compose env59787 (packedSelected [1,3,13] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound59787 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env59788 : List Nat := [2,4,8,16,32,64,128,68,48,1024,123,1028,72,1109,81,34,1029,163,1025,80,1028,153,17,1078,193,65,1151,1108,1108,27,68,1093,68,64,1029,48]

theorem envBound59788 : H12AffineFastState.Bounded env59788 := by
  intro p hp
  have h : env59788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59787_59788 : H12AffineEnvironment.transform 8 48 env59787 = env59788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env59787 == env59788) = true)

theorem identity59788 : scanCanonicalize (H12AffineFastState.compose env59788 (packedSelected [0,2,3,4,7,8,9,10,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound59788 : packedSelected [0,2,3,4,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env59789 : List Nat := [2,4,8,16,32,64,128,68,48,84,123,80,72,1,81,34,81,163,85,80,80,153,17,98,193,65,43,0,0,27,68,17,68,64,81,48]

theorem envBound59789 : H12AffineFastState.Bounded env59789 := by
  intro p hp
  have h : env59789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59788_59789 : H12AffineEnvironment.transform 9 84 env59788 = env59789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env59788 == env59789) = true)

theorem identity59789 : scanCanonicalize (H12AffineFastState.compose env59789 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound59789 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env59790 : List Nat := [2,4,8,16,32,64,89,68,48,84,123,80,72,1,81,34,81,122,85,80,80,64,17,98,24,65,43,0,0,27,68,17,68,64,81,48]

theorem envBound59790 : H12AffineFastState.Bounded env59790 := by
  intro p hp
  have h : env59790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59789_59790 : H12AffineEnvironment.transform 6 89 env59789 = env59790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env59789 == env59790) = true)

theorem identity59790 : scanCanonicalize (H12AffineFastState.compose env59790 (packedSelected [4,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound59790 : packedSelected [4,5] rootPS < 2^1333 := by decide +kernel

def env59791 : List Nat := [2,4,8,11,32,64,66,68,43,79,96,75,72,1,74,34,74,97,78,75,75,64,10,98,3,65,43,0,0,0,68,10,68,64,74,43]

theorem envBound59791 : H12AffineFastState.Bounded env59791 := by
  intro p hp
  have h : env59791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59790_59791 : H12AffineEnvironment.transform 3 11 env59790 = env59791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env59790 == env59791) = true)

theorem identity59791 : scanCanonicalize (H12AffineFastState.compose env59791 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound59791 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env59792 : List Nat := [2,4,8,11,32,33,35,37,43,46,1,42,41,1,43,34,43,0,47,42,42,33,10,3,3,32,43,0,0,0,37,10,37,33,43,43]

theorem envBound59792 : H12AffineFastState.Bounded env59792 := by
  intro p hp
  have h : env59792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59791_59792 : H12AffineEnvironment.transform 5 33 env59791 = env59792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env59791 == env59792) = true)

def env59793 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5385,1297,276,5158,1344,5287,4417,277,4096,477,16,1078,192,5376,4415,1297,1296,7269,5381,1280,256,5377,1345,5952]

theorem envBound59793 : H12AffineFastState.Bounded env59793 := by
  intro p hp
  have h : env59793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59783_59793 : H12AffineEnvironment.transform 12 5385 env59783 = env59793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5385 env59783 == env59793) = true)

theorem identity59793 : scanCanonicalize (H12AffineFastState.compose env59793 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound59793 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env59794 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,1369,1297,276,1142,1344,1271,273,277,80,477,16,1078,192,1360,367,1297,1296,3125,1365,1280,256,1361,1345,1808]

theorem envBound59794 : H12AffineFastState.Bounded env59794 := by
  intro p hp
  have h : env59794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59793_59794 : H12AffineEnvironment.transform 11 80 env59793 = env59794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env59793 == env59794) = true)

theorem identity59794 : scanCanonicalize (H12AffineFastState.compose env59794 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound59794 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env59795 : List Nat := [2,4,8,16,32,64,128,256,512,188,2048,80,485,429,276,202,508,75,273,277,80,477,16,138,192,492,367,429,428,2185,489,444,256,493,509,940]

theorem envBound59795 : H12AffineFastState.Bounded env59795 := by
  intro p hp
  have h : env59795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59794_59795 : H12AffineEnvironment.transform 9 188 env59794 = env59795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env59794 == env59795) = true)

theorem identity59795 : scanCanonicalize (H12AffineFastState.compose env59795 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 373) := by decide +kernel

theorem selectedBound59795 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env59796 : List Nat := [2,4,8,16,32,64,128,256,373,188,2048,80,485,429,276,202,508,75,273,277,80,477,16,138,192,492,367,429,428,2185,489,444,256,493,509,217]

theorem envBound59796 : H12AffineFastState.Bounded env59796 := by
  intro p hp
  have h : env59796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59795_59796 : H12AffineEnvironment.transform 8 373 env59795 = env59796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 373 env59795 == env59796) = true)

theorem identity59796 : scanCanonicalize (H12AffineFastState.compose env59796 (packedSelected [0,2,3,7,8,10,13,16] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound59796 : packedSelected [0,2,3,7,8,10,13,16] rootPS < 2^1333 := by decide +kernel

def env59797 : List Nat := [2,4,8,16,32,64,128,256,373,188,0,80,485,429,276,202,508,75,273,277,80,477,16,138,192,492,367,429,428,137,489,444,256,493,509,217]

theorem envBound59797 : H12AffineFastState.Bounded env59797 := by
  intro p hp
  have h : env59797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59796_59797 : H12AffineEnvironment.transform 10 0 env59796 = env59797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env59796 == env59797) = true)

theorem identity59797 : scanCanonicalize (H12AffineFastState.compose env59797 (packedSelected [1,2,3,7,9,10,12] rootPS)) = affineNative (2^(6+1) ^^^ 114) := by decide +kernel

theorem selectedBound59797 : packedSelected [1,2,3,7,9,10,12] rootPS < 2^1333 := by decide +kernel

def env59798 : List Nat := [2,4,8,16,32,64,114,256,373,78,0,80,279,351,276,56,270,75,273,277,80,303,16,120,50,286,367,351,350,123,283,334,256,287,271,43]

theorem envBound59798 : H12AffineFastState.Bounded env59798 := by
  intro p hp
  have h : env59798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59797_59798 : H12AffineEnvironment.transform 6 114 env59797 = env59798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 114 env59797 == env59798) = true)

theorem identity59798 : scanCanonicalize (H12AffineFastState.compose env59798 (packedSelected [7,9] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound59798 : packedSelected [7,9] rootPS < 2^1333 := by decide +kernel

def env59799 : List Nat := [2,4,8,11,32,64,105,256,366,78,0,75,268,324,271,35,270,75,266,270,75,303,11,99,41,261,367,324,325,96,256,334,256,260,271,43]

theorem envBound59799 : H12AffineFastState.Bounded env59799 := by
  intro p hp
  have h : env59799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59798_59799 : H12AffineEnvironment.transform 3 11 env59798 = env59799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env59798 == env59799) = true)

theorem identity59799 : scanCanonicalize (H12AffineFastState.compose env59799 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound59799 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env59800 : List Nat := [2,4,8,11,32,64,105,37,75,78,0,75,41,97,42,35,43,75,47,43,75,10,11,99,41,32,74,97,96,96,37,107,37,33,42,43]

theorem envBound59800 : H12AffineFastState.Bounded env59800 := by
  intro p hp
  have h : env59800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59799_59800 : H12AffineEnvironment.transform 7 37 env59799 = env59800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env59799 == env59800) = true)

theorem identity59800 : scanCanonicalize (H12AffineFastState.compose env59800 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound59800 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59801 : List Nat := [2,4,8,11,32,33,8,37,42,47,0,42,41,0,42,35,43,42,47,43,42,10,11,2,41,32,43,0,1,1,37,10,37,33,42,43]

theorem envBound59801 : H12AffineFastState.Bounded env59801 := by
  intro p hp
  have h : env59801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59800_59801 : H12AffineEnvironment.transform 5 33 env59800 = env59801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env59800 == env59801) = true)

theorem identity59801 : scanCanonicalize (H12AffineFastState.compose env59801 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound59801 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env59802 : List Nat := [2,4,0,3,32,33,0,37,34,39,0,34,33,0,34,35,35,34,39,35,34,2,3,2,33,32,35,0,1,1,37,2,37,33,34,35]

theorem envBound59802 : H12AffineFastState.Bounded env59802 := by
  intro p hp
  have h : env59802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59801_59802 : H12AffineEnvironment.transform 2 0 env59801 = env59802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env59801 == env59802) = true)

theorem identity59802 : scanCanonicalize (H12AffineFastState.compose env59802 (packedSelected [0,4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound59802 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env59803 : List Nat := [1,4,0,0,32,33,0,37,33,36,0,33,33,0,33,32,32,33,36,32,33,1,0,1,33,32,32,0,1,1,37,1,37,33,33,32]

theorem envBound59803 : H12AffineFastState.Bounded env59803 := by
  intro p hp
  have h : env59803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59802_59803 : H12AffineEnvironment.transform 0 1 env59802 = env59803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env59802 == env59803) = true)

theorem identity59803 : scanCanonicalize (H12AffineFastState.compose env59803 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound59803 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59804 : List Nat := [1,0,0,0,32,33,0,33,33,32,0,33,33,0,33,32,32,33,32,32,33,1,0,1,33,32,32,0,1,1,33,1,33,33,33,32]

theorem envBound59804 : H12AffineFastState.Bounded env59804 := by
  intro p hp
  have h : env59804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59803_59804 : H12AffineEnvironment.transform 1 0 env59803 = env59804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env59803 == env59804) = true)

def env59805 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21585,32769,4096,61649,91182,123164,28889,78894,385202,90415,1297,96347,25885,74799,256,25880,1345,21072]

theorem envBound59805 : H12AffineFastState.Bounded env59805 := by
  intro p hp
  have h : env59805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59711_59805 : H12AffineEnvironment.transform 18 21585 env59711 = env59805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env59711 == env59805) = true)

theorem identity59805 : scanCanonicalize (H12AffineFastState.compose env59805 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25676) := by decide +kernel

theorem selectedBound59805 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env59806 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25676,65536,74863,262144,21585,25677,4096,5277,91182,66896,28889,78894,328958,90415,1297,96347,25885,74799,256,25880,1345,21072]

theorem envBound59806 : H12AffineFastState.Bounded env59806 := by
  intro p hp
  have h : env59806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59805_59806 : H12AffineEnvironment.transform 14 25676 env59805 = env59806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25676 env59805 == env59806) = true)

def env59807 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74863,262144,4417,8541,4096,5277,74046,66896,13769,78894,328958,74815,1297,81227,8205,74799,256,8200,1345,5952]

theorem envBound59807 : H12AffineFastState.Bounded env59807 := by
  intro p hp
  have h : env59807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59806_59807 : H12AffineEnvironment.transform 13 1296 env59806 = env59807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env59806 == env59807) = true)

def env59808 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74863,65664,4417,8541,4096,5277,74046,66896,13769,78894,1150,74815,1297,81227,8205,74799,256,8200,1345,5952]

theorem envBound59808 : H12AffineFastState.Bounded env59808 := by
  intro p hp
  have h : env59808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59807_59808 : H12AffineEnvironment.transform 17 65664 env59807 = env59808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env59807 == env59808) = true)

theorem identity59808 : scanCanonicalize (H12AffineFastState.compose env59808 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9327) := by decide +kernel

theorem selectedBound59808 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env59809 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,9327,0,9455,4417,8541,4096,5277,1361,8511,13769,4161,1150,80,1297,6436,8205,64,256,8200,1345,5952]

theorem envBound59809 : H12AffineFastState.Bounded env59809 := by
  intro p hp
  have h : env59809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59808_59809 : H12AffineEnvironment.transform 15 9327 env59808 = env59809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9327 env59808 == env59809) = true)

def env59810 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,80,8540,8495,0,8623,4417,8541,4096,4573,17,8511,12425,4161,318,80,81,6436,8205,64,256,8200,1,4608]

theorem envBound59810 : H12AffineFastState.Bounded env59810 := by
  intro p hp
  have h : env59810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59809_59810 : H12AffineEnvironment.transform 9 320 env59809 = env59810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env59809 == env59810) = true)

theorem identity59810 : scanCanonicalize (H12AffineFastState.compose env59810 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound59810 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env59811 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,269,80,81,34,0,162,4417,80,4096,4573,17,50,4484,4161,318,80,81,6436,256,64,256,261,1,4608]

theorem envBound59811 : H12AffineFastState.Bounded env59811 := by
  intro p hp
  have h : env59811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59810_59811 : H12AffineEnvironment.transform 12 269 env59810 = env59811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env59810 == env59811) = true)

theorem identity59811 : scanCanonicalize (H12AffineFastState.compose env59811 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound59811 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env59812 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,0,269,80,81,34,0,162,321,80,0,477,17,50,388,65,318,80,81,2340,256,64,256,261,1,512]

theorem envBound59812 : H12AffineFastState.Bounded env59812 := by
  intro p hp
  have h : env59812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59811_59812 : H12AffineEnvironment.transform 11 0 env59811 = env59812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env59811 == env59812) = true)

theorem identity59812 : scanCanonicalize (H12AffineFastState.compose env59812 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound59812 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59813 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,269,0,1,34,0,162,273,0,0,397,17,50,388,17,318,0,1,2340,256,16,256,261,1,512]

theorem envBound59813 : H12AffineFastState.Bounded env59813 := by
  intro p hp
  have h : env59813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59812_59813 : H12AffineEnvironment.transform 5 16 env59812 = env59813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env59812 == env59813) = true)

theorem identity59813 : scanCanonicalize (H12AffineFastState.compose env59813 (packedSelected [1,2,5] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound59813 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env59814 : List Nat := [2,4,8,16,32,16,128,256,512,272,561,0,269,0,1,34,0,162,273,0,0,397,17,50,388,17,318,0,1,789,256,16,256,261,1,512]

theorem envBound59814 : H12AffineFastState.Bounded env59814 := by
  intro p hp
  have h : env59814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59813_59814 : H12AffineEnvironment.transform 10 561 env59813 = env59814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env59813 == env59814) = true)

theorem identity59814 : scanCanonicalize (H12AffineFastState.compose env59814 (packedSelected [3,8] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound59814 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env59815 : List Nat := [2,4,8,16,10,16,128,256,512,272,539,0,269,0,1,8,0,136,273,0,0,397,17,24,388,17,276,0,1,789,256,16,256,261,1,512]

theorem envBound59815 : H12AffineFastState.Bounded env59815 := by
  intro p hp
  have h : env59815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59814_59815 : H12AffineEnvironment.transform 4 10 env59814 = env59815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env59814 == env59815) = true)

theorem identity59815 : scanCanonicalize (H12AffineFastState.compose env59815 (packedSelected [1,2,3,10] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound59815 : packedSelected [1,2,3,10] rootPS < 2^1333 := by decide +kernel

def env59816 : List Nat := [2,4,8,16,10,16,128,256,137,272,146,0,269,0,1,8,0,136,273,0,0,397,17,24,388,17,276,0,1,412,256,16,256,261,1,137]

theorem envBound59816 : H12AffineFastState.Bounded env59816 := by
  intro p hp
  have h : env59816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59815_59816 : H12AffineEnvironment.transform 8 137 env59815 = env59816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env59815 == env59816) = true)

theorem identity59816 : scanCanonicalize (H12AffineFastState.compose env59816 (packedSelected [3,7] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound59816 : packedSelected [3,7] rootPS < 2^1333 := by decide +kernel

def env59817 : List Nat := [2,4,8,16,10,16,128,15,137,31,146,0,2,0,1,8,0,136,30,0,0,130,17,24,139,17,27,0,1,147,15,16,15,10,1,137]

theorem envBound59817 : H12AffineFastState.Bounded env59817 := by
  intro p hp
  have h : env59817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59816_59817 : H12AffineEnvironment.transform 7 15 env59816 = env59817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env59816 == env59817) = true)

theorem identity59817 : scanCanonicalize (H12AffineFastState.compose env59817 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound59817 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env59818 : List Nat := [2,4,8,16,10,16,8,15,1,31,26,0,2,0,1,8,0,0,30,0,0,10,17,24,3,17,27,0,1,27,15,16,15,10,1,1]

theorem envBound59818 : H12AffineFastState.Bounded env59818 := by
  intro p hp
  have h : env59818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59817_59818 : H12AffineEnvironment.transform 6 8 env59817 = env59818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env59817 == env59818) = true)

theorem identity59818 : scanCanonicalize (H12AffineFastState.compose env59818 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound59818 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env59819 : List Nat := [2,4,8,11,10,11,8,15,1,4,1,0,2,0,1,8,0,0,5,0,0,10,10,3,3,10,0,0,1,0,15,11,15,10,1,1]

theorem envBound59819 : H12AffineFastState.Bounded env59819 := by
  intro p hp
  have h : env59819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59818_59819 : H12AffineEnvironment.transform 3 11 env59818 = env59819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env59818 == env59819) = true)

theorem identity59819 : scanCanonicalize (H12AffineFastState.compose env59819 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound59819 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59820 : List Nat := [2,2,8,11,10,11,8,9,1,2,1,0,2,0,1,8,0,0,3,0,0,10,10,3,3,10,0,0,1,0,9,11,9,10,1,1]

theorem envBound59820 : H12AffineFastState.Bounded env59820 := by
  intro p hp
  have h : env59820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59819_59820 : H12AffineEnvironment.transform 1 2 env59819 = env59820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env59819 == env59820) = true)

def env59821 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,81,8540,8494,0,8622,4417,8541,4096,4572,16,8511,12424,4161,319,80,80,6436,8205,64,256,8200,0,4609]

theorem envBound59821 : H12AffineFastState.Bounded env59821 := by
  intro p hp
  have h : env59821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59809_59821 : H12AffineEnvironment.transform 9 321 env59809 = env59821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env59809 == env59821) = true)

theorem identity59821 : scanCanonicalize (H12AffineFastState.compose env59821 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound59821 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env59822 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,24,81,324,310,0,438,4417,325,4096,4572,16,295,4240,4161,319,80,80,6436,21,64,256,16,0,4609]

theorem envBound59822 : H12AffineFastState.Bounded env59822 := by
  intro p hp
  have h : env59822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59821_59822 : H12AffineEnvironment.transform 12 24 env59821 = env59822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env59821 == env59822) = true)

theorem identity59822 : scanCanonicalize (H12AffineFastState.compose env59822 (packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 951) := by decide +kernel

theorem selectedBound59822 : packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env59823 : List Nat := [2,4,8,16,32,64,128,256,512,321,951,4096,24,81,324,310,0,438,4417,325,4096,4572,16,295,4240,4161,319,80,80,4755,21,64,256,16,0,4609]

theorem envBound59823 : H12AffineFastState.Bounded env59823 := by
  intro p hp
  have h : env59823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59822_59823 : H12AffineEnvironment.transform 10 951 env59822 = env59823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 951 env59822 == env59823) = true)

theorem identity59823 : scanCanonicalize (H12AffineFastState.compose env59823 (packedSelected [0,1,2,4,5,7,9,10,11,13,23] rootPS)) = affineNative (2^(11+1) ^^^ 649) := by decide +kernel

theorem selectedBound59823 : packedSelected [0,1,2,4,5,7,9,10,11,13,23] rootPS < 2^1333 := by decide +kernel

def env59824 : List Nat := [2,4,8,16,32,64,128,256,512,321,951,649,24,81,324,310,0,438,968,325,649,853,16,295,537,712,319,80,80,26,21,64,256,16,0,136]

theorem envBound59824 : H12AffineFastState.Bounded env59824 := by
  intro p hp
  have h : env59824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59823_59824 : H12AffineEnvironment.transform 11 649 env59823 = env59824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 649 env59823 == env59824) = true)

theorem identity59824 : scanCanonicalize (H12AffineFastState.compose env59824 (packedSelected [4,9,13,16,17] rootPS)) = affineNative (2^(8+1) ^^^ 460) := by decide +kernel

theorem selectedBound59824 : packedSelected [4,9,13,16,17] rootPS < 2^1333 := by decide +kernel

def env59825 : List Nat := [2,4,8,16,32,64,128,256,460,321,123,325,24,81,324,310,0,438,4,325,325,153,16,295,469,260,319,80,80,26,21,64,256,16,0,136]

theorem envBound59825 : H12AffineFastState.Bounded env59825 := by
  intro p hp
  have h : env59825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59824_59825 : H12AffineEnvironment.transform 8 460 env59824 = env59825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 460 env59824 == env59825) = true)

theorem identity59825 : scanCanonicalize (H12AffineFastState.compose env59825 (packedSelected [1,2,5,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound59825 : packedSelected [1,2,5,10,12] rootPS < 2^1333 := by decide +kernel

def env59826 : List Nat := [2,4,8,16,32,64,128,68,136,5,123,1,24,81,0,114,0,242,4,1,1,153,16,99,145,64,123,80,80,26,21,64,68,16,0,136]

theorem envBound59826 : H12AffineFastState.Bounded env59826 := by
  intro p hp
  have h : env59826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59825_59826 : H12AffineEnvironment.transform 7 68 env59825 = env59826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env59825 == env59826) = true)

theorem identity59826 : scanCanonicalize (H12AffineFastState.compose env59826 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 67) := by decide +kernel

theorem selectedBound59826 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env59827 : List Nat := [2,4,8,16,32,64,67,68,75,5,123,1,24,81,0,114,0,49,4,1,1,90,16,99,82,64,123,80,80,26,21,64,68,16,0,75]

theorem envBound59827 : H12AffineFastState.Bounded env59827 := by
  intro p hp
  have h : env59827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59826_59827 : H12AffineEnvironment.transform 6 67 env59826 = env59827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 67 env59826 == env59827) = true)

theorem identity59827 : scanCanonicalize (H12AffineFastState.compose env59827 (packedSelected [1,2,4] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound59827 : packedSelected [1,2,4] rootPS < 2^1333 := by decide +kernel

def env59828 : List Nat := [2,4,8,16,32,59,56,63,48,5,0,1,24,42,0,9,0,49,4,1,1,33,16,24,41,59,0,43,43,26,21,59,63,16,0,48]

theorem envBound59828 : H12AffineFastState.Bounded env59828 := by
  intro p hp
  have h : env59828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59827_59828 : H12AffineEnvironment.transform 5 59 env59827 = env59828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env59827 == env59828) = true)

theorem identity59828 : scanCanonicalize (H12AffineFastState.compose env59828 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound59828 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env59829 : List Nat := [2,4,8,10,32,33,34,37,42,5,0,1,2,42,0,9,0,43,4,1,1,33,10,2,41,33,0,43,43,0,15,33,37,10,0,42]

theorem envBound59829 : H12AffineFastState.Bounded env59829 := by
  intro p hp
  have h : env59829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59828_59829 : H12AffineEnvironment.transform 3 10 env59828 = env59829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env59828 == env59829) = true)

theorem identity59829 : scanCanonicalize (H12AffineFastState.compose env59829 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound59829 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59830 : List Nat := [2,4,8,10,10,11,8,15,0,5,0,1,2,0,0,9,0,1,4,1,1,11,10,2,3,11,0,1,1,0,15,11,15,10,0,0]

theorem envBound59830 : H12AffineFastState.Bounded env59830 := by
  intro p hp
  have h : env59830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59829_59830 : H12AffineEnvironment.transform 4 10 env59829 = env59830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env59829 == env59830) = true)

theorem identity59830 : scanCanonicalize (H12AffineFastState.compose env59830 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound59830 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59831 : List Nat := [2,2,8,10,10,11,8,9,0,3,0,1,2,0,0,9,0,1,2,1,1,11,10,2,3,11,0,1,1,0,9,11,9,10,0,0]

theorem envBound59831 : H12AffineFastState.Bounded env59831 := by
  intro p hp
  have h : env59831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59830_59831 : H12AffineEnvironment.transform 1 2 env59830 = env59831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env59830 == env59831) = true)

def env59832 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74863,65665,4417,8541,4096,5277,74046,66896,13769,78894,1151,74815,1297,81227,8205,74799,256,8200,1345,5952]

theorem envBound59832 : H12AffineFastState.Bounded env59832 := by
  intro p hp
  have h : env59832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59807_59832 : H12AffineEnvironment.transform 17 65665 env59807 = env59832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env59807 == env59832) = true)

theorem identity59832 : scanCanonicalize (H12AffineFastState.compose env59832 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12590) := by decide +kernel

theorem selectedBound59832 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env59833 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,12590,5441,12719,4417,8541,4096,5277,4112,13438,13769,1280,1151,5393,1297,3173,8205,5377,256,8200,1345,5952]

theorem envBound59833 : H12AffineFastState.Bounded env59833 := by
  intro p hp
  have h : env59833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59832_59833 : H12AffineEnvironment.transform 15 12590 env59832 = env59833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12590 env59832 == env59833) = true)

def env59834 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1296,8540,8494,1345,8623,321,8541,0,1181,16,9342,9673,1280,1151,1297,1297,3173,8205,1281,256,8200,1345,1856]

theorem envBound59834 : H12AffineFastState.Bounded env59834 := by
  intro p hp
  have h : env59834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59833_59834 : H12AffineEnvironment.transform 11 0 env59833 = env59834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env59833 == env59834) = true)

theorem identity59834 : scanCanonicalize (H12AffineFastState.compose env59834 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 1369) := by decide +kernel

theorem selectedBound59834 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env59835 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,1369,1296,1029,1143,1345,1270,321,1028,0,1181,16,295,144,1280,1151,1297,1297,3173,1364,1281,256,1361,1345,1856]

theorem envBound59835 : H12AffineFastState.Bounded env59835 := by
  intro p hp
  have h : env59835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59834_59835 : H12AffineEnvironment.transform 12 1369 env59834 = env59835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1369 env59834 == env59835) = true)

theorem identity59835 : scanCanonicalize (H12AffineFastState.compose env59835 (packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 1783) := by decide +kernel

theorem selectedBound59835 : packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env59836 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1783,0,1369,1296,1029,1143,1345,1270,321,1028,0,1181,16,295,144,1280,1151,1297,1297,658,1364,1281,256,1361,1345,1856]

theorem envBound59836 : H12AffineFastState.Bounded env59836 := by
  intro p hp
  have h : env59836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59835_59836 : H12AffineEnvironment.transform 10 1783 env59835 = env59836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1783 env59835 == env59836) = true)

theorem identity59836 : scanCanonicalize (H12AffineFastState.compose env59836 (packedSelected [0,1,2,4,5,7,9,10,11,13,23] rootPS)) = affineNative (2^(9+1) ^^^ 969) := by decide +kernel

theorem selectedBound59836 : packedSelected [0,1,2,4,5,7,9,10,11,13,23] rootPS < 2^1333 := by decide +kernel

def env59837 : List Nat := [2,4,8,16,32,64,128,256,512,969,318,0,656,729,972,958,648,831,321,973,0,852,16,295,144,713,950,728,728,658,669,712,256,664,648,137]

theorem envBound59837 : H12AffineFastState.Bounded env59837 := by
  intro p hp
  have h : env59837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59836_59837 : H12AffineEnvironment.transform 9 969 env59836 = env59837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 969 env59836 == env59837) = true)

theorem identity59837 : scanCanonicalize (H12AffineFastState.compose env59837 (packedSelected [3,8,11,13,15,16] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound59837 : packedSelected [3,8,11,13,15,16] rootPS < 2^1333 := by decide +kernel

def env59838 : List Nat := [2,4,8,16,32,64,128,256,49,504,318,0,161,232,509,399,185,270,321,508,0,357,16,295,144,248,391,233,233,163,172,249,256,169,185,137]

theorem envBound59838 : H12AffineFastState.Bounded env59838 := by
  intro p hp
  have h : env59838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59837_59838 : H12AffineEnvironment.transform 8 49 env59837 = env59838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env59837 == env59838) = true)

theorem identity59838 : scanCanonicalize (H12AffineFastState.compose env59838 (packedSelected [0,1,2,7,8,11] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound59838 : packedSelected [0,1,2,7,8,11] rootPS < 2^1333 := by decide +kernel

def env59839 : List Nat := [2,4,8,16,32,64,128,252,49,4,194,0,161,232,1,115,185,242,189,0,0,153,16,219,144,248,123,233,233,163,172,249,252,169,185,137]

theorem envBound59839 : H12AffineFastState.Bounded env59839 := by
  intro p hp
  have h : env59839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59838_59839 : H12AffineEnvironment.transform 7 252 env59838 = env59839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env59838 == env59839) = true)

theorem identity59839 : scanCanonicalize (H12AffineFastState.compose env59839 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound59839 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env59840 : List Nat := [2,4,8,16,32,64,18,110,49,4,80,0,51,122,1,115,43,96,47,0,0,11,16,73,2,106,123,123,123,49,62,107,110,59,43,27]

theorem envBound59840 : H12AffineFastState.Bounded env59840 := by
  intro p hp
  have h : env59840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59839_59840 : H12AffineEnvironment.transform 6 18 env59839 = env59840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env59839 == env59840) = true)

theorem identity59840 : scanCanonicalize (H12AffineFastState.compose env59840 (packedSelected [2,5,8] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound59840 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env59841 : List Nat := [2,4,8,16,17,64,18,95,0,4,80,0,2,75,1,66,26,81,30,0,0,11,16,73,2,91,74,74,74,0,15,90,95,10,26,27]

theorem envBound59841 : H12AffineFastState.Bounded env59841 := by
  intro p hp
  have h : env59841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59840_59841 : H12AffineEnvironment.transform 4 17 env59840 = env59841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env59840 == env59841) = true)

theorem identity59841 : scanCanonicalize (H12AffineFastState.compose env59841 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound59841 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env59842 : List Nat := [2,4,8,16,17,10,18,21,0,4,26,0,2,1,1,8,26,27,30,0,0,11,16,3,2,17,0,0,0,0,15,16,21,10,26,27]

theorem envBound59842 : H12AffineFastState.Bounded env59842 := by
  intro p hp
  have h : env59842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59841_59842 : H12AffineEnvironment.transform 5 10 env59841 = env59842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env59841 == env59842) = true)

theorem identity59842 : scanCanonicalize (H12AffineFastState.compose env59842 (packedSelected [0,1,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound59842 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env59843 : List Nat := [2,3,8,16,17,10,18,18,0,3,26,0,2,1,1,8,26,27,25,0,0,11,16,3,2,17,0,0,0,0,8,16,18,10,26,27]

theorem envBound59843 : H12AffineFastState.Bounded env59843 := by
  intro p hp
  have h : env59843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59842_59843 : H12AffineEnvironment.transform 1 3 env59842 = env59843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env59842 == env59843) = true)

theorem identity59843 : scanCanonicalize (H12AffineFastState.compose env59843 (packedSelected [0,1,9] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound59843 : packedSelected [0,1,9] rootPS < 2^1333 := by decide +kernel

def env59844 : List Nat := [2,3,8,10,11,10,8,8,0,3,0,0,2,1,1,8,0,1,3,0,0,11,10,3,2,11,0,0,0,0,8,10,8,10,0,1]

theorem envBound59844 : H12AffineFastState.Bounded env59844 := by
  intro p hp
  have h : env59844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59843_59844 : H12AffineEnvironment.transform 3 10 env59843 = env59844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env59843 == env59844) = true)

theorem identity59844 : scanCanonicalize (H12AffineFastState.compose env59844 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound59844 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59845 : List Nat := [0,1,8,8,9,8,8,8,0,1,0,0,0,1,1,8,0,1,1,0,0,9,8,1,0,9,0,0,0,0,8,8,8,8,0,1]

theorem envBound59845 : H12AffineFastState.Bounded env59845 := by
  intro p hp
  have h : env59845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59844_59845 : H12AffineEnvironment.transform 0 0 env59844 = env59845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env59844 == env59845) = true)

theorem identity59845 : scanCanonicalize (H12AffineFastState.compose env59845 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound59845 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env59846 : List Nat := [0,1,1,1,0,1,1,1,0,1,0,0,0,1,1,1,0,1,1,0,0,0,1,1,0,0,0,0,0,0,1,1,1,1,0,1]

theorem envBound59846 : H12AffineFastState.Bounded env59846 := by
  intro p hp
  have h : env59846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59845_59846 : H12AffineEnvironment.transform 2 1 env59845 = env59846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env59845 == env59846) = true)

def env59847 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1296,8540,8495,1344,8622,320,8541,1,1180,17,9343,9672,1280,1151,1296,1297,3173,8205,1280,256,8200,1345,1857]

theorem envBound59847 : H12AffineFastState.Bounded env59847 := by
  intro p hp
  have h : env59847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59833_59847 : H12AffineEnvironment.transform 11 1 env59833 = env59847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env59833 == env59847) = true)

theorem identity59847 : scanCanonicalize (H12AffineFastState.compose env59847 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound59847 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env59848 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,269,1296,81,34,1344,163,320,80,1,1180,17,1394,1221,1280,1151,1296,1297,3173,256,1280,256,261,1345,1857]

theorem envBound59848 : H12AffineFastState.Bounded env59848 := by
  intro p hp
  have h : env59848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59847_59848 : H12AffineEnvironment.transform 12 269 env59847 = env59848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env59847 == env59848) = true)

theorem identity59848 : scanCanonicalize (H12AffineFastState.compose env59848 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound59848 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env59849 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,269,81,81,34,1,163,320,80,1,477,17,51,388,65,318,81,80,2340,256,65,256,261,0,512]

theorem envBound59849 : H12AffineFastState.Bounded env59849 := by
  intro p hp
  have h : env59849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59848_59849 : H12AffineEnvironment.transform 9 321 env59848 = env59849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env59848 == env59849) = true)

theorem identity59849 : scanCanonicalize (H12AffineFastState.compose env59849 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound59849 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59850 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,269,1,1,34,1,163,272,0,1,397,17,51,388,17,318,1,0,2340,256,17,256,261,0,512]

theorem envBound59850 : H12AffineFastState.Bounded env59850 := by
  intro p hp
  have h : env59850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59849_59850 : H12AffineEnvironment.transform 5 16 env59849 = env59850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env59849 == env59850) = true)

theorem identity59850 : scanCanonicalize (H12AffineFastState.compose env59850 (packedSelected [1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 271) := by decide +kernel

theorem selectedBound59850 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env59851 : List Nat := [2,4,8,16,32,16,128,256,271,273,2048,1,269,1,1,34,1,163,272,0,1,397,17,51,388,17,318,1,0,2340,256,17,256,261,0,271]

theorem envBound59851 : H12AffineFastState.Bounded env59851 := by
  intro p hp
  have h : env59851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59850_59851 : H12AffineEnvironment.transform 8 271 env59850 = env59851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 271 env59850 == env59851) = true)

theorem identity59851 : scanCanonicalize (H12AffineFastState.compose env59851 (packedSelected [3,8] rootPS)) = affineNative (2^(10+1) ^^^ 429) := by decide +kernel

theorem selectedBound59851 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env59852 : List Nat := [2,4,8,16,32,16,128,256,271,273,429,1,269,1,1,34,1,163,272,0,1,397,17,51,388,17,318,1,0,137,256,17,256,261,0,271]

theorem envBound59852 : H12AffineFastState.Bounded env59852 := by
  intro p hp
  have h : env59852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59851_59852 : H12AffineEnvironment.transform 10 429 env59851 = env59852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 429 env59851 == env59852) = true)

theorem identity59852 : scanCanonicalize (H12AffineFastState.compose env59852 (packedSelected [0,2,3,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 134) := by decide +kernel

theorem selectedBound59852 : packedSelected [0,2,3,7,9] rootPS < 2^1333 := by decide +kernel

def env59853 : List Nat := [2,4,8,16,32,16,128,134,137,151,43,1,139,1,1,34,1,163,150,0,1,11,17,51,2,17,184,1,0,137,134,17,134,131,0,137]

theorem envBound59853 : H12AffineFastState.Bounded env59853 := by
  intro p hp
  have h : env59853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59852_59853 : H12AffineEnvironment.transform 7 134 env59852 = env59853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 134 env59852 == env59853) = true)

theorem identity59853 : scanCanonicalize (H12AffineFastState.compose env59853 (packedSelected [3,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound59853 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env59854 : List Nat := [2,4,8,10,32,10,128,134,137,141,43,1,139,1,1,34,1,163,140,0,1,11,11,41,2,11,162,1,0,137,134,11,134,131,0,137]

theorem envBound59854 : H12AffineFastState.Bounded env59854 := by
  intro p hp
  have h : env59854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59853_59854 : H12AffineEnvironment.transform 3 10 env59853 = env59854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env59853 == env59854) = true)

theorem identity59854 : scanCanonicalize (H12AffineFastState.compose env59854 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound59854 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env59855 : List Nat := [2,4,8,10,32,10,8,14,1,5,43,1,3,1,1,34,1,43,4,0,1,11,11,41,2,11,42,1,0,1,14,11,14,11,0,1]

theorem envBound59855 : H12AffineFastState.Bounded env59855 := by
  intro p hp
  have h : env59855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59854_59855 : H12AffineEnvironment.transform 6 8 env59854 = env59855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env59854 == env59855) = true)

theorem identity59855 : scanCanonicalize (H12AffineFastState.compose env59855 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound59855 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59856 : List Nat := [2,4,8,10,6,10,8,14,1,5,13,1,3,1,1,4,1,13,4,0,1,11,11,15,2,11,12,1,0,1,14,11,14,11,0,1]

theorem envBound59856 : H12AffineFastState.Bounded env59856 := by
  intro p hp
  have h : env59856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59855_59856 : H12AffineEnvironment.transform 4 6 env59855 = env59856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env59855 == env59856) = true)

theorem identity59856 : scanCanonicalize (H12AffineFastState.compose env59856 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound59856 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env59857 : List Nat := [2,4,5,7,6,7,5,3,1,5,0,1,3,1,1,4,1,0,4,0,1,6,6,2,2,6,1,1,0,1,3,6,3,6,0,1]

theorem envBound59857 : H12AffineFastState.Bounded env59857 := by
  intro p hp
  have h : env59857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59856_59857 : H12AffineEnvironment.transform 2 5 env59856 = env59857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env59856 == env59857) = true)

def env59858 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74863,262144,4416,8540,4096,5277,74047,66896,13768,78894,328958,74814,1297,81226,8204,74799,256,8201,1345,5953]

theorem envBound59858 : H12AffineFastState.Bounded env59858 := by
  intro p hp
  have h : env59858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59806_59858 : H12AffineEnvironment.transform 13 1297 env59806 = env59858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env59806 == env59858) = true)

def env59859 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74863,65664,4416,8540,4096,5277,74047,66896,13768,78894,1150,74814,1297,81226,8204,74799,256,8201,1345,5953]

theorem envBound59859 : H12AffineFastState.Bounded env59859 := by
  intro p hp
  have h : env59859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59858_59859 : H12AffineEnvironment.transform 17 65664 env59858 = env59859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env59858 == env59859) = true)

theorem identity59859 : scanCanonicalize (H12AffineFastState.compose env59859 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5158) := by decide +kernel

theorem selectedBound59859 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env59860 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,5158,12361,5286,4416,8540,4096,5277,13593,4470,13768,8200,1150,12312,1297,10604,8204,12297,256,8201,1345,5953]

theorem envBound59860 : H12AffineFastState.Bounded env59860 := by
  intro p hp
  have h : env59860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59859_59860 : H12AffineEnvironment.transform 15 5158 env59859 = env59860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5158 env59859 == env59860) = true)

def env59861 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5384,1297,5205,5158,1345,5286,4416,5204,4096,5277,17,4470,192,5376,1150,1296,1297,7268,5380,1281,256,5377,1345,5953]

theorem envBound59861 : H12AffineFastState.Bounded env59861 := by
  intro p hp
  have h : env59861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59860_59861 : H12AffineEnvironment.transform 12 5384 env59860 = env59861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5384 env59860 == env59861) = true)

theorem identity59861 : scanCanonicalize (H12AffineFastState.compose env59861 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound59861 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env59862 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,4121,0,4420,4407,80,4535,4416,4421,4096,4492,17,4470,192,4113,367,1,0,6517,4117,16,256,4112,80,4688]

theorem envBound59862 : H12AffineFastState.Bounded env59862 := by
  intro p hp
  have h : env59862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59861_59862 : H12AffineEnvironment.transform 9 273 env59861 = env59862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env59861 == env59862) = true)

theorem identity59862 : scanCanonicalize (H12AffineFastState.compose env59862 (packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS)) = affineNative (2^(11+1) ^^^ 972) := by decide +kernel

theorem selectedBound59862 : packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS < 2^1333 := by decide +kernel

def env59863 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,972,981,0,648,763,80,635,652,649,972,576,17,698,192,989,367,1,0,2745,985,16,256,988,80,412]

theorem envBound59863 : H12AffineFastState.Bounded env59863 := by
  intro p hp
  have h : env59863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59862_59863 : H12AffineEnvironment.transform 11 972 env59862 = env59863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 972 env59862 == env59863) = true)

theorem identity59863 : scanCanonicalize (H12AffineFastState.compose env59863 (packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound59863 : packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS < 2^1333 := by decide +kernel

def env59864 : List Nat := [2,4,8,16,32,64,128,256,136,273,2048,324,349,0,0,115,80,243,4,1,324,200,17,50,192,341,367,1,0,2097,337,16,256,340,80,412]

theorem envBound59864 : H12AffineFastState.Bounded env59864 := by
  intro p hp
  have h : env59864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59863_59864 : H12AffineEnvironment.transform 8 136 env59863 = env59864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env59863 == env59864) = true)

theorem identity59864 : scanCanonicalize (H12AffineFastState.compose env59864 (packedSelected [0,1,2,3,7,10,11,15] rootPS)) = affineNative (2^(10+1) ^^^ 439) := by decide +kernel

end H12CloudChart2