import H12CloudChart2Data043

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans10709_10728 : H12AffineEnvironment.transform 21 41089 env10709 = env10728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env10709 == env10728) = true)

theorem identity10728 : scanCanonicalize (H12AffineFastState.compose env10728 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 44174) := by decide +kernel

theorem selectedBound10728 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env10729 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,8192,1297,32768,33166,1345,43048,524288,32768,1344,41089,16,138,8329,64,2477,1296,1296,43396,1285,44174,256,526383,1345,136]

theorem envBound10729 : H12AffineFastState.Bounded env10729 := by
  intro p hp
  have h : env10729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10728_10729 : H12AffineEnvironment.transform 31 44174 env10728 = env10729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 44174 env10728 == env10729) = true)

theorem identity10729 : scanCanonicalize (H12AffineFastState.compose env10729 (packedSelected [3,5,10] rootPS)) = affineNative (2^(18+1) ^^^ 43483) := by decide +kernel

theorem selectedBound10729 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env10730 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,8192,1297,32768,33166,1345,43048,43483,32768,1344,41089,16,138,8329,64,2477,1296,1296,43396,1285,44174,256,41460,1345,136]

theorem envBound10730 : H12AffineFastState.Bounded env10730 := by
  intro p hp
  have h : env10730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10729_10730 : H12AffineEnvironment.transform 18 43483 env10729 = env10730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 43483 env10729 == env10730) = true)

def env10731 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,8192,1297,2184,2310,1345,8352,8531,2184,1344,10249,16,138,8329,64,2477,1296,1296,8460,1285,9222,256,10620,1345,136]

theorem envBound10731 : H12AffineFastState.Bounded env10731 := by
  intro p hp
  have h : env10731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10730_10731 : H12AffineEnvironment.transform 14 2184 env10730 = env10731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2184 env10730 == env10731) = true)

theorem identity10731 : scanCanonicalize (H12AffineFastState.compose env10731 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound10731 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10732 : List Nat := [2,4,8,16,32,64,128,4,137,1024,2048,1092,8192,1045,2184,2050,1093,8352,8279,2184,1092,10249,16,138,8329,64,2217,1044,1044,8200,1025,9222,4,10360,1093,136]

theorem envBound10732 : H12AffineFastState.Bounded env10732 := by
  intro p hp
  have h : env10732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10731_10732 : H12AffineEnvironment.transform 7 4 env10731 = env10732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env10731 == env10732) = true)

theorem identity10732 : scanCanonicalize (H12AffineFastState.compose env10732 (packedSelected [2,4] rootPS)) = affineNative (2^(12+1) ^^^ 2288) := by decide +kernel

theorem selectedBound10732 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env10733 : List Nat := [2,4,8,16,32,64,128,4,137,1024,2048,1092,2288,1045,2184,2050,1093,2128,2215,2184,1092,249,16,138,2169,64,2217,1044,1044,2296,1025,3318,4,136,1093,136]

theorem envBound10733 : H12AffineFastState.Bounded env10733 := by
  intro p hp
  have h : env10733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10732_10733 : H12AffineEnvironment.transform 12 2288 env10732 = env10733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2288 env10732 == env10733) = true)

theorem identity10733 : scanCanonicalize (H12AffineFastState.compose env10733 (packedSelected [1,12,13] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound10733 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env10734 : List Nat := [2,4,8,16,32,64,120,4,113,1024,2048,1092,2056,1045,2160,2050,1093,2128,2143,2160,1092,1,16,114,2169,64,2129,1044,1044,2048,1025,3086,4,112,1093,112]

theorem envBound10734 : H12AffineFastState.Bounded env10734 := by
  intro p hp
  have h : env10734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10733_10734 : H12AffineEnvironment.transform 6 120 env10733 = env10734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env10733 == env10734) = true)

theorem identity10734 : scanCanonicalize (H12AffineFastState.compose env10734 (packedSelected [1,2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound10734 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env10735 : List Nat := [2,4,8,16,32,16,40,4,33,1024,2048,1044,2056,1045,2080,2050,1045,2048,2063,2080,1044,1,16,34,2089,16,2049,1044,1044,2048,1025,3086,4,32,1045,32]

theorem envBound10735 : H12AffineFastState.Bounded env10735 := by
  intro p hp
  have h : env10735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10734_10735 : H12AffineEnvironment.transform 5 16 env10734 = env10735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10734 == env10735) = true)

theorem identity10735 : scanCanonicalize (H12AffineFastState.compose env10735 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 1070) := by decide +kernel

theorem selectedBound10735 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env10736 : List Nat := [2,4,8,16,32,16,40,4,33,1024,1070,1044,1062,1045,1038,1068,1045,1070,1057,1038,1044,1,16,34,1031,16,1071,1044,1044,1070,1025,32,4,32,1045,32]

theorem envBound10736 : H12AffineFastState.Bounded env10736 := by
  intro p hp
  have h : env10736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10735_10736 : H12AffineEnvironment.transform 10 1070 env10735 = env10736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1070 env10735 == env10736) = true)

theorem identity10736 : scanCanonicalize (H12AffineFastState.compose env10736 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound10736 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10737 : List Nat := [2,4,8,16,0,16,8,4,1,1024,1038,1044,1030,1045,1038,1036,1045,1038,1025,1038,1044,1,16,2,1031,16,1039,1044,1044,1038,1025,0,4,0,1045,0]

theorem envBound10737 : H12AffineFastState.Bounded env10737 := by
  intro p hp
  have h : env10737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10736_10737 : H12AffineEnvironment.transform 4 0 env10736 = env10737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env10736 == env10737) = true)

def leafEnv10737 : List Nat := [2,4,8,16,0,16,8,4,1,1024,1038,1044,1030,1045,1038,1036,1045,1038,1025,1038,1044,1,16,2,1025,1031,1,16,1039,1044,1044,1038,1025,0,4,0,5,1037,1045,0,0,1045,1]

def active10737 : List Nat := [0,1,2,3,9]

def tree10737 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood10737 : H12WitnessSearch.Good tree10737 := H12GlobalWitnessIndex.good

theorem leafIdentity10737 : H12AffineFastState.composeSystem env10737 rootObs = leafEnv10737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env10737 rootObs == leafEnv10737) = true)

theorem terminalChecked10737 : H12PackedTerminal.terminalCheckFast leafEnv10737 active10737 tree10737 = true := by decide +kernel

def env10738 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,8192,1297,2185,2311,1345,8353,8530,2185,1344,10248,16,138,8329,64,2477,1296,1296,8461,1285,9223,256,10621,1345,136]

theorem envBound10738 : H12AffineFastState.Bounded env10738 := by
  intro p hp
  have h : env10738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10730_10738 : H12AffineEnvironment.transform 14 2185 env10730 = env10738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2185 env10730 == env10738) = true)

theorem identity10738 : scanCanonicalize (H12AffineFastState.compose env10738 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 2057) := by decide +kernel

theorem selectedBound10738 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10739 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,2057,1297,2185,2311,1345,2216,2395,2185,1344,1,16,138,2176,64,2477,1296,1296,2308,1285,3086,256,372,1345,136]

theorem envBound10739 : H12AffineFastState.Bounded env10739 := by
  intro p hp
  have h : env10739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10738_10739 : H12AffineEnvironment.transform 12 2057 env10738 = env10739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2057 env10738 == env10739) = true)

theorem identity10739 : scanCanonicalize (H12AffineFastState.compose env10739 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound10739 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env10740 : List Nat := [2,4,8,16,32,64,128,85,137,1024,2048,1045,2057,1092,2185,2130,1044,2216,2062,2185,1045,1,16,138,2176,64,2296,1093,1093,2129,1104,3086,85,33,1044,136]

theorem envBound10740 : H12AffineFastState.Bounded env10740 := by
  intro p hp
  have h : env10740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10739_10740 : H12AffineEnvironment.transform 7 85 env10739 = env10740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env10739 == env10740) = true)

theorem identity10740 : scanCanonicalize (H12AffineFastState.compose env10740 (packedSelected [5] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound10740 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env10741 : List Nat := [2,4,8,16,32,64,120,85,113,1024,2048,1045,2057,1092,2161,2130,1044,2128,2062,2161,1045,1,16,114,2168,64,2048,1093,1093,2129,1104,3086,85,33,1044,112]

theorem envBound10741 : H12AffineFastState.Bounded env10741 := by
  intro p hp
  have h : env10741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10740_10741 : H12AffineEnvironment.transform 6 120 env10740 = env10741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env10740 == env10741) = true)

theorem identity10741 : scanCanonicalize (H12AffineFastState.compose env10741 (packedSelected [7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound10741 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env10742 : List Nat := [2,4,8,16,32,17,41,4,32,1024,2048,1045,2057,1045,2080,2051,1044,2049,2062,2080,1045,1,16,35,2089,17,2048,1044,1044,2048,1025,3086,4,33,1044,33]

theorem envBound10742 : H12AffineFastState.Bounded env10742 := by
  intro p hp
  have h : env10742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10741_10742 : H12AffineEnvironment.transform 5 17 env10741 = env10742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10741 == env10742) = true)

theorem identity10742 : scanCanonicalize (H12AffineFastState.compose env10742 (packedSelected [1,2] rootPS)) = affineNative (2^(10+1) ^^^ 1039) := by decide +kernel

theorem selectedBound10742 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env10743 : List Nat := [2,4,8,16,32,17,41,4,32,1024,1039,1045,1030,1045,1071,1036,1044,1038,1025,1071,1045,1,16,35,1062,17,1039,1044,1044,1039,1025,1,4,33,1044,33]

theorem envBound10743 : H12AffineFastState.Bounded env10743 := by
  intro p hp
  have h : env10743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10742_10743 : H12AffineEnvironment.transform 10 1039 env10742 = env10743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1039 env10742 == env10743) = true)

def env10744 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,65536,1344,262144,524288,32768,1345,4194304,17,16777216,8329,65,21331968,1297,1297,4294795,16876545,4294967296,256,4316464298,1344,513]

theorem envBound10744 : H12AffineFastState.Bounded env10744 := by
  intro p hp
  have h : env10744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10704_10744 : H12AffineEnvironment.transform 11 1345 env10704 = env10744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env10704 == env10744) = true)

theorem identity10744 : scanCanonicalize (H12AffineFastState.compose env10744 (packedSelected [0,4,7,9,16,20] rootPS)) = affineNative (2^(8+1) ^^^ 217) := by decide +kernel

theorem selectedBound10744 : packedSelected [0,4,7,9,16,20] rootPS < 2^1333 := by decide +kernel

def env10745 : List Nat := [2,4,8,16,32,64,128,256,217,1024,2048,1345,8192,1296,32768,65536,1344,262144,524288,32768,1345,4194304,17,16777216,8329,65,21331968,1297,1297,4294795,16876545,4294967296,256,4316464298,1344,216]

theorem envBound10745 : H12AffineFastState.Bounded env10745 := by
  intro p hp
  have h : env10745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10744_10745 : H12AffineEnvironment.transform 8 217 env10744 = env10745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env10744 == env10745) = true)

theorem identity10745 : scanCanonicalize (H12AffineFastState.compose env10745 (packedSelected [4,16,22] rootPS)) = affineNative (2^(23+1) ^^^ 623876) := by decide +kernel

theorem selectedBound10745 : packedSelected [4,16,22] rootPS < 2^1333 := by decide +kernel

def env10746 : List Nat := [2,4,8,16,32,64,128,256,217,1024,2048,1345,8192,1296,32768,65536,1344,262144,524288,32768,1345,4194304,17,623876,8329,65,4982020,1297,1297,4294795,524549,4294967296,256,4299260334,1344,216]

theorem envBound10746 : H12AffineFastState.Bounded env10746 := by
  intro p hp
  have h : env10746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10745_10746 : H12AffineEnvironment.transform 23 623876 env10745 = env10746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 623876 env10745 == env10746) = true)

theorem identity10746 : scanCanonicalize (H12AffineFastState.compose env10746 (packedSelected [4,9,16] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound10746 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env10747 : List Nat := [2,4,8,16,32,64,128,256,217,1024,2048,1345,8192,1296,32768,65536,1344,262144,1025,32768,1345,4194304,17,98565,8329,65,4456709,1297,1297,4294795,1284,4294967296,256,4299260334,1344,216]

theorem envBound10747 : H12AffineFastState.Bounded env10747 := by
  intro p hp
  have h : env10747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10746_10747 : H12AffineEnvironment.transform 18 1025 env10746 = env10747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env10746 == env10747) = true)

theorem identity10747 : scanCanonicalize (H12AffineFastState.compose env10747 (packedSelected [3,5,10] rootPS)) = affineNative (2^(31+1) ^^^ 98598) := by decide +kernel

theorem selectedBound10747 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env10748 : List Nat := [2,4,8,16,32,64,128,256,217,1024,2048,1345,8192,1296,32768,65536,1344,262144,1025,32768,1345,4194304,17,98565,8329,65,4456709,1297,1297,4294795,1284,98598,256,4194440,1344,216]

theorem envBound10748 : H12AffineFastState.Bounded env10748 := by
  intro p hp
  have h : env10748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10747_10748 : H12AffineEnvironment.transform 31 98598 env10747 = env10748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 98598 env10747 == env10748) = true)

theorem identity10748 : scanCanonicalize (H12AffineFastState.compose env10748 (packedSelected [1,12,13] rootPS)) = affineNative (2^(21+1) ^^^ 338317) := by decide +kernel

theorem selectedBound10748 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env10749 : List Nat := [2,4,8,16,32,64,128,256,217,1024,2048,1345,8192,1296,32768,65536,1344,262144,1025,32768,1345,338317,17,98565,8329,65,75912,1297,1297,303366,1284,98598,256,338181,1344,216]

theorem envBound10749 : H12AffineFastState.Bounded env10749 := by
  intro p hp
  have h : env10749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10748_10749 : H12AffineEnvironment.transform 21 338317 env10748 = env10749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 338317 env10748 == env10749) = true)

theorem identity10749 : scanCanonicalize (H12AffineFastState.compose env10749 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound10749 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env10750 : List Nat := [2,4,8,16,32,64,128,256,217,1024,2048,1345,8192,1296,32768,65536,1344,43049,1025,32768,1345,98724,17,98565,8329,65,75912,1297,1297,2351,1284,98598,256,98604,1344,216]

theorem envBound10750 : H12AffineFastState.Bounded env10750 := by
  intro p hp
  have h : env10750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10749_10750 : H12AffineEnvironment.transform 17 43049 env10749 = env10750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env10749 == env10750) = true)

theorem identity10750 : scanCanonicalize (H12AffineFastState.compose env10750 (packedSelected [1,3,5] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound10750 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env10751 : List Nat := [2,4,8,16,32,64,128,256,217,1024,2048,1345,8192,1296,8460,65536,1344,2341,1025,8460,1345,73896,17,73737,8329,65,75912,1297,1297,2351,1284,73770,256,73760,1344,216]

theorem envBound10751 : H12AffineFastState.Bounded env10751 := by
  intro p hp
  have h : env10751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10750_10751 : H12AffineEnvironment.transform 14 8460 env10750 = env10751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env10750 == env10751) = true)

theorem identity10751 : scanCanonicalize (H12AffineFastState.compose env10751 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 1245) := by decide +kernel

theorem selectedBound10751 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env10752 : List Nat := [2,4,8,16,32,64,128,256,217,1024,1245,1345,8192,1296,8460,65536,1344,1528,1025,8460,1345,73896,17,73737,8329,65,74837,1297,1297,1522,1284,73770,256,73760,1344,216]

theorem envBound10752 : H12AffineFastState.Bounded env10752 := by
  intro p hp
  have h : env10752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10751_10752 : H12AffineEnvironment.transform 10 1245 env10751 = env10752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1245 env10751 == env10752) = true)

theorem identity10752 : scanCanonicalize (H12AffineFastState.compose env10752 (packedSelected [1,12,21] rootPS)) = affineNative (2^(5+1) ^^^ 27) := by decide +kernel

theorem selectedBound10752 : packedSelected [1,12,21] rootPS < 2^1333 := by decide +kernel

def env10753 : List Nat := [2,4,8,16,32,27,128,256,130,1024,1158,1306,8192,1296,8460,65536,1307,1443,1025,8460,1306,73896,17,73737,8329,26,74766,1297,1297,1449,1284,73770,256,73760,1307,131]

theorem envBound10753 : H12AffineFastState.Bounded env10753 := by
  intro p hp
  have h : env10753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10752_10753 : H12AffineEnvironment.transform 5 27 env10752 = env10753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 27 env10752 == env10753) = true)

def env10754 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,4097,4194304,17665,16777216,33554432,67108864,21352528,67130625,131153,1073741824,16876545,4294967296,256,4417151346,131072,33563272]

theorem envBound10754 : H12AffineFastState.Bounded env10754 := by
  intro p hp
  have h : env10754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10641_10754 : H12AffineEnvironment.transform 20 4097 env10641 = env10754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env10641 == env10754) = true)

def env10755 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,17665,16777216,33554432,67108864,134217728,67130625,157794305,1073741824,140788817,4294967296,157663568,4417151346,131073,33563272]

theorem envBound10755 : H12AffineFastState.Bounded env10755 := by
  intro p hp
  have h : env10755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10091_10755 : H12AffineEnvironment.transform 28 157794305 env10091 = env10755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 157794305 env10091 == env10755) = true)

theorem identity10755 : scanCanonicalize (H12AffineFastState.compose env10755 (packedSelected [14] rootPS)) = affineNative (2^(20+1) ^^^ 4096) := by decide +kernel

theorem selectedBound10755 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env10756 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,4096,4194304,17665,16777216,33554432,67108864,134217728,67130625,155701249,1073741824,138695761,4294967296,155570512,4417151346,131073,33563272]

theorem envBound10756 : H12AffineFastState.Bounded env10756 := by
  intro p hp
  have h : env10756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10755_10756 : H12AffineEnvironment.transform 20 4096 env10755 = env10756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env10755 == env10756) = true)

def env10757 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,4096,4194304,17665,16777216,33554432,67108864,21352528,67130625,131153,1073741824,16876545,4294967296,256,4417151346,131073,33563272]

theorem envBound10757 : H12AffineFastState.Bounded env10757 := by
  intro p hp
  have h : env10757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10756_10757 : H12AffineEnvironment.transform 26 21352528 env10756 = env10757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21352528 env10756 == env10757) = true)

theorem identity10757 : scanCanonicalize (H12AffineFastState.compose env10757 (packedSelected [35] rootPS)) = affineNative (2^(25+1) ^^^ 5377) := by decide +kernel

theorem selectedBound10757 : packedSelected [35] rootPS < 2^1333 := by decide +kernel

def env10758 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,4096,4194304,17665,16777216,33554432,5377,21352528,16384,131153,1073741824,16876545,4294967296,256,4350047347,131073,33563272]

theorem envBound10758 : H12AffineFastState.Bounded env10758 := by
  intro p hp
  have h : env10758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10757_10758 : H12AffineEnvironment.transform 25 5377 env10757 = env10758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 5377 env10757 == env10758) = true)

theorem identity10758 : scanCanonicalize (H12AffineFastState.compose env10758 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(24+1) ^^^ 8329) := by decide +kernel

theorem selectedBound10758 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env10759 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,4096,4194304,17665,16777216,8329,5377,21352528,16384,131153,1073741824,16876545,4294967296,256,4316484858,131073,513]

theorem envBound10759 : H12AffineFastState.Bounded env10759 := by
  intro p hp
  have h : env10759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10758_10759 : H12AffineEnvironment.transform 24 8329 env10758 = env10759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8329 env10758 == env10759) = true)

def env10760 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,524288,32768,4096,4194304,5457,16777216,8329,5377,21331968,4176,131153,1073741824,16876545,4294967296,256,4316464298,131073,513]

theorem envBound10760 : H12AffineFastState.Bounded env10760 := by
  intro p hp
  have h : env10760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10759_10760 : H12AffineEnvironment.transform 13 4176 env10759 = env10760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env10759 == env10760) = true)

theorem identity10760 : scanCanonicalize (H12AffineFastState.compose env10760 (packedSelected [6,25] rootPS)) = affineNative (2^(29+1) ^^^ 4294795) := by decide +kernel

theorem selectedBound10760 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env10761 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,524288,32768,4096,4194304,5457,16777216,8329,5377,21331968,4176,131153,4294795,16876545,4294967296,256,4316464298,131073,513]

theorem envBound10761 : H12AffineFastState.Bounded env10761 := by
  intro p hp
  have h : env10761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10760_10761 : H12AffineEnvironment.transform 29 4294795 env10760 = env10761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4294795 env10760 == env10761) = true)

def env10762 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,4096,262144,524288,32768,4096,4194304,5457,16777216,8329,5377,21331968,4176,4177,4294795,16876545,4294967296,256,4316464298,4097,513]

theorem envBound10762 : H12AffineFastState.Bounded env10762 := by
  intro p hp
  have h : env10762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10761_10762 : H12AffineEnvironment.transform 16 4096 env10761 = env10762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env10761 == env10762) = true)

def env10763 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,65536,1344,262144,524288,32768,1344,4194304,17,16777216,8329,65,21331968,1296,1297,4294795,16876545,4294967296,256,4316464298,1345,513]

theorem envBound10763 : H12AffineFastState.Bounded env10763 := by
  intro p hp
  have h : env10763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10762_10763 : H12AffineEnvironment.transform 11 1344 env10762 = env10763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env10762 == env10763) = true)

theorem identity10763 : scanCanonicalize (H12AffineFastState.compose env10763 (packedSelected [0,4,7,9,16,20] rootPS)) = affineNative (2^(23+1) ^^^ 99213) := by decide +kernel

theorem selectedBound10763 : packedSelected [0,4,7,9,16,20] rootPS < 2^1333 := by decide +kernel

def env10764 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,65536,1344,262144,524288,32768,1344,4194304,17,99213,8329,65,4457357,1296,1297,4294795,1932,4294967296,256,4299786023,1345,513]

theorem envBound10764 : H12AffineFastState.Bounded env10764 := by
  intro p hp
  have h : env10764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10763_10764 : H12AffineEnvironment.transform 23 99213 env10763 = env10764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 99213 env10763 == env10764) = true)

theorem identity10764 : scanCanonicalize (H12AffineFastState.compose env10764 (packedSelected [4,16,22] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound10764 : packedSelected [4,16,22] rootPS < 2^1333 := by decide +kernel

def env10765 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,8192,1296,32768,65536,1344,262144,524288,32768,1344,4194304,17,98564,8329,65,4456708,1296,1297,4294795,1285,4294967296,256,4299785646,1345,136]

theorem envBound10765 : H12AffineFastState.Bounded env10765 := by
  intro p hp
  have h : env10765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10764_10765 : H12AffineEnvironment.transform 8 137 env10764 = env10765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env10764 == env10765) = true)

theorem identity10765 : scanCanonicalize (H12AffineFastState.compose env10765 (packedSelected [1,3,12,13,15,17] rootPS)) = affineNative (2^(17+1) ^^^ 76198) := by decide +kernel

theorem selectedBound10765 : packedSelected [1,3,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env10766 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,8192,1296,32768,65536,1344,76198,524288,32768,1344,4194304,17,98564,8329,65,4270242,1296,1297,4294795,1285,4294967296,256,4299785646,1345,136]

theorem envBound10766 : H12AffineFastState.Bounded env10766 := by
  intro p hp
  have h : env10766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10765_10766 : H12AffineEnvironment.transform 17 76198 env10765 = env10766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76198 env10765 == env10766) = true)

theorem identity10766 : scanCanonicalize (H12AffineFastState.compose env10766 (packedSelected [1,3,5,12,13,24] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound10766 : packedSelected [1,3,5,12,13,24] rootPS < 2^1333 := by decide +kernel

def env10767 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,8192,1296,32768,33166,1344,43048,524288,32768,1344,4194304,17,138,8329,65,4237612,1296,1297,4196613,1285,4294967296,256,4299686944,1345,136]

theorem envBound10767 : H12AffineFastState.Bounded env10767 := by
  intro p hp
  have h : env10767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10766_10767 : H12AffineEnvironment.transform 15 33166 env10766 = env10767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env10766 == env10767) = true)

def env10768 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,8192,1296,32768,33166,1344,43048,524288,32768,1344,41088,17,138,8329,65,2476,1296,1297,43397,1285,4294967296,256,4295533728,1345,136]

theorem envBound10768 : H12AffineFastState.Bounded env10768 := by
  intro p hp
  have h : env10768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10767_10768 : H12AffineEnvironment.transform 21 41088 env10767 = env10768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env10767 == env10768) = true)

theorem identity10768 : scanCanonicalize (H12AffineFastState.compose env10768 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 3459) := by decide +kernel

theorem selectedBound10768 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env10769 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,8192,1296,32768,33166,1344,43048,524288,32768,1344,41088,17,138,8329,65,2476,1296,1297,43397,1285,3459,256,567587,1345,136]

theorem envBound10769 : H12AffineFastState.Bounded env10769 := by
  intro p hp
  have h : env10769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10768_10769 : H12AffineEnvironment.transform 31 3459 env10768 = env10769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 3459 env10768 == env10769) = true)

theorem identity10769 : scanCanonicalize (H12AffineFastState.compose env10769 (packedSelected [3,5,10] rootPS)) = affineNative (2^(18+1) ^^^ 2263) := by decide +kernel

theorem selectedBound10769 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env10770 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,8192,1296,32768,33166,1344,43048,2263,32768,1344,41088,17,138,8329,65,2476,1296,1297,43397,1285,3459,256,41460,1345,136]

theorem envBound10770 : H12AffineFastState.Bounded env10770 := by
  intro p hp
  have h : env10770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10769_10770 : H12AffineEnvironment.transform 18 2263 env10769 = env10770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 2263 env10769 == env10770) = true)

def env10771 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,8192,1296,2184,2310,1344,8352,2263,2184,1344,10248,17,138,8329,65,2476,1296,1297,8461,1285,3459,256,10620,1345,136]

theorem envBound10771 : H12AffineFastState.Bounded env10771 := by
  intro p hp
  have h : env10771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10770_10771 : H12AffineEnvironment.transform 14 2184 env10770 = env10771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2184 env10770 == env10771) = true)

theorem identity10771 : scanCanonicalize (H12AffineFastState.compose env10771 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 2136) := by decide +kernel

theorem selectedBound10771 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10772 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,2136,1296,2184,2310,1344,2296,2263,2184,1344,80,17,138,2257,65,2476,1296,1297,2389,1285,3459,256,292,1345,136]

theorem envBound10772 : H12AffineFastState.Bounded env10772 := by
  intro p hp
  have h : env10772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10771_10772 : H12AffineEnvironment.transform 12 2136 env10771 = env10772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2136 env10771 == env10772) = true)

theorem identity10772 : scanCanonicalize (H12AffineFastState.compose env10772 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound10772 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env10773 : List Nat := [2,4,8,16,32,64,128,4,137,1024,2048,1092,2136,1044,2184,2050,1092,2296,2263,2184,1092,80,17,138,2257,65,2216,1044,1045,2129,1025,3207,4,32,1093,136]

theorem envBound10773 : H12AffineFastState.Bounded env10773 := by
  intro p hp
  have h : env10773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10772_10773 : H12AffineEnvironment.transform 7 4 env10772 = env10773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env10772 == env10773) = true)

theorem identity10773 : scanCanonicalize (H12AffineFastState.compose env10773 (packedSelected [2,3,5,12] rootPS)) = affineNative (2^(10+1) ^^^ 1070) := by decide +kernel

theorem selectedBound10773 : packedSelected [2,3,5,12] rootPS < 2^1333 := by decide +kernel

def env10774 : List Nat := [2,4,8,16,32,64,128,4,137,1024,1070,1092,1142,1044,1190,1068,1092,1238,1273,1190,1092,80,17,138,1279,65,1158,1044,1045,1151,1025,169,4,32,1093,136]

theorem envBound10774 : H12AffineFastState.Bounded env10774 := by
  intro p hp
  have h : env10774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10773_10774 : H12AffineEnvironment.transform 10 1070 env10773 = env10774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1070 env10773 == env10774) = true)

theorem identity10774 : scanCanonicalize (H12AffineFastState.compose env10774 (packedSelected [2,3] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound10774 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env10775 : List Nat := [2,4,8,16,32,64,120,4,113,1024,1070,1092,1142,1044,1118,1068,1092,1070,1025,1118,1092,80,17,114,1031,65,1150,1044,1045,1151,1025,81,4,32,1093,112]

theorem envBound10775 : H12AffineFastState.Bounded env10775 := by
  intro p hp
  have h : env10775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10774_10775 : H12AffineEnvironment.transform 6 120 env10774 = env10775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env10774 == env10775) = true)

theorem identity10775 : scanCanonicalize (H12AffineFastState.compose env10775 (packedSelected [1,2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound10775 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env10776 : List Nat := [2,4,8,16,32,16,40,4,33,1024,1070,1044,1062,1044,1038,1068,1044,1070,1025,1038,1044,0,17,34,1031,17,1070,1044,1045,1071,1025,1,4,32,1045,32]

theorem envBound10776 : H12AffineFastState.Bounded env10776 := by
  intro p hp
  have h : env10776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10775_10776 : H12AffineEnvironment.transform 5 16 env10775 = env10776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10775 == env10776) = true)

def env10777 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,8192,1296,2185,2311,1344,8353,2263,2185,1344,10249,17,138,8329,65,2476,1296,1297,8460,1285,3459,256,10621,1345,136]

theorem envBound10777 : H12AffineFastState.Bounded env10777 := by
  intro p hp
  have h : env10777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10770_10777 : H12AffineEnvironment.transform 14 2185 env10770 = env10777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2185 env10770 == env10777) = true)

theorem identity10777 : scanCanonicalize (H12AffineFastState.compose env10777 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound10777 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10778 : List Nat := [2,4,8,16,32,64,128,85,137,1024,2048,1045,8192,1093,2185,2130,1045,8353,2263,2185,1045,10249,17,138,8329,65,2297,1093,1092,8281,1104,3286,85,10280,1044,136]

theorem envBound10778 : H12AffineFastState.Bounded env10778 := by
  intro p hp
  have h : env10778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10777_10778 : H12AffineEnvironment.transform 7 85 env10777 = env10778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env10777 == env10778) = true)

theorem identity10778 : scanCanonicalize (H12AffineFastState.compose env10778 (packedSelected [2,4] rootPS)) = affineNative (2^(12+1) ^^^ 2289) := by decide +kernel

theorem selectedBound10778 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env10779 : List Nat := [2,4,8,16,32,64,128,85,137,1024,2048,1045,2289,1093,2185,2130,1045,2128,2263,2185,1045,248,17,138,2168,65,2297,1093,1092,2216,1104,3286,85,217,1044,136]

theorem envBound10779 : H12AffineFastState.Bounded env10779 := by
  intro p hp
  have h : env10779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10778_10779 : H12AffineEnvironment.transform 12 2289 env10778 = env10779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2289 env10778 == env10779) = true)

theorem identity10779 : scanCanonicalize (H12AffineFastState.compose env10779 (packedSelected [1,13] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound10779 : packedSelected [1,13] rootPS < 2^1333 := by decide +kernel

def env10780 : List Nat := [2,4,8,16,32,64,120,85,113,1024,2048,1045,2057,1093,2161,2130,1045,2128,2095,2161,1045,0,17,114,2168,65,2049,1093,1092,2128,1104,3118,85,33,1044,112]

theorem envBound10780 : H12AffineFastState.Bounded env10780 := by
  intro p hp
  have h : env10780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10779_10780 : H12AffineEnvironment.transform 6 120 env10779 = env10780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env10779 == env10780) = true)

theorem identity10780 : scanCanonicalize (H12AffineFastState.compose env10780 (packedSelected [7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound10780 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env10781 : List Nat := [2,4,8,16,32,17,41,4,32,1024,2048,1045,2057,1044,2080,2051,1045,2049,2095,2080,1045,0,17,35,2089,16,2049,1044,1045,2049,1025,3118,4,33,1044,33]

theorem envBound10781 : H12AffineFastState.Bounded env10781 := by
  intro p hp
  have h : env10781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10780_10781 : H12AffineEnvironment.transform 5 17 env10780 = env10781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10780 == env10781) = true)

theorem identity10781 : scanCanonicalize (H12AffineFastState.compose env10781 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1039) := by decide +kernel

theorem selectedBound10781 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10782 : List Nat := [2,4,8,16,32,17,41,4,32,1024,1039,1045,1030,1044,1071,1036,1045,1038,1056,1071,1045,0,17,35,1062,16,1038,1044,1045,1038,1025,33,4,33,1044,33]

theorem envBound10782 : H12AffineFastState.Bounded env10782 := by
  intro p hp
  have h : env10782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10781_10782 : H12AffineEnvironment.transform 10 1039 env10781 = env10782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1039 env10781 == env10782) = true)

theorem identity10782 : scanCanonicalize (H12AffineFastState.compose env10782 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound10782 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10783 : List Nat := [2,4,8,16,1,17,8,4,1,1024,1039,1045,1030,1044,1038,1036,1045,1038,1025,1038,1045,0,17,2,1031,16,1038,1044,1045,1038,1025,0,4,0,1044,0]

theorem envBound10783 : H12AffineFastState.Bounded env10783 := by
  intro p hp
  have h : env10783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10782_10783 : H12AffineEnvironment.transform 4 1 env10782 = env10783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env10782 == env10783) = true)

def leafEnv10783 : List Nat := [2,4,8,16,1,17,8,4,1,1024,1039,1045,1030,1044,1038,1036,1045,1038,1025,1038,1045,0,17,2,1025,1031,1,16,1038,1044,1045,1038,1025,0,4,0,5,1037,1044,0,0,1044,1]

def active10783 : List Nat := [0,1,2,3,9]

def tree10783 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood10783 : H12WitnessSearch.Good tree10783 := H12GlobalWitnessIndex.good

theorem leafIdentity10783 : H12AffineFastState.composeSystem env10783 rootObs = leafEnv10783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env10783 rootObs == leafEnv10783) = true)

theorem terminalChecked10783 : H12PackedTerminal.terminalCheckFast leafEnv10783 active10783 tree10783 = true := by decide +kernel

def env10784 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,8192,1296,32768,33166,1344,43048,524288,32768,1344,41089,17,138,8329,65,2477,1296,1297,43396,1285,4294967296,256,4295533729,1345,136]

theorem envBound10784 : H12AffineFastState.Bounded env10784 := by
  intro p hp
  have h : env10784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10767_10784 : H12AffineEnvironment.transform 21 41089 env10767 = env10784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env10767 == env10784) = true)

theorem identity10784 : scanCanonicalize (H12AffineFastState.compose env10784 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 44175) := by decide +kernel

theorem selectedBound10784 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env10785 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,8192,1296,32768,33166,1344,43048,524288,32768,1344,41089,17,138,8329,65,2477,1296,1297,43396,1285,44175,256,526382,1345,136]

theorem envBound10785 : H12AffineFastState.Bounded env10785 := by
  intro p hp
  have h : env10785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10784_10785 : H12AffineEnvironment.transform 31 44175 env10784 = env10785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 44175 env10784 == env10785) = true)

theorem identity10785 : scanCanonicalize (H12AffineFastState.compose env10785 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 11739) := by decide +kernel

theorem selectedBound10785 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env10786 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,8192,1296,11739,11349,1344,1523,524288,11739,1344,3418,17,138,8329,65,2477,1296,1297,1119,1285,340,256,526382,1345,136]

theorem envBound10786 : H12AffineFastState.Bounded env10786 := by
  intro p hp
  have h : env10786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10785_10786 : H12AffineEnvironment.transform 14 11739 env10785 = env10786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 11739 env10785 == env10786) = true)

def env10787 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,2316,1296,1239,1369,1344,1523,524288,1239,1344,3418,17,138,2437,65,2477,1296,1297,1119,1285,340,256,526382,1345,136]

theorem envBound10787 : H12AffineFastState.Bounded env10787 := by
  intro p hp
  have h : env10787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10786_10787 : H12AffineEnvironment.transform 12 2316 env10786 = env10787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2316 env10786 == env10787) = true)

theorem identity10787 : scanCanonicalize (H12AffineFastState.compose env10787 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1290) := by decide +kernel

theorem selectedBound10787 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10788 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1290,1344,1030,1296,1239,1369,1344,1523,524288,1239,1344,80,17,138,1167,65,1191,1296,1297,1119,1285,340,256,525604,1345,136]

theorem envBound10788 : H12AffineFastState.Bounded env10788 := by
  intro p hp
  have h : env10788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10787_10788 : H12AffineEnvironment.transform 10 1290 env10787 = env10788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1290 env10787 == env10788) = true)

theorem identity10788 : scanCanonicalize (H12AffineFastState.compose env10788 (packedSelected [2,4,7] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound10788 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env10789 : List Nat := [2,4,8,16,32,64,128,84,137,1024,1118,1044,1030,1092,1239,1037,1044,1191,524288,1239,1044,80,17,138,1167,65,1191,1092,1093,1119,1105,0,84,525424,1045,136]

theorem envBound10789 : H12AffineFastState.Bounded env10789 := by
  intro p hp
  have h : env10789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10788_10789 : H12AffineEnvironment.transform 7 84 env10788 = env10789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env10788 == env10789) = true)

theorem identity10789 : scanCanonicalize (H12AffineFastState.compose env10789 (packedSelected [2,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound10789 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env10790 : List Nat := [2,4,8,16,32,16,128,4,137,1024,1038,1044,1030,1044,1159,1037,1044,1191,524288,1159,1044,0,17,138,1167,17,1191,1044,1045,1039,1025,0,4,525344,1045,136]

theorem envBound10790 : H12AffineFastState.Bounded env10790 := by
  intro p hp
  have h : env10790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10789_10790 : H12AffineEnvironment.transform 5 16 env10789 = env10790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10789 == env10790) = true)

theorem identity10790 : scanCanonicalize (H12AffineFastState.compose env10790 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound10790 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10791 : List Nat := [2,4,8,16,32,16,9,4,0,1024,1038,1044,1030,1044,1038,1037,1044,1070,524288,1038,1044,0,17,3,1030,17,1070,1044,1045,1039,1025,0,4,525344,1045,1]

theorem envBound10791 : H12AffineFastState.Bounded env10791 := by
  intro p hp
  have h : env10791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10790_10791 : H12AffineEnvironment.transform 6 9 env10790 = env10791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env10790 == env10791) = true)

theorem identity10791 : scanCanonicalize (H12AffineFastState.compose env10791 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound10791 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10792 : List Nat := [2,4,8,16,0,16,9,4,0,1024,1038,1044,1030,1044,1038,1037,1044,1038,524288,1038,1044,0,17,3,1030,17,1038,1044,1045,1039,1025,0,4,525312,1045,1]

theorem envBound10792 : H12AffineFastState.Bounded env10792 := by
  intro p hp
  have h : env10792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10791_10792 : H12AffineEnvironment.transform 4 0 env10791 = env10792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env10791 == env10792) = true)

def leafEnv10792 : List Nat := [2,4,8,16,0,16,9,4,0,1024,1038,1044,1030,1044,1038,1037,1044,1038,524288,1038,1044,0,17,3,524288,1030,1,17,1038,1044,1045,1039,1025,0,4,525312,5,1037,1045,1,0,1044,1]

def active10792 : List Nat := [0,1,2,3,9,18]

def tree10792 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood10792 : H12WitnessSearch.Good tree10792 := H12GlobalWitnessIndex.good

theorem leafIdentity10792 : H12AffineFastState.composeSystem env10792 rootObs = leafEnv10792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env10792 rootObs == leafEnv10792) = true)

theorem terminalChecked10792 : H12PackedTerminal.terminalCheckFast leafEnv10792 active10792 tree10792 = true := by decide +kernel

def env10793 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,2317,1296,1238,1368,1344,1523,524288,1238,1344,3418,17,138,2436,65,2477,1296,1297,1119,1285,340,256,526382,1345,136]

theorem envBound10793 : H12AffineFastState.Bounded env10793 := by
  intro p hp
  have h : env10793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10786_10793 : H12AffineEnvironment.transform 12 2317 env10786 = env10793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2317 env10786 == env10793) = true)

theorem identity10793 : scanCanonicalize (H12AffineFastState.compose env10793 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound10793 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10794 : List Nat := [2,4,8,16,32,64,128,85,137,1024,2048,1045,2136,1093,1238,1037,1045,1190,524288,1238,1045,3087,17,138,2257,65,2296,1093,1092,1119,1104,1,85,526382,1044,136]

theorem envBound10794 : H12AffineFastState.Bounded env10794 := by
  intro p hp
  have h : env10794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10793_10794 : H12AffineEnvironment.transform 7 85 env10793 = env10794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env10793 == env10794) = true)

theorem identity10794 : scanCanonicalize (H12AffineFastState.compose env10794 (packedSelected [2,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 1191) := by decide +kernel

theorem selectedBound10794 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env10795 : List Nat := [2,4,8,16,32,64,128,85,137,1024,1191,1045,1279,1093,1238,1037,1045,1190,524288,1238,1045,168,17,138,1142,65,1119,1093,1092,1119,1104,1,85,525449,1044,136]

theorem envBound10795 : H12AffineFastState.Bounded env10795 := by
  intro p hp
  have h : env10795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10794_10795 : H12AffineEnvironment.transform 10 1191 env10794 = env10795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1191 env10794 == env10795) = true)

theorem identity10795 : scanCanonicalize (H12AffineFastState.compose env10795 (packedSelected [2,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound10795 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env10796 : List Nat := [2,4,8,16,32,17,128,4,137,1024,1191,1045,1198,1044,1159,1037,1045,1190,524288,1159,1045,168,17,138,1063,16,1038,1044,1045,1038,1025,1,4,525449,1044,136]

theorem envBound10796 : H12AffineFastState.Bounded env10796 := by
  intro p hp
  have h : env10796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10795_10796 : H12AffineEnvironment.transform 5 17 env10795 = env10796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10795 == env10796) = true)

theorem identity10796 : scanCanonicalize (H12AffineFastState.compose env10796 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound10796 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10797 : List Nat := [2,4,8,16,32,17,40,4,33,1024,1039,1045,1030,1044,1071,1037,1045,1038,524288,1071,1045,0,17,34,1063,16,1038,1044,1045,1038,1025,1,4,525345,1044,32]

theorem envBound10797 : H12AffineFastState.Bounded env10797 := by
  intro p hp
  have h : env10797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10796_10797 : H12AffineEnvironment.transform 6 40 env10796 = env10797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env10796 == env10797) = true)

def env10798 : List Nat := [2,4,8,16,32,17,40,4,33,1024,1039,1045,1030,1044,1071,1037,1045,1038,1024,1071,1045,0,17,34,1063,16,1038,1044,1045,1038,1025,1,4,33,1044,32]

theorem envBound10798 : H12AffineFastState.Bounded env10798 := by
  intro p hp
  have h : env10798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10797_10798 : H12AffineEnvironment.transform 18 1024 env10797 = env10798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env10797 == env10798) = true)

theorem identity10798 : scanCanonicalize (H12AffineFastState.compose env10798 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound10798 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10799 : List Nat := [2,4,8,16,1,17,9,4,0,1024,1039,1045,1030,1044,1038,1037,1045,1038,1024,1038,1045,0,17,3,1030,16,1038,1044,1045,1038,1025,1,4,0,1044,1]

theorem envBound10799 : H12AffineFastState.Bounded env10799 := by
  intro p hp
  have h : env10799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10798_10799 : H12AffineEnvironment.transform 4 1 env10798 = env10799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env10798 == env10799) = true)

def leafEnv10799 : List Nat := [2,4,8,16,1,17,9,4,0,1024,1039,1045,1030,1044,1038,1037,1045,1038,1024,1038,1045,0,17,3,1024,1030,1,16,1038,1044,1045,1038,1025,1,4,0,5,1037,1044,1,0,1044,1]

def active10799 : List Nat := [0,1,2,3,9]

def tree10799 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood10799 : H12WitnessSearch.Good tree10799 := H12GlobalWitnessIndex.good

theorem leafIdentity10799 : H12AffineFastState.composeSystem env10799 rootObs = leafEnv10799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env10799 rootObs == leafEnv10799) = true)

theorem terminalChecked10799 : H12PackedTerminal.terminalCheckFast leafEnv10799 active10799 tree10799 = true := by decide +kernel

def env10800 : List Nat := [2,4,8,16,32,17,40,4,33,1024,1039,1045,1030,1044,1071,1037,1045,1038,1025,1071,1045,0,17,34,1063,16,1038,1044,1045,1038,1025,1,4,32,1044,32]

theorem envBound10800 : H12AffineFastState.Bounded env10800 := by
  intro p hp
  have h : env10800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10797_10800 : H12AffineEnvironment.transform 18 1025 env10797 = env10800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env10797 == env10800) = true)

def leafEnv10800 : List Nat := [2,4,8,16,32,17,40,4,33,1024,1039,1045,1030,1044,1071,1037,1045,1038,1025,1071,1045,0,17,34,1025,1063,1,16,1038,1044,1045,1038,1025,1,4,32,5,1068,1044,32,0,1044,1]

def active10800 : List Nat := [0,1,2,3,4,9]

def tree10800 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood10800 : H12WitnessSearch.Good tree10800 := H12GlobalWitnessIndex.good

theorem leafIdentity10800 : H12AffineFastState.composeSystem env10800 rootObs = leafEnv10800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env10800 rootObs == leafEnv10800) = true)

theorem terminalChecked10800 : H12PackedTerminal.terminalCheckFast leafEnv10800 active10800 tree10800 = true := by decide +kernel

def env10801 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,65536,1345,262144,524288,32768,1345,4194304,16,16777216,8329,64,21331968,1297,1296,4294795,16876545,4294967296,256,4316464298,1344,513]

theorem envBound10801 : H12AffineFastState.Bounded env10801 := by
  intro p hp
  have h : env10801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10762_10801 : H12AffineEnvironment.transform 11 1345 env10762 = env10801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env10762 == env10801) = true)

theorem identity10801 : scanCanonicalize (H12AffineFastState.compose env10801 (packedSelected [0,4,7,9,16,20] rootPS)) = affineNative (2^(23+1) ^^^ 99293) := by decide +kernel

theorem selectedBound10801 : packedSelected [0,4,7,9,16,20] rootPS < 2^1333 := by decide +kernel

def env10802 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,65536,1345,262144,524288,32768,1345,4194304,16,99293,8329,64,4457437,1297,1296,4294795,2012,4294967296,256,4299786103,1344,513]

theorem envBound10802 : H12AffineFastState.Bounded env10802 := by
  intro p hp
  have h : env10802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10801_10802 : H12AffineEnvironment.transform 23 99293 env10801 = env10802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 99293 env10801 == env10802) = true)

theorem identity10802 : scanCanonicalize (H12AffineFastState.compose env10802 (packedSelected [4,16,22] rootPS)) = affineNative (2^(18+1) ^^^ 1753) := by decide +kernel

theorem selectedBound10802 : packedSelected [4,16,22] rootPS < 2^1333 := by decide +kernel

def env10803 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,65536,1345,262144,1753,32768,1345,4194304,16,99293,8329,64,4457437,1297,1296,4294795,2012,4294967296,256,4299260334,1344,513]

theorem envBound10803 : H12AffineFastState.Bounded env10803 := by
  intro p hp
  have h : env10803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10802_10803 : H12AffineEnvironment.transform 18 1753 env10802 = env10803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1753 env10802 == env10803) = true)

theorem identity10803 : scanCanonicalize (H12AffineFastState.compose env10803 (packedSelected [4,9,16] rootPS)) = affineNative (2^(8+1) ^^^ 216) := by decide +kernel

theorem selectedBound10803 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env10804 : List Nat := [2,4,8,16,32,64,128,256,216,1024,2048,1345,8192,1297,32768,65536,1345,262144,1025,32768,1345,4194304,16,98565,8329,64,4456709,1297,1296,4294795,1284,4294967296,256,4299260334,1344,217]

theorem envBound10804 : H12AffineFastState.Bounded env10804 := by
  intro p hp
  have h : env10804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10803_10804 : H12AffineEnvironment.transform 8 216 env10803 = env10804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env10803 == env10804) = true)

theorem identity10804 : scanCanonicalize (H12AffineFastState.compose env10804 (packedSelected [3,5,10] rootPS)) = affineNative (2^(31+1) ^^^ 98599) := by decide +kernel

theorem selectedBound10804 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env10805 : List Nat := [2,4,8,16,32,64,128,256,216,1024,2048,1345,8192,1297,32768,65536,1345,262144,1025,32768,1345,4194304,16,98565,8329,64,4456709,1297,1296,4294795,1284,98599,256,4194441,1344,217]

theorem envBound10805 : H12AffineFastState.Bounded env10805 := by
  intro p hp
  have h : env10805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10804_10805 : H12AffineEnvironment.transform 31 98599 env10804 = env10805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 98599 env10804 == env10805) = true)

theorem identity10805 : scanCanonicalize (H12AffineFastState.compose env10805 (packedSelected [1,12,13] rootPS)) = affineNative (2^(21+1) ^^^ 270630) := by decide +kernel

theorem selectedBound10805 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env10806 : List Nat := [2,4,8,16,32,64,128,256,216,1024,2048,1345,8192,1297,32768,65536,1345,262144,1025,32768,1345,270630,16,98565,8329,64,8227,1297,1296,371117,1284,98599,256,270767,1344,217]

theorem envBound10806 : H12AffineFastState.Bounded env10806 := by
  intro p hp
  have h : env10806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10805_10806 : H12AffineEnvironment.transform 21 270630 env10805 = env10806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 270630 env10805 == env10806) = true)

def env10807 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,4097,262144,524288,32768,4096,4194304,5457,16777216,8329,5377,21331968,4176,4176,4294795,16876545,4294967296,256,4316464298,4096,513]

theorem envBound10807 : H12AffineFastState.Bounded env10807 := by
  intro p hp
  have h : env10807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10761_10807 : H12AffineEnvironment.transform 16 4097 env10761 = env10807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4097 env10761 == env10807) = true)

def env10808 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,65536,1345,262144,524288,32768,1344,4194304,17,16777216,8329,65,21331968,1296,1296,4294795,16876545,4294967296,256,4316464298,1344,513]

theorem envBound10808 : H12AffineFastState.Bounded env10808 := by
  intro p hp
  have h : env10808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10807_10808 : H12AffineEnvironment.transform 11 1344 env10807 = env10808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env10807 == env10808) = true)

theorem identity10808 : scanCanonicalize (H12AffineFastState.compose env10808 (packedSelected [0,4,7,9,16,20] rootPS)) = affineNative (2^(8+1) ^^^ 217) := by decide +kernel

theorem selectedBound10808 : packedSelected [0,4,7,9,16,20] rootPS < 2^1333 := by decide +kernel

def env10809 : List Nat := [2,4,8,16,32,64,128,256,217,1024,2048,1344,8192,1296,32768,65536,1345,262144,524288,32768,1344,4194304,17,16777216,8329,65,21331968,1296,1296,4294795,16876545,4294967296,256,4316464298,1344,216]

theorem envBound10809 : H12AffineFastState.Bounded env10809 := by
  intro p hp
  have h : env10809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10808_10809 : H12AffineEnvironment.transform 8 217 env10808 = env10809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env10808 == env10809) = true)

theorem identity10809 : scanCanonicalize (H12AffineFastState.compose env10809 (packedSelected [4,16,22] rootPS)) = affineNative (2^(23+1) ^^^ 623876) := by decide +kernel

theorem selectedBound10809 : packedSelected [4,16,22] rootPS < 2^1333 := by decide +kernel

def env10810 : List Nat := [2,4,8,16,32,64,128,256,217,1024,2048,1344,8192,1296,32768,65536,1345,262144,524288,32768,1344,4194304,17,623876,8329,65,4982020,1296,1296,4294795,524549,4294967296,256,4299260334,1344,216]

theorem envBound10810 : H12AffineFastState.Bounded env10810 := by
  intro p hp
  have h : env10810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10809_10810 : H12AffineEnvironment.transform 23 623876 env10809 = env10810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 623876 env10809 == env10810) = true)

theorem identity10810 : scanCanonicalize (H12AffineFastState.compose env10810 (packedSelected [4,9,16] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound10810 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env10811 : List Nat := [2,4,8,16,32,64,128,256,217,1024,2048,1344,8192,1296,32768,65536,1345,262144,1025,32768,1344,4194304,17,98565,8329,65,4456709,1296,1296,4294795,1284,4294967296,256,4299260334,1344,216]

theorem envBound10811 : H12AffineFastState.Bounded env10811 := by
  intro p hp
  have h : env10811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10810_10811 : H12AffineEnvironment.transform 18 1025 env10810 = env10811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env10810 == env10811) = true)

theorem identity10811 : scanCanonicalize (H12AffineFastState.compose env10811 (packedSelected [3,5,10] rootPS)) = affineNative (2^(31+1) ^^^ 98598) := by decide +kernel

theorem selectedBound10811 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env10812 : List Nat := [2,4,8,16,32,64,128,256,217,1024,2048,1344,8192,1296,32768,65536,1345,262144,1025,32768,1344,4194304,17,98565,8329,65,4456709,1296,1296,4294795,1284,98598,256,4194440,1344,216]

theorem envBound10812 : H12AffineFastState.Bounded env10812 := by
  intro p hp
  have h : env10812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10811_10812 : H12AffineEnvironment.transform 31 98598 env10811 = env10812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 98598 env10811 == env10812) = true)

theorem identity10812 : scanCanonicalize (H12AffineFastState.compose env10812 (packedSelected [1,12,13] rootPS)) = affineNative (2^(21+1) ^^^ 270710) := by decide +kernel

theorem selectedBound10812 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env10813 : List Nat := [2,4,8,16,32,64,128,256,217,1024,2048,1344,8192,1296,32768,65536,1345,262144,1025,32768,1344,270710,17,98565,8329,65,8307,1296,1296,371197,1284,98598,256,270846,1344,216]

theorem envBound10813 : H12AffineFastState.Bounded env10813 := by
  intro p hp
  have h : env10813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10812_10813 : H12AffineEnvironment.transform 21 270710 env10812 = env10813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 270710 env10812 == env10813) = true)

def env10814 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,65536,1344,262144,524288,32768,1345,4194304,16,16777216,8329,64,21331968,1297,1297,4294795,16876545,4294967296,256,4316464298,1345,513]

theorem envBound10814 : H12AffineFastState.Bounded env10814 := by
  intro p hp
  have h : env10814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10807_10814 : H12AffineEnvironment.transform 11 1345 env10807 = env10814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env10807 == env10814) = true)

theorem identity10814 : scanCanonicalize (H12AffineFastState.compose env10814 (packedSelected [0,4,7,9,16,20] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound10814 : packedSelected [0,4,7,9,16,20] rootPS < 2^1333 := by decide +kernel

def env10815 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,8192,1297,32768,65536,1344,262144,524288,32768,1345,4194304,16,16777216,8329,64,21331968,1297,1297,4294795,16876545,4294967296,256,4316464298,1345,136]

theorem envBound10815 : H12AffineFastState.Bounded env10815 := by
  intro p hp
  have h : env10815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10814_10815 : H12AffineEnvironment.transform 8 137 env10814 = env10815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env10814 == env10815) = true)

theorem identity10815 : scanCanonicalize (H12AffineFastState.compose env10815 (packedSelected [4,16,22] rootPS)) = affineNative (2^(23+1) ^^^ 98564) := by decide +kernel

theorem selectedBound10815 : packedSelected [4,16,22] rootPS < 2^1333 := by decide +kernel

def env10816 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,8192,1297,32768,65536,1344,262144,524288,32768,1345,4194304,16,98564,8329,64,4456708,1297,1297,4294795,1285,4294967296,256,4299785646,1345,136]

theorem envBound10816 : H12AffineFastState.Bounded env10816 := by
  intro p hp
  have h : env10816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10815_10816 : H12AffineEnvironment.transform 23 98564 env10815 = env10816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98564 env10815 == env10816) = true)

theorem identity10816 : scanCanonicalize (H12AffineFastState.compose env10816 (packedSelected [1,3,12,13,15,17] rootPS)) = affineNative (2^(17+1) ^^^ 76198) := by decide +kernel

theorem selectedBound10816 : packedSelected [1,3,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env10817 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,8192,1297,32768,65536,1344,76198,524288,32768,1345,4194304,16,98564,8329,64,4270242,1297,1297,4294795,1285,4294967296,256,4299785646,1345,136]

theorem envBound10817 : H12AffineFastState.Bounded env10817 := by
  intro p hp
  have h : env10817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10816_10817 : H12AffineEnvironment.transform 17 76198 env10816 = env10817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76198 env10816 == env10817) = true)

theorem identity10817 : scanCanonicalize (H12AffineFastState.compose env10817 (packedSelected [1,3,5,12,13,24] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound10817 : packedSelected [1,3,5,12,13,24] rootPS < 2^1333 := by decide +kernel

def env10818 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,8192,1297,32768,33166,1344,43048,524288,32768,1345,4194304,16,138,8329,64,4237612,1297,1297,4196613,1285,4294967296,256,4299686944,1345,136]

theorem envBound10818 : H12AffineFastState.Bounded env10818 := by
  intro p hp
  have h : env10818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10817_10818 : H12AffineEnvironment.transform 15 33166 env10817 = env10818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env10817 == env10818) = true)

def env10819 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,8192,1297,32768,33166,1344,43048,524288,32768,1345,41088,16,138,8329,64,2476,1297,1297,43397,1285,4294967296,256,4295533728,1345,136]

theorem envBound10819 : H12AffineFastState.Bounded env10819 := by
  intro p hp
  have h : env10819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10818_10819 : H12AffineEnvironment.transform 21 41088 env10818 = env10819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env10818 == env10819) = true)

theorem identity10819 : scanCanonicalize (H12AffineFastState.compose env10819 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 3458) := by decide +kernel

theorem selectedBound10819 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env10820 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,8192,1297,32768,33166,1344,43048,524288,32768,1345,41088,16,138,8329,64,2476,1297,1297,43397,1285,3458,256,567586,1345,136]

theorem envBound10820 : H12AffineFastState.Bounded env10820 := by
  intro p hp
  have h : env10820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10819_10820 : H12AffineEnvironment.transform 31 3458 env10819 = env10820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 3458 env10819 == env10820) = true)

theorem identity10820 : scanCanonicalize (H12AffineFastState.compose env10820 (packedSelected [3,5,10] rootPS)) = affineNative (2^(18+1) ^^^ 2262) := by decide +kernel

theorem selectedBound10820 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env10821 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,8192,1297,32768,33166,1344,43048,2262,32768,1345,41088,16,138,8329,64,2476,1297,1297,43397,1285,3458,256,41460,1345,136]

theorem envBound10821 : H12AffineFastState.Bounded env10821 := by
  intro p hp
  have h : env10821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10820_10821 : H12AffineEnvironment.transform 18 2262 env10820 = env10821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 2262 env10820 == env10821) = true)

def env10822 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,8192,1297,2184,2310,1344,8352,2262,2184,1345,10248,16,138,8329,64,2476,1297,1297,8461,1285,3458,256,10620,1345,136]

theorem envBound10822 : H12AffineFastState.Bounded env10822 := by
  intro p hp
  have h : env10822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10821_10822 : H12AffineEnvironment.transform 14 2184 env10821 = env10822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2184 env10821 == env10822) = true)

theorem identity10822 : scanCanonicalize (H12AffineFastState.compose env10822 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 2137) := by decide +kernel

theorem selectedBound10822 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10823 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,2137,1297,2184,2310,1344,2297,2262,2184,1345,81,16,138,2256,64,2476,1297,1297,2388,1285,3458,256,293,1345,136]

theorem envBound10823 : H12AffineFastState.Bounded env10823 := by
  intro p hp
  have h : env10823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10822_10823 : H12AffineEnvironment.transform 12 2137 env10822 = env10823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2137 env10822 == env10823) = true)

theorem identity10823 : scanCanonicalize (H12AffineFastState.compose env10823 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound10823 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env10824 : List Nat := [2,4,8,16,32,64,128,4,137,1024,2048,1093,2137,1045,2184,2050,1092,2297,2262,2184,1093,81,16,138,2256,64,2216,1045,1045,2128,1025,3206,4,33,1093,136]

theorem envBound10824 : H12AffineFastState.Bounded env10824 := by
  intro p hp
  have h : env10824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10823_10824 : H12AffineEnvironment.transform 7 4 env10823 = env10824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env10823 == env10824) = true)

theorem identity10824 : scanCanonicalize (H12AffineFastState.compose env10824 (packedSelected [2,3,5,12] rootPS)) = affineNative (2^(10+1) ^^^ 1239) := by decide +kernel

theorem selectedBound10824 : packedSelected [2,3,5,12] rootPS < 2^1333 := by decide +kernel

def env10825 : List Nat := [2,4,8,16,32,64,128,4,137,1024,1239,1093,1166,1045,1119,1237,1092,1070,1025,1119,1093,81,16,138,1031,64,1151,1045,1045,1159,1025,81,4,33,1093,136]

theorem envBound10825 : H12AffineFastState.Bounded env10825 := by
  intro p hp
  have h : env10825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10824_10825 : H12AffineEnvironment.transform 10 1239 env10824 = env10825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1239 env10824 == env10825) = true)

theorem identity10825 : scanCanonicalize (H12AffineFastState.compose env10825 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound10825 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env10826 : List Nat := [2,4,8,16,32,64,40,4,33,1024,1151,1093,1062,1045,1119,1149,1092,1070,1025,1119,1093,81,16,34,1031,64,1151,1045,1045,1071,1025,81,4,33,1093,32]

theorem envBound10826 : H12AffineFastState.Bounded env10826 := by
  intro p hp
  have h : env10826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10825_10826 : H12AffineEnvironment.transform 6 40 env10825 = env10826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env10825 == env10826) = true)

theorem identity10826 : scanCanonicalize (H12AffineFastState.compose env10826 (packedSelected [1,2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound10826 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env10827 : List Nat := [2,4,8,16,32,17,40,4,33,1024,1070,1044,1062,1045,1038,1068,1045,1070,1025,1038,1044,0,16,34,1031,17,1070,1045,1045,1071,1025,0,4,33,1044,32]

theorem envBound10827 : H12AffineFastState.Bounded env10827 := by
  intro p hp
  have h : env10827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10826_10827 : H12AffineEnvironment.transform 5 17 env10826 = env10827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10826 == env10827) = true)

theorem identity10827 : scanCanonicalize (H12AffineFastState.compose env10827 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound10827 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10828 : List Nat := [2,4,8,16,1,17,9,4,0,1024,1039,1044,1031,1045,1038,1037,1045,1039,1025,1038,1044,0,16,3,1031,17,1039,1045,1045,1038,1025,0,4,0,1044,1]

theorem envBound10828 : H12AffineFastState.Bounded env10828 := by
  intro p hp
  have h : env10828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10827_10828 : H12AffineEnvironment.transform 4 1 env10827 = env10828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env10827 == env10828) = true)

def leafEnv10828 : List Nat := [2,4,8,16,1,17,9,4,0,1024,1039,1044,1031,1045,1038,1037,1045,1039,1025,1038,1044,0,16,3,1025,1031,1,17,1039,1045,1045,1038,1025,0,4,0,5,1037,1044,1,0,1044,1]

def active10828 : List Nat := [0,1,2,3,9]

def tree10828 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood10828 : H12WitnessSearch.Good tree10828 := H12GlobalWitnessIndex.good

theorem leafIdentity10828 : H12AffineFastState.composeSystem env10828 rootObs = leafEnv10828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env10828 rootObs == leafEnv10828) = true)

theorem terminalChecked10828 : H12PackedTerminal.terminalCheckFast leafEnv10828 active10828 tree10828 = true := by decide +kernel

def env10829 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,8192,1297,2185,2311,1344,8353,2262,2185,1345,10249,16,138,8329,64,2476,1297,1297,8460,1285,3458,256,10621,1345,136]

theorem envBound10829 : H12AffineFastState.Bounded env10829 := by
  intro p hp
  have h : env10829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10821_10829 : H12AffineEnvironment.transform 14 2185 env10821 = env10829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2185 env10821 == env10829) = true)

theorem identity10829 : scanCanonicalize (H12AffineFastState.compose env10829 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound10829 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10830 : List Nat := [2,4,8,16,32,64,128,84,137,1024,2048,1045,8192,1093,2185,2131,1044,8353,2262,2185,1045,10249,16,138,8329,64,2296,1093,1093,8280,1105,3286,84,10281,1045,136]

theorem envBound10830 : H12AffineFastState.Bounded env10830 := by
  intro p hp
  have h : env10830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10829_10830 : H12AffineEnvironment.transform 7 84 env10829 = env10830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env10829 == env10830) = true)

theorem identity10830 : scanCanonicalize (H12AffineFastState.compose env10830 (packedSelected [2,4] rootPS)) = affineNative (2^(12+1) ^^^ 2288) := by decide +kernel

theorem selectedBound10830 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env10831 : List Nat := [2,4,8,16,32,64,128,84,137,1024,2048,1045,2288,1093,2185,2131,1044,2129,2262,2185,1045,249,16,138,2169,64,2296,1093,1093,2216,1105,3286,84,217,1045,136]

theorem envBound10831 : H12AffineFastState.Bounded env10831 := by
  intro p hp
  have h : env10831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10830_10831 : H12AffineEnvironment.transform 12 2288 env10830 = env10831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2288 env10830 == env10831) = true)

theorem identity10831 : scanCanonicalize (H12AffineFastState.compose env10831 (packedSelected [2,3] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound10831 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env10832 : List Nat := [2,4,8,16,32,64,41,84,32,1024,2048,1045,2137,1093,2080,2131,1044,2129,2175,2080,1045,80,16,35,2169,64,2129,1093,1093,2049,1105,3199,84,112,1045,33]

theorem envBound10832 : H12AffineFastState.Bounded env10832 := by
  intro p hp
  have h : env10832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10831_10832 : H12AffineEnvironment.transform 6 41 env10831 = env10832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env10831 == env10832) = true)

theorem identity10832 : scanCanonicalize (H12AffineFastState.compose env10832 (packedSelected [7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound10832 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env10833 : List Nat := [2,4,8,16,32,16,41,4,32,1024,2048,1045,2057,1045,2080,2051,1044,2049,2095,2080,1045,0,16,35,2089,16,2049,1045,1045,2049,1025,3119,4,32,1045,33]

theorem envBound10833 : H12AffineFastState.Bounded env10833 := by
  intro p hp
  have h : env10833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10832_10833 : H12AffineEnvironment.transform 5 16 env10832 = env10833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10832 == env10833) = true)

theorem identity10833 : scanCanonicalize (H12AffineFastState.compose env10833 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1070) := by decide +kernel

theorem selectedBound10833 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10834 : List Nat := [2,4,8,16,32,16,41,4,32,1024,1070,1045,1063,1045,1038,1069,1044,1071,1025,1038,1045,0,16,35,1031,16,1071,1045,1045,1071,1025,1,4,32,1045,33]

theorem envBound10834 : H12AffineFastState.Bounded env10834 := by
  intro p hp
  have h : env10834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10833_10834 : H12AffineEnvironment.transform 10 1070 env10833 = env10834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1070 env10833 == env10834) = true)

def leafEnv10834 : List Nat := [2,4,8,16,32,16,41,4,32,1024,1070,1045,1063,1045,1038,1069,1044,1071,1025,1038,1045,0,16,35,1025,1031,1,16,1071,1045,1045,1071,1025,1,4,32,5,1037,1045,33,0,1044,1]

def active10834 : List Nat := [0,1,2,3,4,9]

def tree10834 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood10834 : H12WitnessSearch.Good tree10834 := H12GlobalWitnessIndex.good

theorem leafIdentity10834 : H12AffineFastState.composeSystem env10834 rootObs = leafEnv10834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env10834 rootObs == leafEnv10834) = true)

theorem terminalChecked10834 : H12PackedTerminal.terminalCheckFast leafEnv10834 active10834 tree10834 = true := by decide +kernel

def env10835 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,8192,1297,32768,33166,1344,43048,524288,32768,1345,41089,16,138,8329,64,2477,1297,1297,43396,1285,4294967296,256,4295533729,1345,136]

theorem envBound10835 : H12AffineFastState.Bounded env10835 := by
  intro p hp
  have h : env10835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10818_10835 : H12AffineEnvironment.transform 21 41089 env10818 = env10835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env10818 == env10835) = true)

theorem identity10835 : scanCanonicalize (H12AffineFastState.compose env10835 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 44174) := by decide +kernel

theorem selectedBound10835 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env10836 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,8192,1297,32768,33166,1344,43048,524288,32768,1345,41089,16,138,8329,64,2477,1297,1297,43396,1285,44174,256,526383,1345,136]

theorem envBound10836 : H12AffineFastState.Bounded env10836 := by
  intro p hp
  have h : env10836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10835_10836 : H12AffineEnvironment.transform 31 44174 env10835 = env10836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 44174 env10835 == env10836) = true)

theorem identity10836 : scanCanonicalize (H12AffineFastState.compose env10836 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 11738) := by decide +kernel

theorem selectedBound10836 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env10837 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,8192,1297,11738,11348,1344,1522,524288,11738,1345,3419,16,138,8329,64,2477,1297,1297,1118,1285,340,256,526383,1345,136]

theorem envBound10837 : H12AffineFastState.Bounded env10837 := by
  intro p hp
  have h : env10837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10836_10837 : H12AffineEnvironment.transform 14 11738 env10836 = env10837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 11738 env10836 == env10837) = true)

def env10838 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,2316,1297,1238,1368,1344,1522,524288,1238,1345,3419,16,138,2437,64,2477,1297,1297,1118,1285,340,256,526383,1345,136]

theorem envBound10838 : H12AffineFastState.Bounded env10838 := by
  intro p hp
  have h : env10838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10837_10838 : H12AffineEnvironment.transform 12 2316 env10837 = env10838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2316 env10837 == env10838) = true)

theorem identity10838 : scanCanonicalize (H12AffineFastState.compose env10838 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1290) := by decide +kernel

theorem selectedBound10838 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10839 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1290,1345,1030,1297,1238,1368,1344,1522,524288,1238,1345,81,16,138,1167,64,1191,1297,1297,1118,1285,340,256,525605,1345,136]

theorem envBound10839 : H12AffineFastState.Bounded env10839 := by
  intro p hp
  have h : env10839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10838_10839 : H12AffineEnvironment.transform 10 1290 env10838 = env10839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1290 env10838 == env10839) = true)

theorem identity10839 : scanCanonicalize (H12AffineFastState.compose env10839 (packedSelected [2,4,7] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound10839 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env10840 : List Nat := [2,4,8,16,32,64,128,85,137,1024,1119,1044,1030,1092,1238,1037,1045,1191,524288,1238,1044,81,16,138,1167,64,1191,1092,1092,1118,1104,1,85,525424,1044,136]

theorem envBound10840 : H12AffineFastState.Bounded env10840 := by
  intro p hp
  have h : env10840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10839_10840 : H12AffineEnvironment.transform 7 85 env10839 = env10840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env10839 == env10840) = true)

theorem identity10840 : scanCanonicalize (H12AffineFastState.compose env10840 (packedSelected [2,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound10840 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env10841 : List Nat := [2,4,8,16,32,17,128,4,137,1024,1038,1044,1030,1045,1159,1037,1045,1191,524288,1159,1044,0,16,138,1167,17,1191,1045,1045,1039,1025,1,4,525345,1044,136]

theorem envBound10841 : H12AffineFastState.Bounded env10841 := by
  intro p hp
  have h : env10841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10840_10841 : H12AffineEnvironment.transform 5 17 env10840 = env10841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10840 == env10841) = true)

theorem identity10841 : scanCanonicalize (H12AffineFastState.compose env10841 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound10841 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10842 : List Nat := [2,4,8,16,32,17,41,4,32,1024,1038,1044,1030,1045,1070,1037,1045,1038,524288,1070,1044,0,16,35,1062,17,1038,1045,1045,1039,1025,1,4,525345,1044,33]

theorem envBound10842 : H12AffineFastState.Bounded env10842 := by
  intro p hp
  have h : env10842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10841_10842 : H12AffineEnvironment.transform 6 41 env10841 = env10842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env10841 == env10842) = true)

def env10843 : List Nat := [2,4,8,16,32,17,41,4,32,1024,1038,1044,1030,1045,1070,1037,1045,1038,1024,1070,1044,0,16,35,1062,17,1038,1045,1045,1039,1025,1,4,33,1044,33]

theorem envBound10843 : H12AffineFastState.Bounded env10843 := by
  intro p hp
  have h : env10843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10842_10843 : H12AffineEnvironment.transform 18 1024 env10842 = env10843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env10842 == env10843) = true)

theorem identity10843 : scanCanonicalize (H12AffineFastState.compose env10843 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound10843 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10844 : List Nat := [2,4,8,16,0,17,9,4,0,1024,1038,1044,1030,1045,1038,1037,1045,1038,1024,1038,1044,0,16,3,1030,17,1038,1045,1045,1039,1025,1,4,1,1044,1]

theorem envBound10844 : H12AffineFastState.Bounded env10844 := by
  intro p hp
  have h : env10844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10843_10844 : H12AffineEnvironment.transform 4 0 env10843 = env10844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env10843 == env10844) = true)

def leafEnv10844 : List Nat := [2,4,8,16,0,17,9,4,0,1024,1038,1044,1030,1045,1038,1037,1045,1038,1024,1038,1044,0,16,3,1024,1030,1,17,1038,1045,1045,1039,1025,1,4,1,5,1037,1044,1,0,1044,1]

def active10844 : List Nat := [0,1,2,3,9]

def tree10844 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood10844 : H12WitnessSearch.Good tree10844 := H12GlobalWitnessIndex.good

theorem leafIdentity10844 : H12AffineFastState.composeSystem env10844 rootObs = leafEnv10844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env10844 rootObs == leafEnv10844) = true)

theorem terminalChecked10844 : H12PackedTerminal.terminalCheckFast leafEnv10844 active10844 tree10844 = true := by decide +kernel

def env10845 : List Nat := [2,4,8,16,32,17,41,4,32,1024,1038,1044,1030,1045,1070,1037,1045,1038,1025,1070,1044,0,16,35,1062,17,1038,1045,1045,1039,1025,1,4,32,1044,33]

theorem envBound10845 : H12AffineFastState.Bounded env10845 := by
  intro p hp
  have h : env10845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10842_10845 : H12AffineEnvironment.transform 18 1025 env10842 = env10845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env10842 == env10845) = true)

def leafEnv10845 : List Nat := [2,4,8,16,32,17,41,4,32,1024,1038,1044,1030,1045,1070,1037,1045,1038,1025,1070,1044,0,16,35,1025,1062,1,17,1038,1045,1045,1039,1025,1,4,32,5,1069,1044,33,0,1044,1]

def active10845 : List Nat := [0,1,2,3,4,9]

def tree10845 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood10845 : H12WitnessSearch.Good tree10845 := H12GlobalWitnessIndex.good

theorem leafIdentity10845 : H12AffineFastState.composeSystem env10845 rootObs = leafEnv10845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env10845 rootObs == leafEnv10845) = true)

theorem terminalChecked10845 : H12PackedTerminal.terminalCheckFast leafEnv10845 active10845 tree10845 = true := by decide +kernel

def env10846 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,2317,1297,1239,1369,1344,1522,524288,1239,1345,3419,16,138,2436,64,2477,1297,1297,1118,1285,340,256,526383,1345,136]

theorem envBound10846 : H12AffineFastState.Bounded env10846 := by
  intro p hp
  have h : env10846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10837_10846 : H12AffineEnvironment.transform 12 2317 env10837 = env10846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2317 env10837 == env10846) = true)

theorem identity10846 : scanCanonicalize (H12AffineFastState.compose env10846 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound10846 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10847 : List Nat := [2,4,8,16,32,64,128,84,137,1024,2048,1045,2137,1093,1239,1037,1044,1190,524288,1239,1045,3087,16,138,2256,64,2297,1093,1093,1118,1105,0,84,526383,1045,136]

theorem envBound10847 : H12AffineFastState.Bounded env10847 := by
  intro p hp
  have h : env10847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10846_10847 : H12AffineEnvironment.transform 7 84 env10846 = env10847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env10846 == env10847) = true)

theorem identity10847 : scanCanonicalize (H12AffineFastState.compose env10847 (packedSelected [2,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 1191) := by decide +kernel

theorem selectedBound10847 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env10848 : List Nat := [2,4,8,16,32,64,128,84,137,1024,1191,1045,1278,1093,1239,1037,1044,1190,524288,1239,1045,168,16,138,1143,64,1118,1093,1093,1118,1105,0,84,525448,1045,136]

theorem envBound10848 : H12AffineFastState.Bounded env10848 := by
  intro p hp
  have h : env10848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10847_10848 : H12AffineEnvironment.transform 10 1191 env10847 = env10848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1191 env10847 == env10848) = true)

theorem identity10848 : scanCanonicalize (H12AffineFastState.compose env10848 (packedSelected [2,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound10848 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env10849 : List Nat := [2,4,8,16,32,16,128,4,137,1024,1191,1045,1198,1045,1159,1037,1044,1190,524288,1159,1045,168,16,138,1063,16,1038,1045,1045,1038,1025,0,4,525448,1045,136]

theorem envBound10849 : H12AffineFastState.Bounded env10849 := by
  intro p hp
  have h : env10849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10848_10849 : H12AffineEnvironment.transform 5 16 env10848 = env10849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10848 == env10849) = true)

theorem identity10849 : scanCanonicalize (H12AffineFastState.compose env10849 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound10849 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10850 : List Nat := [2,4,8,16,1,16,128,4,137,1024,1158,1045,1167,1045,1159,1037,1044,1159,524288,1159,1045,137,16,138,1030,16,1038,1045,1045,1038,1025,0,4,525448,1045,136]

theorem envBound10850 : H12AffineFastState.Bounded env10850 := by
  intro p hp
  have h : env10850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10849_10850 : H12AffineEnvironment.transform 4 1 env10849 = env10850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env10849 == env10850) = true)

theorem identity10850 : scanCanonicalize (H12AffineFastState.compose env10850 (packedSelected [1,12] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound10850 : packedSelected [1,12] rootPS < 2^1333 := by decide +kernel

def env10851 : List Nat := [2,4,8,16,1,16,9,4,0,1024,1039,1045,1030,1045,1038,1037,1044,1038,524288,1038,1045,0,16,3,1030,16,1038,1045,1045,1038,1025,0,4,525313,1045,1]

theorem envBound10851 : H12AffineFastState.Bounded env10851 := by
  intro p hp
  have h : env10851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10850_10851 : H12AffineEnvironment.transform 6 9 env10850 = env10851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env10850 == env10851) = true)

def leafEnv10851 : List Nat := [2,4,8,16,1,16,9,4,0,1024,1039,1045,1030,1045,1038,1037,1044,1038,524288,1038,1045,0,16,3,524288,1030,1,16,1038,1045,1045,1038,1025,0,4,525313,5,1037,1045,1,0,1044,1]

def active10851 : List Nat := [0,1,2,3,9,18]

def tree10851 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood10851 : H12WitnessSearch.Good tree10851 := H12GlobalWitnessIndex.good

theorem leafIdentity10851 : H12AffineFastState.composeSystem env10851 rootObs = leafEnv10851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env10851 rootObs == leafEnv10851) = true)

theorem terminalChecked10851 : H12PackedTerminal.terminalCheckFast leafEnv10851 active10851 tree10851 = true := by decide +kernel

def env10852 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,524288,32768,4096,4194304,5456,16777216,8329,5377,21331969,4177,131153,1073741824,16876545,4294967296,256,4316464299,131073,513]

theorem envBound10852 : H12AffineFastState.Bounded env10852 := by
  intro p hp
  have h : env10852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10759_10852 : H12AffineEnvironment.transform 13 4177 env10759 = env10852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env10759 == env10852) = true)

theorem identity10852 : scanCanonicalize (H12AffineFastState.compose env10852 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(29+1) ^^^ 21629134) := by decide +kernel

theorem selectedBound10852 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env10853 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,524288,32768,4096,4194304,5456,16777216,8329,5377,21331969,4177,131153,21629134,16876545,4294967296,256,4316464299,131073,513]

theorem envBound10853 : H12AffineFastState.Bounded env10853 := by
  intro p hp
  have h : env10853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10852_10853 : H12AffineEnvironment.transform 29 21629134 env10852 = env10853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 21629134 env10852 == env10853) = true)

theorem identity10853 : scanCanonicalize (H12AffineFastState.compose env10853 (packedSelected [6,25] rootPS)) = affineNative (2^(23+1) ^^^ 230469) := by decide +kernel

theorem selectedBound10853 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env10854 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,524288,32768,4096,4194304,5456,230469,8329,5377,4588612,4177,131153,4820107,131140,4294967296,256,4299915502,131073,513]

theorem envBound10854 : H12AffineFastState.Bounded env10854 := by
  intro p hp
  have h : env10854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10853_10854 : H12AffineEnvironment.transform 23 230469 env10853 = env10854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 230469 env10853 == env10854) = true)

theorem identity10854 : scanCanonicalize (H12AffineFastState.compose env10854 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(18+1) ^^^ 1024) := by decide +kernel

theorem selectedBound10854 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env10855 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1024,32768,4096,4194304,5456,230469,8329,5377,4588612,4177,131153,4294795,131140,4294967296,256,4299392238,131073,513]

theorem envBound10855 : H12AffineFastState.Bounded env10855 := by
  intro p hp
  have h : env10855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10854_10855 : H12AffineEnvironment.transform 18 1024 env10854 = env10855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env10854 == env10855) = true)

theorem identity10855 : scanCanonicalize (H12AffineFastState.compose env10855 (packedSelected [13,21] rootPS)) = affineNative (2^(31+1) ^^^ 4329688) := by decide +kernel

theorem selectedBound10855 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env10856 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1024,32768,4096,4194304,5456,230469,8329,5377,4588612,4177,131153,4294795,131140,4329688,256,103478,131073,513]

theorem envBound10856 : H12AffineFastState.Bounded env10856 := by
  intro p hp
  have h : env10856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10855_10856 : H12AffineEnvironment.transform 31 4329688 env10855 = env10856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4329688 env10855 == env10856) = true)

def env10857 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,4096,4194304,17665,16777216,33554432,67108864,21352529,67130625,131152,1073741824,16876544,4294967296,257,4417151346,131073,33563272]

theorem envBound10857 : H12AffineFastState.Bounded env10857 := by
  intro p hp
  have h : env10857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10756_10857 : H12AffineEnvironment.transform 26 21352529 env10756 = env10857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21352529 env10756 == env10857) = true)

theorem identity10857 : scanCanonicalize (H12AffineFastState.compose env10857 (packedSelected [35] rootPS)) = affineNative (2^(25+1) ^^^ 17011013) := by decide +kernel

theorem selectedBound10857 : packedSelected [35] rootPS < 2^1333 := by decide +kernel

def env10858 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,4096,4194304,17665,16777216,33554432,17011013,21352529,17024068,131152,1073741824,16876544,4294967296,257,4333498423,131073,33563272]

theorem envBound10858 : H12AffineFastState.Bounded env10858 := by
  intro p hp
  have h : env10858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10857_10858 : H12AffineEnvironment.transform 25 17011013 env10857 = env10858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 17011013 env10857 == env10858) = true)

def env10859 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,4096,4194304,17665,16777216,33554432,17011013,21352529,17024068,131152,1073741824,16876544,4294967296,257,4332975159,131073,33563272]

theorem envBound10859 : H12AffineFastState.Bounded env10859 := by
  intro p hp
  have h : env10859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10858_10859 : H12AffineEnvironment.transform 18 1024 env10858 = env10859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env10858 == env10859) = true)

theorem identity10859 : scanCanonicalize (H12AffineFastState.compose env10859 (packedSelected [4,6,7,9,16,20,25,27] rootPS)) = affineNative (2^(29+1) ^^^ 21126302) := by decide +kernel

theorem selectedBound10859 : packedSelected [4,6,7,9,16,20,25,27] rootPS < 2^1333 := by decide +kernel

def env10860 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,4096,4194304,17665,16777216,33554432,17011013,21352529,17024068,131152,21126302,16876544,4294967296,257,4332975159,131073,33563272]

theorem envBound10860 : H12AffineFastState.Bounded env10860 := by
  intro p hp
  have h : env10860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10859_10860 : H12AffineEnvironment.transform 29 21126302 env10859 = env10860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 21126302 env10859 == env10860) = true)

def env10861 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4096,32768,65536,131072,262144,1024,32768,4096,4194304,5377,16777216,33554432,17011013,21332049,17011780,131152,21105822,16876544,4294967296,257,4332954679,131073,33563272]

theorem envBound10861 : H12AffineFastState.Bounded env10861 := by
  intro p hp
  have h : env10861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10860_10861 : H12AffineEnvironment.transform 13 4096 env10860 = env10861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env10860 == env10861) = true)

def env10862 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,131072,262144,1024,32768,4096,4194304,5377,16777216,33554432,17010965,21331969,17011732,131072,21105822,16876544,4294967296,257,4332954679,131073,33563272]

theorem envBound10862 : H12AffineFastState.Bounded env10862 := by
  intro p hp
  have h : env10862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10861_10862 : H12AffineEnvironment.transform 5 16 env10861 = env10862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10861 == env10862) = true)

theorem identity10862 : scanCanonicalize (H12AffineFastState.compose env10862 (packedSelected [13,17,21,33] rootPS)) = affineNative (2^(23+1) ^^^ 230421) := by decide +kernel

theorem selectedBound10862 : packedSelected [13,17,21,33] rootPS < 2^1333 := by decide +kernel

def env10863 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,131072,262144,1024,32768,4096,4194304,5377,230421,33554432,5376,4588564,4097,131072,4294795,131093,4294967296,257,4332954679,131073,33563272]

theorem envBound10863 : H12AffineFastState.Bounded env10863 := by
  intro p hp
  have h : env10863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10862_10863 : H12AffineEnvironment.transform 23 230421 env10862 = env10863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 230421 env10862 == env10863) = true)

theorem identity10863 : scanCanonicalize (H12AffineFastState.compose env10863 (packedSelected [1,3,17,21,24,28] rootPS)) = affineNative (2^(24+1) ^^^ 8329) := by decide +kernel

theorem selectedBound10863 : packedSelected [1,3,17,21,24,28] rootPS < 2^1333 := by decide +kernel

def env10864 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,131072,262144,1024,32768,4096,4194304,5377,230421,8329,5376,4588564,4097,131072,4294795,131093,4294967296,257,4299392190,131073,513]

theorem envBound10864 : H12AffineFastState.Bounded env10864 := by
  intro p hp
  have h : env10864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10863_10864 : H12AffineEnvironment.transform 24 8329 env10863 = env10864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8329 env10863 == env10864) = true)

theorem identity10864 : scanCanonicalize (H12AffineFastState.compose env10864 (packedSelected [13,21] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound10864 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env10865 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,13340,65536,131072,262144,1024,13340,4096,4194304,5377,208905,8329,5376,4588564,4097,131072,4275351,131093,4294967296,257,4299370658,131073,513]

theorem envBound10865 : H12AffineFastState.Bounded env10865 := by
  intro p hp
  have h : env10865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10864_10865 : H12AffineEnvironment.transform 14 13340 env10864 = env10865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env10864 == env10865) = true)

theorem identity10865 : scanCanonicalize (H12AffineFastState.compose env10865 (packedSelected [0,5,7,8,13,17,20] rootPS)) = affineNative (2^(16+1) ^^^ 1297) := by decide +kernel

theorem selectedBound10865 : packedSelected [0,5,7,8,13,17,20] rootPS < 2^1333 := by decide +kernel

def env10866 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,13340,65536,1297,262144,1024,13340,4096,4194304,5377,79128,8329,5376,4456709,4097,1297,4275351,1284,4294967296,257,4299240883,1296,513]

theorem envBound10866 : H12AffineFastState.Bounded env10866 := by
  intro p hp
  have h : env10866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10865_10866 : H12AffineEnvironment.transform 16 1297 env10865 = env10866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1297 env10865 == env10866) = true)

theorem identity10866 : scanCanonicalize (H12AffineFastState.compose env10866 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound10866 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env10867 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,8192,4096,13340,65536,1297,262144,1024,13340,4096,4194304,5377,79128,8329,5376,4456709,4097,1297,4275351,1284,4294967296,257,4299240883,1296,137]

theorem envBound10867 : H12AffineFastState.Bounded env10867 := by
  intro p hp
  have h : env10867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10866_10867 : H12AffineEnvironment.transform 8 136 env10866 = env10867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env10866 == env10867) = true)

theorem identity10867 : scanCanonicalize (H12AffineFastState.compose env10867 (packedSelected [1,6,8,12] rootPS)) = affineNative (2^(21+1) ^^^ 343174) := by decide +kernel

theorem selectedBound10867 : packedSelected [1,6,8,12] rootPS < 2^1333 := by decide +kernel

def env10868 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,8192,4096,13340,65536,1297,262144,1024,13340,4096,343174,5377,79128,8329,5376,81283,4097,1297,262161,1284,4294967296,257,4295231797,1296,137]

theorem envBound10868 : H12AffineFastState.Bounded env10868 := by
  intro p hp
  have h : env10868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10867_10868 : H12AffineEnvironment.transform 21 343174 env10867 = env10868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 343174 env10867 == env10868) = true)

theorem identity10868 : scanCanonicalize (H12AffineFastState.compose env10868 (packedSelected [6,8,13] rootPS)) = affineNative (2^(12+1) ^^^ 2333) := by decide +kernel

theorem selectedBound10868 : packedSelected [6,8,13] rootPS < 2^1333 := by decide +kernel

def env10869 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,2333,4096,7425,65536,1297,262144,1024,7425,4096,333211,5377,72709,2452,5376,70814,4097,1297,262161,1284,4294967296,257,4295231797,1296,137]

theorem envBound10869 : H12AffineFastState.Bounded env10869 := by
  intro p hp
  have h : env10869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10868_10869 : H12AffineEnvironment.transform 12 2333 env10868 = env10869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2333 env10868 == env10869) = true)

theorem identity10869 : scanCanonicalize (H12AffineFastState.compose env10869 (packedSelected [3,5,6,15] rootPS)) = affineNative (2^(17+1) ^^^ 65723) := by decide +kernel

theorem selectedBound10869 : packedSelected [3,5,6,15] rootPS < 2^1333 := by decide +kernel

def env10870 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,2333,4096,7425,65536,1297,65723,1024,7425,4096,5408,5377,72709,2452,5376,70814,4097,1297,65706,1284,4294967296,257,4295035278,1296,137]

theorem envBound10870 : H12AffineFastState.Bounded env10870 := by
  intro p hp
  have h : env10870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10869_10870 : H12AffineEnvironment.transform 17 65723 env10869 = env10870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65723 env10869 == env10870) = true)

theorem identity10870 : scanCanonicalize (H12AffineFastState.compose env10870 (packedSelected [3,6] rootPS)) = affineNative (2^(15+1) ^^^ 2219) := by decide +kernel

theorem selectedBound10870 : packedSelected [3,6] rootPS < 2^1333 := by decide +kernel

def env10871 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,2333,4096,7425,2219,1297,2064,1024,7425,4096,5408,5377,5294,2452,5376,7221,4097,1297,2049,1284,4294967296,257,4294967589,1296,137]

theorem envBound10871 : H12AffineFastState.Bounded env10871 := by
  intro p hp
  have h : env10871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10870_10871 : H12AffineEnvironment.transform 15 2219 env10870 = env10871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2219 env10870 == env10871) = true)

theorem identity10871 : scanCanonicalize (H12AffineFastState.compose env10871 (packedSelected [0,2,3,9] rootPS)) = affineNative (2^(11+1) ^^^ 1061) := by decide +kernel

theorem selectedBound10871 : packedSelected [0,2,3,9] rootPS < 2^1333 := by decide +kernel

def env10872 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,1061,2333,1061,2340,2219,1297,2064,1024,2340,1061,261,292,139,2452,293,2064,1060,1297,2049,1284,4294967296,257,4294967589,1296,137]

theorem envBound10872 : H12AffineFastState.Bounded env10872 := by
  intro p hp
  have h : env10872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10871_10872 : H12AffineEnvironment.transform 11 1061 env10871 = env10872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1061 env10871 == env10872) = true)

theorem identity10872 : scanCanonicalize (H12AffineFastState.compose env10872 (packedSelected [0,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound10872 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env10873 : List Nat := [2,4,8,16,32,16,128,36,136,1024,2048,1061,2105,1061,2048,2219,1077,2064,1024,2048,1061,33,0,139,2224,1,2064,1060,1077,2049,1056,4294967296,37,4294967297,1076,137]

theorem envBound10873 : H12AffineFastState.Bounded env10873 := by
  intro p hp
  have h : env10873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10872_10873 : H12AffineEnvironment.transform 7 36 env10872 = env10873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env10872 == env10873) = true)

def env10874 : List Nat := [2,4,8,0,32,0,128,36,136,1024,2048,1061,2089,1061,2048,2219,1061,2048,1024,2048,1061,33,0,139,2208,1,2048,1060,1061,2049,1056,4294967296,37,4294967297,1060,137]

theorem envBound10874 : H12AffineFastState.Bounded env10874 := by
  intro p hp
  have h : env10874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10873_10874 : H12AffineEnvironment.transform 3 0 env10873 = env10874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env10873 == env10874) = true)

theorem identity10874 : scanCanonicalize (H12AffineFastState.compose env10874 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 42) := by decide +kernel

theorem selectedBound10874 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10875 : List Nat := [2,4,8,0,32,0,128,36,136,1024,2048,1061,2089,1061,2048,2219,1061,2048,1024,2048,1061,33,0,139,2208,1,2048,1060,1061,2049,1056,42,37,43,1060,137]

theorem envBound10875 : H12AffineFastState.Bounded env10875 := by
  intro p hp
  have h : env10875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10874_10875 : H12AffineEnvironment.transform 31 42 env10874 = env10875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 42 env10874 == env10875) = true)

def leafEnv10875 : List Nat := [2,4,8,0,32,0,128,36,136,1024,2048,1061,2089,1061,2048,2219,1061,2048,1024,2048,1061,33,0,139,1056,2208,1,1,2048,1060,1061,2049,1056,42,37,43,5,2083,1060,137,0,1061,1]

def active10875 : List Nat := [0,1,2,4,6,9,10]

def tree10875 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood10875 : H12WitnessSearch.Good tree10875 := H12GlobalWitnessIndex.good

theorem leafIdentity10875 : H12AffineFastState.composeSystem env10875 rootObs = leafEnv10875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env10875 rootObs == leafEnv10875) = true)

theorem terminalChecked10875 : H12PackedTerminal.terminalCheckFast leafEnv10875 active10875 tree10875 = true := by decide +kernel

def env10876 : List Nat := [2,4,8,1,32,1,128,36,136,1024,2048,1061,2088,1061,2048,2219,1060,2049,1024,2048,1061,33,0,139,2209,1,2049,1060,1060,2049,1056,4294967296,37,4294967297,1061,137]

theorem envBound10876 : H12AffineFastState.Bounded env10876 := by
  intro p hp
  have h : env10876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10873_10876 : H12AffineEnvironment.transform 3 1 env10873 = env10876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env10873 == env10876) = true)

theorem identity10876 : scanCanonicalize (H12AffineFastState.compose env10876 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 163) := by decide +kernel

theorem selectedBound10876 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10877 : List Nat := [2,4,8,1,32,1,128,36,136,1024,2048,1061,2088,1061,2048,2219,1060,2049,1024,2048,1061,33,0,139,2209,1,2049,1060,1060,2049,1056,163,37,162,1061,137]

theorem envBound10877 : H12AffineFastState.Bounded env10877 := by
  intro p hp
  have h : env10877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10876_10877 : H12AffineEnvironment.transform 31 163 env10876 = env10877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 163 env10876 == env10877) = true)

def leafEnv10877 : List Nat := [2,4,8,1,32,1,128,36,136,1024,2048,1061,2088,1061,2048,2219,1060,2049,1024,2048,1061,33,0,139,1056,2209,1,1,2049,1060,1060,2049,1056,163,37,162,5,2083,1061,137,0,1060,1]

def active10877 : List Nat := [0,1,2,4,6,9,10]

def tree10877 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood10877 : H12WitnessSearch.Good tree10877 := H12GlobalWitnessIndex.good

theorem leafIdentity10877 : H12AffineFastState.composeSystem env10877 rootObs = leafEnv10877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env10877 rootObs == leafEnv10877) = true)

theorem terminalChecked10877 : H12PackedTerminal.terminalCheckFast leafEnv10877 active10877 tree10877 = true := by decide +kernel

def env10878 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,65536,131072,262144,1024,32768,4096,4194304,5377,16777216,33554432,17010964,21331968,17011733,131073,21105822,16876544,4294967296,257,4332954679,131073,33563272]

theorem envBound10878 : H12AffineFastState.Bounded env10878 := by
  intro p hp
  have h : env10878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10861_10878 : H12AffineEnvironment.transform 5 17 env10861 = env10878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10861 == env10878) = true)

theorem identity10878 : scanCanonicalize (H12AffineFastState.compose env10878 (packedSelected [13,17,21,33] rootPS)) = affineNative (2^(24+1) ^^^ 17015964) := by decide +kernel

theorem selectedBound10878 : packedSelected [13,17,21,33] rootPS < 2^1333 := by decide +kernel

def env10879 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,65536,131072,262144,1024,32768,4096,4194304,5377,16777216,17015964,17010964,21331968,17011733,131073,21105822,16876544,4294967296,257,4315938987,131073,17008148]

theorem envBound10879 : H12AffineFastState.Bounded env10879 := by
  intro p hp
  have h : env10879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10878_10879 : H12AffineEnvironment.transform 24 17015964 env10878 = env10879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 17015964 env10878 == env10879) = true)

theorem identity10879 : scanCanonicalize (H12AffineFastState.compose env10879 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(23+1) ^^^ 230420) := by decide +kernel

theorem selectedBound10879 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env10880 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,65536,131072,262144,1024,32768,4096,4194304,5377,230420,8328,5376,4588564,4097,131073,4294794,131092,4294967296,257,4299392191,131073,512]

theorem envBound10880 : H12AffineFastState.Bounded env10880 := by
  intro p hp
  have h : env10880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10879_10880 : H12AffineEnvironment.transform 23 230420 env10879 = env10880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 230420 env10879 == env10880) = true)

theorem identity10880 : scanCanonicalize (H12AffineFastState.compose env10880 (packedSelected [4,9,16] rootPS)) = affineNative (2^(21+1) ^^^ 396) := by decide +kernel

theorem selectedBound10880 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env10881 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,65536,131072,262144,1024,32768,4096,396,5377,230420,8328,5376,394648,4097,131073,100614,131092,4294967296,257,4295198003,131073,512]

theorem envBound10881 : H12AffineFastState.Bounded env10881 := by
  intro p hp
  have h : env10881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10880_10881 : H12AffineEnvironment.transform 21 396 env10880 = env10881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 396 env10880 == env10881) = true)

theorem identity10881 : scanCanonicalize (H12AffineFastState.compose env10881 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 1297) := by decide +kernel

theorem selectedBound10881 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env10882 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,65536,1297,262144,1024,32768,4096,396,5377,98565,8328,5376,262281,4097,1296,100614,1285,4294967296,257,4295065634,1296,512]

theorem envBound10882 : H12AffineFastState.Bounded env10882 := by
  intro p hp
  have h : env10882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10881_10882 : H12AffineEnvironment.transform 16 1297 env10881 = env10882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1297 env10881 == env10882) = true)

theorem identity10882 : scanCanonicalize (H12AffineFastState.compose env10882 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 106538) := by decide +kernel

theorem selectedBound10882 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env10883 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,65536,1297,262144,1024,32768,4096,396,5377,98565,8328,5376,262281,4097,1296,100614,1285,106538,257,8200,1296,512]

theorem envBound10883 : H12AffineFastState.Bounded env10883 := by
  intro p hp
  have h : env10883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10882_10883 : H12AffineEnvironment.transform 31 106538 env10882 = env10883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 106538 env10882 == env10883) = true)

theorem identity10883 : scanCanonicalize (H12AffineFastState.compose env10883 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 37563) := by decide +kernel

theorem selectedBound10883 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env10884 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,37563,1297,262144,1024,32768,4096,396,5377,5054,8328,5376,262281,4097,1296,7101,1285,12945,257,8200,1296,512]

theorem envBound10884 : H12AffineFastState.Bounded env10884 := by
  intro p hp
  have h : env10884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10883_10884 : H12AffineEnvironment.transform 15 37563 env10883 = env10884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 37563 env10883 == env10884) = true)

theorem identity10884 : scanCanonicalize (H12AffineFastState.compose env10884 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound10884 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env10885 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,8461,13238,1297,262144,1024,8461,4096,396,5377,5054,8328,5376,262281,4097,1296,7101,1285,12945,257,8200,1296,512]

theorem envBound10885 : H12AffineFastState.Bounded env10885 := by
  intro p hp
  have h : env10885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10884_10885 : H12AffineEnvironment.transform 14 8461 env10884 = env10885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env10884 == env10885) = true)

theorem identity10885 : scanCanonicalize (H12AffineFastState.compose env10885 (packedSelected [1,8,12] rootPS)) = affineNative (2^(17+1) ^^^ 4927) := by decide +kernel

theorem selectedBound10885 : packedSelected [1,8,12] rootPS < 2^1333 := by decide +kernel

def env10886 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,8461,13238,1297,4927,1024,8461,4096,396,5377,5054,8328,5376,5046,4097,1296,7101,1285,12945,257,8200,1296,512]

theorem envBound10886 : H12AffineFastState.Bounded env10886 := by
  intro p hp
  have h : env10886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10885_10886 : H12AffineEnvironment.transform 17 4927 env10885 = env10886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4927 env10885 == env10886) = true)

theorem identity10886 : scanCanonicalize (H12AffineFastState.compose env10886 (packedSelected [0,7,20] rootPS)) = affineNative (2^(12+1) ^^^ 5400) := by decide +kernel

theorem selectedBound10886 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env10887 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,5400,4096,5141,1710,1297,4927,1024,5141,4096,396,5377,5054,5520,5376,5046,4097,1296,7101,1285,1929,257,5392,1296,512]

theorem envBound10887 : H12AffineFastState.Bounded env10887 := by
  intro p hp
  have h : env10887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10886_10887 : H12AffineEnvironment.transform 12 5400 env10886 = env10887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5400 env10886 == env10887) = true)

theorem identity10887 : scanCanonicalize (H12AffineFastState.compose env10887 (packedSelected [3,5,8,13,24] rootPS)) = affineNative (2^(11+1) ^^^ 1944) := by decide +kernel

theorem selectedBound10887 : packedSelected [3,5,8,13,24] rootPS < 2^1333 := by decide +kernel

def env10888 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1944,640,1944,909,1710,1297,1191,1024,909,1944,396,665,1062,520,664,1070,1945,1296,3109,1285,1929,257,648,1296,512]

theorem envBound10888 : H12AffineFastState.Bounded env10888 := by
  intro p hp
  have h : env10888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10887_10888 : H12AffineEnvironment.transform 11 1944 env10887 = env10888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1944 env10887 == env10888) = true)

theorem identity10888 : scanCanonicalize (H12AffineFastState.compose env10888 (packedSelected [8,13] rootPS)) = affineNative (2^(8+1) ^^^ 396) := by decide +kernel

theorem selectedBound10888 : packedSelected [8,13] rootPS < 2^1333 := by decide +kernel

def env10889 : List Nat := [2,4,8,16,32,17,128,256,396,1024,2048,1044,268,1044,1,1314,1297,1191,1024,1,1044,396,277,1062,388,276,1070,1045,1296,3109,1285,1029,257,260,1296,396]

theorem envBound10889 : H12AffineFastState.Bounded env10889 := by
  intro p hp
  have h : env10889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10888_10889 : H12AffineEnvironment.transform 8 396 env10888 = env10889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 396 env10888 == env10889) = true)

theorem identity10889 : scanCanonicalize (H12AffineFastState.compose env10889 (packedSelected [2,23,32] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound10889 : packedSelected [2,23,32] rootPS < 2^1333 := by decide +kernel

def env10890 : List Nat := [2,4,8,16,32,17,128,256,396,5,2048,17,268,17,1,295,276,162,5,1,17,396,277,35,388,276,43,16,277,2080,256,0,257,260,277,396]

theorem envBound10890 : H12AffineFastState.Bounded env10890 := by
  intro p hp
  have h : env10890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10889_10890 : H12AffineEnvironment.transform 9 5 env10889 = env10890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env10889 == env10890) = true)

def env10891 : List Nat := [2,4,8,16,32,17,128,256,396,5,0,17,268,17,1,295,276,162,5,1,17,396,277,35,388,276,43,16,277,32,256,0,257,260,277,396]

theorem envBound10891 : H12AffineFastState.Bounded env10891 := by
  intro p hp
  have h : env10891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10890_10891 : H12AffineEnvironment.transform 10 0 env10890 = env10891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env10890 == env10891) = true)

theorem identity10891 : scanCanonicalize (H12AffineFastState.compose env10891 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 191) := by decide +kernel

theorem selectedBound10891 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10892 : List Nat := [2,4,8,16,32,17,128,191,51,5,0,17,179,17,1,152,171,162,5,1,17,51,170,35,59,171,43,16,170,32,191,0,190,187,170,51]

theorem envBound10892 : H12AffineFastState.Bounded env10892 := by
  intro p hp
  have h : env10892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10891_10892 : H12AffineEnvironment.transform 7 191 env10891 = env10892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 191 env10891 == env10892) = true)

theorem identity10892 : scanCanonicalize (H12AffineFastState.compose env10892 (packedSelected [7,11] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound10892 : packedSelected [7,11] rootPS < 2^1333 := by decide +kernel

def env10893 : List Nat := [2,4,8,16,10,17,128,149,25,5,0,17,153,17,1,152,129,136,5,1,17,25,128,9,17,129,1,16,128,10,149,0,148,145,128,25]

theorem envBound10893 : H12AffineFastState.Bounded env10893 := by
  intro p hp
  have h : env10893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10892_10893 : H12AffineEnvironment.transform 4 10 env10892 = env10893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env10892 == env10893) = true)

theorem identity10893 : scanCanonicalize (H12AffineFastState.compose env10893 (packedSelected [7] rootPS)) = affineNative (2^(6+1) ^^^ 17) := by decide +kernel

theorem selectedBound10893 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env10894 : List Nat := [2,4,8,16,10,17,17,4,25,5,0,17,8,17,1,9,16,25,5,1,17,25,17,9,17,16,1,16,17,10,4,0,5,0,17,25]

theorem envBound10894 : H12AffineFastState.Bounded env10894 := by
  intro p hp
  have h : env10894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10893_10894 : H12AffineEnvironment.transform 6 17 env10893 = env10894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 17 env10893 == env10894) = true)

theorem identity10894 : scanCanonicalize (H12AffineFastState.compose env10894 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound10894 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10895 : List Nat := [2,4,8,2,10,3,3,4,11,5,0,3,8,3,1,9,2,11,5,1,3,11,3,9,3,2,1,2,3,10,4,0,5,0,3,11]

theorem envBound10895 : H12AffineFastState.Bounded env10895 := by
  intro p hp
  have h : env10895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10894_10895 : H12AffineEnvironment.transform 3 2 env10894 = env10895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env10894 == env10895) = true)

theorem identity10895 : scanCanonicalize (H12AffineFastState.compose env10895 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound10895 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10896 : List Nat := [2,4,2,2,0,3,3,4,1,5,0,3,2,3,1,3,2,1,5,1,3,1,3,3,3,2,1,2,3,0,4,0,5,0,3,1]

theorem envBound10896 : H12AffineFastState.Bounded env10896 := by
  intro p hp
  have h : env10896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10895_10896 : H12AffineEnvironment.transform 2 2 env10895 = env10896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env10895 == env10896) = true)

def leafEnv10896 : List Nat := [2,4,2,2,0,3,3,4,1,5,0,3,2,3,1,3,2,1,5,1,3,1,3,3,4,3,1,2,1,2,3,0,4,0,5,0,5,2,3,1,0,3,1]

def active10896 : List Nat := [0,1]

def tree10896 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood10896 : H12WitnessSearch.Good tree10896 := H12GlobalWitnessIndex.good

theorem leafIdentity10896 : H12AffineFastState.composeSystem env10896 rootObs = leafEnv10896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env10896 rootObs == leafEnv10896) = true)

theorem terminalChecked10896 : H12PackedTerminal.terminalCheckFast leafEnv10896 active10896 tree10896 = true := by decide +kernel

def env10897 : List Nat := [2,4,8,16,32,17,128,256,396,5,1,17,268,17,1,295,276,162,5,1,17,396,277,35,388,276,43,16,277,33,256,0,257,260,277,396]

theorem envBound10897 : H12AffineFastState.Bounded env10897 := by
  intro p hp
  have h : env10897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10890_10897 : H12AffineEnvironment.transform 10 1 env10890 = env10897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env10890 == env10897) = true)

theorem identity10897 : scanCanonicalize (H12AffineFastState.compose env10897 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 158) := by decide +kernel

theorem selectedBound10897 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10898 : List Nat := [2,4,8,16,32,17,128,158,18,5,1,17,146,17,1,185,138,162,5,1,17,18,139,35,26,138,43,16,139,33,158,0,159,154,139,18]

theorem envBound10898 : H12AffineFastState.Bounded env10898 := by
  intro p hp
  have h : env10898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10897_10898 : H12AffineEnvironment.transform 7 158 env10897 = env10898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 158 env10897 == env10898) = true)

theorem identity10898 : scanCanonicalize (H12AffineFastState.compose env10898 (packedSelected [7,11] rootPS)) = affineNative (2^(6+1) ^^^ 49) := by decide +kernel

theorem selectedBound10898 : packedSelected [7,11] rootPS < 2^1333 := by decide +kernel

def env10899 : List Nat := [2,4,8,16,32,17,49,47,18,5,1,17,35,17,1,8,59,19,5,1,17,18,58,35,26,59,43,16,58,33,47,0,46,43,58,18]

theorem envBound10899 : H12AffineFastState.Bounded env10899 := by
  intro p hp
  have h : env10899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10898_10899 : H12AffineEnvironment.transform 6 49 env10898 = env10899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 49 env10898 == env10899) = true)

theorem identity10899 : scanCanonicalize (H12AffineFastState.compose env10899 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound10899 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env10900 : List Nat := [2,4,8,16,10,17,27,5,18,5,1,17,9,17,1,8,17,19,5,1,17,18,16,9,26,17,1,16,16,11,5,0,4,1,16,18]

theorem envBound10900 : H12AffineFastState.Bounded env10900 := by
  intro p hp
  have h : env10900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10899_10900 : H12AffineEnvironment.transform 4 10 env10899 = env10900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env10899 == env10900) = true)

theorem identity10900 : scanCanonicalize (H12AffineFastState.compose env10900 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound10900 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10901 : List Nat := [2,4,2,16,0,17,17,5,18,5,1,17,3,17,1,2,17,19,5,1,17,18,16,3,16,17,1,16,16,1,5,0,4,1,16,18]

theorem envBound10901 : H12AffineFastState.Bounded env10901 := by
  intro p hp
  have h : env10901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10900_10901 : H12AffineEnvironment.transform 2 2 env10900 = env10901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env10900 == env10901) = true)

theorem identity10901 : scanCanonicalize (H12AffineFastState.compose env10901 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound10901 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env10902 : List Nat := [2,4,2,2,0,3,3,5,0,5,1,3,3,3,1,2,3,1,5,1,3,0,2,3,2,3,1,2,2,1,5,0,4,1,2,0]

theorem envBound10902 : H12AffineFastState.Bounded env10902 := by
  intro p hp
  have h : env10902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10901_10902 : H12AffineEnvironment.transform 3 2 env10901 = env10902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env10901 == env10902) = true)

def leafEnv10902 : List Nat := [2,4,2,2,0,3,3,5,0,5,1,3,3,3,1,2,3,1,5,1,3,0,2,3,5,2,1,3,1,2,2,1,5,0,4,1,5,3,2,0,0,2,1]

def active10902 : List Nat := [0,1]

def tree10902 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood10902 : H12WitnessSearch.Good tree10902 := H12GlobalWitnessIndex.good

theorem leafIdentity10902 : H12AffineFastState.composeSystem env10902 rootObs = leafEnv10902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env10902 rootObs == leafEnv10902) = true)

theorem terminalChecked10902 : H12PackedTerminal.terminalCheckFast leafEnv10902 active10902 tree10902 = true := by decide +kernel

def env10903 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4097,32768,65536,131072,262144,1024,32768,4096,4194304,5376,16777216,33554432,17011013,21332048,17011781,131152,21105823,16876544,4294967296,257,4332954678,131073,33563272]

theorem envBound10903 : H12AffineFastState.Bounded env10903 := by
  intro p hp
  have h : env10903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10860_10903 : H12AffineEnvironment.transform 13 4097 env10860 = env10903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4097 env10860 == env10903) = true)

def env10904 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,131072,262144,1024,32768,4096,4194304,5376,16777216,33554432,17010965,21331968,17011733,131072,21105823,16876544,4294967296,257,4332954678,131073,33563272]

theorem envBound10904 : H12AffineFastState.Bounded env10904 := by
  intro p hp
  have h : env10904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10903_10904 : H12AffineEnvironment.transform 5 16 env10903 = env10904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10903 == env10904) = true)

theorem identity10904 : scanCanonicalize (H12AffineFastState.compose env10904 (packedSelected [13,17,21,33] rootPS)) = affineNative (2^(24+1) ^^^ 17015965) := by decide +kernel

theorem selectedBound10904 : packedSelected [13,17,21,33] rootPS < 2^1333 := by decide +kernel

def env10905 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,131072,262144,1024,32768,4096,4194304,5376,16777216,17015965,17010965,21331968,17011733,131072,21105823,16876544,4294967296,257,4315938987,131073,17008149]

theorem envBound10905 : H12AffineFastState.Bounded env10905 := by
  intro p hp
  have h : env10905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10904_10905 : H12AffineEnvironment.transform 24 17015965 env10904 = env10905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 17015965 env10904 == env10905) = true)

theorem identity10905 : scanCanonicalize (H12AffineFastState.compose env10905 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(23+1) ^^^ 230421) := by decide +kernel

theorem selectedBound10905 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env10906 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,131072,262144,1024,32768,4096,4194304,5376,230421,8328,5376,4588565,4096,131072,4294794,131093,4294967296,257,4299392190,131073,512]

theorem envBound10906 : H12AffineFastState.Bounded env10906 := by
  intro p hp
  have h : env10906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10905_10906 : H12AffineEnvironment.transform 23 230421 env10905 = env10906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 230421 env10905 == env10906) = true)

theorem identity10906 : scanCanonicalize (H12AffineFastState.compose env10906 (packedSelected [4,9,16] rootPS)) = affineNative (2^(21+1) ^^^ 396) := by decide +kernel

theorem selectedBound10906 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env10907 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,131072,262144,1024,32768,4096,396,5376,230421,8328,5376,394649,4096,131072,100614,131093,4294967296,257,4295198002,131073,512]

theorem envBound10907 : H12AffineFastState.Bounded env10907 := by
  intro p hp
  have h : env10907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10906_10907 : H12AffineEnvironment.transform 21 396 env10906 = env10907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 396 env10906 == env10907) = true)

theorem identity10907 : scanCanonicalize (H12AffineFastState.compose env10907 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 1296) := by decide +kernel

theorem selectedBound10907 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env10908 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,1296,262144,1024,32768,4096,396,5376,98565,8328,5376,262281,4096,1296,100614,1285,4294967296,257,4295065634,1297,512]

theorem envBound10908 : H12AffineFastState.Bounded env10908 := by
  intro p hp
  have h : env10908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10907_10908 : H12AffineEnvironment.transform 16 1296 env10907 = env10908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1296 env10907 == env10908) = true)

theorem identity10908 : scanCanonicalize (H12AffineFastState.compose env10908 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 106539) := by decide +kernel

theorem selectedBound10908 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env10909 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,1296,262144,1024,32768,4096,396,5376,98565,8328,5376,262281,4096,1296,100614,1285,106539,257,8201,1297,512]

theorem envBound10909 : H12AffineFastState.Bounded env10909 := by
  intro p hp
  have h : env10909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10908_10909 : H12AffineEnvironment.transform 31 106539 env10908 = env10909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 106539 env10908 == env10909) = true)

theorem identity10909 : scanCanonicalize (H12AffineFastState.compose env10909 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 37562) := by decide +kernel

theorem selectedBound10909 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env10910 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,37562,1296,262144,1024,32768,4096,396,5376,5055,8328,5376,262281,4096,1296,7100,1285,12945,257,8201,1297,512]

theorem envBound10910 : H12AffineFastState.Bounded env10910 := by
  intro p hp
  have h : env10910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10909_10910 : H12AffineEnvironment.transform 15 37562 env10909 = env10910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 37562 env10909 == env10910) = true)

theorem identity10910 : scanCanonicalize (H12AffineFastState.compose env10910 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound10910 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env10911 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,8461,13239,1296,262144,1024,8461,4096,396,5376,5055,8328,5376,262281,4096,1296,7100,1285,12945,257,8201,1297,512]

theorem envBound10911 : H12AffineFastState.Bounded env10911 := by
  intro p hp
  have h : env10911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10910_10911 : H12AffineEnvironment.transform 14 8461 env10910 = env10911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env10910 == env10911) = true)

theorem identity10911 : scanCanonicalize (H12AffineFastState.compose env10911 (packedSelected [1,8,12] rootPS)) = affineNative (2^(17+1) ^^^ 4927) := by decide +kernel

theorem selectedBound10911 : packedSelected [1,8,12] rootPS < 2^1333 := by decide +kernel

def env10912 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,8461,13239,1296,4927,1024,8461,4096,396,5376,5055,8328,5376,5046,4096,1296,7100,1285,12945,257,8201,1297,512]

theorem envBound10912 : H12AffineFastState.Bounded env10912 := by
  intro p hp
  have h : env10912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10911_10912 : H12AffineEnvironment.transform 17 4927 env10911 = env10912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4927 env10911 == env10912) = true)

theorem identity10912 : scanCanonicalize (H12AffineFastState.compose env10912 (packedSelected [0,7,20] rootPS)) = affineNative (2^(12+1) ^^^ 5400) := by decide +kernel

theorem selectedBound10912 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env10913 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5400,4097,5141,1711,1296,4927,1024,5141,4096,396,5376,5055,5520,5376,5046,4096,1296,7100,1285,1929,257,5393,1297,512]

theorem envBound10913 : H12AffineFastState.Bounded env10913 := by
  intro p hp
  have h : env10913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10912_10913 : H12AffineEnvironment.transform 12 5400 env10912 = env10913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5400 env10912 == env10913) = true)

theorem identity10913 : scanCanonicalize (H12AffineFastState.compose env10913 (packedSelected [3,5,8,13,24] rootPS)) = affineNative (2^(11+1) ^^^ 1945) := by decide +kernel

theorem selectedBound10913 : packedSelected [3,5,8,13,24] rootPS < 2^1333 := by decide +kernel

def env10914 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1945,641,1944,908,1711,1296,1190,1024,908,1945,396,665,1062,521,665,1071,1945,1296,3109,1285,1929,257,648,1297,512]

theorem envBound10914 : H12AffineFastState.Bounded env10914 := by
  intro p hp
  have h : env10914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10913_10914 : H12AffineEnvironment.transform 11 1945 env10913 = env10914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1945 env10913 == env10914) = true)

theorem identity10914 : scanCanonicalize (H12AffineFastState.compose env10914 (packedSelected [8,13] rootPS)) = affineNative (2^(8+1) ^^^ 396) := by decide +kernel

theorem selectedBound10914 : packedSelected [8,13] rootPS < 2^1333 := by decide +kernel

def env10915 : List Nat := [2,4,8,16,32,16,128,256,396,1024,2048,1045,269,1044,0,1315,1296,1190,1024,0,1045,396,277,1062,389,277,1071,1045,1296,3109,1285,1029,257,260,1297,396]

theorem envBound10915 : H12AffineFastState.Bounded env10915 := by
  intro p hp
  have h : env10915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10914_10915 : H12AffineEnvironment.transform 8 396 env10914 = env10915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 396 env10914 == env10915) = true)

theorem identity10915 : scanCanonicalize (H12AffineFastState.compose env10915 (packedSelected [2,23,32] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound10915 : packedSelected [2,23,32] rootPS < 2^1333 := by decide +kernel

def env10916 : List Nat := [2,4,8,16,32,16,128,256,396,256,2048,277,269,276,0,35,16,422,256,0,277,396,277,294,389,277,303,277,16,2341,5,261,257,260,17,396]

theorem envBound10916 : H12AffineFastState.Bounded env10916 := by
  intro p hp
  have h : env10916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10915_10916 : H12AffineEnvironment.transform 9 256 env10915 = env10916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env10915 == env10916) = true)

theorem identity10916 : scanCanonicalize (H12AffineFastState.compose env10916 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound10916 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10917 : List Nat := [2,4,8,16,32,16,9,256,261,256,2048,277,269,276,0,35,16,303,256,0,277,261,277,294,268,277,303,277,16,2341,5,261,257,260,17,261]

theorem envBound10917 : H12AffineFastState.Bounded env10917 := by
  intro p hp
  have h : env10917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10916_10917 : H12AffineEnvironment.transform 6 9 env10916 = env10917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env10916 == env10917) = true)

theorem identity10917 : scanCanonicalize (H12AffineFastState.compose env10917 (packedSelected [7] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound10917 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env10918 : List Nat := [2,4,8,8,32,8,9,256,261,256,2048,269,269,268,0,35,8,303,256,0,269,261,269,294,268,269,303,269,8,2341,5,261,257,260,9,261]

theorem envBound10918 : H12AffineFastState.Bounded env10918 := by
  intro p hp
  have h : env10918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10917_10918 : H12AffineEnvironment.transform 3 8 env10917 = env10918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env10917 == env10918) = true)

theorem identity10918 : scanCanonicalize (H12AffineFastState.compose env10918 (packedSelected [0,11] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound10918 : packedSelected [0,11] rootPS < 2^1333 := by decide +kernel

def env10919 : List Nat := [2,4,8,8,32,8,9,256,261,256,0,269,269,268,0,35,8,303,256,0,269,261,269,294,268,269,303,269,8,293,5,261,257,260,9,261]

theorem envBound10919 : H12AffineFastState.Bounded env10919 := by
  intro p hp
  have h : env10919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10918_10919 : H12AffineEnvironment.transform 10 0 env10918 = env10919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env10918 == env10919) = true)

theorem identity10919 : scanCanonicalize (H12AffineFastState.compose env10919 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 47) := by decide +kernel

theorem selectedBound10919 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10920 : List Nat := [2,4,8,8,32,8,9,47,42,47,0,34,34,35,0,35,8,0,47,0,34,42,34,9,35,34,0,34,8,10,5,42,46,43,9,42]

theorem envBound10920 : H12AffineFastState.Bounded env10920 := by
  intro p hp
  have h : env10920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10919_10920 : H12AffineEnvironment.transform 7 47 env10919 = env10920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 47 env10919 == env10920) = true)

theorem identity10920 : scanCanonicalize (H12AffineFastState.compose env10920 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound10920 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env10921 : List Nat := [2,4,2,2,32,2,3,37,32,37,0,34,34,35,0,35,2,0,37,0,34,32,34,3,35,34,0,34,2,0,5,32,36,33,3,32]

theorem envBound10921 : H12AffineFastState.Bounded env10921 := by
  intro p hp
  have h : env10921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10920_10921 : H12AffineEnvironment.transform 2 2 env10920 = env10921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env10920 == env10921) = true)

def leafEnv10921 : List Nat := [2,4,2,2,32,2,3,37,32,37,0,34,34,35,0,35,2,0,37,0,34,32,34,3,5,35,1,34,0,34,2,0,5,32,36,33,5,34,3,32,0,2,1]

def active10921 : List Nat := [0,1,4]

def tree10921 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood10921 : H12WitnessSearch.Good tree10921 := H12GlobalWitnessIndex.good

theorem leafIdentity10921 : H12AffineFastState.composeSystem env10921 rootObs = leafEnv10921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env10921 rootObs == leafEnv10921) = true)

theorem terminalChecked10921 : H12PackedTerminal.terminalCheckFast leafEnv10921 active10921 tree10921 = true := by decide +kernel

def env10922 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,65536,131072,262144,1024,32768,4096,4194304,5376,16777216,33554432,17010964,21331969,17011732,131073,21105823,16876544,4294967296,257,4332954678,131073,33563272]

theorem envBound10922 : H12AffineFastState.Bounded env10922 := by
  intro p hp
  have h : env10922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10903_10922 : H12AffineEnvironment.transform 5 17 env10903 = env10922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10903 == env10922) = true)

theorem identity10922 : scanCanonicalize (H12AffineFastState.compose env10922 (packedSelected [13,17,21,33] rootPS)) = affineNative (2^(23+1) ^^^ 230420) := by decide +kernel

theorem selectedBound10922 : packedSelected [13,17,21,33] rootPS < 2^1333 := by decide +kernel

def env10923 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,65536,131072,262144,1024,32768,4096,4194304,5376,230420,33554432,5376,4588565,4096,131073,4294795,131092,4294967296,257,4332954678,131073,33563272]

theorem envBound10923 : H12AffineFastState.Bounded env10923 := by
  intro p hp
  have h : env10923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10922_10923 : H12AffineEnvironment.transform 23 230420 env10922 = env10923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 230420 env10922 == env10923) = true)

theorem identity10923 : scanCanonicalize (H12AffineFastState.compose env10923 (packedSelected [1,3,17,21,24,28] rootPS)) = affineNative (2^(24+1) ^^^ 8329) := by decide +kernel

theorem selectedBound10923 : packedSelected [1,3,17,21,24,28] rootPS < 2^1333 := by decide +kernel

def env10924 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,65536,131072,262144,1024,32768,4096,4194304,5376,230420,8329,5376,4588565,4096,131073,4294795,131092,4294967296,257,4299392191,131073,513]

theorem envBound10924 : H12AffineFastState.Bounded env10924 := by
  intro p hp
  have h : env10924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10923_10924 : H12AffineEnvironment.transform 24 8329 env10923 = env10924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8329 env10923 == env10924) = true)

theorem identity10924 : scanCanonicalize (H12AffineFastState.compose env10924 (packedSelected [13,21] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound10924 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env10925 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,13340,65536,131072,262144,1024,13340,4096,4194304,5376,208904,8329,5376,4588565,4096,131073,4275351,131092,4294967296,257,4299370659,131073,513]

theorem envBound10925 : H12AffineFastState.Bounded env10925 := by
  intro p hp
  have h : env10925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10924_10925 : H12AffineEnvironment.transform 14 13340 env10924 = env10925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env10924 == env10925) = true)

theorem identity10925 : scanCanonicalize (H12AffineFastState.compose env10925 (packedSelected [0,5,7,8,13,17,20] rootPS)) = affineNative (2^(16+1) ^^^ 1296) := by decide +kernel

theorem selectedBound10925 : packedSelected [0,5,7,8,13,17,20] rootPS < 2^1333 := by decide +kernel

def env10926 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,13340,65536,1296,262144,1024,13340,4096,4194304,5376,79128,8329,5376,4456709,4096,1297,4275351,1284,4294967296,257,4299240883,1297,513]

theorem envBound10926 : H12AffineFastState.Bounded env10926 := by
  intro p hp
  have h : env10926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10925_10926 : H12AffineEnvironment.transform 16 1296 env10925 = env10926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1296 env10925 == env10926) = true)

theorem identity10926 : scanCanonicalize (H12AffineFastState.compose env10926 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound10926 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env10927 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,4096,8192,4097,13340,65536,1296,262144,1024,13340,4096,4194304,5376,79128,8329,5376,4456709,4096,1297,4275351,1284,4294967296,257,4299240883,1297,137]

theorem envBound10927 : H12AffineFastState.Bounded env10927 := by
  intro p hp
  have h : env10927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10926_10927 : H12AffineEnvironment.transform 8 136 env10926 = env10927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env10926 == env10927) = true)

theorem identity10927 : scanCanonicalize (H12AffineFastState.compose env10927 (packedSelected [1,6,8,12] rootPS)) = affineNative (2^(21+1) ^^^ 338326) := by decide +kernel

theorem selectedBound10927 : packedSelected [1,6,8,12] rootPS < 2^1333 := by decide +kernel

def env10928 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,4096,8192,4097,13340,65536,1296,262144,1024,13340,4096,338326,5376,79128,8329,5376,75923,4096,1297,267521,1284,4294967296,257,4295236645,1297,137]

theorem envBound10928 : H12AffineFastState.Bounded env10928 := by
  intro p hp
  have h : env10928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10927_10928 : H12AffineEnvironment.transform 21 338326 env10927 = env10928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 338326 env10927 == env10928) = true)

theorem identity10928 : scanCanonicalize (H12AffineFastState.compose env10928 (packedSelected [6,8,13] rootPS)) = affineNative (2^(12+1) ^^^ 7181) := by decide +kernel

theorem selectedBound10928 : packedSelected [6,8,13] rootPS < 2^1333 := by decide +kernel

def env10929 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,4096,7181,4097,2065,65536,1296,262144,1024,2065,4096,333211,5376,67861,7300,5376,70814,4096,1297,267521,1284,4294967296,257,4295236645,1297,137]

theorem envBound10929 : H12AffineFastState.Bounded env10929 := by
  intro p hp
  have h : env10929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10928_10929 : H12AffineEnvironment.transform 12 7181 env10928 = env10929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7181 env10928 == env10929) = true)

theorem identity10929 : scanCanonicalize (H12AffineFastState.compose env10929 (packedSelected [3,5,6,15] rootPS)) = affineNative (2^(17+1) ^^^ 71083) := by decide +kernel

theorem selectedBound10929 : packedSelected [3,5,6,15] rootPS < 2^1333 := by decide +kernel

def env10930 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,4096,7181,4097,2065,65536,1296,71083,1024,2065,4096,48,5376,67861,7300,5376,70814,4096,1297,65706,1284,4294967296,257,4295035278,1297,137]

theorem envBound10930 : H12AffineFastState.Bounded env10930 := by
  intro p hp
  have h : env10930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10929_10930 : H12AffineEnvironment.transform 17 71083 env10929 = env10930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 71083 env10929 == env10930) = true)

theorem identity10930 : scanCanonicalize (H12AffineFastState.compose env10930 (packedSelected [3,6] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound10930 : packedSelected [3,6] rootPS < 2^1333 := by decide +kernel

def env10931 : List Nat := [2,4,8,16,32,17,128,53,136,1024,2048,4096,7181,4097,2065,65536,1061,70814,1024,2065,4096,48,5173,67616,7300,5173,70814,4096,1060,65706,1073,4294967296,52,4295035067,1060,137]

theorem envBound10931 : H12AffineFastState.Bounded env10931 := by
  intro p hp
  have h : env10931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10930_10931 : H12AffineEnvironment.transform 7 53 env10930 = env10931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env10930 == env10931) = true)

theorem identity10931 : scanCanonicalize (H12AffineFastState.compose env10931 (packedSelected [0,2,3,9] rootPS)) = affineNative (2^(15+1) ^^^ 2219) := by decide +kernel

theorem selectedBound10931 : packedSelected [0,2,3,9] rootPS < 2^1333 := by decide +kernel

def env10932 : List Nat := [2,4,8,16,32,17,128,53,136,1024,2048,4096,7181,4097,2065,2219,1061,7221,1024,2065,4096,48,5173,139,7300,5173,7221,4096,1060,2049,1073,4294967296,52,4294967312,1060,137]

theorem envBound10932 : H12AffineFastState.Bounded env10932 := by
  intro p hp
  have h : env10932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10931_10932 : H12AffineEnvironment.transform 15 2219 env10931 = env10932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2219 env10931 == env10932) = true)

theorem identity10932 : scanCanonicalize (H12AffineFastState.compose env10932 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound10932 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env10933 : List Nat := [2,4,8,1,32,0,128,36,136,1024,2048,4096,7181,4097,2048,2219,1061,7204,1024,2048,4096,33,5156,139,7300,5156,7204,4096,1060,2049,1056,4294967296,37,4294967297,1060,137]

theorem envBound10933 : H12AffineFastState.Bounded env10933 := by
  intro p hp
  have h : env10933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10932_10933 : H12AffineEnvironment.transform 3 1 env10932 = env10933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env10932 == env10933) = true)

def env10934 : List Nat := [2,4,8,1,32,0,8,36,0,1024,2048,4096,7181,4097,2048,2083,1061,7204,1024,2048,4096,33,5156,3,7180,5156,7204,4096,1060,2049,1056,4294967296,37,4294967297,1060,1]

theorem envBound10934 : H12AffineFastState.Bounded env10934 := by
  intro p hp
  have h : env10934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10933_10934 : H12AffineEnvironment.transform 6 8 env10933 = env10934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env10933 == env10934) = true)

theorem identity10934 : scanCanonicalize (H12AffineFastState.compose env10934 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 5134) := by decide +kernel

theorem selectedBound10934 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10935 : List Nat := [2,4,8,1,32,0,8,36,0,1024,2048,4096,7181,4097,2048,2083,1061,7204,1024,2048,4096,33,5156,3,7180,5156,7204,4096,1060,2049,1056,5134,37,5135,1060,1]

theorem envBound10935 : H12AffineFastState.Bounded env10935 := by
  intro p hp
  have h : env10935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10934_10935 : H12AffineEnvironment.transform 31 5134 env10934 = env10935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 5134 env10934 == env10935) = true)

def leafEnv10935 : List Nat := [2,4,8,1,32,0,8,36,0,1024,2048,4096,7181,4097,2048,2083,1061,7204,1024,2048,4096,33,5156,3,1056,7180,1,5156,7204,4096,1060,2049,1056,5134,37,5135,5,2083,1060,1,0,1060,1]

def active10935 : List Nat := [0,1,2,4,9,10,11]

def tree10935 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood10935 : H12WitnessSearch.Good tree10935 := H12GlobalWitnessIndex.good

theorem leafIdentity10935 : H12AffineFastState.composeSystem env10935 rootObs = leafEnv10935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env10935 rootObs == leafEnv10935) = true)

theorem terminalChecked10935 : H12PackedTerminal.terminalCheckFast leafEnv10935 active10935 tree10935 = true := by decide +kernel

def env10936 : List Nat := [2,4,8,1,32,0,9,36,1,1024,2048,4096,7181,4097,2048,2082,1061,7204,1024,2048,4096,33,5156,2,7181,5156,7204,4096,1060,2049,1056,4294967296,37,4294967297,1060,0]

theorem envBound10936 : H12AffineFastState.Bounded env10936 := by
  intro p hp
  have h : env10936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10933_10936 : H12AffineEnvironment.transform 6 9 env10933 = env10936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env10933 == env10936) = true)

theorem identity10936 : scanCanonicalize (H12AffineFastState.compose env10936 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 42) := by decide +kernel

theorem selectedBound10936 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10937 : List Nat := [2,4,8,1,32,0,9,36,1,1024,2048,4096,7181,4097,2048,2082,1061,7204,1024,2048,4096,33,5156,2,7181,5156,7204,4096,1060,2049,1056,42,37,43,1060,0]

theorem envBound10937 : H12AffineFastState.Bounded env10937 := by
  intro p hp
  have h : env10937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10936_10937 : H12AffineEnvironment.transform 31 42 env10936 = env10937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 42 env10936 == env10937) = true)

def leafEnv10937 : List Nat := [2,4,8,1,32,0,9,36,1,1024,2048,4096,7181,4097,2048,2082,1061,7204,1024,2048,4096,33,5156,2,1056,7181,1,5156,7204,4096,1060,2049,1056,42,37,43,5,2083,1060,0,0,1060,1]

def active10937 : List Nat := [0,1,2,4,9,10,11]

def tree10937 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood10937 : H12WitnessSearch.Good tree10937 := H12GlobalWitnessIndex.good

theorem leafIdentity10937 : H12AffineFastState.composeSystem env10937 rootObs = leafEnv10937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env10937 rootObs == leafEnv10937) = true)

theorem terminalChecked10937 : H12PackedTerminal.terminalCheckFast leafEnv10937 active10937 tree10937 = true := by decide +kernel

def env10938 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,4096,4194304,17665,16777216,33554432,17011013,21352529,17024068,131152,1073741824,16876544,4294967296,257,4332975158,131073,33563272]

theorem envBound10938 : H12AffineFastState.Bounded env10938 := by
  intro p hp
  have h : env10938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10858_10938 : H12AffineEnvironment.transform 18 1025 env10858 = env10938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env10858 == env10938) = true)

theorem identity10938 : scanCanonicalize (H12AffineFastState.compose env10938 (packedSelected [4,6,7,9,16,20,25,27] rootPS)) = affineNative (2^(29+1) ^^^ 21105871) := by decide +kernel

theorem selectedBound10938 : packedSelected [4,6,7,9,16,20,25,27] rootPS < 2^1333 := by decide +kernel

def env10939 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,4096,4194304,17665,16777216,33554432,17011013,21352529,17024068,131152,21105871,16876544,4294967296,257,4332975158,131073,33563272]

theorem envBound10939 : H12AffineFastState.Bounded env10939 := by
  intro p hp
  have h : env10939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10938_10939 : H12AffineEnvironment.transform 29 21105871 env10938 = env10939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 21105871 env10938 == env10939) = true)

def env10940 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,4096,4194304,17665,16777216,33554432,17010965,21352449,17024020,131072,21105823,16876544,4294967296,257,4332975158,131073,33563272]

theorem envBound10940 : H12AffineFastState.Bounded env10940 := by
  intro p hp
  have h : env10940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10939_10940 : H12AffineEnvironment.transform 5 16 env10939 = env10940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10939 == env10940) = true)

def env10941 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,640,16384,32768,65536,131072,262144,1025,32768,4096,4194304,17665,16777216,33554432,17010965,21352449,17024020,131072,21105823,16876544,4294967296,257,4332967606,131073,33554440]

theorem envBound10941 : H12AffineFastState.Bounded env10941 := by
  intro p hp
  have h : env10941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10940_10941 : H12AffineEnvironment.transform 12 640 env10940 = env10941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 640 env10940 == env10941) = true)

def env10942 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,640,16384,32768,65536,4096,262144,1025,32768,4096,4194304,17665,16777216,33554432,16875797,21352449,16897044,4096,20978847,16876544,4294967296,257,4332832438,4097,33554440]

theorem envBound10942 : H12AffineFastState.Bounded env10942 := by
  intro p hp
  have h : env10942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10941_10942 : H12AffineEnvironment.transform 16 4096 env10941 = env10942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env10941 == env10942) = true)

theorem identity10942 : scanCanonicalize (H12AffineFastState.compose env10942 (packedSelected [1,3,5,8,9,10,19,22] rootPS)) = affineNative (2^(13+1) ^^^ 4744) := by decide +kernel

theorem selectedBound10942 : packedSelected [1,3,5,8,9,10,19,22] rootPS < 2^1333 := by decide +kernel

def env10943 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,640,4744,32768,65536,4096,262144,1025,32768,4096,4194304,6025,16777216,33554432,16875797,21332617,16877212,4096,20978847,16876544,4294967296,257,4332819518,4097,33554440]

theorem envBound10943 : H12AffineFastState.Bounded env10943 := by
  intro p hp
  have h : env10943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10942_10943 : H12AffineEnvironment.transform 13 4744 env10942 = env10943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4744 env10942 == env10943) = true)

def env10944 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,8,4096,32768,65536,4096,262144,1025,32768,4096,4194304,5377,16777216,33554432,16875797,21331969,16876564,4096,20978847,16876544,4294967296,257,4332819518,4097,33554440]

theorem envBound10944 : H12AffineFastState.Bounded env10944 := by
  intro p hp
  have h : env10944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10943_10944 : H12AffineEnvironment.transform 8 136 env10943 = env10944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env10943 == env10944) = true)

theorem identity10944 : scanCanonicalize (H12AffineFastState.compose env10944 (packedSelected [3,5,8,17,21,28] rootPS)) = affineNative (2^(23+1) ^^^ 138) := by decide +kernel

theorem selectedBound10944 : packedSelected [3,5,8,17,21,28] rootPS < 2^1333 := by decide +kernel

def env10945 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,8,4096,32768,65536,4096,262144,1025,32768,4096,4194304,5377,138,33554432,98719,4554891,99486,4096,4201493,99466,4294967296,257,4332819518,4097,33554440]

theorem envBound10945 : H12AffineFastState.Bounded env10945 := by
  intro p hp
  have h : env10945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10944_10945 : H12AffineEnvironment.transform 23 138 env10944 = env10945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 138 env10944 == env10945) = true)

theorem identity10945 : scanCanonicalize (H12AffineFastState.compose env10945 (packedSelected [1,5,6,8,10,17,19,21,24,25,26,31] rootPS)) = affineNative (2^(24+1) ^^^ 129) := by decide +kernel

theorem selectedBound10945 : packedSelected [1,5,6,8,10,17,19,21,24,25,26,31] rootPS < 2^1333 := by decide +kernel

def env10946 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,8,4096,32768,65536,4096,262144,1025,32768,4096,4194304,5377,138,129,98719,4554891,99486,4096,4201493,99466,4294967296,257,4299265215,4097,137]

theorem envBound10946 : H12AffineFastState.Bounded env10946 := by
  intro p hp
  have h : env10946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10945_10946 : H12AffineEnvironment.transform 24 129 env10945 = env10946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 129 env10945 == env10946) = true)

theorem identity10946 : scanCanonicalize (H12AffineFastState.compose env10946 (packedSelected [3,4,9,10,16,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 38047) := by decide +kernel

theorem selectedBound10946 : packedSelected [3,4,9,10,16,24,26] rootPS < 2^1333 := by decide +kernel

def env10947 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,8,4096,32768,38047,4096,262144,1025,32768,4096,4194304,5377,138,129,5376,4461588,4097,4096,4201493,4117,4294967296,257,4299161632,4097,137]

theorem envBound10947 : H12AffineFastState.Bounded env10947 := by
  intro p hp
  have h : env10947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10946_10947 : H12AffineEnvironment.transform 15 38047 env10946 = env10947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38047 env10946 == env10947) = true)

theorem identity10947 : scanCanonicalize (H12AffineFastState.compose env10947 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound10947 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env10948 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,1297,8,1297,32768,33166,1297,262144,1025,32768,1297,4194304,16,138,129,17,4456709,1296,1297,4196612,1284,4294967296,257,4299161632,1296,137]

theorem envBound10948 : H12AffineFastState.Bounded env10948 := by
  intro p hp
  have h : env10948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10947_10948 : H12AffineEnvironment.transform 11 1297 env10947 = env10948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env10947 == env10948) = true)

theorem identity10948 : scanCanonicalize (H12AffineFastState.compose env10948 (packedSelected [1,3] rootPS)) = affineNative (2^(14+1) ^^^ 2184) := by decide +kernel

theorem selectedBound10948 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env10949 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,1297,8,1297,2184,2310,1297,262144,1025,2184,1297,4194304,16,138,129,17,4456709,1296,1297,4196612,1284,4294967296,257,4299161632,1296,137]

theorem envBound10949 : H12AffineFastState.Bounded env10949 := by
  intro p hp
  have h : env10949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10948_10949 : H12AffineEnvironment.transform 14 2184 env10948 = env10949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2184 env10948 == env10949) = true)

theorem identity10949 : scanCanonicalize (H12AffineFastState.compose env10949 (packedSelected [5] rootPS)) = affineNative (2^(21+1) ^^^ 2080) := by decide +kernel

theorem selectedBound10949 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env10950 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,1297,8,1297,2184,2310,1297,262144,1025,2184,1297,2080,16,138,129,17,264485,1296,1297,292,1284,4294967296,257,4294969344,1296,137]

theorem envBound10950 : H12AffineFastState.Bounded env10950 := by
  intro p hp
  have h : env10950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10949_10950 : H12AffineEnvironment.transform 21 2080 env10949 = env10950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2080 env10949 == env10950) = true)

theorem identity10950 : scanCanonicalize (H12AffineFastState.compose env10950 (packedSelected [8] rootPS)) = affineNative (2^(17+1) ^^^ 169) := by decide +kernel

theorem selectedBound10950 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env10951 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,1297,8,1297,2184,2310,1297,169,1025,2184,1297,2080,16,138,129,17,2444,1296,1297,292,1284,4294967296,257,4294969344,1296,137]

theorem envBound10951 : H12AffineFastState.Bounded env10951 := by
  intro p hp
  have h : env10951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10950_10951 : H12AffineEnvironment.transform 17 169 env10950 = env10951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 169 env10950 == env10951) = true)

theorem identity10951 : scanCanonicalize (H12AffineFastState.compose env10951 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 136) := by decide +kernel

theorem selectedBound10951 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10952 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,1297,8,1297,2184,2310,1297,169,1025,2184,1297,2080,16,138,129,17,2444,1296,1297,292,1284,136,257,2184,1296,137]

theorem envBound10952 : H12AffineFastState.Bounded env10952 := by
  intro p hp
  have h : env10952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10951_10952 : H12AffineEnvironment.transform 31 136 env10951 = env10952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 136 env10951 == env10952) = true)

theorem identity10952 : scanCanonicalize (H12AffineFastState.compose env10952 (packedSelected [10] rootPS)) = affineNative (2^(10+1) ^^^ 429) := by decide +kernel

theorem selectedBound10952 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env10953 : List Nat := [2,4,8,16,32,16,128,256,136,1024,429,1297,8,1297,293,171,1297,169,1025,293,1297,397,16,138,129,17,33,1296,1297,292,1284,136,257,293,1296,137]

theorem envBound10953 : H12AffineFastState.Bounded env10953 := by
  intro p hp
  have h : env10953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10952_10953 : H12AffineEnvironment.transform 10 429 env10952 = env10953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 429 env10952 == env10953) = true)

theorem identity10953 : scanCanonicalize (H12AffineFastState.compose env10953 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 134) := by decide +kernel

theorem selectedBound10953 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env10954 : List Nat := [2,4,8,16,32,16,128,134,136,1024,43,1175,8,1175,163,171,1175,169,1025,163,1175,11,16,138,129,17,33,1174,1175,162,1154,136,135,163,1174,137]

theorem envBound10954 : H12AffineFastState.Bounded env10954 := by
  intro p hp
  have h : env10954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10953_10954 : H12AffineEnvironment.transform 7 134 env10953 = env10954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 134 env10953 == env10954) = true)

theorem identity10954 : scanCanonicalize (H12AffineFastState.compose env10954 (packedSelected [4,7] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound10954 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env10955 : List Nat := [2,4,8,16,26,16,128,134,136,1024,17,1175,8,1175,153,145,1175,147,1025,153,1175,11,16,138,129,17,27,1174,1175,152,1154,136,135,153,1174,137]

theorem envBound10955 : H12AffineFastState.Bounded env10955 := by
  intro p hp
  have h : env10955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10954_10955 : H12AffineEnvironment.transform 4 26 env10954 = env10955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env10954 == env10955) = true)

theorem identity10955 : scanCanonicalize (H12AffineFastState.compose env10955 (packedSelected [12] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound10955 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env10956 : List Nat := [2,4,8,16,26,16,8,14,0,1024,17,1055,8,1055,17,25,1055,27,1025,17,1055,11,16,2,9,17,27,1054,1055,16,1034,0,15,17,1054,1]

theorem envBound10956 : H12AffineFastState.Bounded env10956 := by
  intro p hp
  have h : env10956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10955_10956 : H12AffineEnvironment.transform 6 8 env10955 = env10956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env10955 == env10956) = true)

theorem identity10956 : scanCanonicalize (H12AffineFastState.compose env10956 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound10956 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10957 : List Nat := [2,4,8,0,10,0,8,14,0,1024,1,1039,8,1039,1,9,1039,11,1025,1,1039,11,0,2,9,1,11,1038,1039,0,1034,0,15,1,1038,1]

theorem envBound10957 : H12AffineFastState.Bounded env10957 := by
  intro p hp
  have h : env10957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10956_10957 : H12AffineEnvironment.transform 3 0 env10956 = env10957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env10956 == env10957) = true)

theorem identity10957 : scanCanonicalize (H12AffineFastState.compose env10957 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound10957 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env10958 : List Nat := [2,4,2,0,0,0,2,4,0,1024,1,1029,2,1029,1,3,1029,1,1025,1,1029,1,0,2,3,1,1,1028,1029,0,1024,0,5,1,1028,1]

theorem envBound10958 : H12AffineFastState.Bounded env10958 := by
  intro p hp
  have h : env10958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10957_10958 : H12AffineEnvironment.transform 2 2 env10957 = env10958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env10957 == env10958) = true)

def leafEnv10958 : List Nat := [2,4,2,0,0,0,2,4,0,1024,1,1029,2,1029,1,3,1029,1,1025,1,1029,1,0,2,1025,3,1,1,1,1028,1029,0,1024,0,5,1,5,2,1028,1,0,1029,1]

def active10958 : List Nat := [0,1,9]

def tree10958 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood10958 : H12WitnessSearch.Good tree10958 := H12GlobalWitnessIndex.good

theorem leafIdentity10958 : H12AffineFastState.composeSystem env10958 rootObs = leafEnv10958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env10958 rootObs == leafEnv10958) = true)

theorem terminalChecked10958 : H12PackedTerminal.terminalCheckFast leafEnv10958 active10958 tree10958 = true := by decide +kernel

def env10959 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,9,4097,32768,65536,4096,262144,1025,32768,4096,4194304,5376,16777216,33554432,16875797,21331968,16876565,4096,20978847,16876544,4294967296,257,4332819518,4097,33554440]

theorem envBound10959 : H12AffineFastState.Bounded env10959 := by
  intro p hp
  have h : env10959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10943_10959 : H12AffineEnvironment.transform 8 137 env10943 = env10959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env10943 == env10959) = true)

def env10960 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,9,4097,32768,65536,4096,262144,1025,32768,4096,65544,5376,16777216,33554432,16875797,17072136,16876565,4096,16850071,16876544,4294967296,257,4328559670,4097,33554440]

theorem envBound10960 : H12AffineFastState.Bounded env10960 := by
  intro p hp
  have h : env10960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10959_10960 : H12AffineEnvironment.transform 21 65544 env10959 = env10960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65544 env10959 == env10960) = true)

def env10961 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,9,1297,32768,65536,1296,262144,1025,32768,1296,65544,16,16777216,33554432,16875797,17072136,16876565,1296,16845191,16876544,4294967296,257,4328554790,1297,33554440]

theorem envBound10961 : H12AffineFastState.Bounded env10961 := by
  intro p hp
  have h : env10961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10960_10961 : H12AffineEnvironment.transform 11 1296 env10960 = env10961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env10960 == env10961) = true)

theorem identity10961 : scanCanonicalize (H12AffineFastState.compose env10961 (packedSelected [3,5,24] rootPS)) = affineNative (2^(24+1) ^^^ 327681) := by decide +kernel

theorem selectedBound10961 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env10962 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,9,1297,32768,65536,1296,262144,1025,32768,1296,65544,16,16777216,327681,16875797,17072136,16876565,1296,16845191,16876544,4294967296,257,4295328039,1297,327689]

theorem envBound10962 : H12AffineFastState.Bounded env10962 := by
  intro p hp
  have h : env10962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10961_10962 : H12AffineEnvironment.transform 24 327681 env10961 = env10962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 327681 env10961 == env10962) = true)

theorem identity10962 : scanCanonicalize (H12AffineFastState.compose env10962 (packedSelected [1,3,8,13,15,19] rootPS)) = affineNative (2^(14+1) ^^^ 261) := by decide +kernel

theorem selectedBound10962 : packedSelected [1,3,8,13,15,19] rootPS < 2^1333 := by decide +kernel

def env10963 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,9,1297,261,65536,1296,262144,1025,261,1296,65544,16,16777216,327681,16842768,17039629,16844048,1296,16845191,16844037,4294967296,257,4295295010,1297,327689]

theorem envBound10963 : H12AffineFastState.Bounded env10963 := by
  intro p hp
  have h : env10963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10962_10963 : H12AffineEnvironment.transform 14 261 env10962 = env10963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 261 env10962 == env10963) = true)

theorem identity10963 : scanCanonicalize (H12AffineFastState.compose env10963 (packedSelected [0,4,7,9,16,20] rootPS)) = affineNative (2^(23+1) ^^^ 65536) := by decide +kernel

theorem selectedBound10963 : packedSelected [0,4,7,9,16,20] rootPS < 2^1333 := by decide +kernel

def env10964 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,9,1297,261,65536,1296,262144,1025,261,1296,65544,16,65536,327681,16,327949,1296,1296,2439,1285,4294967296,257,4295295010,1297,327689]

theorem envBound10964 : H12AffineFastState.Bounded env10964 := by
  intro p hp
  have h : env10964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10963_10964 : H12AffineEnvironment.transform 23 65536 env10963 = env10964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 65536 env10963 == env10964) = true)

theorem identity10964 : scanCanonicalize (H12AffineFastState.compose env10964 (packedSelected [1,3,5] rootPS)) = affineNative (2^(17+1) ^^^ 65665) := by decide +kernel

theorem selectedBound10964 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env10965 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,9,1297,261,65536,1296,65665,1025,261,1296,65544,16,65536,128,16,396,1296,1296,2439,1285,4294967296,257,4294967459,1297,136]

theorem envBound10965 : H12AffineFastState.Bounded env10965 := by
  intro p hp
  have h : env10965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10964_10965 : H12AffineEnvironment.transform 17 65665 env10964 = env10965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env10964 == env10965) = true)

theorem identity10965 : scanCanonicalize (H12AffineFastState.compose env10965 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 162) := by decide +kernel

theorem selectedBound10965 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env10966 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,9,1297,261,65536,1296,65665,1025,261,1296,65544,16,65536,128,16,396,1296,1296,2439,1285,162,257,1,1297,136]

theorem envBound10966 : H12AffineFastState.Bounded env10966 := by
  intro p hp
  have h : env10966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10965_10966 : H12AffineEnvironment.transform 31 162 env10965 = env10966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 162 env10965 == env10966) = true)

theorem identity10966 : scanCanonicalize (H12AffineFastState.compose env10966 (packedSelected [1,10] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound10966 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env10967 : List Nat := [2,4,8,16,32,16,34,256,43,1024,2048,1296,9,1297,261,65536,1296,65571,1025,261,1296,65544,16,65536,34,16,302,1296,1296,2341,1285,0,257,1,1297,42]

theorem envBound10967 : H12AffineFastState.Bounded env10967 := by
  intro p hp
  have h : env10967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10966_10967 : H12AffineEnvironment.transform 6 34 env10966 = env10967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env10966 == env10967) = true)

end H12CloudChart2