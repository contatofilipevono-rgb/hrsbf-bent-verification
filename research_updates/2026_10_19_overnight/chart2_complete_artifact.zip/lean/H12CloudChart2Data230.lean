import H12CloudChart2Data229

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans58057_58058 : H12AffineEnvironment.transform 10 137 env58057 = env58058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env58057 == env58058) = true)

theorem identity58058 : scanCanonicalize (H12AffineFastState.compose env58058 (packedSelected [3,10,11,13,18] rootPS)) = affineNative (2^(7+1) ^^^ 40) := by decide +kernel

theorem selectedBound58058 : packedSelected [3,10,11,13,18] rootPS < 2^1333 := by decide +kernel

def env58059 : List Nat := [2,4,8,16,32,1,128,40,48,56,137,29,36,1,17,62,12,190,52,16,29,185,12,62,160,16,6,29,0,149,40,13,40,45,17,61]

theorem envBound58059 : H12AffineFastState.Bounded env58059 := by
  intro p hp
  have h : env58059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58058_58059 : H12AffineEnvironment.transform 7 40 env58058 = env58059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 40 env58058 == env58059) = true)

theorem identity58059 : scanCanonicalize (H12AffineFastState.compose env58059 (packedSelected [2,10] rootPS)) = affineNative (2^(6+1) ^^^ 37) := by decide +kernel

theorem selectedBound58059 : packedSelected [2,10] rootPS < 2^1333 := by decide +kernel

def env58060 : List Nat := [2,4,8,16,32,1,37,40,48,56,44,29,36,1,17,62,12,27,52,16,29,28,12,62,5,16,6,29,0,48,40,13,40,45,17,61]

theorem envBound58060 : H12AffineFastState.Bounded env58060 := by
  intro p hp
  have h : env58060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58059_58060 : H12AffineEnvironment.transform 6 37 env58059 = env58060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 37 env58059 == env58060) = true)

theorem identity58060 : scanCanonicalize (H12AffineFastState.compose env58060 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound58060 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env58061 : List Nat := [2,4,8,16,11,1,14,3,27,19,7,29,15,1,17,21,12,27,31,16,29,28,12,21,5,16,6,29,0,27,3,13,3,6,17,22]

theorem envBound58061 : H12AffineFastState.Bounded env58061 := by
  intro p hp
  have h : env58061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58060_58061 : H12AffineEnvironment.transform 4 11 env58060 = env58061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env58060 == env58061) = true)

theorem identity58061 : scanCanonicalize (H12AffineFastState.compose env58061 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound58061 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env58062 : List Nat := [2,4,3,16,0,1,5,3,16,19,7,22,4,1,17,21,7,16,20,16,22,23,7,21,5,16,6,22,0,16,3,6,3,6,17,22]

theorem envBound58062 : H12AffineFastState.Bounded env58062 := by
  intro p hp
  have h : env58062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58061_58062 : H12AffineEnvironment.transform 2 3 env58061 = env58062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env58061 == env58062) = true)

theorem identity58062 : scanCanonicalize (H12AffineFastState.compose env58062 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound58062 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env58063 : List Nat := [2,4,3,6,0,1,5,3,6,5,7,0,4,1,7,3,7,6,2,6,0,1,7,3,5,6,6,0,0,6,3,6,3,6,7,0]

theorem envBound58063 : H12AffineFastState.Bounded env58063 := by
  intro p hp
  have h : env58063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58062_58063 : H12AffineEnvironment.transform 3 6 env58062 = env58063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env58062 == env58063) = true)

theorem identity58063 : scanCanonicalize (H12AffineFastState.compose env58063 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound58063 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env58064 : List Nat := [2,2,3,0,0,1,3,3,0,3,1,0,2,1,1,3,1,0,2,0,0,1,1,3,3,0,0,0,0,0,3,0,3,0,1,0]

theorem envBound58064 : H12AffineFastState.Bounded env58064 := by
  intro p hp
  have h : env58064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58063_58064 : H12AffineEnvironment.transform 1 2 env58063 = env58064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env58063 == env58064) = true)

def env58065 : List Nat := [2,4,8,16,32,1,128,256,281,272,2048,28,8192,1,8477,8498,12,8626,285,8476,28,400,12,8498,8325,17,302,29,0,2357,8204,13,256,8201,17,277]

theorem envBound58065 : H12AffineFastState.Bounded env58065 := by
  intro p hp
  have h : env58065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58055_58065 : H12AffineEnvironment.transform 8 281 env58055 = env58065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 281 env58055 == env58065) = true)

theorem identity58065 : scanCanonicalize (H12AffineFastState.compose env58065 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 257) := by decide +kernel

theorem selectedBound58065 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env58066 : List Nat := [2,4,8,16,32,1,128,256,281,272,2048,28,257,1,28,51,12,179,285,29,28,400,12,51,388,17,302,29,0,2357,269,13,256,264,17,277]

theorem envBound58066 : H12AffineFastState.Bounded env58066 := by
  intro p hp
  have h : env58066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58065_58066 : H12AffineEnvironment.transform 12 257 env58065 = env58066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 257 env58065 == env58066) = true)

theorem identity58066 : scanCanonicalize (H12AffineFastState.compose env58066 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound58066 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env58067 : List Nat := [2,4,8,13,32,1,128,256,260,269,2048,1,257,1,1,46,12,174,256,0,1,397,12,46,388,12,302,0,0,2344,269,13,256,264,12,264]

theorem envBound58067 : H12AffineFastState.Bounded env58067 := by
  intro p hp
  have h : env58067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58066_58067 : H12AffineEnvironment.transform 3 13 env58066 = env58067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env58066 == env58067) = true)

theorem identity58067 : scanCanonicalize (H12AffineFastState.compose env58067 (packedSelected [0,1,3,5,7,8,10,11,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound58067 : packedSelected [0,1,3,5,7,8,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env58068 : List Nat := [2,4,8,13,32,1,128,256,260,269,33,1,257,1,1,46,12,174,256,0,1,397,12,46,388,12,302,0,0,265,269,13,256,264,12,264]

theorem envBound58068 : H12AffineFastState.Bounded env58068 := by
  intro p hp
  have h : env58068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58067_58068 : H12AffineEnvironment.transform 10 33 env58067 = env58068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env58067 == env58068) = true)

theorem identity58068 : scanCanonicalize (H12AffineFastState.compose env58068 (packedSelected [3,5,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound58068 : packedSelected [3,5,8,10] rootPS < 2^1333 := by decide +kernel

def env58069 : List Nat := [2,4,8,13,32,1,128,36,32,41,33,1,37,1,1,46,12,174,36,0,1,169,12,46,160,12,10,0,0,45,41,13,36,44,12,44]

theorem envBound58069 : H12AffineFastState.Bounded env58069 := by
  intro p hp
  have h : env58069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58068_58069 : H12AffineEnvironment.transform 7 36 env58068 = env58069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env58068 == env58069) = true)

theorem identity58069 : scanCanonicalize (H12AffineFastState.compose env58069 (packedSelected [1,3,8] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound58069 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env58070 : List Nat := [2,4,2,7,32,1,128,36,32,35,33,1,37,1,1,36,6,164,36,0,1,163,6,36,160,6,0,0,0,39,35,7,36,38,6,38]

theorem envBound58070 : H12AffineFastState.Bounded env58070 := by
  intro p hp
  have h : env58070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58069_58070 : H12AffineEnvironment.transform 2 2 env58069 = env58070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env58069 == env58070) = true)

theorem identity58070 : scanCanonicalize (H12AffineFastState.compose env58070 (packedSelected [0,4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound58070 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env58071 : List Nat := [2,2,2,1,32,1,128,34,32,35,33,1,35,1,1,34,0,162,34,0,1,163,0,34,160,0,0,0,0,33,35,1,34,32,0,32]

theorem envBound58071 : H12AffineFastState.Bounded env58071 := by
  intro p hp
  have h : env58071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58070_58071 : H12AffineEnvironment.transform 1 2 env58070 = env58071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env58070 == env58071) = true)

theorem identity58071 : scanCanonicalize (H12AffineFastState.compose env58071 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound58071 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58072 : List Nat := [2,2,2,1,32,1,2,34,32,35,33,1,35,1,1,34,0,32,34,0,1,33,0,34,34,0,0,0,0,33,35,1,34,32,0,32]

theorem envBound58072 : H12AffineFastState.Bounded env58072 := by
  intro p hp
  have h : env58072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58071_58072 : H12AffineEnvironment.transform 6 2 env58071 = env58072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env58071 == env58072) = true)

def env58073 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74863,65665,4416,8541,4096,5276,74046,66897,13768,78895,1150,74815,1296,81226,8204,74799,256,8201,1344,5953]

theorem envBound58073 : H12AffineFastState.Bounded env58073 := by
  intro p hp
  have h : env58073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57988_58073 : H12AffineEnvironment.transform 17 65665 env57988 = env58073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env57988 == env58073) = true)

theorem identity58073 : scanCanonicalize (H12AffineFastState.compose env58073 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound58073 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58074 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1297,8540,65536,74863,65665,272,8541,80,1228,74046,66897,9624,74879,1150,74815,1296,77082,8204,74799,256,8201,1344,1809]

theorem envBound58074 : H12AffineFastState.Bounded env58074 := by
  intro p hp
  have h : env58074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58073_58074 : H12AffineEnvironment.transform 11 80 env58073 = env58074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env58073 == env58074) = true)

def env58075 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,80,8192,81,8540,65536,74031,65665,272,8541,80,396,74046,65553,8408,74047,318,74111,80,75866,8204,74095,256,8201,0,593]

theorem envBound58075 : H12AffineFastState.Bounded env58075 := by
  intro p hp
  have h : env58075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58074_58075 : H12AffineEnvironment.transform 9 320 env58074 = env58075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env58074 == env58075) = true)

theorem identity58075 : scanCanonicalize (H12AffineFastState.compose env58075 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound58075 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env58076 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,80,8192,81,8540,114,8541,243,272,8541,80,396,8524,99,8408,8525,318,8461,80,10280,8204,8477,256,8201,0,593]

theorem envBound58076 : H12AffineFastState.Bounded env58076 := by
  intro p hp
  have h : env58076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58075_58076 : H12AffineEnvironment.transform 15 114 env58075 = env58076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env58075 == env58076) = true)

def env58077 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,80,8192,80,8540,65536,74030,65665,272,8541,80,397,74046,65552,8409,74046,319,74110,81,75867,8204,74094,256,8201,1,592]

theorem envBound58077 : H12AffineFastState.Bounded env58077 := by
  intro p hp
  have h : env58077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58074_58077 : H12AffineEnvironment.transform 9 321 env58074 = env58077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env58074 == env58077) = true)

theorem identity58077 : scanCanonicalize (H12AffineFastState.compose env58077 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound58077 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env58078 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,80,8192,80,8540,34,8460,163,272,8541,80,397,8476,50,8409,8476,319,8540,81,10361,8204,8524,256,8201,1,592]

theorem envBound58078 : H12AffineFastState.Bounded env58078 := by
  intro p hp
  have h : env58078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58077_58078 : H12AffineEnvironment.transform 15 34 env58077 = env58078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env58077 == env58078) = true)

theorem identity58078 : scanCanonicalize (H12AffineFastState.compose env58078 (packedSelected [1,2,3,5,8,10,19,23,32] rootPS)) = affineNative (2^(8+1) ^^^ 461) := by decide +kernel

theorem selectedBound58078 : packedSelected [1,2,3,5,8,10,19,23,32] rootPS < 2^1333 := by decide +kernel

def env58079 : List Nat := [2,4,8,16,32,64,128,256,461,321,2048,80,8192,80,8540,34,8460,163,272,8541,80,397,8476,50,8409,8476,319,8540,81,10361,8204,8524,256,8201,1,413]

theorem envBound58079 : H12AffineFastState.Bounded env58079 := by
  intro p hp
  have h : env58079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58078_58079 : H12AffineEnvironment.transform 8 461 env58078 = env58079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 461 env58078 == env58079) = true)

theorem identity58079 : scanCanonicalize (H12AffineFastState.compose env58079 (packedSelected [1,2,3,4,5,8,9,10,11,13,16,18,19,24,28] rootPS)) = affineNative (2^(12+1) ^^^ 241) := by decide +kernel

theorem selectedBound58079 : packedSelected [1,2,3,4,5,8,9,10,11,13,16,18,19,24,28] rootPS < 2^1333 := by decide +kernel

def env58080 : List Nat := [2,4,8,16,32,64,128,256,461,321,2048,80,241,80,429,34,509,163,272,428,80,397,493,50,40,493,319,429,81,2184,253,445,256,248,1,413]

theorem envBound58080 : H12AffineFastState.Bounded env58080 := by
  intro p hp
  have h : env58080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58079_58080 : H12AffineEnvironment.transform 12 241 env58079 = env58080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 241 env58079 == env58080) = true)

theorem identity58080 : scanCanonicalize (H12AffineFastState.compose env58080 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 366) := by decide +kernel

theorem selectedBound58080 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env58081 : List Nat := [2,4,8,16,32,64,128,256,461,321,366,80,241,80,429,34,509,163,272,428,80,397,493,50,40,493,319,429,81,486,253,445,256,248,1,413]

theorem envBound58081 : H12AffineFastState.Bounded env58081 := by
  intro p hp
  have h : env58081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58080_58081 : H12AffineEnvironment.transform 10 366 env58080 = env58081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 366 env58080 == env58081) = true)

theorem identity58081 : scanCanonicalize (H12AffineFastState.compose env58081 (packedSelected [2,3,4,5,9,10,12,13] rootPS)) = affineNative (2^(7+1) ^^^ 110) := by decide +kernel

theorem selectedBound58081 : packedSelected [2,3,4,5,9,10,12,13] rootPS < 2^1333 := by decide +kernel

def env58082 : List Nat := [2,4,8,16,32,64,128,110,163,47,0,80,241,80,195,34,147,163,126,194,80,227,131,50,40,131,81,195,81,136,253,211,110,248,1,243]

theorem envBound58082 : H12AffineFastState.Bounded env58082 := by
  intro p hp
  have h : env58082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58081_58082 : H12AffineEnvironment.transform 7 110 env58081 = env58082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 110 env58081 == env58082) = true)

theorem identity58082 : scanCanonicalize (H12AffineFastState.compose env58082 (packedSelected [0,4,10] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound58082 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env58083 : List Nat := [2,4,8,16,32,64,56,110,27,47,0,80,73,80,123,34,43,27,126,122,80,91,59,50,40,59,81,123,81,48,69,107,110,64,1,75]

theorem envBound58083 : H12AffineFastState.Bounded env58083 := by
  intro p hp
  have h : env58083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58082_58083 : H12AffineEnvironment.transform 6 56 env58082 = env58083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env58082 == env58083) = true)

theorem identity58083 : scanCanonicalize (H12AffineFastState.compose env58083 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound58083 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env58084 : List Nat := [2,4,8,16,32,11,56,37,27,47,0,27,2,27,48,34,43,27,53,49,27,16,59,50,40,59,26,48,26,48,14,32,37,11,1,0]

theorem envBound58084 : H12AffineFastState.Bounded env58084 := by
  intro p hp
  have h : env58084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58083_58084 : H12AffineEnvironment.transform 5 11 env58083 = env58084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env58083 == env58084) = true)

theorem identity58084 : scanCanonicalize (H12AffineFastState.compose env58084 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound58084 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58085 : List Nat := [2,4,8,16,17,11,9,20,27,30,0,27,2,27,1,19,26,27,4,0,27,16,10,3,25,10,26,1,26,1,14,17,20,11,1,0]

theorem envBound58085 : H12AffineFastState.Bounded env58085 := by
  intro p hp
  have h : env58085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58084_58085 : H12AffineEnvironment.transform 4 17 env58084 = env58085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env58084 == env58085) = true)

theorem identity58085 : scanCanonicalize (H12AffineFastState.compose env58085 (packedSelected [0,1,4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound58085 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env58086 : List Nat := [2,2,8,16,17,11,9,18,27,24,0,27,2,27,1,19,26,27,2,0,27,16,10,3,25,10,26,1,26,1,8,17,18,11,1,0]

theorem envBound58086 : H12AffineFastState.Bounded env58086 := by
  intro p hp
  have h : env58086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58085_58086 : H12AffineEnvironment.transform 1 2 env58085 = env58086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env58085 == env58086) = true)

def env58087 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,524288,32769,4096,61649,91183,123165,533640,614526,385203,90414,545089,96347,25884,618622,256,25881,1344,525825]

theorem envBound58087 : H12AffineFastState.Bounded env58087 := by
  intro p hp
  have h : env58087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57537_58087 : H12AffineEnvironment.transform 23 123165 env57537 = env58087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123165 env57537 == env58087) = true)

def env58088 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21584,32769,4096,61649,91183,123165,28888,78894,385203,90414,1297,96347,25884,74798,256,25881,1344,21073]

theorem envBound58088 : H12AffineFastState.Bounded env58088 := by
  intro p hp
  have h : env58088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58087_58088 : H12AffineEnvironment.transform 18 21584 env58087 = env58088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env58087 == env58088) = true)

theorem identity58088 : scanCanonicalize (H12AffineFastState.compose env58088 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound58088 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env58089 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13340,65536,74863,262144,21584,13341,4096,17613,91183,87297,28888,78894,349359,90414,1297,96347,25884,74798,256,25881,1344,21073]

theorem envBound58089 : H12AffineFastState.Bounded env58089 := by
  intro p hp
  have h : env58089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58088_58089 : H12AffineEnvironment.transform 14 13340 env58088 = env58089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env58088 == env58089) = true)

def env58090 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74863,262144,4416,13341,4096,477,74047,69649,13768,78894,332223,74814,1297,81227,8204,74798,256,8201,1344,5953]

theorem envBound58090 : H12AffineFastState.Bounded env58090 := by
  intro p hp
  have h : env58090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58089_58090 : H12AffineEnvironment.transform 13 1296 env58089 = env58090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env58089 == env58090) = true)

def env58091 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74863,65664,4416,13341,4096,477,74047,69649,13768,78894,4415,74814,1297,81227,8204,74798,256,8201,1344,5953]

theorem envBound58091 : H12AffineFastState.Bounded env58091 := by
  intro p hp
  have h : env58091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58090_58091 : H12AffineEnvironment.transform 17 65664 env58090 = env58091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env58090 == env58091) = true)

theorem identity58091 : scanCanonicalize (H12AffineFastState.compose env58091 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 311) := by decide +kernel

theorem selectedBound58091 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58092 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,311,9560,439,4416,13341,4096,477,8200,4390,13768,13593,4415,9481,1297,15484,8204,9497,256,8201,1344,5953]

theorem envBound58092 : H12AffineFastState.Bounded env58092 := by
  intro p hp
  have h : env58092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58091_58092 : H12AffineEnvironment.transform 15 311 env58091 = env58092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 311 env58091 == env58092) = true)

def env58093 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,0,12556,311,8264,439,4416,12557,4096,477,8200,4390,12504,12297,4415,8217,1,14700,8204,8201,256,8201,80,4689]

theorem envBound58093 : H12AffineFastState.Bounded env58093 := by
  intro p hp
  have h : env58093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58092_58093 : H12AffineEnvironment.transform 9 272 env58092 = env58093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env58092 == env58093) = true)

theorem identity58093 : scanCanonicalize (H12AffineFastState.compose env58093 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 4121) := by decide +kernel

theorem selectedBound58093 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env58094 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,4121,0,277,311,4177,439,4416,276,4096,477,4113,4390,193,16,4415,4096,1,2421,4117,4112,256,4112,80,4689]

theorem envBound58094 : H12AffineFastState.Bounded env58094 := by
  intro p hp
  have h : env58094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58093_58094 : H12AffineEnvironment.transform 12 4121 env58093 = env58094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4121 env58093 == env58094) = true)

theorem identity58094 : scanCanonicalize (H12AffineFastState.compose env58094 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound58094 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env58095 : List Nat := [2,4,8,16,32,64,128,68,512,84,2048,4096,4121,0,81,115,4177,243,4100,80,4096,153,4113,4194,193,16,4219,4096,1,2097,4117,4112,68,4112,80,4689]

theorem envBound58095 : H12AffineFastState.Bounded env58095 := by
  intro p hp
  have h : env58095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58094_58095 : H12AffineEnvironment.transform 7 68 env58094 = env58095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env58094 == env58095) = true)

theorem identity58095 : scanCanonicalize (H12AffineFastState.compose env58095 (packedSelected [0,1,7,8,13,15,17,18,19] rootPS)) = affineNative (2^(10+1) ^^^ 97) := by decide +kernel

theorem selectedBound58095 : packedSelected [0,1,7,8,13,15,17,18,19] rootPS < 2^1333 := by decide +kernel

def env58096 : List Nat := [2,4,8,16,32,64,128,68,512,84,97,4096,4121,0,81,115,4177,243,4100,80,4096,153,4113,4194,193,16,4219,4096,1,80,4117,4112,68,4112,80,4689]

theorem envBound58096 : H12AffineFastState.Bounded env58096 := by
  intro p hp
  have h : env58096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58095_58096 : H12AffineEnvironment.transform 10 97 env58095 = env58096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 97 env58095 == env58096) = true)

theorem identity58096 : scanCanonicalize (H12AffineFastState.compose env58096 (packedSelected [1,8,10,12,13] rootPS)) = affineNative (2^(11+1) ^^^ 42) := by decide +kernel

theorem selectedBound58096 : packedSelected [1,8,10,12,13] rootPS < 2^1333 := by decide +kernel

def env58097 : List Nat := [2,4,8,16,32,64,128,68,512,84,97,42,51,0,81,115,123,243,46,80,42,153,59,72,193,16,81,42,1,80,63,58,68,58,80,635]

theorem envBound58097 : H12AffineFastState.Bounded env58097 := by
  intro p hp
  have h : env58097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58096_58097 : H12AffineEnvironment.transform 11 42 env58096 = env58097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 42 env58096 == env58097) = true)

theorem identity58097 : scanCanonicalize (H12AffineFastState.compose env58097 (packedSelected [0,2,3,4,8,11] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound58097 : packedSelected [0,2,3,4,8,11] rootPS < 2^1333 := by decide +kernel

def env58098 : List Nat := [2,4,8,16,32,64,19,68,512,84,97,42,51,0,81,115,123,96,46,80,42,10,59,72,82,16,81,42,1,80,63,58,68,58,80,635]

theorem envBound58098 : H12AffineFastState.Bounded env58098 := by
  intro p hp
  have h : env58098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58097_58098 : H12AffineEnvironment.transform 6 19 env58097 = env58098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env58097 == env58098) = true)

theorem identity58098 : scanCanonicalize (H12AffineFastState.compose env58098 (packedSelected [1,3,4,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 124) := by decide +kernel

theorem selectedBound58098 : packedSelected [1,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env58099 : List Nat := [2,4,8,16,32,64,19,68,124,84,97,42,51,0,81,115,123,96,46,80,42,10,59,72,82,16,81,42,1,80,63,58,68,58,80,7]

theorem envBound58099 : H12AffineFastState.Bounded env58099 := by
  intro p hp
  have h : env58099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58098_58099 : H12AffineEnvironment.transform 8 124 env58098 = env58099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 124 env58098 == env58099) = true)

theorem identity58099 : scanCanonicalize (H12AffineFastState.compose env58099 (packedSelected [1,4,5,8,9] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound58099 : packedSelected [1,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env58100 : List Nat := [2,4,8,16,22,64,19,68,74,84,87,28,5,0,81,69,77,86,24,80,28,10,13,72,82,16,81,28,1,80,9,12,68,12,80,7]

theorem envBound58100 : H12AffineFastState.Bounded env58100 := by
  intro p hp
  have h : env58100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58099_58100 : H12AffineEnvironment.transform 4 22 env58099 = env58100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env58099 == env58100) = true)

theorem identity58100 : scanCanonicalize (H12AffineFastState.compose env58100 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound58100 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env58101 : List Nat := [2,4,8,16,22,17,19,21,27,5,6,28,5,0,0,20,28,7,24,1,28,10,13,25,3,16,0,28,1,1,9,12,21,12,1,7]

theorem envBound58101 : H12AffineFastState.Bounded env58101 := by
  intro p hp
  have h : env58101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58100_58101 : H12AffineEnvironment.transform 5 17 env58100 = env58101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env58100 == env58101) = true)

def env58102 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,1,12557,311,8265,439,4416,12556,4096,477,8200,4390,12505,12296,4415,8216,0,14701,8204,8200,256,8201,81,4688]

theorem envBound58102 : H12AffineFastState.Bounded env58102 := by
  intro p hp
  have h : env58102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58092_58102 : H12AffineEnvironment.transform 9 273 env58092 = env58102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env58092 == env58102) = true)

theorem identity58102 : scanCanonicalize (H12AffineFastState.compose env58102 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound58102 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env58103 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,268,1,4097,311,325,439,4416,4096,4096,477,260,4390,4565,4356,4415,276,0,6241,256,260,256,261,81,4688]

theorem envBound58103 : H12AffineFastState.Bounded env58103 := by
  intro p hp
  have h : env58103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58102_58103 : H12AffineEnvironment.transform 12 268 env58102 = env58103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env58102 == env58103) = true)

theorem identity58103 : scanCanonicalize (H12AffineFastState.compose env58103 (packedSelected [0,3,4,5,7,9,10,12,13,15,18,23] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound58103 : packedSelected [0,3,4,5,7,9,10,12,13,15,18,23] rootPS < 2^1333 := by decide +kernel

def env58104 : List Nat := [2,4,8,16,32,64,128,173,512,188,2048,4096,161,1,4097,154,232,26,4333,4096,4096,112,169,4235,4216,4265,4242,185,0,6241,173,169,173,168,81,4688]

theorem envBound58104 : H12AffineFastState.Bounded env58104 := by
  intro p hp
  have h : env58104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58103_58104 : H12AffineEnvironment.transform 7 173 env58103 = env58104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env58103 == env58104) = true)

theorem identity58104 : scanCanonicalize (H12AffineFastState.compose env58104 (packedSelected [13,15,16,17,18] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound58104 : packedSelected [13,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env58105 : List Nat := [2,4,8,16,17,64,128,156,512,141,2048,4096,144,1,4097,154,217,26,4316,4096,4096,65,152,4235,4169,4248,4242,136,0,6224,156,152,156,153,81,4688]

theorem envBound58105 : H12AffineFastState.Bounded env58105 := by
  intro p hp
  have h : env58105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58104_58105 : H12AffineEnvironment.transform 4 17 env58104 = env58105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env58104 == env58105) = true)

theorem identity58105 : scanCanonicalize (H12AffineFastState.compose env58105 (packedSelected [0,1,3,5,7,8,12,13] rootPS)) = affineNative (2^(10+1) ^^^ 74) := by decide +kernel

theorem selectedBound58105 : packedSelected [0,1,3,5,7,8,12,13] rootPS < 2^1333 := by decide +kernel

def env58106 : List Nat := [2,4,8,16,17,64,128,156,512,141,74,4096,144,1,4097,154,217,26,4316,4096,4096,65,152,4235,4169,4248,4242,136,0,4122,156,152,156,153,81,4688]

theorem envBound58106 : H12AffineFastState.Bounded env58106 := by
  intro p hp
  have h : env58106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58105_58106 : H12AffineEnvironment.transform 10 74 env58105 = env58106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 74 env58105 == env58106) = true)

theorem identity58106 : scanCanonicalize (H12AffineFastState.compose env58106 (packedSelected [1,2,3,4,8,9,10,11] rootPS)) = affineNative (2^(8+1) ^^^ 212) := by decide +kernel

theorem selectedBound58106 : packedSelected [1,2,3,4,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env58107 : List Nat := [2,4,8,16,17,64,128,156,212,141,74,4096,144,1,4097,154,217,26,4316,4096,4096,65,152,4235,4169,4248,4242,136,0,4122,156,152,156,153,81,4228]

theorem envBound58107 : H12AffineFastState.Bounded env58107 := by
  intro p hp
  have h : env58107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58106_58107 : H12AffineEnvironment.transform 8 212 env58106 = env58107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 212 env58106 == env58107) = true)

theorem identity58107 : scanCanonicalize (H12AffineFastState.compose env58107 (packedSelected [1,3,4,7,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 159) := by decide +kernel

theorem selectedBound58107 : packedSelected [1,3,4,7,10,12] rootPS < 2^1333 := by decide +kernel

def env58108 : List Nat := [2,4,8,16,17,64,128,156,212,141,74,159,144,1,158,154,217,26,67,159,159,65,152,20,214,7,13,136,0,133,156,152,156,153,81,27]

theorem envBound58108 : H12AffineFastState.Bounded env58108 := by
  intro p hp
  have h : env58108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58107_58108 : H12AffineEnvironment.transform 11 159 env58107 = env58108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 159 env58107 == env58108) = true)

theorem identity58108 : scanCanonicalize (H12AffineFastState.compose env58108 (packedSelected [4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 67) := by decide +kernel

theorem selectedBound58108 : packedSelected [4,5,7] rootPS < 2^1333 := by decide +kernel

def env58109 : List Nat := [2,4,8,16,17,64,67,95,23,78,74,92,83,1,93,89,26,26,67,92,92,65,91,20,21,7,13,75,0,70,95,91,95,90,81,27]

theorem envBound58109 : H12AffineFastState.Bounded env58109 := by
  intro p hp
  have h : env58109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58108_58109 : H12AffineEnvironment.transform 6 67 env58108 = env58109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 67 env58108 == env58109) = true)

theorem identity58109 : scanCanonicalize (H12AffineFastState.compose env58109 (packedSelected [2,3] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound58109 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env58110 : List Nat := [2,4,8,16,17,10,9,21,23,4,0,22,25,1,23,19,26,26,9,22,22,11,17,20,21,7,13,1,0,12,21,17,21,16,27,27]

theorem envBound58110 : H12AffineFastState.Bounded env58110 := by
  intro p hp
  have h : env58110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58109_58110 : H12AffineEnvironment.transform 5 10 env58109 = env58110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env58109 == env58110) = true)

theorem identity58110 : scanCanonicalize (H12AffineFastState.compose env58110 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound58110 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58111 : List Nat := [2,4,8,11,10,10,9,14,12,4,0,13,2,1,12,8,1,1,9,13,13,11,10,15,14,7,13,1,0,12,14,10,14,11,0,0]

theorem envBound58111 : H12AffineFastState.Bounded env58111 := by
  intro p hp
  have h : env58111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58110_58111 : H12AffineEnvironment.transform 3 11 env58110 = env58111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env58110 == env58111) = true)

def env58112 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74863,65665,4416,13341,4096,477,74047,69649,13768,78894,4414,74814,1297,81227,8204,74798,256,8201,1344,5953]

theorem envBound58112 : H12AffineFastState.Bounded env58112 := by
  intro p hp
  have h : env58112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58090_58112 : H12AffineEnvironment.transform 17 65665 env58090 = env58112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env58090 == env58112) = true)

theorem identity58112 : scanCanonicalize (H12AffineFastState.compose env58112 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5239) := by decide +kernel

theorem selectedBound58112 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58113 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,5239,12312,5366,4416,13341,4096,477,13640,1126,13768,8281,4414,12361,1297,10556,8204,12377,256,8201,1344,5953]

theorem envBound58113 : H12AffineFastState.Bounded env58113 := by
  intro p hp
  have h : env58113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58112_58113 : H12AffineEnvironment.transform 15 5239 env58112 = env58113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5239 env58112 == env58113) = true)

def env58114 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1296,9292,1063,8264,1190,272,9293,80,477,9496,1126,9624,8281,366,8217,1297,10556,8204,8201,256,8201,1344,1809]

theorem envBound58114 : H12AffineFastState.Bounded env58114 := by
  intro p hp
  have h : env58114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58113_58114 : H12AffineEnvironment.transform 11 80 env58113 = env58114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env58113 == env58114) = true)

theorem identity58114 : scanCanonicalize (H12AffineFastState.compose env58114 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 73) := by decide +kernel

theorem selectedBound58114 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env58115 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,73,1296,1029,1063,1,1190,272,1028,80,477,1361,1126,1489,16,366,80,1297,2421,69,64,256,64,1344,1809]

theorem envBound58115 : H12AffineFastState.Bounded env58115 := by
  intro p hp
  have h : env58115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58114_58115 : H12AffineEnvironment.transform 12 73 env58114 = env58115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env58114 == env58115) = true)

theorem identity58115 : scanCanonicalize (H12AffineFastState.compose env58115 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound58115 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env58116 : List Nat := [2,4,8,16,32,64,128,256,512,84,2048,80,73,324,81,115,1,242,272,80,80,477,261,50,389,16,366,80,325,2421,69,64,256,64,276,837]

theorem envBound58116 : H12AffineFastState.Bounded env58116 := by
  intro p hp
  have h : env58116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58115_58116 : H12AffineEnvironment.transform 9 84 env58115 = env58116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env58115 == env58116) = true)

theorem identity58116 : scanCanonicalize (H12AffineFastState.compose env58116 (packedSelected [0,1,7,8,15,18,19] rootPS)) = affineNative (2^(7+1) ^^^ 182) := by decide +kernel

theorem selectedBound58116 : packedSelected [0,1,7,8,15,18,19] rootPS < 2^1333 := by decide +kernel

def env58117 : List Nat := [2,4,8,16,32,64,128,182,512,84,2048,80,73,242,81,115,1,242,166,80,80,107,179,50,51,16,216,80,243,2243,69,64,182,64,162,755]

theorem envBound58117 : H12AffineFastState.Bounded env58117 := by
  intro p hp
  have h : env58117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58116_58117 : H12AffineEnvironment.transform 7 182 env58116 = env58117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 182 env58116 == env58117) = true)

theorem identity58117 : scanCanonicalize (H12AffineFastState.compose env58117 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound58117 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env58118 : List Nat := [2,4,8,16,32,64,18,36,512,84,2048,80,73,96,81,115,1,96,52,80,80,107,33,50,51,16,74,80,97,2129,69,64,36,64,48,609]

theorem envBound58118 : H12AffineFastState.Bounded env58118 := by
  intro p hp
  have h : env58118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58117_58118 : H12AffineEnvironment.transform 6 18 env58117 = env58118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env58117 == env58118) = true)

theorem identity58118 : scanCanonicalize (H12AffineFastState.compose env58118 (packedSelected [1,2,3,4,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 102) := by decide +kernel

theorem selectedBound58118 : packedSelected [1,2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env58119 : List Nat := [2,4,8,16,32,64,18,36,512,84,102,80,73,96,81,115,1,96,52,80,80,107,33,50,51,16,74,80,97,55,69,64,36,64,48,609]

theorem envBound58119 : H12AffineFastState.Bounded env58119 := by
  intro p hp
  have h : env58119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58118_58119 : H12AffineEnvironment.transform 10 102 env58118 = env58119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 102 env58118 == env58119) = true)

theorem identity58119 : scanCanonicalize (H12AffineFastState.compose env58119 (packedSelected [0,1,2,3,4,5,12] rootPS)) = affineNative (2^(5+1) ^^^ 60) := by decide +kernel

theorem selectedBound58119 : packedSelected [0,1,2,3,4,5,12] rootPS < 2^1333 := by decide +kernel

def env58120 : List Nat := [2,4,8,16,32,60,18,36,512,40,26,44,53,28,45,15,1,28,52,44,44,23,33,50,51,16,54,44,29,55,57,60,36,60,48,541]

theorem envBound58120 : H12AffineFastState.Bounded env58120 := by
  intro p hp
  have h : env58120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58119_58120 : H12AffineEnvironment.transform 5 60 env58119 = env58120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 60 env58119 == env58120) = true)

theorem identity58120 : scanCanonicalize (H12AffineFastState.compose env58120 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound58120 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env58121 : List Nat := [2,4,8,16,22,10,18,18,512,30,26,26,3,28,27,15,1,28,2,26,26,23,23,4,5,16,0,26,29,1,15,10,18,10,6,541]

theorem envBound58121 : H12AffineFastState.Bounded env58121 := by
  intro p hp
  have h : env58121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58120_58121 : H12AffineEnvironment.transform 4 22 env58120 = env58121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env58120 == env58121) = true)

theorem identity58121 : scanCanonicalize (H12AffineFastState.compose env58121 (packedSelected [1,5,8] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound58121 : packedSelected [1,5,8] rootPS < 2^1333 := by decide +kernel

def env58122 : List Nat := [2,3,8,16,17,10,18,18,512,25,26,26,3,27,27,8,1,27,2,26,26,16,16,3,2,16,0,26,26,1,8,10,18,10,1,538]

theorem envBound58122 : H12AffineFastState.Bounded env58122 := by
  intro p hp
  have h : env58122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58121_58122 : H12AffineEnvironment.transform 1 3 env58121 = env58122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env58121 == env58122) = true)

theorem identity58122 : scanCanonicalize (H12AffineFastState.compose env58122 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound58122 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58123 : List Nat := [2,3,8,16,17,10,18,18,1,25,26,26,3,27,27,8,1,27,2,26,26,16,16,3,2,16,0,26,26,1,8,10,18,10,1,27]

theorem envBound58123 : H12AffineFastState.Bounded env58123 := by
  intro p hp
  have h : env58123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58122_58123 : H12AffineEnvironment.transform 8 1 env58122 = env58123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env58122 == env58123) = true)

def env58124 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1296,9293,1062,8265,1191,273,9292,81,477,9497,1126,9625,8281,367,8216,1297,10556,8204,8200,256,8201,1344,1808]

theorem envBound58124 : H12AffineFastState.Bounded env58124 := by
  intro p hp
  have h : env58124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58113_58124 : H12AffineEnvironment.transform 11 81 env58113 = env58124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env58113 == env58124) = true)

theorem identity58124 : scanCanonicalize (H12AffineFastState.compose env58124 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound58124 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env58125 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,268,1296,1345,1062,325,1191,273,1344,81,477,1045,1126,1173,341,367,276,1297,2096,256,260,256,261,1344,1808]

theorem envBound58125 : H12AffineFastState.Bounded env58125 := by
  intro p hp
  have h : env58125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58124_58125 : H12AffineEnvironment.transform 12 268 env58124 = env58125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env58124 == env58125) = true)

theorem identity58125 : scanCanonicalize (H12AffineFastState.compose env58125 (packedSelected [0,1,4,7,8,9,12,13,15,18,19,23] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound58125 : packedSelected [0,1,4,7,8,9,12,13,15,18,19,23] rootPS < 2^1333 := by decide +kernel

def env58126 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,81,240,1260,1213,1062,185,1191,237,1212,81,33,1045,1126,1173,169,147,232,1261,2096,252,248,252,249,1212,1772]

theorem envBound58126 : H12AffineFastState.Bounded env58126 := by
  intro p hp
  have h : env58126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58125_58126 : H12AffineEnvironment.transform 7 252 env58125 = env58126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env58125 == env58126) = true)

theorem identity58126 : scanCanonicalize (H12AffineFastState.compose env58126 (packedSelected [0,1,5,7,8,12,16,17] rootPS)) = affineNative (2^(10+1) ^^^ 255) := by decide +kernel

theorem selectedBound58126 : packedSelected [0,1,5,7,8,12,16,17] rootPS < 2^1333 := by decide +kernel

def env58127 : List Nat := [2,4,8,16,32,64,128,252,512,1024,255,81,240,1260,1213,1062,185,1191,237,1212,81,33,1045,1126,1173,169,147,232,1261,207,252,248,252,249,1212,1772]

theorem envBound58127 : H12AffineFastState.Bounded env58127 := by
  intro p hp
  have h : env58127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58126_58127 : H12AffineEnvironment.transform 10 255 env58126 = env58127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 255 env58126 == env58127) = true)

theorem identity58127 : scanCanonicalize (H12AffineFastState.compose env58127 (packedSelected [0,1,2,5,7,8,11,12,13,16,18] rootPS)) = affineNative (2^(9+1) ^^^ 736) := by decide +kernel

theorem selectedBound58127 : packedSelected [0,1,2,5,7,8,11,12,13,16,18] rootPS < 2^1333 := by decide +kernel

def env58128 : List Nat := [2,4,8,16,32,64,128,252,512,736,255,81,240,524,605,710,185,583,237,604,81,33,757,646,629,169,147,232,525,207,252,248,252,249,604,12]

theorem envBound58128 : H12AffineFastState.Bounded env58128 := by
  intro p hp
  have h : env58128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58127_58128 : H12AffineEnvironment.transform 9 736 env58127 = env58128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 736 env58127 == env58128) = true)

theorem identity58128 : scanCanonicalize (H12AffineFastState.compose env58128 (packedSelected [1,3,4,9,12,15,16] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound58128 : packedSelected [1,3,4,9,12,15,16] rootPS < 2^1333 := by decide +kernel

def env58129 : List Nat := [2,4,8,16,28,64,128,192,512,732,195,81,204,524,605,710,133,583,209,604,81,29,713,646,585,149,147,212,525,207,192,196,192,197,604,12]

theorem envBound58129 : H12AffineFastState.Bounded env58129 := by
  intro p hp
  have h : env58129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58128_58129 : H12AffineEnvironment.transform 4 28 env58128 = env58129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env58128 == env58129) = true)

theorem identity58129 : scanCanonicalize (H12AffineFastState.compose env58129 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(8+1) ^^^ 92) := by decide +kernel

theorem selectedBound58129 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env58130 : List Nat := [2,4,8,16,28,64,128,192,92,128,195,81,204,80,1,154,133,27,209,0,81,29,149,218,21,149,147,212,81,207,192,196,192,197,0,12]

theorem envBound58130 : H12AffineFastState.Bounded env58130 := by
  intro p hp
  have h : env58130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58129_58130 : H12AffineEnvironment.transform 8 92 env58129 = env58130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 92 env58129 == env58130) = true)

theorem identity58130 : scanCanonicalize (H12AffineFastState.compose env58130 (packedSelected [1,2,3,4,5,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 29) := by decide +kernel

theorem selectedBound58130 : packedSelected [1,2,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env58131 : List Nat := [2,4,8,16,28,29,128,157,1,128,158,12,145,13,1,154,133,27,140,0,12,29,149,135,21,149,147,137,12,146,157,153,157,152,0,12]

theorem envBound58131 : H12AffineFastState.Bounded env58131 := by
  intro p hp
  have h : env58131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58130_58131 : H12AffineEnvironment.transform 5 29 env58130 = env58131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 29 env58130 == env58131) = true)

theorem identity58131 : scanCanonicalize (H12AffineFastState.compose env58131 (packedSelected [1,3,5] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound58131 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env58132 : List Nat := [2,4,4,16,16,17,128,145,1,128,146,0,145,1,1,150,133,23,128,0,0,17,149,135,21,149,147,133,0,146,145,149,145,148,0,0]

theorem envBound58132 : H12AffineFastState.Bounded env58132 := by
  intro p hp
  have h : env58132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58131_58132 : H12AffineEnvironment.transform 2 4 env58131 = env58132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env58131 == env58132) = true)

theorem identity58132 : scanCanonicalize (H12AffineFastState.compose env58132 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 22) := by decide +kernel

theorem selectedBound58132 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58133 : List Nat := [2,4,4,16,16,17,22,7,1,22,4,0,7,1,1,0,19,23,22,0,0,17,3,17,21,3,5,19,0,4,7,3,7,2,0,0]

theorem envBound58133 : H12AffineFastState.Bounded env58133 := by
  intro p hp
  have h : env58133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58132_58133 : H12AffineEnvironment.transform 6 22 env58132 = env58133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 22 env58132 == env58133) = true)

theorem identity58133 : scanCanonicalize (H12AffineFastState.compose env58133 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound58133 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env58134 : List Nat := [2,4,4,7,7,6,1,7,1,1,4,0,7,1,1,0,4,0,1,0,0,6,3,6,2,3,5,4,0,4,7,3,7,2,0,0]

theorem envBound58134 : H12AffineFastState.Bounded env58134 := by
  intro p hp
  have h : env58134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58133_58134 : H12AffineEnvironment.transform 3 7 env58133 = env58134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env58133 == env58134) = true)

theorem identity58134 : scanCanonicalize (H12AffineFastState.compose env58134 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound58134 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58135 : List Nat := [2,1,1,2,2,3,1,2,1,1,1,0,2,1,1,0,1,0,1,0,0,3,3,3,2,3,0,1,0,1,2,3,2,2,0,0]

theorem envBound58135 : H12AffineFastState.Bounded env58135 := by
  intro p hp
  have h : env58135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58134_58135 : H12AffineEnvironment.transform 1 1 env58134 = env58135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env58134 == env58135) = true)

theorem identity58135 : scanCanonicalize (H12AffineFastState.compose env58135 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound58135 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env58136 : List Nat := [1,1,1,1,1,0,1,1,1,1,1,0,1,1,1,0,1,0,1,0,0,0,0,0,1,0,0,1,0,1,1,0,1,1,0,0]

theorem envBound58136 : H12AffineFastState.Bounded env58136 := by
  intro p hp
  have h : env58136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58135_58136 : H12AffineEnvironment.transform 0 1 env58135 = env58136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env58135 == env58136) = true)

def env58137 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74863,262144,4417,13341,4096,476,74046,69648,13769,78894,332222,74815,1297,81226,8205,74798,256,8200,1344,5952]

theorem envBound58137 : H12AffineFastState.Bounded env58137 := by
  intro p hp
  have h : env58137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58089_58137 : H12AffineEnvironment.transform 13 1297 env58089 = env58137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env58089 == env58137) = true)

def env58138 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74863,65664,4417,13341,4096,476,74046,69648,13769,78894,4414,74815,1297,81226,8205,74798,256,8200,1344,5952]

theorem envBound58138 : H12AffineFastState.Bounded env58138 := by
  intro p hp
  have h : env58138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58137_58138 : H12AffineEnvironment.transform 17 65664 env58137 = env58138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env58137 == env58138) = true)

theorem identity58138 : scanCanonicalize (H12AffineFastState.compose env58138 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12671) := by decide +kernel

theorem selectedBound58138 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58139 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,12671,5392,12799,4417,13341,4096,476,4161,8559,13769,1361,4414,5440,1297,3125,8205,5457,256,8200,1344,5952]

theorem envBound58139 : H12AffineFastState.Bounded env58139 := by
  intro p hp
  have h : env58139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58138_58139 : H12AffineEnvironment.transform 15 12671 env58138 = env58139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12671 env58138 == env58139) = true)

def env58140 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1297,9292,8495,1344,8623,273,9293,80,476,17,8559,9625,1361,366,1296,1297,3125,8205,1281,256,8200,1344,1808]

theorem envBound58140 : H12AffineFastState.Bounded env58140 := by
  intro p hp
  have h : env58140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58139_58140 : H12AffineEnvironment.transform 11 80 env58139 = env58140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env58139 == env58140) = true)

theorem identity58140 : scanCanonicalize (H12AffineFastState.compose env58140 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 1369) := by decide +kernel

theorem selectedBound58140 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58141 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,1369,1297,277,1142,1344,1270,273,276,80,476,17,1078,192,1361,366,1296,1297,3125,1364,1281,256,1361,1344,1808]

theorem envBound58141 : H12AffineFastState.Bounded env58141 := by
  intro p hp
  have h : env58141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58140_58141 : H12AffineEnvironment.transform 12 1369 env58140 = env58141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1369 env58140 == env58141) = true)

theorem identity58141 : scanCanonicalize (H12AffineFastState.compose env58141 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound58141 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env58142 : List Nat := [2,4,8,16,32,64,128,256,512,188,2048,80,485,429,277,202,508,74,273,276,80,476,17,138,192,493,366,428,429,2185,488,445,256,493,508,940]

theorem envBound58142 : H12AffineFastState.Bounded env58142 := by
  intro p hp
  have h : env58142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58141_58142 : H12AffineEnvironment.transform 9 188 env58141 = env58142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env58141 == env58142) = true)

theorem identity58142 : scanCanonicalize (H12AffineFastState.compose env58142 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 217) := by decide +kernel

theorem selectedBound58142 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env58143 : List Nat := [2,4,8,16,32,64,128,256,217,188,2048,80,485,429,277,202,508,74,273,276,80,476,17,138,192,493,366,428,429,2185,488,445,256,493,508,373]

theorem envBound58143 : H12AffineFastState.Bounded env58143 := by
  intro p hp
  have h : env58143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58142_58143 : H12AffineEnvironment.transform 8 217 env58142 = env58143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env58142 == env58143) = true)

theorem identity58143 : scanCanonicalize (H12AffineFastState.compose env58143 (packedSelected [0,2,3,7,8,10,13,16] rootPS)) = affineNative (2^(6+1) ^^^ 66) := by decide +kernel

theorem selectedBound58143 : packedSelected [0,2,3,7,8,10,13,16] rootPS < 2^1333 := by decide +kernel

def env58144 : List Nat := [2,4,8,16,32,64,66,256,27,126,2048,80,295,367,277,8,318,74,273,276,80,286,17,72,2,303,366,366,367,2123,298,383,256,303,318,373]

theorem envBound58144 : H12AffineFastState.Bounded env58144 := by
  intro p hp
  have h : env58144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58143_58144 : H12AffineEnvironment.transform 6 66 env58143 = env58144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 66 env58143 == env58144) = true)

theorem identity58144 : scanCanonicalize (H12AffineFastState.compose env58144 (packedSelected [0,4,7,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 110) := by decide +kernel

theorem selectedBound58144 : packedSelected [0,4,7,9,10] rootPS < 2^1333 := by decide +kernel

def env58145 : List Nat := [2,4,8,16,32,64,66,110,27,126,2048,80,73,1,123,8,80,74,127,122,80,112,17,72,2,65,0,0,1,2123,68,17,110,65,80,27]

theorem envBound58145 : H12AffineFastState.Bounded env58145 := by
  intro p hp
  have h : env58145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58144_58145 : H12AffineEnvironment.transform 7 110 env58144 = env58145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 110 env58144 == env58145) = true)

theorem identity58145 : scanCanonicalize (H12AffineFastState.compose env58145 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound58145 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env58146 : List Nat := [2,4,8,16,32,10,8,36,27,52,2048,26,3,1,49,8,26,0,53,48,26,58,17,2,2,11,0,0,1,2049,14,17,36,11,26,27]

theorem envBound58146 : H12AffineFastState.Bounded env58146 := by
  intro p hp
  have h : env58146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58145_58146 : H12AffineEnvironment.transform 5 10 env58145 = env58146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env58145 == env58146) = true)

theorem identity58146 : scanCanonicalize (H12AffineFastState.compose env58146 (packedSelected [0,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound58146 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env58147 : List Nat := [2,4,8,16,32,10,8,36,27,52,1,26,3,1,49,8,26,0,53,48,26,58,17,2,2,11,0,0,1,0,14,17,36,11,26,27]

theorem envBound58147 : H12AffineFastState.Bounded env58147 := by
  intro p hp
  have h : env58147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58146_58147 : H12AffineEnvironment.transform 10 1 env58146 = env58147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env58146 == env58147) = true)

theorem identity58147 : scanCanonicalize (H12AffineFastState.compose env58147 (packedSelected [0,1,2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound58147 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env58148 : List Nat := [2,4,8,16,17,10,8,21,27,5,1,26,3,1,0,8,26,0,4,1,26,11,17,2,2,11,0,0,1,0,14,17,21,11,26,27]

theorem envBound58148 : H12AffineFastState.Bounded env58148 := by
  intro p hp
  have h : env58148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58147_58148 : H12AffineEnvironment.transform 4 17 env58147 = env58148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env58147 == env58148) = true)

theorem identity58148 : scanCanonicalize (H12AffineFastState.compose env58148 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound58148 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env58149 : List Nat := [2,4,8,11,10,10,8,14,0,5,1,1,3,1,0,8,1,0,4,1,1,11,10,2,2,11,0,0,1,0,14,10,14,11,1,0]

theorem envBound58149 : H12AffineFastState.Bounded env58149 := by
  intro p hp
  have h : env58149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58148_58149 : H12AffineEnvironment.transform 3 11 env58148 = env58149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env58148 == env58149) = true)

theorem identity58149 : scanCanonicalize (H12AffineFastState.compose env58149 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound58149 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58150 : List Nat := [2,4,4,7,6,6,4,2,0,5,1,1,3,1,0,4,1,0,4,1,1,7,6,2,2,7,0,0,1,0,2,6,2,7,1,0]

theorem envBound58150 : H12AffineFastState.Bounded env58150 := by
  intro p hp
  have h : env58150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58149_58150 : H12AffineEnvironment.transform 2 4 env58149 = env58150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env58149 == env58150) = true)

def env58151 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1297,9293,8494,1345,8622,272,9292,81,476,16,8559,9624,1361,367,1297,1297,3125,8205,1280,256,8200,1344,1809]

theorem envBound58151 : H12AffineFastState.Bounded env58151 := by
  intro p hp
  have h : env58151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58139_58151 : H12AffineEnvironment.transform 11 81 env58139 = env58151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env58139 == env58151) = true)

theorem identity58151 : scanCanonicalize (H12AffineFastState.compose env58151 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound58151 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58152 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,1052,1297,81,1330,1345,1458,272,80,81,476,16,1395,388,1361,367,1297,1297,3125,1041,1280,256,1044,1344,1809]

theorem envBound58152 : H12AffineFastState.Bounded env58152 := by
  intro p hp
  have h : env58152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58151_58152 : H12AffineEnvironment.transform 12 1052 env58151 = env58152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env58151 == env58152) = true)

theorem identity58152 : scanCanonicalize (H12AffineFastState.compose env58152 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound58152 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env58153 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,81,269,0,81,35,80,163,272,80,81,476,16,98,388,64,367,0,0,2340,256,17,256,261,81,512]

theorem envBound58153 : H12AffineFastState.Bounded env58153 := by
  intro p hp
  have h : env58153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58152_58153 : H12AffineEnvironment.transform 9 273 env58152 = env58153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env58152 == env58153) = true)

theorem identity58153 : scanCanonicalize (H12AffineFastState.compose env58153 (packedSelected [2,5,8,13] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound58153 : packedSelected [2,5,8,13] rootPS < 2^1333 := by decide +kernel

def env58154 : List Nat := [2,4,8,16,32,64,105,256,512,273,2048,81,269,0,81,35,80,74,272,80,81,309,16,98,365,64,367,0,0,2340,256,17,256,261,81,512]

theorem envBound58154 : H12AffineFastState.Bounded env58154 := by
  intro p hp
  have h : env58154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58153_58154 : H12AffineEnvironment.transform 6 105 env58153 = env58154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env58153 == env58154) = true)

theorem identity58154 : scanCanonicalize (H12AffineFastState.compose env58154 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound58154 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env58155 : List Nat := [2,4,8,16,32,64,105,256,49,273,2048,81,269,0,81,35,80,74,272,80,81,309,16,98,365,64,367,0,0,2340,256,17,256,261,81,49]

theorem envBound58155 : H12AffineFastState.Bounded env58155 := by
  intro p hp
  have h : env58155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58154_58155 : H12AffineEnvironment.transform 8 49 env58154 = env58155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env58154 == env58155) = true)

theorem identity58155 : scanCanonicalize (H12AffineFastState.compose env58155 (packedSelected [0,7,10,11,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 366) := by decide +kernel

theorem selectedBound58155 : packedSelected [0,7,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env58156 : List Nat := [2,4,8,16,32,64,105,256,49,273,366,81,269,0,81,35,80,74,272,80,81,309,16,98,365,64,367,0,0,74,256,17,256,261,81,49]

theorem envBound58156 : H12AffineFastState.Bounded env58156 := by
  intro p hp
  have h : env58156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58155_58156 : H12AffineEnvironment.transform 10 366 env58155 = env58156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 366 env58155 == env58156) = true)

theorem identity58156 : scanCanonicalize (H12AffineFastState.compose env58156 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 110) := by decide +kernel

theorem selectedBound58156 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env58157 : List Nat := [2,4,8,16,32,64,105,110,49,127,0,81,99,0,81,35,80,74,126,80,81,91,16,98,3,64,1,0,0,74,110,17,110,107,81,49]

theorem envBound58157 : H12AffineFastState.Bounded env58157 := by
  intro p hp
  have h : env58157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58156_58157 : H12AffineEnvironment.transform 7 110 env58156 = env58157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 110 env58156 == env58157) = true)

theorem identity58157 : scanCanonicalize (H12AffineFastState.compose env58157 (packedSelected [0,1,2] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound58157 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env58158 : List Nat := [2,4,8,16,32,32,9,14,49,31,0,49,3,0,49,35,48,42,30,48,49,59,16,2,3,32,1,0,0,42,14,17,14,11,49,49]

theorem envBound58158 : H12AffineFastState.Bounded env58158 := by
  intro p hp
  have h : env58158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58157_58158 : H12AffineEnvironment.transform 5 32 env58157 = env58158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env58157 == env58158) = true)

theorem identity58158 : scanCanonicalize (H12AffineFastState.compose env58158 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound58158 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env58159 : List Nat := [2,4,8,16,17,17,9,14,0,31,0,0,3,0,0,18,1,27,30,1,0,10,16,2,3,17,1,0,0,27,14,17,14,11,0,0]

theorem envBound58159 : H12AffineFastState.Bounded env58159 := by
  intro p hp
  have h : env58159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58158_58159 : H12AffineEnvironment.transform 4 17 env58158 = env58159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env58158 == env58159) = true)

theorem identity58159 : scanCanonicalize (H12AffineFastState.compose env58159 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound58159 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env58160 : List Nat := [2,4,8,11,10,10,9,14,0,4,0,0,3,0,0,9,1,0,5,1,0,10,11,2,3,10,1,0,0,0,14,10,14,11,0,0]

theorem envBound58160 : H12AffineFastState.Bounded env58160 := by
  intro p hp
  have h : env58160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58159_58160 : H12AffineEnvironment.transform 3 11 env58159 = env58160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env58159 == env58160) = true)

theorem identity58160 : scanCanonicalize (H12AffineFastState.compose env58160 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound58160 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58161 : List Nat := [2,4,5,6,7,7,4,3,0,4,0,0,3,0,0,4,1,0,5,1,0,7,6,2,3,7,1,0,0,0,3,7,3,6,0,0]

theorem envBound58161 : H12AffineFastState.Bounded env58161 := by
  intro p hp
  have h : env58161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58160_58161 : H12AffineEnvironment.transform 2 5 env58160 = env58161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env58160 == env58161) = true)

def env58162 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,65536,74863,65665,4417,13341,4096,476,74046,69648,13769,78894,4415,74815,1297,81226,8205,74798,256,8200,1344,5952]

theorem envBound58162 : H12AffineFastState.Bounded env58162 := by
  intro p hp
  have h : env58162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58137_58162 : H12AffineEnvironment.transform 17 65665 env58137 = env58162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env58137 == env58162) = true)

theorem identity58162 : scanCanonicalize (H12AffineFastState.compose env58162 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9278) := by decide +kernel

theorem selectedBound58162 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58163 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13340,9278,81,9407,4417,13341,4096,476,1280,13358,13769,4112,4415,1,1297,6516,8205,16,256,8200,1344,5952]

theorem envBound58163 : H12AffineFastState.Bounded env58163 := by
  intro p hp
  have h : env58163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58162_58163 : H12AffineEnvironment.transform 15 9278 env58162 = env58163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9278 env58162 == env58163) = true)

def env58164 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,1,12556,8494,81,8623,4417,12557,4096,476,16,12606,12505,4112,4415,1,1,6516,8205,16,256,8200,80,4688]

theorem envBound58164 : H12AffineFastState.Bounded env58164 := by
  intro p hp
  have h : env58164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58163_58164 : H12AffineEnvironment.transform 9 272 env58163 = env58164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env58163 == env58164) = true)

theorem identity58164 : scanCanonicalize (H12AffineFastState.compose env58164 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 4445) := by decide +kernel

theorem selectedBound58164 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58165 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,4445,1,81,4211,81,4338,4417,80,4096,476,16,99,388,4112,4415,1,1,6516,4432,16,256,4437,80,4688]

theorem envBound58165 : H12AffineFastState.Bounded env58165 := by
  intro p hp
  have h : env58165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58164_58165 : H12AffineEnvironment.transform 12 4445 env58164 = env58165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4445 env58164 == env58165) = true)

theorem identity58165 : scanCanonicalize (H12AffineFastState.compose env58165 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound58165 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env58166 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,80,269,1,81,35,81,162,273,80,80,476,16,99,388,64,367,1,1,2340,256,16,256,261,80,512]

theorem envBound58166 : H12AffineFastState.Bounded env58166 := by
  intro p hp
  have h : env58166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58165_58166 : H12AffineEnvironment.transform 11 80 env58165 = env58166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env58165 == env58166) = true)

theorem identity58166 : scanCanonicalize (H12AffineFastState.compose env58166 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound58166 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env58167 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,1,269,1,0,35,0,162,273,1,1,397,16,50,388,17,318,1,1,2340,256,16,256,261,1,512]

theorem envBound58167 : H12AffineFastState.Bounded env58167 := by
  intro p hp
  have h : env58167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58166_58167 : H12AffineEnvironment.transform 5 17 env58166 = env58167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env58166 == env58167) = true)

theorem identity58167 : scanCanonicalize (H12AffineFastState.compose env58167 (packedSelected [1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound58167 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env58168 : List Nat := [2,4,8,16,32,17,128,256,0,272,2048,1,269,1,0,35,0,162,273,1,1,397,16,50,388,17,318,1,1,2340,256,16,256,261,1,0]

theorem envBound58168 : H12AffineFastState.Bounded env58168 := by
  intro p hp
  have h : env58168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58167_58168 : H12AffineEnvironment.transform 8 0 env58167 = env58168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env58167 == env58168) = true)

theorem identity58168 : scanCanonicalize (H12AffineFastState.compose env58168 (packedSelected [3,8] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound58168 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env58169 : List Nat := [2,4,8,16,32,17,128,256,0,272,26,1,269,1,0,35,0,162,273,1,1,397,16,50,388,17,318,1,1,318,256,16,256,261,1,0]

theorem envBound58169 : H12AffineFastState.Bounded env58169 := by
  intro p hp
  have h : env58169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58168_58169 : H12AffineEnvironment.transform 10 26 env58168 = env58169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env58168 == env58169) = true)

theorem identity58169 : scanCanonicalize (H12AffineFastState.compose env58169 (packedSelected [0,2,3,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound58169 : packedSelected [0,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env58170 : List Nat := [2,4,8,16,16,17,128,256,0,272,26,1,269,1,0,19,0,146,273,1,1,397,16,2,388,17,270,1,1,270,256,16,256,261,1,0]

theorem envBound58170 : H12AffineFastState.Bounded env58170 := by
  intro p hp
  have h : env58170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58169_58170 : H12AffineEnvironment.transform 4 16 env58169 = env58170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env58169 == env58170) = true)

theorem identity58170 : scanCanonicalize (H12AffineFastState.compose env58170 (packedSelected [1,9] rootPS)) = affineNative (2^(7+1) ^^^ 135) := by decide +kernel

theorem selectedBound58170 : packedSelected [1,9] rootPS < 2^1333 := by decide +kernel

def env58171 : List Nat := [2,4,8,16,16,17,128,135,0,151,26,1,138,1,0,19,0,146,150,1,1,10,16,2,3,17,137,1,1,137,135,16,135,130,1,0]

theorem envBound58171 : H12AffineFastState.Bounded env58171 := by
  intro p hp
  have h : env58171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58170_58171 : H12AffineEnvironment.transform 7 135 env58170 = env58171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 135 env58170 == env58171) = true)

def env58172 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,0,12557,8495,81,8622,4417,12556,4096,476,17,12607,12504,4112,4415,1,0,6516,8205,16,256,8200,81,4689]

theorem envBound58172 : H12AffineFastState.Bounded env58172 := by
  intro p hp
  have h : env58172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58163_58172 : H12AffineEnvironment.transform 9 273 env58163 = env58172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env58163 == env58172) = true)

theorem identity58172 : scanCanonicalize (H12AffineFastState.compose env58172 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 72) := by decide +kernel

theorem selectedBound58172 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58173 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,72,0,4421,359,81,486,4417,4420,4096,476,17,4471,4240,4112,4415,1,0,6516,69,16,256,64,81,4689]

theorem envBound58173 : H12AffineFastState.Bounded env58173 := by
  intro p hp
  have h : env58173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58172_58173 : H12AffineEnvironment.transform 12 72 env58172 = env58173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env58172 == env58173) = true)

theorem identity58173 : scanCanonicalize (H12AffineFastState.compose env58173 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(11+1) ^^^ 509) := by decide +kernel

theorem selectedBound58173 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env58174 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,509,72,0,184,359,81,486,188,185,509,476,17,138,365,493,194,1,0,2185,69,16,256,64,81,940]

theorem envBound58174 : H12AffineFastState.Bounded env58174 := by
  intro p hp
  have h : env58174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58173_58174 : H12AffineEnvironment.transform 11 509 env58173 = env58174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 509 env58173 == env58174) = true)

theorem identity58174 : scanCanonicalize (H12AffineFastState.compose env58174 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 217) := by decide +kernel

theorem selectedBound58174 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env58175 : List Nat := [2,4,8,16,32,64,128,256,217,273,2048,509,72,0,184,359,81,486,188,185,509,476,17,138,365,493,194,1,0,2185,69,16,256,64,81,373]

theorem envBound58175 : H12AffineFastState.Bounded env58175 := by
  intro p hp
  have h : env58175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58174_58175 : H12AffineEnvironment.transform 8 217 env58174 = env58175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env58174 == env58175) = true)

theorem identity58175 : scanCanonicalize (H12AffineFastState.compose env58175 (packedSelected [0,2,3,7,8,10,13,16] rootPS)) = affineNative (2^(7+1) ^^^ 111) := by decide +kernel

theorem selectedBound58175 : packedSelected [0,2,3,7,8,10,13,16] rootPS < 2^1333 := by decide +kernel

def env58176 : List Nat := [2,4,8,16,32,64,128,111,217,126,2048,146,72,0,184,8,81,137,188,185,146,179,17,138,2,130,194,1,0,2185,69,16,111,64,81,26]

theorem envBound58176 : H12AffineFastState.Bounded env58176 := by
  intro p hp
  have h : env58176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58175_58176 : H12AffineEnvironment.transform 7 111 env58175 = env58176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 111 env58175 == env58176) = true)

def env58177 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21585,32769,4096,61649,91183,123165,28889,78895,385203,90414,1296,96347,25884,74799,256,25881,1344,21072]

theorem envBound58177 : H12AffineFastState.Bounded env58177 := by
  intro p hp
  have h : env58177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58087_58177 : H12AffineEnvironment.transform 18 21585 env58087 = env58177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env58087 == env58177) = true)

theorem identity58177 : scanCanonicalize (H12AffineFastState.compose env58177 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25677) := by decide +kernel

theorem selectedBound58177 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env58178 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25677,65536,74863,262144,21585,25676,4096,5276,91183,66896,28889,78895,328958,90414,1296,96347,25884,74799,256,25881,1344,21072]

theorem envBound58178 : H12AffineFastState.Bounded env58178 := by
  intro p hp
  have h : env58178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58177_58178 : H12AffineEnvironment.transform 14 25677 env58177 = env58178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25677 env58177 == env58178) = true)

def env58179 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74863,262144,4417,8540,4096,5276,74047,66896,13769,78895,328958,74814,1296,81227,8204,74799,256,8201,1344,5952]

theorem envBound58179 : H12AffineFastState.Bounded env58179 := by
  intro p hp
  have h : env58179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58178_58179 : H12AffineEnvironment.transform 13 1296 env58178 = env58179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env58178 == env58179) = true)

def env58180 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74863,65664,4417,8540,4096,5276,74047,66896,13769,78895,1150,74814,1296,81227,8204,74799,256,8201,1344,5952]

theorem envBound58180 : H12AffineFastState.Bounded env58180 := by
  intro p hp
  have h : env58180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58179_58180 : H12AffineEnvironment.transform 17 65664 env58179 = env58180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env58179 == env58180) = true)

theorem identity58180 : scanCanonicalize (H12AffineFastState.compose env58180 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5238) := by decide +kernel

theorem selectedBound58180 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58181 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,5238,12313,5366,4417,8540,4096,5276,13641,4390,13769,8281,1150,12360,1296,10557,8204,12377,256,8201,1344,5952]

theorem envBound58181 : H12AffineFastState.Bounded env58181 := by
  intro p hp
  have h : env58181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58180_58181 : H12AffineEnvironment.transform 15 5238 env58180 = env58181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5238 env58180 == env58181) = true)

def env58182 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5464,1296,5125,5238,1345,5366,4417,5124,4096,5276,17,4390,145,5377,1150,1296,1296,7269,5460,1281,256,5457,1344,5952]

theorem envBound58182 : H12AffineFastState.Bounded env58182 := by
  intro p hp
  have h : env58182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58181_58182 : H12AffineEnvironment.transform 12 5464 env58181 = env58182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5464 env58181 == env58182) = true)

theorem identity58182 : scanCanonicalize (H12AffineFastState.compose env58182 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound58182 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58183 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,1369,1296,1028,1143,1345,1271,320,1029,1,1181,17,295,145,1280,1150,1296,1296,3172,1365,1281,256,1360,1344,1857]

theorem envBound58183 : H12AffineFastState.Bounded env58183 := by
  intro p hp
  have h : env58183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58182_58183 : H12AffineEnvironment.transform 11 1 env58182 = env58183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env58182 == env58183) = true)

theorem identity58183 : scanCanonicalize (H12AffineFastState.compose env58183 (packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 950) := by decide +kernel

theorem selectedBound58183 : packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env58184 : List Nat := [2,4,8,16,32,64,128,256,512,1024,950,1,1369,1296,1028,1143,1345,1271,320,1029,1,1181,17,295,145,1280,1150,1296,1296,2002,1365,1281,256,1360,1344,1857]

theorem envBound58184 : H12AffineFastState.Bounded env58184 := by
  intro p hp
  have h : env58184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58183_58184 : H12AffineEnvironment.transform 10 950 env58183 = env58184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 950 env58183 == env58184) = true)

theorem identity58184 : scanCanonicalize (H12AffineFastState.compose env58184 (packedSelected [0,1,2,4,5,7,9,10,11,13,23] rootPS)) = affineNative (2^(9+1) ^^^ 969) := by decide +kernel

theorem selectedBound58184 : packedSelected [0,1,2,4,5,7,9,10,11,13,23] rootPS < 2^1333 := by decide +kernel

def env58185 : List Nat := [2,4,8,16,32,64,128,256,512,969,950,1,656,729,973,958,648,830,320,972,1,852,17,295,145,713,951,729,729,27,668,712,256,665,649,136]

theorem envBound58185 : H12AffineFastState.Bounded env58185 := by
  intro p hp
  have h : env58185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58184_58185 : H12AffineEnvironment.transform 9 969 env58184 = env58185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 969 env58184 == env58185) = true)

theorem identity58185 : scanCanonicalize (H12AffineFastState.compose env58185 (packedSelected [1,8,11,15,16] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound58185 : packedSelected [1,8,11,15,16] rootPS < 2^1333 := by decide +kernel

def env58186 : List Nat := [2,4,8,16,32,64,128,256,292,237,146,1,436,509,233,154,428,26,320,232,1,112,17,295,145,493,147,509,509,27,440,492,256,445,429,136]

theorem envBound58186 : H12AffineFastState.Bounded env58186 := by
  intro p hp
  have h : env58186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58185_58186 : H12AffineEnvironment.transform 8 292 env58185 = env58186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env58185 == env58186) = true)

theorem identity58186 : scanCanonicalize (H12AffineFastState.compose env58186 (packedSelected [0,1,2,7,8,11] rootPS)) = affineNative (2^(6+1) ^^^ 104) := by decide +kernel

theorem selectedBound58186 : packedSelected [0,1,2,7,8,11] rootPS < 2^1333 := by decide +kernel

def env58187 : List Nat := [2,4,8,16,32,64,104,256,292,5,122,1,348,277,1,114,324,26,320,0,1,112,17,295,121,261,123,277,277,27,336,260,256,341,325,96]

theorem envBound58187 : H12AffineFastState.Bounded env58187 := by
  intro p hp
  have h : env58187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58186_58187 : H12AffineEnvironment.transform 6 104 env58186 = env58187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 104 env58186 == env58187) = true)

theorem identity58187 : scanCanonicalize (H12AffineFastState.compose env58187 (packedSelected [2,5,7,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound58187 : packedSelected [2,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env58188 : List Nat := [2,4,8,16,32,64,104,15,43,5,122,1,83,26,1,114,75,26,79,0,1,112,17,40,121,10,123,26,26,27,95,11,15,90,74,96]

theorem envBound58188 : H12AffineFastState.Bounded env58188 := by
  intro p hp
  have h : env58188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58187_58188 : H12AffineEnvironment.transform 7 15 env58187 = env58188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env58187 == env58188) = true)

theorem identity58188 : scanCanonicalize (H12AffineFastState.compose env58188 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound58188 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env58189 : List Nat := [2,4,8,16,32,59,19,15,43,5,1,1,40,26,1,9,48,26,52,0,1,11,17,40,2,10,0,26,26,27,36,11,15,33,49,27]

theorem envBound58189 : H12AffineFastState.Bounded env58189 := by
  intro p hp
  have h : env58189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58188_58189 : H12AffineEnvironment.transform 5 59 env58188 = env58189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env58188 == env58189) = true)

theorem identity58189 : scanCanonicalize (H12AffineFastState.compose env58189 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound58189 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env58190 : List Nat := [2,4,8,16,11,16,19,15,0,5,1,1,3,26,1,9,27,26,31,0,1,11,17,3,2,10,0,26,26,27,15,11,15,10,26,27]

theorem envBound58190 : H12AffineFastState.Bounded env58190 := by
  intro p hp
  have h : env58190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58189_58190 : H12AffineEnvironment.transform 4 11 env58189 = env58190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env58189 == env58190) = true)

theorem identity58190 : scanCanonicalize (H12AffineFastState.compose env58190 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound58190 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58191 : List Nat := [2,4,8,13,11,13,14,15,0,5,1,1,3,7,1,9,6,7,2,0,1,11,12,3,2,10,0,7,7,6,15,11,15,10,7,6]

theorem envBound58191 : H12AffineFastState.Bounded env58191 := by
  intro p hp
  have h : env58191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58190_58191 : H12AffineEnvironment.transform 3 13 env58190 = env58191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env58190 == env58191) = true)

theorem identity58191 : scanCanonicalize (H12AffineFastState.compose env58191 (packedSelected [4,7] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound58191 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env58192 : List Nat := [2,2,8,11,11,11,8,9,0,3,1,1,3,1,1,9,0,1,2,0,1,11,10,3,2,10,0,1,1,0,9,11,9,10,1,0]

theorem envBound58192 : H12AffineFastState.Bounded env58192 := by
  intro p hp
  have h : env58192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58191_58192 : H12AffineEnvironment.transform 1 2 env58191 = env58192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env58191 == env58192) = true)

def env58193 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5465,1296,5124,5238,1344,5366,4417,5125,4096,5276,16,4390,144,5376,1150,1297,1296,7268,5461,1280,256,5456,1344,5952]

theorem envBound58193 : H12AffineFastState.Bounded env58193 := by
  intro p hp
  have h : env58193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58181_58193 : H12AffineEnvironment.transform 12 5465 env58181 = env58193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5465 env58181 == env58193) = true)

theorem identity58193 : scanCanonicalize (H12AffineFastState.compose env58193 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1108) := by decide +kernel

theorem selectedBound58193 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58194 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1108,269,1296,80,34,1344,162,1301,81,1108,200,16,1394,144,340,1150,1297,1296,2096,257,1280,256,260,1344,788]

theorem envBound58194 : H12AffineFastState.Bounded env58194 := by
  intro p hp
  have h : env58194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58193_58194 : H12AffineEnvironment.transform 11 1108 env58193 = env58194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1108 env58193 == env58194) = true)

theorem identity58194 : scanCanonicalize (H12AffineFastState.compose env58194 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound58194 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env58195 : List Nat := [2,4,8,16,32,64,128,20,512,1024,2048,1108,25,1028,80,34,1108,162,1025,81,1108,200,16,1126,144,64,1150,1029,1028,2096,21,1044,20,16,1108,512]

theorem envBound58195 : H12AffineFastState.Bounded env58195 := by
  intro p hp
  have h : env58195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58194_58195 : H12AffineEnvironment.transform 7 20 env58194 = env58195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env58194 == env58195) = true)

theorem identity58195 : scanCanonicalize (H12AffineFastState.compose env58195 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound58195 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env58196 : List Nat := [2,4,8,16,32,16,128,20,512,1024,2048,1028,25,1028,0,34,1028,162,1025,1,1028,152,16,1078,144,16,1070,1029,1028,2096,21,1044,20,16,1028,512]

theorem envBound58196 : H12AffineFastState.Bounded env58196 := by
  intro p hp
  have h : env58196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58195_58196 : H12AffineEnvironment.transform 5 16 env58195 = env58196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env58195 == env58196) = true)

theorem identity58196 : scanCanonicalize (H12AffineFastState.compose env58196 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound58196 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env58197 : List Nat := [2,4,8,16,32,16,19,20,512,1024,2048,1028,25,1028,0,34,1028,49,1025,1,1028,11,16,1078,3,16,1070,1029,1028,2096,21,1044,20,16,1028,512]

theorem envBound58197 : H12AffineFastState.Bounded env58197 := by
  intro p hp
  have h : env58197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58196_58197 : H12AffineEnvironment.transform 6 19 env58196 = env58197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env58196 == env58197) = true)

theorem identity58197 : scanCanonicalize (H12AffineFastState.compose env58197 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 542) := by decide +kernel

theorem selectedBound58197 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env58198 : List Nat := [2,4,8,16,32,16,19,20,512,542,2048,538,25,538,0,34,538,49,543,1,538,11,16,552,3,16,560,539,538,2096,21,522,20,16,538,512]

theorem envBound58198 : H12AffineFastState.Bounded env58198 := by
  intro p hp
  have h : env58198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58197_58198 : H12AffineEnvironment.transform 9 542 env58197 = env58198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 542 env58197 == env58198) = true)

theorem identity58198 : scanCanonicalize (H12AffineFastState.compose env58198 (packedSelected [0,4,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 554) := by decide +kernel

theorem selectedBound58198 : packedSelected [0,4,5,7] rootPS < 2^1333 := by decide +kernel

def env58199 : List Nat := [2,4,8,16,32,16,19,20,512,542,554,538,25,538,0,34,538,49,543,1,538,11,16,552,3,16,560,539,538,538,21,522,20,16,538,512]

theorem envBound58199 : H12AffineFastState.Bounded env58199 := by
  intro p hp
  have h : env58199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58198_58199 : H12AffineEnvironment.transform 10 554 env58198 = env58199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 554 env58198 == env58199) = true)

theorem identity58199 : scanCanonicalize (H12AffineFastState.compose env58199 (packedSelected [0,1,2] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound58199 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env58200 : List Nat := [2,4,8,16,32,16,19,20,0,30,42,26,25,26,0,34,26,49,31,1,26,11,16,40,3,16,48,27,26,26,21,10,20,16,26,0]

theorem envBound58200 : H12AffineFastState.Bounded env58200 := by
  intro p hp
  have h : env58200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58199_58200 : H12AffineEnvironment.transform 8 0 env58199 = env58200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env58199 == env58200) = true)

theorem identity58200 : scanCanonicalize (H12AffineFastState.compose env58200 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound58200 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env58201 : List Nat := [2,4,8,11,32,11,8,15,0,5,42,1,2,1,0,34,1,42,4,1,1,11,11,40,3,11,43,0,1,1,14,10,15,11,1,0]

theorem envBound58201 : H12AffineFastState.Bounded env58201 := by
  intro p hp
  have h : env58201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58200_58201 : H12AffineEnvironment.transform 3 11 env58200 = env58201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env58200 == env58201) = true)

theorem identity58201 : scanCanonicalize (H12AffineFastState.compose env58201 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound58201 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58202 : List Nat := [2,4,8,11,12,11,8,15,0,5,6,1,2,1,0,14,1,6,4,1,1,11,11,4,3,11,7,0,1,1,14,10,15,11,1,0]

theorem envBound58202 : H12AffineFastState.Bounded env58202 := by
  intro p hp
  have h : env58202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58201_58202 : H12AffineEnvironment.transform 4 12 env58201 = env58202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env58201 == env58202) = true)

theorem identity58202 : scanCanonicalize (H12AffineFastState.compose env58202 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound58202 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58203 : List Nat := [2,2,8,11,10,11,8,9,0,3,0,1,2,1,0,8,1,0,2,1,1,11,11,2,3,11,1,0,1,1,8,10,9,11,1,0]

theorem envBound58203 : H12AffineFastState.Bounded env58203 := by
  intro p hp
  have h : env58203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58202_58203 : H12AffineEnvironment.transform 1 2 env58202 = env58203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env58202 == env58203) = true)

def env58204 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74863,65665,4417,8540,4096,5276,74047,66896,13769,78895,1151,74814,1296,81227,8204,74799,256,8201,1344,5952]

theorem envBound58204 : H12AffineFastState.Bounded env58204 := by
  intro p hp
  have h : env58204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58179_58204 : H12AffineEnvironment.transform 17 65665 env58179 = env58204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env58179 == env58204) = true)

theorem identity58204 : scanCanonicalize (H12AffineFastState.compose env58204 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 311) := by decide +kernel

theorem selectedBound58204 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58205 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,311,9560,438,4417,8540,4096,5276,8200,1127,13769,13592,1151,9481,1296,15484,8204,9496,256,8201,1344,5952]

theorem envBound58205 : H12AffineFastState.Bounded env58205 := by
  intro p hp
  have h : env58205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58204_58205 : H12AffineEnvironment.transform 15 311 env58204 = env58205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 311 env58204 == env58205) = true)

def env58206 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,24,1296,325,311,1344,438,4417,324,4096,5276,16,1127,5585,5376,1151,1297,1296,7268,20,1280,256,17,1344,5952]

theorem envBound58206 : H12AffineFastState.Bounded env58206 := by
  intro p hp
  have h : env58206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58205_58206 : H12AffineEnvironment.transform 12 24 env58205 = env58206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env58205 == env58206) = true)

theorem identity58206 : scanCanonicalize (H12AffineFastState.compose env58206 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound58206 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58207 : List Nat := [2,4,8,16,32,64,128,21,512,1024,2048,4096,24,1029,80,34,1109,163,4180,81,4096,5276,16,1127,5316,5141,1151,1028,1029,7268,20,1045,21,17,1109,5717]

theorem envBound58207 : H12AffineFastState.Bounded env58207 := by
  intro p hp
  have h : env58207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58206_58207 : H12AffineEnvironment.transform 7 21 env58206 = env58207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env58206 == env58207) = true)

theorem identity58207 : scanCanonicalize (H12AffineFastState.compose env58207 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 1109) := by decide +kernel

theorem selectedBound58207 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env58208 : List Nat := [2,4,8,16,32,64,128,21,512,1024,2048,1109,24,1029,80,34,1109,163,1025,81,1109,201,16,1127,145,64,1151,1028,1029,2097,20,1045,21,17,1109,512]

theorem envBound58208 : H12AffineFastState.Bounded env58208 := by
  intro p hp
  have h : env58208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58207_58208 : H12AffineEnvironment.transform 11 1109 env58207 = env58208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1109 env58207 == env58208) = true)

theorem identity58208 : scanCanonicalize (H12AffineFastState.compose env58208 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound58208 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env58209 : List Nat := [2,4,8,16,32,16,128,21,512,1024,2048,1029,24,1029,0,34,1029,163,1025,1,1029,153,16,1079,145,16,1071,1028,1029,2097,20,1045,21,17,1029,512]

theorem envBound58209 : H12AffineFastState.Bounded env58209 := by
  intro p hp
  have h : env58209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58208_58209 : H12AffineEnvironment.transform 5 16 env58208 = env58209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env58208 == env58209) = true)

theorem identity58209 : scanCanonicalize (H12AffineFastState.compose env58209 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound58209 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env58210 : List Nat := [2,4,8,16,32,16,128,21,512,47,2048,42,24,42,0,34,42,163,46,1,42,153,16,24,145,16,0,43,42,2097,20,58,21,17,42,512]

theorem envBound58210 : H12AffineFastState.Bounded env58210 := by
  intro p hp
  have h : env58210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58209_58210 : H12AffineEnvironment.transform 9 47 env58209 = env58210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env58209 == env58210) = true)

theorem identity58210 : scanCanonicalize (H12AffineFastState.compose env58210 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 163) := by decide +kernel

theorem selectedBound58210 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env58211 : List Nat := [2,4,8,16,32,16,128,21,163,47,2048,42,24,42,0,34,42,163,46,1,42,153,16,24,145,16,0,43,42,2097,20,58,21,17,42,163]

theorem envBound58211 : H12AffineFastState.Bounded env58211 := by
  intro p hp
  have h : env58211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58210_58211 : H12AffineEnvironment.transform 8 163 env58210 = env58211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 163 env58210 == env58211) = true)

theorem identity58211 : scanCanonicalize (H12AffineFastState.compose env58211 (packedSelected [2,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound58211 : packedSelected [2,5,7] rootPS < 2^1333 := by decide +kernel

def env58212 : List Nat := [2,4,8,16,32,16,19,21,48,47,2048,42,24,42,0,34,42,48,46,1,42,10,16,24,2,16,0,43,42,2097,20,58,21,17,42,48]

theorem envBound58212 : H12AffineFastState.Bounded env58212 := by
  intro p hp
  have h : env58212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58211_58212 : H12AffineEnvironment.transform 6 19 env58211 = env58212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env58211 == env58212) = true)

theorem identity58212 : scanCanonicalize (H12AffineFastState.compose env58212 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound58212 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58213 : List Nat := [2,4,8,16,32,16,19,21,48,47,0,42,24,42,0,34,42,48,46,1,42,10,16,24,2,16,0,43,42,49,20,58,21,17,42,48]

theorem envBound58213 : H12AffineFastState.Bounded env58213 := by
  intro p hp
  have h : env58213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58212_58213 : H12AffineEnvironment.transform 10 0 env58212 = env58213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env58212 == env58213) = true)

theorem identity58213 : scanCanonicalize (H12AffineFastState.compose env58213 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound58213 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env58214 : List Nat := [2,4,8,16,11,16,19,21,27,4,0,1,24,1,0,9,1,27,5,1,1,10,16,24,2,16,0,0,1,26,20,17,21,17,1,27]

theorem envBound58214 : H12AffineFastState.Bounded env58214 := by
  intro p hp
  have h : env58214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58213_58214 : H12AffineEnvironment.transform 4 11 env58213 = env58214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env58213 == env58214) = true)

theorem identity58214 : scanCanonicalize (H12AffineFastState.compose env58214 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound58214 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58215 : List Nat := [2,4,5,16,6,16,19,21,22,4,0,1,21,1,0,4,1,22,5,1,1,7,16,21,2,16,0,0,1,23,20,17,21,17,1,22]

theorem envBound58215 : H12AffineFastState.Bounded env58215 := by
  intro p hp
  have h : env58215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58214_58215 : H12AffineEnvironment.transform 2 5 env58214 = env58215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env58214 == env58215) = true)

theorem identity58215 : scanCanonicalize (H12AffineFastState.compose env58215 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound58215 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env58216 : List Nat := [2,4,5,6,6,6,5,3,0,4,0,1,3,1,0,4,1,0,5,1,1,7,6,3,2,6,0,0,1,1,2,7,3,7,1,0]

theorem envBound58216 : H12AffineFastState.Bounded env58216 := by
  intro p hp
  have h : env58216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58215_58216 : H12AffineEnvironment.transform 3 6 env58215 = env58216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env58215 == env58216) = true)

def env58217 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,25,1296,324,311,1345,438,4417,325,4096,5276,17,1127,5584,5377,1151,1296,1296,7269,21,1281,256,16,1344,5952]

theorem envBound58217 : H12AffineFastState.Bounded env58217 := by
  intro p hp
  have h : env58217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58205_58217 : H12AffineEnvironment.transform 12 25 env58205 = env58217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env58205 == env58217) = true)

theorem identity58217 : scanCanonicalize (H12AffineFastState.compose env58217 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound58217 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58218 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,25,80,324,311,1,438,4417,325,4096,4572,17,295,4240,4161,319,80,80,6437,21,65,256,16,0,4608]

theorem envBound58218 : H12AffineFastState.Bounded env58218 := by
  intro p hp
  have h : env58218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58217_58218 : H12AffineEnvironment.transform 9 320 env58217 = env58218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env58217 == env58218) = true)

theorem identity58218 : scanCanonicalize (H12AffineFastState.compose env58218 (packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS)) = affineNative (2^(11+1) ^^^ 2998) := by decide +kernel

theorem selectedBound58218 : packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env58219 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,2998,25,80,324,311,1,438,2807,325,2998,2666,17,295,2854,3063,319,80,80,659,21,65,256,16,0,2486]

theorem envBound58219 : H12AffineFastState.Bounded env58219 := by
  intro p hp
  have h : env58219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58218_58219 : H12AffineEnvironment.transform 11 2998 env58218 = env58219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2998 env58218 == env58219) = true)

theorem identity58219 : scanCanonicalize (H12AffineFastState.compose env58219 (packedSelected [0,1,2,4,5,7,9,10,11,13,23] rootPS)) = affineNative (2^(10+1) ^^^ 319) := by decide +kernel

theorem selectedBound58219 : packedSelected [0,1,2,4,5,7,9,10,11,13,23] rootPS < 2^1333 := by decide +kernel

def env58220 : List Nat := [2,4,8,16,32,64,128,256,512,320,319,649,25,80,324,311,1,438,968,325,649,853,17,295,537,712,319,80,80,659,21,65,256,16,0,137]

theorem envBound58220 : H12AffineFastState.Bounded env58220 := by
  intro p hp
  have h : env58220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58219_58220 : H12AffineEnvironment.transform 10 319 env58219 = env58220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 319 env58219 == env58220) = true)

theorem identity58220 : scanCanonicalize (H12AffineFastState.compose env58220 (packedSelected [4,9,13,16,17] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound58220 : packedSelected [4,9,13,16,17] rootPS < 2^1333 := by decide +kernel

def env58221 : List Nat := [2,4,8,16,32,64,128,69,512,5,122,649,25,80,1,114,1,243,653,0,649,528,17,98,537,712,122,80,80,659,21,65,69,16,0,137]

theorem envBound58221 : H12AffineFastState.Bounded env58221 := by
  intro p hp
  have h : env58221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58220_58221 : H12AffineEnvironment.transform 7 69 env58220 = env58221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env58220 == env58221) = true)

theorem identity58221 : scanCanonicalize (H12AffineFastState.compose env58221 (packedSelected [2,3,5,10,12,13] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound58221 : packedSelected [2,3,5,10,12,13] rootPS < 2^1333 := by decide +kernel

def env58222 : List Nat := [2,4,8,16,32,64,128,69,137,5,122,0,25,80,1,114,1,243,4,0,0,153,17,98,144,65,122,80,80,26,21,65,69,16,0,137]

theorem envBound58222 : H12AffineFastState.Bounded env58222 := by
  intro p hp
  have h : env58222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58221_58222 : H12AffineEnvironment.transform 8 137 env58221 = env58222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env58221 == env58222) = true)

theorem identity58222 : scanCanonicalize (H12AffineFastState.compose env58222 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 67) := by decide +kernel

theorem selectedBound58222 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env58223 : List Nat := [2,4,8,16,32,64,67,69,74,5,122,0,25,80,1,114,1,48,4,0,0,90,17,98,83,65,122,80,80,26,21,65,69,16,0,74]

theorem envBound58223 : H12AffineFastState.Bounded env58223 := by
  intro p hp
  have h : env58223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58222_58223 : H12AffineEnvironment.transform 6 67 env58222 = env58223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 67 env58222 == env58223) = true)

theorem identity58223 : scanCanonicalize (H12AffineFastState.compose env58223 (packedSelected [1,2,4] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound58223 : packedSelected [1,2,4] rootPS < 2^1333 := by decide +kernel

def env58224 : List Nat := [2,4,8,16,32,59,56,62,49,5,1,0,25,43,1,9,1,48,4,0,0,33,17,25,40,58,1,43,43,26,21,58,62,16,0,49]

theorem envBound58224 : H12AffineFastState.Bounded env58224 := by
  intro p hp
  have h : env58224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58223_58224 : H12AffineEnvironment.transform 5 59 env58223 = env58224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env58223 == env58224) = true)

theorem identity58224 : scanCanonicalize (H12AffineFastState.compose env58224 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound58224 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env58225 : List Nat := [2,4,8,16,16,11,8,14,1,5,1,0,25,27,1,9,1,0,4,0,0,17,17,25,24,10,1,27,27,26,21,10,14,16,0,1]

theorem envBound58225 : H12AffineFastState.Bounded env58225 := by
  intro p hp
  have h : env58225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58224_58225 : H12AffineEnvironment.transform 4 16 env58224 = env58225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env58224 == env58225) = true)

def env58226 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74863,262144,4416,8541,4096,5276,74046,66896,13768,78895,328958,74815,1296,81226,8205,74799,256,8200,1344,5953]

theorem envBound58226 : H12AffineFastState.Bounded env58226 := by
  intro p hp
  have h : env58226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58178_58226 : H12AffineEnvironment.transform 13 1297 env58178 = env58226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env58178 == env58226) = true)

def env58227 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74863,65664,4416,8541,4096,5276,74046,66896,13768,78895,1150,74815,1296,81226,8205,74799,256,8200,1344,5953]

theorem envBound58227 : H12AffineFastState.Bounded env58227 := by
  intro p hp
  have h : env58227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58226_58227 : H12AffineEnvironment.transform 17 65664 env58226 = env58227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env58226 == env58227) = true)

theorem identity58227 : scanCanonicalize (H12AffineFastState.compose env58227 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9279) := by decide +kernel

theorem selectedBound58227 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58228 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,9279,80,9407,4416,8541,4096,5276,1281,8559,13768,4112,1150,0,1296,6517,8205,16,256,8200,1344,5953]

theorem envBound58228 : H12AffineFastState.Bounded env58228 := by
  intro p hp
  have h : env58228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58227_58228 : H12AffineEnvironment.transform 15 9279 env58227 = env58228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9279 env58227 == env58228) = true)

def env58229 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,8540,9279,80,9407,1024,8541,1344,476,1281,8559,8328,1360,1150,0,1296,3125,8205,16,256,8200,1344,513]

theorem envBound58229 : H12AffineFastState.Bounded env58229 := by
  intro p hp
  have h : env58229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58228_58229 : H12AffineEnvironment.transform 11 1344 env58228 = env58229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env58228 == env58229) = true)

theorem identity58229 : scanCanonicalize (H12AffineFastState.compose env58229 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound58229 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env58230 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,269,1297,81,1330,80,1458,1024,80,1344,476,1281,98,389,1360,1150,0,1296,3125,256,16,256,261,1344,513]

theorem envBound58230 : H12AffineFastState.Bounded env58230 := by
  intro p hp
  have h : env58230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58229_58230 : H12AffineEnvironment.transform 12 269 env58229 = env58230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env58229 == env58230) = true)

theorem identity58230 : scanCanonicalize (H12AffineFastState.compose env58230 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound58230 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env58231 : List Nat := [2,4,8,16,32,64,128,69,512,1024,2048,1029,72,1108,81,1143,80,1271,1024,80,1029,153,1092,98,192,1045,1150,0,1109,3125,69,16,69,64,1029,513]

theorem envBound58231 : H12AffineFastState.Bounded env58231 := by
  intro p hp
  have h : env58231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58230_58231 : H12AffineEnvironment.transform 7 69 env58230 = env58231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env58230 == env58231) = true)

theorem identity58231 : scanCanonicalize (H12AffineFastState.compose env58231 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound58231 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env58232 : List Nat := [2,4,8,16,32,64,128,69,512,20,2048,17,72,64,81,99,80,227,20,80,17,153,80,98,192,1,106,0,65,2081,69,16,69,64,17,513]

theorem envBound58232 : H12AffineFastState.Bounded env58232 := by
  intro p hp
  have h : env58232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58231_58232 : H12AffineEnvironment.transform 9 20 env58231 = env58232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env58231 == env58232) = true)

theorem identity58232 : scanCanonicalize (H12AffineFastState.compose env58232 (packedSelected [2,12,13] rootPS)) = affineNative (2^(10+1) ^^^ 739) := by decide +kernel

theorem selectedBound58232 : packedSelected [2,12,13] rootPS < 2^1333 := by decide +kernel

def env58233 : List Nat := [2,4,8,16,32,64,128,69,512,20,739,17,72,64,81,99,80,227,20,80,17,153,80,98,192,1,106,0,65,706,69,16,69,64,17,513]

theorem envBound58233 : H12AffineFastState.Bounded env58233 := by
  intro p hp
  have h : env58233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58232_58233 : H12AffineEnvironment.transform 10 739 env58232 = env58233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 739 env58232 == env58233) = true)

theorem identity58233 : scanCanonicalize (H12AffineFastState.compose env58233 (packedSelected [0,3,7,8,11,12] rootPS)) = affineNative (2^(8+1) ^^^ 97) := by decide +kernel

theorem selectedBound58233 : packedSelected [0,3,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env58234 : List Nat := [2,4,8,16,32,64,128,69,97,20,130,17,72,64,81,99,80,227,20,80,17,153,80,98,192,1,106,0,65,163,69,16,69,64,17,96]

theorem envBound58234 : H12AffineFastState.Bounded env58234 := by
  intro p hp
  have h : env58234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58233_58234 : H12AffineEnvironment.transform 8 97 env58233 = env58234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env58233 == env58234) = true)

theorem identity58234 : scanCanonicalize (H12AffineFastState.compose env58234 (packedSelected [5] rootPS)) = affineNative (2^(6+1) ^^^ 126) := by decide +kernel

theorem selectedBound58234 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env58235 : List Nat := [2,4,8,16,32,64,126,69,97,20,124,17,72,64,81,99,80,29,20,80,17,103,80,98,62,1,106,0,65,93,69,16,69,64,17,96]

theorem envBound58235 : H12AffineFastState.Bounded env58235 := by
  intro p hp
  have h : env58235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58234_58235 : H12AffineEnvironment.transform 6 126 env58234 = env58235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 126 env58234 == env58235) = true)

theorem identity58235 : scanCanonicalize (H12AffineFastState.compose env58235 (packedSelected [0,1,7,8,11,15] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound58235 : packedSelected [0,1,7,8,11,15] rootPS < 2^1333 := by decide +kernel

def env58236 : List Nat := [2,4,8,1,32,64,111,69,97,5,109,0,72,64,64,99,65,12,5,65,0,103,65,98,47,1,106,0,65,76,69,1,69,64,0,96]

theorem envBound58236 : H12AffineFastState.Bounded env58236 := by
  intro p hp
  have h : env58236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58235_58236 : H12AffineEnvironment.transform 3 1 env58235 = env58236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env58235 == env58236) = true)

theorem identity58236 : scanCanonicalize (H12AffineFastState.compose env58236 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound58236 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env58237 : List Nat := [2,4,8,1,6,64,73,69,71,5,75,0,72,64,64,69,65,12,5,65,0,65,65,68,9,1,76,0,65,76,69,1,69,64,0,70]

theorem envBound58237 : H12AffineFastState.Bounded env58237 := by
  intro p hp
  have h : env58237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58236_58237 : H12AffineEnvironment.transform 4 6 env58236 = env58237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env58236 == env58237) = true)

theorem identity58237 : scanCanonicalize (H12AffineFastState.compose env58237 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound58237 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env58238 : List Nat := [2,4,8,1,6,11,2,14,12,5,0,0,3,11,11,14,10,12,5,10,0,10,10,15,9,1,7,0,10,7,14,1,14,11,0,13]

theorem envBound58238 : H12AffineFastState.Bounded env58238 := by
  intro p hp
  have h : env58238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58237_58238 : H12AffineEnvironment.transform 5 11 env58237 = env58238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env58237 == env58238) = true)

theorem identity58238 : scanCanonicalize (H12AffineFastState.compose env58238 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound58238 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58239 : List Nat := [2,4,0,1,6,3,2,6,4,5,0,0,3,3,3,6,2,4,5,2,0,2,2,7,1,1,7,0,2,7,6,1,6,3,0,5]

theorem envBound58239 : H12AffineFastState.Bounded env58239 := by
  intro p hp
  have h : env58239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58238_58239 : H12AffineEnvironment.transform 2 0 env58238 = env58239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env58238 == env58239) = true)

theorem identity58239 : scanCanonicalize (H12AffineFastState.compose env58239 (packedSelected [1,7] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound58239 : packedSelected [1,7] rootPS < 2^1333 := by decide +kernel

def env58240 : List Nat := [2,2,0,1,0,3,2,0,2,3,0,0,3,3,3,0,2,2,3,2,0,2,2,1,1,1,1,0,2,1,0,1,0,3,0,3]

theorem envBound58240 : H12AffineFastState.Bounded env58240 := by
  intro p hp
  have h : env58240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58239_58240 : H12AffineEnvironment.transform 1 2 env58239 = env58240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env58239 == env58240) = true)

theorem identity58240 : scanCanonicalize (H12AffineFastState.compose env58240 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound58240 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58241 : List Nat := [0,0,0,1,0,1,0,0,0,1,0,0,1,1,1,0,0,0,1,0,0,0,0,1,1,1,1,0,0,1,0,1,0,1,0,1]

theorem envBound58241 : H12AffineFastState.Bounded env58241 := by
  intro p hp
  have h : env58241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58240_58241 : H12AffineEnvironment.transform 0 0 env58240 = env58241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env58240 == env58241) = true)

def env58242 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,8540,9279,80,9407,1025,8541,1345,477,1281,8559,8329,1361,1150,0,1296,3124,8205,16,256,8200,1344,512]

theorem envBound58242 : H12AffineFastState.Bounded env58242 := by
  intro p hp
  have h : env58242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58228_58242 : H12AffineEnvironment.transform 11 1345 env58228 = env58242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env58228 == env58242) = true)

theorem identity58242 : scanCanonicalize (H12AffineFastState.compose env58242 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound58242 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env58243 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,1100,1297,1296,115,80,243,1025,1297,1345,477,1281,1315,1221,1361,1150,0,1296,3124,1089,16,256,1092,1344,512]

theorem envBound58243 : H12AffineFastState.Bounded env58243 := by
  intro p hp
  have h : env58243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58242_58243 : H12AffineEnvironment.transform 12 1100 env58242 = env58243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env58242 == env58243) = true)

theorem identity58243 : scanCanonicalize (H12AffineFastState.compose env58243 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound58243 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env58244 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,1052,1297,1296,35,0,163,1025,1297,1297,397,1281,1315,1173,1281,1070,0,1296,3124,1041,16,256,1044,1296,512]

theorem envBound58244 : H12AffineFastState.Bounded env58244 := by
  intro p hp
  have h : env58244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58243_58244 : H12AffineEnvironment.transform 5 16 env58243 = env58244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env58243 == env58244) = true)

theorem identity58244 : scanCanonicalize (H12AffineFastState.compose env58244 (packedSelected [2,13,17] rootPS)) = affineNative (2^(10+1) ^^^ 1725) := by decide +kernel

theorem selectedBound58244 : packedSelected [2,13,17] rootPS < 2^1333 := by decide +kernel

def env58245 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1725,1297,1052,1297,1296,35,0,163,1025,1297,1297,397,1281,1315,1173,1281,1070,0,1296,649,1041,16,256,1044,1296,512]

theorem envBound58245 : H12AffineFastState.Bounded env58245 := by
  intro p hp
  have h : env58245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58244_58245 : H12AffineEnvironment.transform 10 1725 env58244 = env58245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1725 env58244 == env58245) = true)

theorem identity58245 : scanCanonicalize (H12AffineFastState.compose env58245 (packedSelected [1,2,5] rootPS)) = affineNative (2^(9+1) ^^^ 288) := by decide +kernel

theorem selectedBound58245 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env58246 : List Nat := [2,4,8,16,32,16,128,256,512,288,925,49,316,49,48,35,0,163,289,49,49,397,33,3,437,33,270,0,48,649,305,16,256,308,48,512]

theorem envBound58246 : H12AffineFastState.Bounded env58246 := by
  intro p hp
  have h : env58246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58245_58246 : H12AffineEnvironment.transform 9 288 env58245 = env58246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 288 env58245 == env58246) = true)

theorem identity58246 : scanCanonicalize (H12AffineFastState.compose env58246 (packedSelected [2,3,8,10] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound58246 : packedSelected [2,3,8,10] rootPS < 2^1333 := by decide +kernel

def env58247 : List Nat := [2,4,8,16,32,16,128,256,136,288,277,49,316,49,48,35,0,163,289,49,49,397,33,3,437,33,270,0,48,1,305,16,256,308,48,136]

theorem envBound58247 : H12AffineFastState.Bounded env58247 := by
  intro p hp
  have h : env58247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58246_58247 : H12AffineEnvironment.transform 8 136 env58246 = env58247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env58246 == env58247) = true)

theorem identity58247 : scanCanonicalize (H12AffineFastState.compose env58247 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound58247 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env58248 : List Nat := [2,4,8,16,32,16,128,14,136,46,27,49,50,49,48,35,0,163,47,49,49,131,33,3,187,33,0,0,48,1,63,16,14,58,48,136]

theorem envBound58248 : H12AffineFastState.Bounded env58248 := by
  intro p hp
  have h : env58248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58247_58248 : H12AffineEnvironment.transform 7 14 env58247 = env58248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env58247 == env58248) = true)

theorem identity58248 : scanCanonicalize (H12AffineFastState.compose env58248 (packedSelected [0,2,4] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound58248 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env58249 : List Nat := [2,4,8,16,32,16,56,14,48,46,27,49,50,49,48,35,0,27,47,49,49,59,33,3,3,33,0,0,48,1,63,16,14,58,48,48]

theorem envBound58249 : H12AffineFastState.Bounded env58249 := by
  intro p hp
  have h : env58249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58248_58249 : H12AffineEnvironment.transform 6 56 env58248 = env58249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env58248 == env58249) = true)

theorem identity58249 : scanCanonicalize (H12AffineFastState.compose env58249 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound58249 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58250 : List Nat := [2,4,8,16,11,16,19,14,27,5,27,26,25,26,27,8,0,27,4,26,26,16,10,3,3,10,0,0,27,1,20,16,14,17,27,27]

theorem envBound58250 : H12AffineFastState.Bounded env58250 := by
  intro p hp
  have h : env58250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58249_58250 : H12AffineEnvironment.transform 4 11 env58249 = env58250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env58249 == env58250) = true)

theorem identity58250 : scanCanonicalize (H12AffineFastState.compose env58250 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound58250 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58251 : List Nat := [2,2,8,16,11,16,19,8,27,3,27,26,25,26,27,8,0,27,2,26,26,16,10,3,3,10,0,0,27,1,18,16,8,17,27,27]

theorem envBound58251 : H12AffineFastState.Bounded env58251 := by
  intro p hp
  have h : env58251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58250_58251 : H12AffineEnvironment.transform 1 2 env58250 = env58251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env58250 == env58251) = true)

theorem identity58251 : scanCanonicalize (H12AffineFastState.compose env58251 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound58251 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58252 : List Nat := [2,2,8,10,11,10,9,8,1,3,1,0,3,0,1,8,0,1,2,0,0,10,10,3,3,10,0,0,1,1,8,10,8,11,1,1]

theorem envBound58252 : H12AffineFastState.Bounded env58252 := by
  intro p hp
  have h : env58252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58251_58252 : H12AffineEnvironment.transform 3 10 env58251 = env58252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env58251 == env58252) = true)

def env58253 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74863,65665,4416,8541,4096,5276,74046,66896,13768,78895,1151,74815,1296,81226,8205,74799,256,8200,1344,5953]

theorem envBound58253 : H12AffineFastState.Bounded env58253 := by
  intro p hp
  have h : env58253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58226_58253 : H12AffineEnvironment.transform 17 65665 env58226 = env58253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env58226 == env58253) = true)

theorem identity58253 : scanCanonicalize (H12AffineFastState.compose env58253 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12671) := by decide +kernel

theorem selectedBound58253 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58254 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,12671,5392,12798,4416,8541,4096,5276,4161,13359,13768,1360,1151,5440,1296,3125,8205,5456,256,8200,1344,5953]

theorem envBound58254 : H12AffineFastState.Bounded env58254 := by
  intro p hp
  have h : env58254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58253_58254 : H12AffineEnvironment.transform 15 12671 env58253 = env58254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12671 env58253 == env58254) = true)

def env58255 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1297,8540,8495,1344,8622,272,8541,80,1228,17,9343,9624,1360,1151,1296,1296,3125,8205,1280,256,8200,1344,1809]

theorem envBound58255 : H12AffineFastState.Bounded env58255 := by
  intro p hp
  have h : env58255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58254_58255 : H12AffineEnvironment.transform 11 80 env58254 = env58255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env58254 == env58255) = true)

theorem identity58255 : scanCanonicalize (H12AffineFastState.compose env58255 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound58255 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58256 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,1053,1297,1345,1330,1344,1459,272,1344,80,1228,17,98,389,1360,1151,1296,1296,3125,1040,1280,256,1045,1344,1809]

theorem envBound58256 : H12AffineFastState.Bounded env58256 := by
  intro p hp
  have h : env58256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58255_58256 : H12AffineEnvironment.transform 12 1053 env58255 = env58256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env58255 == env58256) = true)

theorem identity58256 : scanCanonicalize (H12AffineFastState.compose env58256 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound58256 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env58257 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,80,268,0,80,35,81,162,272,81,80,477,17,98,389,65,366,1,1,2340,257,17,256,260,81,512]

theorem envBound58257 : H12AffineFastState.Bounded env58257 := by
  intro p hp
  have h : env58257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58256_58257 : H12AffineEnvironment.transform 9 273 env58256 = env58257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env58256 == env58257) = true)

theorem identity58257 : scanCanonicalize (H12AffineFastState.compose env58257 (packedSelected [2,5,8,13] rootPS)) = affineNative (2^(10+1) ^^^ 367) := by decide +kernel

theorem selectedBound58257 : packedSelected [2,5,8,13] rootPS < 2^1333 := by decide +kernel

def env58258 : List Nat := [2,4,8,16,32,64,128,256,512,273,367,80,268,0,80,35,81,162,272,81,80,477,17,98,389,65,366,1,1,75,257,17,256,260,81,512]

theorem envBound58258 : H12AffineFastState.Bounded env58258 := by
  intro p hp
  have h : env58258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58257_58258 : H12AffineEnvironment.transform 10 367 env58257 = env58258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 367 env58257 == env58258) = true)

theorem identity58258 : scanCanonicalize (H12AffineFastState.compose env58258 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound58258 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env58259 : List Nat := [2,4,8,16,32,64,128,256,136,273,367,80,268,0,80,35,81,162,272,81,80,477,17,98,389,65,366,1,1,75,257,17,256,260,81,136]

theorem envBound58259 : H12AffineFastState.Bounded env58259 := by
  intro p hp
  have h : env58259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58258_58259 : H12AffineEnvironment.transform 8 136 env58258 = env58259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env58258 == env58259) = true)

theorem identity58259 : scanCanonicalize (H12AffineFastState.compose env58259 (packedSelected [1,2,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound58259 : packedSelected [1,2,8,10] rootPS < 2^1333 := by decide +kernel

def env58260 : List Nat := [2,4,8,16,32,64,128,172,136,189,195,80,160,0,80,35,81,162,188,81,80,113,17,98,41,65,194,1,1,75,173,17,172,168,81,136]

theorem envBound58260 : H12AffineFastState.Bounded env58260 := by
  intro p hp
  have h : env58260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58259_58260 : H12AffineEnvironment.transform 7 172 env58259 = env58260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env58259 == env58260) = true)

theorem identity58260 : scanCanonicalize (H12AffineFastState.compose env58260 (packedSelected [2,4,5,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound58260 : packedSelected [2,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env58261 : List Nat := [2,4,8,16,32,64,88,116,80,101,27,80,120,0,80,35,81,122,100,81,80,113,17,98,41,65,26,1,1,75,117,17,116,112,81,80]

theorem envBound58261 : H12AffineFastState.Bounded env58261 := by
  intro p hp
  have h : env58261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58260_58261 : H12AffineEnvironment.transform 6 88 env58260 = env58261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env58260 == env58261) = true)

theorem identity58261 : scanCanonicalize (H12AffineFastState.compose env58261 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound58261 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env58262 : List Nat := [2,4,8,11,32,64,67,111,75,101,0,75,99,0,75,35,74,97,100,74,75,106,10,98,41,65,1,1,1,75,110,10,111,107,74,75]

theorem envBound58262 : H12AffineFastState.Bounded env58262 := by
  intro p hp
  have h : env58262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58261_58262 : H12AffineEnvironment.transform 3 11 env58261 = env58262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env58261 == env58262) = true)

theorem identity58262 : scanCanonicalize (H12AffineFastState.compose env58262 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound58262 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58263 : List Nat := [2,4,8,11,11,64,67,68,75,78,0,75,72,0,75,8,74,74,79,74,75,65,10,73,2,65,1,1,1,75,69,10,68,64,74,75]

theorem envBound58263 : H12AffineFastState.Bounded env58263 := by
  intro p hp
  have h : env58263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58262_58263 : H12AffineEnvironment.transform 4 11 env58262 = env58263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env58262 == env58263) = true)

def env58264 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1297,8540,8494,1345,8623,273,8541,81,1229,16,9342,9625,1360,1151,1297,1296,3125,8205,1281,256,8200,1344,1808]

theorem envBound58264 : H12AffineFastState.Bounded env58264 := by
  intro p hp
  have h : env58264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58254_58264 : H12AffineEnvironment.transform 11 81 env58254 = env58264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env58254 == env58264) = true)

theorem identity58264 : scanCanonicalize (H12AffineFastState.compose env58264 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 72) := by decide +kernel

theorem selectedBound58264 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58265 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,72,1297,276,358,1345,487,273,277,81,1229,16,1078,1489,1360,1151,1297,1296,3125,69,1281,256,64,1344,1808]

theorem envBound58265 : H12AffineFastState.Bounded env58265 := by
  intro p hp
  have h : env58265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58264_58265 : H12AffineEnvironment.transform 12 72 env58264 = env58265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env58264 == env58265) = true)

theorem identity58265 : scanCanonicalize (H12AffineFastState.compose env58265 (packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS)) = affineNative (2^(9+1) ^^^ 652) := by decide +kernel

theorem selectedBound58265 : packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS < 2^1333 := by decide +kernel

def env58266 : List Nat := [2,4,8,16,32,64,128,256,512,652,2048,81,72,925,276,358,973,487,273,277,81,577,16,698,861,988,755,925,924,2745,69,909,256,64,972,412]

theorem envBound58266 : H12AffineFastState.Bounded env58266 := by
  intro p hp
  have h : env58266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58265_58266 : H12AffineEnvironment.transform 9 652 env58265 = env58266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 652 env58265 == env58266) = true)

theorem identity58266 : scanCanonicalize (H12AffineFastState.compose env58266 (packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound58266 : packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS < 2^1333 := by decide +kernel

def env58267 : List Nat := [2,4,8,16,32,64,128,21,512,652,2048,81,72,648,1,115,728,242,4,0,81,577,16,698,584,713,755,648,649,2745,69,664,21,64,729,137]

theorem envBound58267 : H12AffineFastState.Bounded env58267 := by
  intro p hp
  have h : env58267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58266_58267 : H12AffineEnvironment.transform 7 21 env58266 = env58267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env58266 == env58267) = true)

theorem identity58267 : scanCanonicalize (H12AffineFastState.compose env58267 (packedSelected [2,3,4,5,9,10,15,16,17] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound58267 : packedSelected [2,3,4,5,9,10,15,16,17] rootPS < 2^1333 := by decide +kernel

def env58268 : List Nat := [2,4,8,16,32,64,128,21,512,652,561,81,72,648,1,115,728,242,4,0,81,577,16,698,584,713,755,648,649,136,69,664,21,64,729,137]

theorem envBound58268 : H12AffineFastState.Bounded env58268 := by
  intro p hp
  have h : env58268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58267_58268 : H12AffineEnvironment.transform 10 561 env58267 = env58268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env58267 == env58268) = true)

theorem identity58268 : scanCanonicalize (H12AffineFastState.compose env58268 (packedSelected [0,1,2,3,7,10,11,13,15] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound58268 : packedSelected [0,1,2,3,7,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env58269 : List Nat := [2,4,8,16,32,64,34,21,512,558,561,81,72,554,1,115,634,80,4,0,81,577,16,536,584,619,593,554,555,42,69,570,21,64,635,43]

theorem envBound58269 : H12AffineFastState.Bounded env58269 := by
  intro p hp
  have h : env58269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58268_58269 : H12AffineEnvironment.transform 6 34 env58268 = env58269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env58268 == env58269) = true)

theorem identity58269 : scanCanonicalize (H12AffineFastState.compose env58269 (packedSelected [1,2,4,5,9] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound58269 : packedSelected [1,2,4,5,9] rootPS < 2^1333 := by decide +kernel

def env58270 : List Nat := [2,4,8,16,32,64,34,21,48,30,1,81,72,26,1,115,74,80,4,0,81,113,16,40,120,91,97,26,27,42,69,10,21,64,75,43]

theorem envBound58270 : H12AffineFastState.Bounded env58270 := by
  intro p hp
  have h : env58270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58269_58270 : H12AffineEnvironment.transform 8 48 env58269 = env58270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env58269 == env58270) = true)

theorem identity58270 : scanCanonicalize (H12AffineFastState.compose env58270 (packedSelected [1,2,8] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound58270 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env58271 : List Nat := [2,4,8,16,32,59,34,21,48,30,1,42,51,26,1,8,49,43,4,0,42,10,16,40,3,32,26,26,27,42,62,10,21,59,48,43]

theorem envBound58271 : H12AffineFastState.Bounded env58271 := by
  intro p hp
  have h : env58271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58270_58271 : H12AffineEnvironment.transform 5 59 env58270 = env58271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env58270 == env58271) = true)

theorem identity58271 : scanCanonicalize (H12AffineFastState.compose env58271 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound58271 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58272 : List Nat := [2,4,8,11,32,32,34,14,43,5,1,42,40,1,1,8,42,43,4,0,42,10,11,40,3,32,1,1,0,42,37,10,14,32,43,43]

theorem envBound58272 : H12AffineFastState.Bounded env58272 := by
  intro p hp
  have h : env58272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58271_58272 : H12AffineEnvironment.transform 3 11 env58271 = env58272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env58271 == env58272) = true)

theorem identity58272 : scanCanonicalize (H12AffineFastState.compose env58272 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound58272 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env58273 : List Nat := [2,4,8,11,11,11,9,14,0,5,1,1,3,1,1,8,1,0,4,0,1,10,11,3,3,11,1,1,0,1,14,10,14,11,0,0]

theorem envBound58273 : H12AffineFastState.Bounded env58273 := by
  intro p hp
  have h : env58273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58272_58273 : H12AffineEnvironment.transform 4 11 env58272 = env58273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env58272 == env58273) = true)

theorem identity58273 : scanCanonicalize (H12AffineFastState.compose env58273 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound58273 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58274 : List Nat := [2,2,8,11,11,11,9,8,0,3,1,1,3,1,1,8,1,0,2,0,1,10,11,3,3,11,1,1,0,1,8,10,8,11,0,0]

theorem envBound58274 : H12AffineFastState.Bounded env58274 := by
  intro p hp
  have h : env58274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58273_58274 : H12AffineEnvironment.transform 1 2 env58273 = env58274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env58273 == env58274) = true)

def env58275 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,533641,672785,134217728,148801,545088,96347,16876544,618622,257,16876549,151462017,525824]

theorem envBound58275 : H12AffineFastState.Bounded env58275 := by
  intro p hp
  have h : env58275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57194_58275 : H12AffineEnvironment.transform 24 533641 env57194 = env58275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533641 env57194 == env58275) = true)

def env58276 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,533641,672785,17245632,148801,545088,96347,16876544,618622,257,16876549,1345,525824]

theorem envBound58276 : H12AffineFastState.Bounded env58276 := by
  intro p hp
  have h : env58276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58275_58276 : H12AffineEnvironment.transform 26 17245632 env58275 = env58276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env58275 == env58276) = true)

theorem identity58276 : scanCanonicalize (H12AffineFastState.compose env58276 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 717115) := by decide +kernel

theorem selectedBound58276 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env58277 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,717115,533641,672785,906491,148801,545088,96347,750907,618622,257,750910,1345,525824]

theorem envBound58277 : H12AffineFastState.Bounded env58277 := by
  intro p hp
  have h : env58277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58276_58277 : H12AffineEnvironment.transform 23 717115 env58276 = env58277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 717115 env58276 == env58277) = true)

def env58278 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147520,58683,143497,20497,508155,148801,148800,96347,90427,222334,257,90430,1345,135680]

theorem envBound58278 : H12AffineFastState.Bounded env58278 := by
  intro p hp
  have h : env58278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58277_58278 : H12AffineEnvironment.transform 18 136192 env58277 = env58278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env58277 == env58278) = true)

def env58279 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147520,58519,143497,20497,508155,148717,148716,96347,90263,222334,173,90258,1261,135680]

theorem envBound58279 : H12AffineFastState.Bounded env58279 := by
  intro p hp
  have h : env58279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58278_58279 : H12AffineEnvironment.transform 7 172 env58278 = env58279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env58278 == env58279) = true)

def env58280 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147472,58519,143497,20497,508075,148669,148668,96267,90263,222254,173,90258,1213,135680]

theorem envBound58280 : H12AffineFastState.Bounded env58280 := by
  intro p hp
  have h : env58280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58279_58280 : H12AffineEnvironment.transform 5 16 env58279 = env58280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env58279 == env58280) = true)

theorem identity58280 : scanCanonicalize (H12AffineFastState.compose env58280 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 137352) := by decide +kernel

theorem selectedBound58280 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env58281 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137352,136192,32769,4096,61569,147472,58519,143497,20497,120867,148669,148668,96267,90263,222254,173,90258,1213,135680]

theorem envBound58281 : H12AffineFastState.Bounded env58281 := by
  intro p hp
  have h : env58281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58280_58281 : H12AffineEnvironment.transform 17 137352 env58280 = env58281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137352 env58280 == env58281) = true)

theorem identity58281 : scanCanonicalize (H12AffineFastState.compose env58281 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(16+1) ^^^ 62492) := by decide +kernel

theorem selectedBound58281 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env58282 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,62492,60564,57372,32769,4096,61569,46092,58519,50325,20497,120867,45217,45216,96267,90263,102450,173,90258,1213,58908]

theorem envBound58282 : H12AffineFastState.Bounded env58282 := by
  intro p hp
  have h : env58282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58281_58282 : H12AffineEnvironment.transform 16 62492 env58281 = env58282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 62492 env58281 == env58282) = true)

theorem identity58282 : scanCanonicalize (H12AffineFastState.compose env58282 (packedSelected [4,9,16] rootPS)) = affineNative (2^(14+1) ^^^ 29861) := by decide +kernel

theorem selectedBound58282 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env58283 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,29861,65536,185,6193,5305,29860,4096,1060,16553,4146,12336,20497,76934,17412,17413,96267,90263,91287,173,90258,1213,4793]

theorem envBound58283 : H12AffineFastState.Bounded env58283 := by
  intro p hp
  have h : env58283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58282_58283 : H12AffineEnvironment.transform 14 29861 env58282 = env58283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29861 env58282 == env58283) = true)

theorem identity58283 : scanCanonicalize (H12AffineFastState.compose env58283 (packedSelected [0,2,3,5,6,7,10,13,20] rootPS)) = affineNative (2^(15+1) ^^^ 6674) := by decide +kernel

theorem selectedBound58283 : packedSelected [0,2,3,5,6,7,10,13,20] rootPS < 2^1333 := by decide +kernel

def env58284 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,29861,6674,185,6193,5305,29860,4096,1060,16553,4146,12336,20497,13972,17412,17413,25113,31365,32389,173,31360,1213,4793]

theorem envBound58284 : H12AffineFastState.Bounded env58284 := by
  intro p hp
  have h : env58284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58283_58284 : H12AffineEnvironment.transform 15 6674 env58283 = env58284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 6674 env58283 == env58284) = true)

theorem identity58284 : scanCanonicalize (H12AffineFastState.compose env58284 (packedSelected [17,18,19,21,23,26] rootPS)) = affineNative (2^(12+1) ^^^ 7829) := by decide +kernel

theorem selectedBound58284 : packedSelected [17,18,19,21,23,26] rootPS < 2^1333 := by decide +kernel

def env58285 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,7829,16384,18992,6674,185,6193,5305,18993,4096,1060,16553,4146,3749,20497,2049,17412,17413,23692,17424,16400,173,17429,1213,4793]

theorem envBound58285 : H12AffineFastState.Bounded env58285 := by
  intro p hp
  have h : env58285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58284_58285 : H12AffineEnvironment.transform 12 7829 env58284 = env58285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7829 env58284 == env58285) = true)

theorem identity58285 : scanCanonicalize (H12AffineFastState.compose env58285 (packedSelected [0,1,3,5,8,9,11,13,17] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound58285 : packedSelected [0,1,3,5,8,9,11,13,17] rootPS < 2^1333 := by decide +kernel

def env58286 : List Nat := [2,4,8,16,32,16,128,172,136,1024,2048,4096,7197,16384,18616,6298,185,6193,5305,18617,4096,1060,16553,4146,3117,20497,2049,17412,17413,23692,17424,16400,173,17429,1213,4145]

theorem envBound58286 : H12AffineFastState.Bounded env58286 := by
  intro p hp
  have h : env58286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58285_58286 : H12AffineEnvironment.transform 8 136 env58285 = env58286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env58285 == env58286) = true)

theorem identity58286 : scanCanonicalize (H12AffineFastState.compose env58286 (packedSelected [2,4,5,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 162) := by decide +kernel

theorem selectedBound58286 : packedSelected [2,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env58287 : List Nat := [2,4,8,16,32,16,128,172,136,1024,162,4096,5311,16384,16410,4152,185,4243,5305,16411,4096,1060,16553,4146,1167,20497,163,17412,17413,21550,17424,16400,173,17429,1213,4145]

theorem envBound58287 : H12AffineFastState.Bounded env58287 := by
  intro p hp
  have h : env58287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58286_58287 : H12AffineEnvironment.transform 10 162 env58286 = env58287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 162 env58286 == env58287) = true)

theorem identity58287 : scanCanonicalize (H12AffineFastState.compose env58287 (packedSelected [0,1,2,5,6,7,10] rootPS)) = affineNative (2^(9+1) ^^^ 31) := by decide +kernel

theorem selectedBound58287 : packedSelected [0,1,2,5,6,7,10] rootPS < 2^1333 := by decide +kernel

def env58288 : List Nat := [2,4,8,16,32,16,128,172,136,31,162,4096,4256,16384,16410,4152,185,4243,4262,16411,4096,59,16553,4146,144,20497,163,16411,16410,20529,16399,16400,173,16394,162,4145]

theorem envBound58288 : H12AffineFastState.Bounded env58288 := by
  intro p hp
  have h : env58288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58287_58288 : H12AffineEnvironment.transform 9 31 env58287 = env58288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 31 env58287 == env58288) = true)

theorem identity58288 : scanCanonicalize (H12AffineFastState.compose env58288 (packedSelected [1,2,4,5,9] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound58288 : packedSelected [1,2,4,5,9] rootPS < 2^1333 := by decide +kernel

def env58289 : List Nat := [2,4,8,16,32,16,128,172,136,31,162,184,24,16384,16410,128,185,43,30,16411,184,59,16553,138,144,16553,163,16411,16410,16521,16399,16400,173,16394,162,137]

theorem envBound58289 : H12AffineFastState.Bounded env58289 := by
  intro p hp
  have h : env58289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58288_58289 : H12AffineEnvironment.transform 11 184 env58288 = env58289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env58288 == env58289) = true)

theorem identity58289 : scanCanonicalize (H12AffineFastState.compose env58289 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(13+1) ^^^ 58) := by decide +kernel

theorem selectedBound58289 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env58290 : List Nat := [2,4,8,16,32,16,128,172,136,31,162,184,24,58,32,128,185,43,30,33,184,59,147,138,144,147,163,33,32,179,53,42,173,48,162,137]

theorem envBound58290 : H12AffineFastState.Bounded env58290 := by
  intro p hp
  have h : env58290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58289_58290 : H12AffineEnvironment.transform 13 58 env58289 = env58290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 58 env58289 == env58290) = true)

theorem identity58290 : scanCanonicalize (H12AffineFastState.compose env58290 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound58290 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env58291 : List Nat := [2,4,8,16,32,16,8,36,0,31,42,48,24,58,32,8,49,43,30,33,48,59,27,2,24,27,43,33,32,59,53,42,37,48,42,1]

theorem envBound58291 : H12AffineFastState.Bounded env58291 := by
  intro p hp
  have h : env58291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58290_58291 : H12AffineEnvironment.transform 6 8 env58290 = env58291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env58290 == env58291) = true)

theorem identity58291 : scanCanonicalize (H12AffineFastState.compose env58291 (packedSelected [0,1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound58291 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env58292 : List Nat := [0,4,8,16,32,16,8,36,0,29,40,48,24,56,32,8,49,41,28,33,48,57,25,0,24,25,41,33,32,57,53,40,37,48,40,1]

theorem envBound58292 : H12AffineFastState.Bounded env58292 := by
  intro p hp
  have h : env58292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58291_58292 : H12AffineEnvironment.transform 0 0 env58291 = env58292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env58291 == env58292) = true)

theorem identity58292 : scanCanonicalize (H12AffineFastState.compose env58292 (packedSelected [2,3,4] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound58292 : packedSelected [2,3,4] rootPS < 2^1333 := by decide +kernel

def env58293 : List Nat := [0,4,1,16,32,16,1,36,0,20,33,48,17,49,32,1,49,32,21,33,48,48,16,0,17,16,32,33,32,48,53,33,37,48,33,1]

theorem envBound58293 : H12AffineFastState.Bounded env58293 := by
  intro p hp
  have h : env58293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58292_58293 : H12AffineEnvironment.transform 2 1 env58292 = env58293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env58292 == env58293) = true)

theorem identity58293 : scanCanonicalize (H12AffineFastState.compose env58293 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound58293 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58294 : List Nat := [0,1,1,16,32,16,1,33,0,17,33,48,17,49,32,1,49,32,16,33,48,48,16,0,17,16,32,33,32,48,48,33,32,48,33,1]

theorem envBound58294 : H12AffineFastState.Bounded env58294 := by
  intro p hp
  have h : env58294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58293_58294 : H12AffineEnvironment.transform 1 1 env58293 = env58294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env58293 == env58294) = true)

theorem identity58294 : scanCanonicalize (H12AffineFastState.compose env58294 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound58294 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env58295 : List Nat := [0,1,1,16,17,16,1,16,0,17,16,1,17,0,17,1,0,17,16,16,1,1,16,0,17,16,17,16,17,1,1,16,17,1,16,1]

theorem envBound58295 : H12AffineFastState.Bounded env58295 := by
  intro p hp
  have h : env58295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58294_58295 : H12AffineEnvironment.transform 4 17 env58294 = env58295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env58294 == env58295) = true)

def env58296 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147473,58519,143497,20497,508074,148668,148669,96266,90263,222255,173,90258,1212,135680]

theorem envBound58296 : H12AffineFastState.Bounded env58296 := by
  intro p hp
  have h : env58296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58279_58296 : H12AffineEnvironment.transform 5 17 env58279 = env58296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env58279 == env58296) = true)

theorem identity58296 : scanCanonicalize (H12AffineFastState.compose env58296 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound58296 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env58297 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,45216,262144,42144,32769,4096,61568,61617,58519,32809,20497,356362,62492,62493,96266,90263,119951,173,90258,1212,41632]

theorem envBound58297 : H12AffineFastState.Bounded env58297 := by
  intro p hp
  have h : env58297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58296_58297 : H12AffineEnvironment.transform 16 45216 env58296 = env58297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env58296 == env58297) = true)

theorem identity58297 : scanCanonicalize (H12AffineFastState.compose env58297 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound58297 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env58298 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,45216,2185,42144,32769,4096,61568,61617,58519,32809,20497,96387,62492,62493,96266,90263,119951,173,90258,1212,41632]

theorem envBound58298 : H12AffineFastState.Bounded env58298 := by
  intro p hp
  have h : env58298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58297_58298 : H12AffineEnvironment.transform 17 2185 env58297 = env58298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env58297 == env58298) = true)

theorem identity58298 : scanCanonicalize (H12AffineFastState.compose env58298 (packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 24634) := by decide +kernel

theorem selectedBound58298 : packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env58299 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,24634,45216,2185,42144,32769,4096,61568,61617,58519,32809,20497,6329,62492,62493,6192,173,46261,173,168,1212,41632]

theorem envBound58299 : H12AffineFastState.Bounded env58299 := by
  intro p hp
  have h : env58299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58298_58299 : H12AffineEnvironment.transform 15 24634 env58298 = env58299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24634 env58298 == env58299) = true)

theorem identity58299 : scanCanonicalize (H12AffineFastState.compose env58299 (packedSelected [1,4,5,8,9,16,17,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound58299 : packedSelected [1,4,5,8,9,16,17,21,24] rootPS < 2^1333 := by decide +kernel

def env58300 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,5124,32768,13374,45216,2185,42144,32769,4096,42116,42165,45203,32809,1045,6329,40984,40985,6192,173,46261,173,168,1212,41632]

theorem envBound58300 : H12AffineFastState.Bounded env58300 := by
  intro p hp
  have h : env58300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58299_58300 : H12AffineEnvironment.transform 13 5124 env58299 = env58300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env58299 == env58300) = true)

theorem identity58300 : scanCanonicalize (H12AffineFastState.compose env58300 (packedSelected [2,3,5,6,10,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 7684) := by decide +kernel

theorem selectedBound58300 : packedSelected [2,3,5,6,10,15,17] rootPS < 2^1333 := by decide +kernel

def env58301 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,5124,7684,13374,11940,2185,15012,7685,4096,14976,15025,11927,7725,1045,6329,15900,15901,6192,173,10929,173,168,1212,15524]

theorem envBound58301 : H12AffineFastState.Bounded env58301 := by
  intro p hp
  have h : env58301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58300_58301 : H12AffineEnvironment.transform 14 7684 env58300 = env58301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7684 env58300 == env58301) = true)

theorem identity58301 : scanCanonicalize (H12AffineFastState.compose env58301 (packedSelected [3,4,5,6,7,12,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 5284) := by decide +kernel

theorem selectedBound58301 : packedSelected [3,4,5,6,7,12,15,16] rootPS < 2^1333 := by decide +kernel

def env58302 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,5284,5124,7684,154,6656,2185,3584,7685,4096,3620,3605,6707,7725,1045,6329,2744,2745,6192,173,7701,173,168,1212,2048]

theorem envBound58302 : H12AffineFastState.Bounded env58302 := by
  intro p hp
  have h : env58302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58301_58302 : H12AffineEnvironment.transform 12 5284 env58301 = env58302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5284 env58301 == env58302) = true)

theorem identity58302 : scanCanonicalize (H12AffineFastState.compose env58302 (packedSelected [0,4,11] rootPS)) = affineNative (2^(11+1) ^^^ 3213) := by decide +kernel

theorem selectedBound58302 : packedSelected [0,4,11] rootPS < 2^1333 := by decide +kernel

def env58303 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,3213,2089,2185,649,154,1677,2185,3584,648,3213,3620,3605,1726,672,1045,1076,2744,2745,1213,173,664,173,168,1212,2048]

theorem envBound58303 : H12AffineFastState.Bounded env58303 := by
  intro p hp
  have h : env58303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58302_58303 : H12AffineEnvironment.transform 11 3213 env58302 = env58303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3213 env58302 == env58303) = true)

theorem identity58303 : scanCanonicalize (H12AffineFastState.compose env58303 (packedSelected [0,1,3,6,7,10] rootPS)) = affineNative (2^(9+1) ^^^ 167) := by decide +kernel

theorem selectedBound58303 : packedSelected [0,1,3,6,7,10] rootPS < 2^1333 := by decide +kernel

def env58304 : List Nat := [2,4,8,16,32,17,128,172,512,167,2048,2090,2089,2185,649,154,554,2185,2727,648,2090,2691,2738,537,672,178,147,2744,2745,26,173,664,173,168,27,2048]

theorem envBound58304 : H12AffineFastState.Bounded env58304 := by
  intro p hp
  have h : env58304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58303_58304 : H12AffineEnvironment.transform 9 167 env58303 = env58304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 167 env58303 == env58304) = true)

theorem identity58304 : scanCanonicalize (H12AffineFastState.compose env58304 (packedSelected [3,4,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound58304 : packedSelected [3,4,8,9] rootPS < 2^1333 := by decide +kernel

def env58305 : List Nat := [2,4,8,16,32,17,9,37,512,46,2048,2090,2089,2048,512,19,554,2048,2606,513,2090,2570,2619,537,553,59,26,2609,2608,26,36,529,36,33,27,2048]

theorem envBound58305 : H12AffineFastState.Bounded env58305 := by
  intro p hp
  have h : env58305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58304_58305 : H12AffineEnvironment.transform 6 9 env58304 = env58305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env58304 == env58305) = true)

theorem identity58305 : scanCanonicalize (H12AffineFastState.compose env58305 (packedSelected [1,2,4,5,6,7] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound58305 : packedSelected [1,2,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env58306 : List Nat := [2,4,8,16,16,17,9,21,512,30,2048,2074,2073,2048,512,19,538,2048,2590,513,2074,2570,2571,537,537,11,26,2561,2560,26,20,529,20,17,27,2048]

theorem envBound58306 : H12AffineFastState.Bounded env58306 := by
  intro p hp
  have h : env58306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58305_58306 : H12AffineEnvironment.transform 4 16 env58305 = env58306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env58305 == env58306) = true)

theorem identity58306 : scanCanonicalize (H12AffineFastState.compose env58306 (packedSelected [6] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound58306 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58307 : List Nat := [2,4,8,16,16,17,9,21,0,30,2048,2074,2073,2048,0,19,26,2048,2078,1,2074,2058,2059,25,25,11,26,2049,2048,26,20,17,20,17,27,2048]

theorem envBound58307 : H12AffineFastState.Bounded env58307 := by
  intro p hp
  have h : env58307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58306_58307 : H12AffineEnvironment.transform 8 0 env58306 = env58307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env58306 == env58307) = true)

theorem identity58307 : scanCanonicalize (H12AffineFastState.compose env58307 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound58307 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58308 : List Nat := [2,4,8,16,16,17,9,21,0,30,0,26,25,0,0,19,26,0,30,1,26,10,11,25,25,11,26,1,0,26,20,17,20,17,27,0]

theorem envBound58308 : H12AffineFastState.Bounded env58308 := by
  intro p hp
  have h : env58308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58307_58308 : H12AffineEnvironment.transform 10 0 env58307 = env58308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env58307 == env58308) = true)

theorem identity58308 : scanCanonicalize (H12AffineFastState.compose env58308 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound58308 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env58309 : List Nat := [2,4,8,11,11,10,9,14,0,5,0,1,2,0,0,8,1,0,5,1,1,10,11,2,2,11,1,1,0,1,15,10,15,10,0,0]

theorem envBound58309 : H12AffineFastState.Bounded env58309 := by
  intro p hp
  have h : env58309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58308_58309 : H12AffineEnvironment.transform 3 11 env58308 = env58309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env58308 == env58309) = true)

theorem identity58309 : scanCanonicalize (H12AffineFastState.compose env58309 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound58309 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58310 : List Nat := [2,3,8,11,11,10,9,9,0,2,0,1,2,0,0,8,1,0,2,1,1,10,11,2,2,11,1,1,0,1,8,10,8,10,0,0]

theorem envBound58310 : H12AffineFastState.Bounded env58310 := by
  intro p hp
  have h : env58310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58309_58310 : H12AffineEnvironment.transform 1 3 env58309 = env58310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env58309 == env58310) = true)

def env58311 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147520,58518,143497,20497,508155,148716,148717,96347,90262,222334,172,90259,1260,135680]

theorem envBound58311 : H12AffineFastState.Bounded env58311 := by
  intro p hp
  have h : env58311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58278_58311 : H12AffineEnvironment.transform 7 173 env58278 = env58311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env58278 == env58311) = true)

def env58312 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147472,58518,143497,20497,508075,148668,148669,96267,90262,222254,172,90259,1212,135680]

theorem envBound58312 : H12AffineFastState.Bounded env58312 := by
  intro p hp
  have h : env58312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58311_58312 : H12AffineEnvironment.transform 5 16 env58311 = env58312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env58311 == env58312) = true)

theorem identity58312 : scanCanonicalize (H12AffineFastState.compose env58312 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 208055) := by decide +kernel

theorem selectedBound58312 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env58313 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,208055,136192,32769,4096,61569,147472,58518,143497,20497,60444,148668,148669,96267,90262,222254,172,90259,1212,135680]

theorem envBound58313 : H12AffineFastState.Bounded env58313 := by
  intro p hp
  have h : env58313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58312_58313 : H12AffineEnvironment.transform 17 208055 env58312 = env58313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 208055 env58312 == env58313) = true)

theorem identity58313 : scanCanonicalize (H12AffineFastState.compose env58313 (packedSelected [1,3,5,7,8,10,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound58313 : packedSelected [1,3,5,7,8,10,20,26,27] rootPS < 2^1333 := by decide +kernel

def env58314 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,53283,131072,195732,136192,32769,4096,61569,147472,58518,143497,20497,60444,148668,148669,43048,45237,177165,172,45232,1212,135680]

theorem envBound58314 : H12AffineFastState.Bounded env58314 := by
  intro p hp
  have h : env58314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58313_58314 : H12AffineEnvironment.transform 15 53283 env58313 = env58314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env58313 == env58314) = true)

theorem identity58314 : scanCanonicalize (H12AffineFastState.compose env58314 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 21692) := by decide +kernel

theorem selectedBound58314 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env58315 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,53283,21692,43048,16572,32769,4096,61569,5292,58518,25653,20497,60444,4096,4097,43048,45237,57521,172,45232,1212,18108]

theorem envBound58315 : H12AffineFastState.Bounded env58315 := by
  intro p hp
  have h : env58315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58314_58315 : H12AffineEnvironment.transform 16 21692 env58314 = env58315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21692 env58314 == env58315) = true)

end H12CloudChart2