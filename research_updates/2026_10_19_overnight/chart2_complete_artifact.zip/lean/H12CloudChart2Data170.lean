import H12CloudChart2Data169

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity42545 : scanCanonicalize (H12AffineFastState.compose env42545 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 37) := by decide +kernel

theorem selectedBound42545 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env42546 : List Nat := [2,4,8,6,32,33,37,3,32,35,6,1,40,38,1,46,42,10,35,0,0,12,44,40,4,11,43,13,39,10,37,32,2,11,0,32]

theorem envBound42546 : H12AffineFastState.Bounded env42546 := by
  intro p hp
  have h : env42546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42545_42546 : H12AffineEnvironment.transform 6 37 env42545 = env42546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 37 env42545 == env42546) = true)

theorem identity42546 : scanCanonicalize (H12AffineFastState.compose env42546 (packedSelected [0,2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound42546 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env42547 : List Nat := [2,3,8,1,32,33,34,3,32,35,1,1,40,33,1,41,42,10,35,0,0,11,43,40,3,11,43,10,32,10,34,32,2,11,0,32]

theorem envBound42547 : H12AffineFastState.Bounded env42547 := by
  intro p hp
  have h : env42547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42546_42547 : H12AffineEnvironment.transform 1 3 env42546 = env42547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env42546 == env42547) = true)

theorem identity42547 : scanCanonicalize (H12AffineFastState.compose env42547 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound42547 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42548 : List Nat := [2,3,3,1,32,33,34,3,32,35,1,1,35,33,1,34,33,1,35,0,0,0,32,35,3,0,32,1,32,1,34,32,2,0,0,32]

theorem envBound42548 : H12AffineFastState.Bounded env42548 := by
  intro p hp
  have h : env42548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42547_42548 : H12AffineEnvironment.transform 2 3 env42547 = env42548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env42547 == env42548) = true)

theorem identity42548 : scanCanonicalize (H12AffineFastState.compose env42548 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound42548 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env42549 : List Nat := [2,3,3,1,1,0,3,3,1,2,1,1,2,0,1,3,0,1,2,0,0,0,1,2,3,0,1,1,1,1,3,1,2,0,0,1]

theorem envBound42549 : H12AffineFastState.Bounded env42549 := by
  intro p hp
  have h : env42549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42548_42549 : H12AffineEnvironment.transform 4 1 env42548 = env42549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env42548 == env42549) = true)

def env42550 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,4096,5385,1296,276,65536,69991,65665,4416,277,4097,477,70710,69649,192,65830,4415,69943,1297,67651,5380,5377,257,69927,1345,5141]

theorem envBound42550 : H12AffineFastState.Bounded env42550 := by
  intro p hp
  have h : env42550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42527_42550 : H12AffineEnvironment.transform 8 341 env42527 = env42550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env42527 == env42550) = true)

def env42551 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,0,1289,1296,276,65536,65895,65665,320,277,1,477,66614,65553,192,65830,319,65847,1297,67651,1284,1281,257,65831,1345,1045]

theorem envBound42551 : H12AffineFastState.Bounded env42551 := by
  intro p hp
  have h : env42551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42550_42551 : H12AffineEnvironment.transform 11 0 env42550 = env42551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env42550 == env42551) = true)

theorem identity42551 : scanCanonicalize (H12AffineFastState.compose env42551 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound42551 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env42552 : List Nat := [2,4,8,16,32,64,128,20,65,1024,2048,0,1053,1028,0,65536,65651,65665,84,1,1,201,66614,65553,192,65586,43,65571,1029,67651,1040,1045,21,65587,1109,1045]

theorem envBound42552 : H12AffineFastState.Bounded env42552 := by
  intro p hp
  have h : env42552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42551_42552 : H12AffineEnvironment.transform 7 20 env42551 = env42552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env42551 == env42552) = true)

theorem identity42552 : scanCanonicalize (H12AffineFastState.compose env42552 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound42552 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env42553 : List Nat := [2,4,8,16,32,64,128,20,65,4,2048,0,25,0,0,65536,65651,65665,84,1,1,201,65586,65553,192,65586,43,65571,1,67651,20,17,21,65587,81,17]

theorem envBound42553 : H12AffineFastState.Bounded env42553 := by
  intro p hp
  have h : env42553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42552_42553 : H12AffineEnvironment.transform 9 4 env42552 = env42553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env42552 == env42553) = true)

theorem identity42553 : scanCanonicalize (H12AffineFastState.compose env42553 (packedSelected [8,13,15] rootPS)) = affineNative (2^(15+1) ^^^ 2100) := by decide +kernel

theorem selectedBound42553 : packedSelected [8,13,15] rootPS < 2^1333 := by decide +kernel

def env42554 : List Nat := [2,4,8,16,32,64,128,20,65,4,2048,0,25,0,0,2100,2119,2229,84,1,1,201,2054,2085,192,2054,43,2071,1,119,20,17,21,2055,81,17]

theorem envBound42554 : H12AffineFastState.Bounded env42554 := by
  intro p hp
  have h : env42554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42553_42554 : H12AffineEnvironment.transform 15 2100 env42553 = env42554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2100 env42553 == env42554) = true)

theorem identity42554 : scanCanonicalize (H12AffineFastState.compose env42554 (packedSelected [0,1,7,8,10,11,12,17] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound42554 : packedSelected [0,1,7,8,10,11,12,17] rootPS < 2^1333 := by decide +kernel

def env42555 : List Nat := [2,4,8,16,32,64,34,20,65,4,2048,0,25,0,0,2100,2119,2071,84,1,1,107,2054,2085,98,2054,43,2071,1,119,20,17,21,2055,81,17]

theorem envBound42555 : H12AffineFastState.Bounded env42555 := by
  intro p hp
  have h : env42555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42554_42555 : H12AffineEnvironment.transform 6 34 env42554 = env42555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env42554 == env42555) = true)

theorem identity42555 : scanCanonicalize (H12AffineFastState.compose env42555 (packedSelected [0,2,7,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 125) := by decide +kernel

theorem selectedBound42555 : packedSelected [0,2,7,11,13] rootPS < 2^1333 := by decide +kernel

def env42556 : List Nat := [2,4,8,16,32,64,34,20,65,4,125,0,25,0,0,73,58,106,84,1,1,107,123,88,98,123,43,106,1,119,20,17,21,122,81,17]

theorem envBound42556 : H12AffineFastState.Bounded env42556 := by
  intro p hp
  have h : env42556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42555_42556 : H12AffineEnvironment.transform 10 125 env42555 = env42556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 125 env42555 == env42556) = true)

theorem identity42556 : scanCanonicalize (H12AffineFastState.compose env42556 (packedSelected [10] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound42556 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env42557 : List Nat := [2,4,8,12,32,64,34,8,65,4,97,0,5,0,0,73,38,106,72,1,1,107,103,68,98,103,43,106,1,107,8,13,9,102,77,13]

theorem envBound42557 : H12AffineFastState.Bounded env42557 := by
  intro p hp
  have h : env42557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42556_42557 : H12AffineEnvironment.transform 3 12 env42556 = env42557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env42556 == env42557) = true)

theorem identity42557 : scanCanonicalize (H12AffineFastState.compose env42557 (packedSelected [2,5] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound42557 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env42558 : List Nat := [2,4,8,12,32,33,34,8,32,4,0,0,5,0,0,40,38,11,41,1,1,10,6,37,3,6,43,11,1,10,8,13,9,7,44,13]

theorem envBound42558 : H12AffineFastState.Bounded env42558 := by
  intro p hp
  have h : env42558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42557_42558 : H12AffineEnvironment.transform 5 33 env42557 = env42558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env42557 == env42558) = true)

theorem identity42558 : scanCanonicalize (H12AffineFastState.compose env42558 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound42558 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env42559 : List Nat := [2,4,8,12,13,12,15,8,13,4,0,0,5,0,0,5,11,11,4,1,1,10,6,8,3,6,6,11,1,10,8,13,9,7,1,13]

theorem envBound42559 : H12AffineFastState.Bounded env42559 := by
  intro p hp
  have h : env42559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42558_42559 : H12AffineEnvironment.transform 4 13 env42558 = env42559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env42558 == env42559) = true)

theorem identity42559 : scanCanonicalize (H12AffineFastState.compose env42559 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound42559 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42560 : List Nat := [2,4,5,1,0,1,2,5,0,4,0,0,5,0,0,5,6,6,4,1,1,7,6,5,3,6,6,6,1,7,5,0,4,7,1,0]

theorem envBound42560 : H12AffineFastState.Bounded env42560 := by
  intro p hp
  have h : env42560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42559_42560 : H12AffineEnvironment.transform 2 5 env42559 = env42560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env42559 == env42560) = true)

theorem identity42560 : scanCanonicalize (H12AffineFastState.compose env42560 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound42560 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42561 : List Nat := [2,3,2,1,0,1,2,2,0,3,0,0,2,0,0,2,1,1,3,1,1,0,1,2,3,1,1,1,1,0,2,0,3,0,1,0]

theorem envBound42561 : H12AffineFastState.Bounded env42561 := by
  intro p hp
  have h : env42561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42560_42561 : H12AffineEnvironment.transform 1 3 env42560 = env42561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env42560 == env42561) = true)

def env42562 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,1,1288,1296,276,65536,65894,65665,321,277,0,477,66615,65552,192,65830,318,65846,1297,67651,1285,1280,257,65830,1345,1044]

theorem envBound42562 : H12AffineFastState.Bounded env42562 := by
  intro p hp
  have h : env42562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42550_42562 : H12AffineEnvironment.transform 11 1 env42550 = env42562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env42550 == env42562) = true)

theorem identity42562 : scanCanonicalize (H12AffineFastState.compose env42562 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound42562 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env42563 : List Nat := [2,4,8,16,32,64,128,256,341,84,2048,1,348,324,276,65536,65894,65665,321,277,0,477,65635,65552,192,65830,318,65846,325,67651,337,340,257,65830,277,64]

theorem envBound42563 : H12AffineFastState.Bounded env42563 := by
  intro p hp
  have h : env42563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42562_42563 : H12AffineEnvironment.transform 9 84 env42562 = env42563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env42562 == env42563) = true)

theorem identity42563 : scanCanonicalize (H12AffineFastState.compose env42563 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(15+1) ^^^ 2364) := by decide +kernel

theorem selectedBound42563 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env42564 : List Nat := [2,4,8,16,32,64,128,256,341,84,2048,1,348,324,276,2364,2138,2493,321,277,0,477,2399,2348,192,2074,318,2058,325,383,337,340,257,2074,277,64]

theorem envBound42564 : H12AffineFastState.Bounded env42564 := by
  intro p hp
  have h : env42564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42563_42564 : H12AffineEnvironment.transform 15 2364 env42563 = env42564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2364 env42563 == env42564) = true)

theorem identity42564 : scanCanonicalize (H12AffineFastState.compose env42564 (packedSelected [0,1,5,7,8,10,11,15,17] rootPS)) = affineNative (2^(6+1) ^^^ 111) := by decide +kernel

theorem selectedBound42564 : packedSelected [0,1,5,7,8,10,11,15,17] rootPS < 2^1333 := by decide +kernel

def env42565 : List Nat := [2,4,8,16,32,64,111,256,341,84,2048,1,348,324,276,2364,2138,2386,321,277,0,306,2399,2348,47,2074,318,2058,325,383,337,340,257,2074,277,64]

theorem envBound42565 : H12AffineFastState.Bounded env42565 := by
  intro p hp
  have h : env42565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42564_42565 : H12AffineEnvironment.transform 6 111 env42564 = env42565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 111 env42564 == env42565) = true)

theorem identity42565 : scanCanonicalize (H12AffineFastState.compose env42565 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound42565 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env42566 : List Nat := [2,4,8,16,32,64,111,21,64,84,2048,1,73,81,1,2089,2138,2119,84,0,0,39,2122,2105,47,2074,43,2058,80,106,68,65,20,2074,0,64]

theorem envBound42566 : H12AffineFastState.Bounded env42566 := by
  intro p hp
  have h : env42566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42565_42566 : H12AffineEnvironment.transform 7 21 env42565 = env42566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env42565 == env42566) = true)

theorem identity42566 : scanCanonicalize (H12AffineFastState.compose env42566 (packedSelected [3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 45) := by decide +kernel

theorem selectedBound42566 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42567 : List Nat := [2,4,8,16,32,64,111,21,64,84,45,1,73,81,1,4,119,106,84,0,0,39,103,20,47,55,43,39,80,106,68,65,20,55,0,64]

theorem envBound42567 : H12AffineFastState.Bounded env42567 := by
  intro p hp
  have h : env42567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42566_42567 : H12AffineEnvironment.transform 10 45 env42566 = env42567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 45 env42566 == env42567) = true)

theorem identity42567 : scanCanonicalize (H12AffineFastState.compose env42567 (packedSelected [1,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound42567 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env42568 : List Nat := [2,4,8,16,32,33,14,21,33,53,45,1,40,48,1,4,22,11,53,0,0,39,6,20,47,55,43,39,49,11,37,32,20,55,0,33]

theorem envBound42568 : H12AffineFastState.Bounded env42568 := by
  intro p hp
  have h : env42568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42567_42568 : H12AffineEnvironment.transform 5 33 env42567 = env42568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env42567 == env42568) = true)

theorem identity42568 : scanCanonicalize (H12AffineFastState.compose env42568 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound42568 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env42569 : List Nat := [2,4,8,16,28,29,14,21,29,9,17,1,20,12,1,4,22,11,9,0,0,27,6,20,19,11,23,27,13,11,25,28,20,11,0,29]

theorem envBound42569 : H12AffineFastState.Bounded env42569 := by
  intro p hp
  have h : env42569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42568_42569 : H12AffineEnvironment.transform 4 28 env42568 = env42569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env42568 == env42569) = true)

theorem identity42569 : scanCanonicalize (H12AffineFastState.compose env42569 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound42569 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env42570 : List Nat := [2,4,8,0,12,13,14,5,13,9,1,1,4,12,1,4,6,11,9,0,0,11,6,4,3,11,7,11,13,11,9,12,4,11,0,13]

theorem envBound42570 : H12AffineFastState.Bounded env42570 := by
  intro p hp
  have h : env42570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42569_42570 : H12AffineEnvironment.transform 3 0 env42569 = env42570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env42569 == env42570) = true)

theorem identity42570 : scanCanonicalize (H12AffineFastState.compose env42570 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound42570 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42571 : List Nat := [2,4,2,0,6,7,4,5,7,3,1,1,4,6,1,4,6,1,3,0,0,1,6,4,3,1,7,1,7,1,3,6,4,1,0,7]

theorem envBound42571 : H12AffineFastState.Bounded env42571 := by
  intro p hp
  have h : env42571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42570_42571 : H12AffineEnvironment.transform 2 2 env42570 = env42571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env42570 == env42571) = true)

theorem identity42571 : scanCanonicalize (H12AffineFastState.compose env42571 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound42571 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env42572 : List Nat := [2,2,2,0,0,1,2,3,1,3,1,1,2,0,1,2,0,1,3,0,0,1,0,2,3,1,1,1,1,1,3,0,2,1,0,1]

theorem envBound42572 : H12AffineFastState.Bounded env42572 := by
  intro p hp
  have h : env42572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42571_42572 : H12AffineEnvironment.transform 1 2 env42571 = env42572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env42571 == env42572) = true)

def env42573 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74862,262144,4417,13340,4097,476,74046,69648,13768,78895,332223,74815,1297,81227,8204,8201,257,74798,1345,5953]

theorem envBound42573 : H12AffineFastState.Bounded env42573 := by
  intro p hp
  have h : env42573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42481_42573 : H12AffineEnvironment.transform 13 1297 env42481 = env42573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env42481 == env42573) = true)

def env42574 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74862,65664,4417,13340,4097,476,74046,69648,13768,78895,4415,74815,1297,81227,8204,8201,257,74798,1345,5953]

theorem envBound42574 : H12AffineFastState.Bounded env42574 := by
  intro p hp
  have h : env42574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42573_42574 : H12AffineEnvironment.transform 17 65664 env42573 = env42574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env42573 == env42574) = true)

theorem identity42574 : scanCanonicalize (H12AffineFastState.compose env42574 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound42574 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env42575 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1297,9245,65536,74862,65664,321,9244,1,476,74046,65552,9672,74799,319,74815,1297,77131,8204,8201,257,74798,1345,1857]

theorem envBound42575 : H12AffineFastState.Bounded env42575 := by
  intro p hp
  have h : env42575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42574_42575 : H12AffineEnvironment.transform 11 0 env42574 = env42575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env42574 == env42575) = true)

def env42576 : List Nat := [2,4,8,16,32,64,128,256,340,1024,2048,0,8192,1297,9245,65536,74862,65664,321,9244,1,476,74046,65552,9672,74799,319,74815,1297,77131,8204,8201,257,74798,1345,1045]

theorem envBound42576 : H12AffineFastState.Bounded env42576 := by
  intro p hp
  have h : env42576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42575_42576 : H12AffineEnvironment.transform 8 340 env42575 = env42576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env42575 == env42576) = true)

def env42577 : List Nat := [2,4,8,0,32,64,128,256,324,1024,2048,0,8192,1281,9229,65536,74862,65664,321,9228,1,460,74030,65536,9672,74799,303,74799,1281,77131,8204,8201,257,74798,1345,1029]

theorem envBound42577 : H12AffineFastState.Bounded env42577 := by
  intro p hp
  have h : env42577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42576_42577 : H12AffineEnvironment.transform 3 0 env42576 = env42577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env42576 == env42577) = true)

theorem identity42577 : scanCanonicalize (H12AffineFastState.compose env42577 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 1348) := by decide +kernel

theorem selectedBound42577 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env42578 : List Nat := [2,4,8,0,32,64,128,256,324,1024,2048,0,8192,1281,9229,1348,8490,1476,321,9228,1,460,9322,1348,9672,8555,303,8555,1281,10255,8204,8201,257,8554,1345,1029]

theorem envBound42578 : H12AffineFastState.Bounded env42578 := by
  intro p hp
  have h : env42578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42577_42578 : H12AffineEnvironment.transform 15 1348 env42577 = env42578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1348 env42577 == env42578) = true)

def env42579 : List Nat := [2,4,8,0,32,64,128,256,324,1024,2048,0,1288,1281,261,1348,1058,1476,321,260,1,460,354,1348,192,1123,303,1123,1281,3335,1284,1281,257,1122,1345,1029]

theorem envBound42579 : H12AffineFastState.Bounded env42579 := by
  intro p hp
  have h : env42579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42578_42579 : H12AffineEnvironment.transform 12 1288 env42578 = env42579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1288 env42578 == env42579) = true)

theorem identity42579 : scanCanonicalize (H12AffineFastState.compose env42579 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound42579 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env42580 : List Nat := [2,4,8,0,32,64,128,5,65,1024,2048,0,1037,1028,0,1089,1058,1217,68,1,1,201,103,1089,192,1123,42,1123,1028,3074,1025,1028,4,1122,1092,1029]

theorem envBound42580 : H12AffineFastState.Bounded env42580 := by
  intro p hp
  have h : env42580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42579_42580 : H12AffineEnvironment.transform 7 5 env42579 = env42580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env42579 == env42580) = true)

theorem identity42580 : scanCanonicalize (H12AffineFastState.compose env42580 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound42580 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env42581 : List Nat := [2,4,8,0,32,0,128,5,1,1024,2048,0,1037,1028,0,1025,1058,1153,4,1,1,137,39,1025,128,1059,42,1059,1028,3074,1025,1028,4,1058,1028,1029]

theorem envBound42581 : H12AffineFastState.Bounded env42581 := by
  intro p hp
  have h : env42581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42580_42581 : H12AffineEnvironment.transform 5 0 env42580 = env42581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env42580 == env42581) = true)

theorem identity42581 : scanCanonicalize (H12AffineFastState.compose env42581 (packedSelected [0,1,7,8,10,11,12,13] rootPS)) = affineNative (2^(10+1) ^^^ 175) := by decide +kernel

theorem selectedBound42581 : packedSelected [0,1,7,8,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env42582 : List Nat := [2,4,8,0,32,0,128,5,1,1024,175,0,1037,1028,0,1025,1058,1153,4,1,1,137,39,1025,128,1059,42,1059,1028,1197,1025,1028,4,1058,1028,1029]

theorem envBound42582 : H12AffineFastState.Bounded env42582 := by
  intro p hp
  have h : env42582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42581_42582 : H12AffineEnvironment.transform 10 175 env42581 = env42582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 175 env42581 == env42582) = true)

theorem identity42582 : scanCanonicalize (H12AffineFastState.compose env42582 (packedSelected [1,2] rootPS)) = affineNative (2^(9+1) ^^^ 3) := by decide +kernel

theorem selectedBound42582 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env42583 : List Nat := [2,4,8,0,32,0,128,5,1,3,175,0,14,7,0,2,33,130,4,1,1,137,39,2,128,32,42,32,7,174,2,7,4,33,7,6]

theorem envBound42583 : H12AffineFastState.Bounded env42583 := by
  intro p hp
  have h : env42583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42582_42583 : H12AffineEnvironment.transform 9 3 env42582 = env42583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 3 env42582 == env42583) = true)

theorem identity42583 : scanCanonicalize (H12AffineFastState.compose env42583 (packedSelected [4,9] rootPS)) = affineNative (2^(6+1) ^^^ 37) := by decide +kernel

theorem selectedBound42583 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env42584 : List Nat := [2,4,8,0,32,0,37,5,1,3,10,0,14,7,0,2,33,39,4,1,1,44,39,2,37,32,42,32,7,11,2,7,4,33,7,6]

theorem envBound42584 : H12AffineFastState.Bounded env42584 := by
  intro p hp
  have h : env42584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42583_42584 : H12AffineEnvironment.transform 6 37 env42583 = env42584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 37 env42583 == env42584) = true)

theorem identity42584 : scanCanonicalize (H12AffineFastState.compose env42584 (packedSelected [0,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound42584 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env42585 : List Nat := [2,4,8,0,13,0,8,5,1,3,10,0,14,7,0,2,12,10,4,1,1,1,10,2,8,13,7,13,7,11,2,7,4,12,7,6]

theorem envBound42585 : H12AffineFastState.Bounded env42585 := by
  intro p hp
  have h : env42585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42584_42585 : H12AffineEnvironment.transform 4 13 env42584 = env42585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env42584 == env42585) = true)

theorem identity42585 : scanCanonicalize (H12AffineFastState.compose env42585 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound42585 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42586 : List Nat := [2,4,3,0,6,0,3,5,1,3,1,0,5,7,0,2,7,1,4,1,1,1,1,2,3,6,7,6,7,0,2,7,4,7,7,6]

theorem envBound42586 : H12AffineFastState.Bounded env42586 := by
  intro p hp
  have h : env42586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42585_42586 : H12AffineEnvironment.transform 2 3 env42585 = env42586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env42585 == env42586) = true)

def env42587 : List Nat := [2,4,8,0,32,64,128,256,324,1024,2048,0,1289,1281,260,1348,1059,1476,321,261,1,460,355,1348,193,1122,303,1122,1281,3334,1285,1280,257,1123,1345,1029]

theorem envBound42587 : H12AffineFastState.Bounded env42587 := by
  intro p hp
  have h : env42587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42578_42587 : H12AffineEnvironment.transform 12 1289 env42578 = env42587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1289 env42578 == env42587) = true)

theorem identity42587 : scanCanonicalize (H12AffineFastState.compose env42587 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound42587 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env42588 : List Nat := [2,4,8,0,32,64,128,256,324,68,2048,0,333,325,260,256,103,384,321,261,1,460,355,256,193,38,303,38,325,2370,321,324,257,39,261,65]

theorem envBound42588 : H12AffineFastState.Bounded env42588 := by
  intro p hp
  have h : env42588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42587_42588 : H12AffineEnvironment.transform 9 68 env42587 = env42588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env42587 == env42588) = true)

theorem identity42588 : scanCanonicalize (H12AffineFastState.compose env42588 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound42588 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env42589 : List Nat := [2,4,8,0,32,64,128,256,324,68,11,0,333,325,260,256,103,384,321,261,1,460,355,256,193,38,303,38,325,329,321,324,257,39,261,65]

theorem envBound42589 : H12AffineFastState.Bounded env42589 := by
  intro p hp
  have h : env42589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42588_42589 : H12AffineEnvironment.transform 10 11 env42588 = env42589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env42588 == env42589) = true)

theorem identity42589 : scanCanonicalize (H12AffineFastState.compose env42589 (packedSelected [1,5,8,11,17,20] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound42589 : packedSelected [1,5,8,11,17,20] rootPS < 2^1333 := by decide +kernel

def env42590 : List Nat := [2,4,5,0,32,64,128,256,324,68,6,0,320,325,260,256,103,384,321,261,1,449,355,256,193,38,290,38,325,324,321,324,257,39,261,65]

theorem envBound42590 : H12AffineFastState.Bounded env42590 := by
  intro p hp
  have h : env42590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42589_42590 : H12AffineEnvironment.transform 2 5 env42589 = env42590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env42589 == env42590) = true)

theorem identity42590 : scanCanonicalize (H12AffineFastState.compose env42590 (packedSelected [4,7,8,10] rootPS)) = affineNative (2^(6+1) ^^^ 101) := by decide +kernel

theorem selectedBound42590 : packedSelected [4,7,8,10] rootPS < 2^1333 := by decide +kernel

def env42591 : List Nat := [2,4,5,0,32,64,101,256,324,68,6,0,320,325,260,256,103,357,321,261,1,292,355,256,36,38,290,38,325,324,321,324,257,39,261,65]

theorem envBound42591 : H12AffineFastState.Bounded env42591 := by
  intro p hp
  have h : env42591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42590_42591 : H12AffineEnvironment.transform 6 101 env42590 = env42591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 101 env42590 == env42591) = true)

theorem identity42591 : scanCanonicalize (H12AffineFastState.compose env42591 (packedSelected [0,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 67) := by decide +kernel

theorem selectedBound42591 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env42592 : List Nat := [2,4,5,0,32,64,101,67,7,68,6,0,3,6,71,67,103,38,2,70,1,103,32,67,36,38,97,38,6,7,2,7,66,39,70,65]

theorem envBound42592 : H12AffineFastState.Bounded env42592 := by
  intro p hp
  have h : env42592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42591_42592 : H12AffineEnvironment.transform 7 67 env42591 = env42592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 67 env42591 == env42592) = true)

theorem identity42592 : scanCanonicalize (H12AffineFastState.compose env42592 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 6) := by decide +kernel

theorem selectedBound42592 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42593 : List Nat := [2,4,5,0,32,6,35,5,7,2,6,0,3,6,1,5,33,38,2,0,1,33,32,5,36,38,39,38,6,7,2,7,4,39,0,7]

theorem envBound42593 : H12AffineFastState.Bounded env42593 := by
  intro p hp
  have h : env42593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42592_42593 : H12AffineEnvironment.transform 5 6 env42592 = env42593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 6 env42592 == env42593) = true)

theorem identity42593 : scanCanonicalize (H12AffineFastState.compose env42593 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound42593 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42594 : List Nat := [2,3,2,0,32,1,35,2,0,2,1,0,3,1,1,2,33,33,2,0,1,33,32,2,35,33,32,33,1,0,2,0,3,32,0,0]

theorem envBound42594 : H12AffineFastState.Bounded env42594 := by
  intro p hp
  have h : env42594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42593_42594 : H12AffineEnvironment.transform 1 3 env42593 = env42594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env42593 == env42594) = true)

theorem identity42594 : scanCanonicalize (H12AffineFastState.compose env42594 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound42594 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42595 : List Nat := [2,3,2,0,0,1,3,2,0,2,1,0,3,1,1,2,1,1,2,0,1,1,0,2,3,1,0,1,1,0,2,0,3,0,0,0]

theorem envBound42595 : H12AffineFastState.Bounded env42595 := by
  intro p hp
  have h : env42595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42594_42595 : H12AffineEnvironment.transform 4 0 env42594 = env42595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env42594 == env42595) = true)

def env42596 : List Nat := [2,4,8,1,32,64,128,256,325,1024,2048,0,8192,1280,9228,65536,74862,65664,321,9229,1,461,74031,65537,9672,74799,302,74798,1280,77131,8204,8201,257,74798,1345,1028]

theorem envBound42596 : H12AffineFastState.Bounded env42596 := by
  intro p hp
  have h : env42596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42576_42596 : H12AffineEnvironment.transform 3 1 env42576 = env42596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env42576 == env42596) = true)

theorem identity42596 : scanCanonicalize (H12AffineFastState.compose env42596 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8268) := by decide +kernel

theorem selectedBound42596 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env42597 : List Nat := [2,4,8,1,32,64,128,256,325,1024,2048,0,8192,1280,9228,8268,1058,8396,321,9229,1,461,355,8269,9672,1123,302,1122,1280,3335,8204,8201,257,1122,1345,1028]

theorem envBound42597 : H12AffineFastState.Bounded env42597 := by
  intro p hp
  have h : env42597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42596_42597 : H12AffineEnvironment.transform 15 8268 env42596 = env42597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8268 env42596 == env42597) = true)

def env42598 : List Nat := [2,4,4,1,32,64,128,256,325,1024,2048,0,8192,1280,9216,8256,1058,8384,321,9217,1,449,355,8257,9668,1123,290,1122,1280,3335,8192,8197,257,1122,1345,1028]

theorem envBound42598 : H12AffineFastState.Bounded env42598 := by
  intro p hp
  have h : env42598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42597_42598 : H12AffineEnvironment.transform 2 4 env42597 = env42598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env42597 == env42598) = true)

theorem identity42598 : scanCanonicalize (H12AffineFastState.compose env42598 (packedSelected [2,3,5,8,11,15,16,17,19,20,21,23,24] rootPS)) = affineNative (2^(12+1) ^^^ 2469) := by decide +kernel

theorem selectedBound42598 : packedSelected [2,3,5,8,11,15,16,17,19,20,21,23,24] rootPS < 2^1333 := by decide +kernel

def env42599 : List Nat := [2,4,4,1,32,64,128,256,325,1024,2048,0,2469,1280,3493,2533,1058,2405,321,3492,1,449,355,2532,3169,1123,290,1122,1280,3335,2469,2464,257,1122,1345,1028]

theorem envBound42599 : H12AffineFastState.Bounded env42599 := by
  intro p hp
  have h : env42599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42598_42599 : H12AffineEnvironment.transform 12 2469 env42598 = env42599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2469 env42598 == env42599) = true)

theorem identity42599 : scanCanonicalize (H12AffineFastState.compose env42599 (packedSelected [1,4,7,8,10,11,12,16,20,21,23] rootPS)) = affineNative (2^(10+1) ^^^ 422) := by decide +kernel

theorem selectedBound42599 : packedSelected [1,4,7,8,10,11,12,16,20,21,23] rootPS < 2^1333 := by decide +kernel

def env42600 : List Nat := [2,4,4,1,32,64,128,256,325,1024,422,0,3,1280,1027,67,1058,195,321,1026,1,449,355,66,1479,1123,290,1122,1280,1185,3,6,257,1122,1345,1028]

theorem envBound42600 : H12AffineFastState.Bounded env42600 := by
  intro p hp
  have h : env42600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42599_42600 : H12AffineEnvironment.transform 10 422 env42599 = env42600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 422 env42599 == env42600) = true)

theorem identity42600 : scanCanonicalize (H12AffineFastState.compose env42600 (packedSelected [0,2,5,7,8,10,11,12,13,15,17] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound42600 : packedSelected [0,2,5,7,8,10,11,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env42601 : List Nat := [2,4,4,1,32,64,128,256,325,37,422,0,3,293,38,67,7,195,321,39,1,449,355,66,482,70,290,71,293,132,3,6,257,71,356,33]

theorem envBound42601 : H12AffineFastState.Bounded env42601 := by
  intro p hp
  have h : env42601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42600_42601 : H12AffineEnvironment.transform 9 37 env42600 = env42601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env42600 == env42601) = true)

theorem identity42601 : scanCanonicalize (H12AffineFastState.compose env42601 (packedSelected [0,1,2,5,9] rootPS)) = affineNative (2^(7+1) ^^^ 224) := by decide +kernel

theorem selectedBound42601 : packedSelected [0,1,2,5,9] rootPS < 2^1333 := by decide +kernel

def env42602 : List Nat := [2,4,4,1,32,64,128,224,165,37,70,0,3,197,38,67,7,195,161,39,1,33,131,66,2,70,194,71,197,132,3,6,225,71,132,33]

theorem envBound42602 : H12AffineFastState.Bounded env42602 := by
  intro p hp
  have h : env42602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42601_42602 : H12AffineEnvironment.transform 7 224 env42601 = env42602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 224 env42601 == env42602) = true)

theorem identity42602 : scanCanonicalize (H12AffineFastState.compose env42602 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 37) := by decide +kernel

theorem selectedBound42602 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env42603 : List Nat := [2,4,4,1,32,64,37,69,0,37,70,0,3,96,38,67,7,102,4,39,1,33,38,66,2,70,103,71,96,33,3,6,68,71,33,33]

theorem envBound42603 : H12AffineFastState.Bounded env42603 := by
  intro p hp
  have h : env42603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42602_42603 : H12AffineEnvironment.transform 6 37 env42602 = env42603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 37 env42602 == env42603) = true)

def env42604 : List Nat := [2,4,5,1,32,64,128,256,325,1024,2048,0,8192,1280,9217,8257,1058,8385,321,9216,1,448,355,8256,9669,1123,291,1122,1280,3335,8193,8196,257,1122,1345,1028]

theorem envBound42604 : H12AffineFastState.Bounded env42604 := by
  intro p hp
  have h : env42604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42597_42604 : H12AffineEnvironment.transform 2 5 env42597 = env42604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env42597 == env42604) = true)

theorem identity42604 : scanCanonicalize (H12AffineFastState.compose env42604 (packedSelected [2,3,5,8,11,15,16,17,19,20,21,23,24] rootPS)) = affineNative (2^(10+1) ^^^ 1475) := by decide +kernel

theorem selectedBound42604 : packedSelected [2,3,5,8,11,15,16,17,19,20,21,23,24] rootPS < 2^1333 := by decide +kernel

def env42605 : List Nat := [2,4,5,1,32,64,128,256,325,1024,1475,0,8192,1280,9217,8257,1058,8385,321,9216,1,448,355,8256,9669,1123,291,1122,1280,196,8193,8196,257,1122,1345,1028]

theorem envBound42605 : H12AffineFastState.Bounded env42605 := by
  intro p hp
  have h : env42605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42604_42605 : H12AffineEnvironment.transform 10 1475 env42604 = env42605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1475 env42604 == env42605) = true)

theorem identity42605 : scanCanonicalize (H12AffineFastState.compose env42605 (packedSelected [1,3,4,7,9,12,15,17,19,20,23,27] rootPS)) = affineNative (2^(12+1) ^^^ 98) := by decide +kernel

theorem selectedBound42605 : packedSelected [1,3,4,7,9,12,15,17,19,20,23,27] rootPS < 2^1333 := by decide +kernel

def env42606 : List Nat := [2,4,5,1,32,64,128,256,325,1024,1475,0,98,1280,1123,35,1058,163,321,1122,1,448,355,34,1447,1123,291,1122,1280,196,99,102,257,1122,1345,1028]

theorem envBound42606 : H12AffineFastState.Bounded env42606 := by
  intro p hp
  have h : env42606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42605_42606 : H12AffineEnvironment.transform 12 98 env42605 = env42606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 98 env42605 == env42606) = true)

theorem identity42606 : scanCanonicalize (H12AffineFastState.compose env42606 (packedSelected [2,7,8,9,10,12,15,16,17] rootPS)) = affineNative (2^(9+1) ^^^ 257) := by decide +kernel

theorem selectedBound42606 : packedSelected [2,7,8,9,10,12,15,16,17] rootPS < 2^1333 := by decide +kernel

def env42607 : List Nat := [2,4,5,1,32,64,128,256,325,257,194,0,98,1,354,35,291,163,321,355,1,448,355,34,166,354,291,355,1,196,99,102,257,355,64,261]

theorem envBound42607 : H12AffineFastState.Bounded env42607 := by
  intro p hp
  have h : env42607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42606_42607 : H12AffineEnvironment.transform 9 257 env42606 = env42607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env42606 == env42607) = true)

theorem identity42607 : scanCanonicalize (H12AffineFastState.compose env42607 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound42607 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env42608 : List Nat := [2,3,2,1,32,64,128,256,322,257,194,0,98,1,354,35,291,163,321,355,1,448,355,34,161,354,291,355,1,195,99,97,257,355,64,258]

theorem envBound42608 : H12AffineFastState.Bounded env42608 := by
  intro p hp
  have h : env42608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42607_42608 : H12AffineEnvironment.transform 1 3 env42607 = env42608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env42607 == env42608) = true)

theorem identity42608 : scanCanonicalize (H12AffineFastState.compose env42608 (packedSelected [8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound42608 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env42609 : List Nat := [2,3,2,1,0,64,128,256,322,257,194,0,66,1,322,3,259,131,321,323,1,448,323,2,129,322,259,323,1,195,67,65,257,323,64,258]

theorem envBound42609 : H12AffineFastState.Bounded env42609 := by
  intro p hp
  have h : env42609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42608_42609 : H12AffineEnvironment.transform 4 0 env42608 = env42609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env42608 == env42609) = true)

theorem identity42609 : scanCanonicalize (H12AffineFastState.compose env42609 (packedSelected [0,1,4] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound42609 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env42610 : List Nat := [2,3,2,1,0,0,128,256,258,257,130,0,2,1,258,3,259,131,257,259,1,384,259,2,129,258,259,259,1,131,3,1,257,259,0,258]

theorem envBound42610 : H12AffineFastState.Bounded env42610 := by
  intro p hp
  have h : env42610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42609_42610 : H12AffineEnvironment.transform 5 0 env42609 = env42610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env42609 == env42610) = true)

theorem identity42610 : scanCanonicalize (H12AffineFastState.compose env42610 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 2) := by decide +kernel

theorem selectedBound42610 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env42611 : List Nat := [2,3,2,1,0,0,128,2,0,3,130,0,2,1,0,3,1,131,3,1,1,130,1,2,129,0,1,1,1,131,3,1,3,1,0,0]

theorem envBound42611 : H12AffineFastState.Bounded env42611 := by
  intro p hp
  have h : env42611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42610_42611 : H12AffineEnvironment.transform 7 2 env42610 = env42611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 2 env42610 == env42611) = true)

theorem identity42611 : scanCanonicalize (H12AffineFastState.compose env42611 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound42611 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42612 : List Nat := [2,3,2,1,0,0,3,2,0,3,1,0,2,1,0,3,1,0,3,1,1,1,1,2,2,0,1,1,1,0,3,1,3,1,0,0]

theorem envBound42612 : H12AffineFastState.Bounded env42612 := by
  intro p hp
  have h : env42612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42611_42612 : H12AffineEnvironment.transform 6 3 env42611 = env42612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env42611 == env42612) = true)

def env42613 : List Nat := [2,4,8,16,32,64,128,256,341,1024,2048,0,8192,1297,9245,65536,74862,65664,321,9244,1,476,74046,65552,9672,74799,319,74815,1297,77131,8204,8201,257,74798,1345,1044]

theorem envBound42613 : H12AffineFastState.Bounded env42613 := by
  intro p hp
  have h : env42613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42575_42613 : H12AffineEnvironment.transform 8 341 env42575 = env42613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env42575 == env42613) = true)

def env42614 : List Nat := [2,4,8,0,32,64,128,256,325,1024,2048,0,8192,1281,9229,65536,74862,65664,321,9228,1,460,74030,65536,9672,74799,303,74799,1281,77131,8204,8201,257,74798,1345,1028]

theorem envBound42614 : H12AffineFastState.Bounded env42614 := by
  intro p hp
  have h : env42614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42613_42614 : H12AffineEnvironment.transform 3 0 env42613 = env42614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env42613 == env42614) = true)

theorem identity42614 : scanCanonicalize (H12AffineFastState.compose env42614 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 1130) := by decide +kernel

theorem selectedBound42614 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env42615 : List Nat := [2,4,8,0,32,64,128,256,325,1024,2048,0,1130,1281,103,65536,65540,65664,321,102,1,460,66884,65536,418,65605,303,65605,1281,67873,1126,1123,257,65604,1345,1028]

theorem envBound42615 : H12AffineFastState.Bounded env42615 := by
  intro p hp
  have h : env42615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42614_42615 : H12AffineEnvironment.transform 12 1130 env42614 = env42615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1130 env42614 == env42615) = true)

def env42616 : List Nat := [2,4,8,0,32,64,128,104,45,1024,2048,0,1130,1129,103,65536,65540,65664,41,102,1,164,66604,65536,202,65605,71,65605,1129,67657,1126,1123,105,65604,1065,1028]

theorem envBound42616 : H12AffineFastState.Bounded env42616 := by
  intro p hp
  have h : env42616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42615_42616 : H12AffineEnvironment.transform 7 104 env42615 = env42616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 104 env42615 == env42616) = true)

theorem identity42616 : scanCanonicalize (H12AffineFastState.compose env42616 (packedSelected [0,8,13,15,24,27] rootPS)) = affineNative (2^(15+1) ^^^ 234) := by decide +kernel

theorem selectedBound42616 : packedSelected [0,8,13,15,24,27] rootPS < 2^1333 := by decide +kernel

def env42617 : List Nat := [2,4,8,0,32,64,128,104,45,1024,2048,0,1130,1129,103,234,238,106,41,102,1,164,1222,234,202,175,71,175,1129,2211,1126,1123,105,174,1065,1028]

theorem envBound42617 : H12AffineFastState.Bounded env42617 := by
  intro p hp
  have h : env42617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42616_42617 : H12AffineEnvironment.transform 15 234 env42616 = env42617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 234 env42616 == env42617) = true)

theorem identity42617 : scanCanonicalize (H12AffineFastState.compose env42617 (packedSelected [0,1,3,4,7,8,9,10,16,17,20,23] rootPS)) = affineNative (2^(10+1) ^^^ 200) := by decide +kernel

theorem selectedBound42617 : packedSelected [0,1,3,4,7,8,9,10,16,17,20,23] rootPS < 2^1333 := by decide +kernel

def env42618 : List Nat := [2,4,8,0,32,64,128,104,45,1024,200,0,1130,1129,103,234,238,106,41,102,1,164,1222,234,202,175,71,175,1129,107,1126,1123,105,174,1065,1028]

theorem envBound42618 : H12AffineFastState.Bounded env42618 := by
  intro p hp
  have h : env42618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42617_42618 : H12AffineEnvironment.transform 10 200 env42617 = env42618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 200 env42617 == env42618) = true)

theorem identity42618 : scanCanonicalize (H12AffineFastState.compose env42618 (packedSelected [2,3,4,5,9,10,11,15,16,17] rootPS)) = affineNative (2^(6+1) ^^^ 110) := by decide +kernel

theorem selectedBound42618 : packedSelected [2,3,4,5,9,10,11,15,16,17] rootPS < 2^1333 := by decide +kernel

def env42619 : List Nat := [2,4,8,0,32,64,110,104,45,1024,38,0,1130,1129,103,4,0,106,41,102,1,74,1064,4,36,65,71,65,1129,107,1126,1123,105,64,1065,1028]

theorem envBound42619 : H12AffineFastState.Bounded env42619 := by
  intro p hp
  have h : env42619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42618_42619 : H12AffineEnvironment.transform 6 110 env42618 = env42619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 110 env42618 == env42619) = true)

theorem identity42619 : scanCanonicalize (H12AffineFastState.compose env42619 (packedSelected [0,2,4,10,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound42619 : packedSelected [0,2,4,10,11,12] rootPS < 2^1333 := by decide +kernel

def env42620 : List Nat := [2,4,8,0,32,64,110,104,45,4,38,0,110,109,103,4,0,106,41,102,1,74,44,4,36,65,71,65,109,107,98,103,105,64,45,0]

theorem envBound42620 : H12AffineFastState.Bounded env42620 := by
  intro p hp
  have h : env42620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42619_42620 : H12AffineEnvironment.transform 9 4 env42619 = env42620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env42619 == env42620) = true)

theorem identity42620 : scanCanonicalize (H12AffineFastState.compose env42620 (packedSelected [1,3,4,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound42620 : packedSelected [1,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env42621 : List Nat := [2,4,8,0,7,64,73,79,10,4,1,0,73,74,64,4,0,77,14,65,1,74,11,4,3,65,71,65,74,76,69,64,78,64,10,0]

theorem envBound42621 : H12AffineFastState.Bounded env42621 := by
  intro p hp
  have h : env42621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42620_42621 : H12AffineEnvironment.transform 4 7 env42620 = env42621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env42620 == env42621) = true)

theorem identity42621 : scanCanonicalize (H12AffineFastState.compose env42621 (packedSelected [0,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 7) := by decide +kernel

theorem selectedBound42621 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env42622 : List Nat := [2,4,8,0,7,7,14,8,10,4,1,0,14,13,7,4,0,10,14,6,1,13,11,4,3,6,0,6,13,11,2,7,9,7,10,0]

theorem envBound42622 : H12AffineFastState.Bounded env42622 := by
  intro p hp
  have h : env42622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42621_42622 : H12AffineEnvironment.transform 5 7 env42621 = env42622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 7 env42621 == env42622) = true)

def env42623 : List Nat := [2,4,8,0,32,64,128,105,44,1024,2048,0,1130,1128,103,65536,65540,65664,40,102,1,165,66605,65536,203,65605,70,65605,1128,67656,1126,1123,104,65604,1064,1028]

theorem envBound42623 : H12AffineFastState.Bounded env42623 := by
  intro p hp
  have h : env42623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42615_42623 : H12AffineEnvironment.transform 7 105 env42615 = env42623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 105 env42615 == env42623) = true)

theorem identity42623 : scanCanonicalize (H12AffineFastState.compose env42623 (packedSelected [0,8,13,15,24,27] rootPS)) = affineNative (2^(15+1) ^^^ 225) := by decide +kernel

theorem selectedBound42623 : packedSelected [0,8,13,15,24,27] rootPS < 2^1333 := by decide +kernel

def env42624 : List Nat := [2,4,8,0,32,64,128,105,44,1024,2048,0,1130,1128,103,225,229,97,40,102,1,165,1228,225,203,164,70,164,1128,2217,1126,1123,104,165,1064,1028]

theorem envBound42624 : H12AffineFastState.Bounded env42624 := by
  intro p hp
  have h : env42624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42623_42624 : H12AffineEnvironment.transform 15 225 env42623 = env42624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 225 env42623 == env42624) = true)

theorem identity42624 : scanCanonicalize (H12AffineFastState.compose env42624 (packedSelected [1,3,4,5,7,10,13,17,18,21,24] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound42624 : packedSelected [1,3,4,5,7,10,13,17,18,21,24] rootPS < 2^1333 := by decide +kernel

def env42625 : List Nat := [2,4,8,0,32,64,4,105,44,1024,2048,0,1130,1128,103,101,97,97,40,102,1,33,1096,101,79,32,70,32,1128,2093,1126,1123,104,33,1064,1028]

theorem envBound42625 : H12AffineFastState.Bounded env42625 := by
  intro p hp
  have h : env42625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42624_42625 : H12AffineEnvironment.transform 6 4 env42624 = env42625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env42624 == env42625) = true)

theorem identity42625 : scanCanonicalize (H12AffineFastState.compose env42625 (packedSelected [0,2,4,5,7,9,10,11,12,13,15,18] rootPS)) = affineNative (2^(9+1) ^^^ 110) := by decide +kernel

theorem selectedBound42625 : packedSelected [0,2,4,5,7,9,10,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env42626 : List Nat := [2,4,8,0,32,64,4,105,44,110,2048,0,4,6,103,101,97,97,40,102,1,33,38,101,79,32,70,32,6,2093,8,13,104,33,70,106]

theorem envBound42626 : H12AffineFastState.Bounded env42626 := by
  intro p hp
  have h : env42626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42625_42626 : H12AffineEnvironment.transform 9 110 env42625 = env42626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 110 env42625 == env42626) = true)

theorem identity42626 : scanCanonicalize (H12AffineFastState.compose env42626 (packedSelected [1,2,8,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 38) := by decide +kernel

theorem selectedBound42626 : packedSelected [1,2,8,10,11] rootPS < 2^1333 := by decide +kernel

def env42627 : List Nat := [2,4,8,0,32,38,4,15,44,8,2048,0,4,6,1,3,7,7,40,0,1,33,38,3,41,32,32,32,6,2093,8,13,14,33,32,12]

theorem envBound42627 : H12AffineFastState.Bounded env42627 := by
  intro p hp
  have h : env42627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42626_42627 : H12AffineEnvironment.transform 5 38 env42626 = env42627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 38 env42626 == env42627) = true)

theorem identity42627 : scanCanonicalize (H12AffineFastState.compose env42627 (packedSelected [3,4,5,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound42627 : packedSelected [3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env42628 : List Nat := [2,4,8,0,32,38,4,15,44,8,11,0,4,6,1,3,7,7,40,0,1,33,38,3,41,32,32,32,6,38,8,13,14,33,32,12]

theorem envBound42628 : H12AffineFastState.Bounded env42628 := by
  intro p hp
  have h : env42628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42627_42628 : H12AffineEnvironment.transform 10 11 env42627 = env42628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env42627 == env42628) = true)

theorem identity42628 : scanCanonicalize (H12AffineFastState.compose env42628 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound42628 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env42629 : List Nat := [2,4,5,0,32,38,4,2,33,5,6,0,4,6,1,3,7,7,37,0,1,33,38,3,36,32,32,32,6,38,5,0,3,33,32,1]

theorem envBound42629 : H12AffineFastState.Bounded env42629 := by
  intro p hp
  have h : env42629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42628_42629 : H12AffineEnvironment.transform 2 5 env42628 = env42629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env42628 == env42629) = true)

theorem identity42629 : scanCanonicalize (H12AffineFastState.compose env42629 (packedSelected [0,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound42629 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env42630 : List Nat := [2,4,5,0,1,7,4,2,0,5,6,0,4,6,1,3,7,7,4,0,1,0,7,3,5,1,1,1,6,7,5,0,3,0,1,1]

theorem envBound42630 : H12AffineFastState.Bounded env42630 := by
  intro p hp
  have h : env42630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42629_42630 : H12AffineEnvironment.transform 4 1 env42629 = env42630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env42629 == env42630) = true)

theorem identity42630 : scanCanonicalize (H12AffineFastState.compose env42630 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound42630 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42631 : List Nat := [2,0,1,0,1,3,0,2,0,1,2,0,0,2,1,3,3,3,0,0,1,0,3,3,1,1,1,1,2,3,1,0,3,0,1,1]

theorem envBound42631 : H12AffineFastState.Bounded env42631 := by
  intro p hp
  have h : env42631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42630_42631 : H12AffineEnvironment.transform 1 0 env42630 = env42631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env42630 == env42631) = true)

theorem identity42631 : scanCanonicalize (H12AffineFastState.compose env42631 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound42631 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42632 : List Nat := [1,0,1,0,1,0,0,1,0,1,1,0,0,1,1,0,0,0,0,0,1,0,0,0,1,1,1,1,1,0,1,0,0,0,1,1]

theorem envBound42632 : H12AffineFastState.Bounded env42632 := by
  intro p hp
  have h : env42632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42631_42632 : H12AffineEnvironment.transform 0 1 env42631 = env42632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env42631 == env42632) = true)

def env42633 : List Nat := [2,4,8,1,32,64,128,256,324,1024,2048,0,8192,1280,9228,65536,74862,65664,321,9229,1,461,74031,65537,9672,74799,302,74798,1280,77131,8204,8201,257,74798,1345,1029]

theorem envBound42633 : H12AffineFastState.Bounded env42633 := by
  intro p hp
  have h : env42633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42613_42633 : H12AffineEnvironment.transform 3 1 env42613 = env42633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env42613 == env42633) = true)

theorem identity42633 : scanCanonicalize (H12AffineFastState.compose env42633 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 98) := by decide +kernel

theorem selectedBound42633 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env42634 : List Nat := [2,4,8,1,32,64,128,98,38,1024,2048,0,8192,1122,9228,65536,74862,65664,35,9229,1,175,73805,65537,9386,74799,76,74798,1122,76841,8204,8201,99,74798,1059,1029]

theorem envBound42634 : H12AffineFastState.Bounded env42634 := by
  intro p hp
  have h : env42634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42633_42634 : H12AffineEnvironment.transform 7 98 env42633 = env42634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 98 env42633 == env42634) = true)

def env42635 : List Nat := [2,4,8,1,32,64,128,98,38,1024,2048,0,3208,1122,2180,65536,67814,65664,35,2181,1,175,68805,65537,2082,67751,76,67750,1122,65697,3204,3201,99,67750,1059,1029]

theorem envBound42635 : H12AffineFastState.Bounded env42635 := by
  intro p hp
  have h : env42635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42634_42635 : H12AffineEnvironment.transform 12 3208 env42634 = env42635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3208 env42634 == env42635) = true)

def env42636 : List Nat := [2,4,8,1,32,64,128,98,38,1024,2048,0,3208,1122,2180,192,2086,64,35,2181,1,175,3077,193,2082,2151,76,2150,1122,97,3204,3201,99,2150,1059,1029]

theorem envBound42636 : H12AffineFastState.Bounded env42636 := by
  intro p hp
  have h : env42636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42635_42636 : H12AffineEnvironment.transform 15 192 env42635 = env42636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 192 env42635 == env42636) = true)

theorem identity42636 : scanCanonicalize (H12AffineFastState.compose env42636 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound42636 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env42637 : List Nat := [2,4,8,1,32,64,128,98,38,1024,33,0,1193,1122,165,192,7,64,35,164,1,175,1060,193,3,70,76,71,1122,97,1189,1184,99,71,1059,1029]

theorem envBound42637 : H12AffineFastState.Bounded env42637 := by
  intro p hp
  have h : env42637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42636_42637 : H12AffineEnvironment.transform 10 33 env42636 = env42637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env42636 == env42637) = true)

theorem identity42637 : scanCanonicalize (H12AffineFastState.compose env42637 (packedSelected [0,1,4,12,13,15,16,17] rootPS)) = affineNative (2^(9+1) ^^^ 41) := by decide +kernel

theorem selectedBound42637 : packedSelected [0,1,4,12,13,15,16,17] rootPS < 2^1333 := by decide +kernel

def env42638 : List Nat := [2,4,8,1,32,64,128,98,38,41,33,0,128,75,165,192,7,64,35,164,1,175,13,193,3,70,76,71,75,97,140,137,99,71,10,44]

theorem envBound42638 : H12AffineFastState.Bounded env42638 := by
  intro p hp
  have h : env42638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42637_42638 : H12AffineEnvironment.transform 9 41 env42637 = env42638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 41 env42637 == env42638) = true)

theorem identity42638 : scanCanonicalize (H12AffineFastState.compose env42638 (packedSelected [1,2,5,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 47) := by decide +kernel

theorem selectedBound42638 : packedSelected [1,2,5,11,12] rootPS < 2^1333 := by decide +kernel

def env42639 : List Nat := [2,4,8,1,32,64,47,98,38,41,33,0,47,75,10,111,7,64,35,11,1,0,13,110,3,70,76,71,75,97,35,38,99,71,10,44]

theorem envBound42639 : H12AffineFastState.Bounded env42639 := by
  intro p hp
  have h : env42639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42638_42639 : H12AffineEnvironment.transform 6 47 env42638 = env42639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 47 env42638 == env42639) = true)

theorem identity42639 : scanCanonicalize (H12AffineFastState.compose env42639 (packedSelected [2,4,5,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound42639 : packedSelected [2,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env42640 : List Nat := [2,4,8,1,32,12,47,46,38,41,33,0,47,7,10,35,7,12,35,11,1,0,13,34,3,10,0,11,7,45,35,38,47,11,10,44]

theorem envBound42640 : H12AffineFastState.Bounded env42640 := by
  intro p hp
  have h : env42640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42639_42640 : H12AffineEnvironment.transform 5 12 env42639 = env42640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env42639 == env42640) = true)

theorem identity42640 : scanCanonicalize (H12AffineFastState.compose env42640 (packedSelected [0,1,4] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound42640 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env42641 : List Nat := [2,4,4,1,32,0,35,34,38,37,33,0,35,7,6,35,7,0,35,7,1,0,1,34,3,6,0,7,7,33,35,38,35,7,6,32]

theorem envBound42641 : H12AffineFastState.Bounded env42641 := by
  intro p hp
  have h : env42641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42640_42641 : H12AffineEnvironment.transform 2 4 env42640 = env42641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env42640 == env42641) = true)

theorem identity42641 : scanCanonicalize (H12AffineFastState.compose env42641 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound42641 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42642 : List Nat := [2,3,3,1,32,0,35,34,33,34,33,0,35,0,1,35,0,0,35,0,1,0,1,34,3,1,0,0,0,33,35,33,35,0,1,32]

theorem envBound42642 : H12AffineFastState.Bounded env42642 := by
  intro p hp
  have h : env42642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42641_42642 : H12AffineEnvironment.transform 1 3 env42641 = env42642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env42641 == env42642) = true)

theorem identity42642 : scanCanonicalize (H12AffineFastState.compose env42642 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound42642 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42643 : List Nat := [1,0,0,1,32,0,32,33,33,33,33,0,32,0,1,32,0,0,32,0,1,0,1,33,0,1,0,0,0,33,32,33,32,0,1,32]

theorem envBound42643 : H12AffineFastState.Bounded env42643 := by
  intro p hp
  have h : env42643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42642_42643 : H12AffineEnvironment.transform 0 1 env42642 = env42643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env42642 == env42643) = true)

theorem identity42643 : scanCanonicalize (H12AffineFastState.compose env42643 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound42643 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42644 : List Nat := [1,0,0,1,1,0,1,0,0,0,0,0,1,0,1,1,0,0,1,0,1,0,1,0,0,1,0,0,0,0,1,0,1,0,1,1]

theorem envBound42644 : H12AffineFastState.Bounded env42644 := by
  intro p hp
  have h : env42644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42643_42644 : H12AffineEnvironment.transform 4 1 env42643 = env42644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env42643 == env42644) = true)

def env42645 : List Nat := [2,4,8,1,32,64,128,98,38,1024,2048,0,3208,1122,2180,193,2087,65,35,2181,1,175,3076,192,2082,2150,76,2151,1122,96,3204,3201,99,2151,1059,1029]

theorem envBound42645 : H12AffineFastState.Bounded env42645 := by
  intro p hp
  have h : env42645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42635_42645 : H12AffineEnvironment.transform 15 193 env42635 = env42645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 193 env42635 == env42645) = true)

theorem identity42645 : scanCanonicalize (H12AffineFastState.compose env42645 (packedSelected [3] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound42645 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env42646 : List Nat := [2,4,8,1,32,64,128,98,38,100,2048,0,2284,6,2180,193,2087,65,35,2181,1,175,2144,192,2082,2150,76,2151,6,96,2272,2277,99,2151,71,97]

theorem envBound42646 : H12AffineFastState.Bounded env42646 := by
  intro p hp
  have h : env42646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42645_42646 : H12AffineEnvironment.transform 9 100 env42645 = env42646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env42645 == env42646) = true)

theorem identity42646 : scanCanonicalize (H12AffineFastState.compose env42646 (packedSelected [1,4,7,8,11,13,18,19] rootPS)) = affineNative (2^(6+1) ^^^ 67) := by decide +kernel

theorem selectedBound42646 : packedSelected [1,4,7,8,11,13,18,19] rootPS < 2^1333 := by decide +kernel

def env42647 : List Nat := [2,4,8,1,32,64,67,98,38,100,2048,0,2095,6,2119,2,2087,65,35,2118,1,108,2144,3,2082,2150,76,2151,6,96,2083,2086,99,2151,71,97]

theorem envBound42647 : H12AffineFastState.Bounded env42647 := by
  intro p hp
  have h : env42647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42646_42647 : H12AffineEnvironment.transform 6 67 env42646 = env42647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 67 env42646 == env42647) = true)

theorem identity42647 : scanCanonicalize (H12AffineFastState.compose env42647 (packedSelected [2,4,5,8,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound42647 : packedSelected [2,4,5,8,9,10] rootPS < 2^1333 := by decide +kernel

def env42648 : List Nat := [2,4,8,1,32,12,15,46,38,40,2048,0,2095,6,2059,2,2087,13,35,2058,1,32,2092,3,2082,2090,0,2091,6,44,2083,2086,47,2091,11,45]

theorem envBound42648 : H12AffineFastState.Bounded env42648 := by
  intro p hp
  have h : env42648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42647_42648 : H12AffineEnvironment.transform 5 12 env42647 = env42648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env42647 == env42648) = true)

theorem identity42648 : scanCanonicalize (H12AffineFastState.compose env42648 (packedSelected [0,2,4] rootPS)) = affineNative (2^(10+1) ^^^ 39) := by decide +kernel

theorem selectedBound42648 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env42649 : List Nat := [2,4,8,1,32,12,15,46,38,40,39,0,8,6,44,2,0,13,35,45,1,32,11,3,5,13,0,12,6,44,4,1,47,12,11,45]

theorem envBound42649 : H12AffineFastState.Bounded env42649 := by
  intro p hp
  have h : env42649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42648_42649 : H12AffineEnvironment.transform 10 39 env42648 = env42649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 39 env42648 == env42649) = true)

theorem identity42649 : scanCanonicalize (H12AffineFastState.compose env42649 (packedSelected [0,5,7] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound42649 : packedSelected [0,5,7] rootPS < 2^1333 := by decide +kernel

def env42650 : List Nat := [2,2,8,1,32,10,9,40,32,40,33,0,8,0,42,2,0,11,35,43,1,32,11,3,3,11,0,10,0,42,2,1,41,10,11,43]

theorem envBound42650 : H12AffineFastState.Bounded env42650 := by
  intro p hp
  have h : env42650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42649_42650 : H12AffineEnvironment.transform 1 2 env42649 = env42650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env42649 == env42650) = true)

def env42651 : List Nat := [2,4,8,1,32,64,128,98,38,1024,2048,0,3209,1122,2181,65536,67815,65664,35,2180,1,175,68804,65537,2083,67750,76,67751,1122,65696,3205,3200,99,67751,1059,1029]

theorem envBound42651 : H12AffineFastState.Bounded env42651 := by
  intro p hp
  have h : env42651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42634_42651 : H12AffineEnvironment.transform 12 3209 env42634 = env42651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3209 env42634 == env42651) = true)

def env42652 : List Nat := [2,4,8,1,32,64,128,98,38,1024,2048,0,3209,1122,2181,192,2087,64,35,2180,1,175,3076,193,2083,2150,76,2151,1122,96,3205,3200,99,2151,1059,1029]

theorem envBound42652 : H12AffineFastState.Bounded env42652 := by
  intro p hp
  have h : env42652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42651_42652 : H12AffineEnvironment.transform 15 192 env42651 = env42652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 192 env42651 == env42652) = true)

theorem identity42652 : scanCanonicalize (H12AffineFastState.compose env42652 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 7) := by decide +kernel

theorem selectedBound42652 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env42653 : List Nat := [2,4,8,1,32,7,128,37,38,1024,2048,0,3209,1061,2181,135,2087,7,35,2180,1,175,3076,134,2083,2081,11,2080,1061,39,3205,3200,36,2080,1059,1029]

theorem envBound42653 : H12AffineFastState.Bounded env42653 := by
  intro p hp
  have h : env42653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42652_42653 : H12AffineEnvironment.transform 5 7 env42652 = env42653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 7 env42652 == env42653) = true)

theorem identity42653 : scanCanonicalize (H12AffineFastState.compose env42653 (packedSelected [0,1,2,5,7,11,13,15,18,19] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound42653 : packedSelected [0,1,2,5,7,11,13,15,18,19] rootPS < 2^1333 := by decide +kernel

def env42654 : List Nat := [2,4,8,1,32,7,128,37,38,1024,11,0,1154,1061,142,135,44,7,35,143,1,175,1039,134,40,42,11,43,1061,39,1166,1163,36,43,1059,1029]

theorem envBound42654 : H12AffineFastState.Bounded env42654 := by
  intro p hp
  have h : env42654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42653_42654 : H12AffineEnvironment.transform 10 11 env42653 = env42654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env42653 == env42654) = true)

theorem identity42654 : scanCanonicalize (H12AffineFastState.compose env42654 (packedSelected [0,1,2,4,7,8,9,10,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 135) := by decide +kernel

theorem selectedBound42654 : packedSelected [0,1,2,4,7,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env42655 : List Nat := [2,4,8,1,32,7,128,37,38,135,11,0,5,162,142,135,44,7,35,143,1,175,136,134,40,42,11,43,162,39,9,12,36,43,164,130]

theorem envBound42655 : H12AffineFastState.Bounded env42655 := by
  intro p hp
  have h : env42655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42654_42655 : H12AffineEnvironment.transform 9 135 env42654 = env42655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 135 env42654 == env42655) = true)

theorem identity42655 : scanCanonicalize (H12AffineFastState.compose env42655 (packedSelected [0,8,9] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound42655 : packedSelected [0,8,9] rootPS < 2^1333 := by decide +kernel

def env42656 : List Nat := [2,4,8,1,12,7,128,9,10,135,11,0,5,142,142,135,0,7,15,143,1,131,136,134,4,6,11,7,142,11,9,12,8,7,136,130]

theorem envBound42656 : H12AffineFastState.Bounded env42656 := by
  intro p hp
  have h : env42656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42655_42656 : H12AffineEnvironment.transform 4 12 env42655 = env42656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env42655 == env42656) = true)

theorem identity42656 : scanCanonicalize (H12AffineFastState.compose env42656 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound42656 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42657 : List Nat := [2,4,8,1,12,7,8,9,10,15,11,0,5,6,6,15,0,7,15,7,1,11,0,14,4,6,11,7,6,11,9,12,8,7,0,10]

theorem envBound42657 : H12AffineFastState.Bounded env42657 := by
  intro p hp
  have h : env42657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42656_42657 : H12AffineEnvironment.transform 6 8 env42656 = env42657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env42656 == env42657) = true)

theorem identity42657 : scanCanonicalize (H12AffineFastState.compose env42657 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound42657 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42658 : List Nat := [2,4,5,1,1,7,5,4,7,2,6,0,5,6,6,2,0,7,2,7,1,6,0,3,4,6,6,7,6,6,4,1,5,7,0,7]

theorem envBound42658 : H12AffineFastState.Bounded env42658 := by
  intro p hp
  have h : env42658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42657_42658 : H12AffineEnvironment.transform 2 5 env42657 = env42658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env42657 == env42658) = true)

def env42659 : List Nat := [2,4,8,1,32,64,128,98,38,1024,2048,0,3209,1122,2181,193,2086,65,35,2180,1,175,3077,192,2083,2151,76,2150,1122,97,3205,3200,99,2150,1059,1029]

theorem envBound42659 : H12AffineFastState.Bounded env42659 := by
  intro p hp
  have h : env42659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42651_42659 : H12AffineEnvironment.transform 15 193 env42651 = env42659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 193 env42651 == env42659) = true)

theorem identity42659 : scanCanonicalize (H12AffineFastState.compose env42659 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 1026) := by decide +kernel

theorem selectedBound42659 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env42660 : List Nat := [2,4,8,1,32,64,128,98,38,1024,1026,0,139,1122,1159,193,1060,65,35,1158,1,175,7,192,1057,1125,76,1124,1122,97,135,130,99,1124,1059,1029]

theorem envBound42660 : H12AffineFastState.Bounded env42660 := by
  intro p hp
  have h : env42660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42659_42660 : H12AffineEnvironment.transform 10 1026 env42659 = env42660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1026 env42659 == env42660) = true)

theorem identity42660 : scanCanonicalize (H12AffineFastState.compose env42660 (packedSelected [4,8,9,10,11,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 203) := by decide +kernel

theorem selectedBound42660 : packedSelected [4,8,9,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env42661 : List Nat := [2,4,8,1,32,64,128,98,38,203,201,0,139,169,76,193,239,65,35,77,1,175,7,192,234,174,76,175,169,97,135,130,99,175,232,206]

theorem envBound42661 : H12AffineFastState.Bounded env42661 := by
  intro p hp
  have h : env42661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42660_42661 : H12AffineEnvironment.transform 9 203 env42660 = env42661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 203 env42660 == env42661) = true)

theorem identity42661 : scanCanonicalize (H12AffineFastState.compose env42661 (packedSelected [0,1,4,7,9,12] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound42661 : packedSelected [0,1,4,7,9,12] rootPS < 2^1333 := by decide +kernel

def env42662 : List Nat := [2,4,8,1,32,64,40,98,38,99,97,0,35,1,76,105,71,65,35,77,1,7,7,104,66,6,76,7,1,97,47,42,99,7,64,102]

theorem envBound42662 : H12AffineFastState.Bounded env42662 := by
  intro p hp
  have h : env42662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42661_42662 : H12AffineEnvironment.transform 6 40 env42661 = env42662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env42661 == env42662) = true)

theorem identity42662 : scanCanonicalize (H12AffineFastState.compose env42662 (packedSelected [0,4,8] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound42662 : packedSelected [0,4,8] rootPS < 2^1333 := by decide +kernel

def env42663 : List Nat := [2,4,8,1,10,64,2,72,12,73,75,0,9,1,76,67,71,65,9,77,1,7,7,66,66,6,76,7,1,75,5,0,73,7,64,76]

theorem envBound42663 : H12AffineFastState.Bounded env42663 := by
  intro p hp
  have h : env42663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42662_42663 : H12AffineEnvironment.transform 4 10 env42662 = env42663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env42662 == env42663) = true)

theorem identity42663 : scanCanonicalize (H12AffineFastState.compose env42663 (packedSelected [2,5] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound42663 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env42664 : List Nat := [2,4,4,1,6,64,2,68,0,69,71,0,5,1,64,67,71,65,5,65,1,7,7,66,66,6,64,7,1,71,5,0,69,7,64,64]

theorem envBound42664 : H12AffineFastState.Bounded env42664 := by
  intro p hp
  have h : env42664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42663_42664 : H12AffineEnvironment.transform 2 4 env42663 = env42664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env42663 == env42664) = true)

theorem identity42664 : scanCanonicalize (H12AffineFastState.compose env42664 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound42664 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42665 : List Nat := [2,2,2,1,0,64,2,66,0,67,65,0,3,1,64,67,65,65,3,65,1,1,1,66,66,0,64,1,1,65,3,0,67,1,64,64]

theorem envBound42665 : H12AffineFastState.Bounded env42665 := by
  intro p hp
  have h : env42665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42664_42665 : H12AffineEnvironment.transform 1 2 env42664 = env42665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env42664 == env42665) = true)

def env42666 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74862,65665,4417,13340,4097,476,74046,69648,13768,78895,4414,74815,1297,81227,8204,8201,257,74798,1345,5953]

theorem envBound42666 : H12AffineFastState.Bounded env42666 := by
  intro p hp
  have h : env42666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42573_42666 : H12AffineEnvironment.transform 17 65665 env42573 = env42666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env42573 == env42666) = true)

theorem identity42666 : scanCanonicalize (H12AffineFastState.compose env42666 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound42666 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env42667 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,81,12637,65536,74030,65665,4417,12636,4097,476,74046,69648,12424,78191,4414,74111,81,79883,8204,8201,257,74094,1,4609]

theorem envBound42667 : H12AffineFastState.Bounded env42667 := by
  intro p hp
  have h : env42667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42666_42667 : H12AffineEnvironment.transform 9 320 env42666 = env42667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env42666 == env42667) = true)

def env42668 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,4096,8192,81,12637,65536,74030,65665,4417,12636,4097,476,74046,69648,12424,78191,4414,74111,81,79883,8204,8201,257,74094,1,4437]

theorem envBound42668 : H12AffineFastState.Bounded env42668 := by
  intro p hp
  have h : env42668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42667_42668 : H12AffineEnvironment.transform 8 340 env42667 = env42668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env42667 == env42668) = true)

def env42669 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,16,8192,81,8525,65536,74030,65665,337,8524,17,476,74046,65536,8344,74111,302,74111,81,75803,8204,8201,257,74094,1,325]

theorem envBound42669 : H12AffineFastState.Bounded env42669 := by
  intro p hp
  have h : env42669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42668_42669 : H12AffineEnvironment.transform 11 16 env42668 = env42669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env42668 == env42669) = true)

theorem identity42669 : scanCanonicalize (H12AffineFastState.compose env42669 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 5) := by decide +kernel

theorem selectedBound42669 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env42670 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,16,8192,81,8525,5,8491,132,337,8524,17,476,8507,5,8344,8570,302,8570,81,10270,8204,8201,257,8555,1,325]

theorem envBound42670 : H12AffineFastState.Bounded env42670 := by
  intro p hp
  have h : env42670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42669_42670 : H12AffineEnvironment.transform 15 5 env42669 = env42670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5 env42669 == env42670) = true)

def env42671 : List Nat := [2,4,8,0,32,64,128,256,324,320,2048,0,8192,65,8525,5,8491,132,321,8524,1,460,8491,5,8328,8554,302,8554,65,10254,8204,8201,257,8555,1,325]

theorem envBound42671 : H12AffineFastState.Bounded env42671 := by
  intro p hp
  have h : env42671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42670_42671 : H12AffineEnvironment.transform 3 0 env42670 = env42671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env42670 == env42671) = true)

theorem identity42671 : scanCanonicalize (H12AffineFastState.compose env42671 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 110) := by decide +kernel

theorem selectedBound42671 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env42672 : List Nat := [2,4,8,0,32,64,128,256,324,320,2048,0,110,65,291,5,325,132,321,290,1,460,325,5,230,260,302,260,65,2144,98,103,257,261,1,325]

theorem envBound42672 : H12AffineFastState.Bounded env42672 := by
  intro p hp
  have h : env42672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42671_42672 : H12AffineEnvironment.transform 12 110 env42671 = env42672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 110 env42671 == env42672) = true)

theorem identity42672 : scanCanonicalize (H12AffineFastState.compose env42672 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 35) := by decide +kernel

theorem selectedBound42672 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env42673 : List Nat := [2,4,8,0,32,64,128,35,103,99,2048,0,110,65,0,5,102,132,98,1,1,239,102,5,230,39,13,39,65,2144,98,103,34,38,1,102]

theorem envBound42673 : H12AffineFastState.Bounded env42673 := by
  intro p hp
  have h : env42673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42672_42673 : H12AffineEnvironment.transform 7 35 env42672 = env42673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 35 env42672 == env42673) = true)

theorem identity42673 : scanCanonicalize (H12AffineFastState.compose env42673 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound42673 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42674 : List Nat := [2,4,8,0,32,1,128,35,38,34,2048,0,47,0,0,5,39,132,35,1,1,174,39,5,167,39,13,39,0,2081,35,38,34,38,1,39]

theorem envBound42674 : H12AffineFastState.Bounded env42674 := by
  intro p hp
  have h : env42674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42673_42674 : H12AffineEnvironment.transform 5 1 env42673 = env42674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env42673 == env42674) = true)

theorem identity42674 : scanCanonicalize (H12AffineFastState.compose env42674 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound42674 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42675 : List Nat := [2,4,8,0,32,1,8,35,38,34,2048,0,47,0,0,5,39,12,35,1,1,38,39,5,47,39,13,39,0,2081,35,38,34,38,1,39]

theorem envBound42675 : H12AffineFastState.Bounded env42675 := by
  intro p hp
  have h : env42675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42674_42675 : H12AffineEnvironment.transform 6 8 env42674 = env42675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env42674 == env42675) = true)

theorem identity42675 : scanCanonicalize (H12AffineFastState.compose env42675 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 7) := by decide +kernel

theorem selectedBound42675 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42676 : List Nat := [2,4,8,0,32,1,8,35,38,34,7,0,47,0,0,5,39,12,35,1,1,38,39,5,47,39,13,39,0,38,35,38,34,38,1,39]

theorem envBound42676 : H12AffineFastState.Bounded env42676 := by
  intro p hp
  have h : env42676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42675_42676 : H12AffineEnvironment.transform 10 7 env42675 = env42676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 7 env42675 == env42676) = true)

theorem identity42676 : scanCanonicalize (H12AffineFastState.compose env42676 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 14) := by decide +kernel

theorem selectedBound42676 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env42677 : List Nat := [2,4,8,0,14,1,8,13,8,12,7,0,1,0,0,5,9,12,13,1,1,8,9,5,1,9,13,9,0,8,13,8,12,8,1,9]

theorem envBound42677 : H12AffineFastState.Bounded env42677 := by
  intro p hp
  have h : env42677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42676_42677 : H12AffineEnvironment.transform 4 14 env42676 = env42677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 14 env42676 == env42677) = true)

theorem identity42677 : scanCanonicalize (H12AffineFastState.compose env42677 (packedSelected [7] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound42677 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env42678 : List Nat := [2,4,5,0,3,1,5,0,5,1,7,0,1,0,0,5,4,1,0,1,1,5,4,5,1,4,0,4,0,5,0,5,1,5,1,4]

theorem envBound42678 : H12AffineFastState.Bounded env42678 := by
  intro p hp
  have h : env42678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42677_42678 : H12AffineEnvironment.transform 2 5 env42677 = env42678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env42677 == env42678) = true)

theorem identity42678 : scanCanonicalize (H12AffineFastState.compose env42678 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound42678 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env42679 : List Nat := [0,4,5,0,1,1,5,0,5,1,5,0,1,0,0,5,4,1,0,1,1,5,4,5,1,4,0,4,0,5,0,5,1,5,1,4]

theorem envBound42679 : H12AffineFastState.Bounded env42679 := by
  intro p hp
  have h : env42679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42678_42679 : H12AffineEnvironment.transform 0 0 env42678 = env42679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env42678 == env42679) = true)

theorem identity42679 : scanCanonicalize (H12AffineFastState.compose env42679 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound42679 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42680 : List Nat := [0,0,1,0,1,1,1,0,1,1,1,0,1,0,0,1,0,1,0,1,1,1,0,1,1,0,0,0,0,1,0,1,1,1,1,0]

theorem envBound42680 : H12AffineFastState.Bounded env42680 := by
  intro p hp
  have h : env42680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42679_42680 : H12AffineEnvironment.transform 1 0 env42679 = env42680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env42679 == env42680) = true)

def env42681 : List Nat := [2,4,8,1,32,64,128,256,325,320,2048,1,8192,64,8525,5,8491,132,320,8524,0,461,8490,5,8329,8555,302,8555,64,10255,8204,8201,257,8555,1,325]

theorem envBound42681 : H12AffineFastState.Bounded env42681 := by
  intro p hp
  have h : env42681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42670_42681 : H12AffineEnvironment.transform 3 1 env42670 = env42681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env42670 == env42681) = true)

theorem identity42681 : scanCanonicalize (H12AffineFastState.compose env42681 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound42681 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env42682 : List Nat := [2,4,8,1,32,64,128,5,64,69,2048,1,8192,64,8264,5,8238,132,69,8265,0,200,8239,5,8329,8302,43,8302,64,10255,8204,8201,4,8302,1,64]

theorem envBound42682 : H12AffineFastState.Bounded env42682 := by
  intro p hp
  have h : env42682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42681_42682 : H12AffineEnvironment.transform 7 5 env42681 = env42682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env42681 == env42682) = true)

theorem identity42682 : scanCanonicalize (H12AffineFastState.compose env42682 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound42682 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env42683 : List Nat := [2,4,8,1,32,1,128,5,1,4,2048,1,8192,1,8201,5,8238,132,4,8200,0,137,8239,5,8329,8239,43,8239,1,10255,8204,8201,4,8239,1,1]

theorem envBound42683 : H12AffineFastState.Bounded env42683 := by
  intro p hp
  have h : env42683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42682_42683 : H12AffineEnvironment.transform 5 1 env42682 = env42683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env42682 == env42683) = true)

theorem identity42683 : scanCanonicalize (H12AffineFastState.compose env42683 (packedSelected [0,3,7,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound42683 : packedSelected [0,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env42684 : List Nat := [2,4,8,1,32,1,128,5,1,4,0,1,8192,1,8201,5,8238,132,4,8200,0,137,8239,5,8329,8239,43,8239,1,8207,8204,8201,4,8239,1,1]

theorem envBound42684 : H12AffineFastState.Bounded env42684 := by
  intro p hp
  have h : env42684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42683_42684 : H12AffineEnvironment.transform 10 0 env42683 = env42684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env42683 == env42684) = true)

theorem identity42684 : scanCanonicalize (H12AffineFastState.compose env42684 (packedSelected [3] rootPS)) = affineNative (2^(12+1) ^^^ 37) := by decide +kernel

theorem selectedBound42684 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env42685 : List Nat := [2,4,8,1,32,1,128,5,1,4,0,1,37,1,44,5,11,132,4,45,0,137,10,5,172,10,43,10,1,42,41,44,4,10,1,1]

theorem envBound42685 : H12AffineFastState.Bounded env42685 := by
  intro p hp
  have h : env42685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42684_42685 : H12AffineEnvironment.transform 12 37 env42684 = env42685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 37 env42684 == env42685) = true)

theorem identity42685 : scanCanonicalize (H12AffineFastState.compose env42685 (packedSelected [0,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound42685 : packedSelected [0,2,5] rootPS < 2^1333 := by decide +kernel

def env42686 : List Nat := [2,4,8,1,12,1,128,5,1,4,0,1,9,1,0,5,11,132,4,1,0,137,10,5,128,10,7,10,1,6,5,0,4,10,1,1]

theorem envBound42686 : H12AffineFastState.Bounded env42686 := by
  intro p hp
  have h : env42686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42685_42686 : H12AffineEnvironment.transform 4 12 env42685 = env42686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env42685 == env42686) = true)

theorem identity42686 : scanCanonicalize (H12AffineFastState.compose env42686 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound42686 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42687 : List Nat := [2,4,8,1,12,1,14,5,1,4,0,1,9,1,0,5,11,10,4,1,0,7,10,5,14,10,7,10,1,6,5,0,4,10,1,1]

theorem envBound42687 : H12AffineFastState.Bounded env42687 := by
  intro p hp
  have h : env42687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42686_42687 : H12AffineEnvironment.transform 6 14 env42686 = env42687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env42686 == env42687) = true)

theorem identity42687 : scanCanonicalize (H12AffineFastState.compose env42687 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound42687 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42688 : List Nat := [2,4,5,1,1,1,3,5,1,4,0,1,4,1,0,5,6,7,4,1,0,7,7,5,3,7,7,7,1,6,5,0,4,7,1,1]

theorem envBound42688 : H12AffineFastState.Bounded env42688 := by
  intro p hp
  have h : env42688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42687_42688 : H12AffineEnvironment.transform 2 5 env42687 = env42688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env42687 == env42688) = true)

def env42689 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,17,8192,81,8524,65536,74030,65665,336,8525,16,476,74046,65537,8345,74110,303,74111,81,75802,8204,8201,257,74094,1,324]

theorem envBound42689 : H12AffineFastState.Bounded env42689 := by
  intro p hp
  have h : env42689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42668_42689 : H12AffineEnvironment.transform 11 17 env42668 = env42689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env42668 == env42689) = true)

theorem identity42689 : scanCanonicalize (H12AffineFastState.compose env42689 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8269) := by decide +kernel

theorem selectedBound42689 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env42690 : List Nat := [2,4,8,16,32,64,128,256,340,320,2048,17,8192,81,8524,8269,355,8396,336,8525,16,476,371,8268,8345,307,303,306,81,2135,8204,8201,257,291,1,324]

theorem envBound42690 : H12AffineFastState.Bounded env42690 := by
  intro p hp
  have h : env42690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42689_42690 : H12AffineEnvironment.transform 15 8269 env42689 = env42690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8269 env42689 == env42690) = true)

def env42691 : List Nat := [2,4,8,0,32,64,128,256,324,320,2048,1,8192,65,8524,8269,355,8396,320,8525,0,460,355,8268,8329,291,303,290,65,2119,8204,8201,257,291,1,324]

theorem envBound42691 : H12AffineFastState.Bounded env42691 := by
  intro p hp
  have h : env42691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42690_42691 : H12AffineEnvironment.transform 3 0 env42690 = env42691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env42690 == env42691) = true)

theorem identity42691 : scanCanonicalize (H12AffineFastState.compose env42691 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound42691 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env42692 : List Nat := [2,4,8,0,32,64,128,4,64,68,2048,1,8192,65,8264,8269,103,8396,68,8265,0,200,103,8268,8329,39,43,38,65,2119,8204,8201,5,39,1,64]

theorem envBound42692 : H12AffineFastState.Bounded env42692 := by
  intro p hp
  have h : env42692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42691_42692 : H12AffineEnvironment.transform 7 4 env42691 = env42692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env42691 == env42692) = true)

theorem identity42692 : scanCanonicalize (H12AffineFastState.compose env42692 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound42692 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env42693 : List Nat := [2,4,8,0,32,0,128,4,0,4,2048,1,8192,1,8200,8205,39,8332,4,8201,0,136,39,8204,8329,39,43,38,1,2055,8204,8201,5,39,1,0]

theorem envBound42693 : H12AffineFastState.Bounded env42693 := by
  intro p hp
  have h : env42693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42692_42693 : H12AffineEnvironment.transform 5 0 env42692 = env42693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env42692 == env42693) = true)

theorem identity42693 : scanCanonicalize (H12AffineFastState.compose env42693 (packedSelected [0,3,7,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 38) := by decide +kernel

theorem selectedBound42693 : packedSelected [0,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env42694 : List Nat := [2,4,8,0,32,0,128,4,0,4,38,1,8192,1,8200,8205,39,8332,4,8201,0,136,39,8204,8329,39,43,38,1,33,8204,8201,5,39,1,0]

theorem envBound42694 : H12AffineFastState.Bounded env42694 := by
  intro p hp
  have h : env42694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42693_42694 : H12AffineEnvironment.transform 10 38 env42693 = env42694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 38 env42693 == env42694) = true)

theorem identity42694 : scanCanonicalize (H12AffineFastState.compose env42694 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound42694 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env42695 : List Nat := [2,4,8,0,13,0,128,4,0,4,11,1,8192,1,8200,8205,10,8332,4,8201,0,136,10,8204,8329,10,6,11,1,12,8204,8201,5,10,1,0]

theorem envBound42695 : H12AffineFastState.Bounded env42695 := by
  intro p hp
  have h : env42695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42694_42695 : H12AffineEnvironment.transform 4 13 env42694 = env42695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env42694 == env42695) = true)

theorem identity42695 : scanCanonicalize (H12AffineFastState.compose env42695 (packedSelected [0,4,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 129) := by decide +kernel

theorem selectedBound42695 : packedSelected [0,4,5,7] rootPS < 2^1333 := by decide +kernel

def env42696 : List Nat := [2,4,8,0,13,0,128,4,0,4,11,1,129,1,137,140,10,13,4,136,0,136,10,141,8,10,6,11,1,12,141,136,5,10,1,0]

theorem envBound42696 : H12AffineFastState.Bounded env42696 := by
  intro p hp
  have h : env42696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42695_42696 : H12AffineEnvironment.transform 12 129 env42695 = env42696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 129 env42695 == env42696) = true)

theorem identity42696 : scanCanonicalize (H12AffineFastState.compose env42696 (packedSelected [2,4] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound42696 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env42697 : List Nat := [2,4,8,0,13,0,3,4,0,4,11,1,2,1,10,15,10,13,4,11,0,11,10,14,8,10,6,11,1,12,14,11,5,10,1,0]

theorem envBound42697 : H12AffineFastState.Bounded env42697 := by
  intro p hp
  have h : env42697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42696_42697 : H12AffineEnvironment.transform 6 3 env42696 = env42697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env42696 == env42697) = true)

theorem identity42697 : scanCanonicalize (H12AffineFastState.compose env42697 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound42697 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42698 : List Nat := [2,4,5,0,0,0,3,4,0,4,6,1,2,1,7,2,7,0,4,6,0,6,7,3,5,7,6,6,1,1,3,6,5,7,1,0]

theorem envBound42698 : H12AffineFastState.Bounded env42698 := by
  intro p hp
  have h : env42698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42697_42698 : H12AffineEnvironment.transform 2 5 env42697 = env42698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env42697 == env42698) = true)

theorem identity42698 : scanCanonicalize (H12AffineFastState.compose env42698 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound42698 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42699 : List Nat := [2,3,2,0,0,0,3,3,0,3,1,1,2,1,0,2,0,0,3,1,0,1,0,3,2,0,1,1,1,1,3,1,2,0,1,0]

theorem envBound42699 : H12AffineFastState.Bounded env42699 := by
  intro p hp
  have h : env42699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42698_42699 : H12AffineEnvironment.transform 1 3 env42698 = env42699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env42698 == env42699) = true)

def env42700 : List Nat := [2,4,8,1,32,64,128,256,325,320,2048,0,8192,64,8524,8269,355,8396,321,8525,1,461,354,8268,8328,290,303,291,64,2118,8204,8201,257,291,1,324]

theorem envBound42700 : H12AffineFastState.Bounded env42700 := by
  intro p hp
  have h : env42700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42690_42700 : H12AffineEnvironment.transform 3 1 env42690 = env42700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env42690 == env42700) = true)

theorem identity42700 : scanCanonicalize (H12AffineFastState.compose env42700 (packedSelected [4,9,16] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound42700 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env42701 : List Nat := [2,4,8,1,6,64,128,256,325,320,2048,0,8192,64,8524,8269,325,8396,321,8525,1,461,324,8268,8328,260,265,261,64,2118,8204,8201,257,261,1,324]

theorem envBound42701 : H12AffineFastState.Bounded env42701 := by
  intro p hp
  have h : env42701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42700_42701 : H12AffineEnvironment.transform 4 6 env42700 = env42701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env42700 == env42701) = true)

theorem identity42701 : scanCanonicalize (H12AffineFastState.compose env42701 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 332) := by decide +kernel

theorem selectedBound42701 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env42702 : List Nat := [2,4,8,1,6,64,128,256,325,320,2048,0,332,64,0,257,325,384,321,1,1,461,324,256,452,260,265,261,64,2118,320,325,257,261,1,324]

theorem envBound42702 : H12AffineFastState.Bounded env42702 := by
  intro p hp
  have h : env42702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42701_42702 : H12AffineEnvironment.transform 12 332 env42701 = env42702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 332 env42701 == env42702) = true)

theorem identity42702 : scanCanonicalize (H12AffineFastState.compose env42702 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound42702 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42703 : List Nat := [2,4,8,1,6,1,128,256,260,257,2048,0,269,1,0,257,260,384,256,1,1,396,261,256,389,260,265,261,1,2055,257,260,257,261,1,261]

theorem envBound42703 : H12AffineFastState.Bounded env42703 := by
  intro p hp
  have h : env42703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42702_42703 : H12AffineEnvironment.transform 5 1 env42702 = env42703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env42702 == env42703) = true)

theorem identity42703 : scanCanonicalize (H12AffineFastState.compose env42703 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound42703 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42704 : List Nat := [2,4,5,1,6,1,128,256,260,257,2048,0,256,1,0,257,260,384,256,1,1,385,261,256,389,260,260,261,1,2055,257,260,257,261,1,261]

theorem envBound42704 : H12AffineFastState.Bounded env42704 := by
  intro p hp
  have h : env42704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42703_42704 : H12AffineEnvironment.transform 2 5 env42703 = env42704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env42703 == env42704) = true)

theorem identity42704 : scanCanonicalize (H12AffineFastState.compose env42704 (packedSelected [1,5] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound42704 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env42705 : List Nat := [2,4,5,1,6,1,3,256,260,257,2048,0,256,1,0,257,260,259,256,1,1,258,261,256,262,260,260,261,1,2055,257,260,257,261,1,261]

theorem envBound42705 : H12AffineFastState.Bounded env42705 := by
  intro p hp
  have h : env42705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42704_42705 : H12AffineEnvironment.transform 6 3 env42704 = env42705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env42704 == env42705) = true)

theorem identity42705 : scanCanonicalize (H12AffineFastState.compose env42705 (packedSelected [0,1,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 263) := by decide +kernel

theorem selectedBound42705 : packedSelected [0,1,4,7] rootPS < 2^1333 := by decide +kernel

def env42706 : List Nat := [2,4,5,1,6,1,3,256,260,257,263,0,256,1,0,257,260,259,256,1,1,258,261,256,262,260,260,261,1,256,257,260,257,261,1,261]

theorem envBound42706 : H12AffineFastState.Bounded env42706 := by
  intro p hp
  have h : env42706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42705_42706 : H12AffineEnvironment.transform 10 263 env42705 = env42706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 263 env42705 == env42706) = true)

theorem identity42706 : scanCanonicalize (H12AffineFastState.compose env42706 (packedSelected [8] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound42706 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env42707 : List Nat := [2,2,3,1,0,1,3,256,258,257,257,0,256,1,0,257,258,259,256,1,1,258,259,256,256,258,258,259,1,256,257,258,257,259,1,259]

theorem envBound42707 : H12AffineFastState.Bounded env42707 := by
  intro p hp
  have h : env42707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42706_42707 : H12AffineEnvironment.transform 1 2 env42706 = env42707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env42706 == env42707) = true)

theorem identity42707 : scanCanonicalize (H12AffineFastState.compose env42707 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 1) := by decide +kernel

theorem selectedBound42707 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42708 : List Nat := [2,2,3,1,0,1,3,1,3,0,0,0,1,1,0,0,3,2,1,1,1,3,2,1,1,3,3,2,1,1,0,3,0,2,1,2]

theorem envBound42708 : H12AffineFastState.Bounded env42708 := by
  intro p hp
  have h : env42708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42707_42708 : H12AffineEnvironment.transform 7 1 env42707 = env42708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 1 env42707 == env42708) = true)

theorem identity42708 : scanCanonicalize (H12AffineFastState.compose env42708 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound42708 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42709 : List Nat := [0,0,1,1,0,1,1,1,1,0,0,0,1,1,0,0,1,0,1,1,1,1,0,1,1,1,1,0,1,1,0,1,0,0,1,0]

theorem envBound42709 : H12AffineFastState.Bounded env42709 := by
  intro p hp
  have h : env42709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42708_42709 : H12AffineEnvironment.transform 0 0 env42708 = env42709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env42708 == env42709) = true)

def env42710 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,4096,8192,81,12637,65536,74030,65665,4417,12636,4097,476,74046,69648,12424,78191,4414,74111,81,79883,8204,8201,257,74094,1,4436]

theorem envBound42710 : H12AffineFastState.Bounded env42710 := by
  intro p hp
  have h : env42710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42667_42710 : H12AffineEnvironment.transform 8 341 env42667 = env42710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env42667 == env42710) = true)

def env42711 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,16,8192,81,8525,65536,74030,65665,337,8524,17,476,74046,65536,8344,74111,302,74111,81,75803,8204,8201,257,74094,1,324]

theorem envBound42711 : H12AffineFastState.Bounded env42711 := by
  intro p hp
  have h : env42711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42710_42711 : H12AffineEnvironment.transform 11 16 env42710 = env42711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env42710 == env42711) = true)

theorem identity42711 : scanCanonicalize (H12AffineFastState.compose env42711 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 299) := by decide +kernel

theorem selectedBound42711 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env42712 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,16,299,81,102,65536,65541,65665,337,103,17,476,65557,65536,435,65620,302,65620,81,67888,295,290,257,65605,1,324]

theorem envBound42712 : H12AffineFastState.Bounded env42712 := by
  intro p hp
  have h : env42712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42711_42712 : H12AffineEnvironment.transform 12 299 env42711 = env42712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 299 env42711 == env42712) = true)

def env42713 : List Nat := [2,4,8,0,32,64,128,256,325,320,2048,0,299,65,102,65536,65541,65665,321,103,1,460,65541,65536,419,65604,302,65604,65,67872,295,290,257,65605,1,324]

theorem envBound42713 : H12AffineFastState.Bounded env42713 := by
  intro p hp
  have h : env42713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42712_42713 : H12AffineEnvironment.transform 3 0 env42712 = env42713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env42712 == env42713) = true)

theorem identity42713 : scanCanonicalize (H12AffineFastState.compose env42713 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 320) := by decide +kernel

theorem selectedBound42713 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env42714 : List Nat := [2,4,8,0,32,64,128,256,325,320,2048,0,299,65,102,320,325,449,321,103,1,460,325,320,419,260,302,260,65,2144,295,290,257,261,1,324]

theorem envBound42714 : H12AffineFastState.Bounded env42714 := by
  intro p hp
  have h : env42714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42713_42714 : H12AffineEnvironment.transform 15 320 env42713 = env42714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 320 env42713 == env42714) = true)

theorem identity42714 : scanCanonicalize (H12AffineFastState.compose env42714 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(5+1) ^^^ 38) := by decide +kernel

theorem selectedBound42714 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env42715 : List Nat := [2,4,8,0,32,38,128,256,291,294,2048,0,299,39,0,294,291,423,295,1,1,426,291,294,419,260,302,260,39,2054,295,290,257,261,1,290]

theorem envBound42715 : H12AffineFastState.Bounded env42715 := by
  intro p hp
  have h : env42715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42714_42715 : H12AffineEnvironment.transform 5 38 env42714 = env42715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 38 env42714 == env42715) = true)

theorem identity42715 : scanCanonicalize (H12AffineFastState.compose env42715 (packedSelected [3,5,10] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound42715 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42716 : List Nat := [2,4,8,0,7,1,128,256,260,257,2048,0,268,0,0,257,260,384,256,1,1,397,260,257,388,260,265,260,0,2054,256,261,257,261,1,261]

theorem envBound42716 : H12AffineFastState.Bounded env42716 := by
  intro p hp
  have h : env42716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42715_42716 : H12AffineEnvironment.transform 4 7 env42715 = env42716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env42715 == env42716) = true)

theorem identity42716 : scanCanonicalize (H12AffineFastState.compose env42716 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound42716 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42717 : List Nat := [2,4,8,0,7,1,9,256,260,257,2048,0,268,0,0,257,260,265,256,1,1,260,260,257,269,260,265,260,0,2054,256,261,257,261,1,261]

theorem envBound42717 : H12AffineFastState.Bounded env42717 := by
  intro p hp
  have h : env42717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42716_42717 : H12AffineEnvironment.transform 6 9 env42716 = env42717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env42716 == env42717) = true)

theorem identity42717 : scanCanonicalize (H12AffineFastState.compose env42717 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 7) := by decide +kernel

theorem selectedBound42717 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42718 : List Nat := [2,4,8,0,7,1,9,256,260,257,7,0,268,0,0,257,260,265,256,1,1,260,260,257,269,260,265,260,0,1,256,261,257,261,1,261]

theorem envBound42718 : H12AffineFastState.Bounded env42718 := by
  intro p hp
  have h : env42718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42717_42718 : H12AffineEnvironment.transform 10 7 env42717 = env42718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 7 env42717 == env42718) = true)

theorem identity42718 : scanCanonicalize (H12AffineFastState.compose env42718 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 6) := by decide +kernel

theorem selectedBound42718 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42719 : List Nat := [2,4,8,0,7,1,9,6,2,7,7,0,10,0,0,7,2,15,6,1,1,2,2,7,11,2,15,2,0,1,6,3,7,3,1,3]

theorem envBound42719 : H12AffineFastState.Bounded env42719 := by
  intro p hp
  have h : env42719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42718_42719 : H12AffineEnvironment.transform 7 6 env42718 = env42719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 6 env42718 == env42719) = true)

theorem identity42719 : scanCanonicalize (H12AffineFastState.compose env42719 (packedSelected [7] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound42719 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env42720 : List Nat := [2,4,1,0,7,1,0,6,2,7,7,0,3,0,0,7,2,6,6,1,1,2,2,7,2,2,6,2,0,1,6,3,7,3,1,3]

theorem envBound42720 : H12AffineFastState.Bounded env42720 := by
  intro p hp
  have h : env42720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42719_42720 : H12AffineEnvironment.transform 2 1 env42719 = env42720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env42719 == env42720) = true)

theorem identity42720 : scanCanonicalize (H12AffineFastState.compose env42720 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound42720 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env42721 : List Nat := [2,2,1,0,1,1,0,0,2,1,1,0,3,0,0,1,2,0,0,1,1,2,2,1,2,2,0,2,0,1,0,3,1,3,1,3]

theorem envBound42721 : H12AffineFastState.Bounded env42721 := by
  intro p hp
  have h : env42721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42720_42721 : H12AffineEnvironment.transform 1 2 env42720 = env42721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env42720 == env42721) = true)

theorem identity42721 : scanCanonicalize (H12AffineFastState.compose env42721 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound42721 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42722 : List Nat := [0,0,1,0,1,1,0,0,0,1,1,0,1,0,0,1,0,0,0,1,1,0,0,1,0,0,0,0,0,1,0,1,1,1,1,1]

theorem envBound42722 : H12AffineFastState.Bounded env42722 := by
  intro p hp
  have h : env42722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42721_42722 : H12AffineEnvironment.transform 0 0 env42721 = env42722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env42721 == env42722) = true)

def env42723 : List Nat := [2,4,8,1,32,64,128,256,324,320,2048,1,299,64,102,65536,65541,65665,320,103,0,461,65540,65536,418,65605,302,65605,64,67873,295,290,257,65605,1,324]

theorem envBound42723 : H12AffineFastState.Bounded env42723 := by
  intro p hp
  have h : env42723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42712_42723 : H12AffineEnvironment.transform 3 1 env42712 = env42723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env42712 == env42723) = true)

theorem identity42723 : scanCanonicalize (H12AffineFastState.compose env42723 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound42723 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env42724 : List Nat := [2,4,8,1,32,64,128,5,65,69,2048,1,46,64,102,65536,65541,65665,69,103,0,200,65540,65536,167,65605,43,65605,64,67620,34,39,4,65605,1,65]

theorem envBound42724 : H12AffineFastState.Bounded env42724 := by
  intro p hp
  have h : env42724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42723_42724 : H12AffineEnvironment.transform 7 5 env42723 = env42724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env42723 == env42724) = true)

theorem identity42724 : scanCanonicalize (H12AffineFastState.compose env42724 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound42724 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env42725 : List Nat := [2,4,8,1,32,1,128,5,0,4,2048,1,46,1,39,65536,65541,65665,4,38,0,137,65540,65536,167,65540,43,65540,1,67620,34,39,4,65540,1,0]

theorem envBound42725 : H12AffineFastState.Bounded env42725 := by
  intro p hp
  have h : env42725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42724_42725 : H12AffineEnvironment.transform 5 1 env42724 = env42725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env42724 == env42725) = true)

theorem identity42725 : scanCanonicalize (H12AffineFastState.compose env42725 (packedSelected [0,3,7,8,11] rootPS)) = affineNative (2^(15+1) ^^^ 2052) := by decide +kernel

theorem selectedBound42725 : packedSelected [0,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env42726 : List Nat := [2,4,8,1,32,1,128,5,0,4,2048,1,46,1,39,2052,2049,2181,4,38,0,137,2048,2052,167,2048,43,2048,1,32,34,39,4,2048,1,0]

theorem envBound42726 : H12AffineFastState.Bounded env42726 := by
  intro p hp
  have h : env42726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42725_42726 : H12AffineEnvironment.transform 15 2052 env42725 = env42726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2052 env42725 == env42726) = true)

theorem identity42726 : scanCanonicalize (H12AffineFastState.compose env42726 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound42726 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env42727 : List Nat := [2,4,8,1,32,1,128,5,0,4,10,1,46,1,39,14,11,143,4,38,0,137,10,14,167,10,43,10,1,32,34,39,4,10,1,0]

theorem envBound42727 : H12AffineFastState.Bounded env42727 := by
  intro p hp
  have h : env42727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42726_42727 : H12AffineEnvironment.transform 10 10 env42726 = env42727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env42726 == env42727) = true)

theorem identity42727 : scanCanonicalize (H12AffineFastState.compose env42727 (packedSelected [0,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 46) := by decide +kernel

theorem selectedBound42727 : packedSelected [0,4,5,7] rootPS < 2^1333 := by decide +kernel

def env42728 : List Nat := [2,4,8,1,32,1,46,5,0,4,10,1,46,1,39,14,11,33,4,38,0,39,10,14,9,10,43,10,1,32,34,39,4,10,1,0]

theorem envBound42728 : H12AffineFastState.Bounded env42728 := by
  intro p hp
  have h : env42728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42727_42728 : H12AffineEnvironment.transform 6 46 env42727 = env42728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 46 env42727 == env42728) = true)

theorem identity42728 : scanCanonicalize (H12AffineFastState.compose env42728 (packedSelected [2,4] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound42728 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env42729 : List Nat := [2,4,8,1,12,1,2,5,0,4,10,1,2,1,11,14,11,13,4,10,0,11,10,14,9,10,7,10,1,12,14,11,4,10,1,0]

theorem envBound42729 : H12AffineFastState.Bounded env42729 := by
  intro p hp
  have h : env42729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42728_42729 : H12AffineEnvironment.transform 4 12 env42728 = env42729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env42728 == env42729) = true)

theorem identity42729 : scanCanonicalize (H12AffineFastState.compose env42729 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound42729 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42730 : List Nat := [2,4,5,1,1,1,2,5,0,4,7,1,2,1,6,3,6,0,4,7,0,6,7,3,4,7,7,7,1,1,3,6,4,7,1,0]

theorem envBound42730 : H12AffineFastState.Bounded env42730 := by
  intro p hp
  have h : env42730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42729_42730 : H12AffineEnvironment.transform 2 5 env42729 = env42730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env42729 == env42730) = true)

theorem identity42730 : scanCanonicalize (H12AffineFastState.compose env42730 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound42730 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42731 : List Nat := [2,2,3,1,1,1,2,3,0,2,1,1,2,1,0,3,0,0,2,1,0,0,1,3,2,1,1,1,1,1,3,0,2,1,1,0]

theorem envBound42731 : H12AffineFastState.Bounded env42731 := by
  intro p hp
  have h : env42731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42730_42731 : H12AffineEnvironment.transform 1 2 env42730 = env42731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env42730 == env42731) = true)

def env42732 : List Nat := [2,4,8,16,32,64,128,256,341,320,2048,17,8192,81,8524,65536,74030,65665,336,8525,16,476,74046,65537,8345,74110,303,74111,81,75802,8204,8201,257,74094,1,325]

theorem envBound42732 : H12AffineFastState.Bounded env42732 := by
  intro p hp
  have h : env42732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42710_42732 : H12AffineEnvironment.transform 11 17 env42710 = env42732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env42710 == env42732) = true)

theorem identity42732 : scanCanonicalize (H12AffineFastState.compose env42732 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 99) := by decide +kernel

theorem selectedBound42732 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env42733 : List Nat := [2,4,8,16,32,64,128,99,54,35,2048,17,8192,81,8239,65536,73805,65665,51,8238,16,191,73821,65537,8345,73757,76,73756,81,75802,8204,8201,98,73741,1,38]

theorem envBound42733 : H12AffineFastState.Bounded env42733 := by
  intro p hp
  have h : env42733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42732_42733 : H12AffineEnvironment.transform 7 99 env42732 = env42733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 99 env42732 == env42733) = true)

def env42734 : List Nat := [2,4,8,0,32,64,128,99,38,35,2048,1,8192,65,8239,65536,73805,65665,35,8238,0,175,73805,65537,8329,73741,76,73740,65,75786,8204,8201,98,73741,1,38]

theorem envBound42734 : H12AffineFastState.Bounded env42734 := by
  intro p hp
  have h : env42734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42733_42734 : H12AffineEnvironment.transform 3 0 env42733 = env42734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env42733 == env42734) = true)

theorem identity42734 : scanCanonicalize (H12AffineFastState.compose env42734 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 39) := by decide +kernel

theorem selectedBound42734 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env42735 : List Nat := [2,4,8,0,32,39,128,4,38,35,2048,1,8192,38,8239,65536,73770,65665,35,8238,0,175,73770,65537,8329,73741,43,73740,38,75786,8204,8201,5,73741,1,38]

theorem envBound42735 : H12AffineFastState.Bounded env42735 := by
  intro p hp
  have h : env42735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42734_42735 : H12AffineEnvironment.transform 5 39 env42734 = env42735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 39 env42734 == env42735) = true)

theorem identity42735 : scanCanonicalize (H12AffineFastState.compose env42735 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound42735 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env42736 : List Nat := [2,4,8,0,7,0,128,4,1,4,2048,1,8192,1,8200,65536,73741,65665,4,8201,0,136,73741,65537,8329,73741,12,73740,1,75786,8204,8201,5,73741,1,1]

theorem envBound42736 : H12AffineFastState.Bounded env42736 := by
  intro p hp
  have h : env42736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42735_42736 : H12AffineEnvironment.transform 4 7 env42735 = env42736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env42735 == env42736) = true)

theorem identity42736 : scanCanonicalize (H12AffineFastState.compose env42736 (packedSelected [0,3,7,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound42736 : packedSelected [0,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env42737 : List Nat := [2,4,8,0,7,0,128,4,1,4,0,1,8192,1,8200,65536,73741,65665,4,8201,0,136,73741,65537,8329,73741,12,73740,1,73738,8204,8201,5,73741,1,1]

theorem envBound42737 : H12AffineFastState.Bounded env42737 := by
  intro p hp
  have h : env42737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42736_42737 : H12AffineEnvironment.transform 10 0 env42736 = env42737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env42736 == env42737) = true)

theorem identity42737 : scanCanonicalize (H12AffineFastState.compose env42737 (packedSelected [3] rootPS)) = affineNative (2^(15+1) ^^^ 8199) := by decide +kernel

theorem selectedBound42737 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env42738 : List Nat := [2,4,8,0,7,0,128,4,1,4,0,1,8192,1,8200,8199,10,8326,4,8201,0,136,10,8198,8329,10,12,11,1,13,8204,8201,5,10,1,1]

theorem envBound42738 : H12AffineFastState.Bounded env42738 := by
  intro p hp
  have h : env42738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42737_42738 : H12AffineEnvironment.transform 15 8199 env42737 = env42738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8199 env42737 == env42738) = true)

theorem identity42738 : scanCanonicalize (H12AffineFastState.compose env42738 (packedSelected [0,2,5] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound42738 : packedSelected [0,2,5] rootPS < 2^1333 := by decide +kernel

def env42739 : List Nat := [2,4,8,0,7,0,128,4,1,4,0,1,8,1,0,15,10,142,4,1,0,136,10,14,129,10,12,11,1,13,4,1,5,10,1,1]

theorem envBound42739 : H12AffineFastState.Bounded env42739 := by
  intro p hp
  have h : env42739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42738_42739 : H12AffineEnvironment.transform 12 8 env42738 = env42739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env42738 == env42739) = true)

theorem identity42739 : scanCanonicalize (H12AffineFastState.compose env42739 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound42739 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42740 : List Nat := [2,4,8,0,7,0,5,4,1,4,0,1,8,1,0,15,10,11,4,1,0,13,10,14,4,10,12,11,1,13,4,1,5,10,1,1]

theorem envBound42740 : H12AffineFastState.Bounded env42740 := by
  intro p hp
  have h : env42740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42739_42740 : H12AffineEnvironment.transform 6 5 env42739 = env42740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env42739 == env42740) = true)

theorem identity42740 : scanCanonicalize (H12AffineFastState.compose env42740 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound42740 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42741 : List Nat := [2,3,8,0,0,0,2,3,1,3,0,1,8,1,0,8,10,11,3,1,0,10,10,9,3,10,11,11,1,10,3,1,2,10,1,1]

theorem envBound42741 : H12AffineFastState.Bounded env42741 := by
  intro p hp
  have h : env42741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42740_42741 : H12AffineEnvironment.transform 1 3 env42740 = env42741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env42740 == env42741) = true)

def env42742 : List Nat := [2,4,8,1,32,64,128,99,39,35,2048,0,8192,64,8239,65536,73805,65665,34,8238,1,174,73804,65537,8328,73740,76,73741,64,75787,8204,8201,98,73741,1,38]

theorem envBound42742 : H12AffineFastState.Bounded env42742 := by
  intro p hp
  have h : env42742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42733_42742 : H12AffineEnvironment.transform 3 1 env42733 = env42742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env42733 == env42742) = true)

theorem identity42742 : scanCanonicalize (H12AffineFastState.compose env42742 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 8299) := by decide +kernel

theorem selectedBound42742 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env42743 : List Nat := [2,4,8,1,32,64,128,99,39,35,2048,0,8192,64,8239,8299,38,8426,34,8238,1,174,39,8298,8328,103,76,102,64,2144,8204,8201,98,102,1,38]

theorem envBound42743 : H12AffineFastState.Bounded env42743 := by
  intro p hp
  have h : env42743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42742_42743 : H12AffineEnvironment.transform 15 8299 env42742 = env42743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8299 env42742 == env42743) = true)

theorem identity42743 : scanCanonicalize (H12AffineFastState.compose env42743 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 47) := by decide +kernel

theorem selectedBound42743 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env42744 : List Nat := [2,4,8,1,32,64,128,99,39,35,2048,0,47,64,0,68,38,197,34,1,1,174,39,69,167,103,76,102,64,2144,35,38,98,102,1,38]

theorem envBound42744 : H12AffineFastState.Bounded env42744 := by
  intro p hp
  have h : env42744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42743_42744 : H12AffineEnvironment.transform 12 47 env42743 = env42744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 47 env42743 == env42744) = true)

theorem identity42744 : scanCanonicalize (H12AffineFastState.compose env42744 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound42744 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42745 : List Nat := [2,4,8,1,32,1,128,34,39,35,2048,0,47,1,0,5,38,132,34,1,1,174,39,4,167,38,13,39,1,2081,35,38,35,39,1,38]

theorem envBound42745 : H12AffineFastState.Bounded env42745 := by
  intro p hp
  have h : env42745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42744_42745 : H12AffineEnvironment.transform 5 1 env42744 = env42745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env42744 == env42745) = true)

def env42746 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,21585,32769,4097,61648,91183,123164,28888,78894,385203,90414,1296,96346,25885,25880,257,74799,1345,21073]

theorem envBound42746 : H12AffineFastState.Bounded env42746 := by
  intro p hp
  have h : env42746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42479_42746 : H12AffineEnvironment.transform 18 21585 env42479 = env42746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env42479 == env42746) = true)

theorem identity42746 : scanCanonicalize (H12AffineFastState.compose env42746 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25677) := by decide +kernel

theorem selectedBound42746 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env42747 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25677,65536,74862,262144,21585,25676,4097,5277,91183,66897,28888,78894,328958,90414,1296,96346,25885,25880,257,74799,1345,21073]

theorem envBound42747 : H12AffineFastState.Bounded env42747 := by
  intro p hp
  have h : env42747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42746_42747 : H12AffineEnvironment.transform 14 25677 env42746 = env42747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25677 env42746 == env42747) = true)

def env42748 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74862,262144,4417,8540,4097,5277,74047,66897,13768,78894,328958,74814,1296,81226,8205,8200,257,74799,1345,5953]

theorem envBound42748 : H12AffineFastState.Bounded env42748 := by
  intro p hp
  have h : env42748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42747_42748 : H12AffineEnvironment.transform 13 1296 env42747 = env42748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env42747 == env42748) = true)

def env42749 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74862,65664,4417,8540,4097,5277,74047,66897,13768,78894,1150,74814,1296,81226,8205,8200,257,74799,1345,5953]

theorem envBound42749 : H12AffineFastState.Bounded env42749 := by
  intro p hp
  have h : env42749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42748_42749 : H12AffineEnvironment.transform 17 65664 env42748 = env42749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env42748 == env42749) = true)

theorem identity42749 : scanCanonicalize (H12AffineFastState.compose env42749 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5384) := by decide +kernel

theorem selectedBound42749 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env42750 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5384,1296,5205,65536,69990,65664,4417,5204,4097,5277,70711,66897,192,65830,1150,69942,1296,67650,5381,5376,257,69927,1345,5953]

theorem envBound42750 : H12AffineFastState.Bounded env42750 := by
  intro p hp
  have h : env42750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42749_42750 : H12AffineEnvironment.transform 12 5384 env42749 = env42750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5384 env42749 == env42750) = true)

def env42751 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1556,796,1296,577,65536,67442,65664,1877,576,1557,649,66083,66897,192,65830,1150,67362,1296,67650,785,788,257,67379,1345,341]

theorem envBound42751 : H12AffineFastState.Bounded env42751 := by
  intro p hp
  have h : env42751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42750_42751 : H12AffineEnvironment.transform 11 1556 env42750 = env42751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env42750 == env42751) = true)

def env42752 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,836,796,64,577,65536,66082,65664,517,576,837,649,66083,65537,192,65830,302,66162,64,67650,785,788,257,66147,17,341]

theorem envBound42752 : H12AffineFastState.Bounded env42752 := by
  intro p hp
  have h : env42752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42751_42752 : H12AffineEnvironment.transform 9 336 env42751 = env42752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env42751 == env42752) = true)

theorem identity42752 : scanCanonicalize (H12AffineFastState.compose env42752 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 69) := by decide +kernel

theorem selectedBound42752 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env42753 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,836,796,64,577,69,615,197,517,576,837,649,614,68,192,355,302,567,64,2055,785,788,257,550,17,341]

theorem envBound42753 : H12AffineFastState.Bounded env42753 := by
  intro p hp
  have h : env42753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42752_42753 : H12AffineEnvironment.transform 15 69 env42752 = env42753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 69 env42752 == env42753) = true)

def env42754 : List Nat := [2,4,8,0,32,64,128,256,512,320,2048,836,780,64,577,69,615,197,517,576,837,649,614,68,192,355,302,551,64,2055,769,772,257,550,1,325]

theorem envBound42754 : H12AffineFastState.Bounded env42754 := by
  intro p hp
  have h : env42754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42753_42754 : H12AffineEnvironment.transform 3 0 env42753 = env42754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env42753 == env42754) = true)

theorem identity42754 : scanCanonicalize (H12AffineFastState.compose env42754 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound42754 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env42755 : List Nat := [2,4,8,0,32,64,128,4,512,68,2048,576,520,64,577,69,615,197,517,576,577,649,614,68,192,103,42,551,64,2055,517,512,5,550,1,65]

theorem envBound42755 : H12AffineFastState.Bounded env42755 := by
  intro p hp
  have h : env42755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42754_42755 : H12AffineEnvironment.transform 7 4 env42754 = env42755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env42754 == env42755) = true)

theorem identity42755 : scanCanonicalize (H12AffineFastState.compose env42755 (packedSelected [2,4,9,11,13,16,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 620) := by decide +kernel

theorem selectedBound42755 : packedSelected [2,4,9,11,13,16,17,18] rootPS < 2^1333 := by decide +kernel

def env42756 : List Nat := [2,4,8,0,32,64,128,4,512,68,620,576,520,64,577,69,615,197,517,576,577,649,614,68,192,103,42,551,64,619,517,512,5,550,1,65]

theorem envBound42756 : H12AffineFastState.Bounded env42756 := by
  intro p hp
  have h : env42756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42755_42756 : H12AffineEnvironment.transform 10 620 env42755 = env42756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 620 env42755 == env42756) = true)

theorem identity42756 : scanCanonicalize (H12AffineFastState.compose env42756 (packedSelected [1,13,15] rootPS)) = affineNative (2^(6+1) ^^^ 66) := by decide +kernel

theorem selectedBound42756 : packedSelected [1,13,15] rootPS < 2^1333 := by decide +kernel

def env42757 : List Nat := [2,4,8,0,32,64,66,4,512,68,620,576,520,64,577,69,615,7,517,576,577,587,614,68,2,103,42,551,64,619,517,512,5,550,1,65]

theorem envBound42757 : H12AffineFastState.Bounded env42757 := by
  intro p hp
  have h : env42757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42756_42757 : H12AffineEnvironment.transform 6 66 env42756 = env42757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 66 env42756 == env42757) = true)

theorem identity42757 : scanCanonicalize (H12AffineFastState.compose env42757 (packedSelected [1,3,10] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound42757 : packedSelected [1,3,10] rootPS < 2^1333 := by decide +kernel

def env42758 : List Nat := [2,4,8,0,32,64,66,4,11,68,103,75,3,64,74,69,108,7,14,75,74,64,109,68,2,103,42,44,64,96,14,11,5,45,1,65]

theorem envBound42758 : H12AffineFastState.Bounded env42758 := by
  intro p hp
  have h : env42758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42757_42758 : H12AffineEnvironment.transform 8 11 env42757 = env42758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env42757 == env42758) = true)

theorem identity42758 : scanCanonicalize (H12AffineFastState.compose env42758 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 6) := by decide +kernel

theorem selectedBound42758 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env42759 : List Nat := [2,4,8,0,32,6,4,4,11,2,33,13,3,6,12,3,42,7,14,13,12,6,43,2,2,33,42,44,6,38,14,11,5,45,1,7]

theorem envBound42759 : H12AffineFastState.Bounded env42759 := by
  intro p hp
  have h : env42759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42758_42759 : H12AffineEnvironment.transform 5 6 env42758 = env42759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 6 env42758 == env42759) = true)

theorem identity42759 : scanCanonicalize (H12AffineFastState.compose env42759 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound42759 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env42760 : List Nat := [2,4,8,0,10,6,4,4,11,2,11,13,3,6,12,3,0,7,14,13,12,6,1,2,2,11,0,6,6,12,14,11,5,7,1,7]

theorem envBound42760 : H12AffineFastState.Bounded env42760 := by
  intro p hp
  have h : env42760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42759_42760 : H12AffineEnvironment.transform 4 10 env42759 = env42760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env42759 == env42760) = true)

def env42761 : List Nat := [2,4,8,1,32,64,128,256,512,321,2048,836,781,64,577,69,615,197,517,576,837,649,614,68,192,355,302,550,64,2055,768,773,257,550,0,324]

theorem envBound42761 : H12AffineFastState.Bounded env42761 := by
  intro p hp
  have h : env42761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42753_42761 : H12AffineEnvironment.transform 3 1 env42753 = env42761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env42753 == env42761) = true)

theorem identity42761 : scanCanonicalize (H12AffineFastState.compose env42761 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound42761 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env42762 : List Nat := [2,4,8,1,32,64,128,256,64,321,2048,260,333,64,1,69,39,197,69,0,261,201,38,68,192,355,302,102,64,2055,320,325,257,102,0,324]

theorem envBound42762 : H12AffineFastState.Bounded env42762 := by
  intro p hp
  have h : env42762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42761_42762 : H12AffineEnvironment.transform 8 64 env42761 = env42762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env42761 == env42762) = true)

theorem identity42762 : scanCanonicalize (H12AffineFastState.compose env42762 (packedSelected [0,2,3,4,5,7,9,10,11,13,16,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 197) := by decide +kernel

theorem selectedBound42762 : packedSelected [0,2,3,4,5,7,9,10,11,13,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env42763 : List Nat := [2,4,8,1,32,64,128,256,64,321,197,260,333,64,1,69,39,197,69,0,261,201,38,68,192,355,302,102,64,194,320,325,257,102,0,324]

theorem envBound42763 : H12AffineFastState.Bounded env42763 := by
  intro p hp
  have h : env42763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42762_42763 : H12AffineEnvironment.transform 10 197 env42762 = env42763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 197 env42762 == env42763) = true)

theorem identity42763 : scanCanonicalize (H12AffineFastState.compose env42763 (packedSelected [0,5,7,8,10,11] rootPS)) = affineNative (2^(7+1) ^^^ 72) := by decide +kernel

theorem selectedBound42763 : packedSelected [0,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env42764 : List Nat := [2,4,8,1,32,64,128,72,64,9,197,76,5,64,1,69,39,197,69,0,77,201,38,68,192,43,102,102,64,194,8,13,73,102,0,12]

theorem envBound42764 : H12AffineFastState.Bounded env42764 := by
  intro p hp
  have h : env42764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42763_42764 : H12AffineEnvironment.transform 7 72 env42763 = env42764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 72 env42763 == env42764) = true)

theorem identity42764 : scanCanonicalize (H12AffineFastState.compose env42764 (packedSelected [2,4,8,9] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound42764 : packedSelected [2,4,8,9] rootPS < 2^1333 := by decide +kernel

def env42765 : List Nat := [2,4,8,1,13,64,128,72,64,9,197,76,5,64,1,69,10,197,69,0,77,201,11,68,192,6,75,75,64,194,8,13,73,75,0,12]

theorem envBound42765 : H12AffineFastState.Bounded env42765 := by
  intro p hp
  have h : env42765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42764_42765 : H12AffineEnvironment.transform 4 13 env42764 = env42765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env42764 == env42765) = true)

theorem identity42765 : scanCanonicalize (H12AffineFastState.compose env42765 (packedSelected [0,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound42765 : packedSelected [0,5,7] rootPS < 2^1333 := by decide +kernel

def env42766 : List Nat := [2,4,8,1,13,10,128,2,10,9,143,6,5,10,1,15,10,143,15,0,7,131,11,14,138,6,1,1,10,136,8,13,3,1,0,12]

theorem envBound42766 : H12AffineFastState.Bounded env42766 := by
  intro p hp
  have h : env42766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42765_42766 : H12AffineEnvironment.transform 5 10 env42765 = env42766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env42765 == env42766) = true)

def env42767 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,837,796,65,577,65536,66083,65664,516,576,836,649,66083,65536,192,65830,303,66163,65,67650,785,788,257,66146,16,341]

theorem envBound42767 : H12AffineFastState.Bounded env42767 := by
  intro p hp
  have h : env42767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42751_42767 : H12AffineEnvironment.transform 9 337 env42751 = env42767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env42751 == env42767) = true)

theorem identity42767 : scanCanonicalize (H12AffineFastState.compose env42767 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 769) := by decide +kernel

theorem selectedBound42767 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env42768 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,837,796,65,577,769,290,897,516,576,836,649,290,769,192,551,303,370,65,2883,785,788,257,355,16,341]

theorem envBound42768 : H12AffineFastState.Bounded env42768 := by
  intro p hp
  have h : env42768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42767_42768 : H12AffineEnvironment.transform 15 769 env42767 = env42768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 769 env42767 == env42768) = true)

def env42769 : List Nat := [2,4,8,16,32,64,128,52,512,101,2048,625,552,65,577,565,22,693,516,576,624,649,22,565,192,551,27,70,65,2679,549,544,53,87,16,97]

theorem envBound42769 : H12AffineFastState.Bounded env42769 := by
  intro p hp
  have h : env42769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42768_42769 : H12AffineEnvironment.transform 7 52 env42768 = env42769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env42768 == env42769) = true)

theorem identity42769 : scanCanonicalize (H12AffineFastState.compose env42769 (packedSelected [0,4,5,9,12,16,17,21,27,38] rootPS)) = affineNative (2^(8+1) ^^^ 190) := by decide +kernel

theorem selectedBound42769 : packedSelected [0,4,5,9,12,16,17,21,27,38] rootPS < 2^1333 := by decide +kernel

def env42770 : List Nat := [2,4,8,16,32,64,128,52,190,101,2048,207,150,65,255,139,22,11,186,254,206,55,22,139,192,153,27,70,65,2249,155,158,53,87,16,97]

theorem envBound42770 : H12AffineFastState.Bounded env42770 := by
  intro p hp
  have h : env42770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42769_42770 : H12AffineEnvironment.transform 8 190 env42769 = env42770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 190 env42769 == env42770) = true)

theorem identity42770 : scanCanonicalize (H12AffineFastState.compose env42770 (packedSelected [1,3,8,11,12,13,15,17,18,20,21] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound42770 : packedSelected [1,3,8,11,12,13,15,17,18,20,21] rootPS < 2^1333 := by decide +kernel

def env42771 : List Nat := [2,4,8,16,32,64,128,52,190,101,137,207,150,65,255,139,22,11,186,254,206,55,22,139,192,153,27,70,65,64,155,158,53,87,16,97]

theorem envBound42771 : H12AffineFastState.Bounded env42771 := by
  intro p hp
  have h : env42771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42770_42771 : H12AffineEnvironment.transform 10 137 env42770 = env42771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env42770 == env42771) = true)

theorem identity42771 : scanCanonicalize (H12AffineFastState.compose env42771 (packedSelected [1,3,12,15,16,17] rootPS)) = affineNative (2^(6+1) ^^^ 20) := by decide +kernel

theorem selectedBound42771 : packedSelected [1,3,12,15,16,17] rootPS < 2^1333 := by decide +kernel

def env42772 : List Nat := [2,4,8,16,32,64,20,52,42,101,29,91,2,65,107,31,22,11,46,106,90,55,22,31,84,13,27,70,65,64,15,10,53,87,16,97]

theorem envBound42772 : H12AffineFastState.Bounded env42772 := by
  intro p hp
  have h : env42772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42771_42772 : H12AffineEnvironment.transform 6 20 env42771 = env42772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 20 env42771 == env42772) = true)

theorem identity42772 : scanCanonicalize (H12AffineFastState.compose env42772 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound42772 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env42773 : List Nat := [2,4,8,10,32,64,14,46,42,101,7,65,2,65,107,5,12,11,46,106,64,45,12,5,78,13,1,70,65,64,15,10,47,77,10,97]

theorem envBound42773 : H12AffineFastState.Bounded env42773 := by
  intro p hp
  have h : env42773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42772_42773 : H12AffineEnvironment.transform 3 10 env42772 = env42773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env42772 == env42773) = true)

theorem identity42773 : scanCanonicalize (H12AffineFastState.compose env42773 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(5+1) ^^^ 38) := by decide +kernel

theorem selectedBound42773 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env42774 : List Nat := [2,4,8,10,32,38,14,46,42,3,7,39,2,39,13,5,12,11,46,12,38,45,12,5,40,13,1,32,39,38,15,10,47,43,10,7]

theorem envBound42774 : H12AffineFastState.Bounded env42774 := by
  intro p hp
  have h : env42774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42773_42774 : H12AffineEnvironment.transform 5 38 env42773 = env42774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 38 env42773 == env42774) = true)

theorem identity42774 : scanCanonicalize (H12AffineFastState.compose env42774 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound42774 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env42775 : List Nat := [2,2,8,10,32,32,8,40,42,3,1,33,2,33,11,3,10,11,40,10,32,43,10,3,40,11,1,32,33,32,9,10,41,43,10,1]

theorem envBound42775 : H12AffineFastState.Bounded env42775 := by
  intro p hp
  have h : env42775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42774_42775 : H12AffineEnvironment.transform 1 2 env42774 = env42775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env42774 == env42775) = true)

theorem identity42775 : scanCanonicalize (H12AffineFastState.compose env42775 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound42775 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env42776 : List Nat := [2,2,8,10,1,1,8,9,11,3,1,0,2,0,11,3,10,11,9,10,1,10,10,3,9,11,1,1,0,1,9,10,8,10,10,1]

theorem envBound42776 : H12AffineFastState.Bounded env42776 := by
  intro p hp
  have h : env42776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42775_42776 : H12AffineEnvironment.transform 4 1 env42775 = env42776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env42775 == env42776) = true)

theorem identity42776 : scanCanonicalize (H12AffineFastState.compose env42776 (packedSelected [0,7] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound42776 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env42777 : List Nat := [2,2,2,0,1,1,2,3,1,3,1,0,2,0,1,3,0,1,3,0,1,0,0,3,3,1,1,1,0,1,3,0,2,0,0,1]

theorem envBound42777 : H12AffineFastState.Bounded env42777 := by
  intro p hp
  have h : env42777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42776_42777 : H12AffineEnvironment.transform 2 2 env42776 = env42777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env42776 == env42777) = true)

def env42778 : List Nat := [2,4,8,16,32,64,128,53,512,100,2048,624,553,65,577,564,23,692,516,576,625,649,23,564,192,551,26,71,65,2678,548,545,52,86,16,96]

theorem envBound42778 : H12AffineFastState.Bounded env42778 := by
  intro p hp
  have h : env42778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42768_42778 : H12AffineEnvironment.transform 7 53 env42768 = env42778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env42768 == env42778) = true)

theorem identity42778 : scanCanonicalize (H12AffineFastState.compose env42778 (packedSelected [0,4,5,9,12,16,17,21,27,38] rootPS)) = affineNative (2^(8+1) ^^^ 185) := by decide +kernel

theorem selectedBound42778 : packedSelected [0,4,5,9,12,16,17,21,27,38] rootPS < 2^1333 := by decide +kernel

def env42779 : List Nat := [2,4,8,16,32,64,128,53,185,100,2048,201,144,65,248,141,23,13,189,249,200,48,23,141,192,158,26,71,65,2255,157,152,52,86,16,96]

theorem envBound42779 : H12AffineFastState.Bounded env42779 := by
  intro p hp
  have h : env42779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42778_42779 : H12AffineEnvironment.transform 8 185 env42778 = env42779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 185 env42778 == env42779) = true)

theorem identity42779 : scanCanonicalize (H12AffineFastState.compose env42779 (packedSelected [1,3,4,8,9,10,16,17,19] rootPS)) = affineNative (2^(6+1) ^^^ 63) := by decide +kernel

theorem selectedBound42779 : packedSelected [1,3,4,8,9,10,16,17,19] rootPS < 2^1333 := by decide +kernel

def env42780 : List Nat := [2,4,8,16,32,64,63,53,6,100,2048,118,47,65,71,50,23,13,2,70,119,48,23,50,127,33,26,71,65,2160,34,39,52,86,16,96]

theorem envBound42780 : H12AffineFastState.Bounded env42780 := by
  intro p hp
  have h : env42780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42779_42780 : H12AffineEnvironment.transform 6 63 env42779 = env42780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 63 env42779 == env42780) = true)

theorem identity42780 : scanCanonicalize (H12AffineFastState.compose env42780 (packedSelected [3,8,13,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 97) := by decide +kernel

theorem selectedBound42780 : packedSelected [3,8,13,17,18] rootPS < 2^1333 := by decide +kernel

def env42781 : List Nat := [2,4,8,16,32,64,63,53,6,100,97,118,47,65,71,50,23,13,2,70,119,48,23,50,127,33,26,71,65,17,34,39,52,86,16,96]

theorem envBound42781 : H12AffineFastState.Bounded env42781 := by
  intro p hp
  have h : env42781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42780_42781 : H12AffineEnvironment.transform 10 97 env42780 = env42781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 97 env42780 == env42781) = true)

theorem identity42781 : scanCanonicalize (H12AffineFastState.compose env42781 (packedSelected [0,2,3,4,10] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound42781 : packedSelected [0,2,3,4,10] rootPS < 2^1333 := by decide +kernel

def env42782 : List Nat := [2,4,8,16,7,64,24,18,6,67,70,81,8,65,71,21,23,13,2,70,80,23,23,21,88,6,26,71,65,17,5,0,19,86,16,71]

theorem envBound42782 : H12AffineFastState.Bounded env42782 := by
  intro p hp
  have h : env42782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42781_42782 : H12AffineEnvironment.transform 4 7 env42781 = env42782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env42781 == env42782) = true)

theorem identity42782 : scanCanonicalize (H12AffineFastState.compose env42782 (packedSelected [1,2,3,4,5,7,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound42782 : packedSelected [1,2,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env42783 : List Nat := [2,4,8,0,7,64,8,2,6,67,70,65,8,65,71,5,7,13,2,70,64,7,7,5,72,6,10,71,65,1,5,0,3,70,0,71]

theorem envBound42783 : H12AffineFastState.Bounded env42783 := by
  intro p hp
  have h : env42783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42782_42783 : H12AffineEnvironment.transform 3 0 env42782 = env42783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env42782 == env42783) = true)

theorem identity42783 : scanCanonicalize (H12AffineFastState.compose env42783 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound42783 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42784 : List Nat := [2,4,8,0,7,11,8,2,6,8,13,10,8,10,12,5,7,13,2,13,11,7,7,5,3,6,10,12,10,1,5,0,3,13,0,12]

theorem envBound42784 : H12AffineFastState.Bounded env42784 := by
  intro p hp
  have h : env42784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42783_42784 : H12AffineEnvironment.transform 5 11 env42783 = env42784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env42783 == env42784) = true)

theorem identity42784 : scanCanonicalize (H12AffineFastState.compose env42784 (packedSelected [2,3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound42784 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env42785 : List Nat := [2,4,5,0,7,6,5,2,6,5,0,7,5,7,1,5,7,0,2,0,6,7,7,5,3,6,7,1,7,1,5,0,3,0,0,1]

theorem envBound42785 : H12AffineFastState.Bounded env42785 := by
  intro p hp
  have h : env42785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42784_42785 : H12AffineEnvironment.transform 2 5 env42784 = env42785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env42784 == env42785) = true)

def env42786 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1557,797,1296,576,65536,67443,65664,1876,577,1556,648,66082,66897,192,65830,1150,67363,1296,67650,784,789,257,67378,1345,340]

theorem envBound42786 : H12AffineFastState.Bounded env42786 := by
  intro p hp
  have h : env42786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42750_42786 : H12AffineEnvironment.transform 11 1557 env42750 = env42786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env42750 == env42786) = true)

def env42787 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,837,797,64,576,65536,66083,65664,516,577,836,648,66082,65537,192,65830,302,66163,64,67650,784,789,257,66146,17,340]

theorem envBound42787 : H12AffineFastState.Bounded env42787 := by
  intro p hp
  have h : env42787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42786_42787 : H12AffineEnvironment.transform 9 336 env42786 = env42787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env42786 == env42787) = true)

theorem identity42787 : scanCanonicalize (H12AffineFastState.compose env42787 (packedSelected [1,8,28] rootPS)) = affineNative (2^(8+1) ^^^ 119) := by decide +kernel

theorem selectedBound42787 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env42788 : List Nat := [2,4,8,16,32,64,128,256,119,336,2048,306,362,64,55,65536,65620,65664,115,54,307,255,65621,65537,192,65830,302,65540,64,67650,359,354,257,65557,17,340]

theorem envBound42788 : H12AffineFastState.Bounded env42788 := by
  intro p hp
  have h : env42788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42787_42788 : H12AffineEnvironment.transform 8 119 env42787 = env42788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 119 env42787 == env42788) = true)

def env42789 : List Nat := [2,4,8,0,32,64,128,256,103,320,2048,290,362,64,39,65536,65604,65664,99,38,291,239,65605,65537,192,65830,302,65540,64,67650,359,354,257,65541,1,324]

theorem envBound42789 : H12AffineFastState.Bounded env42789 := by
  intro p hp
  have h : env42789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42788_42789 : H12AffineEnvironment.transform 3 0 env42788 = env42789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env42788 == env42789) = true)

theorem identity42789 : scanCanonicalize (H12AffineFastState.compose env42789 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound42789 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env42790 : List Nat := [2,4,8,0,32,64,128,4,103,68,2048,38,110,64,39,65536,65604,65664,99,38,39,239,65605,65537,192,65570,42,65540,64,67650,99,102,5,65541,1,64]

theorem envBound42790 : H12AffineFastState.Bounded env42790 := by
  intro p hp
  have h : env42790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42789_42790 : H12AffineEnvironment.transform 7 4 env42789 = env42790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env42789 == env42790) = true)

theorem identity42790 : scanCanonicalize (H12AffineFastState.compose env42790 (packedSelected [2,4,9,11,13,16,17,18] rootPS)) = affineNative (2^(15+1) ^^^ 2126) := by decide +kernel

theorem selectedBound42790 : packedSelected [2,4,9,11,13,16,17,18] rootPS < 2^1333 := by decide +kernel

def env42791 : List Nat := [2,4,8,0,32,64,128,4,103,68,2048,38,110,64,39,2126,2058,2254,99,38,39,239,2059,2127,192,2156,42,2122,64,12,99,102,5,2123,1,64]

theorem envBound42791 : H12AffineFastState.Bounded env42791 := by
  intro p hp
  have h : env42791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42790_42791 : H12AffineEnvironment.transform 15 2126 env42790 = env42791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2126 env42790 == env42791) = true)

theorem identity42791 : scanCanonicalize (H12AffineFastState.compose env42791 (packedSelected [1,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 175) := by decide +kernel

theorem selectedBound42791 : packedSelected [1,13,15] rootPS < 2^1333 := by decide +kernel

def env42792 : List Nat := [2,4,8,0,32,64,128,4,103,68,175,38,110,64,39,225,165,97,99,38,39,239,164,224,192,195,42,229,64,12,99,102,5,228,1,64]

theorem envBound42792 : H12AffineFastState.Bounded env42792 := by
  intro p hp
  have h : env42792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42791_42792 : H12AffineEnvironment.transform 10 175 env42791 = env42792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 175 env42791 == env42792) = true)

theorem identity42792 : scanCanonicalize (H12AffineFastState.compose env42792 (packedSelected [0,1,2,3,5,7,11] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound42792 : packedSelected [0,1,2,3,5,7,11] rootPS < 2^1333 := by decide +kernel

def env42793 : List Nat := [2,4,8,0,32,64,34,4,103,68,13,38,110,64,39,67,7,97,99,38,39,77,6,66,98,97,42,71,64,12,99,102,5,70,1,64]

theorem envBound42793 : H12AffineFastState.Bounded env42793 := by
  intro p hp
  have h : env42793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42792_42793 : H12AffineEnvironment.transform 6 34 env42792 = env42793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env42792 == env42793) = true)

theorem identity42793 : scanCanonicalize (H12AffineFastState.compose env42793 (packedSelected [1,2,4,5,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound42793 : packedSelected [1,2,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env42794 : List Nat := [2,4,8,0,32,33,34,4,6,37,13,38,15,33,39,34,7,0,2,38,39,44,6,35,3,0,42,38,33,12,2,7,5,39,1,33]

theorem envBound42794 : H12AffineFastState.Bounded env42794 := by
  intro p hp
  have h : env42794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42793_42794 : H12AffineEnvironment.transform 5 33 env42793 = env42794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env42793 == env42794) = true)

theorem identity42794 : scanCanonicalize (H12AffineFastState.compose env42794 (packedSelected [0,2,4] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound42794 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env42795 : List Nat := [2,4,5,0,32,33,34,4,6,37,0,38,2,33,39,34,7,0,2,38,39,33,6,35,3,0,39,38,33,1,2,7,5,39,1,33]

theorem envBound42795 : H12AffineFastState.Bounded env42795 := by
  intro p hp
  have h : env42795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42794_42795 : H12AffineEnvironment.transform 2 5 env42794 = env42795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env42794 == env42795) = true)

theorem identity42795 : scanCanonicalize (H12AffineFastState.compose env42795 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound42795 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42796 : List Nat := [2,4,5,0,7,6,5,4,6,2,0,1,2,6,0,5,7,0,2,1,0,6,6,4,3,0,0,1,6,1,2,7,5,0,1,6]

theorem envBound42796 : H12AffineFastState.Bounded env42796 := by
  intro p hp
  have h : env42796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42795_42796 : H12AffineEnvironment.transform 4 7 env42795 = env42796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env42795 == env42796) = true)

theorem identity42796 : scanCanonicalize (H12AffineFastState.compose env42796 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound42796 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42797 : List Nat := [2,2,3,0,1,0,3,2,0,2,0,1,2,0,0,3,1,0,2,1,0,0,0,2,3,0,0,1,0,1,2,1,3,0,1,0]

theorem envBound42797 : H12AffineFastState.Bounded env42797 := by
  intro p hp
  have h : env42797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42796_42797 : H12AffineEnvironment.transform 1 2 env42796 = env42797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env42796 == env42797) = true)

def env42798 : List Nat := [2,4,8,1,32,64,128,256,102,321,2048,291,362,64,38,65536,65605,65664,98,39,290,238,65604,65537,192,65830,302,65540,64,67650,359,354,257,65540,0,325]

theorem envBound42798 : H12AffineFastState.Bounded env42798 := by
  intro p hp
  have h : env42798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42788_42798 : H12AffineEnvironment.transform 3 1 env42788 = env42798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env42788 == env42798) = true)

theorem identity42798 : scanCanonicalize (H12AffineFastState.compose env42798 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound42798 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env42799 : List Nat := [2,4,8,1,7,64,128,256,65,321,2048,260,333,64,1,65536,65605,65664,69,0,261,201,65604,65537,192,65793,265,65540,64,67650,320,325,257,65540,0,325]

theorem envBound42799 : H12AffineFastState.Bounded env42799 := by
  intro p hp
  have h : env42799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42798_42799 : H12AffineEnvironment.transform 4 7 env42798 = env42799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env42798 == env42799) = true)

theorem identity42799 : scanCanonicalize (H12AffineFastState.compose env42799 (packedSelected [0,2,3,4,5,7,9,10,11,13,16,17,18,20] rootPS)) = affineNative (2^(15+1) ^^^ 2177) := by decide +kernel

theorem selectedBound42799 : packedSelected [0,2,3,4,5,7,9,10,11,13,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env42800 : List Nat := [2,4,8,1,7,64,128,256,65,321,2048,260,333,64,1,2177,2244,2049,69,0,261,201,2245,2176,192,2432,265,2181,64,195,320,325,257,2181,0,325]

theorem envBound42800 : H12AffineFastState.Bounded env42800 := by
  intro p hp
  have h : env42800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42799_42800 : H12AffineEnvironment.transform 15 2177 env42799 = env42800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2177 env42799 == env42800) = true)

theorem identity42800 : scanCanonicalize (H12AffineFastState.compose env42800 (packedSelected [0,5,7,8,10,11] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound42800 : packedSelected [0,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env42801 : List Nat := [2,4,5,1,7,64,128,256,65,321,2048,260,320,64,1,2177,2244,2049,69,0,261,196,2245,2176,192,2432,260,2181,64,195,320,325,257,2181,0,325]

theorem envBound42801 : H12AffineFastState.Bounded env42801 := by
  intro p hp
  have h : env42801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42800_42801 : H12AffineEnvironment.transform 2 5 env42800 = env42801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env42800 == env42801) = true)

def env42802 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,836,797,65,576,65536,66082,65664,517,577,837,648,66082,65536,192,65830,303,66162,65,67650,784,789,257,66147,16,340]

theorem envBound42802 : H12AffineFastState.Bounded env42802 := by
  intro p hp
  have h : env42802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42786_42802 : H12AffineEnvironment.transform 9 337 env42786 = env42802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env42786 == env42802) = true)

theorem identity42802 : scanCanonicalize (H12AffineFastState.compose env42802 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 50) := by decide +kernel

theorem selectedBound42802 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env42803 : List Nat := [2,4,8,16,32,64,128,50,512,99,2048,630,559,65,576,65536,66082,65664,517,577,631,648,66082,65536,192,65556,29,66162,65,67650,546,551,51,66147,16,102]

theorem envBound42803 : H12AffineFastState.Bounded env42803 := by
  intro p hp
  have h : env42803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42802_42803 : H12AffineEnvironment.transform 7 50 env42802 = env42803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 50 env42802 == env42803) = true)

def env42804 : List Nat := [2,4,8,0,32,64,128,34,512,99,2048,614,559,65,576,65536,66082,65664,517,577,615,648,66082,65536,192,65540,13,66146,65,67650,546,551,35,66147,0,102]

theorem envBound42804 : H12AffineFastState.Bounded env42804 := by
  intro p hp
  have h : env42804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42803_42804 : H12AffineEnvironment.transform 3 0 env42803 = env42804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env42803 == env42804) = true)

theorem identity42804 : scanCanonicalize (H12AffineFastState.compose env42804 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 65) := by decide +kernel

theorem selectedBound42804 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env42805 : List Nat := [2,4,8,0,32,64,128,34,65,99,2048,39,110,65,1,65536,65635,65664,68,0,38,201,65635,65536,192,65540,13,65571,65,67650,99,102,35,65570,0,102]

theorem envBound42805 : H12AffineFastState.Bounded env42805 := by
  intro p hp
  have h : env42805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42804_42805 : H12AffineEnvironment.transform 8 65 env42804 = env42805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env42804 == env42805) = true)

theorem identity42805 : scanCanonicalize (H12AffineFastState.compose env42805 (packedSelected [0,2,3,4,5,7,9,10,11,13,16,17,18,20] rootPS)) = affineNative (2^(15+1) ^^^ 2176) := by decide +kernel

theorem selectedBound42805 : packedSelected [0,2,3,4,5,7,9,10,11,13,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env42806 : List Nat := [2,4,8,0,32,64,128,34,65,99,2048,39,110,65,1,2176,2275,2048,68,0,38,201,2275,2176,192,2180,13,2211,65,194,99,102,35,2210,0,102]

theorem envBound42806 : H12AffineFastState.Bounded env42806 := by
  intro p hp
  have h : env42806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42805_42806 : H12AffineEnvironment.transform 15 2176 env42805 = env42806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2176 env42805 == env42806) = true)

theorem identity42806 : scanCanonicalize (H12AffineFastState.compose env42806 (packedSelected [0,5,7,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound42806 : packedSelected [0,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env42807 : List Nat := [2,4,8,0,32,64,128,34,65,99,137,39,110,65,1,9,106,137,68,0,38,201,106,9,192,13,13,42,65,194,99,102,35,43,0,102]

end H12CloudChart2