import H12CloudChart2Data060

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env14910 : List Nat := [2,4,8,16,32,64,128,256,136,1024,0,4096,8192,1345,32768,65536,1345,262144,304169,32769,4097,8200,64,98565,8328,303161,33061,1345,307241,295205,1284,4294967296,256,4295074215,1345,136]

theorem envBound14910 : H12AffineFastState.Bounded env14910 := by
  intro p hp
  have h : env14910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14909_14910 : H12AffineEnvironment.transform 8 136 env14909 = env14910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env14909 == env14910) = true)

def env14911 : List Nat := [2,4,8,16,32,64,128,256,136,1024,0,4096,8192,1345,32768,65536,1345,46440,4417,32769,4097,8200,64,98565,8328,5457,33061,1345,1345,13389,1284,4294967296,256,4295074215,1345,136]

theorem envBound14911 : H12AffineFastState.Bounded env14911 := by
  intro p hp
  have h : env14911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14910_14911 : H12AffineEnvironment.transform 17 46440 env14910 = env14911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 46440 env14910 == env14911) = true)

def env14912 : List Nat := [2,4,8,16,32,64,128,256,136,1024,0,1344,8192,1345,32768,65536,1345,41000,1025,32769,1345,8200,64,98565,8328,17,33061,1345,1345,8461,1284,4294967296,256,4295074215,1345,136]

theorem envBound14912 : H12AffineFastState.Bounded env14912 := by
  intro p hp
  have h : env14912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14911_14912 : H12AffineEnvironment.transform 11 1344 env14911 = env14912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env14911 == env14912) = true)

theorem identity14912 : scanCanonicalize (H12AffineFastState.compose env14912 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound14912 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env14913 : List Nat := [2,4,8,16,32,64,128,256,136,1024,0,1344,8192,1345,32768,33166,1345,41000,1025,32769,1345,8200,64,139,8328,17,33061,1345,1345,8461,1284,4294967296,256,4294975529,1345,136]

theorem envBound14913 : H12AffineFastState.Bounded env14913 := by
  intro p hp
  have h : env14913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14912_14913 : H12AffineEnvironment.transform 15 33166 env14912 = env14913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env14912 == env14913) = true)

theorem identity14913 : scanCanonicalize (H12AffineFastState.compose env14913 (packedSelected [3,5] rootPS)) = affineNative (2^(12+1) ^^^ 82) := by decide +kernel

theorem selectedBound14913 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env14914 : List Nat := [2,4,8,16,32,64,128,256,136,1024,0,1344,82,1345,32768,33166,1345,32890,1025,32769,1345,90,64,139,218,17,33061,1345,1345,351,1284,4294967296,256,4294967419,1345,136]

theorem envBound14914 : H12AffineFastState.Bounded env14914 := by
  intro p hp
  have h : env14914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14913_14914 : H12AffineEnvironment.transform 12 82 env14913 = env14914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 82 env14913 == env14914) = true)

theorem identity14914 : scanCanonicalize (H12AffineFastState.compose env14914 (packedSelected [1] rootPS)) = affineNative (2^(14+1) ^^^ 123) := by decide +kernel

theorem selectedBound14914 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14915 : List Nat := [2,4,8,16,32,64,128,256,136,1024,0,1344,82,1345,123,501,1345,1,1025,122,1345,90,64,139,218,17,350,1345,1345,351,1284,4294967296,256,4294967419,1345,136]

theorem envBound14915 : H12AffineFastState.Bounded env14915 := by
  intro p hp
  have h : env14915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14914_14915 : H12AffineEnvironment.transform 14 123 env14914 = env14915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 123 env14914 == env14915) = true)

theorem identity14915 : scanCanonicalize (H12AffineFastState.compose env14915 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound14915 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env14916 : List Nat := [2,4,8,16,32,64,128,14,136,1024,0,1102,82,1103,123,251,1103,1,1025,122,1103,90,64,139,218,17,80,1103,1103,81,1034,4294967296,14,4294967419,1103,136]

theorem envBound14916 : H12AffineFastState.Bounded env14916 := by
  intro p hp
  have h : env14916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14915_14916 : H12AffineEnvironment.transform 7 14 env14915 = env14916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env14915 == env14916) = true)

theorem identity14916 : scanCanonicalize (H12AffineFastState.compose env14916 (packedSelected [8] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound14916 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env14917 : List Nat := [2,4,8,16,32,59,128,14,136,1024,0,1077,41,1076,0,128,1076,1,1025,1,1076,33,59,139,161,17,43,1076,1076,42,1034,4294967296,14,4294967296,1076,136]

theorem envBound14917 : H12AffineFastState.Bounded env14917 := by
  intro p hp
  have h : env14917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14916_14917 : H12AffineEnvironment.transform 5 59 env14916 = env14917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env14916 == env14917) = true)

theorem identity14917 : scanCanonicalize (H12AffineFastState.compose env14917 (packedSelected [2] rootPS)) = affineNative (2^(31+1) ^^^ 147) := by decide +kernel

theorem selectedBound14917 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14918 : List Nat := [2,4,8,16,32,59,128,14,136,1024,0,1077,41,1076,0,128,1076,1,1025,1,1076,33,59,139,161,17,43,1076,1076,42,1034,147,14,147,1076,136]

theorem envBound14918 : H12AffineFastState.Bounded env14918 := by
  intro p hp
  have h : env14918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14917_14918 : H12AffineEnvironment.transform 31 147 env14917 = env14918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 147 env14917 == env14918) = true)

def env14919 : List Nat := [2,4,8,16,32,64,128,256,136,1024,0,1345,8192,1345,32768,65536,1345,41001,1024,32769,1344,8200,64,98565,8328,16,33061,1345,1345,8460,1284,4294967296,256,4295074215,1345,136]

theorem envBound14919 : H12AffineFastState.Bounded env14919 := by
  intro p hp
  have h : env14919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14911_14919 : H12AffineEnvironment.transform 11 1345 env14911 = env14919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env14911 == env14919) = true)

theorem identity14919 : scanCanonicalize (H12AffineFastState.compose env14919 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound14919 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env14920 : List Nat := [2,4,8,16,32,64,128,256,136,1024,0,1345,8192,1345,292,65536,1345,8461,1024,293,1344,8200,64,65569,8328,16,1,1345,1345,8460,1284,4294967296,256,4295041155,1345,136]

theorem envBound14920 : H12AffineFastState.Bounded env14920 := by
  intro p hp
  have h : env14920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14919_14920 : H12AffineEnvironment.transform 14 292 env14919 = env14920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env14919 == env14920) = true)

theorem identity14920 : scanCanonicalize (H12AffineFastState.compose env14920 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound14920 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env14921 : List Nat := [2,4,8,16,32,16,128,256,136,1024,0,1297,8192,1297,292,65536,1297,8461,1024,293,1296,8200,16,65569,8328,16,1,1297,1297,8460,1284,4294967296,256,4295041155,1297,136]

theorem envBound14921 : H12AffineFastState.Bounded env14921 := by
  intro p hp
  have h : env14921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14920_14921 : H12AffineEnvironment.transform 5 16 env14920 = env14921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14920 == env14921) = true)

theorem identity14921 : scanCanonicalize (H12AffineFastState.compose env14921 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound14921 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env14922 : List Nat := [2,4,8,16,32,16,128,256,136,1024,0,1297,269,1297,292,65536,1297,0,1024,293,1296,261,16,65569,389,16,1,1297,1297,1,1284,4294967296,256,4295033230,1297,136]

theorem envBound14922 : H12AffineFastState.Bounded env14922 := by
  intro p hp
  have h : env14922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14921_14922 : H12AffineEnvironment.transform 12 269 env14921 = env14922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env14921 == env14922) = true)

def env14923 : List Nat := [2,4,8,16,32,16,128,36,136,1024,0,1077,41,1077,0,65536,1077,0,1024,1,1076,33,16,65569,161,16,1,1077,1077,1,1056,4294967296,36,4295033002,1077,136]

theorem envBound14923 : H12AffineFastState.Bounded env14923 := by
  intro p hp
  have h : env14923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14922_14923 : H12AffineEnvironment.transform 7 36 env14922 = env14923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env14922 == env14923) = true)

theorem identity14923 : scanCanonicalize (H12AffineFastState.compose env14923 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 137) := by decide +kernel

theorem selectedBound14923 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14924 : List Nat := [2,4,8,16,32,16,128,36,136,1024,0,1077,41,1077,0,65536,1077,0,1024,1,1076,33,16,65569,161,16,1,1077,1077,1,1056,137,36,65571,1077,136]

theorem envBound14924 : H12AffineFastState.Bounded env14924 := by
  intro p hp
  have h : env14924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14923_14924 : H12AffineEnvironment.transform 31 137 env14923 = env14924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 137 env14923 == env14924) = true)

def env14925 : List Nat := [2,4,8,16,32,16,128,36,136,52,0,1,41,1,0,65536,1,0,52,1,0,33,16,65569,161,16,1,1,1,1,20,137,36,65571,1,136]

theorem envBound14925 : H12AffineFastState.Bounded env14925 := by
  intro p hp
  have h : env14925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14924_14925 : H12AffineEnvironment.transform 9 52 env14924 = env14925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env14924 == env14925) = true)

theorem identity14925 : scanCanonicalize (H12AffineFastState.compose env14925 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound14925 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14926 : List Nat := [2,4,8,16,32,16,128,36,136,52,0,1,41,1,0,170,1,0,52,1,0,33,16,139,161,16,1,1,1,1,20,137,36,137,1,136]

theorem envBound14926 : H12AffineFastState.Bounded env14926 := by
  intro p hp
  have h : env14926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14925_14926 : H12AffineEnvironment.transform 15 170 env14925 = env14926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env14925 == env14926) = true)

def leafEnv14926 : List Nat := [2,4,8,16,32,16,128,36,136,52,0,1,41,1,0,170,1,0,52,1,0,33,16,139,20,161,1,16,1,1,1,1,20,137,36,137,4,35,1,136,0,0,1]

def active14926 : List Nat := [0,1,2,3,4,6]

def tree14926 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14926 : H12WitnessSearch.Good tree14926 := H12GlobalWitnessIndex.good

theorem leafIdentity14926 : H12AffineFastState.composeSystem env14926 rootObs = leafEnv14926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14926 rootObs == leafEnv14926) = true)

theorem terminalChecked14926 : H12PackedTerminal.terminalCheckFast leafEnv14926 active14926 tree14926 = true := by decide +kernel

def env14927 : List Nat := [2,4,8,16,32,16,128,36,136,53,0,0,41,0,0,65536,0,0,53,1,1,33,16,65569,161,16,1,0,0,1,21,137,36,65571,0,136]

theorem envBound14927 : H12AffineFastState.Bounded env14927 := by
  intro p hp
  have h : env14927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14924_14927 : H12AffineEnvironment.transform 9 53 env14924 = env14927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env14924 == env14927) = true)

def env14928 : List Nat := [2,4,8,16,0,16,128,4,136,21,0,0,9,0,0,65536,0,0,21,1,1,1,16,65537,129,16,1,0,0,1,21,137,4,65539,0,136]

theorem envBound14928 : H12AffineFastState.Bounded env14928 := by
  intro p hp
  have h : env14928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14927_14928 : H12AffineEnvironment.transform 4 0 env14927 = env14928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14927 == env14928) = true)

def leafEnv14928 : List Nat := [2,4,8,16,0,16,128,4,136,21,0,0,9,0,0,65536,0,0,21,1,1,1,16,65537,21,129,1,16,1,0,0,1,21,137,4,65539,4,3,0,136,0,1,1]

def active14928 : List Nat := [0,1,2,3,6,15]

def tree14928 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14928 : H12WitnessSearch.Good tree14928 := H12GlobalWitnessIndex.good

theorem leafIdentity14928 : H12AffineFastState.composeSystem env14928 rootObs = leafEnv14928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14928 rootObs == leafEnv14928) = true)

theorem terminalChecked14928 : H12PackedTerminal.terminalCheckFast leafEnv14928 active14928 tree14928 = true := by decide +kernel

def env14929 : List Nat := [2,4,8,16,1,16,128,5,136,20,0,0,8,0,0,65536,0,0,20,1,1,0,16,65536,128,16,1,0,0,1,21,137,5,65538,0,136]

theorem envBound14929 : H12AffineFastState.Bounded env14929 := by
  intro p hp
  have h : env14929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14927_14929 : H12AffineEnvironment.transform 4 1 env14927 = env14929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14927 == env14929) = true)

theorem identity14929 : scanCanonicalize (H12AffineFastState.compose env14929 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 139) := by decide +kernel

theorem selectedBound14929 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14930 : List Nat := [2,4,8,16,1,16,128,5,136,20,0,0,8,0,0,139,0,0,20,1,1,0,16,139,128,16,1,0,0,1,21,137,5,137,0,136]

theorem envBound14930 : H12AffineFastState.Bounded env14930 := by
  intro p hp
  have h : env14930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14929_14930 : H12AffineEnvironment.transform 15 139 env14929 = env14930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 139 env14929 == env14930) = true)

def leafEnv14930 : List Nat := [2,4,8,16,1,16,128,5,136,20,0,0,8,0,0,139,0,0,20,1,1,0,16,139,21,128,1,16,1,0,0,1,21,137,5,137,4,2,0,136,0,1,1]

def active14930 : List Nat := [0,1,2,3,6]

def tree14930 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14930 : H12WitnessSearch.Good tree14930 := H12GlobalWitnessIndex.good

theorem leafIdentity14930 : H12AffineFastState.composeSystem env14930 rootObs = leafEnv14930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14930 rootObs == leafEnv14930) = true)

theorem terminalChecked14930 : H12PackedTerminal.terminalCheckFast leafEnv14930 active14930 tree14930 = true := by decide +kernel

def env14931 : List Nat := [2,4,8,16,32,16,128,37,136,1024,0,1076,40,1076,1,65536,1076,0,1024,0,1077,32,16,65569,160,16,1,1076,1076,1,1057,4294967296,37,4295033003,1076,136]

theorem envBound14931 : H12AffineFastState.Bounded env14931 := by
  intro p hp
  have h : env14931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14922_14931 : H12AffineEnvironment.transform 7 37 env14922 = env14931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env14922 == env14931) = true)

theorem identity14931 : scanCanonicalize (H12AffineFastState.compose env14931 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 65707) := by decide +kernel

theorem selectedBound14931 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14932 : List Nat := [2,4,8,16,32,16,128,37,136,1024,0,1076,40,1076,1,65536,1076,0,1024,0,1077,32,16,65569,160,16,1,1076,1076,1,1057,65707,37,0,1076,136]

theorem envBound14932 : H12AffineFastState.Bounded env14932 := by
  intro p hp
  have h : env14932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14931_14932 : H12AffineEnvironment.transform 31 65707 env14931 = env14932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 65707 env14931 == env14932) = true)

def env14933 : List Nat := [2,4,8,16,32,16,128,37,136,52,0,0,40,0,1,65536,0,0,52,0,1,32,16,65569,160,16,1,0,0,1,21,65707,37,0,0,136]

theorem envBound14933 : H12AffineFastState.Bounded env14933 := by
  intro p hp
  have h : env14933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14932_14933 : H12AffineEnvironment.transform 9 52 env14932 = env14933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env14932 == env14933) = true)

def env14934 : List Nat := [2,4,8,16,32,16,8,37,0,52,0,0,40,0,1,65536,0,0,52,0,1,32,16,65569,40,16,1,0,0,1,21,65571,37,0,0,0]

theorem envBound14934 : H12AffineFastState.Bounded env14934 := by
  intro p hp
  have h : env14934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14933_14934 : H12AffineEnvironment.transform 6 8 env14933 = env14934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14933 == env14934) = true)

theorem identity14934 : scanCanonicalize (H12AffineFastState.compose env14934 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound14934 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14935 : List Nat := [2,4,8,16,32,16,8,37,0,52,0,0,40,0,1,2,0,0,52,0,1,32,16,35,40,16,1,0,0,1,21,33,37,0,0,0]

theorem envBound14935 : H12AffineFastState.Bounded env14935 := by
  intro p hp
  have h : env14935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14934_14935 : H12AffineEnvironment.transform 15 2 env14934 = env14935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env14934 == env14935) = true)

def leafEnv14935 : List Nat := [2,4,8,16,32,16,8,37,0,52,0,0,40,0,1,2,0,0,52,0,1,32,16,35,21,40,1,16,1,0,0,1,21,33,37,0,4,35,0,0,0,1,1]

def active14935 : List Nat := [0,1,2,3,4]

def tree14935 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14935 : H12WitnessSearch.Good tree14935 := H12GlobalWitnessIndex.good

theorem leafIdentity14935 : H12AffineFastState.composeSystem env14935 rootObs = leafEnv14935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14935 rootObs == leafEnv14935) = true)

theorem terminalChecked14935 : H12PackedTerminal.terminalCheckFast leafEnv14935 active14935 tree14935 = true := by decide +kernel

def env14936 : List Nat := [2,4,8,16,32,16,9,37,1,52,0,0,40,0,1,65536,0,0,52,0,1,32,16,65569,41,16,1,0,0,1,21,65570,37,0,0,1]

theorem envBound14936 : H12AffineFastState.Bounded env14936 := by
  intro p hp
  have h : env14936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14933_14936 : H12AffineEnvironment.transform 6 9 env14933 = env14936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14933 == env14936) = true)

theorem identity14936 : scanCanonicalize (H12AffineFastState.compose env14936 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound14936 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14937 : List Nat := [2,4,8,16,1,16,9,4,1,21,0,0,9,0,1,65536,0,0,21,0,1,1,16,65536,8,16,1,0,0,1,21,65539,4,0,0,1]

theorem envBound14937 : H12AffineFastState.Bounded env14937 := by
  intro p hp
  have h : env14937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14936_14937 : H12AffineEnvironment.transform 4 1 env14936 = env14937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14936 == env14937) = true)

def leafEnv14937 : List Nat := [2,4,8,16,1,16,9,4,1,21,0,0,9,0,1,65536,0,0,21,0,1,1,16,65536,21,8,1,16,1,0,0,1,21,65539,4,0,4,2,0,1,0,1,1]

def active14937 : List Nat := [0,1,2,3,15]

def tree14937 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14937 : H12WitnessSearch.Good tree14937 := H12GlobalWitnessIndex.good

theorem leafIdentity14937 : H12AffineFastState.composeSystem env14937 rootObs = leafEnv14937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14937 rootObs == leafEnv14937) = true)

theorem terminalChecked14937 : H12PackedTerminal.terminalCheckFast leafEnv14937 active14937 tree14937 = true := by decide +kernel

def env14938 : List Nat := [2,4,8,16,32,16,128,37,136,53,0,1,40,1,1,65536,1,0,53,0,0,32,16,65569,160,16,1,1,1,1,20,65707,37,0,1,136]

theorem envBound14938 : H12AffineFastState.Bounded env14938 := by
  intro p hp
  have h : env14938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14932_14938 : H12AffineEnvironment.transform 9 53 env14932 = env14938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env14932 == env14938) = true)

theorem identity14938 : scanCanonicalize (H12AffineFastState.compose env14938 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound14938 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14939 : List Nat := [2,4,8,16,32,16,128,37,136,53,0,1,40,1,1,170,1,0,53,0,0,32,16,139,160,16,1,1,1,1,20,1,37,0,1,136]

theorem envBound14939 : H12AffineFastState.Bounded env14939 := by
  intro p hp
  have h : env14939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14938_14939 : H12AffineEnvironment.transform 15 170 env14938 = env14939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env14938 == env14939) = true)

theorem identity14939 : scanCanonicalize (H12AffineFastState.compose env14939 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound14939 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14940 : List Nat := [2,4,8,16,32,16,40,37,32,53,0,1,40,1,1,2,1,0,53,0,0,32,16,35,8,16,1,1,1,1,20,1,37,0,1,32]

theorem envBound14940 : H12AffineFastState.Bounded env14940 := by
  intro p hp
  have h : env14940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14939_14940 : H12AffineEnvironment.transform 6 40 env14939 = env14940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env14939 == env14940) = true)

def leafEnv14940 : List Nat := [2,4,8,16,32,16,40,37,32,53,0,1,40,1,1,2,1,0,53,0,0,32,16,35,20,8,1,16,1,1,1,1,20,1,37,0,4,35,1,32,0,0,1]

def active14940 : List Nat := [0,1,2,3,4]

def tree14940 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14940 : H12WitnessSearch.Good tree14940 := H12GlobalWitnessIndex.good

theorem leafIdentity14940 : H12AffineFastState.composeSystem env14940 rootObs = leafEnv14940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14940 rootObs == leafEnv14940) = true)

theorem terminalChecked14940 : H12PackedTerminal.terminalCheckFast leafEnv14940 active14940 tree14940 = true := by decide +kernel

def env14941 : List Nat := [2,4,8,16,32,64,128,256,136,1024,0,4096,8192,1345,32768,65536,1345,46441,4416,32769,4097,8200,64,98565,8328,5456,33061,1345,1344,13388,1284,4294967296,256,4295074215,1345,136]

theorem envBound14941 : H12AffineFastState.Bounded env14941 := by
  intro p hp
  have h : env14941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14910_14941 : H12AffineEnvironment.transform 17 46441 env14910 = env14941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 46441 env14910 == env14941) = true)

def env14942 : List Nat := [2,4,8,16,32,64,128,256,136,1024,0,1344,8192,1345,32768,65536,1345,41001,1024,32769,1345,8200,64,98565,8328,16,33061,1345,1344,8460,1284,4294967296,256,4295074215,1345,136]

theorem envBound14942 : H12AffineFastState.Bounded env14942 := by
  intro p hp
  have h : env14942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14941_14942 : H12AffineEnvironment.transform 11 1344 env14941 = env14942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env14941 == env14942) = true)

theorem identity14942 : scanCanonicalize (H12AffineFastState.compose env14942 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound14942 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env14943 : List Nat := [2,4,8,16,32,64,128,256,136,1024,0,1344,8192,1345,292,65536,1345,8461,1024,293,1345,8200,64,65569,8328,16,1,1345,1344,8460,1284,4294967296,256,4295041155,1345,136]

theorem envBound14943 : H12AffineFastState.Bounded env14943 := by
  intro p hp
  have h : env14943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14942_14943 : H12AffineEnvironment.transform 14 292 env14942 = env14943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env14942 == env14943) = true)

theorem identity14943 : scanCanonicalize (H12AffineFastState.compose env14943 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(15+1) ^^^ 251) := by decide +kernel

theorem selectedBound14943 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env14944 : List Nat := [2,4,8,16,32,64,128,256,136,1024,0,1344,8192,1345,292,251,1345,8461,1024,293,1345,8200,64,218,8328,16,1,1345,1344,8460,1284,4294967296,256,4294975608,1345,136]

theorem envBound14944 : H12AffineFastState.Bounded env14944 := by
  intro p hp
  have h : env14944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14943_14944 : H12AffineEnvironment.transform 15 251 env14943 = env14944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 251 env14943 == env14944) = true)

theorem identity14944 : scanCanonicalize (H12AffineFastState.compose env14944 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound14944 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env14945 : List Nat := [2,4,8,16,32,17,128,256,136,1024,0,1297,8192,1296,292,170,1296,8461,1024,293,1296,8200,17,139,8328,16,1,1296,1297,8460,1284,4294967296,256,4294975529,1296,136]

theorem envBound14945 : H12AffineFastState.Bounded env14945 := by
  intro p hp
  have h : env14945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14944_14945 : H12AffineEnvironment.transform 5 17 env14944 = env14945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14944 == env14945) = true)

theorem identity14945 : scanCanonicalize (H12AffineFastState.compose env14945 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound14945 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14946 : List Nat := [2,4,8,16,32,17,128,36,136,1024,0,1077,8192,1076,0,170,1076,8233,1024,1,1076,8200,17,139,8328,16,1,1076,1077,8232,1056,4294967296,36,4294975529,1076,136]

theorem envBound14946 : H12AffineFastState.Bounded env14946 := by
  intro p hp
  have h : env14946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14945_14946 : H12AffineEnvironment.transform 7 36 env14945 = env14946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env14945 == env14946) = true)

theorem identity14946 : scanCanonicalize (H12AffineFastState.compose env14946 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound14946 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env14947 : List Nat := [2,4,8,16,32,17,128,36,136,1024,0,1077,41,1076,0,170,1076,0,1024,1,1076,33,17,139,161,16,1,1076,1077,1,1056,4294967296,36,4294967296,1076,136]

theorem envBound14947 : H12AffineFastState.Bounded env14947 := by
  intro p hp
  have h : env14947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14946_14947 : H12AffineEnvironment.transform 12 41 env14946 = env14947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env14946 == env14947) = true)

theorem identity14947 : scanCanonicalize (H12AffineFastState.compose env14947 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 136) := by decide +kernel

theorem selectedBound14947 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14948 : List Nat := [2,4,8,16,32,17,128,36,136,1024,0,1077,41,1076,0,170,1076,0,1024,1,1076,33,17,139,161,16,1,1076,1077,1,1056,136,36,136,1076,136]

theorem envBound14948 : H12AffineFastState.Bounded env14948 := by
  intro p hp
  have h : env14948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14947_14948 : H12AffineEnvironment.transform 31 136 env14947 = env14948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 136 env14947 == env14948) = true)

def leafEnv14948 : List Nat := [2,4,8,16,32,17,128,36,136,1024,0,1077,41,1076,0,170,1076,0,1024,1,1076,33,17,139,1056,161,1,16,1,1076,1077,1,1056,136,36,136,4,35,1076,136,0,1076,1]

def active14948 : List Nat := [0,1,2,3,4,6,9]

def tree14948 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14948 : H12WitnessSearch.Good tree14948 := H12GlobalWitnessIndex.good

theorem leafIdentity14948 : H12AffineFastState.composeSystem env14948 rootObs = leafEnv14948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14948 rootObs == leafEnv14948) = true)

theorem terminalChecked14948 : H12PackedTerminal.terminalCheckFast leafEnv14948 active14948 tree14948 = true := by decide +kernel

def env14949 : List Nat := [2,4,8,16,32,64,128,256,136,1024,0,1345,8192,1345,32768,65536,1345,41000,1025,32769,1344,8200,64,98565,8328,17,33061,1345,1344,8461,1284,4294967296,256,4295074215,1345,136]

theorem envBound14949 : H12AffineFastState.Bounded env14949 := by
  intro p hp
  have h : env14949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14941_14949 : H12AffineEnvironment.transform 11 1345 env14941 = env14949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env14941 == env14949) = true)

theorem identity14949 : scanCanonicalize (H12AffineFastState.compose env14949 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound14949 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env14950 : List Nat := [2,4,8,16,32,64,128,256,136,1024,0,1345,8192,1345,32768,33166,1345,41000,1025,32769,1344,8200,64,139,8328,17,33061,1345,1344,8461,1284,4294967296,256,4294975529,1345,136]

theorem envBound14950 : H12AffineFastState.Bounded env14950 := by
  intro p hp
  have h : env14950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14949_14950 : H12AffineEnvironment.transform 15 33166 env14949 = env14950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env14949 == env14950) = true)

theorem identity14950 : scanCanonicalize (H12AffineFastState.compose env14950 (packedSelected [3,5] rootPS)) = affineNative (2^(14+1) ^^^ 350) := by decide +kernel

theorem selectedBound14950 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env14951 : List Nat := [2,4,8,16,32,64,128,256,136,1024,0,1345,8192,1345,350,208,1345,8566,1025,351,1344,8200,64,139,8328,17,123,1345,1344,8461,1284,4294967296,256,4294975529,1345,136]

theorem envBound14951 : H12AffineFastState.Bounded env14951 := by
  intro p hp
  have h : env14951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14950_14951 : H12AffineEnvironment.transform 14 350 env14950 = env14951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 350 env14950 == env14951) = true)

theorem identity14951 : scanCanonicalize (H12AffineFastState.compose env14951 (packedSelected [1,3,8] rootPS)) = affineNative (2^(12+1) ^^^ 375) := by decide +kernel

theorem selectedBound14951 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env14952 : List Nat := [2,4,8,16,32,64,128,256,136,1024,0,1345,375,1345,350,208,1345,1,1025,351,1344,383,64,139,511,17,123,1345,1344,122,1284,4294967296,256,4294967646,1345,136]

theorem envBound14952 : H12AffineFastState.Bounded env14952 := by
  intro p hp
  have h : env14952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14951_14952 : H12AffineEnvironment.transform 12 375 env14951 = env14952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 375 env14951 == env14952) = true)

theorem identity14952 : scanCanonicalize (H12AffineFastState.compose env14952 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound14952 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env14953 : List Nat := [2,4,8,16,10,64,128,256,136,1024,0,1345,349,1345,350,208,1345,1,1025,351,1344,341,64,139,469,17,81,1345,1344,80,1284,4294967296,256,4294967646,1345,136]

theorem envBound14953 : H12AffineFastState.Bounded env14953 := by
  intro p hp
  have h : env14953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14952_14953 : H12AffineEnvironment.transform 4 10 env14952 = env14953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env14952 == env14953) = true)

theorem identity14953 : scanCanonicalize (H12AffineFastState.compose env14953 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 94) := by decide +kernel

theorem selectedBound14953 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env14954 : List Nat := [2,4,8,16,10,64,128,94,136,1024,0,1055,3,1055,0,208,1055,1,1025,1,1054,11,64,139,139,17,81,1055,1054,80,1114,4294967296,94,4294967296,1055,136]

theorem envBound14954 : H12AffineFastState.Bounded env14954 := by
  intro p hp
  have h : env14954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14953_14954 : H12AffineEnvironment.transform 7 94 env14953 = env14954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 94 env14953 == env14954) = true)

def env14955 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,4096,8192,1345,32768,65536,1345,262144,304169,32769,4097,8200,64,98565,8328,303161,33061,1345,307241,295205,1284,4294967296,256,4295074215,1345,137]

theorem envBound14955 : H12AffineFastState.Bounded env14955 := by
  intro p hp
  have h : env14955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14909_14955 : H12AffineEnvironment.transform 8 137 env14909 = env14955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env14909 == env14955) = true)

theorem identity14955 : scanCanonicalize (H12AffineFastState.compose env14955 (packedSelected [0,1,2,3,4,6,10,13,15] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound14955 : packedSelected [0,1,2,3,4,6,10,13,15] rootPS < 2^1333 := by decide +kernel

def env14956 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,4096,8192,1345,32768,33166,1345,262144,304169,32769,4097,8200,64,139,8328,303161,33061,1345,307241,295205,1284,4294967296,256,4294975529,1345,137]

theorem envBound14956 : H12AffineFastState.Bounded env14956 := by
  intro p hp
  have h : env14956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14955_14956 : H12AffineEnvironment.transform 15 33166 env14955 = env14956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env14955 == env14956) = true)

def env14957 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,4096,8192,1345,32768,33166,1345,41000,1025,32769,4097,8200,64,139,8328,17,33061,1345,4097,8461,1284,4294967296,256,4294975529,1345,137]

theorem envBound14957 : H12AffineFastState.Bounded env14957 := by
  intro p hp
  have h : env14957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14956_14957 : H12AffineEnvironment.transform 17 41000 env14956 = env14957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 41000 env14956 == env14957) = true)

def env14958 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,4096,8192,1345,32768,33166,1345,41001,1024,32769,4097,8200,64,139,8328,16,33061,1345,4096,8460,1284,4294967296,256,4294975529,1345,137]

theorem envBound14958 : H12AffineFastState.Bounded env14958 := by
  intro p hp
  have h : env14958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14956_14958 : H12AffineEnvironment.transform 17 41001 env14956 = env14958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 41001 env14956 == env14958) = true)

theorem identity14958 : scanCanonicalize (H12AffineFastState.compose env14958 (packedSelected [1,8,10] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound14958 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env14959 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,4096,8192,1345,292,170,1345,8461,1024,293,4097,8200,64,139,8328,16,1,1345,4096,8460,1284,4294967296,256,4294975529,1345,137]

theorem envBound14959 : H12AffineFastState.Bounded env14959 := by
  intro p hp
  have h : env14959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14958_14959 : H12AffineEnvironment.transform 14 292 env14958 = env14959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env14958 == env14959) = true)

theorem identity14959 : scanCanonicalize (H12AffineFastState.compose env14959 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound14959 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env14960 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,1297,8192,1345,292,170,1345,8461,1024,293,1296,8200,64,139,8328,16,1,1345,1297,8460,1284,4294967296,256,4294975529,1345,137]

theorem envBound14960 : H12AffineFastState.Bounded env14960 := by
  intro p hp
  have h : env14960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14959_14960 : H12AffineEnvironment.transform 11 1297 env14959 = env14960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env14959 == env14960) = true)

theorem identity14960 : scanCanonicalize (H12AffineFastState.compose env14960 (packedSelected [2,4] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound14960 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env14961 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,1297,388,1345,292,170,1345,137,1024,293,1296,396,64,139,268,16,1,1345,1297,136,1284,4294967296,256,4294967725,1345,137]

theorem envBound14961 : H12AffineFastState.Bounded env14961 := by
  intro p hp
  have h : env14961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14960_14961 : H12AffineEnvironment.transform 12 388 env14960 = env14961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env14960 == env14961) = true)

theorem identity14961 : scanCanonicalize (H12AffineFastState.compose env14961 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 509) := by decide +kernel

theorem selectedBound14961 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14962 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,1297,388,1345,292,170,1345,137,1024,293,1296,396,64,139,268,16,1,1345,1297,136,1284,509,256,80,1345,137]

theorem envBound14962 : H12AffineFastState.Bounded env14962 := by
  intro p hp
  have h : env14962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14961_14962 : H12AffineEnvironment.transform 31 509 env14961 = env14962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 509 env14961 == env14962) = true)

theorem identity14962 : scanCanonicalize (H12AffineFastState.compose env14962 (packedSelected [5] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound14962 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env14963 : List Nat := [2,4,8,16,32,64,88,256,81,1024,0,1297,348,1345,292,114,1345,81,1024,293,1296,340,64,83,268,16,1,1345,1297,80,1284,293,256,80,1345,81]

theorem envBound14963 : H12AffineFastState.Bounded env14963 := by
  intro p hp
  have h : env14963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14962_14963 : H12AffineEnvironment.transform 6 88 env14962 = env14963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env14962 == env14963) = true)

def env14964 : List Nat := [2,4,8,16,32,16,8,256,1,1024,0,1297,268,1297,292,34,1297,1,1024,293,1296,260,16,3,268,16,1,1297,1297,0,1284,293,256,0,1297,1]

theorem envBound14964 : H12AffineFastState.Bounded env14964 := by
  intro p hp
  have h : env14964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14963_14964 : H12AffineEnvironment.transform 5 16 env14963 = env14964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14963 == env14964) = true)

def env14965 : List Nat := [2,4,8,16,0,16,8,256,1,1024,0,1297,268,1297,260,2,1297,1,1024,261,1296,260,16,3,268,16,1,1297,1297,0,1284,261,256,0,1297,1]

theorem envBound14965 : H12AffineFastState.Bounded env14965 := by
  intro p hp
  have h : env14965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14964_14965 : H12AffineEnvironment.transform 4 0 env14964 = env14965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14964 == env14965) = true)

def env14966 : List Nat := [2,4,8,16,1,16,8,256,1,1024,0,1297,268,1297,261,3,1297,1,1024,260,1296,260,16,3,268,16,1,1297,1297,0,1284,260,256,0,1297,1]

theorem envBound14966 : H12AffineFastState.Bounded env14966 := by
  intro p hp
  have h : env14966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14964_14966 : H12AffineEnvironment.transform 4 1 env14964 = env14966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14964 == env14966) = true)

theorem identity14966 : scanCanonicalize (H12AffineFastState.compose env14966 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound14966 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14967 : List Nat := [2,4,8,16,1,16,8,5,1,1024,0,1044,9,1044,0,3,1044,1,1024,1,1045,1,16,3,9,16,1,1044,1044,0,1025,1,5,0,1044,1]

theorem envBound14967 : H12AffineFastState.Bounded env14967 := by
  intro p hp
  have h : env14967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14966_14967 : H12AffineEnvironment.transform 7 5 env14966 = env14967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env14966 == env14967) = true)

def leafEnv14967 : List Nat := [2,4,8,16,1,16,8,5,1,1024,0,1044,9,1044,0,3,1044,1,1024,1,1045,1,16,3,1025,9,1,16,1,1044,1044,0,1025,1,5,0,4,2,1044,1,0,1045,1]

def active14967 : List Nat := [0,1,2,3,9]

def tree14967 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14967 : H12WitnessSearch.Good tree14967 := H12GlobalWitnessIndex.good

theorem leafIdentity14967 : H12AffineFastState.composeSystem env14967 rootObs = leafEnv14967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14967 rootObs == leafEnv14967) = true)

theorem terminalChecked14967 : H12PackedTerminal.terminalCheckFast leafEnv14967 active14967 tree14967 = true := by decide +kernel

def env14968 : List Nat := [2,4,8,16,32,17,9,256,0,1024,0,1297,269,1296,292,35,1296,0,1024,293,1296,261,17,2,268,16,1,1296,1297,1,1284,293,256,1,1296,0]

theorem envBound14968 : H12AffineFastState.Bounded env14968 := by
  intro p hp
  have h : env14968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14963_14968 : H12AffineEnvironment.transform 5 17 env14963 = env14968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14963 == env14968) = true)

theorem identity14968 : scanCanonicalize (H12AffineFastState.compose env14968 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound14968 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14969 : List Nat := [2,4,8,16,32,17,9,36,0,1024,0,1077,41,1076,0,35,1076,0,1024,1,1076,33,17,2,40,16,1,1076,1077,1,1056,1,36,1,1076,0]

theorem envBound14969 : H12AffineFastState.Bounded env14969 := by
  intro p hp
  have h : env14969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14968_14969 : H12AffineEnvironment.transform 7 36 env14968 = env14969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env14968 == env14969) = true)

def env14970 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,16384,262144,524288,32769,4097,8201,17665,98565,8328,541009,795917,1345,529408,1073741824,16453,4294967296,17473,4295074214,16384,512]

theorem envBound14970 : H12AffineFastState.Bounded env14970 := by
  intro p hp
  have h : env14970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14869_14970 : H12AffineEnvironment.transform 10 1 env14869 = env14970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env14869 == env14970) = true)

def env14971 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,1344,32768,65536,1344,262144,524288,32769,4097,8201,65,98565,8328,525329,795917,1345,529408,1073741824,1285,4294967296,257,4295074214,1344,512]

theorem envBound14971 : H12AffineFastState.Bounded env14971 := by
  intro p hp
  have h : env14971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14970_14971 : H12AffineEnvironment.transform 13 1344 env14970 = env14971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env14970 == env14971) = true)

theorem identity14971 : scanCanonicalize (H12AffineFastState.compose env14971 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 13341) := by decide +kernel

theorem selectedBound14971 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env14972 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,1344,32768,65536,1344,262144,524288,32769,4097,8201,65,98565,8328,525329,795917,1345,529408,13341,1285,4294967296,257,4295074214,1344,512]

theorem envBound14972 : H12AffineFastState.Bounded env14972 := by
  intro p hp
  have h : env14972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14971_14972 : H12AffineEnvironment.transform 29 13341 env14971 = env14972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 13341 env14971 == env14972) = true)

theorem identity14972 : scanCanonicalize (H12AffineFastState.compose env14972 (packedSelected [4,9,16] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound14972 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env14973 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,1344,32768,65536,1344,262144,1025,32769,4097,8201,65,98565,8328,16,270604,1345,4097,13341,1285,4294967296,257,4295074214,1344,512]

theorem envBound14973 : H12AffineFastState.Bounded env14973 := by
  intro p hp
  have h : env14973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14972_14973 : H12AffineEnvironment.transform 18 1025 env14972 = env14973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env14972 == env14973) = true)

theorem identity14973 : scanCanonicalize (H12AffineFastState.compose env14973 (packedSelected [0,1,4,5,7,9,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 940) := by decide +kernel

theorem selectedBound14973 : packedSelected [0,1,4,5,7,9,15,17] rootPS < 2^1333 := by decide +kernel

def env14974 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,1344,940,65536,1344,262144,1025,941,4097,8201,65,66217,8328,16,270604,1345,4097,13341,1285,4294967296,257,4295041546,1344,512]

theorem envBound14974 : H12AffineFastState.Bounded env14974 := by
  intro p hp
  have h : env14974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14973_14974 : H12AffineEnvironment.transform 14 940 env14973 = env14974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 940 env14973 == env14974) = true)

theorem identity14974 : scanCanonicalize (H12AffineFastState.compose env14974 (packedSelected [0,1,4,5,7,9,15,21] rootPS)) = affineNative (2^(11+1) ^^^ 1945) := by decide +kernel

theorem selectedBound14974 : packedSelected [0,1,4,5,7,9,15,21] rootPS < 2^1333 := by decide +kernel

def env14975 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1945,8192,1344,940,65536,1344,262144,1025,941,1944,8201,65,66217,8328,16,270604,1345,1944,9092,1285,4294967296,257,4295041546,1344,512]

theorem envBound14975 : H12AffineFastState.Bounded env14975 := by
  intro p hp
  have h : env14975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14974_14975 : H12AffineEnvironment.transform 11 1945 env14974 = env14975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1945 env14974 == env14975) = true)

def env14976 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1945,8192,1344,940,65536,1344,648,1025,941,1944,8201,65,66217,8328,16,9092,1345,1944,9092,1285,4294967296,257,4295041546,1344,512]

theorem envBound14976 : H12AffineFastState.Bounded env14976 := by
  intro p hp
  have h : env14976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14975_14976 : H12AffineEnvironment.transform 17 648 env14975 = env14976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 648 env14975 == env14976) = true)

theorem identity14976 : scanCanonicalize (H12AffineFastState.compose env14976 (packedSelected [4,9] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound14976 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env14977 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,1296,8192,1344,293,65536,1344,1,1025,292,1297,8201,65,65568,8328,16,8461,1345,1297,8461,1285,4294967296,257,4295041155,1344,137]

theorem envBound14977 : H12AffineFastState.Bounded env14977 := by
  intro p hp
  have h : env14977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14976_14977 : H12AffineEnvironment.transform 8 137 env14976 = env14977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env14976 == env14977) = true)

theorem identity14977 : scanCanonicalize (H12AffineFastState.compose env14977 (packedSelected [1,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound14977 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env14978 : List Nat := [2,4,8,16,32,64,128,4,137,1024,1,1044,8192,1092,33,65536,1092,1,1025,32,1045,8201,65,65568,8328,16,8201,1093,1045,8201,1025,4294967296,5,4295041155,1092,137]

theorem envBound14978 : H12AffineFastState.Bounded env14978 := by
  intro p hp
  have h : env14978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14977_14978 : H12AffineEnvironment.transform 7 4 env14977 = env14978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env14977 == env14978) = true)

theorem identity14978 : scanCanonicalize (H12AffineFastState.compose env14978 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound14978 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env14979 : List Nat := [2,4,8,16,32,64,128,4,137,1024,1,1044,9,1092,33,65536,1092,1,1025,32,1045,0,65,65568,129,16,0,1093,1045,0,1025,4294967296,5,4295032970,1092,137]

theorem envBound14979 : H12AffineFastState.Bounded env14979 := by
  intro p hp
  have h : env14979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14978_14979 : H12AffineEnvironment.transform 12 9 env14978 = env14979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env14978 == env14979) = true)

def env14980 : List Nat := [2,4,8,16,0,64,128,4,137,1024,1,1044,9,1092,1,65536,1092,1,1025,0,1045,0,65,65536,129,16,0,1093,1045,0,1025,4294967296,5,4295032970,1092,137]

theorem envBound14980 : H12AffineFastState.Bounded env14980 := by
  intro p hp
  have h : env14980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14979_14980 : H12AffineEnvironment.transform 4 0 env14979 = env14980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14979 == env14980) = true)

theorem identity14980 : scanCanonicalize (H12AffineFastState.compose env14980 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 66703) := by decide +kernel

theorem selectedBound14980 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14981 : List Nat := [2,4,8,16,0,64,128,4,137,1024,1,1044,9,1092,1,65536,1092,1,1025,0,1045,0,65,65536,129,16,0,1093,1045,0,1025,66703,5,1029,1092,137]

theorem envBound14981 : H12AffineFastState.Bounded env14981 := by
  intro p hp
  have h : env14981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14980_14981 : H12AffineEnvironment.transform 31 66703 env14980 = env14981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 66703 env14980 == env14981) = true)

def env14982 : List Nat := [2,4,8,16,0,64,128,4,137,68,1,80,9,0,1,65536,0,1,69,0,81,0,65,65536,129,16,0,1,81,0,69,65739,5,65,0,137]

theorem envBound14982 : H12AffineFastState.Bounded env14982 := by
  intro p hp
  have h : env14982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14981_14982 : H12AffineEnvironment.transform 9 68 env14981 = env14982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env14981 == env14982) = true)

theorem identity14982 : scanCanonicalize (H12AffineFastState.compose env14982 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound14982 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14983 : List Nat := [2,4,8,16,0,16,128,4,137,20,1,0,9,0,1,65536,0,1,21,0,1,0,17,65536,129,16,0,1,1,0,21,65691,5,17,0,137]

theorem envBound14983 : H12AffineFastState.Bounded env14983 := by
  intro p hp
  have h : env14983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14982_14983 : H12AffineEnvironment.transform 5 16 env14982 = env14983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14982 == env14983) = true)

theorem identity14983 : scanCanonicalize (H12AffineFastState.compose env14983 (packedSelected [3] rootPS)) = affineNative (2^(15+1) ^^^ 19) := by decide +kernel

theorem selectedBound14983 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env14984 : List Nat := [2,4,8,16,0,16,128,4,137,20,1,0,9,0,1,19,0,1,21,0,1,0,17,19,129,16,0,1,1,0,21,136,5,17,0,137]

theorem envBound14984 : H12AffineFastState.Bounded env14984 := by
  intro p hp
  have h : env14984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14983_14984 : H12AffineEnvironment.transform 15 19 env14983 = env14984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 19 env14983 == env14984) = true)

def env14985 : List Nat := [2,4,8,16,0,64,128,4,137,69,1,81,9,1,1,65536,1,1,68,0,80,0,65,65536,129,16,0,0,80,0,68,65738,5,64,1,137]

theorem envBound14985 : H12AffineFastState.Bounded env14985 := by
  intro p hp
  have h : env14985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14981_14985 : H12AffineEnvironment.transform 9 69 env14981 = env14985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env14981 == env14985) = true)

theorem identity14985 : scanCanonicalize (H12AffineFastState.compose env14985 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 219) := by decide +kernel

theorem selectedBound14985 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14986 : List Nat := [2,4,8,16,0,64,128,4,137,69,1,81,9,1,1,219,1,1,68,0,80,0,65,219,129,16,0,0,80,0,68,17,5,64,1,137]

theorem envBound14986 : H12AffineFastState.Bounded env14986 := by
  intro p hp
  have h : env14986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14985_14986 : H12AffineEnvironment.transform 15 219 env14985 = env14986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 219 env14985 == env14986) = true)

theorem identity14986 : scanCanonicalize (H12AffineFastState.compose env14986 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 73) := by decide +kernel

theorem selectedBound14986 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env14987 : List Nat := [2,4,8,16,0,64,73,4,64,69,1,81,9,1,1,18,1,1,68,0,80,0,65,18,72,16,0,0,80,0,68,17,5,64,1,64]

theorem envBound14987 : H12AffineFastState.Bounded env14987 := by
  intro p hp
  have h : env14987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14986_14987 : H12AffineEnvironment.transform 6 73 env14986 = env14987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 73 env14986 == env14987) = true)

theorem identity14987 : scanCanonicalize (H12AffineFastState.compose env14987 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound14987 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14988 : List Nat := [2,4,8,16,0,16,25,4,16,21,1,1,9,1,1,18,1,1,20,0,0,0,17,18,24,16,0,0,0,0,20,17,5,16,1,16]

theorem envBound14988 : H12AffineFastState.Bounded env14988 := by
  intro p hp
  have h : env14988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14987_14988 : H12AffineEnvironment.transform 5 16 env14987 = env14988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14987 == env14988) = true)

def leafEnv14988 : List Nat := [2,4,8,16,0,16,25,4,16,21,1,1,9,1,1,18,1,1,20,0,0,0,17,18,20,24,1,16,0,0,0,0,20,17,5,16,4,2,1,16,0,0,1]

def active14988 : List Nat := [0,1,2,3]

def tree14988 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14988 : H12WitnessSearch.Good tree14988 := H12GlobalWitnessIndex.good

theorem leafIdentity14988 : H12AffineFastState.composeSystem env14988 rootObs = leafEnv14988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14988 rootObs == leafEnv14988) = true)

theorem terminalChecked14988 : H12PackedTerminal.terminalCheckFast leafEnv14988 active14988 tree14988 = true := by decide +kernel

def env14989 : List Nat := [2,4,8,16,1,64,128,4,137,1024,1,1044,9,1092,0,65536,1092,1,1025,1,1045,0,65,65537,129,16,0,1093,1045,0,1025,4294967296,5,4295032970,1092,137]

theorem envBound14989 : H12AffineFastState.Bounded env14989 := by
  intro p hp
  have h : env14989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14979_14989 : H12AffineEnvironment.transform 4 1 env14979 = env14989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14979 == env14989) = true)

theorem identity14989 : scanCanonicalize (H12AffineFastState.compose env14989 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 1164) := by decide +kernel

theorem selectedBound14989 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14990 : List Nat := [2,4,8,16,1,64,128,4,137,1024,1,1044,9,1092,0,65536,1092,1,1025,1,1045,0,65,65537,129,16,0,1093,1045,0,1025,1164,5,66566,1092,137]

theorem envBound14990 : H12AffineFastState.Bounded env14990 := by
  intro p hp
  have h : env14990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14989_14990 : H12AffineEnvironment.transform 31 1164 env14989 = env14990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1164 env14989 == env14990) = true)

def env14991 : List Nat := [2,4,8,16,1,64,128,4,137,68,1,80,9,0,0,65536,0,1,69,1,81,0,65,65537,129,16,0,1,81,0,69,200,5,65602,0,137]

theorem envBound14991 : H12AffineFastState.Bounded env14991 := by
  intro p hp
  have h : env14991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14990_14991 : H12AffineEnvironment.transform 9 68 env14990 = env14991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env14990 == env14991) = true)

def env14992 : List Nat := [2,4,8,16,1,0,128,4,137,4,1,16,9,0,0,65536,0,1,5,1,17,0,1,65537,129,16,0,1,17,0,5,136,5,65538,0,137]

theorem envBound14992 : H12AffineFastState.Bounded env14992 := by
  intro p hp
  have h : env14992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14991_14992 : H12AffineEnvironment.transform 5 0 env14991 = env14992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env14991 == env14992) = true)

theorem identity14992 : scanCanonicalize (H12AffineFastState.compose env14992 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 154) := by decide +kernel

theorem selectedBound14992 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14993 : List Nat := [2,4,8,16,1,0,128,4,137,4,1,16,9,0,0,154,0,1,5,1,17,0,1,155,129,16,0,1,17,0,5,136,5,152,0,137]

theorem envBound14993 : H12AffineFastState.Bounded env14993 := by
  intro p hp
  have h : env14993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14992_14993 : H12AffineEnvironment.transform 15 154 env14992 = env14993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 154 env14992 == env14993) = true)

theorem identity14993 : scanCanonicalize (H12AffineFastState.compose env14993 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound14993 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env14994 : List Nat := [2,4,8,0,1,0,128,4,137,4,1,0,9,0,0,138,0,1,5,1,1,0,1,139,129,0,0,1,1,0,5,136,5,136,0,137]

theorem envBound14994 : H12AffineFastState.Bounded env14994 := by
  intro p hp
  have h : env14994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14993_14994 : H12AffineEnvironment.transform 3 0 env14993 = env14994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env14993 == env14994) = true)

def leafEnv14994 : List Nat := [2,4,8,0,1,0,128,4,137,4,1,0,9,0,0,138,0,1,5,1,1,0,1,139,5,129,1,0,0,1,1,0,5,136,5,136,4,3,0,137,0,1,1]

def active14994 : List Nat := [0,1,2,6]

def tree14994 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood14994 : H12WitnessSearch.Good tree14994 := H12GlobalWitnessIndex.good

theorem leafIdentity14994 : H12AffineFastState.composeSystem env14994 rootObs = leafEnv14994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env14994 rootObs == leafEnv14994) = true)

theorem terminalChecked14994 : H12PackedTerminal.terminalCheckFast leafEnv14994 active14994 tree14994 = true := by decide +kernel

def env14995 : List Nat := [2,4,8,16,1,1,128,4,137,5,1,17,9,0,0,65536,0,1,4,1,16,0,0,65537,129,16,0,1,16,0,4,137,5,65539,0,137]

theorem envBound14995 : H12AffineFastState.Bounded env14995 := by
  intro p hp
  have h : env14995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14991_14995 : H12AffineEnvironment.transform 5 1 env14991 = env14995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env14991 == env14995) = true)

theorem identity14995 : scanCanonicalize (H12AffineFastState.compose env14995 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound14995 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14996 : List Nat := [2,4,8,1,1,1,128,4,137,5,1,0,9,0,0,65536,0,1,4,1,1,0,0,65537,129,1,0,1,1,0,4,137,5,65539,0,137]

theorem envBound14996 : H12AffineFastState.Bounded env14996 := by
  intro p hp
  have h : env14996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14995_14996 : H12AffineEnvironment.transform 3 1 env14995 = env14996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env14995 == env14996) = true)

def env14997 : List Nat := [2,4,8,16,1,64,128,4,137,69,1,81,9,1,0,65536,1,1,68,1,80,0,65,65537,129,16,0,0,80,0,68,201,5,65603,1,137]

theorem envBound14997 : H12AffineFastState.Bounded env14997 := by
  intro p hp
  have h : env14997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14990_14997 : H12AffineEnvironment.transform 9 69 env14990 = env14997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env14990 == env14997) = true)

theorem identity14997 : scanCanonicalize (H12AffineFastState.compose env14997 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 138) := by decide +kernel

theorem selectedBound14997 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14998 : List Nat := [2,4,8,16,1,64,128,4,137,69,1,81,9,1,0,138,1,1,68,1,80,0,65,139,129,16,0,0,80,0,68,201,5,201,1,137]

theorem envBound14998 : H12AffineFastState.Bounded env14998 := by
  intro p hp
  have h : env14998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14997_14998 : H12AffineEnvironment.transform 15 138 env14997 = env14998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 138 env14997 == env14998) = true)

theorem identity14998 : scanCanonicalize (H12AffineFastState.compose env14998 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound14998 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14999 : List Nat := [2,4,8,16,1,17,128,4,137,20,1,0,9,1,0,138,1,1,21,1,1,0,16,139,129,16,0,0,1,0,21,152,5,152,1,137]

theorem envBound14999 : H12AffineFastState.Bounded env14999 := by
  intro p hp
  have h : env14999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14998_14999 : H12AffineEnvironment.transform 5 17 env14998 = env14999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14998 == env14999) = true)

theorem identity14999 : scanCanonicalize (H12AffineFastState.compose env14999 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound14999 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env15000 : List Nat := [2,4,8,0,1,1,128,4,137,4,1,0,9,1,0,138,1,1,5,1,1,0,0,139,129,0,0,0,1,0,5,136,5,136,1,137]

theorem envBound15000 : H12AffineFastState.Bounded env15000 := by
  intro p hp
  have h : env15000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14999_15000 : H12AffineEnvironment.transform 3 0 env14999 = env15000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env14999 == env15000) = true)

def leafEnv15000 : List Nat := [2,4,8,0,1,1,128,4,137,4,1,0,9,1,0,138,1,1,5,1,1,0,0,139,5,129,1,0,0,0,1,0,5,136,5,136,4,3,1,137,0,1,1]

def active15000 : List Nat := [0,1,2,6]

def tree15000 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15000 : H12WitnessSearch.Good tree15000 := H12GlobalWitnessIndex.good

theorem leafIdentity15000 : H12AffineFastState.composeSystem env15000 rootObs = leafEnv15000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15000 rootObs == leafEnv15000) = true)

theorem terminalChecked15000 : H12PackedTerminal.terminalCheckFast leafEnv15000 active15000 tree15000 = true := by decide +kernel

def env15001 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1945,8192,1344,940,65536,1344,649,1025,941,1944,8201,65,66217,8328,16,9093,1345,1944,9092,1285,4294967296,257,4295041546,1344,512]

theorem envBound15001 : H12AffineFastState.Bounded env15001 := by
  intro p hp
  have h : env15001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14975_15001 : H12AffineEnvironment.transform 17 649 env14975 = env15001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 649 env14975 == env15001) = true)

theorem identity15001 : scanCanonicalize (H12AffineFastState.compose env15001 (packedSelected [4,9] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound15001 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env15002 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1945,268,1344,940,65536,1344,649,1025,941,1944,261,65,66217,388,16,649,1345,1944,648,1285,4294967296,257,4295033606,1344,512]

theorem envBound15002 : H12AffineFastState.Bounded env15002 := by
  intro p hp
  have h : env15002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15001_15002 : H12AffineEnvironment.transform 12 268 env15001 = env15002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env15001 == env15002) = true)

theorem identity15002 : scanCanonicalize (H12AffineFastState.compose env15002 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound15002 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env15003 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,1296,268,1344,293,65536,1344,0,1025,292,1297,261,65,65568,388,16,0,1345,1297,1,1285,4294967296,257,4295033231,1344,137]

theorem envBound15003 : H12AffineFastState.Bounded env15003 := by
  intro p hp
  have h : env15003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15002_15003 : H12AffineEnvironment.transform 8 137 env15002 = env15003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env15002 == env15003) = true)

theorem identity15003 : scanCanonicalize (H12AffineFastState.compose env15003 (packedSelected [1,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound15003 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env15004 : List Nat := [2,4,8,16,32,64,128,5,137,1024,1,1045,9,1093,32,65536,1093,0,1025,33,1044,0,65,65568,129,16,0,1092,1044,1,1024,4294967296,4,4295032970,1093,137]

theorem envBound15004 : H12AffineFastState.Bounded env15004 := by
  intro p hp
  have h : env15004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15003_15004 : H12AffineEnvironment.transform 7 5 env15003 = env15004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env15003 == env15004) = true)

theorem identity15004 : scanCanonicalize (H12AffineFastState.compose env15004 (packedSelected [2,4] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound15004 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env15005 : List Nat := [2,4,8,16,32,64,128,5,137,1024,1,1045,9,1093,32,171,1093,0,1025,33,1044,0,65,139,129,16,0,1092,1044,1,1024,4294967296,4,4294967329,1093,137]

theorem envBound15005 : H12AffineFastState.Bounded env15005 := by
  intro p hp
  have h : env15005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15004_15005 : H12AffineEnvironment.transform 15 171 env15004 = env15005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env15004 == env15005) = true)

theorem identity15005 : scanCanonicalize (H12AffineFastState.compose env15005 (packedSelected [1,3] rootPS)) = affineNative (2^(31+1) ^^^ 136) := by decide +kernel

theorem selectedBound15005 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15006 : List Nat := [2,4,8,16,32,64,128,5,137,1024,1,1045,9,1093,32,171,1093,0,1025,33,1044,0,65,139,129,16,0,1092,1044,1,1024,136,4,169,1093,137]

theorem envBound15006 : H12AffineFastState.Bounded env15006 := by
  intro p hp
  have h : env15006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15005_15006 : H12AffineEnvironment.transform 31 136 env15005 = env15006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 136 env15005 == env15006) = true)

theorem identity15006 : scanCanonicalize (H12AffineFastState.compose env15006 (packedSelected [0,2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound15006 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env15007 : List Nat := [2,4,8,16,32,64,128,5,137,52,1,33,9,113,32,171,113,0,53,33,32,0,65,139,129,16,0,112,32,1,52,136,4,169,113,137]

theorem envBound15007 : H12AffineFastState.Bounded env15007 := by
  intro p hp
  have h : env15007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15006_15007 : H12AffineEnvironment.transform 9 52 env15006 = env15007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env15006 == env15007) = true)

def env15008 : List Nat := [2,4,8,16,0,64,128,5,137,20,1,1,9,81,0,139,81,0,21,1,0,0,65,139,129,16,0,80,0,1,20,136,4,137,81,137]

theorem envBound15008 : H12AffineFastState.Bounded env15008 := by
  intro p hp
  have h : env15008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15007_15008 : H12AffineEnvironment.transform 4 0 env15007 = env15008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15007 == env15008) = true)

theorem identity15008 : scanCanonicalize (H12AffineFastState.compose env15008 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound15008 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15009 : List Nat := [2,4,8,16,0,64,25,5,16,20,1,1,9,81,0,18,81,0,21,1,0,0,65,18,24,16,0,80,0,1,20,17,4,16,81,16]

theorem envBound15009 : H12AffineFastState.Bounded env15009 := by
  intro p hp
  have h : env15009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15008_15009 : H12AffineEnvironment.transform 6 25 env15008 = env15009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env15008 == env15009) = true)

theorem identity15009 : scanCanonicalize (H12AffineFastState.compose env15009 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound15009 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15010 : List Nat := [2,4,8,16,0,17,25,5,16,20,1,1,9,0,0,18,0,0,21,1,0,0,16,18,24,16,0,1,0,1,20,17,4,16,0,16]

theorem envBound15010 : H12AffineFastState.Bounded env15010 := by
  intro p hp
  have h : env15010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15009_15010 : H12AffineEnvironment.transform 5 17 env15009 = env15010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15009 == env15010) = true)

def leafEnv15010 : List Nat := [2,4,8,16,0,17,25,5,16,20,1,1,9,0,0,18,0,0,21,1,0,0,16,18,20,24,1,16,0,1,0,1,20,17,4,16,4,2,0,16,0,0,1]

def active15010 : List Nat := [0,1,2,3]

def tree15010 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15010 : H12WitnessSearch.Good tree15010 := H12GlobalWitnessIndex.good

theorem leafIdentity15010 : H12AffineFastState.composeSystem env15010 rootObs = leafEnv15010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15010 rootObs == leafEnv15010) = true)

theorem terminalChecked15010 : H12PackedTerminal.terminalCheckFast leafEnv15010 active15010 tree15010 = true := by decide +kernel

def env15011 : List Nat := [2,4,8,16,1,64,128,5,137,21,1,0,9,80,1,138,80,0,20,0,1,0,65,139,129,16,0,81,1,1,21,136,4,136,80,137]

theorem envBound15011 : H12AffineFastState.Bounded env15011 := by
  intro p hp
  have h : env15011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15007_15011 : H12AffineEnvironment.transform 4 1 env15007 = env15011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15007 == env15011) = true)

theorem identity15011 : scanCanonicalize (H12AffineFastState.compose env15011 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound15011 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15012 : List Nat := [2,4,8,1,1,64,128,5,137,4,1,0,9,65,1,138,65,0,5,0,1,0,65,139,129,1,0,64,1,1,4,136,4,136,65,137]

theorem envBound15012 : H12AffineFastState.Bounded env15012 := by
  intro p hp
  have h : env15012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15011_15012 : H12AffineEnvironment.transform 3 1 env15011 = env15012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env15011 == env15012) = true)

def env15013 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,1345,32768,65536,1345,262144,524288,32769,4097,8201,64,98565,8328,525328,795917,1345,529408,1073741824,1284,4294967296,256,4295074214,1345,512]

theorem envBound15013 : H12AffineFastState.Bounded env15013 := by
  intro p hp
  have h : env15013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14970_15013 : H12AffineEnvironment.transform 13 1345 env14970 = env15013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env14970 == env15013) = true)

theorem identity15013 : scanCanonicalize (H12AffineFastState.compose env15013 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 533772) := by decide +kernel

theorem selectedBound15013 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env15014 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,1345,32768,65536,1345,262144,524288,32769,4097,8201,64,98565,8328,525328,795917,1345,529408,533772,1284,4294967296,256,4295074214,1345,512]

theorem envBound15014 : H12AffineFastState.Bounded env15014 := by
  intro p hp
  have h : env15014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15013_15014 : H12AffineEnvironment.transform 29 533772 env15013 = env15014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 533772 env15013 == env15014) = true)

theorem identity15014 : scanCanonicalize (H12AffineFastState.compose env15014 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(18+1) ^^^ 304168) := by decide +kernel

theorem selectedBound15014 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env15015 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,1345,32768,65536,1345,262144,304168,32769,4097,8201,64,98565,8328,303160,33061,1345,307240,295204,1284,4294967296,256,4295074214,1345,512]

theorem envBound15015 : H12AffineFastState.Bounded env15015 := by
  intro p hp
  have h : env15015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15014_15015 : H12AffineEnvironment.transform 18 304168 env15014 = env15015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 304168 env15014 == env15015) = true)

def env15016 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,4096,8192,1345,32768,65536,1345,262144,304168,32769,4097,8201,64,98565,8328,303160,33061,1345,307240,295204,1284,4294967296,256,4295074214,1345,136]

theorem envBound15016 : H12AffineFastState.Bounded env15016 := by
  intro p hp
  have h : env15016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15015_15016 : H12AffineEnvironment.transform 8 136 env15015 = env15016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env15015 == env15016) = true)

def env15017 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,4096,8192,1345,32768,65536,1345,46440,4416,32769,4097,8201,64,98565,8328,5456,33061,1345,1344,13388,1284,4294967296,256,4295074214,1345,136]

theorem envBound15017 : H12AffineFastState.Bounded env15017 := by
  intro p hp
  have h : env15017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15016_15017 : H12AffineEnvironment.transform 17 46440 env15016 = env15017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 46440 env15016 == env15017) = true)

def env15018 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,1344,8192,1345,32768,65536,1345,41000,1024,32769,1345,8201,64,98565,8328,16,33061,1345,1344,8460,1284,4294967296,256,4295074214,1345,136]

theorem envBound15018 : H12AffineFastState.Bounded env15018 := by
  intro p hp
  have h : env15018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15017_15018 : H12AffineEnvironment.transform 11 1344 env15017 = env15018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env15017 == env15018) = true)

theorem identity15018 : scanCanonicalize (H12AffineFastState.compose env15018 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound15018 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env15019 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,1344,8192,1345,293,65536,1345,8461,1024,292,1345,8201,64,65568,8328,16,0,1345,1344,8460,1284,4294967296,256,4295041155,1345,136]

theorem envBound15019 : H12AffineFastState.Bounded env15019 := by
  intro p hp
  have h : env15019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15018_15019 : H12AffineEnvironment.transform 14 293 env15018 = env15019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env15018 == env15019) = true)

theorem identity15019 : scanCanonicalize (H12AffineFastState.compose env15019 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(15+1) ^^^ 250) := by decide +kernel

theorem selectedBound15019 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env15020 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,1344,8192,1345,293,250,1345,8461,1024,292,1345,8201,64,218,8328,16,0,1345,1344,8460,1284,4294967296,256,4294975609,1345,136]

theorem envBound15020 : H12AffineFastState.Bounded env15020 := by
  intro p hp
  have h : env15020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15019_15020 : H12AffineEnvironment.transform 15 250 env15019 = env15020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 250 env15019 == env15020) = true)

theorem identity15020 : scanCanonicalize (H12AffineFastState.compose env15020 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound15020 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env15021 : List Nat := [2,4,8,16,32,17,128,256,136,1024,1,1297,8192,1296,293,171,1296,8461,1024,292,1296,8201,17,139,8328,16,0,1296,1297,8460,1284,4294967296,256,4294975528,1296,136]

theorem envBound15021 : H12AffineFastState.Bounded env15021 := by
  intro p hp
  have h : env15021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15020_15021 : H12AffineEnvironment.transform 5 17 env15020 = env15021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15020 == env15021) = true)

theorem identity15021 : scanCanonicalize (H12AffineFastState.compose env15021 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound15021 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15022 : List Nat := [2,4,8,16,32,17,128,36,136,1024,1,1077,8192,1076,1,171,1076,8233,1024,0,1076,8201,17,139,8328,16,0,1076,1077,8232,1056,4294967296,36,4294975528,1076,136]

theorem envBound15022 : H12AffineFastState.Bounded env15022 := by
  intro p hp
  have h : env15022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15021_15022 : H12AffineEnvironment.transform 7 36 env15021 = env15022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env15021 == env15022) = true)

theorem identity15022 : scanCanonicalize (H12AffineFastState.compose env15022 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound15022 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env15023 : List Nat := [2,4,8,16,32,17,128,36,136,1024,1,1077,40,1076,1,171,1076,1,1024,0,1076,33,17,139,160,16,0,1076,1077,0,1056,4294967296,36,4294967296,1076,136]

theorem envBound15023 : H12AffineFastState.Bounded env15023 := by
  intro p hp
  have h : env15023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15022_15023 : H12AffineEnvironment.transform 12 40 env15022 = env15023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env15022 == env15023) = true)

theorem identity15023 : scanCanonicalize (H12AffineFastState.compose env15023 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 136) := by decide +kernel

theorem selectedBound15023 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15024 : List Nat := [2,4,8,16,32,17,128,36,136,1024,1,1077,40,1076,1,171,1076,1,1024,0,1076,33,17,139,160,16,0,1076,1077,0,1056,136,36,136,1076,136]

theorem envBound15024 : H12AffineFastState.Bounded env15024 := by
  intro p hp
  have h : env15024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15023_15024 : H12AffineEnvironment.transform 31 136 env15023 = env15024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 136 env15023 == env15024) = true)

def leafEnv15024 : List Nat := [2,4,8,16,32,17,128,36,136,1024,1,1077,40,1076,1,171,1076,1,1024,0,1076,33,17,139,1056,160,1,16,0,1076,1077,0,1056,136,36,136,4,34,1076,136,0,1076,1]

def active15024 : List Nat := [0,1,2,3,4,6,9]

def tree15024 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15024 : H12WitnessSearch.Good tree15024 := H12GlobalWitnessIndex.good

theorem leafIdentity15024 : H12AffineFastState.composeSystem env15024 rootObs = leafEnv15024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15024 rootObs == leafEnv15024) = true)

theorem terminalChecked15024 : H12PackedTerminal.terminalCheckFast leafEnv15024 active15024 tree15024 = true := by decide +kernel

def env15025 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,1345,8192,1345,32768,65536,1345,41001,1025,32769,1344,8201,64,98565,8328,17,33061,1345,1344,8461,1284,4294967296,256,4295074214,1345,136]

theorem envBound15025 : H12AffineFastState.Bounded env15025 := by
  intro p hp
  have h : env15025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15017_15025 : H12AffineEnvironment.transform 11 1345 env15017 = env15025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env15017 == env15025) = true)

theorem identity15025 : scanCanonicalize (H12AffineFastState.compose env15025 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound15025 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env15026 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,1345,8192,1345,32768,33166,1345,41001,1025,32769,1344,8201,64,139,8328,17,33061,1345,1344,8461,1284,4294967296,256,4294975528,1345,136]

theorem envBound15026 : H12AffineFastState.Bounded env15026 := by
  intro p hp
  have h : env15026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15025_15026 : H12AffineEnvironment.transform 15 33166 env15025 = env15026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env15025 == env15026) = true)

theorem identity15026 : scanCanonicalize (H12AffineFastState.compose env15026 (packedSelected [3,5] rootPS)) = affineNative (2^(14+1) ^^^ 351) := by decide +kernel

theorem selectedBound15026 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env15027 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,1345,8192,1345,351,209,1345,8566,1025,350,1344,8201,64,139,8328,17,122,1345,1344,8461,1284,4294967296,256,4294975528,1345,136]

theorem envBound15027 : H12AffineFastState.Bounded env15027 := by
  intro p hp
  have h : env15027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15026_15027 : H12AffineEnvironment.transform 14 351 env15026 = env15027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 351 env15026 == env15027) = true)

theorem identity15027 : scanCanonicalize (H12AffineFastState.compose env15027 (packedSelected [1,3,8] rootPS)) = affineNative (2^(12+1) ^^^ 374) := by decide +kernel

theorem selectedBound15027 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env15028 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,1345,374,1345,351,209,1345,0,1025,350,1344,383,64,139,510,17,122,1345,1344,123,1284,4294967296,256,4294967646,1345,136]

theorem envBound15028 : H12AffineFastState.Bounded env15028 := by
  intro p hp
  have h : env15028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15027_15028 : H12AffineEnvironment.transform 12 374 env15027 = env15028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 374 env15027 == env15028) = true)

theorem identity15028 : scanCanonicalize (H12AffineFastState.compose env15028 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound15028 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env15029 : List Nat := [2,4,8,16,10,64,128,256,136,1024,1,1345,348,1345,351,209,1345,0,1025,350,1344,341,64,139,468,17,80,1345,1344,81,1284,4294967296,256,4294967646,1345,136]

theorem envBound15029 : H12AffineFastState.Bounded env15029 := by
  intro p hp
  have h : env15029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15028_15029 : H12AffineEnvironment.transform 4 10 env15028 = env15029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env15028 == env15029) = true)

theorem identity15029 : scanCanonicalize (H12AffineFastState.compose env15029 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 94) := by decide +kernel

theorem selectedBound15029 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env15030 : List Nat := [2,4,8,16,10,64,128,94,136,1024,1,1055,2,1055,1,209,1055,0,1025,0,1054,11,64,139,138,17,80,1055,1054,81,1114,4294967296,94,4294967296,1055,136]

theorem envBound15030 : H12AffineFastState.Bounded env15030 := by
  intro p hp
  have h : env15030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15029_15030 : H12AffineEnvironment.transform 7 94 env15029 = env15030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 94 env15029 == env15030) = true)

def env15031 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,4096,8192,1345,32768,65536,1345,46441,4417,32769,4097,8201,64,98565,8328,5457,33061,1345,1345,13389,1284,4294967296,256,4295074214,1345,136]

theorem envBound15031 : H12AffineFastState.Bounded env15031 := by
  intro p hp
  have h : env15031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15016_15031 : H12AffineEnvironment.transform 17 46441 env15016 = env15031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 46441 env15016 == env15031) = true)

def env15032 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,1344,8192,1345,32768,65536,1345,41001,1025,32769,1345,8201,64,98565,8328,17,33061,1345,1345,8461,1284,4294967296,256,4295074214,1345,136]

theorem envBound15032 : H12AffineFastState.Bounded env15032 := by
  intro p hp
  have h : env15032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15031_15032 : H12AffineEnvironment.transform 11 1344 env15031 = env15032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env15031 == env15032) = true)

theorem identity15032 : scanCanonicalize (H12AffineFastState.compose env15032 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound15032 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env15033 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,1344,8192,1345,32768,33166,1345,41001,1025,32769,1345,8201,64,139,8328,17,33061,1345,1345,8461,1284,4294967296,256,4294975528,1345,136]

theorem envBound15033 : H12AffineFastState.Bounded env15033 := by
  intro p hp
  have h : env15033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15032_15033 : H12AffineEnvironment.transform 15 33166 env15032 = env15033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env15032 == env15033) = true)

theorem identity15033 : scanCanonicalize (H12AffineFastState.compose env15033 (packedSelected [3,5] rootPS)) = affineNative (2^(12+1) ^^^ 83) := by decide +kernel

theorem selectedBound15033 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env15034 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,1344,83,1345,32768,33166,1345,32890,1025,32769,1345,90,64,139,219,17,33061,1345,1345,350,1284,4294967296,256,4294967419,1345,136]

theorem envBound15034 : H12AffineFastState.Bounded env15034 := by
  intro p hp
  have h : env15034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15033_15034 : H12AffineEnvironment.transform 12 83 env15033 = env15034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 83 env15033 == env15034) = true)

theorem identity15034 : scanCanonicalize (H12AffineFastState.compose env15034 (packedSelected [1] rootPS)) = affineNative (2^(14+1) ^^^ 122) := by decide +kernel

theorem selectedBound15034 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15035 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,1344,83,1345,122,500,1345,0,1025,123,1345,90,64,139,219,17,351,1345,1345,350,1284,4294967296,256,4294967419,1345,136]

theorem envBound15035 : H12AffineFastState.Bounded env15035 := by
  intro p hp
  have h : env15035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15034_15035 : H12AffineEnvironment.transform 14 122 env15034 = env15035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 122 env15034 == env15035) = true)

theorem identity15035 : scanCanonicalize (H12AffineFastState.compose env15035 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound15035 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env15036 : List Nat := [2,4,8,16,32,64,128,14,136,1024,1,1102,83,1103,122,250,1103,0,1025,123,1103,90,64,139,219,17,81,1103,1103,80,1034,4294967296,14,4294967419,1103,136]

theorem envBound15036 : H12AffineFastState.Bounded env15036 := by
  intro p hp
  have h : env15036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15035_15036 : H12AffineEnvironment.transform 7 14 env15035 = env15036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env15035 == env15036) = true)

theorem identity15036 : scanCanonicalize (H12AffineFastState.compose env15036 (packedSelected [8] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound15036 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env15037 : List Nat := [2,4,8,16,32,59,128,14,136,1024,1,1077,40,1076,1,129,1076,0,1025,0,1076,33,59,139,160,17,42,1076,1076,43,1034,4294967296,14,4294967296,1076,136]

theorem envBound15037 : H12AffineFastState.Bounded env15037 := by
  intro p hp
  have h : env15037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15036_15037 : H12AffineEnvironment.transform 5 59 env15036 = env15037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env15036 == env15037) = true)

theorem identity15037 : scanCanonicalize (H12AffineFastState.compose env15037 (packedSelected [2] rootPS)) = affineNative (2^(31+1) ^^^ 147) := by decide +kernel

theorem selectedBound15037 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15038 : List Nat := [2,4,8,16,32,59,128,14,136,1024,1,1077,40,1076,1,129,1076,0,1025,0,1076,33,59,139,160,17,42,1076,1076,43,1034,147,14,147,1076,136]

theorem envBound15038 : H12AffineFastState.Bounded env15038 := by
  intro p hp
  have h : env15038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15037_15038 : H12AffineEnvironment.transform 31 147 env15037 = env15038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 147 env15037 == env15038) = true)

def env15039 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,1345,8192,1345,32768,65536,1345,41000,1024,32769,1344,8201,64,98565,8328,16,33061,1345,1345,8460,1284,4294967296,256,4295074214,1345,136]

theorem envBound15039 : H12AffineFastState.Bounded env15039 := by
  intro p hp
  have h : env15039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15031_15039 : H12AffineEnvironment.transform 11 1345 env15031 = env15039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env15031 == env15039) = true)

theorem identity15039 : scanCanonicalize (H12AffineFastState.compose env15039 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound15039 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env15040 : List Nat := [2,4,8,16,32,64,128,256,136,1024,1,1345,8192,1345,293,65536,1345,8461,1024,292,1344,8201,64,65568,8328,16,0,1345,1345,8460,1284,4294967296,256,4295041155,1345,136]

theorem envBound15040 : H12AffineFastState.Bounded env15040 := by
  intro p hp
  have h : env15040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15039_15040 : H12AffineEnvironment.transform 14 293 env15039 = env15040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env15039 == env15040) = true)

theorem identity15040 : scanCanonicalize (H12AffineFastState.compose env15040 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound15040 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env15041 : List Nat := [2,4,8,16,32,16,128,256,136,1024,1,1297,8192,1297,293,65536,1297,8461,1024,292,1296,8201,16,65568,8328,16,0,1297,1297,8460,1284,4294967296,256,4295041155,1297,136]

theorem envBound15041 : H12AffineFastState.Bounded env15041 := by
  intro p hp
  have h : env15041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15040_15041 : H12AffineEnvironment.transform 5 16 env15040 = env15041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15040 == env15041) = true)

theorem identity15041 : scanCanonicalize (H12AffineFastState.compose env15041 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound15041 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env15042 : List Nat := [2,4,8,16,32,16,128,256,136,1024,1,1297,268,1297,293,65536,1297,1,1024,292,1296,261,16,65568,388,16,0,1297,1297,0,1284,4294967296,256,4295033231,1297,136]

theorem envBound15042 : H12AffineFastState.Bounded env15042 := by
  intro p hp
  have h : env15042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15041_15042 : H12AffineEnvironment.transform 12 268 env15041 = env15042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env15041 == env15042) = true)

def env15043 : List Nat := [2,4,8,16,32,16,128,36,136,1024,1,1077,40,1077,1,65536,1077,1,1024,0,1076,33,16,65568,160,16,0,1077,1077,0,1056,4294967296,36,4295033003,1077,136]

theorem envBound15043 : H12AffineFastState.Bounded env15043 := by
  intro p hp
  have h : env15043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15042_15043 : H12AffineEnvironment.transform 7 36 env15042 = env15043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env15042 == env15043) = true)

theorem identity15043 : scanCanonicalize (H12AffineFastState.compose env15043 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 65570) := by decide +kernel

theorem selectedBound15043 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15044 : List Nat := [2,4,8,16,32,16,128,36,136,1024,1,1077,40,1077,1,65536,1077,1,1024,0,1076,33,16,65568,160,16,0,1077,1077,0,1056,65570,36,137,1077,136]

theorem envBound15044 : H12AffineFastState.Bounded env15044 := by
  intro p hp
  have h : env15044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15043_15044 : H12AffineEnvironment.transform 31 65570 env15043 = env15044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 65570 env15043 == env15044) = true)

def env15045 : List Nat := [2,4,8,16,32,16,128,36,136,52,1,1,40,1,1,65536,1,1,52,0,0,33,16,65568,160,16,0,1,1,0,20,65570,36,137,1,136]

theorem envBound15045 : H12AffineFastState.Bounded env15045 := by
  intro p hp
  have h : env15045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15044_15045 : H12AffineEnvironment.transform 9 52 env15044 = env15045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env15044 == env15045) = true)

theorem identity15045 : scanCanonicalize (H12AffineFastState.compose env15045 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound15045 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15046 : List Nat := [2,4,8,16,32,16,128,36,136,52,1,1,40,1,1,171,1,1,52,0,0,33,16,139,160,16,0,1,1,0,20,137,36,137,1,136]

theorem envBound15046 : H12AffineFastState.Bounded env15046 := by
  intro p hp
  have h : env15046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15045_15046 : H12AffineEnvironment.transform 15 171 env15045 = env15046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env15045 == env15046) = true)

def leafEnv15046 : List Nat := [2,4,8,16,32,16,128,36,136,52,1,1,40,1,1,171,1,1,52,0,0,33,16,139,20,160,1,16,0,1,1,0,20,137,36,137,4,34,1,136,0,0,1]

def active15046 : List Nat := [0,1,2,3,4,6]

def tree15046 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15046 : H12WitnessSearch.Good tree15046 := H12GlobalWitnessIndex.good

theorem leafIdentity15046 : H12AffineFastState.composeSystem env15046 rootObs = leafEnv15046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15046 rootObs == leafEnv15046) = true)

theorem terminalChecked15046 : H12PackedTerminal.terminalCheckFast leafEnv15046 active15046 tree15046 = true := by decide +kernel

def env15047 : List Nat := [2,4,8,16,32,16,128,36,136,53,1,0,40,0,1,65536,0,1,53,0,1,33,16,65568,160,16,0,0,0,0,21,65570,36,137,0,136]

theorem envBound15047 : H12AffineFastState.Bounded env15047 := by
  intro p hp
  have h : env15047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15044_15047 : H12AffineEnvironment.transform 9 53 env15044 = env15047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env15044 == env15047) = true)

def env15048 : List Nat := [2,4,8,16,0,16,128,4,136,21,1,0,8,0,1,65536,0,1,21,0,1,1,16,65536,128,16,0,0,0,0,21,65538,4,137,0,136]

theorem envBound15048 : H12AffineFastState.Bounded env15048 := by
  intro p hp
  have h : env15048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15047_15048 : H12AffineEnvironment.transform 4 0 env15047 = env15048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15047 == env15048) = true)

def leafEnv15048 : List Nat := [2,4,8,16,0,16,128,4,136,21,1,0,8,0,1,65536,0,1,21,0,1,1,16,65536,21,128,1,16,0,0,0,0,21,65538,4,137,4,2,0,136,0,1,1]

def active15048 : List Nat := [0,1,2,3,6,15]

def tree15048 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15048 : H12WitnessSearch.Good tree15048 := H12GlobalWitnessIndex.good

theorem leafIdentity15048 : H12AffineFastState.composeSystem env15048 rootObs = leafEnv15048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15048 rootObs == leafEnv15048) = true)

theorem terminalChecked15048 : H12PackedTerminal.terminalCheckFast leafEnv15048 active15048 tree15048 = true := by decide +kernel

def env15049 : List Nat := [2,4,8,16,1,16,128,5,136,20,1,0,9,0,1,65536,0,1,20,0,1,0,16,65537,129,16,0,0,0,0,21,65539,5,137,0,136]

theorem envBound15049 : H12AffineFastState.Bounded env15049 := by
  intro p hp
  have h : env15049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15047_15049 : H12AffineEnvironment.transform 4 1 env15047 = env15049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15047 == env15049) = true)

theorem identity15049 : scanCanonicalize (H12AffineFastState.compose env15049 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 138) := by decide +kernel

theorem selectedBound15049 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env15050 : List Nat := [2,4,8,16,1,16,128,5,136,20,1,0,9,0,1,138,0,1,20,0,1,0,16,139,129,16,0,0,0,0,21,137,5,137,0,136]

theorem envBound15050 : H12AffineFastState.Bounded env15050 := by
  intro p hp
  have h : env15050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15049_15050 : H12AffineEnvironment.transform 15 138 env15049 = env15050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 138 env15049 == env15050) = true)

def leafEnv15050 : List Nat := [2,4,8,16,1,16,128,5,136,20,1,0,9,0,1,138,0,1,20,0,1,0,16,139,21,129,1,16,0,0,0,0,21,137,5,137,4,3,0,136,0,1,1]

def active15050 : List Nat := [0,1,2,3,6]

def tree15050 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15050 : H12WitnessSearch.Good tree15050 := H12GlobalWitnessIndex.good

theorem leafIdentity15050 : H12AffineFastState.composeSystem env15050 rootObs = leafEnv15050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15050 rootObs == leafEnv15050) = true)

theorem terminalChecked15050 : H12PackedTerminal.terminalCheckFast leafEnv15050 active15050 tree15050 = true := by decide +kernel

def env15051 : List Nat := [2,4,8,16,32,16,128,37,136,1024,1,1076,41,1076,0,65536,1076,1,1024,1,1077,32,16,65568,161,16,0,1076,1076,0,1057,4294967296,37,4295033002,1076,136]

theorem envBound15051 : H12AffineFastState.Bounded env15051 := by
  intro p hp
  have h : env15051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15042_15051 : H12AffineEnvironment.transform 7 37 env15042 = env15051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env15042 == env15051) = true)

theorem identity15051 : scanCanonicalize (H12AffineFastState.compose env15051 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 1) := by decide +kernel

theorem selectedBound15051 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15052 : List Nat := [2,4,8,16,32,16,128,37,136,1024,1,1076,41,1076,0,65536,1076,1,1024,1,1077,32,16,65568,161,16,0,1076,1076,0,1057,1,37,65707,1076,136]

theorem envBound15052 : H12AffineFastState.Bounded env15052 := by
  intro p hp
  have h : env15052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15051_15052 : H12AffineEnvironment.transform 31 1 env15051 = env15052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1 env15051 == env15052) = true)

def env15053 : List Nat := [2,4,8,16,32,16,128,37,136,52,1,0,41,0,0,65536,0,1,52,1,1,32,16,65568,161,16,0,0,0,0,21,1,37,65707,0,136]

theorem envBound15053 : H12AffineFastState.Bounded env15053 := by
  intro p hp
  have h : env15053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15052_15053 : H12AffineEnvironment.transform 9 52 env15052 = env15053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env15052 == env15053) = true)

def env15054 : List Nat := [2,4,8,16,32,16,8,37,0,52,1,0,41,0,0,65536,0,1,52,1,1,32,16,65568,41,16,0,0,0,0,21,1,37,65571,0,0]

theorem envBound15054 : H12AffineFastState.Bounded env15054 := by
  intro p hp
  have h : env15054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15053_15054 : H12AffineEnvironment.transform 6 8 env15053 = env15054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15053 == env15054) = true)

theorem identity15054 : scanCanonicalize (H12AffineFastState.compose env15054 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound15054 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15055 : List Nat := [2,4,8,16,0,16,8,5,0,20,1,0,9,0,0,65536,0,1,20,1,1,0,16,65536,9,16,0,0,0,0,21,1,5,65539,0,0]

theorem envBound15055 : H12AffineFastState.Bounded env15055 := by
  intro p hp
  have h : env15055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15054_15055 : H12AffineEnvironment.transform 4 0 env15054 = env15055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15054 == env15055) = true)

theorem identity15055 : scanCanonicalize (H12AffineFastState.compose env15055 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound15055 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env15056 : List Nat := [2,4,8,16,0,16,8,5,0,20,1,0,9,0,0,3,0,1,20,1,1,0,16,3,9,16,0,0,0,0,21,1,5,0,0,0]

theorem envBound15056 : H12AffineFastState.Bounded env15056 := by
  intro p hp
  have h : env15056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15055_15056 : H12AffineEnvironment.transform 15 3 env15055 = env15056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env15055 == env15056) = true)

def leafEnv15056 : List Nat := [2,4,8,16,0,16,8,5,0,20,1,0,9,0,0,3,0,1,20,1,1,0,16,3,21,9,1,16,0,0,0,0,21,1,5,0,4,2,0,0,0,1,1]

def active15056 : List Nat := [0,1,2,3]

def tree15056 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15056 : H12WitnessSearch.Good tree15056 := H12GlobalWitnessIndex.good

theorem leafIdentity15056 : H12AffineFastState.composeSystem env15056 rootObs = leafEnv15056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15056 rootObs == leafEnv15056) = true)

theorem terminalChecked15056 : H12PackedTerminal.terminalCheckFast leafEnv15056 active15056 tree15056 = true := by decide +kernel

def env15057 : List Nat := [2,4,8,16,32,16,9,37,1,52,1,0,41,0,0,65536,0,1,52,1,1,32,16,65568,40,16,0,0,0,0,21,1,37,65570,0,1]

theorem envBound15057 : H12AffineFastState.Bounded env15057 := by
  intro p hp
  have h : env15057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15053_15057 : H12AffineEnvironment.transform 6 9 env15053 = env15057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15053 == env15057) = true)

theorem identity15057 : scanCanonicalize (H12AffineFastState.compose env15057 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound15057 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15058 : List Nat := [2,4,8,16,32,16,9,37,1,52,1,0,41,0,0,3,0,1,52,1,1,32,16,35,40,16,0,0,0,0,21,1,37,33,0,1]

theorem envBound15058 : H12AffineFastState.Bounded env15058 := by
  intro p hp
  have h : env15058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15057_15058 : H12AffineEnvironment.transform 15 3 env15057 = env15058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env15057 == env15058) = true)

theorem identity15058 : scanCanonicalize (H12AffineFastState.compose env15058 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound15058 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env15059 : List Nat := [2,4,8,16,1,16,9,4,1,21,1,0,8,0,0,3,0,1,21,1,1,1,16,2,9,16,0,0,0,0,21,1,4,0,0,1]

theorem envBound15059 : H12AffineFastState.Bounded env15059 := by
  intro p hp
  have h : env15059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15058_15059 : H12AffineEnvironment.transform 4 1 env15058 = env15059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15058 == env15059) = true)

def leafEnv15059 : List Nat := [2,4,8,16,1,16,9,4,1,21,1,0,8,0,0,3,0,1,21,1,1,1,16,2,21,9,1,16,0,0,0,0,21,1,4,0,4,3,0,1,0,1,1]

def active15059 : List Nat := [0,1,2,3]

def tree15059 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15059 : H12WitnessSearch.Good tree15059 := H12GlobalWitnessIndex.good

theorem leafIdentity15059 : H12AffineFastState.composeSystem env15059 rootObs = leafEnv15059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15059 rootObs == leafEnv15059) = true)

theorem terminalChecked15059 : H12PackedTerminal.terminalCheckFast leafEnv15059 active15059 tree15059 = true := by decide +kernel

def env15060 : List Nat := [2,4,8,16,32,16,128,37,136,53,1,1,41,1,0,65536,1,1,53,1,0,32,16,65568,161,16,0,1,1,0,20,1,37,65707,1,136]

theorem envBound15060 : H12AffineFastState.Bounded env15060 := by
  intro p hp
  have h : env15060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15052_15060 : H12AffineEnvironment.transform 9 53 env15052 = env15060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env15052 == env15060) = true)

theorem identity15060 : scanCanonicalize (H12AffineFastState.compose env15060 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound15060 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15061 : List Nat := [2,4,8,16,32,16,128,37,136,53,1,1,41,1,0,171,1,1,53,1,0,32,16,139,161,16,0,1,1,0,20,1,37,0,1,136]

theorem envBound15061 : H12AffineFastState.Bounded env15061 := by
  intro p hp
  have h : env15061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15060_15061 : H12AffineEnvironment.transform 15 171 env15060 = env15061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env15060 == env15061) = true)

theorem identity15061 : scanCanonicalize (H12AffineFastState.compose env15061 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound15061 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15062 : List Nat := [2,4,8,16,32,16,40,37,32,53,1,1,41,1,0,3,1,1,53,1,0,32,16,35,9,16,0,1,1,0,20,1,37,0,1,32]

theorem envBound15062 : H12AffineFastState.Bounded env15062 := by
  intro p hp
  have h : env15062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15061_15062 : H12AffineEnvironment.transform 6 40 env15061 = env15062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env15061 == env15062) = true)

def leafEnv15062 : List Nat := [2,4,8,16,32,16,40,37,32,53,1,1,41,1,0,3,1,1,53,1,0,32,16,35,20,9,1,16,0,1,1,0,20,1,37,0,4,34,1,32,0,0,1]

def active15062 : List Nat := [0,1,2,3,4]

def tree15062 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15062 : H12WitnessSearch.Good tree15062 := H12GlobalWitnessIndex.good

theorem leafIdentity15062 : H12AffineFastState.composeSystem env15062 rootObs = leafEnv15062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15062 rootObs == leafEnv15062) = true)

theorem terminalChecked15062 : H12PackedTerminal.terminalCheckFast leafEnv15062 active15062 tree15062 = true := by decide +kernel

def env15063 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,4096,8192,1345,32768,65536,1345,262144,304168,32769,4097,8201,64,98565,8328,303160,33061,1345,307240,295204,1284,4294967296,256,4295074214,1345,137]

theorem envBound15063 : H12AffineFastState.Bounded env15063 := by
  intro p hp
  have h : env15063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15015_15063 : H12AffineEnvironment.transform 8 137 env15015 = env15063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env15015 == env15063) = true)

theorem identity15063 : scanCanonicalize (H12AffineFastState.compose env15063 (packedSelected [0,1,2,3,4,6,10,13,15] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound15063 : packedSelected [0,1,2,3,4,6,10,13,15] rootPS < 2^1333 := by decide +kernel

def env15064 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,4096,8192,1345,32768,33166,1345,262144,304168,32769,4097,8201,64,139,8328,303160,33061,1345,307240,295204,1284,4294967296,256,4294975528,1345,137]

theorem envBound15064 : H12AffineFastState.Bounded env15064 := by
  intro p hp
  have h : env15064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15063_15064 : H12AffineEnvironment.transform 15 33166 env15063 = env15064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env15063 == env15064) = true)

def env15065 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,4096,8192,1345,32768,33166,1345,41000,1024,32769,4097,8201,64,139,8328,16,33061,1345,4096,8460,1284,4294967296,256,4294975528,1345,137]

theorem envBound15065 : H12AffineFastState.Bounded env15065 := by
  intro p hp
  have h : env15065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15064_15065 : H12AffineEnvironment.transform 17 41000 env15064 = env15065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 41000 env15064 == env15065) = true)

theorem identity15065 : scanCanonicalize (H12AffineFastState.compose env15065 (packedSelected [1,8,10] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound15065 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env15066 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,4096,8192,1345,293,171,1345,8461,1024,292,4097,8201,64,139,8328,16,0,1345,4096,8460,1284,4294967296,256,4294975528,1345,137]

theorem envBound15066 : H12AffineFastState.Bounded env15066 := by
  intro p hp
  have h : env15066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15065_15066 : H12AffineEnvironment.transform 14 293 env15065 = env15066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env15065 == env15066) = true)

theorem identity15066 : scanCanonicalize (H12AffineFastState.compose env15066 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound15066 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env15067 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,1297,8192,1345,293,171,1345,8461,1024,292,1296,8201,64,139,8328,16,0,1345,1297,8460,1284,4294967296,256,4294975528,1345,137]

theorem envBound15067 : H12AffineFastState.Bounded env15067 := by
  intro p hp
  have h : env15067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15066_15067 : H12AffineEnvironment.transform 11 1297 env15066 = env15067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env15066 == env15067) = true)

theorem identity15067 : scanCanonicalize (H12AffineFastState.compose env15067 (packedSelected [2,4] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound15067 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env15068 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,1297,389,1345,293,171,1345,136,1024,292,1296,396,64,139,269,16,0,1345,1297,137,1284,4294967296,256,4294967725,1345,137]

theorem envBound15068 : H12AffineFastState.Bounded env15068 := by
  intro p hp
  have h : env15068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15067_15068 : H12AffineEnvironment.transform 12 389 env15067 = env15068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env15067 == env15068) = true)

theorem identity15068 : scanCanonicalize (H12AffineFastState.compose env15068 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 509) := by decide +kernel

theorem selectedBound15068 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15069 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,1297,389,1345,293,171,1345,136,1024,292,1296,396,64,139,269,16,0,1345,1297,137,1284,509,256,80,1345,137]

theorem envBound15069 : H12AffineFastState.Bounded env15069 := by
  intro p hp
  have h : env15069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15068_15069 : H12AffineEnvironment.transform 31 509 env15068 = env15069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 509 env15068 == env15069) = true)

theorem identity15069 : scanCanonicalize (H12AffineFastState.compose env15069 (packedSelected [5] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound15069 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env15070 : List Nat := [2,4,8,16,32,64,88,256,81,1024,1,1297,349,1345,293,115,1345,80,1024,292,1296,340,64,83,269,16,0,1345,1297,81,1284,293,256,80,1345,81]

theorem envBound15070 : H12AffineFastState.Bounded env15070 := by
  intro p hp
  have h : env15070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15069_15070 : H12AffineEnvironment.transform 6 88 env15069 = env15070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env15069 == env15070) = true)

def env15071 : List Nat := [2,4,8,16,32,16,8,256,1,1024,1,1297,269,1297,293,35,1297,0,1024,292,1296,260,16,3,269,16,0,1297,1297,1,1284,293,256,0,1297,1]

theorem envBound15071 : H12AffineFastState.Bounded env15071 := by
  intro p hp
  have h : env15071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15070_15071 : H12AffineEnvironment.transform 5 16 env15070 = env15071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15070 == env15071) = true)

def env15072 : List Nat := [2,4,8,16,0,16,8,256,1,1024,1,1297,269,1297,261,3,1297,0,1024,260,1296,260,16,3,269,16,0,1297,1297,1,1284,261,256,0,1297,1]

theorem envBound15072 : H12AffineFastState.Bounded env15072 := by
  intro p hp
  have h : env15072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15071_15072 : H12AffineEnvironment.transform 4 0 env15071 = env15072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15071 == env15072) = true)

def env15073 : List Nat := [2,4,8,16,1,16,8,256,1,1024,1,1297,269,1297,260,2,1297,0,1024,261,1296,260,16,3,269,16,0,1297,1297,1,1284,260,256,0,1297,1]

theorem envBound15073 : H12AffineFastState.Bounded env15073 := by
  intro p hp
  have h : env15073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15071_15073 : H12AffineEnvironment.transform 4 1 env15071 = env15073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15071 == env15073) = true)

theorem identity15073 : scanCanonicalize (H12AffineFastState.compose env15073 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound15073 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15074 : List Nat := [2,4,8,16,1,16,8,5,1,1024,1,1044,8,1044,1,2,1044,0,1024,0,1045,1,16,3,8,16,0,1044,1044,1,1025,1,5,0,1044,1]

theorem envBound15074 : H12AffineFastState.Bounded env15074 := by
  intro p hp
  have h : env15074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15073_15074 : H12AffineEnvironment.transform 7 5 env15073 = env15074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env15073 == env15074) = true)

def leafEnv15074 : List Nat := [2,4,8,16,1,16,8,5,1,1024,1,1044,8,1044,1,2,1044,0,1024,0,1045,1,16,3,1025,8,1,16,0,1044,1044,1,1025,1,5,0,4,3,1044,1,0,1045,1]

def active15074 : List Nat := [0,1,2,3,9]

def tree15074 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15074 : H12WitnessSearch.Good tree15074 := H12GlobalWitnessIndex.good

theorem leafIdentity15074 : H12AffineFastState.composeSystem env15074 rootObs = leafEnv15074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15074 rootObs == leafEnv15074) = true)

theorem terminalChecked15074 : H12PackedTerminal.terminalCheckFast leafEnv15074 active15074 tree15074 = true := by decide +kernel

def env15075 : List Nat := [2,4,8,16,32,17,9,256,0,1024,1,1297,268,1296,293,34,1296,1,1024,292,1296,261,17,2,269,16,0,1296,1297,0,1284,293,256,1,1296,0]

theorem envBound15075 : H12AffineFastState.Bounded env15075 := by
  intro p hp
  have h : env15075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15070_15075 : H12AffineEnvironment.transform 5 17 env15070 = env15075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15070 == env15075) = true)

theorem identity15075 : scanCanonicalize (H12AffineFastState.compose env15075 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound15075 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15076 : List Nat := [2,4,8,16,32,17,9,36,0,1024,1,1077,40,1076,1,34,1076,1,1024,0,1076,33,17,2,41,16,0,1076,1077,0,1056,1,36,1,1076,0]

theorem envBound15076 : H12AffineFastState.Bounded env15076 := by
  intro p hp
  have h : env15076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15075_15076 : H12AffineEnvironment.transform 7 36 env15075 = env15076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env15075 == env15076) = true)

def env15077 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,4096,8192,1345,32768,33166,1345,41001,1025,32769,4097,8201,64,139,8328,17,33061,1345,4097,8461,1284,4294967296,256,4294975528,1345,137]

theorem envBound15077 : H12AffineFastState.Bounded env15077 := by
  intro p hp
  have h : env15077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15064_15077 : H12AffineEnvironment.transform 17 41001 env15064 = env15077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 41001 env15064 == env15077) = true)

def env15078 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16384,262144,524288,32769,4097,10249,17665,98565,8328,541009,797965,1345,529408,1073741824,16453,4294967296,17473,4295076262,16384,512]

theorem envBound15078 : H12AffineFastState.Bounded env15078 := by
  intro p hp
  have h : env15078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14868_15078 : H12AffineEnvironment.transform 21 10249 env14868 = env15078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10249 env14868 == env15078) = true)

def env15079 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,16384,32768,65536,16384,262144,524288,32769,4097,8201,17665,98565,8328,541009,795917,1345,529408,1073741824,16453,4294967296,17473,4295074214,16384,512]

theorem envBound15079 : H12AffineFastState.Bounded env15079 := by
  intro p hp
  have h : env15079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15078_15079 : H12AffineEnvironment.transform 10 0 env15078 = env15079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env15078 == env15079) = true)

def env15080 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,1344,32768,65536,1344,262144,524288,32769,4097,8201,65,98565,8328,525329,795917,1345,529408,1073741824,1285,4294967296,257,4295074214,1344,512]

theorem envBound15080 : H12AffineFastState.Bounded env15080 := by
  intro p hp
  have h : env15080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15079_15080 : H12AffineEnvironment.transform 13 1344 env15079 = env15080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env15079 == env15080) = true)

theorem identity15080 : scanCanonicalize (H12AffineFastState.compose env15080 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 46393) := by decide +kernel

theorem selectedBound15080 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env15081 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,1344,32768,65536,1344,262144,524288,32769,4097,8201,65,98565,8328,525329,795917,1345,529408,46393,1285,4294967296,257,4295074214,1344,512]

theorem envBound15081 : H12AffineFastState.Bounded env15081 := by
  intro p hp
  have h : env15081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15080_15081 : H12AffineEnvironment.transform 29 46393 env15080 = env15081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 46393 env15080 == env15081) = true)

theorem identity15081 : scanCanonicalize (H12AffineFastState.compose env15081 (packedSelected [4,9,16] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound15081 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env15082 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,1344,32768,65536,1344,262144,1025,32769,4097,8201,65,98565,8328,16,270604,1345,4097,46393,1285,4294967296,257,4295074214,1344,512]

theorem envBound15082 : H12AffineFastState.Bounded env15082 := by
  intro p hp
  have h : env15082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15081_15082 : H12AffineEnvironment.transform 18 1025 env15081 = env15082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env15081 == env15082) = true)

theorem identity15082 : scanCanonicalize (H12AffineFastState.compose env15082 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound15082 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env15083 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1296,8192,1344,32768,65536,1344,262144,1025,32769,1297,8201,65,98565,8328,16,270604,1345,1297,41001,1285,4294967296,257,4295074214,1344,512]

theorem envBound15083 : H12AffineFastState.Bounded env15083 := by
  intro p hp
  have h : env15083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15082_15083 : H12AffineEnvironment.transform 11 1296 env15082 = env15083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env15082 == env15083) = true)

theorem identity15083 : scanCanonicalize (H12AffineFastState.compose env15083 (packedSelected [5,8] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound15083 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env15084 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,1296,8192,1344,32768,65536,1344,262144,1025,32769,1297,8201,65,98565,8328,16,270604,1345,1297,41001,1285,4294967296,257,4295074214,1344,137]

theorem envBound15084 : H12AffineFastState.Bounded env15084 := by
  intro p hp
  have h : env15084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15083_15084 : H12AffineEnvironment.transform 8 137 env15083 = env15084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env15083 == env15084) = true)

theorem identity15084 : scanCanonicalize (H12AffineFastState.compose env15084 (packedSelected [1,3,5] rootPS)) = affineNative (2^(17+1) ^^^ 261) := by decide +kernel

theorem selectedBound15084 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env15085 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,1296,8192,1344,32768,65536,1344,261,1025,32769,1297,8201,65,98565,8328,16,8201,1345,1297,41001,1285,4294967296,257,4295074214,1344,137]

theorem envBound15085 : H12AffineFastState.Bounded env15085 := by
  intro p hp
  have h : env15085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15084_15085 : H12AffineEnvironment.transform 17 261 env15084 = env15085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 261 env15084 == env15085) = true)

theorem identity15085 : scanCanonicalize (H12AffineFastState.compose env15085 (packedSelected [1,12,13] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound15085 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env15086 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,1296,8192,1344,293,65536,1344,261,1025,292,1297,8201,65,65568,8328,16,8201,1345,1297,8460,1285,4294967296,257,4295041155,1344,137]

theorem envBound15086 : H12AffineFastState.Bounded env15086 := by
  intro p hp
  have h : env15086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15085_15086 : H12AffineEnvironment.transform 14 293 env15085 = env15086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env15085 == env15086) = true)

theorem identity15086 : scanCanonicalize (H12AffineFastState.compose env15086 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound15086 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env15087 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,1296,8,1344,293,65536,1344,261,1025,292,1297,1,65,65568,128,16,1,1345,1297,260,1285,4294967296,257,4295032971,1344,137]

theorem envBound15087 : H12AffineFastState.Bounded env15087 := by
  intro p hp
  have h : env15087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15086_15087 : H12AffineEnvironment.transform 12 8 env15086 = env15087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env15086 == env15087) = true)

def env15088 : List Nat := [2,4,8,16,32,16,128,256,137,1024,0,1296,8,1296,293,65536,1296,261,1025,292,1297,1,17,65568,128,16,1,1297,1297,260,1285,4294967296,257,4295032971,1296,137]

theorem envBound15088 : H12AffineFastState.Bounded env15088 := by
  intro p hp
  have h : env15088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15087_15088 : H12AffineEnvironment.transform 5 16 env15087 = env15088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15087 == env15088) = true)

theorem identity15088 : scanCanonicalize (H12AffineFastState.compose env15088 (packedSelected [1,3] rootPS)) = affineNative (2^(31+1) ^^^ 137) := by decide +kernel

theorem selectedBound15088 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15089 : List Nat := [2,4,8,16,32,16,128,256,137,1024,0,1296,8,1296,293,65536,1296,261,1025,292,1297,1,17,65568,128,16,1,1297,1297,260,1285,137,257,65538,1296,137]

theorem envBound15089 : H12AffineFastState.Bounded env15089 := by
  intro p hp
  have h : env15089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15088_15089 : H12AffineEnvironment.transform 31 137 env15088 = env15089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 137 env15088 == env15089) = true)

def env15090 : List Nat := [2,4,8,16,32,16,128,256,137,272,0,0,8,0,293,65536,0,261,273,292,1,1,17,65568,128,16,1,1,1,260,21,137,257,65538,0,137]

theorem envBound15090 : H12AffineFastState.Bounded env15090 := by
  intro p hp
  have h : env15090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15089_15090 : H12AffineEnvironment.transform 9 272 env15089 = env15090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env15089 == env15090) = true)

theorem identity15090 : scanCanonicalize (H12AffineFastState.compose env15090 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound15090 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15091 : List Nat := [2,4,8,16,32,16,128,5,137,21,0,0,8,0,32,65536,0,0,20,33,1,1,17,65568,128,16,1,1,1,1,21,137,4,65538,0,137]

theorem envBound15091 : H12AffineFastState.Bounded env15091 := by
  intro p hp
  have h : env15091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15090_15091 : H12AffineEnvironment.transform 7 5 env15090 = env15091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env15090 == env15091) = true)

theorem identity15091 : scanCanonicalize (H12AffineFastState.compose env15091 (packedSelected [2,4] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound15091 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env15092 : List Nat := [2,4,8,16,32,16,128,5,137,21,0,0,8,0,32,171,0,0,20,33,1,1,17,139,128,16,1,1,1,1,21,137,4,169,0,137]

theorem envBound15092 : H12AffineFastState.Bounded env15092 := by
  intro p hp
  have h : env15092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15091_15092 : H12AffineEnvironment.transform 15 171 env15091 = env15092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env15091 == env15092) = true)

theorem identity15092 : scanCanonicalize (H12AffineFastState.compose env15092 (packedSelected [0,2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound15092 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env15093 : List Nat := [2,4,8,16,0,16,128,5,137,21,0,0,8,0,0,139,0,0,20,1,1,1,17,139,128,16,1,1,1,1,21,137,4,137,0,137]

theorem envBound15093 : H12AffineFastState.Bounded env15093 := by
  intro p hp
  have h : env15093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15092_15093 : H12AffineEnvironment.transform 4 0 env15092 = env15093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15092 == env15093) = true)

theorem identity15093 : scanCanonicalize (H12AffineFastState.compose env15093 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound15093 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15094 : List Nat := [2,4,8,1,0,1,128,5,137,4,0,0,8,0,0,139,0,0,5,1,1,1,0,139,128,1,1,1,1,1,4,137,4,137,0,137]

theorem envBound15094 : H12AffineFastState.Bounded env15094 := by
  intro p hp
  have h : env15094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15093_15094 : H12AffineEnvironment.transform 3 1 env15093 = env15094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env15093 == env15094) = true)

def leafEnv15094 : List Nat := [2,4,8,1,0,1,128,5,137,4,0,0,8,0,0,139,0,0,5,1,1,1,0,139,4,128,1,1,1,1,1,1,4,137,4,137,4,2,0,137,0,1,1]

def active15094 : List Nat := [0,1,2,6]

def tree15094 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15094 : H12WitnessSearch.Good tree15094 := H12GlobalWitnessIndex.good

theorem leafIdentity15094 : H12AffineFastState.composeSystem env15094 rootObs = leafEnv15094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15094 rootObs == leafEnv15094) = true)

theorem terminalChecked15094 : H12PackedTerminal.terminalCheckFast leafEnv15094 active15094 tree15094 = true := by decide +kernel

def env15095 : List Nat := [2,4,8,16,32,16,128,256,137,273,0,1,8,1,293,65536,1,261,272,292,0,1,17,65568,128,16,1,0,0,260,20,137,257,65538,1,137]

theorem envBound15095 : H12AffineFastState.Bounded env15095 := by
  intro p hp
  have h : env15095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15089_15095 : H12AffineEnvironment.transform 9 273 env15089 = env15095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env15089 == env15095) = true)

theorem identity15095 : scanCanonicalize (H12AffineFastState.compose env15095 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 430) := by decide +kernel

theorem selectedBound15095 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15096 : List Nat := [2,4,8,16,32,16,128,256,137,273,0,1,8,1,293,430,1,261,272,292,0,1,17,398,128,16,1,0,0,260,20,137,257,428,1,137]

theorem envBound15096 : H12AffineFastState.Bounded env15096 := by
  intro p hp
  have h : env15096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15095_15096 : H12AffineEnvironment.transform 15 430 env15095 = env15096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 430 env15095 == env15096) = true)

theorem identity15096 : scanCanonicalize (H12AffineFastState.compose env15096 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound15096 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env15097 : List Nat := [2,4,8,16,32,16,128,5,137,20,0,1,8,1,32,171,1,0,21,33,0,1,17,139,128,16,1,0,0,1,20,137,4,169,1,137]

theorem envBound15097 : H12AffineFastState.Bounded env15097 := by
  intro p hp
  have h : env15097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15096_15097 : H12AffineEnvironment.transform 7 5 env15096 = env15097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env15096 == env15097) = true)

theorem identity15097 : scanCanonicalize (H12AffineFastState.compose env15097 (packedSelected [0,2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound15097 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env15098 : List Nat := [2,4,8,16,1,16,128,5,137,20,0,1,8,1,1,138,1,0,21,0,0,1,17,139,128,16,1,0,0,1,20,137,4,136,1,137]

theorem envBound15098 : H12AffineFastState.Bounded env15098 := by
  intro p hp
  have h : env15098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15097_15098 : H12AffineEnvironment.transform 4 1 env15097 = env15098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15097 == env15098) = true)

theorem identity15098 : scanCanonicalize (H12AffineFastState.compose env15098 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound15098 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15099 : List Nat := [2,4,8,16,1,16,24,5,17,20,0,1,8,1,1,18,1,0,21,0,0,1,17,19,24,16,1,0,0,1,20,17,4,16,1,17]

theorem envBound15099 : H12AffineFastState.Bounded env15099 := by
  intro p hp
  have h : env15099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15098_15099 : H12AffineEnvironment.transform 6 24 env15098 = env15099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env15098 == env15099) = true)

def leafEnv15099 : List Nat := [2,4,8,16,1,16,24,5,17,20,0,1,8,1,1,18,1,0,21,0,0,1,17,19,20,24,1,16,1,0,0,1,20,17,4,16,4,3,1,17,0,0,1]

def active15099 : List Nat := [0,1,2,3]

def tree15099 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15099 : H12WitnessSearch.Good tree15099 := H12GlobalWitnessIndex.good

theorem leafIdentity15099 : H12AffineFastState.composeSystem env15099 rootObs = leafEnv15099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15099 rootObs == leafEnv15099) = true)

theorem terminalChecked15099 : H12PackedTerminal.terminalCheckFast leafEnv15099 active15099 tree15099 = true := by decide +kernel

def env15100 : List Nat := [2,4,8,16,32,17,128,256,137,1024,0,1296,8,1297,293,65536,1297,261,1025,292,1297,1,16,65568,128,16,1,1296,1297,260,1285,4294967296,257,4295032971,1297,137]

theorem envBound15100 : H12AffineFastState.Bounded env15100 := by
  intro p hp
  have h : env15100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15087_15100 : H12AffineEnvironment.transform 5 17 env15087 = env15100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15087 == env15100) = true)

theorem identity15100 : scanCanonicalize (H12AffineFastState.compose env15100 (packedSelected [1,3] rootPS)) = affineNative (2^(31+1) ^^^ 65570) := by decide +kernel

theorem selectedBound15100 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15101 : List Nat := [2,4,8,16,32,17,128,256,137,1024,0,1296,8,1297,293,65536,1297,261,1025,292,1297,1,16,65568,128,16,1,1296,1297,260,1285,65570,257,169,1297,137]

theorem envBound15101 : H12AffineFastState.Bounded env15101 := by
  intro p hp
  have h : env15101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15100_15101 : H12AffineEnvironment.transform 31 65570 env15100 = env15101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 65570 env15100 == env15101) = true)

theorem identity15101 : scanCanonicalize (H12AffineFastState.compose env15101 (packedSelected [0,2] rootPS)) = affineNative (2^(15+1) ^^^ 1182) := by decide +kernel

theorem selectedBound15101 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env15102 : List Nat := [2,4,8,16,32,17,128,256,137,1024,0,1296,8,1297,293,1182,1297,261,1025,292,1297,1,16,1214,128,16,1,1296,1297,260,1285,1212,257,169,1297,137]

theorem envBound15102 : H12AffineFastState.Bounded env15102 := by
  intro p hp
  have h : env15102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15101_15102 : H12AffineEnvironment.transform 15 1182 env15101 = env15102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1182 env15101 == env15102) = true)

def env15103 : List Nat := [2,4,8,16,32,17,128,256,137,272,0,0,8,1,293,398,1,261,273,292,1,1,16,430,128,16,1,0,1,260,21,428,257,169,1,137]

theorem envBound15103 : H12AffineFastState.Bounded env15103 := by
  intro p hp
  have h : env15103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15102_15103 : H12AffineEnvironment.transform 9 272 env15102 = env15103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env15102 == env15103) = true)

def env15104 : List Nat := [2,4,8,16,0,17,128,256,137,272,0,0,8,1,261,398,1,261,273,260,1,1,16,398,128,16,1,0,1,260,21,396,257,137,1,137]

theorem envBound15104 : H12AffineFastState.Bounded env15104 := by
  intro p hp
  have h : env15104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15103_15104 : H12AffineEnvironment.transform 4 0 env15103 = env15104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15103 == env15104) = true)

theorem identity15104 : scanCanonicalize (H12AffineFastState.compose env15104 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound15104 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15105 : List Nat := [2,4,8,1,0,0,128,256,137,257,0,0,8,1,261,398,1,261,256,260,1,1,1,398,128,1,1,0,1,260,4,396,257,137,1,137]

theorem envBound15105 : H12AffineFastState.Bounded env15105 := by
  intro p hp
  have h : env15105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15104_15105 : H12AffineEnvironment.transform 3 1 env15104 = env15105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env15104 == env15105) = true)

theorem identity15105 : scanCanonicalize (H12AffineFastState.compose env15105 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound15105 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env15106 : List Nat := [2,4,8,1,0,0,128,5,137,4,0,0,8,1,0,139,1,0,5,1,1,1,1,139,128,1,1,0,1,1,4,137,4,137,1,137]

theorem envBound15106 : H12AffineFastState.Bounded env15106 := by
  intro p hp
  have h : env15106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15105_15106 : H12AffineEnvironment.transform 7 5 env15105 = env15106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env15105 == env15106) = true)

def leafEnv15106 : List Nat := [2,4,8,1,0,0,128,5,137,4,0,0,8,1,0,139,1,0,5,1,1,1,1,139,4,128,1,1,1,0,1,1,4,137,4,137,4,2,1,137,0,1,1]

def active15106 : List Nat := [0,1,2,6]

def tree15106 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15106 : H12WitnessSearch.Good tree15106 := H12GlobalWitnessIndex.good

theorem leafIdentity15106 : H12AffineFastState.composeSystem env15106 rootObs = leafEnv15106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15106 rootObs == leafEnv15106) = true)

theorem terminalChecked15106 : H12PackedTerminal.terminalCheckFast leafEnv15106 active15106 tree15106 = true := by decide +kernel

def env15107 : List Nat := [2,4,8,16,1,17,128,256,137,272,0,0,8,1,260,398,1,261,273,261,1,1,16,399,128,16,1,0,1,260,21,397,257,136,1,137]

theorem envBound15107 : H12AffineFastState.Bounded env15107 := by
  intro p hp
  have h : env15107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15103_15107 : H12AffineEnvironment.transform 4 1 env15103 = env15107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15103 == env15107) = true)

theorem identity15107 : scanCanonicalize (H12AffineFastState.compose env15107 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 156) := by decide +kernel

theorem selectedBound15107 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15108 : List Nat := [2,4,8,16,1,17,128,156,137,140,0,0,8,1,152,18,1,153,141,153,1,1,16,19,128,16,1,0,1,152,21,17,157,136,1,137]

theorem envBound15108 : H12AffineFastState.Bounded env15108 := by
  intro p hp
  have h : env15108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15107_15108 : H12AffineEnvironment.transform 7 156 env15107 = env15108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 156 env15107 == env15108) = true)

def env15109 : List Nat := [2,4,8,16,32,17,128,256,137,273,0,1,8,0,293,399,0,261,272,292,0,1,16,431,128,16,1,1,0,260,20,429,257,169,0,137]

theorem envBound15109 : H12AffineFastState.Bounded env15109 := by
  intro p hp
  have h : env15109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15102_15109 : H12AffineEnvironment.transform 9 273 env15102 = env15109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env15102 == env15109) = true)

theorem identity15109 : scanCanonicalize (H12AffineFastState.compose env15109 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound15109 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15110 : List Nat := [2,4,8,16,32,17,128,37,137,52,0,1,8,0,0,170,0,32,53,1,0,1,16,138,128,16,1,1,0,33,20,136,36,169,0,137]

theorem envBound15110 : H12AffineFastState.Bounded env15110 := by
  intro p hp
  have h : env15110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15109_15110 : H12AffineEnvironment.transform 7 37 env15109 = env15110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env15109 == env15110) = true)

def env15111 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,1345,32768,65536,1345,262144,524288,32769,4097,8201,64,98565,8328,525328,795917,1345,529408,1073741824,1284,4294967296,256,4295074214,1345,512]

theorem envBound15111 : H12AffineFastState.Bounded env15111 := by
  intro p hp
  have h : env15111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15079_15111 : H12AffineEnvironment.transform 13 1345 env15079 = env15111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env15079 == env15111) = true)

theorem identity15111 : scanCanonicalize (H12AffineFastState.compose env15111 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 566312) := by decide +kernel

theorem selectedBound15111 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env15112 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,1345,32768,65536,1345,262144,524288,32769,4097,8201,64,98565,8328,525328,795917,1345,529408,566312,1284,4294967296,256,4295074214,1345,512]

theorem envBound15112 : H12AffineFastState.Bounded env15112 := by
  intro p hp
  have h : env15112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15111_15112 : H12AffineEnvironment.transform 29 566312 env15111 = env15112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 566312 env15111 == env15112) = true)

def env15113 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,1345,32768,65536,1345,262144,304168,32769,4097,8201,64,98565,8328,303160,33061,1345,307240,262144,1284,4294967296,256,4295074214,1345,512]

theorem envBound15113 : H12AffineFastState.Bounded env15113 := by
  intro p hp
  have h : env15113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15112_15113 : H12AffineEnvironment.transform 18 304168 env15112 = env15113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 304168 env15112 == env15113) = true)

def env15114 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,1345,32768,65536,1345,262144,304169,32769,4097,8201,64,98565,8328,303161,33060,1345,307241,262145,1284,4294967296,256,4295074214,1345,512]

theorem envBound15114 : H12AffineFastState.Bounded env15114 := by
  intro p hp
  have h : env15114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15112_15114 : H12AffineEnvironment.transform 18 304169 env15112 = env15114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 304169 env15112 == env15114) = true)

theorem identity15114 : scanCanonicalize (H12AffineFastState.compose env15114 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound15114 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env15115 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,4096,8192,1345,293,65536,1345,262144,271628,292,4097,8201,64,65568,8328,270620,1,1345,274700,262145,1284,4294967296,256,4295041155,1345,512]

theorem envBound15115 : H12AffineFastState.Bounded env15115 := by
  intro p hp
  have h : env15115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15114_15115 : H12AffineEnvironment.transform 14 293 env15114 = env15115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env15114 == env15115) = true)

def env15116 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1296,8192,1345,293,65536,1345,262144,271628,292,1297,8201,64,65568,8328,270620,1,1345,271388,262145,1284,4294967296,256,4295041155,1345,512]

theorem envBound15116 : H12AffineFastState.Bounded env15116 := by
  intro p hp
  have h : env15116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15115_15116 : H12AffineEnvironment.transform 11 1296 env15115 = env15116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env15115 == env15116) = true)

theorem identity15116 : scanCanonicalize (H12AffineFastState.compose env15116 (packedSelected [0,7] rootPS)) = affineNative (2^(17+1) ^^^ 8460) := by decide +kernel

theorem selectedBound15116 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env15117 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1296,8192,1345,293,65536,1345,8460,1024,292,1297,8201,64,65568,8328,16,1,1345,1296,8461,1284,4294967296,256,4295041155,1345,512]

theorem envBound15117 : H12AffineFastState.Bounded env15117 := by
  intro p hp
  have h : env15117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15116_15117 : H12AffineEnvironment.transform 17 8460 env15116 = env15117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8460 env15116 == env15117) = true)

theorem identity15117 : scanCanonicalize (H12AffineFastState.compose env15117 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound15117 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env15118 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1296,40,1345,293,65536,1345,292,1024,292,1297,33,64,65568,160,16,1,1345,1296,293,1284,4294967296,256,4295033003,1345,512]

theorem envBound15118 : H12AffineFastState.Bounded env15118 := by
  intro p hp
  have h : env15118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15117_15118 : H12AffineEnvironment.transform 12 40 env15117 = env15118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env15117 == env15118) = true)

theorem identity15118 : scanCanonicalize (H12AffineFastState.compose env15118 (packedSelected [1,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound15118 : packedSelected [1,5,10] rootPS < 2^1333 := by decide +kernel

def env15119 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1296,40,1345,293,171,1345,292,1024,292,1297,33,64,139,160,16,1,1345,1296,293,1284,4294967296,256,4294967296,1345,512]

theorem envBound15119 : H12AffineFastState.Bounded env15119 := by
  intro p hp
  have h : env15119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15118_15119 : H12AffineEnvironment.transform 15 171 env15118 = env15119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env15118 == env15119) = true)

theorem identity15119 : scanCanonicalize (H12AffineFastState.compose env15119 (packedSelected [2] rootPS)) = affineNative (2^(31+1) ^^^ 885) := by decide +kernel

theorem selectedBound15119 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15120 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1296,40,1345,293,171,1345,292,1024,292,1297,33,64,139,160,16,1,1345,1296,293,1284,885,256,885,1345,512]

theorem envBound15120 : H12AffineFastState.Bounded env15120 := by
  intro p hp
  have h : env15120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15119_15120 : H12AffineEnvironment.transform 31 885 env15119 = env15120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 885 env15119 == env15120) = true)

def env15121 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,1297,8192,1345,293,65536,1345,262144,271628,292,1296,8201,64,65568,8328,270620,1,1345,271389,262145,1284,4294967296,256,4295041155,1345,512]

theorem envBound15121 : H12AffineFastState.Bounded env15121 := by
  intro p hp
  have h : env15121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15115_15121 : H12AffineEnvironment.transform 11 1297 env15115 = env15121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env15115 == env15121) = true)

def env15122 : List Nat := [2,4,8,16,32,16,128,256,512,1024,0,1297,8192,1297,293,65536,1297,262144,271628,292,1296,8201,16,65568,8328,270620,1,1297,271389,262145,1284,4294967296,256,4295041155,1297,512]

theorem envBound15122 : H12AffineFastState.Bounded env15122 := by
  intro p hp
  have h : env15122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15121_15122 : H12AffineEnvironment.transform 5 16 env15121 = env15122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15121 == env15122) = true)

theorem identity15122 : scanCanonicalize (H12AffineFastState.compose env15122 (packedSelected [3,8,10,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 8460) := by decide +kernel

theorem selectedBound15122 : packedSelected [3,8,10,12,15] rootPS < 2^1333 := by decide +kernel

def env15123 : List Nat := [2,4,8,16,32,16,128,256,512,1024,0,1297,8192,1297,293,65536,1297,8460,1024,292,1296,8201,16,65568,8328,16,1,1297,1297,8461,1284,4294967296,256,4295041155,1297,512]

theorem envBound15123 : H12AffineFastState.Bounded env15123 := by
  intro p hp
  have h : env15123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15122_15123 : H12AffineEnvironment.transform 17 8460 env15122 = env15123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8460 env15122 == env15123) = true)

theorem identity15123 : scanCanonicalize (H12AffineFastState.compose env15123 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 901) := by decide +kernel

theorem selectedBound15123 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env15124 : List Nat := [2,4,8,16,32,16,128,256,512,1024,0,1297,901,1297,293,65536,1297,649,1024,292,1296,908,16,65568,781,16,1,1297,1297,648,1284,4294967296,256,4295033606,1297,512]

theorem envBound15124 : H12AffineFastState.Bounded env15124 := by
  intro p hp
  have h : env15124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15123_15124 : H12AffineEnvironment.transform 12 901 env15123 = env15124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 901 env15123 == env15124) = true)

def env15125 : List Nat := [2,4,8,16,32,16,128,36,512,1024,0,1077,673,1077,1,65536,1077,649,1024,0,1076,680,16,65568,553,16,1,1077,1077,648,1056,4294967296,36,4295033378,1077,512]

theorem envBound15125 : H12AffineFastState.Bounded env15125 := by
  intro p hp
  have h : env15125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15124_15125 : H12AffineEnvironment.transform 7 36 env15124 = env15125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env15124 == env15125) = true)

theorem identity15125 : scanCanonicalize (H12AffineFastState.compose env15125 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 65707) := by decide +kernel

theorem selectedBound15125 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15126 : List Nat := [2,4,8,16,32,16,128,36,512,1024,0,1077,673,1077,1,65536,1077,649,1024,0,1076,680,16,65568,553,16,1,1077,1077,648,1056,65707,36,649,1077,512]

theorem envBound15126 : H12AffineFastState.Bounded env15126 := by
  intro p hp
  have h : env15126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15125_15126 : H12AffineEnvironment.transform 31 65707 env15125 = env15126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 65707 env15125 == env15126) = true)

def env15127 : List Nat := [2,4,8,16,32,16,128,36,512,52,0,1,673,1,1,65536,1,649,52,0,0,680,16,65568,553,16,1,1,1,648,20,65707,36,649,1,512]

theorem envBound15127 : H12AffineFastState.Bounded env15127 := by
  intro p hp
  have h : env15127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15126_15127 : H12AffineEnvironment.transform 9 52 env15126 = env15127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env15126 == env15127) = true)

theorem identity15127 : scanCanonicalize (H12AffineFastState.compose env15127 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound15127 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15128 : List Nat := [2,4,8,16,32,16,128,36,512,52,0,1,673,1,1,171,1,649,52,0,0,680,16,139,553,16,1,1,1,648,20,0,36,649,1,512]

theorem envBound15128 : H12AffineFastState.Bounded env15128 := by
  intro p hp
  have h : env15128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15127_15128 : H12AffineEnvironment.transform 15 171 env15127 = env15128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env15127 == env15128) = true)

def env15129 : List Nat := [2,4,8,16,0,16,128,4,512,20,0,1,641,1,1,139,1,649,20,0,0,648,16,139,521,16,1,1,1,648,20,0,4,649,1,512]

theorem envBound15129 : H12AffineFastState.Bounded env15129 := by
  intro p hp
  have h : env15129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15128_15129 : H12AffineEnvironment.transform 4 0 env15128 = env15129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15128 == env15129) = true)

theorem identity15129 : scanCanonicalize (H12AffineFastState.compose env15129 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound15129 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15130 : List Nat := [2,4,8,16,0,16,8,4,512,20,0,1,521,1,1,3,1,513,20,0,0,512,16,3,521,16,1,1,1,512,20,0,4,513,1,512]

theorem envBound15130 : H12AffineFastState.Bounded env15130 := by
  intro p hp
  have h : env15130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15129_15130 : H12AffineEnvironment.transform 6 8 env15129 = env15130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15129 == env15130) = true)

def env15131 : List Nat := [2,4,8,16,1,16,128,5,512,21,0,1,640,1,1,138,1,649,21,0,0,649,16,139,520,16,1,1,1,648,20,0,5,649,1,512]

theorem envBound15131 : H12AffineFastState.Bounded env15131 := by
  intro p hp
  have h : env15131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15128_15131 : H12AffineEnvironment.transform 4 1 env15128 = env15131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15128 == env15131) = true)

theorem identity15131 : scanCanonicalize (H12AffineFastState.compose env15131 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound15131 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15132 : List Nat := [2,4,8,16,1,16,128,5,1,21,0,1,129,1,1,138,1,136,21,0,0,136,16,139,9,16,1,1,1,137,20,0,5,136,1,1]

theorem envBound15132 : H12AffineFastState.Bounded env15132 := by
  intro p hp
  have h : env15132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15131_15132 : H12AffineEnvironment.transform 8 1 env15131 = env15132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env15131 == env15132) = true)

def env15133 : List Nat := [2,4,8,16,32,16,128,36,512,53,0,0,673,0,1,65536,0,649,53,0,1,680,16,65568,553,16,1,0,0,648,21,65707,36,649,0,512]

theorem envBound15133 : H12AffineFastState.Bounded env15133 := by
  intro p hp
  have h : env15133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15126_15133 : H12AffineEnvironment.transform 9 53 env15126 = env15133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env15126 == env15133) = true)

def env15134 : List Nat := [2,4,8,16,32,16,128,36,32,53,0,0,129,0,1,65536,0,169,53,0,1,136,16,65568,9,16,1,0,0,168,21,65707,36,169,0,32]

theorem envBound15134 : H12AffineFastState.Bounded env15134 := by
  intro p hp
  have h : env15134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15133_15134 : H12AffineEnvironment.transform 8 32 env15133 = env15134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env15133 == env15134) = true)

theorem identity15134 : scanCanonicalize (H12AffineFastState.compose env15134 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound15134 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env15135 : List Nat := [2,4,8,16,32,16,128,36,32,53,0,0,129,0,1,170,0,169,53,0,1,136,16,138,9,16,1,0,0,168,21,1,36,169,0,32]

theorem envBound15135 : H12AffineFastState.Bounded env15135 := by
  intro p hp
  have h : env15135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15134_15135 : H12AffineEnvironment.transform 15 170 env15134 = env15135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env15134 == env15135) = true)

theorem identity15135 : scanCanonicalize (H12AffineFastState.compose env15135 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound15135 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15136 : List Nat := [2,4,8,16,32,16,40,36,32,53,0,0,41,0,1,2,0,1,53,0,1,32,16,34,9,16,1,0,0,0,21,1,36,1,0,32]

theorem envBound15136 : H12AffineFastState.Bounded env15136 := by
  intro p hp
  have h : env15136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15135_15136 : H12AffineEnvironment.transform 6 40 env15135 = env15136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env15135 == env15136) = true)

theorem identity15136 : scanCanonicalize (H12AffineFastState.compose env15136 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound15136 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15137 : List Nat := [2,4,8,16,1,16,9,5,1,20,0,0,8,0,1,2,0,1,20,0,1,1,16,3,9,16,1,0,0,0,21,1,5,1,0,1]

theorem envBound15137 : H12AffineFastState.Bounded env15137 := by
  intro p hp
  have h : env15137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15136_15137 : H12AffineEnvironment.transform 4 1 env15136 = env15137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15136 == env15137) = true)

def leafEnv15137 : List Nat := [2,4,8,16,1,16,9,5,1,20,0,0,8,0,1,2,0,1,20,0,1,1,16,3,21,9,1,16,1,0,0,0,21,1,5,1,4,3,0,1,0,1,1]

def active15137 : List Nat := [0,1,2,3]

def tree15137 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15137 : H12WitnessSearch.Good tree15137 := H12GlobalWitnessIndex.good

theorem leafIdentity15137 : H12AffineFastState.composeSystem env15137 rootObs = leafEnv15137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15137 rootObs == leafEnv15137) = true)

theorem terminalChecked15137 : H12PackedTerminal.terminalCheckFast leafEnv15137 active15137 tree15137 = true := by decide +kernel

def env15138 : List Nat := [2,4,8,16,32,16,128,36,33,53,0,0,128,0,1,65536,0,168,53,0,1,137,16,65568,8,16,1,0,0,169,21,65707,36,168,0,33]

theorem envBound15138 : H12AffineFastState.Bounded env15138 := by
  intro p hp
  have h : env15138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15133_15138 : H12AffineEnvironment.transform 8 33 env15133 = env15138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env15133 == env15138) = true)

theorem identity15138 : scanCanonicalize (H12AffineFastState.compose env15138 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound15138 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env15139 : List Nat := [2,4,8,16,32,16,41,36,33,53,0,0,41,0,1,65536,0,1,53,0,1,32,16,65568,8,16,1,0,0,0,21,65538,36,1,0,33]

theorem envBound15139 : H12AffineFastState.Bounded env15139 := by
  intro p hp
  have h : env15139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15138_15139 : H12AffineEnvironment.transform 6 41 env15138 = env15139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env15138 == env15139) = true)

def env15140 : List Nat := [2,4,8,16,0,16,9,4,1,21,0,0,9,0,1,65536,0,1,21,0,1,0,16,65536,8,16,1,0,0,0,21,65538,4,1,0,1]

theorem envBound15140 : H12AffineFastState.Bounded env15140 := by
  intro p hp
  have h : env15140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15139_15140 : H12AffineEnvironment.transform 4 0 env15139 = env15140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15139 == env15140) = true)

def env15141 : List Nat := [2,4,8,16,1,16,8,5,0,20,0,0,8,0,1,65536,0,1,20,0,1,1,16,65537,8,16,1,0,0,0,21,65538,5,1,0,0]

theorem envBound15141 : H12AffineFastState.Bounded env15141 := by
  intro p hp
  have h : env15141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15139_15141 : H12AffineEnvironment.transform 4 1 env15139 = env15141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15139 == env15141) = true)

theorem identity15141 : scanCanonicalize (H12AffineFastState.compose env15141 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound15141 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15142 : List Nat := [2,4,8,16,1,16,8,5,0,20,0,0,8,0,1,3,0,1,20,0,1,1,16,2,8,16,1,0,0,0,21,1,5,1,0,0]

theorem envBound15142 : H12AffineFastState.Bounded env15142 := by
  intro p hp
  have h : env15142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15141_15142 : H12AffineEnvironment.transform 15 3 env15141 = env15142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env15141 == env15142) = true)

def leafEnv15142 : List Nat := [2,4,8,16,1,16,8,5,0,20,0,0,8,0,1,3,0,1,20,0,1,1,16,2,21,8,1,16,1,0,0,0,21,1,5,1,4,3,0,0,0,1,1]

def active15142 : List Nat := [0,1,2,3]

def tree15142 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15142 : H12WitnessSearch.Good tree15142 := H12GlobalWitnessIndex.good

theorem leafIdentity15142 : H12AffineFastState.composeSystem env15142 rootObs = leafEnv15142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15142 rootObs == leafEnv15142) = true)

theorem terminalChecked15142 : H12PackedTerminal.terminalCheckFast leafEnv15142 active15142 tree15142 = true := by decide +kernel

def env15143 : List Nat := [2,4,8,16,32,16,128,37,512,1024,0,1076,672,1076,0,65536,1076,649,1024,1,1077,681,16,65568,552,16,1,1076,1076,648,1057,4294967296,37,4295033379,1076,512]

theorem envBound15143 : H12AffineFastState.Bounded env15143 := by
  intro p hp
  have h : env15143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15124_15143 : H12AffineEnvironment.transform 7 37 env15124 = env15143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env15124 == env15143) = true)

theorem identity15143 : scanCanonicalize (H12AffineFastState.compose env15143 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 513) := by decide +kernel

theorem selectedBound15143 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15144 : List Nat := [2,4,8,16,32,16,128,37,512,1024,0,1076,672,1076,0,65536,1076,649,1024,1,1077,681,16,65568,552,16,1,1076,1076,648,1057,513,37,65570,1076,512]

theorem envBound15144 : H12AffineFastState.Bounded env15144 := by
  intro p hp
  have h : env15144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15143_15144 : H12AffineEnvironment.transform 31 513 env15143 = env15144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 513 env15143 == env15144) = true)

def env15145 : List Nat := [2,4,8,16,32,16,128,37,512,52,0,0,672,0,0,65536,0,649,52,1,1,681,16,65568,552,16,1,0,0,648,21,513,37,65570,0,512]

theorem envBound15145 : H12AffineFastState.Bounded env15145 := by
  intro p hp
  have h : env15145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15144_15145 : H12AffineEnvironment.transform 9 52 env15144 = env15145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env15144 == env15145) = true)

def env15146 : List Nat := [2,4,8,16,32,16,128,37,32,52,0,0,128,0,0,65536,0,169,52,1,1,137,16,65568,8,16,1,0,0,168,21,33,37,65570,0,32]

theorem envBound15146 : H12AffineFastState.Bounded env15146 := by
  intro p hp
  have h : env15146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15145_15146 : H12AffineEnvironment.transform 8 32 env15145 = env15146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env15145 == env15146) = true)

theorem identity15146 : scanCanonicalize (H12AffineFastState.compose env15146 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound15146 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15147 : List Nat := [2,4,8,16,32,16,128,37,32,52,0,0,128,0,0,2,0,169,52,1,1,137,16,34,8,16,1,0,0,168,21,33,37,32,0,32]

theorem envBound15147 : H12AffineFastState.Bounded env15147 := by
  intro p hp
  have h : env15147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15146_15147 : H12AffineEnvironment.transform 15 2 env15146 = env15147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env15146 == env15147) = true)

theorem identity15147 : scanCanonicalize (H12AffineFastState.compose env15147 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound15147 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env15148 : List Nat := [2,4,8,16,0,16,128,5,0,20,0,0,128,0,0,2,0,137,20,1,1,137,16,2,8,16,1,0,0,136,21,1,5,0,0,0]

theorem envBound15148 : H12AffineFastState.Bounded env15148 := by
  intro p hp
  have h : env15148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15147_15148 : H12AffineEnvironment.transform 4 0 env15147 = env15148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15147 == env15148) = true)

def leafEnv15148 : List Nat := [2,4,8,16,0,16,128,5,0,20,0,0,128,0,0,2,0,137,20,1,1,137,16,2,21,8,1,16,1,0,0,136,21,1,5,0,4,2,0,0,0,1,1]

def active15148 : List Nat := [0,1,2,3,6]

def tree15148 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15148 : H12WitnessSearch.Good tree15148 := H12GlobalWitnessIndex.good

theorem leafIdentity15148 : H12AffineFastState.composeSystem env15148 rootObs = leafEnv15148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15148 rootObs == leafEnv15148) = true)

theorem terminalChecked15148 : H12PackedTerminal.terminalCheckFast leafEnv15148 active15148 tree15148 = true := by decide +kernel

def env15149 : List Nat := [2,4,8,16,32,16,128,37,33,52,0,0,129,0,0,65536,0,168,52,1,1,136,16,65568,9,16,1,0,0,169,21,32,37,65570,0,33]

theorem envBound15149 : H12AffineFastState.Bounded env15149 := by
  intro p hp
  have h : env15149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15145_15149 : H12AffineEnvironment.transform 8 33 env15145 = env15149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env15145 == env15149) = true)

theorem identity15149 : scanCanonicalize (H12AffineFastState.compose env15149 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound15149 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15150 : List Nat := [2,4,8,16,32,16,128,37,33,52,0,0,129,0,0,170,0,168,52,1,1,136,16,138,9,16,1,0,0,169,21,32,37,136,0,33]

theorem envBound15150 : H12AffineFastState.Bounded env15150 := by
  intro p hp
  have h : env15150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15149_15150 : H12AffineEnvironment.transform 15 170 env15149 = env15150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env15149 == env15150) = true)

theorem identity15150 : scanCanonicalize (H12AffineFastState.compose env15150 (packedSelected [4,6] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound15150 : packedSelected [4,6] rootPS < 2^1333 := by decide +kernel

def env15151 : List Nat := [2,4,8,16,32,16,41,37,33,52,0,0,40,0,0,3,0,1,52,1,1,33,16,35,9,16,1,0,0,0,21,32,37,33,0,33]

theorem envBound15151 : H12AffineFastState.Bounded env15151 := by
  intro p hp
  have h : env15151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15150_15151 : H12AffineEnvironment.transform 6 41 env15150 = env15151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env15150 == env15151) = true)

theorem identity15151 : scanCanonicalize (H12AffineFastState.compose env15151 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound15151 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env15152 : List Nat := [2,4,8,16,0,16,9,5,1,20,0,0,8,0,0,3,0,1,20,1,1,1,16,3,9,16,1,0,0,0,21,0,5,1,0,1]

theorem envBound15152 : H12AffineFastState.Bounded env15152 := by
  intro p hp
  have h : env15152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15151_15152 : H12AffineEnvironment.transform 4 0 env15151 = env15152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15151 == env15152) = true)

def leafEnv15152 : List Nat := [2,4,8,16,0,16,9,5,1,20,0,0,8,0,0,3,0,1,20,1,1,1,16,3,21,9,1,16,1,0,0,0,21,0,5,1,4,2,0,1,0,1,1]

def active15152 : List Nat := [0,1,2,3]

def tree15152 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15152 : H12WitnessSearch.Good tree15152 := H12GlobalWitnessIndex.good

theorem leafIdentity15152 : H12AffineFastState.composeSystem env15152 rootObs = leafEnv15152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15152 rootObs == leafEnv15152) = true)

theorem terminalChecked15152 : H12PackedTerminal.terminalCheckFast leafEnv15152 active15152 tree15152 = true := by decide +kernel

def env15153 : List Nat := [2,4,8,16,32,16,128,37,512,53,0,1,672,1,0,65536,1,649,53,1,0,681,16,65568,552,16,1,1,1,648,20,513,37,65570,1,512]

theorem envBound15153 : H12AffineFastState.Bounded env15153 := by
  intro p hp
  have h : env15153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15144_15153 : H12AffineEnvironment.transform 9 53 env15144 = env15153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env15144 == env15153) = true)

theorem identity15153 : scanCanonicalize (H12AffineFastState.compose env15153 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound15153 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15154 : List Nat := [2,4,8,16,32,16,128,37,512,53,0,1,672,1,0,171,1,649,53,1,0,681,16,139,552,16,1,1,1,648,20,513,37,137,1,512]

theorem envBound15154 : H12AffineFastState.Bounded env15154 := by
  intro p hp
  have h : env15154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15153_15154 : H12AffineEnvironment.transform 15 171 env15153 = env15154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env15153 == env15154) = true)

def env15155 : List Nat := [2,4,8,16,32,16,128,37,32,53,0,1,128,1,0,171,1,169,53,1,0,137,16,139,8,16,1,1,1,168,20,33,37,137,1,32]

end H12CloudChart2