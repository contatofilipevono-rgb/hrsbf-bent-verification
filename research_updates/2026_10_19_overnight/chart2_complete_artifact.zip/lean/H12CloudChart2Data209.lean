import H12CloudChart2Data208

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound52627 : H12AffineFastState.Bounded env52627 := by
  intro p hp
  have h : env52627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52623_52627 : H12AffineEnvironment.transform 11 1345 env52623 = env52627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env52623 == env52627) = true)

theorem identity52627 : scanCanonicalize (H12AffineFastState.compose env52627 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound52627 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env52628 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,0,8192,81,32768,32882,0,262144,40989,32769,0,41088,16,262288,33236,41245,41059,81,41229,43128,262562,41245,256,303354,0,41821]

theorem envBound52628 : H12AffineFastState.Bounded env52628 := by
  intro p hp
  have h : env52628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52627_52628 : H12AffineEnvironment.transform 9 321 env52627 = env52628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env52627 == env52628) = true)

theorem identity52628 : scanCanonicalize (H12AffineFastState.compose env52628 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound52628 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env52629 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,0,8192,81,8541,8495,0,262144,320,8540,0,477,16,262288,8329,64,318,81,80,2341,262562,64,256,262567,0,512]

theorem envBound52629 : H12AffineFastState.Bounded env52629 := by
  intro p hp
  have h : env52629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52628_52629 : H12AffineEnvironment.transform 14 8541 env52628 = env52629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env52628 == env52629) = true)

theorem identity52629 : scanCanonicalize (H12AffineFastState.compose env52629 (packedSelected [4,9,16] rootPS)) = affineNative (2^(17+1) ^^^ 243) := by decide +kernel

theorem selectedBound52629 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env52630 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,0,8192,81,8541,8495,0,243,320,8540,0,477,16,99,8329,64,318,81,80,2341,337,64,256,340,0,512]

theorem envBound52630 : H12AffineFastState.Bounded env52630 := by
  intro p hp
  have h : env52630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52629_52630 : H12AffineEnvironment.transform 17 243 env52629 = env52630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 243 env52629 == env52630) = true)

theorem identity52630 : scanCanonicalize (H12AffineFastState.compose env52630 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 901) := by decide +kernel

theorem selectedBound52630 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52631 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,0,901,81,728,682,0,243,320,729,0,477,16,99,780,64,318,81,80,2341,337,64,256,340,0,512]

theorem envBound52631 : H12AffineFastState.Bounded env52631 := by
  intro p hp
  have h : env52631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52630_52631 : H12AffineEnvironment.transform 12 901 env52630 = env52631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 901 env52630 == env52631) = true)

theorem identity52631 : scanCanonicalize (H12AffineFastState.compose env52631 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound52631 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env52632 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,0,901,1,648,682,0,163,272,649,0,397,16,51,780,16,318,1,0,2341,257,16,256,260,0,512]

theorem envBound52632 : H12AffineFastState.Bounded env52632 := by
  intro p hp
  have h : env52632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52631_52632 : H12AffineEnvironment.transform 5 16 env52631 = env52632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52631 == env52632) = true)

theorem identity52632 : scanCanonicalize (H12AffineFastState.compose env52632 (packedSelected [1,3,13] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound52632 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env52633 : List Nat := [2,4,8,16,32,16,56,256,512,273,2048,0,829,1,560,530,0,27,272,561,0,309,16,51,780,16,318,1,0,2341,257,16,256,260,0,512]

theorem envBound52633 : H12AffineFastState.Bounded env52633 := by
  intro p hp
  have h : env52633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52632_52633 : H12AffineEnvironment.transform 6 56 env52632 = env52633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env52632 == env52633) = true)

theorem identity52633 : scanCanonicalize (H12AffineFastState.compose env52633 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 560) := by decide +kernel

theorem selectedBound52633 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52634 : List Nat := [2,4,8,16,32,16,56,256,512,273,560,0,829,1,560,530,0,27,272,561,0,309,16,51,780,16,318,1,0,789,257,16,256,260,0,512]

theorem envBound52634 : H12AffineFastState.Bounded env52634 := by
  intro p hp
  have h : env52634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52633_52634 : H12AffineEnvironment.transform 10 560 env52633 = env52634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 560 env52633 == env52634) = true)

theorem identity52634 : scanCanonicalize (H12AffineFastState.compose env52634 (packedSelected [0,5] rootPS)) = affineNative (2^(8+1) ^^^ 271) := by decide +kernel

theorem selectedBound52634 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env52635 : List Nat := [2,4,8,16,32,16,56,256,271,273,319,0,50,1,319,285,0,27,272,318,0,309,16,51,3,16,318,1,0,26,257,16,256,260,0,271]

theorem envBound52635 : H12AffineFastState.Bounded env52635 := by
  intro p hp
  have h : env52635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52634_52635 : H12AffineEnvironment.transform 8 271 env52634 = env52635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 271 env52634 == env52635) = true)

theorem identity52635 : scanCanonicalize (H12AffineFastState.compose env52635 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound52635 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env52636 : List Nat := [2,4,8,16,11,16,19,256,271,273,276,0,25,1,276,285,0,27,272,277,0,286,16,24,3,16,277,1,0,26,257,16,256,260,0,271]

theorem envBound52636 : H12AffineFastState.Bounded env52636 := by
  intro p hp
  have h : env52636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52635_52636 : H12AffineEnvironment.transform 4 11 env52635 = env52636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env52635 == env52636) = true)

theorem identity52636 : scanCanonicalize (H12AffineFastState.compose env52636 (packedSelected [3,8] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound52636 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env52637 : List Nat := [2,4,8,10,11,10,9,256,271,267,270,0,3,1,270,263,0,1,266,271,0,260,10,2,3,10,271,1,0,0,257,10,256,260,0,271]

theorem envBound52637 : H12AffineFastState.Bounded env52637 := by
  intro p hp
  have h : env52637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52636_52637 : H12AffineEnvironment.transform 3 10 env52636 = env52637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env52636 == env52637) = true)

theorem identity52637 : scanCanonicalize (H12AffineFastState.compose env52637 (packedSelected [0,9] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound52637 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env52638 : List Nat := [2,4,8,10,11,10,9,14,1,5,0,0,3,1,0,9,0,1,4,1,0,10,10,2,3,10,1,1,0,0,15,10,14,10,0,1]

theorem envBound52638 : H12AffineFastState.Bounded env52638 := by
  intro p hp
  have h : env52638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52637_52638 : H12AffineEnvironment.transform 7 14 env52637 = env52638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env52637 == env52638) = true)

theorem identity52638 : scanCanonicalize (H12AffineFastState.compose env52638 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound52638 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52639 : List Nat := [2,3,8,10,11,10,9,9,1,2,0,0,3,1,0,9,0,1,3,1,0,10,10,2,3,10,1,1,0,0,8,10,9,10,0,1]

theorem envBound52639 : H12AffineFastState.Bounded env52639 := by
  intro p hp
  have h : env52639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52638_52639 : H12AffineEnvironment.transform 1 3 env52638 = env52639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env52638 == env52639) = true)

def env52640 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1344,262144,77934,32769,4096,46528,16,266385,70886,78895,77841,1296,74814,81226,365712,74799,256,308667,1345,79471]

theorem envBound52640 : H12AffineFastState.Bounded env52640 := by
  intro p hp
  have h : env52640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52621_52640 : H12AffineEnvironment.transform 13 1297 env52621 = env52640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env52621 == env52640) = true)

theorem identity52640 : scanCanonicalize (H12AffineFastState.compose env52640 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound52640 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env52641 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1344,262144,77934,13340,4096,477,16,266385,70886,78895,77841,1296,74814,81226,336013,74799,256,262566,1345,79471]

theorem envBound52641 : H12AffineFastState.Bounded env52641 := by
  intro p hp
  have h : env52641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52640_52641 : H12AffineEnvironment.transform 14 13341 env52640 = env52641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env52640 == env52641) = true)

def env52642 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1344,65664,77934,13340,4096,477,16,69649,70886,78895,77841,1296,74814,81226,8205,74799,256,65830,1345,79471]

theorem envBound52642 : H12AffineFastState.Bounded env52642 := by
  intro p hp
  have h : env52642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52641_52642 : H12AffineEnvironment.transform 17 65664 env52641 = env52642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env52641 == env52642) = true)

theorem identity52642 : scanCanonicalize (H12AffineFastState.compose env52642 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 359) := by decide +kernel

theorem selectedBound52642 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env52643 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,359,1344,487,12553,13340,4096,477,16,4470,5505,13640,12662,1296,9561,15405,8205,9544,256,65,1345,14088]

theorem envBound52643 : H12AffineFastState.Bounded env52643 := by
  intro p hp
  have h : env52643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52642_52643 : H12AffineEnvironment.transform 15 359 env52642 = env52643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 359 env52642 == env52643) = true)

def env52644 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,1297,13341,311,1296,439,12553,13340,4096,397,16,4390,5505,13592,12582,1296,9481,15405,8205,9496,256,17,1297,14088]

theorem envBound52644 : H12AffineFastState.Bounded env52644 := by
  intro p hp
  have h : env52644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52643_52644 : H12AffineEnvironment.transform 5 16 env52643 = env52644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52643 == env52644) = true)

theorem identity52644 : scanCanonicalize (H12AffineFastState.compose env52644 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound52644 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env52645 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,1297,5393,311,1296,439,4101,5392,4096,397,16,4390,5505,5140,4138,1296,1029,7457,257,1044,256,17,1297,5636]

theorem envBound52645 : H12AffineFastState.Bounded env52645 := by
  intro p hp
  have h : env52645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52644_52645 : H12AffineEnvironment.transform 12 268 env52644 = env52645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env52644 == env52645) = true)

theorem identity52645 : scanCanonicalize (H12AffineFastState.compose env52645 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound52645 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env52646 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,268,1297,0,311,1296,439,1300,1,1297,397,16,1079,144,261,1339,1296,1029,2096,257,1044,256,17,1297,789]

theorem envBound52646 : H12AffineFastState.Bounded env52646 := by
  intro p hp
  have h : env52646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52645_52646 : H12AffineEnvironment.transform 11 1297 env52645 = env52646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env52645 == env52646) = true)

theorem identity52646 : scanCanonicalize (H12AffineFastState.compose env52646 (packedSelected [0,1,2,3,5,7,8,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 428) := by decide +kernel

theorem selectedBound52646 : packedSelected [0,1,2,3,5,7,8,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env52647 : List Nat := [2,4,8,16,32,16,128,256,428,1024,2048,1297,268,1297,0,311,1296,439,1300,1,1297,397,16,1079,144,261,1339,1296,1029,2096,257,1044,256,17,1297,185]

theorem envBound52647 : H12AffineFastState.Bounded env52647 := by
  intro p hp
  have h : env52647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52646_52647 : H12AffineEnvironment.transform 8 428 env52646 = env52647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 428 env52646 == env52647) = true)

theorem identity52647 : scanCanonicalize (H12AffineFastState.compose env52647 (packedSelected [2,3,8,10,12,13,15,19] rootPS)) = affineNative (2^(10+1) ^^^ 1432) := by decide +kernel

theorem selectedBound52647 : packedSelected [2,3,8,10,12,13,15,19] rootPS < 2^1333 := by decide +kernel

def env52648 : List Nat := [2,4,8,16,32,16,128,256,428,1024,1432,1297,268,1297,0,311,1296,439,1300,1,1297,397,16,1079,144,261,1339,1296,1029,1448,257,1044,256,17,1297,185]

theorem envBound52648 : H12AffineFastState.Bounded env52648 := by
  intro p hp
  have h : env52648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52647_52648 : H12AffineEnvironment.transform 10 1432 env52647 = env52648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1432 env52647 == env52648) = true)

theorem identity52648 : scanCanonicalize (H12AffineFastState.compose env52648 (packedSelected [1,3,10,12] rootPS)) = affineNative (2^(9+1) ^^^ 315) := by decide +kernel

theorem selectedBound52648 : packedSelected [1,3,10,12] rootPS < 2^1333 := by decide +kernel

def env52649 : List Nat := [2,4,8,16,32,16,128,256,428,315,163,42,268,42,0,311,43,439,47,1,42,397,16,268,144,261,0,43,318,147,257,303,256,17,42,185]

theorem envBound52649 : H12AffineFastState.Bounded env52649 := by
  intro p hp
  have h : env52649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52648_52649 : H12AffineEnvironment.transform 9 315 env52648 = env52649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 315 env52648 == env52649) = true)

theorem identity52649 : scanCanonicalize (H12AffineFastState.compose env52649 (packedSelected [0,2,3,5,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound52649 : packedSelected [0,2,3,5,9,10] rootPS < 2^1333 := by decide +kernel

def env52650 : List Nat := [2,4,8,16,32,16,128,15,163,52,163,42,3,42,0,56,43,184,47,1,42,130,16,3,144,10,0,43,49,147,14,32,15,17,42,185]

theorem envBound52650 : H12AffineFastState.Bounded env52650 := by
  intro p hp
  have h : env52650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52649_52650 : H12AffineEnvironment.transform 7 15 env52649 = env52650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env52649 == env52650) = true)

def env52651 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1297,13341,310,1297,438,12553,13340,4096,396,16,4391,5505,13593,12583,1296,9480,15405,8205,9497,256,16,1296,14088]

theorem envBound52651 : H12AffineFastState.Bounded env52651 := by
  intro p hp
  have h : env52651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52643_52651 : H12AffineEnvironment.transform 5 17 env52643 = env52651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52643 == env52651) = true)

theorem identity52651 : scanCanonicalize (H12AffineFastState.compose env52651 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound52651 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env52652 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1029,8192,1297,8216,310,1297,438,9484,8217,1029,396,16,1314,388,8476,9506,1296,9480,10280,8205,9497,256,16,1296,8973]

theorem envBound52652 : H12AffineFastState.Bounded env52652 := by
  intro p hp
  have h : env52652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52651_52652 : H12AffineEnvironment.transform 11 1029 env52651 = env52652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env52651 == env52652) = true)

theorem identity52652 : scanCanonicalize (H12AffineFastState.compose env52652 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound52652 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env52653 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1029,25,1297,1,310,1297,438,1301,0,1029,396,16,1314,388,261,1339,1296,1297,2097,20,1280,256,16,1296,788]

theorem envBound52653 : H12AffineFastState.Bounded env52653 := by
  intro p hp
  have h : env52653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52652_52653 : H12AffineEnvironment.transform 12 25 env52652 = env52653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env52652 == env52653) = true)

theorem identity52653 : scanCanonicalize (H12AffineFastState.compose env52653 (packedSelected [0,1,2,5,7,10,11,19] rootPS)) = affineNative (2^(10+1) ^^^ 1809) := by decide +kernel

theorem selectedBound52653 : packedSelected [0,1,2,5,7,10,11,19] rootPS < 2^1333 := by decide +kernel

def env52654 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1809,1029,25,1297,1,310,1297,438,1301,0,1029,396,16,1314,388,261,1339,1296,1297,1824,20,1280,256,16,1296,788]

theorem envBound52654 : H12AffineFastState.Bounded env52654 := by
  intro p hp
  have h : env52654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52653_52654 : H12AffineEnvironment.transform 10 1809 env52653 = env52654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1809 env52653 == env52654) = true)

theorem identity52654 : scanCanonicalize (H12AffineFastState.compose env52654 (packedSelected [0,3,5,7,13,18] rootPS)) = affineNative (2^(9+1) ^^^ 266) := by decide +kernel

theorem selectedBound52654 : packedSelected [0,3,5,7,13,18] rootPS < 2^1333 := by decide +kernel

def env52655 : List Nat := [2,4,8,16,32,17,128,256,512,266,539,271,25,27,1,310,27,438,31,0,271,396,16,40,388,261,49,26,27,554,20,10,256,16,26,788]

theorem envBound52655 : H12AffineFastState.Bounded env52655 := by
  intro p hp
  have h : env52655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52654_52655 : H12AffineEnvironment.transform 9 266 env52654 = env52655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 266 env52654 == env52655) = true)

theorem identity52655 : scanCanonicalize (H12AffineFastState.compose env52655 (packedSelected [1,3,13] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound52655 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env52656 : List Nat := [2,4,8,11,32,10,128,256,512,266,512,271,2,0,1,301,0,429,4,0,271,396,11,40,388,261,42,1,0,554,15,10,256,11,1,783]

theorem envBound52656 : H12AffineFastState.Bounded env52656 := by
  intro p hp
  have h : env52656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52655_52656 : H12AffineEnvironment.transform 3 11 env52655 = env52656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env52655 == env52656) = true)

theorem identity52656 : scanCanonicalize (H12AffineFastState.compose env52656 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound52656 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env52657 : List Nat := [2,4,8,11,32,10,128,37,512,47,512,42,2,0,1,8,0,136,4,0,42,169,11,40,161,32,42,1,0,554,15,10,37,11,1,554]

theorem envBound52657 : H12AffineFastState.Bounded env52657 := by
  intro p hp
  have h : env52657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52656_52657 : H12AffineEnvironment.transform 7 37 env52656 = env52657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env52656 == env52657) = true)

theorem identity52657 : scanCanonicalize (H12AffineFastState.compose env52657 (packedSelected [1,5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound52657 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env52658 : List Nat := [2,4,8,11,32,10,9,37,512,47,512,42,2,0,1,8,0,1,4,0,42,32,11,40,40,32,42,1,0,554,15,10,37,11,1,554]

theorem envBound52658 : H12AffineFastState.Bounded env52658 := by
  intro p hp
  have h : env52658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52657_52658 : H12AffineEnvironment.transform 6 9 env52657 = env52658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env52657 == env52658) = true)

theorem identity52658 : scanCanonicalize (H12AffineFastState.compose env52658 (packedSelected [1,2] rootPS)) = affineNative (2^(8+1) ^^^ 44) := by decide +kernel

theorem selectedBound52658 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env52659 : List Nat := [2,4,8,11,32,10,9,37,44,47,44,42,2,0,1,8,0,1,4,0,42,32,11,40,40,32,42,1,0,6,15,10,37,11,1,6]

theorem envBound52659 : H12AffineFastState.Bounded env52659 := by
  intro p hp
  have h : env52659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52658_52659 : H12AffineEnvironment.transform 8 44 env52658 = env52659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 44 env52658 == env52659) = true)

theorem identity52659 : scanCanonicalize (H12AffineFastState.compose env52659 (packedSelected [1,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound52659 : packedSelected [1,4,7] rootPS < 2^1333 := by decide +kernel

def env52660 : List Nat := [2,4,8,11,11,10,9,14,7,4,7,1,2,0,1,8,0,1,4,0,1,11,11,3,3,11,1,1,0,6,15,10,14,11,1,6]

theorem envBound52660 : H12AffineFastState.Bounded env52660 := by
  intro p hp
  have h : env52660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52659_52660 : H12AffineEnvironment.transform 4 11 env52659 = env52660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env52659 == env52660) = true)

theorem identity52660 : scanCanonicalize (H12AffineFastState.compose env52660 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound52660 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52661 : List Nat := [2,4,1,2,2,3,0,7,7,4,7,1,2,0,1,1,0,1,4,0,1,2,2,3,3,2,1,1,0,6,6,3,7,2,1,6]

theorem envBound52661 : H12AffineFastState.Bounded env52661 := by
  intro p hp
  have h : env52661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52660_52661 : H12AffineEnvironment.transform 2 1 env52660 = env52661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env52660 == env52661) = true)

theorem identity52661 : scanCanonicalize (H12AffineFastState.compose env52661 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound52661 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52662 : List Nat := [2,3,1,2,2,3,0,0,0,3,0,1,2,0,1,1,0,1,3,0,1,2,2,3,3,2,1,1,0,1,1,3,0,2,1,1]

theorem envBound52662 : H12AffineFastState.Bounded env52662 := by
  intro p hp
  have h : env52662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52661_52662 : H12AffineEnvironment.transform 1 3 env52661 = env52662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env52661 == env52662) = true)

theorem identity52662 : scanCanonicalize (H12AffineFastState.compose env52662 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound52662 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env52663 : List Nat := [0,1,1,0,0,1,0,0,0,1,0,1,0,0,1,1,0,1,1,0,1,0,0,1,1,0,1,1,0,1,1,1,0,0,1,1]

theorem envBound52663 : H12AffineFastState.Bounded env52663 := by
  intro p hp
  have h : env52663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52662_52663 : H12AffineEnvironment.transform 0 0 env52662 = env52663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env52662 == env52663) = true)

def env52664 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1344,65665,77934,13340,4096,477,16,69648,70886,78895,77841,1296,74814,81226,8204,74799,256,65831,1345,79471]

theorem envBound52664 : H12AffineFastState.Bounded env52664 := by
  intro p hp
  have h : env52664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52641_52664 : H12AffineEnvironment.transform 17 65665 env52641 = env52664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env52641 == env52664) = true)

theorem identity52664 : scanCanonicalize (H12AffineFastState.compose env52664 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5159) := by decide +kernel

theorem selectedBound52664 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env52665 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,5159,1344,5286,9289,13340,4096,477,16,1079,193,8200,9270,1296,12313,10605,8204,12296,256,5376,1345,8776]

theorem envBound52665 : H12AffineFastState.Bounded env52665 := by
  intro p hp
  have h : env52665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52664_52665 : H12AffineEnvironment.transform 15 5159 env52664 = env52665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5159 env52664 == env52665) = true)

def env52666 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,1297,13341,5159,1296,5286,9241,13340,4096,397,16,1079,145,8200,9270,1296,12313,10557,8204,12296,256,5376,1297,8728]

theorem envBound52666 : H12AffineFastState.Bounded env52666 := by
  intro p hp
  have h : env52666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52665_52666 : H12AffineEnvironment.transform 5 16 env52665 = env52666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52665 == env52666) = true)

theorem identity52666 : scanCanonicalize (H12AffineFastState.compose env52666 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound52666 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env52667 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,1297,5392,5159,1296,5286,1300,5393,4096,397,16,1079,145,261,1339,1296,4372,2096,257,4357,256,5376,1297,789]

theorem envBound52667 : H12AffineFastState.Bounded env52667 := by
  intro p hp
  have h : env52667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52666_52667 : H12AffineEnvironment.transform 12 269 env52666 = env52667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env52666 == env52667) = true)

theorem identity52667 : scanCanonicalize (H12AffineFastState.compose env52667 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound52667 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env52668 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1028,269,1297,276,35,1296,162,1300,277,1028,397,16,1079,145,261,1339,1296,1296,2096,257,1281,256,260,1297,789]

theorem envBound52668 : H12AffineFastState.Bounded env52668 := by
  intro p hp
  have h : env52668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52667_52668 : H12AffineEnvironment.transform 11 1028 env52667 = env52668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env52667 == env52668) = true)

theorem identity52668 : scanCanonicalize (H12AffineFastState.compose env52668 (packedSelected [0,1,2,5,7,10,11,19] rootPS)) = affineNative (2^(10+1) ^^^ 276) := by decide +kernel

theorem selectedBound52668 : packedSelected [0,1,2,5,7,10,11,19] rootPS < 2^1333 := by decide +kernel

def env52669 : List Nat := [2,4,8,16,32,16,128,256,512,1024,276,1028,269,1297,276,35,1296,162,1300,277,1028,397,16,1079,145,261,1339,1296,1296,292,257,1281,256,260,1297,789]

theorem envBound52669 : H12AffineFastState.Bounded env52669 := by
  intro p hp
  have h : env52669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52668_52669 : H12AffineEnvironment.transform 10 276 env52668 = env52669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 276 env52668 == env52669) = true)

theorem identity52669 : scanCanonicalize (H12AffineFastState.compose env52669 (packedSelected [1,2,8,10,15] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound52669 : packedSelected [1,2,8,10,15] rootPS < 2^1333 := by decide +kernel

def env52670 : List Nat := [2,4,8,16,32,16,128,256,276,1024,276,1028,269,1297,276,35,1296,162,1300,277,1028,397,16,1079,145,261,1339,1296,1296,292,257,1281,256,260,1297,1]

theorem envBound52670 : H12AffineFastState.Bounded env52670 := by
  intro p hp
  have h : env52670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52669_52670 : H12AffineEnvironment.transform 8 276 env52669 = env52670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env52669 == env52670) = true)

theorem identity52670 : scanCanonicalize (H12AffineFastState.compose env52670 (packedSelected [0,2,3,7,8,10,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 141) := by decide +kernel

theorem selectedBound52670 : packedSelected [0,2,3,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env52671 : List Nat := [2,4,8,16,32,16,128,256,276,141,276,137,269,412,276,35,413,162,409,277,137,397,16,186,145,261,438,413,413,292,257,396,256,260,412,1]

theorem envBound52671 : H12AffineFastState.Bounded env52671 := by
  intro p hp
  have h : env52671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52670_52671 : H12AffineEnvironment.transform 9 141 env52670 = env52671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 141 env52670 == env52671) = true)

theorem identity52671 : scanCanonicalize (H12AffineFastState.compose env52671 (packedSelected [0,2,3,4,8,10] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound52671 : packedSelected [0,2,3,4,8,10] rootPS < 2^1333 := by decide +kernel

def env52672 : List Nat := [2,4,8,16,16,16,128,256,276,141,276,137,269,412,276,19,413,146,409,277,137,397,16,138,145,261,390,413,413,276,257,396,256,260,412,1]

theorem envBound52672 : H12AffineFastState.Bounded env52672 := by
  intro p hp
  have h : env52672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52671_52672 : H12AffineEnvironment.transform 4 16 env52671 = env52672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env52671 == env52672) = true)

theorem identity52672 : scanCanonicalize (H12AffineFastState.compose env52672 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound52672 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52673 : List Nat := [2,4,8,16,16,16,9,256,276,4,276,0,269,277,276,19,276,27,272,277,0,260,16,3,24,261,271,276,276,276,257,261,256,260,277,1]

theorem envBound52673 : H12AffineFastState.Bounded env52673 := by
  intro p hp
  have h : env52673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52672_52673 : H12AffineEnvironment.transform 6 9 env52672 = env52673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env52672 == env52673) = true)

theorem identity52673 : scanCanonicalize (H12AffineFastState.compose env52673 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 8) := by decide +kernel

theorem selectedBound52673 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52674 : List Nat := [2,4,8,16,16,16,9,8,28,4,28,0,5,29,28,19,28,27,24,29,0,12,16,3,24,13,7,28,28,28,9,13,8,12,29,1]

theorem envBound52674 : H12AffineFastState.Bounded env52674 := by
  intro p hp
  have h : env52674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52673_52674 : H12AffineEnvironment.transform 7 8 env52673 = env52674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 8 env52673 == env52674) = true)

theorem identity52674 : scanCanonicalize (H12AffineFastState.compose env52674 (packedSelected [8] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound52674 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env52675 : List Nat := [2,4,8,10,10,10,9,8,6,4,6,0,5,7,6,9,6,1,2,7,0,12,10,3,2,13,7,6,6,6,9,13,8,12,7,1]

theorem envBound52675 : H12AffineFastState.Bounded env52675 := by
  intro p hp
  have h : env52675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52674_52675 : H12AffineEnvironment.transform 3 10 env52674 = env52675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env52674 == env52675) = true)

def env52676 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,1297,13341,5159,1297,5286,9240,13340,4096,396,16,1079,144,8200,9270,1296,12313,10556,8204,12296,256,5376,1296,8729]

theorem envBound52676 : H12AffineFastState.Bounded env52676 := by
  intro p hp
  have h : env52676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52665_52676 : H12AffineEnvironment.transform 5 17 env52665 = env52676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52665 == env52676) = true)

theorem identity52676 : scanCanonicalize (H12AffineFastState.compose env52676 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound52676 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env52677 : List Nat := [2,4,8,16,32,17,128,21,512,1024,2048,4096,8192,1028,13341,5159,1028,5286,9240,13340,4096,153,16,1079,144,8200,9270,1029,12313,10281,8204,12296,21,5141,1029,8729]

theorem envBound52677 : H12AffineFastState.Bounded env52677 := by
  intro p hp
  have h : env52677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52676_52677 : H12AffineEnvironment.transform 7 21 env52676 = env52677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env52676 == env52677) = true)

theorem identity52677 : scanCanonicalize (H12AffineFastState.compose env52677 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound52677 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env52678 : List Nat := [2,4,8,16,32,17,128,21,512,1024,2048,1028,8192,1028,8217,35,1028,162,9240,8216,1028,153,16,1079,144,8200,9270,1029,9245,10281,8204,9228,21,17,1029,8729]

theorem envBound52678 : H12AffineFastState.Bounded env52678 := by
  intro p hp
  have h : env52678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52677_52678 : H12AffineEnvironment.transform 11 1028 env52677 = env52678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env52677 == env52678) = true)

theorem identity52678 : scanCanonicalize (H12AffineFastState.compose env52678 (packedSelected [0,1,3,5,7,8,11,12,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 2099) := by decide +kernel

theorem selectedBound52678 : packedSelected [0,1,3,5,7,8,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env52679 : List Nat := [2,4,8,16,32,17,128,21,512,1024,2048,1028,2099,1028,2090,35,1028,162,3115,2091,1028,153,16,1079,144,2107,3077,1029,3118,26,2111,3135,21,17,1029,2602]

theorem envBound52679 : H12AffineFastState.Bounded env52679 := by
  intro p hp
  have h : env52679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52678_52679 : H12AffineEnvironment.transform 12 2099 env52678 = env52679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2099 env52678 == env52679) = true)

def env52680 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,95615,32769,4096,61649,147521,284033,86519,209263,225345,148801,74814,96347,381312,205167,256,456171,1345,95102]

theorem envBound52680 : H12AffineFastState.Bounded env52680 := by
  intro p hp
  have h : env52680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52555_52680 : H12AffineEnvironment.transform 23 284033 env52555 = env52680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 284033 env52555 == env52680) = true)

def env52681 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16464,262144,95615,32769,4096,61649,17,284033,86519,94527,77841,1297,74814,96347,381312,90431,256,308667,1345,95102]

theorem envBound52681 : H12AffineFastState.Bounded env52681 := by
  intro p hp
  have h : env52681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52680_52681 : H12AffineEnvironment.transform 16 16464 env52680 = env52681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16464 env52680 == env52681) = true)

def env52682 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1344,262144,77935,32769,4096,46529,17,266385,70887,78895,77841,1297,74814,81227,365712,74799,256,308667,1345,79470]

theorem envBound52682 : H12AffineFastState.Bounded env52682 := by
  intro p hp
  have h : env52682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52681_52682 : H12AffineEnvironment.transform 13 1296 env52681 = env52682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env52681 == env52682) = true)

theorem identity52682 : scanCanonicalize (H12AffineFastState.compose env52682 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound52682 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env52683 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1344,262144,77935,13340,4096,476,17,266385,70887,78895,77841,1297,74814,81227,336013,74799,256,262566,1345,79470]

theorem envBound52683 : H12AffineFastState.Bounded env52683 := by
  intro p hp
  have h : env52683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52682_52683 : H12AffineEnvironment.transform 14 13341 env52682 = env52683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env52682 == env52683) = true)

def env52684 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1344,65664,77935,13340,4096,476,17,69649,70887,78895,77841,1297,74814,81227,8205,74799,256,65830,1345,79470]

theorem envBound52684 : H12AffineFastState.Bounded env52684 := by
  intro p hp
  have h : env52684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52683_52684 : H12AffineEnvironment.transform 17 65664 env52683 = env52684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env52683 == env52684) = true)

theorem identity52684 : scanCanonicalize (H12AffineFastState.compose env52684 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound52684 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env52685 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1296,9244,65536,1344,65664,73838,9245,1,476,17,65552,66790,74798,73744,1297,74814,77130,8205,74799,256,65830,1345,75375]

theorem envBound52685 : H12AffineFastState.Bounded env52685 := by
  intro p hp
  have h : env52685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52684_52685 : H12AffineEnvironment.transform 11 1 env52684 = env52685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env52684 == env52685) = true)

def env52686 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1,8192,1296,9244,65536,1296,65664,73790,9245,1,396,17,65552,66742,74798,73744,1297,74814,77082,8205,74799,256,65830,1297,75327]

theorem envBound52686 : H12AffineFastState.Bounded env52686 := by
  intro p hp
  have h : env52686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52685_52686 : H12AffineEnvironment.transform 5 16 env52685 = env52686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52685 == env52686) = true)

theorem identity52686 : scanCanonicalize (H12AffineFastState.compose env52686 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 1331) := by decide +kernel

theorem selectedBound52686 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env52687 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1,8192,1296,9244,1331,1296,1459,9485,9245,1,396,17,1315,389,8477,9507,1297,8461,10281,8205,8476,256,1045,1297,8972]

theorem envBound52687 : H12AffineFastState.Bounded env52687 := by
  intro p hp
  have h : env52687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52686_52687 : H12AffineEnvironment.transform 15 1331 env52686 = env52687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1331 env52686 == env52687) = true)

theorem identity52687 : scanCanonicalize (H12AffineFastState.compose env52687 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound52687 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env52688 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1,1053,1296,1,1331,1296,1459,272,0,1,396,17,1315,389,1280,318,1297,1296,3124,1040,1281,256,1045,1297,1809]

theorem envBound52688 : H12AffineFastState.Bounded env52688 := by
  intro p hp
  have h : env52688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52687_52688 : H12AffineEnvironment.transform 12 1053 env52687 = env52688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env52687 == env52688) = true)

theorem identity52688 : scanCanonicalize (H12AffineFastState.compose env52688 (packedSelected [0,2,3,7,8,11,12,15,17] rootPS)) = affineNative (2^(9+1) ^^^ 315) := by decide +kernel

theorem selectedBound52688 : packedSelected [0,2,3,7,8,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env52689 : List Nat := [2,4,8,16,32,16,128,256,512,315,2048,1,294,43,1,8,43,136,272,0,1,396,17,24,389,59,318,42,43,2319,299,58,256,302,42,554]

theorem envBound52689 : H12AffineFastState.Bounded env52689 := by
  intro p hp
  have h : env52689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52688_52689 : H12AffineEnvironment.transform 9 315 env52688 = env52689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 315 env52688 == env52689) = true)

theorem identity52689 : scanCanonicalize (H12AffineFastState.compose env52689 (packedSelected [1,3,10,11,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound52689 : packedSelected [1,3,10,11,15,18] rootPS < 2^1333 := by decide +kernel

def env52690 : List Nat := [2,4,8,16,32,16,128,256,1,315,2048,1,294,43,1,8,43,136,272,0,1,396,17,24,389,59,318,42,43,2319,299,58,256,302,42,43]

theorem envBound52690 : H12AffineFastState.Bounded env52690 := by
  intro p hp
  have h : env52690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52689_52690 : H12AffineEnvironment.transform 8 1 env52689 = env52690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env52689 == env52690) = true)

theorem identity52690 : scanCanonicalize (H12AffineFastState.compose env52690 (packedSelected [0,1,3,5,7,8,10,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound52690 : packedSelected [0,1,3,5,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env52691 : List Nat := [2,4,8,16,32,16,128,256,1,315,1,1,294,43,1,8,43,136,272,0,1,396,17,24,389,59,318,42,43,270,299,58,256,302,42,43]

theorem envBound52691 : H12AffineFastState.Bounded env52691 := by
  intro p hp
  have h : env52691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52690_52691 : H12AffineEnvironment.transform 10 1 env52690 = env52691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env52690 == env52691) = true)

theorem identity52691 : scanCanonicalize (H12AffineFastState.compose env52691 (packedSelected [1,2,5,10,11] rootPS)) = affineNative (2^(7+1) ^^^ 134) := by decide +kernel

theorem selectedBound52691 : packedSelected [1,2,5,10,11] rootPS < 2^1333 := by decide +kernel

def env52692 : List Nat := [2,4,8,16,32,16,128,134,1,189,1,1,160,43,1,8,43,136,150,0,1,10,17,24,3,59,184,42,43,136,173,58,134,168,42,43]

theorem envBound52692 : H12AffineFastState.Bounded env52692 := by
  intro p hp
  have h : env52692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52691_52692 : H12AffineEnvironment.transform 7 134 env52691 = env52692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 134 env52691 == env52692) = true)

theorem identity52692 : scanCanonicalize (H12AffineFastState.compose env52692 (packedSelected [3,8] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound52692 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env52693 : List Nat := [2,4,8,16,32,16,56,62,1,5,1,1,24,43,1,8,43,48,46,0,1,10,17,24,3,59,0,42,43,48,21,58,62,16,42,43]

theorem envBound52693 : H12AffineFastState.Bounded env52693 := by
  intro p hp
  have h : env52693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52692_52693 : H12AffineEnvironment.transform 6 56 env52692 = env52693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env52692 == env52693) = true)

theorem identity52693 : scanCanonicalize (H12AffineFastState.compose env52693 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound52693 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env52694 : List Nat := [2,4,8,10,32,10,34,36,1,5,1,1,2,43,1,8,43,42,46,0,1,10,11,2,3,33,0,42,43,42,15,32,36,10,42,43]

theorem envBound52694 : H12AffineFastState.Bounded env52694 := by
  intro p hp
  have h : env52694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52693_52694 : H12AffineEnvironment.transform 3 10 env52693 = env52694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env52693 == env52694) = true)

def env52695 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1,8192,1296,9244,65536,1297,65664,73791,9245,1,397,17,65552,66743,74798,73744,1297,74814,77083,8205,74799,256,65830,1296,75326]

theorem envBound52695 : H12AffineFastState.Bounded env52695 := by
  intro p hp
  have h : env52695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52685_52695 : H12AffineEnvironment.transform 5 17 env52685 = env52695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52685 == env52695) = true)

theorem identity52695 : scanCanonicalize (H12AffineFastState.compose env52695 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound52695 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env52696 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1,269,1296,1297,65536,1297,65664,65842,1296,1,397,17,65552,66743,66851,65821,1297,66867,68630,256,66850,256,65830,1296,67379]

theorem envBound52696 : H12AffineFastState.Bounded env52696 := by
  intro p hp
  have h : env52696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52695_52696 : H12AffineEnvironment.transform 12 269 env52695 = env52696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env52695 == env52696) = true)

theorem identity52696 : scanCanonicalize (H12AffineFastState.compose env52696 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound52696 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env52697 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,269,1,0,65536,0,65664,65842,1,1,397,17,65552,65958,65586,65821,0,65570,67847,256,65587,256,65830,1,66082]

theorem envBound52697 : H12AffineFastState.Bounded env52697 := by
  intro p hp
  have h : env52697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52696_52697 : H12AffineEnvironment.transform 9 273 env52696 = env52697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env52696 == env52697) = true)

theorem identity52697 : scanCanonicalize (H12AffineFastState.compose env52697 (packedSelected [0,1,3,5,7,8,11,12,15,17] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound52697 : packedSelected [0,1,3,5,7,8,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env52698 : List Nat := [2,4,8,16,32,17,128,15,512,30,2048,1,2,1,0,65536,0,65664,65597,1,1,130,17,65552,65705,65586,65554,0,65570,67592,15,65587,15,65577,1,66082]

theorem envBound52698 : H12AffineFastState.Bounded env52698 := by
  intro p hp
  have h : env52698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52697_52698 : H12AffineEnvironment.transform 7 15 env52697 = env52698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env52697 == env52698) = true)

theorem identity52698 : scanCanonicalize (H12AffineFastState.compose env52698 (packedSelected [2,3,5,10,11,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 184) := by decide +kernel

theorem selectedBound52698 : packedSelected [2,3,5,10,11,13,15,18] rootPS < 2^1333 := by decide +kernel

def env52699 : List Nat := [2,4,8,16,32,17,128,15,184,30,2048,1,2,1,0,65536,0,65664,65597,1,1,130,17,65552,65705,65586,65554,0,65570,67592,15,65587,15,65577,1,65690]

theorem envBound52699 : H12AffineFastState.Bounded env52699 := by
  intro p hp
  have h : env52699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52698_52699 : H12AffineEnvironment.transform 8 184 env52698 = env52699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 184 env52698 == env52699) = true)

theorem identity52699 : scanCanonicalize (H12AffineFastState.compose env52699 (packedSelected [0,1,3,5,7,8,10,11,12,13] rootPS)) = affineNative (2^(15+1) ^^^ 56) := by decide +kernel

theorem selectedBound52699 : packedSelected [0,1,3,5,7,8,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env52700 : List Nat := [2,4,8,16,32,17,128,15,184,30,2048,1,2,1,0,56,0,184,5,1,1,130,17,40,145,10,42,0,26,2096,15,11,15,17,1,162]

theorem envBound52700 : H12AffineFastState.Bounded env52700 := by
  intro p hp
  have h : env52700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52699_52700 : H12AffineEnvironment.transform 15 56 env52699 = env52700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 56 env52699 == env52700) = true)

theorem identity52700 : scanCanonicalize (H12AffineFastState.compose env52700 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound52700 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env52701 : List Nat := [2,4,8,16,32,17,57,15,1,30,2048,1,2,1,0,56,0,1,5,1,1,59,17,40,40,10,42,0,26,2096,15,11,15,17,1,27]

theorem envBound52701 : H12AffineFastState.Bounded env52701 := by
  intro p hp
  have h : env52701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52700_52701 : H12AffineEnvironment.transform 6 57 env52700 = env52701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env52700 == env52701) = true)

theorem identity52701 : scanCanonicalize (H12AffineFastState.compose env52701 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound52701 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env52702 : List Nat := [2,4,8,16,32,17,57,15,1,30,49,1,2,1,0,56,0,1,5,1,1,59,17,40,40,10,42,0,26,1,15,11,15,17,1,27]

theorem envBound52702 : H12AffineFastState.Bounded env52702 := by
  intro p hp
  have h : env52702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52701_52702 : H12AffineEnvironment.transform 10 49 env52701 = env52702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env52701 == env52702) = true)

theorem identity52702 : scanCanonicalize (H12AffineFastState.compose env52702 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound52702 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52703 : List Nat := [2,4,8,16,16,17,9,15,1,30,1,1,2,1,0,8,0,1,5,1,1,11,17,24,24,10,26,0,26,1,15,11,15,17,1,27]

theorem envBound52703 : H12AffineFastState.Bounded env52703 := by
  intro p hp
  have h : env52703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52702_52703 : H12AffineEnvironment.transform 4 16 env52702 = env52703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env52702 == env52703) = true)

theorem identity52703 : scanCanonicalize (H12AffineFastState.compose env52703 (packedSelected [0,1,4] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound52703 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env52704 : List Nat := [2,4,5,16,16,17,4,2,1,19,1,1,2,1,0,5,0,1,5,1,1,6,17,21,21,7,23,0,23,1,2,6,2,17,1,22]

theorem envBound52704 : H12AffineFastState.Bounded env52704 := by
  intro p hp
  have h : env52704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52703_52704 : H12AffineEnvironment.transform 2 5 env52703 = env52704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env52703 == env52704) = true)

theorem identity52704 : scanCanonicalize (H12AffineFastState.compose env52704 (packedSelected [0,1,7] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound52704 : packedSelected [0,1,7] rootPS < 2^1333 := by decide +kernel

def env52705 : List Nat := [2,4,5,6,6,7,4,2,1,5,1,1,2,1,0,5,0,1,5,1,1,6,7,3,3,7,1,0,1,1,2,6,2,7,1,0]

theorem envBound52705 : H12AffineFastState.Bounded env52705 := by
  intro p hp
  have h : env52705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52704_52705 : H12AffineEnvironment.transform 3 6 env52704 = env52705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env52704 == env52705) = true)

theorem identity52705 : scanCanonicalize (H12AffineFastState.compose env52705 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound52705 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52706 : List Nat := [0,4,5,4,4,5,4,0,1,5,1,1,0,1,0,5,0,1,5,1,1,4,5,1,1,5,1,0,1,1,0,4,0,5,1,0]

theorem envBound52706 : H12AffineFastState.Bounded env52706 := by
  intro p hp
  have h : env52706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52705_52706 : H12AffineEnvironment.transform 0 0 env52705 = env52706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env52705 == env52706) = true)

theorem identity52706 : scanCanonicalize (H12AffineFastState.compose env52706 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound52706 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52707 : List Nat := [0,1,0,1,1,0,1,0,1,0,1,1,0,1,0,0,0,1,0,1,1,1,0,1,1,0,1,0,1,1,0,1,0,0,1,0]

theorem envBound52707 : H12AffineFastState.Bounded env52707 := by
  intro p hp
  have h : env52707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52706_52707 : H12AffineEnvironment.transform 1 1 env52706 = env52707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env52706 == env52707) = true)

def env52708 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,1344,65665,77935,13340,4096,476,17,69648,70887,78895,77841,1297,74814,81227,8204,74799,256,65831,1345,79470]

theorem envBound52708 : H12AffineFastState.Bounded env52708 := by
  intro p hp
  have h : env52708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52683_52708 : H12AffineEnvironment.transform 17 65665 env52683 = env52708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env52683 == env52708) = true)

theorem identity52708 : scanCanonicalize (H12AffineFastState.compose env52708 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound52708 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env52709 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,81,12636,65536,1,65665,77935,12637,4096,476,17,69648,70054,78190,77841,80,74111,79882,8204,74094,256,65831,0,78639]

theorem envBound52709 : H12AffineFastState.Bounded env52709 := by
  intro p hp
  have h : env52709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52708_52709 : H12AffineEnvironment.transform 9 321 env52708 = env52709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env52708 == env52709) = true)

def env52710 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,4096,8192,1,12556,65536,1,65665,77887,12557,4096,396,17,69648,70054,78142,77841,0,74031,79882,8204,74046,256,65831,0,78639]

theorem envBound52710 : H12AffineFastState.Bounded env52710 := by
  intro p hp
  have h : env52710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52709_52710 : H12AffineEnvironment.transform 5 16 env52709 = env52710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52709 == env52710) = true)

theorem identity52710 : scanCanonicalize (H12AffineFastState.compose env52710 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 4130) := by decide +kernel

theorem selectedBound52710 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env52711 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,4096,8192,1,12556,4130,1,4259,8221,12557,4096,396,17,50,388,8476,8243,0,12557,10280,8204,12572,256,4357,0,8973]

theorem envBound52711 : H12AffineFastState.Bounded env52711 := by
  intro p hp
  have h : env52711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52710_52711 : H12AffineEnvironment.transform 15 4130 env52710 = env52711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4130 env52710 == env52711) = true)

theorem identity52711 : scanCanonicalize (H12AffineFastState.compose env52711 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound52711 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env52712 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,8192,1,8461,35,1,162,8221,8460,1,396,17,50,388,8476,8243,0,8460,10280,8204,8477,256,260,0,8973]

theorem envBound52712 : H12AffineFastState.Bounded env52712 := by
  intro p hp
  have h : env52712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52711_52712 : H12AffineEnvironment.transform 11 1 env52711 = env52712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env52711 == env52712) = true)

theorem identity52712 : scanCanonicalize (H12AffineFastState.compose env52712 (packedSelected [0,2,7,10,12,15,17,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 2948) := by decide +kernel

theorem selectedBound52712 : packedSelected [0,2,7,10,12,15,17,18,19] rootPS < 2^1333 := by decide +kernel

def env52713 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,2948,1,2697,35,1,162,2969,2696,1,396,17,50,388,2712,2999,0,2696,940,2952,2713,256,260,0,2185]

theorem envBound52713 : H12AffineFastState.Bounded env52713 := by
  intro p hp
  have h : env52713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52712_52713 : H12AffineEnvironment.transform 12 2948 env52712 = env52713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2948 env52712 == env52713) = true)

theorem identity52713 : scanCanonicalize (H12AffineFastState.compose env52713 (packedSelected [3,5,17] rootPS)) = affineNative (2^(10+1) ^^^ 146) := by decide +kernel

theorem selectedBound52713 : packedSelected [3,5,17] rootPS < 2^1333 := by decide +kernel

def env52714 : List Nat := [2,4,8,16,32,16,128,256,512,273,146,1,790,1,539,35,1,162,779,538,1,396,17,50,388,522,805,0,538,940,794,523,256,260,0,27]

theorem envBound52714 : H12AffineFastState.Bounded env52714 := by
  intro p hp
  have h : env52714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52713_52714 : H12AffineEnvironment.transform 10 146 env52713 = env52714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 146 env52713 == env52714) = true)

theorem identity52714 : scanCanonicalize (H12AffineFastState.compose env52714 (packedSelected [0,4,7,9,10,13] rootPS)) = affineNative (2^(8+1) ^^^ 162) := by decide +kernel

theorem selectedBound52714 : packedSelected [0,4,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env52715 : List Nat := [2,4,8,16,32,16,128,256,162,273,146,1,436,1,185,35,1,162,425,184,1,396,17,50,388,168,391,0,184,270,440,169,256,260,0,27]

theorem envBound52715 : H12AffineFastState.Bounded env52715 := by
  intro p hp
  have h : env52715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52714_52715 : H12AffineEnvironment.transform 8 162 env52714 = env52715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 162 env52714 == env52715) = true)

def env52716 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,4096,8192,0,12557,65536,1,65665,77886,12556,4096,397,17,69648,70054,78143,77841,1,74030,79882,8204,74047,256,65831,0,78639]

theorem envBound52716 : H12AffineFastState.Bounded env52716 := by
  intro p hp
  have h : env52716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52709_52716 : H12AffineEnvironment.transform 5 17 env52709 = env52716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52709 == env52716) = true)

theorem identity52716 : scanCanonicalize (H12AffineFastState.compose env52716 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound52716 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env52717 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,4096,268,0,4097,65536,1,65665,69938,4096,4096,397,17,69648,70054,69683,69917,1,65570,71942,256,65587,256,65831,0,70179]

theorem envBound52717 : H12AffineFastState.Bounded env52717 := by
  intro p hp
  have h : env52717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52716_52717 : H12AffineEnvironment.transform 12 268 env52716 = env52717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env52716 == env52717) = true)

theorem identity52717 : scanCanonicalize (H12AffineFastState.compose env52717 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound52717 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env52718 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,4096,268,0,4097,35,1,162,4369,4096,4096,397,17,4147,4485,4112,4414,1,1,6437,256,16,256,260,0,4608]

theorem envBound52718 : H12AffineFastState.Bounded env52718 := by
  intro p hp
  have h : env52718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52717_52718 : H12AffineEnvironment.transform 15 35 env52717 = env52718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env52717 == env52718) = true)

theorem identity52718 : scanCanonicalize (H12AffineFastState.compose env52718 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 2707) := by decide +kernel

theorem selectedBound52718 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env52719 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,2707,268,0,2706,35,1,162,2946,2707,2707,397,17,2720,2838,2691,2989,1,1,950,256,16,256,260,0,2195]

theorem envBound52719 : H12AffineFastState.Bounded env52719 := by
  intro p hp
  have h : env52719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52718_52719 : H12AffineEnvironment.transform 11 2707 env52718 = env52719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2707 env52718 == env52719) = true)

theorem identity52719 : scanCanonicalize (H12AffineFastState.compose env52719 (packedSelected [0,1,5,7,11,12,15,17] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound52719 : packedSelected [0,1,5,7,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env52720 : List Nat := [2,4,8,16,32,17,128,256,42,272,2048,2233,268,0,2232,35,1,162,2472,2233,2233,397,17,2186,2364,2217,2439,1,1,412,256,16,256,260,0,2195]

theorem envBound52720 : H12AffineFastState.Bounded env52720 := by
  intro p hp
  have h : env52720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52719_52720 : H12AffineEnvironment.transform 8 42 env52719 = env52720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env52719 == env52720) = true)

theorem identity52720 : scanCanonicalize (H12AffineFastState.compose env52720 (packedSelected [0,3,5,7,12,15,18] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound52720 : packedSelected [0,3,5,7,12,15,18] rootPS < 2^1333 := by decide +kernel

def env52721 : List Nat := [2,4,8,16,32,17,128,173,42,189,2048,2233,161,0,2232,35,1,162,2053,2233,2233,32,17,2186,2193,2217,2090,1,1,49,173,16,173,169,0,2195]

theorem envBound52721 : H12AffineFastState.Bounded env52721 := by
  intro p hp
  have h : env52721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52720_52721 : H12AffineEnvironment.transform 7 173 env52720 = env52721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env52720 == env52721) = true)

theorem identity52721 : scanCanonicalize (H12AffineFastState.compose env52721 (packedSelected [2,3,5,7,9,10,12] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound52721 : packedSelected [2,3,5,7,9,10,12] rootPS < 2^1333 := by decide +kernel

def env52722 : List Nat := [2,4,8,16,32,17,35,14,42,30,2048,2074,2,0,2075,35,1,1,2053,2074,2074,32,17,2089,2098,2058,2090,1,1,49,14,16,14,10,0,2096]

theorem envBound52722 : H12AffineFastState.Bounded env52722 := by
  intro p hp
  have h : env52722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52721_52722 : H12AffineEnvironment.transform 6 35 env52721 = env52722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env52721 == env52722) = true)

theorem identity52722 : scanCanonicalize (H12AffineFastState.compose env52722 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound52722 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env52723 : List Nat := [2,4,8,16,32,17,35,14,42,30,48,42,2,0,43,35,1,1,53,42,42,32,17,25,2,58,26,1,1,49,14,16,14,10,0,0]

theorem envBound52723 : H12AffineFastState.Bounded env52723 := by
  intro p hp
  have h : env52723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52722_52723 : H12AffineEnvironment.transform 10 48 env52722 = env52723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env52722 == env52723) = true)

theorem identity52723 : scanCanonicalize (H12AffineFastState.compose env52723 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound52723 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env52724 : List Nat := [2,4,8,11,32,10,35,14,42,5,43,42,2,0,43,35,1,1,46,42,42,32,10,2,2,33,1,1,1,42,14,11,14,10,0,0]

theorem envBound52724 : H12AffineFastState.Bounded env52724 := by
  intro p hp
  have h : env52724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52723_52724 : H12AffineEnvironment.transform 3 11 env52723 = env52724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env52723 == env52724) = true)

theorem identity52724 : scanCanonicalize (H12AffineFastState.compose env52724 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound52724 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52725 : List Nat := [2,4,8,11,13,10,14,14,7,5,6,7,2,0,6,14,1,1,3,7,7,13,10,2,2,12,1,1,1,7,14,11,14,10,0,0]

theorem envBound52725 : H12AffineFastState.Bounded env52725 := by
  intro p hp
  have h : env52725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52724_52725 : H12AffineEnvironment.transform 4 13 env52724 = env52725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env52724 == env52725) = true)

theorem identity52725 : scanCanonicalize (H12AffineFastState.compose env52725 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound52725 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52726 : List Nat := [2,2,8,11,11,10,8,8,1,3,0,1,2,0,0,8,1,1,3,1,1,11,10,2,2,10,1,1,1,1,8,11,8,10,0,0]

theorem envBound52726 : H12AffineFastState.Bounded env52726 := by
  intro p hp
  have h : env52726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52725_52726 : H12AffineEnvironment.transform 1 2 env52725 = env52726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env52725 == env52726) = true)

theorem identity52726 : scanCanonicalize (H12AffineFastState.compose env52726 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound52726 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52727 : List Nat := [2,2,1,2,2,3,1,1,1,3,0,1,2,0,0,1,1,1,3,1,1,2,3,2,2,3,1,1,1,1,1,2,1,3,0,0]

theorem envBound52727 : H12AffineFastState.Bounded env52727 := by
  intro p hp
  have h : env52727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52726_52727 : H12AffineEnvironment.transform 2 1 env52726 = env52727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env52726 == env52727) = true)

theorem identity52727 : scanCanonicalize (H12AffineFastState.compose env52727 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound52727 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env52728 : List Nat := [0,0,1,0,0,1,1,1,1,1,0,1,0,0,0,1,1,1,1,1,1,0,1,0,0,1,1,1,1,1,1,0,1,1,0,0]

theorem envBound52728 : H12AffineFastState.Bounded env52728 := by
  intro p hp
  have h : env52728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52727_52728 : H12AffineEnvironment.transform 0 0 env52727 = env52728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env52727 == env52728) = true)

def env52729 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1345,262144,77934,32769,4096,46528,17,266384,70886,78894,77841,1297,74814,81226,365713,74798,256,308667,1345,79471]

theorem envBound52729 : H12AffineFastState.Bounded env52729 := by
  intro p hp
  have h : env52729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52681_52729 : H12AffineEnvironment.transform 13 1297 env52681 = env52729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env52681 == env52729) = true)

theorem identity52729 : scanCanonicalize (H12AffineFastState.compose env52729 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32883) := by decide +kernel

theorem selectedBound52729 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env52730 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,32883,1345,262144,45085,32769,4096,46528,17,266384,38037,46173,45154,1297,42061,48441,267490,42077,256,308667,1345,46620]

theorem envBound52730 : H12AffineFastState.Bounded env52730 := by
  intro p hp
  have h : env52730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52729_52730 : H12AffineEnvironment.transform 15 32883 env52729 = env52730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32883 env52729 == env52730) = true)

def env52731 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32883,1345,262144,42333,32769,1344,41088,17,263632,33237,41245,42274,1297,42061,43129,262562,42077,256,303355,1345,41820]

theorem envBound52731 : H12AffineFastState.Bounded env52731 := by
  intro p hp
  have h : env52731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52730_52731 : H12AffineEnvironment.transform 11 1344 env52730 = env52731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env52730 == env52731) = true)

theorem identity52731 : scanCanonicalize (H12AffineFastState.compose env52731 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 41147) := by decide +kernel

theorem selectedBound52731 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env52732 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,32768,32883,1345,41147,42333,32769,1344,41088,17,42347,33237,41245,42274,1297,42061,43129,41241,42077,256,64,1345,41820]

theorem envBound52732 : H12AffineFastState.Bounded env52732 := by
  intro p hp
  have h : env52732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52731_52732 : H12AffineEnvironment.transform 17 41147 env52731 = env52732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 41147 env52731 == env52732) = true)

theorem identity52732 : scanCanonicalize (H12AffineFastState.compose env52732 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound52732 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env52733 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,8540,8495,1345,487,1025,8541,1344,476,17,1079,8329,65,1150,1297,1297,2341,69,1281,256,64,1345,512]

theorem envBound52733 : H12AffineFastState.Bounded env52733 := by
  intro p hp
  have h : env52733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52732_52733 : H12AffineEnvironment.transform 14 8540 env52732 = env52733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env52732 == env52733) = true)

theorem identity52733 : scanCanonicalize (H12AffineFastState.compose env52733 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound52733 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env52734 : List Nat := [2,4,8,16,32,64,128,20,512,1024,2048,1108,8192,1029,8264,8251,1109,243,1025,8265,1108,200,17,1079,8329,65,1150,1029,1029,2097,69,1045,20,64,1109,512]

theorem envBound52734 : H12AffineFastState.Bounded env52734 := by
  intro p hp
  have h : env52734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52733_52734 : H12AffineEnvironment.transform 7 20 env52733 = env52734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env52733 == env52734) = true)

theorem identity52734 : scanCanonicalize (H12AffineFastState.compose env52734 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 657) := by decide +kernel

theorem selectedBound52734 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52735 : List Nat := [2,4,8,16,32,64,128,20,512,1024,2048,1108,657,1029,729,682,1109,243,1025,728,1108,200,17,1079,536,65,1150,1029,1029,2097,69,1045,20,64,1109,512]

theorem envBound52735 : H12AffineFastState.Bounded env52735 := by
  intro p hp
  have h : env52735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52734_52735 : H12AffineEnvironment.transform 12 657 env52734 = env52735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 657 env52734 == env52735) = true)

theorem identity52735 : scanCanonicalize (H12AffineFastState.compose env52735 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound52735 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env52736 : List Nat := [2,4,8,16,32,16,128,20,512,1024,2048,1028,657,1029,649,682,1029,163,1025,648,1028,152,17,1079,536,17,1070,1029,1029,2097,21,1045,20,16,1029,512]

theorem envBound52736 : H12AffineFastState.Bounded env52736 := by
  intro p hp
  have h : env52736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52735_52736 : H12AffineEnvironment.transform 5 16 env52735 = env52736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52735 == env52736) = true)

theorem identity52736 : scanCanonicalize (H12AffineFastState.compose env52736 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound52736 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env52737 : List Nat := [2,4,8,16,32,16,57,20,512,1024,2048,1028,552,1029,560,531,1029,26,1025,561,1028,33,17,1079,536,17,1070,1029,1029,2097,21,1045,20,16,1029,512]

theorem envBound52737 : H12AffineFastState.Bounded env52737 := by
  intro p hp
  have h : env52737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52736_52737 : H12AffineEnvironment.transform 6 57 env52736 = env52737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env52736 == env52737) = true)

theorem identity52737 : scanCanonicalize (H12AffineFastState.compose env52737 (packedSelected [0,1,2,4,5,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound52737 : packedSelected [0,1,2,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env52738 : List Nat := [2,4,8,16,32,16,57,20,512,1024,513,1028,552,1029,560,531,1029,26,1025,561,1028,33,17,1079,536,17,1070,1029,1029,560,21,1045,20,16,1029,512]

theorem envBound52738 : H12AffineFastState.Bounded env52738 := by
  intro p hp
  have h : env52738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52737_52738 : H12AffineEnvironment.transform 10 513 env52737 = env52738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env52737 == env52738) = true)

theorem identity52738 : scanCanonicalize (H12AffineFastState.compose env52738 (packedSelected [0,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound52738 : packedSelected [0,2,5] rootPS < 2^1333 := by decide +kernel

def env52739 : List Nat := [2,4,8,16,16,16,9,20,512,1024,513,1028,536,1029,512,531,1029,26,1025,513,1028,17,17,1031,536,17,1054,1029,1029,512,21,1045,20,16,1029,512]

theorem envBound52739 : H12AffineFastState.Bounded env52739 := by
  intro p hp
  have h : env52739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52738_52739 : H12AffineEnvironment.transform 4 16 env52738 = env52739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env52738 == env52739) = true)

def env52740 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,32883,1345,262144,42332,32769,1345,41089,17,263633,33236,41244,42275,1297,42061,43128,262563,42077,256,303354,1345,41821]

theorem envBound52740 : H12AffineFastState.Bounded env52740 := by
  intro p hp
  have h : env52740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52730_52740 : H12AffineEnvironment.transform 11 1345 env52730 = env52740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env52730 == env52740) = true)

theorem identity52740 : scanCanonicalize (H12AffineFastState.compose env52740 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 72) := by decide +kernel

theorem selectedBound52740 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env52741 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,72,1297,32768,32883,1345,262144,34068,32769,1345,32969,17,263633,33236,33108,34155,1297,33797,34864,262563,33813,256,295090,1345,33557]

theorem envBound52741 : H12AffineFastState.Bounded env52741 := by
  intro p hp
  have h : env52741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52740_52741 : H12AffineEnvironment.transform 12 72 env52740 = env52741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env52740 == env52741) = true)

theorem identity52741 : scanCanonicalize (H12AffineFastState.compose env52741 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 35605) := by decide +kernel

theorem selectedBound52741 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env52742 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,72,1297,32768,32883,1345,35605,34068,32769,1345,32969,17,36548,33236,33108,34155,1297,33797,34864,35510,33813,256,2983,1345,33557]

theorem envBound52742 : H12AffineFastState.Bounded env52742 := by
  intro p hp
  have h : env52742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52741_52742 : H12AffineEnvironment.transform 17 35605 env52741 = env52742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35605 env52741 == env52742) = true)

def env52743 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16465,262144,95615,32769,4096,61649,16,284033,86519,94526,77840,1296,74814,96347,381312,90430,256,308666,1345,95102]

theorem envBound52743 : H12AffineFastState.Bounded env52743 := by
  intro p hp
  have h : env52743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52680_52743 : H12AffineEnvironment.transform 16 16465 env52680 = env52743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16465 env52680 == env52743) = true)

def env52744 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,65536,1345,262144,77935,32769,4096,46529,16,266385,70887,78894,77840,1296,74814,81227,365712,74798,256,308666,1345,79470]

theorem envBound52744 : H12AffineFastState.Bounded env52744 := by
  intro p hp
  have h : env52744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52743_52744 : H12AffineEnvironment.transform 13 1296 env52743 = env52744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env52743 == env52744) = true)

theorem identity52744 : scanCanonicalize (H12AffineFastState.compose env52744 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 32882) := by decide +kernel

theorem selectedBound52744 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env52745 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,32768,32882,1345,262144,45085,32769,4096,46529,16,266385,38037,46172,45154,1296,42060,48441,267490,42076,256,308666,1345,46620]

theorem envBound52745 : H12AffineFastState.Bounded env52745 := by
  intro p hp
  have h : env52745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52744_52745 : H12AffineEnvironment.transform 15 32882 env52744 = env52745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32882 env52744 == env52745) = true)

def env52746 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32882,1345,262144,42333,32769,1344,41089,16,263633,33237,41244,42274,1296,42060,43129,262562,42076,256,303354,1345,41820]

theorem envBound52746 : H12AffineFastState.Bounded env52746 := by
  intro p hp
  have h : env52746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52745_52746 : H12AffineEnvironment.transform 11 1344 env52745 = env52746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env52745 == env52746) = true)

theorem identity52746 : scanCanonicalize (H12AffineFastState.compose env52746 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 9455) := by decide +kernel

theorem selectedBound52746 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env52747 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,32882,1345,9455,42333,32769,1344,41089,16,8510,33237,41244,42274,1296,42060,43129,9549,42076,256,33813,1345,41820]

theorem envBound52747 : H12AffineFastState.Bounded env52747 := by
  intro p hp
  have h : env52747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52746_52747 : H12AffineEnvironment.transform 17 9455 env52746 = env52747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 9455 env52746 == env52747) = true)

theorem identity52747 : scanCanonicalize (H12AffineFastState.compose env52747 (packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 4019) := by decide +kernel

theorem selectedBound52747 : packedSelected [4,5,8,9,10,11,12,13,19,20,21,32,38] rootPS < 2^1333 := by decide +kernel

def env52748 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,4019,4033,1345,9455,10990,4018,1344,12082,16,8510,3686,11951,10897,1296,11263,10186,9549,11247,256,2982,1345,11503]

theorem envBound52748 : H12AffineFastState.Bounded env52748 := by
  intro p hp
  have h : env52748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52747_52748 : H12AffineEnvironment.transform 14 4019 env52747 = env52748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 4019 env52747 == env52748) = true)

def env52749 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,32882,1345,262144,42332,32769,1345,41088,16,263632,33236,41245,42275,1296,42060,43128,262563,42076,256,303355,1345,41821]

theorem envBound52749 : H12AffineFastState.Bounded env52749 := by
  intro p hp
  have h : env52749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52745_52749 : H12AffineEnvironment.transform 11 1345 env52745 = env52749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env52745 == env52749) = true)

theorem identity52749 : scanCanonicalize (H12AffineFastState.compose env52749 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 9245) := by decide +kernel

theorem selectedBound52749 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env52750 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,9245,9327,1345,262144,321,9244,1345,1181,16,263632,9673,1280,318,1296,81,3173,262563,65,256,263398,1345,1856]

theorem envBound52750 : H12AffineFastState.Bounded env52750 := by
  intro p hp
  have h : env52750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52749_52750 : H12AffineEnvironment.transform 14 9245 env52749 = env52750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9245 env52749 == env52750) = true)

theorem identity52750 : scanCanonicalize (H12AffineFastState.compose env52750 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound52750 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env52751 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,8192,80,8541,8495,1,262144,321,8540,1,477,16,262288,8329,64,318,80,81,2341,262563,65,256,262566,1,512]

theorem envBound52751 : H12AffineFastState.Bounded env52751 := by
  intro p hp
  have h : env52751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52750_52751 : H12AffineEnvironment.transform 9 320 env52750 = env52751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env52750 == env52751) = true)

theorem identity52751 : scanCanonicalize (H12AffineFastState.compose env52751 (packedSelected [4,9,16] rootPS)) = affineNative (2^(17+1) ^^^ 242) := by decide +kernel

theorem selectedBound52751 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env52752 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,8192,80,8541,8495,1,242,321,8540,1,477,16,98,8329,64,318,80,81,2341,337,65,256,340,1,512]

theorem envBound52752 : H12AffineFastState.Bounded env52752 := by
  intro p hp
  have h : env52752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52751_52752 : H12AffineEnvironment.transform 17 242 env52751 = env52752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 242 env52751 == env52752) = true)

theorem identity52752 : scanCanonicalize (H12AffineFastState.compose env52752 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 900) := by decide +kernel

theorem selectedBound52752 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52753 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,900,80,729,683,1,242,321,728,1,477,16,98,781,64,318,80,81,2341,337,65,256,340,1,512]

theorem envBound52753 : H12AffineFastState.Bounded env52753 := by
  intro p hp
  have h : env52753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52752_52753 : H12AffineEnvironment.transform 12 900 env52752 = env52753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 900 env52752 == env52753) = true)

theorem identity52753 : scanCanonicalize (H12AffineFastState.compose env52753 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound52753 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env52754 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,1,900,0,649,683,1,162,273,648,1,397,16,50,781,16,318,0,1,2341,257,17,256,260,1,512]

theorem envBound52754 : H12AffineFastState.Bounded env52754 := by
  intro p hp
  have h : env52754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52753_52754 : H12AffineEnvironment.transform 5 16 env52753 = env52754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52753 == env52754) = true)

theorem identity52754 : scanCanonicalize (H12AffineFastState.compose env52754 (packedSelected [1,3,13] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound52754 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env52755 : List Nat := [2,4,8,16,32,16,57,256,512,272,2048,1,829,0,560,530,1,27,273,561,1,308,16,50,781,16,318,0,1,2341,257,17,256,260,1,512]

theorem envBound52755 : H12AffineFastState.Bounded env52755 := by
  intro p hp
  have h : env52755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52754_52755 : H12AffineEnvironment.transform 6 57 env52754 = env52755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env52754 == env52755) = true)

theorem identity52755 : scanCanonicalize (H12AffineFastState.compose env52755 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 560) := by decide +kernel

theorem selectedBound52755 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52756 : List Nat := [2,4,8,16,32,16,57,256,512,272,560,1,829,0,560,530,1,27,273,561,1,308,16,50,781,16,318,0,1,789,257,17,256,260,1,512]

theorem envBound52756 : H12AffineFastState.Bounded env52756 := by
  intro p hp
  have h : env52756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52755_52756 : H12AffineEnvironment.transform 10 560 env52755 = env52756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 560 env52755 == env52756) = true)

theorem identity52756 : scanCanonicalize (H12AffineFastState.compose env52756 (packedSelected [0,5] rootPS)) = affineNative (2^(8+1) ^^^ 271) := by decide +kernel

theorem selectedBound52756 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env52757 : List Nat := [2,4,8,16,32,16,57,256,271,272,319,1,50,0,319,285,1,27,273,318,1,308,16,50,2,16,318,0,1,26,257,17,256,260,1,271]

theorem envBound52757 : H12AffineFastState.Bounded env52757 := by
  intro p hp
  have h : env52757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52756_52757 : H12AffineEnvironment.transform 8 271 env52756 = env52757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 271 env52756 == env52757) = true)

theorem identity52757 : scanCanonicalize (H12AffineFastState.compose env52757 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound52757 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env52758 : List Nat := [2,4,8,16,32,16,57,62,49,46,1,1,50,0,1,35,1,27,47,0,1,10,16,50,2,16,0,0,1,26,63,17,62,58,1,49]

theorem envBound52758 : H12AffineFastState.Bounded env52758 := by
  intro p hp
  have h : env52758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52757_52758 : H12AffineEnvironment.transform 7 62 env52757 = env52758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env52757 == env52758) = true)

theorem identity52758 : scanCanonicalize (H12AffineFastState.compose env52758 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound52758 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env52759 : List Nat := [2,4,8,16,10,16,19,20,27,4,1,1,24,0,1,9,1,27,5,0,1,10,16,24,2,16,0,0,1,26,21,17,20,16,1,27]

theorem envBound52759 : H12AffineFastState.Bounded env52759 := by
  intro p hp
  have h : env52759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52758_52759 : H12AffineEnvironment.transform 4 10 env52758 = env52759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env52758 == env52759) = true)

theorem identity52759 : scanCanonicalize (H12AffineFastState.compose env52759 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound52759 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52760 : List Nat := [2,4,8,7,10,7,4,3,12,4,1,1,15,0,1,9,1,12,5,0,1,10,7,15,2,7,0,0,1,13,2,6,3,7,1,12]

theorem envBound52760 : H12AffineFastState.Bounded env52760 := by
  intro p hp
  have h : env52760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52759_52760 : H12AffineEnvironment.transform 3 7 env52759 = env52760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env52759 == env52760) = true)

theorem identity52760 : scanCanonicalize (H12AffineFastState.compose env52760 (packedSelected [8] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound52760 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env52761 : List Nat := [2,4,4,7,6,7,4,3,0,4,1,1,3,0,1,5,1,0,5,0,1,6,7,3,2,7,0,0,1,1,2,6,3,7,1,0]

theorem envBound52761 : H12AffineFastState.Bounded env52761 := by
  intro p hp
  have h : env52761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52760_52761 : H12AffineEnvironment.transform 2 4 env52760 = env52761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env52760 == env52761) = true)

def env52762 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,32768,65536,1344,262144,77934,32769,4096,46528,16,266384,70886,78895,77840,1296,74814,81226,365713,74799,256,308666,1345,79471]

theorem envBound52762 : H12AffineFastState.Bounded env52762 := by
  intro p hp
  have h : env52762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52743_52762 : H12AffineEnvironment.transform 13 1297 env52743 = env52762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env52743 == env52762) = true)

theorem identity52762 : scanCanonicalize (H12AffineFastState.compose env52762 (packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound52762 : packedSelected [1,4,5,7,8,9,16,19,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env52763 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1344,262144,77934,13340,4096,477,16,266384,70886,78895,77840,1296,74814,81226,336012,74799,256,262567,1345,79471]

theorem envBound52763 : H12AffineFastState.Bounded env52763 := by
  intro p hp
  have h : env52763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52762_52763 : H12AffineEnvironment.transform 14 13341 env52762 = env52763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env52762 == env52763) = true)

def env52764 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1344,65664,77934,13340,4096,477,16,69648,70886,78895,77840,1296,74814,81226,8204,74799,256,65831,1345,79471]

theorem envBound52764 : H12AffineFastState.Bounded env52764 := by
  intro p hp
  have h : env52764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52763_52764 : H12AffineEnvironment.transform 17 65664 env52763 = env52764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env52763 == env52764) = true)

theorem identity52764 : scanCanonicalize (H12AffineFastState.compose env52764 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 73) := by decide +kernel

theorem selectedBound52764 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env52765 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,73,1297,5204,65536,1344,65664,69671,5205,4096,477,16,69648,70886,70758,69721,1296,66679,72963,69,66662,256,65831,1345,71206]

theorem envBound52765 : H12AffineFastState.Bounded env52765 := by
  intro p hp
  have h : env52765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52764_52765 : H12AffineEnvironment.transform 12 73 env52764 = env52765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env52764 == env52765) = true)

def env52766 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,25,1297,5124,65536,1296,65664,69671,5125,4096,397,16,69648,70838,70710,69641,1296,66599,72963,21,66614,256,65831,1297,71206]

theorem envBound52766 : H12AffineFastState.Bounded env52766 := by
  intro p hp
  have h : env52766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52765_52766 : H12AffineEnvironment.transform 5 16 env52765 = env52766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52765 == env52766) = true)

theorem identity52766 : scanCanonicalize (H12AffineFastState.compose env52766 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound52766 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env52767 : List Nat := [2,4,8,16,32,16,128,20,512,1024,2048,4096,25,1029,5124,65536,1028,65664,69671,5125,4096,153,16,69648,70838,70710,69641,1028,66599,72727,21,66614,20,65587,1029,71206]

theorem envBound52767 : H12AffineFastState.Bounded env52767 := by
  intro p hp
  have h : env52767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52766_52767 : H12AffineEnvironment.transform 7 20 env52766 = env52767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env52766 == env52767) = true)

theorem identity52767 : scanCanonicalize (H12AffineFastState.compose env52767 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound52767 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env52768 : List Nat := [2,4,8,16,32,16,128,20,512,1024,2048,4096,25,1029,5124,35,1028,163,4100,5125,4096,153,16,4147,5269,5141,4138,1028,1028,7220,21,1045,20,16,1029,5637]

theorem envBound52768 : H12AffineFastState.Bounded env52768 := by
  intro p hp
  have h : env52768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52767_52768 : H12AffineEnvironment.transform 15 35 env52767 = env52768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env52767 == env52768) = true)

theorem identity52768 : scanCanonicalize (H12AffineFastState.compose env52768 (packedSelected [10,11,13,17,18,19] rootPS)) = affineNative (2^(11+1) ^^^ 3213) := by decide +kernel

theorem selectedBound52768 : packedSelected [10,11,13,17,18,19] rootPS < 2^1333 := by decide +kernel

def env52769 : List Nat := [2,4,8,16,32,16,128,20,512,1024,2048,3213,25,1029,2185,35,1028,163,3209,2184,3213,153,16,3262,2072,2200,3239,1028,1028,185,21,1045,20,16,1029,2696]

theorem envBound52769 : H12AffineFastState.Bounded env52769 := by
  intro p hp
  have h : env52769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52768_52769 : H12AffineEnvironment.transform 11 3213 env52768 = env52769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3213 env52768 == env52769) = true)

theorem identity52769 : scanCanonicalize (H12AffineFastState.compose env52769 (packedSelected [0,2,3,5,7,10,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 542) := by decide +kernel

theorem selectedBound52769 : packedSelected [0,2,3,5,7,10,11,12] rootPS < 2^1333 := by decide +kernel

def env52770 : List Nat := [2,4,8,16,32,16,128,20,512,542,2048,2707,25,539,2185,35,538,163,2711,2184,2707,153,16,2720,2072,2200,2745,538,538,185,21,523,20,16,539,2696]

theorem envBound52770 : H12AffineFastState.Bounded env52770 := by
  intro p hp
  have h : env52770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52769_52770 : H12AffineEnvironment.transform 9 542 env52769 = env52770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 542 env52769 == env52770) = true)

theorem identity52770 : scanCanonicalize (H12AffineFastState.compose env52770 (packedSelected [0,1,3,5,7,8,10,11,15] rootPS)) = affineNative (2^(10+1) ^^^ 648) := by decide +kernel

theorem selectedBound52770 : packedSelected [0,1,3,5,7,8,10,11,15] rootPS < 2^1333 := by decide +kernel

def env52771 : List Nat := [2,4,8,16,32,16,128,20,512,542,648,27,25,539,513,35,538,163,31,512,27,153,16,40,656,528,49,538,538,185,21,523,20,16,539,0]

theorem envBound52771 : H12AffineFastState.Bounded env52771 := by
  intro p hp
  have h : env52771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52770_52771 : H12AffineEnvironment.transform 10 648 env52770 = env52771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 648 env52770 == env52771) = true)

theorem identity52771 : scanCanonicalize (H12AffineFastState.compose env52771 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound52771 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env52772 : List Nat := [2,4,8,16,32,16,128,20,43,53,163,27,25,48,42,35,49,163,31,43,27,153,16,40,187,59,49,49,49,185,21,32,20,16,48,0]

theorem envBound52772 : H12AffineFastState.Bounded env52772 := by
  intro p hp
  have h : env52772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52771_52772 : H12AffineEnvironment.transform 8 43 env52771 = env52772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env52771 == env52772) = true)

theorem identity52772 : scanCanonicalize (H12AffineFastState.compose env52772 (packedSelected [1,5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound52772 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env52773 : List Nat := [2,4,8,16,32,16,9,20,43,53,42,27,25,48,42,35,49,42,31,43,27,16,16,40,50,59,49,49,49,48,21,32,20,16,48,0]

theorem envBound52773 : H12AffineFastState.Bounded env52773 := by
  intro p hp
  have h : env52773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52772_52773 : H12AffineEnvironment.transform 6 9 env52772 = env52773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env52772 == env52773) = true)

theorem identity52773 : scanCanonicalize (H12AffineFastState.compose env52773 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound52773 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52774 : List Nat := [2,4,8,16,17,16,9,20,26,4,27,27,25,1,27,18,0,27,31,26,27,16,16,25,3,10,0,0,0,1,21,17,20,16,1,0]

theorem envBound52774 : H12AffineFastState.Bounded env52774 := by
  intro p hp
  have h : env52774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52773_52774 : H12AffineEnvironment.transform 4 17 env52773 = env52774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env52773 == env52774) = true)

theorem identity52774 : scanCanonicalize (H12AffineFastState.compose env52774 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound52774 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52775 : List Nat := [2,2,8,16,17,16,9,18,26,2,27,27,25,1,27,18,0,27,25,26,27,16,16,25,3,10,0,0,0,1,19,17,18,16,1,0]

theorem envBound52775 : H12AffineFastState.Bounded env52775 := by
  intro p hp
  have h : env52775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52774_52775 : H12AffineEnvironment.transform 1 2 env52774 = env52775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env52774 == env52775) = true)

def env52776 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,24,1297,5125,65536,1297,65664,69671,5124,4096,396,16,69648,70839,70711,69640,1296,66598,72963,20,66615,256,65831,1296,71206]

theorem envBound52776 : H12AffineFastState.Bounded env52776 := by
  intro p hp
  have h : env52776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52765_52776 : H12AffineEnvironment.transform 5 17 env52765 = env52776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52765 == env52776) = true)

theorem identity52776 : scanCanonicalize (H12AffineFastState.compose env52776 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 5426) := by decide +kernel

theorem selectedBound52776 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env52777 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,24,1297,5125,5426,1297,5554,1301,5124,4096,396,16,1314,389,261,1338,1296,4372,2097,20,4357,256,5141,1296,788]

theorem envBound52777 : H12AffineFastState.Bounded env52777 := by
  intro p hp
  have h : env52777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52776_52777 : H12AffineEnvironment.transform 15 5426 env52776 = env52777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5426 env52776 == env52777) = true)

theorem identity52777 : scanCanonicalize (H12AffineFastState.compose env52777 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound52777 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env52778 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,24,1297,276,35,1297,163,1301,277,1297,396,16,1314,389,261,1338,1296,1029,2097,20,1044,256,260,1296,788]

theorem envBound52778 : H12AffineFastState.Bounded env52778 := by
  intro p hp
  have h : env52778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52777_52778 : H12AffineEnvironment.transform 11 1297 env52777 = env52778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env52777 == env52778) = true)

theorem identity52778 : scanCanonicalize (H12AffineFastState.compose env52778 (packedSelected [0,1,3,7,10,11,12,15,19] rootPS)) = affineNative (2^(9+1) ^^^ 920) := by decide +kernel

theorem selectedBound52778 : packedSelected [0,1,3,7,10,11,12,15,19] rootPS < 2^1333 := by decide +kernel

def env52779 : List Nat := [2,4,8,16,32,17,128,256,512,920,2048,649,24,649,276,35,649,163,653,277,649,396,16,698,389,261,674,648,925,2097,20,908,256,260,648,788]

theorem envBound52779 : H12AffineFastState.Bounded env52779 := by
  intro p hp
  have h : env52779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52778_52779 : H12AffineEnvironment.transform 9 920 env52778 = env52779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 920 env52778 == env52779) = true)

theorem identity52779 : scanCanonicalize (H12AffineFastState.compose env52779 (packedSelected [2,3,8,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 146) := by decide +kernel

theorem selectedBound52779 : packedSelected [2,3,8,12,13,15] rootPS < 2^1333 := by decide +kernel

def env52780 : List Nat := [2,4,8,16,32,17,128,256,512,920,146,649,24,649,276,35,649,163,653,277,649,396,16,698,389,261,674,648,925,163,20,908,256,260,648,788]

theorem envBound52780 : H12AffineFastState.Bounded env52780 := by
  intro p hp
  have h : env52780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52779_52780 : H12AffineEnvironment.transform 10 146 env52779 = env52780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 146 env52779 == env52780) = true)

theorem identity52780 : scanCanonicalize (H12AffineFastState.compose env52780 (packedSelected [2,4,9,10,11,13] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound52780 : packedSelected [2,4,9,10,11,13] rootPS < 2^1333 := by decide +kernel

def env52781 : List Nat := [2,4,8,16,32,17,128,173,512,565,146,649,24,649,185,35,649,163,653,184,649,33,16,698,40,168,674,648,560,163,20,545,173,169,648,697]

theorem envBound52781 : H12AffineFastState.Bounded env52781 := by
  intro p hp
  have h : env52781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52780_52781 : H12AffineEnvironment.transform 7 173 env52780 = env52781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env52780 == env52781) = true)

theorem identity52781 : scanCanonicalize (H12AffineFastState.compose env52781 (packedSelected [2,3,8] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound52781 : packedSelected [2,3,8] rootPS < 2^1333 := by decide +kernel

def env52782 : List Nat := [2,4,8,16,32,17,57,20,512,565,43,560,24,560,0,35,560,26,564,1,560,33,16,515,40,17,539,561,560,26,20,545,20,16,561,512]

theorem envBound52782 : H12AffineFastState.Bounded env52782 := by
  intro p hp
  have h : env52782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52781_52782 : H12AffineEnvironment.transform 6 57 env52781 = env52782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env52781 == env52782) = true)

theorem identity52782 : scanCanonicalize (H12AffineFastState.compose env52782 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound52782 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52783 : List Nat := [2,4,8,16,11,17,18,20,512,542,0,539,24,539,0,8,539,26,543,1,539,10,16,515,3,17,539,538,539,26,20,522,20,16,538,512]

theorem envBound52783 : H12AffineFastState.Bounded env52783 := by
  intro p hp
  have h : env52783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52782_52783 : H12AffineEnvironment.transform 4 11 env52782 = env52783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env52782 == env52783) = true)

def env52784 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,1344,65665,77934,13340,4096,477,16,69649,70886,78895,77840,1296,74814,81226,8205,74799,256,65830,1345,79471]

theorem envBound52784 : H12AffineFastState.Bounded env52784 := by
  intro p hp
  have h : env52784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52763_52784 : H12AffineEnvironment.transform 17 65665 env52763 = env52784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env52763 == env52784) = true)

theorem identity52784 : scanCanonicalize (H12AffineFastState.compose env52784 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5385) := by decide +kernel

theorem selectedBound52784 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env52785 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5385,1297,276,65536,1344,65665,66919,277,4096,477,16,69649,70886,65830,66841,1296,69943,67651,5380,69926,256,65830,1345,66406]

theorem envBound52785 : H12AffineFastState.Bounded env52785 := by
  intro p hp
  have h : env52785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52784_52785 : H12AffineEnvironment.transform 12 5385 env52784 = env52785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5385 env52784 == env52785) = true)

def env52786 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5385,1297,276,65536,1296,65665,66871,277,4096,397,16,69649,70838,65830,66841,1296,69943,67603,5380,69926,256,65830,1297,66358]

theorem envBound52786 : H12AffineFastState.Bounded env52786 := by
  intro p hp
  have h : env52786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52785_52786 : H12AffineEnvironment.transform 5 16 env52785 = env52786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52785 == env52786) = true)

theorem identity52786 : scanCanonicalize (H12AffineFastState.compose env52786 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound52786 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env52787 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1029,268,1297,276,65536,1296,65665,66871,277,1029,397,16,66580,65715,65830,66841,1296,66866,67603,257,66851,256,65830,1297,66358]

theorem envBound52787 : H12AffineFastState.Bounded env52787 := by
  intro p hp
  have h : env52787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52786_52787 : H12AffineEnvironment.transform 11 1029 env52786 = env52787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env52786 == env52787) = true)

theorem identity52787 : scanCanonicalize (H12AffineFastState.compose env52787 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound52787 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env52788 : List Nat := [2,4,8,16,32,16,128,20,512,1024,2048,1029,24,1029,0,65536,1028,65665,66595,1,1029,153,16,66580,65715,65586,66573,1028,66598,67603,21,66615,20,65586,1029,66082]

theorem envBound52788 : H12AffineFastState.Bounded env52788 := by
  intro p hp
  have h : env52788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52787_52788 : H12AffineEnvironment.transform 7 20 env52787 = env52788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env52787 == env52788) = true)

theorem identity52788 : scanCanonicalize (H12AffineFastState.compose env52788 (packedSelected [0,1,2,3,7,10,12,15,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 2737) := by decide +kernel

theorem selectedBound52788 : packedSelected [0,1,2,3,7,10,12,15,18,19] rootPS < 2^1333 := by decide +kernel

def env52789 : List Nat := [2,4,8,16,32,16,128,20,512,1024,2048,1029,24,1029,0,2737,1028,2608,3730,1,1029,153,16,3749,2562,2691,3772,1028,3735,674,21,3718,20,2691,1029,2195]

theorem envBound52789 : H12AffineFastState.Bounded env52789 := by
  intro p hp
  have h : env52789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52788_52789 : H12AffineEnvironment.transform 15 2737 env52788 = env52789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2737 env52788 == env52789) = true)

theorem identity52789 : scanCanonicalize (H12AffineFastState.compose env52789 (packedSelected [1,2,5,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 560) := by decide +kernel

theorem selectedBound52789 : packedSelected [1,2,5,12,13,15] rootPS < 2^1333 := by decide +kernel

def env52790 : List Nat := [2,4,8,16,32,16,128,20,512,1024,560,1029,24,1029,0,129,1028,0,1186,1,1029,153,16,1173,50,179,1164,1028,1191,674,21,1206,20,179,1029,675]

theorem envBound52790 : H12AffineFastState.Bounded env52790 := by
  intro p hp
  have h : env52790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52789_52790 : H12AffineEnvironment.transform 10 560 env52789 = env52790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 560 env52789 == env52790) = true)

theorem identity52790 : scanCanonicalize (H12AffineFastState.compose env52790 (packedSelected [1,2,5,10,12,13] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound52790 : packedSelected [1,2,5,10,12,13] rootPS < 2^1333 := by decide +kernel

def env52791 : List Nat := [2,4,8,16,32,16,8,20,512,1024,560,1029,24,1029,0,9,1028,0,1066,1,1029,17,16,1053,50,59,1028,1028,1071,554,21,1086,20,59,1029,555]

theorem envBound52791 : H12AffineFastState.Bounded env52791 := by
  intro p hp
  have h : env52791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52790_52791 : H12AffineEnvironment.transform 6 8 env52790 = env52791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52790 == env52791) = true)

theorem identity52791 : scanCanonicalize (H12AffineFastState.compose env52791 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 31) := by decide +kernel

theorem selectedBound52791 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env52792 : List Nat := [2,4,8,16,32,16,8,20,512,31,560,26,24,26,0,9,27,0,53,1,26,17,16,2,50,59,27,27,48,554,21,33,20,59,26,555]

theorem envBound52792 : H12AffineFastState.Bounded env52792 := by
  intro p hp
  have h : env52792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52791_52792 : H12AffineEnvironment.transform 9 31 env52791 = env52792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 31 env52791 == env52792) = true)

theorem identity52792 : scanCanonicalize (H12AffineFastState.compose env52792 (packedSelected [1,2,4,5,9] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound52792 : packedSelected [1,2,4,5,9] rootPS < 2^1333 := by decide +kernel

def env52793 : List Nat := [2,4,8,16,32,16,8,20,27,31,43,26,24,26,0,9,27,0,53,1,26,17,16,2,50,59,27,27,48,49,21,33,20,59,26,48]

theorem envBound52793 : H12AffineFastState.Bounded env52793 := by
  intro p hp
  have h : env52793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52792_52793 : H12AffineEnvironment.transform 8 27 env52792 = env52793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env52792 == env52793) = true)

theorem identity52793 : scanCanonicalize (H12AffineFastState.compose env52793 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound52793 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52794 : List Nat := [2,4,8,16,11,16,8,20,27,31,0,26,24,26,0,9,27,0,30,1,26,17,16,2,25,16,27,27,27,26,21,10,20,16,26,27]

theorem envBound52794 : H12AffineFastState.Bounded env52794 := by
  intro p hp
  have h : env52794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52793_52794 : H12AffineEnvironment.transform 4 11 env52793 = env52794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env52793 == env52794) = true)

def env52795 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,5385,1297,276,65536,1297,65665,66870,277,4096,396,16,69649,70839,65830,66841,1296,69943,67602,5380,69926,256,65830,1296,66359]

theorem envBound52795 : H12AffineFastState.Bounded env52795 := by
  intro p hp
  have h : env52795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52785_52795 : H12AffineEnvironment.transform 5 17 env52785 = env52795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52785 == env52795) = true)

theorem identity52795 : scanCanonicalize (H12AffineFastState.compose env52795 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 5427) := by decide +kernel

theorem selectedBound52795 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env52796 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,5385,1297,276,5427,1297,5554,4101,277,4096,396,16,1314,388,5141,4138,1296,1028,7457,5380,1045,256,5141,1296,5636]

theorem envBound52796 : H12AffineFastState.Bounded env52796 := by
  intro p hp
  have h : env52796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52795_52796 : H12AffineEnvironment.transform 15 5427 env52795 = env52796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5427 env52795 == env52796) = true)

theorem identity52796 : scanCanonicalize (H12AffineFastState.compose env52796 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound52796 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env52797 : List Nat := [2,4,8,16,32,17,128,21,512,1024,2048,4096,5148,1028,1,5158,1028,5287,4101,0,4096,153,16,1079,145,5141,4138,1029,1028,7220,5137,1045,21,5141,1029,5636]

theorem envBound52797 : H12AffineFastState.Bounded env52797 := by
  intro p hp
  have h : env52797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52796_52797 : H12AffineEnvironment.transform 7 21 env52796 = env52797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env52796 == env52797) = true)

theorem identity52797 : scanCanonicalize (H12AffineFastState.compose env52797 (packedSelected [10,11,13,17,18,19] rootPS)) = affineNative (2^(11+1) ^^^ 49) := by decide +kernel

theorem selectedBound52797 : packedSelected [10,11,13,17,18,19] rootPS < 2^1333 := by decide +kernel

def env52798 : List Nat := [2,4,8,16,32,17,128,21,512,1024,2048,49,1069,1028,1,1047,1028,1174,52,0,49,153,16,1079,145,1060,27,1029,1028,3077,1056,1045,21,1060,1029,1589]

theorem envBound52798 : H12AffineFastState.Bounded env52798 := by
  intro p hp
  have h : env52798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52797_52798 : H12AffineEnvironment.transform 11 49 env52797 = env52798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env52797 == env52798) = true)

theorem identity52798 : scanCanonicalize (H12AffineFastState.compose env52798 (packedSelected [0,7,11,12,13,15] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound52798 : packedSelected [0,7,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env52799 : List Nat := [2,4,8,16,32,17,18,21,512,1024,2048,49,1069,1028,1,1047,1028,1028,52,0,49,11,16,1079,3,1060,27,1029,1028,3077,1056,1045,21,1060,1029,1589]

theorem envBound52799 : H12AffineFastState.Bounded env52799 := by
  intro p hp
  have h : env52799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52798_52799 : H12AffineEnvironment.transform 6 18 env52798 = env52799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env52798 == env52799) = true)

theorem identity52799 : scanCanonicalize (H12AffineFastState.compose env52799 (packedSelected [1,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 1029) := by decide +kernel

theorem selectedBound52799 : packedSelected [1,8,10,11] rootPS < 2^1333 := by decide +kernel

def env52800 : List Nat := [2,4,8,16,32,17,18,21,512,1024,1029,49,1069,1028,1,1047,1028,1028,52,0,49,11,16,1079,3,1060,27,1029,1028,0,1056,1045,21,1060,1029,1589]

theorem envBound52800 : H12AffineFastState.Bounded env52800 := by
  intro p hp
  have h : env52800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52799_52800 : H12AffineEnvironment.transform 10 1029 env52799 = env52800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1029 env52799 == env52800) = true)

theorem identity52800 : scanCanonicalize (H12AffineFastState.compose env52800 (packedSelected [2,4,7] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound52800 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env52801 : List Nat := [2,4,8,16,32,17,18,21,512,5,0,49,40,1,1,18,1,1,52,0,49,11,16,50,3,33,27,0,1,0,37,16,21,33,0,560]

theorem envBound52801 : H12AffineFastState.Bounded env52801 := by
  intro p hp
  have h : env52801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52800_52801 : H12AffineEnvironment.transform 9 5 env52800 = env52801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env52800 == env52801) = true)

theorem identity52801 : scanCanonicalize (H12AffineFastState.compose env52801 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound52801 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52802 : List Nat := [2,4,8,16,32,17,18,21,0,5,0,49,40,1,1,18,1,1,52,0,49,11,16,50,3,33,27,0,1,0,37,16,21,33,0,48]

theorem envBound52802 : H12AffineFastState.Bounded env52802 := by
  intro p hp
  have h : env52802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52801_52802 : H12AffineEnvironment.transform 8 0 env52801 = env52802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env52801 == env52802) = true)

theorem identity52802 : scanCanonicalize (H12AffineFastState.compose env52802 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound52802 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52803 : List Nat := [2,4,8,16,16,17,18,21,0,5,0,1,24,1,1,18,1,1,4,0,1,11,16,2,3,17,27,0,1,0,21,16,21,17,0,0]

theorem envBound52803 : H12AffineFastState.Bounded env52803 := by
  intro p hp
  have h : env52803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52802_52803 : H12AffineEnvironment.transform 4 16 env52802 = env52803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env52802 == env52803) = true)

theorem identity52803 : scanCanonicalize (H12AffineFastState.compose env52803 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound52803 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52804 : List Nat := [2,4,8,13,13,12,15,8,0,5,0,1,5,1,1,15,1,1,4,0,1,11,13,2,3,12,6,0,1,0,8,13,8,12,0,0]

theorem envBound52804 : H12AffineFastState.Bounded env52804 := by
  intro p hp
  have h : env52804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52803_52804 : H12AffineEnvironment.transform 3 13 env52803 = env52804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env52803 == env52804) = true)

def env52805 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,16777216,533640,672784,17245633,148801,545089,96347,16876545,205167,256,17552661,1344,525825]

theorem envBound52805 : H12AffineFastState.Bounded env52805 := by
  intro p hp
  have h : env52805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52553_52805 : H12AffineEnvironment.transform 26 17245633 env52553 = env52805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env52553 == env52805) = true)

theorem identity52805 : scanCanonicalize (H12AffineFastState.compose env52805 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 74863) := by decide +kernel

theorem selectedBound52805 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env52806 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,524288,32769,4096,61649,91182,16777216,533640,614527,17039790,90414,545089,96347,16876545,1280,256,17363322,1344,525825]

theorem envBound52806 : H12AffineFastState.Bounded env52806 := by
  intro p hp
  have h : env52806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52805_52806 : H12AffineEnvironment.transform 16 74863 env52805 = env52806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 74863 env52805 == env52806) = true)

def env52807 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,524288,32769,4096,61649,91182,123164,533640,614527,385202,90414,545089,96347,25885,1280,256,594022,1344,525825]

theorem envBound52807 : H12AffineFastState.Bounded env52807 := by
  intro p hp
  have h : env52807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52806_52807 : H12AffineEnvironment.transform 23 123164 env52806 = env52807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123164 env52806 == env52807) = true)

def env52808 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21584,32769,4096,61649,91182,123164,28888,78895,385202,90414,1297,96347,25885,1280,256,82998,1344,21073]

theorem envBound52808 : H12AffineFastState.Bounded env52808 := by
  intro p hp
  have h : env52808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52807_52808 : H12AffineEnvironment.transform 18 21584 env52807 = env52808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env52807 == env52808) = true)

theorem identity52808 : scanCanonicalize (H12AffineFastState.compose env52808 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25677) := by decide +kernel

theorem selectedBound52808 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env52809 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25677,65536,74863,262144,21584,25676,4096,5276,91182,66897,28888,78895,328959,90414,1297,96347,25885,1280,256,82998,1344,21073]

theorem envBound52809 : H12AffineFastState.Bounded env52809 := by
  intro p hp
  have h : env52809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52808_52809 : H12AffineEnvironment.transform 14 25677 env52808 = env52809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25677 env52808 == env52809) = true)

def env52810 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74863,262144,4416,8540,4096,5276,74046,66897,13768,78895,328959,74814,1297,81227,8205,1280,256,65830,1344,5953]

theorem envBound52810 : H12AffineFastState.Bounded env52810 := by
  intro p hp
  have h : env52810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52809_52810 : H12AffineEnvironment.transform 13 1296 env52809 = env52810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env52809 == env52810) = true)

def env52811 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74863,65664,4416,8540,4096,5276,74046,66897,13768,78895,1151,74814,1297,81227,8205,1280,256,65830,1344,5953]

theorem envBound52811 : H12AffineFastState.Bounded env52811 := by
  intro p hp
  have h : env52811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52810_52811 : H12AffineEnvironment.transform 17 65664 env52810 = env52811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env52810 == env52811) = true)

theorem identity52811 : scanCanonicalize (H12AffineFastState.compose env52811 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 358) := by decide +kernel

theorem selectedBound52811 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env52812 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,358,9481,486,4416,8540,4096,5276,8280,1079,13768,13641,1151,9560,1297,15405,8205,1280,256,64,1344,5953]

theorem envBound52812 : H12AffineFastState.Bounded env52812 := by
  intro p hp
  have h : env52812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52811_52812 : H12AffineEnvironment.transform 15 358 env52811 = env52812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 358 env52811 == env52812) = true)

def env52813 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,72,1296,277,358,1345,486,4416,276,4096,5276,16,1079,5504,5377,1151,1296,1297,7269,69,1280,256,64,1344,5953]

theorem envBound52813 : H12AffineFastState.Bounded env52813 := by
  intro p hp
  have h : env52813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52812_52813 : H12AffineEnvironment.transform 12 72 env52812 = env52813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env52812 == env52813) = true)

theorem identity52813 : scanCanonicalize (H12AffineFastState.compose env52813 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound52813 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env52814 : List Nat := [2,4,8,16,32,64,128,69,512,1024,2048,4096,72,1109,80,35,1028,163,4101,81,4096,5276,16,1079,5317,5188,1151,1109,1108,7269,69,1093,69,64,1029,5636]

theorem envBound52814 : H12AffineFastState.Bounded env52814 := by
  intro p hp
  have h : env52814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52813_52814 : H12AffineEnvironment.transform 7 69 env52813 = env52814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env52813 == env52814) = true)

theorem identity52814 : scanCanonicalize (H12AffineFastState.compose env52814 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound52814 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env52815 : List Nat := [2,4,8,16,32,64,128,69,512,1024,2048,1028,72,1109,80,35,1028,163,1025,81,1028,152,16,1079,193,64,1151,1109,1108,2145,69,1093,69,64,1029,512]

theorem envBound52815 : H12AffineFastState.Bounded env52815 := by
  intro p hp
  have h : env52815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52814_52815 : H12AffineEnvironment.transform 11 1028 env52814 = env52815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env52814 == env52815) = true)

theorem identity52815 : scanCanonicalize (H12AffineFastState.compose env52815 (packedSelected [0,2,5,7,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 122) := by decide +kernel

theorem selectedBound52815 : packedSelected [0,2,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env52816 : List Nat := [2,4,8,16,32,64,128,69,512,1024,122,1028,72,1109,80,35,1028,163,1025,81,1028,152,16,1079,193,64,1151,1109,1108,27,69,1093,69,64,1029,512]

theorem envBound52816 : H12AffineFastState.Bounded env52816 := by
  intro p hp
  have h : env52816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52815_52816 : H12AffineEnvironment.transform 10 122 env52815 = env52816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 122 env52815 == env52816) = true)

theorem identity52816 : scanCanonicalize (H12AffineFastState.compose env52816 (packedSelected [1,3,13] rootPS)) = affineNative (2^(9+1) ^^^ 732) := by decide +kernel

theorem selectedBound52816 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env52817 : List Nat := [2,4,8,16,32,64,128,69,512,732,122,728,72,649,80,35,728,163,733,81,728,152,16,747,193,64,675,649,648,27,69,665,69,64,729,512]

theorem envBound52817 : H12AffineFastState.Bounded env52817 := by
  intro p hp
  have h : env52817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52816_52817 : H12AffineEnvironment.transform 9 732 env52816 = env52817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 732 env52816 == env52817) = true)

def env52818 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,73,1296,276,358,1344,486,4416,277,4096,5276,17,1079,5505,5376,1151,1297,1297,7268,68,1280,256,64,1344,5953]

theorem envBound52818 : H12AffineFastState.Bounded env52818 := by
  intro p hp
  have h : env52818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52812_52818 : H12AffineEnvironment.transform 12 73 env52812 = env52818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env52812 == env52818) = true)

theorem identity52818 : scanCanonicalize (H12AffineFastState.compose env52818 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound52818 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env52819 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,73,1,276,358,81,486,4416,277,4096,4493,17,294,4240,4113,366,0,0,6517,68,17,256,64,81,4688]

theorem envBound52819 : H12AffineFastState.Bounded env52819 := by
  intro p hp
  have h : env52819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52818_52819 : H12AffineEnvironment.transform 9 273 env52818 = env52819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env52818 == env52819) = true)

theorem identity52819 : scanCanonicalize (H12AffineFastState.compose env52819 (packedSelected [0,2,3,5,7,10,11,12,15,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 755) := by decide +kernel

theorem selectedBound52819 : packedSelected [0,2,3,5,7,10,11,12,15,17,18,20] rootPS < 2^1333 := by decide +kernel

def env52820 : List Nat := [2,4,8,16,32,64,128,256,512,273,755,4096,73,1,276,358,81,486,4416,277,4096,4493,17,294,4240,4113,366,0,0,4998,68,17,256,64,81,4688]

theorem envBound52820 : H12AffineFastState.Bounded env52820 := by
  intro p hp
  have h : env52820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52819_52820 : H12AffineEnvironment.transform 10 755 env52819 = env52820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 755 env52819 == env52820) = true)

theorem identity52820 : scanCanonicalize (H12AffineFastState.compose env52820 (packedSelected [1,5,8,13,28] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound52820 : packedSelected [1,5,8,13,28] rootPS < 2^1333 := by decide +kernel

def env52821 : List Nat := [2,4,8,16,32,64,128,256,512,273,755,277,73,1,276,358,81,486,85,277,277,152,17,294,389,260,366,0,0,659,68,17,256,64,81,837]

theorem envBound52821 : H12AffineFastState.Bounded env52821 := by
  intro p hp
  have h : env52821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52820_52821 : H12AffineEnvironment.transform 11 277 env52820 = env52821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env52820 == env52821) = true)

theorem identity52821 : scanCanonicalize (H12AffineFastState.compose env52821 (packedSelected [0,2,3,7,8,11,13] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound52821 : packedSelected [0,2,3,7,8,11,13] rootPS < 2^1333 := by decide +kernel

def env52822 : List Nat := [2,4,8,16,32,64,128,173,512,188,755,184,73,1,185,203,81,75,85,184,184,152,17,139,40,169,195,0,0,659,68,17,173,64,81,744]

theorem envBound52822 : H12AffineFastState.Bounded env52822 := by
  intro p hp
  have h : env52822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52821_52822 : H12AffineEnvironment.transform 7 173 env52821 = env52822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env52821 == env52822) = true)

theorem identity52822 : scanCanonicalize (H12AffineFastState.compose env52822 (packedSelected [0,2,4,7,9,15] rootPS)) = affineNative (2^(8+1) ^^^ 97) := by decide +kernel

theorem selectedBound52822 : packedSelected [0,2,4,7,9,15] rootPS < 2^1333 := by decide +kernel

def env52823 : List Nat := [2,4,8,16,32,64,128,173,97,188,146,184,73,1,185,203,81,75,85,184,184,152,17,139,40,169,195,0,0,242,68,17,173,64,81,137]

theorem envBound52823 : H12AffineFastState.Bounded env52823 := by
  intro p hp
  have h : env52823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52822_52823 : H12AffineEnvironment.transform 8 97 env52822 = env52823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env52822 == env52823) = true)

theorem identity52823 : scanCanonicalize (H12AffineFastState.compose env52823 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound52823 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env52824 : List Nat := [2,4,8,16,32,16,128,173,49,188,146,184,25,1,185,155,1,27,5,184,184,152,17,139,40,169,147,0,0,162,20,17,173,16,1,137]

theorem envBound52824 : H12AffineFastState.Bounded env52824 := by
  intro p hp
  have h : env52824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52823_52824 : H12AffineEnvironment.transform 5 16 env52823 = env52824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52823 == env52824) = true)

theorem identity52824 : scanCanonicalize (H12AffineFastState.compose env52824 (packedSelected [1,2] rootPS)) = affineNative (2^(6+1) ^^^ 21) := by decide +kernel

theorem selectedBound52824 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env52825 : List Nat := [2,4,8,16,32,16,21,56,49,41,7,45,25,1,44,14,1,27,5,45,45,13,17,30,40,60,6,0,0,55,20,17,56,16,1,28]

theorem envBound52825 : H12AffineFastState.Bounded env52825 := by
  intro p hp
  have h : env52825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52824_52825 : H12AffineEnvironment.transform 6 21 env52824 = env52825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 21 env52824 == env52825) = true)

theorem identity52825 : scanCanonicalize (H12AffineFastState.compose env52825 (packedSelected [1,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound52825 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env52826 : List Nat := [2,4,8,16,23,16,21,15,6,30,7,26,25,1,27,14,1,27,5,26,26,13,17,30,31,11,6,0,0,0,20,17,15,16,1,28]

theorem envBound52826 : H12AffineFastState.Bounded env52826 := by
  intro p hp
  have h : env52826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52825_52826 : H12AffineEnvironment.transform 4 23 env52825 = env52826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env52825 == env52826) = true)

theorem identity52826 : scanCanonicalize (H12AffineFastState.compose env52826 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound52826 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52827 : List Nat := [2,4,8,13,10,13,8,15,6,3,7,7,4,1,6,14,1,6,5,7,7,13,12,3,2,11,6,0,0,0,9,12,15,13,1,1]

theorem envBound52827 : H12AffineFastState.Bounded env52827 := by
  intro p hp
  have h : env52827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52826_52827 : H12AffineEnvironment.transform 3 13 env52826 = env52827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env52826 == env52827) = true)

theorem identity52827 : scanCanonicalize (H12AffineFastState.compose env52827 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound52827 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52828 : List Nat := [2,3,8,10,10,10,8,8,1,3,0,0,3,1,1,9,1,1,2,0,0,10,11,3,2,11,1,0,0,0,9,11,8,10,1,1]

theorem envBound52828 : H12AffineFastState.Bounded env52828 := by
  intro p hp
  have h : env52828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52827_52828 : H12AffineEnvironment.transform 1 3 env52827 = env52828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env52827 == env52828) = true)

def env52829 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74863,65665,4416,8540,4096,5276,74046,66897,13768,78895,1150,74814,1297,81227,8205,1280,256,65830,1344,5953]

theorem envBound52829 : H12AffineFastState.Bounded env52829 := by
  intro p hp
  have h : env52829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52810_52829 : H12AffineEnvironment.transform 17 65665 env52810 = env52829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env52810 == env52829) = true)

theorem identity52829 : scanCanonicalize (H12AffineFastState.compose env52829 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5158) := by decide +kernel

theorem selectedBound52829 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env52830 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,5158,12361,5287,4416,8540,4096,5276,13592,4471,13768,8201,1150,12312,1297,10605,8205,1280,256,5376,1344,5953]

theorem envBound52830 : H12AffineFastState.Bounded env52830 := by
  intro p hp
  have h : env52830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52829_52830 : H12AffineEnvironment.transform 15 5158 env52829 = env52830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5158 env52829 == env52830) = true)

def env52831 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5384,1296,5205,5158,1345,5287,4416,5204,4096,5276,16,4471,192,5377,1150,1296,1297,7269,5381,1280,256,5376,1344,5953]

theorem envBound52831 : H12AffineFastState.Bounded env52831 := by
  intro p hp
  have h : env52831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52830_52831 : H12AffineEnvironment.transform 12 5384 env52830 = env52831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5384 env52830 == env52831) = true)

theorem identity52831 : scanCanonicalize (H12AffineFastState.compose env52831 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound52831 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env52832 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1029,269,1296,80,35,1345,162,1349,81,1029,153,16,1394,192,260,1150,1296,1297,2144,256,1280,256,261,1344,836]

theorem envBound52832 : H12AffineFastState.Bounded env52832 := by
  intro p hp
  have h : env52832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52831_52832 : H12AffineEnvironment.transform 11 1029 env52831 = env52832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env52831 == env52832) = true)

theorem identity52832 : scanCanonicalize (H12AffineFastState.compose env52832 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound52832 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env52833 : List Nat := [2,4,8,16,32,64,128,68,512,1024,2048,1029,73,1108,80,35,1029,162,1025,81,1029,153,16,1078,192,64,1150,1108,1109,2144,68,1092,68,65,1028,512]

theorem envBound52833 : H12AffineFastState.Bounded env52833 := by
  intro p hp
  have h : env52833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52832_52833 : H12AffineEnvironment.transform 7 68 env52832 = env52833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env52832 == env52833) = true)

theorem identity52833 : scanCanonicalize (H12AffineFastState.compose env52833 (packedSelected [0,2,5,7,8,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 237) := by decide +kernel

theorem selectedBound52833 : packedSelected [0,2,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env52834 : List Nat := [2,4,8,16,32,64,128,68,512,237,2048,232,73,185,80,35,232,162,236,81,232,153,16,219,192,64,147,185,184,2144,68,169,68,65,233,512]

theorem envBound52834 : H12AffineFastState.Bounded env52834 := by
  intro p hp
  have h : env52834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52833_52834 : H12AffineEnvironment.transform 9 237 env52833 = env52834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 237 env52833 == env52834) = true)

theorem identity52834 : scanCanonicalize (H12AffineFastState.compose env52834 (packedSelected [0,1,2,3,4,5,7,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound52834 : packedSelected [0,1,2,3,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env52835 : List Nat := [2,4,8,16,32,64,57,68,512,84,2048,81,73,0,80,35,81,27,85,81,81,32,16,98,121,64,42,0,1,2144,68,16,68,65,80,512]

theorem envBound52835 : H12AffineFastState.Bounded env52835 := by
  intro p hp
  have h : env52835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52834_52835 : H12AffineEnvironment.transform 6 57 env52834 = env52835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env52834 == env52835) = true)

theorem identity52835 : scanCanonicalize (H12AffineFastState.compose env52835 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound52835 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env52836 : List Nat := [2,4,8,16,32,64,57,68,49,84,2048,81,73,0,80,35,81,27,85,81,81,32,16,98,121,64,42,0,1,2144,68,16,68,65,80,49]

theorem envBound52836 : H12AffineFastState.Bounded env52836 := by
  intro p hp
  have h : env52836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52835_52836 : H12AffineEnvironment.transform 8 49 env52835 = env52836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env52835 == env52836) = true)

theorem identity52836 : scanCanonicalize (H12AffineFastState.compose env52836 (packedSelected [2,12] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound52836 : packedSelected [2,12] rootPS < 2^1333 := by decide +kernel

def env52837 : List Nat := [2,4,8,16,32,64,57,68,49,84,43,81,73,0,80,35,81,27,85,81,81,32,16,98,121,64,42,0,1,75,68,16,68,65,80,49]

theorem envBound52837 : H12AffineFastState.Bounded env52837 := by
  intro p hp
  have h : env52837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52836_52837 : H12AffineEnvironment.transform 10 43 env52836 = env52837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env52836 == env52837) = true)

theorem identity52837 : scanCanonicalize (H12AffineFastState.compose env52837 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound52837 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52838 : List Nat := [2,4,8,16,32,17,57,21,49,5,43,0,24,0,1,35,0,27,4,0,0,32,16,51,40,17,42,0,1,26,21,16,21,16,1,49]

theorem envBound52838 : H12AffineFastState.Bounded env52838 := by
  intro p hp
  have h : env52838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52837_52838 : H12AffineEnvironment.transform 5 17 env52837 = env52838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env52837 == env52838) = true)

theorem identity52838 : scanCanonicalize (H12AffineFastState.compose env52838 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound52838 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52839 : List Nat := [2,4,8,16,7,17,30,21,22,5,12,0,24,0,1,4,0,27,4,0,0,7,16,20,15,17,13,0,1,26,21,16,21,16,1,22]

theorem envBound52839 : H12AffineFastState.Bounded env52839 := by
  intro p hp
  have h : env52839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52838_52839 : H12AffineEnvironment.transform 4 7 env52838 = env52839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env52838 == env52839) = true)

theorem identity52839 : scanCanonicalize (H12AffineFastState.compose env52839 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound52839 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52840 : List Nat := [2,4,8,10,7,11,4,15,12,5,12,0,2,0,1,4,0,1,4,0,0,7,10,14,15,11,13,0,1,0,15,10,15,10,1,12]

theorem envBound52840 : H12AffineFastState.Bounded env52840 := by
  intro p hp
  have h : env52840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52839_52840 : H12AffineEnvironment.transform 3 10 env52839 = env52840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env52839 == env52840) = true)

theorem identity52840 : scanCanonicalize (H12AffineFastState.compose env52840 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound52840 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52841 : List Nat := [2,4,4,6,7,7,4,3,0,5,0,0,2,0,1,4,0,1,4,0,0,7,6,2,3,7,1,0,1,0,3,6,3,6,1,0]

theorem envBound52841 : H12AffineFastState.Bounded env52841 := by
  intro p hp
  have h : env52841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52840_52841 : H12AffineEnvironment.transform 2 4 env52840 = env52841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env52840 == env52841) = true)

def env52842 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5385,1296,5204,5158,1344,5287,4416,5205,4096,5276,17,4471,193,5376,1150,1297,1297,7268,5380,1280,256,5376,1344,5953]

theorem envBound52842 : H12AffineFastState.Bounded env52842 := by
  intro p hp
  have h : env52842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52830_52842 : H12AffineEnvironment.transform 12 5385 env52830 = env52842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5385 env52830 == env52842) = true)

theorem identity52842 : scanCanonicalize (H12AffineFastState.compose env52842 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound52842 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env52843 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,1368,1296,1029,1143,1344,1270,273,1028,81,1229,17,294,193,1361,1150,1297,1297,3125,1365,1280,256,1361,1344,1808]

theorem envBound52843 : H12AffineFastState.Bounded env52843 := by
  intro p hp
  have h : env52843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52842_52843 : H12AffineEnvironment.transform 11 81 env52842 = env52843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env52842 == env52843) = true)

theorem identity52843 : scanCanonicalize (H12AffineFastState.compose env52843 (packedSelected [0,2,3,5,7,10,11,12,15,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 754) := by decide +kernel

theorem selectedBound52843 : packedSelected [0,2,3,5,7,10,11,12,15,17,18,20] rootPS < 2^1333 := by decide +kernel

def env52844 : List Nat := [2,4,8,16,32,64,128,256,512,1024,754,81,1368,1296,1029,1143,1344,1270,273,1028,81,1229,17,294,193,1361,1150,1297,1297,1735,1365,1280,256,1361,1344,1808]

theorem envBound52844 : H12AffineFastState.Bounded env52844 := by
  intro p hp
  have h : env52844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52843_52844 : H12AffineEnvironment.transform 10 754 env52843 = env52844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 754 env52843 == env52844) = true)

theorem identity52844 : scanCanonicalize (H12AffineFastState.compose env52844 (packedSelected [1,5,8,13,28] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound52844 : packedSelected [1,5,8,13,28] rootPS < 2^1333 := by decide +kernel

def env52845 : List Nat := [2,4,8,16,32,64,128,256,512,84,754,81,268,324,81,35,276,162,273,80,81,153,17,294,193,261,42,325,325,659,257,340,256,261,276,836]

theorem envBound52845 : H12AffineFastState.Bounded env52845 := by
  intro p hp
  have h : env52845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52844_52845 : H12AffineEnvironment.transform 9 84 env52844 = env52845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env52844 == env52845) = true)

theorem identity52845 : scanCanonicalize (H12AffineFastState.compose env52845 (packedSelected [0,4,5,7,8,9,10,11,12,16] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound52845 : packedSelected [0,4,5,7,8,9,10,11,12,16] rootPS < 2^1333 := by decide +kernel

def env52846 : List Nat := [2,4,8,16,32,64,105,256,512,84,539,81,268,324,81,35,276,75,273,80,81,112,17,294,40,261,42,325,325,634,257,340,256,261,276,836]

theorem envBound52846 : H12AffineFastState.Bounded env52846 := by
  intro p hp
  have h : env52846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52845_52846 : H12AffineEnvironment.transform 6 105 env52845 = env52846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env52845 == env52846) = true)

theorem identity52846 : scanCanonicalize (H12AffineFastState.compose env52846 (packedSelected [3,4,8,9,11,12] rootPS)) = affineNative (2^(8+1) ^^^ 373) := by decide +kernel

theorem selectedBound52846 : packedSelected [3,4,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env52847 : List Nat := [2,4,8,16,32,64,105,256,373,84,366,81,268,324,81,35,276,75,273,80,81,112,17,294,40,261,42,325,325,271,257,340,256,261,276,49]

theorem envBound52847 : H12AffineFastState.Bounded env52847 := by
  intro p hp
  have h : env52847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52846_52847 : H12AffineEnvironment.transform 8 373 env52846 = env52847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 373 env52846 == env52847) = true)

theorem identity52847 : scanCanonicalize (H12AffineFastState.compose env52847 (packedSelected [4,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound52847 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env52848 : List Nat := [2,4,8,16,32,64,105,117,0,84,27,81,121,49,81,35,97,75,100,80,81,112,17,83,40,112,42,48,48,122,116,33,117,112,97,49]

theorem envBound52848 : H12AffineFastState.Bounded env52848 := by
  intro p hp
  have h : env52848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52847_52848 : H12AffineEnvironment.transform 7 117 env52847 = env52848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env52847 == env52848) = true)

theorem identity52848 : scanCanonicalize (H12AffineFastState.compose env52848 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound52848 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env52849 : List Nat := [2,4,8,16,32,11,34,62,0,31,27,26,50,49,26,35,42,0,47,27,26,59,17,24,40,59,42,48,48,49,63,33,62,59,42,49]

theorem envBound52849 : H12AffineFastState.Bounded env52849 := by
  intro p hp
  have h : env52849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52848_52849 : H12AffineEnvironment.transform 5 11 env52848 = env52849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env52848 == env52849) = true)

theorem identity52849 : scanCanonicalize (H12AffineFastState.compose env52849 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound52849 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env52850 : List Nat := [2,4,8,10,32,11,34,36,0,5,1,0,40,43,0,35,42,0,47,1,0,33,11,2,40,33,42,42,42,43,37,33,36,33,42,43]

theorem envBound52850 : H12AffineFastState.Bounded env52850 := by
  intro p hp
  have h : env52850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52849_52850 : H12AffineEnvironment.transform 3 10 env52849 = env52850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env52849 == env52850) = true)

theorem identity52850 : scanCanonicalize (H12AffineFastState.compose env52850 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound52850 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52851 : List Nat := [2,4,5,7,32,6,34,36,0,5,1,0,37,38,0,35,39,0,34,1,0,33,6,2,37,33,39,39,39,38,37,33,36,33,39,38]

theorem envBound52851 : H12AffineFastState.Bounded env52851 := by
  intro p hp
  have h : env52851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52850_52851 : H12AffineEnvironment.transform 2 5 env52850 = env52851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env52850 == env52851) = true)

theorem identity52851 : scanCanonicalize (H12AffineFastState.compose env52851 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound52851 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52852 : List Nat := [2,4,5,7,6,6,4,2,0,5,1,0,3,0,0,5,1,0,4,1,0,7,6,2,3,7,1,1,1,0,3,7,2,7,1,0]

theorem envBound52852 : H12AffineFastState.Bounded env52852 := by
  intro p hp
  have h : env52852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52851_52852 : H12AffineEnvironment.transform 4 6 env52851 = env52852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env52851 == env52852) = true)

def env52853 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74863,262144,4417,8541,4096,5276,74047,66897,13769,78895,328959,74815,1297,81226,8204,1280,256,65831,1344,5952]

theorem envBound52853 : H12AffineFastState.Bounded env52853 := by
  intro p hp
  have h : env52853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52809_52853 : H12AffineEnvironment.transform 13 1297 env52809 = env52853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env52809 == env52853) = true)

def env52854 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74863,65664,4417,8541,4096,5276,74047,66897,13769,78895,1151,74815,1297,81226,8204,1280,256,65831,1344,5952]

theorem envBound52854 : H12AffineFastState.Bounded env52854 := by
  intro p hp
  have h : env52854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52853_52854 : H12AffineEnvironment.transform 17 65664 env52853 = env52854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env52853 == env52854) = true)

theorem identity52854 : scanCanonicalize (H12AffineFastState.compose env52854 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12591) := by decide +kernel

theorem selectedBound52854 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env52855 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,12591,5440,12719,4417,8541,4096,5276,4112,13438,13769,1280,1151,5392,1297,3173,8204,1280,256,12296,1344,5952]

theorem envBound52855 : H12AffineFastState.Bounded env52855 := by
  intro p hp
  have h : env52855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52854_52855 : H12AffineEnvironment.transform 15 12591 env52854 = env52855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12591 env52854 == env52855) = true)

def env52856 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,8192,1297,8540,8495,1344,8623,321,8541,0,1180,16,9342,9673,1280,1151,1296,1297,3173,8204,1280,256,8200,1344,1856]

theorem envBound52856 : H12AffineFastState.Bounded env52856 := by
  intro p hp
  have h : env52856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52855_52856 : H12AffineEnvironment.transform 11 0 env52855 = env52856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env52855 == env52856) = true)

theorem identity52856 : scanCanonicalize (H12AffineFastState.compose env52856 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound52856 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env52857 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,25,1297,325,310,1344,438,321,324,0,1180,16,1127,1488,1280,1151,1296,1297,3173,21,1280,256,17,1344,1856]

theorem envBound52857 : H12AffineFastState.Bounded env52857 := by
  intro p hp
  have h : env52857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52856_52857 : H12AffineEnvironment.transform 12 25 env52856 = env52857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env52856 == env52857) = true)

theorem identity52857 : scanCanonicalize (H12AffineFastState.compose env52857 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,16,18,20] rootPS)) = affineNative (2^(9+1) ^^^ 969) := by decide +kernel

theorem selectedBound52857 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,16,18,20] rootPS < 2^1333 := by decide +kernel

def env52858 : List Nat := [2,4,8,16,32,64,128,256,512,969,2048,0,25,728,325,310,649,438,321,324,0,853,16,942,537,713,950,729,728,2988,21,713,256,17,649,137]

theorem envBound52858 : H12AffineFastState.Bounded env52858 := by
  intro p hp
  have h : env52858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52857_52858 : H12AffineEnvironment.transform 9 969 env52857 = env52858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 969 env52857 == env52858) = true)

theorem identity52858 : scanCanonicalize (H12AffineFastState.compose env52858 (packedSelected [0,1,2,3,7,8,10,11,12,13,15,16,23,24] rootPS)) = affineNative (2^(8+1) ^^^ 460) := by decide +kernel

theorem selectedBound52858 : packedSelected [0,1,2,3,7,8,10,11,12,13,15,16,23,24] rootPS < 2^1333 := by decide +kernel

def env52859 : List Nat := [2,4,8,16,32,64,128,256,460,5,2048,0,25,276,325,310,325,438,321,324,0,153,16,98,469,261,122,277,276,2144,21,261,256,17,325,137]

theorem envBound52859 : H12AffineFastState.Bounded env52859 := by
  intro p hp
  have h : env52859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52858_52859 : H12AffineEnvironment.transform 8 460 env52858 = env52859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 460 env52858 == env52859) = true)

theorem identity52859 : scanCanonicalize (H12AffineFastState.compose env52859 (packedSelected [0,3,5,7,11,12,13,15] rootPS)) = affineNative (2^(6+1) ^^^ 114) := by decide +kernel

theorem selectedBound52859 : packedSelected [0,3,5,7,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env52860 : List Nat := [2,4,8,16,32,64,114,256,318,5,2048,0,25,276,325,310,325,324,321,324,0,107,16,98,295,261,122,277,276,2144,21,261,256,17,325,123]

theorem envBound52860 : H12AffineFastState.Bounded env52860 := by
  intro p hp
  have h : env52860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52859_52860 : H12AffineEnvironment.transform 6 114 env52859 = env52860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 114 env52859 == env52860) = true)

theorem identity52860 : scanCanonicalize (H12AffineFastState.compose env52860 (packedSelected [0,3,4,5,7,9,10,11,12,13,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound52860 : packedSelected [0,3,4,5,7,9,10,11,12,13,16] rootPS < 2^1333 := by decide +kernel

def env52861 : List Nat := [2,4,8,16,32,16,34,256,318,5,2048,0,25,276,277,310,277,276,273,276,0,59,16,50,295,261,42,277,276,2096,21,261,256,17,277,43]

theorem envBound52861 : H12AffineFastState.Bounded env52861 := by
  intro p hp
  have h : env52861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52860_52861 : H12AffineEnvironment.transform 5 16 env52860 = env52861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52860 == env52861) = true)

theorem identity52861 : scanCanonicalize (H12AffineFastState.compose env52861 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound52861 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env52862 : List Nat := [2,4,8,11,32,11,34,256,293,5,2048,0,2,271,270,301,270,271,266,271,0,32,11,41,295,261,42,270,271,2091,14,261,256,10,270,43]

theorem envBound52862 : H12AffineFastState.Bounded env52862 := by
  intro p hp
  have h : env52862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52861_52862 : H12AffineEnvironment.transform 3 11 env52861 = env52862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env52861 == env52862) = true)

theorem identity52862 : scanCanonicalize (H12AffineFastState.compose env52862 (packedSelected [1,2,5] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound52862 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env52863 : List Nat := [2,4,8,11,32,11,34,256,293,5,0,0,2,271,270,301,270,271,266,271,0,32,11,41,295,261,42,270,271,43,14,261,256,10,270,43]

theorem envBound52863 : H12AffineFastState.Bounded env52863 := by
  intro p hp
  have h : env52863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52862_52863 : H12AffineEnvironment.transform 10 0 env52862 = env52863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env52862 == env52863) = true)

theorem identity52863 : scanCanonicalize (H12AffineFastState.compose env52863 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound52863 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env52864 : List Nat := [2,4,8,11,32,11,34,37,0,5,0,0,2,42,43,8,43,42,47,42,0,32,11,41,2,32,42,43,42,43,14,32,37,10,43,43]

theorem envBound52864 : H12AffineFastState.Bounded env52864 := by
  intro p hp
  have h : env52864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52863_52864 : H12AffineEnvironment.transform 7 37 env52863 = env52864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env52863 == env52864) = true)

theorem identity52864 : scanCanonicalize (H12AffineFastState.compose env52864 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound52864 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env52865 : List Nat := [2,4,8,11,10,11,8,15,0,5,0,0,2,0,1,8,1,0,5,0,0,10,11,3,2,10,0,1,0,1,14,10,15,10,1,1]

theorem envBound52865 : H12AffineFastState.Bounded env52865 := by
  intro p hp
  have h : env52865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52864_52865 : H12AffineEnvironment.transform 4 10 env52864 = env52865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env52864 == env52865) = true)

theorem identity52865 : scanCanonicalize (H12AffineFastState.compose env52865 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound52865 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env52866 : List Nat := [2,1,8,11,10,11,8,10,0,0,0,0,2,0,1,8,1,0,0,0,0,10,11,3,2,10,0,1,0,1,11,10,10,10,1,1]

theorem envBound52866 : H12AffineFastState.Bounded env52866 := by
  intro p hp
  have h : env52866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52865_52866 : H12AffineEnvironment.transform 1 1 env52865 = env52866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env52865 == env52866) = true)

theorem identity52866 : scanCanonicalize (H12AffineFastState.compose env52866 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound52866 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env52867 : List Nat := [2,1,1,2,3,2,1,3,0,0,0,0,2,0,1,1,1,0,0,0,0,3,2,3,2,3,0,1,0,1,2,3,3,3,1,1]

theorem envBound52867 : H12AffineFastState.Bounded env52867 := by
  intro p hp
  have h : env52867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52866_52867 : H12AffineEnvironment.transform 2 1 env52866 = env52867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env52866 == env52867) = true)

theorem identity52867 : scanCanonicalize (H12AffineFastState.compose env52867 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound52867 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env52868 : List Nat := [0,1,1,0,1,0,1,1,0,0,0,0,0,0,1,1,1,0,0,0,0,1,0,1,0,1,0,1,0,1,0,1,1,1,1,1]

theorem envBound52868 : H12AffineFastState.Bounded env52868 := by
  intro p hp
  have h : env52868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52867_52868 : H12AffineEnvironment.transform 0 0 env52867 = env52868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env52867 == env52868) = true)

def env52869 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1297,8540,8494,1345,8622,320,8541,1,1181,17,9343,9672,1280,1151,1297,1297,3173,8204,1280,256,8201,1344,1857]

theorem envBound52869 : H12AffineFastState.Bounded env52869 := by
  intro p hp
  have h : env52869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52855_52869 : H12AffineEnvironment.transform 11 1 env52855 = env52869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env52855 == env52869) = true)

theorem identity52869 : scanCanonicalize (H12AffineFastState.compose env52869 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound52869 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env52870 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,1101,1297,1297,1379,1345,1507,320,1296,1,1181,17,50,389,1280,1151,1297,1297,3173,1089,1280,256,1092,1344,1857]

theorem envBound52870 : H12AffineFastState.Bounded env52870 := by
  intro p hp
  have h : env52870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52869_52870 : H12AffineEnvironment.transform 12 1101 env52869 = env52870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env52869 == env52870) = true)

theorem identity52870 : scanCanonicalize (H12AffineFastState.compose env52870 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound52870 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env52871 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,268,80,80,34,0,162,320,81,1,476,17,50,389,65,318,80,80,2340,256,65,256,261,1,512]

theorem envBound52871 : H12AffineFastState.Bounded env52871 := by
  intro p hp
  have h : env52871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52870_52871 : H12AffineEnvironment.transform 9 321 env52870 = env52871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env52870 == env52871) = true)

theorem identity52871 : scanCanonicalize (H12AffineFastState.compose env52871 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound52871 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env52872 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,1,268,0,0,34,0,162,272,1,1,396,17,50,389,17,318,0,0,2340,256,17,256,261,1,512]

theorem envBound52872 : H12AffineFastState.Bounded env52872 := by
  intro p hp
  have h : env52872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52871_52872 : H12AffineEnvironment.transform 5 16 env52871 = env52872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52871 == env52872) = true)

theorem identity52872 : scanCanonicalize (H12AffineFastState.compose env52872 (packedSelected [1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 439) := by decide +kernel

theorem selectedBound52872 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env52873 : List Nat := [2,4,8,16,32,16,128,256,439,273,2048,1,268,0,0,34,0,162,272,1,1,396,17,50,389,17,318,0,0,2340,256,17,256,261,1,439]

theorem envBound52873 : H12AffineFastState.Bounded env52873 := by
  intro p hp
  have h : env52873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52872_52873 : H12AffineEnvironment.transform 8 439 env52872 = env52873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 439 env52872 == env52873) = true)

theorem identity52873 : scanCanonicalize (H12AffineFastState.compose env52873 (packedSelected [3,8] rootPS)) = affineNative (2^(7+1) ^^^ 134) := by decide +kernel

theorem selectedBound52873 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env52874 : List Nat := [2,4,8,16,32,16,128,134,49,151,2048,1,138,0,0,34,0,162,150,1,1,10,17,50,3,17,184,0,0,2210,134,17,134,131,1,49]

theorem envBound52874 : H12AffineFastState.Bounded env52874 := by
  intro p hp
  have h : env52874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52873_52874 : H12AffineEnvironment.transform 7 134 env52873 = env52874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 134 env52873 == env52874) = true)

theorem identity52874 : scanCanonicalize (H12AffineFastState.compose env52874 (packedSelected [0,1,2,4,7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound52874 : packedSelected [0,1,2,4,7] rootPS < 2^1333 := by decide +kernel

def env52875 : List Nat := [2,4,8,16,32,16,8,14,49,31,2048,1,2,0,0,34,0,42,30,1,1,10,17,50,3,17,48,0,0,2090,14,17,14,11,1,49]

theorem envBound52875 : H12AffineFastState.Bounded env52875 := by
  intro p hp
  have h : env52875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52874_52875 : H12AffineEnvironment.transform 6 8 env52874 = env52875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env52874 == env52875) = true)

theorem identity52875 : scanCanonicalize (H12AffineFastState.compose env52875 (packedSelected [1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound52875 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env52876 : List Nat := [2,4,8,16,32,16,8,14,49,31,43,1,2,0,0,34,0,42,30,1,1,10,17,50,3,17,48,0,0,1,14,17,14,11,1,49]

theorem envBound52876 : H12AffineFastState.Bounded env52876 := by
  intro p hp
  have h : env52876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52875_52876 : H12AffineEnvironment.transform 10 43 env52875 = env52876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env52875 == env52876) = true)

theorem identity52876 : scanCanonicalize (H12AffineFastState.compose env52876 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound52876 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env52877 : List Nat := [2,4,8,16,16,16,8,14,1,31,27,1,2,0,0,18,0,26,30,1,1,10,17,2,3,17,0,0,0,1,14,17,14,11,1,1]

theorem envBound52877 : H12AffineFastState.Bounded env52877 := by
  intro p hp
  have h : env52877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52876_52877 : H12AffineEnvironment.transform 4 16 env52876 = env52877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env52876 == env52877) = true)

def env52878 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74863,65665,4417,8541,4096,5276,74047,66897,13769,78895,1150,74815,1297,81226,8204,1280,256,65831,1344,5952]

theorem envBound52878 : H12AffineFastState.Bounded env52878 := by
  intro p hp
  have h : env52878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52853_52878 : H12AffineEnvironment.transform 17 65665 env52853 = env52878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env52853 == env52878) = true)

theorem identity52878 : scanCanonicalize (H12AffineFastState.compose env52878 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9326) := by decide +kernel

theorem selectedBound52878 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env52879 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,9326,1,9455,4417,8541,4096,5276,1361,8511,13769,4161,1150,81,1297,6436,8204,1280,256,9545,1344,5952]

theorem envBound52879 : H12AffineFastState.Bounded env52879 := by
  intro p hp
  have h : env52879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52878_52879 : H12AffineEnvironment.transform 15 9326 env52878 = env52879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9326 env52878 == env52879) = true)

def env52880 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,81,8540,8494,1,8623,4417,8541,4096,4572,17,8511,12425,4161,318,81,81,6436,8204,64,256,8201,0,4608]

theorem envBound52880 : H12AffineFastState.Bounded env52880 := by
  intro p hp
  have h : env52880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52879_52880 : H12AffineEnvironment.transform 9 320 env52879 = env52880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env52879 == env52880) = true)

theorem identity52880 : scanCanonicalize (H12AffineFastState.compose env52880 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 4364) := by decide +kernel

theorem selectedBound52880 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env52881 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,4364,81,4176,4130,1,4259,4417,4177,4096,4572,17,4147,389,4161,318,81,81,6436,4352,64,256,4357,0,4608]

theorem envBound52881 : H12AffineFastState.Bounded env52881 := by
  intro p hp
  have h : env52881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52880_52881 : H12AffineEnvironment.transform 12 4364 env52880 = env52881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4364 env52880 == env52881) = true)

theorem identity52881 : scanCanonicalize (H12AffineFastState.compose env52881 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound52881 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env52882 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,0,268,81,80,34,1,163,321,81,0,476,17,51,389,65,318,81,81,2340,256,64,256,261,0,512]

theorem envBound52882 : H12AffineFastState.Bounded env52882 := by
  intro p hp
  have h : env52882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52881_52882 : H12AffineEnvironment.transform 11 0 env52881 = env52882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env52881 == env52882) = true)

theorem identity52882 : scanCanonicalize (H12AffineFastState.compose env52882 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound52882 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env52883 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,0,268,1,0,34,1,163,273,1,0,396,17,51,389,17,318,1,1,2340,256,16,256,261,0,512]

theorem envBound52883 : H12AffineFastState.Bounded env52883 := by
  intro p hp
  have h : env52883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52882_52883 : H12AffineEnvironment.transform 5 16 env52882 = env52883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env52882 == env52883) = true)

theorem identity52883 : scanCanonicalize (H12AffineFastState.compose env52883 (packedSelected [1,2,5] rootPS)) = affineNative (2^(10+1) ^^^ 648) := by decide +kernel

theorem selectedBound52883 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env52884 : List Nat := [2,4,8,16,32,16,128,256,512,272,648,0,268,1,0,34,1,163,273,1,0,396,17,51,389,17,318,1,1,940,256,16,256,261,0,512]

theorem envBound52884 : H12AffineFastState.Bounded env52884 := by
  intro p hp
  have h : env52884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52883_52884 : H12AffineEnvironment.transform 10 648 env52883 = env52884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 648 env52883 == env52884) = true)

theorem identity52884 : scanCanonicalize (H12AffineFastState.compose env52884 (packedSelected [3,8] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound52884 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env52885 : List Nat := [2,4,8,16,32,16,128,256,137,272,1,0,268,1,0,34,1,163,273,1,0,396,17,51,389,17,318,1,1,293,256,16,256,261,0,137]

theorem envBound52885 : H12AffineFastState.Bounded env52885 := by
  intro p hp
  have h : env52885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52884_52885 : H12AffineEnvironment.transform 8 137 env52884 = env52885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env52884 == env52885) = true)

end H12CloudChart2