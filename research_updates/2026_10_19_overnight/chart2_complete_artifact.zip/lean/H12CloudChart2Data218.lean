import H12CloudChart2Data217

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env54954 : List Nat := [2,4,8,16,32,16,128,21,137,47,1,43,24,42,0,35,42,162,46,1,43,152,16,24,145,16,1,43,43,48,21,59,21,17,42,137]

theorem envBound54954 : H12AffineFastState.Bounded env54954 := by
  intro p hp
  have h : env54954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54953_54954 : H12AffineEnvironment.transform 9 47 env54953 = env54954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env54953 == env54954) = true)

theorem identity54954 : scanCanonicalize (H12AffineFastState.compose env54954 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound54954 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env54955 : List Nat := [2,4,8,16,32,16,8,21,1,47,1,43,24,42,0,35,42,42,46,1,43,16,16,24,25,16,1,43,43,48,21,59,21,17,42,1]

theorem envBound54955 : H12AffineFastState.Bounded env54955 := by
  intro p hp
  have h : env54955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54954_54955 : H12AffineEnvironment.transform 6 8 env54954 = env54955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env54954 == env54955) = true)

theorem identity54955 : scanCanonicalize (H12AffineFastState.compose env54955 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound54955 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env54956 : List Nat := [2,4,8,16,17,16,8,21,1,30,1,26,24,27,0,18,27,27,31,1,26,16,16,24,25,16,1,26,26,1,21,10,21,17,27,1]

theorem envBound54956 : H12AffineFastState.Bounded env54956 := by
  intro p hp
  have h : env54956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54955_54956 : H12AffineEnvironment.transform 4 17 env54955 = env54956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env54955 == env54956) = true)

def env54957 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,25,1296,324,310,1345,439,4416,325,4096,5276,17,1127,5585,5376,1150,1296,1297,7268,20,1281,256,17,1344,5953]

theorem envBound54957 : H12AffineFastState.Bounded env54957 := by
  intro p hp
  have h : env54957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54947_54957 : H12AffineEnvironment.transform 12 25 env54947 = env54957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env54947 == env54957) = true)

theorem identity54957 : scanCanonicalize (H12AffineFastState.compose env54957 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound54957 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env54958 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,25,1296,324,310,1345,439,321,325,1,1181,17,1127,1488,1281,1150,1296,1297,3173,20,1281,256,17,1344,1856]

theorem envBound54958 : H12AffineFastState.Bounded env54958 := by
  intro p hp
  have h : env54958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54957_54958 : H12AffineEnvironment.transform 11 1 env54957 = env54958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env54957 == env54958) = true)

theorem identity54958 : scanCanonicalize (H12AffineFastState.compose env54958 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,16,18,20] rootPS)) = affineNative (2^(9+1) ^^^ 969) := by decide +kernel

theorem selectedBound54958 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,16,18,20] rootPS < 2^1333 := by decide +kernel

def env54959 : List Nat := [2,4,8,16,32,64,128,256,512,969,2048,1,25,729,324,310,648,439,321,325,1,852,17,942,537,712,951,729,728,2988,20,712,256,17,649,137]

theorem envBound54959 : H12AffineFastState.Bounded env54959 := by
  intro p hp
  have h : env54959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54958_54959 : H12AffineEnvironment.transform 9 969 env54958 = env54959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 969 env54958 == env54959) = true)

theorem identity54959 : scanCanonicalize (H12AffineFastState.compose env54959 (packedSelected [0,1,2,3,7,8,10,11,12,13,15,16,23,24] rootPS)) = affineNative (2^(8+1) ^^^ 461) := by decide +kernel

theorem selectedBound54959 : packedSelected [0,1,2,3,7,8,10,11,12,13,15,16,23,24] rootPS < 2^1333 := by decide +kernel

def env54960 : List Nat := [2,4,8,16,32,64,128,256,461,4,2048,1,25,276,324,310,325,439,321,325,1,153,17,99,468,261,122,276,277,2145,20,261,256,17,324,137]

theorem envBound54960 : H12AffineFastState.Bounded env54960 := by
  intro p hp
  have h : env54960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54959_54960 : H12AffineEnvironment.transform 8 461 env54959 = env54960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 461 env54959 == env54960) = true)

theorem identity54960 : scanCanonicalize (H12AffineFastState.compose env54960 (packedSelected [0,3,5,7,11,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound54960 : packedSelected [0,3,5,7,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env54961 : List Nat := [2,4,8,16,32,64,128,256,461,4,292,1,25,276,324,310,325,439,321,325,1,153,17,99,468,261,122,276,277,325,20,261,256,17,324,137]

theorem envBound54961 : H12AffineFastState.Bounded env54961 := by
  intro p hp
  have h : env54961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54960_54961 : H12AffineEnvironment.transform 10 292 env54960 = env54961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env54960 == env54961) = true)

theorem identity54961 : scanCanonicalize (H12AffineFastState.compose env54961 (packedSelected [1,4,8,9,10,12,13,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound54961 : packedSelected [1,4,8,9,10,12,13,16] rootPS < 2^1333 := by decide +kernel

def env54962 : List Nat := [2,4,8,16,32,16,128,256,413,4,292,1,25,276,276,310,277,439,273,277,1,153,17,51,388,261,42,276,277,277,20,261,256,17,276,137]

theorem envBound54962 : H12AffineFastState.Bounded env54962 := by
  intro p hp
  have h : env54962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54961_54962 : H12AffineEnvironment.transform 5 16 env54961 = env54962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54961 == env54962) = true)

def env54963 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74862,262144,4417,8541,4096,5276,74047,66897,13769,78895,328959,74814,1297,81226,8204,1281,256,65830,1344,5952]

theorem envBound54963 : H12AffineFastState.Bounded env54963 := by
  intro p hp
  have h : env54963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54920_54963 : H12AffineEnvironment.transform 13 1297 env54920 = env54963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env54920 == env54963) = true)

def env54964 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74862,65664,4417,8541,4096,5276,74047,66897,13769,78895,1151,74814,1297,81226,8204,1281,256,65830,1344,5952]

theorem envBound54964 : H12AffineFastState.Bounded env54964 := by
  intro p hp
  have h : env54964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54963_54964 : H12AffineEnvironment.transform 17 65664 env54963 = env54964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env54963 == env54964) = true)

theorem identity54964 : scanCanonicalize (H12AffineFastState.compose env54964 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9279) := by decide +kernel

theorem selectedBound54964 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env54965 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,9279,81,9407,4417,8541,4096,5276,1280,8558,13769,4112,1151,1,1297,6517,8204,1281,256,9497,1344,5952]

theorem envBound54965 : H12AffineFastState.Bounded env54965 := by
  intro p hp
  have h : env54965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54964_54965 : H12AffineEnvironment.transform 15 9279 env54964 = env54965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9279 env54964 == env54965) = true)

def env54966 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,1,8540,8495,81,8623,4417,8541,4096,4492,16,8558,12505,4112,367,1,1,6517,8204,17,256,8201,80,4688]

theorem envBound54966 : H12AffineFastState.Bounded env54966 := by
  intro p hp
  have h : env54966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54965_54966 : H12AffineEnvironment.transform 9 272 env54965 = env54966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env54965 == env54966) = true)

theorem identity54966 : scanCanonicalize (H12AffineFastState.compose env54966 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 72) := by decide +kernel

theorem selectedBound54966 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env54967 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,72,1,276,359,81,487,4417,277,4096,4492,16,294,4241,4112,367,1,1,6517,68,17,256,65,80,4688]

theorem envBound54967 : H12AffineFastState.Bounded env54967 := by
  intro p hp
  have h : env54967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54966_54967 : H12AffineEnvironment.transform 12 72 env54966 = env54967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env54966 == env54967) = true)

theorem identity54967 : scanCanonicalize (H12AffineFastState.compose env54967 (packedSelected [0,2,3,5,7,10,11,12,15,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 754) := by decide +kernel

theorem selectedBound54967 : packedSelected [0,2,3,5,7,10,11,12,15,17,18,20] rootPS < 2^1333 := by decide +kernel

def env54968 : List Nat := [2,4,8,16,32,64,128,256,512,272,754,4096,72,1,276,359,81,487,4417,277,4096,4492,16,294,4241,4112,367,1,1,4999,68,17,256,65,80,4688]

theorem envBound54968 : H12AffineFastState.Bounded env54968 := by
  intro p hp
  have h : env54968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54967_54968 : H12AffineEnvironment.transform 10 754 env54967 = env54968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 754 env54967 == env54968) = true)

theorem identity54968 : scanCanonicalize (H12AffineFastState.compose env54968 (packedSelected [1,5,8,13,28] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound54968 : packedSelected [1,5,8,13,28] rootPS < 2^1333 := by decide +kernel

def env54969 : List Nat := [2,4,8,16,32,64,128,256,512,272,754,184,72,1,276,359,81,487,505,277,184,308,16,294,41,168,367,1,1,831,68,17,256,65,80,744]

theorem envBound54969 : H12AffineFastState.Bounded env54969 := by
  intro p hp
  have h : env54969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54968_54969 : H12AffineEnvironment.transform 11 184 env54968 = env54969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env54968 == env54969) = true)

theorem identity54969 : scanCanonicalize (H12AffineFastState.compose env54969 (packedSelected [2,4,5,8,9,10,11,12,13,15,17] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound54969 : packedSelected [2,4,5,8,9,10,11,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env54970 : List Nat := [2,4,8,16,32,64,128,173,512,189,754,184,72,1,185,202,81,74,84,184,184,153,16,139,41,168,194,1,1,658,68,17,173,65,80,744]

theorem envBound54970 : H12AffineFastState.Bounded env54970 := by
  intro p hp
  have h : env54970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54969_54970 : H12AffineEnvironment.transform 7 173 env54969 = env54970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env54969 == env54970) = true)

theorem identity54970 : scanCanonicalize (H12AffineFastState.compose env54970 (packedSelected [0,2,3,7,8,11,13] rootPS)) = affineNative (2^(8+1) ^^^ 216) := by decide +kernel

theorem selectedBound54970 : packedSelected [0,2,3,7,8,11,13] rootPS < 2^1333 := by decide +kernel

def env54971 : List Nat := [2,4,8,16,32,64,128,173,216,189,42,184,72,1,185,202,81,74,84,184,184,153,16,139,41,168,194,1,1,74,68,17,173,65,80,48]

theorem envBound54971 : H12AffineFastState.Bounded env54971 := by
  intro p hp
  have h : env54971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54970_54971 : H12AffineEnvironment.transform 8 216 env54970 = env54971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env54970 == env54971) = true)

theorem identity54971 : scanCanonicalize (H12AffineFastState.compose env54971 (packedSelected [1,3,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 114) := by decide +kernel

theorem selectedBound54971 : packedSelected [1,3,7,9] rootPS < 2^1333 := by decide +kernel

def env54972 : List Nat := [2,4,8,16,32,64,114,95,42,79,42,74,72,1,75,56,81,74,84,74,74,107,16,121,41,90,48,1,1,74,68,17,95,65,80,48]

theorem envBound54972 : H12AffineFastState.Bounded env54972 := by
  intro p hp
  have h : env54972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54971_54972 : H12AffineEnvironment.transform 6 114 env54971 = env54972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 114 env54971 == env54972) = true)

theorem identity54972 : scanCanonicalize (H12AffineFastState.compose env54972 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound54972 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env54973 : List Nat := [2,4,8,16,32,33,19,62,42,46,42,43,41,1,42,56,48,43,53,43,43,10,16,24,41,59,48,1,1,43,37,17,62,32,49,48]

theorem envBound54973 : H12AffineFastState.Bounded env54973 := by
  intro p hp
  have h : env54973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54972_54973 : H12AffineEnvironment.transform 5 33 env54972 = env54973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env54972 == env54973) = true)

def env54974 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,0,8540,8494,81,8622,4417,8541,4096,4493,17,8558,12504,4112,366,1,0,6517,8204,16,256,8200,81,4689]

theorem envBound54974 : H12AffineFastState.Bounded env54974 := by
  intro p hp
  have h : env54974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54965_54974 : H12AffineEnvironment.transform 9 273 env54965 = env54974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env54965 == env54974) = true)

theorem identity54974 : scanCanonicalize (H12AffineFastState.compose env54974 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound54974 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env54975 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,268,0,80,34,81,162,4417,81,4096,4493,17,98,4564,4112,366,1,0,6517,256,16,256,260,81,4689]

theorem envBound54975 : H12AffineFastState.Bounded env54975 := by
  intro p hp
  have h : env54975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54974_54975 : H12AffineEnvironment.transform 12 268 env54974 = env54975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env54974 == env54975) = true)

theorem identity54975 : scanCanonicalize (H12AffineFastState.compose env54975 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound54975 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env54976 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,81,268,0,80,34,81,162,272,81,81,476,17,98,389,65,366,1,0,2340,256,16,256,260,81,512]

theorem envBound54976 : H12AffineFastState.Bounded env54976 := by
  intro p hp
  have h : env54976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54975_54976 : H12AffineEnvironment.transform 11 81 env54975 = env54976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env54975 == env54976) = true)

theorem identity54976 : scanCanonicalize (H12AffineFastState.compose env54976 (packedSelected [2,5,8,13] rootPS)) = affineNative (2^(10+1) ^^^ 470) := by decide +kernel

theorem selectedBound54976 : packedSelected [2,5,8,13] rootPS < 2^1333 := by decide +kernel

def env54977 : List Nat := [2,4,8,16,32,64,128,256,512,273,470,81,268,0,80,34,81,162,272,81,81,476,17,98,389,65,366,1,0,242,256,16,256,260,81,512]

theorem envBound54977 : H12AffineFastState.Bounded env54977 := by
  intro p hp
  have h : env54977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54976_54977 : H12AffineEnvironment.transform 10 470 env54976 = env54977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 470 env54976 == env54977) = true)

theorem identity54977 : scanCanonicalize (H12AffineFastState.compose env54977 (packedSelected [0,1,2,4,7,8,9,10] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound54977 : packedSelected [0,1,2,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env54978 : List Nat := [2,4,8,16,32,64,128,256,48,273,470,81,268,0,80,34,81,162,272,81,81,476,17,98,389,65,366,1,0,242,256,16,256,260,81,48]

theorem envBound54978 : H12AffineFastState.Bounded env54978 := by
  intro p hp
  have h : env54978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54977_54978 : H12AffineEnvironment.transform 8 48 env54977 = env54978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env54977 == env54978) = true)

theorem identity54978 : scanCanonicalize (H12AffineFastState.compose env54978 (packedSelected [0,2,3,7,8,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound54978 : packedSelected [0,2,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env54979 : List Nat := [2,4,8,16,32,16,128,256,48,273,390,1,268,0,0,34,1,162,272,1,1,396,17,50,389,17,318,1,0,162,256,16,256,260,1,48]

theorem envBound54979 : H12AffineFastState.Bounded env54979 := by
  intro p hp
  have h : env54979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54978_54979 : H12AffineEnvironment.transform 5 16 env54978 = env54979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54978 == env54979) = true)

theorem identity54979 : scanCanonicalize (H12AffineFastState.compose env54979 (packedSelected [1,2,5] rootPS)) = affineNative (2^(7+1) ^^^ 135) := by decide +kernel

theorem selectedBound54979 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env54980 : List Nat := [2,4,8,16,32,16,128,135,48,150,1,1,139,0,0,34,1,162,151,1,1,11,17,50,2,17,185,1,0,162,135,16,135,131,1,48]

theorem envBound54980 : H12AffineFastState.Bounded env54980 := by
  intro p hp
  have h : env54980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54979_54980 : H12AffineEnvironment.transform 7 135 env54979 = env54980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 135 env54979 == env54980) = true)

theorem identity54980 : scanCanonicalize (H12AffineFastState.compose env54980 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound54980 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env54981 : List Nat := [2,4,8,16,32,16,8,15,48,30,1,1,3,0,0,34,1,42,31,1,1,11,17,50,2,17,49,1,0,42,15,16,15,11,1,48]

theorem envBound54981 : H12AffineFastState.Bounded env54981 := by
  intro p hp
  have h : env54981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54980_54981 : H12AffineEnvironment.transform 6 8 env54980 = env54981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env54980 == env54981) = true)

theorem identity54981 : scanCanonicalize (H12AffineFastState.compose env54981 (packedSelected [0,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound54981 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env54982 : List Nat := [2,4,8,11,32,11,8,15,43,5,1,1,3,0,0,34,1,42,4,1,1,11,10,41,2,10,42,1,0,42,15,11,15,11,1,43]

theorem envBound54982 : H12AffineFastState.Bounded env54982 := by
  intro p hp
  have h : env54982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54981_54982 : H12AffineEnvironment.transform 3 11 env54981 = env54982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env54981 == env54982) = true)

theorem identity54982 : scanCanonicalize (H12AffineFastState.compose env54982 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound54982 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54983 : List Nat := [2,4,8,11,7,11,8,15,12,5,1,1,3,0,0,5,1,13,4,1,1,11,10,14,2,10,13,1,0,13,15,11,15,11,1,12]

theorem envBound54983 : H12AffineFastState.Bounded env54983 := by
  intro p hp
  have h : env54983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54982_54983 : H12AffineEnvironment.transform 4 7 env54982 = env54983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env54982 == env54983) = true)

theorem identity54983 : scanCanonicalize (H12AffineFastState.compose env54983 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound54983 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54984 : List Nat := [2,4,4,7,7,7,4,3,0,5,1,1,3,0,0,5,1,1,4,1,1,7,6,2,2,6,1,1,0,1,3,7,3,7,1,0]

theorem envBound54984 : H12AffineFastState.Bounded env54984 := by
  intro p hp
  have h : env54984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54983_54984 : H12AffineEnvironment.transform 2 4 env54983 = env54984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env54983 == env54984) = true)

def env54985 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74862,65665,4417,8541,4096,5276,74047,66897,13769,78895,1150,74814,1297,81226,8204,1281,256,65830,1344,5952]

theorem envBound54985 : H12AffineFastState.Bounded env54985 := by
  intro p hp
  have h : env54985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54963_54985 : H12AffineEnvironment.transform 17 65665 env54963 = env54985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env54963 == env54985) = true)

theorem identity54985 : scanCanonicalize (H12AffineFastState.compose env54985 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12670) := by decide +kernel

theorem selectedBound54985 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env54986 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,12670,5392,12799,4417,8541,4096,5276,4161,13359,13769,1361,1150,5440,1297,3124,8204,1281,256,12376,1344,5952]

theorem envBound54986 : H12AffineFastState.Bounded env54986 := by
  intro p hp
  have h : env54986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54985_54986 : H12AffineEnvironment.transform 15 12670 env54985 = env54986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12670 env54985 == env54986) = true)

def env54987 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1297,8540,8494,1344,8623,273,8541,80,1228,17,9343,9625,1361,1150,1296,1297,3124,8204,1281,256,8200,1344,1808]

theorem envBound54987 : H12AffineFastState.Bounded env54987 := by
  intro p hp
  have h : env54987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54986_54987 : H12AffineEnvironment.transform 11 80 env54986 = env54987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env54986 == env54987) = true)

theorem identity54987 : scanCanonicalize (H12AffineFastState.compose env54987 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound54987 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env54988 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,268,1297,80,34,1344,163,273,81,80,1228,17,1395,1173,1361,1150,1296,1297,3124,256,1281,256,260,1344,1808]

theorem envBound54988 : H12AffineFastState.Bounded env54988 := by
  intro p hp
  have h : env54988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54987_54988 : H12AffineEnvironment.transform 12 268 env54987 = env54988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env54987 == env54988) = true)

theorem identity54988 : scanCanonicalize (H12AffineFastState.compose env54988 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound54988 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env54989 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,80,268,1,80,34,80,163,273,81,80,476,17,99,389,65,366,0,1,2340,256,17,256,260,80,512]

theorem envBound54989 : H12AffineFastState.Bounded env54989 := by
  intro p hp
  have h : env54989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54988_54989 : H12AffineEnvironment.transform 9 272 env54988 = env54989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env54988 == env54989) = true)

theorem identity54989 : scanCanonicalize (H12AffineFastState.compose env54989 (packedSelected [2,5,8,13] rootPS)) = affineNative (2^(10+1) ^^^ 319) := by decide +kernel

theorem selectedBound54989 : packedSelected [2,5,8,13] rootPS < 2^1333 := by decide +kernel

def env54990 : List Nat := [2,4,8,16,32,64,128,256,512,272,319,80,268,1,80,34,80,163,273,81,80,476,17,99,389,65,366,0,1,27,256,17,256,260,80,512]

theorem envBound54990 : H12AffineFastState.Bounded env54990 := by
  intro p hp
  have h : env54990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54989_54990 : H12AffineEnvironment.transform 10 319 env54989 = env54990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 319 env54989 == env54990) = true)

theorem identity54990 : scanCanonicalize (H12AffineFastState.compose env54990 (packedSelected [1,2,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound54990 : packedSelected [1,2,8,10] rootPS < 2^1333 := by decide +kernel

def env54991 : List Nat := [2,4,8,16,32,64,128,253,512,237,194,80,241,1,80,34,80,163,236,81,80,33,17,99,120,65,147,0,1,27,253,17,253,249,80,512]

theorem envBound54991 : H12AffineFastState.Bounded env54991 := by
  intro p hp
  have h : env54991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54990_54991 : H12AffineEnvironment.transform 7 253 env54990 = env54991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env54990 == env54991) = true)

theorem identity54991 : scanCanonicalize (H12AffineFastState.compose env54991 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound54991 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env54992 : List Nat := [2,4,8,16,32,16,128,173,512,189,146,0,161,1,0,34,0,163,188,1,0,33,17,51,40,17,147,0,1,27,173,17,173,169,0,512]

theorem envBound54992 : H12AffineFastState.Bounded env54992 := by
  intro p hp
  have h : env54992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54991_54992 : H12AffineEnvironment.transform 5 16 env54991 = env54992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54991 == env54992) = true)

theorem identity54992 : scanCanonicalize (H12AffineFastState.compose env54992 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 146) := by decide +kernel

theorem selectedBound54992 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54993 : List Nat := [2,4,8,16,32,16,128,173,146,189,146,0,161,1,0,34,0,163,188,1,0,33,17,51,40,17,147,0,1,27,173,17,173,169,0,146]

theorem envBound54993 : H12AffineFastState.Bounded env54993 := by
  intro p hp
  have h : env54993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54992_54993 : H12AffineEnvironment.transform 8 146 env54992 = env54993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 146 env54992 == env54993) = true)

theorem identity54993 : scanCanonicalize (H12AffineFastState.compose env54993 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound54993 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env54994 : List Nat := [2,4,8,16,16,16,128,157,146,141,146,0,145,1,0,18,0,147,140,1,0,17,17,3,24,17,147,0,1,27,157,17,157,153,0,146]

theorem envBound54994 : H12AffineFastState.Bounded env54994 := by
  intro p hp
  have h : env54994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54993_54994 : H12AffineEnvironment.transform 4 16 env54993 = env54994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env54993 == env54994) = true)

theorem identity54994 : scanCanonicalize (H12AffineFastState.compose env54994 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound54994 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env54995 : List Nat := [2,4,8,11,11,11,128,134,137,141,137,0,138,1,0,9,0,136,140,1,0,10,10,3,3,10,136,0,1,0,134,10,134,130,0,137]

theorem envBound54995 : H12AffineFastState.Bounded env54995 := by
  intro p hp
  have h : env54995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54994_54995 : H12AffineEnvironment.transform 3 11 env54994 = env54995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env54994 == env54995) = true)

theorem identity54995 : scanCanonicalize (H12AffineFastState.compose env54995 (packedSelected [0,3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound54995 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env54996 : List Nat := [2,4,8,11,11,11,8,14,1,5,1,0,2,1,0,9,0,0,4,1,0,10,10,3,3,10,0,0,1,0,14,10,14,10,0,1]

theorem envBound54996 : H12AffineFastState.Bounded env54996 := by
  intro p hp
  have h : env54996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54995_54996 : H12AffineEnvironment.transform 6 8 env54995 = env54996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env54995 == env54996) = true)

theorem identity54996 : scanCanonicalize (H12AffineFastState.compose env54996 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound54996 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54997 : List Nat := [2,4,5,6,6,6,5,3,1,5,1,0,2,1,0,4,0,0,4,1,0,7,7,3,3,7,0,0,1,0,3,7,3,7,0,1]

theorem envBound54997 : H12AffineFastState.Bounded env54997 := by
  intro p hp
  have h : env54997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54996_54997 : H12AffineEnvironment.transform 2 5 env54996 = env54997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env54996 == env54997) = true)

def env54998 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1297,8540,8495,1345,8622,272,8541,81,1229,16,9342,9624,1361,1150,1297,1297,3124,8204,1281,256,8201,1344,1809]

theorem envBound54998 : H12AffineFastState.Bounded env54998 := by
  intro p hp
  have h : env54998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54986_54998 : H12AffineEnvironment.transform 11 81 env54986 = env54998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env54986 == env54998) = true)

theorem identity54998 : scanCanonicalize (H12AffineFastState.compose env54998 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 1368) := by decide +kernel

theorem selectedBound54998 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env54999 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,1368,1297,1028,1143,1345,1270,272,1029,81,1229,16,294,192,1361,1150,1297,1297,3124,1364,1281,256,1361,1344,1809]

theorem envBound54999 : H12AffineFastState.Bounded env54999 := by
  intro p hp
  have h : env54999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54998_54999 : H12AffineEnvironment.transform 12 1368 env54998 = env54999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1368 env54998 == env54999) = true)

theorem identity54999 : scanCanonicalize (H12AffineFastState.compose env54999 (packedSelected [0,2,3,5,7,10,11,12,15,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 755) := by decide +kernel

theorem selectedBound54999 : packedSelected [0,2,3,5,7,10,11,12,15,17,18,20] rootPS < 2^1333 := by decide +kernel

def env55000 : List Nat := [2,4,8,16,32,64,128,256,512,1024,755,81,1368,1297,1028,1143,1345,1270,272,1029,81,1229,16,294,192,1361,1150,1297,1297,1735,1364,1281,256,1361,1344,1809]

theorem envBound55000 : H12AffineFastState.Bounded env55000 := by
  intro p hp
  have h : env55000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54999_55000 : H12AffineEnvironment.transform 10 755 env54999 = env55000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 755 env54999 == env55000) = true)

theorem identity55000 : scanCanonicalize (H12AffineFastState.compose env55000 (packedSelected [1,5,8,13,28] rootPS)) = affineNative (2^(9+1) ^^^ 504) := by decide +kernel

theorem selectedBound55000 : packedSelected [1,5,8,13,28] rootPS < 2^1333 := by decide +kernel

def env55001 : List Nat := [2,4,8,16,32,64,128,256,512,504,755,81,160,233,508,399,185,270,272,509,81,309,16,294,192,169,390,233,233,831,172,249,256,169,184,745]

theorem envBound55001 : H12AffineFastState.Bounded env55001 := by
  intro p hp
  have h : env55001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55000_55001 : H12AffineEnvironment.transform 9 504 env55000 = env55001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 504 env55000 == env55001) = true)

theorem identity55001 : scanCanonicalize (H12AffineFastState.compose env55001 (packedSelected [3,8,11,12,13,16,17] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound55001 : packedSelected [3,8,11,12,13,16,17] rootPS < 2^1333 := by decide +kernel

def env55002 : List Nat := [2,4,8,16,32,64,128,252,512,4,755,81,160,233,0,115,185,242,236,1,81,201,16,218,192,169,122,233,233,707,172,249,252,169,184,745]

theorem envBound55002 : H12AffineFastState.Bounded env55002 := by
  intro p hp
  have h : env55002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55001_55002 : H12AffineEnvironment.transform 7 252 env55001 = env55002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env55001 == env55002) = true)

theorem identity55002 : scanCanonicalize (H12AffineFastState.compose env55002 (packedSelected [2,3,5,10,12,13] rootPS)) = affineNative (2^(8+1) ^^^ 97) := by decide +kernel

theorem selectedBound55002 : packedSelected [2,3,5,10,12,13] rootPS < 2^1333 := by decide +kernel

def env55003 : List Nat := [2,4,8,16,32,64,128,252,97,4,146,81,160,233,0,115,185,242,236,1,81,201,16,218,192,169,122,233,233,162,172,249,252,169,184,136]

theorem envBound55003 : H12AffineFastState.Bounded env55003 := by
  intro p hp
  have h : env55003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55002_55003 : H12AffineEnvironment.transform 8 97 env55002 = env55003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env55002 == env55003) = true)

theorem identity55003 : scanCanonicalize (H12AffineFastState.compose env55003 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(6+1) ^^^ 115) := by decide +kernel

theorem selectedBound55003 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env55004 : List Nat := [2,4,8,16,32,64,115,15,97,4,97,81,83,26,0,115,74,1,31,1,81,58,16,41,51,90,122,26,26,81,95,10,15,90,75,123]

theorem envBound55004 : H12AffineFastState.Bounded env55004 := by
  intro p hp
  have h : env55004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55003_55004 : H12AffineEnvironment.transform 6 115 env55003 = env55004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 115 env55003 == env55004) = true)

theorem identity55004 : scanCanonicalize (H12AffineFastState.compose env55004 (packedSelected [2,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound55004 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env55005 : List Nat := [2,4,8,16,32,16,35,15,49,4,49,1,3,26,0,35,26,1,31,1,1,58,16,41,51,10,42,26,26,1,15,10,15,10,27,43]

theorem envBound55005 : H12AffineFastState.Bounded env55005 := by
  intro p hp
  have h : env55005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55004_55005 : H12AffineEnvironment.transform 5 16 env55004 = env55005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env55004 == env55005) = true)

theorem identity55005 : scanCanonicalize (H12AffineFastState.compose env55005 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound55005 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env55006 : List Nat := [2,4,5,16,32,16,35,2,49,4,49,1,3,23,0,35,23,1,18,1,1,55,16,36,51,7,39,23,23,1,2,7,2,7,22,38]

theorem envBound55006 : H12AffineFastState.Bounded env55006 := by
  intro p hp
  have h : env55006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55005_55006 : H12AffineEnvironment.transform 2 5 env55005 = env55006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env55005 == env55006) = true)

theorem identity55006 : scanCanonicalize (H12AffineFastState.compose env55006 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound55006 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55007 : List Nat := [2,4,5,16,6,16,5,2,23,4,23,1,3,23,0,5,23,1,18,1,1,17,16,2,21,7,1,23,23,1,2,7,2,7,22,0]

theorem envBound55007 : H12AffineFastState.Bounded env55007 := by
  intro p hp
  have h : env55007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55006_55007 : H12AffineEnvironment.transform 4 6 env55006 = env55007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env55006 == env55007) = true)

def env55008 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,21585,32769,4096,61649,91182,123164,28889,78894,385202,90415,1296,96347,25885,1280,256,82999,1344,21072]

theorem envBound55008 : H12AffineFastState.Bounded env55008 := by
  intro p hp
  have h : env55008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54918_55008 : H12AffineEnvironment.transform 18 21585 env54918 = env55008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env54918 == env55008) = true)

theorem identity55008 : scanCanonicalize (H12AffineFastState.compose env55008 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound55008 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env55009 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13341,65536,74862,262144,21585,13340,4096,17612,91182,87297,28889,78894,349359,90415,1296,96347,25885,1280,256,82999,1344,21072]

theorem envBound55009 : H12AffineFastState.Bounded env55009 := by
  intro p hp
  have h : env55009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55008_55009 : H12AffineEnvironment.transform 14 13341 env55008 = env55009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env55008 == env55009) = true)

def env55010 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74862,262144,4417,13340,4096,476,74046,69649,13769,78894,332223,74815,1296,81227,8205,1280,256,65831,1344,5952]

theorem envBound55010 : H12AffineFastState.Bounded env55010 := by
  intro p hp
  have h : env55010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55009_55010 : H12AffineEnvironment.transform 13 1296 env55009 = env55010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env55009 == env55010) = true)

def env55011 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74862,65664,4417,13340,4096,476,74046,69649,13769,78894,4415,74815,1296,81227,8205,1280,256,65831,1344,5952]

theorem envBound55011 : H12AffineFastState.Bounded env55011 := by
  intro p hp
  have h : env55011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55010_55011 : H12AffineEnvironment.transform 17 65664 env55010 = env55011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env55010 == env55011) = true)

theorem identity55011 : scanCanonicalize (H12AffineFastState.compose env55011 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5239) := by decide +kernel

theorem selectedBound55011 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env55012 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,5239,12313,5367,4417,13340,4096,476,13641,1126,13769,8281,4415,12360,1296,10556,8205,1280,256,5456,1344,5952]

theorem envBound55012 : H12AffineFastState.Bounded env55012 := by
  intro p hp
  have h : env55012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55011_55012 : H12AffineEnvironment.transform 15 5239 env55011 = env55012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5239 env55011 == env55012) = true)

def env55013 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1296,9293,1063,8265,1191,273,9292,80,476,9497,1126,9625,8281,367,8216,1296,10556,8205,1280,256,1280,1344,1808]

theorem envBound55013 : H12AffineFastState.Bounded env55013 := by
  intro p hp
  have h : env55013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55012_55013 : H12AffineEnvironment.transform 11 80 env55012 = env55013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env55012 == env55013) = true)

theorem identity55013 : scanCanonicalize (H12AffineFastState.compose env55013 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound55013 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env55014 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,80,8192,81,8460,358,8265,486,273,8461,80,476,8280,295,8408,8281,367,8216,81,10556,8205,65,256,65,1,593]

theorem envBound55014 : H12AffineFastState.Bounded env55014 := by
  intro p hp
  have h : env55014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55013_55014 : H12AffineEnvironment.transform 9 321 env55013 = env55014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env55013 == env55014) = true)

theorem identity55014 : scanCanonicalize (H12AffineFastState.compose env55014 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound55014 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env55015 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,1,8192,0,8460,311,8216,439,273,8461,1,397,8201,295,8329,8200,318,8216,0,10556,8205,16,256,16,1,512]

theorem envBound55015 : H12AffineFastState.Bounded env55015 := by
  intro p hp
  have h : env55015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55014_55015 : H12AffineEnvironment.transform 5 17 env55014 = env55015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55014 == env55015) = true)

theorem identity55015 : scanCanonicalize (H12AffineFastState.compose env55015 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 900) := by decide +kernel

theorem selectedBound55015 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env55016 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,1,900,0,648,311,924,439,273,649,1,397,909,295,781,908,318,924,0,2744,905,16,256,16,1,512]

theorem envBound55016 : H12AffineFastState.Bounded env55016 := by
  intro p hp
  have h : env55016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55015_55016 : H12AffineEnvironment.transform 12 900 env55015 = env55016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 900 env55015 == env55016) = true)

theorem identity55016 : scanCanonicalize (H12AffineFastState.compose env55016 (packedSelected [3,8,13] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound55016 : packedSelected [3,8,13] rootPS < 2^1333 := by decide +kernel

def env55017 : List Nat := [2,4,8,16,32,17,128,256,512,272,292,1,900,0,648,311,924,439,273,649,1,397,909,295,781,908,318,924,0,924,905,16,256,16,1,512]

theorem envBound55017 : H12AffineFastState.Bounded env55017 := by
  intro p hp
  have h : env55017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55016_55017 : H12AffineEnvironment.transform 10 292 env55016 = env55017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env55016 == env55017) = true)

theorem identity55017 : scanCanonicalize (H12AffineFastState.compose env55017 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound55017 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env55018 : List Nat := [2,4,8,16,32,17,128,15,512,31,43,1,651,0,648,56,659,184,30,649,1,130,642,40,514,643,49,659,0,659,646,16,15,16,1,512]

theorem envBound55018 : H12AffineFastState.Bounded env55018 := by
  intro p hp
  have h : env55018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55017_55018 : H12AffineEnvironment.transform 7 15 env55017 = env55018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env55017 == env55018) = true)

theorem identity55018 : scanCanonicalize (H12AffineFastState.compose env55018 (packedSelected [1,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 63) := by decide +kernel

theorem selectedBound55018 : packedSelected [1,4,5] rootPS < 2^1333 := by decide +kernel

def env55019 : List Nat := [2,4,8,16,32,17,63,15,512,31,43,1,564,0,567,56,556,7,30,566,1,61,573,40,514,572,49,556,0,556,569,16,15,16,1,512]

theorem envBound55019 : H12AffineFastState.Bounded env55019 := by
  intro p hp
  have h : env55019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55018_55019 : H12AffineEnvironment.transform 6 63 env55018 = env55019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 63 env55018 == env55019) = true)

theorem identity55019 : scanCanonicalize (H12AffineFastState.compose env55019 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound55019 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env55020 : List Nat := [2,4,8,13,32,12,34,15,512,2,43,1,553,0,554,37,556,7,3,555,1,32,544,40,514,545,44,556,0,556,548,13,15,13,1,512]

theorem envBound55020 : H12AffineFastState.Bounded env55020 := by
  intro p hp
  have h : env55020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55019_55020 : H12AffineEnvironment.transform 3 13 env55019 = env55020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env55019 == env55020) = true)

theorem identity55020 : scanCanonicalize (H12AffineFastState.compose env55020 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound55020 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55021 : List Nat := [2,2,8,11,32,10,34,9,512,2,43,1,553,0,554,35,554,1,3,555,1,32,544,40,514,545,42,554,0,554,546,11,9,11,1,512]

theorem envBound55021 : H12AffineFastState.Bounded env55021 := by
  intro p hp
  have h : env55021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55020_55021 : H12AffineEnvironment.transform 1 2 env55020 = env55021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env55020 == env55021) = true)

theorem identity55021 : scanCanonicalize (H12AffineFastState.compose env55021 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound55021 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55022 : List Nat := [2,2,8,11,32,10,34,9,1,2,43,1,40,0,43,35,43,1,3,42,1,32,33,40,3,32,42,43,0,43,35,11,9,11,1,1]

theorem envBound55022 : H12AffineFastState.Bounded env55022 := by
  intro p hp
  have h : env55022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55021_55022 : H12AffineEnvironment.transform 8 1 env55021 = env55022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env55021 == env55022) = true)

theorem identity55022 : scanCanonicalize (H12AffineFastState.compose env55022 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound55022 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55023 : List Nat := [2,2,8,11,10,10,8,9,1,2,1,1,2,0,1,9,1,1,3,0,1,10,11,2,3,10,0,1,0,1,9,11,9,11,1,1]

theorem envBound55023 : H12AffineFastState.Bounded env55023 := by
  intro p hp
  have h : env55023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55022_55023 : H12AffineEnvironment.transform 4 10 env55022 = env55023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env55022 == env55023) = true)

def env55024 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1296,9292,1062,8264,1190,272,9293,81,476,9496,1126,9624,8281,366,8217,1296,10556,8205,1280,256,1281,1344,1809]

theorem envBound55024 : H12AffineFastState.Bounded env55024 := by
  intro p hp
  have h : env55024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55012_55024 : H12AffineEnvironment.transform 11 81 env55012 = env55024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env55012 == env55024) = true)

theorem identity55024 : scanCanonicalize (H12AffineFastState.compose env55024 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound55024 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env55025 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,269,1296,1345,1062,325,1190,272,1344,81,476,1045,1126,1173,340,366,276,1296,2097,256,1280,256,1281,1344,1809]

theorem envBound55025 : H12AffineFastState.Bounded env55025 := by
  intro p hp
  have h : env55025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55024_55025 : H12AffineEnvironment.transform 12 269 env55024 = env55025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env55024 == env55025) = true)

theorem identity55025 : scanCanonicalize (H12AffineFastState.compose env55025 (packedSelected [0,1,4,7,8,9,12,13,15,18,19,23] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound55025 : packedSelected [0,1,4,7,8,9,12,13,15,18,19,23] rootPS < 2^1333 := by decide +kernel

def env55026 : List Nat := [2,4,8,16,32,64,105,256,512,1024,2048,81,269,1296,1345,1062,325,1103,272,1344,81,309,1045,1126,1148,340,366,276,1296,2097,256,1280,256,1281,1344,1809]

theorem envBound55026 : H12AffineFastState.Bounded env55026 := by
  intro p hp
  have h : env55026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55025_55026 : H12AffineEnvironment.transform 6 105 env55025 = env55026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env55025 == env55026) = true)

theorem identity55026 : scanCanonicalize (H12AffineFastState.compose env55026 (packedSelected [0,1,2,5,7,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 92) := by decide +kernel

theorem selectedBound55026 : packedSelected [0,1,2,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env55027 : List Nat := [2,4,8,16,32,64,105,256,512,1024,92,81,269,1296,1345,1062,325,1103,272,1344,81,309,1045,1126,1148,340,366,276,1296,109,256,1280,256,1281,1344,1809]

theorem envBound55027 : H12AffineFastState.Bounded env55027 := by
  intro p hp
  have h : env55027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55026_55027 : H12AffineEnvironment.transform 10 92 env55026 = env55027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 92 env55026 == env55027) = true)

theorem identity55027 : scanCanonicalize (H12AffineFastState.compose env55027 (packedSelected [0,3,7,10,13,17,18,19] rootPS)) = affineNative (2^(9+1) ^^^ 531) := by decide +kernel

theorem selectedBound55027 : packedSelected [0,3,7,10,13,17,18,19] rootPS < 2^1333 := by decide +kernel

def env55028 : List Nat := [2,4,8,16,32,64,105,256,512,531,92,81,269,771,850,565,325,604,272,851,81,309,518,629,623,340,366,276,771,109,256,787,256,786,851,258]

theorem envBound55028 : H12AffineFastState.Bounded env55028 := by
  intro p hp
  have h : env55028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55027_55028 : H12AffineEnvironment.transform 9 531 env55027 = env55028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 531 env55027 == env55028) = true)

theorem identity55028 : scanCanonicalize (H12AffineFastState.compose env55028 (packedSelected [0,1,2,4,7,8,9,12,13] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound55028 : packedSelected [0,1,2,4,7,8,9,12,13] rootPS < 2^1333 := by decide +kernel

def env55029 : List Nat := [2,4,8,16,32,58,19,256,512,531,38,43,269,771,808,565,319,550,272,809,43,309,518,527,533,302,276,276,771,23,256,787,256,786,809,258]

theorem envBound55029 : H12AffineFastState.Bounded env55029 := by
  intro p hp
  have h : env55029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55028_55029 : H12AffineEnvironment.transform 5 58 env55028 = env55029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env55028 == env55029) = true)

theorem identity55029 : scanCanonicalize (H12AffineFastState.compose env55029 (packedSelected [0,1,2,4,7,9,12] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound55029 : packedSelected [0,1,2,4,7,9,12] rootPS < 2^1333 := by decide +kernel

def env55030 : List Nat := [2,4,8,6,32,44,5,256,512,517,38,43,269,771,808,547,297,550,262,809,43,291,518,527,515,302,258,258,771,1,256,773,256,772,809,258]

theorem envBound55030 : H12AffineFastState.Bounded env55030 := by
  intro p hp
  have h : env55030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55029_55030 : H12AffineEnvironment.transform 3 6 env55029 = env55030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env55029 == env55030) = true)

theorem identity55030 : scanCanonicalize (H12AffineFastState.compose env55030 (packedSelected [1,2,3,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 2) := by decide +kernel

theorem selectedBound55030 : packedSelected [1,2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env55031 : List Nat := [2,4,8,6,32,44,5,2,512,517,38,43,15,513,554,547,43,550,4,555,43,33,518,527,515,44,0,0,513,1,2,519,2,518,555,0]

theorem envBound55031 : H12AffineFastState.Bounded env55031 := by
  intro p hp
  have h : env55031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55030_55031 : H12AffineEnvironment.transform 7 2 env55030 = env55031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 2 env55030 == env55031) = true)

def env55032 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74862,65665,4417,13340,4096,476,74046,69649,13769,78894,4414,74815,1296,81227,8205,1280,256,65831,1344,5952]

theorem envBound55032 : H12AffineFastState.Bounded env55032 := by
  intro p hp
  have h : env55032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55010_55032 : H12AffineEnvironment.transform 17 65665 env55010 = env55032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env55010 == env55032) = true)

theorem identity55032 : scanCanonicalize (H12AffineFastState.compose env55032 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 310) := by decide +kernel

theorem selectedBound55032 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env55033 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,310,9560,439,4417,13340,4096,476,8200,4391,13769,13592,4414,9481,1296,15485,8205,1280,256,17,1344,5952]

theorem envBound55033 : H12AffineFastState.Bounded env55033 := by
  intro p hp
  have h : env55033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55032_55033 : H12AffineEnvironment.transform 15 310 env55032 = env55033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 310 env55032 == env55033) = true)

def env55034 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,0,12557,310,8264,439,4417,12556,4096,476,8200,4391,12505,12296,4414,8217,0,14701,8205,16,256,17,80,4688]

theorem envBound55034 : H12AffineFastState.Bounded env55034 := by
  intro p hp
  have h : env55034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55033_55034 : H12AffineEnvironment.transform 9 272 env55033 = env55034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env55033 == env55034) = true)

theorem identity55034 : scanCanonicalize (H12AffineFastState.compose env55034 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound55034 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env55035 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,269,0,4096,310,325,439,4417,4097,4096,476,261,4391,4564,4357,4414,276,0,6240,256,16,256,17,80,4688]

theorem envBound55035 : H12AffineFastState.Bounded env55035 := by
  intro p hp
  have h : env55035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55034_55035 : H12AffineEnvironment.transform 12 269 env55034 = env55035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env55034 == env55035) = true)

theorem identity55035 : scanCanonicalize (H12AffineFastState.compose env55035 (packedSelected [0,3,4,5,7,9,10,12,13,15,18,23] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound55035 : packedSelected [0,3,4,5,7,9,10,12,13,15,18,23] rootPS < 2^1333 := by decide +kernel

def env55036 : List Nat := [2,4,8,16,32,64,128,173,512,189,2048,4096,160,0,4096,155,232,26,4332,4097,4096,113,168,4234,4217,4264,4243,185,0,6240,173,16,173,17,80,4688]

theorem envBound55036 : H12AffineFastState.Bounded env55036 := by
  intro p hp
  have h : env55036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55035_55036 : H12AffineEnvironment.transform 7 173 env55035 = env55036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env55035 == env55036) = true)

theorem identity55036 : scanCanonicalize (H12AffineFastState.compose env55036 (packedSelected [13,15,16,17,18] rootPS)) = affineNative (2^(11+1) ^^^ 2123) := by decide +kernel

theorem selectedBound55036 : packedSelected [13,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env55037 : List Nat := [2,4,8,16,32,64,128,173,512,189,2048,2123,160,0,2123,155,232,26,2215,2122,2123,113,168,2241,2098,2275,2264,185,0,43,173,16,173,17,80,2587]

theorem envBound55037 : H12AffineFastState.Bounded env55037 := by
  intro p hp
  have h : env55037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55036_55037 : H12AffineEnvironment.transform 11 2123 env55036 = env55037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2123 env55036 == env55037) = true)

theorem identity55037 : scanCanonicalize (H12AffineFastState.compose env55037 (packedSelected [2,4,9,13,16] rootPS)) = affineNative (2^(10+1) ^^^ 608) := by decide +kernel

theorem selectedBound55037 : packedSelected [2,4,9,13,16] rootPS < 2^1333 := by decide +kernel

def env55038 : List Nat := [2,4,8,16,32,64,128,173,512,189,608,555,160,0,555,155,232,26,711,554,555,113,168,673,594,643,696,185,0,43,173,16,173,17,80,123]

theorem envBound55038 : H12AffineFastState.Bounded env55038 := by
  intro p hp
  have h : env55038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55037_55038 : H12AffineEnvironment.transform 10 608 env55037 = env55038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 608 env55037 == env55038) = true)

theorem identity55038 : scanCanonicalize (H12AffineFastState.compose env55038 (packedSelected [0,1,2,3,7,8,12] rootPS)) = affineNative (2^(8+1) ^^^ 38) := by decide +kernel

theorem selectedBound55038 : packedSelected [0,1,2,3,7,8,12] rootPS < 2^1333 := by decide +kernel

def env55039 : List Nat := [2,4,8,16,32,64,128,173,38,189,70,13,160,0,13,155,232,26,225,12,13,113,168,135,116,165,158,185,0,43,173,16,173,17,80,123]

theorem envBound55039 : H12AffineFastState.Bounded env55039 := by
  intro p hp
  have h : env55039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55038_55039 : H12AffineEnvironment.transform 8 38 env55038 = env55039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 38 env55038 == env55039) = true)

theorem identity55039 : scanCanonicalize (H12AffineFastState.compose env55039 (packedSelected [0,2,3,7,8,10,11,13,15] rootPS)) = affineNative (2^(6+1) ^^^ 67) := by decide +kernel

theorem selectedBound55039 : packedSelected [0,2,3,7,8,10,11,13,15] rootPS < 2^1333 := by decide +kernel

def env55040 : List Nat := [2,4,8,16,32,64,67,110,38,126,70,13,99,0,13,88,43,26,34,12,13,113,107,68,116,102,93,122,0,43,110,16,110,17,80,123]

theorem envBound55040 : H12AffineFastState.Bounded env55040 := by
  intro p hp
  have h : env55040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55039_55040 : H12AffineEnvironment.transform 6 67 env55039 = env55040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 67 env55039 == env55040) = true)

theorem identity55040 : scanCanonicalize (H12AffineFastState.compose env55040 (packedSelected [1,3,4,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound55040 : packedSelected [1,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env55041 : List Nat := [2,4,8,16,32,16,19,62,38,46,22,13,51,0,13,8,43,26,34,12,13,33,59,20,36,54,13,42,0,43,62,16,62,17,0,43]

theorem envBound55041 : H12AffineFastState.Bounded env55041 := by
  intro p hp
  have h : env55041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55040_55041 : H12AffineEnvironment.transform 5 16 env55040 = env55041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env55040 == env55041) = true)

theorem identity55041 : scanCanonicalize (H12AffineFastState.compose env55041 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound55041 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55042 : List Nat := [2,4,8,16,11,16,19,21,13,5,22,13,24,0,13,8,0,26,9,12,13,10,16,20,15,29,13,1,0,0,21,16,21,17,0,0]

theorem envBound55042 : H12AffineFastState.Bounded env55042 := by
  intro p hp
  have h : env55042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55041_55042 : H12AffineEnvironment.transform 4 11 env55041 = env55042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env55041 == env55042) = true)

theorem identity55042 : scanCanonicalize (H12AffineFastState.compose env55042 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound55042 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55043 : List Nat := [2,4,8,6,11,6,5,3,13,5,0,13,14,0,13,8,0,12,9,12,13,10,6,2,15,11,13,1,0,0,3,6,3,7,0,0]

theorem envBound55043 : H12AffineFastState.Bounded env55043 := by
  intro p hp
  have h : env55043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55042_55043 : H12AffineEnvironment.transform 3 6 env55042 = env55043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env55042 == env55043) = true)

def env55044 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,1,12556,310,8265,439,4417,12557,4096,476,8200,4391,12504,12297,4414,8216,1,14700,8205,17,256,17,81,4689]

theorem envBound55044 : H12AffineFastState.Bounded env55044 := by
  intro p hp
  have h : env55044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55033_55044 : H12AffineEnvironment.transform 9 273 env55033 = env55044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env55033 == env55044) = true)

theorem identity55044 : scanCanonicalize (H12AffineFastState.compose env55044 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound55044 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env55045 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,0,8192,1,8460,310,8265,439,321,8461,0,476,8200,295,8408,8201,318,8216,1,10604,8205,17,256,17,81,593]

theorem envBound55045 : H12AffineFastState.Bounded env55045 := by
  intro p hp
  have h : env55045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55044_55045 : H12AffineEnvironment.transform 11 0 env55044 = env55045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env55044 == env55045) = true)

theorem identity55045 : scanCanonicalize (H12AffineFastState.compose env55045 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound55045 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env55046 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,0,8192,1,8460,310,8216,439,272,8461,0,397,8200,295,8329,8201,318,8216,1,10557,8205,17,256,17,0,512]

theorem envBound55046 : H12AffineFastState.Bounded env55046 := by
  intro p hp
  have h : env55046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55045_55046 : H12AffineEnvironment.transform 5 17 env55045 = env55046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55045 == env55046) = true)

theorem identity55046 : scanCanonicalize (H12AffineFastState.compose env55046 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 901) := by decide +kernel

theorem selectedBound55046 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env55047 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,0,901,1,649,310,925,439,272,648,0,397,909,295,780,908,318,925,1,2744,904,17,256,17,0,512]

theorem envBound55047 : H12AffineFastState.Bounded env55047 := by
  intro p hp
  have h : env55047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55046_55047 : H12AffineEnvironment.transform 12 901 env55046 = env55047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 901 env55046 == env55047) = true)

theorem identity55047 : scanCanonicalize (H12AffineFastState.compose env55047 (packedSelected [3,8,13] rootPS)) = affineNative (2^(8+1) ^^^ 390) := by decide +kernel

theorem selectedBound55047 : packedSelected [3,8,13] rootPS < 2^1333 := by decide +kernel

def env55048 : List Nat := [2,4,8,16,32,17,128,256,390,273,2048,0,3,1,271,310,27,439,272,270,0,397,11,295,138,10,318,27,1,2366,14,17,256,17,0,390]

theorem envBound55048 : H12AffineFastState.Bounded env55048 := by
  intro p hp
  have h : env55048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55047_55048 : H12AffineEnvironment.transform 8 390 env55047 = env55048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 390 env55047 == env55048) = true)

theorem identity55048 : scanCanonicalize (H12AffineFastState.compose env55048 (packedSelected [1,3,8,12] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound55048 : packedSelected [1,3,8,12] rootPS < 2^1333 := by decide +kernel

def env55049 : List Nat := [2,4,8,12,32,13,128,256,390,269,2048,0,3,1,271,298,7,427,268,270,0,397,11,295,138,10,290,7,1,2338,14,13,256,13,0,390]

theorem envBound55049 : H12AffineFastState.Bounded env55049 := by
  intro p hp
  have h : env55049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55048_55049 : H12AffineEnvironment.transform 3 12 env55048 = env55049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env55048 == env55049) = true)

theorem identity55049 : scanCanonicalize (H12AffineFastState.compose env55049 (packedSelected [5,8,15] rootPS)) = affineNative (2^(10+1) ^^^ 44) := by decide +kernel

theorem selectedBound55049 : packedSelected [5,8,15] rootPS < 2^1333 := by decide +kernel

def env55050 : List Nat := [2,4,8,12,32,13,128,256,390,269,44,0,3,1,271,298,7,427,268,270,0,397,11,295,138,10,290,7,1,270,14,13,256,13,0,390]

theorem envBound55050 : H12AffineFastState.Bounded env55050 := by
  intro p hp
  have h : env55050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55049_55050 : H12AffineEnvironment.transform 10 44 env55049 = env55050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 44 env55049 == env55050) = true)

theorem identity55050 : scanCanonicalize (H12AffineFastState.compose env55050 (packedSelected [0,2] rootPS)) = affineNative (2^(7+1) ^^^ 8) := by decide +kernel

theorem selectedBound55050 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env55051 : List Nat := [2,4,8,12,32,13,128,8,142,5,44,0,3,1,7,34,7,163,4,6,0,133,11,47,138,10,42,7,1,6,14,13,8,13,0,142]

theorem envBound55051 : H12AffineFastState.Bounded env55051 := by
  intro p hp
  have h : env55051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55050_55051 : H12AffineEnvironment.transform 7 8 env55050 = env55051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 8 env55050 == env55051) = true)

theorem identity55051 : scanCanonicalize (H12AffineFastState.compose env55051 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound55051 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env55052 : List Nat := [2,4,8,12,13,13,128,8,142,5,1,0,3,1,7,15,7,142,4,6,0,133,11,2,138,10,7,7,1,6,14,13,8,13,0,142]

theorem envBound55052 : H12AffineFastState.Bounded env55052 := by
  intro p hp
  have h : env55052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55051_55052 : H12AffineEnvironment.transform 4 13 env55051 = env55052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env55051 == env55052) = true)

theorem identity55052 : scanCanonicalize (H12AffineFastState.compose env55052 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound55052 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env55053 : List Nat := [2,3,8,11,10,10,128,8,137,2,1,0,3,1,0,8,0,137,3,1,0,130,11,2,138,10,0,0,1,1,9,10,8,10,0,137]

theorem envBound55053 : H12AffineFastState.Bounded env55053 := by
  intro p hp
  have h : env55053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55052_55053 : H12AffineEnvironment.transform 1 3 env55052 = env55053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env55052 == env55053) = true)

theorem identity55053 : scanCanonicalize (H12AffineFastState.compose env55053 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound55053 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55054 : List Nat := [2,3,8,11,10,10,9,8,0,2,1,0,3,1,0,8,0,0,3,1,0,11,11,2,3,10,0,0,1,1,9,10,8,10,0,0]

theorem envBound55054 : H12AffineFastState.Bounded env55054 := by
  intro p hp
  have h : env55054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55053_55054 : H12AffineEnvironment.transform 6 9 env55053 = env55054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env55053 == env55054) = true)

def env55055 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74862,262144,4416,13340,4096,477,74047,69648,13768,78894,332222,74814,1296,81226,8204,1280,256,65830,1344,5953]

theorem envBound55055 : H12AffineFastState.Bounded env55055 := by
  intro p hp
  have h : env55055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55009_55055 : H12AffineEnvironment.transform 13 1297 env55009 = env55055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env55009 == env55055) = true)

def env55056 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74862,65664,4416,13340,4096,477,74047,69648,13768,78894,4414,74814,1296,81226,8204,1280,256,65830,1344,5953]

theorem envBound55056 : H12AffineFastState.Bounded env55056 := by
  intro p hp
  have h : env55056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55055_55056 : H12AffineEnvironment.transform 17 65664 env55055 = env55056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env55055 == env55056) = true)

theorem identity55056 : scanCanonicalize (H12AffineFastState.compose env55056 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9278) := by decide +kernel

theorem selectedBound55056 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env55057 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,9278,80,9406,4416,13340,4096,477,1281,13358,13768,4112,4414,0,1296,6516,8204,1280,256,9496,1344,5953]

theorem envBound55057 : H12AffineFastState.Bounded env55057 := by
  intro p hp
  have h : env55057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55056_55057 : H12AffineEnvironment.transform 15 9278 env55056 = env55057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9278 env55056 == env55057) = true)

def env55058 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,1,12557,8494,80,8622,4416,12556,4096,477,17,12606,12504,4112,4414,0,0,6516,8204,16,256,8200,80,4689]

theorem envBound55058 : H12AffineFastState.Bounded env55058 := by
  intro p hp
  have h : env55058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55057_55058 : H12AffineEnvironment.transform 9 272 env55057 = env55058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env55057 == env55058) = true)

theorem identity55058 : scanCanonicalize (H12AffineFastState.compose env55058 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 4120) := by decide +kernel

theorem selectedBound55058 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env55059 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,4120,1,277,4406,80,4534,4416,276,4096,477,17,294,192,4112,4414,0,0,6516,4116,16,256,4112,80,4689]

theorem envBound55059 : H12AffineFastState.Bounded env55059 := by
  intro p hp
  have h : env55059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55058_55059 : H12AffineEnvironment.transform 12 4120 env55058 = env55059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4120 env55058 == env55059) = true)

theorem identity55059 : scanCanonicalize (H12AffineFastState.compose env55059 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound55059 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env55060 : List Nat := [2,4,8,16,32,64,128,172,512,188,2048,4096,4120,1,185,4250,80,4122,4332,184,4096,113,17,138,192,4112,4242,0,0,6360,4116,16,172,4112,80,4689]

theorem envBound55060 : H12AffineFastState.Bounded env55060 := by
  intro p hp
  have h : env55060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55059_55060 : H12AffineEnvironment.transform 7 172 env55059 = env55060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env55059 == env55060) = true)

theorem identity55060 : scanCanonicalize (H12AffineFastState.compose env55060 (packedSelected [0,2,3,4,5,7,9,10,11,12,15,17,18] rootPS)) = affineNative (2^(11+1) ^^^ 2634) := by decide +kernel

theorem selectedBound55060 : packedSelected [0,2,3,4,5,7,9,10,11,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env55061 : List Nat := [2,4,8,16,32,64,128,172,512,188,2048,2634,2642,1,185,2768,80,2640,2726,184,2634,113,17,138,192,2650,2776,0,0,658,2654,16,172,2650,80,2075]

theorem envBound55061 : H12AffineFastState.Bounded env55061 := by
  intro p hp
  have h : env55061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55060_55061 : H12AffineEnvironment.transform 11 2634 env55060 = env55061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2634 env55060 == env55061) = true)

theorem identity55061 : scanCanonicalize (H12AffineFastState.compose env55061 (packedSelected [0,2,3,7,8,10,16,17] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound55061 : packedSelected [0,2,3,7,8,10,16,17] rootPS < 2^1333 := by decide +kernel

def env55062 : List Nat := [2,4,8,16,32,64,128,172,512,188,1,587,595,1,185,721,80,593,679,184,587,113,17,138,192,603,729,0,0,658,607,16,172,603,80,26]

theorem envBound55062 : H12AffineFastState.Bounded env55062 := by
  intro p hp
  have h : env55062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55061_55062 : H12AffineEnvironment.transform 10 1 env55061 = env55062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env55061 == env55062) = true)

theorem identity55062 : scanCanonicalize (H12AffineFastState.compose env55062 (packedSelected [0,1,3,4,10] rootPS)) = affineNative (2^(6+1) ^^^ 114) := by decide +kernel

theorem selectedBound55062 : packedSelected [0,1,3,4,10] rootPS < 2^1333 := by decide +kernel

def env55063 : List Nat := [2,4,8,16,32,64,114,94,512,78,1,587,595,1,75,547,80,593,597,74,587,113,17,120,50,603,555,0,0,608,607,16,94,603,80,26]

theorem envBound55063 : H12AffineFastState.Bounded env55063 := by
  intro p hp
  have h : env55063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55062_55063 : H12AffineEnvironment.transform 6 114 env55062 = env55063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 114 env55062 == env55063) = true)

theorem identity55063 : scanCanonicalize (H12AffineFastState.compose env55063 (packedSelected [0,1,2,4,7,8,9,11] rootPS)) = affineNative (2^(8+1) ^^^ 96) := by decide +kernel

theorem selectedBound55063 : packedSelected [0,1,2,4,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env55064 : List Nat := [2,4,8,16,32,64,114,94,96,78,1,43,51,1,75,67,80,49,53,74,43,113,17,120,50,59,75,0,0,0,63,16,94,59,80,26]

theorem envBound55064 : H12AffineFastState.Bounded env55064 := by
  intro p hp
  have h : env55064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55063_55064 : H12AffineEnvironment.transform 8 96 env55063 = env55064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 96 env55063 == env55064) = true)

theorem identity55064 : scanCanonicalize (H12AffineFastState.compose env55064 (packedSelected [3,5] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound55064 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env55065 : List Nat := [2,4,8,16,32,11,57,21,43,5,1,43,51,1,0,8,27,49,53,1,43,58,17,51,50,59,0,0,0,0,63,16,21,59,27,26]

theorem envBound55065 : H12AffineFastState.Bounded env55065 := by
  intro p hp
  have h : env55065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55064_55065 : H12AffineEnvironment.transform 5 11 env55064 = env55065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env55064 == env55065) = true)

def env55066 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,0,12556,8495,80,8623,4416,12557,4096,477,16,12607,12505,4112,4414,0,1,6516,8204,17,256,8201,81,4688]

theorem envBound55066 : H12AffineFastState.Bounded env55066 := by
  intro p hp
  have h : env55066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55057_55066 : H12AffineEnvironment.transform 9 273 env55057 = env55066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env55057 == env55066) = true)

theorem identity55066 : scanCanonicalize (H12AffineFastState.compose env55066 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound55066 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env55067 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,268,0,4096,35,80,163,4416,4097,4096,477,16,4147,4565,4112,4414,0,1,6516,256,17,256,261,81,4688]

theorem envBound55067 : H12AffineFastState.Bounded env55067 := by
  intro p hp
  have h : env55067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55066_55067 : H12AffineEnvironment.transform 12 268 env55066 = env55067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env55066 == env55067) = true)

theorem identity55067 : scanCanonicalize (H12AffineFastState.compose env55067 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound55067 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env55068 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,80,268,0,80,35,80,163,272,81,80,477,16,99,389,64,366,0,1,2340,256,17,256,261,81,512]

theorem envBound55068 : H12AffineFastState.Bounded env55068 := by
  intro p hp
  have h : env55068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55067_55068 : H12AffineEnvironment.transform 11 80 env55067 = env55068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env55067 == env55068) = true)

theorem identity55068 : scanCanonicalize (H12AffineFastState.compose env55068 (packedSelected [2,5,8,13] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound55068 : packedSelected [2,5,8,13] rootPS < 2^1333 := by decide +kernel

def env55069 : List Nat := [2,4,8,16,32,64,56,256,512,273,2048,80,268,0,80,35,80,27,272,81,80,357,16,99,317,64,366,0,1,2340,256,17,256,261,81,512]

theorem envBound55069 : H12AffineFastState.Bounded env55069 := by
  intro p hp
  have h : env55069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55068_55069 : H12AffineEnvironment.transform 6 56 env55068 = env55069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env55068 == env55069) = true)

theorem identity55069 : scanCanonicalize (H12AffineFastState.compose env55069 (packedSelected [0,1,2,4,7,8,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 539) := by decide +kernel

theorem selectedBound55069 : packedSelected [0,1,2,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env55070 : List Nat := [2,4,8,16,32,64,56,256,512,273,539,80,268,0,80,35,80,27,272,81,80,357,16,99,317,64,366,0,1,831,256,17,256,261,81,512]

theorem envBound55070 : H12AffineFastState.Bounded env55070 := by
  intro p hp
  have h : env55070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55069_55070 : H12AffineEnvironment.transform 10 539 env55069 = env55070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 539 env55069 == env55070) = true)

theorem identity55070 : scanCanonicalize (H12AffineFastState.compose env55070 (packedSelected [0,3,5,7,11,12,15] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound55070 : packedSelected [0,3,5,7,11,12,15] rootPS < 2^1333 := by decide +kernel

def env55071 : List Nat := [2,4,8,16,32,64,56,256,48,273,43,80,268,0,80,35,80,27,272,81,80,357,16,99,317,64,366,0,1,271,256,17,256,261,81,48]

theorem envBound55071 : H12AffineFastState.Bounded env55071 := by
  intro p hp
  have h : env55071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55070_55071 : H12AffineEnvironment.transform 8 48 env55070 = env55071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env55070 == env55071) = true)

theorem identity55071 : scanCanonicalize (H12AffineFastState.compose env55071 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 63) := by decide +kernel

theorem selectedBound55071 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env55072 : List Nat := [2,4,8,16,32,64,56,63,48,46,43,80,51,0,80,35,80,27,47,81,80,90,16,99,2,64,81,0,1,48,63,17,63,58,81,48]

theorem envBound55072 : H12AffineFastState.Bounded env55072 := by
  intro p hp
  have h : env55072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55071_55072 : H12AffineEnvironment.transform 7 63 env55071 = env55072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env55071 == env55072) = true)

theorem identity55072 : scanCanonicalize (H12AffineFastState.compose env55072 (packedSelected [2,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound55072 : packedSelected [2,3,4] rootPS < 2^1333 := by decide +kernel

def env55073 : List Nat := [2,4,8,16,11,64,19,20,27,5,0,80,24,0,80,8,80,27,4,81,80,90,16,72,2,64,81,0,1,27,20,17,20,17,81,27]

theorem envBound55073 : H12AffineFastState.Bounded env55073 := by
  intro p hp
  have h : env55073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55072_55073 : H12AffineEnvironment.transform 4 11 env55072 = env55073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env55072 == env55073) = true)

theorem identity55073 : scanCanonicalize (H12AffineFastState.compose env55073 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 22) := by decide +kernel

theorem selectedBound55073 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55074 : List Nat := [2,4,8,16,11,22,19,20,27,5,0,6,24,0,6,8,6,27,4,7,6,12,16,30,2,22,7,0,1,27,20,17,20,17,7,27]

theorem envBound55074 : H12AffineFastState.Bounded env55074 := by
  intro p hp
  have h : env55074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55073_55074 : H12AffineEnvironment.transform 5 22 env55073 = env55074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 22 env55073 == env55074) = true)

def env55075 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74862,65665,4416,13340,4096,477,74047,69648,13768,78894,4415,74814,1296,81226,8204,1280,256,65830,1344,5953]

theorem envBound55075 : H12AffineFastState.Bounded env55075 := by
  intro p hp
  have h : env55075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55055_55075 : H12AffineEnvironment.transform 17 65665 env55055 = env55075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env55055 == env55075) = true)

theorem identity55075 : scanCanonicalize (H12AffineFastState.compose env55075 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12670) := by decide +kernel

theorem selectedBound55075 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env55076 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,12670,5392,12799,4416,13340,4096,477,4161,8558,13768,1360,4415,5440,1296,3124,8204,1280,256,12376,1344,5953]

theorem envBound55076 : H12AffineFastState.Bounded env55076 := by
  intro p hp
  have h : env55076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55075_55076 : H12AffineEnvironment.transform 15 12670 env55075 = env55076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12670 env55075 == env55076) = true)

def env55077 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1297,9293,8494,1344,8623,272,9292,80,477,17,8558,9624,1360,367,1296,1296,3124,8204,1280,256,8200,1344,1809]

theorem envBound55077 : H12AffineFastState.Bounded env55077 := by
  intro p hp
  have h : env55077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55076_55077 : H12AffineEnvironment.transform 11 80 env55076 = env55077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env55076 == env55077) = true)

theorem identity55077 : scanCanonicalize (H12AffineFastState.compose env55077 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 72) := by decide +kernel

theorem selectedBound55077 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env55078 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,72,1297,1029,358,1344,487,272,1028,80,477,17,294,1488,1360,367,1296,1296,3124,68,1280,256,64,1344,1809]

theorem envBound55078 : H12AffineFastState.Bounded env55078 := by
  intro p hp
  have h : env55078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55077_55078 : H12AffineEnvironment.transform 12 72 env55077 = env55078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env55077 == env55078) = true)

theorem identity55078 : scanCanonicalize (H12AffineFastState.compose env55078 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound55078 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env55079 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,80,72,1213,1029,202,1260,75,188,1028,80,113,17,138,1148,1276,195,1212,1212,3124,68,1196,172,64,1260,1725]

theorem envBound55079 : H12AffineFastState.Bounded env55079 := by
  intro p hp
  have h : env55079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55078_55079 : H12AffineEnvironment.transform 7 172 env55078 = env55079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env55078 == env55079) = true)

theorem identity55079 : scanCanonicalize (H12AffineFastState.compose env55079 (packedSelected [0,2,3,4,5,7,9,10,11,12,15,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 539) := by decide +kernel

theorem selectedBound55079 : packedSelected [0,2,3,4,5,7,9,10,11,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env55080 : List Nat := [2,4,8,16,32,64,128,172,512,1024,539,80,72,1213,1029,202,1260,75,188,1028,80,113,17,138,1148,1276,195,1212,1212,1583,68,1196,172,64,1260,1725]

theorem envBound55080 : H12AffineFastState.Bounded env55080 := by
  intro p hp
  have h : env55080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55079_55080 : H12AffineEnvironment.transform 10 539 env55079 = env55080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 539 env55079 == env55080) = true)

theorem identity55080 : scanCanonicalize (H12AffineFastState.compose env55080 (packedSelected [0,2,3,7,8,10,16,17] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound55080 : packedSelected [0,2,3,7,8,10,16,17] rootPS < 2^1333 := by decide +kernel

def env55081 : List Nat := [2,4,8,16,32,64,128,172,27,1024,0,80,72,1213,1029,202,1260,75,188,1028,80,113,17,138,1148,1276,195,1212,1212,1076,68,1196,172,64,1260,1190]

theorem envBound55081 : H12AffineFastState.Bounded env55081 := by
  intro p hp
  have h : env55081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55080_55081 : H12AffineEnvironment.transform 8 27 env55080 = env55081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env55080 == env55081) = true)

theorem identity55081 : scanCanonicalize (H12AffineFastState.compose env55081 (packedSelected [1,2,7,8,9,13] rootPS)) = affineNative (2^(9+1) ^^^ 167) := by decide +kernel

theorem selectedBound55081 : packedSelected [1,2,7,8,9,13] rootPS < 2^1333 := by decide +kernel

def env55082 : List Nat := [2,4,8,16,32,64,128,172,27,167,0,80,72,26,162,202,75,75,188,163,80,113,17,138,219,91,195,27,27,147,68,11,172,64,75,1]

theorem envBound55082 : H12AffineFastState.Bounded env55082 := by
  intro p hp
  have h : env55082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55081_55082 : H12AffineEnvironment.transform 9 167 env55081 = env55082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 167 env55081 == env55082) = true)

theorem identity55082 : scanCanonicalize (H12AffineFastState.compose env55082 (packedSelected [1,2,8] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound55082 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env55083 : List Nat := [2,4,8,16,32,10,128,172,27,167,0,26,2,26,162,128,1,1,188,163,26,59,17,138,145,17,137,27,27,147,14,11,172,10,1,1]

theorem envBound55083 : H12AffineFastState.Bounded env55083 := by
  intro p hp
  have h : env55083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55082_55083 : H12AffineEnvironment.transform 5 10 env55082 = env55083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env55082 == env55083) = true)

theorem identity55083 : scanCanonicalize (H12AffineFastState.compose env55083 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound55083 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55084 : List Nat := [2,4,8,16,32,10,35,15,27,4,0,26,2,26,1,35,1,1,31,0,26,59,17,41,50,17,42,27,27,48,14,11,15,10,1,1]

theorem envBound55084 : H12AffineFastState.Bounded env55084 := by
  intro p hp
  have h : env55084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55083_55084 : H12AffineEnvironment.transform 6 35 env55083 = env55084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env55083 == env55084) = true)

theorem identity55084 : scanCanonicalize (H12AffineFastState.compose env55084 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound55084 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55085 : List Nat := [2,4,8,16,28,10,31,15,27,4,0,26,2,26,1,31,1,1,31,0,26,7,17,21,14,17,22,27,27,12,14,11,15,10,1,1]

theorem envBound55085 : H12AffineFastState.Bounded env55085 := by
  intro p hp
  have h : env55085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55084_55085 : H12AffineEnvironment.transform 4 28 env55084 = env55085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env55084 == env55085) = true)

theorem identity55085 : scanCanonicalize (H12AffineFastState.compose env55085 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound55085 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env55086 : List Nat := [2,4,8,10,6,10,5,15,1,4,0,0,2,0,1,5,1,1,5,0,0,7,11,15,14,11,12,1,1,12,14,11,15,10,1,1]

theorem envBound55086 : H12AffineFastState.Bounded env55086 := by
  intro p hp
  have h : env55086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55085_55086 : H12AffineEnvironment.transform 3 10 env55085 = env55086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env55085 == env55086) = true)

def env55087 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1297,9292,8495,1345,8622,273,9293,81,477,16,8558,9625,1360,366,1297,1296,3124,8204,1280,256,8201,1344,1808]

theorem envBound55087 : H12AffineFastState.Bounded env55087 := by
  intro p hp
  have h : env55087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55076_55087 : H12AffineEnvironment.transform 11 81 env55076 = env55087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env55076 == env55087) = true)

theorem identity55087 : scanCanonicalize (H12AffineFastState.compose env55087 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound55087 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env55088 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,268,1297,1344,35,1345,162,273,1345,81,477,16,98,1173,1360,366,1297,1296,3124,256,1280,256,261,1344,1808]

theorem envBound55088 : H12AffineFastState.Bounded env55088 := by
  intro p hp
  have h : env55088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55087_55088 : H12AffineEnvironment.transform 12 268 env55087 = env55088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env55087 == env55088) = true)

theorem identity55088 : scanCanonicalize (H12AffineFastState.compose env55088 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound55088 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env55089 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,81,268,1,80,35,81,162,273,81,81,477,16,98,389,64,366,1,0,2340,256,16,256,261,80,512]

theorem envBound55089 : H12AffineFastState.Bounded env55089 := by
  intro p hp
  have h : env55089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55088_55089 : H12AffineEnvironment.transform 9 272 env55088 = env55089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env55088 == env55089) = true)

theorem identity55089 : scanCanonicalize (H12AffineFastState.compose env55089 (packedSelected [2,5,8,13] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound55089 : packedSelected [2,5,8,13] rootPS < 2^1333 := by decide +kernel

def env55090 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,1,268,1,0,35,1,162,273,1,1,397,16,50,389,16,318,1,0,2340,256,16,256,261,0,512]

theorem envBound55090 : H12AffineFastState.Bounded env55090 := by
  intro p hp
  have h : env55090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55089_55090 : H12AffineEnvironment.transform 5 16 env55089 = env55090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env55089 == env55090) = true)

theorem identity55090 : scanCanonicalize (H12AffineFastState.compose env55090 (packedSelected [1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound55090 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env55091 : List Nat := [2,4,8,16,32,16,128,256,27,272,2048,1,268,1,0,35,1,162,273,1,1,397,16,50,389,16,318,1,0,2340,256,16,256,261,0,27]

theorem envBound55091 : H12AffineFastState.Bounded env55091 := by
  intro p hp
  have h : env55091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55090_55091 : H12AffineEnvironment.transform 8 27 env55090 = env55091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env55090 == env55091) = true)

theorem identity55091 : scanCanonicalize (H12AffineFastState.compose env55091 (packedSelected [3,8] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound55091 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env55092 : List Nat := [2,4,8,16,32,16,128,256,27,272,1,1,268,1,0,35,1,162,273,1,1,397,16,50,389,16,318,1,0,293,256,16,256,261,0,27]

theorem envBound55092 : H12AffineFastState.Bounded env55092 := by
  intro p hp
  have h : env55092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55091_55092 : H12AffineEnvironment.transform 10 1 env55091 = env55092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env55091 == env55092) = true)

theorem identity55092 : scanCanonicalize (H12AffineFastState.compose env55092 (packedSelected [1,2,3,10] rootPS)) = affineNative (2^(7+1) ^^^ 134) := by decide +kernel

theorem selectedBound55092 : packedSelected [1,2,3,10] rootPS < 2^1333 := by decide +kernel

def env55093 : List Nat := [2,4,8,16,32,16,128,134,27,150,1,1,138,1,0,35,1,162,151,1,1,11,16,50,3,16,184,1,0,163,134,16,134,131,0,27]

theorem envBound55093 : H12AffineFastState.Bounded env55093 := by
  intro p hp
  have h : env55093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55092_55093 : H12AffineEnvironment.transform 7 134 env55092 = env55093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 134 env55092 == env55093) = true)

theorem identity55093 : scanCanonicalize (H12AffineFastState.compose env55093 (packedSelected [0,1,2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound55093 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env55094 : List Nat := [2,4,8,11,32,11,128,134,0,141,1,1,138,1,0,35,1,162,140,1,1,11,11,41,3,11,163,1,0,163,134,11,134,131,0,0]

theorem envBound55094 : H12AffineFastState.Bounded env55094 := by
  intro p hp
  have h : env55094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55093_55094 : H12AffineEnvironment.transform 3 11 env55093 = env55094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env55093 == env55094) = true)

def env55095 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,524288,32769,4096,61649,91182,123165,533640,614527,385203,90415,545089,96347,25884,545105,256,82998,1344,525825]

theorem envBound55095 : H12AffineFastState.Bounded env55095 := by
  intro p hp
  have h : env55095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54917_55095 : H12AffineEnvironment.transform 23 123165 env54917 = env55095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123165 env54917 == env55095) = true)

def env55096 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,21584,32769,4096,61649,91182,123165,28888,78895,385203,90415,1297,96347,25884,1281,256,82998,1344,21073]

theorem envBound55096 : H12AffineFastState.Bounded env55096 := by
  intro p hp
  have h : env55096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55095_55096 : H12AffineEnvironment.transform 18 21584 env55095 = env55096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env55095 == env55096) = true)

theorem identity55096 : scanCanonicalize (H12AffineFastState.compose env55096 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25677) := by decide +kernel

theorem selectedBound55096 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env55097 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25677,65536,74862,262144,21584,25676,4096,5276,91182,66896,28888,78895,328958,90415,1297,96347,25884,1281,256,82998,1344,21073]

theorem envBound55097 : H12AffineFastState.Bounded env55097 := by
  intro p hp
  have h : env55097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55096_55097 : H12AffineEnvironment.transform 14 25677 env55096 = env55097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25677 env55096 == env55097) = true)

def env55098 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74862,262144,4416,8540,4096,5276,74046,66896,13768,78895,328958,74815,1297,81227,8204,1281,256,65830,1344,5953]

theorem envBound55098 : H12AffineFastState.Bounded env55098 := by
  intro p hp
  have h : env55098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55097_55098 : H12AffineEnvironment.transform 13 1296 env55097 = env55098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env55097 == env55098) = true)

def env55099 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74862,65664,4416,8540,4096,5276,74046,66896,13768,78895,1150,74815,1297,81227,8204,1281,256,65830,1344,5953]

theorem envBound55099 : H12AffineFastState.Bounded env55099 := by
  intro p hp
  have h : env55099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55098_55099 : H12AffineEnvironment.transform 17 65664 env55098 = env55099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env55098 == env55099) = true)

theorem identity55099 : scanCanonicalize (H12AffineFastState.compose env55099 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5465) := by decide +kernel

theorem selectedBound55099 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env55100 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5465,1296,5124,65536,69943,65664,4416,5125,4096,5276,70759,66896,145,65910,1150,69990,1297,67602,5461,1281,256,65830,1344,5953]

theorem envBound55100 : H12AffineFastState.Bounded env55100 := by
  intro p hp
  have h : env55100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55099_55100 : H12AffineEnvironment.transform 12 5465 env55099 = env55100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5465 env55099 == env55100) = true)

def env55101 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1556,845,1296,528,65536,67363,65664,1876,529,1556,648,66163,66896,145,65910,1150,67442,1297,67602,833,1281,256,65830,1344,341]

theorem envBound55101 : H12AffineFastState.Bounded env55101 := by
  intro p hp
  have h : env55101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55100_55101 : H12AffineEnvironment.transform 11 1556 env55100 = env55101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env55100 == env55101) = true)

def env55102 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,836,845,64,528,65536,66163,65664,516,529,836,648,66163,65536,145,65910,302,66082,65,67602,833,81,256,65830,16,341]

theorem envBound55102 : H12AffineFastState.Bounded env55102 := by
  intro p hp
  have h : env55102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55101_55102 : H12AffineEnvironment.transform 9 336 env55101 = env55102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env55101 == env55102) = true)

theorem identity55102 : scanCanonicalize (H12AffineFastState.compose env55102 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 532) := by decide +kernel

theorem selectedBound55102 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env55103 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,836,845,64,528,532,103,660,516,529,836,648,103,532,145,866,302,54,65,2566,833,81,256,818,16,341]

theorem envBound55103 : H12AffineFastState.Bounded env55103 := by
  intro p hp
  have h : env55103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55102_55103 : H12AffineEnvironment.transform 15 532 env55102 = env55103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 532 env55102 == env55103) = true)

def env55104 : List Nat := [2,4,8,16,32,64,128,256,152,336,2048,476,469,64,136,140,103,12,156,137,476,16,103,140,145,506,302,54,65,2206,473,81,256,426,16,341]

theorem envBound55104 : H12AffineFastState.Bounded env55104 := by
  intro p hp
  have h : env55104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55103_55104 : H12AffineEnvironment.transform 8 152 env55103 = env55104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 152 env55103 == env55104) = true)

theorem identity55104 : scanCanonicalize (H12AffineFastState.compose env55104 (packedSelected [0,1,3,5,8,10,12,15,17,19,21,27,38,41] rootPS)) = affineNative (2^(7+1) ^^^ 35) := by decide +kernel

theorem selectedBound55104 : packedSelected [0,1,3,5,8,10,12,15,17,19,21,27,38,41] rootPS < 2^1333 := by decide +kernel

def env55105 : List Nat := [2,4,8,16,32,64,128,35,152,115,2048,255,246,64,136,140,103,12,156,137,255,16,103,140,145,217,13,54,65,2206,250,81,35,137,16,118]

theorem envBound55105 : H12AffineFastState.Bounded env55105 := by
  intro p hp
  have h : env55105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55104_55105 : H12AffineEnvironment.transform 7 35 env55104 = env55105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 35 env55104 == env55105) = true)

theorem identity55105 : scanCanonicalize (H12AffineFastState.compose env55105 (packedSelected [4,5,7,9,12,15,19,20,23,27] rootPS)) = affineNative (2^(5+1) ^^^ 22) := by decide +kernel

theorem selectedBound55105 : packedSelected [4,5,7,9,12,15,19,20,23,27] rootPS < 2^1333 := by decide +kernel

def env55106 : List Nat := [2,4,8,16,32,22,128,35,152,37,2048,169,160,22,136,140,49,12,156,137,169,16,49,140,145,143,13,54,23,2206,172,7,35,137,16,32]

theorem envBound55106 : H12AffineFastState.Bounded env55106 := by
  intro p hp
  have h : env55106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55105_55106 : H12AffineEnvironment.transform 5 22 env55105 = env55106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 22 env55105 == env55106) = true)

theorem identity55106 : scanCanonicalize (H12AffineFastState.compose env55106 (packedSelected [0,3,4,7,9,12,13,15,16,17] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound55106 : packedSelected [0,3,4,7,9,12,13,15,16,17] rootPS < 2^1333 := by decide +kernel

def env55107 : List Nat := [2,4,8,13,32,11,128,35,133,37,2048,169,160,11,136,140,44,12,129,137,169,13,44,140,140,143,13,43,10,2179,172,7,35,137,13,32]

theorem envBound55107 : H12AffineFastState.Bounded env55107 := by
  intro p hp
  have h : env55107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55106_55107 : H12AffineEnvironment.transform 3 13 env55106 = env55107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env55106 == env55107) = true)

theorem identity55107 : scanCanonicalize (H12AffineFastState.compose env55107 (packedSelected [0,7,8,12] rootPS)) = affineNative (2^(10+1) ^^^ 142) := by decide +kernel

theorem selectedBound55107 : packedSelected [0,7,8,12] rootPS < 2^1333 := by decide +kernel

def env55108 : List Nat := [2,4,8,13,32,11,128,35,133,37,142,169,160,11,136,140,44,12,129,137,169,13,44,140,140,143,13,43,10,13,172,7,35,137,13,32]

theorem envBound55108 : H12AffineFastState.Bounded env55108 := by
  intro p hp
  have h : env55108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55107_55108 : H12AffineEnvironment.transform 10 142 env55107 = env55108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 142 env55107 == env55108) = true)

theorem identity55108 : scanCanonicalize (H12AffineFastState.compose env55108 (packedSelected [0,2,3,7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound55108 : packedSelected [0,2,3,7] rootPS < 2^1333 := by decide +kernel

def env55109 : List Nat := [2,4,8,13,10,11,128,9,133,15,142,131,138,11,136,140,6,12,129,137,131,13,6,140,140,143,13,1,10,13,134,7,9,137,13,10]

theorem envBound55109 : H12AffineFastState.Bounded env55109 := by
  intro p hp
  have h : env55109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55108_55109 : H12AffineEnvironment.transform 4 10 env55108 = env55109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env55108 == env55109) = true)

theorem identity55109 : scanCanonicalize (H12AffineFastState.compose env55109 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound55109 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55110 : List Nat := [2,4,8,13,10,11,3,9,6,15,13,0,9,11,11,15,6,12,2,10,0,13,6,15,15,12,13,1,10,13,5,7,9,10,13,10]

theorem envBound55110 : H12AffineFastState.Bounded env55110 := by
  intro p hp
  have h : env55110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55109_55110 : H12AffineEnvironment.transform 6 3 env55109 = env55110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env55109 == env55110) = true)

theorem identity55110 : scanCanonicalize (H12AffineFastState.compose env55110 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound55110 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env55111 : List Nat := [2,4,2,7,0,1,3,3,6,5,7,0,3,1,1,5,6,6,2,0,0,7,6,5,5,6,7,1,0,7,5,7,3,0,7,0]

theorem envBound55111 : H12AffineFastState.Bounded env55111 := by
  intro p hp
  have h : env55111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55110_55111 : H12AffineEnvironment.transform 2 2 env55110 = env55111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env55110 == env55111) = true)

theorem identity55111 : scanCanonicalize (H12AffineFastState.compose env55111 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound55111 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55112 : List Nat := [2,2,2,1,0,1,3,3,0,3,1,0,3,1,1,3,0,0,2,0,0,1,0,3,3,0,1,1,0,1,3,1,3,0,1,0]

theorem envBound55112 : H12AffineFastState.Bounded env55112 := by
  intro p hp
  have h : env55112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55111_55112 : H12AffineEnvironment.transform 1 2 env55111 = env55112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env55111 == env55112) = true)

def env55113 : List Nat := [2,4,8,16,32,64,128,256,153,336,2048,477,468,64,137,141,103,13,157,136,477,17,103,141,145,507,302,54,65,2207,472,81,256,427,16,341]

theorem envBound55113 : H12AffineFastState.Bounded env55113 := by
  intro p hp
  have h : env55113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55103_55113 : H12AffineEnvironment.transform 8 153 env55103 = env55113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 153 env55103 == env55113) = true)

theorem identity55113 : scanCanonicalize (H12AffineFastState.compose env55113 (packedSelected [0,1,3,5,8,10,12,15,17,19,21,27,38,41] rootPS)) = affineNative (2^(6+1) ^^^ 110) := by decide +kernel

theorem selectedBound55113 : packedSelected [0,1,3,5,8,10,12,15,17,19,21,27,38,41] rootPS < 2^1333 := by decide +kernel

def env55114 : List Nat := [2,4,8,16,32,64,110,256,119,336,2048,307,314,64,103,99,103,13,115,102,307,17,103,99,127,277,302,54,65,2161,310,81,256,325,16,341]

theorem envBound55114 : H12AffineFastState.Bounded env55114 := by
  intro p hp
  have h : env55114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55113_55114 : H12AffineEnvironment.transform 6 110 env55113 = env55114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 110 env55113 == env55114) = true)

theorem identity55114 : scanCanonicalize (H12AffineFastState.compose env55114 (packedSelected [0,3,4,7,9,10,12,13,15,16,18,24] rootPS)) = affineNative (2^(10+1) ^^^ 264) := by decide +kernel

theorem selectedBound55114 : packedSelected [0,3,4,7,9,10,12,13,15,16,18,24] rootPS < 2^1333 := by decide +kernel

def env55115 : List Nat := [2,4,8,16,32,64,110,256,119,336,264,307,314,64,103,99,103,13,115,102,307,17,103,99,127,277,302,54,65,377,310,81,256,325,16,341]

theorem envBound55115 : H12AffineFastState.Bounded env55115 := by
  intro p hp
  have h : env55115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55114_55115 : H12AffineEnvironment.transform 10 264 env55114 = env55115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 264 env55114 == env55115) = true)

theorem identity55115 : scanCanonicalize (H12AffineFastState.compose env55115 (packedSelected [1,2,3,4,5,7,8,11,12,13,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 45) := by decide +kernel

theorem selectedBound55115 : packedSelected [1,2,3,4,5,7,8,11,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env55116 : List Nat := [2,4,8,16,32,45,3,256,26,317,264,307,314,45,10,14,10,13,30,11,307,17,10,14,18,277,302,54,44,276,310,60,256,296,16,312]

theorem envBound55116 : H12AffineFastState.Bounded env55116 := by
  intro p hp
  have h : env55116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55115_55116 : H12AffineEnvironment.transform 5 45 env55115 = env55116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 45 env55115 == env55116) = true)

theorem identity55116 : scanCanonicalize (H12AffineFastState.compose env55116 (packedSelected [0,1,2,4,5,7,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 50) := by decide +kernel

theorem selectedBound55116 : packedSelected [0,1,2,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env55117 : List Nat := [2,4,8,16,32,45,3,50,26,15,58,1,8,45,10,14,10,13,30,11,1,17,10,14,18,39,28,54,44,38,4,60,50,26,16,10]

theorem envBound55117 : H12AffineFastState.Bounded env55117 := by
  intro p hp
  have h : env55117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55116_55117 : H12AffineEnvironment.transform 7 50 env55116 = env55117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 50 env55116 == env55117) = true)

theorem identity55117 : scanCanonicalize (H12AffineFastState.compose env55117 (packedSelected [0,1,5,7,8] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound55117 : packedSelected [0,1,5,7,8] rootPS < 2^1333 := by decide +kernel

def env55118 : List Nat := [2,4,8,10,32,45,3,40,0,15,32,1,8,45,10,14,10,13,4,11,1,11,10,14,8,39,6,44,44,38,4,38,40,0,10,10]

theorem envBound55118 : H12AffineFastState.Bounded env55118 := by
  intro p hp
  have h : env55118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55117_55118 : H12AffineEnvironment.transform 3 10 env55117 = env55118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env55117 == env55118) = true)

def env55119 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,837,845,65,528,65536,66162,65664,517,529,837,648,66163,65537,145,65910,303,66083,64,67602,833,80,256,65830,17,341]

theorem envBound55119 : H12AffineFastState.Bounded env55119 := by
  intro p hp
  have h : env55119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55101_55119 : H12AffineEnvironment.transform 9 337 env55101 = env55119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env55101 == env55119) = true)

theorem identity55119 : scanCanonicalize (H12AffineFastState.compose env55119 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 257) := by decide +kernel

theorem selectedBound55119 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env55120 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,837,845,65,528,257,883,385,517,529,837,648,882,256,145,119,303,802,64,2323,833,80,256,39,17,341]

theorem envBound55120 : H12AffineFastState.Bounded env55120 := by
  intro p hp
  have h : env55120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55119_55120 : H12AffineEnvironment.transform 15 257 env55119 = env55120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 257 env55119 == env55120) = true)

def env55121 : List Nat := [2,4,8,16,32,64,128,256,512,337,556,837,845,65,528,257,883,385,517,529,837,648,882,256,145,119,303,802,64,831,833,80,256,39,17,341]

theorem envBound55121 : H12AffineFastState.Bounded env55121 := by
  intro p hp
  have h : env55121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55120_55121 : H12AffineEnvironment.transform 10 556 env55120 = env55121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 556 env55120 == env55121) = true)

def env55122 : List Nat := [2,4,8,16,32,64,4,256,512,337,556,837,845,65,528,257,883,261,517,529,837,524,882,256,21,119,303,802,64,831,833,80,256,39,17,341]

theorem envBound55122 : H12AffineFastState.Bounded env55122 := by
  intro p hp
  have h : env55122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55121_55122 : H12AffineEnvironment.transform 6 4 env55121 = env55122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env55121 == env55122) = true)

theorem identity55122 : scanCanonicalize (H12AffineFastState.compose env55122 (packedSelected [2,3,4,5,9,12,17,18,20] rootPS)) = affineNative (2^(8+1) ^^^ 308) := by decide +kernel

theorem selectedBound55122 : packedSelected [2,3,4,5,9,12,17,18,20] rootPS < 2^1333 := by decide +kernel

def env55123 : List Nat := [2,4,8,16,32,64,4,256,308,337,280,113,121,65,292,257,71,261,305,293,113,312,70,256,21,119,303,22,64,11,117,80,256,39,17,341]

theorem envBound55123 : H12AffineFastState.Bounded env55123 := by
  intro p hp
  have h : env55123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55122_55123 : H12AffineEnvironment.transform 8 308 env55122 = env55123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env55122 == env55123) = true)

theorem identity55123 : scanCanonicalize (H12AffineFastState.compose env55123 (packedSelected [4,5,7,10,15,16] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound55123 : packedSelected [4,5,7,10,15,16] rootPS < 2^1333 := by decide +kernel

def env55124 : List Nat := [2,4,4,16,32,64,4,256,308,337,276,113,117,65,292,257,71,261,305,293,113,308,70,256,21,119,291,22,64,7,117,80,256,39,17,341]

theorem envBound55124 : H12AffineFastState.Bounded env55124 := by
  intro p hp
  have h : env55124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55123_55124 : H12AffineEnvironment.transform 2 4 env55123 = env55124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env55123 == env55124) = true)

theorem identity55124 : scanCanonicalize (H12AffineFastState.compose env55124 (packedSelected [1,2,3,8,12] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound55124 : packedSelected [1,2,3,8,12] rootPS < 2^1333 := by decide +kernel

def env55125 : List Nat := [2,4,4,16,22,64,4,256,258,337,276,71,67,65,274,257,71,261,263,275,71,258,70,256,21,65,277,22,64,7,67,80,256,17,17,341]

theorem envBound55125 : H12AffineFastState.Bounded env55125 := by
  intro p hp
  have h : env55125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55124_55125 : H12AffineEnvironment.transform 4 22 env55124 = env55125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env55124 == env55125) = true)

theorem identity55125 : scanCanonicalize (H12AffineFastState.compose env55125 (packedSelected [4,7] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound55125 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env55126 : List Nat := [2,4,4,16,22,0,4,256,258,273,276,7,3,1,274,257,7,261,263,275,7,258,6,256,21,1,277,22,0,7,3,16,256,17,17,277]

theorem envBound55126 : H12AffineFastState.Bounded env55126 := by
  intro p hp
  have h : env55126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55125_55126 : H12AffineEnvironment.transform 5 0 env55125 = env55126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env55125 == env55126) = true)

theorem identity55126 : scanCanonicalize (H12AffineFastState.compose env55126 (packedSelected [0,3,4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound55126 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env55127 : List Nat := [2,2,2,16,16,0,2,256,258,273,274,1,3,1,274,257,1,259,257,275,1,258,0,256,19,1,275,16,0,1,3,16,256,17,17,275]

theorem envBound55127 : H12AffineFastState.Bounded env55127 := by
  intro p hp
  have h : env55127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55126_55127 : H12AffineEnvironment.transform 1 2 env55126 = env55127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env55126 == env55127) = true)

theorem identity55127 : scanCanonicalize (H12AffineFastState.compose env55127 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound55127 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55128 : List Nat := [2,2,2,0,0,0,2,256,258,257,258,1,3,1,258,257,1,259,257,259,1,258,0,256,3,1,259,0,0,1,3,0,256,1,1,259]

theorem envBound55128 : H12AffineFastState.Bounded env55128 := by
  intro p hp
  have h : env55128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55127_55128 : H12AffineEnvironment.transform 3 0 env55127 = env55128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env55127 == env55128) = true)

theorem identity55128 : scanCanonicalize (H12AffineFastState.compose env55128 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 0) := by decide +kernel

theorem selectedBound55128 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55129 : List Nat := [2,2,2,0,0,0,2,0,2,1,2,1,3,1,2,1,1,3,1,3,1,2,0,0,3,1,3,0,0,1,3,0,0,1,1,3]

theorem envBound55129 : H12AffineFastState.Bounded env55129 := by
  intro p hp
  have h : env55129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55128_55129 : H12AffineEnvironment.transform 7 0 env55128 = env55129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 0 env55128 == env55129) = true)

theorem identity55129 : scanCanonicalize (H12AffineFastState.compose env55129 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound55129 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env55130 : List Nat := [1,1,1,0,0,0,1,0,1,1,1,1,0,1,1,1,1,0,1,0,1,1,0,0,0,1,0,0,0,1,0,0,0,1,1,0]

theorem envBound55130 : H12AffineFastState.Bounded env55130 := by
  intro p hp
  have h : env55130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55129_55130 : H12AffineEnvironment.transform 0 1 env55129 = env55130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env55129 == env55130) = true)

def env55131 : List Nat := [2,4,8,16,32,64,5,256,512,337,556,837,845,65,528,257,883,260,517,529,837,525,882,256,20,119,303,802,64,831,833,80,256,39,17,341]

theorem envBound55131 : H12AffineFastState.Bounded env55131 := by
  intro p hp
  have h : env55131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55121_55131 : H12AffineEnvironment.transform 6 5 env55121 = env55131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env55121 == env55131) = true)

theorem identity55131 : scanCanonicalize (H12AffineFastState.compose env55131 (packedSelected [2,3,4,5,9,12,17,18,20] rootPS)) = affineNative (2^(8+1) ^^^ 28) := by decide +kernel

theorem selectedBound55131 : packedSelected [2,3,4,5,9,12,17,18,20] rootPS < 2^1333 := by decide +kernel

def env55132 : List Nat := [2,4,8,16,32,64,5,256,28,337,48,345,337,65,12,257,367,260,25,13,345,17,366,256,20,119,303,318,64,291,349,80,256,39,17,341]

theorem envBound55132 : H12AffineFastState.Bounded env55132 := by
  intro p hp
  have h : env55132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55131_55132 : H12AffineEnvironment.transform 8 28 env55131 = env55132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 28 env55131 == env55132) = true)

theorem identity55132 : scanCanonicalize (H12AffineFastState.compose env55132 (packedSelected [0,1,2,3,4,8,11,13,15,18] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound55132 : packedSelected [0,1,2,3,4,8,11,13,15,18] rootPS < 2^1333 := by decide +kernel

def env55133 : List Nat := [2,4,8,16,32,64,5,14,28,95,48,87,95,65,12,15,97,10,25,13,87,17,96,14,20,119,33,48,64,45,83,80,14,39,17,91]

theorem envBound55133 : H12AffineFastState.Bounded env55133 := by
  intro p hp
  have h : env55133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55132_55133 : H12AffineEnvironment.transform 7 14 env55132 = env55133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env55132 == env55133) = true)

theorem identity55133 : scanCanonicalize (H12AffineFastState.compose env55133 (packedSelected [0,1,5,8,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound55133 : packedSelected [0,1,5,8,9,10] rootPS < 2^1333 := by decide +kernel

def env55134 : List Nat := [2,4,8,16,32,12,5,14,28,19,48,27,19,13,12,15,45,10,25,13,27,17,44,14,20,59,33,48,12,45,31,28,14,39,17,23]

theorem envBound55134 : H12AffineFastState.Bounded env55134 := by
  intro p hp
  have h : env55134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55133_55134 : H12AffineEnvironment.transform 5 12 env55133 = env55134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env55133 == env55134) = true)

theorem identity55134 : scanCanonicalize (H12AffineFastState.compose env55134 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound55134 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env55135 : List Nat := [2,4,8,16,26,12,5,14,28,19,10,27,19,13,12,15,23,10,25,13,27,17,22,14,20,1,27,10,12,23,31,28,14,29,17,23]

theorem envBound55135 : H12AffineFastState.Bounded env55135 := by
  intro p hp
  have h : env55135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55134_55135 : H12AffineEnvironment.transform 4 26 env55134 = env55135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env55134 == env55135) = true)

theorem identity55135 : scanCanonicalize (H12AffineFastState.compose env55135 (packedSelected [0,1,4] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound55135 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env55136 : List Nat := [2,4,8,11,1,12,5,14,7,8,10,0,8,13,12,15,12,10,2,13,0,10,13,14,15,1,0,10,12,12,4,7,14,6,10,12]

theorem envBound55136 : H12AffineFastState.Bounded env55136 := by
  intro p hp
  have h : env55136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55135_55136 : H12AffineEnvironment.transform 3 11 env55135 = env55136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env55135 == env55136) = true)

theorem identity55136 : scanCanonicalize (H12AffineFastState.compose env55136 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound55136 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55137 : List Nat := [2,4,3,0,1,7,5,5,7,3,1,0,3,6,7,4,7,1,2,6,0,1,6,5,4,1,0,1,7,7,4,7,5,6,1,7]

theorem envBound55137 : H12AffineFastState.Bounded env55137 := by
  intro p hp
  have h : env55137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55136_55137 : H12AffineEnvironment.transform 2 3 env55136 = env55137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env55136 == env55137) = true)

theorem identity55137 : scanCanonicalize (H12AffineFastState.compose env55137 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound55137 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55138 : List Nat := [2,3,3,0,1,0,2,2,0,3,1,0,3,1,0,3,0,1,2,1,0,1,1,2,3,1,0,1,0,0,3,0,2,1,1,0]

theorem envBound55138 : H12AffineFastState.Bounded env55138 := by
  intro p hp
  have h : env55138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55137_55138 : H12AffineEnvironment.transform 1 3 env55137 = env55138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env55137 == env55138) = true)

def env55139 : List Nat := [2,4,8,16,32,64,128,256,512,337,557,837,845,65,528,257,883,385,517,529,837,648,882,256,145,119,303,802,64,830,833,80,256,39,17,341]

theorem envBound55139 : H12AffineFastState.Bounded env55139 := by
  intro p hp
  have h : env55139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55120_55139 : H12AffineEnvironment.transform 10 557 env55120 = env55139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 557 env55120 == env55139) = true)

def env55140 : List Nat := [2,4,8,16,32,64,4,256,512,337,557,837,845,65,528,257,883,261,517,529,837,524,882,256,21,119,303,802,64,830,833,80,256,39,17,341]

theorem envBound55140 : H12AffineFastState.Bounded env55140 := by
  intro p hp
  have h : env55140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55139_55140 : H12AffineEnvironment.transform 6 4 env55139 = env55140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env55139 == env55140) = true)

theorem identity55140 : scanCanonicalize (H12AffineFastState.compose env55140 (packedSelected [2,3,4,5,9,12,17,18,20] rootPS)) = affineNative (2^(8+1) ^^^ 60) := by decide +kernel

theorem selectedBound55140 : packedSelected [2,3,4,5,9,12,17,18,20] rootPS < 2^1333 := by decide +kernel

def env55141 : List Nat := [2,4,8,16,32,64,4,256,60,337,17,377,369,65,44,257,335,261,57,45,377,48,334,256,21,119,303,286,64,258,381,80,256,39,17,341]

theorem envBound55141 : H12AffineFastState.Bounded env55141 := by
  intro p hp
  have h : env55141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55140_55141 : H12AffineEnvironment.transform 8 60 env55140 = env55141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 60 env55140 == env55141) = true)

theorem identity55141 : scanCanonicalize (H12AffineFastState.compose env55141 (packedSelected [0,1,2,5,7,11,12,13,16,17] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound55141 : packedSelected [0,1,2,5,7,11,12,13,16,17] rootPS < 2^1333 := by decide +kernel

def env55142 : List Nat := [2,4,8,16,32,12,4,256,60,285,17,309,317,13,44,257,259,261,57,45,309,48,258,256,21,59,303,286,12,258,305,28,256,39,17,281]

theorem envBound55142 : H12AffineFastState.Bounded env55142 := by
  intro p hp
  have h : env55142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55141_55142 : H12AffineEnvironment.transform 5 12 env55141 = env55142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env55141 == env55142) = true)

theorem identity55142 : scanCanonicalize (H12AffineFastState.compose env55142 (packedSelected [1,2,8] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound55142 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env55143 : List Nat := [2,4,8,16,27,12,4,256,7,285,17,270,262,13,23,257,259,261,2,22,270,11,258,256,21,0,276,286,12,258,266,28,256,28,17,281]

theorem envBound55143 : H12AffineFastState.Bounded env55143 := by
  intro p hp
  have h : env55143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55142_55143 : H12AffineEnvironment.transform 4 27 env55142 = env55143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env55142 == env55143) = true)

theorem identity55143 : scanCanonicalize (H12AffineFastState.compose env55143 (packedSelected [0,2,4] rootPS)) = affineNative (2^(7+1) ^^^ 30) := by decide +kernel

theorem selectedBound55143 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env55144 : List Nat := [2,4,8,16,27,12,4,30,7,3,17,16,24,13,23,31,29,27,2,22,16,11,28,30,21,0,10,0,12,28,20,28,30,28,17,7]

theorem envBound55144 : H12AffineFastState.Bounded env55144 := by
  intro p hp
  have h : env55144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55143_55144 : H12AffineEnvironment.transform 7 30 env55143 = env55144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 30 env55143 == env55144) = true)

theorem identity55144 : scanCanonicalize (H12AffineFastState.compose env55144 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound55144 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55145 : List Nat := [2,4,5,16,22,1,4,19,7,3,17,16,21,0,23,18,16,22,2,22,16,6,17,19,21,0,7,0,1,17,20,17,19,17,17,7]

theorem envBound55145 : H12AffineFastState.Bounded env55145 := by
  intro p hp
  have h : env55145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55144_55145 : H12AffineEnvironment.transform 2 5 env55144 = env55145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env55144 == env55145) = true)

theorem identity55145 : scanCanonicalize (H12AffineFastState.compose env55145 (packedSelected [1,2] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound55145 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env55146 : List Nat := [2,4,5,7,1,1,4,4,7,3,6,7,2,0,0,5,7,1,2,1,7,6,6,4,2,0,7,0,1,6,3,6,4,6,6,7]

theorem envBound55146 : H12AffineFastState.Bounded env55146 := by
  intro p hp
  have h : env55146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55145_55146 : H12AffineEnvironment.transform 3 7 env55145 = env55146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env55145 == env55146) = true)

def env55147 : List Nat := [2,4,8,16,32,64,5,256,512,337,557,837,845,65,528,257,883,260,517,529,837,525,882,256,20,119,303,802,64,830,833,80,256,39,17,341]

theorem envBound55147 : H12AffineFastState.Bounded env55147 := by
  intro p hp
  have h : env55147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55139_55147 : H12AffineEnvironment.transform 6 5 env55139 = env55147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env55139 == env55147) = true)

theorem identity55147 : scanCanonicalize (H12AffineFastState.compose env55147 (packedSelected [2,3,4,5,9,12,17,18,20] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound55147 : packedSelected [2,3,4,5,9,12,17,18,20] rootPS < 2^1333 := by decide +kernel

def env55148 : List Nat := [2,4,8,16,32,64,5,256,277,337,312,80,88,65,261,257,102,260,272,260,80,280,103,256,20,119,303,55,64,43,84,80,256,39,17,341]

theorem envBound55148 : H12AffineFastState.Bounded env55148 := by
  intro p hp
  have h : env55148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55147_55148 : H12AffineEnvironment.transform 8 277 env55147 = env55148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env55147 == env55148) = true)

theorem identity55148 : scanCanonicalize (H12AffineFastState.compose env55148 (packedSelected [3,5,8,10,13,15] rootPS)) = affineNative (2^(5+1) ^^^ 39) := by decide +kernel

theorem selectedBound55148 : packedSelected [3,5,8,10,13,15] rootPS < 2^1333 := by decide +kernel

def env55149 : List Nat := [2,4,8,16,32,39,5,256,277,310,312,55,63,38,261,257,1,260,272,260,55,280,0,256,20,16,303,55,39,43,51,55,256,39,17,306]

theorem envBound55149 : H12AffineFastState.Bounded env55149 := by
  intro p hp
  have h : env55149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55148_55149 : H12AffineEnvironment.transform 5 39 env55148 = env55149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 39 env55148 == env55149) = true)

theorem identity55149 : scanCanonicalize (H12AffineFastState.compose env55149 (packedSelected [3,7,9,10,11] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound55149 : packedSelected [3,7,9,10,11] rootPS < 2^1333 := by decide +kernel

def env55150 : List Nat := [2,4,8,16,0,7,5,256,277,278,280,23,31,6,261,257,1,260,272,260,23,280,0,256,20,16,271,23,7,11,19,23,256,7,17,274]

theorem envBound55150 : H12AffineFastState.Bounded env55150 := by
  intro p hp
  have h : env55150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55149_55150 : H12AffineEnvironment.transform 4 0 env55149 = env55150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env55149 == env55150) = true)

theorem identity55150 : scanCanonicalize (H12AffineFastState.compose env55150 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound55150 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env55151 : List Nat := [2,4,8,1,0,7,5,256,260,263,265,6,14,6,261,257,1,260,257,260,6,265,0,256,5,1,271,6,7,11,2,6,256,7,0,259]

theorem envBound55151 : H12AffineFastState.Bounded env55151 := by
  intro p hp
  have h : env55151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55150_55151 : H12AffineEnvironment.transform 3 1 env55150 = env55151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env55150 == env55151) = true)

theorem identity55151 : scanCanonicalize (H12AffineFastState.compose env55151 (packedSelected [0,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound55151 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env55152 : List Nat := [2,3,8,1,0,0,2,256,259,256,265,1,9,1,258,257,1,259,257,259,1,265,0,256,2,1,264,1,0,11,2,1,256,0,0,259]

theorem envBound55152 : H12AffineFastState.Bounded env55152 := by
  intro p hp
  have h : env55152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55151_55152 : H12AffineEnvironment.transform 1 3 env55151 = env55152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env55151 == env55152) = true)

theorem identity55152 : scanCanonicalize (H12AffineFastState.compose env55152 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound55152 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55153 : List Nat := [2,3,3,1,0,0,2,256,259,256,258,1,2,1,258,257,1,259,257,259,1,258,0,256,2,1,259,1,0,0,2,1,256,0,0,259]

theorem envBound55153 : H12AffineFastState.Bounded env55153 := by
  intro p hp
  have h : env55153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55152_55153 : H12AffineEnvironment.transform 2 3 env55152 = env55153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env55152 == env55153) = true)

def env55154 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1557,844,1296,529,65536,67362,65664,1877,528,1557,649,66162,66896,145,65910,1150,67443,1297,67602,832,1281,256,65830,1344,340]

theorem envBound55154 : H12AffineFastState.Bounded env55154 := by
  intro p hp
  have h : env55154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55100_55154 : H12AffineEnvironment.transform 11 1557 env55100 = env55154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env55100 == env55154) = true)

def env55155 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,837,844,64,529,65536,66162,65664,517,528,837,649,66162,65536,145,65910,302,66083,65,67602,832,81,256,65830,16,340]

theorem envBound55155 : H12AffineFastState.Bounded env55155 := by
  intro p hp
  have h : env55155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55154_55155 : H12AffineEnvironment.transform 9 336 env55154 = env55155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env55154 == env55155) = true)

theorem identity55155 : scanCanonicalize (H12AffineFastState.compose env55155 (packedSelected [1,8,28] rootPS)) = affineNative (2^(5+1) ^^^ 55) := by decide +kernel

theorem selectedBound55155 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env55156 : List Nat := [2,4,8,16,32,55,128,256,512,295,2048,818,827,55,529,65536,66053,65664,517,528,818,649,66053,65536,145,65793,302,66083,54,67602,823,38,256,65830,16,291]

theorem envBound55156 : H12AffineFastState.Bounded env55156 := by
  intro p hp
  have h : env55156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55155_55156 : H12AffineEnvironment.transform 5 55 env55155 = env55156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 55 env55155 == env55156) = true)

def env55157 : List Nat := [2,4,8,16,32,55,128,256,512,295,2048,818,827,55,529,316,825,444,517,528,818,649,825,316,145,61,302,799,54,2350,823,38,256,26,16,291]

theorem envBound55157 : H12AffineFastState.Bounded env55157 := by
  intro p hp
  have h : env55157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55156_55157 : H12AffineEnvironment.transform 15 316 env55156 = env55157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 316 env55156 == env55157) = true)

theorem identity55157 : scanCanonicalize (H12AffineFastState.compose env55157 (packedSelected [0,1,3,4,5,7,9,10,13,15,16,19,20,24] rootPS)) = affineNative (2^(10+1) ^^^ 654) := by decide +kernel

theorem selectedBound55157 : packedSelected [0,1,3,4,5,7,9,10,13,15,16,19,20,24] rootPS < 2^1333 := by decide +kernel

def env55158 : List Nat := [2,4,8,16,32,55,128,256,512,295,654,818,827,55,529,316,825,444,517,528,818,649,825,316,145,61,302,799,54,928,823,38,256,26,16,291]

theorem envBound55158 : H12AffineFastState.Bounded env55158 := by
  intro p hp
  have h : env55158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55157_55158 : H12AffineEnvironment.transform 10 654 env55157 = env55158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 654 env55157 == env55158) = true)

theorem identity55158 : scanCanonicalize (H12AffineFastState.compose env55158 (packedSelected [0,2,4,5,10,12,13,16,18,19,23] rootPS)) = affineNative (2^(8+1) ^^^ 302) := by decide +kernel

theorem selectedBound55158 : packedSelected [0,2,4,5,10,12,13,16,18,19,23] rootPS < 2^1333 := by decide +kernel

def env55159 : List Nat := [2,4,8,16,32,55,128,256,302,295,416,28,21,55,319,316,23,444,299,318,28,423,23,316,145,61,302,49,54,142,25,38,256,26,16,291]

theorem envBound55159 : H12AffineFastState.Bounded env55159 := by
  intro p hp
  have h : env55159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55158_55159 : H12AffineEnvironment.transform 8 302 env55158 = env55159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 302 env55158 == env55159) = true)

theorem identity55159 : scanCanonicalize (H12AffineFastState.compose env55159 (packedSelected [0,1,2,5,7,8,10,11,15] rootPS)) = affineNative (2^(7+1) ^^^ 156) := by decide +kernel

theorem selectedBound55159 : packedSelected [0,1,2,5,7,8,10,11,15] rootPS < 2^1333 := by decide +kernel

def env55160 : List Nat := [2,4,8,16,32,55,128,156,178,187,60,28,21,55,163,160,23,32,183,162,28,59,23,160,145,61,178,49,54,142,25,38,156,26,16,191]

theorem envBound55160 : H12AffineFastState.Bounded env55160 := by
  intro p hp
  have h : env55160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55159_55160 : H12AffineEnvironment.transform 7 156 env55159 = env55160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 156 env55159 == env55160) = true)

theorem identity55160 : scanCanonicalize (H12AffineFastState.compose env55160 (packedSelected [0,5,9] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound55160 : packedSelected [0,5,9] rootPS < 2^1333 := by decide +kernel

def env55161 : List Nat := [2,4,8,16,27,12,128,156,137,128,7,28,21,12,152,155,23,27,140,153,28,0,23,155,145,6,137,10,13,142,25,29,156,26,16,132]

theorem envBound55161 : H12AffineFastState.Bounded env55161 := by
  intro p hp
  have h : env55161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55160_55161 : H12AffineEnvironment.transform 4 27 env55160 = env55161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env55160 == env55161) = true)

theorem identity55161 : scanCanonicalize (H12AffineFastState.compose env55161 (packedSelected [1,2,3,4,5,7,8] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound55161 : packedSelected [1,2,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env55162 : List Nat := [2,4,8,13,6,12,128,129,137,128,7,1,8,12,133,134,10,6,140,132,1,0,10,134,140,6,137,10,13,142,4,0,129,7,13,132]

theorem envBound55162 : H12AffineFastState.Bounded env55162 := by
  intro p hp
  have h : env55162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55161_55162 : H12AffineEnvironment.transform 3 13 env55161 = env55162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env55161 == env55162) = true)

theorem identity55162 : scanCanonicalize (H12AffineFastState.compose env55162 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound55162 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env55163 : List Nat := [2,4,8,13,6,12,15,14,6,15,7,1,8,12,10,9,10,6,3,11,1,0,10,9,3,6,6,10,13,1,4,0,14,7,13,11]

theorem envBound55163 : H12AffineFastState.Bounded env55163 := by
  intro p hp
  have h : env55163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55162_55163 : H12AffineEnvironment.transform 6 15 env55162 = env55163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env55162 == env55163) = true)

theorem identity55163 : scanCanonicalize (H12AffineFastState.compose env55163 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound55163 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55164 : List Nat := [2,3,8,10,1,11,8,9,1,8,0,1,8,11,10,9,10,1,3,11,1,0,10,9,3,1,1,10,10,1,3,0,9,0,10,11]

theorem envBound55164 : H12AffineFastState.Bounded env55164 := by
  intro p hp
  have h : env55164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55163_55164 : H12AffineEnvironment.transform 1 3 env55163 = env55164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env55163 == env55164) = true)

def env55165 : List Nat := [2,4,8,16,32,55,128,256,512,295,2048,818,827,55,529,317,824,445,517,528,818,649,824,317,145,60,302,798,54,2351,823,38,256,27,16,291]

theorem envBound55165 : H12AffineFastState.Bounded env55165 := by
  intro p hp
  have h : env55165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55156_55165 : H12AffineEnvironment.transform 15 317 env55156 = env55165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 317 env55156 == env55165) = true)

theorem identity55165 : scanCanonicalize (H12AffineFastState.compose env55165 (packedSelected [0,1,3,4,5,7,9,10,13,15,16,19,20,24] rootPS)) = affineNative (2^(10+1) ^^^ 411) := by decide +kernel

theorem selectedBound55165 : packedSelected [0,1,3,4,5,7,9,10,13,15,16,19,20,24] rootPS < 2^1333 := by decide +kernel

def env55166 : List Nat := [2,4,8,16,32,55,128,256,512,295,411,818,827,55,529,317,824,445,517,528,818,649,824,317,145,60,302,798,54,180,823,38,256,27,16,291]

theorem envBound55166 : H12AffineFastState.Bounded env55166 := by
  intro p hp
  have h : env55166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55165_55166 : H12AffineEnvironment.transform 10 411 env55165 = env55166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 411 env55165 == env55166) = true)

theorem identity55166 : scanCanonicalize (H12AffineFastState.compose env55166 (packedSelected [0,1,4,5,8,11,12,17,18,19] rootPS)) = affineNative (2^(8+1) ^^^ 286) := by decide +kernel

theorem selectedBound55166 : packedSelected [0,1,4,5,8,11,12,17,18,19] rootPS < 2^1333 := by decide +kernel

def env55167 : List Nat := [2,4,8,16,32,55,128,256,286,295,411,44,37,55,271,317,38,445,283,270,44,407,38,317,145,60,302,0,54,180,41,38,256,27,16,291]

theorem envBound55167 : H12AffineFastState.Bounded env55167 := by
  intro p hp
  have h : env55167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55166_55167 : H12AffineEnvironment.transform 8 286 env55166 = env55167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 286 env55166 == env55167) = true)

theorem identity55167 : scanCanonicalize (H12AffineFastState.compose env55167 (packedSelected [0,7,10,12,13] rootPS)) = affineNative (2^(6+1) ^^^ 20) := by decide +kernel

theorem selectedBound55167 : packedSelected [0,7,10,12,13] rootPS < 2^1333 := by decide +kernel

def env55168 : List Nat := [2,4,8,16,32,55,20,256,286,295,271,44,37,55,271,317,38,297,283,270,44,259,38,317,5,60,302,0,54,32,41,38,256,27,16,291]

theorem envBound55168 : H12AffineFastState.Bounded env55168 := by
  intro p hp
  have h : env55168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55167_55168 : H12AffineEnvironment.transform 6 20 env55167 = env55168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 20 env55167 == env55168) = true)

theorem identity55168 : scanCanonicalize (H12AffineFastState.compose env55168 (packedSelected [1,2,3,4,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound55168 : packedSelected [1,2,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env55169 : List Nat := [2,4,8,16,32,55,20,52,42,19,59,44,37,55,59,9,38,29,47,58,44,55,38,9,5,60,26,0,54,32,41,38,52,27,16,23]

theorem envBound55169 : H12AffineFastState.Bounded env55169 := by
  intro p hp
  have h : env55169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55168_55169 : H12AffineEnvironment.transform 7 52 env55168 = env55169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env55168 == env55169) = true)

theorem identity55169 : scanCanonicalize (H12AffineFastState.compose env55169 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound55169 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env55170 : List Nat := [2,4,8,13,32,42,9,41,42,14,38,44,37,42,38,9,38,0,47,39,44,42,38,9,5,33,7,0,43,32,41,38,41,6,13,10]

theorem envBound55170 : H12AffineFastState.Bounded env55170 := by
  intro p hp
  have h : env55170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55169_55170 : H12AffineEnvironment.transform 3 13 env55169 = env55170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env55169 == env55170) = true)

theorem identity55170 : scanCanonicalize (H12AffineFastState.compose env55170 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound55170 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55171 : List Nat := [2,4,2,7,32,32,3,35,32,4,38,38,37,32,38,3,38,0,37,39,38,32,38,3,5,33,7,0,33,32,35,38,35,6,7,0]

theorem envBound55171 : H12AffineFastState.Bounded env55171 := by
  intro p hp
  have h : env55171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55170_55171 : H12AffineEnvironment.transform 2 2 env55170 = env55171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env55170 == env55171) = true)

theorem identity55171 : scanCanonicalize (H12AffineFastState.compose env55171 (packedSelected [2,3] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound55171 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env55172 : List Nat := [2,4,2,7,6,6,3,5,6,4,0,0,3,6,0,3,0,0,3,1,0,6,0,3,5,7,7,0,7,6,5,0,5,6,7,0]

theorem envBound55172 : H12AffineFastState.Bounded env55172 := by
  intro p hp
  have h : env55172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55171_55172 : H12AffineEnvironment.transform 4 6 env55171 = env55172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env55171 == env55172) = true)

theorem identity55172 : scanCanonicalize (H12AffineFastState.compose env55172 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound55172 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env55173 : List Nat := [2,2,2,1,0,0,3,3,0,2,0,0,3,0,0,3,0,0,3,1,0,0,0,3,3,1,1,0,1,0,3,0,3,0,1,0]

theorem envBound55173 : H12AffineFastState.Bounded env55173 := by
  intro p hp
  have h : env55173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55172_55173 : H12AffineEnvironment.transform 1 2 env55172 = env55173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env55172 == env55173) = true)

def env55174 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,836,844,65,529,65536,66163,65664,516,528,836,649,66162,65537,145,65910,303,66082,64,67602,832,80,256,65830,17,340]

theorem envBound55174 : H12AffineFastState.Bounded env55174 := by
  intro p hp
  have h : env55174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55154_55174 : H12AffineEnvironment.transform 9 337 env55154 = env55174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env55154 == env55174) = true)

theorem identity55174 : scanCanonicalize (H12AffineFastState.compose env55174 (packedSelected [1,8,28] rootPS)) = affineNative (2^(8+1) ^^^ 355) := by decide +kernel

theorem selectedBound55174 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env55175 : List Nat := [2,4,8,16,32,64,128,256,355,337,2048,39,47,65,370,65536,65808,65664,359,371,39,490,65809,65537,145,65910,303,65857,64,67602,35,80,256,65830,17,340]

theorem envBound55175 : H12AffineFastState.Bounded env55175 := by
  intro p hp
  have h : env55175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55174_55175 : H12AffineEnvironment.transform 8 355 env55174 = env55175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 355 env55174 == env55175) = true)

def env55176 : List Nat := [2,4,8,16,32,60,128,256,287,301,2048,39,47,61,270,65536,65808,65664,283,271,39,406,65809,65537,145,65802,303,65853,60,67602,35,44,256,65830,17,296]

theorem envBound55176 : H12AffineFastState.Bounded env55176 := by
  intro p hp
  have h : env55176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55175_55176 : H12AffineEnvironment.transform 5 60 env55175 = env55176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 60 env55175 == env55176) = true)

theorem identity55176 : scanCanonicalize (H12AffineFastState.compose env55176 (packedSelected [0,7,8,12,13,17,20,21,24,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 2193) := by decide +kernel

theorem selectedBound55176 : packedSelected [0,7,8,12,13,17,20,21,24,38,41] rootPS < 2^1333 := by decide +kernel

def env55177 : List Nat := [2,4,8,16,32,60,128,256,287,301,2048,39,47,61,270,2193,2433,2065,283,271,39,406,2432,2192,145,2459,303,2476,60,131,35,44,256,2487,17,296]

theorem envBound55177 : H12AffineFastState.Bounded env55177 := by
  intro p hp
  have h : env55177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55176_55177 : H12AffineEnvironment.transform 15 2193 env55176 = env55177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2193 env55176 == env55177) = true)

theorem identity55177 : scanCanonicalize (H12AffineFastState.compose env55177 (packedSelected [3,4,5,9,18,23,24] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound55177 : packedSelected [3,4,5,9,18,23,24] rootPS < 2^1333 := by decide +kernel

def env55178 : List Nat := [2,4,8,16,32,60,128,256,287,301,0,39,47,61,270,145,385,17,283,271,39,406,384,144,145,411,303,428,60,131,35,44,256,439,17,296]

theorem envBound55178 : H12AffineFastState.Bounded env55178 := by
  intro p hp
  have h : env55178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55177_55178 : H12AffineEnvironment.transform 10 0 env55177 = env55178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env55177 == env55178) = true)

theorem identity55178 : scanCanonicalize (H12AffineFastState.compose env55178 (packedSelected [0,1,2,4,8,12,15] rootPS)) = affineNative (2^(4+1) ^^^ 29) := by decide +kernel

theorem selectedBound55178 : packedSelected [0,1,2,4,8,12,15] rootPS < 2^1333 := by decide +kernel

def env55179 : List Nat := [2,4,8,16,29,1,128,256,287,272,0,26,18,0,270,145,385,17,283,271,26,406,384,144,145,411,274,401,1,131,30,17,256,394,17,277]

theorem envBound55179 : H12AffineFastState.Bounded env55179 := by
  intro p hp
  have h : env55179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55178_55179 : H12AffineEnvironment.transform 4 29 env55178 = env55179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env55178 == env55179) = true)

theorem identity55179 : scanCanonicalize (H12AffineFastState.compose env55179 (packedSelected [1,3,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound55179 : packedSelected [1,3,7,9] rootPS < 2^1333 := by decide +kernel

def env55180 : List Nat := [2,4,8,16,29,1,15,256,287,272,0,26,18,0,270,30,270,17,283,271,26,281,271,31,30,276,274,286,1,12,30,17,256,261,17,277]

theorem envBound55180 : H12AffineFastState.Bounded env55180 := by
  intro p hp
  have h : env55180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55179_55180 : H12AffineEnvironment.transform 6 15 env55179 = env55180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env55179 == env55180) = true)

theorem identity55180 : scanCanonicalize (H12AffineFastState.compose env55180 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 19) := by decide +kernel

theorem selectedBound55180 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env55181 : List Nat := [2,4,8,16,29,1,15,19,12,3,0,26,18,0,29,30,29,17,8,28,26,10,28,31,30,7,1,13,1,12,30,17,19,22,17,6]

theorem envBound55181 : H12AffineFastState.Bounded env55181 := by
  intro p hp
  have h : env55181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55180_55181 : H12AffineEnvironment.transform 7 19 env55180 = env55181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 19 env55180 == env55181) = true)

theorem identity55181 : scanCanonicalize (H12AffineFastState.compose env55181 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound55181 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env55182 : List Nat := [2,4,8,12,1,1,15,15,12,3,0,6,14,0,1,2,1,13,8,0,6,10,0,3,2,7,1,13,1,12,2,13,15,10,13,6]

theorem envBound55182 : H12AffineFastState.Bounded env55182 := by
  intro p hp
  have h : env55182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55181_55182 : H12AffineEnvironment.transform 3 12 env55181 = env55182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env55181 == env55182) = true)

theorem identity55182 : scanCanonicalize (H12AffineFastState.compose env55182 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound55182 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env55183 : List Nat := [2,4,5,1,1,1,2,2,1,3,0,6,3,0,1,2,1,0,5,0,6,7,0,3,2,7,1,0,1,1,2,0,2,7,0,6]

theorem envBound55183 : H12AffineFastState.Bounded env55183 := by
  intro p hp
  have h : env55183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55182_55183 : H12AffineEnvironment.transform 2 5 env55182 = env55183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env55182 == env55183) = true)

def env55184 : List Nat := [2,4,8,16,32,61,128,256,286,300,2048,39,47,60,271,65536,65808,65664,282,270,39,407,65809,65537,145,65803,303,65852,61,67602,35,45,256,65830,17,297]

theorem envBound55184 : H12AffineFastState.Bounded env55184 := by
  intro p hp
  have h : env55184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55175_55184 : H12AffineEnvironment.transform 5 61 env55175 = env55184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 61 env55175 == env55184) = true)

theorem identity55184 : scanCanonicalize (H12AffineFastState.compose env55184 (packedSelected [0,7,8,12,13,17,20,21,24,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 2202) := by decide +kernel

theorem selectedBound55184 : packedSelected [0,7,8,12,13,17,20,21,24,38,41] rootPS < 2^1333 := by decide +kernel

def env55185 : List Nat := [2,4,8,16,32,61,128,256,286,300,2048,39,47,60,271,2202,2442,2074,282,270,39,407,2443,2203,145,2449,303,2470,61,136,35,45,256,2492,17,297]

theorem envBound55185 : H12AffineFastState.Bounded env55185 := by
  intro p hp
  have h : env55185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55184_55185 : H12AffineEnvironment.transform 15 2202 env55184 = env55185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2202 env55184 == env55185) = true)

theorem identity55185 : scanCanonicalize (H12AffineFastState.compose env55185 (packedSelected [2,5,8,11,15,18,19,20,21] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound55185 : packedSelected [2,5,8,11,15,18,19,20,21] rootPS < 2^1333 := by decide +kernel

def env55186 : List Nat := [2,4,8,16,32,61,128,256,286,300,11,39,47,60,271,145,385,17,282,270,39,407,384,144,145,410,303,429,61,136,35,45,256,439,17,297]

theorem envBound55186 : H12AffineFastState.Bounded env55186 := by
  intro p hp
  have h : env55186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55185_55186 : H12AffineEnvironment.transform 10 11 env55185 = env55186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env55185 == env55186) = true)

theorem identity55186 : scanCanonicalize (H12AffineFastState.compose env55186 (packedSelected [0,2,4,5,8,12,13,16,17] rootPS)) = affineNative (2^(6+1) ^^^ 62) := by decide +kernel

theorem selectedBound55186 : packedSelected [0,2,4,5,8,12,13,16,17] rootPS < 2^1333 := by decide +kernel

def env55187 : List Nat := [2,4,8,16,32,61,62,256,286,300,11,39,47,60,271,47,319,17,282,270,39,297,318,46,47,292,303,275,61,54,35,45,256,265,17,297]

theorem envBound55187 : H12AffineFastState.Bounded env55187 := by
  intro p hp
  have h : env55187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55186_55187 : H12AffineEnvironment.transform 6 62 env55186 = env55187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 62 env55186 == env55187) = true)

theorem identity55187 : scanCanonicalize (H12AffineFastState.compose env55187 (packedSelected [1,2,3,4,5,7,8,10,11] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound55187 : packedSelected [1,2,3,4,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env55188 : List Nat := [2,4,8,16,10,23,20,256,286,262,11,13,5,22,271,5,277,17,282,270,13,259,276,4,5,270,261,275,23,28,9,7,256,265,17,259]

theorem envBound55188 : H12AffineFastState.Bounded env55188 := by
  intro p hp
  have h : env55188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55187_55188 : H12AffineEnvironment.transform 4 10 env55187 = env55188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env55187 == env55188) = true)

theorem identity55188 : scanCanonicalize (H12AffineFastState.compose env55188 (packedSelected [0,2,4,5,8] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound55188 : packedSelected [0,2,4,5,8] rootPS < 2^1333 := by decide +kernel

def env55189 : List Nat := [2,4,4,16,6,23,20,256,274,262,7,1,5,22,259,5,277,17,278,258,1,259,276,4,5,258,261,275,23,16,5,7,256,261,17,259]

theorem envBound55189 : H12AffineFastState.Bounded env55189 := by
  intro p hp
  have h : env55189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55188_55189 : H12AffineEnvironment.transform 2 4 env55188 = env55189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env55188 == env55189) = true)

theorem identity55189 : scanCanonicalize (H12AffineFastState.compose env55189 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound55189 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env55190 : List Nat := [2,4,4,7,6,0,3,256,261,262,7,1,5,1,259,5,258,6,257,258,1,259,259,4,5,258,261,260,0,7,5,7,256,261,6,259]

theorem envBound55190 : H12AffineFastState.Bounded env55190 := by
  intro p hp
  have h : env55190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55189_55190 : H12AffineEnvironment.transform 3 7 env55189 = env55190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env55189 == env55190) = true)

theorem identity55190 : scanCanonicalize (H12AffineFastState.compose env55190 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound55190 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env55191 : List Nat := [2,4,4,7,6,0,3,4,1,2,7,1,5,1,7,5,6,6,5,6,1,7,7,4,5,6,1,0,0,7,5,7,4,1,6,7]

theorem envBound55191 : H12AffineFastState.Bounded env55191 := by
  intro p hp
  have h : env55191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55190_55191 : H12AffineEnvironment.transform 7 4 env55190 = env55191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env55190 == env55191) = true)

theorem identity55191 : scanCanonicalize (H12AffineFastState.compose env55191 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound55191 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env55192 : List Nat := [2,3,3,0,1,0,3,3,1,2,0,1,2,1,0,2,1,1,2,1,1,0,0,3,2,1,1,0,0,0,2,0,3,1,1,0]

theorem envBound55192 : H12AffineFastState.Bounded env55192 := by
  intro p hp
  have h : env55192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55191_55192 : H12AffineEnvironment.transform 1 3 env55191 = env55192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env55191 == env55192) = true)

theorem identity55192 : scanCanonicalize (H12AffineFastState.compose env55192 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound55192 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55193 : List Nat := [1,0,0,0,1,0,0,0,1,1,0,1,1,1,0,1,1,1,1,1,1,0,0,0,1,1,1,0,0,0,1,0,0,1,1,0]

theorem envBound55193 : H12AffineFastState.Bounded env55193 := by
  intro p hp
  have h : env55193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55192_55193 : H12AffineEnvironment.transform 0 1 env55192 = env55193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env55192 == env55193) = true)

def env55194 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74862,65665,4416,8540,4096,5276,74046,66896,13768,78895,1151,74815,1297,81227,8204,1281,256,65830,1344,5953]

theorem envBound55194 : H12AffineFastState.Bounded env55194 := by
  intro p hp
  have h : env55194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55098_55194 : H12AffineEnvironment.transform 17 65665 env55098 = env55194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env55098 == env55194) = true)

theorem identity55194 : scanCanonicalize (H12AffineFastState.compose env55194 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound55194 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env55195 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,25,1296,324,65536,66679,65665,4416,325,4096,5276,65831,66896,5585,70710,1151,66598,1297,73042,21,1281,256,65830,1344,5953]

theorem envBound55195 : H12AffineFastState.Bounded env55195 := by
  intro p hp
  have h : env55195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55194_55195 : H12AffineEnvironment.transform 12 25 env55194 = env55195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env55194 == env55195) = true)

def env55196 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1556,25,1296,324,65536,66679,65665,1876,325,1556,648,65831,66896,965,66082,1151,66598,1297,68422,21,1281,256,65830,1344,341]

theorem envBound55196 : H12AffineFastState.Bounded env55196 := by
  intro p hp
  have h : env55196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55195_55196 : H12AffineEnvironment.transform 11 1556 env55195 = env55196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env55195 == env55196) = true)

def env55197 : List Nat := [2,4,8,16,32,0,128,256,512,1024,2048,1556,25,1296,260,65536,66615,65665,1812,261,1556,648,65831,66832,901,66082,1087,66598,1297,68358,21,1281,256,65830,1280,277]

theorem envBound55197 : H12AffineFastState.Bounded env55197 := by
  intro p hp
  have h : env55197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55196_55197 : H12AffineEnvironment.transform 5 0 env55196 = env55197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env55196 == env55197) = true)

theorem identity55197 : scanCanonicalize (H12AffineFastState.compose env55197 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 1796) := by decide +kernel

theorem selectedBound55197 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env55198 : List Nat := [2,4,8,16,32,0,128,256,512,1024,2048,1556,25,1296,260,1796,819,1925,1812,261,1556,648,1571,532,901,1318,1087,802,1297,3074,21,1281,256,1570,1280,277]

theorem envBound55198 : H12AffineFastState.Bounded env55198 := by
  intro p hp
  have h : env55198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55197_55198 : H12AffineEnvironment.transform 15 1796 env55197 = env55198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1796 env55197 == env55198) = true)

def env55199 : List Nat := [2,4,8,16,32,0,128,256,512,272,2048,772,25,0,260,532,819,661,516,261,772,648,819,532,901,54,303,802,1,2322,21,17,256,818,16,277]

theorem envBound55199 : H12AffineFastState.Bounded env55199 := by
  intro p hp
  have h : env55199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55198_55199 : H12AffineEnvironment.transform 9 272 env55198 = env55199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env55198 == env55199) = true)

theorem identity55199 : scanCanonicalize (H12AffineFastState.compose env55199 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound55199 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env55200 : List Nat := [2,4,8,16,32,0,128,5,512,21,2048,513,25,0,1,532,566,661,516,0,513,648,566,532,640,54,42,551,1,2071,21,17,5,567,16,16]

theorem envBound55200 : H12AffineFastState.Bounded env55200 := by
  intro p hp
  have h : env55200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55199_55200 : H12AffineEnvironment.transform 7 5 env55199 = env55200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env55199 == env55200) = true)

theorem identity55200 : scanCanonicalize (H12AffineFastState.compose env55200 (packedSelected [3,11,15,18] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound55200 : packedSelected [3,11,15,18] rootPS < 2^1333 := by decide +kernel

def env55201 : List Nat := [2,4,8,16,32,0,56,5,512,21,2048,513,25,0,1,532,566,557,516,0,513,560,566,532,568,54,42,551,1,2071,21,17,5,567,16,16]

theorem envBound55201 : H12AffineFastState.Bounded env55201 := by
  intro p hp
  have h : env55201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55200_55201 : H12AffineEnvironment.transform 6 56 env55200 = env55201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env55200 == env55201) = true)

theorem identity55201 : scanCanonicalize (H12AffineFastState.compose env55201 (packedSelected [1,2,5,12,17] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound55201 : packedSelected [1,2,5,12,17] rootPS < 2^1333 := by decide +kernel

def env55202 : List Nat := [2,4,8,16,32,0,56,5,7,21,2048,6,25,0,1,19,49,42,3,0,6,55,49,19,63,54,42,32,1,2071,21,17,5,48,16,16]

theorem envBound55202 : H12AffineFastState.Bounded env55202 := by
  intro p hp
  have h : env55202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55201_55202 : H12AffineEnvironment.transform 8 7 env55201 = env55202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env55201 == env55202) = true)

theorem identity55202 : scanCanonicalize (H12AffineFastState.compose env55202 (packedSelected [4,5,8,9,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 6) := by decide +kernel

theorem selectedBound55202 : packedSelected [4,5,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env55203 : List Nat := [2,4,8,16,32,0,56,5,7,21,6,6,25,0,1,19,49,42,3,0,6,55,49,19,63,54,42,32,1,17,21,17,5,48,16,16]

theorem envBound55203 : H12AffineFastState.Bounded env55203 := by
  intro p hp
  have h : env55203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55202_55203 : H12AffineEnvironment.transform 10 6 env55202 = env55203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 6 env55202 == env55203) = true)

theorem identity55203 : scanCanonicalize (H12AffineFastState.compose env55203 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound55203 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env55204 : List Nat := [2,4,8,16,23,0,15,5,7,21,6,6,25,0,1,19,6,29,3,0,6,0,6,19,8,1,29,23,1,17,21,17,5,7,16,16]

theorem envBound55204 : H12AffineFastState.Bounded env55204 := by
  intro p hp
  have h : env55204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55203_55204 : H12AffineEnvironment.transform 4 23 env55203 = env55204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env55203 == env55204) = true)

theorem identity55204 : scanCanonicalize (H12AffineFastState.compose env55204 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound55204 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55205 : List Nat := [2,2,8,16,17,0,9,3,1,19,0,0,25,0,1,19,0,27,3,0,0,0,0,19,8,1,27,17,1,17,19,17,3,1,16,16]

theorem envBound55205 : H12AffineFastState.Bounded env55205 := by
  intro p hp
  have h : env55205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55204_55205 : H12AffineEnvironment.transform 1 2 env55204 = env55205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env55204 == env55205) = true)

theorem identity55205 : scanCanonicalize (H12AffineFastState.compose env55205 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound55205 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55206 : List Nat := [2,2,2,16,17,0,3,3,1,19,0,0,19,0,1,19,0,17,3,0,0,0,0,19,2,1,17,17,1,17,19,17,3,1,16,16]

theorem envBound55206 : H12AffineFastState.Bounded env55206 := by
  intro p hp
  have h : env55206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55205_55206 : H12AffineEnvironment.transform 2 2 env55205 = env55206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env55205 == env55206) = true)

theorem identity55206 : scanCanonicalize (H12AffineFastState.compose env55206 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound55206 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55207 : List Nat := [2,2,2,0,1,0,3,3,1,3,0,0,3,0,1,3,0,1,3,0,0,0,0,3,2,1,1,1,1,1,3,1,3,1,0,0]

theorem envBound55207 : H12AffineFastState.Bounded env55207 := by
  intro p hp
  have h : env55207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55206_55207 : H12AffineEnvironment.transform 3 0 env55206 = env55207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env55206 == env55207) = true)

theorem identity55207 : scanCanonicalize (H12AffineFastState.compose env55207 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound55207 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55208 : List Nat := [0,0,0,0,1,0,1,1,1,1,0,0,1,0,1,1,0,1,1,0,0,0,0,1,0,1,1,1,1,1,1,1,1,1,0,0]

theorem envBound55208 : H12AffineFastState.Bounded env55208 := by
  intro p hp
  have h : env55208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55207_55208 : H12AffineEnvironment.transform 0 0 env55207 = env55208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env55207 == env55208) = true)

def env55209 : List Nat := [2,4,8,16,32,0,128,256,512,273,2048,773,25,1,260,533,819,660,517,261,773,648,818,532,901,55,302,802,0,2323,21,16,256,819,17,277]

theorem envBound55209 : H12AffineFastState.Bounded env55209 := by
  intro p hp
  have h : env55209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55198_55209 : H12AffineEnvironment.transform 9 273 env55198 = env55209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env55198 == env55209) = true)

theorem identity55209 : scanCanonicalize (H12AffineFastState.compose env55209 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound55209 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env55210 : List Nat := [2,4,8,16,32,0,128,256,16,273,2048,277,25,1,260,5,291,132,21,261,277,152,290,4,405,55,302,306,0,2323,21,16,256,291,17,277]

theorem envBound55210 : H12AffineFastState.Bounded env55210 := by
  intro p hp
  have h : env55210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55209_55210 : H12AffineEnvironment.transform 8 16 env55209 = env55210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env55209 == env55210) = true)

theorem identity55210 : scanCanonicalize (H12AffineFastState.compose env55210 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound55210 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env55211 : List Nat := [2,4,8,16,23,0,128,256,16,273,2048,277,25,1,260,5,276,132,21,261,277,152,277,4,405,0,281,261,0,2323,21,16,256,276,17,277]

theorem envBound55211 : H12AffineFastState.Bounded env55211 := by
  intro p hp
  have h : env55211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55210_55211 : H12AffineEnvironment.transform 4 23 env55210 = env55211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env55210 == env55211) = true)

theorem identity55211 : scanCanonicalize (H12AffineFastState.compose env55211 (packedSelected [1,2,12] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound55211 : packedSelected [1,2,12] rootPS < 2^1333 := by decide +kernel

def env55212 : List Nat := [2,4,8,16,23,0,128,256,16,273,260,277,25,1,260,5,276,132,21,261,277,152,277,4,405,0,281,261,0,23,21,16,256,276,17,277]

theorem envBound55212 : H12AffineFastState.Bounded env55212 := by
  intro p hp
  have h : env55212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55211_55212 : H12AffineEnvironment.transform 10 260 env55211 = env55212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env55211 == env55212) = true)

theorem identity55212 : scanCanonicalize (H12AffineFastState.compose env55212 (packedSelected [1,3,5,8,10] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound55212 : packedSelected [1,3,5,8,10] rootPS < 2^1333 := by decide +kernel

def env55213 : List Nat := [2,4,8,7,0,0,128,256,7,262,260,258,14,1,260,5,259,132,2,261,258,143,258,4,386,0,270,261,0,0,2,7,256,259,6,258]

theorem envBound55213 : H12AffineFastState.Bounded env55213 := by
  intro p hp
  have h : env55213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55212_55213 : H12AffineEnvironment.transform 3 7 env55212 = env55213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env55212 == env55213) = true)

theorem identity55213 : scanCanonicalize (H12AffineFastState.compose env55213 (packedSelected [1,2,8] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound55213 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

end H12CloudChart2