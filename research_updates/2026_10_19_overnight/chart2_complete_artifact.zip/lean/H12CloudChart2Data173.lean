import H12CloudChart2Data172

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound43320 : packedSelected [1,4,6,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env43321 : List Nat := [2,4,8,16,32,17,128,173,27,1024,1175,4096,5174,184,4258,56,5125,43,5,4259,4096,5292,5293,187,4283,4265,1190,4097,4097,43,5153,4112,173,169,1212,1055]

theorem envBound43321 : H12AffineFastState.Bounded env43321 := by
  intro p hp
  have h : env43321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43320_43321 : H12AffineEnvironment.transform 8 27 env43320 = env43321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env43320 == env43321) = true)

theorem identity43321 : scanCanonicalize (H12AffineFastState.compose env43321 (packedSelected [2,3,4,7,8] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound43321 : packedSelected [2,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env43322 : List Nat := [2,4,8,11,32,10,128,173,0,1024,1164,4096,5165,163,4258,35,5125,43,5,4259,4096,5292,5293,160,4256,4265,1190,4097,4097,43,5153,4107,173,169,1191,1028]

theorem envBound43322 : H12AffineFastState.Bounded env43322 := by
  intro p hp
  have h : env43322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43321_43322 : H12AffineEnvironment.transform 3 11 env43321 = env43322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env43321 == env43322) = true)

theorem identity43322 : scanCanonicalize (H12AffineFastState.compose env43322 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 166) := by decide +kernel

theorem selectedBound43322 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43323 : List Nat := [2,4,8,11,32,10,128,173,0,166,42,4096,4235,163,4258,35,4259,43,5,4259,4096,4106,4107,160,4256,4265,0,4097,4097,43,4231,4107,173,169,1,162]

theorem envBound43323 : H12AffineFastState.Bounded env43323 := by
  intro p hp
  have h : env43323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43322_43323 : H12AffineEnvironment.transform 9 166 env43322 = env43323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 166 env43322 == env43323) = true)

theorem identity43323 : scanCanonicalize (H12AffineFastState.compose env43323 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound43323 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env43324 : List Nat := [2,4,8,11,32,10,9,36,0,47,42,4096,4098,42,4139,35,4138,43,5,4138,4096,4106,4107,41,4137,4128,0,4097,4097,43,4110,4107,36,32,1,43]

theorem envBound43324 : H12AffineFastState.Bounded env43324 := by
  intro p hp
  have h : env43324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43323_43324 : H12AffineEnvironment.transform 6 9 env43323 = env43324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43323 == env43324) = true)

theorem identity43324 : scanCanonicalize (H12AffineFastState.compose env43324 (packedSelected [0,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 6) := by decide +kernel

theorem selectedBound43324 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env43325 : List Nat := [2,4,8,11,32,10,9,36,0,47,42,6,4,42,45,35,44,43,5,44,6,12,13,41,47,38,0,7,7,43,8,13,36,32,1,43]

theorem envBound43325 : H12AffineFastState.Bounded env43325 := by
  intro p hp
  have h : env43325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43324_43325 : H12AffineEnvironment.transform 11 6 env43324 = env43325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 6 env43324 == env43325) = true)

theorem identity43325 : scanCanonicalize (H12AffineFastState.compose env43325 (packedSelected [1,5] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound43325 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env43326 : List Nat := [2,3,8,11,32,10,9,35,0,40,42,1,3,42,42,35,43,43,2,43,1,11,10,41,40,33,0,0,0,43,8,10,35,32,1,43]

theorem envBound43326 : H12AffineFastState.Bounded env43326 := by
  intro p hp
  have h : env43326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43325_43326 : H12AffineEnvironment.transform 1 3 env43325 = env43326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env43325 == env43326) = true)

def env43327 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147521,58683,143497,20496,508154,148800,148801,96347,90427,148816,256,16400,1344,135680]

theorem envBound43327 : H12AffineFastState.Bounded env43327 := by
  intro p hp
  have h : env43327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43269_43327 : H12AffineEnvironment.transform 18 136193 env43269 = env43327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env43269 == env43327) = true)

def env43328 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147521,58519,143497,20496,508154,148716,148717,96347,90263,148732,172,16400,1260,135680]

theorem envBound43328 : H12AffineFastState.Bounded env43328 := by
  intro p hp
  have h : env43328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43327_43328 : H12AffineEnvironment.transform 7 172 env43327 = env43328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env43327 == env43328) = true)

def env43329 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147473,58519,143497,20496,508074,148668,148669,96267,90263,148652,172,16400,1212,135680]

theorem envBound43329 : H12AffineFastState.Bounded env43329 := by
  intro p hp
  have h : env43329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43328_43329 : H12AffineEnvironment.transform 5 16 env43328 = env43329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43328 == env43329) = true)

theorem identity43329 : scanCanonicalize (H12AffineFastState.compose env43329 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 137353) := by decide +kernel

theorem selectedBound43329 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env43330 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,137353,136193,32769,4096,61569,147473,58519,143497,20496,120867,148668,148669,96267,90263,148652,172,16400,1212,135680]

theorem envBound43330 : H12AffineFastState.Bounded env43330 := by
  intro p hp
  have h : env43330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43329_43330 : H12AffineEnvironment.transform 17 137353 env43329 = env43330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137353 env43329 == env43330) = true)

theorem identity43330 : scanCanonicalize (H12AffineFastState.compose env43330 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(16+1) ^^^ 62492) := by decide +kernel

theorem selectedBound43330 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env43331 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,62492,60565,57373,32769,4096,61569,46093,58519,50325,20496,120867,45216,45217,96267,90263,45232,172,16400,1212,58908]

theorem envBound43331 : H12AffineFastState.Bounded env43331 := by
  intro p hp
  have h : env43331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43330_43331 : H12AffineEnvironment.transform 16 62492 env43330 = env43331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 62492 env43330 == env43331) = true)

theorem identity43331 : scanCanonicalize (H12AffineFastState.compose env43331 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 12346) := by decide +kernel

theorem selectedBound43331 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env43332 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,12346,62492,60565,57373,32769,4096,61569,46093,58519,50325,20496,59417,45216,45217,18481,20653,45232,172,16400,1212,58908]

theorem envBound43332 : H12AffineFastState.Bounded env43332 := by
  intro p hp
  have h : env43332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43331_43332 : H12AffineEnvironment.transform 15 12346 env43331 = env43332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12346 env43331 == env43332) = true)

theorem identity43332 : scanCanonicalize (H12AffineFastState.compose env43332 (packedSelected [0,2,3,4,5,6,7,9,10,13,18,23] rootPS)) = affineNative (2^(14+1) ^^^ 24205) := by decide +kernel

theorem selectedBound43332 : packedSelected [0,2,3,4,5,6,7,9,10,13,18,23] rootPS < 2^1333 := by decide +kernel

def env43333 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,24205,12346,10897,12824,16016,24204,4096,11788,27264,14874,6680,20496,13972,28205,28204,18481,20653,28221,172,16400,1212,14481]

theorem envBound43333 : H12AffineFastState.Bounded env43333 := by
  intro p hp
  have h : env43333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43332_43333 : H12AffineEnvironment.transform 14 24205 env43332 = env43333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 24205 env43332 == env43333) = true)

theorem identity43333 : scanCanonicalize (H12AffineFastState.compose env43333 (packedSelected [0,2,3,4,5,6,7,9,10,13,17,19,21,26] rootPS)) = affineNative (2^(12+1) ^^^ 7829) := by decide +kernel

theorem selectedBound43333 : packedSelected [0,2,3,4,5,6,7,9,10,13,17,19,21,26] rootPS < 2^1333 := by decide +kernel

def env43334 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,7829,16384,24205,3759,5124,3213,5,24204,4096,4249,21525,1167,6680,20496,2049,20664,20665,18481,20653,20648,172,16400,1212,1540]

theorem envBound43334 : H12AffineFastState.Bounded env43334 := by
  intro p hp
  have h : env43334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43333_43334 : H12AffineEnvironment.transform 12 7829 env43333 = env43334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7829 env43333 == env43334) = true)

theorem identity43334 : scanCanonicalize (H12AffineFastState.compose env43334 (packedSelected [3,5,6,10,11,12,15,17] rootPS)) = affineNative (2^(11+1) ^^^ 1077) := by decide +kernel

theorem selectedBound43334 : packedSelected [3,5,6,10,11,12,15,17] rootPS < 2^1333 := by decide +kernel

def env43335 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,1077,2720,16384,19128,3759,49,3213,5,19129,1077,1196,16416,1167,3629,17445,2049,17549,17548,18481,17560,17565,172,16400,1212,1540]

theorem envBound43335 : H12AffineFastState.Bounded env43335 := by
  intro p hp
  have h : env43335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43334_43335 : H12AffineEnvironment.transform 11 1077 env43334 = env43335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1077 env43334 == env43335) = true)

theorem identity43335 : scanCanonicalize (H12AffineFastState.compose env43335 (packedSelected [0,1,3,9,10,13] rootPS)) = affineNative (2^(9+1) ^^^ 30) := by decide +kernel

theorem selectedBound43335 : packedSelected [0,1,3,9,10,13] rootPS < 2^1333 := by decide +kernel

def env43336 : List Nat := [2,4,8,16,32,16,128,172,512,30,2048,43,2720,16384,19128,2737,49,2195,5,19129,43,178,16416,145,2611,16443,2049,16531,16530,18481,16518,16515,172,16400,162,538]

theorem envBound43336 : H12AffineFastState.Bounded env43336 := by
  intro p hp
  have h : env43336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43335_43336 : H12AffineEnvironment.transform 9 30 env43335 = env43336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 30 env43335 == env43336) = true)

theorem identity43336 : scanCanonicalize (H12AffineFastState.compose env43336 (packedSelected [1,2,4,6,7,8,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound43336 : packedSelected [1,2,4,6,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env43337 : List Nat := [2,4,8,16,32,16,19,63,512,30,2048,43,2611,16384,18987,2594,49,2048,5,18986,43,33,16416,2,2611,16443,2049,16384,16385,18481,16405,16400,63,16400,49,538]

theorem envBound43337 : H12AffineFastState.Bounded env43337 := by
  intro p hp
  have h : env43337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43336_43337 : H12AffineEnvironment.transform 6 19 env43336 = env43337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env43336 == env43337) = true)

theorem identity43337 : scanCanonicalize (H12AffineFastState.compose env43337 (packedSelected [1,2,4,5,6,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound43337 : packedSelected [1,2,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env43338 : List Nat := [2,4,8,10,32,10,9,37,512,4,2048,43,2601,16384,18987,2594,43,2048,5,18986,43,33,16416,2,2601,16417,2049,16384,16385,18475,16399,16394,37,16394,43,512]

theorem envBound43338 : H12AffineFastState.Bounded env43338 := by
  intro p hp
  have h : env43338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43337_43338 : H12AffineEnvironment.transform 3 10 env43337 = env43338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env43337 == env43338) = true)

theorem identity43338 : scanCanonicalize (H12AffineFastState.compose env43338 (packedSelected [2,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound43338 : packedSelected [2,3,4] rootPS < 2^1333 := by decide +kernel

def env43339 : List Nat := [2,4,8,10,32,10,9,37,512,4,42,43,515,16384,16897,520,43,42,5,16896,43,33,16416,2,515,16417,43,16384,16385,16385,16399,16394,37,16394,43,512]

theorem envBound43339 : H12AffineFastState.Bounded env43339 := by
  intro p hp
  have h : env43339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43338_43339 : H12AffineEnvironment.transform 10 42 env43338 = env43339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env43338 == env43339) = true)

theorem identity43339 : scanCanonicalize (H12AffineFastState.compose env43339 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound43339 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43340 : List Nat := [2,4,8,10,32,10,9,37,1,4,42,43,2,16384,16384,9,43,42,5,16385,43,33,16416,2,2,16417,43,16384,16385,16385,16399,16394,37,16394,43,1]

theorem envBound43340 : H12AffineFastState.Bounded env43340 := by
  intro p hp
  have h : env43340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43339_43340 : H12AffineEnvironment.transform 8 1 env43339 = env43340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env43339 == env43340) = true)

theorem identity43340 : scanCanonicalize (H12AffineFastState.compose env43340 (packedSelected [0,1] rootPS)) = affineNative (2^(13+1) ^^^ 42) := by decide +kernel

theorem selectedBound43340 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env43341 : List Nat := [2,4,8,10,32,10,9,37,1,4,42,43,2,42,42,9,43,42,5,43,43,33,10,2,2,11,43,42,43,43,37,32,37,32,43,1]

theorem envBound43341 : H12AffineFastState.Bounded env43341 := by
  intro p hp
  have h : env43341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43340_43341 : H12AffineEnvironment.transform 13 42 env43340 = env43341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 42 env43340 == env43341) = true)

theorem identity43341 : scanCanonicalize (H12AffineFastState.compose env43341 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound43341 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43342 : List Nat := [2,4,8,10,6,10,9,3,1,4,12,13,2,12,12,9,13,12,5,13,13,7,10,2,2,11,13,12,13,13,3,6,3,6,13,1]

theorem envBound43342 : H12AffineFastState.Bounded env43342 := by
  intro p hp
  have h : env43342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43341_43342 : H12AffineEnvironment.transform 4 6 env43341 = env43342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env43341 == env43342) = true)

theorem identity43342 : scanCanonicalize (H12AffineFastState.compose env43342 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound43342 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43343 : List Nat := [2,4,5,7,6,7,4,3,1,4,1,0,2,1,1,4,0,1,5,0,0,7,7,2,2,6,0,1,0,0,3,6,3,6,0,1]

theorem envBound43343 : H12AffineFastState.Bounded env43343 := by
  intro p hp
  have h : env43343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43342_43343 : H12AffineEnvironment.transform 2 5 env43342 = env43343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env43342 == env43343) = true)

def env43344 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147472,58519,143497,20496,508075,148669,148668,96266,90263,148653,172,16400,1213,135680]

theorem envBound43344 : H12AffineFastState.Bounded env43344 := by
  intro p hp
  have h : env43344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43328_43344 : H12AffineEnvironment.transform 5 17 env43328 = env43344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43328 == env43344) = true)

theorem identity43344 : scanCanonicalize (H12AffineFastState.compose env43344 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound43344 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env43345 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,45217,262144,42144,32769,4096,61568,61617,58519,32808,20496,356362,62492,62493,96266,90263,62476,172,16400,1213,41633]

theorem envBound43345 : H12AffineFastState.Bounded env43345 := by
  intro p hp
  have h : env43345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43344_43345 : H12AffineEnvironment.transform 16 45217 env43344 = env43345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env43344 == env43345) = true)

theorem identity43345 : scanCanonicalize (H12AffineFastState.compose env43345 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound43345 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env43346 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,45217,2184,42144,32769,4096,61568,61617,58519,32808,20496,96386,62492,62493,96266,90263,62476,172,16400,1213,41633]

theorem envBound43346 : H12AffineFastState.Bounded env43346 := by
  intro p hp
  have h : env43346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43345_43346 : H12AffineEnvironment.transform 17 2184 env43345 = env43346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env43345 == env43346) = true)

theorem identity43346 : scanCanonicalize (H12AffineFastState.compose env43346 (packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS)) = affineNative (2^(14+1) ^^^ 24601) := by decide +kernel

theorem selectedBound43346 : packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env43347 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,24601,65536,20664,2184,17593,24600,4096,4249,4264,1166,24625,20496,96386,5125,5124,96266,90263,5141,172,16400,1213,17080]

theorem envBound43347 : H12AffineFastState.Bounded env43347 := by
  intro p hp
  have h : env43347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43346_43347 : H12AffineEnvironment.transform 14 24601 env43346 = env43347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 24601 env43346 == env43347) = true)

theorem identity43347 : scanCanonicalize (H12AffineFastState.compose env43347 (packedSelected [1,4,5,8,9,16,17,21,24] rootPS)) = affineNative (2^(15+1) ^^^ 13374) := by decide +kernel

theorem selectedBound43347 : packedSelected [1,4,5,8,9,16,17,21,24] rootPS < 2^1333 := by decide +kernel

def env43348 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,24601,13374,20664,2184,17593,24600,4096,4249,4264,1166,24625,20496,19644,5125,5124,19508,21673,5141,172,16400,1213,17080]

theorem envBound43348 : H12AffineFastState.Bounded env43348 := by
  intro p hp
  have h : env43348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43347_43348 : H12AffineEnvironment.transform 15 13374 env43347 = env43348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13374 env43347 == env43348) = true)

theorem identity43348 : scanCanonicalize (H12AffineFastState.compose env43348 (packedSelected [2,3,5,6,10,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 2584) := by decide +kernel

theorem selectedBound43348 : packedSelected [2,3,5,6,10,15,17] rootPS < 2^1333 := by decide +kernel

def env43349 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,2584,16384,18945,7718,20664,2184,17593,18944,4096,4249,4264,1166,18985,20496,19644,5125,5124,19508,21673,5141,172,16400,1213,17080]

theorem envBound43349 : H12AffineFastState.Bounded env43349 := by
  intro p hp
  have h : env43349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43348_43349 : H12AffineEnvironment.transform 12 2584 env43348 = env43349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2584 env43348 == env43349) = true)

theorem identity43349 : scanCanonicalize (H12AffineFastState.compose env43349 (packedSelected [2,4,7,10,12,13,16] rootPS)) = affineNative (2^(13+1) ^^^ 6656) := by decide +kernel

theorem selectedBound43349 : packedSelected [2,4,7,10,12,13,16] rootPS < 2^1333 := by decide +kernel

def env43350 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,2584,6656,4097,7718,2744,2184,7865,4096,4096,4249,4264,1166,4137,2576,5820,5125,5124,5684,3753,5141,172,6672,1213,6328]

theorem envBound43350 : H12AffineFastState.Bounded env43350 := by
  intro p hp
  have h : env43350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43349_43350 : H12AffineEnvironment.transform 13 6656 env43349 = env43350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6656 env43349 == env43350) = true)

theorem identity43350 : scanCanonicalize (H12AffineFastState.compose env43350 (packedSelected [0,2,3,4,7,8,9,10,11,12] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound43350 : packedSelected [0,2,3,4,7,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env43351 : List Nat := [2,4,8,16,32,17,128,172,43,1024,2048,4096,2099,6187,4097,7181,2195,2184,7314,4096,4096,4249,4264,1166,4137,2107,5271,5125,5124,5151,3202,5141,172,6203,1213,6328]

theorem envBound43351 : H12AffineFastState.Bounded env43351 := by
  intro p hp
  have h : env43351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43350_43351 : H12AffineEnvironment.transform 8 43 env43350 = env43351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env43350 == env43351) = true)

theorem identity43351 : scanCanonicalize (H12AffineFastState.compose env43351 (packedSelected [6,7,9,13] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound43351 : packedSelected [6,7,9,13] rootPS < 2^1333 := by decide +kernel

def env43352 : List Nat := [2,4,8,16,32,17,8,36,43,1024,2048,4096,2099,6187,4097,7181,2075,2048,7194,4096,4096,4113,4128,1030,4137,2107,5151,5125,5124,5151,3082,5141,36,6203,1077,6192]

theorem envBound43352 : H12AffineFastState.Bounded env43352 := by
  intro p hp
  have h : env43352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43351_43352 : H12AffineEnvironment.transform 6 8 env43351 = env43352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43351 == env43352) = true)

theorem identity43352 : scanCanonicalize (H12AffineFastState.compose env43352 (packedSelected [2,4,5,8,9] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound43352 : packedSelected [2,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env43353 : List Nat := [2,4,8,10,32,11,8,36,43,1024,2048,4096,2089,6187,4097,7181,2049,2048,7168,4096,4096,4107,4128,1030,4137,2081,5125,5125,5124,5125,3082,5135,36,6177,1071,6186]

theorem envBound43353 : H12AffineFastState.Bounded env43353 := by
  intro p hp
  have h : env43353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43352_43353 : H12AffineEnvironment.transform 3 10 env43352 = env43353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env43352 == env43353) = true)

theorem identity43353 : scanCanonicalize (H12AffineFastState.compose env43353 (packedSelected [1,4,5,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound43353 : packedSelected [1,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env43354 : List Nat := [2,4,8,10,32,11,8,36,43,1024,43,4096,2,4096,4097,5158,42,43,5163,4096,4096,4107,4128,1030,4137,10,5125,5125,5124,5125,1057,5135,36,4106,1071,4097]

theorem envBound43354 : H12AffineFastState.Bounded env43354 := by
  intro p hp
  have h : env43354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43353_43354 : H12AffineEnvironment.transform 10 43 env43353 = env43354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env43353 == env43354) = true)

theorem identity43354 : scanCanonicalize (H12AffineFastState.compose env43354 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound43354 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env43355 : List Nat := [2,4,8,10,32,11,8,36,43,4,43,4096,2,4096,4097,4130,42,43,4143,4096,4096,4107,4128,2,4137,10,4097,4097,4096,4097,37,4107,36,4106,43,4097]

theorem envBound43355 : H12AffineFastState.Bounded env43355 := by
  intro p hp
  have h : env43355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43354_43355 : H12AffineEnvironment.transform 9 4 env43354 = env43355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env43354 == env43355) = true)

theorem identity43355 : scanCanonicalize (H12AffineFastState.compose env43355 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound43355 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43356 : List Nat := [2,4,5,7,32,6,5,36,38,4,38,4096,2,4096,4097,4130,39,38,4130,4096,4096,4102,4128,2,4132,7,4097,4097,4096,4097,37,4102,36,4103,38,4097]

theorem envBound43356 : H12AffineFastState.Bounded env43356 := by
  intro p hp
  have h : env43356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43355_43356 : H12AffineEnvironment.transform 2 5 env43355 = env43356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env43355 == env43356) = true)

def env43357 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147521,58518,143497,20496,508154,148717,148716,96347,90262,148733,173,16400,1261,135680]

theorem envBound43357 : H12AffineFastState.Bounded env43357 := by
  intro p hp
  have h : env43357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43327_43357 : H12AffineEnvironment.transform 7 173 env43327 = env43357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env43327 == env43357) = true)

def env43358 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147473,58518,143497,20496,508074,148669,148668,96267,90262,148653,173,16400,1213,135680]

theorem envBound43358 : H12AffineFastState.Bounded env43358 := by
  intro p hp
  have h : env43358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43357_43358 : H12AffineEnvironment.transform 5 16 env43357 = env43358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43357 == env43358) = true)

theorem identity43358 : scanCanonicalize (H12AffineFastState.compose env43358 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 208054) := by decide +kernel

theorem selectedBound43358 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env43359 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,208054,136193,32769,4096,61569,147473,58518,143497,20496,60444,148669,148668,96267,90262,148653,173,16400,1213,135680]

theorem envBound43359 : H12AffineFastState.Bounded env43359 := by
  intro p hp
  have h : env43359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43358_43359 : H12AffineEnvironment.transform 17 208054 env43358 = env43359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 208054 env43358 == env43359) = true)

theorem identity43359 : scanCanonicalize (H12AffineFastState.compose env43359 (packedSelected [1,3,5,7,8,10,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound43359 : packedSelected [1,3,5,7,8,10,20,26,27] rootPS < 2^1333 := by decide +kernel

def env43360 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,53283,131072,195733,136193,32769,4096,61569,147473,58518,143497,20496,60444,148669,148668,43048,45237,148653,173,16400,1213,135680]

theorem envBound43360 : H12AffineFastState.Bounded env43360 := by
  intro p hp
  have h : env43360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43359_43360 : H12AffineEnvironment.transform 15 53283 env43359 = env43360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env43359 == env43360) = true)

theorem identity43360 : scanCanonicalize (H12AffineFastState.compose env43360 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 21693) := by decide +kernel

theorem selectedBound43360 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env43361 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,53283,21693,43048,16572,32769,4096,61569,5292,58518,25652,20496,60444,4096,4097,43048,45237,4112,173,16400,1213,18109]

theorem envBound43361 : H12AffineFastState.Bounded env43361 := by
  intro p hp
  have h : env43361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43360_43361 : H12AffineEnvironment.transform 16 21693 env43360 = env43361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21693 env43360 == env43361) = true)

theorem identity43361 : scanCanonicalize (H12AffineFastState.compose env43361 (packedSelected [4,9,20] rootPS)) = affineNative (2^(13+1) ^^^ 184) := by decide +kernel

theorem selectedBound43361 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env43362 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,184,32768,37019,5125,43048,4,32769,4096,45113,5292,42030,9356,4264,44196,4096,4097,43048,45237,4112,173,168,1213,1541]

theorem envBound43362 : H12AffineFastState.Bounded env43362 := by
  intro p hp
  have h : env43362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43361_43362 : H12AffineEnvironment.transform 13 184 env43361 = env43362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 184 env43361 == env43362) = true)

theorem identity43362 : scanCanonicalize (H12AffineFastState.compose env43362 (packedSelected [0,2,3,4,5,6,11,16] rootPS)) = affineNative (2^(12+1) ^^^ 5661) := by decide +kernel

theorem selectedBound43362 : packedSelected [0,2,3,4,5,6,11,16] rootPS < 2^1333 := by decide +kernel

def env43363 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,5661,184,32768,37019,5125,40501,4,32769,4096,34340,5292,37427,4753,4264,39609,4096,4097,40501,34472,4112,173,168,1213,1541]

theorem envBound43363 : H12AffineFastState.Bounded env43363 := by
  intro p hp
  have h : env43363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43362_43363 : H12AffineEnvironment.transform 12 5661 env43362 = env43363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5661 env43362 == env43363) = true)

theorem identity43363 : scanCanonicalize (H12AffineFastState.compose env43363 (packedSelected [1,3,6,7,9,11,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 6699) := by decide +kernel

theorem selectedBound43363 : packedSelected [1,3,6,7,9,11,15,17] rootPS < 2^1333 := by decide +kernel

def env43364 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,5661,184,6699,2736,5125,1054,4,6698,4096,7183,5292,2072,4753,4264,146,4096,4097,1054,7299,4112,173,168,1213,1541]

theorem envBound43364 : H12AffineFastState.Bounded env43364 := by
  intro p hp
  have h : env43364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43363_43364 : H12AffineEnvironment.transform 14 6699 env43363 = env43364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 6699 env43363 == env43364) = true)

theorem identity43364 : scanCanonicalize (H12AffineFastState.compose env43364 (packedSelected [6,7,9,11,15] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound43364 : packedSelected [6,7,9,11,15] rootPS < 2^1333 := by decide +kernel

def env43365 : List Nat := [2,4,8,16,17,16,128,156,512,1024,2048,4096,5661,137,6682,2689,5125,1054,4,6683,4096,7183,5277,2072,4753,4249,146,4096,4097,1054,7299,4112,156,153,1164,1541]

theorem envBound43365 : H12AffineFastState.Bounded env43365 := by
  intro p hp
  have h : env43365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43364_43365 : H12AffineEnvironment.transform 4 17 env43364 = env43365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env43364 == env43365) = true)

theorem identity43365 : scanCanonicalize (H12AffineFastState.compose env43365 (packedSelected [1,4,6,7,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 1677) := by decide +kernel

theorem selectedBound43365 : packedSelected [1,4,6,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env43366 : List Nat := [2,4,8,16,17,16,128,156,512,1024,1677,4096,5661,137,5271,1036,5125,1054,4,5270,4096,4738,5277,1685,4753,4249,146,4096,4097,1054,4622,4112,156,153,1164,1541]

theorem envBound43366 : H12AffineFastState.Bounded env43366 := by
  intro p hp
  have h : env43366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43365_43366 : H12AffineEnvironment.transform 10 1677 env43365 = env43366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1677 env43365 == env43366) = true)

theorem identity43366 : scanCanonicalize (H12AffineFastState.compose env43366 (packedSelected [2,3,4,7,8] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound43366 : packedSelected [2,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env43367 : List Nat := [2,4,8,10,11,10,128,134,512,1024,1677,4096,5639,137,5261,1036,5125,1028,4,5260,4096,4738,5255,1679,4747,4227,136,4096,4097,1028,4622,4106,134,131,1164,1541]

theorem envBound43367 : H12AffineFastState.Bounded env43367 := by
  intro p hp
  have h : env43367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43366_43367 : H12AffineEnvironment.transform 3 10 env43366 = env43367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env43366 == env43367) = true)

theorem identity43367 : scanCanonicalize (H12AffineFastState.compose env43367 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound43367 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env43368 : List Nat := [2,4,8,10,11,10,128,134,512,517,136,4096,4098,137,4744,521,4608,513,4,4745,4096,4738,4738,138,4747,4227,136,4096,4097,513,4622,4106,134,131,649,0]

theorem envBound43368 : H12AffineFastState.Bounded env43368 := by
  intro p hp
  have h : env43368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43367_43368 : H12AffineEnvironment.transform 9 517 env43367 = env43368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env43367 == env43368) = true)

theorem identity43368 : scanCanonicalize (H12AffineFastState.compose env43368 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound43368 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43369 : List Nat := [2,4,4,6,7,6,128,134,512,517,132,4096,4098,133,4740,517,4608,513,4,4741,4096,4738,4738,134,4743,4227,132,4096,4097,513,4610,4102,134,131,645,0]

theorem envBound43369 : H12AffineFastState.Bounded env43369 := by
  intro p hp
  have h : env43369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43368_43369 : H12AffineEnvironment.transform 2 4 env43368 = env43369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env43368 == env43369) = true)

theorem identity43369 : scanCanonicalize (H12AffineFastState.compose env43369 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound43369 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43370 : List Nat := [2,4,4,6,7,6,5,3,512,517,1,4096,4098,0,4609,517,4608,513,4,4608,4096,4615,4615,3,4610,4102,1,4096,4097,513,4610,4102,3,6,512,0]

theorem envBound43370 : H12AffineFastState.Bounded env43370 := by
  intro p hp
  have h : env43370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43369_43370 : H12AffineEnvironment.transform 6 5 env43369 = env43370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env43369 == env43370) = true)

theorem identity43370 : scanCanonicalize (H12AffineFastState.compose env43370 (packedSelected [3] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound43370 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env43371 : List Nat := [2,4,4,6,7,6,5,3,512,517,1,512,514,0,1,517,0,513,4,0,512,7,7,3,2,518,1,512,513,513,2,518,3,6,512,0]

theorem envBound43371 : H12AffineFastState.Bounded env43371 := by
  intro p hp
  have h : env43371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43370_43371 : H12AffineEnvironment.transform 11 512 env43370 = env43371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env43370 == env43371) = true)

theorem identity43371 : scanCanonicalize (H12AffineFastState.compose env43371 (packedSelected [6] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound43371 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env43372 : List Nat := [2,4,4,6,7,6,5,3,1,4,1,1,3,0,1,4,0,0,4,0,1,7,7,3,2,7,1,1,0,0,2,7,3,6,1,0]

theorem envBound43372 : H12AffineFastState.Bounded env43372 := by
  intro p hp
  have h : env43372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43371_43372 : H12AffineEnvironment.transform 8 1 env43371 = env43372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env43371 == env43372) = true)

theorem identity43372 : scanCanonicalize (H12AffineFastState.compose env43372 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound43372 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43373 : List Nat := [2,0,0,2,3,2,1,3,1,0,1,1,3,0,1,0,0,0,0,0,1,3,3,3,2,3,1,1,0,0,2,3,3,2,1,0]

theorem envBound43373 : H12AffineFastState.Bounded env43373 := by
  intro p hp
  have h : env43373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43372_43373 : H12AffineEnvironment.transform 1 0 env43372 = env43373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env43372 == env43373) = true)

theorem identity43373 : scanCanonicalize (H12AffineFastState.compose env43373 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound43373 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env43374 : List Nat := [1,0,0,1,0,1,1,0,1,0,1,1,0,0,1,0,0,0,0,0,1,0,0,0,1,0,1,1,0,0,1,0,0,1,1,0]

theorem envBound43374 : H12AffineFastState.Bounded env43374 := by
  intro p hp
  have h : env43374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43373_43374 : H12AffineEnvironment.transform 0 1 env43373 = env43374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env43373 == env43374) = true)

def env43375 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147472,58518,143497,20496,508075,148668,148669,96266,90262,148652,173,16400,1212,135680]

theorem envBound43375 : H12AffineFastState.Bounded env43375 := by
  intro p hp
  have h : env43375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43357_43375 : H12AffineEnvironment.transform 5 17 env43357 = env43375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43357 == env43375) = true)

theorem identity43375 : scanCanonicalize (H12AffineFastState.compose env43375 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 99487) := by decide +kernel

theorem selectedBound43375 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env43376 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,99487,262144,102558,32769,4096,61568,115855,58518,111638,20496,279604,114723,114722,96266,90262,114739,173,16400,1212,104095]

theorem envBound43376 : H12AffineFastState.Bounded env43376 := by
  intro p hp
  have h : env43376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43375_43376 : H12AffineEnvironment.transform 16 99487 env43375 = env43376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 99487 env43375 == env43376) = true)

theorem identity43376 : scanCanonicalize (H12AffineFastState.compose env43376 (packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound43376 : packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env43377 : List Nat := [2,4,8,16,32,17,128,173,512,5,2048,4096,8192,16384,32768,65536,98458,262144,102558,32769,4096,61568,114826,57491,110611,20496,278577,114723,114722,96266,90262,114739,173,16400,185,103066]

theorem envBound43377 : H12AffineFastState.Bounded env43377 := by
  intro p hp
  have h : env43377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43376_43377 : H12AffineEnvironment.transform 9 5 env43376 = env43377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env43376 == env43377) = true)

theorem identity43377 : scanCanonicalize (H12AffineFastState.compose env43377 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 37018) := by decide +kernel

theorem selectedBound43377 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env43378 : List Nat := [2,4,8,16,32,17,128,173,512,5,2048,4096,8192,16384,32768,37018,4096,262144,4,32769,4096,61568,20496,57491,8329,20496,278577,20665,20664,59536,61452,20649,173,16400,185,512]

theorem envBound43378 : H12AffineFastState.Bounded env43378 := by
  intro p hp
  have h : env43378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43377_43378 : H12AffineEnvironment.transform 15 37018 env43377 = env43378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 37018 env43377 == env43378) = true)

theorem identity43378 : scanCanonicalize (H12AffineFastState.compose env43378 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 184) := by decide +kernel

theorem selectedBound43378 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env43379 : List Nat := [2,4,8,16,32,17,128,173,512,5,2048,4096,8192,184,32768,37018,4096,262144,4,32769,4096,45112,4264,41003,8329,4264,262281,4097,4096,43048,45236,4113,173,168,185,512]

theorem envBound43379 : H12AffineFastState.Bounded env43379 := by
  intro p hp
  have h : env43379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43378_43379 : H12AffineEnvironment.transform 13 184 env43378 = env43379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 184 env43378 == env43379) = true)

theorem identity43379 : scanCanonicalize (H12AffineFastState.compose env43379 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 4648) := by decide +kernel

theorem selectedBound43379 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env43380 : List Nat := [2,4,8,16,32,17,128,173,512,5,2048,4096,4648,184,32768,37018,4096,262144,4,32769,4096,33296,4264,37379,4769,4264,262281,4097,4096,39424,33436,4113,173,168,185,512]

theorem envBound43380 : H12AffineFastState.Bounded env43380 := by
  intro p hp
  have h : env43380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43379_43380 : H12AffineEnvironment.transform 12 4648 env43379 = env43380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4648 env43379 == env43380) = true)

theorem identity43380 : scanCanonicalize (H12AffineFastState.compose env43380 (packedSelected [1,3,13] rootPS)) = affineNative (2^(17+1) ^^^ 6192) := by decide +kernel

theorem selectedBound43380 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env43381 : List Nat := [2,4,8,16,32,17,128,173,512,5,2048,4096,4648,184,32768,37018,4096,6192,4,32769,4096,33296,4264,37379,4769,4264,6329,4097,4096,39424,33436,4113,173,168,185,512]

theorem envBound43381 : H12AffineFastState.Bounded env43381 := by
  intro p hp
  have h : env43381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43380_43381 : H12AffineEnvironment.transform 17 6192 env43380 = env43381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6192 env43380 == env43381) = true)

theorem identity43381 : scanCanonicalize (H12AffineFastState.compose env43381 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 2587) := by decide +kernel

theorem selectedBound43381 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env43382 : List Nat := [2,4,8,16,32,17,128,173,512,5,2048,2587,2099,184,32768,35457,2587,555,4,32769,2587,33296,2739,34840,2234,2739,674,2586,2587,32795,33436,2570,173,168,185,512]

theorem envBound43382 : H12AffineFastState.Bounded env43382 := by
  intro p hp
  have h : env43382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43381_43382 : H12AffineEnvironment.transform 11 2587 env43381 = env43382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2587 env43381 == env43382) = true)

def env43383 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,16777216,533641,672785,134217728,148800,545089,96347,16876545,16949354,257,676881,151462017,525824]

theorem envBound43383 : H12AffineFastState.Bounded env43383 := by
  intro p hp
  have h : env43383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43153_43383 : H12AffineEnvironment.transform 24 533641 env43153 = env43383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533641 env43153 == env43383) = true)

def env43384 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,16777216,533641,672785,17245632,148800,545089,96347,16876545,16949354,257,676881,1345,525824]

theorem envBound43384 : H12AffineFastState.Bounded env43384 := by
  intro p hp
  have h : env43384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43383_43384 : H12AffineEnvironment.transform 26 17245632 env43383 = env43384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env43383 == env43384) = true)

theorem identity43384 : scanCanonicalize (H12AffineFastState.compose env43384 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 74863) := by decide +kernel

theorem selectedBound43384 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env43385 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,524288,32769,4096,61649,91182,16777216,533641,614526,17039791,90415,545089,96347,16876545,16876549,257,618622,1345,525824]

theorem envBound43385 : H12AffineFastState.Bounded env43385 := by
  intro p hp
  have h : env43385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43384_43385 : H12AffineEnvironment.transform 16 74863 env43384 = env43385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 74863 env43384 == env43385) = true)

def env43386 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,524288,32769,4096,61649,91182,123164,533641,614526,385203,90415,545089,96347,25885,25881,257,618622,1345,525824]

theorem envBound43386 : H12AffineFastState.Bounded env43386 := by
  intro p hp
  have h : env43386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43385_43386 : H12AffineEnvironment.transform 23 123164 env43385 = env43386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123164 env43385 == env43386) = true)

def env43387 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21584,32769,4096,61649,91182,123164,28889,78894,385203,90415,1297,96347,25885,25881,257,74798,1345,21072]

theorem envBound43387 : H12AffineFastState.Bounded env43387 := by
  intro p hp
  have h : env43387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43386_43387 : H12AffineEnvironment.transform 18 21584 env43386 = env43387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env43386 == env43387) = true)

theorem identity43387 : scanCanonicalize (H12AffineFastState.compose env43387 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound43387 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env43388 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13341,65536,74863,262144,21584,13340,4096,17612,91182,87297,28889,78894,349358,90415,1297,96347,25885,25881,257,74798,1345,21072]

theorem envBound43388 : H12AffineFastState.Bounded env43388 := by
  intro p hp
  have h : env43388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43387_43388 : H12AffineEnvironment.transform 14 13341 env43387 = env43388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env43387 == env43388) = true)

def env43389 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74863,262144,4416,13340,4096,476,74046,69649,13769,78894,332222,74815,1297,81227,8205,8201,257,74798,1345,5952]

theorem envBound43389 : H12AffineFastState.Bounded env43389 := by
  intro p hp
  have h : env43389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43388_43389 : H12AffineEnvironment.transform 13 1296 env43388 = env43389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env43388 == env43389) = true)

def env43390 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74863,65664,4416,13340,4096,476,74046,69649,13769,78894,4414,74815,1297,81227,8205,8201,257,74798,1345,5952]

theorem envBound43390 : H12AffineFastState.Bounded env43390 := by
  intro p hp
  have h : env43390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43389_43390 : H12AffineEnvironment.transform 17 65664 env43389 = env43390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env43389 == env43390) = true)

theorem identity43390 : scanCanonicalize (H12AffineFastState.compose env43390 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5465) := by decide +kernel

theorem selectedBound43390 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env43391 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5465,1296,324,65536,69942,65664,4416,325,4096,476,70759,69649,144,65911,4414,69990,1297,67602,5460,5456,257,70007,1345,5952]

theorem envBound43391 : H12AffineFastState.Bounded env43391 := by
  intro p hp
  have h : env43391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43390_43391 : H12AffineEnvironment.transform 12 5465 env43390 = env43391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5465 env43390 == env43391) = true)

def env43392 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5465,1296,324,1052,5418,1180,4416,325,4096,476,4219,5133,144,1387,4414,5498,1297,3086,5460,5456,257,5483,1345,5952]

theorem envBound43392 : H12AffineFastState.Bounded env43392 := by
  intro p hp
  have h : env43392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43391_43392 : H12AffineEnvironment.transform 15 1052 env43391 = env43392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1052 env43391 == env43392) = true)

theorem identity43392 : scanCanonicalize (H12AffineFastState.compose env43392 (packedSelected [0,2,3,5,8,11,15,16,17,20,21,23,24,27,28] rootPS)) = affineNative (2^(9+1) ^^^ 104) := by decide +kernel

theorem selectedBound43392 : packedSelected [0,2,3,5,8,11,15,16,17,20,21,23,24,27,28] rootPS < 2^1333 := by decide +kernel

def env43393 : List Nat := [2,4,8,16,32,64,128,256,512,104,2048,4096,4401,376,324,116,4418,244,4416,325,4096,476,4219,4197,144,259,4414,4370,377,2150,4412,4408,257,4355,297,4904]

theorem envBound43393 : H12AffineFastState.Bounded env43393 := by
  intro p hp
  have h : env43393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43392_43393 : H12AffineEnvironment.transform 9 104 env43392 = env43393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 104 env43392 == env43393) = true)

def env43394 : List Nat := [2,4,8,16,32,64,128,256,512,104,2048,80,353,376,324,116,274,244,272,325,80,476,43,53,144,259,366,322,377,2150,364,360,257,339,297,888]

theorem envBound43394 : H12AffineFastState.Bounded env43394 := by
  intro p hp
  have h : env43394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43393_43394 : H12AffineEnvironment.transform 11 80 env43393 = env43394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env43393 == env43394) = true)

theorem identity43394 : scanCanonicalize (H12AffineFastState.compose env43394 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound43394 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env43395 : List Nat := [2,4,8,16,28,64,128,256,512,84,2048,80,349,324,324,72,274,200,272,325,80,476,23,9,144,259,338,322,325,2138,336,340,257,339,277,836]

theorem envBound43395 : H12AffineFastState.Bounded env43395 := by
  intro p hp
  have h : env43395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43394_43395 : H12AffineEnvironment.transform 4 28 env43394 = env43395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env43394 == env43395) = true)

theorem identity43395 : scanCanonicalize (H12AffineFastState.compose env43395 (packedSelected [1,3,4,8,9,10,12,16,17] rootPS)) = affineNative (2^(10+1) ^^^ 589) := by decide +kernel

theorem selectedBound43395 : packedSelected [1,3,4,8,9,10,12,16,17] rootPS < 2^1333 := by decide +kernel

def env43396 : List Nat := [2,4,8,16,28,64,128,256,512,84,589,80,349,324,324,72,274,200,272,325,80,476,23,9,144,259,338,322,325,535,336,340,257,339,277,836]

theorem envBound43396 : H12AffineFastState.Bounded env43396 := by
  intro p hp
  have h : env43396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43395_43396 : H12AffineEnvironment.transform 10 589 env43395 = env43396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 589 env43395 == env43396) = true)

theorem identity43396 : scanCanonicalize (H12AffineFastState.compose env43396 (packedSelected [0,1,2,4,7,8,9,10,12,13,16,18] rootPS)) = affineNative (2^(8+1) ^^^ 259) := by decide +kernel

theorem selectedBound43396 : packedSelected [0,1,2,4,7,8,9,10,12,13,16,18] rootPS < 2^1333 := by decide +kernel

def env43397 : List Nat := [2,4,8,16,28,64,128,256,259,84,334,80,349,324,324,72,274,200,272,325,80,476,23,9,144,259,338,322,325,276,336,340,257,339,277,71]

theorem envBound43397 : H12AffineFastState.Bounded env43397 := by
  intro p hp
  have h : env43397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43396_43397 : H12AffineEnvironment.transform 8 259 env43396 = env43397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 259 env43396 == env43397) = true)

theorem identity43397 : scanCanonicalize (H12AffineFastState.compose env43397 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 67) := by decide +kernel

theorem selectedBound43397 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env43398 : List Nat := [2,4,8,16,28,64,128,67,64,84,13,80,30,7,7,72,81,200,83,6,80,159,23,9,144,64,17,1,6,87,19,23,66,16,86,71]

theorem envBound43398 : H12AffineFastState.Bounded env43398 := by
  intro p hp
  have h : env43398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43397_43398 : H12AffineEnvironment.transform 7 67 env43397 = env43398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 67 env43397 == env43398) = true)

theorem identity43398 : scanCanonicalize (H12AffineFastState.compose env43398 (packedSelected [0,3,7,11] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound43398 : packedSelected [0,3,7,11] rootPS < 2^1333 := by decide +kernel

def env43399 : List Nat := [2,4,8,16,28,64,3,67,64,84,13,80,30,7,7,72,81,75,83,6,80,28,23,9,19,64,17,1,6,87,19,23,66,16,86,71]

theorem envBound43399 : H12AffineFastState.Bounded env43399 := by
  intro p hp
  have h : env43399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43398_43399 : H12AffineEnvironment.transform 6 3 env43398 = env43399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env43398 == env43399) = true)

theorem identity43399 : scanCanonicalize (H12AffineFastState.compose env43399 (packedSelected [1,5,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound43399 : packedSelected [1,5,8] rootPS < 2^1333 := by decide +kernel

def env43400 : List Nat := [2,4,8,0,12,64,3,67,64,68,13,64,14,7,7,72,65,75,67,6,64,12,7,9,3,64,1,1,6,71,3,7,66,0,70,71]

theorem envBound43400 : H12AffineFastState.Bounded env43400 := by
  intro p hp
  have h : env43400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43399_43400 : H12AffineEnvironment.transform 3 0 env43399 = env43400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env43399 == env43400) = true)

theorem identity43400 : scanCanonicalize (H12AffineFastState.compose env43400 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound43400 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env43401 : List Nat := [2,4,8,0,12,13,3,14,13,9,13,13,14,7,7,5,12,6,14,6,13,12,7,9,3,13,1,1,6,10,3,7,15,0,11,10]

theorem envBound43401 : H12AffineFastState.Bounded env43401 := by
  intro p hp
  have h : env43401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43400_43401 : H12AffineEnvironment.transform 5 13 env43400 = env43401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env43400 == env43401) = true)

theorem identity43401 : scanCanonicalize (H12AffineFastState.compose env43401 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound43401 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43402 : List Nat := [2,2,8,0,10,11,3,8,11,9,11,11,8,1,1,3,10,0,8,0,11,10,1,9,3,11,1,1,0,10,3,1,9,0,11,10]

theorem envBound43402 : H12AffineFastState.Bounded env43402 := by
  intro p hp
  have h : env43402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43401_43402 : H12AffineEnvironment.transform 1 2 env43401 = env43402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env43401 == env43402) = true)

theorem identity43402 : scanCanonicalize (H12AffineFastState.compose env43402 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound43402 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43403 : List Nat := [2,2,0,0,2,3,3,0,3,1,3,3,0,1,1,3,2,0,0,0,3,2,1,1,3,3,1,1,0,2,3,1,1,0,3,2]

theorem envBound43403 : H12AffineFastState.Bounded env43403 := by
  intro p hp
  have h : env43403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43402_43403 : H12AffineEnvironment.transform 2 0 env43402 = env43403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env43402 == env43403) = true)

theorem identity43403 : scanCanonicalize (H12AffineFastState.compose env43403 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound43403 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env43404 : List Nat := [1,1,0,0,1,0,0,0,0,1,0,0,0,1,1,0,1,0,0,0,0,1,1,1,0,0,1,1,0,1,0,1,1,0,0,1]

theorem envBound43404 : H12AffineFastState.Bounded env43404 := by
  intro p hp
  have h : env43404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43403_43404 : H12AffineEnvironment.transform 0 1 env43403 = env43404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env43403 == env43404) = true)

def env43405 : List Nat := [2,4,8,16,32,64,128,256,512,104,2048,81,352,376,324,116,275,244,273,325,81,476,42,52,144,259,367,323,377,2150,365,361,257,338,297,889]

theorem envBound43405 : H12AffineFastState.Bounded env43405 := by
  intro p hp
  have h : env43405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43393_43405 : H12AffineEnvironment.transform 11 81 env43393 = env43405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env43393 == env43405) = true)

theorem identity43405 : scanCanonicalize (H12AffineFastState.compose env43405 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound43405 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env43406 : List Nat := [2,4,8,16,32,64,128,69,512,104,2048,81,37,61,1,116,86,244,84,0,81,153,42,52,144,70,42,6,60,2150,40,44,68,23,108,572]

theorem envBound43406 : H12AffineFastState.Bounded env43406 := by
  intro p hp
  have h : env43406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43405_43406 : H12AffineEnvironment.transform 7 69 env43405 = env43406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env43405 == env43406) = true)

theorem identity43406 : scanCanonicalize (H12AffineFastState.compose env43406 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound43406 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env43407 : List Nat := [2,4,8,16,32,16,128,21,512,56,2048,1,37,61,1,36,6,164,4,0,1,153,42,52,144,22,42,6,60,2102,40,44,20,23,60,572]

theorem envBound43407 : H12AffineFastState.Bounded env43407 := by
  intro p hp
  have h : env43407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43406_43407 : H12AffineEnvironment.transform 5 16 env43406 = env43407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43406 == env43407) = true)

theorem identity43407 : scanCanonicalize (H12AffineFastState.compose env43407 (packedSelected [0,1,7,8,10,11,12,13] rootPS)) = affineNative (2^(10+1) ^^^ 29) := by decide +kernel

theorem selectedBound43407 : packedSelected [0,1,7,8,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env43408 : List Nat := [2,4,8,16,32,16,128,21,512,56,29,1,37,61,1,36,6,164,4,0,1,153,42,52,144,22,42,6,60,43,40,44,20,23,60,572]

theorem envBound43408 : H12AffineFastState.Bounded env43408 := by
  intro p hp
  have h : env43408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43407_43408 : H12AffineEnvironment.transform 10 29 env43407 = env43408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 29 env43407 == env43408) = true)

theorem identity43408 : scanCanonicalize (H12AffineFastState.compose env43408 (packedSelected [2,12,15] rootPS)) = affineNative (2^(8+1) ^^^ 148) := by decide +kernel

theorem selectedBound43408 : packedSelected [2,12,15] rootPS < 2^1333 := by decide +kernel

def env43409 : List Nat := [2,4,8,16,32,16,128,21,148,56,29,1,37,61,1,36,6,164,4,0,1,153,42,52,144,22,42,6,60,43,40,44,20,23,60,168]

theorem envBound43409 : H12AffineFastState.Bounded env43409 := by
  intro p hp
  have h : env43409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43408_43409 : H12AffineEnvironment.transform 8 148 env43408 = env43409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 148 env43408 == env43409) = true)

theorem identity43409 : scanCanonicalize (H12AffineFastState.compose env43409 (packedSelected [0,5,7,10,11] rootPS)) = affineNative (2^(4+1) ^^^ 29) := by decide +kernel

theorem selectedBound43409 : packedSelected [0,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env43410 : List Nat := [2,4,8,16,29,16,128,21,148,5,29,1,24,0,1,25,6,153,4,0,1,153,23,9,144,22,23,6,1,22,21,17,20,23,1,149]

theorem envBound43410 : H12AffineFastState.Bounded env43410 := by
  intro p hp
  have h : env43410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43409_43410 : H12AffineEnvironment.transform 4 29 env43409 = env43410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env43409 == env43410) = true)

theorem identity43410 : scanCanonicalize (H12AffineFastState.compose env43410 (packedSelected [1,5] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound43410 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env43411 : List Nat := [2,4,8,16,29,16,14,21,26,5,29,1,24,0,1,25,6,23,4,0,1,23,23,9,30,22,23,6,1,22,21,17,20,23,1,27]

theorem envBound43411 : H12AffineFastState.Bounded env43411 := by
  intro p hp
  have h : env43411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43410_43411 : H12AffineEnvironment.transform 6 14 env43410 = env43411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env43410 == env43411) = true)

theorem identity43411 : scanCanonicalize (H12AffineFastState.compose env43411 (packedSelected [2,3] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound43411 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env43412 : List Nat := [2,4,4,16,17,16,2,21,22,5,17,1,20,0,1,21,6,23,4,0,1,23,23,5,18,22,23,6,1,22,21,17,20,23,1,23]

theorem envBound43412 : H12AffineFastState.Bounded env43412 := by
  intro p hp
  have h : env43412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43411_43412 : H12AffineEnvironment.transform 2 4 env43411 = env43412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env43411 == env43412) = true)

theorem identity43412 : scanCanonicalize (H12AffineFastState.compose env43412 (packedSelected [0,1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound43412 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env43413 : List Nat := [0,4,4,16,17,16,0,21,20,5,17,1,20,0,1,21,4,21,4,0,1,21,21,5,16,20,21,4,1,20,21,17,20,21,1,21]

theorem envBound43413 : H12AffineFastState.Bounded env43413 := by
  intro p hp
  have h : env43413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43412_43413 : H12AffineEnvironment.transform 0 0 env43412 = env43413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env43412 == env43413) = true)

theorem identity43413 : scanCanonicalize (H12AffineFastState.compose env43413 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound43413 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43414 : List Nat := [0,4,4,4,5,4,0,1,0,5,5,1,0,0,1,1,4,1,4,0,1,1,1,5,4,0,1,4,1,0,1,5,0,1,1,1]

theorem envBound43414 : H12AffineFastState.Bounded env43414 := by
  intro p hp
  have h : env43414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43413_43414 : H12AffineEnvironment.transform 3 4 env43413 = env43414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env43413 == env43414) = true)

theorem identity43414 : scanCanonicalize (H12AffineFastState.compose env43414 (packedSelected [7] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound43414 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env43415 : List Nat := [0,0,0,0,1,0,0,1,0,1,1,1,0,0,1,1,0,1,0,0,1,1,1,1,0,0,1,0,1,0,1,1,0,1,1,1]

theorem envBound43415 : H12AffineFastState.Bounded env43415 := by
  intro p hp
  have h : env43415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43414_43415 : H12AffineEnvironment.transform 1 0 env43414 = env43415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env43414 == env43415) = true)

def env43416 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5465,1296,324,1053,5419,1181,4416,325,4096,476,4218,5132,144,1386,4414,5499,1297,3087,5460,5456,257,5482,1345,5952]

theorem envBound43416 : H12AffineFastState.Bounded env43416 := by
  intro p hp
  have h : env43416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43391_43416 : H12AffineEnvironment.transform 15 1053 env43391 = env43416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1053 env43391 == env43416) = true)

theorem identity43416 : scanCanonicalize (H12AffineFastState.compose env43416 (packedSelected [0,2,3,5,8,11,15,16,17,20,21,23,24,27,28] rootPS)) = affineNative (2^(9+1) ^^^ 83) := by decide +kernel

theorem selectedBound43416 : packedSelected [0,2,3,5,8,11,15,16,17,20,21,23,24,27,28] rootPS < 2^1333 := by decide +kernel

def env43417 : List Nat := [2,4,8,16,32,64,128,256,512,83,2048,4096,4362,323,324,78,4472,206,4416,325,4096,476,4218,4191,144,313,4414,4392,322,2140,4359,4355,257,4409,274,4883]

theorem envBound43417 : H12AffineFastState.Bounded env43417 := by
  intro p hp
  have h : env43417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43416_43417 : H12AffineEnvironment.transform 9 83 env43416 = env43417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 83 env43416 == env43417) = true)

def env43418 : List Nat := [2,4,8,16,28,64,128,256,512,83,2048,4096,4362,323,324,78,4420,206,4416,325,4096,476,4166,4191,144,261,4354,4372,322,2140,4359,4355,257,4357,274,4883]

theorem envBound43418 : H12AffineFastState.Bounded env43418 := by
  intro p hp
  have h : env43418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43417_43418 : H12AffineEnvironment.transform 4 28 env43417 = env43418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env43417 == env43418) = true)

theorem identity43418 : scanCanonicalize (H12AffineFastState.compose env43418 (packedSelected [0,1,7,8,13,19,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound43418 : packedSelected [0,1,7,8,13,19,20,21] rootPS < 2^1333 := by decide +kernel

def env43419 : List Nat := [2,4,8,16,28,64,128,69,512,83,2048,4096,4175,6,1,78,4097,206,4101,0,4096,153,4166,4191,144,64,4167,4177,7,2140,4162,4166,68,4160,87,4694]

theorem envBound43419 : H12AffineFastState.Bounded env43419 := by
  intro p hp
  have h : env43419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43418_43419 : H12AffineEnvironment.transform 7 69 env43418 = env43419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env43418 == env43419) = true)

theorem identity43419 : scanCanonicalize (H12AffineFastState.compose env43419 (packedSelected [2,4,8,9,10,11,15,16,17,18] rootPS)) = affineNative (2^(11+1) ^^^ 2761) := by decide +kernel

theorem selectedBound43419 : packedSelected [2,4,8,9,10,11,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env43420 : List Nat := [2,4,8,16,28,64,128,69,512,83,2048,2761,2694,6,1,78,2760,206,2764,0,2761,153,2703,2710,144,64,2702,2712,7,2140,2699,2703,68,2697,87,2207]

theorem envBound43420 : H12AffineFastState.Bounded env43420 := by
  intro p hp
  have h : env43420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43419_43420 : H12AffineEnvironment.transform 11 2761 env43419 = env43420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2761 env43419 == env43420) = true)

theorem identity43420 : scanCanonicalize (H12AffineFastState.compose env43420 (packedSelected [0,1,7,8,19,20] rootPS)) = affineNative (2^(10+1) ^^^ 712) := by decide +kernel

theorem selectedBound43420 : packedSelected [0,1,7,8,19,20] rootPS < 2^1333 := by decide +kernel

def env43421 : List Nat := [2,4,8,16,28,64,128,69,512,83,712,1,78,6,1,78,0,206,4,0,1,153,71,94,144,64,70,80,7,660,67,71,68,65,87,599]

theorem envBound43421 : H12AffineFastState.Bounded env43421 := by
  intro p hp
  have h : env43421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43420_43421 : H12AffineEnvironment.transform 10 712 env43420 = env43421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 712 env43420 == env43421) = true)

theorem identity43421 : scanCanonicalize (H12AffineFastState.compose env43421 (packedSelected [0,1,7,10,11] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound43421 : packedSelected [0,1,7,10,11] rootPS < 2^1333 := by decide +kernel

def env43422 : List Nat := [2,4,8,16,28,64,128,69,10,83,194,1,78,6,1,78,0,206,4,0,1,153,71,94,144,64,70,80,7,158,67,71,68,65,87,93]

theorem envBound43422 : H12AffineFastState.Bounded env43422 := by
  intro p hp
  have h : env43422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43421_43422 : H12AffineEnvironment.transform 8 10 env43421 = env43422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env43421 == env43422) = true)

theorem identity43422 : scanCanonicalize (H12AffineFastState.compose env43422 (packedSelected [0,1,2,3,4,5,7,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 22) := by decide +kernel

theorem selectedBound43422 : packedSelected [0,1,2,3,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env43423 : List Nat := [2,4,8,16,28,22,128,19,10,5,148,1,24,6,1,24,0,152,4,0,1,153,17,8,144,22,16,6,7,158,21,17,18,23,1,11]

theorem envBound43423 : H12AffineFastState.Bounded env43423 := by
  intro p hp
  have h : env43423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43422_43423 : H12AffineEnvironment.transform 5 22 env43422 = env43423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 22 env43422 == env43423) = true)

theorem identity43423 : scanCanonicalize (H12AffineFastState.compose env43423 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound43423 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43424 : List Nat := [2,4,8,12,0,10,128,15,10,5,136,1,4,6,1,4,0,132,4,0,1,133,13,8,140,10,12,6,7,130,9,13,14,11,1,11]

theorem envBound43424 : H12AffineFastState.Bounded env43424 := by
  intro p hp
  have h : env43424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43423_43424 : H12AffineEnvironment.transform 3 12 env43423 = env43424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env43423 == env43424) = true)

theorem identity43424 : scanCanonicalize (H12AffineFastState.compose env43424 (packedSelected [1,4] rootPS)) = affineNative (2^(6+1) ^^^ 1) := by decide +kernel

theorem selectedBound43424 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env43425 : List Nat := [2,4,8,12,0,10,1,15,10,5,9,1,4,6,1,4,0,5,4,0,1,4,13,8,13,10,12,6,7,3,9,13,14,11,1,11]

theorem envBound43425 : H12AffineFastState.Bounded env43425 := by
  intro p hp
  have h : env43425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43424_43425 : H12AffineEnvironment.transform 6 1 env43424 = env43425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 1 env43424 == env43425) = true)

theorem identity43425 : scanCanonicalize (H12AffineFastState.compose env43425 (packedSelected [2,5] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound43425 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env43426 : List Nat := [2,4,6,2,0,4,1,1,4,5,7,1,4,6,1,4,0,5,4,0,1,4,3,6,3,4,2,6,7,3,7,3,0,5,1,5]

theorem envBound43426 : H12AffineFastState.Bounded env43426 := by
  intro p hp
  have h : env43426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43425_43426 : H12AffineEnvironment.transform 2 6 env43425 = env43426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env43425 == env43426) = true)

theorem identity43426 : scanCanonicalize (H12AffineFastState.compose env43426 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound43426 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43427 : List Nat := [0,4,4,0,0,4,1,1,4,5,5,1,4,4,1,4,0,5,4,0,1,4,1,4,1,4,0,4,5,1,5,1,0,5,1,5]

theorem envBound43427 : H12AffineFastState.Bounded env43427 := by
  intro p hp
  have h : env43427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43426_43427 : H12AffineEnvironment.transform 0 0 env43426 = env43427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env43426 == env43427) = true)

theorem identity43427 : scanCanonicalize (H12AffineFastState.compose env43427 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound43427 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43428 : List Nat := [0,1,1,0,0,1,1,1,1,0,0,1,1,1,1,1,0,0,1,0,1,1,1,1,1,1,0,1,0,1,0,1,0,0,1,0]

theorem envBound43428 : H12AffineFastState.Bounded env43428 := by
  intro p hp
  have h : env43428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43427_43428 : H12AffineEnvironment.transform 1 1 env43427 = env43428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env43427 == env43428) = true)

def env43429 : List Nat := [2,4,8,16,29,64,128,256,512,83,2048,4096,4362,323,324,78,4421,206,4416,325,4096,476,4167,4191,144,260,4355,4373,322,2140,4359,4355,257,4356,274,4883]

theorem envBound43429 : H12AffineFastState.Bounded env43429 := by
  intro p hp
  have h : env43429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43417_43429 : H12AffineEnvironment.transform 4 29 env43417 = env43429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env43417 == env43429) = true)

theorem identity43429 : scanCanonicalize (H12AffineFastState.compose env43429 (packedSelected [0,1,7,8,13,19,20,21] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound43429 : packedSelected [0,1,7,8,13,19,20,21] rootPS < 2^1333 := by decide +kernel

def env43430 : List Nat := [2,4,8,16,29,64,128,256,512,83,2048,276,30,323,324,78,81,206,84,325,276,476,339,331,144,260,23,1,322,2140,19,23,257,16,274,519]

theorem envBound43430 : H12AffineFastState.Bounded env43430 := by
  intro p hp
  have h : env43430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43429_43430 : H12AffineEnvironment.transform 11 276 env43429 = env43430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env43429 == env43430) = true)

theorem identity43430 : scanCanonicalize (H12AffineFastState.compose env43430 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound43430 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env43431 : List Nat := [2,4,8,16,29,16,128,256,512,3,2048,276,30,275,276,30,1,158,4,277,276,396,259,283,144,260,23,1,274,2060,19,23,257,16,274,519]

theorem envBound43431 : H12AffineFastState.Bounded env43431 := by
  intro p hp
  have h : env43431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43430_43431 : H12AffineEnvironment.transform 5 16 env43430 = env43431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43430 == env43431) = true)

theorem identity43431 : scanCanonicalize (H12AffineFastState.compose env43431 (packedSelected [3,4,5,9,10,15,16] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound43431 : packedSelected [3,4,5,9,10,15,16] rootPS < 2^1333 := by decide +kernel

def env43432 : List Nat := [2,4,8,16,29,16,14,256,512,3,2048,276,30,275,276,30,1,16,4,277,276,258,259,283,30,260,23,1,274,2060,19,23,257,16,274,519]

theorem envBound43432 : H12AffineFastState.Bounded env43432 := by
  intro p hp
  have h : env43432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43431_43432 : H12AffineEnvironment.transform 6 14 env43431 = env43432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env43431 == env43432) = true)

theorem identity43432 : scanCanonicalize (H12AffineFastState.compose env43432 (packedSelected [5,12] rootPS)) = affineNative (2^(8+1) ^^^ 265) := by decide +kernel

theorem selectedBound43432 : packedSelected [5,12] rootPS < 2^1333 := by decide +kernel

def env43433 : List Nat := [2,4,8,16,29,16,14,256,265,3,2048,276,30,275,276,30,1,16,4,277,276,258,259,283,30,260,23,1,274,2060,19,23,257,16,274,270]

theorem envBound43433 : H12AffineFastState.Bounded env43433 := by
  intro p hp
  have h : env43433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43432_43433 : H12AffineEnvironment.transform 8 265 env43432 = env43433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 265 env43432 == env43433) = true)

def env43434 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74863,65665,4416,13340,4096,476,74046,69649,13769,78894,4415,74815,1297,81227,8205,8201,257,74798,1345,5952]

theorem envBound43434 : H12AffineFastState.Bounded env43434 := by
  intro p hp
  have h : env43434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43389_43434 : H12AffineEnvironment.transform 17 65665 env43389 = env43434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env43389 == env43434) = true)

theorem identity43434 : scanCanonicalize (H12AffineFastState.compose env43434 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound43434 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env43435 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,24,1296,5125,65536,66679,65665,4416,5124,4096,476,65830,69649,5585,70710,4415,66599,1297,73043,21,17,257,66614,1345,5952]

theorem envBound43435 : H12AffineFastState.Bounded env43435 := by
  intro p hp
  have h : env43435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43434_43435 : H12AffineEnvironment.transform 12 24 env43434 = env43435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env43434 == env43435) = true)

def env43436 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,24,1296,5125,1052,107,1181,4416,5124,4096,476,1338,5133,5585,4138,4415,59,1297,6479,21,17,257,42,1345,5952]

theorem envBound43436 : H12AffineFastState.Bounded env43436 := by
  intro p hp
  have h : env43436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43435_43436 : H12AffineEnvironment.transform 15 1052 env43435 = env43436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1052 env43435 == env43436) = true)

theorem identity43436 : scanCanonicalize (H12AffineFastState.compose env43436 (packedSelected [0,1,2,4,7,9,10,11,15,17,19,21,23,24,28] rootPS)) = affineNative (2^(11+1) ^^^ 1404) := by decide +kernel

theorem selectedBound43436 : packedSelected [0,1,2,4,7,9,10,11,15,17,19,21,23,24,28] rootPS < 2^1333 := by decide +kernel

def env43437 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1404,24,1296,377,1052,107,1181,1084,376,1404,476,1338,369,173,1366,1091,59,1297,3123,21,17,257,42,1345,572]

theorem envBound43437 : H12AffineFastState.Bounded env43437 := by
  intro p hp
  have h : env43437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43436_43437 : H12AffineEnvironment.transform 11 1404 env43436 = env43437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1404 env43436 == env43437) = true)

def env43438 : List Nat := [2,4,8,16,28,64,128,256,512,1024,2048,1344,24,1296,325,1052,87,1181,1024,324,1344,476,1286,333,145,1366,1091,7,1297,3087,21,17,257,22,1345,512]

theorem envBound43438 : H12AffineFastState.Bounded env43438 := by
  intro p hp
  have h : env43438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43437_43438 : H12AffineEnvironment.transform 4 28 env43437 = env43438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env43437 == env43438) = true)

theorem identity43438 : scanCanonicalize (H12AffineFastState.compose env43438 (packedSelected [4,9,16] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound43438 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env43439 : List Nat := [2,4,8,16,28,64,128,256,512,84,2048,276,24,324,325,72,87,201,84,324,276,476,338,333,145,258,23,7,325,2139,21,17,257,22,277,512]

theorem envBound43439 : H12AffineFastState.Bounded env43439 := by
  intro p hp
  have h : env43439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43438_43439 : H12AffineEnvironment.transform 9 84 env43438 = env43439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env43438 == env43439) = true)

theorem identity43439 : scanCanonicalize (H12AffineFastState.compose env43439 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound43439 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env43440 : List Nat := [2,4,8,16,28,16,128,256,512,4,2048,276,24,276,277,24,7,153,4,276,276,396,258,285,145,258,23,7,277,2059,21,17,257,22,277,512]

theorem envBound43440 : H12AffineFastState.Bounded env43440 := by
  intro p hp
  have h : env43440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43439_43440 : H12AffineEnvironment.transform 5 16 env43439 = env43440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43439 == env43440) = true)

theorem identity43440 : scanCanonicalize (H12AffineFastState.compose env43440 (packedSelected [0,1,5,7,8,11,13,15,17] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound43440 : packedSelected [0,1,5,7,8,11,13,15,17] rootPS < 2^1333 := by decide +kernel

def env43441 : List Nat := [2,4,4,16,16,16,128,256,512,4,2048,276,20,276,277,20,7,149,4,276,276,384,258,273,145,258,23,7,277,2055,21,17,257,22,277,512]

theorem envBound43441 : H12AffineFastState.Bounded env43441 := by
  intro p hp
  have h : env43441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43440_43441 : H12AffineEnvironment.transform 2 4 env43440 = env43441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env43440 == env43441) = true)

theorem identity43441 : scanCanonicalize (H12AffineFastState.compose env43441 (packedSelected [2,5,12] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound43441 : packedSelected [2,5,12] rootPS < 2^1333 := by decide +kernel

def env43442 : List Nat := [2,4,4,16,16,16,5,256,512,4,2048,276,20,276,277,20,7,16,4,276,276,261,258,273,20,258,23,7,277,2055,21,17,257,22,277,512]

theorem envBound43442 : H12AffineFastState.Bounded env43442 := by
  intro p hp
  have h : env43442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43441_43442 : H12AffineEnvironment.transform 6 5 env43441 = env43442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env43441 == env43442) = true)

theorem identity43442 : scanCanonicalize (H12AffineFastState.compose env43442 (packedSelected [0,1,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 3) := by decide +kernel

theorem selectedBound43442 : packedSelected [0,1,7,8] rootPS < 2^1333 := by decide +kernel

def env43443 : List Nat := [2,4,4,16,16,16,5,3,512,4,2048,23,20,23,22,20,7,16,4,23,23,6,1,18,20,1,23,7,22,2055,21,17,2,22,22,512]

theorem envBound43443 : H12AffineFastState.Bounded env43443 := by
  intro p hp
  have h : env43443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43442_43443 : H12AffineEnvironment.transform 7 3 env43442 = env43443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 3 env43442 == env43443) = true)

theorem identity43443 : scanCanonicalize (H12AffineFastState.compose env43443 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 535) := by decide +kernel

theorem selectedBound43443 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env43444 : List Nat := [2,4,4,16,16,16,5,3,512,4,535,23,20,23,22,20,7,16,4,23,23,6,1,18,20,1,23,7,22,528,21,17,2,22,22,512]

theorem envBound43444 : H12AffineFastState.Bounded env43444 := by
  intro p hp
  have h : env43444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43443_43444 : H12AffineEnvironment.transform 10 535 env43443 = env43444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 535 env43443 == env43444) = true)

def env43445 : List Nat := [2,4,8,16,29,64,128,256,512,1024,2048,1345,24,1296,324,1052,86,1181,1025,325,1345,476,1287,332,144,1366,1091,6,1297,3086,21,17,257,23,1345,513]

theorem envBound43445 : H12AffineFastState.Bounded env43445 := by
  intro p hp
  have h : env43445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43437_43445 : H12AffineEnvironment.transform 4 29 env43437 = env43445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env43437 == env43445) = true)

theorem identity43445 : scanCanonicalize (H12AffineFastState.compose env43445 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 19) := by decide +kernel

theorem selectedBound43445 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env43446 : List Nat := [2,4,8,16,29,64,128,19,512,1024,2048,1106,24,1027,87,1052,86,1181,1025,86,1106,207,1044,95,144,1093,1091,6,1026,3086,21,17,18,23,1106,513]

theorem envBound43446 : H12AffineFastState.Bounded env43446 := by
  intro p hp
  have h : env43446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43445_43446 : H12AffineEnvironment.transform 7 19 env43445 = env43446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 19 env43445 == env43446) = true)

theorem identity43446 : scanCanonicalize (H12AffineFastState.compose env43446 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(5+1) ^^^ 22) := by decide +kernel

theorem selectedBound43446 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env43447 : List Nat := [2,4,8,16,29,22,128,19,512,1024,2048,1028,24,1027,1,1052,0,1181,1025,0,1028,153,1044,9,144,1043,1045,6,1026,3086,21,17,18,23,1028,513]

theorem envBound43447 : H12AffineFastState.Bounded env43447 := by
  intro p hp
  have h : env43447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43446_43447 : H12AffineEnvironment.transform 5 22 env43446 = env43447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 22 env43446 == env43447) = true)

theorem identity43447 : scanCanonicalize (H12AffineFastState.compose env43447 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 19) := by decide +kernel

theorem selectedBound43447 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env43448 : List Nat := [2,4,8,16,29,22,128,19,512,19,2048,23,24,16,1,15,0,142,18,0,23,153,7,9,144,0,6,6,17,2077,21,17,18,23,23,513]

theorem envBound43448 : H12AffineFastState.Bounded env43448 := by
  intro p hp
  have h : env43448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43447_43448 : H12AffineEnvironment.transform 9 19 env43447 = env43448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 19 env43447 == env43448) = true)

theorem identity43448 : scanCanonicalize (H12AffineFastState.compose env43448 (packedSelected [2,7] rootPS)) = affineNative (2^(8+1) ^^^ 135) := by decide +kernel

theorem selectedBound43448 : packedSelected [2,7] rootPS < 2^1333 := by decide +kernel

def env43449 : List Nat := [2,4,8,16,29,22,128,19,135,19,2048,23,24,16,1,15,0,142,18,0,23,153,7,9,144,0,6,6,17,2077,21,17,18,23,23,134]

theorem envBound43449 : H12AffineFastState.Bounded env43449 := by
  intro p hp
  have h : env43449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43448_43449 : H12AffineEnvironment.transform 8 135 env43448 = env43449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 135 env43448 == env43449) = true)

theorem identity43449 : scanCanonicalize (H12AffineFastState.compose env43449 (packedSelected [0,11,12,13] rootPS)) = affineNative (2^(10+1) ^^^ 5) := by decide +kernel

theorem selectedBound43449 : packedSelected [0,11,12,13] rootPS < 2^1333 := by decide +kernel

def env43450 : List Nat := [2,4,8,16,29,22,128,19,135,19,5,23,24,16,1,15,0,142,18,0,23,153,7,9,144,0,6,6,17,24,21,17,18,23,23,134]

theorem envBound43450 : H12AffineFastState.Bounded env43450 := by
  intro p hp
  have h : env43450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43449_43450 : H12AffineEnvironment.transform 10 5 env43449 = env43450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 5 env43449 == env43450) = true)

theorem identity43450 : scanCanonicalize (H12AffineFastState.compose env43450 (packedSelected [1,3,8,15] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound43450 : packedSelected [1,3,8,15] rootPS < 2^1333 := by decide +kernel

def env43451 : List Nat := [2,4,6,16,19,22,128,19,135,19,5,23,22,16,1,1,0,128,18,0,23,151,7,7,144,0,6,6,17,22,21,17,18,23,23,134]

theorem envBound43451 : H12AffineFastState.Bounded env43451 := by
  intro p hp
  have h : env43451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43450_43451 : H12AffineEnvironment.transform 2 6 env43450 = env43451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env43450 == env43451) = true)

theorem identity43451 : scanCanonicalize (H12AffineFastState.compose env43451 (packedSelected [2,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound43451 : packedSelected [2,4,5] rootPS < 2^1333 := by decide +kernel

def env43452 : List Nat := [2,4,6,16,19,22,19,19,20,19,5,23,22,16,1,1,0,19,18,0,23,4,7,7,3,0,6,6,17,22,21,17,18,23,23,21]

theorem envBound43452 : H12AffineFastState.Bounded env43452 := by
  intro p hp
  have h : env43452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43451_43452 : H12AffineEnvironment.transform 6 19 env43451 = env43452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env43451 == env43452) = true)

theorem identity43452 : scanCanonicalize (H12AffineFastState.compose env43452 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound43452 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env43453 : List Nat := [2,4,6,7,4,1,4,4,3,4,5,0,1,7,1,1,0,4,5,0,0,4,7,7,3,0,6,6,6,1,2,6,5,0,0,2]

theorem envBound43453 : H12AffineFastState.Bounded env43453 := by
  intro p hp
  have h : env43453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43452_43453 : H12AffineEnvironment.transform 3 7 env43452 = env43453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env43452 == env43453) = true)

theorem identity43453 : scanCanonicalize (H12AffineFastState.compose env43453 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound43453 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43454 : List Nat := [1,4,5,4,4,1,4,4,0,4,5,0,1,4,1,1,0,4,5,0,0,4,4,4,0,0,5,5,5,1,1,5,5,0,0,1]

theorem envBound43454 : H12AffineFastState.Bounded env43454 := by
  intro p hp
  have h : env43454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43453_43454 : H12AffineEnvironment.transform 0 1 env43453 = env43454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env43453 == env43454) = true)

def env43455 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,24,1296,5125,1053,106,1180,4416,5124,4096,476,1339,5132,5585,4139,4415,58,1297,6478,21,17,257,43,1345,5952]

theorem envBound43455 : H12AffineFastState.Bounded env43455 := by
  intro p hp
  have h : env43455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43435_43455 : H12AffineEnvironment.transform 15 1053 env43435 = env43455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1053 env43435 == env43455) = true)

theorem identity43455 : scanCanonicalize (H12AffineFastState.compose env43455 (packedSelected [0,1,2,4,7,9,10,11,15,17,19,21,23,24,28] rootPS)) = affineNative (2^(11+1) ^^^ 1351) := by decide +kernel

theorem selectedBound43455 : packedSelected [0,1,2,4,7,9,10,11,15,17,19,21,23,24,28] rootPS < 2^1333 := by decide +kernel

def env43456 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1351,24,1296,322,1053,106,1180,1031,323,1351,476,1339,331,150,1388,1144,58,1297,3081,21,17,257,43,1345,519]

theorem envBound43456 : H12AffineFastState.Bounded env43456 := by
  intro p hp
  have h : env43456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43455_43456 : H12AffineEnvironment.transform 11 1351 env43455 = env43456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1351 env43455 == env43456) = true)

def env43457 : List Nat := [2,4,8,16,32,64,128,256,512,380,2048,59,24,108,322,353,106,480,379,323,59,476,71,331,150,16,260,58,109,2421,21,17,257,43,61,519]

theorem envBound43457 : H12AffineFastState.Bounded env43457 := by
  intro p hp
  have h : env43457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43456_43457 : H12AffineEnvironment.transform 9 380 env43456 = env43457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 380 env43456 == env43457) = true)

theorem identity43457 : scanCanonicalize (H12AffineFastState.compose env43457 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 47) := by decide +kernel

theorem selectedBound43457 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env43458 : List Nat := [2,4,8,16,32,64,128,47,512,83,2048,59,24,108,109,78,106,207,84,108,59,243,71,100,150,16,43,58,109,2138,21,17,46,43,61,519]

theorem envBound43458 : H12AffineFastState.Bounded env43458 := by
  intro p hp
  have h : env43458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43457_43458 : H12AffineEnvironment.transform 7 47 env43457 = env43458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 47 env43457 == env43458) = true)

theorem identity43458 : scanCanonicalize (H12AffineFastState.compose env43458 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound43458 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env43459 : List Nat := [2,4,8,16,32,16,128,47,512,3,2048,59,24,60,61,30,58,159,4,60,59,163,23,52,150,16,43,58,61,2058,21,17,46,43,61,519]

theorem envBound43459 : H12AffineFastState.Bounded env43459 := by
  intro p hp
  have h : env43459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43458_43459 : H12AffineEnvironment.transform 5 16 env43458 = env43459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43458 == env43459) = true)

theorem identity43459 : scanCanonicalize (H12AffineFastState.compose env43459 (packedSelected [0,1,3,5,7,11,12,13] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound43459 : packedSelected [0,1,3,5,7,11,12,13] rootPS < 2^1333 := by decide +kernel

def env43460 : List Nat := [2,4,8,16,32,16,128,47,512,3,10,59,24,60,61,30,58,159,4,60,59,163,23,52,150,16,43,58,61,0,21,17,46,43,61,519]

theorem envBound43460 : H12AffineFastState.Bounded env43460 := by
  intro p hp
  have h : env43460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43459_43460 : H12AffineEnvironment.transform 10 10 env43459 = env43460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env43459 == env43460) = true)

theorem identity43460 : scanCanonicalize (H12AffineFastState.compose env43460 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 55) := by decide +kernel

theorem selectedBound43460 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43461 : List Nat := [2,4,8,16,32,16,128,47,55,3,10,59,24,60,61,30,58,159,4,60,59,163,23,52,150,16,43,58,61,0,21,17,46,43,61,48]

theorem envBound43461 : H12AffineFastState.Bounded env43461 := by
  intro p hp
  have h : env43461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43460_43461 : H12AffineEnvironment.transform 8 55 env43460 = env43461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 55 env43460 == env43461) = true)

theorem identity43461 : scanCanonicalize (H12AffineFastState.compose env43461 (packedSelected [0,1,3,7,11,15] rootPS)) = affineNative (2^(6+1) ^^^ 53) := by decide +kernel

theorem selectedBound43461 : packedSelected [0,1,3,7,11,15] rootPS < 2^1333 := by decide +kernel

def env43462 : List Nat := [2,4,8,16,32,16,53,47,55,3,10,59,24,60,61,30,58,42,4,60,59,22,23,52,35,16,43,58,61,0,21,17,46,43,61,48]

theorem envBound43462 : H12AffineFastState.Bounded env43462 := by
  intro p hp
  have h : env43462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43461_43462 : H12AffineEnvironment.transform 6 53 env43461 = env43462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 53 env43461 == env43462) = true)

theorem identity43462 : scanCanonicalize (H12AffineFastState.compose env43462 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound43462 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env43463 : List Nat := [2,4,8,11,32,11,46,47,44,3,10,32,3,39,38,5,33,42,4,39,32,13,12,47,35,11,43,33,38,0,14,10,46,43,38,43]

theorem envBound43463 : H12AffineFastState.Bounded env43463 := by
  intro p hp
  have h : env43463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43462_43463 : H12AffineEnvironment.transform 3 11 env43462 = env43463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env43462 == env43463) = true)

theorem identity43463 : scanCanonicalize (H12AffineFastState.compose env43463 (packedSelected [0,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound43463 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env43464 : List Nat := [2,4,8,11,13,11,3,2,1,3,10,13,3,10,11,5,12,7,4,10,13,13,12,2,14,11,6,12,11,0,14,10,3,6,11,6]

theorem envBound43464 : H12AffineFastState.Bounded env43464 := by
  intro p hp
  have h : env43464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43463_43464 : H12AffineEnvironment.transform 4 13 env43463 = env43464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env43463 == env43464) = true)

theorem identity43464 : scanCanonicalize (H12AffineFastState.compose env43464 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound43464 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env43465 : List Nat := [2,3,8,11,10,11,3,2,1,3,10,10,3,10,11,2,11,0,3,10,10,10,11,2,9,11,1,11,11,0,9,10,3,1,11,1]

theorem envBound43465 : H12AffineFastState.Bounded env43465 := by
  intro p hp
  have h : env43465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43464_43465 : H12AffineEnvironment.transform 1 3 env43464 = env43465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env43464 == env43465) = true)

theorem identity43465 : scanCanonicalize (H12AffineFastState.compose env43465 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound43465 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43466 : List Nat := [2,3,2,1,0,1,3,2,1,3,0,0,3,0,1,2,1,0,3,0,0,0,1,2,3,1,1,1,1,0,3,0,3,1,1,1]

theorem envBound43466 : H12AffineFastState.Bounded env43466 := by
  intro p hp
  have h : env43466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43465_43466 : H12AffineEnvironment.transform 2 2 env43465 = env43466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env43465 == env43466) = true)

def env43467 : List Nat := [2,4,8,16,32,64,128,256,512,381,2048,58,24,109,322,352,106,481,378,323,58,476,70,331,150,17,261,58,108,2420,21,17,257,43,60,519]

theorem envBound43467 : H12AffineFastState.Bounded env43467 := by
  intro p hp
  have h : env43467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43456_43467 : H12AffineEnvironment.transform 9 381 env43456 = env43467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 381 env43456 == env43467) = true)

theorem identity43467 : scanCanonicalize (H12AffineFastState.compose env43467 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 41) := by decide +kernel

theorem selectedBound43467 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env43468 : List Nat := [2,4,8,16,32,64,128,41,512,84,2048,58,24,109,107,73,106,200,83,106,58,245,70,98,150,17,44,58,108,2141,21,17,40,43,60,519]

theorem envBound43468 : H12AffineFastState.Bounded env43468 := by
  intro p hp
  have h : env43468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43467_43468 : H12AffineEnvironment.transform 7 41 env43467 = env43468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 41 env43467 == env43468) = true)

theorem identity43468 : scanCanonicalize (H12AffineFastState.compose env43468 (packedSelected [2,4,9,12,17,19,21,23,24] rootPS)) = affineNative (2^(10+1) ^^^ 233) := by decide +kernel

theorem selectedBound43468 : packedSelected [2,4,9,12,17,19,21,23,24] rootPS < 2^1333 := by decide +kernel

def env43469 : List Nat := [2,4,8,16,32,64,128,41,512,84,233,58,24,109,107,73,106,200,83,106,58,245,70,98,150,17,44,58,108,180,21,17,40,43,60,519]

theorem envBound43469 : H12AffineFastState.Bounded env43469 := by
  intro p hp
  have h : env43469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43468_43469 : H12AffineEnvironment.transform 10 233 env43468 = env43469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 233 env43468 == env43469) = true)

theorem identity43469 : scanCanonicalize (H12AffineFastState.compose env43469 (packedSelected [0,1,3,7,8,12,15,20] rootPS)) = affineNative (2^(8+1) ^^^ 108) := by decide +kernel

theorem selectedBound43469 : packedSelected [0,1,3,7,8,12,15,20] rootPS < 2^1333 := by decide +kernel

def env43470 : List Nat := [2,4,8,16,32,64,128,41,108,84,233,58,24,109,107,73,106,200,83,106,58,245,70,98,150,17,44,58,108,180,21,17,40,43,60,107]

theorem envBound43470 : H12AffineFastState.Bounded env43470 := by
  intro p hp
  have h : env43470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43469_43470 : H12AffineEnvironment.transform 8 108 env43469 = env43470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 108 env43469 == env43470) = true)

theorem identity43470 : scanCanonicalize (H12AffineFastState.compose env43470 (packedSelected [0,1,2,7,10,11,12,13] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound43470 : packedSelected [0,1,2,7,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env43471 : List Nat := [2,4,8,16,26,64,128,19,86,84,211,0,24,87,81,73,80,200,83,80,0,207,70,88,150,17,22,0,86,142,21,17,18,17,6,81]

theorem envBound43471 : H12AffineFastState.Bounded env43471 := by
  intro p hp
  have h : env43471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43470_43471 : H12AffineEnvironment.transform 4 26 env43470 = env43471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env43470 == env43471) = true)

theorem identity43471 : scanCanonicalize (H12AffineFastState.compose env43471 (packedSelected [3,8,10] rootPS)) = affineNative (2^(5+1) ^^^ 23) := by decide +kernel

theorem selectedBound43471 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env43472 : List Nat := [2,4,8,16,26,23,128,19,1,3,132,0,24,0,6,30,7,159,4,7,0,152,17,15,150,17,22,0,1,142,21,17,18,17,6,6]

theorem envBound43472 : H12AffineFastState.Bounded env43472 := by
  intro p hp
  have h : env43472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43471_43472 : H12AffineEnvironment.transform 5 23 env43471 = env43472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 23 env43471 == env43472) = true)

theorem identity43472 : scanCanonicalize (H12AffineFastState.compose env43472 (packedSelected [3,5] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound43472 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env43473 : List Nat := [2,4,8,12,6,11,128,15,1,3,132,0,4,0,6,2,7,131,4,7,0,132,13,15,138,13,10,0,1,142,9,13,14,13,6,6]

theorem envBound43473 : H12AffineFastState.Bounded env43473 := by
  intro p hp
  have h : env43473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43472_43473 : H12AffineEnvironment.transform 3 12 env43472 = env43473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env43472 == env43473) = true)

theorem identity43473 : scanCanonicalize (H12AffineFastState.compose env43473 (packedSelected [2,3] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound43473 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env43474 : List Nat := [2,4,8,12,6,11,4,15,1,3,0,0,4,0,6,2,7,7,4,7,0,0,13,15,14,13,10,0,1,10,9,13,14,13,6,6]

theorem envBound43474 : H12AffineFastState.Bounded env43474 := by
  intro p hp
  have h : env43474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43473_43474 : H12AffineEnvironment.transform 6 4 env43473 = env43474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env43473 == env43474) = true)

theorem identity43474 : scanCanonicalize (H12AffineFastState.compose env43474 (packedSelected [0,1,4] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound43474 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env43475 : List Nat := [2,4,4,0,6,7,4,3,1,3,0,0,4,0,6,2,7,7,4,7,0,0,1,3,2,1,6,0,1,6,5,1,2,1,6,6]

theorem envBound43475 : H12AffineFastState.Bounded env43475 := by
  intro p hp
  have h : env43475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43474_43475 : H12AffineEnvironment.transform 2 4 env43474 = env43475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env43474 == env43475) = true)

theorem identity43475 : scanCanonicalize (H12AffineFastState.compose env43475 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound43475 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43476 : List Nat := [2,2,2,0,0,1,2,3,1,3,0,0,2,0,0,2,1,1,2,1,0,0,1,3,2,1,0,0,1,0,3,1,2,1,0,0]

theorem envBound43476 : H12AffineFastState.Bounded env43476 := by
  intro p hp
  have h : env43476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43475_43476 : H12AffineEnvironment.transform 1 2 env43475 = env43476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env43475 == env43476) = true)

theorem identity43476 : scanCanonicalize (H12AffineFastState.compose env43476 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound43476 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43477 : List Nat := [0,0,0,0,0,1,0,1,1,1,0,0,0,0,0,0,1,1,0,1,0,0,1,1,0,1,0,0,1,0,1,1,0,1,0,0]

theorem envBound43477 : H12AffineFastState.Bounded env43477 := by
  intro p hp
  have h : env43477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43476_43477 : H12AffineEnvironment.transform 0 0 env43476 = env43477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env43476 == env43477) = true)

def env43478 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74863,262144,4417,13340,4096,477,74047,69648,13768,78894,332223,74814,1297,81226,8204,8200,257,74798,1345,5953]

theorem envBound43478 : H12AffineFastState.Bounded env43478 := by
  intro p hp
  have h : env43478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43388_43478 : H12AffineEnvironment.transform 13 1297 env43388 = env43478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env43388 == env43478) = true)

def env43479 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74863,65664,4417,13340,4096,477,74047,69648,13768,78894,4415,74814,1297,81226,8204,8200,257,74798,1345,5953]

theorem envBound43479 : H12AffineFastState.Bounded env43479 := by
  intro p hp
  have h : env43479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43478_43479 : H12AffineEnvironment.transform 17 65664 env43478 = env43479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env43478 == env43479) = true)

theorem identity43479 : scanCanonicalize (H12AffineFastState.compose env43479 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound43479 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env43480 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,0,12556,65536,74110,65664,4417,12557,4096,477,74047,69648,12505,78143,4415,74031,0,79963,8204,8200,257,74047,80,4688]

theorem envBound43480 : H12AffineFastState.Bounded env43480 := by
  intro p hp
  have h : env43480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43479_43480 : H12AffineEnvironment.transform 9 273 env43479 = env43480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env43479 == env43480) = true)

def env43481 : List Nat := [2,4,8,16,32,64,128,256,340,273,2048,4096,8192,0,12556,65536,74110,65664,4417,12557,4096,477,74047,69648,12505,78143,4415,74031,0,79963,8204,8200,257,74047,80,4356]

theorem envBound43481 : H12AffineFastState.Bounded env43481 := by
  intro p hp
  have h : env43481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43480_43481 : H12AffineEnvironment.transform 8 340 env43480 = env43481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env43480 == env43481) = true)

def env43482 : List Nat := [2,4,8,16,32,64,128,256,340,273,2048,16,8192,0,8476,65536,74110,65664,337,8477,16,477,74047,65536,8393,74031,303,74031,0,75851,8204,8200,257,74047,80,276]

theorem envBound43482 : H12AffineFastState.Bounded env43482 := by
  intro p hp
  have h : env43482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43481_43482 : H12AffineEnvironment.transform 11 16 env43481 = env43482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env43481 == env43482) = true)

theorem identity43482 : scanCanonicalize (H12AffineFastState.compose env43482 (packedSelected [1,8,28] rootPS)) = affineNative (2^(5+1) ^^^ 29) := by decide +kernel

theorem selectedBound43482 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env43483 : List Nat := [2,4,8,16,32,29,128,256,265,273,2048,16,8192,0,8476,65536,74019,65664,268,8477,16,384,74047,65536,8340,74031,303,74031,0,75798,8204,8200,257,74047,13,276]

theorem envBound43483 : H12AffineFastState.Bounded env43483 := by
  intro p hp
  have h : env43483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43482_43483 : H12AffineEnvironment.transform 5 29 env43482 = env43483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 29 env43482 == env43483) = true)

def env43484 : List Nat := [2,4,8,12,32,1,128,256,265,269,2048,12,8192,0,8448,65536,74019,65664,268,8449,12,384,74019,65536,8328,74031,303,74031,0,75786,8204,8200,257,74019,13,264]

theorem envBound43484 : H12AffineFastState.Bounded env43484 := by
  intro p hp
  have h : env43484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43483_43484 : H12AffineEnvironment.transform 3 12 env43483 = env43484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env43483 == env43484) = true)

theorem identity43484 : scanCanonicalize (H12AffineFastState.compose env43484 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 8230) := by decide +kernel

theorem selectedBound43484 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env43485 : List Nat := [2,4,8,12,32,1,128,256,265,269,2048,12,8192,0,8448,8230,261,8358,268,8449,12,384,261,8230,8328,265,303,265,0,2092,8204,8200,257,261,13,264]

theorem envBound43485 : H12AffineFastState.Bounded env43485 := by
  intro p hp
  have h : env43485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43484_43485 : H12AffineEnvironment.transform 15 8230 env43484 = env43485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8230 env43484 == env43485) = true)

theorem identity43485 : scanCanonicalize (H12AffineFastState.compose env43485 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 257) := by decide +kernel

theorem selectedBound43485 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env43486 : List Nat := [2,4,8,12,32,1,128,256,265,269,2048,12,257,0,1,295,261,423,268,0,12,384,261,295,393,265,303,265,0,2092,269,265,257,261,13,264]

theorem envBound43486 : H12AffineFastState.Bounded env43486 := by
  intro p hp
  have h : env43486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43485_43486 : H12AffineEnvironment.transform 12 257 env43485 = env43486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 257 env43485 == env43486) = true)

theorem identity43486 : scanCanonicalize (H12AffineFastState.compose env43486 (packedSelected [3,5,10] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound43486 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env43487 : List Nat := [2,4,5,1,32,1,128,256,260,256,2048,1,257,0,1,295,261,423,257,0,1,384,261,295,388,260,290,260,0,2081,256,260,257,261,0,261]

theorem envBound43487 : H12AffineFastState.Bounded env43487 := by
  intro p hp
  have h : env43487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43486_43487 : H12AffineEnvironment.transform 2 5 env43486 = env43487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env43486 == env43487) = true)

theorem identity43487 : scanCanonicalize (H12AffineFastState.compose env43487 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 161) := by decide +kernel

theorem selectedBound43487 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43488 : List Nat := [2,4,5,1,32,1,128,161,165,161,2048,1,160,0,1,134,164,6,160,0,1,33,164,134,37,165,131,165,0,2081,161,165,160,164,0,164]

theorem envBound43488 : H12AffineFastState.Bounded env43488 := by
  intro p hp
  have h : env43488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43487_43488 : H12AffineEnvironment.transform 7 161 env43487 = env43488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 161 env43487 == env43488) = true)

theorem identity43488 : scanCanonicalize (H12AffineFastState.compose env43488 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 164) := by decide +kernel

theorem selectedBound43488 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43489 : List Nat := [2,4,5,1,32,1,128,161,165,161,164,1,160,0,1,134,164,6,160,0,1,33,164,134,37,165,131,165,0,133,161,165,160,164,0,164]

theorem envBound43489 : H12AffineFastState.Bounded env43489 := by
  intro p hp
  have h : env43489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43488_43489 : H12AffineEnvironment.transform 10 164 env43488 = env43489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 164 env43488 == env43489) = true)

def env43490 : List Nat := [2,4,8,13,32,0,128,256,265,268,2048,13,8192,0,8449,65536,74019,65664,268,8448,13,384,74018,65536,8329,74031,303,74031,0,75787,8204,8200,257,74018,13,265]

theorem envBound43490 : H12AffineFastState.Bounded env43490 := by
  intro p hp
  have h : env43490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43483_43490 : H12AffineEnvironment.transform 3 13 env43483 = env43490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env43483 == env43490) = true)

theorem identity43490 : scanCanonicalize (H12AffineFastState.compose env43490 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound43490 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env43491 : List Nat := [2,4,8,13,32,0,128,5,12,9,2048,13,8192,0,8196,65536,73766,65664,9,8197,13,133,73767,65536,8329,73770,42,73770,0,75787,8204,8200,4,73767,13,12]

theorem envBound43491 : H12AffineFastState.Bounded env43491 := by
  intro p hp
  have h : env43491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43490_43491 : H12AffineEnvironment.transform 7 5 env43490 = env43491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env43490 == env43491) = true)

theorem identity43491 : scanCanonicalize (H12AffineFastState.compose env43491 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound43491 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env43492 : List Nat := [2,4,5,0,32,0,128,5,1,4,2048,0,8192,0,8196,65536,73766,65664,4,8197,0,133,73767,65536,8324,73767,39,73767,0,75782,8193,8197,4,73767,0,1]

theorem envBound43492 : H12AffineFastState.Bounded env43492 := by
  intro p hp
  have h : env43492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43491_43492 : H12AffineEnvironment.transform 2 5 env43491 = env43492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env43491 == env43492) = true)

theorem identity43492 : scanCanonicalize (H12AffineFastState.compose env43492 (packedSelected [0,3,7,8,11] rootPS)) = affineNative (2^(12+1) ^^^ 2209) := by decide +kernel

theorem selectedBound43492 : packedSelected [0,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env43493 : List Nat := [2,4,5,0,32,0,128,5,1,4,2048,0,2209,0,2213,65536,67719,65664,4,2212,0,133,67718,65536,2085,67718,39,67718,0,65703,2208,2212,4,67718,0,1]

theorem envBound43493 : H12AffineFastState.Bounded env43493 := by
  intro p hp
  have h : env43493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43492_43493 : H12AffineEnvironment.transform 12 2209 env43492 = env43493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2209 env43492 == env43493) = true)

theorem identity43493 : scanCanonicalize (H12AffineFastState.compose env43493 (packedSelected [0,2,3,5,7,8,9] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound43493 : packedSelected [0,2,3,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env43494 : List Nat := [2,4,5,0,32,0,128,5,1,4,2048,0,2209,0,2213,35,2212,163,4,2212,0,133,2213,35,2085,2213,39,2213,0,132,2208,2212,4,2213,0,1]

theorem envBound43494 : H12AffineFastState.Bounded env43494 := by
  intro p hp
  have h : env43494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43493_43494 : H12AffineEnvironment.transform 15 35 env43493 = env43494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env43493 == env43494) = true)

theorem identity43494 : scanCanonicalize (H12AffineFastState.compose env43494 (packedSelected [1,2] rootPS)) = affineNative (2^(10+1) ^^^ 39) := by decide +kernel

theorem selectedBound43494 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env43495 : List Nat := [2,4,5,0,32,0,128,5,1,4,39,0,134,0,130,35,131,163,4,131,0,133,130,35,2,130,39,130,0,132,135,131,4,130,0,1]

theorem envBound43495 : H12AffineFastState.Bounded env43495 := by
  intro p hp
  have h : env43495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43494_43495 : H12AffineEnvironment.transform 10 39 env43494 = env43495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 39 env43494 == env43495) = true)

theorem identity43495 : scanCanonicalize (H12AffineFastState.compose env43495 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound43495 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43496 : List Nat := [2,4,5,0,32,0,3,5,1,4,39,0,5,0,1,35,0,32,4,0,0,6,1,35,2,1,39,1,0,7,4,0,4,1,0,1]

theorem envBound43496 : H12AffineFastState.Bounded env43496 := by
  intro p hp
  have h : env43496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43495_43496 : H12AffineEnvironment.transform 6 3 env43495 = env43496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env43495 == env43496) = true)

theorem identity43496 : scanCanonicalize (H12AffineFastState.compose env43496 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound43496 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43497 : List Nat := [2,2,3,0,32,0,3,3,1,2,33,0,3,0,1,35,0,32,2,0,0,0,1,35,2,1,33,1,0,1,2,0,2,1,0,1]

theorem envBound43497 : H12AffineFastState.Bounded env43497 := by
  intro p hp
  have h : env43497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43496_43497 : H12AffineEnvironment.transform 1 2 env43496 = env43497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env43496 == env43497) = true)

theorem identity43497 : scanCanonicalize (H12AffineFastState.compose env43497 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound43497 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43498 : List Nat := [2,2,3,0,0,0,3,3,1,2,1,0,3,0,1,3,0,0,2,0,0,0,1,3,2,1,1,1,0,1,2,0,2,1,0,1]

theorem envBound43498 : H12AffineFastState.Bounded env43498 := by
  intro p hp
  have h : env43498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43497_43498 : H12AffineEnvironment.transform 4 0 env43497 = env43498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env43497 == env43498) = true)

def env43499 : List Nat := [2,4,8,16,32,64,128,256,340,273,2048,17,8192,0,8477,65536,74110,65664,336,8476,17,477,74047,65537,8392,74030,302,74031,0,75850,8204,8200,257,74047,80,277]

theorem envBound43499 : H12AffineFastState.Bounded env43499 := by
  intro p hp
  have h : env43499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43481_43499 : H12AffineEnvironment.transform 11 17 env43481 = env43499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env43481 == env43499) = true)

theorem identity43499 : scanCanonicalize (H12AffineFastState.compose env43499 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 69) := by decide +kernel

theorem selectedBound43499 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env43500 : List Nat := [2,4,8,16,32,64,128,256,340,273,2048,17,69,0,344,65536,65851,65664,336,345,17,477,65914,65537,141,65899,302,65898,0,67599,73,77,257,65914,80,277]

theorem envBound43500 : H12AffineFastState.Bounded env43500 := by
  intro p hp
  have h : env43500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43499_43500 : H12AffineEnvironment.transform 12 69 env43499 = env43500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 69 env43499 == env43500) = true)

def env43501 : List Nat := [2,4,8,16,32,0,128,256,276,273,2048,17,5,0,280,65536,65851,65664,272,281,17,413,65850,65537,141,65835,302,65834,0,67599,9,13,257,65850,16,277]

theorem envBound43501 : H12AffineFastState.Bounded env43501 := by
  intro p hp
  have h : env43501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43500_43501 : H12AffineEnvironment.transform 5 0 env43500 = env43501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env43500 == env43501) = true)

theorem identity43501 : scanCanonicalize (H12AffineFastState.compose env43501 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 63) := by decide +kernel

theorem selectedBound43501 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env43502 : List Nat := [2,4,8,16,32,0,128,256,276,273,2048,17,5,0,280,63,260,191,272,281,17,413,261,62,141,276,302,277,0,2096,9,13,257,261,16,277]

theorem envBound43502 : H12AffineFastState.Bounded env43502 := by
  intro p hp
  have h : env43502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43501_43502 : H12AffineEnvironment.transform 15 63 env43501 = env43502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 63 env43501 == env43502) = true)

theorem identity43502 : scanCanonicalize (H12AffineFastState.compose env43502 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 25) := by decide +kernel

theorem selectedBound43502 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env43503 : List Nat := [2,4,8,16,32,0,128,25,13,8,2048,17,5,0,1,63,29,191,9,0,17,132,28,62,141,13,55,12,0,2096,9,13,24,28,16,12]

theorem envBound43503 : H12AffineFastState.Bounded env43503 := by
  intro p hp
  have h : env43503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43502_43503 : H12AffineEnvironment.transform 7 25 env43502 = env43503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 25 env43502 == env43503) = true)

theorem identity43503 : scanCanonicalize (H12AffineFastState.compose env43503 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound43503 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env43504 : List Nat := [2,4,8,1,32,0,128,8,13,8,2048,0,5,0,1,46,12,174,9,0,0,132,13,47,141,13,38,12,0,2081,9,13,9,13,1,12]

theorem envBound43504 : H12AffineFastState.Bounded env43504 := by
  intro p hp
  have h : env43504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43503_43504 : H12AffineEnvironment.transform 3 1 env43503 = env43504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env43503 == env43504) = true)

theorem identity43504 : scanCanonicalize (H12AffineFastState.compose env43504 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound43504 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43505 : List Nat := [2,4,8,1,12,0,128,8,13,8,2048,0,5,0,1,2,12,130,9,0,0,132,13,3,141,13,10,12,0,2061,9,13,9,13,1,12]

theorem envBound43505 : H12AffineFastState.Bounded env43505 := by
  intro p hp
  have h : env43505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43504_43505 : H12AffineEnvironment.transform 4 12 env43504 = env43505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env43504 == env43505) = true)

theorem identity43505 : scanCanonicalize (H12AffineFastState.compose env43505 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 12) := by decide +kernel

theorem selectedBound43505 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env43506 : List Nat := [2,4,8,1,12,0,12,8,13,8,2048,0,5,0,1,2,12,14,9,0,0,8,13,3,1,13,10,12,0,2061,9,13,9,13,1,12]

theorem envBound43506 : H12AffineFastState.Bounded env43506 := by
  intro p hp
  have h : env43506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43505_43506 : H12AffineEnvironment.transform 6 12 env43505 = env43506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 12 env43505 == env43506) = true)

theorem identity43506 : scanCanonicalize (H12AffineFastState.compose env43506 (packedSelected [0,3] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound43506 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env43507 : List Nat := [0,4,8,1,12,0,12,8,13,8,2048,0,5,0,1,0,12,12,9,0,0,8,13,1,1,13,8,12,0,2061,9,13,9,13,1,12]

theorem envBound43507 : H12AffineFastState.Bounded env43507 := by
  intro p hp
  have h : env43507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43506_43507 : H12AffineEnvironment.transform 0 0 env43506 = env43507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env43506 == env43507) = true)

theorem identity43507 : scanCanonicalize (H12AffineFastState.compose env43507 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 13) := by decide +kernel

theorem selectedBound43507 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env43508 : List Nat := [0,4,8,1,12,0,12,8,13,8,13,0,5,0,1,0,12,12,9,0,0,8,13,1,1,13,8,12,0,0,9,13,9,13,1,12]

theorem envBound43508 : H12AffineFastState.Bounded env43508 := by
  intro p hp
  have h : env43508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43507_43508 : H12AffineEnvironment.transform 10 13 env43507 = env43508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 13 env43507 == env43508) = true)

theorem identity43508 : scanCanonicalize (H12AffineFastState.compose env43508 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound43508 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43509 : List Nat := [0,4,4,1,0,0,0,4,1,4,1,0,5,0,1,0,0,0,5,0,0,4,1,1,1,1,4,0,0,0,5,1,5,1,1,0]

theorem envBound43509 : H12AffineFastState.Bounded env43509 := by
  intro p hp
  have h : env43509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43508_43509 : H12AffineEnvironment.transform 2 4 env43508 = env43509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env43508 == env43509) = true)

def env43510 : List Nat := [2,4,8,16,32,1,128,256,277,273,2048,17,4,0,281,65536,65851,65664,273,280,17,412,65851,65537,141,65834,302,65835,0,67599,8,12,257,65851,17,277]

theorem envBound43510 : H12AffineFastState.Bounded env43510 := by
  intro p hp
  have h : env43510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43500_43510 : H12AffineEnvironment.transform 5 1 env43500 = env43510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env43500 == env43510) = true)

theorem identity43510 : scanCanonicalize (H12AffineFastState.compose env43510 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound43510 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env43511 : List Nat := [2,4,8,16,32,1,128,4,17,21,2048,17,4,0,29,65536,65599,65664,21,28,17,152,65599,65537,141,65582,42,65583,0,67599,8,12,5,65599,17,17]

theorem envBound43511 : H12AffineFastState.Bounded env43511 := by
  intro p hp
  have h : env43511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43510_43511 : H12AffineEnvironment.transform 7 4 env43510 = env43511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env43510 == env43511) = true)

theorem identity43511 : scanCanonicalize (H12AffineFastState.compose env43511 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound43511 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env43512 : List Nat := [2,4,8,1,32,1,128,4,0,4,2048,0,4,0,12,65536,65582,65664,4,13,0,137,65582,65537,141,65582,42,65583,0,67599,8,12,5,65582,0,0]

theorem envBound43512 : H12AffineFastState.Bounded env43512 := by
  intro p hp
  have h : env43512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43511_43512 : H12AffineEnvironment.transform 3 1 env43511 = env43512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env43511 == env43512) = true)

theorem identity43512 : scanCanonicalize (H12AffineFastState.compose env43512 (packedSelected [0,3,7,8,11] rootPS)) = affineNative (2^(15+1) ^^^ 2187) := by decide +kernel

theorem selectedBound43512 : packedSelected [0,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env43513 : List Nat := [2,4,8,1,32,1,128,4,0,4,2048,0,4,0,12,2187,2213,2059,4,13,0,137,2213,2186,141,2213,42,2212,0,132,8,12,5,2213,0,0]

theorem envBound43513 : H12AffineFastState.Bounded env43513 := by
  intro p hp
  have h : env43513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43512_43513 : H12AffineEnvironment.transform 15 2187 env43512 = env43513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2187 env43512 == env43513) = true)

theorem identity43513 : scanCanonicalize (H12AffineFastState.compose env43513 (packedSelected [2,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound43513 : packedSelected [2,5,10] rootPS < 2^1333 := by decide +kernel

def env43514 : List Nat := [2,4,8,1,32,1,128,4,0,4,33,0,4,0,12,170,132,42,4,13,0,137,132,171,141,132,42,133,0,132,8,12,5,132,0,0]

theorem envBound43514 : H12AffineFastState.Bounded env43514 := by
  intro p hp
  have h : env43514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43513_43514 : H12AffineEnvironment.transform 10 33 env43513 = env43514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env43513 == env43514) = true)

theorem identity43514 : scanCanonicalize (H12AffineFastState.compose env43514 (packedSelected [0,2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound43514 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env43515 : List Nat := [2,4,8,1,32,1,8,4,0,4,33,0,4,0,12,34,12,42,4,13,0,1,12,35,5,12,42,13,0,12,8,12,5,12,0,0]

theorem envBound43515 : H12AffineFastState.Bounded env43515 := by
  intro p hp
  have h : env43515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43514_43515 : H12AffineEnvironment.transform 6 8 env43514 = env43515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43514 == env43515) = true)

theorem identity43515 : scanCanonicalize (H12AffineFastState.compose env43515 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound43515 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env43516 : List Nat := [2,4,8,1,6,1,8,4,0,4,7,0,4,0,12,4,12,12,4,13,0,1,12,5,5,12,12,13,0,12,8,12,5,12,0,0]

theorem envBound43516 : H12AffineFastState.Bounded env43516 := by
  intro p hp
  have h : env43516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43515_43516 : H12AffineEnvironment.transform 4 6 env43515 = env43516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env43515 == env43516) = true)

def env43517 : List Nat := [2,4,8,16,32,64,128,256,341,273,2048,4096,8192,0,12556,65536,74110,65664,4417,12557,4096,477,74047,69648,12505,78143,4415,74031,0,79963,8204,8200,257,74047,80,4357]

theorem envBound43517 : H12AffineFastState.Bounded env43517 := by
  intro p hp
  have h : env43517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43480_43517 : H12AffineEnvironment.transform 8 341 env43480 = env43517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env43480 == env43517) = true)

def env43518 : List Nat := [2,4,8,16,32,64,128,256,341,273,2048,16,8192,0,8476,65536,74110,65664,337,8477,16,477,74047,65536,8393,74031,303,74031,0,75851,8204,8200,257,74047,80,277]

theorem envBound43518 : H12AffineFastState.Bounded env43518 := by
  intro p hp
  have h : env43518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43517_43518 : H12AffineEnvironment.transform 11 16 env43517 = env43518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env43517 == env43518) = true)

theorem identity43518 : scanCanonicalize (H12AffineFastState.compose env43518 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8563) := by decide +kernel

theorem selectedBound43518 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env43519 : List Nat := [2,4,8,16,32,64,128,256,341,273,2048,16,8192,0,8476,8563,13,8691,337,8477,16,477,76,8563,8393,92,303,92,0,2360,8204,8200,257,76,80,277]

theorem envBound43519 : H12AffineFastState.Bounded env43519 := by
  intro p hp
  have h : env43519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43518_43519 : H12AffineEnvironment.transform 15 8563 env43518 = env43519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8563 env43518 == env43519) = true)

def env43520 : List Nat := [2,4,8,16,32,0,128,256,277,273,2048,16,8192,0,8476,8499,13,8627,273,8477,16,413,12,8499,8329,28,303,28,0,2360,8204,8200,257,12,16,277]

theorem envBound43520 : H12AffineFastState.Bounded env43520 := by
  intro p hp
  have h : env43520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43519_43520 : H12AffineEnvironment.transform 5 0 env43519 = env43520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env43519 == env43520) = true)

theorem identity43520 : scanCanonicalize (H12AffineFastState.compose env43520 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound43520 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env43521 : List Nat := [2,4,8,16,32,0,128,5,16,20,2048,16,8192,0,8217,8246,13,8374,20,8216,16,152,12,8246,8329,28,42,28,0,2109,8204,8200,4,12,16,16]

theorem envBound43521 : H12AffineFastState.Bounded env43521 := by
  intro p hp
  have h : env43521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43520_43521 : H12AffineEnvironment.transform 7 5 env43520 = env43521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env43520 == env43521) = true)

theorem identity43521 : scanCanonicalize (H12AffineFastState.compose env43521 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound43521 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env43522 : List Nat := [2,4,8,0,32,0,128,5,0,4,2048,0,8192,0,8201,8230,13,8358,4,8200,0,136,12,8230,8329,12,42,12,0,2093,8204,8200,4,12,0,0]

theorem envBound43522 : H12AffineFastState.Bounded env43522 := by
  intro p hp
  have h : env43522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43521_43522 : H12AffineEnvironment.transform 3 0 env43521 = env43522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env43521 == env43522) = true)

theorem identity43522 : scanCanonicalize (H12AffineFastState.compose env43522 (packedSelected [0,3,7,8,11] rootPS)) = affineNative (2^(12+1) ^^^ 2220) := by decide +kernel

theorem selectedBound43522 : packedSelected [0,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env43523 : List Nat := [2,4,8,0,32,0,128,5,0,4,2048,0,2220,0,2213,2186,13,2058,4,2212,0,136,12,2186,2085,12,42,12,0,2093,2208,2212,4,12,0,0]

theorem envBound43523 : H12AffineFastState.Bounded env43523 := by
  intro p hp
  have h : env43523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43522_43523 : H12AffineEnvironment.transform 12 2220 env43522 = env43523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2220 env43522 == env43523) = true)

theorem identity43523 : scanCanonicalize (H12AffineFastState.compose env43523 (packedSelected [2,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound43523 : packedSelected [2,5,10] rootPS < 2^1333 := by decide +kernel

def env43524 : List Nat := [2,4,8,0,32,0,128,5,0,4,32,0,140,0,133,170,13,42,4,132,0,136,12,170,5,12,42,12,0,13,128,132,4,12,0,0]

theorem envBound43524 : H12AffineFastState.Bounded env43524 := by
  intro p hp
  have h : env43524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43523_43524 : H12AffineEnvironment.transform 10 32 env43523 = env43524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env43523 == env43524) = true)

theorem identity43524 : scanCanonicalize (H12AffineFastState.compose env43524 (packedSelected [0,2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound43524 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env43525 : List Nat := [2,4,8,0,32,0,8,5,0,4,32,0,4,0,13,34,13,42,4,12,0,0,12,34,5,12,42,12,0,13,8,12,4,12,0,0]

theorem envBound43525 : H12AffineFastState.Bounded env43525 := by
  intro p hp
  have h : env43525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43524_43525 : H12AffineEnvironment.transform 6 8 env43524 = env43525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43524 == env43525) = true)

theorem identity43525 : scanCanonicalize (H12AffineFastState.compose env43525 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound43525 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env43526 : List Nat := [2,4,8,0,7,0,8,5,0,4,7,0,4,0,13,5,13,13,4,12,0,0,12,5,5,12,13,12,0,13,8,12,4,12,0,0]

theorem envBound43526 : H12AffineFastState.Bounded env43526 := by
  intro p hp
  have h : env43526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43525_43526 : H12AffineEnvironment.transform 4 7 env43525 = env43526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env43525 == env43526) = true)

def env43527 : List Nat := [2,4,8,16,32,1,128,256,276,273,2048,16,8192,0,8476,8498,13,8626,272,8477,16,412,13,8498,8328,29,303,29,0,2360,8204,8200,257,13,17,277]

theorem envBound43527 : H12AffineFastState.Bounded env43527 := by
  intro p hp
  have h : env43527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43519_43527 : H12AffineEnvironment.transform 5 1 env43519 = env43527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env43519 == env43527) = true)

theorem identity43527 : scanCanonicalize (H12AffineFastState.compose env43527 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 8) := by decide +kernel

theorem selectedBound43527 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env43528 : List Nat := [2,4,8,16,32,1,128,8,28,25,2048,16,8192,0,8212,8250,13,8378,24,8213,16,148,13,8250,8328,29,39,29,0,2096,8204,8200,9,13,17,29]

theorem envBound43528 : H12AffineFastState.Bounded env43528 := by
  intro p hp
  have h : env43528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43527_43528 : H12AffineEnvironment.transform 7 8 env43527 = env43528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 8 env43527 == env43528) = true)

theorem identity43528 : scanCanonicalize (H12AffineFastState.compose env43528 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 21) := by decide +kernel

theorem selectedBound43528 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env43529 : List Nat := [2,4,8,16,32,1,128,8,28,25,2048,16,21,0,1,47,13,175,24,0,16,148,13,47,157,29,39,29,0,2096,25,29,9,13,17,29]

theorem envBound43529 : H12AffineFastState.Bounded env43529 := by
  intro p hp
  have h : env43529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43528_43529 : H12AffineEnvironment.transform 12 21 env43528 = env43529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 21 env43528 == env43529) = true)

theorem identity43529 : scanCanonicalize (H12AffineFastState.compose env43529 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound43529 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env43530 : List Nat := [2,4,8,1,32,1,128,8,13,8,2048,1,4,0,1,47,13,175,9,0,1,133,13,47,140,12,39,12,0,2081,8,12,9,13,0,12]

theorem envBound43530 : H12AffineFastState.Bounded env43530 := by
  intro p hp
  have h : env43530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43529_43530 : H12AffineEnvironment.transform 3 1 env43529 = env43530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env43529 == env43530) = true)

theorem identity43530 : scanCanonicalize (H12AffineFastState.compose env43530 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 37) := by decide +kernel

theorem selectedBound43530 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43531 : List Nat := [2,4,8,1,32,1,37,8,13,8,2048,1,4,0,1,47,13,10,9,0,1,32,13,47,41,12,39,12,0,2081,8,12,9,13,0,12]

theorem envBound43531 : H12AffineFastState.Bounded env43531 := by
  intro p hp
  have h : env43531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43530_43531 : H12AffineEnvironment.transform 6 37 env43530 = env43531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 37 env43530 == env43531) = true)

theorem identity43531 : scanCanonicalize (H12AffineFastState.compose env43531 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound43531 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43532 : List Nat := [2,4,8,1,32,1,37,8,13,8,1,1,4,0,1,47,13,10,9,0,1,32,13,47,41,12,39,12,0,32,8,12,9,13,0,12]

theorem envBound43532 : H12AffineFastState.Bounded env43532 := by
  intro p hp
  have h : env43532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43531_43532 : H12AffineEnvironment.transform 10 1 env43531 = env43532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env43531 == env43532) = true)

theorem identity43532 : scanCanonicalize (H12AffineFastState.compose env43532 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound43532 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43533 : List Nat := [2,0,8,1,32,1,33,8,9,8,1,1,0,0,1,43,9,10,9,0,1,32,9,43,41,8,35,8,0,32,8,8,9,9,0,8]

theorem envBound43533 : H12AffineFastState.Bounded env43533 := by
  intro p hp
  have h : env43533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43532_43533 : H12AffineEnvironment.transform 1 0 env43532 = env43533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env43532 == env43533) = true)

def env43534 : List Nat := [2,4,8,16,32,64,128,256,341,273,2048,17,8192,0,8477,65536,74110,65664,336,8476,17,477,74047,65537,8392,74030,302,74031,0,75850,8204,8200,257,74047,80,276]

theorem envBound43534 : H12AffineFastState.Bounded env43534 := by
  intro p hp
  have h : env43534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43517_43534 : H12AffineEnvironment.transform 11 17 env43517 = env43534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env43517 == env43534) = true)

theorem identity43534 : scanCanonicalize (H12AffineFastState.compose env43534 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 363) := by decide +kernel

theorem selectedBound43534 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env43535 : List Nat := [2,4,8,16,32,64,128,256,341,273,2048,17,8192,0,8477,363,8213,491,336,8476,17,477,8276,362,8392,8261,302,8260,0,10529,8204,8200,257,8276,80,276]

theorem envBound43535 : H12AffineFastState.Bounded env43535 := by
  intro p hp
  have h : env43535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43534_43535 : H12AffineEnvironment.transform 15 363 env43534 = env43535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 363 env43534 == env43535) = true)

def env43536 : List Nat := [2,4,8,16,32,0,128,256,277,273,2048,17,8192,0,8477,299,8213,427,272,8476,17,413,8212,298,8328,8197,302,8196,0,10529,8204,8200,257,8212,16,276]

theorem envBound43536 : H12AffineFastState.Bounded env43536 := by
  intro p hp
  have h : env43536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43535_43536 : H12AffineEnvironment.transform 5 0 env43535 = env43536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env43535 == env43536) = true)

theorem identity43536 : scanCanonicalize (H12AffineFastState.compose env43536 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 273) := by decide +kernel

theorem selectedBound43536 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env43537 : List Nat := [2,4,8,16,32,0,128,256,277,273,2048,17,273,0,12,299,260,427,272,13,17,413,261,298,409,276,302,277,0,2096,285,281,257,261,16,276]

theorem envBound43537 : H12AffineFastState.Bounded env43537 := by
  intro p hp
  have h : env43537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43536_43537 : H12AffineEnvironment.transform 12 273 env43536 = env43537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 273 env43536 == env43537) = true)

theorem identity43537 : scanCanonicalize (H12AffineFastState.compose env43537 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound43537 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env43538 : List Nat := [2,4,5,16,32,0,128,256,277,273,2048,17,273,0,1,294,260,422,272,0,17,400,261,295,404,276,291,277,0,2096,272,276,257,261,16,276]

theorem envBound43538 : H12AffineFastState.Bounded env43538 := by
  intro p hp
  have h : env43538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43537_43538 : H12AffineEnvironment.transform 2 5 env43537 = env43538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env43537 == env43538) = true)

theorem identity43538 : scanCanonicalize (H12AffineFastState.compose env43538 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound43538 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env43539 : List Nat := [2,4,5,1,32,0,128,256,260,256,2048,0,256,0,1,294,260,422,257,0,0,385,261,295,389,261,291,260,0,2081,257,261,257,261,1,261]

theorem envBound43539 : H12AffineFastState.Bounded env43539 := by
  intro p hp
  have h : env43539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43538_43539 : H12AffineEnvironment.transform 3 1 env43538 = env43539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env43538 == env43539) = true)

theorem identity43539 : scanCanonicalize (H12AffineFastState.compose env43539 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound43539 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43540 : List Nat := [2,4,5,1,32,0,128,37,33,37,2048,0,37,0,1,3,33,131,36,0,0,164,32,2,160,32,6,33,0,2081,36,32,36,32,1,32]

theorem envBound43540 : H12AffineFastState.Bounded env43540 := by
  intro p hp
  have h : env43540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43539_43540 : H12AffineEnvironment.transform 7 37 env43539 = env43540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env43539 == env43540) = true)

theorem identity43540 : scanCanonicalize (H12AffineFastState.compose env43540 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 129) := by decide +kernel

theorem selectedBound43540 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env43541 : List Nat := [2,4,5,1,32,0,128,37,33,37,129,0,37,0,1,3,33,131,36,0,0,164,32,2,160,32,6,33,0,160,36,32,36,32,1,32]

theorem envBound43541 : H12AffineFastState.Bounded env43541 := by
  intro p hp
  have h : env43541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43540_43541 : H12AffineEnvironment.transform 10 129 env43540 = env43541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 129 env43540 == env43541) = true)

theorem identity43541 : scanCanonicalize (H12AffineFastState.compose env43541 (packedSelected [0,3] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound43541 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env43542 : List Nat := [2,4,5,1,32,0,3,37,33,37,2,0,37,0,1,3,33,0,36,0,0,39,32,2,35,32,6,33,0,35,36,32,36,32,1,32]

theorem envBound43542 : H12AffineFastState.Bounded env43542 := by
  intro p hp
  have h : env43542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43541_43542 : H12AffineEnvironment.transform 6 3 env43541 = env43542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env43541 == env43542) = true)

theorem identity43542 : scanCanonicalize (H12AffineFastState.compose env43542 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound43542 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env43543 : List Nat := [2,2,3,1,32,0,3,35,33,35,2,0,35,0,1,3,33,0,34,0,0,33,32,2,35,32,0,33,0,35,34,32,34,32,1,32]

theorem envBound43543 : H12AffineFastState.Bounded env43543 := by
  intro p hp
  have h : env43543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43542_43543 : H12AffineEnvironment.transform 1 2 env43542 = env43543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env43542 == env43543) = true)

theorem identity43543 : scanCanonicalize (H12AffineFastState.compose env43543 (packedSelected [0,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound43543 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env43544 : List Nat := [2,2,3,1,1,0,3,2,0,2,2,0,2,0,1,3,0,0,3,0,0,0,1,2,2,1,0,0,0,2,3,1,3,1,1,1]

theorem envBound43544 : H12AffineFastState.Bounded env43544 := by
  intro p hp
  have h : env43544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43543_43544 : H12AffineEnvironment.transform 4 1 env43543 = env43544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env43543 == env43544) = true)

theorem identity43544 : scanCanonicalize (H12AffineFastState.compose env43544 (packedSelected [7] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound43544 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env43545 : List Nat := [1,1,0,1,1,0,0,1,0,1,1,0,1,0,1,0,0,0,0,0,0,0,1,1,1,1,0,0,0,1,0,1,0,1,1,1]

theorem envBound43545 : H12AffineFastState.Bounded env43545 := by
  intro p hp
  have h : env43545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43544_43545 : H12AffineEnvironment.transform 0 1 env43544 = env43545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env43544 == env43545) = true)

def env43546 : List Nat := [2,4,8,16,32,1,128,256,276,273,2048,17,8192,0,8477,298,8213,426,273,8476,17,412,8213,299,8329,8196,302,8197,0,10529,8204,8200,257,8213,17,276]

theorem envBound43546 : H12AffineFastState.Bounded env43546 := by
  intro p hp
  have h : env43546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43535_43546 : H12AffineEnvironment.transform 5 1 env43535 = env43546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env43535 == env43546) = true)

theorem identity43546 : scanCanonicalize (H12AffineFastState.compose env43546 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound43546 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env43547 : List Nat := [2,4,8,16,32,1,128,4,16,21,2048,17,8192,0,8217,46,8213,174,21,8216,17,152,8213,47,8329,8196,42,8197,0,10277,8204,8200,5,8213,17,16]

theorem envBound43547 : H12AffineFastState.Bounded env43547 := by
  intro p hp
  have h : env43547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43546_43547 : H12AffineEnvironment.transform 7 4 env43546 = env43547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env43546 == env43547) = true)

theorem identity43547 : scanCanonicalize (H12AffineFastState.compose env43547 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound43547 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env43548 : List Nat := [2,4,8,1,32,1,128,4,1,4,2048,0,8192,0,8200,46,8196,174,4,8201,0,137,8196,47,8329,8196,42,8197,0,10277,8204,8200,5,8196,0,1]

theorem envBound43548 : H12AffineFastState.Bounded env43548 := by
  intro p hp
  have h : env43548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43547_43548 : H12AffineEnvironment.transform 3 1 env43547 = env43548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env43547 == env43548) = true)

theorem identity43548 : scanCanonicalize (H12AffineFastState.compose env43548 (packedSelected [0,3,7,8,11] rootPS)) = affineNative (2^(12+1) ^^^ 2209) := by decide +kernel

theorem selectedBound43548 : packedSelected [0,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env43549 : List Nat := [2,4,8,1,32,1,128,4,1,4,2048,0,2209,0,2217,46,2213,174,4,2216,0,137,2213,47,2088,2213,42,2212,0,132,2221,2217,5,2213,0,1]

theorem envBound43549 : H12AffineFastState.Bounded env43549 := by
  intro p hp
  have h : env43549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43548_43549 : H12AffineEnvironment.transform 12 2209 env43548 = env43549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2209 env43548 == env43549) = true)

theorem identity43549 : scanCanonicalize (H12AffineFastState.compose env43549 (packedSelected [0,2,3,5,7,8,9] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound43549 : packedSelected [0,2,3,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env43550 : List Nat := [2,4,5,1,32,1,128,4,1,4,2048,0,2209,0,2212,35,2213,163,4,2213,0,132,2213,34,2085,2213,39,2212,0,132,2208,2212,5,2213,0,1]

theorem envBound43550 : H12AffineFastState.Bounded env43550 := by
  intro p hp
  have h : env43550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43549_43550 : H12AffineEnvironment.transform 2 5 env43549 = env43550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env43549 == env43550) = true)

theorem identity43550 : scanCanonicalize (H12AffineFastState.compose env43550 (packedSelected [1,2] rootPS)) = affineNative (2^(10+1) ^^^ 39) := by decide +kernel

theorem selectedBound43550 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env43551 : List Nat := [2,4,5,1,32,1,128,4,1,4,39,0,134,0,131,35,130,163,4,130,0,132,130,34,2,130,39,131,0,132,135,131,5,130,0,1]

theorem envBound43551 : H12AffineFastState.Bounded env43551 := by
  intro p hp
  have h : env43551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43550_43551 : H12AffineEnvironment.transform 10 39 env43550 = env43551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 39 env43550 == env43551) = true)

theorem identity43551 : scanCanonicalize (H12AffineFastState.compose env43551 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound43551 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43552 : List Nat := [2,4,5,1,32,1,2,4,1,4,39,0,4,0,1,35,0,33,4,0,0,6,0,34,2,0,39,1,0,6,5,1,5,0,0,1]

theorem envBound43552 : H12AffineFastState.Bounded env43552 := by
  intro p hp
  have h : env43552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43551_43552 : H12AffineEnvironment.transform 6 2 env43551 = env43552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env43551 == env43552) = true)

theorem identity43552 : scanCanonicalize (H12AffineFastState.compose env43552 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound43552 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43553 : List Nat := [2,3,2,1,32,1,2,3,1,3,32,0,3,0,1,35,0,33,3,0,0,1,0,34,2,0,32,1,0,1,2,1,2,0,0,1]

theorem envBound43553 : H12AffineFastState.Bounded env43553 := by
  intro p hp
  have h : env43553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43552_43553 : H12AffineEnvironment.transform 1 3 env43552 = env43553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env43552 == env43553) = true)

theorem identity43553 : scanCanonicalize (H12AffineFastState.compose env43553 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound43553 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43554 : List Nat := [2,3,2,1,1,1,2,3,1,3,1,0,3,0,1,2,0,0,3,0,0,1,0,3,2,0,1,1,0,1,2,1,2,0,0,1]

theorem envBound43554 : H12AffineFastState.Bounded env43554 := by
  intro p hp
  have h : env43554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43553_43554 : H12AffineEnvironment.transform 4 1 env43553 = env43554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env43553 == env43554) = true)

def env43555 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74863,65665,4417,13340,4096,477,74047,69648,13768,78894,4414,74814,1297,81226,8204,8200,257,74798,1345,5953]

theorem envBound43555 : H12AffineFastState.Bounded env43555 := by
  intro p hp
  have h : env43555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43478_43555 : H12AffineEnvironment.transform 17 65665 env43478 = env43555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env43478 == env43555) = true)

theorem identity43555 : scanCanonicalize (H12AffineFastState.compose env43555 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound43555 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env43556 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1297,9292,65536,74863,65665,272,9293,81,477,74047,65601,9625,74879,367,74814,1297,77083,8204,8200,257,74798,1345,1808]

theorem envBound43556 : H12AffineFastState.Bounded env43556 := by
  intro p hp
  have h : env43556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43555_43556 : H12AffineEnvironment.transform 11 81 env43555 = env43556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env43555 == env43556) = true)

def env43557 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,81,8192,81,8460,65536,74031,65665,272,8461,81,477,74047,65601,8409,74047,367,74110,81,75867,8204,8200,257,74094,1,592]

theorem envBound43557 : H12AffineFastState.Bounded env43557 := by
  intro p hp
  have h : env43557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43556_43557 : H12AffineEnvironment.transform 9 320 env43556 = env43557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env43556 == env43557) = true)

theorem identity43557 : scanCanonicalize (H12AffineFastState.compose env43557 (packedSelected [7,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound43557 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env43558 : List Nat := [2,4,8,16,32,64,128,68,512,4,2048,81,8192,81,8264,65536,73835,65665,84,8265,81,153,73851,65601,8409,73851,43,73786,81,75867,8204,8200,69,73770,1,592]

theorem envBound43558 : H12AffineFastState.Bounded env43558 := by
  intro p hp
  have h : env43558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43557_43558 : H12AffineEnvironment.transform 7 68 env43557 = env43558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env43557 == env43558) = true)

theorem identity43558 : scanCanonicalize (H12AffineFastState.compose env43558 (packedSelected [2,13,21,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 8883) := by decide +kernel

theorem selectedBound43558 : packedSelected [2,13,21,23,32] rootPS < 2^1333 := by decide +kernel

def env43559 : List Nat := [2,4,8,16,32,64,128,68,512,4,2048,81,8192,81,8264,8883,728,8754,84,8265,81,153,712,8946,8409,712,43,649,81,2792,8204,8200,69,665,1,592]

theorem envBound43559 : H12AffineFastState.Bounded env43559 := by
  intro p hp
  have h : env43559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43558_43559 : H12AffineEnvironment.transform 15 8883 env43558 = env43559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8883 env43558 == env43559) = true)

theorem identity43559 : scanCanonicalize (H12AffineFastState.compose env43559 (packedSelected [0,1,4,7,8,9,13,18,19,23,24,28] rootPS)) = affineNative (2^(10+1) ^^^ 675) := by decide +kernel

theorem selectedBound43559 : packedSelected [0,1,4,7,8,9,13,18,19,23,24,28] rootPS < 2^1333 := by decide +kernel

def env43560 : List Nat := [2,4,8,16,32,64,128,68,512,4,675,81,8192,81,8264,8883,728,8754,84,8265,81,153,712,8946,8409,712,43,649,81,75,8204,8200,69,665,1,592]

theorem envBound43560 : H12AffineFastState.Bounded env43560 := by
  intro p hp
  have h : env43560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43559_43560 : H12AffineEnvironment.transform 10 675 env43559 = env43560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 675 env43559 == env43560) = true)

theorem identity43560 : scanCanonicalize (H12AffineFastState.compose env43560 (packedSelected [12,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 553) := by decide +kernel

theorem selectedBound43560 : packedSelected [12,13,15] rootPS < 2^1333 := by decide +kernel

def env43561 : List Nat := [2,4,8,16,32,64,128,68,512,4,675,81,553,81,609,154,728,27,84,608,81,153,712,219,752,712,43,649,81,75,549,545,69,665,1,592]

theorem envBound43561 : H12AffineFastState.Bounded env43561 := by
  intro p hp
  have h : env43561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43560_43561 : H12AffineEnvironment.transform 12 553 env43560 = env43561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 553 env43560 == env43561) = true)

theorem identity43561 : scanCanonicalize (H12AffineFastState.compose env43561 (packedSelected [0,3,4,5,7,9,11,13] rootPS)) = affineNative (2^(6+1) ^^^ 66) := by decide +kernel

theorem selectedBound43561 : packedSelected [0,3,4,5,7,9,11,13] rootPS < 2^1333 := by decide +kernel

def env43562 : List Nat := [2,4,8,16,32,64,66,68,512,4,609,81,553,81,609,88,538,27,84,608,81,91,522,25,562,522,43,587,81,75,549,545,69,603,1,592]

theorem envBound43562 : H12AffineFastState.Bounded env43562 := by
  intro p hp
  have h : env43562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43561_43562 : H12AffineEnvironment.transform 6 66 env43561 = env43562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 66 env43561 == env43562) = true)

theorem identity43562 : scanCanonicalize (H12AffineFastState.compose env43562 (packedSelected [0,2,3,5,9,10] rootPS)) = affineNative (2^(8+1) ^^^ 123) := by decide +kernel

theorem selectedBound43562 : packedSelected [0,2,3,5,9,10] rootPS < 2^1333 := by decide +kernel

def env43563 : List Nat := [2,4,8,16,32,64,66,68,123,4,26,81,82,81,26,88,97,27,84,27,81,91,113,25,73,113,43,48,81,75,94,90,69,32,1,43]

theorem envBound43563 : H12AffineFastState.Bounded env43563 := by
  intro p hp
  have h : env43563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43562_43563 : H12AffineEnvironment.transform 8 123 env43562 = env43563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 123 env43562 == env43563) = true)

theorem identity43563 : scanCanonicalize (H12AffineFastState.compose env43563 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound43563 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env43564 : List Nat := [2,4,8,16,32,17,19,21,42,4,26,0,3,0,26,9,48,27,5,27,0,10,32,25,24,32,43,48,0,26,15,11,20,32,1,43]

theorem envBound43564 : H12AffineFastState.Bounded env43564 := by
  intro p hp
  have h : env43564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43563_43564 : H12AffineEnvironment.transform 5 17 env43563 = env43564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43563 == env43564) = true)

theorem identity43564 : scanCanonicalize (H12AffineFastState.compose env43564 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound43564 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env43565 : List Nat := [2,4,8,2,32,3,1,7,42,4,8,0,3,0,8,9,34,9,5,9,0,10,32,11,10,32,43,34,0,8,15,11,6,32,1,43]

theorem envBound43565 : H12AffineFastState.Bounded env43565 := by
  intro p hp
  have h : env43565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43564_43565 : H12AffineEnvironment.transform 3 2 env43564 = env43565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env43564 == env43565) = true)

theorem identity43565 : scanCanonicalize (H12AffineFastState.compose env43565 (packedSelected [0,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound43565 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env43566 : List Nat := [2,4,8,2,10,3,1,7,0,4,8,0,3,0,8,9,8,9,5,9,0,10,10,11,10,10,1,8,0,8,15,11,6,10,1,1]

theorem envBound43566 : H12AffineFastState.Bounded env43566 := by
  intro p hp
  have h : env43566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43565_43566 : H12AffineEnvironment.transform 4 10 env43565 = env43566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env43565 == env43566) = true)

theorem identity43566 : scanCanonicalize (H12AffineFastState.compose env43566 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound43566 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43567 : List Nat := [2,4,4,2,6,3,1,7,0,4,4,0,3,0,4,5,4,5,5,5,0,6,6,7,6,6,1,4,0,4,3,7,6,6,1,1]

theorem envBound43567 : H12AffineFastState.Bounded env43567 := by
  intro p hp
  have h : env43567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43566_43567 : H12AffineEnvironment.transform 2 4 env43566 = env43567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env43566 == env43567) = true)

theorem identity43567 : scanCanonicalize (H12AffineFastState.compose env43567 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound43567 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43568 : List Nat := [2,1,1,2,3,3,1,2,0,1,1,0,3,0,1,0,1,0,0,0,0,3,3,2,3,3,1,1,0,1,3,2,3,3,1,1]

theorem envBound43568 : H12AffineFastState.Bounded env43568 := by
  intro p hp
  have h : env43568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43567_43568 : H12AffineEnvironment.transform 1 1 env43567 = env43568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env43567 == env43568) = true)

theorem identity43568 : scanCanonicalize (H12AffineFastState.compose env43568 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound43568 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env43569 : List Nat := [0,1,1,0,1,1,1,0,0,1,1,0,1,0,1,0,1,0,0,0,0,1,1,0,1,1,1,1,0,1,1,0,1,1,1,1]

theorem envBound43569 : H12AffineFastState.Bounded env43569 := by
  intro p hp
  have h : env43569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43568_43569 : H12AffineEnvironment.transform 0 0 env43568 = env43569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env43568 == env43569) = true)

def env43570 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,81,8192,80,8461,65536,74030,65665,272,8460,81,477,74047,65601,8408,74046,367,74111,80,75866,8204,8200,257,74095,0,593]

theorem envBound43570 : H12AffineFastState.Bounded env43570 := by
  intro p hp
  have h : env43570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43556_43570 : H12AffineEnvironment.transform 9 321 env43556 = env43570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env43556 == env43570) = true)

theorem identity43570 : scanCanonicalize (H12AffineFastState.compose env43570 (packedSelected [7,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound43570 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env43571 : List Nat := [2,4,8,16,32,64,128,21,512,84,2048,81,8192,80,8216,65536,73787,65665,5,8217,81,200,73770,65601,8408,73771,122,73834,80,75866,8204,8200,20,73850,0,593]

theorem envBound43571 : H12AffineFastState.Bounded env43571 := by
  intro p hp
  have h : env43571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43570_43571 : H12AffineEnvironment.transform 7 21 env43570 = env43571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env43570 == env43571) = true)

theorem identity43571 : scanCanonicalize (H12AffineFastState.compose env43571 (packedSelected [0,1,4,7,8,9,16,19,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound43571 : packedSelected [0,1,4,7,8,9,16,19,20] rootPS < 2^1333 := by decide +kernel

def env43572 : List Nat := [2,4,8,16,32,16,128,21,512,4,2048,1,8192,0,8216,65536,73787,65665,5,8217,1,152,73770,65553,8328,73771,42,73786,0,75786,8204,8200,20,73770,0,513]

theorem envBound43572 : H12AffineFastState.Bounded env43572 := by
  intro p hp
  have h : env43572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43571_43572 : H12AffineEnvironment.transform 5 16 env43571 = env43572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43571 == env43572) = true)

theorem identity43572 : scanCanonicalize (H12AffineFastState.compose env43572 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 8250) := by decide +kernel

theorem selectedBound43572 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env43573 : List Nat := [2,4,8,16,32,16,128,21,512,4,2048,1,8192,0,8216,8250,1,8379,5,8217,1,152,16,8235,8328,17,42,0,0,2096,8204,8200,20,16,0,513]

theorem envBound43573 : H12AffineFastState.Bounded env43573 := by
  intro p hp
  have h : env43573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43572_43573 : H12AffineEnvironment.transform 15 8250 env43572 = env43573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8250 env43572 == env43573) = true)

theorem identity43573 : scanCanonicalize (H12AffineFastState.compose env43573 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 185) := by decide +kernel

theorem selectedBound43573 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43574 : List Nat := [2,4,8,16,32,16,128,21,185,4,2048,1,8192,0,8216,8250,1,8379,5,8217,1,152,16,8235,8328,17,42,0,0,2096,8204,8200,20,16,0,184]

theorem envBound43574 : H12AffineFastState.Bounded env43574 := by
  intro p hp
  have h : env43574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43573_43574 : H12AffineEnvironment.transform 8 185 env43573 = env43574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 185 env43573 == env43574) = true)

theorem identity43574 : scanCanonicalize (H12AffineFastState.compose env43574 (packedSelected [3,8] rootPS)) = affineNative (2^(12+1) ^^^ 2193) := by decide +kernel

theorem selectedBound43574 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env43575 : List Nat := [2,4,8,16,32,16,128,21,185,4,2048,1,2193,0,2185,2219,1,2090,5,2184,1,152,16,2234,2073,17,42,0,0,2096,2205,2201,20,16,0,184]

theorem envBound43575 : H12AffineFastState.Bounded env43575 := by
  intro p hp
  have h : env43575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43574_43575 : H12AffineEnvironment.transform 12 2193 env43574 = env43575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2193 env43574 == env43575) = true)

theorem identity43575 : scanCanonicalize (H12AffineFastState.compose env43575 (packedSelected [0,1,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 128) := by decide +kernel

theorem selectedBound43575 : packedSelected [0,1,4,7] rootPS < 2^1333 := by decide +kernel

def env43576 : List Nat := [2,4,8,16,32,16,128,21,185,4,128,1,17,0,9,43,1,170,5,8,1,152,16,58,153,17,42,0,0,176,29,25,20,16,0,184]

theorem envBound43576 : H12AffineFastState.Bounded env43576 := by
  intro p hp
  have h : env43576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43575_43576 : H12AffineEnvironment.transform 10 128 env43575 = env43576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 128 env43575 == env43576) = true)

theorem identity43576 : scanCanonicalize (H12AffineFastState.compose env43576 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound43576 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env43577 : List Nat := [2,4,8,9,32,9,128,12,160,4,128,1,8,0,9,43,1,170,5,8,1,129,9,35,128,8,42,0,0,169,4,0,13,9,0,161]

theorem envBound43577 : H12AffineFastState.Bounded env43577 := by
  intro p hp
  have h : env43577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43576_43577 : H12AffineEnvironment.transform 3 9 env43576 = env43577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env43576 == env43577) = true)

theorem identity43577 : scanCanonicalize (H12AffineFastState.compose env43577 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 37) := by decide +kernel

theorem selectedBound43577 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env43578 : List Nat := [2,4,8,9,32,9,37,12,5,4,37,1,8,0,9,43,1,15,5,8,1,36,9,35,37,8,42,0,0,12,4,0,13,9,0,4]

theorem envBound43578 : H12AffineFastState.Bounded env43578 := by
  intro p hp
  have h : env43578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43577_43578 : H12AffineEnvironment.transform 6 37 env43577 = env43578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 37 env43577 == env43578) = true)

theorem identity43578 : scanCanonicalize (H12AffineFastState.compose env43578 (packedSelected [1,4,11] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

end H12CloudChart2