import H12CloudChart2Data088

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity21843 : scanCanonicalize (H12AffineFastState.compose env21843 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound21843 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21844 : List Nat := [2,4,8,16,1,17,8,256,260,1024,2048,1296,8192,1297,2308,2050,1296,8460,1025,2309,1297,10248,17,3,8192,16,2048,1297,1297,8460,1284,260,257,10508,1296,260]

theorem envBound21844 : H12AffineFastState.Bounded env21844 := by
  intro p hp
  have h : env21844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21843_21844 : H12AffineEnvironment.transform 4 1 env21843 = env21844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21843 == env21844) = true)

theorem identity21844 : scanCanonicalize (H12AffineFastState.compose env21844 (packedSelected [3] rootPS)) = affineNative (2^(12+1) ^^^ 2317) := by decide +kernel

theorem selectedBound21844 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env21845 : List Nat := [2,4,8,16,1,17,8,256,260,1024,2048,1296,2317,1297,2308,2050,1296,2049,1025,2309,1297,261,17,3,2317,16,2048,1297,1297,2049,1284,260,257,1,1296,260]

theorem envBound21845 : H12AffineFastState.Bounded env21845 := by
  intro p hp
  have h : env21845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21844_21845 : H12AffineEnvironment.transform 12 2317 env21844 = env21845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2317 env21844 == env21845) = true)

theorem identity21845 : scanCanonicalize (H12AffineFastState.compose env21845 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound21845 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env21846 : List Nat := [2,4,8,16,1,17,8,4,0,1024,2048,1044,2057,1045,2048,2050,1044,2049,1025,2049,1045,1,17,3,2057,16,2048,1045,1045,2049,1024,0,5,1,1044,0]

theorem envBound21846 : H12AffineFastState.Bounded env21846 := by
  intro p hp
  have h : env21846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21845_21846 : H12AffineEnvironment.transform 7 4 env21845 = env21846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env21845 == env21846) = true)

def leafEnv21846 : List Nat := [2,4,8,16,1,17,8,4,0,1024,2048,1044,2057,1045,2048,2050,1044,2049,1025,2049,1045,1,17,3,1025,2057,1,16,2048,1045,1045,2049,1024,0,5,1,5,2051,1044,0,0,1044,1]

def active21846 : List Nat := [0,1,2,3,9,10]

def tree21846 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21846 : H12WitnessSearch.Good tree21846 := H12GlobalWitnessIndex.good

theorem leafIdentity21846 : H12AffineFastState.composeSystem env21846 rootObs = leafEnv21846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21846 rootObs == leafEnv21846) = true)

theorem terminalChecked21846 : H12PackedTerminal.terminalCheckFast leafEnv21846 active21846 tree21846 = true := by decide +kernel

def env21847 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,2561,2959,1296,8744,1025,2560,4097,10248,5377,139,8328,5376,2852,4097,1297,8460,1284,4294967296,257,4294977577,1296,512]

theorem envBound21847 : H12AffineFastState.Bounded env21847 := by
  intro p hp
  have h : env21847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21834_21847 : H12AffineEnvironment.transform 14 2561 env21834 = env21847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2561 env21834 == env21847) = true)

theorem identity21847 : scanCanonicalize (H12AffineFastState.compose env21847 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 11021) := by decide +kernel

theorem selectedBound21847 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21848 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,2561,2959,1296,8744,1025,2560,4097,10248,5377,139,8328,5376,2852,4097,1297,8460,1284,11021,257,804,1296,512]

theorem envBound21848 : H12AffineFastState.Bounded env21848 := by
  intro p hp
  have h : env21848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21847_21848 : H12AffineEnvironment.transform 31 11021 env21847 = env21848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 11021 env21847 == env21848) = true)

theorem identity21848 : scanCanonicalize (H12AffineFastState.compose env21848 (packedSelected [3,12] rootPS)) = affineNative (2^(12+1) ^^^ 2349) := by decide +kernel

theorem selectedBound21848 : packedSelected [3,12] rootPS < 2^1333 := by decide +kernel

def env21849 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,2349,4097,2561,2959,1296,2821,1025,2560,4097,293,5377,139,2469,5376,2852,4097,1297,2081,1284,544,257,804,1296,512]

theorem envBound21849 : H12AffineFastState.Bounded env21849 := by
  intro p hp
  have h : env21849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21848_21849 : H12AffineEnvironment.transform 12 2349 env21848 = env21849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2349 env21848 == env21849) = true)

def env21850 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,2349,1297,2561,2959,1296,2821,1025,2560,1297,293,17,139,2469,16,2852,1297,1297,2081,1284,544,257,804,1296,512]

theorem envBound21850 : H12AffineFastState.Bounded env21850 := by
  intro p hp
  have h : env21850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21849_21850 : H12AffineEnvironment.transform 11 1296 env21849 = env21850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env21849 == env21850) = true)

theorem identity21850 : scanCanonicalize (H12AffineFastState.compose env21850 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound21850 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21851 : List Nat := [2,4,8,16,32,17,128,256,292,1024,2048,1296,2349,1297,2341,2219,1296,2081,1025,2340,1297,293,17,139,2469,16,2048,1297,1297,2081,1284,260,257,0,1296,292]

theorem envBound21851 : H12AffineFastState.Bounded env21851 := by
  intro p hp
  have h : env21851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21850_21851 : H12AffineEnvironment.transform 8 292 env21850 = env21851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env21850 == env21851) = true)

theorem identity21851 : scanCanonicalize (H12AffineFastState.compose env21851 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound21851 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21852 : List Nat := [2,4,8,16,0,17,128,256,260,1024,2048,1296,2317,1297,2309,2187,1296,2049,1025,2308,1297,261,17,139,2437,16,2048,1297,1297,2049,1284,260,257,0,1296,260]

theorem envBound21852 : H12AffineFastState.Bounded env21852 := by
  intro p hp
  have h : env21852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21851_21852 : H12AffineEnvironment.transform 4 0 env21851 = env21852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21851 == env21852) = true)

def env21853 : List Nat := [2,4,8,16,0,17,8,256,260,1024,2048,1296,2317,1297,2309,2051,1296,2049,1025,2308,1297,261,17,3,2317,16,2048,1297,1297,2049,1284,260,257,0,1296,260]

theorem envBound21853 : H12AffineFastState.Bounded env21853 := by
  intro p hp
  have h : env21853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21852_21853 : H12AffineEnvironment.transform 6 8 env21852 = env21853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21852 == env21853) = true)

theorem identity21853 : scanCanonicalize (H12AffineFastState.compose env21853 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound21853 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env21854 : List Nat := [2,4,8,16,0,17,8,4,0,1024,2048,1044,2057,1045,2049,2051,1044,2049,1025,2048,1045,1,17,3,2057,16,2048,1045,1045,2049,1024,0,5,0,1044,0]

theorem envBound21854 : H12AffineFastState.Bounded env21854 := by
  intro p hp
  have h : env21854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21853_21854 : H12AffineEnvironment.transform 7 4 env21853 = env21854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env21853 == env21854) = true)

def leafEnv21854 : List Nat := [2,4,8,16,0,17,8,4,0,1024,2048,1044,2057,1045,2049,2051,1044,2049,1025,2048,1045,1,17,3,1025,2057,1,16,2048,1045,1045,2049,1024,0,5,0,5,2050,1044,0,0,1044,1]

def active21854 : List Nat := [0,1,2,3,9,10]

def tree21854 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21854 : H12WitnessSearch.Good tree21854 := H12GlobalWitnessIndex.good

theorem leafIdentity21854 : H12AffineFastState.composeSystem env21854 rootObs = leafEnv21854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21854 rootObs == leafEnv21854) = true)

theorem terminalChecked21854 : H12PackedTerminal.terminalCheckFast leafEnv21854 active21854 tree21854 = true := by decide +kernel

def env21855 : List Nat := [2,4,8,16,0,17,9,256,260,1024,2048,1296,2317,1297,2309,2050,1296,2049,1025,2308,1297,261,17,2,2316,16,2048,1297,1297,2049,1284,260,257,0,1296,260]

theorem envBound21855 : H12AffineFastState.Bounded env21855 := by
  intro p hp
  have h : env21855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21852_21855 : H12AffineEnvironment.transform 6 9 env21852 = env21855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21852 == env21855) = true)

def leafEnv21855 : List Nat := [2,4,8,16,0,17,9,256,260,1024,2048,1296,2317,1297,2309,2050,1296,2049,1025,2308,1297,261,17,2,1285,2316,1,16,2048,1297,1297,2049,1284,260,257,0,5,2050,1296,260,0,1296,1]

def active21855 : List Nat := [0,1,2,3,7,9,10]

def tree21855 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21855 : H12WitnessSearch.Good tree21855 := H12GlobalWitnessIndex.good

theorem leafIdentity21855 : H12AffineFastState.composeSystem env21855 rootObs = leafEnv21855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21855 rootObs == leafEnv21855) = true)

theorem terminalChecked21855 : H12PackedTerminal.terminalCheckFast leafEnv21855 active21855 tree21855 = true := by decide +kernel

def env21856 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,2349,1296,2561,2959,1296,2821,1025,2560,1296,293,16,139,2469,17,2852,1296,1297,2081,1284,544,257,804,1296,512]

theorem envBound21856 : H12AffineFastState.Bounded env21856 := by
  intro p hp
  have h : env21856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21849_21856 : H12AffineEnvironment.transform 11 1297 env21849 = env21856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env21849 == env21856) = true)

theorem identity21856 : scanCanonicalize (H12AffineFastState.compose env21856 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound21856 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env21857 : List Nat := [2,4,8,16,32,17,128,256,293,1024,2048,1297,2349,1296,2340,2218,1296,2080,1025,2341,1296,293,16,139,2469,17,2049,1296,1297,2081,1284,261,257,1,1296,293]

theorem envBound21857 : H12AffineFastState.Bounded env21857 := by
  intro p hp
  have h : env21857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21856_21857 : H12AffineEnvironment.transform 8 293 env21856 = env21857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env21856 == env21857) = true)

theorem identity21857 : scanCanonicalize (H12AffineFastState.compose env21857 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound21857 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21858 : List Nat := [2,4,8,16,32,17,128,4,33,1024,2048,1045,2089,1044,2080,2218,1044,2080,1025,2081,1044,33,16,139,2209,17,2049,1044,1045,2081,1024,1,5,1,1044,33]

theorem envBound21858 : H12AffineFastState.Bounded env21858 := by
  intro p hp
  have h : env21858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21857_21858 : H12AffineEnvironment.transform 7 4 env21857 = env21858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env21857 == env21858) = true)

theorem identity21858 : scanCanonicalize (H12AffineFastState.compose env21858 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound21858 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env21859 : List Nat := [2,4,8,16,32,17,41,4,33,1024,2048,1045,2089,1044,2080,2051,1044,2080,1025,2081,1044,33,16,34,2056,17,2049,1044,1045,2081,1024,1,5,1,1044,33]

theorem envBound21859 : H12AffineFastState.Bounded env21859 := by
  intro p hp
  have h : env21859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21858_21859 : H12AffineEnvironment.transform 6 41 env21858 = env21859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env21858 == env21859) = true)

def env21860 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,1296,63528,21504,32769,4097,10249,17664,98565,8328,5376,33060,16384,1297,28940,1284,4294967296,257,4295076262,1296,512]

theorem envBound21860 : H12AffineFastState.Bounded env21860 := by
  intro p hp
  have h : env21860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21831_21860 : H12AffineEnvironment.transform 21 10249 env21831 = env21860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10249 env21831 == env21860) = true)

theorem identity21860 : scanCanonicalize (H12AffineFastState.compose env21860 (packedSelected [11] rootPS)) = affineNative (2^(14+1) ^^^ 22820) := by decide +kernel

theorem selectedBound21860 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env21861 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,22820,65536,1296,8460,21504,22821,4097,10249,17664,88097,8328,5376,22528,16384,1297,28940,1284,4294967296,257,4295061634,1296,512]

theorem envBound21861 : H12AffineFastState.Bounded env21861 := by
  intro p hp
  have h : env21861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21860_21861 : H12AffineEnvironment.transform 14 22820 env21860 = env21861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 22820 env21860 == env21861) = true)

def env21862 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,2340,65536,1296,8460,1024,2341,4097,10249,5376,67617,8328,5376,2048,4096,1297,8460,1284,4294967296,257,4295041154,1296,512]

theorem envBound21862 : H12AffineFastState.Bounded env21862 := by
  intro p hp
  have h : env21862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21861_21862 : H12AffineEnvironment.transform 13 4096 env21861 = env21862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env21861 == env21862) = true)

theorem identity21862 : scanCanonicalize (H12AffineFastState.compose env21862 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 7196) := by decide +kernel

theorem selectedBound21862 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env21863 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,7196,4096,2340,65536,1296,7440,1024,2341,4097,5141,5376,67617,7316,5376,2048,4096,1297,7440,1284,4294967296,257,4295040158,1296,512]

theorem envBound21863 : H12AffineFastState.Bounded env21863 := by
  intro p hp
  have h : env21863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21862_21863 : H12AffineEnvironment.transform 12 7196 env21862 = env21863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7196 env21862 == env21863) = true)

theorem identity21863 : scanCanonicalize (H12AffineFastState.compose env21863 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 2822) := by decide +kernel

theorem selectedBound21863 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21864 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,7196,4096,2340,2822,1296,7440,1024,2341,4097,5141,5376,807,7316,5376,2048,4096,1297,7440,1284,4294967296,257,4294973336,1296,512]

theorem envBound21864 : H12AffineFastState.Bounded env21864 := by
  intro p hp
  have h : env21864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21863_21864 : H12AffineEnvironment.transform 15 2822 env21863 = env21864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2822 env21863 == env21864) = true)

theorem identity21864 : scanCanonicalize (H12AffineFastState.compose env21864 (packedSelected [5,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound21864 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env21865 : List Nat := [2,4,8,16,32,17,128,37,512,1024,2048,4096,7196,4096,2049,2595,1077,7221,1024,2048,4097,5141,5157,514,7316,5157,2048,4096,1076,7221,1057,4294967296,36,4294973117,1077,512]

theorem envBound21865 : H12AffineFastState.Bounded env21865 := by
  intro p hp
  have h : env21865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21864_21865 : H12AffineEnvironment.transform 7 37 env21864 = env21865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env21864 == env21865) = true)

theorem identity21865 : scanCanonicalize (H12AffineFastState.compose env21865 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound21865 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env21866 : List Nat := [2,4,8,16,32,17,128,37,136,1024,2048,4096,7196,4096,2049,2219,1077,7221,1024,2048,4097,5141,5157,138,7316,5157,2048,4096,1076,7221,1057,4294967296,36,4294972469,1077,136]

theorem envBound21866 : H12AffineFastState.Bounded env21866 := by
  intro p hp
  have h : env21866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21865_21866 : H12AffineEnvironment.transform 8 136 env21865 = env21866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env21865 == env21866) = true)

theorem identity21866 : scanCanonicalize (H12AffineFastState.compose env21866 (packedSelected [0,1] rootPS)) = affineNative (2^(11+1) ^^^ 2179) := by decide +kernel

theorem selectedBound21866 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env21867 : List Nat := [2,4,8,16,32,17,128,37,136,1024,2048,2179,1183,2179,2049,2219,1077,1206,1024,2048,2178,3222,3238,138,1047,3238,2048,2179,1076,1206,1057,4294967296,36,4294970550,1077,136]

theorem envBound21867 : H12AffineFastState.Bounded env21867 := by
  intro p hp
  have h : env21867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21866_21867 : H12AffineEnvironment.transform 11 2179 env21866 = env21867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2179 env21866 == env21867) = true)

theorem identity21867 : scanCanonicalize (H12AffineFastState.compose env21867 (packedSelected [2,4] rootPS)) = affineNative (2^(10+1) ^^^ 1054) := by decide +kernel

theorem selectedBound21867 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env21868 : List Nat := [2,4,8,16,32,17,128,37,136,1024,1054,1181,1183,1181,1055,1205,1077,1206,1024,1054,1180,136,184,138,1047,184,1054,1181,1076,1206,1057,4294967296,36,4294967464,1077,136]

theorem envBound21868 : H12AffineFastState.Bounded env21868 := by
  intro p hp
  have h : env21868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21867_21868 : H12AffineEnvironment.transform 10 1054 env21867 = env21868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1054 env21867 == env21868) = true)

def env21869 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,2341,65536,1296,8460,1025,2340,4097,10249,5377,67616,8328,5376,2049,4097,1297,8461,1284,4294967296,257,4295041155,1296,512]

theorem envBound21869 : H12AffineFastState.Bounded env21869 := by
  intro p hp
  have h : env21869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21861_21869 : H12AffineEnvironment.transform 13 4097 env21861 = env21869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4097 env21861 == env21869) = true)

theorem identity21869 : scanCanonicalize (H12AffineFastState.compose env21869 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound21869 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env21870 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,2341,65536,1296,8460,1025,2340,1296,10249,16,67616,8328,17,2049,1296,1297,8461,1284,4294967296,257,4295041155,1296,512]

theorem envBound21870 : H12AffineFastState.Bounded env21870 := by
  intro p hp
  have h : env21870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21869_21870 : H12AffineEnvironment.transform 11 1297 env21869 = env21870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env21869 == env21870) = true)

theorem identity21870 : scanCanonicalize (H12AffineFastState.compose env21870 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 2219) := by decide +kernel

theorem selectedBound21870 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21871 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,2341,2219,1296,8460,1025,2340,1296,10249,16,139,8328,17,2049,1296,1297,8461,1284,4294967296,257,4294977576,1296,512]

theorem envBound21871 : H12AffineFastState.Bounded env21871 := by
  intro p hp
  have h : env21871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21870_21871 : H12AffineEnvironment.transform 15 2219 env21870 = env21871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2219 env21870 == env21871) = true)

theorem identity21871 : scanCanonicalize (H12AffineFastState.compose env21871 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 545) := by decide +kernel

theorem selectedBound21871 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21872 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,2341,2219,1296,8460,1025,2340,1296,10249,16,139,8328,17,2049,1296,1297,8461,1284,545,257,10761,1296,512]

theorem envBound21872 : H12AffineFastState.Bounded env21872 := by
  intro p hp
  have h : env21872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21871_21872 : H12AffineEnvironment.transform 31 545 env21871 = env21872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 545 env21871 == env21872) = true)

theorem identity21872 : scanCanonicalize (H12AffineFastState.compose env21872 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound21872 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env21873 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1297,8192,1296,2341,2219,1296,8460,1025,2340,1296,10249,16,139,8328,17,2049,1296,1297,8461,1284,169,257,10369,1296,136]

theorem envBound21873 : H12AffineFastState.Bounded env21873 := by
  intro p hp
  have h : env21873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21872_21873 : H12AffineEnvironment.transform 8 136 env21872 = env21873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env21872 == env21873) = true)

theorem identity21873 : scanCanonicalize (H12AffineFastState.compose env21873 (packedSelected [0,2] rootPS)) = affineNative (2^(12+1) ^^^ 2316) := by decide +kernel

theorem selectedBound21873 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env21874 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1297,2316,1296,2341,2219,1296,2048,1025,2340,1296,261,16,139,2436,17,2049,1296,1297,2049,1284,169,257,397,1296,136]

theorem envBound21874 : H12AffineFastState.Bounded env21874 := by
  intro p hp
  have h : env21874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21873_21874 : H12AffineEnvironment.transform 12 2316 env21873 = env21874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2316 env21873 == env21874) = true)

def env21875 : List Nat := [2,4,8,16,32,17,8,256,0,1024,2048,1297,2316,1296,2341,2083,1296,2048,1025,2340,1296,261,16,3,2316,17,2049,1296,1297,2049,1284,33,257,261,1296,0]

theorem envBound21875 : H12AffineFastState.Bounded env21875 := by
  intro p hp
  have h : env21875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21874_21875 : H12AffineEnvironment.transform 6 8 env21874 = env21875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21874 == env21875) = true)

theorem identity21875 : scanCanonicalize (H12AffineFastState.compose env21875 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound21875 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21876 : List Nat := [2,4,8,16,1,17,8,256,0,1024,2048,1297,2316,1296,2308,2050,1296,2048,1025,2309,1296,261,16,3,2316,17,2049,1296,1297,2049,1284,0,257,261,1296,0]

theorem envBound21876 : H12AffineFastState.Bounded env21876 := by
  intro p hp
  have h : env21876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21875_21876 : H12AffineEnvironment.transform 4 1 env21875 = env21876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21875 == env21876) = true)

def leafEnv21876 : List Nat := [2,4,8,16,1,17,8,256,0,1024,2048,1297,2316,1296,2308,2050,1296,2048,1025,2309,1296,261,16,3,1285,2316,1,17,2049,1296,1297,2049,1284,0,257,261,5,2051,1296,0,0,1296,1]

def active21876 : List Nat := [0,1,2,3,7,9,10]

def tree21876 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21876 : H12WitnessSearch.Good tree21876 := H12GlobalWitnessIndex.good

theorem leafIdentity21876 : H12AffineFastState.composeSystem env21876 rootObs = leafEnv21876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21876 rootObs == leafEnv21876) = true)

theorem terminalChecked21876 : H12PackedTerminal.terminalCheckFast leafEnv21876 active21876 tree21876 = true := by decide +kernel

def env21877 : List Nat := [2,4,8,16,32,17,9,256,1,1024,2048,1297,2316,1296,2341,2082,1296,2048,1025,2340,1296,261,16,2,2317,17,2049,1296,1297,2049,1284,32,257,260,1296,1]

theorem envBound21877 : H12AffineFastState.Bounded env21877 := by
  intro p hp
  have h : env21877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21874_21877 : H12AffineEnvironment.transform 6 9 env21874 = env21877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21874 == env21877) = true)

theorem identity21877 : scanCanonicalize (H12AffineFastState.compose env21877 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound21877 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21878 : List Nat := [2,4,8,16,32,17,9,5,1,1024,2048,1044,2057,1045,2080,2082,1045,2048,1025,2081,1045,0,16,2,2056,17,2049,1045,1044,2049,1025,32,4,1,1045,1]

theorem envBound21878 : H12AffineFastState.Bounded env21878 := by
  intro p hp
  have h : env21878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21877_21878 : H12AffineEnvironment.transform 7 5 env21877 = env21878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env21877 == env21878) = true)

def leafEnv21878 : List Nat := [2,4,8,16,32,17,9,5,1,1024,2048,1044,2057,1045,2080,2082,1045,2048,1025,2081,1045,0,16,2,1024,2056,1,17,2049,1045,1044,2049,1025,32,4,1,5,2082,1045,1,0,1045,1]

def active21878 : List Nat := [0,1,2,3,4,9,10]

def tree21878 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21878 : H12WitnessSearch.Good tree21878 := H12GlobalWitnessIndex.good

theorem leafIdentity21878 : H12AffineFastState.composeSystem env21878 rootObs = leafEnv21878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21878 rootObs == leafEnv21878) = true)

theorem terminalChecked21878 : H12PackedTerminal.terminalCheckFast leafEnv21878 active21878 tree21878 = true := by decide +kernel

def env21879 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,21505,32769,4097,4194304,17664,98565,8328,5456,4477268,16384,1345,1073741824,1284,4294967296,257,4299260335,1297,512]

theorem envBound21879 : H12AffineFastState.Bounded env21879 := by
  intro p hp
  have h : env21879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21827_21879 : H12AffineEnvironment.transform 18 21505 env21827 = env21879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21505 env21827 == env21879) = true)

def env21880 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,1297,262144,21505,32769,4097,4194304,17664,98565,8328,5376,4477188,16384,1297,1073741824,1284,4294967296,257,4299260335,1297,512]

theorem envBound21880 : H12AffineFastState.Bounded env21880 := by
  intro p hp
  have h : env21880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21879_21880 : H12AffineEnvironment.transform 5 16 env21879 = env21880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21879 == env21880) = true)

theorem identity21880 : scanCanonicalize (H12AffineFastState.compose env21880 (packedSelected [3,8,12,15,17,19,21] rootPS)) = affineNative (2^(17+1) ^^^ 63529) := by decide +kernel

theorem selectedBound21880 : packedSelected [3,8,12,15,17,19,21] rootPS < 2^1333 := by decide +kernel

def env21881 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,1297,63529,21505,32769,4097,4194304,17664,98565,8328,5376,4237613,16384,1297,1073741824,1284,4294967296,257,4299260335,1297,512]

theorem envBound21881 : H12AffineFastState.Bounded env21881 := by
  intro p hp
  have h : env21881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21880_21881 : H12AffineEnvironment.transform 17 63529 env21880 = env21881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 63529 env21880 == env21881) = true)

theorem identity21881 : scanCanonicalize (H12AffineFastState.compose env21881 (packedSelected [5,15,17,24] rootPS)) = affineNative (2^(29+1) ^^^ 4217092) := by decide +kernel

theorem selectedBound21881 : packedSelected [5,15,17,24] rootPS < 2^1333 := by decide +kernel

def env21882 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,1297,63529,21505,32769,4097,4194304,17664,98565,8328,5376,4237613,16384,1297,4217092,1284,4294967296,257,4299260335,1297,512]

theorem envBound21882 : H12AffineFastState.Bounded env21882 := by
  intro p hp
  have h : env21882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21881_21882 : H12AffineEnvironment.transform 29 4217092 env21881 = env21882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4217092 env21881 == env21882) = true)

def env21883 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,1297,63529,21505,32769,4097,10248,17664,98565,8328,5376,33061,16384,1297,28940,1284,4294967296,257,4295076263,1297,512]

theorem envBound21883 : H12AffineFastState.Bounded env21883 := by
  intro p hp
  have h : env21883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21882_21883 : H12AffineEnvironment.transform 21 10248 env21882 = env21883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10248 env21882 == env21883) = true)

theorem identity21883 : scanCanonicalize (H12AffineFastState.compose env21883 (packedSelected [11] rootPS)) = affineNative (2^(13+1) ^^^ 4096) := by decide +kernel

theorem selectedBound21883 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env21884 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,1297,43049,1025,32769,4097,10248,5376,98565,8328,5376,33061,4096,1297,8460,1284,4294967296,257,4295076263,1297,512]

theorem envBound21884 : H12AffineFastState.Bounded env21884 := by
  intro p hp
  have h : env21884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21883_21884 : H12AffineEnvironment.transform 13 4096 env21883 = env21884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env21883 == env21884) = true)

def env21885 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,32768,65536,1297,43049,1025,32769,1297,10248,16,98565,8328,16,33061,1296,1297,8460,1284,4294967296,257,4295076263,1297,512]

theorem envBound21885 : H12AffineFastState.Bounded env21885 := by
  intro p hp
  have h : env21885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21884_21885 : H12AffineEnvironment.transform 11 1296 env21884 = env21885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env21884 == env21885) = true)

theorem identity21885 : scanCanonicalize (H12AffineFastState.compose env21885 (packedSelected [1,3] rootPS)) = affineNative (2^(14+1) ^^^ 8232) := by decide +kernel

theorem selectedBound21885 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21886 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,8232,65536,1297,2049,1025,8233,1297,10248,16,74029,8328,16,8461,1296,1297,8460,1284,4294967296,257,4295035279,1297,512]

theorem envBound21886 : H12AffineFastState.Bounded env21886 := by
  intro p hp
  have h : env21886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21885_21886 : H12AffineEnvironment.transform 14 8232 env21885 = env21886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env21885 == env21886) = true)

theorem identity21886 : scanCanonicalize (H12AffineFastState.compose env21886 (packedSelected [5] rootPS)) = affineNative (2^(15+1) ^^^ 2595) := by decide +kernel

theorem selectedBound21886 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env21887 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,8232,2595,1297,2049,1025,8233,1297,10248,16,11022,8328,16,8461,1296,1297,8460,1284,4294967296,257,4294968236,1297,512]

theorem envBound21887 : H12AffineFastState.Bounded env21887 := by
  intro p hp
  have h : env21887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21886_21887 : H12AffineEnvironment.transform 15 2595 env21886 = env21887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2595 env21886 == env21887) = true)

theorem identity21887 : scanCanonicalize (H12AffineFastState.compose env21887 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 2317) := by decide +kernel

theorem selectedBound21887 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env21888 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,2317,1296,2341,2595,1297,2049,1025,2340,1297,261,16,515,2437,16,2048,1296,1297,2049,1284,4294967296,257,4294968236,1297,512]

theorem envBound21888 : H12AffineFastState.Bounded env21888 := by
  intro p hp
  have h : env21888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21887_21888 : H12AffineEnvironment.transform 12 2317 env21887 = env21888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2317 env21887 == env21888) = true)

theorem identity21888 : scanCanonicalize (H12AffineFastState.compose env21888 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound21888 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env21889 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,1296,2317,1296,2341,2219,1297,2049,1025,2340,1297,261,16,139,2437,16,2048,1296,1297,2049,1284,4294967296,257,4294967588,1297,136]

theorem envBound21889 : H12AffineFastState.Bounded env21889 := by
  intro p hp
  have h : env21889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21888_21889 : H12AffineEnvironment.transform 8 136 env21888 = env21889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env21888 == env21889) = true)

theorem identity21889 : scanCanonicalize (H12AffineFastState.compose env21889 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 33) := by decide +kernel

theorem selectedBound21889 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21890 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,1296,2317,1296,2341,2219,1297,2049,1025,2340,1297,261,16,139,2437,16,2048,1296,1297,2049,1284,33,257,261,1297,136]

theorem envBound21890 : H12AffineFastState.Bounded env21890 := by
  intro p hp
  have h : env21890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21889_21890 : H12AffineEnvironment.transform 31 33 env21889 = env21890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 33 env21889 == env21890) = true)

theorem identity21890 : scanCanonicalize (H12AffineFastState.compose env21890 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound21890 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21891 : List Nat := [2,4,8,16,32,16,40,256,32,1024,2048,1296,2317,1296,2341,2051,1297,2049,1025,2340,1297,261,16,35,2349,16,2048,1296,1297,2049,1284,33,257,261,1297,32]

theorem envBound21891 : H12AffineFastState.Bounded env21891 := by
  intro p hp
  have h : env21891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21890_21891 : H12AffineEnvironment.transform 6 40 env21890 = env21891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env21890 == env21891) = true)

def env21892 : List Nat := [2,4,8,16,0,16,8,256,0,1024,2048,1296,2317,1296,2309,2051,1297,2049,1025,2308,1297,261,16,3,2317,16,2048,1296,1297,2049,1284,1,257,261,1297,0]

theorem envBound21892 : H12AffineFastState.Bounded env21892 := by
  intro p hp
  have h : env21892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21891_21892 : H12AffineEnvironment.transform 4 0 env21891 = env21892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21891 == env21892) = true)

def leafEnv21892 : List Nat := [2,4,8,16,0,16,8,256,0,1024,2048,1296,2317,1296,2309,2051,1297,2049,1025,2308,1297,261,16,3,1285,2317,1,16,2048,1296,1297,2049,1284,1,257,261,5,2050,1297,0,0,1296,1]

def active21892 : List Nat := [0,1,2,3,7,9,10]

def tree21892 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21892 : H12WitnessSearch.Good tree21892 := H12GlobalWitnessIndex.good

theorem leafIdentity21892 : H12AffineFastState.composeSystem env21892 rootObs = leafEnv21892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21892 rootObs == leafEnv21892) = true)

theorem terminalChecked21892 : H12PackedTerminal.terminalCheckFast leafEnv21892 active21892 tree21892 = true := by decide +kernel

def env21893 : List Nat := [2,4,8,16,1,16,9,256,1,1024,2048,1296,2317,1296,2308,2051,1297,2049,1025,2309,1297,261,16,2,2316,16,2048,1296,1297,2049,1284,0,257,261,1297,1]

theorem envBound21893 : H12AffineFastState.Bounded env21893 := by
  intro p hp
  have h : env21893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21891_21893 : H12AffineEnvironment.transform 4 1 env21891 = env21893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21891 == env21893) = true)

theorem identity21893 : scanCanonicalize (H12AffineFastState.compose env21893 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound21893 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21894 : List Nat := [2,4,8,16,1,16,9,4,1,1024,2048,1044,2057,1044,2048,2051,1045,2049,1025,2049,1045,1,16,2,2056,16,2048,1044,1045,2049,1024,0,5,1,1045,1]

theorem envBound21894 : H12AffineFastState.Bounded env21894 := by
  intro p hp
  have h : env21894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21893_21894 : H12AffineEnvironment.transform 7 4 env21893 = env21894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env21893 == env21894) = true)

def leafEnv21894 : List Nat := [2,4,8,16,1,16,9,4,1,1024,2048,1044,2057,1044,2048,2051,1045,2049,1025,2049,1045,1,16,2,1025,2056,1,16,2048,1044,1045,2049,1024,0,5,1,5,2051,1045,1,0,1044,1]

def active21894 : List Nat := [0,1,2,3,9,10]

def tree21894 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21894 : H12WitnessSearch.Good tree21894 := H12GlobalWitnessIndex.good

theorem leafIdentity21894 : H12AffineFastState.composeSystem env21894 rootObs = leafEnv21894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21894 rootObs == leafEnv21894) = true)

theorem terminalChecked21894 : H12PackedTerminal.terminalCheckFast leafEnv21894 active21894 tree21894 = true := by decide +kernel

def env21895 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,32768,65536,1297,43049,1025,32769,1296,10248,17,98565,8328,17,33061,1297,1297,8460,1284,4294967296,257,4295076263,1297,512]

theorem envBound21895 : H12AffineFastState.Bounded env21895 := by
  intro p hp
  have h : env21895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21884_21895 : H12AffineEnvironment.transform 11 1297 env21884 = env21895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env21884 == env21895) = true)

theorem identity21895 : scanCanonicalize (H12AffineFastState.compose env21895 (packedSelected [1,3] rootPS)) = affineNative (2^(14+1) ^^^ 2340) := by decide +kernel

theorem selectedBound21895 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21896 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,2340,65536,1297,8461,1025,2341,1296,10248,17,67617,8328,17,2049,1297,1297,8460,1284,4294967296,257,4295041155,1297,512]

theorem envBound21896 : H12AffineFastState.Bounded env21896 := by
  intro p hp
  have h : env21896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21895_21896 : H12AffineEnvironment.transform 14 2340 env21895 = env21896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2340 env21895 == env21896) = true)

def env21897 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,1297,63529,21505,32769,4097,10249,17664,98565,8328,5376,33060,16384,1297,28941,1284,4294967296,257,4295076262,1297,512]

theorem envBound21897 : H12AffineFastState.Bounded env21897 := by
  intro p hp
  have h : env21897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21882_21897 : H12AffineEnvironment.transform 21 10249 env21882 = env21897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10249 env21882 == env21897) = true)

theorem identity21897 : scanCanonicalize (H12AffineFastState.compose env21897 (packedSelected [11] rootPS)) = affineNative (2^(14+1) ^^^ 22821) := by decide +kernel

theorem selectedBound21897 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env21898 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,22821,65536,1297,8460,21505,22820,4097,10249,17664,88096,8328,5376,22529,16384,1297,28941,1284,4294967296,257,4295061635,1297,512]

theorem envBound21898 : H12AffineFastState.Bounded env21898 := by
  intro p hp
  have h : env21898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21897_21898 : H12AffineEnvironment.transform 14 22821 env21897 = env21898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 22821 env21897 == env21898) = true)

def env21899 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,2341,65536,1297,8460,1025,2340,4097,10249,5376,67616,8328,5376,2049,4096,1297,8461,1284,4294967296,257,4295041155,1297,512]

theorem envBound21899 : H12AffineFastState.Bounded env21899 := by
  intro p hp
  have h : env21899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21898_21899 : H12AffineEnvironment.transform 13 4096 env21898 = env21899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env21898 == env21899) = true)

theorem identity21899 : scanCanonicalize (H12AffineFastState.compose env21899 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound21899 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env21900 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,2341,65536,1297,8460,1025,2340,1296,10249,17,67616,8328,17,2049,1297,1297,8461,1284,4294967296,257,4295041155,1297,512]

theorem envBound21900 : H12AffineFastState.Bounded env21900 := by
  intro p hp
  have h : env21900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21899_21900 : H12AffineEnvironment.transform 11 1297 env21899 = env21900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env21899 == env21900) = true)

def env21901 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,1,8192,1,2341,65536,1,8460,273,2340,0,10249,17,67616,8328,17,2049,1,1,8461,20,4294967296,257,4295041155,1,512]

theorem envBound21901 : H12AffineFastState.Bounded env21901 := by
  intro p hp
  have h : env21901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21900_21901 : H12AffineEnvironment.transform 9 272 env21900 = env21901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env21900 == env21901) = true)

theorem identity21901 : scanCanonicalize (H12AffineFastState.compose env21901 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 10369) := by decide +kernel

theorem selectedBound21901 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21902 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,1,8192,1,2341,65536,1,8460,273,2340,0,10249,17,67616,8328,17,2049,1,1,8461,20,10369,257,67586,1,512]

theorem envBound21902 : H12AffineFastState.Bounded env21902 := by
  intro p hp
  have h : env21902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21901_21902 : H12AffineEnvironment.transform 31 10369 env21901 = env21902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 10369 env21901 == env21902) = true)

def env21903 : List Nat := [2,4,8,16,32,16,128,256,512,272,292,1,8192,1,1,65536,1,8460,273,0,0,8493,17,65796,8328,17,293,1,1,8461,20,8613,257,65830,1,512]

theorem envBound21903 : H12AffineFastState.Bounded env21903 := by
  intro p hp
  have h : env21903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21902_21903 : H12AffineEnvironment.transform 10 292 env21902 = env21903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env21902 == env21903) = true)

theorem identity21903 : scanCanonicalize (H12AffineFastState.compose env21903 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 8714) := by decide +kernel

theorem selectedBound21903 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21904 : List Nat := [2,4,8,16,32,16,128,256,512,272,292,1,8192,1,1,8714,1,8460,273,0,0,8493,17,8974,8328,17,293,1,1,8461,20,8613,257,9004,1,512]

theorem envBound21904 : H12AffineFastState.Bounded env21904 := by
  intro p hp
  have h : env21904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21903_21904 : H12AffineEnvironment.transform 15 8714 env21903 = env21904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8714 env21903 == env21904) = true)

def env21905 : List Nat := [2,4,8,16,32,16,128,256,512,272,292,1,160,1,1,682,1,428,273,0,0,397,17,942,40,17,293,1,1,429,20,261,257,908,1,512]

theorem envBound21905 : H12AffineFastState.Bounded env21905 := by
  intro p hp
  have h : env21905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21904_21905 : H12AffineEnvironment.transform 12 160 env21904 = env21905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env21904 == env21905) = true)

theorem identity21905 : scanCanonicalize (H12AffineFastState.compose env21905 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound21905 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21906 : List Nat := [2,4,8,16,1,16,128,256,512,272,261,1,129,1,1,651,1,397,273,0,0,397,17,911,9,17,260,1,1,396,20,261,257,908,1,512]

theorem envBound21906 : H12AffineFastState.Bounded env21906 := by
  intro p hp
  have h : env21906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21905_21906 : H12AffineEnvironment.transform 4 1 env21905 = env21906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21905 == env21906) = true)

def env21907 : List Nat := [2,4,8,16,1,16,128,256,0,272,261,1,129,1,1,139,1,397,273,0,0,397,17,399,9,17,260,1,1,396,20,261,257,396,1,0]

theorem envBound21907 : H12AffineFastState.Bounded env21907 := by
  intro p hp
  have h : env21907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21906_21907 : H12AffineEnvironment.transform 8 0 env21906 = env21907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env21906 == env21907) = true)

theorem identity21907 : scanCanonicalize (H12AffineFastState.compose env21907 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound21907 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21908 : List Nat := [2,4,8,16,1,16,128,4,0,20,1,1,129,1,1,139,1,137,21,0,0,137,17,139,9,17,0,1,1,136,20,1,5,136,1,0]

theorem envBound21908 : H12AffineFastState.Bounded env21908 := by
  intro p hp
  have h : env21908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21907_21908 : H12AffineEnvironment.transform 7 4 env21907 = env21908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env21907 == env21908) = true)

def leafEnv21908 : List Nat := [2,4,8,16,1,16,128,4,0,20,1,1,129,1,1,139,1,137,21,0,0,137,17,139,21,9,1,17,0,1,1,136,20,1,5,136,5,2,1,0,0,0,1]

def active21908 : List Nat := [0,1,2,3,6]

def tree21908 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21908 : H12WitnessSearch.Good tree21908 := H12GlobalWitnessIndex.good

theorem leafIdentity21908 : H12AffineFastState.composeSystem env21908 rootObs = leafEnv21908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21908 rootObs == leafEnv21908) = true)

theorem terminalChecked21908 : H12PackedTerminal.terminalCheckFast leafEnv21908 active21908 tree21908 = true := by decide +kernel

def env21909 : List Nat := [2,4,8,16,1,16,128,256,1,272,261,1,129,1,1,138,1,397,273,0,0,397,17,398,9,17,260,1,1,396,20,261,257,397,1,1]

theorem envBound21909 : H12AffineFastState.Bounded env21909 := by
  intro p hp
  have h : env21909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21906_21909 : H12AffineEnvironment.transform 8 1 env21906 = env21909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env21906 == env21909) = true)

def env21910 : List Nat := [2,4,8,16,32,16,128,256,512,272,292,1,161,1,1,683,1,429,273,0,0,396,17,943,41,17,293,1,1,428,20,260,257,909,1,512]

theorem envBound21910 : H12AffineFastState.Bounded env21910 := by
  intro p hp
  have h : env21910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21904_21910 : H12AffineEnvironment.transform 12 161 env21904 = env21910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env21904 == env21910) = true)

theorem identity21910 : scanCanonicalize (H12AffineFastState.compose env21910 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound21910 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21911 : List Nat := [2,4,8,16,32,16,128,256,260,272,292,1,161,1,1,431,1,429,273,0,0,396,17,171,41,17,293,1,1,428,20,260,257,137,1,260]

theorem envBound21911 : H12AffineFastState.Bounded env21911 := by
  intro p hp
  have h : env21911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21910_21911 : H12AffineEnvironment.transform 8 260 env21910 = env21911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env21910 == env21911) = true)

def env21912 : List Nat := [2,4,8,16,0,16,128,256,260,272,260,1,129,1,1,399,1,397,273,0,0,396,17,139,9,17,261,1,1,396,20,260,257,137,1,260]

theorem envBound21912 : H12AffineFastState.Bounded env21912 := by
  intro p hp
  have h : env21912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21911_21912 : H12AffineEnvironment.transform 4 0 env21911 = env21912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21911 == env21912) = true)

theorem identity21912 : scanCanonicalize (H12AffineFastState.compose env21912 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound21912 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21913 : List Nat := [2,4,8,16,0,16,9,256,260,272,260,1,8,1,1,262,1,260,273,0,0,261,17,2,9,17,261,1,1,261,20,260,257,0,1,260]

theorem envBound21913 : H12AffineFastState.Bounded env21913 := by
  intro p hp
  have h : env21913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21912_21913 : H12AffineEnvironment.transform 6 9 env21912 = env21913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21912 == env21913) = true)

def leafEnv21913 : List Nat := [2,4,8,16,0,16,9,256,260,272,260,1,8,1,1,262,1,260,273,0,0,261,17,2,21,9,1,17,261,1,1,261,20,260,257,0,5,262,1,260,0,0,1]

def active21913 : List Nat := [0,1,2,3,7]

def tree21913 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21913 : H12WitnessSearch.Good tree21913 := H12GlobalWitnessIndex.good

theorem leafIdentity21913 : H12AffineFastState.composeSystem env21913 rootObs = leafEnv21913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21913 rootObs == leafEnv21913) = true)

theorem terminalChecked21913 : H12PackedTerminal.terminalCheckFast leafEnv21913 active21913 tree21913 = true := by decide +kernel

def env21914 : List Nat := [2,4,8,16,1,16,128,256,260,272,261,1,128,1,1,398,1,396,273,0,0,396,17,138,8,17,260,1,1,397,20,260,257,137,1,260]

theorem envBound21914 : H12AffineFastState.Bounded env21914 := by
  intro p hp
  have h : env21914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21911_21914 : H12AffineEnvironment.transform 4 1 env21911 = env21914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21911 == env21914) = true)

theorem identity21914 : scanCanonicalize (H12AffineFastState.compose env21914 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound21914 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21915 : List Nat := [2,4,8,16,1,16,128,141,137,157,136,1,128,1,1,3,1,1,156,0,0,1,17,138,8,17,137,1,1,0,20,137,140,137,1,137]

theorem envBound21915 : H12AffineFastState.Bounded env21915 := by
  intro p hp
  have h : env21915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21914_21915 : H12AffineEnvironment.transform 7 141 env21914 = env21915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env21914 == env21915) = true)

def env21916 : List Nat := [2,4,8,16,32,16,128,256,512,272,293,1,8192,1,0,65536,1,8460,273,1,0,8492,17,65797,8328,17,292,1,1,8461,20,8612,257,65831,1,512]

theorem envBound21916 : H12AffineFastState.Bounded env21916 := by
  intro p hp
  have h : env21916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21902_21916 : H12AffineEnvironment.transform 10 293 env21902 = env21916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env21902 == env21916) = true)

theorem identity21916 : scanCanonicalize (H12AffineFastState.compose env21916 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 900) := by decide +kernel

theorem selectedBound21916 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21917 : List Nat := [2,4,8,16,32,16,128,256,512,272,293,1,900,1,0,65536,1,648,273,1,0,680,17,65797,780,17,292,1,1,649,20,544,257,65831,1,512]

theorem envBound21917 : H12AffineFastState.Bounded env21917 := by
  intro p hp
  have h : env21917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21916_21917 : H12AffineEnvironment.transform 12 900 env21916 = env21917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 900 env21916 == env21917) = true)

theorem identity21917 : scanCanonicalize (H12AffineFastState.compose env21917 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound21917 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21918 : List Nat := [2,4,8,16,32,16,128,256,260,272,293,1,128,1,0,65536,1,396,273,1,0,428,17,65797,8,17,292,1,1,397,20,292,257,65831,1,260]

theorem envBound21918 : H12AffineFastState.Bounded env21918 := by
  intro p hp
  have h : env21918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21917_21918 : H12AffineEnvironment.transform 8 260 env21917 = env21918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env21917 == env21918) = true)

def env21919 : List Nat := [2,4,8,16,32,16,128,140,136,156,169,1,128,1,0,65536,1,0,157,1,0,32,17,65673,8,17,168,1,1,1,20,168,141,65707,1,136]

theorem envBound21919 : H12AffineFastState.Bounded env21919 := by
  intro p hp
  have h : env21919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21918_21919 : H12AffineEnvironment.transform 7 140 env21918 = env21919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env21918 == env21919) = true)

def env21920 : List Nat := [2,4,8,16,32,16,8,4,0,20,33,1,8,1,0,65536,1,0,21,1,0,32,17,65537,8,17,32,1,1,1,20,32,5,65571,1,0]

theorem envBound21920 : H12AffineFastState.Bounded env21920 := by
  intro p hp
  have h : env21920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21919_21920 : H12AffineEnvironment.transform 6 8 env21919 = env21920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21919 == env21920) = true)

theorem identity21920 : scanCanonicalize (H12AffineFastState.compose env21920 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound21920 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21921 : List Nat := [2,4,8,16,1,16,8,4,0,20,0,1,8,1,0,65536,1,0,21,1,0,1,17,65537,8,17,1,1,1,1,20,1,5,65538,1,0]

theorem envBound21921 : H12AffineFastState.Bounded env21921 := by
  intro p hp
  have h : env21921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21920_21921 : H12AffineEnvironment.transform 4 1 env21920 = env21921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21920 == env21921) = true)

def leafEnv21921 : List Nat := [2,4,8,16,1,16,8,4,0,20,0,1,8,1,0,65536,1,0,21,1,0,1,17,65537,21,8,1,17,1,1,1,1,20,1,5,65538,5,3,1,0,0,0,1]

def active21921 : List Nat := [0,1,2,3,15]

def tree21921 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21921 : H12WitnessSearch.Good tree21921 := H12GlobalWitnessIndex.good

theorem leafIdentity21921 : H12AffineFastState.composeSystem env21921 rootObs = leafEnv21921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21921 rootObs == leafEnv21921) = true)

theorem terminalChecked21921 : H12PackedTerminal.terminalCheckFast leafEnv21921 active21921 tree21921 = true := by decide +kernel

def env21922 : List Nat := [2,4,8,16,32,16,9,5,1,21,32,1,9,1,0,65536,1,0,20,1,0,32,17,65536,8,17,33,1,1,1,20,33,4,65570,1,1]

theorem envBound21922 : H12AffineFastState.Bounded env21922 := by
  intro p hp
  have h : env21922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21919_21922 : H12AffineEnvironment.transform 6 9 env21919 = env21922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21919 == env21922) = true)

theorem identity21922 : scanCanonicalize (H12AffineFastState.compose env21922 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound21922 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21923 : List Nat := [2,4,8,16,32,16,9,5,1,21,32,1,9,1,0,34,1,0,20,1,0,32,17,34,8,17,33,1,1,1,20,33,4,0,1,1]

theorem envBound21923 : H12AffineFastState.Bounded env21923 := by
  intro p hp
  have h : env21923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21922_21923 : H12AffineEnvironment.transform 15 34 env21922 = env21923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env21922 == env21923) = true)

def leafEnv21923 : List Nat := [2,4,8,16,32,16,9,5,1,21,32,1,9,1,0,34,1,0,20,1,0,32,17,34,21,8,1,17,33,1,1,1,20,33,4,0,5,2,1,1,0,0,1]

def active21923 : List Nat := [0,1,2,3,4]

def tree21923 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21923 : H12WitnessSearch.Good tree21923 := H12GlobalWitnessIndex.good

theorem leafIdentity21923 : H12AffineFastState.composeSystem env21923 rootObs = leafEnv21923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21923 rootObs == leafEnv21923) = true)

theorem terminalChecked21923 : H12PackedTerminal.terminalCheckFast leafEnv21923 active21923 tree21923 = true := by decide +kernel

def env21924 : List Nat := [2,4,8,16,32,16,128,141,137,157,168,1,128,1,0,65536,1,1,156,1,0,33,17,65672,8,17,169,1,1,0,20,169,140,65706,1,137]

theorem envBound21924 : H12AffineFastState.Bounded env21924 := by
  intro p hp
  have h : env21924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21918_21924 : H12AffineEnvironment.transform 7 141 env21918 = env21924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env21918 == env21924) = true)

theorem identity21924 : scanCanonicalize (H12AffineFastState.compose env21924 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound21924 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env21925 : List Nat := [2,4,8,16,32,16,128,141,137,157,168,1,128,1,0,3,1,1,156,1,0,33,17,139,8,17,169,1,1,0,20,169,140,169,1,137]

theorem envBound21925 : H12AffineFastState.Bounded env21925 := by
  intro p hp
  have h : env21925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21924_21925 : H12AffineEnvironment.transform 15 3 env21924 = env21925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env21924 == env21925) = true)

theorem identity21925 : scanCanonicalize (H12AffineFastState.compose env21925 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound21925 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21926 : List Nat := [2,4,8,16,32,16,9,4,0,20,33,1,9,1,0,3,1,1,21,1,0,33,17,2,8,17,32,1,1,0,20,32,5,32,1,0]

theorem envBound21926 : H12AffineFastState.Bounded env21926 := by
  intro p hp
  have h : env21926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21925_21926 : H12AffineEnvironment.transform 6 9 env21925 = env21926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21925 == env21926) = true)

def leafEnv21926 : List Nat := [2,4,8,16,32,16,9,4,0,20,33,1,9,1,0,3,1,1,21,1,0,33,17,2,21,8,1,17,32,1,1,0,20,32,5,32,5,3,1,0,0,0,1]

def active21926 : List Nat := [0,1,2,3,4]

def tree21926 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21926 : H12WitnessSearch.Good tree21926 := H12GlobalWitnessIndex.good

theorem leafIdentity21926 : H12AffineFastState.composeSystem env21926 rootObs = leafEnv21926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21926 rootObs == leafEnv21926) = true)

theorem terminalChecked21926 : H12PackedTerminal.terminalCheckFast leafEnv21926 active21926 tree21926 = true := by decide +kernel

def env21927 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,0,8192,0,2341,65536,0,8460,272,2340,1,10249,17,67616,8328,17,2049,0,0,8461,21,4294967296,257,4295041155,0,512]

theorem envBound21927 : H12AffineFastState.Bounded env21927 := by
  intro p hp
  have h : env21927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21900_21927 : H12AffineEnvironment.transform 9 273 env21900 = env21927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env21900 == env21927) = true)

theorem identity21927 : scanCanonicalize (H12AffineFastState.compose env21927 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 73770) := by decide +kernel

theorem selectedBound21927 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21928 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,0,8192,0,2341,65536,0,8460,272,2340,1,10249,17,67616,8328,17,2049,0,0,8461,21,73770,257,169,0,512]

theorem envBound21928 : H12AffineFastState.Bounded env21928 := by
  intro p hp
  have h : env21928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21927_21928 : H12AffineEnvironment.transform 31 73770 env21927 = env21928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 73770 env21927 == env21928) = true)

def env21929 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,0,2720,0,2341,65536,0,2988,272,2340,1,681,17,67616,2600,17,2049,0,0,2989,21,68234,257,169,0,512]

theorem envBound21929 : H12AffineFastState.Bounded env21929 := by
  intro p hp
  have h : env21929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21928_21929 : H12AffineEnvironment.transform 12 2720 env21928 = env21929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2720 env21928 == env21929) = true)

theorem identity21929 : scanCanonicalize (H12AffineFastState.compose env21929 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound21929 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env21930 : List Nat := [2,4,8,16,1,16,128,256,512,273,2048,0,2689,0,2308,65536,0,2957,272,2309,1,648,17,67585,2569,17,2049,0,0,2956,21,68234,257,136,0,512]

theorem envBound21930 : H12AffineFastState.Bounded env21930 := by
  intro p hp
  have h : env21930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21929_21930 : H12AffineEnvironment.transform 4 1 env21929 = env21930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21929 == env21930) = true)

def env21931 : List Nat := [2,4,8,16,1,16,128,256,512,273,260,0,901,0,0,65536,0,649,272,1,1,648,17,65797,781,17,261,0,0,648,21,66446,257,136,0,512]

theorem envBound21931 : H12AffineFastState.Bounded env21931 := by
  intro p hp
  have h : env21931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21930_21931 : H12AffineEnvironment.transform 10 260 env21930 = env21931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env21930 == env21931) = true)

theorem identity21931 : scanCanonicalize (H12AffineFastState.compose env21931 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 399) := by decide +kernel

theorem selectedBound21931 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21932 : List Nat := [2,4,8,16,1,16,128,256,512,273,260,0,901,0,0,399,0,649,272,1,1,648,17,138,781,17,261,0,0,648,21,513,257,136,0,512]

theorem envBound21932 : H12AffineFastState.Bounded env21932 := by
  intro p hp
  have h : env21932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21931_21932 : H12AffineEnvironment.transform 15 399 env21931 = env21932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 399 env21931 == env21932) = true)

theorem identity21932 : scanCanonicalize (H12AffineFastState.compose env21932 (packedSelected [2,6] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound21932 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env21933 : List Nat := [2,4,8,16,1,16,128,256,136,273,260,0,269,0,0,399,0,1,272,1,1,0,17,138,389,17,261,0,0,0,21,137,257,136,0,136]

theorem envBound21933 : H12AffineFastState.Bounded env21933 := by
  intro p hp
  have h : env21933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21932_21933 : H12AffineEnvironment.transform 8 136 env21932 = env21933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env21932 == env21933) = true)

def env21934 : List Nat := [2,4,8,16,1,16,128,256,512,273,261,0,900,0,1,65536,0,648,272,0,1,648,17,65796,780,17,260,0,0,649,21,66447,257,136,0,512]

theorem envBound21934 : H12AffineFastState.Bounded env21934 := by
  intro p hp
  have h : env21934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21930_21934 : H12AffineEnvironment.transform 10 261 env21930 = env21934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env21930 == env21934) = true)

def env21935 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,0,2721,0,2341,65536,0,2989,272,2340,1,680,17,67616,2601,17,2049,0,0,2988,21,68235,257,169,0,512]

theorem envBound21935 : H12AffineFastState.Bounded env21935 := by
  intro p hp
  have h : env21935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21928_21935 : H12AffineEnvironment.transform 12 2721 env21928 = env21935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2721 env21928 == env21935) = true)

theorem identity21935 : scanCanonicalize (H12AffineFastState.compose env21935 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 2991) := by decide +kernel

theorem selectedBound21935 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env21936 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,0,2721,0,2341,2991,0,2989,272,2340,1,680,17,911,2601,17,2049,0,0,2988,21,292,257,169,0,512]

theorem envBound21936 : H12AffineFastState.Bounded env21936 := by
  intro p hp
  have h : env21936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21935_21936 : H12AffineEnvironment.transform 15 2991 env21935 = env21936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2991 env21935 == env21936) = true)

def env21937 : List Nat := [2,4,8,16,32,16,128,256,512,273,544,0,129,0,773,399,0,397,272,772,1,680,17,911,9,17,545,0,0,396,21,292,257,169,0,512]

theorem envBound21937 : H12AffineFastState.Bounded env21937 := by
  intro p hp
  have h : env21937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21936_21937 : H12AffineEnvironment.transform 10 544 env21936 = env21937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 544 env21936 == env21937) = true)

def env21938 : List Nat := [2,4,8,16,32,16,128,256,0,273,32,0,129,0,261,399,0,397,272,260,1,168,17,399,9,17,33,0,0,396,21,292,257,169,0,0]

theorem envBound21938 : H12AffineFastState.Bounded env21938 := by
  intro p hp
  have h : env21938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21937_21938 : H12AffineEnvironment.transform 8 0 env21937 = env21938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env21937 == env21938) = true)

def env21939 : List Nat := [2,4,8,16,0,16,128,256,0,273,0,0,129,0,261,399,0,397,272,260,1,136,17,399,9,17,1,0,0,396,21,260,257,137,0,0]

theorem envBound21939 : H12AffineFastState.Bounded env21939 := by
  intro p hp
  have h : env21939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21938_21939 : H12AffineEnvironment.transform 4 0 env21938 = env21939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21938 == env21939) = true)

theorem identity21939 : scanCanonicalize (H12AffineFastState.compose env21939 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound21939 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21940 : List Nat := [2,4,8,16,0,16,9,256,0,273,0,0,8,0,261,262,0,260,272,260,1,1,17,262,9,17,1,0,0,261,21,260,257,0,0,0]

theorem envBound21940 : H12AffineFastState.Bounded env21940 := by
  intro p hp
  have h : env21940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21939_21940 : H12AffineEnvironment.transform 6 9 env21939 = env21940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21939 == env21940) = true)

theorem identity21940 : scanCanonicalize (H12AffineFastState.compose env21940 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound21940 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env21941 : List Nat := [2,4,8,16,0,16,9,4,0,21,0,0,8,0,1,2,0,0,20,0,1,1,17,2,9,17,1,0,0,1,21,0,5,0,0,0]

theorem envBound21941 : H12AffineFastState.Bounded env21941 := by
  intro p hp
  have h : env21941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21940_21941 : H12AffineEnvironment.transform 7 4 env21940 = env21941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env21940 == env21941) = true)

def leafEnv21941 : List Nat := [2,4,8,16,0,16,9,4,0,21,0,0,8,0,1,2,0,0,20,0,1,1,17,2,20,9,1,17,1,0,0,1,21,0,5,0,5,2,0,0,0,1,1]

def active21941 : List Nat := [0,1,2,3]

def tree21941 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21941 : H12WitnessSearch.Good tree21941 := H12GlobalWitnessIndex.good

theorem leafIdentity21941 : H12AffineFastState.composeSystem env21941 rootObs = leafEnv21941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21941 rootObs == leafEnv21941) = true)

theorem terminalChecked21941 : H12PackedTerminal.terminalCheckFast leafEnv21941 active21941 tree21941 = true := by decide +kernel

def env21942 : List Nat := [2,4,8,16,1,16,128,256,0,273,1,0,129,0,261,399,0,397,272,260,1,137,17,399,9,17,0,0,0,396,21,261,257,136,0,0]

theorem envBound21942 : H12AffineFastState.Bounded env21942 := by
  intro p hp
  have h : env21942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21938_21942 : H12AffineEnvironment.transform 4 1 env21938 = env21942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21938 == env21942) = true)

def env21943 : List Nat := [2,4,8,16,1,16,8,256,0,273,1,0,9,0,261,263,0,261,272,260,1,1,17,263,9,17,0,0,0,260,21,261,257,0,0,0]

theorem envBound21943 : H12AffineFastState.Bounded env21943 := by
  intro p hp
  have h : env21943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21942_21943 : H12AffineEnvironment.transform 6 8 env21942 = env21943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env21942 == env21943) = true)

def leafEnv21943 : List Nat := [2,4,8,16,1,16,8,256,0,273,1,0,9,0,261,263,0,261,272,260,1,1,17,263,20,9,1,17,0,0,0,260,21,261,257,0,5,2,0,0,0,1,1]

def active21943 : List Nat := [0,1,2,3,7]

def tree21943 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21943 : H12WitnessSearch.Good tree21943 := H12GlobalWitnessIndex.good

theorem leafIdentity21943 : H12AffineFastState.composeSystem env21943 rootObs = leafEnv21943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21943 rootObs == leafEnv21943) = true)

theorem terminalChecked21943 : H12PackedTerminal.terminalCheckFast leafEnv21943 active21943 tree21943 = true := by decide +kernel

def env21944 : List Nat := [2,4,8,16,1,16,9,256,0,273,1,0,8,0,261,262,0,260,272,260,1,0,17,262,9,17,0,0,0,261,21,261,257,1,0,0]

theorem envBound21944 : H12AffineFastState.Bounded env21944 := by
  intro p hp
  have h : env21944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21942_21944 : H12AffineEnvironment.transform 6 9 env21942 = env21944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21942 == env21944) = true)

theorem identity21944 : scanCanonicalize (H12AffineFastState.compose env21944 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound21944 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env21945 : List Nat := [2,4,8,16,1,16,9,4,0,21,1,0,8,0,1,2,0,0,20,0,1,0,17,2,9,17,0,0,0,1,21,1,5,1,0,0]

theorem envBound21945 : H12AffineFastState.Bounded env21945 := by
  intro p hp
  have h : env21945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21944_21945 : H12AffineEnvironment.transform 7 4 env21944 = env21945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env21944 == env21945) = true)

def leafEnv21945 : List Nat := [2,4,8,16,1,16,9,4,0,21,1,0,8,0,1,2,0,0,20,0,1,0,17,2,20,9,1,17,0,0,0,1,21,1,5,1,5,2,0,0,0,1,1]

def active21945 : List Nat := [0,1,2,3]

def tree21945 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21945 : H12WitnessSearch.Good tree21945 := H12GlobalWitnessIndex.good

theorem leafIdentity21945 : H12AffineFastState.composeSystem env21945 rootObs = leafEnv21945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21945 rootObs == leafEnv21945) = true)

theorem terminalChecked21945 : H12PackedTerminal.terminalCheckFast leafEnv21945 active21945 tree21945 = true := by decide +kernel

def env21946 : List Nat := [2,4,8,16,32,16,128,256,1,273,33,0,129,0,260,399,0,397,272,261,1,169,17,398,9,17,32,0,0,396,21,292,257,169,0,1]

theorem envBound21946 : H12AffineFastState.Bounded env21946 := by
  intro p hp
  have h : env21946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21937_21946 : H12AffineEnvironment.transform 8 1 env21937 = env21946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env21937 == env21946) = true)

def env21947 : List Nat := [2,4,8,16,0,16,128,256,1,273,1,0,129,0,260,399,0,397,272,261,1,137,17,398,9,17,0,0,0,396,21,260,257,137,0,1]

theorem envBound21947 : H12AffineFastState.Bounded env21947 := by
  intro p hp
  have h : env21947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21946_21947 : H12AffineEnvironment.transform 4 0 env21946 = env21947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21946 == env21947) = true)

theorem identity21947 : scanCanonicalize (H12AffineFastState.compose env21947 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound21947 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21948 : List Nat := [2,4,8,16,0,16,128,140,1,157,1,0,129,0,136,3,0,1,156,137,1,137,17,2,9,17,0,0,0,0,21,136,141,137,0,1]

theorem envBound21948 : H12AffineFastState.Bounded env21948 := by
  intro p hp
  have h : env21948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21947_21948 : H12AffineEnvironment.transform 7 140 env21947 = env21948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env21947 == env21948) = true)

theorem identity21948 : scanCanonicalize (H12AffineFastState.compose env21948 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound21948 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env21949 : List Nat := [2,4,8,16,0,16,9,5,1,20,1,0,8,0,1,3,0,1,21,0,1,0,17,2,9,17,0,0,0,0,21,1,4,0,0,1]

theorem envBound21949 : H12AffineFastState.Bounded env21949 := by
  intro p hp
  have h : env21949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21948_21949 : H12AffineEnvironment.transform 6 9 env21948 = env21949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21948 == env21949) = true)

def leafEnv21949 : List Nat := [2,4,8,16,0,16,9,5,1,20,1,0,8,0,1,3,0,1,21,0,1,0,17,2,20,9,1,17,0,0,0,0,21,1,4,0,5,3,0,1,0,1,1]

def active21949 : List Nat := [0,1,2,3]

def tree21949 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21949 : H12WitnessSearch.Good tree21949 := H12GlobalWitnessIndex.good

theorem leafIdentity21949 : H12AffineFastState.composeSystem env21949 rootObs = leafEnv21949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21949 rootObs == leafEnv21949) = true)

theorem terminalChecked21949 : H12PackedTerminal.terminalCheckFast leafEnv21949 active21949 tree21949 = true := by decide +kernel

def env21950 : List Nat := [2,4,8,16,1,16,128,256,1,273,0,0,129,0,260,399,0,397,272,261,1,136,17,398,9,17,1,0,0,396,21,261,257,136,0,1]

theorem envBound21950 : H12AffineFastState.Bounded env21950 := by
  intro p hp
  have h : env21950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21946_21950 : H12AffineEnvironment.transform 4 1 env21946 = env21950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21946 == env21950) = true)

theorem identity21950 : scanCanonicalize (H12AffineFastState.compose env21950 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound21950 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21951 : List Nat := [2,4,8,16,1,16,128,4,1,21,0,0,129,0,0,139,0,137,20,1,1,136,17,138,9,17,1,0,0,136,21,1,5,136,0,1]

theorem envBound21951 : H12AffineFastState.Bounded env21951 := by
  intro p hp
  have h : env21951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21950_21951 : H12AffineEnvironment.transform 7 4 env21950 = env21951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env21950 == env21951) = true)

theorem identity21951 : scanCanonicalize (H12AffineFastState.compose env21951 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound21951 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env21952 : List Nat := [2,4,8,16,1,16,9,4,1,21,0,0,8,0,0,2,0,0,20,1,1,1,17,3,9,17,1,0,0,1,21,1,5,1,0,1]

theorem envBound21952 : H12AffineFastState.Bounded env21952 := by
  intro p hp
  have h : env21952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21951_21952 : H12AffineEnvironment.transform 6 9 env21951 = env21952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21951 == env21952) = true)

def leafEnv21952 : List Nat := [2,4,8,16,1,16,9,4,1,21,0,0,8,0,0,2,0,0,20,1,1,1,17,3,20,9,1,17,1,0,0,1,21,1,5,1,5,3,0,1,0,1,1]

def active21952 : List Nat := [0,1,2,3]

def tree21952 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21952 : H12WitnessSearch.Good tree21952 := H12GlobalWitnessIndex.good

theorem leafIdentity21952 : H12AffineFastState.composeSystem env21952 rootObs = leafEnv21952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21952 rootObs == leafEnv21952) = true)

theorem terminalChecked21952 : H12PackedTerminal.terminalCheckFast leafEnv21952 active21952 tree21952 = true := by decide +kernel

def env21953 : List Nat := [2,4,8,16,32,16,128,256,512,273,545,0,128,0,772,398,0,396,272,773,1,680,17,911,8,17,544,0,0,397,21,292,257,169,0,512]

theorem envBound21953 : H12AffineFastState.Bounded env21953 := by
  intro p hp
  have h : env21953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21936_21953 : H12AffineEnvironment.transform 10 545 env21936 = env21953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 545 env21936 == env21953) = true)

theorem identity21953 : scanCanonicalize (H12AffineFastState.compose env21953 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound21953 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env21954 : List Nat := [2,4,8,16,32,16,128,256,260,273,293,0,128,0,0,398,0,396,272,1,1,428,17,139,8,17,292,0,0,397,21,292,257,169,0,260]

theorem envBound21954 : H12AffineFastState.Bounded env21954 := by
  intro p hp
  have h : env21954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21953_21954 : H12AffineEnvironment.transform 8 260 env21953 = env21954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env21953 == env21954) = true)

def env21955 : List Nat := [2,4,8,16,0,16,128,256,260,273,261,0,128,0,0,398,0,396,272,1,1,396,17,139,8,17,260,0,0,397,21,260,257,137,0,260]

theorem envBound21955 : H12AffineFastState.Bounded env21955 := by
  intro p hp
  have h : env21955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21954_21955 : H12AffineEnvironment.transform 4 0 env21954 = env21955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21954 == env21955) = true)

theorem identity21955 : scanCanonicalize (H12AffineFastState.compose env21955 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound21955 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21956 : List Nat := [2,4,8,16,0,16,9,256,260,273,261,0,9,0,0,263,0,261,272,1,1,261,17,2,8,17,260,0,0,260,21,260,257,0,0,260]

theorem envBound21956 : H12AffineFastState.Bounded env21956 := by
  intro p hp
  have h : env21956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21955_21956 : H12AffineEnvironment.transform 6 9 env21955 = env21956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env21955 == env21956) = true)

def leafEnv21956 : List Nat := [2,4,8,16,0,16,9,256,260,273,261,0,9,0,0,263,0,261,272,1,1,261,17,2,20,8,1,17,260,0,0,260,21,260,257,0,5,263,0,260,0,1,1]

def active21956 : List Nat := [0,1,2,3,7]

def tree21956 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21956 : H12WitnessSearch.Good tree21956 := H12GlobalWitnessIndex.good

theorem leafIdentity21956 : H12AffineFastState.composeSystem env21956 rootObs = leafEnv21956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21956 rootObs == leafEnv21956) = true)

theorem terminalChecked21956 : H12PackedTerminal.terminalCheckFast leafEnv21956 active21956 tree21956 = true := by decide +kernel

def env21957 : List Nat := [2,4,8,16,1,16,128,256,260,273,260,0,128,0,0,398,0,396,272,1,1,397,17,139,8,17,261,0,0,397,21,261,257,136,0,260]

theorem envBound21957 : H12AffineFastState.Bounded env21957 := by
  intro p hp
  have h : env21957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21954_21957 : H12AffineEnvironment.transform 4 1 env21954 = env21957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21954 == env21957) = true)

theorem identity21957 : scanCanonicalize (H12AffineFastState.compose env21957 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound21957 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21958 : List Nat := [2,4,8,16,1,16,128,4,0,21,0,0,128,0,0,138,0,136,20,1,1,137,17,139,8,17,1,0,0,137,21,1,5,136,0,0]

theorem envBound21958 : H12AffineFastState.Bounded env21958 := by
  intro p hp
  have h : env21958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21957_21958 : H12AffineEnvironment.transform 7 4 env21957 = env21958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env21957 == env21958) = true)

def leafEnv21958 : List Nat := [2,4,8,16,1,16,128,4,0,21,0,0,128,0,0,138,0,136,20,1,1,137,17,139,20,8,1,17,1,0,0,137,21,1,5,136,5,3,0,0,0,1,1]

def active21958 : List Nat := [0,1,2,3,6]

def tree21958 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood21958 : H12WitnessSearch.Good tree21958 := H12GlobalWitnessIndex.good

theorem leafIdentity21958 : H12AffineFastState.composeSystem env21958 rootObs = leafEnv21958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env21958 rootObs == leafEnv21958) = true)

theorem terminalChecked21958 : H12PackedTerminal.terminalCheckFast leafEnv21958 active21958 tree21958 = true := by decide +kernel

def env21959 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,2340,65536,1297,8460,1024,2341,4097,10249,5377,67617,8328,5376,2048,4097,1297,8460,1284,4294967296,257,4295041154,1297,512]

theorem envBound21959 : H12AffineFastState.Bounded env21959 := by
  intro p hp
  have h : env21959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21898_21959 : H12AffineEnvironment.transform 13 4097 env21898 = env21959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4097 env21898 == env21959) = true)

theorem identity21959 : scanCanonicalize (H12AffineFastState.compose env21959 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 7196) := by decide +kernel

theorem selectedBound21959 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env21960 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,7196,4097,2340,65536,1297,7440,1024,2341,4097,5141,5377,67617,7316,5376,2048,4097,1297,7440,1284,4294967296,257,4295040158,1297,512]

theorem envBound21960 : H12AffineFastState.Bounded env21960 := by
  intro p hp
  have h : env21960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21959_21960 : H12AffineEnvironment.transform 12 7196 env21959 = env21960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7196 env21959 == env21960) = true)

theorem identity21960 : scanCanonicalize (H12AffineFastState.compose env21960 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 428) := by decide +kernel

theorem selectedBound21960 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21961 : List Nat := [2,4,8,16,32,16,128,256,428,1024,2048,4096,7196,4097,2340,65536,1297,7440,1024,2341,4097,5141,5377,67617,7316,5376,2048,4097,1297,7440,1284,4294967296,257,4295040158,1297,428]

theorem envBound21961 : H12AffineFastState.Bounded env21961 := by
  intro p hp
  have h : env21961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21960_21961 : H12AffineEnvironment.transform 8 428 env21960 = env21961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 428 env21960 == env21961) = true)

theorem identity21961 : scanCanonicalize (H12AffineFastState.compose env21961 (packedSelected [5,8] rootPS)) = affineNative (2^(15+1) ^^^ 2447) := by decide +kernel

theorem selectedBound21961 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env21962 : List Nat := [2,4,8,16,32,16,128,256,428,1024,2048,4096,7196,4097,2340,2447,1297,7440,1024,2341,4097,5141,5377,430,7316,5376,2048,4097,1297,7440,1284,4294967296,257,4294972689,1297,428]

theorem envBound21962 : H12AffineFastState.Bounded env21962 := by
  intro p hp
  have h : env21962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21961_21962 : H12AffineEnvironment.transform 15 2447 env21961 = env21962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2447 env21961 == env21962) = true)

def env21963 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,1296,262144,21505,32769,4097,4194304,17664,98565,8328,5377,4477189,16384,1296,1073741824,1284,4294967296,257,4299260335,1297,512]

theorem envBound21963 : H12AffineFastState.Bounded env21963 := by
  intro p hp
  have h : env21963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21879_21963 : H12AffineEnvironment.transform 5 17 env21879 = env21963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21879 == env21963) = true)

theorem identity21963 : scanCanonicalize (H12AffineFastState.compose env21963 (packedSelected [3,8,12,15,17,19,21] rootPS)) = affineNative (2^(31+1) ^^^ 1073806245) := by decide +kernel

theorem selectedBound21963 : packedSelected [3,8,12,15,17,19,21] rootPS < 2^1333 := by decide +kernel

def env21964 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,1296,262144,21505,32769,4097,4194304,17664,98565,8328,5377,4477189,16384,1296,1073741824,1284,1073806245,257,1078032906,1297,512]

theorem envBound21964 : H12AffineFastState.Bounded env21964 := by
  intro p hp
  have h : env21964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21963_21964 : H12AffineEnvironment.transform 31 1073806245 env21963 = env21964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1073806245 env21963 == env21964) = true)

theorem identity21964 : scanCanonicalize (H12AffineFastState.compose env21964 (packedSelected [9,22] rootPS)) = affineNative (2^(13+1) ^^^ 4096) := by decide +kernel

theorem selectedBound21964 : packedSelected [9,22] rootPS < 2^1333 := by decide +kernel

def env21965 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,65536,1296,262144,1025,32769,4097,4194304,5376,98565,8328,5377,4456709,4096,1296,1073741824,1284,1073785765,257,1078012426,1297,512]

theorem envBound21965 : H12AffineFastState.Bounded env21965 := by
  intro p hp
  have h : env21965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21964_21965 : H12AffineEnvironment.transform 13 4096 env21964 = env21965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env21964 == env21965) = true)

theorem identity21965 : scanCanonicalize (H12AffineFastState.compose env21965 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(29+1) ^^^ 4227617) := by decide +kernel

theorem selectedBound21965 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env21966 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,65536,1296,262144,1025,32769,4097,4194304,5376,98565,8328,5377,4456709,4096,1296,4227617,1284,4204932,257,108587,1297,512]

theorem envBound21966 : H12AffineFastState.Bounded env21966 := by
  intro p hp
  have h : env21966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21965_21966 : H12AffineEnvironment.transform 29 4227617 env21965 = env21966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4227617 env21965 == env21966) = true)

theorem identity21966 : scanCanonicalize (H12AffineFastState.compose env21966 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(21+1) ^^^ 772) := by decide +kernel

theorem selectedBound21966 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env21967 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,32768,65536,1296,262144,1025,32769,4097,772,5376,98565,8328,5377,262657,4096,1296,33061,1284,10880,257,108587,1297,512]

theorem envBound21967 : H12AffineFastState.Bounded env21967 := by
  intro p hp
  have h : env21967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21966_21967 : H12AffineEnvironment.transform 21 772 env21966 = env21967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 772 env21966 == env21967) = true)

theorem identity21967 : scanCanonicalize (H12AffineFastState.compose env21967 (packedSelected [1,3,5,12,13,24] rootPS)) = affineNative (2^(14+1) ^^^ 8581) := by decide +kernel

theorem selectedBound21967 : packedSelected [1,3,5,12,13,24] rootPS < 2^1333 := by decide +kernel

def env21968 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,8581,65536,1296,262144,1025,8580,4097,772,5376,73856,8328,5377,262657,4096,1296,8352,1284,10880,257,68014,1297,512]

theorem envBound21968 : H12AffineFastState.Bounded env21968 := by
  intro p hp
  have h : env21968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21967_21968 : H12AffineEnvironment.transform 14 8581 env21967 = env21968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8581 env21967 == env21968) = true)

theorem identity21968 : scanCanonicalize (H12AffineFastState.compose env21968 (packedSelected [8,12,13,28] rootPS)) = affineNative (2^(17+1) ^^^ 8972) := by decide +kernel

theorem selectedBound21968 : packedSelected [8,12,13,28] rootPS < 2^1333 := by decide +kernel

def env21969 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,8581,65536,1296,8972,1025,8580,4097,772,5376,73856,8328,5377,8461,4096,1296,8352,1284,10880,257,68014,1297,512]

theorem envBound21969 : H12AffineFastState.Bounded env21969 := by
  intro p hp
  have h : env21969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21968_21969 : H12AffineEnvironment.transform 17 8972 env21968 = env21969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8972 env21968 == env21969) = true)

theorem identity21969 : scanCanonicalize (H12AffineFastState.compose env21969 (packedSelected [3,8,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound21969 : packedSelected [3,8,10,12] rootPS < 2^1333 := by decide +kernel

def env21970 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4096,8581,8203,1296,8972,1025,8580,4097,772,5376,139,8328,5377,8461,4096,1296,8352,1284,10880,257,10661,1297,512]

theorem envBound21970 : H12AffineFastState.Bounded env21970 := by
  intro p hp
  have h : env21970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21969_21970 : H12AffineEnvironment.transform 15 8203 env21969 = env21970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env21969 == env21970) = true)

def env21971 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,8914001,134217728,8519745,2769921,1073741824,27513920,4294967296,10637632,4315938986,164610305,512]

theorem envBound21971 : H12AffineFastState.Bounded env21971 := by
  intro p hp
  have h : env21971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21101_21971 : H12AffineEnvironment.transform 28 2769921 env21101 = env21971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 2769921 env21101 == env21971) = true)

def env21972 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,4194304,8388608,16777216,8328,8914001,134217728,8519745,676865,1073741824,25412672,4294967296,8536384,4315938986,164610305,512]

theorem envBound21972 : H12AffineFastState.Bounded env21972 := by
  intro p hp
  have h : env21972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21971_21972 : H12AffineEnvironment.transform 20 4096 env21971 = env21972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env21971 == env21972) = true)

theorem identity21972 : scanCanonicalize (H12AffineFastState.compose env21972 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 660496) := by decide +kernel

theorem selectedBound21972 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env21973 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,4194304,660496,16777216,8328,135233,134217728,529489,676865,1073741824,17420368,4294967296,546128,4315938986,155571473,512]

theorem envBound21973 : H12AffineFastState.Bounded env21973 := by
  intro p hp
  have h : env21973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21972_21973 : H12AffineEnvironment.transform 22 660496 env21972 = env21973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 660496 env21972 == env21973) = true)

def env21974 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,524288,32769,4096,4194304,660496,16777216,8328,135233,134217728,529489,656465,1073741824,17399808,4294967296,525568,4315938986,155551041,512]

theorem envBound21974 : H12AffineFastState.Bounded env21974 := by
  intro p hp
  have h : env21974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21973_21974 : H12AffineEnvironment.transform 13 4176 env21973 = env21974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env21973 == env21974) = true)

def env21975 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1024,32769,4096,4194304,135184,16777216,8328,135233,134217728,4177,131153,1073741824,16876544,4294967296,256,4315938986,155551041,512]

theorem envBound21975 : H12AffineFastState.Bounded env21975 := by
  intro p hp
  have h : env21975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21974_21975 : H12AffineEnvironment.transform 18 1024 env21974 = env21975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env21974 == env21975) = true)

def env21976 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1024,32769,4096,4194304,135184,16777216,8328,135233,21331968,4177,131153,1073741824,16876544,4294967296,256,4315938986,1345,512]

theorem envBound21976 : H12AffineFastState.Bounded env21976 := by
  intro p hp
  have h : env21976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21975_21976 : H12AffineEnvironment.transform 26 21331968 env21975 = env21976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21331968 env21975 == env21976) = true)

theorem identity21976 : scanCanonicalize (H12AffineFastState.compose env21976 (packedSelected [7,20,27] rootPS)) = affineNative (2^(16+1) ^^^ 1345) := by decide +kernel

theorem selectedBound21976 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env21977 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,1345,262144,1024,32769,4096,4194304,5457,16777216,8328,5376,21331968,4177,1296,1073741824,16876544,4294967296,256,4315938986,1345,512]

theorem envBound21977 : H12AffineFastState.Bounded env21977 := by
  intro p hp
  have h : env21977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21976_21977 : H12AffineEnvironment.transform 16 1345 env21976 = env21977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env21976 == env21977) = true)

def env21978 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,65536,1345,262144,1024,32769,1344,4194304,17,16777216,8328,64,21331968,1297,1296,1073741824,16876544,4294967296,256,4315938986,1345,512]

theorem envBound21978 : H12AffineFastState.Bounded env21978 := by
  intro p hp
  have h : env21978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21977_21978 : H12AffineEnvironment.transform 11 1344 env21977 = env21978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env21977 == env21978) = true)

theorem identity21978 : scanCanonicalize (H12AffineFastState.compose env21978 (packedSelected [0,7,20] rootPS)) = affineNative (2^(23+1) ^^^ 98565) := by decide +kernel

theorem selectedBound21978 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env21979 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,65536,1345,262144,1024,32769,1344,4194304,17,98565,8328,64,4456709,1297,1296,1073741824,1285,4294967296,256,4299260335,1345,512]

theorem envBound21979 : H12AffineFastState.Bounded env21979 := by
  intro p hp
  have h : env21979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21978_21979 : H12AffineEnvironment.transform 23 98565 env21978 = env21979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98565 env21978 == env21979) = true)

theorem identity21979 : scanCanonicalize (H12AffineFastState.compose env21979 (packedSelected [3,5,10] rootPS)) = affineNative (2^(31+1) ^^^ 1073842179) := by decide +kernel

theorem selectedBound21979 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env21980 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,65536,1345,262144,1024,32769,1344,4194304,17,98565,8328,64,4456709,1297,1296,1073741824,1285,1073842179,256,1077938604,1345,512]

theorem envBound21980 : H12AffineFastState.Bounded env21980 := by
  intro p hp
  have h : env21980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21979_21980 : H12AffineEnvironment.transform 31 1073842179 env21979 = env21980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1073842179 env21979 == env21980) = true)

theorem identity21980 : scanCanonicalize (H12AffineFastState.compose env21980 (packedSelected [1,12,13] rootPS)) = affineNative (2^(21+1) ^^^ 305824) := by decide +kernel

theorem selectedBound21980 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env21981 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,65536,1345,262144,1024,32769,1344,305824,17,98565,8328,64,43941,1297,1296,1073741824,1285,1073842179,256,1074045708,1345,512]

theorem envBound21981 : H12AffineFastState.Bounded env21981 := by
  intro p hp
  have h : env21981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21980_21981 : H12AffineEnvironment.transform 21 305824 env21980 = env21981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 305824 env21980 == env21981) = true)

theorem identity21981 : scanCanonicalize (H12AffineFastState.compose env21981 (packedSelected [3,15,17] rootPS)) = affineNative (2^(29+1) ^^^ 303404) := by decide +kernel

theorem selectedBound21981 : packedSelected [3,15,17] rootPS < 2^1333 := by decide +kernel

def env21982 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,65536,1345,262144,1024,32769,1344,305824,17,98565,8328,64,43941,1297,1296,303404,1285,338223,256,544,1345,512]

theorem envBound21982 : H12AffineFastState.Bounded env21982 := by
  intro p hp
  have h : env21982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21981_21982 : H12AffineEnvironment.transform 29 303404 env21981 = env21982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 303404 env21981 == env21982) = true)

theorem identity21982 : scanCanonicalize (H12AffineFastState.compose env21982 (packedSelected [3,5,24] rootPS)) = affineNative (2^(17+1) ^^^ 43681) := by decide +kernel

theorem selectedBound21982 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env21983 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,65536,1345,43681,1024,32769,1344,1,17,98565,8328,64,43941,1297,1296,2957,1285,99214,256,544,1345,512]

theorem envBound21983 : H12AffineFastState.Bounded env21983 := by
  intro p hp
  have h : env21983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21982_21983 : H12AffineEnvironment.transform 17 43681 env21982 = env21983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43681 env21982 == env21983) = true)

theorem identity21983 : scanCanonicalize (H12AffineFastState.compose env21983 (packedSelected [5,12,15] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound21983 : packedSelected [5,12,15] rootPS < 2^1333 := by decide +kernel

def env21984 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1344,8192,1296,32768,65536,1345,43048,1024,32769,1344,1,17,98565,8328,64,43308,1297,1296,2308,1285,98567,256,169,1345,137]

theorem envBound21984 : H12AffineFastState.Bounded env21984 := by
  intro p hp
  have h : env21984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21983_21984 : H12AffineEnvironment.transform 8 137 env21983 = env21984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env21983 == env21984) = true)

def env21985 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,8192,1296,32768,65536,1297,43048,1024,32769,1296,1,17,98565,8328,16,43308,1297,1296,2308,1285,98567,256,169,1297,137]

theorem envBound21985 : H12AffineFastState.Bounded env21985 := by
  intro p hp
  have h : env21985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21984_21985 : H12AffineEnvironment.transform 5 16 env21984 = env21985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env21984 == env21985) = true)

theorem identity21985 : scanCanonicalize (H12AffineFastState.compose env21985 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 8615) := by decide +kernel

theorem selectedBound21985 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21986 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,8192,1296,32768,8615,1297,43048,1024,32769,1296,1,17,41122,8328,16,43308,1297,1296,2308,1285,41120,256,169,1297,137]

theorem envBound21986 : H12AffineFastState.Bounded env21986 := by
  intro p hp
  have h : env21986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21985_21986 : H12AffineEnvironment.transform 15 8615 env21985 = env21986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8615 env21985 == env21986) = true)

theorem identity21986 : scanCanonicalize (H12AffineFastState.compose env21986 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound21986 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env21987 : List Nat := [2,4,8,16,32,16,128,4,137,1024,2048,1044,8192,1044,32768,8355,1045,43048,1024,32769,1044,1,17,41122,8328,16,43048,1045,1044,2048,1025,41120,4,169,1045,137]

theorem envBound21987 : H12AffineFastState.Bounded env21987 := by
  intro p hp
  have h : env21987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21986_21987 : H12AffineEnvironment.transform 7 4 env21986 = env21987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env21986 == env21987) = true)

theorem identity21987 : scanCanonicalize (H12AffineFastState.compose env21987 (packedSelected [0,6] rootPS)) = affineNative (2^(14+1) ^^^ 2080) := by decide +kernel

theorem selectedBound21987 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env21988 : List Nat := [2,4,8,16,32,16,128,4,137,1024,2048,1044,8192,1044,2080,8355,1045,8200,1024,2081,1044,1,17,10370,8328,16,8200,1045,1044,2048,1025,10368,4,169,1045,137]

theorem envBound21988 : H12AffineFastState.Bounded env21988 := by
  intro p hp
  have h : env21988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21987_21988 : H12AffineEnvironment.transform 14 2080 env21987 = env21988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2080 env21987 == env21988) = true)

theorem identity21988 : scanCanonicalize (H12AffineFastState.compose env21988 (packedSelected [2,4] rootPS)) = affineNative (2^(12+1) ^^^ 2056) := by decide +kernel

theorem selectedBound21988 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env21989 : List Nat := [2,4,8,16,32,16,128,4,137,1024,2048,1044,2056,1044,2080,2219,1045,2048,1024,2081,1044,1,17,138,2176,16,2048,1045,1044,2048,1025,136,4,169,1045,137]

theorem envBound21989 : H12AffineFastState.Bounded env21989 := by
  intro p hp
  have h : env21989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21988_21989 : H12AffineEnvironment.transform 12 2056 env21988 = env21989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2056 env21988 == env21989) = true)

theorem identity21989 : scanCanonicalize (H12AffineFastState.compose env21989 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1212) := by decide +kernel

theorem selectedBound21989 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21990 : List Nat := [2,4,8,16,32,16,128,4,137,1024,1212,1044,1204,1044,1180,1047,1045,1212,1024,1181,1044,1,17,138,1084,16,1212,1045,1044,1212,1025,136,4,169,1045,137]

theorem envBound21990 : H12AffineFastState.Bounded env21990 := by
  intro p hp
  have h : env21990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21989_21990 : H12AffineEnvironment.transform 10 1212 env21989 = env21990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1212 env21989 == env21990) = true)

def env21991 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1297,8192,1296,32768,65536,1296,43048,1024,32769,1297,1,17,98565,8328,17,43308,1297,1296,2308,1285,98567,256,169,1296,137]

theorem envBound21991 : H12AffineFastState.Bounded env21991 := by
  intro p hp
  have h : env21991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21984_21991 : H12AffineEnvironment.transform 5 17 env21984 = env21991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env21984 == env21991) = true)

theorem identity21991 : scanCanonicalize (H12AffineFastState.compose env21991 (packedSelected [1,3] rootPS)) = affineNative (2^(14+1) ^^^ 8493) := by decide +kernel

theorem selectedBound21991 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env21992 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1297,8192,1296,8493,65536,1296,2309,1024,8492,1297,1,17,73768,8328,17,2049,1297,1296,2308,1285,73770,256,169,1296,137]

theorem envBound21992 : H12AffineFastState.Bounded env21992 := by
  intro p hp
  have h : env21992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21991_21992 : H12AffineEnvironment.transform 14 8493 env21991 = env21992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8493 env21991 == env21992) = true)

def env21993 : List Nat := [2,4,8,16,32,17,128,256,137,272,2048,1,8192,0,8493,65536,0,2309,272,8492,1,1,17,73768,8328,17,2049,1,0,2308,21,73770,256,169,0,137]

theorem envBound21993 : H12AffineFastState.Bounded env21993 := by
  intro p hp
  have h : env21993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21992_21993 : H12AffineEnvironment.transform 9 272 env21992 = env21993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env21992 == env21993) = true)

theorem identity21993 : scanCanonicalize (H12AffineFastState.compose env21993 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 301) := by decide +kernel

theorem selectedBound21993 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env21994 : List Nat := [2,4,8,16,32,17,128,256,137,272,2048,1,301,0,0,65536,0,2309,272,1,1,1,17,65797,421,17,2049,1,0,2308,21,65799,256,169,0,137]

theorem envBound21994 : H12AffineFastState.Bounded env21994 := by
  intro p hp
  have h : env21994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21993_21994 : H12AffineEnvironment.transform 12 301 env21993 = env21994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 301 env21993 == env21994) = true)

def env21995 : List Nat := [2,4,8,16,0,17,128,256,137,272,2048,1,269,0,0,65536,0,2309,272,1,1,1,17,65797,389,17,2049,1,0,2308,21,65799,256,137,0,137]

theorem envBound21995 : H12AffineFastState.Bounded env21995 := by
  intro p hp
  have h : env21995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21994_21995 : H12AffineEnvironment.transform 4 0 env21994 = env21995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env21994 == env21995) = true)

def env21996 : List Nat := [2,4,8,16,1,17,128,256,137,272,2048,1,268,0,0,65536,0,2309,272,1,1,1,17,65797,388,17,2049,1,0,2308,21,65799,256,136,0,137]

theorem envBound21996 : H12AffineFastState.Bounded env21996 := by
  intro p hp
  have h : env21996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21994_21996 : H12AffineEnvironment.transform 4 1 env21994 = env21996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env21994 == env21996) = true)

theorem identity21996 : scanCanonicalize (H12AffineFastState.compose env21996 (packedSelected [0,4] rootPS)) = affineNative (2^(15+1) ^^^ 398) := by decide +kernel

theorem selectedBound21996 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env21997 : List Nat := [2,4,8,16,1,17,128,256,137,272,2048,1,268,0,0,398,0,2309,272,1,1,1,17,139,388,17,2049,1,0,2308,21,137,256,136,0,137]

theorem envBound21997 : H12AffineFastState.Bounded env21997 := by
  intro p hp
  have h : env21997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21996_21997 : H12AffineEnvironment.transform 15 398 env21996 = env21997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 398 env21996 == env21997) = true)

theorem identity21997 : scanCanonicalize (H12AffineFastState.compose env21997 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound21997 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env21998 : List Nat := [2,4,8,16,1,17,24,256,17,272,2048,1,268,0,0,278,0,2309,272,1,1,1,17,19,284,17,2049,1,0,2308,21,17,256,16,0,17]

theorem envBound21998 : H12AffineFastState.Bounded env21998 := by
  intro p hp
  have h : env21998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21997_21998 : H12AffineEnvironment.transform 6 24 env21997 = env21998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env21997 == env21998) = true)

def env21999 : List Nat := [2,4,8,16,1,17,24,256,17,272,0,1,268,0,0,278,0,261,272,1,1,1,17,19,284,17,1,1,0,260,21,17,256,16,0,17]

theorem envBound21999 : H12AffineFastState.Bounded env21999 := by
  intro p hp
  have h : env21999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21998_21999 : H12AffineEnvironment.transform 10 0 env21998 = env21999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env21998 == env21999) = true)

theorem identity21999 : scanCanonicalize (H12AffineFastState.compose env21999 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound21999 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22000 : List Nat := [2,4,8,16,1,17,24,5,17,21,0,1,9,0,0,19,0,0,21,1,1,1,17,19,25,17,1,1,0,1,21,17,5,16,0,17]

theorem envBound22000 : H12AffineFastState.Bounded env22000 := by
  intro p hp
  have h : env22000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21999_22000 : H12AffineEnvironment.transform 7 5 env21999 = env22000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env21999 == env22000) = true)

def leafEnv22000 : List Nat := [2,4,8,16,1,17,24,5,17,21,0,1,9,0,0,19,0,0,21,1,1,1,17,19,20,25,1,17,1,1,0,1,21,17,5,16,5,2,0,17,0,1,1]

def active22000 : List Nat := [0,1,2,3]

def tree22000 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22000 : H12WitnessSearch.Good tree22000 := H12GlobalWitnessIndex.good

theorem leafIdentity22000 : H12AffineFastState.composeSystem env22000 rootObs = leafEnv22000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22000 rootObs == leafEnv22000) = true)

theorem terminalChecked22000 : H12PackedTerminal.terminalCheckFast leafEnv22000 active22000 tree22000 = true := by decide +kernel

def env22001 : List Nat := [2,4,8,16,1,17,24,256,17,272,1,1,268,0,0,278,0,260,272,1,1,1,17,19,284,17,0,1,0,261,21,17,256,16,0,17]

theorem envBound22001 : H12AffineFastState.Bounded env22001 := by
  intro p hp
  have h : env22001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21998_22001 : H12AffineEnvironment.transform 10 1 env21998 = env22001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env21998 == env22001) = true)

def leafEnv22001 : List Nat := [2,4,8,16,1,17,24,256,17,272,1,1,268,0,0,278,0,260,272,1,1,1,17,19,20,284,1,17,0,1,0,261,21,17,256,16,5,263,0,17,0,1,1]

def active22001 : List Nat := [0,1,2,3,7]

def tree22001 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22001 : H12WitnessSearch.Good tree22001 := H12GlobalWitnessIndex.good

theorem leafIdentity22001 : H12AffineFastState.composeSystem env22001 rootObs = leafEnv22001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22001 rootObs == leafEnv22001) = true)

theorem terminalChecked22001 : H12PackedTerminal.terminalCheckFast leafEnv22001 active22001 tree22001 = true := by decide +kernel

def env22002 : List Nat := [2,4,8,16,32,17,128,256,137,273,2048,0,8192,1,8493,65536,1,2309,273,8492,0,1,17,73768,8328,17,2049,0,1,2308,20,73770,256,169,1,137]

theorem envBound22002 : H12AffineFastState.Bounded env22002 := by
  intro p hp
  have h : env22002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21992_22002 : H12AffineEnvironment.transform 9 273 env21992 = env22002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env21992 == env22002) = true)

theorem identity22002 : scanCanonicalize (H12AffineFastState.compose env22002 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 398) := by decide +kernel

theorem selectedBound22002 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22003 : List Nat := [2,4,8,16,32,17,128,256,137,273,2048,0,8192,1,8493,398,1,2309,273,8492,0,1,17,8614,8328,17,2049,0,1,2308,20,8612,256,169,1,137]

theorem envBound22003 : H12AffineFastState.Bounded env22003 := by
  intro p hp
  have h : env22003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22002_22003 : H12AffineEnvironment.transform 15 398 env22002 = env22003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 398 env22002 == env22003) = true)

def env22004 : List Nat := [2,4,8,16,0,17,128,256,137,273,2048,0,8192,1,8461,398,1,2309,273,8460,0,1,17,8582,8328,17,2049,0,1,2308,20,8580,256,137,1,137]

theorem envBound22004 : H12AffineFastState.Bounded env22004 := by
  intro p hp
  have h : env22004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22003_22004 : H12AffineEnvironment.transform 4 0 env22003 = env22004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22003 == env22004) = true)

theorem identity22004 : scanCanonicalize (H12AffineFastState.compose env22004 (packedSelected [0,4] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound22004 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env22005 : List Nat := [2,4,8,16,0,17,128,256,137,273,2048,0,269,1,0,398,1,2309,273,1,0,1,17,139,389,17,2049,0,1,2308,20,137,256,137,1,137]

theorem envBound22005 : H12AffineFastState.Bounded env22005 := by
  intro p hp
  have h : env22005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22004_22005 : H12AffineEnvironment.transform 12 269 env22004 = env22005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env22004 == env22005) = true)

theorem identity22005 : scanCanonicalize (H12AffineFastState.compose env22005 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound22005 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22006 : List Nat := [2,4,8,16,0,17,128,20,137,5,2048,0,25,1,0,154,1,2065,5,1,0,1,17,139,145,17,2049,0,1,2064,20,137,20,137,1,137]

theorem envBound22006 : H12AffineFastState.Bounded env22006 := by
  intro p hp
  have h : env22006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22005_22006 : H12AffineEnvironment.transform 7 20 env22005 = env22006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env22005 == env22006) = true)

def env22007 : List Nat := [2,4,8,16,0,17,128,20,137,5,0,0,25,1,0,154,1,17,5,1,0,1,17,139,145,17,1,0,1,16,20,137,20,137,1,137]

theorem envBound22007 : H12AffineFastState.Bounded env22007 := by
  intro p hp
  have h : env22007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22006_22007 : H12AffineEnvironment.transform 10 0 env22006 = env22007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env22006 == env22007) = true)

def leafEnv22007 : List Nat := [2,4,8,16,0,17,128,20,137,5,0,0,25,1,0,154,1,17,5,1,0,1,17,139,21,145,1,17,1,0,1,16,20,137,20,137,5,19,1,137,0,0,1]

def active22007 : List Nat := [0,1,2,3,6]

def tree22007 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22007 : H12WitnessSearch.Good tree22007 := H12GlobalWitnessIndex.good

theorem leafIdentity22007 : H12AffineFastState.composeSystem env22007 rootObs = leafEnv22007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22007 rootObs == leafEnv22007) = true)

theorem terminalChecked22007 : H12PackedTerminal.terminalCheckFast leafEnv22007 active22007 tree22007 = true := by decide +kernel

def env22008 : List Nat := [2,4,8,16,0,17,128,20,137,5,1,0,25,1,0,154,1,16,5,1,0,1,17,139,145,17,0,0,1,17,20,137,20,137,1,137]

theorem envBound22008 : H12AffineFastState.Bounded env22008 := by
  intro p hp
  have h : env22008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22006_22008 : H12AffineEnvironment.transform 10 1 env22006 = env22008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env22006 == env22008) = true)

theorem identity22008 : scanCanonicalize (H12AffineFastState.compose env22008 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound22008 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22009 : List Nat := [2,4,8,1,0,0,128,5,137,5,1,0,8,1,0,139,1,1,5,1,0,1,0,139,128,0,0,0,1,0,5,137,5,137,1,137]

theorem envBound22009 : H12AffineFastState.Bounded env22009 := by
  intro p hp
  have h : env22009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22008_22009 : H12AffineEnvironment.transform 3 1 env22008 = env22009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env22008 == env22009) = true)

def leafEnv22009 : List Nat := [2,4,8,1,0,0,128,5,137,5,1,0,8,1,0,139,1,1,5,1,0,1,0,139,4,128,1,0,0,0,1,0,5,137,5,137,5,2,1,137,0,0,1]

def active22009 : List Nat := [0,1,2,6]

def tree22009 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22009 : H12WitnessSearch.Good tree22009 := H12GlobalWitnessIndex.good

theorem leafIdentity22009 : H12AffineFastState.composeSystem env22009 rootObs = leafEnv22009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22009 rootObs == leafEnv22009) = true)

theorem terminalChecked22009 : H12PackedTerminal.terminalCheckFast leafEnv22009 active22009 tree22009 = true := by decide +kernel

def env22010 : List Nat := [2,4,8,16,1,17,128,256,137,273,2048,0,8192,1,8460,398,1,2309,273,8461,0,1,17,8583,8328,17,2049,0,1,2308,20,8581,256,136,1,137]

theorem envBound22010 : H12AffineFastState.Bounded env22010 := by
  intro p hp
  have h : env22010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22003_22010 : H12AffineEnvironment.transform 4 1 env22003 = env22010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22003 == env22010) = true)

def env22011 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,65536,1345,262144,1024,32769,1345,4194304,16,16777216,8328,65,21331968,1296,1296,1073741824,16876544,4294967296,256,4315938986,1345,512]

theorem envBound22011 : H12AffineFastState.Bounded env22011 := by
  intro p hp
  have h : env22011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans21977_22011 : H12AffineEnvironment.transform 11 1345 env21977 = env22011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env21977 == env22011) = true)

theorem identity22011 : scanCanonicalize (H12AffineFastState.compose env22011 (packedSelected [13,21] rootPS)) = affineNative (2^(31+1) ^^^ 4194440) := by decide +kernel

theorem selectedBound22011 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env22012 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,65536,1345,262144,1024,32769,1345,4194304,16,16777216,8328,65,21331968,1296,1296,1073741824,16876544,4194440,256,16777250,1345,512]

theorem envBound22012 : H12AffineFastState.Bounded env22012 := by
  intro p hp
  have h : env22012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22011_22012 : H12AffineEnvironment.transform 31 4194440 env22011 = env22012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4194440 env22011 == env22012) = true)

def env22013 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,128,1297,32768,65536,1345,262144,1024,32769,1345,4194304,16,16777216,8,65,21331968,1296,1296,1073741824,16876544,4194440,256,16777250,1345,512]

theorem envBound22013 : H12AffineFastState.Bounded env22013 := by
  intro p hp
  have h : env22013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22012_22013 : H12AffineEnvironment.transform 12 128 env22012 = env22013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 128 env22012 == env22013) = true)

theorem identity22013 : scanCanonicalize (H12AffineFastState.compose env22013 (packedSelected [3,5,24] rootPS)) = affineNative (2^(21+1) ^^^ 648) := by decide +kernel

theorem selectedBound22013 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env22014 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,128,1297,32768,65536,1345,262144,1024,32769,1345,648,16,16777216,8,65,17138312,1296,1296,1073741824,16876544,512,256,16777250,1345,512]

theorem envBound22014 : H12AffineFastState.Bounded env22014 := by
  intro p hp
  have h : env22014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22013_22014 : H12AffineEnvironment.transform 21 648 env22013 = env22014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 648 env22013 == env22014) = true)

def env22015 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,128,1297,32768,65536,1345,262144,1024,32769,1345,648,16,65536,8,65,295560,1296,1296,1073741824,33792,512,256,65570,1345,512]

theorem envBound22015 : H12AffineFastState.Bounded env22015 := by
  intro p hp
  have h : env22015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22014_22015 : H12AffineEnvironment.transform 23 65536 env22014 = env22015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 65536 env22014 == env22015) = true)

theorem identity22015 : scanCanonicalize (H12AffineFastState.compose env22015 (packedSelected [1,8,28] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound22015 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env22016 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,128,1297,32768,65536,1345,262144,1024,32769,1345,1,16,65536,8,65,294913,1296,1296,1073741824,33792,137,256,65570,1345,137]

theorem envBound22016 : H12AffineFastState.Bounded env22016 := by
  intro p hp
  have h : env22016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22015_22016 : H12AffineEnvironment.transform 8 137 env22015 = env22016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env22015 == env22016) = true)

def env22017 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,128,1297,0,65536,1345,262144,1024,1,1345,1,16,65536,8,65,262145,1296,1296,1073741824,1024,137,256,65570,1345,137]

theorem envBound22017 : H12AffineFastState.Bounded env22017 := by
  intro p hp
  have h : env22017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22016_22017 : H12AffineEnvironment.transform 14 0 env22016 = env22017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env22016 == env22017) = true)

theorem identity22017 : scanCanonicalize (H12AffineFastState.compose env22017 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 1451) := by decide +kernel

theorem selectedBound22017 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env22018 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,128,1297,0,1451,1345,262144,1024,1,1345,1,16,1451,8,65,262145,1296,1296,1073741824,1024,137,256,1417,1345,137]

theorem envBound22018 : H12AffineFastState.Bounded env22018 := by
  intro p hp
  have h : env22018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22017_22018 : H12AffineEnvironment.transform 15 1451 env22017 = env22018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1451 env22017 == env22018) = true)

theorem identity22018 : scanCanonicalize (H12AffineFastState.compose env22018 (packedSelected [5,15,41] rootPS)) = affineNative (2^(29+1) ^^^ 2308) := by decide +kernel

theorem selectedBound22018 : packedSelected [5,15,41] rootPS < 2^1333 := by decide +kernel

def env22019 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,128,1297,0,1451,1345,262144,1024,1,1345,1,16,1451,8,65,262145,1296,1296,2308,1024,137,256,1417,1345,137]

theorem envBound22019 : H12AffineFastState.Bounded env22019 := by
  intro p hp
  have h : env22019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22018_22019 : H12AffineEnvironment.transform 29 2308 env22018 = env22019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 2308 env22018 == env22019) = true)

theorem identity22019 : scanCanonicalize (H12AffineFastState.compose env22019 (packedSelected [3,4,9,15,17] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound22019 : packedSelected [3,4,9,15,17] rootPS < 2^1333 := by decide +kernel

def env22020 : List Nat := [2,4,8,16,32,64,128,173,137,1024,2048,1260,128,1212,0,1030,1260,262144,1024,1,1260,1,16,1030,8,65,262145,1213,1213,2217,1024,137,173,1060,1260,137]

theorem envBound22020 : H12AffineFastState.Bounded env22020 := by
  intro p hp
  have h : env22020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22019_22020 : H12AffineEnvironment.transform 7 173 env22019 = env22020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env22019 == env22020) = true)

theorem identity22020 : scanCanonicalize (H12AffineFastState.compose env22020 (packedSelected [0,1,2,5,12,13] rootPS)) = affineNative (2^(17+1) ^^^ 3229) := by decide +kernel

theorem selectedBound22020 : packedSelected [0,1,2,5,12,13] rootPS < 2^1333 := by decide +kernel

def env22021 : List Nat := [2,4,8,16,32,64,128,173,137,1024,2048,1260,128,1212,0,1030,1260,3229,1024,1,1260,1,16,1030,8,65,3228,1213,1213,2217,1024,137,173,1060,1260,137]

theorem envBound22021 : H12AffineFastState.Bounded env22021 := by
  intro p hp
  have h : env22021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22020_22021 : H12AffineEnvironment.transform 17 3229 env22020 = env22021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3229 env22020 == env22021) = true)

theorem identity22021 : scanCanonicalize (H12AffineFastState.compose env22021 (packedSelected [0,2,4,5,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound22021 : packedSelected [0,2,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env22022 : List Nat := [2,4,8,16,32,64,128,173,137,37,2048,201,128,153,0,35,201,2232,37,1,201,1,16,35,8,65,2233,152,152,2217,37,137,173,1,201,137]

theorem envBound22022 : H12AffineFastState.Bounded env22022 := by
  intro p hp
  have h : env22022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22021_22022 : H12AffineEnvironment.transform 9 37 env22021 = env22022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env22021 == env22022) = true)

theorem identity22022 : scanCanonicalize (H12AffineFastState.compose env22022 (packedSelected [2,5,7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound22022 : packedSelected [2,5,7] rootPS < 2^1333 := by decide +kernel

def env22023 : List Nat := [2,4,8,0,32,64,128,173,137,37,2048,201,128,137,0,35,201,2216,37,1,201,1,0,35,8,65,2217,136,136,2217,37,137,173,1,201,137]

theorem envBound22023 : H12AffineFastState.Bounded env22023 := by
  intro p hp
  have h : env22023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22022_22023 : H12AffineEnvironment.transform 3 0 env22022 = env22023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env22022 == env22023) = true)

theorem identity22023 : scanCanonicalize (H12AffineFastState.compose env22023 (packedSelected [0,11] rootPS)) = affineNative (2^(6+1) ^^^ 104) := by decide +kernel

theorem selectedBound22023 : packedSelected [0,11] rootPS < 2^1333 := by decide +kernel

def env22024 : List Nat := [2,4,8,0,32,64,104,69,97,37,2048,33,104,97,0,35,33,2112,37,1,33,1,0,35,8,65,2113,96,96,2113,37,97,69,1,33,97]

theorem envBound22024 : H12AffineFastState.Bounded env22024 := by
  intro p hp
  have h : env22024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22023_22024 : H12AffineEnvironment.transform 6 104 env22023 = env22024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 104 env22023 == env22024) = true)

theorem identity22024 : scanCanonicalize (H12AffineFastState.compose env22024 (packedSelected [0,1,2] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound22024 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env22025 : List Nat := [2,4,8,0,32,32,8,37,1,37,2048,33,8,1,0,35,33,2080,37,1,33,1,0,35,8,33,2081,0,0,2081,37,1,37,1,33,1]

theorem envBound22025 : H12AffineFastState.Bounded env22025 := by
  intro p hp
  have h : env22025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22024_22025 : H12AffineEnvironment.transform 5 32 env22024 = env22025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env22024 == env22025) = true)

theorem identity22025 : scanCanonicalize (H12AffineFastState.compose env22025 (packedSelected [8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound22025 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env22026 : List Nat := [2,4,8,0,0,0,8,5,1,5,2048,1,8,1,0,3,1,2048,5,1,1,1,0,3,8,1,2049,0,0,2049,5,1,5,1,1,1]

theorem envBound22026 : H12AffineFastState.Bounded env22026 := by
  intro p hp
  have h : env22026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22025_22026 : H12AffineEnvironment.transform 4 0 env22025 = env22026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22025 == env22026) = true)

def leafEnv22026 : List Nat := [2,4,8,0,0,0,8,5,1,5,2048,1,8,1,0,3,1,2048,5,1,1,1,0,3,4,8,1,1,2049,0,0,2049,5,1,5,1,5,2,1,1,0,1,1]

def active22026 : List Nat := [0,1,2,10]

def tree22026 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22026 : H12WitnessSearch.Good tree22026 := H12GlobalWitnessIndex.good

theorem leafIdentity22026 : H12AffineFastState.composeSystem env22026 rootObs = leafEnv22026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22026 rootObs == leafEnv22026) = true)

theorem terminalChecked22026 : H12PackedTerminal.terminalCheckFast leafEnv22026 active22026 tree22026 = true := by decide +kernel

def env22027 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,128,1297,1,65536,1345,262144,1024,0,1345,1,16,65536,8,65,262144,1296,1296,1073741824,1025,137,256,65570,1345,137]

theorem envBound22027 : H12AffineFastState.Bounded env22027 := by
  intro p hp
  have h : env22027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22016_22027 : H12AffineEnvironment.transform 14 1 env22016 = env22027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env22016 == env22027) = true)

theorem identity22027 : scanCanonicalize (H12AffineFastState.compose env22027 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 1314) := by decide +kernel

theorem selectedBound22027 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env22028 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,128,1297,1,1314,1345,262144,1024,0,1345,1,16,1314,8,65,262144,1296,1296,1073741824,1025,137,256,1280,1345,137]

theorem envBound22028 : H12AffineFastState.Bounded env22028 := by
  intro p hp
  have h : env22028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22027_22028 : H12AffineEnvironment.transform 15 1314 env22027 = env22028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1314 env22027 == env22028) = true)

theorem identity22028 : scanCanonicalize (H12AffineFastState.compose env22028 (packedSelected [5,15,41] rootPS)) = affineNative (2^(29+1) ^^^ 2048) := by decide +kernel

theorem selectedBound22028 : packedSelected [5,15,41] rootPS < 2^1333 := by decide +kernel

def env22029 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,128,1297,1,1314,1345,262144,1024,0,1345,1,16,1314,8,65,262144,1296,1296,2048,1025,137,256,1280,1345,137]

theorem envBound22029 : H12AffineFastState.Bounded env22029 := by
  intro p hp
  have h : env22029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22028_22029 : H12AffineEnvironment.transform 29 2048 env22028 = env22029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 2048 env22028 == env22029) = true)

theorem identity22029 : scanCanonicalize (H12AffineFastState.compose env22029 (packedSelected [0,7] rootPS)) = affineNative (2^(17+1) ^^^ 2217) := by decide +kernel

theorem selectedBound22029 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env22030 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,128,1297,1,1314,1345,2217,1024,0,1345,1,16,1314,8,65,2217,1296,1296,2048,1025,137,256,1280,1345,137]

theorem envBound22030 : H12AffineFastState.Bounded env22030 := by
  intro p hp
  have h : env22030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22029_22030 : H12AffineEnvironment.transform 17 2217 env22029 = env22030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2217 env22029 == env22030) = true)

theorem identity22030 : scanCanonicalize (H12AffineFastState.compose env22030 (packedSelected [4,9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound22030 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env22031 : List Nat := [2,4,8,16,32,64,128,4,137,1024,2048,1093,128,1045,1,1062,1093,2217,1024,0,1093,1,16,1062,8,65,2217,1044,1044,2048,1025,137,4,1028,1093,137]

theorem envBound22031 : H12AffineFastState.Bounded env22031 := by
  intro p hp
  have h : env22031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22030_22031 : H12AffineEnvironment.transform 7 4 env22030 = env22031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env22030 == env22031) = true)

theorem identity22031 : scanCanonicalize (H12AffineFastState.compose env22031 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound22031 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22032 : List Nat := [2,4,8,16,32,64,128,4,137,1024,33,1093,128,1045,1,1062,1093,136,1024,0,1093,1,16,1062,8,65,136,1044,1044,33,1025,137,4,1028,1093,137]

theorem envBound22032 : H12AffineFastState.Bounded env22032 := by
  intro p hp
  have h : env22032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22031_22032 : H12AffineEnvironment.transform 10 33 env22031 = env22032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env22031 == env22032) = true)

theorem identity22032 : scanCanonicalize (H12AffineFastState.compose env22032 (packedSelected [2,4] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound22032 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env22033 : List Nat := [2,4,8,16,32,64,120,4,113,1024,33,1093,120,1045,1,1062,1093,112,1024,0,1093,1,16,1062,8,65,112,1044,1044,33,1025,113,4,1028,1093,113]

theorem envBound22033 : H12AffineFastState.Bounded env22033 := by
  intro p hp
  have h : env22033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22032_22033 : H12AffineEnvironment.transform 6 120 env22032 = env22033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env22032 == env22033) = true)

def env22034 : List Nat := [2,4,8,16,0,64,88,4,81,1024,1,1093,88,1045,1,1030,1093,80,1024,0,1093,1,16,1030,8,65,80,1044,1044,1,1025,81,4,1028,1093,81]

theorem envBound22034 : H12AffineFastState.Bounded env22034 := by
  intro p hp
  have h : env22034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22033_22034 : H12AffineEnvironment.transform 4 0 env22033 = env22034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22033 == env22034) = true)

theorem identity22034 : scanCanonicalize (H12AffineFastState.compose env22034 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound22034 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22035 : List Nat := [2,4,8,16,0,64,88,4,81,20,1,81,88,1,1,18,81,80,20,0,81,1,16,18,8,65,80,0,0,1,21,81,4,16,81,81]

theorem envBound22035 : H12AffineFastState.Bounded env22035 := by
  intro p hp
  have h : env22035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22034_22035 : H12AffineEnvironment.transform 9 20 env22034 = env22035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env22034 == env22035) = true)

def env22036 : List Nat := [2,4,8,16,1,64,89,4,80,1024,0,1093,89,1045,1,1031,1093,81,1024,0,1093,1,16,1031,8,65,81,1044,1044,0,1025,80,4,1028,1093,80]

theorem envBound22036 : H12AffineFastState.Bounded env22036 := by
  intro p hp
  have h : env22036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22033_22036 : H12AffineEnvironment.transform 4 1 env22033 = env22036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22033 == env22036) = true)

theorem identity22036 : scanCanonicalize (H12AffineFastState.compose env22036 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound22036 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22037 : List Nat := [2,4,8,16,1,64,89,4,80,69,0,0,89,80,1,66,0,81,69,0,0,1,16,66,8,65,81,81,81,0,68,80,4,65,0,80]

theorem envBound22037 : H12AffineFastState.Bounded env22037 := by
  intro p hp
  have h : env22037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22036_22037 : H12AffineEnvironment.transform 9 69 env22036 = env22037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env22036 == env22037) = true)

theorem identity22037 : scanCanonicalize (H12AffineFastState.compose env22037 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound22037 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22038 : List Nat := [2,4,8,0,1,64,73,4,64,69,0,0,73,64,1,66,0,65,69,0,0,1,0,66,8,65,65,65,65,0,68,64,4,65,0,64]

theorem envBound22038 : H12AffineFastState.Bounded env22038 := by
  intro p hp
  have h : env22038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22037_22038 : H12AffineEnvironment.transform 3 0 env22037 = env22038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env22037 == env22038) = true)

theorem identity22038 : scanCanonicalize (H12AffineFastState.compose env22038 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound22038 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env22039 : List Nat := [2,4,8,0,1,0,9,4,0,5,0,0,9,0,1,2,0,1,5,0,0,1,0,2,8,1,1,1,1,0,4,0,4,1,0,0]

theorem envBound22039 : H12AffineFastState.Bounded env22039 := by
  intro p hp
  have h : env22039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22038_22039 : H12AffineEnvironment.transform 5 0 env22038 = env22039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env22038 == env22039) = true)

def leafEnv22039 : List Nat := [2,4,8,0,1,0,9,4,0,5,0,0,9,0,1,2,0,1,5,0,0,1,0,2,5,8,1,1,1,1,1,0,4,0,4,1,5,2,0,0,0,0,1]

def active22039 : List Nat := [0,1,2]

def tree22039 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22039 : H12WitnessSearch.Good tree22039 := H12GlobalWitnessIndex.good

theorem leafIdentity22039 : H12AffineFastState.composeSystem env22039 rootObs = leafEnv22039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22039 rootObs == leafEnv22039) = true)

theorem terminalChecked22039 : H12PackedTerminal.terminalCheckFast leafEnv22039 active22039 tree22039 = true := by decide +kernel

def env22040 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,128,1297,32768,65536,1345,262144,1024,32769,1345,648,16,65537,8,65,295561,1296,1296,1073741824,33793,512,256,65571,1345,512]

theorem envBound22040 : H12AffineFastState.Bounded env22040 := by
  intro p hp
  have h : env22040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22014_22040 : H12AffineEnvironment.transform 23 65537 env22014 = env22040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 65537 env22014 == env22040) = true)

theorem identity22040 : scanCanonicalize (H12AffineFastState.compose env22040 (packedSelected [1,8,28] rootPS)) = affineNative (2^(14+1) ^^^ 909) := by decide +kernel

theorem selectedBound22040 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env22041 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,128,1297,909,65536,1345,262144,1024,908,1345,648,16,65537,8,65,262404,1296,1296,1073741824,1932,512,256,65571,1345,512]

theorem envBound22041 : H12AffineFastState.Bounded env22041 := by
  intro p hp
  have h : env22041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22040_22041 : H12AffineEnvironment.transform 14 909 env22040 = env22041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 909 env22040 == env22041) = true)

def env22042 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1345,8,1297,773,65536,1345,262144,1024,772,1345,512,16,65537,8,65,262404,1296,1296,1073741824,1796,512,256,65571,1345,512]

theorem envBound22042 : H12AffineFastState.Bounded env22042 := by
  intro p hp
  have h : env22042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22041_22042 : H12AffineEnvironment.transform 6 8 env22041 = env22042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22041 == env22042) = true)

theorem identity22042 : scanCanonicalize (H12AffineFastState.compose env22042 (packedSelected [6] rootPS)) = affineNative (2^(29+1) ^^^ 3109) := by decide +kernel

theorem selectedBound22042 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env22043 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1345,8,1297,773,65536,1345,262144,1024,772,1345,512,16,65537,8,65,262404,1296,1296,3109,1796,512,256,65571,1345,512]

theorem envBound22043 : H12AffineFastState.Bounded env22043 := by
  intro p hp
  have h : env22043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22042_22043 : H12AffineEnvironment.transform 29 3109 env22042 = env22043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 3109 env22042 == env22043) = true)

def env22044 : List Nat := [2,4,8,16,32,64,8,256,260,1024,2048,1345,8,1297,1,65536,1345,262144,1024,0,1345,260,16,65537,8,65,262404,1296,1296,3109,1024,260,256,65571,1345,260]

theorem envBound22044 : H12AffineFastState.Bounded env22044 := by
  intro p hp
  have h : env22044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22043_22044 : H12AffineEnvironment.transform 8 260 env22043 = env22044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env22043 == env22044) = true)

theorem identity22044 : scanCanonicalize (H12AffineFastState.compose env22044 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound22044 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22045 : List Nat := [2,4,8,16,32,64,8,68,64,1024,2048,1029,8,1109,1,65536,1029,262144,1024,0,1029,64,16,65537,8,65,262208,1108,1108,3109,1024,64,68,65571,1029,64]

theorem envBound22045 : H12AffineFastState.Bounded env22045 := by
  intro p hp
  have h : env22045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22044_22045 : H12AffineEnvironment.transform 7 68 env22044 = env22045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env22044 == env22045) = true)

theorem identity22045 : scanCanonicalize (H12AffineFastState.compose env22045 (packedSelected [3,7,8,11,15,17,18,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 67634) := by decide +kernel

theorem selectedBound22045 : packedSelected [3,7,8,11,15,17,18,23,32] rootPS < 2^1333 := by decide +kernel

def env22046 : List Nat := [2,4,8,16,32,64,8,68,64,1024,2048,1029,8,1109,1,65536,1029,67634,1024,0,1029,64,16,65537,8,65,67698,1108,1108,3109,1024,64,68,65571,1029,64]

theorem envBound22046 : H12AffineFastState.Bounded env22046 := by
  intro p hp
  have h : env22046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22045_22046 : H12AffineEnvironment.transform 17 67634 env22045 = env22046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67634 env22045 == env22046) = true)

theorem identity22046 : scanCanonicalize (H12AffineFastState.compose env22046 (packedSelected [3,7,11,12,13,18] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound22046 : packedSelected [3,7,11,12,13,18] rootPS < 2^1333 := by decide +kernel

def env22047 : List Nat := [2,4,8,16,32,64,8,68,64,53,2048,48,8,96,1,65536,48,67634,53,0,48,64,16,65537,8,65,67698,97,97,2064,53,64,68,65571,48,64]

theorem envBound22047 : H12AffineFastState.Bounded env22047 := by
  intro p hp
  have h : env22047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22046_22047 : H12AffineEnvironment.transform 9 53 env22046 = env22047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env22046 == env22047) = true)

theorem identity22047 : scanCanonicalize (H12AffineFastState.compose env22047 (packedSelected [5,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound22047 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env22048 : List Nat := [2,4,8,16,32,16,8,20,16,53,2048,48,8,48,1,65536,48,67634,53,0,48,16,16,65537,8,17,67618,49,49,2064,53,16,20,65571,48,16]

theorem envBound22048 : H12AffineFastState.Bounded env22048 := by
  intro p hp
  have h : env22048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22047_22048 : H12AffineEnvironment.transform 5 16 env22047 = env22048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22047 == env22048) = true)

theorem identity22048 : scanCanonicalize (H12AffineFastState.compose env22048 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 19) := by decide +kernel

theorem selectedBound22048 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22049 : List Nat := [2,4,8,16,32,16,8,20,16,53,2048,48,8,48,1,19,48,2081,53,0,48,16,16,18,8,17,2097,49,49,2064,53,16,20,48,48,16]

theorem envBound22049 : H12AffineFastState.Bounded env22049 := by
  intro p hp
  have h : env22049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22048_22049 : H12AffineEnvironment.transform 15 19 env22048 = env22049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 19 env22048 == env22049) = true)

theorem identity22049 : scanCanonicalize (H12AffineFastState.compose env22049 (packedSelected [0,3,7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound22049 : packedSelected [0,3,7] rootPS < 2^1333 := by decide +kernel

def env22050 : List Nat := [2,4,8,1,32,1,8,5,1,36,2048,33,8,33,1,2,33,2081,36,0,33,1,1,3,8,0,2080,32,32,2049,36,1,5,33,33,1]

theorem envBound22050 : H12AffineFastState.Bounded env22050 := by
  intro p hp
  have h : env22050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22049_22050 : H12AffineEnvironment.transform 3 1 env22049 = env22050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env22049 == env22050) = true)

theorem identity22050 : scanCanonicalize (H12AffineFastState.compose env22050 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound22050 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22051 : List Nat := [2,4,8,1,1,1,8,5,1,5,2048,0,8,0,1,2,0,2048,5,0,0,1,1,3,8,0,2049,1,1,2049,5,1,5,0,0,1]

theorem envBound22051 : H12AffineFastState.Bounded env22051 := by
  intro p hp
  have h : env22051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22050_22051 : H12AffineEnvironment.transform 4 1 env22050 = env22051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22050 == env22051) = true)

def leafEnv22051 : List Nat := [2,4,8,1,1,1,8,5,1,5,2048,0,8,0,1,2,0,2048,5,0,0,1,1,3,4,8,1,0,2049,1,1,2049,5,1,5,0,5,3,0,1,0,0,1]

def active22051 : List Nat := [0,1,2,10]

def tree22051 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22051 : H12WitnessSearch.Good tree22051 := H12GlobalWitnessIndex.good

theorem leafIdentity22051 : H12AffineFastState.composeSystem env22051 rootObs = leafEnv22051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22051 rootObs == leafEnv22051) = true)

theorem terminalChecked22051 : H12PackedTerminal.terminalCheckFast leafEnv22051 active22051 tree22051 = true := by decide +kernel

def env22052 : List Nat := [2,4,8,16,32,64,8,256,261,1024,2048,1345,8,1297,0,65536,1345,262144,1024,1,1345,261,16,65537,8,65,262404,1296,1296,3109,1025,261,256,65571,1345,261]

theorem envBound22052 : H12AffineFastState.Bounded env22052 := by
  intro p hp
  have h : env22052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22043_22052 : H12AffineEnvironment.transform 8 261 env22043 = env22052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env22043 == env22052) = true)

theorem identity22052 : scanCanonicalize (H12AffineFastState.compose env22052 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 327) := by decide +kernel

theorem selectedBound22052 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22053 : List Nat := [2,4,8,16,32,64,8,256,261,1024,2048,1345,8,1297,0,327,1345,262144,1024,1,1345,261,16,326,8,65,262404,1296,1296,3109,1025,261,256,356,1345,261]

theorem envBound22053 : H12AffineFastState.Bounded env22053 := by
  intro p hp
  have h : env22053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22052_22053 : H12AffineEnvironment.transform 15 327 env22052 = env22053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 327 env22052 == env22053) = true)

theorem identity22053 : scanCanonicalize (H12AffineFastState.compose env22053 (packedSelected [5,15,41] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound22053 : packedSelected [5,15,41] rootPS < 2^1333 := by decide +kernel

def env22054 : List Nat := [2,4,8,16,32,64,8,256,261,37,2048,356,8,308,0,327,356,262144,37,1,356,261,16,326,8,65,262404,309,309,2048,36,261,256,356,356,261]

theorem envBound22054 : H12AffineFastState.Bounded env22054 := by
  intro p hp
  have h : env22054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22053_22054 : H12AffineEnvironment.transform 9 37 env22053 = env22054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env22053 == env22054) = true)

theorem identity22054 : scanCanonicalize (H12AffineFastState.compose env22054 (packedSelected [1,4,5,9,12,13] rootPS)) = affineNative (2^(17+1) ^^^ 2080) := by decide +kernel

theorem selectedBound22054 : packedSelected [1,4,5,9,12,13] rootPS < 2^1333 := by decide +kernel

def env22055 : List Nat := [2,4,8,16,32,64,8,256,261,37,2048,356,8,308,0,327,356,2080,37,1,356,261,16,326,8,65,2340,309,309,2048,36,261,256,356,356,261]

theorem envBound22055 : H12AffineFastState.Bounded env22055 := by
  intro p hp
  have h : env22055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22054_22055 : H12AffineEnvironment.transform 17 2080 env22054 = env22055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2080 env22054 == env22055) = true)

theorem identity22055 : scanCanonicalize (H12AffineFastState.compose env22055 (packedSelected [4,7,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound22055 : packedSelected [4,7,8,9] rootPS < 2^1333 := by decide +kernel

def env22056 : List Nat := [2,4,8,16,32,64,8,256,261,37,32,356,8,308,0,327,356,0,37,1,356,261,16,326,8,65,260,309,309,32,36,261,256,356,356,261]

theorem envBound22056 : H12AffineFastState.Bounded env22056 := by
  intro p hp
  have h : env22056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22055_22056 : H12AffineEnvironment.transform 10 32 env22055 = env22056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env22055 == env22056) = true)

theorem identity22056 : scanCanonicalize (H12AffineFastState.compose env22056 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound22056 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env22057 : List Nat := [2,4,8,16,32,64,8,4,1,37,32,96,8,48,0,67,96,0,37,1,96,1,16,66,8,65,0,49,49,32,36,1,4,96,96,1]

theorem envBound22057 : H12AffineFastState.Bounded env22057 := by
  intro p hp
  have h : env22057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22056_22057 : H12AffineEnvironment.transform 7 4 env22056 = env22057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env22056 == env22057) = true)

theorem identity22057 : scanCanonicalize (H12AffineFastState.compose env22057 (packedSelected [4] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound22057 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22058 : List Nat := [2,4,8,16,32,49,8,4,1,37,32,17,8,48,0,50,17,0,37,1,17,1,16,51,8,48,0,49,49,32,36,1,4,17,17,1]

theorem envBound22058 : H12AffineFastState.Bounded env22058 := by
  intro p hp
  have h : env22058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22057_22058 : H12AffineEnvironment.transform 5 49 env22057 = env22058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env22057 == env22058) = true)

def env22059 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1345,9,1297,772,65536,1345,262144,1024,773,1345,513,16,65537,8,65,262404,1296,1296,1073741824,1797,512,256,65571,1345,512]

theorem envBound22059 : H12AffineFastState.Bounded env22059 := by
  intro p hp
  have h : env22059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22041_22059 : H12AffineEnvironment.transform 6 9 env22041 = env22059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22041 == env22059) = true)

theorem identity22059 : scanCanonicalize (H12AffineFastState.compose env22059 (packedSelected [6] rootPS)) = affineNative (2^(29+1) ^^^ 3361) := by decide +kernel

theorem selectedBound22059 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env22060 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1345,9,1297,772,65536,1345,262144,1024,773,1345,513,16,65537,8,65,262404,1296,1296,3361,1797,512,256,65571,1345,512]

theorem envBound22060 : H12AffineFastState.Bounded env22060 := by
  intro p hp
  have h : env22060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22059_22060 : H12AffineEnvironment.transform 29 3361 env22059 = env22060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 3361 env22059 == env22060) = true)

def env22061 : List Nat := [2,4,8,16,32,64,9,256,260,1024,2048,1345,9,1297,0,65536,1345,262144,1024,1,1345,261,16,65537,8,65,262404,1296,1296,3361,1025,260,256,65571,1345,260]

theorem envBound22061 : H12AffineFastState.Bounded env22061 := by
  intro p hp
  have h : env22061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22060_22061 : H12AffineEnvironment.transform 8 260 env22060 = env22061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env22060 == env22061) = true)

theorem identity22061 : scanCanonicalize (H12AffineFastState.compose env22061 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 358) := by decide +kernel

theorem selectedBound22061 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22062 : List Nat := [2,4,8,16,32,64,9,256,260,1024,2048,1345,9,1297,0,358,1345,262144,1024,1,1345,261,16,359,8,65,262404,1296,1296,3361,1025,260,256,325,1345,260]

theorem envBound22062 : H12AffineFastState.Bounded env22062 := by
  intro p hp
  have h : env22062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22061_22062 : H12AffineEnvironment.transform 15 358 env22061 = env22062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 358 env22061 == env22062) = true)

theorem identity22062 : scanCanonicalize (H12AffineFastState.compose env22062 (packedSelected [3,7,12,13,15,17,23,32,38] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound22062 : packedSelected [3,7,12,13,15,17,23,32,38] rootPS < 2^1333 := by decide +kernel

def env22063 : List Nat := [2,4,8,16,32,64,9,256,260,1024,1044,1345,9,1297,0,358,1345,262144,1024,1,1345,261,16,359,8,65,262404,1296,1296,309,1025,260,256,325,1345,260]

theorem envBound22063 : H12AffineFastState.Bounded env22063 := by
  intro p hp
  have h : env22063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22062_22063 : H12AffineEnvironment.transform 10 1044 env22062 = env22063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env22062 == env22063) = true)

theorem identity22063 : scanCanonicalize (H12AffineFastState.compose env22063 (packedSelected [0,1,5,12,13] rootPS)) = affineNative (2^(17+1) ^^^ 1) := by decide +kernel

theorem selectedBound22063 : packedSelected [0,1,5,12,13] rootPS < 2^1333 := by decide +kernel

def env22064 : List Nat := [2,4,8,16,32,64,9,256,260,1024,1044,1345,9,1297,0,358,1345,1,1024,1,1345,261,16,359,8,65,261,1296,1296,309,1025,260,256,325,1345,260]

theorem envBound22064 : H12AffineFastState.Bounded env22064 := by
  intro p hp
  have h : env22064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22063_22064 : H12AffineEnvironment.transform 17 1 env22063 = env22064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1 env22063 == env22064) = true)

theorem identity22064 : scanCanonicalize (H12AffineFastState.compose env22064 (packedSelected [0,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound22064 : packedSelected [0,4,5,7] rootPS < 2^1333 := by decide +kernel

def env22065 : List Nat := [2,4,8,16,32,64,9,116,112,1024,1044,1077,9,1125,0,18,1077,1,1024,1,1077,113,16,19,8,65,113,1124,1124,65,1025,112,116,49,1077,112]

theorem envBound22065 : H12AffineFastState.Bounded env22065 := by
  intro p hp
  have h : env22065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22064_22065 : H12AffineEnvironment.transform 7 116 env22064 = env22065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env22064 == env22065) = true)

theorem identity22065 : scanCanonicalize (H12AffineFastState.compose env22065 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound22065 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22066 : List Nat := [2,4,8,1,32,64,9,101,97,1024,1029,1060,9,1125,0,3,1060,1,1024,1,1060,96,1,2,8,65,96,1124,1124,65,1025,97,101,32,1060,97]

theorem envBound22066 : H12AffineFastState.Bounded env22066 := by
  intro p hp
  have h : env22066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22065_22066 : H12AffineEnvironment.transform 3 1 env22065 = env22066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env22065 == env22066) = true)

theorem identity22066 : scanCanonicalize (H12AffineFastState.compose env22066 (packedSelected [4] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound22066 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22067 : List Nat := [2,4,8,1,32,64,9,101,97,37,32,1,9,64,0,3,1,1,37,1,1,96,1,2,8,65,96,65,65,65,36,97,101,32,1,97]

theorem envBound22067 : H12AffineFastState.Bounded env22067 := by
  intro p hp
  have h : env22067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22066_22067 : H12AffineEnvironment.transform 9 37 env22066 = env22067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env22066 == env22067) = true)

theorem identity22067 : scanCanonicalize (H12AffineFastState.compose env22067 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound22067 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env22068 : List Nat := [2,4,8,1,0,64,9,69,65,5,0,1,9,64,0,3,1,1,5,1,1,64,1,2,8,65,64,65,65,65,4,65,69,0,1,65]

theorem envBound22068 : H12AffineFastState.Bounded env22068 := by
  intro p hp
  have h : env22068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22067_22068 : H12AffineEnvironment.transform 4 0 env22067 = env22068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22067 == env22068) = true)

theorem identity22068 : scanCanonicalize (H12AffineFastState.compose env22068 (packedSelected [5] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound22068 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env22069 : List Nat := [2,4,8,1,0,1,9,4,0,5,0,1,9,1,0,3,1,1,5,1,1,1,1,2,8,0,1,0,0,0,4,0,4,0,1,0]

theorem envBound22069 : H12AffineFastState.Bounded env22069 := by
  intro p hp
  have h : env22069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22068_22069 : H12AffineEnvironment.transform 5 1 env22068 = env22069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env22068 == env22069) = true)

def leafEnv22069 : List Nat := [2,4,8,1,0,1,9,4,0,5,0,1,9,1,0,3,1,1,5,1,1,1,1,2,5,8,1,0,1,0,0,0,4,0,4,0,5,3,1,0,0,1,1]

def active22069 : List Nat := [0,1,2]

def tree22069 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22069 : H12WitnessSearch.Good tree22069 := H12GlobalWitnessIndex.good

theorem leafIdentity22069 : H12AffineFastState.composeSystem env22069 rootObs = leafEnv22069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22069 rootObs == leafEnv22069) = true)

theorem terminalChecked22069 : H12PackedTerminal.terminalCheckFast leafEnv22069 active22069 tree22069 = true := by decide +kernel

def env22070 : List Nat := [2,4,8,16,32,64,9,256,261,1024,2048,1345,9,1297,1,65536,1345,262144,1024,0,1345,260,16,65537,8,65,262404,1296,1296,3361,1024,261,256,65571,1345,261]

theorem envBound22070 : H12AffineFastState.Bounded env22070 := by
  intro p hp
  have h : env22070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22060_22070 : H12AffineEnvironment.transform 8 261 env22060 = env22070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env22060 == env22070) = true)

theorem identity22070 : scanCanonicalize (H12AffineFastState.compose env22070 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 101) := by decide +kernel

theorem selectedBound22070 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22071 : List Nat := [2,4,8,16,32,64,9,101,96,1024,2048,1060,9,1140,1,65536,1060,262144,1024,0,1060,97,16,65537,8,65,262241,1141,1141,3140,1024,96,101,65571,1060,96]

theorem envBound22071 : H12AffineFastState.Bounded env22071 := by
  intro p hp
  have h : env22071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22070_22071 : H12AffineEnvironment.transform 7 101 env22070 = env22071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 101 env22070 == env22071) = true)

theorem identity22071 : scanCanonicalize (H12AffineFastState.compose env22071 (packedSelected [3,7,12,15,17,23,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 68726) := by decide +kernel

theorem selectedBound22071 : packedSelected [3,7,12,15,17,23,32,38] rootPS < 2^1333 := by decide +kernel

def env22072 : List Nat := [2,4,8,16,32,64,9,101,96,1024,2048,1060,9,1140,1,65536,1060,68726,1024,0,1060,97,16,65537,8,65,68631,1141,1141,3140,1024,96,101,65571,1060,96]

theorem envBound22072 : H12AffineFastState.Bounded env22072 := by
  intro p hp
  have h : env22072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22071_22072 : H12AffineEnvironment.transform 17 68726 env22071 = env22072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 68726 env22071 == env22072) = true)

theorem identity22072 : scanCanonicalize (H12AffineFastState.compose env22072 (packedSelected [1,7,12,13] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound22072 : packedSelected [1,7,12,13] rootPS < 2^1333 := by decide +kernel

def env22073 : List Nat := [2,4,8,16,32,48,9,21,16,1024,2048,1060,9,1028,1,65536,1060,68614,1024,0,1060,17,16,65537,8,49,68631,1029,1029,3124,1024,16,21,65571,1060,16]

theorem envBound22073 : H12AffineFastState.Bounded env22073 := by
  intro p hp
  have h : env22073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22072_22073 : H12AffineEnvironment.transform 5 48 env22072 = env22073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env22072 == env22073) = true)

theorem identity22073 : scanCanonicalize (H12AffineFastState.compose env22073 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound22073 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env22074 : List Nat := [2,4,8,16,32,48,9,21,16,53,2048,17,9,49,1,65536,17,67635,53,0,17,17,16,65537,8,49,67618,48,48,2049,53,16,21,65571,17,16]

theorem envBound22074 : H12AffineFastState.Bounded env22074 := by
  intro p hp
  have h : env22074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22073_22074 : H12AffineEnvironment.transform 9 53 env22073 = env22074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env22073 == env22074) = true)

theorem identity22074 : scanCanonicalize (H12AffineFastState.compose env22074 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound22074 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22075 : List Nat := [2,4,8,16,32,48,9,21,16,53,2048,17,9,49,1,35,17,2064,53,0,17,17,16,34,8,49,2049,48,48,2049,53,16,21,0,17,16]

theorem envBound22075 : H12AffineFastState.Bounded env22075 := by
  intro p hp
  have h : env22075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22074_22075 : H12AffineEnvironment.transform 15 35 env22074 = env22075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env22074 == env22075) = true)

theorem identity22075 : scanCanonicalize (H12AffineFastState.compose env22075 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound22075 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env22076 : List Nat := [2,4,8,16,0,16,9,21,16,21,2048,17,9,17,1,3,17,2064,21,0,17,17,16,2,8,17,2049,16,16,2049,21,16,21,0,17,16]

theorem envBound22076 : H12AffineFastState.Bounded env22076 := by
  intro p hp
  have h : env22076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22075_22076 : H12AffineEnvironment.transform 4 0 env22075 = env22076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22075 == env22076) = true)

theorem identity22076 : scanCanonicalize (H12AffineFastState.compose env22076 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound22076 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22077 : List Nat := [2,4,8,1,0,1,9,4,1,4,2048,0,9,0,1,3,0,2049,4,0,0,0,1,2,8,0,2049,1,1,2049,4,1,4,0,0,1]

theorem envBound22077 : H12AffineFastState.Bounded env22077 := by
  intro p hp
  have h : env22077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22076_22077 : H12AffineEnvironment.transform 3 1 env22076 = env22077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env22076 == env22077) = true)

theorem identity22077 : scanCanonicalize (H12AffineFastState.compose env22077 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound22077 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22078 : List Nat := [2,4,8,1,0,1,9,4,1,4,1,0,9,0,1,3,0,0,4,0,0,0,1,2,8,0,0,1,1,0,4,1,4,0,0,1]

theorem envBound22078 : H12AffineFastState.Bounded env22078 := by
  intro p hp
  have h : env22078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22077_22078 : H12AffineEnvironment.transform 10 1 env22077 = env22078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env22077 == env22078) = true)

def env22079 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,129,1297,32768,65536,1345,262144,1024,32769,1345,4194304,16,16777216,9,65,21331968,1296,1296,1073741824,16876544,4194440,256,16777250,1345,512]

theorem envBound22079 : H12AffineFastState.Bounded env22079 := by
  intro p hp
  have h : env22079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22012_22079 : H12AffineEnvironment.transform 12 129 env22012 = env22079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 129 env22012 == env22079) = true)

theorem identity22079 : scanCanonicalize (H12AffineFastState.compose env22079 (packedSelected [3,5,24] rootPS)) = affineNative (2^(23+1) ^^^ 4293517) := by decide +kernel

theorem selectedBound22079 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env22080 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,129,1297,32768,65536,1345,262144,1024,32769,1345,4194304,16,4293517,9,65,263053,1296,1296,1073741824,4196237,4194440,256,4293551,1345,512]

theorem envBound22080 : H12AffineFastState.Bounded env22080 := by
  intro p hp
  have h : env22080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22079_22080 : H12AffineEnvironment.transform 23 4293517 env22079 = env22080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4293517 env22079 == env22080) = true)

def env22081 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,129,1297,32768,65536,1345,262144,1024,32769,1345,648,16,98565,9,65,263053,1296,1296,1073741824,1285,512,256,98599,1345,512]

theorem envBound22081 : H12AffineFastState.Bounded env22081 := by
  intro p hp
  have h : env22081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22080_22081 : H12AffineEnvironment.transform 21 648 env22080 = env22081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 648 env22080 == env22081) = true)

theorem identity22081 : scanCanonicalize (H12AffineFastState.compose env22081 (packedSelected [1,12,13] rootPS)) = affineNative (2^(17+1) ^^^ 35360) := by decide +kernel

theorem selectedBound22081 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env22082 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,129,1297,32768,65536,1345,35360,1024,32769,1345,648,16,98565,9,65,35245,1296,1296,1073741824,1285,512,256,98599,1345,512]

theorem envBound22082 : H12AffineFastState.Bounded env22082 := by
  intro p hp
  have h : env22082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22081_22082 : H12AffineEnvironment.transform 17 35360 env22081 = env22082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35360 env22081 == env22082) = true)

theorem identity22082 : scanCanonicalize (H12AffineFastState.compose env22082 (packedSelected [3,15,17] rootPS)) = affineNative (2^(29+1) ^^^ 2308) := by decide +kernel

theorem selectedBound22082 : packedSelected [3,15,17] rootPS < 2^1333 := by decide +kernel

def env22083 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,129,1297,32768,65536,1345,35360,1024,32769,1345,648,16,98565,9,65,35245,1296,1296,2308,1285,512,256,98599,1345,512]

theorem envBound22083 : H12AffineFastState.Bounded env22083 := by
  intro p hp
  have h : env22083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22082_22083 : H12AffineEnvironment.transform 29 2308 env22082 = env22083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 2308 env22082 == env22083) = true)

theorem identity22083 : scanCanonicalize (H12AffineFastState.compose env22083 (packedSelected [5,12,15] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound22083 : packedSelected [5,12,15] rootPS < 2^1333 := by decide +kernel

def env22084 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,129,1297,32768,65536,1345,34985,1024,32769,1345,1,16,98565,9,65,35245,1296,1296,2308,1285,137,256,98599,1345,137]

theorem envBound22084 : H12AffineFastState.Bounded env22084 := by
  intro p hp
  have h : env22084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22083_22084 : H12AffineEnvironment.transform 8 137 env22083 = env22084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env22083 == env22084) = true)

def env22085 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,129,1297,32768,65536,1297,34985,1024,32769,1297,1,16,98565,9,17,35245,1296,1296,2308,1285,137,256,98599,1297,137]

theorem envBound22085 : H12AffineFastState.Bounded env22085 := by
  intro p hp
  have h : env22085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22084_22085 : H12AffineEnvironment.transform 5 16 env22084 = env22085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22084 == env22085) = true)

end H12CloudChart2