import H12CloudChart2Data069

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity17157 : scanCanonicalize (H12AffineFastState.compose env17157 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 1215) := by decide +kernel

theorem selectedBound17157 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17158 : List Nat := [2,4,8,16,32,17,128,5,137,1024,1,1,1052,0,32,1215,1,0,20,33,0,1044,1028,1182,1172,17,0,1045,1045,1,20,137,1041,169,0,137]

theorem envBound17158 : H12AffineFastState.Bounded env17158 := by
  intro p hp
  have h : env17158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17157_17158 : H12AffineEnvironment.transform 15 1215 env17157 = env17158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1215 env17157 == env17158) = true)

theorem identity17158 : scanCanonicalize (H12AffineFastState.compose env17158 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound17158 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env17159 : List Nat := [2,4,8,16,32,17,128,5,137,52,1,1,40,0,32,139,1,0,20,33,0,32,48,170,160,17,0,33,33,1,20,137,37,169,0,137]

theorem envBound17159 : H12AffineFastState.Bounded env17159 := by
  intro p hp
  have h : env17159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17158_17159 : H12AffineEnvironment.transform 9 52 env17158 = env17159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env17158 == env17159) = true)

theorem identity17159 : scanCanonicalize (H12AffineFastState.compose env17159 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound17159 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17160 : List Nat := [2,4,8,16,1,17,128,5,137,21,1,1,9,0,1,139,1,0,20,0,0,1,17,139,129,17,0,0,0,1,20,137,4,136,0,137]

theorem envBound17160 : H12AffineFastState.Bounded env17160 := by
  intro p hp
  have h : env17160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17159_17160 : H12AffineEnvironment.transform 4 1 env17159 = env17160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17159 == env17160) = true)

theorem identity17160 : scanCanonicalize (H12AffineFastState.compose env17160 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound17160 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17161 : List Nat := [2,4,8,16,1,17,25,5,16,21,1,1,9,0,1,18,1,0,20,0,0,1,17,18,24,17,0,0,0,1,20,16,4,17,0,16]

theorem envBound17161 : H12AffineFastState.Bounded env17161 := by
  intro p hp
  have h : env17161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17160_17161 : H12AffineEnvironment.transform 6 25 env17160 = env17161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env17160 == env17161) = true)

def env17162 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,13625,65536,11293,13341,11533,13624,4097,10249,5376,78909,8328,15372,13340,14605,1296,2049,11272,4294967296,10253,4295040158,11292,512]

theorem envBound17162 : H12AffineFastState.Bounded env17162 := by
  intro p hp
  have h : env17162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17087_17162 : H12AffineEnvironment.transform 14 13625 env17087 = env17162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13625 env17087 == env17162) = true)

theorem identity17162 : scanCanonicalize (H12AffineFastState.compose env17162 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 7197) := by decide +kernel

theorem selectedBound17162 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env17163 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,7197,4097,2340,65536,4096,2048,4368,2341,4097,5140,5376,67616,7317,17,2049,1296,1296,2049,4117,4294967296,5136,4295040158,4097,512]

theorem envBound17163 : H12AffineFastState.Bounded env17163 := by
  intro p hp
  have h : env17163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17162_17163 : H12AffineEnvironment.transform 12 7197 env17162 = env17163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7197 env17162 == env17163) = true)

def env17164 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,2317,1297,2340,65536,1296,2048,1024,2341,1297,260,16,67616,2437,17,2049,1296,1296,2049,1285,4294967296,256,4295035278,1297,512]

theorem envBound17164 : H12AffineFastState.Bounded env17164 := by
  intro p hp
  have h : env17164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17163_17164 : H12AffineEnvironment.transform 11 1296 env17163 = env17164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env17163 == env17164) = true)

def env17165 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,2316,1296,2340,65536,1297,2048,1025,2341,1296,261,17,67616,2436,17,2049,1296,1296,2049,1284,4294967296,257,4295035279,1296,512]

theorem envBound17165 : H12AffineFastState.Bounded env17165 := by
  intro p hp
  have h : env17165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17163_17165 : H12AffineEnvironment.transform 11 1297 env17163 = env17165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env17163 == env17165) = true)

theorem identity17165 : scanCanonicalize (H12AffineFastState.compose env17165 (packedSelected [1,3] rootPS)) = affineNative (2^(31+1) ^^^ 772) := by decide +kernel

theorem selectedBound17165 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17166 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,2316,1296,2340,65536,1297,2048,1025,2341,1296,261,17,67616,2436,17,2049,1296,1296,2049,1284,772,257,68235,1296,512]

theorem envBound17166 : H12AffineFastState.Bounded env17166 := by
  intro p hp
  have h : env17166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17165_17166 : H12AffineEnvironment.transform 31 772 env17165 = env17166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 772 env17165 == env17166) = true)

theorem identity17166 : scanCanonicalize (H12AffineFastState.compose env17166 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 397) := by decide +kernel

theorem selectedBound17166 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env17167 : List Nat := [2,4,8,16,32,17,128,256,397,1024,2048,1297,2316,1296,2340,65536,1297,2048,1025,2341,1296,261,17,67616,2436,17,2049,1296,1296,2049,1284,137,257,67846,1296,397]

theorem envBound17167 : H12AffineFastState.Bounded env17167 := by
  intro p hp
  have h : env17167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17166_17167 : H12AffineEnvironment.transform 8 397 env17166 = env17167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 397 env17166 == env17167) = true)

theorem identity17167 : scanCanonicalize (H12AffineFastState.compose env17167 (packedSelected [8] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound17167 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env17168 : List Nat := [2,4,8,16,32,17,128,4,137,1024,2048,1045,2056,1044,2080,65536,1045,2048,1025,2081,1044,1,17,67616,2176,17,2049,1044,1044,2049,1024,137,5,67586,1044,137]

theorem envBound17168 : H12AffineFastState.Bounded env17168 := by
  intro p hp
  have h : env17168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17167_17168 : H12AffineEnvironment.transform 7 4 env17167 = env17168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env17167 == env17168) = true)

theorem identity17168 : scanCanonicalize (H12AffineFastState.compose env17168 (packedSelected [2,4] rootPS)) = affineNative (2^(15+1) ^^^ 2219) := by decide +kernel

theorem selectedBound17168 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env17169 : List Nat := [2,4,8,16,32,17,128,4,137,1024,2048,1045,2056,1044,2080,2219,1045,2048,1025,2081,1044,1,17,139,2176,17,2049,1044,1044,2049,1024,137,5,169,1044,137]

theorem envBound17169 : H12AffineFastState.Bounded env17169 := by
  intro p hp
  have h : env17169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17168_17169 : H12AffineEnvironment.transform 15 2219 env17168 = env17169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2219 env17168 == env17169) = true)

theorem identity17169 : scanCanonicalize (H12AffineFastState.compose env17169 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound17169 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17170 : List Nat := [2,4,8,16,32,17,128,4,137,1024,0,1045,8,1044,32,171,1045,0,1025,33,1044,1,17,139,128,17,1,1044,1044,1,1024,137,5,169,1044,137]

theorem envBound17170 : H12AffineFastState.Bounded env17170 := by
  intro p hp
  have h : env17170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17169_17170 : H12AffineEnvironment.transform 10 0 env17169 = env17170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env17169 == env17170) = true)

theorem identity17170 : scanCanonicalize (H12AffineFastState.compose env17170 (packedSelected [0,2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound17170 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env17171 : List Nat := [2,4,8,16,32,17,128,4,137,53,0,32,8,33,32,171,32,0,52,33,33,1,17,139,128,17,1,33,33,1,53,137,5,169,33,137]

theorem envBound17171 : H12AffineFastState.Bounded env17171 := by
  intro p hp
  have h : env17171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17170_17171 : H12AffineEnvironment.transform 9 53 env17170 = env17171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env17170 == env17171) = true)

def env17172 : List Nat := [2,4,8,16,0,17,128,4,137,21,0,0,8,1,0,139,0,0,20,1,1,1,17,139,128,17,1,1,1,1,21,137,5,137,1,137]

theorem envBound17172 : H12AffineFastState.Bounded env17172 := by
  intro p hp
  have h : env17172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17171_17172 : H12AffineEnvironment.transform 4 0 env17171 = env17172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17171 == env17172) = true)

theorem identity17172 : scanCanonicalize (H12AffineFastState.compose env17172 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound17172 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17173 : List Nat := [2,4,8,1,0,0,128,4,137,4,0,0,8,1,0,139,0,0,5,1,1,1,0,139,128,0,1,1,1,1,4,137,5,137,1,137]

theorem envBound17173 : H12AffineFastState.Bounded env17173 := by
  intro p hp
  have h : env17173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17172_17173 : H12AffineEnvironment.transform 3 1 env17172 = env17173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env17172 == env17173) = true)

def leafEnv17173 : List Nat := [2,4,8,1,0,0,128,4,137,4,0,0,8,1,0,139,0,0,5,1,1,1,0,139,4,128,1,0,1,1,1,1,4,137,5,137,4,2,1,137,0,1,1]

def active17173 : List Nat := [0,1,2,6]

def tree17173 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17173 : H12WitnessSearch.Good tree17173 := H12GlobalWitnessIndex.good

theorem leafIdentity17173 : H12AffineFastState.composeSystem env17173 rootObs = leafEnv17173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17173 rootObs == leafEnv17173) = true)

theorem terminalChecked17173 : H12PackedTerminal.terminalCheckFast leafEnv17173 active17173 tree17173 = true := by decide +kernel

def env17174 : List Nat := [2,4,8,16,1,17,128,4,137,20,0,1,8,0,1,138,1,0,21,0,0,1,17,139,128,17,1,0,0,1,20,137,5,136,0,137]

theorem envBound17174 : H12AffineFastState.Bounded env17174 := by
  intro p hp
  have h : env17174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17171_17174 : H12AffineEnvironment.transform 4 1 env17171 = env17174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17171 == env17174) = true)

theorem identity17174 : scanCanonicalize (H12AffineFastState.compose env17174 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound17174 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17175 : List Nat := [2,4,8,16,1,17,24,4,17,20,0,1,8,0,1,18,1,0,21,0,0,1,17,19,24,17,1,0,0,1,20,17,5,16,0,17]

theorem envBound17175 : H12AffineFastState.Bounded env17175 := by
  intro p hp
  have h : env17175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17174_17175 : H12AffineEnvironment.transform 6 24 env17174 = env17175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env17174 == env17175) = true)

def leafEnv17175 : List Nat := [2,4,8,16,1,17,24,4,17,20,0,1,8,0,1,18,1,0,21,0,0,1,17,19,20,24,1,17,1,0,0,1,20,17,5,16,4,3,0,17,0,0,1]

def active17175 : List Nat := [0,1,2,3]

def tree17175 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17175 : H12WitnessSearch.Good tree17175 := H12GlobalWitnessIndex.good

theorem leafIdentity17175 : H12AffineFastState.composeSystem env17175 rootObs = leafEnv17175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17175 rootObs == leafEnv17175) = true)

theorem terminalChecked17175 : H12PackedTerminal.terminalCheckFast leafEnv17175 active17175 tree17175 = true := by decide +kernel

def env17176 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4097,32768,65536,131072,262144,131345,32769,4097,4194304,5377,16777216,8328,135185,4588564,136465,1297,1073741824,17006864,4294967296,132113,4315938986,17006852,512]

theorem envBound17176 : H12AffineFastState.Bounded env17176 := by
  intro p hp
  have h : env17176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17025_17176 : H12AffineEnvironment.transform 18 131345 env17025 = env17176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 131345 env17025 == env17176) = true)

def env17177 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,8914000,134217728,8519745,2769921,1073741824,27513921,4294967296,10637632,4315938986,164610304,512]

theorem envBound17177 : H12AffineFastState.Bounded env17177 := by
  intro p hp
  have h : env17177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16116_17177 : H12AffineEnvironment.transform 28 2769921 env16116 = env17177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 2769921 env16116 == env17177) = true)

def env17178 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,4194304,8388608,16777216,8328,8914000,134217728,8519745,676865,1073741824,25412673,4294967296,8536384,4315938986,164610304,512]

theorem envBound17178 : H12AffineFastState.Bounded env17178 := by
  intro p hp
  have h : env17178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17177_17178 : H12AffineEnvironment.transform 20 4096 env17177 = env17178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env17177 == env17178) = true)

theorem identity17178 : scanCanonicalize (H12AffineFastState.compose env17178 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 774164) := by decide +kernel

theorem selectedBound17178 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env17179 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,4194304,8388608,774164,8328,8914000,134217728,8519745,676865,1073741824,8918101,4294967296,8536384,4299935934,147067156,512]

theorem envBound17179 : H12AffineFastState.Bounded env17179 := by
  intro p hp
  have h : env17179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17178_17179 : H12AffineEnvironment.transform 23 774164 env17178 = env17179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 774164 env17178 == env17179) = true)

def env17180 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,4194304,672832,774164,8328,147472,134217728,541697,676865,1073741824,151573,4294967296,525568,4299935934,139351380,512]

theorem envBound17180 : H12AffineFastState.Bounded env17180 := by
  intro p hp
  have h : env17180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17179_17180 : H12AffineEnvironment.transform 22 672832 env17179 = env17180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 672832 env17179 == env17180) = true)

def env17181 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32769,4096,4194304,540928,644436,8328,17744,134217728,541697,545089,1073741824,21845,4294967296,525568,4299806206,139218964,512]

theorem envBound17181 : H12AffineFastState.Bounded env17181 := by
  intro p hp
  have h : env17181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17180_17181 : H12AffineEnvironment.transform 16 1344 env17180 = env17181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env17180 == env17181) = true)

def env17182 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,1024,32769,4096,4194304,17664,119124,8328,17744,134217728,16385,21825,1073741824,21845,4294967296,256,4299280894,138695700,512]

theorem envBound17182 : H12AffineFastState.Bounded env17182 := by
  intro p hp
  have h : env17182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17181_17182 : H12AffineEnvironment.transform 18 1024 env17181 = env17182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env17181 == env17182) = true)

theorem identity17182 : scanCanonicalize (H12AffineFastState.compose env17182 (packedSelected [7,20,27] rootPS)) = affineNative (2^(13+1) ^^^ 4176) := by decide +kernel

theorem selectedBound17182 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env17183 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,1344,262144,1024,32769,4096,4194304,5456,98564,8328,5376,134217728,4177,1297,1073741824,1285,4294967296,256,4299260334,138675268,512]

theorem envBound17183 : H12AffineFastState.Bounded env17183 := by
  intro p hp
  have h : env17183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17182_17183 : H12AffineEnvironment.transform 13 4176 env17182 = env17183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env17182 == env17183) = true)

def env17184 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4176,32768,65536,1344,262144,1024,32769,4096,4194304,5456,98564,8192,5376,134217728,4177,1297,1073741824,1285,4294967296,256,4299260198,138675268,512]

theorem envBound17184 : H12AffineFastState.Bounded env17184 := by
  intro p hp
  have h : env17184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17183_17184 : H12AffineEnvironment.transform 6 8 env17183 = env17184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17183 == env17184) = true)

theorem identity17184 : scanCanonicalize (H12AffineFastState.compose env17184 (packedSelected [10,17,41] rootPS)) = affineNative (2^(29+1) ^^^ 4497708) := by decide +kernel

theorem selectedBound17184 : packedSelected [10,17,41] rootPS < 2^1333 := by decide +kernel

def env17185 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4176,32768,65536,1344,262144,1024,32769,4096,4194304,5456,98564,8192,5376,134217728,4177,1297,4497708,1285,4294967296,256,4299260198,138675268,512]

theorem envBound17185 : H12AffineFastState.Bounded env17185 := by
  intro p hp
  have h : env17185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17184_17185 : H12AffineEnvironment.transform 29 4497708 env17184 = env17185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4497708 env17184 == env17185) = true)

theorem identity17185 : scanCanonicalize (H12AffineFastState.compose env17185 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound17185 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env17186 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4176,32768,65536,1344,43049,1024,32769,4096,4194304,5456,98564,8192,5376,134217728,4177,1297,4196613,1285,4294967296,256,4299260198,138456173,512]

theorem envBound17186 : H12AffineFastState.Bounded env17186 := by
  intro p hp
  have h : env17186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17185_17186 : H12AffineEnvironment.transform 17 43049 env17185 = env17186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env17185 == env17186) = true)

theorem identity17186 : scanCanonicalize (H12AffineFastState.compose env17186 (packedSelected [3,11,12,13,15,18,20,21,24] rootPS)) = affineNative (2^(26+1) ^^^ 4237612) := by decide +kernel

theorem selectedBound17186 : packedSelected [3,11,12,13,15,18,20,21,24] rootPS < 2^1333 := by decide +kernel

def env17187 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4176,32768,65536,1344,43049,1024,32769,4096,4194304,5456,98564,8192,5376,4237612,4177,1297,4196613,1285,4294967296,256,4299260198,1345,512]

theorem envBound17187 : H12AffineFastState.Bounded env17187 := by
  intro p hp
  have h : env17187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17186_17187 : H12AffineEnvironment.transform 26 4237612 env17186 = env17187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4237612 env17186 == env17187) = true)

def env17188 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4176,32768,65536,1344,43049,1024,32769,4096,10248,5456,98564,8192,5376,33060,4177,1297,8461,1285,4294967296,256,4295076142,1345,512]

theorem envBound17188 : H12AffineFastState.Bounded env17188 := by
  intro p hp
  have h : env17188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17187_17188 : H12AffineEnvironment.transform 21 10248 env17187 = env17188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10248 env17187 == env17188) = true)

def env17189 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4176,8232,65536,1344,2049,1024,8233,4096,10248,5456,74028,8192,5376,8460,4177,1297,8461,1285,4294967296,256,4295035142,1345,512]

theorem envBound17189 : H12AffineFastState.Bounded env17189 := by
  intro p hp
  have h : env17189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17188_17189 : H12AffineEnvironment.transform 14 8232 env17188 = env17189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env17188 == env17189) = true)

theorem identity17189 : scanCanonicalize (H12AffineFastState.compose env17189 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 7196) := by decide +kernel

theorem selectedBound17189 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env17190 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,7196,4176,7220,65536,1344,2049,1024,7221,4096,5140,5456,73008,7196,5376,7440,4177,1297,7441,1285,4294967296,256,4295035142,1345,512]

theorem envBound17190 : H12AffineFastState.Bounded env17190 := by
  intro p hp
  have h : env17190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17189_17190 : H12AffineEnvironment.transform 12 7196 env17189 = env17190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7196 env17189 == env17190) = true)

def env17191 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1344,2396,1296,2420,65536,1344,2049,1024,2421,1344,340,16,67696,2396,64,2128,1297,1297,2129,1285,4294967296,256,4295035142,1345,512]

theorem envBound17191 : H12AffineFastState.Bounded env17191 := by
  intro p hp
  have h : env17191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17190_17191 : H12AffineEnvironment.transform 11 1344 env17190 = env17191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env17190 == env17191) = true)

theorem identity17191 : scanCanonicalize (H12AffineFastState.compose env17191 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 80) := by decide +kernel

theorem selectedBound17191 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env17192 : List Nat := [2,4,8,16,32,64,8,256,80,1024,2048,1344,2396,1296,2420,65536,1344,2049,1024,2421,1344,340,16,67696,2396,64,2128,1297,1297,2129,1285,4294967296,256,4295035142,1345,80]

theorem envBound17192 : H12AffineFastState.Bounded env17192 := by
  intro p hp
  have h : env17192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17191_17192 : H12AffineEnvironment.transform 8 80 env17191 = env17192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 80 env17191 == env17192) = true)

theorem identity17192 : scanCanonicalize (H12AffineFastState.compose env17192 (packedSelected [0,1,2,3,4,6] rootPS)) = affineNative (2^(15+1) ^^^ 2163) := by decide +kernel

theorem selectedBound17192 : packedSelected [0,1,2,3,4,6] rootPS < 2^1333 := by decide +kernel

def env17193 : List Nat := [2,4,8,16,32,64,8,256,80,1024,2048,1344,2396,1296,2420,2163,1344,2049,1024,2421,1344,340,16,3,2396,64,2128,1297,1297,2129,1285,4294967296,256,4294967669,1345,80]

theorem envBound17193 : H12AffineFastState.Bounded env17193 := by
  intro p hp
  have h : env17193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17192_17193 : H12AffineEnvironment.transform 15 2163 env17192 = env17193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2163 env17192 == env17193) = true)

theorem identity17193 : scanCanonicalize (H12AffineFastState.compose env17193 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 340) := by decide +kernel

theorem selectedBound17193 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17194 : List Nat := [2,4,8,16,32,64,8,256,80,1024,2048,1344,2396,1296,2420,2163,1344,2049,1024,2421,1344,340,16,3,2396,64,2128,1297,1297,2129,1285,340,256,33,1345,80]

theorem envBound17194 : H12AffineFastState.Bounded env17194 := by
  intro p hp
  have h : env17194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17193_17194 : H12AffineEnvironment.transform 31 340 env17193 = env17194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 340 env17193 == env17194) = true)

theorem identity17194 : scanCanonicalize (H12AffineFastState.compose env17194 (packedSelected [0,2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound17194 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env17195 : List Nat := [2,4,8,16,32,64,8,36,80,1024,2048,1124,2168,1076,2128,2163,1124,2049,1024,2129,1124,112,16,3,2168,64,2128,1077,1077,2129,1057,112,36,33,1125,80]

theorem envBound17195 : H12AffineFastState.Bounded env17195 := by
  intro p hp
  have h : env17195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17194_17195 : H12AffineEnvironment.transform 7 36 env17194 = env17195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env17194 == env17195) = true)

theorem identity17195 : scanCanonicalize (H12AffineFastState.compose env17195 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound17195 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17196 : List Nat := [2,4,8,16,32,49,8,36,33,1024,2048,1045,2057,1076,2081,2050,1045,2049,1024,2080,1045,1,16,3,2057,49,2081,1077,1077,2080,1057,1,36,33,1044,33]

theorem envBound17196 : H12AffineFastState.Bounded env17196 := by
  intro p hp
  have h : env17196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17195_17196 : H12AffineEnvironment.transform 5 49 env17195 = env17196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env17195 == env17196) = true)

def leafEnv17196 : List Nat := [2,4,8,16,32,49,8,36,33,1024,2048,1045,2057,1076,2081,2050,1045,2049,1024,2080,1045,1,16,3,1057,2057,1,49,2081,1077,1077,2080,1057,1,36,33,4,2051,1044,33,0,1077,1]

def active17196 : List Nat := [0,1,2,3,4,9,10]

def tree17196 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17196 : H12WitnessSearch.Good tree17196 := H12GlobalWitnessIndex.good

theorem leafIdentity17196 : H12AffineFastState.composeSystem env17196 rootObs = leafEnv17196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17196 rootObs == leafEnv17196) = true)

theorem terminalChecked17196 : H12PackedTerminal.terminalCheckFast leafEnv17196 active17196 tree17196 = true := by decide +kernel

def env17197 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1345,2397,1297,2421,65536,1344,2049,1024,2420,1345,341,17,67697,2397,65,2129,1296,1297,2128,1285,4294967296,256,4295035142,1345,512]

theorem envBound17197 : H12AffineFastState.Bounded env17197 := by
  intro p hp
  have h : env17197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17190_17197 : H12AffineEnvironment.transform 11 1345 env17190 = env17197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env17190 == env17197) = true)

theorem identity17197 : scanCanonicalize (H12AffineFastState.compose env17197 (packedSelected [5] rootPS)) = affineNative (2^(15+1) ^^^ 2083) := by decide +kernel

theorem selectedBound17197 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env17198 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1345,2397,1297,2421,2083,1344,2049,1024,2420,1345,341,17,82,2397,65,2129,1296,1297,2128,1285,4294967296,256,4294967589,1345,512]

theorem envBound17198 : H12AffineFastState.Bounded env17198 := by
  intro p hp
  have h : env17198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17197_17198 : H12AffineEnvironment.transform 15 2083 env17197 = env17198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2083 env17197 == env17198) = true)

theorem identity17198 : scanCanonicalize (H12AffineFastState.compose env17198 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound17198 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17199 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1296,2316,1297,2340,2083,1297,2049,1024,2341,1296,260,17,3,2316,16,2048,1296,1297,2049,1285,4294967296,256,4294967589,1296,512]

theorem envBound17199 : H12AffineFastState.Bounded env17199 := by
  intro p hp
  have h : env17199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17198_17199 : H12AffineEnvironment.transform 5 17 env17198 = env17199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17198 == env17199) = true)

theorem identity17199 : scanCanonicalize (H12AffineFastState.compose env17199 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 512) := by decide +kernel

theorem selectedBound17199 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17200 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1296,2316,1297,2340,2083,1297,2049,1024,2341,1296,260,17,3,2316,16,2048,1296,1297,2049,1285,512,256,805,1296,512]

theorem envBound17200 : H12AffineFastState.Bounded env17200 := by
  intro p hp
  have h : env17200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17199_17200 : H12AffineEnvironment.transform 31 512 env17199 = env17200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 512 env17199 == env17200) = true)

theorem identity17200 : scanCanonicalize (H12AffineFastState.compose env17200 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound17200 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17201 : List Nat := [2,4,8,16,32,17,8,256,32,1024,2048,1296,2316,1297,2340,2083,1297,2049,1024,2341,1296,260,17,3,2316,16,2048,1296,1297,2049,1285,32,256,261,1296,32]

theorem envBound17201 : H12AffineFastState.Bounded env17201 := by
  intro p hp
  have h : env17201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17200_17201 : H12AffineEnvironment.transform 8 32 env17200 = env17201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env17200 == env17201) = true)

theorem identity17201 : scanCanonicalize (H12AffineFastState.compose env17201 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound17201 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17202 : List Nat := [2,4,8,16,32,17,8,36,32,1024,2048,1076,2088,1077,2048,2083,1077,2049,1024,2049,1076,32,17,3,2088,16,2048,1076,1077,2049,1057,32,36,33,1076,32]

theorem envBound17202 : H12AffineFastState.Bounded env17202 := by
  intro p hp
  have h : env17202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17201_17202 : H12AffineEnvironment.transform 7 36 env17201 = env17202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env17201 == env17202) = true)

theorem identity17202 : scanCanonicalize (H12AffineFastState.compose env17202 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound17202 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env17203 : List Nat := [2,4,8,16,0,17,8,4,0,1024,2048,1044,2056,1045,2048,2051,1045,2049,1024,2049,1044,0,17,3,2056,16,2048,1044,1045,2049,1025,0,4,1,1044,0]

theorem envBound17203 : H12AffineFastState.Bounded env17203 := by
  intro p hp
  have h : env17203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17202_17203 : H12AffineEnvironment.transform 4 0 env17202 = env17203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17202 == env17203) = true)

def leafEnv17203 : List Nat := [2,4,8,16,0,17,8,4,0,1024,2048,1044,2056,1045,2048,2051,1045,2049,1024,2049,1044,0,17,3,1025,2056,1,16,2048,1044,1045,2049,1025,0,4,1,4,2050,1044,0,0,1045,1]

def active17203 : List Nat := [0,1,2,3,9,10]

def tree17203 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17203 : H12WitnessSearch.Good tree17203 := H12GlobalWitnessIndex.good

theorem leafIdentity17203 : H12AffineFastState.composeSystem env17203 rootObs = leafEnv17203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17203 rootObs == leafEnv17203) = true)

theorem terminalChecked17203 : H12PackedTerminal.terminalCheckFast leafEnv17203 active17203 tree17203 = true := by decide +kernel

def env17204 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4176,8233,65536,1344,2048,1024,8232,4096,10248,5456,74029,8192,5376,8461,4177,1297,8461,1285,4294967296,256,4295035143,1345,512]

theorem envBound17204 : H12AffineFastState.Bounded env17204 := by
  intro p hp
  have h : env17204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17188_17204 : H12AffineEnvironment.transform 14 8233 env17188 = env17204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env17188 == env17204) = true)

theorem identity17204 : scanCanonicalize (H12AffineFastState.compose env17204 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound17204 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env17205 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1297,8192,1345,8233,65536,1344,2048,1024,8232,1297,10248,65,74029,8192,17,8461,1344,1297,8461,1285,4294967296,256,4295035143,1345,512]

theorem envBound17205 : H12AffineFastState.Bounded env17205 := by
  intro p hp
  have h : env17205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17204_17205 : H12AffineEnvironment.transform 11 1297 env17204 = env17205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env17204 == env17205) = true)

theorem identity17205 : scanCanonicalize (H12AffineFastState.compose env17205 (packedSelected [1,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 2316) := by decide +kernel

theorem selectedBound17205 : packedSelected [1,5,10] rootPS < 2^1333 := by decide +kernel

def env17206 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1297,2316,1345,2341,65536,1344,2048,1024,2340,1297,260,65,67617,2316,17,2049,1344,1297,2049,1285,4294967296,256,4295035143,1345,512]

theorem envBound17206 : H12AffineFastState.Bounded env17206 := by
  intro p hp
  have h : env17206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17205_17206 : H12AffineEnvironment.transform 12 2316 env17205 = env17206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2316 env17205 == env17206) = true)

def env17207 : List Nat := [2,4,8,16,32,64,8,256,512,1024,292,1297,40,1345,1,65536,1344,292,1024,0,1297,260,65,65797,40,17,293,1344,1297,293,1285,4294967296,256,4295032867,1345,512]

theorem envBound17207 : H12AffineFastState.Bounded env17207 := by
  intro p hp
  have h : env17207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17206_17207 : H12AffineEnvironment.transform 10 292 env17206 = env17207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env17206 == env17207) = true)

theorem identity17207 : scanCanonicalize (H12AffineFastState.compose env17207 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 66391) := by decide +kernel

theorem selectedBound17207 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17208 : List Nat := [2,4,8,16,32,64,8,256,512,1024,292,1297,40,1345,1,65536,1344,292,1024,0,1297,260,65,65797,40,17,293,1344,1297,293,1285,66391,256,884,1345,512]

theorem envBound17208 : H12AffineFastState.Bounded env17208 := by
  intro p hp
  have h : env17208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17207_17208 : H12AffineEnvironment.transform 31 66391 env17207 = env17208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 66391 env17207 == env17208) = true)

def env17209 : List Nat := [2,4,8,16,32,16,8,256,512,1024,292,1297,40,1297,1,65536,1296,292,1024,0,1297,260,17,65797,40,17,293,1296,1297,293,1285,66311,256,804,1297,512]

theorem envBound17209 : H12AffineFastState.Bounded env17209 := by
  intro p hp
  have h : env17209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17208_17209 : H12AffineEnvironment.transform 5 16 env17208 = env17209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17208 == env17209) = true)

theorem identity17209 : scanCanonicalize (H12AffineFastState.compose env17209 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound17209 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17210 : List Nat := [2,4,8,16,32,16,8,256,512,1024,292,1297,40,1297,1,262,1296,292,1024,0,1297,260,17,3,40,17,293,1296,1297,293,1285,513,256,804,1297,512]

theorem envBound17210 : H12AffineFastState.Bounded env17210 := by
  intro p hp
  have h : env17210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17209_17210 : H12AffineEnvironment.transform 15 262 env17209 = env17210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env17209 == env17210) = true)

theorem identity17210 : scanCanonicalize (H12AffineFastState.compose env17210 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound17210 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17211 : List Nat := [2,4,8,16,32,16,8,256,33,1024,292,1297,40,1297,1,262,1296,292,1024,0,1297,260,17,3,40,17,293,1296,1297,293,1285,32,256,261,1297,33]

theorem envBound17211 : H12AffineFastState.Bounded env17211 := by
  intro p hp
  have h : env17211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17210_17211 : H12AffineEnvironment.transform 8 33 env17210 = env17211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env17210 == env17211) = true)

theorem identity17211 : scanCanonicalize (H12AffineFastState.compose env17211 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound17211 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17212 : List Nat := [2,4,8,16,32,16,8,37,33,1024,1,1076,40,1076,1,35,1077,1,1024,0,1076,33,17,3,40,17,0,1077,1076,0,1056,32,37,32,1076,33]

theorem envBound17212 : H12AffineFastState.Bounded env17212 := by
  intro p hp
  have h : env17212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17211_17212 : H12AffineEnvironment.transform 7 37 env17211 = env17212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env17211 == env17212) = true)

theorem identity17212 : scanCanonicalize (H12AffineFastState.compose env17212 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound17212 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env17213 : List Nat := [2,4,8,16,1,16,8,4,0,1024,1,1045,9,1045,1,2,1044,1,1024,0,1045,0,17,3,9,17,0,1044,1045,0,1025,1,4,1,1045,0]

theorem envBound17213 : H12AffineFastState.Bounded env17213 := by
  intro p hp
  have h : env17213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17212_17213 : H12AffineEnvironment.transform 4 1 env17212 = env17213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17212 == env17213) = true)

def env17214 : List Nat := [2,4,8,16,32,17,8,256,512,1024,292,1297,40,1296,1,65536,1297,292,1024,0,1297,260,16,65797,40,17,293,1297,1297,293,1285,66310,256,805,1296,512]

theorem envBound17214 : H12AffineFastState.Bounded env17214 := by
  intro p hp
  have h : env17214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17208_17214 : H12AffineEnvironment.transform 5 17 env17208 = env17214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17208 == env17214) = true)

theorem identity17214 : scanCanonicalize (H12AffineFastState.compose env17214 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound17214 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env17215 : List Nat := [2,4,8,16,32,17,8,256,1,1024,292,1297,40,1296,1,65536,1297,292,1024,0,1297,260,16,65797,40,17,293,1297,1297,293,1285,65799,256,292,1296,1]

theorem envBound17215 : H12AffineFastState.Bounded env17215 := by
  intro p hp
  have h : env17215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17214_17215 : H12AffineEnvironment.transform 8 1 env17214 = env17215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env17214 == env17215) = true)

theorem identity17215 : scanCanonicalize (H12AffineFastState.compose env17215 (packedSelected [2,4,6] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound17215 : packedSelected [2,4,6] rootPS < 2^1333 := by decide +kernel

def env17216 : List Nat := [2,4,8,16,32,17,8,256,1,1024,292,1297,40,1296,1,262,1297,292,1024,0,1297,260,16,3,40,17,293,1297,1297,293,1285,1,256,292,1296,1]

theorem envBound17216 : H12AffineFastState.Bounded env17216 := by
  intro p hp
  have h : env17216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17215_17216 : H12AffineEnvironment.transform 15 262 env17215 = env17216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env17215 == env17216) = true)

theorem identity17216 : scanCanonicalize (H12AffineFastState.compose env17216 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound17216 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17217 : List Nat := [2,4,8,16,32,17,8,5,1,1024,33,1044,40,1045,1,3,1044,33,1024,0,1044,1,16,3,40,17,32,1044,1044,32,1024,1,5,33,1045,1]

theorem envBound17217 : H12AffineFastState.Bounded env17217 := by
  intro p hp
  have h : env17217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17216_17217 : H12AffineEnvironment.transform 7 5 env17216 = env17217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env17216 == env17217) = true)

theorem identity17217 : scanCanonicalize (H12AffineFastState.compose env17217 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound17217 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17218 : List Nat := [2,4,8,16,1,17,8,5,1,1024,0,1044,9,1045,1,3,1044,0,1024,0,1044,1,16,3,9,17,1,1044,1044,1,1024,1,5,0,1045,1]

theorem envBound17218 : H12AffineFastState.Bounded env17218 := by
  intro p hp
  have h : env17218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17217_17218 : H12AffineEnvironment.transform 4 1 env17217 = env17218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17217 == env17218) = true)

def env17219 : List Nat := [2,4,8,16,32,64,8,256,512,1024,293,1297,41,1345,0,65536,1344,293,1024,1,1297,260,65,65796,41,17,292,1344,1297,292,1285,4294967296,256,4295032866,1345,512]

theorem envBound17219 : H12AffineFastState.Bounded env17219 := by
  intro p hp
  have h : env17219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17206_17219 : H12AffineEnvironment.transform 10 293 env17206 = env17219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env17206 == env17219) = true)

theorem identity17219 : scanCanonicalize (H12AffineFastState.compose env17219 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 593) := by decide +kernel

theorem selectedBound17219 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17220 : List Nat := [2,4,8,16,32,64,8,256,512,1024,293,1297,41,1345,0,65536,1344,293,1024,1,1297,260,65,65796,41,17,292,1344,1297,292,1285,593,256,66163,1345,512]

theorem envBound17220 : H12AffineFastState.Bounded env17220 := by
  intro p hp
  have h : env17220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17219_17220 : H12AffineEnvironment.transform 31 593 env17219 = env17220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 593 env17219 == env17220) = true)

def env17221 : List Nat := [2,4,8,16,32,16,8,256,512,1024,293,1297,41,1297,0,65536,1296,293,1024,1,1297,260,17,65796,41,17,292,1296,1297,292,1285,513,256,66083,1297,512]

theorem envBound17221 : H12AffineFastState.Bounded env17221 := by
  intro p hp
  have h : env17221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17220_17221 : H12AffineEnvironment.transform 5 16 env17220 = env17221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17220 == env17221) = true)

theorem identity17221 : scanCanonicalize (H12AffineFastState.compose env17221 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound17221 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17222 : List Nat := [2,4,8,16,32,16,8,256,512,1024,293,1297,41,1297,0,263,1296,293,1024,1,1297,260,17,3,41,17,292,1296,1297,292,1285,513,256,804,1297,512]

theorem envBound17222 : H12AffineFastState.Bounded env17222 := by
  intro p hp
  have h : env17222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17221_17222 : H12AffineEnvironment.transform 15 263 env17221 = env17222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env17221 == env17222) = true)

theorem identity17222 : scanCanonicalize (H12AffineFastState.compose env17222 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound17222 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17223 : List Nat := [2,4,8,16,32,16,8,256,33,1024,293,1297,41,1297,0,263,1296,293,1024,1,1297,260,17,3,41,17,292,1296,1297,292,1285,32,256,261,1297,33]

theorem envBound17223 : H12AffineFastState.Bounded env17223 := by
  intro p hp
  have h : env17223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17222_17223 : H12AffineEnvironment.transform 8 33 env17222 = env17223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env17222 == env17223) = true)

theorem identity17223 : scanCanonicalize (H12AffineFastState.compose env17223 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound17223 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17224 : List Nat := [2,4,8,16,32,16,8,37,33,1024,0,1076,41,1076,0,34,1077,0,1024,1,1076,33,17,3,41,17,1,1077,1076,1,1056,32,37,32,1076,33]

theorem envBound17224 : H12AffineFastState.Bounded env17224 := by
  intro p hp
  have h : env17224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17223_17224 : H12AffineEnvironment.transform 7 37 env17223 = env17224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env17223 == env17224) = true)

theorem identity17224 : scanCanonicalize (H12AffineFastState.compose env17224 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound17224 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env17225 : List Nat := [2,4,8,16,1,16,8,4,0,1024,0,1045,8,1045,0,3,1044,0,1024,1,1045,0,17,3,8,17,1,1044,1045,1,1025,1,4,1,1045,0]

theorem envBound17225 : H12AffineFastState.Bounded env17225 := by
  intro p hp
  have h : env17225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17224_17225 : H12AffineEnvironment.transform 4 1 env17224 = env17225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17224 == env17225) = true)

def env17226 : List Nat := [2,4,8,16,32,17,8,256,512,1024,293,1297,41,1296,0,65536,1297,293,1024,1,1297,260,16,65796,41,17,292,1297,1297,292,1285,512,256,66082,1296,512]

theorem envBound17226 : H12AffineFastState.Bounded env17226 := by
  intro p hp
  have h : env17226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17220_17226 : H12AffineEnvironment.transform 5 17 env17220 = env17226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17220 == env17226) = true)

theorem identity17226 : scanCanonicalize (H12AffineFastState.compose env17226 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound17226 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env17227 : List Nat := [2,4,8,16,32,17,8,256,1,1024,293,1297,41,1296,0,65536,1297,293,1024,1,1297,260,16,65796,41,17,292,1297,1297,292,1285,1,256,65571,1296,1]

theorem envBound17227 : H12AffineFastState.Bounded env17227 := by
  intro p hp
  have h : env17227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17226_17227 : H12AffineEnvironment.transform 8 1 env17226 = env17227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env17226 == env17227) = true)

theorem identity17227 : scanCanonicalize (H12AffineFastState.compose env17227 (packedSelected [2,4,6] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound17227 : packedSelected [2,4,6] rootPS < 2^1333 := by decide +kernel

def env17228 : List Nat := [2,4,8,16,32,17,8,256,1,1024,293,1297,41,1296,0,263,1297,293,1024,1,1297,260,16,3,41,17,292,1297,1297,292,1285,1,256,292,1296,1]

theorem envBound17228 : H12AffineFastState.Bounded env17228 := by
  intro p hp
  have h : env17228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17227_17228 : H12AffineEnvironment.transform 15 263 env17227 = env17228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env17227 == env17228) = true)

theorem identity17228 : scanCanonicalize (H12AffineFastState.compose env17228 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound17228 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17229 : List Nat := [2,4,8,16,32,17,8,5,1,1024,32,1044,41,1045,0,2,1044,32,1024,1,1044,1,16,3,41,17,33,1044,1044,33,1024,1,5,33,1045,1]

theorem envBound17229 : H12AffineFastState.Bounded env17229 := by
  intro p hp
  have h : env17229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17228_17229 : H12AffineEnvironment.transform 7 5 env17228 = env17229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env17228 == env17229) = true)

theorem identity17229 : scanCanonicalize (H12AffineFastState.compose env17229 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound17229 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17230 : List Nat := [2,4,8,16,1,17,8,5,1,1024,1,1044,8,1045,0,2,1044,1,1024,1,1044,1,16,3,8,17,0,1044,1044,0,1024,1,5,0,1045,1]

theorem envBound17230 : H12AffineFastState.Bounded env17230 := by
  intro p hp
  have h : env17230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17229_17230 : H12AffineEnvironment.transform 4 1 env17229 = env17230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17229 == env17230) = true)

def env17231 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4176,32768,65536,1344,43049,1024,32769,4096,10249,5456,98564,8192,5376,33061,4177,1297,8460,1285,4294967296,256,4295076143,1345,512]

theorem envBound17231 : H12AffineFastState.Bounded env17231 := by
  intro p hp
  have h : env17231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17187_17231 : H12AffineEnvironment.transform 21 10249 env17187 = env17231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10249 env17187 == env17231) = true)

theorem identity17231 : scanCanonicalize (H12AffineFastState.compose env17231 (packedSelected [11] rootPS)) = affineNative (2^(14+1) ^^^ 2340) := by decide +kernel

theorem selectedBound17231 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env17232 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4176,2340,65536,1344,8461,1024,2341,4096,10249,5456,67616,8192,5376,2049,4177,1297,8460,1285,4294967296,256,4295041035,1345,512]

theorem envBound17232 : H12AffineFastState.Bounded env17232 := by
  intro p hp
  have h : env17232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17231_17232 : H12AffineEnvironment.transform 14 2340 env17231 = env17232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2340 env17231 == env17232) = true)

theorem identity17232 : scanCanonicalize (H12AffineFastState.compose env17232 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound17232 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env17233 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1297,8192,1345,2340,65536,1344,8461,1024,2341,1297,10249,65,67616,8192,17,2049,1344,1297,8460,1285,4294967296,256,4295041035,1345,512]

theorem envBound17233 : H12AffineFastState.Bounded env17233 := by
  intro p hp
  have h : env17233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17232_17233 : H12AffineEnvironment.transform 11 1297 env17232 = env17233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env17232 == env17233) = true)

def env17234 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,1297,8192,1297,2340,65536,1296,8461,1024,2341,1297,10249,17,67616,8192,17,2049,1296,1297,8460,1285,4294967296,256,4295041035,1297,512]

theorem envBound17234 : H12AffineFastState.Bounded env17234 := by
  intro p hp
  have h : env17234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17233_17234 : H12AffineEnvironment.transform 5 16 env17233 = env17234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17233 == env17234) = true)

theorem identity17234 : scanCanonicalize (H12AffineFastState.compose env17234 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 2083) := by decide +kernel

theorem selectedBound17234 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17235 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,1297,8192,1297,2340,2083,1296,8461,1024,2341,1297,10249,17,3,8192,17,2049,1296,1297,8460,1285,4294967296,256,4294977576,1297,512]

theorem envBound17235 : H12AffineFastState.Bounded env17235 := by
  intro p hp
  have h : env17235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17234_17235 : H12AffineEnvironment.transform 15 2083 env17234 = env17235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2083 env17234 == env17235) = true)

theorem identity17235 : scanCanonicalize (H12AffineFastState.compose env17235 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 33) := by decide +kernel

theorem selectedBound17235 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17236 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,1297,8192,1297,2340,2083,1296,8461,1024,2341,1297,10249,17,3,8192,17,2049,1296,1297,8460,1285,33,256,10249,1297,512]

theorem envBound17236 : H12AffineFastState.Bounded env17236 := by
  intro p hp
  have h : env17236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17235_17236 : H12AffineEnvironment.transform 31 33 env17235 = env17236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 33 env17235 == env17236) = true)

theorem identity17236 : scanCanonicalize (H12AffineFastState.compose env17236 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound17236 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env17237 : List Nat := [2,4,8,16,32,16,8,256,0,1024,2048,1297,8192,1297,2340,2083,1296,8461,1024,2341,1297,10249,17,3,8192,17,2049,1296,1297,8460,1285,33,256,10249,1297,0]

theorem envBound17237 : H12AffineFastState.Bounded env17237 := by
  intro p hp
  have h : env17237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17236_17237 : H12AffineEnvironment.transform 8 0 env17236 = env17237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env17236 == env17237) = true)

theorem identity17237 : scanCanonicalize (H12AffineFastState.compose env17237 (packedSelected [0,2] rootPS)) = affineNative (2^(12+1) ^^^ 2317) := by decide +kernel

theorem selectedBound17237 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env17238 : List Nat := [2,4,8,16,32,16,8,256,0,1024,2048,1297,2317,1297,2340,2083,1296,2048,1024,2341,1297,260,17,3,2317,17,2049,1296,1297,2049,1285,33,256,260,1297,0]

theorem envBound17238 : H12AffineFastState.Bounded env17238 := by
  intro p hp
  have h : env17238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17237_17238 : H12AffineEnvironment.transform 12 2317 env17237 = env17238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2317 env17237 == env17238) = true)

theorem identity17238 : scanCanonicalize (H12AffineFastState.compose env17238 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound17238 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17239 : List Nat := [2,4,8,16,0,16,8,256,0,1024,2048,1297,2317,1297,2308,2051,1296,2048,1024,2309,1297,260,17,3,2317,17,2049,1296,1297,2049,1285,1,256,260,1297,0]

theorem envBound17239 : H12AffineFastState.Bounded env17239 := by
  intro p hp
  have h : env17239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17238_17239 : H12AffineEnvironment.transform 4 0 env17238 = env17239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17238 == env17239) = true)

def leafEnv17239 : List Nat := [2,4,8,16,0,16,8,256,0,1024,2048,1297,2317,1297,2308,2051,1296,2048,1024,2309,1297,260,17,3,1285,2317,1,17,2049,1296,1297,2049,1285,1,256,260,4,2050,1297,0,0,1297,1]

def active17239 : List Nat := [0,1,2,3,7,9,10]

def tree17239 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17239 : H12WitnessSearch.Good tree17239 := H12GlobalWitnessIndex.good

theorem leafIdentity17239 : H12AffineFastState.composeSystem env17239 rootObs = leafEnv17239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17239 rootObs == leafEnv17239) = true)

theorem terminalChecked17239 : H12PackedTerminal.terminalCheckFast leafEnv17239 active17239 tree17239 = true := by decide +kernel

def env17240 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1297,8192,1296,2340,65536,1297,8461,1024,2341,1297,10249,16,67616,8192,17,2049,1297,1297,8460,1285,4294967296,256,4295041035,1296,512]

theorem envBound17240 : H12AffineFastState.Bounded env17240 := by
  intro p hp
  have h : env17240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17233_17240 : H12AffineEnvironment.transform 5 17 env17233 = env17240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17233 == env17240) = true)

theorem identity17240 : scanCanonicalize (H12AffineFastState.compose env17240 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound17240 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env17241 : List Nat := [2,4,8,16,32,17,8,256,0,1024,2048,1297,8192,1296,2340,65536,1297,8461,1024,2341,1297,10249,16,67616,8192,17,2049,1297,1297,8460,1285,4294967296,256,4295041035,1296,0]

theorem envBound17241 : H12AffineFastState.Bounded env17241 := by
  intro p hp
  have h : env17241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17240_17241 : H12AffineEnvironment.transform 8 0 env17240 = env17241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env17240 == env17241) = true)

def env17242 : List Nat := [2,4,8,16,32,17,8,256,0,272,2048,1,8192,0,2340,65536,1,8461,272,2341,1,10249,16,67616,8192,17,2049,1,1,8460,21,4294967296,256,4295041035,0,0]

theorem envBound17242 : H12AffineFastState.Bounded env17242 := by
  intro p hp
  have h : env17242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17241_17242 : H12AffineEnvironment.transform 9 272 env17241 = env17242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env17241 == env17242) = true)

theorem identity17242 : scanCanonicalize (H12AffineFastState.compose env17242 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 73770) := by decide +kernel

theorem selectedBound17242 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17243 : List Nat := [2,4,8,16,32,17,8,256,0,272,2048,1,8192,0,2340,65536,1,8461,272,2341,1,10249,16,67616,8192,17,2049,1,1,8460,21,73770,256,33,0,0]

theorem envBound17243 : H12AffineFastState.Bounded env17243 := by
  intro p hp
  have h : env17243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17242_17243 : H12AffineEnvironment.transform 31 73770 env17242 = env17243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 73770 env17242 == env17243) = true)

def env17244 : List Nat := [2,4,8,16,32,17,8,256,0,272,2048,1,2088,0,2340,65536,1,2341,272,2341,1,33,16,67616,2088,17,2049,1,1,2340,21,67586,256,33,0,0]

theorem envBound17244 : H12AffineFastState.Bounded env17244 := by
  intro p hp
  have h : env17244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17243_17244 : H12AffineEnvironment.transform 12 2088 env17243 = env17244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env17243 == env17244) = true)

theorem identity17244 : scanCanonicalize (H12AffineFastState.compose env17244 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound17244 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env17245 : List Nat := [2,4,8,16,0,17,8,256,0,272,2048,1,2056,0,2308,65536,1,2309,272,2309,1,1,16,67584,2056,17,2049,1,1,2308,21,67586,256,1,0,0]

theorem envBound17245 : H12AffineFastState.Bounded env17245 := by
  intro p hp
  have h : env17245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17244_17245 : H12AffineEnvironment.transform 4 0 env17244 = env17245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17244 == env17245) = true)

def env17246 : List Nat := [2,4,8,16,0,17,8,256,0,272,260,1,268,0,0,65536,1,1,272,1,1,1,16,65796,268,17,261,1,1,0,21,65798,256,1,0,0]

theorem envBound17246 : H12AffineFastState.Bounded env17246 := by
  intro p hp
  have h : env17246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17245_17246 : H12AffineEnvironment.transform 10 260 env17245 = env17246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env17245 == env17246) = true)

theorem identity17246 : scanCanonicalize (H12AffineFastState.compose env17246 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound17246 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17247 : List Nat := [2,4,8,16,0,17,8,256,0,272,260,1,268,0,0,262,1,1,272,1,1,1,16,2,268,17,261,1,1,0,21,0,256,1,0,0]

theorem envBound17247 : H12AffineFastState.Bounded env17247 := by
  intro p hp
  have h : env17247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17246_17247 : H12AffineEnvironment.transform 15 262 env17246 = env17247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env17246 == env17247) = true)

def leafEnv17247 : List Nat := [2,4,8,16,0,17,8,256,0,272,260,1,268,0,0,262,1,1,272,1,1,1,16,2,21,268,1,17,261,1,1,0,21,0,256,1,4,262,0,0,0,1,1]

def active17247 : List Nat := [0,1,2,3,7]

def tree17247 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17247 : H12WitnessSearch.Good tree17247 := H12GlobalWitnessIndex.good

theorem leafIdentity17247 : H12AffineFastState.composeSystem env17247 rootObs = leafEnv17247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17247 rootObs == leafEnv17247) = true)

theorem terminalChecked17247 : H12PackedTerminal.terminalCheckFast leafEnv17247 active17247 tree17247 = true := by decide +kernel

def env17248 : List Nat := [2,4,8,16,0,17,8,256,0,272,261,1,269,0,1,65536,1,0,272,0,1,1,16,65797,269,17,260,1,1,1,21,65799,256,1,0,0]

theorem envBound17248 : H12AffineFastState.Bounded env17248 := by
  intro p hp
  have h : env17248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17245_17248 : H12AffineEnvironment.transform 10 261 env17245 = env17248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env17245 == env17248) = true)

def env17249 : List Nat := [2,4,8,16,32,17,8,256,0,272,2048,1,2089,0,2340,65536,1,2340,272,2341,1,32,16,67616,2089,17,2049,1,1,2341,21,67587,256,33,0,0]

theorem envBound17249 : H12AffineFastState.Bounded env17249 := by
  intro p hp
  have h : env17249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17243_17249 : H12AffineEnvironment.transform 12 2089 env17243 = env17249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2089 env17243 == env17249) = true)

theorem identity17249 : scanCanonicalize (H12AffineFastState.compose env17249 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 2343) := by decide +kernel

theorem selectedBound17249 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env17250 : List Nat := [2,4,8,16,32,17,8,256,0,272,2048,1,2089,0,2340,2343,1,2340,272,2341,1,32,16,263,2089,17,2049,1,1,2341,21,292,256,33,0,0]

theorem envBound17250 : H12AffineFastState.Bounded env17250 := by
  intro p hp
  have h : env17250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17249_17250 : H12AffineEnvironment.transform 15 2343 env17249 = env17250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2343 env17249 == env17250) = true)

theorem identity17250 : scanCanonicalize (H12AffineFastState.compose env17250 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound17250 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17251 : List Nat := [2,4,8,16,32,17,8,36,0,52,2048,1,2089,0,2048,2051,1,2048,52,2049,1,32,16,35,2089,17,2049,1,1,2049,21,0,36,33,0,0]

theorem envBound17251 : H12AffineFastState.Bounded env17251 := by
  intro p hp
  have h : env17251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17250_17251 : H12AffineEnvironment.transform 7 36 env17250 = env17251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env17250 == env17251) = true)

def env17252 : List Nat := [2,4,8,16,32,17,8,36,0,52,0,1,41,0,0,3,1,0,52,1,1,32,16,35,41,17,1,1,1,1,21,0,36,33,0,0]

theorem envBound17252 : H12AffineFastState.Bounded env17252 := by
  intro p hp
  have h : env17252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17251_17252 : H12AffineEnvironment.transform 10 0 env17251 = env17252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env17251 == env17252) = true)

def leafEnv17252 : List Nat := [2,4,8,16,32,17,8,36,0,52,0,1,41,0,0,3,1,0,52,1,1,32,16,35,21,41,1,17,1,1,1,1,21,0,36,33,4,34,0,0,0,1,1]

def active17252 : List Nat := [0,1,2,3,4]

def tree17252 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17252 : H12WitnessSearch.Good tree17252 := H12GlobalWitnessIndex.good

theorem leafIdentity17252 : H12AffineFastState.composeSystem env17252 rootObs = leafEnv17252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17252 rootObs == leafEnv17252) = true)

theorem terminalChecked17252 : H12PackedTerminal.terminalCheckFast leafEnv17252 active17252 tree17252 = true := by decide +kernel

def env17253 : List Nat := [2,4,8,16,32,17,8,36,0,52,1,1,40,0,1,2,1,1,52,0,1,32,16,35,40,17,0,1,1,0,21,0,36,33,0,0]

theorem envBound17253 : H12AffineFastState.Bounded env17253 := by
  intro p hp
  have h : env17253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17251_17253 : H12AffineEnvironment.transform 10 1 env17251 = env17253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env17251 == env17253) = true)

theorem identity17253 : scanCanonicalize (H12AffineFastState.compose env17253 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound17253 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17254 : List Nat := [2,4,8,16,0,17,8,4,0,20,1,1,8,0,1,2,1,1,20,0,1,0,16,3,8,17,0,1,1,0,21,0,4,1,0,0]

theorem envBound17254 : H12AffineFastState.Bounded env17254 := by
  intro p hp
  have h : env17254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17253_17254 : H12AffineEnvironment.transform 4 0 env17253 = env17254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17253 == env17254) = true)

def leafEnv17254 : List Nat := [2,4,8,16,0,17,8,4,0,20,1,1,8,0,1,2,1,1,20,0,1,0,16,3,21,8,1,17,0,1,1,0,21,0,4,1,4,3,0,0,0,1,1]

def active17254 : List Nat := [0,1,2,3]

def tree17254 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17254 : H12WitnessSearch.Good tree17254 := H12GlobalWitnessIndex.good

theorem leafIdentity17254 : H12AffineFastState.composeSystem env17254 rootObs = leafEnv17254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17254 rootObs == leafEnv17254) = true)

theorem terminalChecked17254 : H12PackedTerminal.terminalCheckFast leafEnv17254 active17254 tree17254 = true := by decide +kernel

def env17255 : List Nat := [2,4,8,16,32,17,8,256,0,273,2048,0,8192,1,2340,65536,0,8461,273,2341,0,10249,16,67616,8192,17,2049,0,0,8460,20,4294967296,256,4295041035,1,0]

theorem envBound17255 : H12AffineFastState.Bounded env17255 := by
  intro p hp
  have h : env17255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17241_17255 : H12AffineEnvironment.transform 9 273 env17241 = env17255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env17241 == env17255) = true)

theorem identity17255 : scanCanonicalize (H12AffineFastState.compose env17255 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 10249) := by decide +kernel

theorem selectedBound17255 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17256 : List Nat := [2,4,8,16,32,17,8,256,0,273,2048,0,8192,1,2340,65536,0,8461,273,2341,0,10249,16,67616,8192,17,2049,0,0,8460,20,10249,256,67586,1,0]

theorem envBound17256 : H12AffineFastState.Bounded env17256 := by
  intro p hp
  have h : env17256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17255_17256 : H12AffineEnvironment.transform 31 10249 env17255 = env17256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 10249 env17255 == env17256) = true)

def env17257 : List Nat := [2,4,8,16,32,17,8,256,0,273,2048,0,2088,1,2340,65536,0,2341,273,2341,0,33,16,67616,2088,17,2049,0,0,2340,20,33,256,67586,1,0]

theorem envBound17257 : H12AffineFastState.Bounded env17257 := by
  intro p hp
  have h : env17257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17256_17257 : H12AffineEnvironment.transform 12 2088 env17256 = env17257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env17256 == env17257) = true)

theorem identity17257 : scanCanonicalize (H12AffineFastState.compose env17257 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound17257 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env17258 : List Nat := [2,4,8,16,0,17,8,256,0,273,2048,0,2056,1,2308,65536,0,2309,273,2309,0,1,16,67584,2056,17,2049,0,0,2308,20,1,256,67586,1,0]

theorem envBound17258 : H12AffineFastState.Bounded env17258 := by
  intro p hp
  have h : env17258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17257_17258 : H12AffineEnvironment.transform 4 0 env17257 = env17258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17257 == env17258) = true)

def env17259 : List Nat := [2,4,8,16,0,17,8,256,0,273,260,0,268,1,0,65536,0,1,273,1,0,1,16,65796,268,17,261,0,0,0,20,1,256,65798,1,0]

theorem envBound17259 : H12AffineFastState.Bounded env17259 := by
  intro p hp
  have h : env17259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17258_17259 : H12AffineEnvironment.transform 10 260 env17258 = env17259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env17258 == env17259) = true)

def env17260 : List Nat := [2,4,8,16,0,17,8,256,0,273,261,0,269,1,1,65536,0,0,273,0,0,1,16,65797,269,17,260,0,0,1,20,1,256,65799,1,0]

theorem envBound17260 : H12AffineFastState.Bounded env17260 := by
  intro p hp
  have h : env17260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17258_17260 : H12AffineEnvironment.transform 10 261 env17258 = env17260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env17258 == env17260) = true)

theorem identity17260 : scanCanonicalize (H12AffineFastState.compose env17260 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound17260 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17261 : List Nat := [2,4,8,16,0,17,8,256,0,273,261,0,269,1,1,263,0,0,273,0,0,1,16,2,269,17,260,0,0,1,20,1,256,0,1,0]

theorem envBound17261 : H12AffineFastState.Bounded env17261 := by
  intro p hp
  have h : env17261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17260_17261 : H12AffineEnvironment.transform 15 263 env17260 = env17261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env17260 == env17261) = true)

def leafEnv17261 : List Nat := [2,4,8,16,0,17,8,256,0,273,261,0,269,1,1,263,0,0,273,0,0,1,16,2,20,269,1,17,260,0,0,1,20,1,256,0,4,263,1,0,0,0,1]

def active17261 : List Nat := [0,1,2,3,7]

def tree17261 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17261 : H12WitnessSearch.Good tree17261 := H12GlobalWitnessIndex.good

theorem leafIdentity17261 : H12AffineFastState.composeSystem env17261 rootObs = leafEnv17261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17261 rootObs == leafEnv17261) = true)

theorem terminalChecked17261 : H12PackedTerminal.terminalCheckFast leafEnv17261 active17261 tree17261 = true := by decide +kernel

def env17262 : List Nat := [2,4,8,16,32,17,8,256,0,273,2048,0,2089,1,2340,65536,0,2340,273,2341,0,32,16,67616,2089,17,2049,0,0,2341,20,32,256,67586,1,0]

theorem envBound17262 : H12AffineFastState.Bounded env17262 := by
  intro p hp
  have h : env17262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17256_17262 : H12AffineEnvironment.transform 12 2089 env17256 = env17262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2089 env17256 == env17262) = true)

theorem identity17262 : scanCanonicalize (H12AffineFastState.compose env17262 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound17262 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env17263 : List Nat := [2,4,8,16,32,17,8,4,0,21,2048,0,2089,1,2080,65536,0,2080,21,2081,0,32,16,67616,2089,17,2049,0,0,2081,20,32,4,67586,1,0]

theorem envBound17263 : H12AffineFastState.Bounded env17263 := by
  intro p hp
  have h : env17263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17262_17263 : H12AffineEnvironment.transform 7 4 env17262 = env17263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env17262 == env17263) = true)

theorem identity17263 : scanCanonicalize (H12AffineFastState.compose env17263 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 2051) := by decide +kernel

theorem selectedBound17263 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17264 : List Nat := [2,4,8,16,32,17,8,4,0,21,2048,0,2089,1,2080,2051,0,2080,21,2081,0,32,16,35,2089,17,2049,0,0,2081,20,32,4,1,1,0]

theorem envBound17264 : H12AffineFastState.Bounded env17264 := by
  intro p hp
  have h : env17264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17263_17264 : H12AffineEnvironment.transform 15 2051 env17263 = env17264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2051 env17263 == env17264) = true)

def env17265 : List Nat := [2,4,8,16,32,17,8,4,0,21,0,0,41,1,32,3,0,32,21,33,0,32,16,35,41,17,1,0,0,33,20,32,4,1,1,0]

theorem envBound17265 : H12AffineFastState.Bounded env17265 := by
  intro p hp
  have h : env17265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17264_17265 : H12AffineEnvironment.transform 10 0 env17264 = env17265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env17264 == env17265) = true)

theorem identity17265 : scanCanonicalize (H12AffineFastState.compose env17265 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound17265 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17266 : List Nat := [2,4,8,16,0,17,8,4,0,21,0,0,9,1,0,3,0,0,21,1,0,0,16,3,9,17,1,0,0,1,20,0,4,1,1,0]

theorem envBound17266 : H12AffineFastState.Bounded env17266 := by
  intro p hp
  have h : env17266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17265_17266 : H12AffineEnvironment.transform 4 0 env17265 = env17266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17265 == env17266) = true)

def leafEnv17266 : List Nat := [2,4,8,16,0,17,8,4,0,21,0,0,9,1,0,3,0,0,21,1,0,0,16,3,20,9,1,17,1,0,0,1,20,0,4,1,4,2,1,0,0,0,1]

def active17266 : List Nat := [0,1,2,3]

def tree17266 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17266 : H12WitnessSearch.Good tree17266 := H12GlobalWitnessIndex.good

theorem leafIdentity17266 : H12AffineFastState.composeSystem env17266 rootObs = leafEnv17266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17266 rootObs == leafEnv17266) = true)

theorem terminalChecked17266 : H12PackedTerminal.terminalCheckFast leafEnv17266 active17266 tree17266 = true := by decide +kernel

def env17267 : List Nat := [2,4,8,16,32,17,8,4,0,21,1,0,40,1,33,2,0,33,21,32,0,32,16,35,40,17,0,0,0,32,20,32,4,1,1,0]

theorem envBound17267 : H12AffineFastState.Bounded env17267 := by
  intro p hp
  have h : env17267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17264_17267 : H12AffineEnvironment.transform 10 1 env17264 = env17267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env17264 == env17267) = true)

def leafEnv17267 : List Nat := [2,4,8,16,32,17,8,4,0,21,1,0,40,1,33,2,0,33,21,32,0,32,16,35,20,40,1,17,0,0,0,32,20,32,4,1,4,35,1,0,0,0,1]

def active17267 : List Nat := [0,1,2,3,4]

def tree17267 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17267 : H12WitnessSearch.Good tree17267 := H12GlobalWitnessIndex.good

theorem leafIdentity17267 : H12AffineFastState.composeSystem env17267 rootObs = leafEnv17267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17267 rootObs == leafEnv17267) = true)

theorem terminalChecked17267 : H12PackedTerminal.terminalCheckFast leafEnv17267 active17267 tree17267 = true := by decide +kernel

def env17268 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4176,32768,65536,1344,262144,1024,32769,4096,4194304,5456,98564,8193,5376,134217728,4177,1297,1073741824,1285,4294967296,256,4299260199,138675268,512]

theorem envBound17268 : H12AffineFastState.Bounded env17268 := by
  intro p hp
  have h : env17268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17183_17268 : H12AffineEnvironment.transform 6 9 env17183 = env17268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17183 == env17268) = true)

theorem identity17268 : scanCanonicalize (H12AffineFastState.compose env17268 (packedSelected [10,17,41] rootPS)) = affineNative (2^(29+1) ^^^ 134258729) := by decide +kernel

theorem selectedBound17268 : packedSelected [10,17,41] rootPS < 2^1333 := by decide +kernel

def env17269 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4176,32768,65536,1344,262144,1024,32769,4096,4194304,5456,98564,8193,5376,134217728,4177,1297,134258729,1285,4294967296,256,4299260199,138675268,512]

theorem envBound17269 : H12AffineFastState.Bounded env17269 := by
  intro p hp
  have h : env17269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17268_17269 : H12AffineEnvironment.transform 29 134258729 env17268 = env17269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 134258729 env17268 == env17269) = true)

theorem identity17269 : scanCanonicalize (H12AffineFastState.compose env17269 (packedSelected [1,3,10,12,15,17,24,28,38] rootPS)) = affineNative (2^(26+1) ^^^ 4456709) := by decide +kernel

theorem selectedBound17269 : packedSelected [1,3,10,12,15,17,24,28,38] rootPS < 2^1333 := by decide +kernel

def env17270 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4176,32768,65536,1344,262144,1024,32769,4096,4194304,5456,98564,8193,5376,4456709,4177,1297,4497708,1285,4294967296,256,4299260199,1345,512]

theorem envBound17270 : H12AffineFastState.Bounded env17270 := by
  intro p hp
  have h : env17270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17269_17270 : H12AffineEnvironment.transform 26 4456709 env17269 = env17270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4456709 env17269 == env17270) = true)

theorem identity17270 : scanCanonicalize (H12AffineFastState.compose env17270 (packedSelected [1,3,10,13,15] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound17270 : packedSelected [1,3,10,13,15] rootPS < 2^1333 := by decide +kernel

def env17271 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4176,32768,65536,1344,43049,1024,32769,4096,4194304,5456,98564,8193,5376,4237612,4177,1297,4196613,1285,4294967296,256,4299260199,1345,512]

theorem envBound17271 : H12AffineFastState.Bounded env17271 := by
  intro p hp
  have h : env17271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17270_17271 : H12AffineEnvironment.transform 17 43049 env17270 = env17271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env17270 == env17271) = true)

def env17272 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4176,32768,65536,1344,43049,1024,32769,4096,10248,5456,98564,8193,5376,33060,4177,1297,8461,1285,4294967296,256,4295076143,1345,512]

theorem envBound17272 : H12AffineFastState.Bounded env17272 := by
  intro p hp
  have h : env17272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17271_17272 : H12AffineEnvironment.transform 21 10248 env17271 = env17272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10248 env17271 == env17272) = true)

def env17273 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4176,8232,65536,1344,2049,1024,8233,4096,10248,5456,74028,8193,5376,8460,4177,1297,8461,1285,4294967296,256,4295035143,1345,512]

theorem envBound17273 : H12AffineFastState.Bounded env17273 := by
  intro p hp
  have h : env17273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17272_17273 : H12AffineEnvironment.transform 14 8232 env17272 = env17273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env17272 == env17273) = true)

theorem identity17273 : scanCanonicalize (H12AffineFastState.compose env17273 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 7196) := by decide +kernel

theorem selectedBound17273 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env17274 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,7196,4176,7220,65536,1344,2049,1024,7221,4096,5140,5456,73008,7197,5376,7440,4177,1297,7441,1285,4294967296,256,4295035143,1345,512]

theorem envBound17274 : H12AffineFastState.Bounded env17274 := by
  intro p hp
  have h : env17274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17273_17274 : H12AffineEnvironment.transform 12 7196 env17273 = env17274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7196 env17273 == env17274) = true)

def env17275 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1344,2396,1296,2420,65536,1344,2049,1024,2421,1344,340,16,67696,2397,64,2128,1297,1297,2129,1285,4294967296,256,4295035143,1345,512]

theorem envBound17275 : H12AffineFastState.Bounded env17275 := by
  intro p hp
  have h : env17275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17274_17275 : H12AffineEnvironment.transform 11 1344 env17274 = env17275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env17274 == env17275) = true)

theorem identity17275 : scanCanonicalize (H12AffineFastState.compose env17275 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound17275 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env17276 : List Nat := [2,4,8,16,32,64,9,256,81,1024,2048,1344,2396,1296,2420,65536,1344,2049,1024,2421,1344,340,16,67696,2397,64,2128,1297,1297,2129,1285,4294967296,256,4295035143,1345,81]

theorem envBound17276 : H12AffineFastState.Bounded env17276 := by
  intro p hp
  have h : env17276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17275_17276 : H12AffineEnvironment.transform 8 81 env17275 = env17276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env17275 == env17276) = true)

theorem identity17276 : scanCanonicalize (H12AffineFastState.compose env17276 (packedSelected [0,1,2,3,4,6] rootPS)) = affineNative (2^(15+1) ^^^ 2162) := by decide +kernel

theorem selectedBound17276 : packedSelected [0,1,2,3,4,6] rootPS < 2^1333 := by decide +kernel

def env17277 : List Nat := [2,4,8,16,32,64,9,256,81,1024,2048,1344,2396,1296,2420,2162,1344,2049,1024,2421,1344,340,16,2,2397,64,2128,1297,1297,2129,1285,4294967296,256,4294967669,1345,81]

theorem envBound17277 : H12AffineFastState.Bounded env17277 := by
  intro p hp
  have h : env17277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17276_17277 : H12AffineEnvironment.transform 15 2162 env17276 = env17277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2162 env17276 == env17277) = true)

theorem identity17277 : scanCanonicalize (H12AffineFastState.compose env17277 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 260) := by decide +kernel

theorem selectedBound17277 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17278 : List Nat := [2,4,8,16,32,64,9,256,81,1024,2048,1344,2396,1296,2420,2162,1344,2049,1024,2421,1344,340,16,2,2397,64,2128,1297,1297,2129,1285,260,256,113,1345,81]

theorem envBound17278 : H12AffineFastState.Bounded env17278 := by
  intro p hp
  have h : env17278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17277_17278 : H12AffineEnvironment.transform 31 260 env17277 = env17278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 260 env17277 == env17278) = true)

theorem identity17278 : scanCanonicalize (H12AffineFastState.compose env17278 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound17278 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17279 : List Nat := [2,4,8,16,0,64,9,256,81,1024,2048,1344,2396,1296,2388,2130,1344,2049,1024,2389,1344,340,16,2,2397,64,2128,1297,1297,2129,1285,260,256,81,1345,81]

theorem envBound17279 : H12AffineFastState.Bounded env17279 := by
  intro p hp
  have h : env17279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17278_17279 : H12AffineEnvironment.transform 4 0 env17278 = env17279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17278 == env17279) = true)

theorem identity17279 : scanCanonicalize (H12AffineFastState.compose env17279 (packedSelected [4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound17279 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env17280 : List Nat := [2,4,8,16,0,16,9,256,1,1024,2048,1296,2316,1296,2308,2050,1296,2049,1024,2309,1296,260,16,2,2317,16,2048,1297,1297,2049,1285,260,256,1,1297,1]

theorem envBound17280 : H12AffineFastState.Bounded env17280 := by
  intro p hp
  have h : env17280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17279_17280 : H12AffineEnvironment.transform 5 16 env17279 = env17280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17279 == env17280) = true)

def leafEnv17280 : List Nat := [2,4,8,16,0,16,9,256,1,1024,2048,1296,2316,1296,2308,2050,1296,2049,1024,2309,1296,260,16,2,1285,2317,1,16,2048,1297,1297,2049,1285,260,256,1,4,2050,1297,1,0,1297,1]

def active17280 : List Nat := [0,1,2,3,7,9,10]

def tree17280 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17280 : H12WitnessSearch.Good tree17280 := H12GlobalWitnessIndex.good

theorem leafIdentity17280 : H12AffineFastState.composeSystem env17280 rootObs = leafEnv17280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17280 rootObs == leafEnv17280) = true)

theorem terminalChecked17280 : H12PackedTerminal.terminalCheckFast leafEnv17280 active17280 tree17280 = true := by decide +kernel

def env17281 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1345,2397,1297,2421,65536,1344,2049,1024,2420,1345,341,17,67697,2396,65,2129,1296,1297,2128,1285,4294967296,256,4295035143,1345,512]

theorem envBound17281 : H12AffineFastState.Bounded env17281 := by
  intro p hp
  have h : env17281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17274_17281 : H12AffineEnvironment.transform 11 1345 env17274 = env17281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env17274 == env17281) = true)

theorem identity17281 : scanCanonicalize (H12AffineFastState.compose env17281 (packedSelected [5] rootPS)) = affineNative (2^(15+1) ^^^ 2082) := by decide +kernel

theorem selectedBound17281 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env17282 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1345,2397,1297,2421,2082,1344,2049,1024,2420,1345,341,17,83,2396,65,2129,1296,1297,2128,1285,4294967296,256,4294967589,1345,512]

theorem envBound17282 : H12AffineFastState.Bounded env17282 := by
  intro p hp
  have h : env17282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17281_17282 : H12AffineEnvironment.transform 15 2082 env17281 = env17282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2082 env17281 == env17282) = true)

theorem identity17282 : scanCanonicalize (H12AffineFastState.compose env17282 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound17282 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17283 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,1296,2316,1297,2340,2082,1297,2049,1024,2341,1296,260,17,2,2317,16,2048,1296,1297,2049,1285,4294967296,256,4294967589,1296,512]

theorem envBound17283 : H12AffineFastState.Bounded env17283 := by
  intro p hp
  have h : env17283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17282_17283 : H12AffineEnvironment.transform 5 17 env17282 = env17283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17282 == env17283) = true)

theorem identity17283 : scanCanonicalize (H12AffineFastState.compose env17283 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 293) := by decide +kernel

theorem selectedBound17283 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17284 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,1296,2316,1297,2340,2082,1297,2049,1024,2341,1296,260,17,2,2317,16,2048,1296,1297,2049,1285,293,256,0,1296,512]

theorem envBound17284 : H12AffineFastState.Bounded env17284 := by
  intro p hp
  have h : env17284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17283_17284 : H12AffineEnvironment.transform 31 293 env17283 = env17284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 293 env17283 == env17284) = true)

theorem identity17284 : scanCanonicalize (H12AffineFastState.compose env17284 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound17284 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17285 : List Nat := [2,4,8,16,32,17,9,5,512,1024,2048,1045,2057,1044,2081,2082,1044,2049,1024,2080,1045,1,17,2,2056,16,2048,1045,1044,2049,1024,32,5,0,1045,512]

theorem envBound17285 : H12AffineFastState.Bounded env17285 := by
  intro p hp
  have h : env17285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17284_17285 : H12AffineEnvironment.transform 7 5 env17284 = env17285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env17284 == env17285) = true)

theorem identity17285 : scanCanonicalize (H12AffineFastState.compose env17285 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound17285 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17286 : List Nat := [2,4,8,16,32,17,9,5,1,1024,2048,1045,2057,1044,2081,2082,1044,2049,1024,2080,1045,1,17,2,2056,16,2048,1045,1044,2049,1024,32,5,0,1045,1]

theorem envBound17286 : H12AffineFastState.Bounded env17286 := by
  intro p hp
  have h : env17286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17285_17286 : H12AffineEnvironment.transform 8 1 env17285 = env17286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env17285 == env17286) = true)

def leafEnv17286 : List Nat := [2,4,8,16,32,17,9,5,1,1024,2048,1045,2057,1044,2081,2082,1044,2049,1024,2080,1045,1,17,2,1024,2056,1,16,2048,1045,1044,2049,1024,32,5,0,4,2082,1045,1,0,1044,1]

def active17286 : List Nat := [0,1,2,3,4,9,10]

def tree17286 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17286 : H12WitnessSearch.Good tree17286 := H12GlobalWitnessIndex.good

theorem leafIdentity17286 : H12AffineFastState.composeSystem env17286 rootObs = leafEnv17286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17286 rootObs == leafEnv17286) = true)

theorem terminalChecked17286 : H12PackedTerminal.terminalCheckFast leafEnv17286 active17286 tree17286 = true := by decide +kernel

def env17287 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4176,8233,65536,1344,2048,1024,8232,4096,10248,5456,74029,8193,5376,8461,4177,1297,8461,1285,4294967296,256,4295035142,1345,512]

theorem envBound17287 : H12AffineFastState.Bounded env17287 := by
  intro p hp
  have h : env17287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17272_17287 : H12AffineEnvironment.transform 14 8233 env17272 = env17287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env17272 == env17287) = true)

theorem identity17287 : scanCanonicalize (H12AffineFastState.compose env17287 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound17287 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env17288 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1297,8192,1345,8233,65536,1344,2048,1024,8232,1297,10248,65,74029,8193,17,8461,1344,1297,8461,1285,4294967296,256,4295035142,1345,512]

theorem envBound17288 : H12AffineFastState.Bounded env17288 := by
  intro p hp
  have h : env17288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17287_17288 : H12AffineEnvironment.transform 11 1297 env17287 = env17288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env17287 == env17288) = true)

theorem identity17288 : scanCanonicalize (H12AffineFastState.compose env17288 (packedSelected [1,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 2316) := by decide +kernel

theorem selectedBound17288 : packedSelected [1,5,10] rootPS < 2^1333 := by decide +kernel

def env17289 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1297,2316,1345,2341,65536,1344,2048,1024,2340,1297,260,65,67617,2317,17,2049,1344,1297,2049,1285,4294967296,256,4295035142,1345,512]

theorem envBound17289 : H12AffineFastState.Bounded env17289 := by
  intro p hp
  have h : env17289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17288_17289 : H12AffineEnvironment.transform 12 2316 env17288 = env17289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2316 env17288 == env17289) = true)

def env17290 : List Nat := [2,4,8,16,32,64,9,256,512,1024,292,1297,40,1345,1,65536,1344,292,1024,0,1297,260,65,65797,41,17,293,1344,1297,293,1285,4294967296,256,4295032866,1345,512]

theorem envBound17290 : H12AffineFastState.Bounded env17290 := by
  intro p hp
  have h : env17290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17289_17290 : H12AffineEnvironment.transform 10 292 env17289 = env17290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env17289 == env17290) = true)

theorem identity17290 : scanCanonicalize (H12AffineFastState.compose env17290 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 65650) := by decide +kernel

theorem selectedBound17290 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17291 : List Nat := [2,4,8,16,32,64,9,256,512,1024,292,1297,40,1345,1,65536,1344,292,1024,0,1297,260,65,65797,41,17,293,1344,1297,293,1285,65650,256,80,1345,512]

theorem envBound17291 : H12AffineFastState.Bounded env17291 := by
  intro p hp
  have h : env17291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17290_17291 : H12AffineEnvironment.transform 31 65650 env17290 = env17291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 65650 env17290 == env17291) = true)

def env17292 : List Nat := [2,4,8,16,32,16,9,256,512,1024,292,1297,40,1297,1,65536,1296,292,1024,0,1297,260,17,65797,41,17,293,1296,1297,293,1285,65570,256,0,1297,512]

theorem envBound17292 : H12AffineFastState.Bounded env17292 := by
  intro p hp
  have h : env17292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17291_17292 : H12AffineEnvironment.transform 5 16 env17291 = env17292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17291 == env17292) = true)

theorem identity17292 : scanCanonicalize (H12AffineFastState.compose env17292 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound17292 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17293 : List Nat := [2,4,8,16,32,16,9,256,512,1024,292,1297,40,1297,1,263,1296,292,1024,0,1297,260,17,2,41,17,293,1296,1297,293,1285,293,256,0,1297,512]

theorem envBound17293 : H12AffineFastState.Bounded env17293 := by
  intro p hp
  have h : env17293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17292_17293 : H12AffineEnvironment.transform 15 263 env17292 = env17293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env17292 == env17293) = true)

theorem identity17293 : scanCanonicalize (H12AffineFastState.compose env17293 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound17293 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17294 : List Nat := [2,4,8,16,32,16,9,4,512,1024,32,1045,40,1045,1,3,1044,32,1024,0,1045,0,17,2,41,17,33,1044,1045,33,1025,33,4,0,1045,512]

theorem envBound17294 : H12AffineFastState.Bounded env17294 := by
  intro p hp
  have h : env17294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17293_17294 : H12AffineEnvironment.transform 7 4 env17293 = env17294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env17293 == env17294) = true)

theorem identity17294 : scanCanonicalize (H12AffineFastState.compose env17294 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound17294 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17295 : List Nat := [2,4,8,16,32,16,9,4,32,1024,32,1045,40,1045,1,3,1044,32,1024,0,1045,0,17,2,41,17,33,1044,1045,33,1025,33,4,0,1045,32]

theorem envBound17295 : H12AffineFastState.Bounded env17295 := by
  intro p hp
  have h : env17295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17294_17295 : H12AffineEnvironment.transform 8 32 env17294 = env17295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env17294 == env17295) = true)

def env17296 : List Nat := [2,4,8,16,32,17,9,256,512,1024,292,1297,40,1296,1,65536,1297,292,1024,0,1297,260,16,65797,41,17,293,1297,1297,293,1285,65571,256,1,1296,512]

theorem envBound17296 : H12AffineFastState.Bounded env17296 := by
  intro p hp
  have h : env17296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17291_17296 : H12AffineEnvironment.transform 5 17 env17291 = env17296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17291 == env17296) = true)

theorem identity17296 : scanCanonicalize (H12AffineFastState.compose env17296 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound17296 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env17297 : List Nat := [2,4,8,16,32,17,9,256,0,1024,292,1297,40,1296,1,65536,1297,292,1024,0,1297,260,16,65797,41,17,293,1297,1297,293,1285,65571,256,1,1296,0]

theorem envBound17297 : H12AffineFastState.Bounded env17297 := by
  intro p hp
  have h : env17297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17296_17297 : H12AffineEnvironment.transform 8 0 env17296 = env17297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env17296 == env17297) = true)

theorem identity17297 : scanCanonicalize (H12AffineFastState.compose env17297 (packedSelected [2,4,6] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound17297 : packedSelected [2,4,6] rootPS < 2^1333 := by decide +kernel

def env17298 : List Nat := [2,4,8,16,32,17,9,256,0,1024,292,1297,40,1296,1,263,1297,292,1024,0,1297,260,16,2,41,17,293,1297,1297,293,1285,292,256,1,1296,0]

theorem envBound17298 : H12AffineFastState.Bounded env17298 := by
  intro p hp
  have h : env17298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17297_17298 : H12AffineEnvironment.transform 15 263 env17297 = env17298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env17297 == env17298) = true)

theorem identity17298 : scanCanonicalize (H12AffineFastState.compose env17298 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound17298 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17299 : List Nat := [2,4,8,16,1,17,9,256,0,1024,261,1297,9,1296,1,263,1297,261,1024,0,1297,260,16,2,8,17,260,1297,1297,260,1285,261,256,1,1296,0]

theorem envBound17299 : H12AffineFastState.Bounded env17299 := by
  intro p hp
  have h : env17299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17298_17299 : H12AffineEnvironment.transform 4 1 env17298 = env17299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17298 == env17299) = true)

theorem identity17299 : scanCanonicalize (H12AffineFastState.compose env17299 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound17299 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17300 : List Nat := [2,4,8,16,1,17,9,4,0,1024,1,1045,9,1044,1,3,1045,1,1024,0,1045,0,16,2,8,17,0,1045,1045,0,1025,1,4,1,1044,0]

theorem envBound17300 : H12AffineFastState.Bounded env17300 := by
  intro p hp
  have h : env17300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17299_17300 : H12AffineEnvironment.transform 7 4 env17299 = env17300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env17299 == env17300) = true)

def leafEnv17300 : List Nat := [2,4,8,16,1,17,9,4,0,1024,1,1045,9,1044,1,3,1045,1,1024,0,1045,0,16,2,1025,8,1,17,0,1045,1045,0,1025,1,4,1,4,3,1044,0,0,1045,1]

def active17300 : List Nat := [0,1,2,3,9]

def tree17300 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17300 : H12WitnessSearch.Good tree17300 := H12GlobalWitnessIndex.good

theorem leafIdentity17300 : H12AffineFastState.composeSystem env17300 rootObs = leafEnv17300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17300 rootObs == leafEnv17300) = true)

theorem terminalChecked17300 : H12PackedTerminal.terminalCheckFast leafEnv17300 active17300 tree17300 = true := by decide +kernel

def env17301 : List Nat := [2,4,8,16,32,64,9,256,512,1024,293,1297,41,1345,0,65536,1344,293,1024,1,1297,260,65,65796,40,17,292,1344,1297,292,1285,4294967296,256,4295032867,1345,512]

theorem envBound17301 : H12AffineFastState.Bounded env17301 := by
  intro p hp
  have h : env17301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17289_17301 : H12AffineEnvironment.transform 10 293 env17289 = env17301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env17289 == env17301) = true)

theorem identity17301 : scanCanonicalize (H12AffineFastState.compose env17301 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 373) := by decide +kernel

theorem selectedBound17301 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17302 : List Nat := [2,4,8,16,32,64,9,256,512,1024,293,1297,41,1345,0,65536,1344,293,1024,1,1297,260,65,65796,40,17,292,1344,1297,292,1285,373,256,65878,1345,512]

theorem envBound17302 : H12AffineFastState.Bounded env17302 := by
  intro p hp
  have h : env17302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17301_17302 : H12AffineEnvironment.transform 31 373 env17301 = env17302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 373 env17301 == env17302) = true)

def env17303 : List Nat := [2,4,8,16,32,16,9,256,512,1024,293,1297,41,1297,0,65536,1296,293,1024,1,1297,260,17,65796,40,17,292,1296,1297,292,1285,293,256,65798,1297,512]

theorem envBound17303 : H12AffineFastState.Bounded env17303 := by
  intro p hp
  have h : env17303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17302_17303 : H12AffineEnvironment.transform 5 16 env17302 = env17303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17302 == env17303) = true)

theorem identity17303 : scanCanonicalize (H12AffineFastState.compose env17303 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound17303 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17304 : List Nat := [2,4,8,16,32,16,9,256,512,1024,293,1297,41,1297,0,262,1296,293,1024,1,1297,260,17,2,40,17,292,1296,1297,292,1285,293,256,0,1297,512]

theorem envBound17304 : H12AffineFastState.Bounded env17304 := by
  intro p hp
  have h : env17304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17303_17304 : H12AffineEnvironment.transform 15 262 env17303 = env17304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env17303 == env17304) = true)

theorem identity17304 : scanCanonicalize (H12AffineFastState.compose env17304 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound17304 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17305 : List Nat := [2,4,8,16,32,16,9,4,512,1024,33,1045,41,1045,0,2,1044,33,1024,1,1045,0,17,2,40,17,32,1044,1045,32,1025,33,4,0,1045,512]

theorem envBound17305 : H12AffineFastState.Bounded env17305 := by
  intro p hp
  have h : env17305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17304_17305 : H12AffineEnvironment.transform 7 4 env17304 = env17305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env17304 == env17305) = true)

theorem identity17305 : scanCanonicalize (H12AffineFastState.compose env17305 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound17305 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17306 : List Nat := [2,4,8,16,32,16,9,4,32,1024,33,1045,41,1045,0,2,1044,33,1024,1,1045,0,17,2,40,17,32,1044,1045,32,1025,33,4,0,1045,32]

theorem envBound17306 : H12AffineFastState.Bounded env17306 := by
  intro p hp
  have h : env17306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17305_17306 : H12AffineEnvironment.transform 8 32 env17305 = env17306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env17305 == env17306) = true)

def env17307 : List Nat := [2,4,8,16,32,17,9,256,512,1024,293,1297,41,1296,0,65536,1297,293,1024,1,1297,260,16,65796,40,17,292,1297,1297,292,1285,292,256,65799,1296,512]

theorem envBound17307 : H12AffineFastState.Bounded env17307 := by
  intro p hp
  have h : env17307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17302_17307 : H12AffineEnvironment.transform 5 17 env17302 = env17307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17302 == env17307) = true)

theorem identity17307 : scanCanonicalize (H12AffineFastState.compose env17307 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound17307 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env17308 : List Nat := [2,4,8,16,32,17,9,256,0,1024,293,1297,41,1296,0,65536,1297,293,1024,1,1297,260,16,65796,40,17,292,1297,1297,292,1285,292,256,65799,1296,0]

theorem envBound17308 : H12AffineFastState.Bounded env17308 := by
  intro p hp
  have h : env17308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17307_17308 : H12AffineEnvironment.transform 8 0 env17307 = env17308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env17307 == env17308) = true)

theorem identity17308 : scanCanonicalize (H12AffineFastState.compose env17308 (packedSelected [2,4,6] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound17308 : packedSelected [2,4,6] rootPS < 2^1333 := by decide +kernel

def env17309 : List Nat := [2,4,8,16,32,17,9,256,0,1024,293,1297,41,1296,0,262,1297,293,1024,1,1297,260,16,2,40,17,292,1297,1297,292,1285,292,256,1,1296,0]

theorem envBound17309 : H12AffineFastState.Bounded env17309 := by
  intro p hp
  have h : env17309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17308_17309 : H12AffineEnvironment.transform 15 262 env17308 = env17309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env17308 == env17309) = true)

theorem identity17309 : scanCanonicalize (H12AffineFastState.compose env17309 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound17309 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17310 : List Nat := [2,4,8,16,1,17,9,256,0,1024,260,1297,8,1296,0,262,1297,260,1024,1,1297,260,16,2,9,17,261,1297,1297,261,1285,261,256,1,1296,0]

theorem envBound17310 : H12AffineFastState.Bounded env17310 := by
  intro p hp
  have h : env17310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17309_17310 : H12AffineEnvironment.transform 4 1 env17309 = env17310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17309 == env17310) = true)

theorem identity17310 : scanCanonicalize (H12AffineFastState.compose env17310 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound17310 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17311 : List Nat := [2,4,8,16,1,17,9,4,0,1024,0,1045,8,1044,0,2,1045,0,1024,1,1045,0,16,2,9,17,1,1045,1045,1,1025,1,4,1,1044,0]

theorem envBound17311 : H12AffineFastState.Bounded env17311 := by
  intro p hp
  have h : env17311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17310_17311 : H12AffineEnvironment.transform 7 4 env17310 = env17311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env17310 == env17311) = true)

def leafEnv17311 : List Nat := [2,4,8,16,1,17,9,4,0,1024,0,1045,8,1044,0,2,1045,0,1024,1,1045,0,16,2,1025,9,1,17,1,1045,1045,1,1025,1,4,1,4,2,1044,0,0,1045,1]

def active17311 : List Nat := [0,1,2,3,9]

def tree17311 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17311 : H12WitnessSearch.Good tree17311 := H12GlobalWitnessIndex.good

theorem leafIdentity17311 : H12AffineFastState.composeSystem env17311 rootObs = leafEnv17311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17311 rootObs == leafEnv17311) = true)

theorem terminalChecked17311 : H12PackedTerminal.terminalCheckFast leafEnv17311 active17311 tree17311 = true := by decide +kernel

def env17312 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4176,32768,65536,1344,43049,1024,32769,4096,10249,5456,98564,8193,5376,33061,4177,1297,8460,1285,4294967296,256,4295076142,1345,512]

theorem envBound17312 : H12AffineFastState.Bounded env17312 := by
  intro p hp
  have h : env17312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17271_17312 : H12AffineEnvironment.transform 21 10249 env17271 = env17312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10249 env17271 == env17312) = true)

theorem identity17312 : scanCanonicalize (H12AffineFastState.compose env17312 (packedSelected [11] rootPS)) = affineNative (2^(14+1) ^^^ 2340) := by decide +kernel

theorem selectedBound17312 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env17313 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4176,2340,65536,1344,8461,1024,2341,4096,10249,5456,67616,8193,5376,2049,4177,1297,8460,1285,4294967296,256,4295041034,1345,512]

theorem envBound17313 : H12AffineFastState.Bounded env17313 := by
  intro p hp
  have h : env17313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17312_17313 : H12AffineEnvironment.transform 14 2340 env17312 = env17313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2340 env17312 == env17313) = true)

theorem identity17313 : scanCanonicalize (H12AffineFastState.compose env17313 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound17313 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env17314 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1297,8192,1345,2340,65536,1344,8461,1024,2341,1297,10249,65,67616,8193,17,2049,1344,1297,8460,1285,4294967296,256,4295041034,1345,512]

theorem envBound17314 : H12AffineFastState.Bounded env17314 := by
  intro p hp
  have h : env17314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17313_17314 : H12AffineEnvironment.transform 11 1297 env17313 = env17314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env17313 == env17314) = true)

def env17315 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1297,8192,1297,2340,65536,1296,8461,1024,2341,1297,10249,17,67616,8193,17,2049,1296,1297,8460,1285,4294967296,256,4295041034,1297,512]

theorem envBound17315 : H12AffineFastState.Bounded env17315 := by
  intro p hp
  have h : env17315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17314_17315 : H12AffineEnvironment.transform 5 16 env17314 = env17315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17314 == env17315) = true)

theorem identity17315 : scanCanonicalize (H12AffineFastState.compose env17315 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 2082) := by decide +kernel

theorem selectedBound17315 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17316 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1297,8192,1297,2340,2082,1296,8461,1024,2341,1297,10249,17,2,8193,17,2049,1296,1297,8460,1285,4294967296,256,4294977576,1297,512]

theorem envBound17316 : H12AffineFastState.Bounded env17316 := by
  intro p hp
  have h : env17316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17315_17316 : H12AffineEnvironment.transform 15 2082 env17315 = env17316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2082 env17315 == env17316) = true)

theorem identity17316 : scanCanonicalize (H12AffineFastState.compose env17316 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 32) := by decide +kernel

theorem selectedBound17316 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17317 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1297,8192,1297,2340,2082,1296,8461,1024,2341,1297,10249,17,2,8193,17,2049,1296,1297,8460,1285,32,256,10248,1297,512]

theorem envBound17317 : H12AffineFastState.Bounded env17317 := by
  intro p hp
  have h : env17317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17316_17317 : H12AffineEnvironment.transform 31 32 env17316 = env17317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 32 env17316 == env17317) = true)

theorem identity17317 : scanCanonicalize (H12AffineFastState.compose env17317 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound17317 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env17318 : List Nat := [2,4,8,16,32,16,9,256,1,1024,2048,1297,8192,1297,2340,2082,1296,8461,1024,2341,1297,10249,17,2,8193,17,2049,1296,1297,8460,1285,32,256,10248,1297,1]

theorem envBound17318 : H12AffineFastState.Bounded env17318 := by
  intro p hp
  have h : env17318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17317_17318 : H12AffineEnvironment.transform 8 1 env17317 = env17318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env17317 == env17318) = true)

theorem identity17318 : scanCanonicalize (H12AffineFastState.compose env17318 (packedSelected [0,2] rootPS)) = affineNative (2^(12+1) ^^^ 2317) := by decide +kernel

theorem selectedBound17318 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env17319 : List Nat := [2,4,8,16,32,16,9,256,1,1024,2048,1297,2317,1297,2340,2082,1296,2048,1024,2341,1297,260,17,2,2316,17,2049,1296,1297,2049,1285,32,256,261,1297,1]

theorem envBound17319 : H12AffineFastState.Bounded env17319 := by
  intro p hp
  have h : env17319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17318_17319 : H12AffineEnvironment.transform 12 2317 env17318 = env17319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2317 env17318 == env17319) = true)

theorem identity17319 : scanCanonicalize (H12AffineFastState.compose env17319 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound17319 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17320 : List Nat := [2,4,8,16,32,16,9,5,1,1024,2048,1044,2056,1044,2081,2082,1045,2048,1024,2080,1044,1,17,2,2057,17,2049,1045,1044,2049,1024,32,5,0,1044,1]

theorem envBound17320 : H12AffineFastState.Bounded env17320 := by
  intro p hp
  have h : env17320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17319_17320 : H12AffineEnvironment.transform 7 5 env17319 = env17320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env17319 == env17320) = true)

def leafEnv17320 : List Nat := [2,4,8,16,32,16,9,5,1,1024,2048,1044,2056,1044,2081,2082,1045,2048,1024,2080,1044,1,17,2,1024,2057,1,17,2049,1045,1044,2049,1024,32,5,0,4,2082,1044,1,0,1044,1]

def active17320 : List Nat := [0,1,2,3,4,9,10]

def tree17320 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17320 : H12WitnessSearch.Good tree17320 := H12GlobalWitnessIndex.good

theorem leafIdentity17320 : H12AffineFastState.composeSystem env17320 rootObs = leafEnv17320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17320 rootObs == leafEnv17320) = true)

theorem terminalChecked17320 : H12PackedTerminal.terminalCheckFast leafEnv17320 active17320 tree17320 = true := by decide +kernel

def env17321 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,1297,8192,1296,2340,65536,1297,8461,1024,2341,1297,10249,16,67616,8193,17,2049,1297,1297,8460,1285,4294967296,256,4295041034,1296,512]

theorem envBound17321 : H12AffineFastState.Bounded env17321 := by
  intro p hp
  have h : env17321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17314_17321 : H12AffineEnvironment.transform 5 17 env17314 = env17321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17314 == env17321) = true)

theorem identity17321 : scanCanonicalize (H12AffineFastState.compose env17321 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound17321 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env17322 : List Nat := [2,4,8,16,32,17,9,256,1,1024,2048,1297,8192,1296,2340,65536,1297,8461,1024,2341,1297,10249,16,67616,8193,17,2049,1297,1297,8460,1285,4294967296,256,4295041034,1296,1]

theorem envBound17322 : H12AffineFastState.Bounded env17322 := by
  intro p hp
  have h : env17322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17321_17322 : H12AffineEnvironment.transform 8 1 env17321 = env17322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env17321 == env17322) = true)

def env17323 : List Nat := [2,4,8,16,32,17,9,256,1,272,2048,1,8192,0,2340,65536,1,8461,272,2341,1,10249,16,67616,8193,17,2049,1,1,8460,21,4294967296,256,4295041034,0,1]

theorem envBound17323 : H12AffineFastState.Bounded env17323 := by
  intro p hp
  have h : env17323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17322_17323 : H12AffineEnvironment.transform 9 272 env17322 = env17323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env17322 == env17323) = true)

theorem identity17323 : scanCanonicalize (H12AffineFastState.compose env17323 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 73770) := by decide +kernel

theorem selectedBound17323 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17324 : List Nat := [2,4,8,16,32,17,9,256,1,272,2048,1,8192,0,2340,65536,1,8461,272,2341,1,10249,16,67616,8193,17,2049,1,1,8460,21,73770,256,32,0,1]

theorem envBound17324 : H12AffineFastState.Bounded env17324 := by
  intro p hp
  have h : env17324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17323_17324 : H12AffineEnvironment.transform 31 73770 env17323 = env17324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 73770 env17323 == env17324) = true)

def env17325 : List Nat := [2,4,8,16,32,17,9,256,1,272,2048,1,2088,0,2340,65536,1,2341,272,2341,1,33,16,67616,2089,17,2049,1,1,2340,21,67586,256,32,0,1]

theorem envBound17325 : H12AffineFastState.Bounded env17325 := by
  intro p hp
  have h : env17325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17324_17325 : H12AffineEnvironment.transform 12 2088 env17324 = env17325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env17324 == env17325) = true)

theorem identity17325 : scanCanonicalize (H12AffineFastState.compose env17325 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound17325 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env17326 : List Nat := [2,4,8,16,0,17,9,256,1,272,2048,1,2056,0,2308,65536,1,2309,272,2309,1,1,16,67584,2057,17,2049,1,1,2308,21,67586,256,0,0,1]

theorem envBound17326 : H12AffineFastState.Bounded env17326 := by
  intro p hp
  have h : env17326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17325_17326 : H12AffineEnvironment.transform 4 0 env17325 = env17326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17325 == env17326) = true)

def env17327 : List Nat := [2,4,8,16,0,17,9,256,1,272,260,1,268,0,0,65536,1,1,272,1,1,1,16,65796,269,17,261,1,1,0,21,65798,256,0,0,1]

theorem envBound17327 : H12AffineFastState.Bounded env17327 := by
  intro p hp
  have h : env17327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17326_17327 : H12AffineEnvironment.transform 10 260 env17326 = env17327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env17326 == env17327) = true)

theorem identity17327 : scanCanonicalize (H12AffineFastState.compose env17327 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound17327 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17328 : List Nat := [2,4,8,16,0,17,9,256,1,272,260,1,268,0,0,263,1,1,272,1,1,1,16,3,269,17,261,1,1,0,21,1,256,0,0,1]

theorem envBound17328 : H12AffineFastState.Bounded env17328 := by
  intro p hp
  have h : env17328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17327_17328 : H12AffineEnvironment.transform 15 263 env17327 = env17328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env17327 == env17328) = true)

def leafEnv17328 : List Nat := [2,4,8,16,0,17,9,256,1,272,260,1,268,0,0,263,1,1,272,1,1,1,16,3,21,269,1,17,261,1,1,0,21,1,256,0,4,262,0,1,0,1,1]

def active17328 : List Nat := [0,1,2,3,7]

def tree17328 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17328 : H12WitnessSearch.Good tree17328 := H12GlobalWitnessIndex.good

theorem leafIdentity17328 : H12AffineFastState.composeSystem env17328 rootObs = leafEnv17328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17328 rootObs == leafEnv17328) = true)

theorem terminalChecked17328 : H12PackedTerminal.terminalCheckFast leafEnv17328 active17328 tree17328 = true := by decide +kernel

def env17329 : List Nat := [2,4,8,16,0,17,9,256,1,272,261,1,269,0,1,65536,1,0,272,0,1,1,16,65797,268,17,260,1,1,1,21,65799,256,0,0,1]

theorem envBound17329 : H12AffineFastState.Bounded env17329 := by
  intro p hp
  have h : env17329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17326_17329 : H12AffineEnvironment.transform 10 261 env17326 = env17329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env17326 == env17329) = true)

def env17330 : List Nat := [2,4,8,16,32,17,9,256,1,272,2048,1,2089,0,2340,65536,1,2340,272,2341,1,32,16,67616,2088,17,2049,1,1,2341,21,67587,256,32,0,1]

theorem envBound17330 : H12AffineFastState.Bounded env17330 := by
  intro p hp
  have h : env17330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17324_17330 : H12AffineEnvironment.transform 12 2089 env17324 = env17330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2089 env17324 == env17330) = true)

theorem identity17330 : scanCanonicalize (H12AffineFastState.compose env17330 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 2343) := by decide +kernel

theorem selectedBound17330 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env17331 : List Nat := [2,4,8,16,32,17,9,256,1,272,2048,1,2089,0,2340,2343,1,2340,272,2341,1,32,16,263,2088,17,2049,1,1,2341,21,292,256,32,0,1]

theorem envBound17331 : H12AffineFastState.Bounded env17331 := by
  intro p hp
  have h : env17331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17330_17331 : H12AffineEnvironment.transform 15 2343 env17330 = env17331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2343 env17330 == env17331) = true)

theorem identity17331 : scanCanonicalize (H12AffineFastState.compose env17331 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound17331 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17332 : List Nat := [2,4,8,16,1,17,9,256,1,272,2048,1,2056,0,2309,2310,1,2309,272,2308,1,1,16,263,2057,17,2049,1,1,2308,21,261,256,1,0,1]

theorem envBound17332 : H12AffineFastState.Bounded env17332 := by
  intro p hp
  have h : env17332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17331_17332 : H12AffineEnvironment.transform 4 1 env17331 = env17332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17331 == env17332) = true)

def env17333 : List Nat := [2,4,8,16,1,17,9,256,1,272,0,1,8,0,261,262,1,261,272,260,1,1,16,263,9,17,1,1,1,260,21,261,256,1,0,1]

theorem envBound17333 : H12AffineFastState.Bounded env17333 := by
  intro p hp
  have h : env17333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17332_17333 : H12AffineEnvironment.transform 10 0 env17332 = env17333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env17332 == env17333) = true)

theorem identity17333 : scanCanonicalize (H12AffineFastState.compose env17333 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound17333 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17334 : List Nat := [2,4,8,16,1,17,9,5,1,21,0,1,8,0,0,3,1,0,21,1,1,1,16,2,9,17,1,1,1,1,21,0,5,1,0,1]

theorem envBound17334 : H12AffineFastState.Bounded env17334 := by
  intro p hp
  have h : env17334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17333_17334 : H12AffineEnvironment.transform 7 5 env17333 = env17334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env17333 == env17334) = true)

def leafEnv17334 : List Nat := [2,4,8,16,1,17,9,5,1,21,0,1,8,0,0,3,1,0,21,1,1,1,16,2,21,9,1,17,1,1,1,1,21,0,5,1,4,3,0,1,0,1,1]

def active17334 : List Nat := [0,1,2,3]

def tree17334 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17334 : H12WitnessSearch.Good tree17334 := H12GlobalWitnessIndex.good

theorem leafIdentity17334 : H12AffineFastState.composeSystem env17334 rootObs = leafEnv17334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17334 rootObs == leafEnv17334) = true)

theorem terminalChecked17334 : H12PackedTerminal.terminalCheckFast leafEnv17334 active17334 tree17334 = true := by decide +kernel

def env17335 : List Nat := [2,4,8,16,1,17,9,256,1,272,1,1,9,0,260,263,1,260,272,261,1,1,16,263,8,17,0,1,1,261,21,261,256,1,0,1]

theorem envBound17335 : H12AffineFastState.Bounded env17335 := by
  intro p hp
  have h : env17335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17332_17335 : H12AffineEnvironment.transform 10 1 env17332 = env17335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env17332 == env17335) = true)

def leafEnv17335 : List Nat := [2,4,8,16,1,17,9,256,1,272,1,1,9,0,260,263,1,260,272,261,1,1,16,263,21,8,1,17,0,1,1,261,21,261,256,1,4,2,0,1,0,1,1]

def active17335 : List Nat := [0,1,2,3,7]

def tree17335 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17335 : H12WitnessSearch.Good tree17335 := H12GlobalWitnessIndex.good

theorem leafIdentity17335 : H12AffineFastState.composeSystem env17335 rootObs = leafEnv17335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17335 rootObs == leafEnv17335) = true)

theorem terminalChecked17335 : H12PackedTerminal.terminalCheckFast leafEnv17335 active17335 tree17335 = true := by decide +kernel

def env17336 : List Nat := [2,4,8,16,32,17,9,256,1,273,2048,0,8192,1,2340,65536,0,8461,273,2341,0,10249,16,67616,8193,17,2049,0,0,8460,20,4294967296,256,4295041034,1,1]

theorem envBound17336 : H12AffineFastState.Bounded env17336 := by
  intro p hp
  have h : env17336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17322_17336 : H12AffineEnvironment.transform 9 273 env17322 = env17336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env17322 == env17336) = true)

theorem identity17336 : scanCanonicalize (H12AffineFastState.compose env17336 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 10248) := by decide +kernel

theorem selectedBound17336 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17337 : List Nat := [2,4,8,16,32,17,9,256,1,273,2048,0,8192,1,2340,65536,0,8461,273,2341,0,10249,16,67616,8193,17,2049,0,0,8460,20,10248,256,67586,1,1]

theorem envBound17337 : H12AffineFastState.Bounded env17337 := by
  intro p hp
  have h : env17337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17336_17337 : H12AffineEnvironment.transform 31 10248 env17336 = env17337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 10248 env17336 == env17337) = true)

def env17338 : List Nat := [2,4,8,16,32,17,9,256,1,273,2048,0,2088,1,2340,65536,0,2341,273,2341,0,33,16,67616,2089,17,2049,0,0,2340,20,32,256,67586,1,1]

theorem envBound17338 : H12AffineFastState.Bounded env17338 := by
  intro p hp
  have h : env17338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17337_17338 : H12AffineEnvironment.transform 12 2088 env17337 = env17338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env17337 == env17338) = true)

theorem identity17338 : scanCanonicalize (H12AffineFastState.compose env17338 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound17338 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env17339 : List Nat := [2,4,8,16,0,17,9,256,1,273,2048,0,2056,1,2308,65536,0,2309,273,2309,0,1,16,67584,2057,17,2049,0,0,2308,20,0,256,67586,1,1]

theorem envBound17339 : H12AffineFastState.Bounded env17339 := by
  intro p hp
  have h : env17339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17338_17339 : H12AffineEnvironment.transform 4 0 env17338 = env17339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17338 == env17339) = true)

def env17340 : List Nat := [2,4,8,16,0,17,9,256,1,273,260,0,268,1,0,65536,0,1,273,1,0,1,16,65796,269,17,261,0,0,0,20,0,256,65798,1,1]

theorem envBound17340 : H12AffineFastState.Bounded env17340 := by
  intro p hp
  have h : env17340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17339_17340 : H12AffineEnvironment.transform 10 260 env17339 = env17340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env17339 == env17340) = true)

def env17341 : List Nat := [2,4,8,16,0,17,9,256,1,273,261,0,269,1,1,65536,0,0,273,0,0,1,16,65797,268,17,260,0,0,1,20,0,256,65799,1,1]

theorem envBound17341 : H12AffineFastState.Bounded env17341 := by
  intro p hp
  have h : env17341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17339_17341 : H12AffineEnvironment.transform 10 261 env17339 = env17341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env17339 == env17341) = true)

theorem identity17341 : scanCanonicalize (H12AffineFastState.compose env17341 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound17341 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17342 : List Nat := [2,4,8,16,0,17,9,256,1,273,261,0,269,1,1,262,0,0,273,0,0,1,16,3,268,17,260,0,0,1,20,0,256,1,1,1]

theorem envBound17342 : H12AffineFastState.Bounded env17342 := by
  intro p hp
  have h : env17342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17341_17342 : H12AffineEnvironment.transform 15 262 env17341 = env17342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env17341 == env17342) = true)

def leafEnv17342 : List Nat := [2,4,8,16,0,17,9,256,1,273,261,0,269,1,1,262,0,0,273,0,0,1,16,3,20,268,1,17,260,0,0,1,20,0,256,1,4,263,1,1,0,0,1]

def active17342 : List Nat := [0,1,2,3,7]

def tree17342 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17342 : H12WitnessSearch.Good tree17342 := H12GlobalWitnessIndex.good

theorem leafIdentity17342 : H12AffineFastState.composeSystem env17342 rootObs = leafEnv17342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17342 rootObs == leafEnv17342) = true)

theorem terminalChecked17342 : H12PackedTerminal.terminalCheckFast leafEnv17342 active17342 tree17342 = true := by decide +kernel

def env17343 : List Nat := [2,4,8,16,32,17,9,256,1,273,2048,0,2089,1,2340,65536,0,2340,273,2341,0,32,16,67616,2088,17,2049,0,0,2341,20,33,256,67586,1,1]

theorem envBound17343 : H12AffineFastState.Bounded env17343 := by
  intro p hp
  have h : env17343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17337_17343 : H12AffineEnvironment.transform 12 2089 env17337 = env17343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2089 env17337 == env17343) = true)

theorem identity17343 : scanCanonicalize (H12AffineFastState.compose env17343 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound17343 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env17344 : List Nat := [2,4,8,16,32,17,9,5,1,20,2048,0,2089,1,2081,65536,0,2081,20,2080,0,32,16,67616,2088,17,2049,0,0,2080,20,33,5,67586,1,1]

theorem envBound17344 : H12AffineFastState.Bounded env17344 := by
  intro p hp
  have h : env17344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17343_17344 : H12AffineEnvironment.transform 7 5 env17343 = env17344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env17343 == env17344) = true)

theorem identity17344 : scanCanonicalize (H12AffineFastState.compose env17344 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound17344 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17345 : List Nat := [2,4,8,16,1,17,9,5,1,20,2048,0,2056,1,2048,65536,0,2048,20,2049,0,1,16,67585,2057,17,2049,0,0,2049,20,0,5,67586,1,1]

theorem envBound17345 : H12AffineFastState.Bounded env17345 := by
  intro p hp
  have h : env17345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17344_17345 : H12AffineEnvironment.transform 4 1 env17344 = env17345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17344 == env17345) = true)

def env17346 : List Nat := [2,4,8,16,1,17,9,5,1,20,0,0,8,1,0,65536,0,0,20,1,0,1,16,65537,9,17,1,0,0,1,20,0,5,65538,1,1]

theorem envBound17346 : H12AffineFastState.Bounded env17346 := by
  intro p hp
  have h : env17346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17345_17346 : H12AffineEnvironment.transform 10 0 env17345 = env17346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env17345 == env17346) = true)

def leafEnv17346 : List Nat := [2,4,8,16,1,17,9,5,1,20,0,0,8,1,0,65536,0,0,20,1,0,1,16,65537,20,9,1,17,1,0,0,1,20,0,5,65538,4,3,1,1,0,0,1]

def active17346 : List Nat := [0,1,2,3,15]

def tree17346 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17346 : H12WitnessSearch.Good tree17346 := H12GlobalWitnessIndex.good

theorem leafIdentity17346 : H12AffineFastState.composeSystem env17346 rootObs = leafEnv17346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17346 rootObs == leafEnv17346) = true)

theorem terminalChecked17346 : H12PackedTerminal.terminalCheckFast leafEnv17346 active17346 tree17346 = true := by decide +kernel

def env17347 : List Nat := [2,4,8,16,1,17,9,5,1,20,1,0,9,1,1,65536,0,1,20,0,0,1,16,65536,8,17,0,0,0,0,20,0,5,65539,1,1]

theorem envBound17347 : H12AffineFastState.Bounded env17347 := by
  intro p hp
  have h : env17347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17345_17347 : H12AffineEnvironment.transform 10 1 env17345 = env17347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env17345 == env17347) = true)

theorem identity17347 : scanCanonicalize (H12AffineFastState.compose env17347 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound17347 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17348 : List Nat := [2,4,8,16,1,17,9,5,1,20,1,0,9,1,1,2,0,1,20,0,0,1,16,2,8,17,0,0,0,0,20,0,5,1,1,1]

theorem envBound17348 : H12AffineFastState.Bounded env17348 := by
  intro p hp
  have h : env17348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17347_17348 : H12AffineEnvironment.transform 15 2 env17347 = env17348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env17347 == env17348) = true)

def leafEnv17348 : List Nat := [2,4,8,16,1,17,9,5,1,20,1,0,9,1,1,2,0,1,20,0,0,1,16,2,20,8,1,17,0,0,0,0,20,0,5,1,4,2,1,1,0,0,1]

def active17348 : List Nat := [0,1,2,3]

def tree17348 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17348 : H12WitnessSearch.Good tree17348 := H12GlobalWitnessIndex.good

theorem leafIdentity17348 : H12AffineFastState.composeSystem env17348 rootObs = leafEnv17348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17348 rootObs == leafEnv17348) = true)

theorem terminalChecked17348 : H12PackedTerminal.terminalCheckFast leafEnv17348 active17348 tree17348 = true := by decide +kernel

def env17349 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,1025,32769,4096,4194304,17665,119125,8328,17744,134217728,16384,21824,1073741824,21845,4294967296,257,4299280895,138695701,512]

theorem envBound17349 : H12AffineFastState.Bounded env17349 := by
  intro p hp
  have h : env17349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17181_17349 : H12AffineEnvironment.transform 18 1025 env17181 = env17349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env17181 == env17349) = true)

def env17350 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32769,4096,4194304,540929,644437,8328,17745,134217728,541697,545088,1073741824,21844,4294967296,525568,4299806207,139218965,512]

theorem envBound17350 : H12AffineFastState.Bounded env17350 := by
  intro p hp
  have h : env17350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17180_17350 : H12AffineEnvironment.transform 16 1345 env17180 = env17350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env17180 == env17350) = true)

def env17351 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,1024,32769,4096,4194304,17665,119125,8328,17745,134217728,16385,21824,1073741824,21844,4294967296,256,4299280895,138695701,512]

theorem envBound17351 : H12AffineFastState.Bounded env17351 := by
  intro p hp
  have h : env17351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17350_17351 : H12AffineEnvironment.transform 18 1024 env17350 = env17351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env17350 == env17351) = true)

theorem identity17351 : scanCanonicalize (H12AffineFastState.compose env17351 (packedSelected [7,20,27] rootPS)) = affineNative (2^(26+1) ^^^ 4456708) := by decide +kernel

theorem selectedBound17351 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env17352 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,1024,32769,4096,4194304,17665,119125,8328,17745,4456708,16385,21824,1073741824,21844,4294967296,256,4299280895,21777,512]

theorem envBound17352 : H12AffineFastState.Bounded env17352 := by
  intro p hp
  have h : env17352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17351_17352 : H12AffineEnvironment.transform 26 4456708 env17351 = env17352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4456708 env17351 == env17352) = true)

def env17353 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,1345,262144,1024,32769,4096,4194304,65,103445,8328,17,4456708,1345,4096,1073741824,4116,4294967296,256,4299265215,4177,512]

theorem envBound17353 : H12AffineFastState.Bounded env17353 := by
  intro p hp
  have h : env17353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17352_17353 : H12AffineEnvironment.transform 13 1344 env17352 = env17353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env17352 == env17353) = true)

theorem identity17353 : scanCanonicalize (H12AffineFastState.compose env17353 (packedSelected [0,7,20] rootPS)) = affineNative (2^(11+1) ^^^ 1345) := by decide +kernel

theorem selectedBound17353 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env17354 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,65536,1345,262144,1024,32769,1345,4194304,65,98644,8328,17,4456708,1345,1345,1073741824,1365,4294967296,256,4299260414,1296,512]

theorem envBound17354 : H12AffineFastState.Bounded env17354 := by
  intro p hp
  have h : env17354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17353_17354 : H12AffineEnvironment.transform 11 1345 env17353 = env17354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env17353 == env17354) = true)

theorem identity17354 : scanCanonicalize (H12AffineFastState.compose env17354 (packedSelected [17,21] rootPS)) = affineNative (2^(15+1) ^^^ 33246) := by decide +kernel

theorem selectedBound17354 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env17355 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,33246,1345,262144,1024,32769,1345,4194304,65,138,8328,17,4456708,1345,1345,1073741824,1365,4294967296,256,4299161632,1296,512]

theorem envBound17355 : H12AffineFastState.Bounded env17355 := by
  intro p hp
  have h : env17355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17354_17355 : H12AffineEnvironment.transform 15 33246 env17354 = env17355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33246 env17354 == env17355) = true)

theorem identity17355 : scanCanonicalize (H12AffineFastState.compose env17355 (packedSelected [1,5,10,13,15,17,24,28,38] rootPS)) = affineNative (2^(31+1) ^^^ 1074045428) := by decide +kernel

theorem selectedBound17355 : packedSelected [1,5,10,13,15,17,24,28,38] rootPS < 2^1333 := by decide +kernel

def env17356 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,33246,1345,262144,1024,32769,1345,4194304,65,138,8328,17,4456708,1345,1345,1073741824,1365,1074045428,256,1078239700,1296,512]

theorem envBound17356 : H12AffineFastState.Bounded env17356 := by
  intro p hp
  have h : env17356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17355_17356 : H12AffineEnvironment.transform 31 1074045428 env17355 = env17356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1074045428 env17355 == env17356) = true)

theorem identity17356 : scanCanonicalize (H12AffineFastState.compose env17356 (packedSelected [1,5,10,24,28] rootPS)) = affineNative (2^(17+1) ^^^ 43128) := by decide +kernel

theorem selectedBound17356 : packedSelected [1,5,10,24,28] rootPS < 2^1333 := by decide +kernel

def env17357 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,33246,1345,43128,1024,32769,1345,4194304,65,138,8328,17,4237692,1345,1345,1073741824,1365,1073744268,256,1077938604,1296,512]

theorem envBound17357 : H12AffineFastState.Bounded env17357 := by
  intro p hp
  have h : env17357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17356_17357 : H12AffineEnvironment.transform 17 43128 env17356 = env17357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43128 env17356 == env17357) = true)

theorem identity17357 : scanCanonicalize (H12AffineFastState.compose env17357 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(29+1) ^^^ 8460) := by decide +kernel

theorem selectedBound17357 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env17358 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,33246,1345,43128,1024,32769,1345,4194304,65,138,8328,17,4237692,1345,1345,8460,1365,10368,256,4204704,1296,512]

theorem envBound17358 : H12AffineFastState.Bounded env17358 := by
  intro p hp
  have h : env17358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17357_17358 : H12AffineEnvironment.transform 29 8460 env17357 = env17358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 8460 env17357 == env17358) = true)

theorem identity17358 : scanCanonicalize (H12AffineFastState.compose env17358 (packedSelected [0,4,7,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 10328) := by decide +kernel

theorem selectedBound17358 : packedSelected [0,4,7,9,11] rootPS < 2^1333 := by decide +kernel

def env17359 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,32768,33246,1345,43128,1024,32769,1345,10328,65,138,8328,17,33060,1345,1345,8460,1365,10368,256,248,1296,512]

theorem envBound17359 : H12AffineFastState.Bounded env17359 := by
  intro p hp
  have h : env17359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17358_17359 : H12AffineEnvironment.transform 21 10328 env17358 = env17359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10328 env17358 == env17359) = true)

theorem identity17359 : scanCanonicalize (H12AffineFastState.compose env17359 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(14+1) ^^^ 2421) := by decide +kernel

theorem selectedBound17359 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env17360 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1344,2421,2219,1345,8461,1024,2420,1345,10328,65,138,8328,17,2129,1345,1345,8460,1365,10368,256,248,1296,512]

theorem envBound17360 : H12AffineFastState.Bounded env17360 := by
  intro p hp
  have h : env17360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17359_17360 : H12AffineEnvironment.transform 14 2421 env17359 = env17360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2421 env17359 == env17360) = true)

theorem identity17360 : scanCanonicalize (H12AffineFastState.compose env17360 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 901) := by decide +kernel

theorem selectedBound17360 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17361 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,901,1344,2421,2219,1345,648,1024,2420,1345,3037,65,138,781,17,2129,1345,1345,649,1365,2821,256,248,1296,512]

theorem envBound17361 : H12AffineFastState.Bounded env17361 := by
  intro p hp
  have h : env17361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17360_17361 : H12AffineEnvironment.transform 12 901 env17360 = env17361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 901 env17360 == env17361) = true)

theorem identity17361 : scanCanonicalize (H12AffineFastState.compose env17361 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 1345) := by decide +kernel

theorem selectedBound17361 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env17362 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1345,1345,901,1344,1076,1514,1345,648,1024,1077,1345,1692,65,138,781,17,1296,1345,1345,649,1365,1604,256,248,1296,512]

theorem envBound17362 : H12AffineFastState.Bounded env17362 := by
  intro p hp
  have h : env17362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17361_17362 : H12AffineEnvironment.transform 10 1345 env17361 = env17362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1345 env17361 == env17362) = true)

theorem identity17362 : scanCanonicalize (H12AffineFastState.compose env17362 (packedSelected [3,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound17362 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env17363 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1296,1296,901,1297,1076,1467,1296,648,1024,1077,1296,1692,16,138,781,17,1296,1296,1296,649,1284,1557,256,169,1296,512]

theorem envBound17363 : H12AffineFastState.Bounded env17363 := by
  intro p hp
  have h : env17363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17362_17363 : H12AffineEnvironment.transform 5 17 env17362 = env17363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17362 == env17363) = true)

theorem identity17363 : scanCanonicalize (H12AffineFastState.compose env17363 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 168) := by decide +kernel

theorem selectedBound17363 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17364 : List Nat := [2,4,8,16,32,17,128,256,168,1024,1296,1296,301,1297,1076,1467,1296,32,1024,1077,1296,1076,16,138,421,17,1296,1296,1296,33,1284,1213,256,169,1296,168]

theorem envBound17364 : H12AffineFastState.Bounded env17364 := by
  intro p hp
  have h : env17364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17363_17364 : H12AffineEnvironment.transform 8 168 env17363 = env17364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 168 env17363 == env17364) = true)

theorem identity17364 : scanCanonicalize (H12AffineFastState.compose env17364 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound17364 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env17365 : List Nat := [2,4,8,16,32,17,128,140,168,1024,1180,1180,161,1181,1076,1079,1180,32,1024,1077,1180,1076,16,138,41,17,1180,1180,1180,33,1160,1213,140,169,1180,168]

theorem envBound17365 : H12AffineFastState.Bounded env17365 := by
  intro p hp
  have h : env17365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17364_17365 : H12AffineEnvironment.transform 7 140 env17364 = env17365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env17364 == env17365) = true)

theorem identity17365 : scanCanonicalize (H12AffineFastState.compose env17365 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound17365 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17366 : List Nat := [2,4,8,16,32,17,25,21,49,1024,1029,1029,56,1028,1076,1079,1029,32,1024,1077,1029,1076,16,19,41,17,1029,1029,1029,33,1041,1060,21,48,1029,49]

theorem envBound17366 : H12AffineFastState.Bounded env17366 := by
  intro p hp
  have h : env17366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17365_17366 : H12AffineEnvironment.transform 6 25 env17365 = env17366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env17365 == env17366) = true)

theorem identity17366 : scanCanonicalize (H12AffineFastState.compose env17366 (packedSelected [4] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound17366 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env17367 : List Nat := [2,4,8,16,32,17,25,21,49,37,32,32,56,33,17,18,32,32,37,16,32,17,16,19,41,17,32,32,32,33,52,1,21,48,32,49]

theorem envBound17367 : H12AffineFastState.Bounded env17367 := by
  intro p hp
  have h : env17367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17366_17367 : H12AffineEnvironment.transform 9 37 env17366 = env17367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env17366 == env17367) = true)

theorem identity17367 : scanCanonicalize (H12AffineFastState.compose env17367 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound17367 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env17368 : List Nat := [2,4,8,16,1,17,25,21,16,4,1,1,25,0,17,18,1,1,4,16,1,17,16,19,8,17,1,1,1,0,21,1,21,17,1,16]

theorem envBound17368 : H12AffineFastState.Bounded env17368 := by
  intro p hp
  have h : env17368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17367_17368 : H12AffineEnvironment.transform 4 1 env17367 = env17368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17367 == env17368) = true)

def env17369 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,1345,262144,1024,32769,4096,4194304,64,103444,8328,16,4456708,1344,4097,1073741824,4117,4294967296,256,4299265214,4176,512]

theorem envBound17369 : H12AffineFastState.Bounded env17369 := by
  intro p hp
  have h : env17369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17352_17369 : H12AffineEnvironment.transform 13 1345 env17352 = env17369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env17352 == env17369) = true)

theorem identity17369 : scanCanonicalize (H12AffineFastState.compose env17369 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound17369 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env17370 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,1297,32768,65536,1297,262144,1024,32769,4096,4194304,16,103444,8328,16,4456708,1296,4097,1073741824,4117,4294967296,256,4299265214,4096,512]

theorem envBound17370 : H12AffineFastState.Bounded env17370 := by
  intro p hp
  have h : env17370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17369_17370 : H12AffineEnvironment.transform 5 16 env17369 = env17370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17369 == env17370) = true)

def env17371 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,1025,32769,4096,4194304,17664,119124,8328,17745,134217728,16384,21825,1073741824,21844,4294967296,257,4299280894,138695700,512]

theorem envBound17371 : H12AffineFastState.Bounded env17371 := by
  intro p hp
  have h : env17371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17350_17371 : H12AffineEnvironment.transform 18 1025 env17350 = env17371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env17350 == env17371) = true)

theorem identity17371 : scanCanonicalize (H12AffineFastState.compose env17371 (packedSelected [7,20,27] rootPS)) = affineNative (2^(26+1) ^^^ 4477268) := by decide +kernel

theorem selectedBound17371 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env17372 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,1025,32769,4096,4194304,17664,119124,8328,17745,4477268,16384,21825,1073741824,21844,4294967296,257,4299280894,1344,512]

theorem envBound17372 : H12AffineFastState.Bounded env17372 := by
  intro p hp
  have h : env17372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17371_17372 : H12AffineEnvironment.transform 26 4477268 env17371 = env17372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4477268 env17371 == env17372) = true)

def env17373 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4096,32768,65536,1345,262144,1025,32769,4096,4194304,5376,98644,8328,5457,4456788,4096,1345,1073741824,1364,4294967296,257,4299260414,1344,512]

theorem envBound17373 : H12AffineFastState.Bounded env17373 := by
  intro p hp
  have h : env17373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17372_17373 : H12AffineEnvironment.transform 13 4096 env17372 = env17373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env17372 == env17373) = true)

theorem identity17373 : scanCanonicalize (H12AffineFastState.compose env17373 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound17373 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env17374 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,1297,262144,1025,32769,4096,4194304,5376,98564,8328,5377,4456708,4096,1297,1073741824,1284,4294967296,257,4299260334,1296,512]

theorem envBound17374 : H12AffineFastState.Bounded env17374 := by
  intro p hp
  have h : env17374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17373_17374 : H12AffineEnvironment.transform 5 16 env17373 = env17374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17373 == env17374) = true)

theorem identity17374 : scanCanonicalize (H12AffineFastState.compose env17374 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(31+1) ^^^ 362498) := by decide +kernel

theorem selectedBound17374 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env17375 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,1297,262144,1025,32769,4096,4194304,5376,98564,8328,5377,4456708,4096,1297,1073741824,1284,362498,257,4458924,1296,512]

theorem envBound17375 : H12AffineFastState.Bounded env17375 := by
  intro p hp
  have h : env17375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17374_17375 : H12AffineEnvironment.transform 31 362498 env17374 = env17375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 362498 env17374 == env17375) = true)

theorem identity17375 : scanCanonicalize (H12AffineFastState.compose env17375 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(17+1) ^^^ 43681) := by decide +kernel

theorem selectedBound17375 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env17376 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,1297,43681,1025,32769,4096,4194304,5376,98564,8328,5377,4238245,4096,1297,1073741824,1284,74403,257,4236045,1296,512]

theorem envBound17376 : H12AffineFastState.Bounded env17376 := by
  intro p hp
  have h : env17376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17375_17376 : H12AffineEnvironment.transform 17 43681 env17375 = env17376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43681 env17375 == env17376) = true)

theorem identity17376 : scanCanonicalize (H12AffineFastState.compose env17376 (packedSelected [1,10] rootPS)) = affineNative (2^(14+1) ^^^ 2728) := by decide +kernel

theorem selectedBound17376 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env17377 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,2728,65536,1297,8201,1025,2729,4096,4194304,5376,68524,8328,5377,4202765,4096,1297,1073741824,1284,74403,257,4204965,1296,512]

theorem envBound17377 : H12AffineFastState.Bounded env17377 := by
  intro p hp
  have h : env17377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17376_17377 : H12AffineEnvironment.transform 14 2728 env17376 = env17377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2728 env17376 == env17377) = true)

theorem identity17377 : scanCanonicalize (H12AffineFastState.compose env17377 (packedSelected [1,3,5,12,13,24] rootPS)) = affineNative (2^(29+1) ^^^ 4196612) := by decide +kernel

theorem selectedBound17377 : packedSelected [1,3,5,12,13,24] rootPS < 2^1333 := by decide +kernel

def env17378 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,2728,65536,1297,8201,1025,2729,4096,4194304,5376,68524,8328,5377,4202765,4096,1297,4196612,1284,74403,257,4204965,1296,512]

theorem envBound17378 : H12AffineFastState.Bounded env17378 := by
  intro p hp
  have h : env17378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17377_17378 : H12AffineEnvironment.transform 29 4196612 env17377 = env17378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4196612 env17377 == env17378) = true)

theorem identity17378 : scanCanonicalize (H12AffineFastState.compose env17378 (packedSelected [5,8] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound17378 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env17379 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,8192,4096,2081,65536,1297,8201,1025,2080,4096,4194304,5376,67877,8328,5377,4202765,4096,1297,4196612,1284,73770,257,4204965,1296,137]

theorem envBound17379 : H12AffineFastState.Bounded env17379 := by
  intro p hp
  have h : env17379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17378_17379 : H12AffineEnvironment.transform 8 137 env17378 = env17379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env17378 == env17379) = true)

def env17380 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,8192,1296,2081,65536,1297,8201,1025,2080,1296,4194304,16,67877,8328,17,4202765,1296,1297,4196612,1284,73770,257,4204965,1296,137]

theorem envBound17380 : H12AffineFastState.Bounded env17380 := by
  intro p hp
  have h : env17380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17379_17380 : H12AffineEnvironment.transform 11 1296 env17379 = env17380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env17379 == env17380) = true)

theorem identity17380 : scanCanonicalize (H12AffineFastState.compose env17380 (packedSelected [1,3] rootPS)) = affineNative (2^(21+1) ^^^ 10508) := by decide +kernel

theorem selectedBound17380 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17381 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,8192,1296,2081,65536,1297,8201,1025,2080,1296,10508,16,67877,8328,17,2049,1296,1297,8200,1284,73770,257,169,1296,137]

theorem envBound17381 : H12AffineFastState.Bounded env17381 := by
  intro p hp
  have h : env17381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17380_17381 : H12AffineEnvironment.transform 21 10508 env17380 = env17381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10508 env17380 == env17381) = true)

def env17382 : List Nat := [2,4,8,16,32,16,128,256,137,272,2048,0,8192,0,2081,65536,1,8201,273,2080,0,10508,16,67877,8328,17,2049,0,1,8200,20,73770,257,169,0,137]

theorem envBound17382 : H12AffineFastState.Bounded env17382 := by
  intro p hp
  have h : env17382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17381_17382 : H12AffineEnvironment.transform 9 272 env17381 = env17382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env17381 == env17382) = true)

theorem identity17382 : scanCanonicalize (H12AffineFastState.compose env17382 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound17382 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17383 : List Nat := [2,4,8,16,32,16,128,256,137,272,33,0,8192,0,0,65536,1,8201,273,1,0,8493,16,65796,8328,17,32,0,1,8200,20,73770,257,169,0,137]

theorem envBound17383 : H12AffineFastState.Bounded env17383 := by
  intro p hp
  have h : env17383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17382_17383 : H12AffineEnvironment.transform 10 33 env17382 = env17383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env17382 == env17383) = true)

def env17384 : List Nat := [2,4,8,16,32,16,128,4,137,20,33,0,8192,0,0,65536,1,8201,21,1,0,8233,16,65536,8328,17,32,0,1,8200,20,73770,5,169,0,137]

theorem envBound17384 : H12AffineFastState.Bounded env17384 := by
  intro p hp
  have h : env17384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17383_17384 : H12AffineEnvironment.transform 7 4 env17383 = env17384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env17383 == env17384) = true)

theorem identity17384 : scanCanonicalize (H12AffineFastState.compose env17384 (packedSelected [2,4] rootPS)) = affineNative (2^(15+1) ^^^ 139) := by decide +kernel

theorem selectedBound17384 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env17385 : List Nat := [2,4,8,16,32,16,128,4,137,20,33,0,8192,0,0,139,1,8201,21,1,0,8233,16,139,8328,17,32,0,1,8200,20,8353,5,169,0,137]

theorem envBound17385 : H12AffineFastState.Bounded env17385 := by
  intro p hp
  have h : env17385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17384_17385 : H12AffineEnvironment.transform 15 139 env17384 = env17385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 139 env17384 == env17385) = true)

theorem identity17385 : scanCanonicalize (H12AffineFastState.compose env17385 (packedSelected [0,2] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound17385 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env17386 : List Nat := [2,4,8,16,32,16,128,4,137,20,33,0,9,0,0,139,1,0,21,1,0,32,16,139,129,17,32,0,1,1,20,168,5,169,0,137]

theorem envBound17386 : H12AffineFastState.Bounded env17386 := by
  intro p hp
  have h : env17386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17385_17386 : H12AffineEnvironment.transform 12 9 env17385 = env17386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env17385 == env17386) = true)

theorem identity17386 : scanCanonicalize (H12AffineFastState.compose env17386 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound17386 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17387 : List Nat := [2,4,8,16,32,16,57,4,48,20,33,0,9,0,0,50,1,0,21,1,0,32,16,50,56,17,32,0,1,1,20,17,5,16,0,48]

theorem envBound17387 : H12AffineFastState.Bounded env17387 := by
  intro p hp
  have h : env17387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17386_17387 : H12AffineEnvironment.transform 6 57 env17386 = env17387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env17386 == env17387) = true)

def leafEnv17387 : List Nat := [2,4,8,16,32,16,57,4,48,20,33,0,9,0,0,50,1,0,21,1,0,32,16,50,20,56,1,17,32,0,1,1,20,17,5,16,4,2,0,48,0,0,1]

def active17387 : List Nat := [0,1,2,3,4]

def tree17387 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17387 : H12WitnessSearch.Good tree17387 := H12GlobalWitnessIndex.good

theorem leafIdentity17387 : H12AffineFastState.composeSystem env17387 rootObs = leafEnv17387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17387 rootObs == leafEnv17387) = true)

theorem terminalChecked17387 : H12PackedTerminal.terminalCheckFast leafEnv17387 active17387 tree17387 = true := by decide +kernel

def env17388 : List Nat := [2,4,8,16,32,16,128,5,137,21,33,0,8192,0,0,65536,1,8201,20,1,0,8232,16,65537,8328,17,32,0,1,8200,20,73770,4,169,0,137]

theorem envBound17388 : H12AffineFastState.Bounded env17388 := by
  intro p hp
  have h : env17388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17383_17388 : H12AffineEnvironment.transform 7 5 env17383 = env17388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env17383 == env17388) = true)

theorem identity17388 : scanCanonicalize (H12AffineFastState.compose env17388 (packedSelected [2,4] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound17388 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env17389 : List Nat := [2,4,8,16,32,16,128,5,137,21,33,0,40,0,0,65536,1,33,20,1,0,0,16,65537,160,17,32,0,1,32,20,65538,4,169,0,137]

theorem envBound17389 : H12AffineFastState.Bounded env17389 := by
  intro p hp
  have h : env17389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17388_17389 : H12AffineEnvironment.transform 12 40 env17388 = env17389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env17388 == env17389) = true)

def env17390 : List Nat := [2,4,8,16,0,16,128,5,137,21,1,0,8,0,0,65536,1,1,20,1,0,0,16,65537,128,17,0,0,1,0,20,65538,4,137,0,137]

theorem envBound17390 : H12AffineFastState.Bounded env17390 := by
  intro p hp
  have h : env17390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17389_17390 : H12AffineEnvironment.transform 4 0 env17389 = env17390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17389 == env17390) = true)

theorem identity17390 : scanCanonicalize (H12AffineFastState.compose env17390 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 19) := by decide +kernel

theorem selectedBound17390 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17391 : List Nat := [2,4,8,16,0,16,128,5,137,21,1,0,8,0,0,19,1,1,20,1,0,0,16,18,128,17,0,0,1,0,20,17,4,137,0,137]

theorem envBound17391 : H12AffineFastState.Bounded env17391 := by
  intro p hp
  have h : env17391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17390_17391 : H12AffineEnvironment.transform 15 19 env17390 = env17391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 19 env17390 == env17391) = true)

theorem identity17391 : scanCanonicalize (H12AffineFastState.compose env17391 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound17391 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17392 : List Nat := [2,4,8,16,0,16,25,5,16,21,1,0,8,0,0,19,1,1,20,1,0,0,16,18,25,17,0,0,1,0,20,17,4,16,0,16]

theorem envBound17392 : H12AffineFastState.Bounded env17392 := by
  intro p hp
  have h : env17392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17391_17392 : H12AffineEnvironment.transform 6 25 env17391 = env17392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env17391 == env17392) = true)

def leafEnv17392 : List Nat := [2,4,8,16,0,16,25,5,16,21,1,0,8,0,0,19,1,1,20,1,0,0,16,18,20,25,1,17,0,0,1,0,20,17,4,16,4,3,0,16,0,0,1]

def active17392 : List Nat := [0,1,2,3]

def tree17392 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17392 : H12WitnessSearch.Good tree17392 := H12GlobalWitnessIndex.good

theorem leafIdentity17392 : H12AffineFastState.composeSystem env17392 rootObs = leafEnv17392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17392 rootObs == leafEnv17392) = true)

theorem terminalChecked17392 : H12PackedTerminal.terminalCheckFast leafEnv17392 active17392 tree17392 = true := by decide +kernel

def env17393 : List Nat := [2,4,8,16,1,16,128,5,137,21,0,0,9,0,0,65536,1,0,20,1,0,0,16,65537,129,17,1,0,1,1,20,65538,4,136,0,137]

theorem envBound17393 : H12AffineFastState.Bounded env17393 := by
  intro p hp
  have h : env17393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17389_17393 : H12AffineEnvironment.transform 4 1 env17389 = env17393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17389 == env17393) = true)

theorem identity17393 : scanCanonicalize (H12AffineFastState.compose env17393 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 155) := by decide +kernel

theorem selectedBound17393 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17394 : List Nat := [2,4,8,16,1,16,128,5,137,21,0,0,9,0,0,155,1,0,20,1,0,0,16,154,129,17,1,0,1,1,20,153,4,136,0,137]

theorem envBound17394 : H12AffineFastState.Bounded env17394 := by
  intro p hp
  have h : env17394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17393_17394 : H12AffineEnvironment.transform 15 155 env17393 = env17394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 155 env17393 == env17394) = true)

def env17395 : List Nat := [2,4,8,16,32,16,128,256,137,273,2048,1,8192,1,2081,65536,0,8201,272,2080,1,10508,16,67877,8328,17,2049,1,0,8200,21,73770,257,169,1,137]

theorem envBound17395 : H12AffineFastState.Bounded env17395 := by
  intro p hp
  have h : env17395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17381_17395 : H12AffineEnvironment.transform 9 273 env17381 = env17395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env17381 == env17395) = true)

theorem identity17395 : scanCanonicalize (H12AffineFastState.compose env17395 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 399) := by decide +kernel

theorem selectedBound17395 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17396 : List Nat := [2,4,8,16,32,16,128,256,137,273,2048,1,8192,1,2081,399,0,8201,272,2080,1,10508,16,2218,8328,17,2049,1,0,8200,21,8613,257,169,1,137]

theorem envBound17396 : H12AffineFastState.Bounded env17396 := by
  intro p hp
  have h : env17396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17395_17396 : H12AffineEnvironment.transform 15 399 env17395 = env17396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 399 env17395 == env17396) = true)

def env17397 : List Nat := [2,4,8,16,32,16,128,256,137,273,2048,1,40,1,2081,399,0,33,272,2080,1,2340,16,2218,160,17,2049,1,0,32,21,397,257,169,1,137]

theorem envBound17397 : H12AffineFastState.Bounded env17397 := by
  intro p hp
  have h : env17397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17396_17397 : H12AffineEnvironment.transform 12 40 env17396 = env17397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env17396 == env17397) = true)

theorem identity17397 : scanCanonicalize (H12AffineFastState.compose env17397 (packedSelected [2,4] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound17397 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env17398 : List Nat := [2,4,8,16,32,16,128,256,137,273,33,1,40,1,0,399,0,33,272,1,1,261,16,139,160,17,32,1,0,32,21,397,257,169,1,137]

theorem envBound17398 : H12AffineFastState.Bounded env17398 := by
  intro p hp
  have h : env17398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17397_17398 : H12AffineEnvironment.transform 10 33 env17397 = env17398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env17397 == env17398) = true)

theorem identity17398 : scanCanonicalize (H12AffineFastState.compose env17398 (packedSelected [0,2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound17398 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env17399 : List Nat := [2,4,8,16,32,16,128,36,137,53,33,1,40,1,0,171,0,33,52,1,1,33,16,139,160,17,32,1,0,32,21,169,37,169,1,137]

theorem envBound17399 : H12AffineFastState.Bounded env17399 := by
  intro p hp
  have h : env17399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17398_17399 : H12AffineEnvironment.transform 7 36 env17398 = env17399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env17398 == env17399) = true)

theorem identity17399 : scanCanonicalize (H12AffineFastState.compose env17399 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound17399 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17400 : List Nat := [2,4,8,16,17,16,128,21,137,4,16,1,25,1,0,154,0,16,5,1,1,16,16,139,145,17,17,1,0,17,21,152,20,152,1,137]

theorem envBound17400 : H12AffineFastState.Bounded env17400 := by
  intro p hp
  have h : env17400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17399_17400 : H12AffineEnvironment.transform 4 17 env17399 = env17400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env17399 == env17400) = true)

def leafEnv17400 : List Nat := [2,4,8,16,17,16,128,21,137,4,16,1,25,1,0,154,0,16,5,1,1,16,16,139,21,145,1,17,17,1,0,17,21,152,20,152,4,19,1,137,0,1,1]

def active17400 : List Nat := [0,1,2,3,6]

def tree17400 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood17400 : H12WitnessSearch.Good tree17400 := H12GlobalWitnessIndex.good

theorem leafIdentity17400 : H12AffineFastState.composeSystem env17400 rootObs = leafEnv17400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env17400 rootObs == leafEnv17400) = true)

theorem terminalChecked17400 : H12PackedTerminal.terminalCheckFast leafEnv17400 active17400 tree17400 = true := by decide +kernel

def env17401 : List Nat := [2,4,8,16,32,16,128,256,137,273,2048,1,41,1,2081,399,0,32,272,2080,1,2341,16,2218,161,17,2049,1,0,33,21,396,257,169,1,137]

theorem envBound17401 : H12AffineFastState.Bounded env17401 := by
  intro p hp
  have h : env17401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17396_17401 : H12AffineEnvironment.transform 12 41 env17396 = env17401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env17396 == env17401) = true)

end H12CloudChart2