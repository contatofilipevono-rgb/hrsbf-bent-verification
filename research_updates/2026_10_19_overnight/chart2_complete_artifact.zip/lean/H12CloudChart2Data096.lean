import H12CloudChart2Data095

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans23567_23568 : H12AffineEnvironment.transform 10 261 env23567 = env23568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env23567 == env23568) = true)

theorem identity23568 : scanCanonicalize (H12AffineFastState.compose env23568 (packedSelected [8,12] rootPS)) = affineNative (2^(15+1) ^^^ 294) := by decide +kernel

theorem selectedBound23568 : packedSelected [8,12] rootPS < 2^1333 := by decide +kernel

def env23569 : List Nat := [2,4,8,16,32,16,9,256,512,272,261,0,781,0,528,294,0,260,273,529,0,16,17,823,780,17,17,0,0,513,272,17,257,789,260,512]

theorem envBound23569 : H12AffineFastState.Bounded env23569 := by
  intro p hp
  have h : env23569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23568_23569 : H12AffineEnvironment.transform 15 294 env23568 = env23569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 294 env23568 == env23569) = true)

theorem identity23569 : scanCanonicalize (H12AffineFastState.compose env23569 (packedSelected [0,3,6] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound23569 : packedSelected [0,3,6] rootPS < 2^1333 := by decide +kernel

def env23570 : List Nat := [2,4,8,16,32,16,9,256,277,272,261,0,24,0,261,294,0,260,273,260,0,16,17,34,25,17,17,0,0,276,272,17,257,0,260,277]

theorem envBound23570 : H12AffineFastState.Bounded env23570 := by
  intro p hp
  have h : env23570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23569_23570 : H12AffineEnvironment.transform 8 277 env23569 = env23570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env23569 == env23570) = true)

theorem identity23570 : scanCanonicalize (H12AffineFastState.compose env23570 (packedSelected [1,2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound23570 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env23571 : List Nat := [2,4,8,16,32,16,9,37,48,53,32,0,24,0,32,3,0,33,52,33,0,16,17,34,25,17,17,0,0,49,53,17,36,0,33,48]

theorem envBound23571 : H12AffineFastState.Bounded env23571 := by
  intro p hp
  have h : env23571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23570_23571 : H12AffineEnvironment.transform 7 37 env23570 = env23571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env23570 == env23571) = true)

theorem identity23571 : scanCanonicalize (H12AffineFastState.compose env23571 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound23571 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23572 : List Nat := [2,4,8,16,17,16,9,20,1,4,17,0,24,0,17,3,0,16,5,16,0,16,17,19,25,17,17,0,0,0,4,17,21,0,16,1]

theorem envBound23572 : H12AffineFastState.Bounded env23572 := by
  intro p hp
  have h : env23572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23571_23572 : H12AffineEnvironment.transform 4 17 env23571 = env23572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env23571 == env23572) = true)

theorem identity23572 : scanCanonicalize (H12AffineFastState.compose env23572 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound23572 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23573 : List Nat := [2,4,8,0,1,0,9,4,1,4,1,0,8,0,1,3,0,0,5,0,0,0,1,3,9,1,1,0,0,0,4,1,5,0,0,1]

theorem envBound23573 : H12AffineFastState.Bounded env23573 := by
  intro p hp
  have h : env23573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23572_23573 : H12AffineEnvironment.transform 3 0 env23572 = env23573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env23572 == env23573) = true)

def env23574 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,0,781,1,529,65536,0,260,272,528,0,17,17,66064,780,16,16,1,1,68131,273,16,257,66098,260,512]

theorem envBound23574 : H12AffineFastState.Bounded env23574 := by
  intro p hp
  have h : env23574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23566_23574 : H12AffineEnvironment.transform 5 17 env23566 = env23574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23566 == env23574) = true)

theorem identity23574 : scanCanonicalize (H12AffineFastState.compose env23574 (packedSelected [5] rootPS)) = affineNative (2^(15+1) ^^^ 2854) := by decide +kernel

theorem selectedBound23574 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23575 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,0,781,1,529,2854,0,260,272,528,0,17,17,2358,780,16,16,1,1,261,273,16,257,2324,260,512]

theorem envBound23575 : H12AffineFastState.Bounded env23575 := by
  intro p hp
  have h : env23575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23574_23575 : H12AffineEnvironment.transform 15 2854 env23574 = env23575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2854 env23574 == env23575) = true)

theorem identity23575 : scanCanonicalize (H12AffineFastState.compose env23575 (packedSelected [0,4,6,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound23575 : packedSelected [0,4,6,9] rootPS < 2^1333 := by decide +kernel

def env23576 : List Nat := [2,4,8,16,0,17,9,256,512,273,2048,0,781,1,529,2822,0,260,272,528,0,17,17,2326,780,16,16,1,1,261,273,16,257,2324,260,512]

theorem envBound23576 : H12AffineFastState.Bounded env23576 := by
  intro p hp
  have h : env23576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23575_23576 : H12AffineEnvironment.transform 4 0 env23575 = env23576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23575 == env23576) = true)

def env23577 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,1,781,81,576,65536,1,260,320,577,1,64,17,66113,780,65,65,81,81,1073741824,321,65,257,66147,261,512]

theorem envBound23577 : H12AffineFastState.Bounded env23577 := by
  intro p hp
  have h : env23577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23564_23577 : H12AffineEnvironment.transform 9 321 env23564 = env23577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env23564 == env23577) = true)

theorem identity23577 : scanCanonicalize (H12AffineFastState.compose env23577 (packedSelected [13] rootPS)) = affineNative (2^(29+1) ^^^ 2097) := by decide +kernel

theorem selectedBound23577 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env23578 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,1,781,81,576,65536,1,260,320,577,1,64,17,66113,780,65,65,81,81,2097,321,65,257,66147,261,512]

theorem envBound23578 : H12AffineFastState.Bounded env23578 := by
  intro p hp
  have h : env23578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23577_23578 : H12AffineEnvironment.transform 29 2097 env23577 = env23578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 2097 env23577 == env23578) = true)

def env23579 : List Nat := [2,4,8,16,32,32,9,256,512,289,2048,1,781,49,544,65536,1,260,288,545,1,32,17,66081,780,33,33,49,49,2097,289,33,257,66051,261,512]

theorem envBound23579 : H12AffineFastState.Bounded env23579 := by
  intro p hp
  have h : env23579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23578_23579 : H12AffineEnvironment.transform 5 32 env23578 = env23579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env23578 == env23579) = true)

theorem identity23579 : scanCanonicalize (H12AffineFastState.compose env23579 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound23579 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23580 : List Nat := [2,4,8,16,32,32,9,256,512,289,17,1,781,49,544,65536,1,260,288,545,1,32,17,66081,780,33,33,49,49,32,289,33,257,66051,261,512]

theorem envBound23580 : H12AffineFastState.Bounded env23580 := by
  intro p hp
  have h : env23580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23579_23580 : H12AffineEnvironment.transform 10 17 env23579 = env23580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env23579 == env23580) = true)

theorem identity23580 : scanCanonicalize (H12AffineFastState.compose env23580 (packedSelected [0,6,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound23580 : packedSelected [0,6,8] rootPS < 2^1333 := by decide +kernel

def env23581 : List Nat := [2,4,8,1,32,32,9,256,512,289,0,1,781,32,544,65536,1,260,288,545,1,32,0,66081,780,33,33,32,32,32,289,33,257,66051,261,512]

theorem envBound23581 : H12AffineFastState.Bounded env23581 := by
  intro p hp
  have h : env23581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23580_23581 : H12AffineEnvironment.transform 3 1 env23580 = env23581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env23580 == env23581) = true)

theorem identity23581 : scanCanonicalize (H12AffineFastState.compose env23581 (packedSelected [0,6] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound23581 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env23582 : List Nat := [2,4,8,1,32,32,9,5,512,36,0,1,520,32,544,65536,1,1,37,545,1,32,0,66081,521,33,33,32,32,32,36,33,4,66051,0,512]

theorem envBound23582 : H12AffineFastState.Bounded env23582 := by
  intro p hp
  have h : env23582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23581_23582 : H12AffineEnvironment.transform 7 5 env23581 = env23582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env23581 == env23582) = true)

theorem identity23582 : scanCanonicalize (H12AffineFastState.compose env23582 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound23582 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23583 : List Nat := [2,4,8,1,32,32,9,5,33,36,0,1,41,32,1,65536,1,1,37,0,1,32,0,65536,40,33,33,32,32,32,36,33,4,65570,0,33]

theorem envBound23583 : H12AffineFastState.Bounded env23583 := by
  intro p hp
  have h : env23583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23582_23583 : H12AffineEnvironment.transform 8 33 env23582 = env23583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env23582 == env23583) = true)

theorem identity23583 : scanCanonicalize (H12AffineFastState.compose env23583 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound23583 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23584 : List Nat := [2,4,8,1,32,32,9,5,33,36,0,1,41,32,1,34,1,1,37,0,1,32,0,34,40,33,33,32,32,32,36,33,4,0,0,33]

theorem envBound23584 : H12AffineFastState.Bounded env23584 := by
  intro p hp
  have h : env23584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23583_23584 : H12AffineEnvironment.transform 15 34 env23583 = env23584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env23583 == env23584) = true)

theorem identity23584 : scanCanonicalize (H12AffineFastState.compose env23584 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound23584 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23585 : List Nat := [2,4,8,1,1,1,9,5,0,5,0,1,8,1,1,3,1,1,4,0,1,1,0,3,9,0,0,1,1,1,5,0,4,0,0,0]

theorem envBound23585 : H12AffineFastState.Bounded env23585 := by
  intro p hp
  have h : env23585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23584_23585 : H12AffineEnvironment.transform 4 1 env23584 = env23585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env23584 == env23585) = true)

def env23586 : List Nat := [2,4,8,16,32,33,9,256,512,288,2048,1,781,48,545,65536,1,260,289,544,1,33,17,66080,780,32,32,48,48,2097,288,32,257,66050,261,512]

theorem envBound23586 : H12AffineFastState.Bounded env23586 := by
  intro p hp
  have h : env23586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23578_23586 : H12AffineEnvironment.transform 5 33 env23578 = env23586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env23578 == env23586) = true)

theorem identity23586 : scanCanonicalize (H12AffineFastState.compose env23586 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound23586 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23587 : List Nat := [2,4,8,16,32,33,9,256,512,288,33,1,781,48,545,65536,1,260,289,544,1,33,17,66080,780,32,32,48,48,16,288,32,257,66050,261,512]

theorem envBound23587 : H12AffineFastState.Bounded env23587 := by
  intro p hp
  have h : env23587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23586_23587 : H12AffineEnvironment.transform 10 33 env23586 = env23587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env23586 == env23587) = true)

theorem identity23587 : scanCanonicalize (H12AffineFastState.compose env23587 (packedSelected [4,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound23587 : packedSelected [4,8,9] rootPS < 2^1333 := by decide +kernel

def env23588 : List Nat := [2,4,8,16,32,33,9,37,512,5,33,1,552,48,545,65536,1,33,4,544,1,33,17,66080,553,32,32,48,48,16,5,32,36,66050,32,512]

theorem envBound23588 : H12AffineFastState.Bounded env23588 := by
  intro p hp
  have h : env23588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23587_23588 : H12AffineEnvironment.transform 7 37 env23587 = env23588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env23587 == env23588) = true)

theorem identity23588 : scanCanonicalize (H12AffineFastState.compose env23588 (packedSelected [0,6] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound23588 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env23589 : List Nat := [2,4,8,0,32,33,9,37,512,5,33,1,552,32,545,65536,1,33,4,544,1,33,1,66080,553,32,32,32,32,0,5,32,36,66050,32,512]

theorem envBound23589 : H12AffineFastState.Bounded env23589 := by
  intro p hp
  have h : env23589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23588_23589 : H12AffineEnvironment.transform 3 0 env23588 = env23589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env23588 == env23589) = true)

theorem identity23589 : scanCanonicalize (H12AffineFastState.compose env23589 (packedSelected [0,3,4] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound23589 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env23590 : List Nat := [2,4,8,0,32,33,9,37,512,5,33,1,552,32,545,34,1,33,4,544,1,33,1,514,553,32,32,32,32,0,5,32,36,544,32,512]

theorem envBound23590 : H12AffineFastState.Bounded env23590 := by
  intro p hp
  have h : env23590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23589_23590 : H12AffineEnvironment.transform 15 34 env23589 = env23590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env23589 == env23590) = true)

theorem identity23590 : scanCanonicalize (H12AffineFastState.compose env23590 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound23590 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23591 : List Nat := [2,4,8,0,0,1,9,5,512,5,1,1,520,0,513,2,1,1,4,512,1,1,1,514,521,0,0,0,0,0,5,0,4,512,0,512]

theorem envBound23591 : H12AffineFastState.Bounded env23591 := by
  intro p hp
  have h : env23591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23590_23591 : H12AffineEnvironment.transform 4 0 env23590 = env23591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23590 == env23591) = true)

theorem identity23591 : scanCanonicalize (H12AffineFastState.compose env23591 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound23591 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23592 : List Nat := [2,4,8,0,0,1,9,5,0,5,1,1,8,0,1,2,1,1,4,0,1,1,1,2,9,0,0,0,0,0,5,0,4,0,0,0]

theorem envBound23592 : H12AffineFastState.Bounded env23592 := by
  intro p hp
  have h : env23592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23591_23592 : H12AffineEnvironment.transform 8 0 env23591 = env23592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env23591 == env23592) = true)

def env23593 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,65536,1344,8833,1025,32769,1344,4194304,17,16777216,8328,65,4203396,1296,1296,1073741824,16876545,4194440,257,16777250,16876613,512]

theorem envBound23593 : H12AffineFastState.Bounded env23593 := by
  intro p hp
  have h : env23593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23472_23593 : H12AffineEnvironment.transform 17 8833 env23472 = env23593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8833 env23472 == env23593) = true)

theorem identity23593 : scanCanonicalize (H12AffineFastState.compose env23593 (packedSelected [3,5,24] rootPS)) = affineNative (2^(21+1) ^^^ 33677) := by decide +kernel

theorem selectedBound23593 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env23594 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,65536,1344,8833,1025,32769,1344,33677,17,16777216,8328,65,40969,1296,1296,1073741824,16876545,33541,257,16777250,16876613,512]

theorem envBound23594 : H12AffineFastState.Bounded env23594 := by
  intro p hp
  have h : env23594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23593_23594 : H12AffineEnvironment.transform 21 33677 env23593 = env23594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33677 env23593 == env23594) = true)

def env23595 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,65536,1344,8833,1025,32769,1344,33677,17,98304,8328,65,40969,1296,1296,1073741824,1025,33541,257,98338,1093,512]

theorem envBound23595 : H12AffineFastState.Bounded env23595 := by
  intro p hp
  have h : env23595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23594_23595 : H12AffineEnvironment.transform 23 98304 env23594 = env23595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98304 env23594 == env23595) = true)

theorem identity23595 : scanCanonicalize (H12AffineFastState.compose env23595 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 520) := by decide +kernel

theorem selectedBound23595 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env23596 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,520,1296,32768,65536,1344,137,1025,32769,1344,33677,17,98304,640,65,33281,1296,1296,1073741824,1025,33541,257,98338,1093,512]

theorem envBound23596 : H12AffineFastState.Bounded env23596 := by
  intro p hp
  have h : env23596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23595_23596 : H12AffineEnvironment.transform 12 520 env23595 = env23596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 520 env23595 == env23596) = true)

def env23597 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1344,520,1296,32768,65536,1344,1,1025,32769,1344,33541,17,98304,520,65,33281,1296,1296,1073741824,1025,33541,257,98338,1093,512]

theorem envBound23597 : H12AffineFastState.Bounded env23597 := by
  intro p hp
  have h : env23597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23596_23597 : H12AffineEnvironment.transform 6 8 env23596 = env23597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23596 == env23597) = true)

theorem identity23597 : scanCanonicalize (H12AffineFastState.compose env23597 (packedSelected [6,7] rootPS)) = affineNative (2^(29+1) ^^^ 100931) := by decide +kernel

theorem selectedBound23597 : packedSelected [6,7] rootPS < 2^1333 := by decide +kernel

def env23598 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1344,520,1296,32768,65536,1344,1,1025,32769,1344,33541,17,98304,520,65,33281,1296,1296,100931,1025,33541,257,98338,1093,512]

theorem envBound23598 : H12AffineFastState.Bounded env23598 := by
  intro p hp
  have h : env23598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23597_23598 : H12AffineEnvironment.transform 29 100931 env23597 = env23598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 100931 env23597 == env23598) = true)

def env23599 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,0,520,80,32768,65536,0,1,321,32769,0,33541,17,98304,520,65,33281,80,80,100931,321,33541,257,98338,261,512]

theorem envBound23599 : H12AffineFastState.Bounded env23599 := by
  intro p hp
  have h : env23599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23598_23599 : H12AffineEnvironment.transform 9 320 env23598 = env23599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env23598 == env23599) = true)

theorem identity23599 : scanCanonicalize (H12AffineFastState.compose env23599 (packedSelected [13] rootPS)) = affineNative (2^(14+1) ^^^ 356) := by decide +kernel

theorem selectedBound23599 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env23600 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,0,520,80,356,65536,0,1,321,357,0,609,17,65892,520,65,869,80,80,68391,321,609,257,65862,261,512]

theorem envBound23600 : H12AffineFastState.Bounded env23600 := by
  intro p hp
  have h : env23600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23599_23600 : H12AffineEnvironment.transform 14 356 env23599 = env23600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 356 env23599 == env23600) = true)

def env23601 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,0,520,0,308,65536,0,1,273,309,0,561,17,65844,520,17,821,0,0,68391,273,561,257,65814,261,512]

theorem envBound23601 : H12AffineFastState.Bounded env23601 := by
  intro p hp
  have h : env23601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23600_23601 : H12AffineEnvironment.transform 5 16 env23600 = env23601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23600 == env23601) = true)

theorem identity23601 : scanCanonicalize (H12AffineFastState.compose env23601 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound23601 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23602 : List Nat := [2,4,8,16,32,16,8,256,512,272,260,0,520,0,308,65536,0,1,273,309,0,561,17,65844,520,17,821,0,0,66083,273,561,257,65814,261,512]

theorem envBound23602 : H12AffineFastState.Bounded env23602 := by
  intro p hp
  have h : env23602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23601_23602 : H12AffineEnvironment.transform 10 260 env23601 = env23602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env23601 == env23602) = true)

theorem identity23602 : scanCanonicalize (H12AffineFastState.compose env23602 (packedSelected [0,6,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound23602 : packedSelected [0,6,8] rootPS < 2^1333 := by decide +kernel

def env23603 : List Nat := [2,4,8,16,1,16,8,256,512,272,260,0,520,0,277,65536,0,1,273,276,0,528,17,65813,520,17,788,0,0,66050,273,528,257,65814,261,512]

theorem envBound23603 : H12AffineFastState.Bounded env23603 := by
  intro p hp
  have h : env23603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23602_23603 : H12AffineEnvironment.transform 4 1 env23602 = env23603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env23602 == env23603) = true)

theorem identity23603 : scanCanonicalize (H12AffineFastState.compose env23603 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound23603 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23604 : List Nat := [2,4,8,16,1,16,8,256,277,272,260,0,285,0,277,65536,0,1,273,276,0,261,17,65813,285,17,1,0,0,65815,273,261,257,65814,261,277]

theorem envBound23604 : H12AffineFastState.Bounded env23604 := by
  intro p hp
  have h : env23604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23603_23604 : H12AffineEnvironment.transform 8 277 env23603 = env23604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env23603 == env23604) = true)

theorem identity23604 : scanCanonicalize (H12AffineFastState.compose env23604 (packedSelected [1,4] rootPS)) = affineNative (2^(15+1) ^^^ 278) := by decide +kernel

theorem selectedBound23604 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env23605 : List Nat := [2,4,8,16,1,16,8,256,277,272,260,0,285,0,277,278,0,1,273,276,0,261,17,3,285,17,1,0,0,1,273,261,257,0,261,277]

theorem envBound23605 : H12AffineFastState.Bounded env23605 := by
  intro p hp
  have h : env23605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23604_23605 : H12AffineEnvironment.transform 15 278 env23604 = env23605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 278 env23604 == env23605) = true)

theorem identity23605 : scanCanonicalize (H12AffineFastState.compose env23605 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound23605 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23606 : List Nat := [2,4,8,16,1,16,8,20,1,4,16,0,9,0,1,2,0,1,5,0,0,17,17,3,9,17,1,0,0,1,5,17,21,0,17,1]

theorem envBound23606 : H12AffineFastState.Bounded env23606 := by
  intro p hp
  have h : env23606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23605_23606 : H12AffineEnvironment.transform 7 20 env23605 = env23606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env23605 == env23606) = true)

theorem identity23606 : scanCanonicalize (H12AffineFastState.compose env23606 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound23606 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23607 : List Nat := [2,4,8,0,1,0,8,4,1,4,0,0,9,0,1,2,0,1,5,0,0,1,1,3,9,1,1,0,0,1,5,1,5,0,1,1]

theorem envBound23607 : H12AffineFastState.Bounded env23607 := by
  intro p hp
  have h : env23607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23606_23607 : H12AffineEnvironment.transform 3 0 env23606 = env23607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env23606 == env23607) = true)

def env23608 : List Nat := [2,4,8,16,32,17,8,256,512,273,2048,0,520,1,309,65536,0,1,272,308,0,560,17,65845,520,16,820,1,1,68391,272,560,257,65815,261,512]

theorem envBound23608 : H12AffineFastState.Bounded env23608 := by
  intro p hp
  have h : env23608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23600_23608 : H12AffineEnvironment.transform 5 17 env23600 = env23608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23600 == env23608) = true)

theorem identity23608 : scanCanonicalize (H12AffineFastState.compose env23608 (packedSelected [5] rootPS)) = affineNative (2^(15+1) ^^^ 2595) := by decide +kernel

theorem selectedBound23608 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23609 : List Nat := [2,4,8,16,32,17,8,256,512,273,2048,0,520,1,309,2595,0,1,272,308,0,560,17,2838,520,16,820,1,1,260,272,560,257,2868,261,512]

theorem envBound23609 : H12AffineFastState.Bounded env23609 := by
  intro p hp
  have h : env23609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23608_23609 : H12AffineEnvironment.transform 15 2595 env23608 = env23609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2595 env23608 == env23609) = true)

theorem identity23609 : scanCanonicalize (H12AffineFastState.compose env23609 (packedSelected [8] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound23609 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env23610 : List Nat := [2,4,8,16,32,17,8,4,512,21,2048,0,520,1,49,2595,0,1,20,48,0,560,17,2578,520,16,560,1,1,0,20,560,5,2608,1,512]

theorem envBound23610 : H12AffineFastState.Bounded env23610 := by
  intro p hp
  have h : env23610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23609_23610 : H12AffineEnvironment.transform 7 4 env23609 = env23610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env23609 == env23610) = true)

theorem identity23610 : scanCanonicalize (H12AffineFastState.compose env23610 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound23610 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23611 : List Nat := [2,4,8,16,32,17,8,4,512,21,0,0,520,1,49,547,0,1,20,48,0,560,17,530,520,16,560,1,1,0,20,560,5,560,1,512]

theorem envBound23611 : H12AffineFastState.Bounded env23611 := by
  intro p hp
  have h : env23611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23610_23611 : H12AffineEnvironment.transform 10 0 env23610 = env23611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env23610 == env23611) = true)

theorem identity23611 : scanCanonicalize (H12AffineFastState.compose env23611 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound23611 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env23612 : List Nat := [2,4,8,16,1,17,8,4,512,21,0,0,520,1,16,514,0,1,20,17,0,529,17,530,520,16,529,1,1,0,20,529,5,529,1,512]

theorem envBound23612 : H12AffineFastState.Bounded env23612 := by
  intro p hp
  have h : env23612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23611_23612 : H12AffineEnvironment.transform 4 1 env23611 = env23612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env23611 == env23612) = true)

theorem identity23612 : scanCanonicalize (H12AffineFastState.compose env23612 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound23612 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23613 : List Nat := [2,4,8,0,1,1,8,4,512,5,0,0,520,1,0,514,0,1,4,1,0,513,1,514,520,0,513,1,1,0,4,513,5,513,1,512]

theorem envBound23613 : H12AffineFastState.Bounded env23613 := by
  intro p hp
  have h : env23613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23612_23613 : H12AffineEnvironment.transform 3 0 env23612 = env23613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env23612 == env23613) = true)

def env23614 : List Nat := [2,4,8,16,32,64,8,256,512,321,2048,1,520,81,32768,65536,1,1,320,32769,1,33541,17,98304,520,65,33281,81,81,100931,320,33541,257,98338,260,512]

theorem envBound23614 : H12AffineFastState.Bounded env23614 := by
  intro p hp
  have h : env23614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23598_23614 : H12AffineEnvironment.transform 9 321 env23598 = env23614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env23598 == env23614) = true)

theorem identity23614 : scanCanonicalize (H12AffineFastState.compose env23614 (packedSelected [13] rootPS)) = affineNative (2^(15+1) ^^^ 359) := by decide +kernel

theorem selectedBound23614 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env23615 : List Nat := [2,4,8,16,32,64,8,256,512,321,2048,1,520,81,32768,359,1,1,320,32769,1,33541,17,33127,520,65,33281,81,81,35620,320,33541,257,33093,260,512]

theorem envBound23615 : H12AffineFastState.Bounded env23615 := by
  intro p hp
  have h : env23615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23614_23615 : H12AffineEnvironment.transform 15 359 env23614 = env23615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 359 env23614 == env23615) = true)

theorem identity23615 : scanCanonicalize (H12AffineFastState.compose env23615 (packedSelected [0,2,3,4,5,6,9,17,18,32,41] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound23615 : packedSelected [0,2,3,4,5,6,9,17,18,32,41] rootPS < 2^1333 := by decide +kernel

def env23616 : List Nat := [2,4,8,16,32,64,8,256,32,321,2048,1,40,81,32768,359,1,1,320,32769,1,33061,17,33127,40,65,32801,81,81,35076,320,33061,257,33093,260,32]

theorem envBound23616 : H12AffineFastState.Bounded env23616 := by
  intro p hp
  have h : env23616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23615_23616 : H12AffineEnvironment.transform 8 32 env23615 = env23616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env23615 == env23616) = true)

theorem identity23616 : scanCanonicalize (H12AffineFastState.compose env23616 (packedSelected [4,9,11] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound23616 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env23617 : List Nat := [2,4,8,16,0,64,8,256,0,321,2048,1,8,81,32768,327,1,1,320,32769,1,33029,17,33095,8,65,32769,81,81,35076,320,33029,257,33093,260,0]

theorem envBound23617 : H12AffineFastState.Bounded env23617 := by
  intro p hp
  have h : env23617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23616_23617 : H12AffineEnvironment.transform 4 0 env23616 = env23617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23616 == env23617) = true)

theorem identity23617 : scanCanonicalize (H12AffineFastState.compose env23617 (packedSelected [1,2,5] rootPS)) = affineNative (2^(14+1) ^^^ 277) := by decide +kernel

theorem selectedBound23617 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env23618 : List Nat := [2,4,8,16,0,64,8,256,0,321,2048,1,8,81,277,327,1,1,320,276,1,16,17,82,8,65,276,81,81,2065,320,16,257,80,260,0]

theorem envBound23618 : H12AffineFastState.Bounded env23618 := by
  intro p hp
  have h : env23618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23617_23618 : H12AffineEnvironment.transform 14 277 env23617 = env23618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 277 env23617 == env23618) = true)

theorem identity23618 : scanCanonicalize (H12AffineFastState.compose env23618 (packedSelected [1,2,6] rootPS)) = affineNative (2^(10+1) ^^^ 65) := by decide +kernel

theorem selectedBound23618 : packedSelected [1,2,6] rootPS < 2^1333 := by decide +kernel

def env23619 : List Nat := [2,4,8,16,0,64,8,256,0,321,65,1,8,81,277,327,1,1,320,276,1,16,17,82,8,65,276,81,81,80,320,16,257,80,260,0]

theorem envBound23619 : H12AffineFastState.Bounded env23619 := by
  intro p hp
  have h : env23619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23618_23619 : H12AffineEnvironment.transform 10 65 env23618 = env23619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 65 env23618 == env23619) = true)

theorem identity23619 : scanCanonicalize (H12AffineFastState.compose env23619 (packedSelected [0,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound23619 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env23620 : List Nat := [2,4,8,16,0,64,8,69,0,4,65,1,8,81,80,2,1,1,5,81,1,16,17,82,8,65,81,81,81,80,5,16,68,80,65,0]

theorem envBound23620 : H12AffineFastState.Bounded env23620 := by
  intro p hp
  have h : env23620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23619_23620 : H12AffineEnvironment.transform 7 69 env23619 = env23620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env23619 == env23620) = true)

theorem identity23620 : scanCanonicalize (H12AffineFastState.compose env23620 (packedSelected [0,2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound23620 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env23621 : List Nat := [2,4,8,16,0,17,8,20,0,4,16,1,8,0,1,2,1,1,5,0,1,16,17,3,8,16,0,0,0,1,5,16,21,1,16,0]

theorem envBound23621 : H12AffineFastState.Bounded env23621 := by
  intro p hp
  have h : env23621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23620_23621 : H12AffineEnvironment.transform 5 17 env23620 = env23621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23620 == env23621) = true)

def env23622 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1344,520,1296,32768,65536,1344,0,1025,32769,1344,33540,17,98304,521,65,33281,1296,1296,1073741824,1025,33541,257,98338,1093,512]

theorem envBound23622 : H12AffineFastState.Bounded env23622 := by
  intro p hp
  have h : env23622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23596_23622 : H12AffineEnvironment.transform 6 9 env23596 = env23622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23596 == env23622) = true)

theorem identity23622 : scanCanonicalize (H12AffineFastState.compose env23622 (packedSelected [6,7] rootPS)) = affineNative (2^(29+1) ^^^ 100678) := by decide +kernel

theorem selectedBound23622 : packedSelected [6,7] rootPS < 2^1333 := by decide +kernel

def env23623 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1344,520,1296,32768,65536,1344,0,1025,32769,1344,33540,17,98304,521,65,33281,1296,1296,100678,1025,33541,257,98338,1093,512]

theorem envBound23623 : H12AffineFastState.Bounded env23623 := by
  intro p hp
  have h : env23623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23622_23623 : H12AffineEnvironment.transform 29 100678 env23622 = env23623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 100678 env23622 == env23623) = true)

def env23624 : List Nat := [2,4,8,16,32,64,9,256,512,320,2048,0,520,80,32768,65536,0,0,321,32769,0,33540,17,98304,521,65,33281,80,80,100678,321,33541,257,98338,261,512]

theorem envBound23624 : H12AffineFastState.Bounded env23624 := by
  intro p hp
  have h : env23624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23623_23624 : H12AffineEnvironment.transform 9 320 env23623 = env23624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env23623 == env23624) = true)

theorem identity23624 : scanCanonicalize (H12AffineFastState.compose env23624 (packedSelected [13] rootPS)) = affineNative (2^(14+1) ^^^ 561) := by decide +kernel

theorem selectedBound23624 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env23625 : List Nat := [2,4,8,16,32,64,9,256,512,320,2048,0,520,80,561,65536,0,0,321,560,0,309,17,66097,521,65,48,80,80,68471,321,308,257,66067,261,512]

theorem envBound23625 : H12AffineFastState.Bounded env23625 := by
  intro p hp
  have h : env23625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23624_23625 : H12AffineEnvironment.transform 14 561 env23624 = env23625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 561 env23624 == env23625) = true)

def env23626 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,0,520,0,561,65536,0,0,273,560,0,309,17,66097,521,17,48,0,0,68391,273,308,257,66067,261,512]

theorem envBound23626 : H12AffineFastState.Bounded env23626 := by
  intro p hp
  have h : env23626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23625_23626 : H12AffineEnvironment.transform 5 16 env23625 = env23626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23625 == env23626) = true)

theorem identity23626 : scanCanonicalize (H12AffineFastState.compose env23626 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound23626 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23627 : List Nat := [2,4,8,16,32,16,9,256,512,272,1,0,520,0,561,65536,0,0,273,560,0,309,17,66097,521,17,48,0,0,66342,273,308,257,66067,261,512]

theorem envBound23627 : H12AffineFastState.Bounded env23627 := by
  intro p hp
  have h : env23627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23626_23627 : H12AffineEnvironment.transform 10 1 env23626 = env23627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env23626 == env23627) = true)

theorem identity23627 : scanCanonicalize (H12AffineFastState.compose env23627 (packedSelected [0,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound23627 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env23628 : List Nat := [2,4,8,16,0,16,9,256,512,272,1,0,520,0,529,65536,0,0,273,528,0,277,17,66065,521,17,16,0,0,66310,273,276,257,66067,261,512]

theorem envBound23628 : H12AffineFastState.Bounded env23628 := by
  intro p hp
  have h : env23628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23627_23628 : H12AffineEnvironment.transform 4 0 env23627 = env23628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23627 == env23628) = true)

theorem identity23628 : scanCanonicalize (H12AffineFastState.compose env23628 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound23628 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23629 : List Nat := [2,4,8,16,0,16,9,20,512,4,1,0,520,0,529,65536,0,0,5,528,0,1,17,66065,521,17,16,0,0,66066,5,0,21,66067,17,512]

theorem envBound23629 : H12AffineFastState.Bounded env23629 := by
  intro p hp
  have h : env23629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23628_23629 : H12AffineEnvironment.transform 7 20 env23628 = env23629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env23628 == env23629) = true)

theorem identity23629 : scanCanonicalize (H12AffineFastState.compose env23629 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound23629 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env23630 : List Nat := [2,4,8,16,0,16,9,20,0,4,1,0,8,0,17,65536,0,0,5,16,0,1,17,65553,9,17,16,0,0,65554,5,0,21,65555,17,0]

theorem envBound23630 : H12AffineFastState.Bounded env23630 := by
  intro p hp
  have h : env23630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23629_23630 : H12AffineEnvironment.transform 8 0 env23629 = env23630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env23629 == env23630) = true)

theorem identity23630 : scanCanonicalize (H12AffineFastState.compose env23630 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound23630 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23631 : List Nat := [2,4,8,16,0,16,9,20,0,4,1,0,8,0,17,3,0,0,5,16,0,1,17,18,9,17,16,0,0,17,5,0,21,16,17,0]

theorem envBound23631 : H12AffineFastState.Bounded env23631 := by
  intro p hp
  have h : env23631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23630_23631 : H12AffineEnvironment.transform 15 3 env23630 = env23631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env23630 == env23631) = true)

theorem identity23631 : scanCanonicalize (H12AffineFastState.compose env23631 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound23631 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env23632 : List Nat := [2,4,8,1,0,1,9,5,0,4,1,0,8,0,0,3,0,0,5,1,0,1,0,3,9,0,1,0,0,0,5,0,4,1,0,0]

theorem envBound23632 : H12AffineFastState.Bounded env23632 := by
  intro p hp
  have h : env23632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23631_23632 : H12AffineEnvironment.transform 3 1 env23631 = env23632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env23631 == env23632) = true)

def env23633 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,0,520,1,561,65536,0,0,272,560,0,309,17,66097,521,16,48,1,1,68390,272,308,257,66067,261,512]

theorem envBound23633 : H12AffineFastState.Bounded env23633 := by
  intro p hp
  have h : env23633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23625_23633 : H12AffineEnvironment.transform 5 17 env23625 = env23633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23625 == env23633) = true)

theorem identity23633 : scanCanonicalize (H12AffineFastState.compose env23633 (packedSelected [5] rootPS)) = affineNative (2^(15+1) ^^^ 2855) := by decide +kernel

theorem selectedBound23633 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23634 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,0,520,1,561,2855,0,0,272,560,0,309,17,2326,521,16,48,1,1,1,272,308,257,2356,261,512]

theorem envBound23634 : H12AffineFastState.Bounded env23634 := by
  intro p hp
  have h : env23634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23633_23634 : H12AffineEnvironment.transform 15 2855 env23633 = env23634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2855 env23633 == env23634) = true)

theorem identity23634 : scanCanonicalize (H12AffineFastState.compose env23634 (packedSelected [0,6] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound23634 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env23635 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,0,520,1,561,2562,0,0,53,560,0,16,17,2099,521,16,48,1,1,1,53,17,36,2065,32,512]

theorem envBound23635 : H12AffineFastState.Bounded env23635 := by
  intro p hp
  have h : env23635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23634_23635 : H12AffineEnvironment.transform 7 37 env23634 = env23635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env23634 == env23635) = true)

def env23636 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,1,520,81,32768,65536,1,0,320,32769,1,33540,17,98304,521,65,33281,81,81,100678,320,33541,257,98338,260,512]

theorem envBound23636 : H12AffineFastState.Bounded env23636 := by
  intro p hp
  have h : env23636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23623_23636 : H12AffineEnvironment.transform 9 321 env23623 = env23636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env23623 == env23636) = true)

theorem identity23636 : scanCanonicalize (H12AffineFastState.compose env23636 (packedSelected [13] rootPS)) = affineNative (2^(15+1) ^^^ 563) := by decide +kernel

theorem selectedBound23636 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env23637 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,1,520,81,32768,563,1,0,320,32769,1,33540,17,33331,521,65,33281,81,81,35701,320,33541,257,33297,260,512]

theorem envBound23637 : H12AffineFastState.Bounded env23637 := by
  intro p hp
  have h : env23637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23636_23637 : H12AffineEnvironment.transform 15 563 env23636 = env23637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 563 env23636 == env23637) = true)

def env23638 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,1,520,1,32768,563,1,0,272,32769,1,33540,17,33331,521,17,33281,1,1,35621,272,33541,257,33297,260,512]

theorem envBound23638 : H12AffineFastState.Bounded env23638 := by
  intro p hp
  have h : env23638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23637_23638 : H12AffineEnvironment.transform 5 16 env23637 = env23638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23637 == env23638) = true)

theorem identity23638 : scanCanonicalize (H12AffineFastState.compose env23638 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound23638 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23639 : List Nat := [2,4,8,16,32,16,9,256,512,273,293,1,520,1,32768,563,1,0,272,32769,1,33540,17,33331,521,17,33281,1,1,33280,272,33541,257,33297,260,512]

theorem envBound23639 : H12AffineFastState.Bounded env23639 := by
  intro p hp
  have h : env23639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23638_23639 : H12AffineEnvironment.transform 10 293 env23638 = env23639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env23638 == env23639) = true)

theorem identity23639 : scanCanonicalize (H12AffineFastState.compose env23639 (packedSelected [4,9] rootPS)) = affineNative (2^(14+1) ^^^ 512) := by decide +kernel

theorem selectedBound23639 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env23640 : List Nat := [2,4,8,16,32,16,9,256,512,273,293,1,520,1,512,563,1,0,272,513,1,260,17,51,521,17,1,1,1,0,272,261,257,17,260,512]

theorem envBound23640 : H12AffineFastState.Bounded env23640 := by
  intro p hp
  have h : env23640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23639_23640 : H12AffineEnvironment.transform 14 512 env23639 = env23640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 512 env23639 == env23640) = true)

theorem identity23640 : scanCanonicalize (H12AffineFastState.compose env23640 (packedSelected [0,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound23640 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env23641 : List Nat := [2,4,8,16,32,16,9,256,292,273,293,1,300,1,292,279,1,0,272,293,1,260,17,51,301,17,1,1,1,0,272,261,257,17,260,292]

theorem envBound23641 : H12AffineFastState.Bounded env23641 := by
  intro p hp
  have h : env23641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23640_23641 : H12AffineEnvironment.transform 8 292 env23640 = env23641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env23640 == env23641) = true)

theorem identity23641 : scanCanonicalize (H12AffineFastState.compose env23641 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound23641 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23642 : List Nat := [2,4,8,16,0,16,9,256,260,273,261,1,268,1,260,279,1,0,272,261,1,260,17,19,269,17,1,1,1,0,272,261,257,17,260,260]

theorem envBound23642 : H12AffineFastState.Bounded env23642 := by
  intro p hp
  have h : env23642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23641_23642 : H12AffineEnvironment.transform 4 0 env23641 = env23642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23641 == env23642) = true)

theorem identity23642 : scanCanonicalize (H12AffineFastState.compose env23642 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound23642 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23643 : List Nat := [2,4,8,16,0,16,9,21,17,4,16,1,25,1,17,2,1,0,5,16,1,17,17,19,24,17,1,1,1,0,5,16,20,17,17,17]

theorem envBound23643 : H12AffineFastState.Bounded env23643 := by
  intro p hp
  have h : env23643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23642_23643 : H12AffineEnvironment.transform 7 21 env23642 = env23643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env23642 == env23643) = true)

def env23644 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,1,520,0,32768,563,1,0,273,32769,1,33540,17,33331,521,16,33281,0,0,35620,273,33541,257,33297,260,512]

theorem envBound23644 : H12AffineFastState.Bounded env23644 := by
  intro p hp
  have h : env23644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23637_23644 : H12AffineEnvironment.transform 5 17 env23637 = env23644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23637 == env23644) = true)

theorem identity23644 : scanCanonicalize (H12AffineFastState.compose env23644 (packedSelected [5] rootPS)) = affineNative (2^(14+1) ^^^ 2560) := by decide +kernel

theorem selectedBound23644 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23645 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,1,520,0,2560,563,1,0,273,2561,1,2308,17,2099,521,16,2049,0,0,292,273,2309,257,2065,260,512]

theorem envBound23645 : H12AffineFastState.Bounded env23645 := by
  intro p hp
  have h : env23645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23644_23645 : H12AffineEnvironment.transform 14 2560 env23644 = env23645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2560 env23644 == env23645) = true)

theorem identity23645 : scanCanonicalize (H12AffineFastState.compose env23645 (packedSelected [1,3,8] rootPS)) = affineNative (2^(10+1) ^^^ 277) := by decide +kernel

theorem selectedBound23645 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env23646 : List Nat := [2,4,8,16,32,17,9,256,512,272,277,1,520,0,789,563,1,0,273,788,1,17,17,294,521,16,276,0,0,292,273,16,257,260,260,512]

theorem envBound23646 : H12AffineFastState.Bounded env23646 := by
  intro p hp
  have h : env23646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23645_23646 : H12AffineEnvironment.transform 10 277 env23645 = env23646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 277 env23645 == env23646) = true)

theorem identity23646 : scanCanonicalize (H12AffineFastState.compose env23646 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound23646 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env23647 : List Nat := [2,4,8,16,32,17,9,256,33,272,277,1,41,0,308,18,1,0,273,309,1,17,17,294,40,16,276,0,0,292,273,16,257,260,260,33]

theorem envBound23647 : H12AffineFastState.Bounded env23647 := by
  intro p hp
  have h : env23647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23646_23647 : H12AffineEnvironment.transform 8 33 env23646 = env23647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env23646 == env23647) = true)

theorem identity23647 : scanCanonicalize (H12AffineFastState.compose env23647 (packedSelected [1,2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound23647 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env23648 : List Nat := [2,4,8,16,32,17,9,4,33,20,17,1,41,0,48,18,1,0,21,49,1,17,17,34,40,16,16,0,0,32,21,16,5,0,0,33]

theorem envBound23648 : H12AffineFastState.Bounded env23648 := by
  intro p hp
  have h : env23648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23647_23648 : H12AffineEnvironment.transform 7 4 env23647 = env23648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env23647 == env23648) = true)

theorem identity23648 : scanCanonicalize (H12AffineFastState.compose env23648 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound23648 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23649 : List Nat := [2,4,8,16,16,17,9,4,17,20,17,1,25,0,0,18,1,0,21,1,1,17,17,18,24,16,16,0,0,16,21,16,5,0,0,17]

theorem envBound23649 : H12AffineFastState.Bounded env23649 := by
  intro p hp
  have h : env23649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23648_23649 : H12AffineEnvironment.transform 4 16 env23648 = env23649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env23648 == env23649) = true)

theorem identity23649 : scanCanonicalize (H12AffineFastState.compose env23649 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound23649 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23650 : List Nat := [2,4,8,1,1,0,9,4,0,5,0,1,8,0,0,3,1,0,4,1,1,0,0,3,9,1,1,0,0,1,4,1,5,0,0,0]

theorem envBound23650 : H12AffineFastState.Bounded env23650 := by
  intro p hp
  have h : env23650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23649_23650 : H12AffineEnvironment.transform 3 1 env23649 = env23650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env23649 == env23650) = true)

def env23651 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,65536,1344,8833,1025,32769,1344,33677,17,98305,8328,65,40969,1296,1296,1073741824,1024,33541,257,98339,1092,512]

theorem envBound23651 : H12AffineFastState.Bounded env23651 := by
  intro p hp
  have h : env23651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23594_23651 : H12AffineEnvironment.transform 23 98305 env23594 = env23651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98305 env23594 == env23651) = true)

theorem identity23651 : scanCanonicalize (H12AffineFastState.compose env23651 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 780) := by decide +kernel

theorem selectedBound23651 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env23652 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,780,1296,32768,65536,1344,397,1025,32769,1344,33677,17,98305,900,65,33541,1296,1296,1073741824,1024,33541,257,98339,1092,512]

theorem envBound23652 : H12AffineFastState.Bounded env23652 := by
  intro p hp
  have h : env23652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23651_23652 : H12AffineEnvironment.transform 12 780 env23651 = env23652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 780 env23651 == env23652) = true)

def env23653 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1344,780,1296,32768,65536,1344,261,1025,32769,1344,33541,17,98305,780,65,33541,1296,1296,1073741824,1024,33541,257,98339,1092,512]

theorem envBound23653 : H12AffineFastState.Bounded env23653 := by
  intro p hp
  have h : env23653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23652_23653 : H12AffineEnvironment.transform 6 8 env23652 = env23653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23652 == env23653) = true)

theorem identity23653 : scanCanonicalize (H12AffineFastState.compose env23653 (packedSelected [6,7] rootPS)) = affineNative (2^(8+1) ^^^ 65) := by decide +kernel

theorem selectedBound23653 : packedSelected [6,7] rootPS < 2^1333 := by decide +kernel

def env23654 : List Nat := [2,4,8,16,32,64,8,256,65,1024,2048,1344,333,1296,32768,65536,1344,261,1025,32769,1344,33092,17,98305,333,65,33092,1296,1296,1073741824,1024,33092,257,98339,1092,65]

theorem envBound23654 : H12AffineFastState.Bounded env23654 := by
  intro p hp
  have h : env23654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23653_23654 : H12AffineEnvironment.transform 8 65 env23653 = env23654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env23653 == env23654) = true)

def env23655 : List Nat := [2,4,8,16,32,64,8,256,65,320,2048,0,333,80,32768,65536,0,261,321,32769,0,33092,17,98305,333,65,33092,80,80,1073741824,320,33092,257,98339,260,65]

theorem envBound23655 : H12AffineFastState.Bounded env23655 := by
  intro p hp
  have h : env23655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23654_23655 : H12AffineEnvironment.transform 9 320 env23654 = env23655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env23654 == env23655) = true)

theorem identity23655 : scanCanonicalize (H12AffineFastState.compose env23655 (packedSelected [13] rootPS)) = affineNative (2^(29+1) ^^^ 67682) := by decide +kernel

theorem selectedBound23655 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env23656 : List Nat := [2,4,8,16,32,64,8,256,65,320,2048,0,333,80,32768,65536,0,261,321,32769,0,33092,17,98305,333,65,33092,80,80,67682,320,33092,257,98339,260,65]

theorem envBound23656 : H12AffineFastState.Bounded env23656 := by
  intro p hp
  have h : env23656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23655_23656 : H12AffineEnvironment.transform 29 67682 env23655 = env23656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 67682 env23655 == env23656) = true)

def env23657 : List Nat := [2,4,8,16,32,16,8,256,17,272,2048,0,285,0,32768,65536,0,261,273,32769,0,33044,17,98305,285,17,33044,0,0,67634,272,33044,257,98339,260,17]

theorem envBound23657 : H12AffineFastState.Bounded env23657 := by
  intro p hp
  have h : env23657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23656_23657 : H12AffineEnvironment.transform 5 16 env23656 = env23657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23656 == env23657) = true)

theorem identity23657 : scanCanonicalize (H12AffineFastState.compose env23657 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound23657 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23658 : List Nat := [2,4,8,16,32,16,8,256,17,272,1,0,285,0,32768,65536,0,261,273,32769,0,33044,17,98305,285,17,33044,0,0,65587,272,33044,257,98339,260,17]

theorem envBound23658 : H12AffineFastState.Bounded env23658 := by
  intro p hp
  have h : env23658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23657_23658 : H12AffineEnvironment.transform 10 1 env23657 = env23658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env23657 == env23658) = true)

theorem identity23658 : scanCanonicalize (H12AffineFastState.compose env23658 (packedSelected [8,12] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound23658 : packedSelected [8,12] rootPS < 2^1333 := by decide +kernel

def env23659 : List Nat := [2,4,8,16,32,16,8,256,17,272,1,0,285,0,32768,34,0,261,273,32769,0,33044,17,32803,285,17,33044,0,0,17,272,33044,257,32769,260,17]

theorem envBound23659 : H12AffineFastState.Bounded env23659 := by
  intro p hp
  have h : env23659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23658_23659 : H12AffineEnvironment.transform 15 34 env23658 = env23659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env23658 == env23659) = true)

theorem identity23659 : scanCanonicalize (H12AffineFastState.compose env23659 (packedSelected [0,3,6,8] rootPS)) = affineNative (2^(14+1) ^^^ 260) := by decide +kernel

theorem selectedBound23659 : packedSelected [0,3,6,8] rootPS < 2^1333 := by decide +kernel

def env23660 : List Nat := [2,4,8,16,32,16,8,256,17,272,1,0,285,0,260,34,0,261,273,261,0,16,17,295,285,17,16,0,0,17,272,16,257,261,260,17]

theorem envBound23660 : H12AffineFastState.Bounded env23660 := by
  intro p hp
  have h : env23660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23659_23660 : H12AffineEnvironment.transform 14 260 env23659 = env23660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 260 env23659 == env23660) = true)

theorem identity23660 : scanCanonicalize (H12AffineFastState.compose env23660 (packedSelected [0,2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound23660 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env23661 : List Nat := [2,4,8,16,1,16,8,256,17,272,1,0,285,0,260,3,0,261,273,261,0,16,17,262,285,17,16,0,0,17,272,16,257,261,260,17]

theorem envBound23661 : H12AffineFastState.Bounded env23661 := by
  intro p hp
  have h : env23661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23660_23661 : H12AffineEnvironment.transform 4 1 env23660 = env23661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env23660 == env23661) = true)

theorem identity23661 : scanCanonicalize (H12AffineFastState.compose env23661 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound23661 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23662 : List Nat := [2,4,8,16,1,16,8,21,17,5,1,0,8,0,17,3,0,16,4,16,0,16,17,19,8,17,16,0,0,17,5,16,20,16,17,17]

theorem envBound23662 : H12AffineFastState.Bounded env23662 := by
  intro p hp
  have h : env23662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23661_23662 : H12AffineEnvironment.transform 7 21 env23661 = env23662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env23661 == env23662) = true)

def env23663 : List Nat := [2,4,8,16,32,17,8,256,16,273,2048,0,284,1,32768,65536,0,261,272,32769,0,33045,17,98305,284,16,33045,1,1,67635,273,33045,257,98339,260,16]

theorem envBound23663 : H12AffineFastState.Bounded env23663 := by
  intro p hp
  have h : env23663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23656_23663 : H12AffineEnvironment.transform 5 17 env23656 = env23663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23656 == env23663) = true)

theorem identity23663 : scanCanonicalize (H12AffineFastState.compose env23663 (packedSelected [5] rootPS)) = affineNative (2^(15+1) ^^^ 2098) := by decide +kernel

theorem selectedBound23663 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23664 : List Nat := [2,4,8,16,32,17,8,256,16,273,2048,0,284,1,32768,2098,0,261,272,32769,0,33045,17,34867,284,16,33045,1,1,1,273,33045,257,34833,260,16]

theorem envBound23664 : H12AffineFastState.Bounded env23664 := by
  intro p hp
  have h : env23664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23663_23664 : H12AffineEnvironment.transform 15 2098 env23663 = env23664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2098 env23663 == env23664) = true)

theorem identity23664 : scanCanonicalize (H12AffineFastState.compose env23664 (packedSelected [8] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound23664 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env23665 : List Nat := [2,4,8,16,32,17,8,5,16,20,2048,0,25,1,32768,2098,0,0,21,32769,0,32784,17,34867,25,16,32784,1,1,1,20,32784,4,34833,1,16]

theorem envBound23665 : H12AffineFastState.Bounded env23665 := by
  intro p hp
  have h : env23665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23664_23665 : H12AffineEnvironment.transform 7 5 env23664 = env23665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env23664 == env23665) = true)

theorem identity23665 : scanCanonicalize (H12AffineFastState.compose env23665 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound23665 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23666 : List Nat := [2,4,8,16,32,17,8,5,16,20,1,0,25,1,32768,51,0,0,21,32769,0,32784,17,32818,25,16,32784,1,1,1,20,32784,4,32784,1,16]

theorem envBound23666 : H12AffineFastState.Bounded env23666 := by
  intro p hp
  have h : env23666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23665_23666 : H12AffineEnvironment.transform 10 1 env23665 = env23666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env23665 == env23666) = true)

theorem identity23666 : scanCanonicalize (H12AffineFastState.compose env23666 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound23666 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env23667 : List Nat := [2,4,8,16,0,17,8,5,16,20,1,0,25,1,32768,19,0,0,21,32769,0,32784,17,32786,25,16,32784,1,1,1,20,32784,4,32784,1,16]

theorem envBound23667 : H12AffineFastState.Bounded env23667 := by
  intro p hp
  have h : env23667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23666_23667 : H12AffineEnvironment.transform 4 0 env23666 = env23667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23666 == env23667) = true)

theorem identity23667 : scanCanonicalize (H12AffineFastState.compose env23667 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound23667 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23668 : List Nat := [2,4,8,0,0,1,8,5,0,4,1,0,9,1,32768,3,0,0,5,32769,0,32768,1,32770,9,0,32768,1,1,1,4,32768,4,32768,1,0]

theorem envBound23668 : H12AffineFastState.Bounded env23668 := by
  intro p hp
  have h : env23668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23667_23668 : H12AffineEnvironment.transform 3 0 env23667 = env23668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env23667 == env23668) = true)

def env23669 : List Nat := [2,4,8,16,32,64,8,256,65,321,2048,1,333,81,32768,65536,1,261,320,32769,1,33092,17,98305,333,65,33092,81,81,1073741824,321,33092,257,98339,261,65]

theorem envBound23669 : H12AffineFastState.Bounded env23669 := by
  intro p hp
  have h : env23669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23654_23669 : H12AffineEnvironment.transform 9 321 env23654 = env23669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env23654 == env23669) = true)

theorem identity23669 : scanCanonicalize (H12AffineFastState.compose env23669 (packedSelected [13] rootPS)) = affineNative (2^(29+1) ^^^ 34912) := by decide +kernel

theorem selectedBound23669 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env23670 : List Nat := [2,4,8,16,32,64,8,256,65,321,2048,1,333,81,32768,65536,1,261,320,32769,1,33092,17,98305,333,65,33092,81,81,34912,321,33092,257,98339,261,65]

theorem envBound23670 : H12AffineFastState.Bounded env23670 := by
  intro p hp
  have h : env23670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23669_23670 : H12AffineEnvironment.transform 29 34912 env23669 = env23670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 34912 env23669 == env23670) = true)

def env23671 : List Nat := [2,4,8,16,32,64,8,256,65,321,2048,1,333,81,96,65536,1,261,320,97,1,292,17,65633,333,65,292,81,81,2048,321,292,257,65603,261,65]

theorem envBound23671 : H12AffineFastState.Bounded env23671 := by
  intro p hp
  have h : env23671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23670_23671 : H12AffineEnvironment.transform 14 96 env23670 = env23671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 96 env23670 == env23671) = true)

theorem identity23671 : scanCanonicalize (H12AffineFastState.compose env23671 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound23671 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23672 : List Nat := [2,4,8,16,32,64,8,256,65,321,32,1,333,81,96,65536,1,261,320,97,1,292,17,65633,333,65,292,81,81,32,321,292,257,65603,261,65]

theorem envBound23672 : H12AffineFastState.Bounded env23672 := by
  intro p hp
  have h : env23672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23671_23672 : H12AffineEnvironment.transform 10 32 env23671 = env23672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env23671 == env23672) = true)

theorem identity23672 : scanCanonicalize (H12AffineFastState.compose env23672 (packedSelected [4,9] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound23672 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env23673 : List Nat := [2,4,8,16,32,48,8,256,49,305,32,1,317,33,16,65536,1,261,304,17,1,292,17,65553,317,49,292,33,33,32,305,292,257,65587,261,49]

theorem envBound23673 : H12AffineFastState.Bounded env23673 := by
  intro p hp
  have h : env23673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23672_23673 : H12AffineEnvironment.transform 5 48 env23672 = env23673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env23672 == env23673) = true)

theorem identity23673 : scanCanonicalize (H12AffineFastState.compose env23673 (packedSelected [0,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound23673 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env23674 : List Nat := [2,4,8,16,1,17,8,256,16,272,1,1,284,0,16,65536,1,261,273,17,1,261,17,65553,284,16,261,0,0,1,272,261,257,65554,261,16]

theorem envBound23674 : H12AffineFastState.Bounded env23674 := by
  intro p hp
  have h : env23674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23673_23674 : H12AffineEnvironment.transform 4 1 env23673 = env23674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env23673 == env23674) = true)

theorem identity23674 : scanCanonicalize (H12AffineFastState.compose env23674 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 19) := by decide +kernel

theorem selectedBound23674 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23675 : List Nat := [2,4,8,16,1,17,8,256,16,272,1,1,284,0,16,19,1,261,273,17,1,261,17,2,284,16,261,0,0,1,272,261,257,1,261,16]

theorem envBound23675 : H12AffineFastState.Bounded env23675 := by
  intro p hp
  have h : env23675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23674_23675 : H12AffineEnvironment.transform 15 19 env23674 = env23675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 19 env23674 == env23675) = true)

theorem identity23675 : scanCanonicalize (H12AffineFastState.compose env23675 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound23675 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env23676 : List Nat := [2,4,8,0,1,1,8,256,0,256,1,1,268,0,0,3,1,261,257,1,1,261,1,2,268,0,261,0,0,1,256,261,257,1,261,0]

theorem envBound23676 : H12AffineFastState.Bounded env23676 := by
  intro p hp
  have h : env23676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23675_23676 : H12AffineEnvironment.transform 3 0 env23675 = env23676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env23675 == env23676) = true)

def env23677 : List Nat := [2,4,8,16,32,64,8,256,65,321,2048,1,333,81,97,65536,1,261,320,96,1,293,17,65632,333,65,293,81,81,2049,321,293,257,65602,261,65]

theorem envBound23677 : H12AffineFastState.Bounded env23677 := by
  intro p hp
  have h : env23677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23670_23677 : H12AffineEnvironment.transform 14 97 env23670 = env23677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 97 env23670 == env23677) = true)

theorem identity23677 : scanCanonicalize (H12AffineFastState.compose env23677 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 112) := by decide +kernel

theorem selectedBound23677 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23678 : List Nat := [2,4,8,16,32,64,8,256,65,321,112,1,333,81,97,65536,1,261,320,96,1,293,17,65632,333,65,293,81,81,113,321,293,257,65602,261,65]

theorem envBound23678 : H12AffineFastState.Bounded env23678 := by
  intro p hp
  have h : env23678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23677_23678 : H12AffineEnvironment.transform 10 112 env23677 = env23678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 112 env23677 == env23678) = true)

theorem identity23678 : scanCanonicalize (H12AffineFastState.compose env23678 (packedSelected [0,4,6,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound23678 : packedSelected [0,4,6,8,9] rootPS < 2^1333 := by decide +kernel

def env23679 : List Nat := [2,4,8,16,32,64,8,117,65,52,112,1,56,81,97,65536,1,112,53,96,1,80,17,65632,56,65,80,81,81,113,52,80,116,65602,112,65]

theorem envBound23679 : H12AffineFastState.Bounded env23679 := by
  intro p hp
  have h : env23679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23678_23679 : H12AffineEnvironment.transform 7 117 env23678 = env23679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env23678 == env23679) = true)

theorem identity23679 : scanCanonicalize (H12AffineFastState.compose env23679 (packedSelected [0,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound23679 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env23680 : List Nat := [2,4,8,16,32,48,8,5,49,52,0,1,56,33,17,65536,1,0,53,16,1,32,17,65552,56,49,32,33,33,1,52,32,4,65586,0,49]

theorem envBound23680 : H12AffineFastState.Bounded env23680 := by
  intro p hp
  have h : env23680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23679_23680 : H12AffineEnvironment.transform 5 48 env23679 = env23680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env23679 == env23680) = true)

theorem identity23680 : scanCanonicalize (H12AffineFastState.compose env23680 (packedSelected [1,2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound23680 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env23681 : List Nat := [2,4,8,1,32,33,8,5,32,37,0,1,41,33,0,65536,1,0,36,1,1,32,0,65537,41,32,32,33,33,1,37,32,4,65571,0,32]

theorem envBound23681 : H12AffineFastState.Bounded env23681 := by
  intro p hp
  have h : env23681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23680_23681 : H12AffineEnvironment.transform 3 1 env23680 = env23681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env23680 == env23681) = true)

def env23682 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1344,780,1296,32768,65536,1344,260,1025,32769,1344,33540,17,98305,781,65,33541,1296,1296,1073741824,1024,33541,257,98339,1092,512]

theorem envBound23682 : H12AffineFastState.Bounded env23682 := by
  intro p hp
  have h : env23682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23652_23682 : H12AffineEnvironment.transform 6 9 env23652 = env23682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23652 == env23682) = true)

theorem identity23682 : scanCanonicalize (H12AffineFastState.compose env23682 (packedSelected [6,7] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound23682 : packedSelected [6,7] rootPS < 2^1333 := by decide +kernel

def env23683 : List Nat := [2,4,8,16,32,64,9,68,512,1024,2048,1028,584,1108,32768,65536,1028,64,1025,32769,1028,33344,17,98305,585,65,33345,1108,1108,1073741824,1024,33345,69,98339,1092,512]

theorem envBound23683 : H12AffineFastState.Bounded env23683 := by
  intro p hp
  have h : env23683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23682_23683 : H12AffineEnvironment.transform 7 68 env23682 = env23683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env23682 == env23683) = true)

def env23684 : List Nat := [2,4,8,16,32,64,9,68,512,4,2048,0,584,80,32768,65536,0,64,5,32769,0,33344,17,98305,585,65,33345,80,80,1073741824,4,33345,69,98339,64,512]

theorem envBound23684 : H12AffineFastState.Bounded env23684 := by
  intro p hp
  have h : env23684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23683_23684 : H12AffineEnvironment.transform 9 4 env23683 = env23684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env23683 == env23684) = true)

theorem identity23684 : scanCanonicalize (H12AffineFastState.compose env23684 (packedSelected [13] rootPS)) = affineNative (2^(29+1) ^^^ 68211) := by decide +kernel

theorem selectedBound23684 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env23685 : List Nat := [2,4,8,16,32,64,9,68,512,4,2048,0,584,80,32768,65536,0,64,5,32769,0,33344,17,98305,585,65,33345,80,80,68211,4,33345,69,98339,64,512]

theorem envBound23685 : H12AffineFastState.Bounded env23685 := by
  intro p hp
  have h : env23685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23684_23685 : H12AffineEnvironment.transform 29 68211 env23684 = env23685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 68211 env23684 == env23685) = true)

def env23686 : List Nat := [2,4,8,16,32,16,9,20,512,4,2048,0,536,0,32768,65536,0,16,5,32769,0,33296,17,98305,537,17,33297,0,0,68131,4,33297,21,98339,16,512]

theorem envBound23686 : H12AffineFastState.Bounded env23686 := by
  intro p hp
  have h : env23686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23685_23686 : H12AffineEnvironment.transform 5 16 env23685 = env23686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23685 == env23686) = true)

theorem identity23686 : scanCanonicalize (H12AffineFastState.compose env23686 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound23686 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23687 : List Nat := [2,4,8,16,32,16,9,20,512,4,17,0,536,0,32768,65536,0,16,5,32769,0,33296,17,98305,537,17,33297,0,0,66098,4,33297,21,98339,16,512]

theorem envBound23687 : H12AffineFastState.Bounded env23687 := by
  intro p hp
  have h : env23687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23686_23687 : H12AffineEnvironment.transform 10 17 env23686 = env23687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env23686 == env23687) = true)

theorem identity23687 : scanCanonicalize (H12AffineFastState.compose env23687 (packedSelected [8,12] rootPS)) = affineNative (2^(15+1) ^^^ 50) := by decide +kernel

theorem selectedBound23687 : packedSelected [8,12] rootPS < 2^1333 := by decide +kernel

def env23688 : List Nat := [2,4,8,16,32,16,9,20,512,4,17,0,536,0,32768,50,0,16,5,32769,0,33296,17,32819,537,17,33297,0,0,512,4,33297,21,32785,16,512]

theorem envBound23688 : H12AffineFastState.Bounded env23688 := by
  intro p hp
  have h : env23688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23687_23688 : H12AffineEnvironment.transform 15 50 env23687 = env23688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50 env23687 == env23688) = true)

theorem identity23688 : scanCanonicalize (H12AffineFastState.compose env23688 (packedSelected [0,3,6] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound23688 : packedSelected [0,3,6] rootPS < 2^1333 := by decide +kernel

def env23689 : List Nat := [2,4,8,16,32,16,9,20,512,4,17,0,536,0,0,50,0,16,5,1,0,528,17,51,537,17,529,0,0,512,4,529,21,17,16,512]

theorem envBound23689 : H12AffineFastState.Bounded env23689 := by
  intro p hp
  have h : env23689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23688_23689 : H12AffineEnvironment.transform 14 0 env23688 = env23689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env23688 == env23689) = true)

theorem identity23689 : scanCanonicalize (H12AffineFastState.compose env23689 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound23689 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env23690 : List Nat := [2,4,8,16,1,16,9,20,512,4,17,0,536,0,0,19,0,16,5,1,0,528,17,18,537,17,529,0,0,512,4,529,21,17,16,512]

theorem envBound23690 : H12AffineFastState.Bounded env23690 := by
  intro p hp
  have h : env23690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23689_23690 : H12AffineEnvironment.transform 4 1 env23689 = env23690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env23689 == env23690) = true)

theorem identity23690 : scanCanonicalize (H12AffineFastState.compose env23690 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound23690 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23691 : List Nat := [2,4,8,16,1,16,9,20,17,4,17,0,9,0,0,19,0,16,5,1,0,1,17,18,8,17,0,0,0,17,4,0,21,17,16,17]

theorem envBound23691 : H12AffineFastState.Bounded env23691 := by
  intro p hp
  have h : env23691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23690_23691 : H12AffineEnvironment.transform 8 17 env23690 = env23691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env23690 == env23691) = true)

def env23692 : List Nat := [2,4,8,16,32,17,9,21,512,4,2048,0,537,1,32768,65536,0,17,5,32769,0,33297,17,98305,536,16,33296,1,1,68130,4,33296,20,98339,17,512]

theorem envBound23692 : H12AffineFastState.Bounded env23692 := by
  intro p hp
  have h : env23692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23685_23692 : H12AffineEnvironment.transform 5 17 env23685 = env23692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23685 == env23692) = true)

theorem identity23692 : scanCanonicalize (H12AffineFastState.compose env23692 (packedSelected [5] rootPS)) = affineNative (2^(15+1) ^^^ 2610) := by decide +kernel

theorem selectedBound23692 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23693 : List Nat := [2,4,8,16,32,17,9,21,512,4,2048,0,537,1,32768,2610,0,17,5,32769,0,33297,17,35379,536,16,33296,1,1,16,4,33296,20,35345,17,512]

theorem envBound23693 : H12AffineFastState.Bounded env23693 := by
  intro p hp
  have h : env23693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23692_23693 : H12AffineEnvironment.transform 15 2610 env23692 = env23693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2610 env23692 == env23693) = true)

theorem identity23693 : scanCanonicalize (H12AffineFastState.compose env23693 (packedSelected [0,4,6,9] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound23693 : packedSelected [0,4,6,9] rootPS < 2^1333 := by decide +kernel

def env23694 : List Nat := [2,4,8,16,16,17,9,21,512,4,2048,0,537,1,32768,2562,0,17,5,32769,0,33297,17,35331,536,16,33296,1,1,16,4,33296,20,35345,17,512]

theorem envBound23694 : H12AffineFastState.Bounded env23694 := by
  intro p hp
  have h : env23694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23693_23694 : H12AffineEnvironment.transform 4 16 env23693 = env23694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env23693 == env23694) = true)

def env23695 : List Nat := [2,4,8,16,32,64,9,68,512,5,2048,1,584,81,32768,65536,1,64,4,32769,1,33344,17,98305,585,65,33345,81,81,1073741824,5,33345,69,98339,65,512]

theorem envBound23695 : H12AffineFastState.Bounded env23695 := by
  intro p hp
  have h : env23695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23683_23695 : H12AffineEnvironment.transform 9 5 env23683 = env23695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env23683 == env23695) = true)

theorem identity23695 : scanCanonicalize (H12AffineFastState.compose env23695 (packedSelected [13] rootPS)) = affineNative (2^(29+1) ^^^ 35440) := by decide +kernel

theorem selectedBound23695 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env23696 : List Nat := [2,4,8,16,32,64,9,68,512,5,2048,1,584,81,32768,65536,1,64,4,32769,1,33344,17,98305,585,65,33345,81,81,35440,5,33345,69,98339,65,512]

theorem envBound23696 : H12AffineFastState.Bounded env23696 := by
  intro p hp
  have h : env23696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23695_23696 : H12AffineEnvironment.transform 29 35440 env23695 = env23696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 35440 env23695 == env23696) = true)

def env23697 : List Nat := [2,4,8,16,32,64,9,68,512,5,2048,1,584,81,544,65536,1,64,4,545,1,96,17,66081,585,65,97,81,81,2128,5,97,69,66051,65,512]

theorem envBound23697 : H12AffineFastState.Bounded env23697 := by
  intro p hp
  have h : env23697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23696_23697 : H12AffineEnvironment.transform 14 544 env23696 = env23697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 544 env23696 == env23697) = true)

theorem identity23697 : scanCanonicalize (H12AffineFastState.compose env23697 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 96) := by decide +kernel

theorem selectedBound23697 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23698 : List Nat := [2,4,8,16,32,64,9,68,512,5,96,1,584,81,544,65536,1,64,4,545,1,96,17,66081,585,65,97,81,81,48,5,97,69,66051,65,512]

theorem envBound23698 : H12AffineFastState.Bounded env23698 := by
  intro p hp
  have h : env23698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23697_23698 : H12AffineEnvironment.transform 10 96 env23697 = env23698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 96 env23697 == env23698) = true)

theorem identity23698 : scanCanonicalize (H12AffineFastState.compose env23698 (packedSelected [4,8,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound23698 : packedSelected [4,8,9] rootPS < 2^1333 := by decide +kernel

def env23699 : List Nat := [2,4,8,16,0,64,9,68,512,5,64,1,584,81,512,65536,1,64,4,513,1,64,17,66049,585,65,65,81,81,16,5,65,69,66051,65,512]

theorem envBound23699 : H12AffineFastState.Bounded env23699 := by
  intro p hp
  have h : env23699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23698_23699 : H12AffineEnvironment.transform 4 0 env23698 = env23699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23698 == env23699) = true)

theorem identity23699 : scanCanonicalize (H12AffineFastState.compose env23699 (packedSelected [0,4] rootPS)) = affineNative (2^(15+1) ^^^ 67) := by decide +kernel

theorem selectedBound23699 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env23700 : List Nat := [2,4,8,16,0,64,9,68,512,5,64,1,584,81,512,67,1,64,4,513,1,64,17,578,585,65,65,81,81,16,5,65,69,576,65,512]

theorem envBound23700 : H12AffineFastState.Bounded env23700 := by
  intro p hp
  have h : env23700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23699_23700 : H12AffineEnvironment.transform 15 67 env23699 = env23700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 67 env23699 == env23700) = true)

theorem identity23700 : scanCanonicalize (H12AffineFastState.compose env23700 (packedSelected [1,2] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound23700 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env23701 : List Nat := [2,4,8,16,0,64,9,68,0,5,64,1,72,81,0,67,1,64,4,1,1,64,17,66,73,65,65,81,81,16,5,65,69,64,65,0]

theorem envBound23701 : H12AffineFastState.Bounded env23701 := by
  intro p hp
  have h : env23701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23700_23701 : H12AffineEnvironment.transform 8 0 env23700 = env23701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env23700 == env23701) = true)

theorem identity23701 : scanCanonicalize (H12AffineFastState.compose env23701 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound23701 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env23702 : List Nat := [2,4,8,16,0,1,9,5,0,5,1,1,9,16,0,2,1,1,4,1,1,1,17,3,8,0,0,16,16,16,5,0,4,1,0,0]

theorem envBound23702 : H12AffineFastState.Bounded env23702 := by
  intro p hp
  have h : env23702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23701_23702 : H12AffineEnvironment.transform 5 1 env23701 = env23702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env23701 == env23702) = true)

theorem identity23702 : scanCanonicalize (H12AffineFastState.compose env23702 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound23702 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23703 : List Nat := [2,4,8,0,0,1,9,5,0,5,1,1,9,0,0,2,1,1,4,1,1,1,1,3,8,0,0,0,0,0,5,0,4,1,0,0]

theorem envBound23703 : H12AffineFastState.Bounded env23703 := by
  intro p hp
  have h : env23703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23702_23703 : H12AffineEnvironment.transform 3 0 env23702 = env23703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env23702 == env23703) = true)

def env23704 : List Nat := [2,4,8,16,32,64,9,68,512,5,2048,1,584,81,545,65536,1,64,4,544,1,97,17,66080,585,65,96,81,81,2129,5,96,69,66050,65,512]

theorem envBound23704 : H12AffineFastState.Bounded env23704 := by
  intro p hp
  have h : env23704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23696_23704 : H12AffineEnvironment.transform 14 545 env23696 = env23704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 545 env23696 == env23704) = true)

theorem identity23704 : scanCanonicalize (H12AffineFastState.compose env23704 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound23704 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env23705 : List Nat := [2,4,8,16,32,64,9,68,512,5,48,1,584,81,545,65536,1,64,4,544,1,97,17,66080,585,65,96,81,81,97,5,96,69,66050,65,512]

theorem envBound23705 : H12AffineFastState.Bounded env23705 := by
  intro p hp
  have h : env23705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23704_23705 : H12AffineEnvironment.transform 10 48 env23704 = env23705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env23704 == env23705) = true)

theorem identity23705 : scanCanonicalize (H12AffineFastState.compose env23705 (packedSelected [0,6,8] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound23705 : packedSelected [0,6,8] rootPS < 2^1333 := by decide +kernel

def env23706 : List Nat := [2,4,8,16,16,64,9,68,512,5,0,1,584,81,529,65536,1,64,4,528,1,81,17,66064,585,65,80,81,81,81,5,80,69,66050,65,512]

theorem envBound23706 : H12AffineFastState.Bounded env23706 := by
  intro p hp
  have h : env23706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23705_23706 : H12AffineEnvironment.transform 4 16 env23705 = env23706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env23705 == env23706) = true)

theorem identity23706 : scanCanonicalize (H12AffineFastState.compose env23706 (packedSelected [0,6] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound23706 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env23707 : List Nat := [2,4,8,16,16,1,9,5,512,5,0,1,521,16,529,65536,1,1,4,528,1,16,17,66064,520,0,17,16,16,16,5,17,4,66050,0,512]

theorem envBound23707 : H12AffineFastState.Bounded env23707 := by
  intro p hp
  have h : env23707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23706_23707 : H12AffineEnvironment.transform 5 1 env23706 = env23707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env23706 == env23707) = true)

theorem identity23707 : scanCanonicalize (H12AffineFastState.compose env23707 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound23707 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23708 : List Nat := [2,4,8,16,16,1,9,5,17,5,0,1,24,16,0,65536,1,1,4,1,1,16,17,65537,25,0,17,16,16,16,5,17,4,65555,0,17]

theorem envBound23708 : H12AffineFastState.Bounded env23708 := by
  intro p hp
  have h : env23708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23707_23708 : H12AffineEnvironment.transform 8 17 env23707 = env23708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env23707 == env23708) = true)

theorem identity23708 : scanCanonicalize (H12AffineFastState.compose env23708 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound23708 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23709 : List Nat := [2,4,8,0,0,1,9,5,1,5,0,1,8,0,0,65536,1,1,4,1,1,0,1,65537,9,0,1,0,0,0,5,1,4,65539,0,1]

theorem envBound23709 : H12AffineFastState.Bounded env23709 := by
  intro p hp
  have h : env23709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23708_23709 : H12AffineEnvironment.transform 3 0 env23708 = env23709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env23708 == env23709) = true)

def env23710 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,21585,32769,4096,4194304,17664,16777216,8328,5376,134217728,16384,1297,1073741824,16876545,4294967296,257,4315938986,155571472,512]

theorem envBound23710 : H12AffineFastState.Bounded env23710 := by
  intro p hp
  have h : env23710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23467_23710 : H12AffineEnvironment.transform 16 1345 env23467 = env23710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env23467 == env23710) = true)

theorem identity23710 : scanCanonicalize (H12AffineFastState.compose env23710 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(23+1) ^^^ 98565) := by decide +kernel

theorem selectedBound23710 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env23711 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,21585,32769,4096,4194304,17664,98565,8328,5376,134217728,16384,1297,1073741824,1284,4294967296,257,4299260335,138695701,512]

theorem envBound23711 : H12AffineFastState.Bounded env23711 := by
  intro p hp
  have h : env23711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23710_23711 : H12AffineEnvironment.transform 23 98565 env23710 = env23711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98565 env23710 == env23711) = true)

def env23712 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,16384,32768,65536,1345,262144,16657,32769,1344,4194304,17664,98565,8328,64,134217728,16384,1297,1073741824,1284,4294967296,257,4299260335,138690901,512]

theorem envBound23712 : H12AffineFastState.Bounded env23712 := by
  intro p hp
  have h : env23712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23711_23712 : H12AffineEnvironment.transform 11 1344 env23711 = env23712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env23711 == env23712) = true)

theorem identity23712 : scanCanonicalize (H12AffineFastState.compose env23712 (packedSelected [9,22] rootPS)) = affineNative (2^(26+1) ^^^ 4456708) := by decide +kernel

theorem selectedBound23712 : packedSelected [9,22] rootPS < 2^1333 := by decide +kernel

def env23713 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,16384,32768,65536,1345,262144,16657,32769,1344,4194304,17664,98565,8328,64,4456708,16384,1297,1073741824,1284,4294967296,257,4299260335,16465,512]

theorem envBound23713 : H12AffineFastState.Bounded env23713 := by
  intro p hp
  have h : env23713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23712_23713 : H12AffineEnvironment.transform 26 4456708 env23712 = env23713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4456708 env23712 == env23713) = true)

theorem identity23713 : scanCanonicalize (H12AffineFastState.compose env23713 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 1296) := by decide +kernel

theorem selectedBound23713 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env23714 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,65536,1345,262144,1025,32769,1344,4194304,16,98565,8328,64,4456708,1296,1297,1073741824,1284,4294967296,257,4299260335,1345,512]

theorem envBound23714 : H12AffineFastState.Bounded env23714 := by
  intro p hp
  have h : env23714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23713_23714 : H12AffineEnvironment.transform 13 1296 env23713 = env23714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env23713 == env23714) = true)

theorem identity23714 : scanCanonicalize (H12AffineFastState.compose env23714 (packedSelected [3,5,10] rootPS)) = affineNative (2^(29+1) ^^^ 4294794) := by decide +kernel

theorem selectedBound23714 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env23715 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,65536,1345,262144,1025,32769,1344,4194304,16,98565,8328,64,4456708,1296,1297,4294794,1284,4294967296,257,4299260335,1345,512]

theorem envBound23715 : H12AffineFastState.Bounded env23715 := by
  intro p hp
  have h : env23715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23714_23715 : H12AffineEnvironment.transform 29 4294794 env23714 = env23715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4294794 env23714 == env23715) = true)

theorem identity23715 : scanCanonicalize (H12AffineFastState.compose env23715 (packedSelected [1,12,13] rootPS)) = affineNative (2^(21+1) ^^^ 41089) := by decide +kernel

theorem selectedBound23715 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env23716 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,65536,1345,262144,1025,32769,1344,41089,16,98565,8328,64,303493,1296,1297,75787,1284,4294967296,257,4295041326,1345,512]

theorem envBound23716 : H12AffineFastState.Bounded env23716 := by
  intro p hp
  have h : env23716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23715_23716 : H12AffineEnvironment.transform 21 41089 env23715 = env23716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env23715 == env23716) = true)

theorem identity23716 : scanCanonicalize (H12AffineFastState.compose env23716 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 74030) := by decide +kernel

theorem selectedBound23716 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env23717 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,32768,65536,1345,262144,1025,32769,1344,41089,16,98565,8328,64,303493,1296,1297,75787,1284,74030,257,0,1345,512]

theorem envBound23717 : H12AffineFastState.Bounded env23717 := by
  intro p hp
  have h : env23717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23716_23717 : H12AffineEnvironment.transform 31 74030 env23716 = env23717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 74030 env23716 == env23717) = true)

def env23718 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,32768,65536,1297,262144,1025,32769,1296,41089,16,98565,8328,16,303493,1296,1297,75787,1284,74030,257,0,1297,512]

theorem envBound23718 : H12AffineFastState.Bounded env23718 := by
  intro p hp
  have h : env23718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23717_23718 : H12AffineEnvironment.transform 5 16 env23717 = env23718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23717 == env23718) = true)

theorem identity23718 : scanCanonicalize (H12AffineFastState.compose env23718 (packedSelected [1,3,5] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound23718 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env23719 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,32768,65536,1297,43049,1025,32769,1296,41089,16,98565,8328,16,2476,1296,1297,75787,1284,74030,257,0,1297,512]

theorem envBound23719 : H12AffineFastState.Bounded env23719 := by
  intro p hp
  have h : env23719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23718_23719 : H12AffineEnvironment.transform 17 43049 env23718 = env23719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env23718 == env23719) = true)

theorem identity23719 : scanCanonicalize (H12AffineFastState.compose env23719 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 2478) := by decide +kernel

theorem selectedBound23719 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23720 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,32768,2478,1297,43049,1025,32769,1296,41089,16,34987,8328,16,2476,1296,1297,8613,1284,10368,257,0,1297,512]

theorem envBound23720 : H12AffineFastState.Bounded env23720 := by
  intro p hp
  have h : env23720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23719_23720 : H12AffineEnvironment.transform 15 2478 env23719 = env23720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2478 env23719 == env23720) = true)

theorem identity23720 : scanCanonicalize (H12AffineFastState.compose env23720 (packedSelected [3,8] rootPS)) = affineNative (2^(14+1) ^^^ 2080) := by decide +kernel

theorem selectedBound23720 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env23721 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,1296,2080,2478,1297,8201,1025,2081,1296,10401,16,139,8328,16,2476,1296,1297,8613,1284,10368,257,0,1297,512]

theorem envBound23721 : H12AffineFastState.Bounded env23721 := by
  intro p hp
  have h : env23721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23720_23721 : H12AffineEnvironment.transform 14 2080 env23720 = env23721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2080 env23720 == env23721) = true)

theorem identity23721 : scanCanonicalize (H12AffineFastState.compose env23721 (packedSelected [3] rootPS)) = affineNative (2^(12+1) ^^^ 2469) := by decide +kernel

theorem selectedBound23721 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env23722 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,2469,1296,2080,2478,1297,2476,1025,2081,1296,260,16,139,2349,16,2476,1296,1297,2048,1284,293,257,0,1297,512]

theorem envBound23722 : H12AffineFastState.Bounded env23722 := by
  intro p hp
  have h : env23722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23721_23722 : H12AffineEnvironment.transform 12 2469 env23721 = env23722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2469 env23721 == env23722) = true)

theorem identity23722 : scanCanonicalize (H12AffineFastState.compose env23722 (packedSelected [12] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound23722 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env23723 : List Nat := [2,4,8,16,32,16,128,5,512,1024,2048,1045,2208,1045,2080,2219,1044,2217,1025,2081,1045,1,16,139,2088,16,2217,1045,1044,2048,1025,32,4,0,1044,512]

theorem envBound23723 : H12AffineFastState.Bounded env23723 := by
  intro p hp
  have h : env23723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23722_23723 : H12AffineEnvironment.transform 7 5 env23722 = env23723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env23722 == env23723) = true)

theorem identity23723 : scanCanonicalize (H12AffineFastState.compose env23723 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound23723 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23724 : List Nat := [2,4,8,16,32,16,128,5,32,1024,2048,1045,2208,1045,2080,2219,1044,2217,1025,2081,1045,1,16,139,2088,16,2217,1045,1044,2048,1025,32,4,0,1044,32]

theorem envBound23724 : H12AffineFastState.Bounded env23724 := by
  intro p hp
  have h : env23724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23723_23724 : H12AffineEnvironment.transform 8 32 env23723 = env23724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env23723 == env23724) = true)

def env23725 : List Nat := [2,4,8,16,0,16,128,5,0,1024,2048,1045,2176,1045,2048,2187,1044,2185,1025,2049,1045,1,16,139,2056,16,2185,1045,1044,2048,1025,0,4,0,1044,0]

theorem envBound23725 : H12AffineFastState.Bounded env23725 := by
  intro p hp
  have h : env23725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23724_23725 : H12AffineEnvironment.transform 4 0 env23724 = env23725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23724 == env23725) = true)

theorem identity23725 : scanCanonicalize (H12AffineFastState.compose env23725 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound23725 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23726 : List Nat := [2,4,8,16,0,16,8,5,0,1024,2048,1045,2056,1045,2048,2051,1044,2049,1025,2049,1045,1,16,3,2056,16,2049,1045,1044,2048,1025,0,4,0,1044,0]

theorem envBound23726 : H12AffineFastState.Bounded env23726 := by
  intro p hp
  have h : env23726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23725_23726 : H12AffineEnvironment.transform 6 8 env23725 = env23726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23725 == env23726) = true)

def leafEnv23726 : List Nat := [2,4,8,16,0,16,8,5,0,1024,2048,1045,2056,1045,2048,2051,1044,2049,1025,2049,1045,1,16,3,1024,2056,1,16,2049,1045,1044,2048,1025,0,4,0,5,2050,1044,0,0,1044,1]

def active23726 : List Nat := [0,1,2,3,9,10]

def tree23726 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23726 : H12WitnessSearch.Good tree23726 := H12GlobalWitnessIndex.good

theorem leafIdentity23726 : H12AffineFastState.composeSystem env23726 rootObs = leafEnv23726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23726 rootObs == leafEnv23726) = true)

theorem terminalChecked23726 : H12PackedTerminal.terminalCheckFast leafEnv23726 active23726 tree23726 = true := by decide +kernel

def env23727 : List Nat := [2,4,8,16,1,16,128,5,1,1024,2048,1045,2177,1045,2049,2186,1044,2184,1025,2048,1045,1,16,139,2057,16,2184,1045,1044,2048,1025,1,4,0,1044,1]

theorem envBound23727 : H12AffineFastState.Bounded env23727 := by
  intro p hp
  have h : env23727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23724_23727 : H12AffineEnvironment.transform 4 1 env23724 = env23727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env23724 == env23727) = true)

def leafEnv23727 : List Nat := [2,4,8,16,1,16,128,5,1,1024,2048,1045,2177,1045,2049,2186,1044,2184,1025,2048,1045,1,16,139,1024,2057,1,16,2184,1045,1044,2048,1025,1,4,0,5,2051,1044,1,0,1044,1]

def active23727 : List Nat := [0,1,2,3,6,9,10]

def tree23727 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23727 : H12WitnessSearch.Good tree23727 := H12GlobalWitnessIndex.good

theorem leafIdentity23727 : H12AffineFastState.composeSystem env23727 rootObs = leafEnv23727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23727 rootObs == leafEnv23727) = true)

theorem terminalChecked23727 : H12PackedTerminal.terminalCheckFast leafEnv23727 active23727 tree23727 = true := by decide +kernel

def env23728 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,32768,65536,1296,262144,1025,32769,1297,41089,16,98565,8328,17,303493,1296,1297,75787,1284,74030,257,0,1296,512]

theorem envBound23728 : H12AffineFastState.Bounded env23728 := by
  intro p hp
  have h : env23728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23717_23728 : H12AffineEnvironment.transform 5 17 env23717 = env23728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23717 == env23728) = true)

theorem identity23728 : scanCanonicalize (H12AffineFastState.compose env23728 (packedSelected [3,12] rootPS)) = affineNative (2^(14+1) ^^^ 8200) := by decide +kernel

theorem selectedBound23728 : packedSelected [3,12] rootPS < 2^1333 := by decide +kernel

def env23729 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,8200,65536,1296,262144,1025,8201,1297,137,16,73997,8328,17,262541,1296,1297,75787,1284,74030,257,0,1296,512]

theorem envBound23729 : H12AffineFastState.Bounded env23729 := by
  intro p hp
  have h : env23729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23728_23729 : H12AffineEnvironment.transform 14 8200 env23728 = env23729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8200 env23728 == env23729) = true)

def env23730 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,8200,65536,1296,2080,1025,8201,1297,137,16,73997,8328,17,2477,1296,1297,75787,1284,74030,257,0,1296,512]

theorem envBound23730 : H12AffineFastState.Bounded env23730 := by
  intro p hp
  have h : env23730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23729_23730 : H12AffineEnvironment.transform 17 2080 env23729 = env23730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2080 env23729 == env23730) = true)

theorem identity23730 : scanCanonicalize (H12AffineFastState.compose env23730 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 9366) := by decide +kernel

theorem selectedBound23730 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23731 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,8200,9366,1296,2080,1025,8201,1297,137,16,1435,8328,17,2477,1296,1297,3229,1284,1464,257,0,1296,512]

theorem envBound23731 : H12AffineFastState.Bounded env23731 := by
  intro p hp
  have h : env23731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23730_23731 : H12AffineEnvironment.transform 15 9366 env23730 = env23731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9366 env23730 == env23731) = true)

def env23732 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,8200,65536,1296,2081,1025,8201,1297,137,16,73997,8328,17,2476,1296,1297,75787,1284,74030,257,0,1296,512]

theorem envBound23732 : H12AffineFastState.Bounded env23732 := by
  intro p hp
  have h : env23732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23729_23732 : H12AffineEnvironment.transform 17 2081 env23729 = env23732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2081 env23729 == env23732) = true)

theorem identity23732 : scanCanonicalize (H12AffineFastState.compose env23732 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 8582) := by decide +kernel

theorem selectedBound23732 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23733 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,8192,1296,8200,8582,1296,2081,1025,8201,1297,137,16,139,8328,17,2476,1296,1297,2445,1284,168,257,0,1296,512]

theorem envBound23733 : H12AffineFastState.Bounded env23733 := by
  intro p hp
  have h : env23733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23732_23733 : H12AffineEnvironment.transform 15 8582 env23732 = env23733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8582 env23732 == env23733) = true)

def env23734 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1297,8192,1296,8200,8462,1296,2081,1025,8201,1297,1,16,3,8192,17,2340,1296,1297,2309,1284,32,257,0,1296,512]

theorem envBound23734 : H12AffineFastState.Bounded env23734 := by
  intro p hp
  have h : env23734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23733_23734 : H12AffineEnvironment.transform 6 8 env23733 = env23734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23733 == env23734) = true)

theorem identity23734 : scanCanonicalize (H12AffineFastState.compose env23734 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound23734 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23735 : List Nat := [2,4,8,16,32,17,8,256,32,1024,2048,1297,8192,1296,8200,8462,1296,2081,1025,8201,1297,1,16,3,8192,17,2340,1296,1297,2309,1284,32,257,0,1296,32]

theorem envBound23735 : H12AffineFastState.Bounded env23735 := by
  intro p hp
  have h : env23735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23734_23735 : H12AffineEnvironment.transform 8 32 env23734 = env23735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env23734 == env23735) = true)

def env23736 : List Nat := [2,4,8,16,32,17,8,256,32,1024,2048,1297,2088,1296,2080,2342,1296,2081,1025,2081,1297,1,16,3,2088,17,2340,1296,1297,2309,1284,32,257,0,1296,32]

theorem envBound23736 : H12AffineFastState.Bounded env23736 := by
  intro p hp
  have h : env23736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23735_23736 : H12AffineEnvironment.transform 12 2088 env23735 = env23736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env23735 == env23736) = true)

def env23737 : List Nat := [2,4,8,16,32,17,8,256,32,1024,2048,1297,2089,1296,2081,2343,1296,2081,1025,2080,1297,1,16,3,2089,17,2340,1296,1297,2309,1284,32,257,0,1296,32]

theorem envBound23737 : H12AffineFastState.Bounded env23737 := by
  intro p hp
  have h : env23737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23735_23737 : H12AffineEnvironment.transform 12 2089 env23735 = env23737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2089 env23735 == env23737) = true)

theorem identity23737 : scanCanonicalize (H12AffineFastState.compose env23737 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound23737 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23738 : List Nat := [2,4,8,16,32,17,8,5,32,1024,2048,1044,2089,1045,2081,2082,1045,2081,1025,2080,1044,1,16,3,2089,17,2081,1045,1044,2048,1025,32,4,0,1045,32]

theorem envBound23738 : H12AffineFastState.Bounded env23738 := by
  intro p hp
  have h : env23738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23737_23738 : H12AffineEnvironment.transform 7 5 env23737 = env23738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env23737 == env23738) = true)

theorem identity23738 : scanCanonicalize (H12AffineFastState.compose env23738 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound23738 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env23739 : List Nat := [2,4,8,16,0,17,8,5,0,1024,2048,1044,2057,1045,2049,2050,1045,2049,1025,2048,1044,1,16,3,2057,17,2049,1045,1044,2048,1025,0,4,0,1045,0]

theorem envBound23739 : H12AffineFastState.Bounded env23739 := by
  intro p hp
  have h : env23739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23738_23739 : H12AffineEnvironment.transform 4 0 env23738 = env23739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23738 == env23739) = true)

def leafEnv23739 : List Nat := [2,4,8,16,0,17,8,5,0,1024,2048,1044,2057,1045,2049,2050,1045,2049,1025,2048,1044,1,16,3,1024,2057,1,17,2049,1045,1044,2048,1025,0,4,0,5,2051,1045,0,0,1044,1]

def active23739 : List Nat := [0,1,2,3,9,10]

def tree23739 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23739 : H12WitnessSearch.Good tree23739 := H12GlobalWitnessIndex.good

theorem leafIdentity23739 : H12AffineFastState.composeSystem env23739 rootObs = leafEnv23739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23739 rootObs == leafEnv23739) = true)

theorem terminalChecked23739 : H12PackedTerminal.terminalCheckFast leafEnv23739 active23739 tree23739 = true := by decide +kernel

def env23740 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,1297,8192,1296,8200,8463,1296,2081,1025,8201,1297,0,16,2,8193,17,2341,1296,1297,2308,1284,33,257,0,1296,512]

theorem envBound23740 : H12AffineFastState.Bounded env23740 := by
  intro p hp
  have h : env23740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23733_23740 : H12AffineEnvironment.transform 6 9 env23733 = env23740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23733 == env23740) = true)

theorem identity23740 : scanCanonicalize (H12AffineFastState.compose env23740 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound23740 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23741 : List Nat := [2,4,8,16,32,17,9,256,260,1024,2048,1297,8192,1296,8200,8463,1296,2081,1025,8201,1297,0,16,2,8193,17,2341,1296,1297,2308,1284,33,257,0,1296,260]

theorem envBound23741 : H12AffineFastState.Bounded env23741 := by
  intro p hp
  have h : env23741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23740_23741 : H12AffineEnvironment.transform 8 260 env23740 = env23741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env23740 == env23741) = true)

def env23742 : List Nat := [2,4,8,16,32,17,9,256,260,1024,2048,1297,2056,1296,2048,2311,1296,2081,1025,2049,1297,0,16,2,2057,17,2341,1296,1297,2308,1284,33,257,0,1296,260]

theorem envBound23742 : H12AffineFastState.Bounded env23742 := by
  intro p hp
  have h : env23742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23741_23742 : H12AffineEnvironment.transform 12 2056 env23741 = env23742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2056 env23741 == env23742) = true)

theorem identity23742 : scanCanonicalize (H12AffineFastState.compose env23742 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound23742 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23743 : List Nat := [2,4,8,16,1,17,9,256,260,1024,2048,1297,2056,1296,2048,2311,1296,2048,1025,2049,1297,0,16,2,2057,17,2308,1296,1297,2308,1284,0,257,0,1296,260]

theorem envBound23743 : H12AffineFastState.Bounded env23743 := by
  intro p hp
  have h : env23743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23742_23743 : H12AffineEnvironment.transform 4 1 env23742 = env23743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env23742 == env23743) = true)

def leafEnv23743 : List Nat := [2,4,8,16,1,17,9,256,260,1024,2048,1297,2056,1296,2048,2311,1296,2048,1025,2049,1297,0,16,2,1285,2057,1,17,2308,1296,1297,2308,1284,0,257,0,5,2311,1296,260,0,1297,1]

def active23743 : List Nat := [0,1,2,3,7,9,10]

def tree23743 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23743 : H12WitnessSearch.Good tree23743 := H12GlobalWitnessIndex.good

theorem leafIdentity23743 : H12AffineFastState.composeSystem env23743 rootObs = leafEnv23743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23743 rootObs == leafEnv23743) = true)

theorem terminalChecked23743 : H12PackedTerminal.terminalCheckFast leafEnv23743 active23743 tree23743 = true := by decide +kernel

def env23744 : List Nat := [2,4,8,16,32,17,9,256,260,1024,2048,1297,2057,1296,2049,2310,1296,2081,1025,2048,1297,0,16,2,2056,17,2341,1296,1297,2308,1284,33,257,0,1296,260]

theorem envBound23744 : H12AffineFastState.Bounded env23744 := by
  intro p hp
  have h : env23744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23741_23744 : H12AffineEnvironment.transform 12 2057 env23741 = env23744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2057 env23741 == env23744) = true)

theorem identity23744 : scanCanonicalize (H12AffineFastState.compose env23744 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound23744 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23745 : List Nat := [2,4,8,16,32,17,9,36,32,1024,2048,1077,2057,1076,2049,2082,1076,2081,1025,2048,1077,0,16,2,2056,17,2049,1076,1077,2080,1056,33,37,0,1076,32]

theorem envBound23745 : H12AffineFastState.Bounded env23745 := by
  intro p hp
  have h : env23745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23744_23745 : H12AffineEnvironment.transform 7 36 env23744 = env23745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env23744 == env23745) = true)

def leafEnv23745 : List Nat := [2,4,8,16,32,17,9,36,32,1024,2048,1077,2057,1076,2049,2082,1076,2081,1025,2048,1077,0,16,2,1057,2056,1,17,2049,1076,1077,2080,1056,33,37,0,5,2082,1076,32,0,1077,1]

def active23745 : List Nat := [0,1,2,3,4,9,10]

def tree23745 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23745 : H12WitnessSearch.Good tree23745 := H12GlobalWitnessIndex.good

theorem leafIdentity23745 : H12AffineFastState.composeSystem env23745 rootObs = leafEnv23745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23745 rootObs == leafEnv23745) = true)

theorem terminalChecked23745 : H12PackedTerminal.terminalCheckFast leafEnv23745 active23745 tree23745 = true := by decide +kernel

def env23746 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,16384,32768,65536,1345,262144,16656,32769,1345,4194304,17664,98565,8328,65,134217728,16384,1297,1073741824,1284,4294967296,257,4299260335,138690900,512]

theorem envBound23746 : H12AffineFastState.Bounded env23746 := by
  intro p hp
  have h : env23746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23711_23746 : H12AffineEnvironment.transform 11 1345 env23711 = env23746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env23711 == env23746) = true)

theorem identity23746 : scanCanonicalize (H12AffineFastState.compose env23746 (packedSelected [9,22] rootPS)) = affineNative (2^(13+1) ^^^ 1297) := by decide +kernel

theorem selectedBound23746 : packedSelected [9,22] rootPS < 2^1333 := by decide +kernel

def env23747 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,65536,1345,262144,1025,32769,1345,4194304,17,98565,8328,65,134217728,1297,1297,1073741824,1284,4294967296,257,4299260335,138675269,512]

theorem envBound23747 : H12AffineFastState.Bounded env23747 := by
  intro p hp
  have h : env23747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23746_23747 : H12AffineEnvironment.transform 13 1297 env23746 = env23747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env23746 == env23747) = true)

def env23748 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,65536,1345,512,1025,32769,1345,4194304,17,98565,8328,65,134217728,1297,1297,1073741824,1284,4294967296,257,4299260335,138413637,512]

theorem envBound23748 : H12AffineFastState.Bounded env23748 := by
  intro p hp
  have h : env23748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23747_23748 : H12AffineEnvironment.transform 17 512 env23747 = env23748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 512 env23747 == env23748) = true)

theorem identity23748 : scanCanonicalize (H12AffineFastState.compose env23748 (packedSelected [3,5,24] rootPS)) = affineNative (2^(21+1) ^^^ 41481) := by decide +kernel

theorem selectedBound23748 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env23749 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,32768,65536,1345,512,1025,32769,1345,41481,17,98565,8328,65,134217728,1297,1297,1073741824,1284,4294967296,257,4295041958,134259788,512]

theorem envBound23749 : H12AffineFastState.Bounded env23749 := by
  intro p hp
  have h : env23749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23748_23749 : H12AffineEnvironment.transform 21 41481 env23748 = env23749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41481 env23748 == env23749) = true)

def env23750 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,0,65536,1345,512,1025,1,1345,8713,17,65797,8328,65,134217728,1297,1297,1073741824,1284,4294967296,257,4295041958,134227020,512]

theorem envBound23750 : H12AffineFastState.Bounded env23750 := by
  intro p hp
  have h : env23750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23749_23750 : H12AffineEnvironment.transform 14 0 env23749 = env23750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env23749 == env23750) = true)

theorem identity23750 : scanCanonicalize (H12AffineFastState.compose env23750 (packedSelected [1,8,28] rootPS)) = affineNative (2^(26+1) ^^^ 8461) := by decide +kernel

theorem selectedBound23750 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env23751 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,0,65536,1345,512,1025,1,1345,8713,17,65797,8328,65,8461,1297,1297,1073741824,1284,4294967296,257,4295041958,1345,512]

theorem envBound23751 : H12AffineFastState.Bounded env23751 := by
  intro p hp
  have h : env23751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23750_23751 : H12AffineEnvironment.transform 26 8461 env23750 = env23751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 8461 env23750 == env23751) = true)

theorem identity23751 : scanCanonicalize (H12AffineFastState.compose env23751 (packedSelected [7] rootPS)) = affineNative (2^(31+1) ^^^ 1073744245) := by decide +kernel

theorem selectedBound23751 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env23752 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,0,65536,1345,512,1025,1,1345,8713,17,65797,8328,65,8461,1297,1297,1073741824,1284,1073744245,257,1073818323,1345,512]

theorem envBound23752 : H12AffineFastState.Bounded env23752 := by
  intro p hp
  have h : env23752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23751_23752 : H12AffineEnvironment.transform 31 1073744245 env23751 = env23752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1073744245 env23751 == env23752) = true)

theorem identity23752 : scanCanonicalize (H12AffineFastState.compose env23752 (packedSelected [1,12,13] rootPS)) = affineNative (2^(29+1) ^^^ 76419) := by decide +kernel

theorem selectedBound23752 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env23753 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,0,65536,1345,512,1025,1,1345,8713,17,65797,8328,65,8461,1297,1297,76419,1284,74742,257,80,1345,512]

theorem envBound23753 : H12AffineFastState.Bounded env23753 := by
  intro p hp
  have h : env23753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23752_23753 : H12AffineEnvironment.transform 29 76419 env23752 = env23753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 76419 env23752 == env23753) = true)

def env23754 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,1345,8192,1297,0,65536,1345,136,1025,1,1345,8321,17,65797,8328,65,8461,1297,1297,75787,1284,74110,257,80,1345,136]

theorem envBound23754 : H12AffineFastState.Bounded env23754 := by
  intro p hp
  have h : env23754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23753_23754 : H12AffineEnvironment.transform 8 136 env23753 = env23754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env23753 == env23754) = true)

theorem identity23754 : scanCanonicalize (H12AffineFastState.compose env23754 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound23754 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env23755 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1296,8192,1297,0,65536,1296,136,1025,1,1296,8321,17,65797,8328,16,8461,1297,1297,75787,1284,74031,257,1,1296,136]

theorem envBound23755 : H12AffineFastState.Bounded env23755 := by
  intro p hp
  have h : env23755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23754_23755 : H12AffineEnvironment.transform 5 17 env23754 = env23755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23754 == env23755) = true)

theorem identity23755 : scanCanonicalize (H12AffineFastState.compose env23755 (packedSelected [1,3,5] rootPS)) = affineNative (2^(12+1) ^^^ 2209) := by decide +kernel

theorem selectedBound23755 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env23756 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1296,2209,1297,0,65536,1296,136,1025,1,1296,2080,17,65797,2089,16,2476,1297,1297,65706,1284,67982,257,1,1296,136]

theorem envBound23756 : H12AffineFastState.Bounded env23756 := by
  intro p hp
  have h : env23756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23755_23756 : H12AffineEnvironment.transform 12 2209 env23755 = env23756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2209 env23755 == env23756) = true)

theorem identity23756 : scanCanonicalize (H12AffineFastState.compose env23756 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound23756 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23757 : List Nat := [2,4,8,16,32,17,128,141,136,1024,2048,1181,2209,1180,0,65536,1181,136,1025,1,1181,2080,17,65672,2089,16,2081,1180,1180,65706,1161,67587,140,1,1181,136]

theorem envBound23757 : H12AffineFastState.Bounded env23757 := by
  intro p hp
  have h : env23757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23756_23757 : H12AffineEnvironment.transform 7 141 env23756 = env23757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env23756 == env23757) = true)

theorem identity23757 : scanCanonicalize (H12AffineFastState.compose env23757 (packedSelected [3,8] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound23757 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env23758 : List Nat := [2,4,8,16,32,17,128,141,136,1024,2048,1181,2209,1180,0,3,1181,136,1025,1,1181,2080,17,139,2089,16,2081,1180,1180,169,1161,2048,140,1,1181,136]

theorem envBound23758 : H12AffineFastState.Bounded env23758 := by
  intro p hp
  have h : env23758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23757_23758 : H12AffineEnvironment.transform 15 3 env23757 = env23758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env23757 == env23758) = true)

theorem identity23758 : scanCanonicalize (H12AffineFastState.compose env23758 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 169) := by decide +kernel

theorem selectedBound23758 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env23759 : List Nat := [2,4,8,16,32,17,128,141,136,1024,169,1181,8,1180,0,3,1181,136,1025,1,1181,137,17,139,128,16,136,1180,1180,169,1161,169,140,1,1181,136]

theorem envBound23759 : H12AffineFastState.Bounded env23759 := by
  intro p hp
  have h : env23759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23758_23759 : H12AffineEnvironment.transform 10 169 env23758 = env23759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 169 env23758 == env23759) = true)

theorem identity23759 : scanCanonicalize (H12AffineFastState.compose env23759 (packedSelected [2,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound23759 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env23760 : List Nat := [2,4,8,16,0,17,128,141,136,1024,137,1181,8,1180,0,3,1181,136,1025,1,1181,137,17,139,128,16,136,1180,1180,137,1161,137,140,1,1181,136]

theorem envBound23760 : H12AffineFastState.Bounded env23760 := by
  intro p hp
  have h : env23760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23759_23760 : H12AffineEnvironment.transform 4 0 env23759 = env23760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23759 == env23760) = true)

def env23761 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,8192,1297,0,65536,1345,137,1025,1,1345,8320,17,65797,8328,65,8461,1297,1297,75786,1284,74111,257,80,1345,137]

theorem envBound23761 : H12AffineFastState.Bounded env23761 := by
  intro p hp
  have h : env23761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23753_23761 : H12AffineEnvironment.transform 8 137 env23753 = env23761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env23753 == env23761) = true)

theorem identity23761 : scanCanonicalize (H12AffineFastState.compose env23761 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound23761 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env23762 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1345,349,1297,0,65536,1345,137,1025,1,1345,477,17,65797,469,65,80,1297,1297,67927,1284,65570,257,80,1345,137]

theorem envBound23762 : H12AffineFastState.Bounded env23762 := by
  intro p hp
  have h : env23762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23761_23762 : H12AffineEnvironment.transform 12 349 env23761 = env23762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env23761 == env23762) = true)

theorem identity23762 : scanCanonicalize (H12AffineFastState.compose env23762 (packedSelected [1,8,12] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound23762 : packedSelected [1,8,12] rootPS < 2^1333 := by decide +kernel

def env23763 : List Nat := [2,4,8,16,32,64,128,84,137,1024,2048,1045,9,1093,0,65536,1045,137,1025,1,1045,137,17,65617,129,65,80,1093,1093,67587,1104,65570,85,80,1045,137]

theorem envBound23763 : H12AffineFastState.Bounded env23763 := by
  intro p hp
  have h : env23763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23762_23763 : H12AffineEnvironment.transform 7 84 env23762 = env23763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env23762 == env23763) = true)

theorem identity23763 : scanCanonicalize (H12AffineFastState.compose env23763 (packedSelected [1,2,3,4,8,9,23] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound23763 : packedSelected [1,2,3,4,8,9,23] rootPS < 2^1333 := by decide +kernel

def env23764 : List Nat := [2,4,8,16,32,64,128,84,137,1024,1,1045,9,1093,0,65536,1045,137,1025,1,1045,137,17,65617,129,65,80,1093,1093,65538,1104,65570,85,80,1045,137]

theorem envBound23764 : H12AffineFastState.Bounded env23764 := by
  intro p hp
  have h : env23764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23763_23764 : H12AffineEnvironment.transform 10 1 env23763 = env23764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env23763 == env23764) = true)

theorem identity23764 : scanCanonicalize (H12AffineFastState.compose env23764 (packedSelected [0,4,5,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound23764 : packedSelected [0,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env23765 : List Nat := [2,4,8,16,32,64,40,84,33,1024,1,1045,9,1093,0,65536,1045,33,1025,1,1045,33,17,65617,41,65,80,1093,1093,65538,1104,65570,85,80,1045,33]

theorem envBound23765 : H12AffineFastState.Bounded env23765 := by
  intro p hp
  have h : env23765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23764_23765 : H12AffineEnvironment.transform 6 40 env23764 = env23765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env23764 == env23765) = true)

theorem identity23765 : scanCanonicalize (H12AffineFastState.compose env23765 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound23765 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env23766 : List Nat := [2,4,8,16,32,16,40,4,33,1024,1,1045,9,1045,0,65536,1045,33,1025,1,1045,33,17,65537,41,17,0,1045,1045,65538,1024,65570,5,0,1045,33]

theorem envBound23766 : H12AffineFastState.Bounded env23766 := by
  intro p hp
  have h : env23766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23765_23766 : H12AffineEnvironment.transform 5 16 env23765 = env23766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23765 == env23766) = true)

theorem identity23766 : scanCanonicalize (H12AffineFastState.compose env23766 (packedSelected [2,4] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound23766 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env23767 : List Nat := [2,4,8,16,32,16,40,4,33,1024,1,1045,9,1045,0,34,1045,33,1025,1,1045,33,17,35,41,17,0,1045,1045,32,1024,0,5,0,1045,33]

theorem envBound23767 : H12AffineFastState.Bounded env23767 := by
  intro p hp
  have h : env23767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23766_23767 : H12AffineEnvironment.transform 15 34 env23766 = env23767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env23766 == env23767) = true)

def leafEnv23767 : List Nat := [2,4,8,16,32,16,40,4,33,1024,1,1045,9,1045,0,34,1045,33,1025,1,1045,33,17,35,1025,41,1,17,0,1045,1045,32,1024,0,5,0,5,3,1045,33,0,1045,1]

def active23767 : List Nat := [0,1,2,3,4,9]

def tree23767 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23767 : H12WitnessSearch.Good tree23767 := H12GlobalWitnessIndex.good

theorem leafIdentity23767 : H12AffineFastState.composeSystem env23767 rootObs = leafEnv23767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23767 rootObs == leafEnv23767) = true)

theorem terminalChecked23767 : H12PackedTerminal.terminalCheckFast leafEnv23767 active23767 tree23767 = true := by decide +kernel

def env23768 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1297,1,65536,1345,512,1025,0,1345,8712,17,65796,8328,65,134217728,1297,1297,1073741824,1284,4294967296,257,4295041958,134227021,512]

theorem envBound23768 : H12AffineFastState.Bounded env23768 := by
  intro p hp
  have h : env23768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23749_23768 : H12AffineEnvironment.transform 14 1 env23749 = env23768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env23749 == env23768) = true)

def env23769 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,81,8192,1,1,65536,81,512,273,0,81,8712,17,65796,8328,65,134217728,1,1,1073741824,20,4294967296,257,4295041958,134226269,512]

theorem envBound23769 : H12AffineFastState.Bounded env23769 := by
  intro p hp
  have h : env23769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23768_23769 : H12AffineEnvironment.transform 9 272 env23768 = env23769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env23768 == env23769) = true)

theorem identity23769 : scanCanonicalize (H12AffineFastState.compose env23769 (packedSelected [7] rootPS)) = affineNative (2^(31+1) ^^^ 134291959) := by decide +kernel

theorem selectedBound23769 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env23770 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,81,8192,1,1,65536,81,512,273,0,81,8712,17,65796,8328,65,134217728,1,1,1073741824,20,134291959,257,134218321,134226269,512]

theorem envBound23770 : H12AffineFastState.Bounded env23770 := by
  intro p hp
  have h : env23770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23769_23770 : H12AffineEnvironment.transform 31 134291959 env23769 = env23770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 134291959 env23769 == env23770) = true)

theorem identity23770 : scanCanonicalize (H12AffineFastState.compose env23770 (packedSelected [5,13,15,21] rootPS)) = affineNative (2^(29+1) ^^^ 292) := by decide +kernel

theorem selectedBound23770 : packedSelected [5,13,15,21] rootPS < 2^1333 := by decide +kernel

def env23771 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,81,8192,1,1,65536,81,512,273,0,81,8712,17,65796,8328,65,134217728,1,1,292,20,134291959,257,134218321,134226269,512]

theorem envBound23771 : H12AffineFastState.Bounded env23771 := by
  intro p hp
  have h : env23771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23770_23771 : H12AffineEnvironment.transform 29 292 env23770 = env23771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 292 env23770 == env23771) = true)

theorem identity23771 : scanCanonicalize (H12AffineFastState.compose env23771 (packedSelected [18] rootPS)) = affineNative (2^(26+1) ^^^ 2852) := by decide +kernel

theorem selectedBound23771 : packedSelected [18] rootPS < 2^1333 := by decide +kernel

def env23772 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,81,8192,1,1,65536,81,512,273,0,81,8712,17,65796,8328,65,2852,1,1,292,20,76499,257,2421,10873,512]

theorem envBound23772 : H12AffineFastState.Bounded env23772 := by
  intro p hp
  have h : env23772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23771_23772 : H12AffineEnvironment.transform 26 2852 env23771 = env23772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 2852 env23771 == env23772) = true)

theorem identity23772 : scanCanonicalize (H12AffineFastState.compose env23772 (packedSelected [23] rootPS)) = affineNative (2^(12+1) ^^^ 2600) := by decide +kernel

theorem selectedBound23772 : packedSelected [23] rootPS < 2^1333 := by decide +kernel

def env23773 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,81,2600,1,1,65536,81,512,273,0,81,2080,17,65796,2720,65,2852,1,1,292,20,65787,257,2421,81,512]

theorem envBound23773 : H12AffineFastState.Bounded env23773 := by
  intro p hp
  have h : env23773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23772_23773 : H12AffineEnvironment.transform 12 2600 env23772 = env23773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2600 env23772 == env23773) = true)

theorem identity23773 : scanCanonicalize (H12AffineFastState.compose env23773 (packedSelected [1,13] rootPS)) = affineNative (2^(15+1) ^^^ 399) := by decide +kernel

theorem selectedBound23773 : packedSelected [1,13] rootPS < 2^1333 := by decide +kernel

def env23774 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,81,2600,1,1,399,81,512,273,0,81,2080,17,139,2720,65,2852,1,1,292,20,372,257,2421,81,512]

theorem envBound23774 : H12AffineFastState.Bounded env23774 := by
  intro p hp
  have h : env23774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23773_23774 : H12AffineEnvironment.transform 15 399 env23773 = env23774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 399 env23773 == env23774) = true)

def env23775 : List Nat := [2,4,8,16,32,64,128,256,512,272,512,81,40,1,1,399,81,512,273,0,81,544,17,139,160,65,292,1,1,292,20,372,257,885,81,512]

theorem envBound23775 : H12AffineFastState.Bounded env23775 := by
  intro p hp
  have h : env23775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23774_23775 : H12AffineEnvironment.transform 10 512 env23774 = env23775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env23774 == env23775) = true)

def env23776 : List Nat := [2,4,8,16,32,16,128,256,512,272,512,1,40,1,1,399,1,512,273,0,1,544,17,139,160,17,292,1,1,292,20,292,257,805,1,512]

theorem envBound23776 : H12AffineFastState.Bounded env23776 := by
  intro p hp
  have h : env23776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23775_23776 : H12AffineEnvironment.transform 5 16 env23775 = env23776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23775 == env23776) = true)

theorem identity23776 : scanCanonicalize (H12AffineFastState.compose env23776 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound23776 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23777 : List Nat := [2,4,8,16,32,16,40,256,512,272,512,1,40,1,1,295,1,512,273,0,1,544,17,35,8,17,292,1,1,292,20,292,257,805,1,512]

theorem envBound23777 : H12AffineFastState.Bounded env23777 := by
  intro p hp
  have h : env23777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23776_23777 : H12AffineEnvironment.transform 6 40 env23776 = env23777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env23776 == env23777) = true)

def env23778 : List Nat := [2,4,8,16,32,16,40,256,0,272,0,1,40,1,1,295,1,0,273,0,1,32,17,35,8,17,292,1,1,292,20,292,257,293,1,0]

theorem envBound23778 : H12AffineFastState.Bounded env23778 := by
  intro p hp
  have h : env23778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23777_23778 : H12AffineEnvironment.transform 8 0 env23777 = env23778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env23777 == env23778) = true)

theorem identity23778 : scanCanonicalize (H12AffineFastState.compose env23778 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound23778 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23779 : List Nat := [2,4,8,16,0,16,8,256,0,272,0,1,8,1,1,263,1,0,273,0,1,0,17,3,8,17,260,1,1,260,20,260,257,261,1,0]

theorem envBound23779 : H12AffineFastState.Bounded env23779 := by
  intro p hp
  have h : env23779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23778_23779 : H12AffineEnvironment.transform 4 0 env23778 = env23779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23778 == env23779) = true)

theorem identity23779 : scanCanonicalize (H12AffineFastState.compose env23779 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound23779 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env23780 : List Nat := [2,4,8,16,0,16,8,4,0,20,0,1,8,1,1,3,1,0,21,0,1,0,17,3,8,17,0,1,1,0,20,0,5,1,1,0]

theorem envBound23780 : H12AffineFastState.Bounded env23780 := by
  intro p hp
  have h : env23780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23779_23780 : H12AffineEnvironment.transform 7 4 env23779 = env23780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env23779 == env23780) = true)

def leafEnv23780 : List Nat := [2,4,8,16,0,16,8,4,0,20,0,1,8,1,1,3,1,0,21,0,1,0,17,3,21,8,1,17,0,1,1,0,20,0,5,1,5,2,1,0,0,1,1]

def active23780 : List Nat := [0,1,2,3]

def tree23780 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23780 : H12WitnessSearch.Good tree23780 := H12GlobalWitnessIndex.good

theorem leafIdentity23780 : H12AffineFastState.composeSystem env23780 rootObs = leafEnv23780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23780 rootObs == leafEnv23780) = true)

theorem terminalChecked23780 : H12PackedTerminal.terminalCheckFast leafEnv23780 active23780 tree23780 = true := by decide +kernel

def env23781 : List Nat := [2,4,8,16,32,16,40,256,1,272,1,1,40,1,1,295,1,1,273,0,1,33,17,35,8,17,292,1,1,292,20,292,257,292,1,1]

theorem envBound23781 : H12AffineFastState.Bounded env23781 := by
  intro p hp
  have h : env23781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23777_23781 : H12AffineEnvironment.transform 8 1 env23777 = env23781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env23777 == env23781) = true)

def env23782 : List Nat := [2,4,8,16,0,16,8,256,1,272,1,1,8,1,1,263,1,1,273,0,1,1,17,3,8,17,260,1,1,260,20,260,257,260,1,1]

theorem envBound23782 : H12AffineFastState.Bounded env23782 := by
  intro p hp
  have h : env23782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23781_23782 : H12AffineEnvironment.transform 4 0 env23781 = env23782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23781 == env23782) = true)

def leafEnv23782 : List Nat := [2,4,8,16,0,16,8,256,1,272,1,1,8,1,1,263,1,1,273,0,1,1,17,3,21,8,1,17,260,1,1,260,20,260,257,260,5,262,1,1,0,1,1]

def active23782 : List Nat := [0,1,2,3,7]

def tree23782 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23782 : H12WitnessSearch.Good tree23782 := H12GlobalWitnessIndex.good

theorem leafIdentity23782 : H12AffineFastState.composeSystem env23782 rootObs = leafEnv23782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23782 rootObs == leafEnv23782) = true)

theorem terminalChecked23782 : H12PackedTerminal.terminalCheckFast leafEnv23782 active23782 tree23782 = true := by decide +kernel

def env23783 : List Nat := [2,4,8,16,1,16,9,256,1,272,1,1,9,1,1,262,1,1,273,0,1,0,17,2,8,17,261,1,1,261,20,261,257,261,1,1]

theorem envBound23783 : H12AffineFastState.Bounded env23783 := by
  intro p hp
  have h : env23783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23781_23783 : H12AffineEnvironment.transform 4 1 env23781 = env23783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env23781 == env23783) = true)

theorem identity23783 : scanCanonicalize (H12AffineFastState.compose env23783 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound23783 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env23784 : List Nat := [2,4,8,16,1,16,9,4,1,20,1,1,9,1,1,2,1,1,21,0,1,0,17,2,8,17,1,1,1,1,20,1,5,1,1,1]

theorem envBound23784 : H12AffineFastState.Bounded env23784 := by
  intro p hp
  have h : env23784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23783_23784 : H12AffineEnvironment.transform 7 4 env23783 = env23784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env23783 == env23784) = true)

def leafEnv23784 : List Nat := [2,4,8,16,1,16,9,4,1,20,1,1,9,1,1,2,1,1,21,0,1,0,17,2,21,8,1,17,1,1,1,1,20,1,5,1,5,2,1,1,0,1,1]

def active23784 : List Nat := [0,1,2,3]

def tree23784 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23784 : H12WitnessSearch.Good tree23784 := H12GlobalWitnessIndex.good

theorem leafIdentity23784 : H12AffineFastState.composeSystem env23784 rootObs = leafEnv23784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23784 rootObs == leafEnv23784) = true)

theorem terminalChecked23784 : H12PackedTerminal.terminalCheckFast leafEnv23784 active23784 tree23784 = true := by decide +kernel

def env23785 : List Nat := [2,4,8,16,32,17,128,256,512,272,512,0,40,1,1,399,0,512,273,0,0,544,17,139,160,16,292,1,1,292,20,293,257,804,0,512]

theorem envBound23785 : H12AffineFastState.Bounded env23785 := by
  intro p hp
  have h : env23785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23775_23785 : H12AffineEnvironment.transform 5 17 env23775 = env23785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23775 == env23785) = true)

theorem identity23785 : scanCanonicalize (H12AffineFastState.compose env23785 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound23785 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23786 : List Nat := [2,4,8,16,1,17,128,256,512,272,512,0,9,1,1,399,0,512,273,0,0,513,17,139,129,16,261,1,1,261,20,260,257,773,0,512]

theorem envBound23786 : H12AffineFastState.Bounded env23786 := by
  intro p hp
  have h : env23786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23785_23786 : H12AffineEnvironment.transform 4 1 env23785 = env23786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env23785 == env23786) = true)

theorem identity23786 : scanCanonicalize (H12AffineFastState.compose env23786 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound23786 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env23787 : List Nat := [2,4,8,16,1,17,128,256,261,272,261,0,9,1,1,399,0,261,273,0,0,260,17,139,129,16,261,1,1,261,20,260,257,0,0,261]

theorem envBound23787 : H12AffineFastState.Bounded env23787 := by
  intro p hp
  have h : env23787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23786_23787 : H12AffineEnvironment.transform 8 261 env23786 = env23787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env23786 == env23787) = true)

def env23788 : List Nat := [2,4,8,16,1,17,8,256,261,272,261,0,9,1,1,263,0,261,273,0,0,260,17,3,9,16,261,1,1,261,20,260,257,0,0,261]

theorem envBound23788 : H12AffineFastState.Bounded env23788 := by
  intro p hp
  have h : env23788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23787_23788 : H12AffineEnvironment.transform 6 8 env23787 = env23788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23787 == env23788) = true)

def env23789 : List Nat := [2,4,8,16,1,17,9,256,261,272,261,0,9,1,1,262,0,261,273,0,0,260,17,2,8,16,261,1,1,261,20,260,257,0,0,261]

theorem envBound23789 : H12AffineFastState.Bounded env23789 := by
  intro p hp
  have h : env23789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23787_23789 : H12AffineEnvironment.transform 6 9 env23787 = env23789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23787 == env23789) = true)

theorem identity23789 : scanCanonicalize (H12AffineFastState.compose env23789 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound23789 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env23790 : List Nat := [2,4,8,16,1,17,9,5,0,21,0,0,9,1,1,3,0,0,20,0,0,1,17,2,8,16,0,1,1,0,20,1,4,0,0,0]

theorem envBound23790 : H12AffineFastState.Bounded env23790 := by
  intro p hp
  have h : env23790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23789_23790 : H12AffineEnvironment.transform 7 5 env23789 = env23790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env23789 == env23790) = true)

def leafEnv23790 : List Nat := [2,4,8,16,1,17,9,5,0,21,0,0,9,1,1,3,0,0,20,0,0,1,17,2,21,8,1,16,0,1,1,0,20,1,4,0,5,3,0,0,0,1,1]

def active23790 : List Nat := [0,1,2,3]

def tree23790 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23790 : H12WitnessSearch.Good tree23790 := H12GlobalWitnessIndex.good

theorem leafIdentity23790 : H12AffineFastState.composeSystem env23790 rootObs = leafEnv23790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23790 rootObs == leafEnv23790) = true)

theorem terminalChecked23790 : H12PackedTerminal.terminalCheckFast leafEnv23790 active23790 tree23790 = true := by decide +kernel

def env23791 : List Nat := [2,4,8,16,32,64,128,256,512,272,513,81,41,1,1,399,81,512,273,0,81,545,17,139,161,65,293,1,1,292,20,372,257,884,81,512]

theorem envBound23791 : H12AffineFastState.Bounded env23791 := by
  intro p hp
  have h : env23791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23774_23791 : H12AffineEnvironment.transform 10 513 env23774 = env23791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env23774 == env23791) = true)

theorem identity23791 : scanCanonicalize (H12AffineFastState.compose env23791 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound23791 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23792 : List Nat := [2,4,8,16,32,64,128,256,293,272,292,81,41,1,1,399,81,293,273,0,81,260,17,139,161,65,293,1,1,292,20,372,257,81,81,293]

theorem envBound23792 : H12AffineFastState.Bounded env23792 := by
  intro p hp
  have h : env23792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23791_23792 : H12AffineEnvironment.transform 8 293 env23791 = env23792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env23791 == env23792) = true)

def env23793 : List Nat := [2,4,8,16,32,16,128,256,293,272,292,1,41,1,1,399,1,293,273,0,1,260,17,139,161,17,293,1,1,292,20,292,257,1,1,293]

theorem envBound23793 : H12AffineFastState.Bounded env23793 := by
  intro p hp
  have h : env23793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23792_23793 : H12AffineEnvironment.transform 5 16 env23792 = env23793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23792 == env23793) = true)

theorem identity23793 : scanCanonicalize (H12AffineFastState.compose env23793 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound23793 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23794 : List Nat := [2,4,8,16,32,16,41,256,293,272,292,1,41,1,1,294,1,293,273,0,1,260,17,34,8,17,293,1,1,292,20,292,257,1,1,293]

theorem envBound23794 : H12AffineFastState.Bounded env23794 := by
  intro p hp
  have h : env23794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23793_23794 : H12AffineEnvironment.transform 6 41 env23793 = env23794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env23793 == env23794) = true)

theorem identity23794 : scanCanonicalize (H12AffineFastState.compose env23794 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound23794 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env23795 : List Nat := [2,4,8,16,32,16,41,5,32,21,33,1,41,1,1,35,1,32,20,0,1,1,17,34,8,17,32,1,1,33,20,33,4,1,1,32]

theorem envBound23795 : H12AffineFastState.Bounded env23795 := by
  intro p hp
  have h : env23795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23794_23795 : H12AffineEnvironment.transform 7 5 env23794 = env23795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env23794 == env23795) = true)

theorem identity23795 : scanCanonicalize (H12AffineFastState.compose env23795 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound23795 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23796 : List Nat := [2,4,8,16,1,16,8,5,1,21,0,1,8,1,1,2,1,1,20,0,1,1,17,3,8,17,1,1,1,0,20,0,4,1,1,1]

theorem envBound23796 : H12AffineFastState.Bounded env23796 := by
  intro p hp
  have h : env23796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23795_23796 : H12AffineEnvironment.transform 4 1 env23795 = env23796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env23795 == env23796) = true)

def leafEnv23796 : List Nat := [2,4,8,16,1,16,8,5,1,21,0,1,8,1,1,2,1,1,20,0,1,1,17,3,21,8,1,17,1,1,1,0,20,0,4,1,5,3,1,1,0,1,1]

def active23796 : List Nat := [0,1,2,3]

def tree23796 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23796 : H12WitnessSearch.Good tree23796 := H12GlobalWitnessIndex.good

theorem leafIdentity23796 : H12AffineFastState.composeSystem env23796 rootObs = leafEnv23796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23796 rootObs == leafEnv23796) = true)

theorem terminalChecked23796 : H12PackedTerminal.terminalCheckFast leafEnv23796 active23796 tree23796 = true := by decide +kernel

def env23797 : List Nat := [2,4,8,16,32,17,128,256,293,272,292,0,41,1,1,399,0,293,273,0,0,260,17,139,161,16,293,1,1,292,20,293,257,0,0,293]

theorem envBound23797 : H12AffineFastState.Bounded env23797 := by
  intro p hp
  have h : env23797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23792_23797 : H12AffineEnvironment.transform 5 17 env23792 = env23797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23792 == env23797) = true)

theorem identity23797 : scanCanonicalize (H12AffineFastState.compose env23797 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound23797 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23798 : List Nat := [2,4,8,16,0,17,128,256,261,272,260,0,9,1,1,399,0,261,273,0,0,260,17,139,129,16,261,1,1,260,20,261,257,0,0,261]

theorem envBound23798 : H12AffineFastState.Bounded env23798 := by
  intro p hp
  have h : env23798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23797_23798 : H12AffineEnvironment.transform 4 0 env23797 = env23798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23797 == env23798) = true)

theorem identity23798 : scanCanonicalize (H12AffineFastState.compose env23798 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound23798 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23799 : List Nat := [2,4,8,16,0,17,128,4,1,20,0,0,9,1,1,139,0,1,21,0,0,0,17,139,129,16,1,1,1,0,20,1,5,0,0,1]

theorem envBound23799 : H12AffineFastState.Bounded env23799 := by
  intro p hp
  have h : env23799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23798_23799 : H12AffineEnvironment.transform 7 4 env23798 = env23799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env23798 == env23799) = true)

def env23800 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,80,8192,0,1,65536,80,512,272,0,80,8712,17,65796,8328,65,134217728,0,0,1073741824,21,4294967296,257,4295041958,134226268,512]

theorem envBound23800 : H12AffineFastState.Bounded env23800 := by
  intro p hp
  have h : env23800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23768_23800 : H12AffineEnvironment.transform 9 273 env23768 = env23800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env23768 == env23800) = true)

theorem identity23800 : scanCanonicalize (H12AffineFastState.compose env23800 (packedSelected [7] rootPS)) = affineNative (2^(31+1) ^^^ 65787) := by decide +kernel

theorem selectedBound23800 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env23801 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,80,8192,0,1,65536,80,512,272,0,80,8712,17,65796,8328,65,134217728,0,0,1073741824,21,65787,257,9053,134226268,512]

theorem envBound23801 : H12AffineFastState.Bounded env23801 := by
  intro p hp
  have h : env23801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23800_23801 : H12AffineEnvironment.transform 31 65787 env23800 = env23801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 65787 env23800 == env23801) = true)

def env23802 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,0,8192,0,1,65536,0,512,272,0,0,8712,17,65796,8328,17,134217728,0,0,1073741824,21,65707,257,8973,134226188,512]

theorem envBound23802 : H12AffineFastState.Bounded env23802 := by
  intro p hp
  have h : env23802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23801_23802 : H12AffineEnvironment.transform 5 16 env23801 = env23802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23801 == env23802) = true)

theorem identity23802 : scanCanonicalize (H12AffineFastState.compose env23802 (packedSelected [1] rootPS)) = affineNative (2^(26+1) ^^^ 396) := by decide +kernel

theorem selectedBound23802 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23803 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,0,8192,0,1,65536,0,512,272,0,0,8712,17,65796,8328,17,396,0,0,1073741824,21,65707,257,8973,8320,512]

theorem envBound23803 : H12AffineFastState.Bounded env23803 := by
  intro p hp
  have h : env23803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23802_23803 : H12AffineEnvironment.transform 26 396 env23802 = env23803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 396 env23802 == env23803) = true)

theorem identity23803 : scanCanonicalize (H12AffineFastState.compose env23803 (packedSelected [3,5] rootPS)) = affineNative (2^(12+1) ^^^ 128) := by decide +kernel

theorem selectedBound23803 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env23804 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,0,128,0,1,65536,0,512,272,0,0,648,17,65796,8,17,396,0,0,1073741824,21,65707,257,909,0,512]

theorem envBound23804 : H12AffineFastState.Bounded env23804 := by
  intro p hp
  have h : env23804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23803_23804 : H12AffineEnvironment.transform 12 128 env23803 = env23804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 128 env23803 == env23804) = true)

theorem identity23804 : scanCanonicalize (H12AffineFastState.compose env23804 (packedSelected [13] rootPS)) = affineNative (2^(29+1) ^^^ 68099) := by decide +kernel

theorem selectedBound23804 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env23805 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,0,128,0,1,65536,0,512,272,0,0,648,17,65796,8,17,396,0,0,68099,21,65707,257,909,0,512]

theorem envBound23805 : H12AffineFastState.Bounded env23805 := by
  intro p hp
  have h : env23805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23804_23805 : H12AffineEnvironment.transform 29 68099 env23804 = env23805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 68099 env23804 == env23805) = true)

def env23806 : List Nat := [2,4,8,16,32,16,128,256,136,273,2048,0,128,0,1,65536,0,136,272,0,0,0,17,65796,8,17,396,0,0,67723,21,65707,257,261,0,136]

theorem envBound23806 : H12AffineFastState.Bounded env23806 := by
  intro p hp
  have h : env23806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23805_23806 : H12AffineEnvironment.transform 8 136 env23805 = env23806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env23805 == env23806) = true)

theorem identity23806 : scanCanonicalize (H12AffineFastState.compose env23806 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound23806 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env23807 : List Nat := [2,4,8,16,32,16,128,4,136,21,2048,0,128,0,1,65536,0,136,20,0,0,0,17,65536,8,17,136,0,0,67723,21,65707,5,1,0,136]

theorem envBound23807 : H12AffineFastState.Bounded env23807 := by
  intro p hp
  have h : env23807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23806_23807 : H12AffineEnvironment.transform 7 4 env23806 = env23807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env23806 == env23807) = true)

theorem identity23807 : scanCanonicalize (H12AffineFastState.compose env23807 (packedSelected [2,4,9] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound23807 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env23808 : List Nat := [2,4,8,16,32,16,128,4,136,21,2048,0,128,0,1,35,0,136,20,0,0,0,17,35,8,17,136,0,0,2216,21,136,5,1,0,136]

theorem envBound23808 : H12AffineFastState.Bounded env23808 := by
  intro p hp
  have h : env23808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23807_23808 : H12AffineEnvironment.transform 15 35 env23807 = env23808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env23807 == env23808) = true)

theorem identity23808 : scanCanonicalize (H12AffineFastState.compose env23808 (packedSelected [0,2,4,11] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound23808 : packedSelected [0,2,4,11] rootPS < 2^1333 := by decide +kernel

def env23809 : List Nat := [2,4,8,16,32,16,128,4,136,21,136,0,128,0,1,35,0,136,20,0,0,0,17,35,8,17,136,0,0,32,21,136,5,1,0,136]

theorem envBound23809 : H12AffineFastState.Bounded env23809 := by
  intro p hp
  have h : env23809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23808_23809 : H12AffineEnvironment.transform 10 136 env23808 = env23809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env23808 == env23809) = true)

theorem identity23809 : scanCanonicalize (H12AffineFastState.compose env23809 (packedSelected [18] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound23809 : packedSelected [18] rootPS < 2^1333 := by decide +kernel

def env23810 : List Nat := [2,4,8,16,32,16,40,4,32,21,32,0,40,0,1,35,0,32,20,0,0,0,17,35,8,17,32,0,0,32,21,32,5,1,0,32]

theorem envBound23810 : H12AffineFastState.Bounded env23810 := by
  intro p hp
  have h : env23810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23809_23810 : H12AffineEnvironment.transform 6 40 env23809 = env23810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env23809 == env23810) = true)

def leafEnv23810 : List Nat := [2,4,8,16,32,16,40,4,32,21,32,0,40,0,1,35,0,32,20,0,0,0,17,35,20,8,1,17,32,0,0,32,21,32,5,1,5,2,0,32,0,0,1]

def active23810 : List Nat := [0,1,2,3,4]

def tree23810 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23810 : H12WitnessSearch.Good tree23810 := H12GlobalWitnessIndex.good

theorem leafIdentity23810 : H12AffineFastState.composeSystem env23810 rootObs = leafEnv23810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23810 rootObs == leafEnv23810) = true)

theorem terminalChecked23810 : H12PackedTerminal.terminalCheckFast leafEnv23810 active23810 tree23810 = true := by decide +kernel

def env23811 : List Nat := [2,4,8,16,32,16,128,256,137,273,2048,0,128,0,1,65536,0,137,272,0,0,1,17,65796,8,17,396,0,0,67722,21,65707,257,260,0,137]

theorem envBound23811 : H12AffineFastState.Bounded env23811 := by
  intro p hp
  have h : env23811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23805_23811 : H12AffineEnvironment.transform 8 137 env23805 = env23811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env23805 == env23811) = true)

theorem identity23811 : scanCanonicalize (H12AffineFastState.compose env23811 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound23811 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env23812 : List Nat := [2,4,8,16,32,16,8,256,1,273,2048,0,8,0,1,65536,0,1,272,0,0,1,17,65796,8,17,260,0,0,67586,21,65571,257,260,0,1]

theorem envBound23812 : H12AffineFastState.Bounded env23812 := by
  intro p hp
  have h : env23812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23811_23812 : H12AffineEnvironment.transform 6 8 env23811 = env23812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23811 == env23812) = true)

theorem identity23812 : scanCanonicalize (H12AffineFastState.compose env23812 (packedSelected [23] rootPS)) = affineNative (2^(15+1) ^^^ 2342) := by decide +kernel

theorem selectedBound23812 : packedSelected [23] rootPS < 2^1333 := by decide +kernel

def env23813 : List Nat := [2,4,8,16,32,16,8,256,1,273,2048,0,8,0,1,2342,0,1,272,0,0,1,17,2082,8,17,260,0,0,292,21,2309,257,260,0,1]

theorem envBound23813 : H12AffineFastState.Bounded env23813 := by
  intro p hp
  have h : env23813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23812_23813 : H12AffineEnvironment.transform 15 2342 env23812 = env23813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2342 env23812 == env23813) = true)

theorem identity23813 : scanCanonicalize (H12AffineFastState.compose env23813 (packedSelected [18] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound23813 : packedSelected [18] rootPS < 2^1333 := by decide +kernel

def env23814 : List Nat := [2,4,8,16,32,16,8,256,1,273,33,0,8,0,1,263,0,1,272,0,0,1,17,3,8,17,260,0,0,292,21,292,257,260,0,1]

theorem envBound23814 : H12AffineFastState.Bounded env23814 := by
  intro p hp
  have h : env23814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23813_23814 : H12AffineEnvironment.transform 10 33 env23813 = env23814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env23813 == env23814) = true)

def env23815 : List Nat := [2,4,8,16,0,16,8,256,1,273,1,0,8,0,1,263,0,1,272,0,0,1,17,3,8,17,260,0,0,260,21,260,257,260,0,1]

theorem envBound23815 : H12AffineFastState.Bounded env23815 := by
  intro p hp
  have h : env23815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23814_23815 : H12AffineEnvironment.transform 4 0 env23814 = env23815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23814 == env23815) = true)

def leafEnv23815 : List Nat := [2,4,8,16,0,16,8,256,1,273,1,0,8,0,1,263,0,1,272,0,0,1,17,3,20,8,1,17,260,0,0,260,21,260,257,260,5,262,0,1,0,0,1]

def active23815 : List Nat := [0,1,2,3,7]

def tree23815 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23815 : H12WitnessSearch.Good tree23815 := H12GlobalWitnessIndex.good

theorem leafIdentity23815 : H12AffineFastState.composeSystem env23815 rootObs = leafEnv23815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23815 rootObs == leafEnv23815) = true)

theorem terminalChecked23815 : H12PackedTerminal.terminalCheckFast leafEnv23815 active23815 tree23815 = true := by decide +kernel

def env23816 : List Nat := [2,4,8,16,1,16,8,256,1,273,0,0,8,0,1,263,0,1,272,0,0,1,17,3,8,17,260,0,0,261,21,261,257,260,0,1]

theorem envBound23816 : H12AffineFastState.Bounded env23816 := by
  intro p hp
  have h : env23816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23814_23816 : H12AffineEnvironment.transform 4 1 env23814 = env23816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env23814 == env23816) = true)

theorem identity23816 : scanCanonicalize (H12AffineFastState.compose env23816 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound23816 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env23817 : List Nat := [2,4,8,16,1,16,8,5,1,20,0,0,8,0,1,2,0,1,21,0,0,1,17,3,8,17,1,0,0,0,21,0,4,1,0,1]

theorem envBound23817 : H12AffineFastState.Bounded env23817 := by
  intro p hp
  have h : env23817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23816_23817 : H12AffineEnvironment.transform 7 5 env23816 = env23817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env23816 == env23817) = true)

def leafEnv23817 : List Nat := [2,4,8,16,1,16,8,5,1,20,0,0,8,0,1,2,0,1,21,0,0,1,17,3,20,8,1,17,1,0,0,0,21,0,4,1,5,3,0,1,0,0,1]

def active23817 : List Nat := [0,1,2,3]

def tree23817 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood23817 : H12WitnessSearch.Good tree23817 := H12GlobalWitnessIndex.good

theorem leafIdentity23817 : H12AffineFastState.composeSystem env23817 rootObs = leafEnv23817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env23817 rootObs == leafEnv23817) = true)

theorem terminalChecked23817 : H12PackedTerminal.terminalCheckFast leafEnv23817 active23817 tree23817 = true := by decide +kernel

def env23818 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,8192,0,1,65536,1,512,272,0,1,8712,17,65796,8328,16,134217728,0,0,1073741824,21,65706,257,8972,134226189,512]

theorem envBound23818 : H12AffineFastState.Bounded env23818 := by
  intro p hp
  have h : env23818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23801_23818 : H12AffineEnvironment.transform 5 17 env23801 = env23818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23801 == env23818) = true)

theorem identity23818 : scanCanonicalize (H12AffineFastState.compose env23818 (packedSelected [1] rootPS)) = affineNative (2^(29+1) ^^^ 134283694) := by decide +kernel

theorem selectedBound23818 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env23819 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,8192,0,1,65536,1,512,272,0,1,8712,17,65796,8328,16,134217728,0,0,134283694,21,65706,257,8972,134226189,512]

theorem envBound23819 : H12AffineFastState.Bounded env23819 := by
  intro p hp
  have h : env23819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23818_23819 : H12AffineEnvironment.transform 29 134283694 env23818 = env23819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 134283694 env23818 == env23819) = true)

theorem identity23819 : scanCanonicalize (H12AffineFastState.compose env23819 (packedSelected [3,5] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound23819 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env23820 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,1,9,0,1,65536,1,512,272,0,1,513,17,65796,129,16,134217728,0,0,134283694,21,65706,257,773,134217988,512]

theorem envBound23820 : H12AffineFastState.Bounded env23820 := by
  intro p hp
  have h : env23820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23819_23820 : H12AffineEnvironment.transform 12 9 env23819 = env23820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env23819 == env23820) = true)

theorem identity23820 : scanCanonicalize (H12AffineFastState.compose env23820 (packedSelected [12] rootPS)) = affineNative (2^(26+1) ^^^ 65674) := by decide +kernel

end H12CloudChart2