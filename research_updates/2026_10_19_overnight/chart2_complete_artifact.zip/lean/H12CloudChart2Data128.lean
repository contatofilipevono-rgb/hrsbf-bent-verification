import H12CloudChart2Data127

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity31687 : scanCanonicalize (H12AffineFastState.compose env31687 (packedSelected [0,2,4] rootPS)) = affineNative (2^(5+1) ^^^ 23) := by decide +kernel

theorem selectedBound31687 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env31688 : List Nat := [2,4,3,16,16,23,18,3,23,5,7,6,4,23,6,21,23,6,19,7,6,7,22,20,2,7,23,16,22,0,3,0,2,6,17,1]

theorem envBound31688 : H12AffineFastState.Bounded env31688 := by
  intro p hp
  have h : env31688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31687_31688 : H12AffineEnvironment.transform 5 23 env31687 = env31688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 23 env31687 == env31688) = true)

def env31689 : List Nat := [2,4,8,16,32,64,128,101,512,52,2048,544,553,64,529,612,22,741,516,528,544,649,23,613,144,631,74,70,65,2678,549,551,100,81,17,48]

theorem envBound31689 : H12AffineFastState.Bounded env31689 := by
  intro p hp
  have h : env31689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31681_31689 : H12AffineEnvironment.transform 7 101 env31681 = env31689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 101 env31681 == env31689) = true)

theorem identity31689 : scanCanonicalize (H12AffineFastState.compose env31689 (packedSelected [0,4,5,9,12,16,17,21,27,38] rootPS)) = affineNative (2^(8+1) ^^^ 185) := by decide +kernel

theorem selectedBound31689 : packedSelected [0,4,5,9,12,16,17,21,27,38] rootPS < 2^1333 := by decide +kernel

def env31690 : List Nat := [2,4,8,16,32,64,128,101,185,52,2048,153,144,64,168,221,22,92,189,169,153,48,23,220,144,206,74,70,65,2255,156,158,100,81,17,48]

theorem envBound31690 : H12AffineFastState.Bounded env31690 := by
  intro p hp
  have h : env31690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31689_31690 : H12AffineEnvironment.transform 8 185 env31689 = env31690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 185 env31689 == env31690) = true)

theorem identity31690 : scanCanonicalize (H12AffineFastState.compose env31690 (packedSelected [2,3,10,11,13,18] rootPS)) = affineNative (2^(10+1) ^^^ 29) := by decide +kernel

theorem selectedBound31690 : packedSelected [2,3,10,11,13,18] rootPS < 2^1333 := by decide +kernel

def env31691 : List Nat := [2,4,8,16,32,64,128,101,185,52,29,153,144,64,168,221,22,92,189,169,153,48,23,220,144,206,74,70,65,210,156,158,100,81,17,48]

theorem envBound31691 : H12AffineFastState.Bounded env31691 := by
  intro p hp
  have h : env31691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31690_31691 : H12AffineEnvironment.transform 10 29 env31690 = env31691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 29 env31690 == env31691) = true)

theorem identity31691 : scanCanonicalize (H12AffineFastState.compose env31691 (packedSelected [0,1,3,7,12,15,16] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound31691 : packedSelected [0,1,3,7,12,15,16] rootPS < 2^1333 := by decide +kernel

def env31692 : List Nat := [2,4,8,0,32,64,128,101,169,36,13,137,128,64,168,205,6,76,173,169,137,32,7,204,128,206,74,70,65,194,140,142,100,65,1,32]

theorem envBound31692 : H12AffineFastState.Bounded env31692 := by
  intro p hp
  have h : env31692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31691_31692 : H12AffineEnvironment.transform 3 0 env31691 = env31692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env31691 == env31692) = true)

theorem identity31692 : scanCanonicalize (H12AffineFastState.compose env31692 (packedSelected [2,3,4,7] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound31692 : packedSelected [2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env31693 : List Nat := [2,4,3,0,32,64,128,101,162,36,6,130,128,64,163,198,6,71,166,162,130,32,7,199,128,197,65,70,65,194,135,133,100,65,1,32]

theorem envBound31693 : H12AffineFastState.Bounded env31693 := by
  intro p hp
  have h : env31693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31692_31693 : H12AffineEnvironment.transform 2 3 env31692 = env31693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env31692 == env31693) = true)

theorem identity31693 : scanCanonicalize (H12AffineFastState.compose env31693 (packedSelected [2,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound31693 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env31694 : List Nat := [2,4,3,0,32,64,5,101,39,36,6,7,5,64,38,67,6,71,35,39,7,32,7,66,5,64,65,70,65,71,2,0,100,65,1,32]

theorem envBound31694 : H12AffineFastState.Bounded env31694 := by
  intro p hp
  have h : env31694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31693_31694 : H12AffineEnvironment.transform 6 5 env31693 = env31694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env31693 == env31694) = true)

theorem identity31694 : scanCanonicalize (H12AffineFastState.compose env31694 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound31694 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env31695 : List Nat := [2,4,3,0,1,64,5,68,6,5,6,7,5,64,7,67,6,71,2,6,7,1,7,66,5,64,65,70,65,71,2,0,69,65,1,1]

theorem envBound31695 : H12AffineFastState.Bounded env31695 := by
  intro p hp
  have h : env31695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31694_31695 : H12AffineEnvironment.transform 4 1 env31694 = env31695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env31694 == env31695) = true)

theorem identity31695 : scanCanonicalize (H12AffineFastState.compose env31695 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound31695 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31696 : List Nat := [2,4,3,0,1,0,5,4,6,5,6,7,5,0,7,3,6,7,2,6,7,1,7,2,5,0,1,6,1,7,2,0,5,1,1,1]

theorem envBound31696 : H12AffineFastState.Bounded env31696 := by
  intro p hp
  have h : env31696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31695_31696 : H12AffineEnvironment.transform 5 0 env31695 = env31696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env31695 == env31696) = true)

def env31697 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1557,845,1297,528,65536,67362,65665,1876,529,1557,648,66162,66896,144,65910,1150,67442,1296,67602,833,65830,257,1280,1344,340]

theorem envBound31697 : H12AffineFastState.Bounded env31697 := by
  intro p hp
  have h : env31697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31658_31697 : H12AffineEnvironment.transform 11 1557 env31658 = env31697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env31658 == env31697) = true)

def env31698 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,837,845,65,528,65536,66162,65665,516,529,837,648,66162,65536,144,65910,302,66082,64,67602,833,65830,257,80,16,340]

theorem envBound31698 : H12AffineFastState.Bounded env31698 := by
  intro p hp
  have h : env31698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31697_31698 : H12AffineEnvironment.transform 9 336 env31697 = env31698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env31697 == env31698) = true)

theorem identity31698 : scanCanonicalize (H12AffineFastState.compose env31698 (packedSelected [1,8,28] rootPS)) = affineNative (2^(8+1) ^^^ 118) := by decide +kernel

theorem selectedBound31698 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env31699 : List Nat := [2,4,8,16,32,64,128,256,118,336,2048,307,315,65,102,65536,65540,65665,114,103,307,254,65540,65536,144,65910,302,65620,64,67602,311,65830,257,80,16,340]

theorem envBound31699 : H12AffineFastState.Bounded env31699 := by
  intro p hp
  have h : env31699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31698_31699 : H12AffineEnvironment.transform 8 118 env31698 = env31699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 118 env31698 == env31699) = true)

def env31700 : List Nat := [2,4,8,16,32,64,128,256,118,336,2048,307,315,65,102,20,16,149,114,103,307,254,16,20,144,354,302,64,64,2054,311,306,257,80,16,340]

theorem envBound31700 : H12AffineFastState.Bounded env31700 := by
  intro p hp
  have h : env31700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31699_31700 : H12AffineEnvironment.transform 15 20 env31699 = env31700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 20 env31699 == env31700) = true)

theorem identity31700 : scanCanonicalize (H12AffineFastState.compose env31700 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 50) := by decide +kernel

theorem selectedBound31700 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env31701 : List Nat := [2,4,8,16,32,64,128,50,118,98,2048,1,9,65,102,20,16,149,114,103,1,254,16,20,144,80,28,64,64,2054,5,0,51,80,16,102]

theorem envBound31701 : H12AffineFastState.Bounded env31701 := by
  intro p hp
  have h : env31701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31700_31701 : H12AffineEnvironment.transform 7 50 env31700 = env31701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 50 env31700 == env31701) = true)

theorem identity31701 : scanCanonicalize (H12AffineFastState.compose env31701 (packedSelected [1,2,3,4,5,8,9,11,13,15,16,17,18] rootPS)) = affineNative (2^(6+1) ^^^ 53) := by decide +kernel

theorem selectedBound31701 : packedSelected [1,2,3,4,5,8,9,11,13,15,16,17,18] rootPS < 2^1333 := by decide +kernel

def env31702 : List Nat := [2,4,8,16,32,64,53,50,118,98,2048,1,9,65,102,20,16,32,114,103,1,75,16,20,37,80,28,64,64,2054,5,0,51,80,16,102]

theorem envBound31702 : H12AffineFastState.Bounded env31702 := by
  intro p hp
  have h : env31702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31701_31702 : H12AffineEnvironment.transform 6 53 env31701 = env31702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 53 env31701 == env31702) = true)

theorem identity31702 : scanCanonicalize (H12AffineFastState.compose env31702 (packedSelected [1,4,9,12,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound31702 : packedSelected [1,4,9,12,15,16] rootPS < 2^1333 := by decide +kernel

def env31703 : List Nat := [2,4,8,16,32,64,53,50,118,98,49,1,9,65,102,20,16,32,114,103,1,75,16,20,37,80,28,64,64,55,5,0,51,80,16,102]

theorem envBound31703 : H12AffineFastState.Bounded env31703 := by
  intro p hp
  have h : env31703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31702_31703 : H12AffineEnvironment.transform 10 49 env31702 = env31703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env31702 == env31703) = true)

theorem identity31703 : scanCanonicalize (H12AffineFastState.compose env31703 (packedSelected [0,1,3,5,9,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound31703 : packedSelected [0,1,3,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env31704 : List Nat := [2,4,8,16,32,0,53,50,54,34,49,1,9,1,38,20,16,32,50,39,1,11,16,20,37,16,28,0,0,55,5,0,51,16,16,38]

theorem envBound31704 : H12AffineFastState.Bounded env31704 := by
  intro p hp
  have h : env31704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31703_31704 : H12AffineEnvironment.transform 5 0 env31703 = env31704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env31703 == env31704) = true)

theorem identity31704 : scanCanonicalize (H12AffineFastState.compose env31704 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound31704 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env31705 : List Nat := [2,4,8,16,10,0,31,24,28,8,27,1,9,1,12,20,16,10,24,13,1,11,16,20,15,16,28,0,0,29,5,0,25,16,16,12]

theorem envBound31705 : H12AffineFastState.Bounded env31705 := by
  intro p hp
  have h : env31705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31704_31705 : H12AffineEnvironment.transform 4 10 env31704 = env31705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env31704 == env31705) = true)

theorem identity31705 : scanCanonicalize (H12AffineFastState.compose env31705 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound31705 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31706 : List Nat := [2,4,3,16,1,0,20,19,23,3,16,1,2,1,7,20,16,1,19,6,1,0,16,20,4,16,23,0,0,22,5,0,18,16,16,7]

theorem envBound31706 : H12AffineFastState.Bounded env31706 := by
  intro p hp
  have h : env31706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31705_31706 : H12AffineEnvironment.transform 2 3 env31705 = env31706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env31705 == env31706) = true)

theorem identity31706 : scanCanonicalize (H12AffineFastState.compose env31706 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound31706 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env31707 : List Nat := [2,4,3,7,1,0,3,4,0,3,7,1,2,1,7,3,7,1,4,6,1,0,7,3,4,7,0,0,0,1,5,0,5,7,7,7]

theorem envBound31707 : H12AffineFastState.Bounded env31707 := by
  intro p hp
  have h : env31707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31706_31707 : H12AffineEnvironment.transform 3 7 env31706 = env31707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env31706 == env31707) = true)

theorem identity31707 : scanCanonicalize (H12AffineFastState.compose env31707 (packedSelected [0,4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound31707 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env31708 : List Nat := [2,2,3,1,1,0,3,2,0,3,1,1,2,1,1,3,1,1,2,0,1,0,1,3,2,1,0,0,0,1,3,0,3,1,1,1]

theorem envBound31708 : H12AffineFastState.Bounded env31708 := by
  intro p hp
  have h : env31708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31707_31708 : H12AffineEnvironment.transform 1 2 env31707 = env31708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env31707 == env31708) = true)

theorem identity31708 : scanCanonicalize (H12AffineFastState.compose env31708 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound31708 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31709 : List Nat := [0,0,1,1,1,0,1,0,0,1,1,1,0,1,1,1,1,1,0,0,1,0,1,1,0,1,0,0,0,1,1,0,1,1,1,1]

theorem envBound31709 : H12AffineFastState.Bounded env31709 := by
  intro p hp
  have h : env31709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31708_31709 : H12AffineEnvironment.transform 0 0 env31708 = env31709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env31708 == env31709) = true)

def env31710 : List Nat := [2,4,8,16,32,64,128,256,118,336,2048,307,315,65,102,21,17,148,114,103,307,254,17,21,144,355,302,65,64,2055,311,307,257,80,16,340]

theorem envBound31710 : H12AffineFastState.Bounded env31710 := by
  intro p hp
  have h : env31710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31699_31710 : H12AffineEnvironment.transform 15 21 env31699 = env31710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21 env31699 == env31710) = true)

theorem identity31710 : scanCanonicalize (H12AffineFastState.compose env31710 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound31710 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env31711 : List Nat := [2,4,8,16,32,64,128,85,118,5,2048,102,110,65,102,21,17,148,114,103,102,254,17,21,144,54,123,65,64,2055,98,102,84,80,16,1]

theorem envBound31711 : H12AffineFastState.Bounded env31711 := by
  intro p hp
  have h : env31711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31710_31711 : H12AffineEnvironment.transform 7 85 env31710 = env31711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env31710 == env31711) = true)

theorem identity31711 : scanCanonicalize (H12AffineFastState.compose env31711 (packedSelected [0,1,3,4,7,8,9,10,16,17,19,20] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound31711 : packedSelected [0,1,3,4,7,8,9,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env31712 : List Nat := [2,4,8,16,32,64,121,85,118,5,2048,102,110,65,102,21,17,109,114,103,102,7,17,21,105,54,123,65,64,2055,98,102,84,80,16,1]

theorem envBound31712 : H12AffineFastState.Bounded env31712 := by
  intro p hp
  have h : env31712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31711_31712 : H12AffineEnvironment.transform 6 121 env31711 = env31712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env31711 == env31712) = true)

theorem identity31712 : scanCanonicalize (H12AffineFastState.compose env31712 (packedSelected [2,5,8,17] rootPS)) = affineNative (2^(5+1) ^^^ 55) := by decide +kernel

theorem selectedBound31712 : packedSelected [2,5,8,17] rootPS < 2^1333 := by decide +kernel

def env31713 : List Nat := [2,4,8,16,32,55,14,34,1,5,2048,17,25,54,17,21,17,26,5,16,17,7,17,21,30,54,12,54,55,2055,21,17,35,39,16,1]

theorem envBound31713 : H12AffineFastState.Bounded env31713 := by
  intro p hp
  have h : env31713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31712_31713 : H12AffineEnvironment.transform 5 55 env31712 = env31713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 55 env31712 == env31713) = true)

theorem identity31713 : scanCanonicalize (H12AffineFastState.compose env31713 (packedSelected [2,8] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound31713 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env31714 : List Nat := [2,2,8,16,32,49,8,34,1,3,2048,17,25,48,17,19,17,26,3,16,17,1,17,19,24,48,10,48,49,2049,19,17,35,33,16,1]

theorem envBound31714 : H12AffineFastState.Bounded env31714 := by
  intro p hp
  have h : env31714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31713_31714 : H12AffineEnvironment.transform 1 2 env31713 = env31714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env31713 == env31714) = true)

theorem identity31714 : scanCanonicalize (H12AffineFastState.compose env31714 (packedSelected [0,2] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound31714 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env31715 : List Nat := [2,2,8,16,32,49,8,34,1,3,26,17,25,48,17,19,17,26,3,16,17,1,17,19,24,48,10,48,49,27,19,17,35,33,16,1]

theorem envBound31715 : H12AffineFastState.Bounded env31715 := by
  intro p hp
  have h : env31715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31714_31715 : H12AffineEnvironment.transform 10 26 env31714 = env31715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env31714 == env31715) = true)

theorem identity31715 : scanCanonicalize (H12AffineFastState.compose env31715 (packedSelected [0,1,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound31715 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env31716 : List Nat := [2,2,3,16,32,49,3,34,1,3,17,17,18,48,17,19,17,17,3,16,17,1,17,19,19,48,1,48,49,16,19,17,35,33,16,1]

theorem envBound31716 : H12AffineFastState.Bounded env31716 := by
  intro p hp
  have h : env31716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31715_31716 : H12AffineEnvironment.transform 2 3 env31715 = env31716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env31715 == env31716) = true)

theorem identity31716 : scanCanonicalize (H12AffineFastState.compose env31716 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound31716 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env31717 : List Nat := [2,2,3,16,1,16,3,3,1,3,17,17,18,17,17,19,17,17,3,16,17,1,17,19,19,17,1,17,16,16,19,17,2,0,16,1]

theorem envBound31717 : H12AffineFastState.Bounded env31717 := by
  intro p hp
  have h : env31717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31716_31717 : H12AffineEnvironment.transform 4 1 env31716 = env31717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env31716 == env31717) = true)

theorem identity31717 : scanCanonicalize (H12AffineFastState.compose env31717 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound31717 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31718 : List Nat := [2,2,3,0,1,0,3,3,1,3,1,1,2,1,1,3,1,1,3,0,1,1,1,3,3,1,1,1,0,0,3,1,2,0,0,1]

theorem envBound31718 : H12AffineFastState.Bounded env31718 := by
  intro p hp
  have h : env31718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31717_31718 : H12AffineEnvironment.transform 3 0 env31717 = env31718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env31717 == env31718) = true)

def env31719 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,836,845,64,528,65536,66163,65665,517,529,836,648,66162,65537,144,65910,303,66083,65,67602,833,65830,257,81,17,340]

theorem envBound31719 : H12AffineFastState.Bounded env31719 := by
  intro p hp
  have h : env31719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31697_31719 : H12AffineEnvironment.transform 9 337 env31697 = env31719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env31697 == env31719) = true)

theorem identity31719 : scanCanonicalize (H12AffineFastState.compose env31719 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 98) := by decide +kernel

theorem selectedBound31719 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env31720 : List Nat := [2,4,8,16,32,64,128,98,512,51,2048,550,559,64,528,65536,66163,65665,517,529,550,648,66162,65537,144,65556,77,66083,65,67602,547,65604,99,81,17,54]

theorem envBound31720 : H12AffineFastState.Bounded env31720 := by
  intro p hp
  have h : env31720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31719_31720 : H12AffineEnvironment.transform 7 98 env31719 = env31720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 98 env31719 == env31720) = true)

def env31721 : List Nat := [2,4,8,16,32,64,128,98,512,51,2048,550,559,64,528,612,23,741,517,529,550,648,22,613,144,624,77,71,65,2678,547,544,99,81,17,54]

theorem envBound31721 : H12AffineFastState.Bounded env31721 := by
  intro p hp
  have h : env31721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31720_31721 : H12AffineEnvironment.transform 15 612 env31720 = env31721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 612 env31720 == env31721) = true)

theorem identity31721 : scanCanonicalize (H12AffineFastState.compose env31721 (packedSelected [0,4,5,9,12,16,17,21,27,38] rootPS)) = affineNative (2^(8+1) ^^^ 184) := by decide +kernel

theorem selectedBound31721 : packedSelected [0,4,5,9,12,16,17,21,27,38] rootPS < 2^1333 := by decide +kernel

def env31722 : List Nat := [2,4,8,16,32,64,128,98,184,51,2048,158,151,64,168,220,23,93,189,169,158,48,22,221,144,200,77,71,65,2254,155,152,99,81,17,54]

theorem envBound31722 : H12AffineFastState.Bounded env31722 := by
  intro p hp
  have h : env31722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31721_31722 : H12AffineEnvironment.transform 8 184 env31721 = env31722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 184 env31721 == env31722) = true)

theorem identity31722 : scanCanonicalize (H12AffineFastState.compose env31722 (packedSelected [2,3,10,11,13,18] rootPS)) = affineNative (2^(10+1) ^^^ 29) := by decide +kernel

theorem selectedBound31722 : packedSelected [2,3,10,11,13,18] rootPS < 2^1333 := by decide +kernel

def env31723 : List Nat := [2,4,8,16,32,64,128,98,184,51,29,158,151,64,168,220,23,93,189,169,158,48,22,221,144,200,77,71,65,211,155,152,99,81,17,54]

theorem envBound31723 : H12AffineFastState.Bounded env31723 := by
  intro p hp
  have h : env31723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31722_31723 : H12AffineEnvironment.transform 10 29 env31722 = env31723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 29 env31722 == env31723) = true)

theorem identity31723 : scanCanonicalize (H12AffineFastState.compose env31723 (packedSelected [2,3,4,7,8,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 36) := by decide +kernel

theorem selectedBound31723 : packedSelected [2,3,4,7,8,12,15] rootPS < 2^1333 := by decide +kernel

def env31724 : List Nat := [2,4,8,16,32,64,36,98,28,51,29,58,51,64,12,120,23,93,25,13,58,48,22,121,52,108,77,71,65,119,63,60,99,81,17,54]

theorem envBound31724 : H12AffineFastState.Bounded env31724 := by
  intro p hp
  have h : env31724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31723_31724 : H12AffineEnvironment.transform 6 36 env31723 = env31724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 36 env31723 == env31724) = true)

theorem identity31724 : scanCanonicalize (H12AffineFastState.compose env31724 (packedSelected [1,2,3,4,7,8] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound31724 : packedSelected [1,2,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env31725 : List Nat := [2,4,4,16,32,64,36,98,16,51,17,54,51,64,0,116,23,81,21,1,54,48,22,117,52,96,65,71,65,119,51,48,99,81,17,54]

theorem envBound31725 : H12AffineFastState.Bounded env31725 := by
  intro p hp
  have h : env31725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31724_31725 : H12AffineEnvironment.transform 2 4 env31724 = env31725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env31724 == env31725) = true)

theorem identity31725 : scanCanonicalize (H12AffineFastState.compose env31725 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 38) := by decide +kernel

theorem selectedBound31725 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env31726 : List Nat := [2,4,4,16,32,38,36,4,16,51,17,54,51,38,0,18,23,55,21,1,54,48,22,19,52,6,39,33,39,17,51,48,5,55,17,54]

theorem envBound31726 : H12AffineFastState.Bounded env31726 := by
  intro p hp
  have h : env31726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31725_31726 : H12AffineEnvironment.transform 5 38 env31725 = env31726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 38 env31725 == env31726) = true)

theorem identity31726 : scanCanonicalize (H12AffineFastState.compose env31726 (packedSelected [0,1,4] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound31726 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env31727 : List Nat := [2,4,4,16,6,0,2,4,16,21,17,16,21,0,0,18,23,17,21,1,16,22,22,19,18,6,1,7,1,17,21,22,5,17,17,16]

theorem envBound31727 : H12AffineFastState.Bounded env31727 := by
  intro p hp
  have h : env31727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31726_31727 : H12AffineEnvironment.transform 4 6 env31726 = env31727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env31726 == env31727) = true)

theorem identity31727 : scanCanonicalize (H12AffineFastState.compose env31727 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound31727 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31728 : List Nat := [2,4,4,0,6,0,2,4,0,5,1,0,5,0,0,2,7,1,5,1,0,6,6,3,2,6,1,7,1,1,5,6,5,1,1,0]

theorem envBound31728 : H12AffineFastState.Bounded env31728 := by
  intro p hp
  have h : env31728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31727_31728 : H12AffineEnvironment.transform 3 0 env31727 = env31728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env31727 == env31728) = true)

theorem identity31728 : scanCanonicalize (H12AffineFastState.compose env31728 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound31728 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31729 : List Nat := [2,2,2,0,0,0,2,2,0,3,1,0,3,0,0,2,1,1,3,1,0,0,0,3,2,0,1,1,1,1,3,0,3,1,1,0]

theorem envBound31729 : H12AffineFastState.Bounded env31729 := by
  intro p hp
  have h : env31729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31728_31729 : H12AffineEnvironment.transform 1 2 env31728 = env31729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env31728 == env31729) = true)

def env31730 : List Nat := [2,4,8,16,32,64,128,98,512,51,2048,550,559,64,528,613,22,740,517,529,550,648,23,612,144,625,77,70,65,2679,547,545,99,81,17,54]

theorem envBound31730 : H12AffineFastState.Bounded env31730 := by
  intro p hp
  have h : env31730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31720_31730 : H12AffineEnvironment.transform 15 613 env31720 = env31730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 613 env31720 == env31730) = true)

theorem identity31730 : scanCanonicalize (H12AffineFastState.compose env31730 (packedSelected [0,4,5,9,12,16,17,21,27,38] rootPS)) = affineNative (2^(8+1) ^^^ 190) := by decide +kernel

theorem selectedBound31730 : packedSelected [0,4,5,9,12,16,17,21,27,38] rootPS < 2^1333 := by decide +kernel

def env31731 : List Nat := [2,4,8,16,32,64,128,98,190,51,2048,152,145,64,174,219,22,90,187,175,152,54,23,218,144,207,77,70,65,2249,157,159,99,81,17,54]

theorem envBound31731 : H12AffineFastState.Bounded env31731 := by
  intro p hp
  have h : env31731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31730_31731 : H12AffineEnvironment.transform 8 190 env31730 = env31731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 190 env31730 == env31731) = true)

theorem identity31731 : scanCanonicalize (H12AffineFastState.compose env31731 (packedSelected [0,1,4,5,7,8,9,10,11,16,17,19,21,23] rootPS)) = affineNative (2^(6+1) ^^^ 114) := by decide +kernel

theorem selectedBound31731 : packedSelected [0,1,4,5,7,8,9,10,11,16,17,19,21,23] rootPS < 2^1333 := by decide +kernel

def env31732 : List Nat := [2,4,8,16,32,64,114,98,76,51,2048,106,99,64,92,41,22,90,73,93,106,54,23,40,98,61,77,70,65,2107,111,109,99,81,17,54]

theorem envBound31732 : H12AffineFastState.Bounded env31732 := by
  intro p hp
  have h : env31732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31731_31732 : H12AffineEnvironment.transform 6 114 env31731 = env31732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 114 env31731 == env31732) = true)

theorem identity31732 : scanCanonicalize (H12AffineFastState.compose env31732 (packedSelected [1,5,10,12,17] rootPS)) = affineNative (2^(10+1) ^^^ 102) := by decide +kernel

theorem selectedBound31732 : packedSelected [1,5,10,12,17] rootPS < 2^1333 := by decide +kernel

def env31733 : List Nat := [2,4,8,16,32,64,114,98,76,51,102,106,99,64,92,41,22,90,73,93,106,54,23,40,98,61,77,70,65,93,111,109,99,81,17,54]

theorem envBound31733 : H12AffineFastState.Bounded env31733 := by
  intro p hp
  have h : env31733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31732_31733 : H12AffineEnvironment.transform 10 102 env31732 = env31733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 102 env31732 == env31733) = true)

theorem identity31733 : scanCanonicalize (H12AffineFastState.compose env31733 (packedSelected [0,1,2,5,7,8,10] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound31733 : packedSelected [0,1,2,5,7,8,10] rootPS < 2^1333 := by decide +kernel

def env31734 : List Nat := [2,4,8,16,0,64,82,66,76,19,70,74,67,64,92,9,22,90,73,93,74,22,23,8,66,29,77,70,65,93,79,77,67,81,17,22]

theorem envBound31734 : H12AffineFastState.Bounded env31734 := by
  intro p hp
  have h : env31734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31733_31734 : H12AffineEnvironment.transform 4 0 env31733 = env31734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env31733 == env31734) = true)

theorem identity31734 : scanCanonicalize (H12AffineFastState.compose env31734 (packedSelected [1,3,4,5,7] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound31734 : packedSelected [1,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env31735 : List Nat := [2,4,8,12,0,64,78,66,76,15,70,74,67,64,64,9,10,70,73,65,74,10,11,8,66,1,77,70,65,65,79,77,67,77,13,10]

theorem envBound31735 : H12AffineFastState.Bounded env31735 := by
  intro p hp
  have h : env31735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31734_31735 : H12AffineEnvironment.transform 3 12 env31734 = env31735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env31734 == env31735) = true)

theorem identity31735 : scanCanonicalize (H12AffineFastState.compose env31735 (packedSelected [2,3] rootPS)) = affineNative (2^(5+1) ^^^ 6) := by decide +kernel

theorem selectedBound31735 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env31736 : List Nat := [2,4,8,12,0,6,8,4,10,15,0,12,5,6,6,9,10,0,15,7,12,10,11,8,4,1,11,0,7,7,9,11,5,11,13,10]

theorem envBound31736 : H12AffineFastState.Bounded env31736 := by
  intro p hp
  have h : env31736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31735_31736 : H12AffineEnvironment.transform 5 6 env31735 = env31736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 6 env31735 == env31736) = true)

theorem identity31736 : scanCanonicalize (H12AffineFastState.compose env31736 (packedSelected [0,2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound31736 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env31737 : List Nat := [2,3,8,11,0,1,8,3,10,8,0,11,2,1,1,9,10,0,8,0,11,10,11,8,3,1,11,0,0,0,9,11,2,11,10,10]

theorem envBound31737 : H12AffineFastState.Bounded env31737 := by
  intro p hp
  have h : env31737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31736_31737 : H12AffineEnvironment.transform 1 3 env31736 = env31737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env31736 == env31737) = true)

def env31738 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74863,262144,21585,32769,4096,61649,91182,123164,28888,78895,385203,90414,1297,96347,25885,82999,257,1281,1344,21073]

theorem envBound31738 : H12AffineFastState.Bounded env31738 := by
  intro p hp
  have h : env31738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31453_31738 : H12AffineEnvironment.transform 18 21585 env31453 = env31738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env31453 == env31738) = true)

theorem identity31738 : scanCanonicalize (H12AffineFastState.compose env31738 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound31738 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env31739 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13341,65536,74863,262144,21585,13340,4096,17612,91182,87297,28888,78895,349358,90414,1297,96347,25885,82999,257,1281,1344,21073]

theorem envBound31739 : H12AffineFastState.Bounded env31739 := by
  intro p hp
  have h : env31739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31738_31739 : H12AffineEnvironment.transform 14 13341 env31738 = env31739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env31738 == env31739) = true)

def env31740 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74863,262144,4417,13340,4096,476,74046,69649,13768,78895,332222,74814,1297,81227,8205,65831,257,1281,1344,5953]

theorem envBound31740 : H12AffineFastState.Bounded env31740 := by
  intro p hp
  have h : env31740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31739_31740 : H12AffineEnvironment.transform 13 1296 env31739 = env31740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env31739 == env31740) = true)

def env31741 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74863,65664,4417,13340,4096,476,74046,69649,13768,78895,4414,74814,1297,81227,8205,65831,257,1281,1344,5953]

theorem envBound31741 : H12AffineFastState.Bounded env31741 := by
  intro p hp
  have h : env31741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31740_31741 : H12AffineEnvironment.transform 17 65664 env31740 = env31741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env31740 == env31741) = true)

theorem identity31741 : scanCanonicalize (H12AffineFastState.compose env31741 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound31741 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env31742 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,1,12556,65536,74110,65664,4417,12557,4096,476,74046,69649,12505,78142,4414,74031,0,79962,8205,65831,257,16,81,4688]

theorem envBound31742 : H12AffineFastState.Bounded env31742 := by
  intro p hp
  have h : env31742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31741_31742 : H12AffineEnvironment.transform 9 273 env31741 = env31742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env31741 == env31742) = true)

def env31743 : List Nat := [2,4,8,16,32,64,128,256,340,273,2048,4096,8192,1,12556,65536,74110,65664,4417,12557,4096,476,74046,69649,12505,78142,4414,74031,0,79962,8205,65831,257,16,81,4356]

theorem envBound31743 : H12AffineFastState.Bounded env31743 := by
  intro p hp
  have h : env31743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31742_31743 : H12AffineEnvironment.transform 8 340 env31742 = env31743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env31742 == env31743) = true)

def env31744 : List Nat := [2,4,8,16,32,64,128,256,340,273,2048,16,8192,1,8476,65536,74110,65664,337,8477,16,476,74046,65537,8393,74030,302,74031,0,75850,8205,65831,257,16,81,276]

theorem envBound31744 : H12AffineFastState.Bounded env31744 := by
  intro p hp
  have h : env31744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31743_31744 : H12AffineEnvironment.transform 11 16 env31743 = env31744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env31743 == env31744) = true)

theorem identity31744 : scanCanonicalize (H12AffineFastState.compose env31744 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 69) := by decide +kernel

theorem selectedBound31744 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env31745 : List Nat := [2,4,8,16,32,64,128,256,340,273,2048,16,8192,1,8476,69,8507,197,337,8477,16,476,8571,68,8393,8555,302,8554,0,10255,8205,354,257,16,81,276]

theorem envBound31745 : H12AffineFastState.Bounded env31745 := by
  intro p hp
  have h : env31745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31744_31745 : H12AffineEnvironment.transform 15 69 env31744 = env31745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 69 env31744 == env31745) = true)

def env31746 : List Nat := [2,4,4,16,32,64,128,256,340,273,2048,16,8192,1,8464,69,8503,197,337,8465,16,464,8567,68,8389,8551,290,8550,0,10243,8193,354,257,16,81,276]

theorem envBound31746 : H12AffineFastState.Bounded env31746 := by
  intro p hp
  have h : env31746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31745_31746 : H12AffineEnvironment.transform 2 4 env31745 = env31746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env31745 == env31746) = true)

theorem identity31746 : scanCanonicalize (H12AffineFastState.compose env31746 (packedSelected [2,3,5,7,8,11,15,16,17,19,21,23,24,27] rootPS)) = affineNative (2^(10+1) ^^^ 407) := by decide +kernel

theorem selectedBound31746 : packedSelected [2,3,5,7,8,11,15,16,17,19,21,23,24,27] rootPS < 2^1333 := by decide +kernel

def env31747 : List Nat := [2,4,4,16,32,64,128,256,340,273,407,16,8192,1,8464,69,8503,197,337,8465,16,464,8567,68,8389,8551,290,8550,0,8596,8193,354,257,16,81,276]

theorem envBound31747 : H12AffineFastState.Bounded env31747 := by
  intro p hp
  have h : env31747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31746_31747 : H12AffineEnvironment.transform 10 407 env31746 = env31747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 407 env31746 == env31747) = true)

theorem identity31747 : scanCanonicalize (H12AffineFastState.compose env31747 (packedSelected [1,2,3,5,10,11,13,19,20,21] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound31747 : packedSelected [1,2,3,5,10,11,13,19,20,21] rootPS < 2^1333 := by decide +kernel

def env31748 : List Nat := [2,2,2,16,32,64,128,256,338,273,401,16,8192,1,8464,67,8497,195,337,8465,16,464,8561,66,8387,8545,290,8544,0,8594,8193,354,257,16,81,274]

theorem envBound31748 : H12AffineFastState.Bounded env31748 := by
  intro p hp
  have h : env31748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31747_31748 : H12AffineEnvironment.transform 1 2 env31747 = env31748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env31747 == env31748) = true)

theorem identity31748 : scanCanonicalize (H12AffineFastState.compose env31748 (packedSelected [1,3,4,7,8,10,13,15,17] rootPS)) = affineNative (2^(7+1) ^^^ 19) := by decide +kernel

theorem selectedBound31748 : packedSelected [1,3,4,7,8,10,13,15,17] rootPS < 2^1333 := by decide +kernel

def env31749 : List Nat := [2,2,2,16,32,64,128,19,65,2,130,16,8192,1,8195,67,8226,195,66,8194,16,195,8290,66,8387,8306,49,8307,0,8321,8193,113,18,16,81,1]

theorem envBound31749 : H12AffineFastState.Bounded env31749 := by
  intro p hp
  have h : env31749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31748_31749 : H12AffineEnvironment.transform 7 19 env31748 = env31749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 19 env31748 == env31749) = true)

theorem identity31749 : scanCanonicalize (H12AffineFastState.compose env31749 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound31749 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env31750 : List Nat := [2,2,2,16,32,0,128,19,1,2,130,16,8192,1,8195,3,8226,131,2,8194,16,131,8226,2,8323,8242,49,8243,0,8321,8193,49,18,16,17,1]

theorem envBound31750 : H12AffineFastState.Bounded env31750 := by
  intro p hp
  have h : env31750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31749_31750 : H12AffineEnvironment.transform 5 0 env31749 = env31750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env31749 == env31750) = true)

theorem identity31750 : scanCanonicalize (H12AffineFastState.compose env31750 (packedSelected [1,2] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound31750 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env31751 : List Nat := [2,2,2,16,32,0,35,19,1,2,33,16,8192,1,8195,3,8226,32,2,8194,16,32,8226,2,8224,8242,49,8243,0,8226,8193,49,18,16,17,1]

theorem envBound31751 : H12AffineFastState.Bounded env31751 := by
  intro p hp
  have h : env31751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31750_31751 : H12AffineEnvironment.transform 6 35 env31750 = env31751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env31750 == env31751) = true)

theorem identity31751 : scanCanonicalize (H12AffineFastState.compose env31751 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound31751 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env31752 : List Nat := [2,2,2,16,0,0,3,19,1,2,1,16,8192,1,8195,3,8194,0,2,8194,16,0,8194,2,8192,8210,17,8211,0,8194,8193,17,18,16,17,1]

theorem envBound31752 : H12AffineFastState.Bounded env31752 := by
  intro p hp
  have h : env31752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31751_31752 : H12AffineEnvironment.transform 4 0 env31751 = env31752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env31751 == env31752) = true)

def env31753 : List Nat := [2,4,5,16,32,64,128,256,340,273,2048,16,8192,1,8465,69,8502,197,337,8464,16,465,8566,68,8388,8550,291,8551,0,10242,8192,354,257,16,81,276]

theorem envBound31753 : H12AffineFastState.Bounded env31753 := by
  intro p hp
  have h : env31753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31745_31753 : H12AffineEnvironment.transform 2 5 env31745 = env31753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env31745 == env31753) = true)

theorem identity31753 : scanCanonicalize (H12AffineFastState.compose env31753 (packedSelected [2,3,5,7,8,11,15,16,17,19,21,23,24,27] rootPS)) = affineNative (2^(10+1) ^^^ 228) := by decide +kernel

theorem selectedBound31753 : packedSelected [2,3,5,7,8,11,15,16,17,19,21,23,24,27] rootPS < 2^1333 := by decide +kernel

def env31754 : List Nat := [2,4,5,16,32,64,128,256,340,273,228,16,8192,1,8465,69,8502,197,337,8464,16,465,8566,68,8388,8550,291,8551,0,8422,8192,354,257,16,81,276]

theorem envBound31754 : H12AffineFastState.Bounded env31754 := by
  intro p hp
  have h : env31754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31753_31754 : H12AffineEnvironment.transform 10 228 env31753 = env31754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 228 env31753 == env31754) = true)

theorem identity31754 : scanCanonicalize (H12AffineFastState.compose env31754 (packedSelected [0,1,2,7,11,13,19,21] rootPS)) = affineNative (2^(12+1) ^^^ 100) := by decide +kernel

theorem selectedBound31754 : packedSelected [0,1,2,7,11,13,19,21] rootPS < 2^1333 := by decide +kernel

def env31755 : List Nat := [2,4,5,16,32,64,128,256,340,273,228,16,100,1,373,69,338,197,337,372,16,465,274,68,160,258,291,259,0,130,100,354,257,16,81,276]

theorem envBound31755 : H12AffineFastState.Bounded env31755 := by
  intro p hp
  have h : env31755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31754_31755 : H12AffineEnvironment.transform 12 100 env31754 = env31755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 100 env31754 == env31755) = true)

theorem identity31755 : scanCanonicalize (H12AffineFastState.compose env31755 (packedSelected [1,4,5,7,10,17] rootPS)) = affineNative (2^(7+1) ^^^ 134) := by decide +kernel

theorem selectedBound31755 : packedSelected [1,4,5,7,10,17] rootPS < 2^1333 := by decide +kernel

def env31756 : List Nat := [2,4,5,16,32,64,128,134,210,151,228,16,100,1,243,69,212,197,215,242,16,87,148,68,160,132,165,133,0,130,100,228,135,16,81,146]

theorem envBound31756 : H12AffineFastState.Bounded env31756 := by
  intro p hp
  have h : env31756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31755_31756 : H12AffineEnvironment.transform 7 134 env31755 = env31756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 134 env31755 == env31756) = true)

theorem identity31756 : scanCanonicalize (H12AffineFastState.compose env31756 (packedSelected [2,4,9,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 99) := by decide +kernel

theorem selectedBound31756 : packedSelected [2,4,9,10,11] rootPS < 2^1333 := by decide +kernel

def env31757 : List Nat := [2,4,5,16,32,64,99,101,49,116,7,16,100,1,16,69,55,38,52,17,16,87,119,68,67,103,70,102,0,97,100,7,100,16,81,113]

theorem envBound31757 : H12AffineFastState.Bounded env31757 := by
  intro p hp
  have h : env31757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31756_31757 : H12AffineEnvironment.transform 6 99 env31756 = env31757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 99 env31756 == env31757) = true)

theorem identity31757 : scanCanonicalize (H12AffineFastState.compose env31757 (packedSelected [2,4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound31757 : packedSelected [2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env31758 : List Nat := [2,4,5,16,32,49,18,20,49,5,7,16,21,1,16,52,55,38,52,17,16,38,6,53,50,22,55,23,0,16,21,7,21,16,32,0]

theorem envBound31758 : H12AffineFastState.Bounded env31758 := by
  intro p hp
  have h : env31758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31757_31758 : H12AffineEnvironment.transform 5 49 env31757 = env31758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env31757 == env31758) = true)

theorem identity31758 : scanCanonicalize (H12AffineFastState.compose env31758 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound31758 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env31759 : List Nat := [2,4,5,16,6,23,18,20,23,5,7,16,21,1,16,18,17,0,18,17,16,0,6,19,20,22,17,23,0,16,21,7,21,16,6,0]

theorem envBound31759 : H12AffineFastState.Bounded env31759 := by
  intro p hp
  have h : env31759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31758_31759 : H12AffineEnvironment.transform 4 6 env31758 = env31759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env31758 == env31759) = true)

theorem identity31759 : scanCanonicalize (H12AffineFastState.compose env31759 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound31759 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31760 : List Nat := [2,2,3,16,0,17,18,18,17,3,1,16,19,1,16,18,17,0,18,17,16,0,0,19,18,16,17,17,0,16,19,1,19,16,0,0]

theorem envBound31760 : H12AffineFastState.Bounded env31760 := by
  intro p hp
  have h : env31760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31759_31760 : H12AffineEnvironment.transform 1 2 env31759 = env31760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env31759 == env31760) = true)

theorem identity31760 : scanCanonicalize (H12AffineFastState.compose env31760 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound31760 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31761 : List Nat := [2,2,3,0,0,1,2,2,1,3,1,0,3,1,0,2,1,0,2,1,0,0,0,3,2,0,1,1,0,0,3,1,3,0,0,0]

theorem envBound31761 : H12AffineFastState.Bounded env31761 := by
  intro p hp
  have h : env31761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31760_31761 : H12AffineEnvironment.transform 3 0 env31760 = env31761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env31760 == env31761) = true)

theorem identity31761 : scanCanonicalize (H12AffineFastState.compose env31761 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound31761 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31762 : List Nat := [1,1,0,0,0,1,1,1,1,0,1,0,0,1,0,1,1,0,1,1,0,0,0,0,1,0,1,1,0,0,0,1,0,0,0,0]

theorem envBound31762 : H12AffineFastState.Bounded env31762 := by
  intro p hp
  have h : env31762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31761_31762 : H12AffineEnvironment.transform 0 1 env31761 = env31762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env31761 == env31762) = true)

def env31763 : List Nat := [2,4,8,16,32,64,128,256,340,273,2048,17,8192,1,8477,65536,74110,65664,336,8476,17,476,74046,65536,8392,74031,303,74031,0,75851,8205,65831,257,16,81,277]

theorem envBound31763 : H12AffineFastState.Bounded env31763 := by
  intro p hp
  have h : env31763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31743_31763 : H12AffineEnvironment.transform 11 17 env31743 = env31763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env31743 == env31763) = true)

theorem identity31763 : scanCanonicalize (H12AffineFastState.compose env31763 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8284) := by decide +kernel

theorem selectedBound31763 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env31764 : List Nat := [2,4,8,16,32,64,128,256,340,273,2048,17,8192,1,8477,8284,290,8412,336,8476,17,476,354,8284,8392,371,303,371,0,2071,8205,8571,257,16,81,277]

theorem envBound31764 : H12AffineFastState.Bounded env31764 := by
  intro p hp
  have h : env31764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31763_31764 : H12AffineEnvironment.transform 15 8284 env31763 = env31764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8284 env31763 == env31764) = true)

def env31765 : List Nat := [2,4,8,16,32,64,128,256,340,273,2048,17,20,1,265,72,290,200,336,264,17,476,354,72,220,371,303,371,0,2071,25,367,257,16,81,277]

theorem envBound31765 : H12AffineFastState.Bounded env31765 := by
  intro p hp
  have h : env31765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31764_31765 : H12AffineEnvironment.transform 12 20 env31764 = env31765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 20 env31764 == env31765) = true)

theorem identity31765 : scanCanonicalize (H12AffineFastState.compose env31765 (packedSelected [2,3,5,7,8,11,15,16,17,19,21,23,24,27] rootPS)) = affineNative (2^(10+1) ^^^ 228) := by decide +kernel

theorem selectedBound31765 : packedSelected [2,3,5,7,8,11,15,16,17,19,21,23,24,27] rootPS < 2^1333 := by decide +kernel

def env31766 : List Nat := [2,4,8,16,32,64,128,256,340,273,228,17,20,1,265,72,290,200,336,264,17,476,354,72,220,371,303,371,0,243,25,367,257,16,81,277]

theorem envBound31766 : H12AffineFastState.Bounded env31766 := by
  intro p hp
  have h : env31766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31765_31766 : H12AffineEnvironment.transform 10 228 env31765 = env31766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 228 env31765 == env31766) = true)

theorem identity31766 : scanCanonicalize (H12AffineFastState.compose env31766 (packedSelected [2,5,8,12,13,15,17,19,20,21,23] rootPS)) = affineNative (2^(6+1) ^^^ 72) := by decide +kernel

theorem selectedBound31766 : packedSelected [2,5,8,12,13,15,17,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env31767 : List Nat := [2,4,8,16,32,64,72,256,340,273,44,17,20,1,265,72,290,0,336,264,17,276,354,72,20,371,303,371,0,59,25,367,257,16,81,277]

theorem envBound31767 : H12AffineFastState.Bounded env31767 := by
  intro p hp
  have h : env31767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31766_31767 : H12AffineEnvironment.transform 6 72 env31766 = env31767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 72 env31766 == env31767) = true)

theorem identity31767 : scanCanonicalize (H12AffineFastState.compose env31767 (packedSelected [0,3,9,10,15] rootPS)) = affineNative (2^(7+1) ^^^ 88) := by decide +kernel

theorem selectedBound31767 : packedSelected [0,3,9,10,15] rootPS < 2^1333 := by decide +kernel

def env31768 : List Nat := [2,4,8,16,32,64,72,88,12,73,44,17,20,1,81,72,122,0,8,80,17,76,58,72,20,43,119,43,0,59,25,55,89,16,81,77]

theorem envBound31768 : H12AffineFastState.Bounded env31768 := by
  intro p hp
  have h : env31768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31767_31768 : H12AffineEnvironment.transform 7 88 env31767 = env31768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 88 env31767 == env31768) = true)

theorem identity31768 : scanCanonicalize (H12AffineFastState.compose env31768 (packedSelected [0,1,2,3,4,5,7,8,9,10] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound31768 : packedSelected [0,1,2,3,4,5,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env31769 : List Nat := [2,4,8,16,12,64,72,88,12,73,0,17,20,1,81,72,86,0,8,80,17,76,22,72,20,7,91,7,0,23,25,27,89,16,81,77]

theorem envBound31769 : H12AffineFastState.Bounded env31769 := by
  intro p hp
  have h : env31769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31768_31769 : H12AffineEnvironment.transform 4 12 env31768 = env31769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env31768 == env31769) = true)

theorem identity31769 : scanCanonicalize (H12AffineFastState.compose env31769 (packedSelected [5,8] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound31769 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env31770 : List Nat := [2,4,4,16,0,64,68,84,0,69,0,17,20,1,81,68,86,0,4,80,17,64,22,68,20,7,87,7,0,23,21,23,85,16,81,65]

theorem envBound31770 : H12AffineFastState.Bounded env31770 := by
  intro p hp
  have h : env31770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31769_31770 : H12AffineEnvironment.transform 2 4 env31769 = env31770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env31769 == env31770) = true)

theorem identity31770 : scanCanonicalize (H12AffineFastState.compose env31770 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound31770 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31771 : List Nat := [2,4,4,6,0,64,68,66,0,69,0,7,2,1,71,68,64,0,4,70,7,64,0,68,2,7,65,7,0,1,3,1,67,6,71,65]

theorem envBound31771 : H12AffineFastState.Bounded env31771 := by
  intro p hp
  have h : env31771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31770_31771 : H12AffineEnvironment.transform 3 6 env31770 = env31771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env31770 == env31771) = true)

def env31772 : List Nat := [2,4,8,16,32,64,128,256,340,273,2048,17,21,1,264,73,290,201,336,265,17,476,354,73,221,371,303,371,0,2071,24,366,257,16,81,277]

theorem envBound31772 : H12AffineFastState.Bounded env31772 := by
  intro p hp
  have h : env31772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31764_31772 : H12AffineEnvironment.transform 12 21 env31764 = env31772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 21 env31764 == env31772) = true)

theorem identity31772 : scanCanonicalize (H12AffineFastState.compose env31772 (packedSelected [2,3,5,7,8,11,15,16,17,19,21,23,24,27] rootPS)) = affineNative (2^(10+1) ^^^ 411) := by decide +kernel

theorem selectedBound31772 : packedSelected [2,3,5,7,8,11,15,16,17,19,21,23,24,27] rootPS < 2^1333 := by decide +kernel

def env31773 : List Nat := [2,4,8,16,32,64,128,256,340,273,411,17,21,1,264,73,290,201,336,265,17,476,354,73,221,371,303,371,0,396,24,366,257,16,81,277]

theorem envBound31773 : H12AffineFastState.Bounded env31773 := by
  intro p hp
  have h : env31773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31772_31773 : H12AffineEnvironment.transform 10 411 env31772 = env31773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 411 env31772 == env31773) = true)

theorem identity31773 : scanCanonicalize (H12AffineFastState.compose env31773 (packedSelected [1,3,8,10,11,12,18,21,23,32] rootPS)) = affineNative (2^(5+1) ^^^ 60) := by decide +kernel

theorem selectedBound31773 : packedSelected [1,3,8,10,11,12,18,21,23,32] rootPS < 2^1333 := by decide +kernel

def env31774 : List Nat := [2,4,8,16,32,60,128,256,296,273,411,17,21,1,264,53,290,181,300,265,17,416,286,53,161,271,303,271,0,396,24,274,257,16,45,277]

theorem envBound31774 : H12AffineFastState.Bounded env31774 := by
  intro p hp
  have h : env31774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31773_31774 : H12AffineEnvironment.transform 5 60 env31773 = env31774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 60 env31773 == env31774) = true)

theorem identity31774 : scanCanonicalize (H12AffineFastState.compose env31774 (packedSelected [0,1,2,3,5,7,8,11,15,17] rootPS)) = affineNative (2^(7+1) ^^^ 183) := by decide +kernel

theorem selectedBound31774 : packedSelected [0,1,2,3,5,7,8,11,15,17] rootPS < 2^1333 := by decide +kernel

def env31775 : List Nat := [2,4,8,16,32,60,128,183,159,166,44,17,21,1,191,53,149,181,155,190,17,23,169,53,161,184,152,184,0,59,24,165,182,16,45,162]

theorem envBound31775 : H12AffineFastState.Bounded env31775 := by
  intro p hp
  have h : env31775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31774_31775 : H12AffineEnvironment.transform 7 183 env31774 = env31775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 183 env31774 == env31775) = true)

theorem identity31775 : scanCanonicalize (H12AffineFastState.compose env31775 (packedSelected [3,5,8,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound31775 : packedSelected [3,5,8,11,12] rootPS < 2^1333 := by decide +kernel

def env31776 : List Nat := [2,4,8,16,22,10,128,129,159,144,26,17,21,1,137,3,149,131,155,136,17,23,159,3,151,142,152,142,0,13,24,147,128,16,27,148]

theorem envBound31776 : H12AffineFastState.Bounded env31776 := by
  intro p hp
  have h : env31776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31775_31776 : H12AffineEnvironment.transform 4 22 env31775 = env31776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env31775 == env31776) = true)

theorem identity31776 : scanCanonicalize (H12AffineFastState.compose env31776 (packedSelected [3,8] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound31776 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env31777 : List Nat := [2,4,8,10,12,10,128,129,133,138,0,11,15,1,137,3,143,131,129,136,11,13,133,3,141,142,130,142,0,13,2,137,128,10,1,142]

theorem envBound31777 : H12AffineFastState.Bounded env31777 := by
  intro p hp
  have h : env31777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31776_31777 : H12AffineEnvironment.transform 3 10 env31776 = env31777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env31776 == env31777) = true)

theorem identity31777 : scanCanonicalize (H12AffineFastState.compose env31777 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound31777 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31778 : List Nat := [2,4,3,1,7,1,128,129,133,129,0,0,4,1,130,3,132,131,129,131,0,6,133,3,134,133,130,133,0,6,2,130,128,1,1,133]

theorem envBound31778 : H12AffineFastState.Bounded env31778 := by
  intro p hp
  have h : env31778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31777_31778 : H12AffineEnvironment.transform 2 3 env31777 = env31778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env31777 == env31778) = true)

theorem identity31778 : scanCanonicalize (H12AffineFastState.compose env31778 (packedSelected [2,3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound31778 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env31779 : List Nat := [2,3,3,1,0,1,128,129,130,129,0,0,3,1,130,3,131,131,129,131,0,1,130,3,129,130,130,130,0,1,2,130,128,1,1,130]

theorem envBound31779 : H12AffineFastState.Bounded env31779 := by
  intro p hp
  have h : env31779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31778_31779 : H12AffineEnvironment.transform 1 3 env31778 = env31779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env31778 == env31779) = true)

theorem identity31779 : scanCanonicalize (H12AffineFastState.compose env31779 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound31779 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31780 : List Nat := [2,3,3,1,0,1,3,2,1,2,0,0,3,1,1,3,0,0,2,0,0,1,1,3,2,1,1,1,0,1,2,1,3,1,1,1]

theorem envBound31780 : H12AffineFastState.Bounded env31780 := by
  intro p hp
  have h : env31780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31779_31780 : H12AffineEnvironment.transform 6 3 env31779 = env31780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env31779 == env31780) = true)

def env31781 : List Nat := [2,4,8,16,32,64,128,256,341,273,2048,4096,8192,1,12556,65536,74110,65664,4417,12557,4096,476,74046,69649,12505,78142,4414,74031,0,79962,8205,65831,257,16,81,4357]

theorem envBound31781 : H12AffineFastState.Bounded env31781 := by
  intro p hp
  have h : env31781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31742_31781 : H12AffineEnvironment.transform 8 341 env31742 = env31781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env31742 == env31781) = true)

def env31782 : List Nat := [2,4,8,16,32,64,128,256,341,273,2048,16,8192,1,8476,65536,74110,65664,337,8477,16,476,74046,65537,8393,74030,302,74031,0,75850,8205,65831,257,16,81,277]

theorem envBound31782 : H12AffineFastState.Bounded env31782 := by
  intro p hp
  have h : env31782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31781_31782 : H12AffineEnvironment.transform 11 16 env31781 = env31782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env31781 == env31782) = true)

theorem identity31782 : scanCanonicalize (H12AffineFastState.compose env31782 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 363) := by decide +kernel

theorem selectedBound31782 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env31783 : List Nat := [2,4,8,16,32,64,128,256,341,273,2048,16,363,1,119,65536,65557,65664,337,118,16,476,65621,65537,418,65605,302,65604,0,67873,358,65831,257,16,81,277]

theorem envBound31783 : H12AffineFastState.Bounded env31783 := by
  intro p hp
  have h : env31783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31782_31783 : H12AffineEnvironment.transform 12 363 env31782 = env31783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 363 env31782 == env31783) = true)

def env31784 : List Nat := [2,4,8,16,32,64,128,116,33,101,2048,16,31,1,119,65536,65557,65664,37,118,16,168,65621,65537,214,65605,90,65604,0,67669,18,65619,117,16,81,97]

theorem envBound31784 : H12AffineFastState.Bounded env31784 := by
  intro p hp
  have h : env31784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31783_31784 : H12AffineEnvironment.transform 7 116 env31783 = env31784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env31783 == env31784) = true)

def env31785 : List Nat := [2,4,8,16,32,0,128,52,33,37,2048,16,31,1,55,65536,65557,65664,37,54,16,168,65557,65537,150,65541,26,65540,0,67605,18,65555,53,16,17,33]

theorem envBound31785 : H12AffineFastState.Bounded env31785 := by
  intro p hp
  have h : env31785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31784_31785 : H12AffineEnvironment.transform 5 0 env31784 = env31785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env31784 == env31785) = true)

theorem identity31785 : scanCanonicalize (H12AffineFastState.compose env31785 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 52) := by decide +kernel

theorem selectedBound31785 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env31786 : List Nat := [2,4,8,16,32,0,128,52,33,37,2048,16,31,1,55,52,33,180,37,54,16,168,33,53,150,49,26,48,0,2081,18,39,53,16,17,33]

theorem envBound31786 : H12AffineFastState.Bounded env31786 := by
  intro p hp
  have h : env31786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31785_31786 : H12AffineEnvironment.transform 15 52 env31785 = env31786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 52 env31785 == env31786) = true)

theorem identity31786 : scanCanonicalize (H12AffineFastState.compose env31786 (packedSelected [5,17] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound31786 : packedSelected [5,17] rootPS < 2^1333 := by decide +kernel

def env31787 : List Nat := [2,4,8,0,32,0,128,36,33,37,2048,0,15,1,39,36,33,164,37,38,0,168,33,37,134,33,10,32,0,2081,2,39,37,0,1,33]

theorem envBound31787 : H12AffineFastState.Bounded env31787 := by
  intro p hp
  have h : env31787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31786_31787 : H12AffineEnvironment.transform 3 0 env31786 = env31787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env31786 == env31787) = true)

theorem identity31787 : scanCanonicalize (H12AffineFastState.compose env31787 (packedSelected [1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 7) := by decide +kernel

theorem selectedBound31787 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env31788 : List Nat := [2,4,8,0,32,0,128,36,33,37,7,0,15,1,39,36,33,164,37,38,0,168,33,37,134,33,10,32,0,38,2,39,37,0,1,33]

theorem envBound31788 : H12AffineFastState.Bounded env31788 := by
  intro p hp
  have h : env31788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31787_31788 : H12AffineEnvironment.transform 10 7 env31787 = env31788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 7 env31787 == env31788) = true)

def env31789 : List Nat := [2,4,8,16,32,1,128,53,33,36,2048,16,31,1,54,65536,65557,65664,37,55,16,168,65556,65537,151,65540,27,65541,0,67604,18,65554,52,16,16,32]

theorem envBound31789 : H12AffineFastState.Bounded env31789 := by
  intro p hp
  have h : env31789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31784_31789 : H12AffineEnvironment.transform 5 1 env31784 = env31789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env31784 == env31789) = true)

theorem identity31789 : scanCanonicalize (H12AffineFastState.compose env31789 (packedSelected [4,9,16] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound31789 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env31790 : List Nat := [2,4,8,16,1,1,128,20,0,5,2048,16,31,1,23,65536,65557,65664,4,22,16,137,65556,65537,151,65540,27,65541,0,67604,18,65554,21,16,16,1]

theorem envBound31790 : H12AffineFastState.Bounded env31790 := by
  intro p hp
  have h : env31790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31789_31790 : H12AffineEnvironment.transform 4 1 env31789 = env31790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env31789 == env31790) = true)

theorem identity31790 : scanCanonicalize (H12AffineFastState.compose env31790 (packedSelected [5,7,8,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 144) := by decide +kernel

theorem selectedBound31790 : packedSelected [5,7,8,11,13] rootPS < 2^1333 := by decide +kernel

def env31791 : List Nat := [2,4,8,16,1,1,128,20,0,5,144,16,31,1,23,65536,65557,65664,4,22,16,137,65556,65537,151,65540,27,65541,0,65668,18,65554,21,16,16,1]

theorem envBound31791 : H12AffineFastState.Bounded env31791 := by
  intro p hp
  have h : env31791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31790_31791 : H12AffineEnvironment.transform 10 144 env31790 = env31791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 144 env31790 == env31791) = true)

theorem identity31791 : scanCanonicalize (H12AffineFastState.compose env31791 (packedSelected [5,17] rootPS)) = affineNative (2^(15+1) ^^^ 141) := by decide +kernel

theorem selectedBound31791 : packedSelected [5,17] rootPS < 2^1333 := by decide +kernel

def env31792 : List Nat := [2,4,8,16,1,1,128,20,0,5,144,16,31,1,23,141,152,13,4,22,16,137,153,140,151,137,27,136,0,9,18,159,21,16,16,1]

theorem envBound31792 : H12AffineFastState.Bounded env31792 := by
  intro p hp
  have h : env31792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31791_31792 : H12AffineEnvironment.transform 15 141 env31791 = env31792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 141 env31791 == env31792) = true)

theorem identity31792 : scanCanonicalize (H12AffineFastState.compose env31792 (packedSelected [0,1,2] rootPS)) = affineNative (2^(6+1) ^^^ 1) := by decide +kernel

theorem selectedBound31792 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env31793 : List Nat := [2,4,8,16,1,1,1,20,0,5,17,16,31,1,23,12,25,13,4,22,16,8,24,13,22,8,27,9,0,9,18,30,21,16,16,1]

theorem envBound31793 : H12AffineFastState.Bounded env31793 := by
  intro p hp
  have h : env31793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31792_31793 : H12AffineEnvironment.transform 6 1 env31792 = env31793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 1 env31792 == env31793) = true)

theorem identity31793 : scanCanonicalize (H12AffineFastState.compose env31793 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound31793 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env31794 : List Nat := [2,4,8,1,1,1,1,5,0,5,0,1,14,1,6,12,8,13,4,7,1,8,9,13,7,8,10,9,0,9,3,15,4,1,1,1]

theorem envBound31794 : H12AffineFastState.Bounded env31794 := by
  intro p hp
  have h : env31794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31793_31794 : H12AffineEnvironment.transform 3 1 env31793 = env31794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env31793 == env31794) = true)

theorem identity31794 : scanCanonicalize (H12AffineFastState.compose env31794 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound31794 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31795 : List Nat := [2,4,4,1,1,1,1,5,0,5,0,1,2,1,6,0,4,1,4,7,1,4,5,1,7,4,6,5,0,5,3,3,4,1,1,1]

theorem envBound31795 : H12AffineFastState.Bounded env31795 := by
  intro p hp
  have h : env31795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31794_31795 : H12AffineEnvironment.transform 2 4 env31794 = env31795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env31794 == env31795) = true)

theorem identity31795 : scanCanonicalize (H12AffineFastState.compose env31795 (packedSelected [0,3] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound31795 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env31796 : List Nat := [0,4,4,1,1,1,1,5,0,5,0,1,0,1,4,0,4,1,4,5,1,4,5,1,5,4,4,5,0,5,1,1,4,1,1,1]

theorem envBound31796 : H12AffineFastState.Bounded env31796 := by
  intro p hp
  have h : env31796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31795_31796 : H12AffineEnvironment.transform 0 0 env31795 = env31796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env31795 == env31796) = true)

theorem identity31796 : scanCanonicalize (H12AffineFastState.compose env31796 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound31796 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31797 : List Nat := [0,0,0,1,1,1,1,1,0,1,0,1,0,1,0,0,0,1,0,1,1,0,1,1,1,0,0,1,0,1,1,1,0,1,1,1]

theorem envBound31797 : H12AffineFastState.Bounded env31797 := by
  intro p hp
  have h : env31797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31796_31797 : H12AffineEnvironment.transform 1 0 env31796 = env31797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env31796 == env31797) = true)

def env31798 : List Nat := [2,4,8,16,32,64,128,117,32,100,2048,16,30,1,119,65536,65557,65664,36,118,16,169,65621,65537,215,65605,91,65604,0,67668,19,65618,116,16,81,96]

theorem envBound31798 : H12AffineFastState.Bounded env31798 := by
  intro p hp
  have h : env31798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31783_31798 : H12AffineEnvironment.transform 7 117 env31783 = env31798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env31783 == env31798) = true)

def env31799 : List Nat := [2,4,8,16,32,0,128,53,32,36,2048,16,30,1,55,65536,65557,65664,36,54,16,169,65557,65537,151,65541,27,65540,0,67604,19,65554,52,16,17,32]

theorem envBound31799 : H12AffineFastState.Bounded env31799 := by
  intro p hp
  have h : env31799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31798_31799 : H12AffineEnvironment.transform 5 0 env31798 = env31799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env31798 == env31799) = true)

theorem identity31799 : scanCanonicalize (H12AffineFastState.compose env31799 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 53) := by decide +kernel

theorem selectedBound31799 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env31800 : List Nat := [2,4,8,16,32,0,128,53,32,36,2048,16,30,1,55,53,32,181,36,54,16,169,32,52,151,48,27,49,0,2081,19,39,52,16,17,32]

theorem envBound31800 : H12AffineFastState.Bounded env31800 := by
  intro p hp
  have h : env31800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31799_31800 : H12AffineEnvironment.transform 15 53 env31799 = env31800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53 env31799 == env31800) = true)

theorem identity31800 : scanCanonicalize (H12AffineFastState.compose env31800 (packedSelected [5,17] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound31800 : packedSelected [5,17] rootPS < 2^1333 := by decide +kernel

def env31801 : List Nat := [2,4,8,16,0,0,128,21,0,4,2048,16,30,1,23,21,0,149,4,22,16,137,0,20,151,16,27,17,0,2049,19,7,20,16,17,0]

theorem envBound31801 : H12AffineFastState.Bounded env31801 := by
  intro p hp
  have h : env31801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31800_31801 : H12AffineEnvironment.transform 4 0 env31800 = env31801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env31800 == env31801) = true)

theorem identity31801 : scanCanonicalize (H12AffineFastState.compose env31801 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound31801 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31802 : List Nat := [2,2,8,16,0,0,128,19,0,2,2048,16,24,1,17,19,0,147,2,16,16,137,0,18,145,16,27,17,0,2049,19,1,18,16,17,0]

theorem envBound31802 : H12AffineFastState.Bounded env31802 := by
  intro p hp
  have h : env31802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31801_31802 : H12AffineEnvironment.transform 1 2 env31801 = env31802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env31801 == env31802) = true)

theorem identity31802 : scanCanonicalize (H12AffineFastState.compose env31802 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound31802 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31803 : List Nat := [2,2,8,16,0,0,128,19,0,2,1,16,24,1,17,19,0,147,2,16,16,137,0,18,145,16,27,17,0,0,19,1,18,16,17,0]

theorem envBound31803 : H12AffineFastState.Bounded env31803 := by
  intro p hp
  have h : env31803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31802_31803 : H12AffineEnvironment.transform 10 1 env31802 = env31803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env31802 == env31803) = true)

theorem identity31803 : scanCanonicalize (H12AffineFastState.compose env31803 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound31803 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env31804 : List Nat := [2,2,8,16,0,0,8,19,0,2,1,16,24,1,17,19,0,27,2,16,16,1,0,18,25,16,27,17,0,0,19,1,18,16,17,0]

theorem envBound31804 : H12AffineFastState.Bounded env31804 := by
  intro p hp
  have h : env31804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31803_31804 : H12AffineEnvironment.transform 6 8 env31803 = env31804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env31803 == env31804) = true)

theorem identity31804 : scanCanonicalize (H12AffineFastState.compose env31804 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound31804 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31805 : List Nat := [2,2,8,11,0,0,8,8,0,2,1,11,3,1,10,8,0,0,2,11,11,1,0,9,2,11,0,10,0,0,8,1,9,11,10,0]

theorem envBound31805 : H12AffineFastState.Bounded env31805 := by
  intro p hp
  have h : env31805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31804_31805 : H12AffineEnvironment.transform 3 11 env31804 = env31805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env31804 == env31805) = true)

theorem identity31805 : scanCanonicalize (H12AffineFastState.compose env31805 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound31805 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env31806 : List Nat := [2,2,3,0,0,0,3,3,0,2,1,0,3,1,1,3,0,0,2,0,0,1,0,2,2,0,0,1,0,0,3,1,2,0,1,0]

theorem envBound31806 : H12AffineFastState.Bounded env31806 := by
  intro p hp
  have h : env31806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31805_31806 : H12AffineEnvironment.transform 2 3 env31805 = env31806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env31805 == env31806) = true)

def env31807 : List Nat := [2,4,8,16,32,1,128,52,32,37,2048,16,30,1,54,65536,65557,65664,36,55,16,169,65556,65537,150,65540,26,65541,0,67605,19,65555,53,16,16,33]

theorem envBound31807 : H12AffineFastState.Bounded env31807 := by
  intro p hp
  have h : env31807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31798_31807 : H12AffineEnvironment.transform 5 1 env31798 = env31807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env31798 == env31807) = true)

theorem identity31807 : scanCanonicalize (H12AffineFastState.compose env31807 (packedSelected [4,9,16] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound31807 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env31808 : List Nat := [2,4,8,16,0,1,128,20,0,5,2048,16,30,1,22,65536,65557,65664,4,23,16,137,65556,65537,150,65540,26,65541,0,67605,19,65555,21,16,16,1]

theorem envBound31808 : H12AffineFastState.Bounded env31808 := by
  intro p hp
  have h : env31808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31807_31808 : H12AffineEnvironment.transform 4 0 env31807 = env31808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env31807 == env31808) = true)

theorem identity31808 : scanCanonicalize (H12AffineFastState.compose env31808 (packedSelected [5,7,8,11,13] rootPS)) = affineNative (2^(15+1) ^^^ 147) := by decide +kernel

theorem selectedBound31808 : packedSelected [5,7,8,11,13] rootPS < 2^1333 := by decide +kernel

def env31809 : List Nat := [2,4,8,16,0,1,128,20,0,5,2048,16,30,1,22,147,134,19,4,23,16,137,135,146,150,151,26,150,0,2182,19,128,21,16,16,1]

theorem envBound31809 : H12AffineFastState.Bounded env31809 := by
  intro p hp
  have h : env31809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31808_31809 : H12AffineEnvironment.transform 15 147 env31808 = env31809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 147 env31808 == env31809) = true)

theorem identity31809 : scanCanonicalize (H12AffineFastState.compose env31809 (packedSelected [5,17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound31809 : packedSelected [5,17] rootPS < 2^1333 := by decide +kernel

def env31810 : List Nat := [2,4,8,16,0,1,9,20,0,5,2048,16,30,1,22,26,15,19,4,23,16,0,14,27,31,30,26,31,0,2063,19,9,21,16,16,1]

theorem envBound31810 : H12AffineFastState.Bounded env31810 := by
  intro p hp
  have h : env31810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31809_31810 : H12AffineEnvironment.transform 6 9 env31809 = env31810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env31809 == env31810) = true)

theorem identity31810 : scanCanonicalize (H12AffineFastState.compose env31810 (packedSelected [0,1,3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 6) := by decide +kernel

theorem selectedBound31810 : packedSelected [0,1,3,5,10] rootPS < 2^1333 := by decide +kernel

def env31811 : List Nat := [2,4,8,16,0,1,9,20,0,5,6,16,30,1,22,26,15,19,4,23,16,0,14,27,31,30,26,31,0,9,19,9,21,16,16,1]

theorem envBound31811 : H12AffineFastState.Bounded env31811 := by
  intro p hp
  have h : env31811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31810_31811 : H12AffineEnvironment.transform 10 6 env31810 = env31811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 6 env31810 == env31811) = true)

theorem identity31811 : scanCanonicalize (H12AffineFastState.compose env31811 (packedSelected [0,1,2,3,4,5,7] rootPS)) = affineNative (2^(3+1) ^^^ 14) := by decide +kernel

theorem selectedBound31811 : packedSelected [0,1,2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env31812 : List Nat := [2,4,8,14,0,1,9,10,0,5,6,14,0,1,8,4,15,13,4,9,14,0,14,5,1,0,4,1,0,9,13,9,11,14,14,1]

theorem envBound31812 : H12AffineFastState.Bounded env31812 := by
  intro p hp
  have h : env31812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31811_31812 : H12AffineEnvironment.transform 3 14 env31811 = env31812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 14 env31811 == env31812) = true)

theorem identity31812 : scanCanonicalize (H12AffineFastState.compose env31812 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound31812 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31813 : List Nat := [2,4,5,3,0,1,4,7,0,5,6,3,0,1,5,4,2,0,4,4,3,0,3,5,1,0,4,1,0,4,0,4,6,3,3,1]

theorem envBound31813 : H12AffineFastState.Bounded env31813 := by
  intro p hp
  have h : env31813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31812_31813 : H12AffineEnvironment.transform 2 5 env31812 = env31813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env31812 == env31813) = true)

theorem identity31813 : scanCanonicalize (H12AffineFastState.compose env31813 (packedSelected [1,2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound31813 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env31814 : List Nat := [2,2,3,3,0,1,2,1,0,3,0,3,0,1,3,2,2,0,2,2,3,0,3,3,1,0,2,1,0,2,0,2,0,3,3,1]

theorem envBound31814 : H12AffineFastState.Bounded env31814 := by
  intro p hp
  have h : env31814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31813_31814 : H12AffineEnvironment.transform 1 2 env31813 = env31814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env31813 == env31814) = true)

def env31815 : List Nat := [2,4,8,16,32,64,128,256,341,273,2048,17,8192,1,8477,65536,74110,65664,336,8476,17,476,74046,65536,8392,74031,303,74031,0,75851,8205,65831,257,16,81,276]

theorem envBound31815 : H12AffineFastState.Bounded env31815 := by
  intro p hp
  have h : env31815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31781_31815 : H12AffineEnvironment.transform 11 17 env31781 = env31815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env31781 == env31815) = true)

theorem identity31815 : scanCanonicalize (H12AffineFastState.compose env31815 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 114) := by decide +kernel

theorem selectedBound31815 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env31816 : List Nat := [2,4,8,16,32,64,128,114,39,99,2048,17,8192,1,8303,65536,73740,65664,34,8302,17,174,73804,65536,8392,73821,93,73821,0,75851,8205,65621,115,16,81,102]

theorem envBound31816 : H12AffineFastState.Bounded env31816 := by
  intro p hp
  have h : env31816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31815_31816 : H12AffineEnvironment.transform 7 114 env31815 = env31816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 114 env31815 == env31816) = true)

def env31817 : List Nat := [2,4,8,16,32,64,84,114,39,99,2048,17,8192,1,8303,65536,73740,65620,34,8302,17,122,73804,65536,8220,73821,93,73821,0,75851,8205,65621,115,16,81,102]

theorem envBound31817 : H12AffineFastState.Bounded env31817 := by
  intro p hp
  have h : env31817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31816_31817 : H12AffineEnvironment.transform 6 84 env31816 = env31817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 84 env31816 == env31817) = true)

theorem identity31817 : scanCanonicalize (H12AffineFastState.compose env31817 (packedSelected [2,3,4,5,7,8,9,10,11,16,18,20,24,27,41] rootPS)) = affineNative (2^(12+1) ^^^ 2053) := by decide +kernel

theorem selectedBound31817 : packedSelected [2,3,4,5,7,8,9,10,11,16,18,20,24,27,41] rootPS < 2^1333 := by decide +kernel

def env31818 : List Nat := [2,4,8,16,32,64,84,114,39,99,2048,17,2053,1,2154,65536,67593,65620,34,2155,17,122,67657,65536,2073,67672,93,67672,0,65614,2056,65621,115,16,81,102]

theorem envBound31818 : H12AffineFastState.Bounded env31818 := by
  intro p hp
  have h : env31818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31817_31818 : H12AffineEnvironment.transform 12 2053 env31817 = env31818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2053 env31817 == env31818) = true)

theorem identity31818 : scanCanonicalize (H12AffineFastState.compose env31818 (packedSelected [0,7,11,15,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 73) := by decide +kernel

theorem selectedBound31818 : packedSelected [0,7,11,15,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env31819 : List Nat := [2,4,8,16,32,64,84,114,39,99,2048,17,2053,1,2154,73,2112,29,34,2155,17,122,2048,73,2073,2065,93,2065,0,7,2056,28,115,16,81,102]

theorem envBound31819 : H12AffineFastState.Bounded env31819 := by
  intro p hp
  have h : env31819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31818_31819 : H12AffineEnvironment.transform 15 73 env31818 = env31819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 73 env31818 == env31819) = true)

theorem identity31819 : scanCanonicalize (H12AffineFastState.compose env31819 (packedSelected [1,2,4,5,9,10,11,12,13,15,18] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound31819 : packedSelected [1,2,4,5,9,10,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env31820 : List Nat := [2,4,8,10,32,64,78,104,39,99,2048,11,2053,1,2154,73,2112,7,34,2155,11,96,2048,73,2051,2059,71,2059,0,7,2056,6,105,10,75,102]

theorem envBound31820 : H12AffineFastState.Bounded env31820 := by
  intro p hp
  have h : env31820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31819_31820 : H12AffineEnvironment.transform 3 10 env31819 = env31820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env31819 == env31820) = true)

theorem identity31820 : scanCanonicalize (H12AffineFastState.compose env31820 (packedSelected [0,1,2,3,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 6) := by decide +kernel

theorem selectedBound31820 : packedSelected [0,1,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env31821 : List Nat := [2,4,8,10,32,64,78,104,39,99,6,11,3,1,108,73,70,7,34,109,11,96,6,73,5,13,71,13,0,7,14,6,105,10,75,102]

theorem envBound31821 : H12AffineFastState.Bounded env31821 := by
  intro p hp
  have h : env31821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31820_31821 : H12AffineEnvironment.transform 10 6 env31820 = env31821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 6 env31820 == env31821) = true)

theorem identity31821 : scanCanonicalize (H12AffineFastState.compose env31821 (packedSelected [1,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 7) := by decide +kernel

theorem selectedBound31821 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env31822 : List Nat := [2,4,8,10,32,7,9,47,39,36,6,11,3,1,43,14,1,7,34,42,11,39,6,14,5,13,0,13,0,7,14,6,46,10,12,33]

theorem envBound31822 : H12AffineFastState.Bounded env31822 := by
  intro p hp
  have h : env31822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31821_31822 : H12AffineEnvironment.transform 5 7 env31821 = env31822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 7 env31821 == env31822) = true)

theorem identity31822 : scanCanonicalize (H12AffineFastState.compose env31822 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound31822 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31823 : List Nat := [2,2,8,10,32,1,9,41,33,34,0,11,3,1,43,8,1,1,34,42,11,33,0,8,3,11,0,11,0,1,8,0,40,10,10,33]

theorem envBound31823 : H12AffineFastState.Bounded env31823 := by
  intro p hp
  have h : env31823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31822_31823 : H12AffineEnvironment.transform 1 2 env31822 = env31823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env31822 == env31823) = true)

def env31824 : List Nat := [2,4,8,16,32,64,85,114,39,99,2048,17,8192,1,8303,65536,73740,65621,34,8302,17,123,73804,65536,8221,73821,93,73821,0,75851,8205,65621,115,16,81,102]

theorem envBound31824 : H12AffineFastState.Bounded env31824 := by
  intro p hp
  have h : env31824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31816_31824 : H12AffineEnvironment.transform 6 85 env31816 = env31824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 85 env31816 == env31824) = true)

theorem identity31824 : scanCanonicalize (H12AffineFastState.compose env31824 (packedSelected [2,3,4,5,7,8,9,10,11,16,18,20,24,27,41] rootPS)) = affineNative (2^(10+1) ^^^ 29) := by decide +kernel

theorem selectedBound31824 : packedSelected [2,3,4,5,7,8,9,10,11,16,18,20,24,27,41] rootPS < 2^1333 := by decide +kernel

def env31825 : List Nat := [2,4,8,16,32,64,85,114,39,99,29,17,8192,1,8303,65536,73740,65621,34,8302,17,123,73804,65536,8221,73821,93,73821,0,73814,8205,65621,115,16,81,102]

theorem envBound31825 : H12AffineFastState.Bounded env31825 := by
  intro p hp
  have h : env31825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31824_31825 : H12AffineEnvironment.transform 10 29 env31824 = env31825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 29 env31824 == env31825) = true)

theorem identity31825 : scanCanonicalize (H12AffineFastState.compose env31825 (packedSelected [0,2,5,7,8,10,11,12,13,15,16,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound31825 : packedSelected [0,2,5,7,8,10,11,12,13,15,16,23,24] rootPS < 2^1333 := by decide +kernel

def env31826 : List Nat := [2,4,8,16,32,64,85,114,39,99,29,17,8192,1,8303,8203,7,8286,34,8302,17,123,71,8203,8221,86,93,86,0,93,8205,8286,115,16,81,102]

theorem envBound31826 : H12AffineFastState.Bounded env31826 := by
  intro p hp
  have h : env31826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31825_31826 : H12AffineEnvironment.transform 15 8203 env31825 = env31826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env31825 == env31826) = true)

theorem identity31826 : scanCanonicalize (H12AffineFastState.compose env31826 (packedSelected [0,2,3,4,5,7,8,9,10,13,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 2) := by decide +kernel

theorem selectedBound31826 : packedSelected [0,2,3,4,5,7,8,9,10,13,16,18] rootPS < 2^1333 := by decide +kernel

def env31827 : List Nat := [2,4,8,16,32,64,85,114,39,99,29,17,2,1,109,9,7,92,34,108,17,123,71,9,31,86,93,86,0,93,15,92,115,16,81,102]

theorem envBound31827 : H12AffineFastState.Bounded env31827 := by
  intro p hp
  have h : env31827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31826_31827 : H12AffineEnvironment.transform 12 2 env31826 = env31827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2 env31826 == env31827) = true)

theorem identity31827 : scanCanonicalize (H12AffineFastState.compose env31827 (packedSelected [0,3,4,5,8,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 44) := by decide +kernel

theorem selectedBound31827 : packedSelected [0,3,4,5,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env31828 : List Nat := [2,4,8,16,32,44,57,30,39,15,29,17,2,1,1,9,7,48,34,0,17,23,43,9,31,58,49,58,0,49,15,48,31,16,61,10]

theorem envBound31828 : H12AffineFastState.Bounded env31828 := by
  intro p hp
  have h : env31828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31827_31828 : H12AffineEnvironment.transform 5 44 env31827 = env31828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 44 env31827 == env31828) = true)

theorem identity31828 : scanCanonicalize (H12AffineFastState.compose env31828 (packedSelected [1,2,3,4,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound31828 : packedSelected [1,2,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env31829 : List Nat := [2,4,8,16,16,28,9,30,23,15,29,17,2,1,1,9,7,0,18,0,17,23,27,9,31,10,1,10,0,1,15,0,31,16,13,10]

theorem envBound31829 : H12AffineFastState.Bounded env31829 := by
  intro p hp
  have h : env31829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31828_31829 : H12AffineEnvironment.transform 4 16 env31828 = env31829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env31828 == env31829) = true)

theorem identity31829 : scanCanonicalize (H12AffineFastState.compose env31829 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound31829 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env31830 : List Nat := [2,4,8,6,6,10,9,8,1,15,11,7,2,1,1,9,7,0,4,0,7,1,13,9,9,10,1,10,0,1,15,0,9,6,13,10]

theorem envBound31830 : H12AffineFastState.Bounded env31830 := by
  intro p hp
  have h : env31830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31829_31830 : H12AffineEnvironment.transform 3 6 env31829 = env31830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env31829 == env31830) = true)

def env31831 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74863,65665,4417,13340,4096,476,74046,69649,13768,78895,4415,74814,1297,81227,8205,65831,257,1281,1344,5953]

theorem envBound31831 : H12AffineFastState.Bounded env31831 := by
  intro p hp
  have h : env31831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31740_31831 : H12AffineEnvironment.transform 17 65665 env31740 = env31831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env31740 == env31831) = true)

theorem identity31831 : scanCanonicalize (H12AffineFastState.compose env31831 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound31831 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env31832 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1296,9292,65536,74863,65665,272,9293,81,476,74046,65600,9625,74878,366,74814,1297,77082,8205,65831,257,1281,1344,1808]

theorem envBound31832 : H12AffineFastState.Bounded env31832 := by
  intro p hp
  have h : env31832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31831_31832 : H12AffineEnvironment.transform 11 81 env31831 = env31832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env31831 == env31832) = true)

def env31833 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,81,8192,80,8460,65536,74031,65665,272,8461,81,476,74046,65600,8409,74046,366,74110,81,75866,8205,65831,257,65,0,592]

theorem envBound31833 : H12AffineFastState.Bounded env31833 := by
  intro p hp
  have h : env31833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31832_31833 : H12AffineEnvironment.transform 9 320 env31832 = env31833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env31832 == env31833) = true)

theorem identity31833 : scanCanonicalize (H12AffineFastState.compose env31833 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 8250) := by decide +kernel

theorem selectedBound31833 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env31834 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,81,8192,80,8460,8250,277,8379,272,8461,81,476,260,8314,8409,260,366,324,81,2144,8205,8477,257,65,0,592]

theorem envBound31834 : H12AffineFastState.Bounded env31834 := by
  intro p hp
  have h : env31834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31833_31834 : H12AffineEnvironment.transform 15 8250 env31833 = env31834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8250 env31833 == env31834) = true)

theorem identity31834 : scanCanonicalize (H12AffineFastState.compose env31834 (packedSelected [0,1,4,7,8,9,16,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound31834 : packedSelected [0,1,4,7,8,9,16,19,20] rootPS < 2^1333 := by decide +kernel

def env31835 : List Nat := [2,4,8,16,32,64,128,69,512,5,2048,81,8192,80,8265,8250,80,8379,85,8264,81,153,65,8314,8409,65,43,1,81,2144,8205,8280,68,65,0,592]

theorem envBound31835 : H12AffineFastState.Bounded env31835 := by
  intro p hp
  have h : env31835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31834_31835 : H12AffineEnvironment.transform 7 69 env31834 = env31835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env31834 == env31835) = true)

theorem identity31835 : scanCanonicalize (H12AffineFastState.compose env31835 (packedSelected [1,3,5,8,13,17] rootPS)) = affineNative (2^(12+1) ^^^ 2072) := by decide +kernel

theorem selectedBound31835 : packedSelected [1,3,5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env31836 : List Nat := [2,4,8,16,32,64,128,69,512,5,2048,81,2072,80,2129,2082,80,2211,85,2128,81,153,65,2146,2241,65,43,1,81,2144,2069,2112,68,65,0,592]

theorem envBound31836 : H12AffineFastState.Bounded env31836 := by
  intro p hp
  have h : env31836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31835_31836 : H12AffineEnvironment.transform 12 2072 env31835 = env31836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2072 env31835 == env31836) = true)

theorem identity31836 : scanCanonicalize (H12AffineFastState.compose env31836 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 608) := by decide +kernel

theorem selectedBound31836 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31837 : List Nat := [2,4,8,16,32,64,128,69,512,5,608,81,632,80,561,578,80,707,85,560,81,153,65,514,673,65,43,1,81,512,629,544,68,65,0,592]

theorem envBound31837 : H12AffineFastState.Bounded env31837 := by
  intro p hp
  have h : env31837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31836_31837 : H12AffineEnvironment.transform 10 608 env31836 = env31837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 608 env31836 == env31837) = true)

theorem identity31837 : scanCanonicalize (H12AffineFastState.compose env31837 (packedSelected [3,8,11,18] rootPS)) = affineNative (2^(8+1) ^^^ 233) := by decide +kernel

theorem selectedBound31837 : packedSelected [3,8,11,18] rootPS < 2^1333 := by decide +kernel

def env31838 : List Nat := [2,4,8,16,32,64,128,69,233,5,137,81,145,80,216,171,80,42,85,217,81,153,65,235,72,65,43,1,81,233,156,201,68,65,0,185]

theorem envBound31838 : H12AffineFastState.Bounded env31838 := by
  intro p hp
  have h : env31838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31837_31838 : H12AffineEnvironment.transform 8 233 env31837 = env31838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 233 env31837 == env31838) = true)

theorem identity31838 : scanCanonicalize (H12AffineFastState.compose env31838 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound31838 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env31839 : List Nat := [2,4,8,16,10,64,128,69,195,5,137,81,145,80,216,129,80,0,85,217,81,153,65,193,72,65,1,1,81,195,156,201,68,65,0,147]

theorem envBound31839 : H12AffineFastState.Bounded env31839 := by
  intro p hp
  have h : env31839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31838_31839 : H12AffineEnvironment.transform 4 10 env31838 = env31839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env31838 == env31839) = true)

theorem identity31839 : scanCanonicalize (H12AffineFastState.compose env31839 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound31839 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env31840 : List Nat := [2,4,8,16,10,64,19,69,80,5,26,81,2,80,75,18,80,0,85,74,81,10,65,82,72,65,1,1,81,80,15,90,68,65,0,0]

theorem envBound31840 : H12AffineFastState.Bounded env31840 := by
  intro p hp
  have h : env31840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31839_31840 : H12AffineEnvironment.transform 6 19 env31839 = env31840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env31839 == env31840) = true)

theorem identity31840 : scanCanonicalize (H12AffineFastState.compose env31840 (packedSelected [4,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound31840 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env31841 : List Nat := [2,4,8,16,10,16,19,21,0,5,26,1,2,0,27,18,0,0,5,26,1,10,17,2,24,17,1,1,1,0,15,10,20,17,0,0]

theorem envBound31841 : H12AffineFastState.Bounded env31841 := by
  intro p hp
  have h : env31841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31840_31841 : H12AffineEnvironment.transform 5 16 env31840 = env31841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31840 == env31841) = true)

theorem identity31841 : scanCanonicalize (H12AffineFastState.compose env31841 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound31841 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env31842 : List Nat := [2,4,8,10,10,10,9,15,0,5,0,1,2,0,1,8,0,0,5,0,1,10,11,2,2,11,1,1,1,0,15,10,14,11,0,0]

theorem envBound31842 : H12AffineFastState.Bounded env31842 := by
  intro p hp
  have h : env31842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31841_31842 : H12AffineEnvironment.transform 3 10 env31841 = env31842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env31841 == env31842) = true)

theorem identity31842 : scanCanonicalize (H12AffineFastState.compose env31842 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound31842 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31843 : List Nat := [2,4,5,7,7,7,4,2,0,5,0,1,2,0,1,5,0,0,5,0,1,7,6,2,2,6,1,1,1,0,2,7,3,6,0,0]

theorem envBound31843 : H12AffineFastState.Bounded env31843 := by
  intro p hp
  have h : env31843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31842_31843 : H12AffineEnvironment.transform 2 5 env31842 = env31843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env31842 == env31843) = true)

def env31844 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,81,8192,81,8461,65536,74030,65665,272,8460,81,476,74046,65600,8408,74047,366,74111,80,75867,8205,65831,257,64,1,593]

theorem envBound31844 : H12AffineFastState.Bounded env31844 := by
  intro p hp
  have h : env31844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31832_31844 : H12AffineEnvironment.transform 9 321 env31832 = env31844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env31832 == env31844) = true)

theorem identity31844 : scanCanonicalize (H12AffineFastState.compose env31844 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 8298) := by decide +kernel

theorem selectedBound31844 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env31845 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,81,8192,81,8461,8298,324,8427,272,8460,81,476,340,8234,8408,341,366,277,80,2097,8205,8525,257,64,1,593]

theorem envBound31845 : H12AffineFastState.Bounded env31845 := by
  intro p hp
  have h : env31845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31844_31845 : H12AffineEnvironment.transform 15 8298 env31844 = env31845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8298 env31844 == env31845) = true)

theorem identity31845 : scanCanonicalize (H12AffineFastState.compose env31845 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound31845 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env31846 : List Nat := [2,4,8,16,32,64,128,21,512,84,2048,81,8192,81,8216,8298,81,8427,5,8217,81,201,65,8234,8408,64,123,0,80,2097,8205,8280,20,64,1,593]

theorem envBound31846 : H12AffineFastState.Bounded env31846 := by
  intro p hp
  have h : env31846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31845_31846 : H12AffineEnvironment.transform 7 21 env31845 = env31846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env31845 == env31846) = true)

theorem identity31846 : scanCanonicalize (H12AffineFastState.compose env31846 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound31846 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env31847 : List Nat := [2,4,8,16,32,17,128,21,512,5,2048,0,8192,0,8216,8251,0,8378,5,8217,0,152,16,8234,8329,17,42,0,1,2097,8205,8201,20,17,1,512]

theorem envBound31847 : H12AffineFastState.Bounded env31847 := by
  intro p hp
  have h : env31847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31846_31847 : H12AffineEnvironment.transform 5 17 env31846 = env31847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31846 == env31847) = true)

theorem identity31847 : scanCanonicalize (H12AffineFastState.compose env31847 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound31847 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31848 : List Nat := [2,4,8,16,32,17,128,21,512,5,513,0,8192,0,8216,8251,0,8378,5,8217,0,152,16,8234,8329,17,42,0,1,560,8205,8201,20,17,1,512]

theorem envBound31848 : H12AffineFastState.Bounded env31848 := by
  intro p hp
  have h : env31848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31847_31848 : H12AffineEnvironment.transform 10 513 env31847 = env31848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env31847 == env31848) = true)

theorem identity31848 : scanCanonicalize (H12AffineFastState.compose env31848 (packedSelected [3,8] rootPS)) = affineNative (2^(12+1) ^^^ 651) := by decide +kernel

theorem selectedBound31848 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env31849 : List Nat := [2,4,8,16,32,17,128,21,512,5,513,0,651,0,659,688,0,561,5,658,0,152,16,673,514,17,42,0,1,560,646,642,20,17,1,512]

theorem envBound31849 : H12AffineFastState.Bounded env31849 := by
  intro p hp
  have h : env31849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31848_31849 : H12AffineEnvironment.transform 12 651 env31848 = env31849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 651 env31848 == env31849) = true)

theorem identity31849 : scanCanonicalize (H12AffineFastState.compose env31849 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound31849 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env31850 : List Nat := [2,4,8,16,32,17,128,21,136,5,137,0,3,0,27,56,0,185,5,26,0,152,16,41,138,17,42,0,1,184,14,10,20,17,1,136]

theorem envBound31850 : H12AffineFastState.Bounded env31850 := by
  intro p hp
  have h : env31850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31849_31850 : H12AffineEnvironment.transform 8 136 env31849 = env31850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env31849 == env31850) = true)

theorem identity31850 : scanCanonicalize (H12AffineFastState.compose env31850 (packedSelected [1,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound31850 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env31851 : List Nat := [2,4,8,10,32,11,128,15,136,5,137,0,3,0,1,34,0,163,5,0,0,130,10,41,138,11,42,0,1,162,14,10,14,11,1,136]

theorem envBound31851 : H12AffineFastState.Bounded env31851 := by
  intro p hp
  have h : env31851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31850_31851 : H12AffineEnvironment.transform 3 10 env31850 = env31851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env31850 == env31851) = true)

theorem identity31851 : scanCanonicalize (H12AffineFastState.compose env31851 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound31851 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31852 : List Nat := [2,4,8,10,6,11,128,15,136,5,137,0,3,0,1,4,0,133,5,0,0,130,10,15,138,11,12,0,1,132,14,10,14,11,1,136]

theorem envBound31852 : H12AffineFastState.Bounded env31852 := by
  intro p hp
  have h : env31852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31851_31852 : H12AffineEnvironment.transform 4 6 env31851 = env31852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env31851 == env31852) = true)

theorem identity31852 : scanCanonicalize (H12AffineFastState.compose env31852 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound31852 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env31853 : List Nat := [2,4,5,7,6,6,128,2,133,5,132,0,3,0,1,4,0,133,5,0,0,130,7,2,135,6,1,0,1,132,3,7,3,6,1,133]

theorem envBound31853 : H12AffineFastState.Bounded env31853 := by
  intro p hp
  have h : env31853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31852_31853 : H12AffineEnvironment.transform 2 5 env31852 = env31853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env31852 == env31853) = true)

theorem identity31853 : scanCanonicalize (H12AffineFastState.compose env31853 (packedSelected [7] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound31853 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env31854 : List Nat := [2,4,5,7,6,6,4,2,1,5,0,0,3,0,1,4,0,1,5,0,0,6,7,2,3,6,1,0,1,0,3,7,3,6,1,1]

theorem envBound31854 : H12AffineFastState.Bounded env31854 := by
  intro p hp
  have h : env31854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31853_31854 : H12AffineEnvironment.transform 6 4 env31853 = env31854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env31853 == env31854) = true)

def env31855 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74863,262144,4416,13340,4096,477,74047,69648,13769,78895,332223,74815,1297,81226,8204,65830,257,1281,1344,5952]

theorem envBound31855 : H12AffineFastState.Bounded env31855 := by
  intro p hp
  have h : env31855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31739_31855 : H12AffineEnvironment.transform 13 1297 env31739 = env31855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env31739 == env31855) = true)

def env31856 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74863,65664,4416,13340,4096,477,74047,69648,13769,78895,4415,74815,1297,81226,8204,65830,257,1281,1344,5952]

theorem envBound31856 : H12AffineFastState.Bounded env31856 := by
  intro p hp
  have h : env31856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31855_31856 : H12AffineEnvironment.transform 17 65664 env31855 = env31856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env31855 == env31856) = true)

theorem identity31856 : scanCanonicalize (H12AffineFastState.compose env31856 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5464) := by decide +kernel

theorem selectedBound31856 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env31857 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5464,1297,325,65536,69943,65664,4416,324,4096,477,70759,69648,145,65911,4415,69991,1297,67602,5460,65830,257,1281,1344,5952]

theorem envBound31857 : H12AffineFastState.Bounded env31857 := by
  intro p hp
  have h : env31857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31856_31857 : H12AffineEnvironment.transform 12 5464 env31856 = env31857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5464 env31856 == env31857) = true)

def env31858 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5464,1297,325,1052,5419,1180,4416,324,4096,477,4219,5132,145,1387,4415,5499,1297,3086,5460,1338,257,1281,1344,5952]

theorem envBound31858 : H12AffineFastState.Bounded env31858 := by
  intro p hp
  have h : env31858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31857_31858 : H12AffineEnvironment.transform 15 1052 env31857 = env31858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1052 env31857 == env31858) = true)

theorem identity31858 : scanCanonicalize (H12AffineFastState.compose env31858 (packedSelected [0,2,3,5,8,11,15,16,17,20,21,23,24,27,28] rootPS)) = affineNative (2^(11+1) ^^^ 3965) := by decide +kernel

theorem selectedBound31858 : packedSelected [0,2,3,5,8,11,15,16,17,20,21,23,24,27,28] rootPS < 2^1333 := by decide +kernel

def env31859 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3965,2597,1297,325,1052,2646,1180,3645,324,3965,477,3846,2929,145,1387,3650,2566,1297,3086,2601,1338,257,1281,1344,2109]

theorem envBound31859 : H12AffineFastState.Bounded env31859 := by
  intro p hp
  have h : env31859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31858_31859 : H12AffineEnvironment.transform 11 3965 env31858 = env31859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3965 env31858 == env31859) = true)

def env31860 : List Nat := [2,4,8,16,32,64,128,68,512,1024,2048,3641,2597,1109,1,1052,2646,1180,3645,0,3641,153,3650,2613,145,1071,3650,2566,1109,3086,2601,1150,69,1093,1028,2109]

theorem envBound31860 : H12AffineFastState.Bounded env31860 := by
  intro p hp
  have h : env31860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31859_31860 : H12AffineEnvironment.transform 7 68 env31859 = env31860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env31859 == env31860) = true)

theorem identity31860 : scanCanonicalize (H12AffineFastState.compose env31860 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 63) := by decide +kernel

theorem selectedBound31860 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env31861 : List Nat := [2,4,8,16,32,64,128,68,512,63,2048,2566,2597,106,1,35,2646,163,2562,0,2566,153,2685,2613,145,16,2685,2566,106,2097,2601,65,69,122,59,2109]

theorem envBound31861 : H12AffineFastState.Bounded env31861 := by
  intro p hp
  have h : env31861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31860_31861 : H12AffineEnvironment.transform 9 63 env31860 = env31861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 63 env31860 == env31861) = true)

theorem identity31861 : scanCanonicalize (H12AffineFastState.compose env31861 (packedSelected [4,9,16] rootPS)) = affineNative (2^(10+1) ^^^ 519) := by decide +kernel

theorem selectedBound31861 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env31862 : List Nat := [2,4,8,16,32,64,128,68,512,63,519,1,34,106,1,35,81,163,5,0,1,153,122,50,145,16,122,1,106,566,46,65,69,122,59,570]

theorem envBound31862 : H12AffineFastState.Bounded env31862 := by
  intro p hp
  have h : env31862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31861_31862 : H12AffineEnvironment.transform 10 519 env31861 = env31862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 519 env31861 == env31862) = true)

theorem identity31862 : scanCanonicalize (H12AffineFastState.compose env31862 (packedSelected [0,1,3,5,7,8,10,11,13] rootPS)) = affineNative (2^(6+1) ^^^ 115) := by decide +kernel

theorem selectedBound31862 : packedSelected [0,1,3,5,7,8,10,11,13] rootPS < 2^1333 := by decide +kernel

def env31863 : List Nat := [2,4,8,16,32,64,115,68,512,63,519,1,34,106,1,35,81,80,5,0,1,106,122,50,98,16,122,1,106,566,46,65,69,122,59,570]

theorem envBound31863 : H12AffineFastState.Bounded env31863 := by
  intro p hp
  have h : env31863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31862_31863 : H12AffineEnvironment.transform 6 115 env31862 = env31863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 115 env31862 == env31863) = true)

theorem identity31863 : scanCanonicalize (H12AffineFastState.compose env31863 (packedSelected [3,5,10,15] rootPS)) = affineNative (2^(8+1) ^^^ 54) := by decide +kernel

theorem selectedBound31863 : packedSelected [3,5,10,15] rootPS < 2^1333 := by decide +kernel

def env31864 : List Nat := [2,4,8,16,32,64,115,68,54,63,49,1,34,106,1,35,81,80,5,0,1,106,122,50,98,16,122,1,106,0,46,65,69,122,59,12]

theorem envBound31864 : H12AffineFastState.Bounded env31864 := by
  intro p hp
  have h : env31864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31863_31864 : H12AffineEnvironment.transform 8 54 env31863 = env31864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 54 env31863 == env31864) = true)

theorem identity31864 : scanCanonicalize (H12AffineFastState.compose env31864 (packedSelected [2,3,4,9] rootPS)) = affineNative (2^(5+1) ^^^ 26) := by decide +kernel

theorem selectedBound31864 : packedSelected [2,3,4,9] rootPS < 2^1333 := by decide +kernel

def env31865 : List Nat := [2,4,8,16,32,26,41,30,54,63,49,1,34,48,1,35,11,10,5,0,1,48,32,50,56,16,32,1,48,0,46,27,31,32,59,12]

theorem envBound31865 : H12AffineFastState.Bounded env31865 := by
  intro p hp
  have h : env31865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31864_31865 : H12AffineEnvironment.transform 5 26 env31864 = env31865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 26 env31864 == env31865) = true)

theorem identity31865 : scanCanonicalize (H12AffineFastState.compose env31865 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound31865 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31866 : List Nat := [2,3,8,16,32,26,41,25,49,56,49,1,34,48,1,35,11,10,2,0,1,48,32,50,56,16,32,1,48,0,41,27,24,32,59,11]

theorem envBound31866 : H12AffineFastState.Bounded env31866 := by
  intro p hp
  have h : env31866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31865_31866 : H12AffineEnvironment.transform 1 3 env31865 = env31866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env31865 == env31866) = true)

theorem identity31866 : scanCanonicalize (H12AffineFastState.compose env31866 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound31866 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31867 : List Nat := [2,3,8,10,32,0,41,3,43,34,43,1,34,42,1,35,11,10,2,0,1,42,32,40,34,10,32,1,42,0,41,1,2,32,33,11]

theorem envBound31867 : H12AffineFastState.Bounded env31867 := by
  intro p hp
  have h : env31867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31866_31867 : H12AffineEnvironment.transform 3 10 env31866 = env31867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env31866 == env31867) = true)

theorem identity31867 : scanCanonicalize (H12AffineFastState.compose env31867 (packedSelected [0,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound31867 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env31868 : List Nat := [2,3,8,10,10,0,3,3,1,8,1,1,8,0,1,9,11,10,2,0,1,0,10,2,8,10,10,1,0,0,3,1,2,10,11,11]

theorem envBound31868 : H12AffineFastState.Bounded env31868 := by
  intro p hp
  have h : env31868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31867_31868 : H12AffineEnvironment.transform 4 10 env31867 = env31868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env31867 == env31868) = true)

theorem identity31868 : scanCanonicalize (H12AffineFastState.compose env31868 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound31868 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env31869 : List Nat := [2,3,3,1,1,0,3,3,1,3,1,1,3,0,1,2,0,1,2,0,1,0,1,2,3,1,1,1,0,0,3,1,2,1,0,0]

theorem envBound31869 : H12AffineFastState.Bounded env31869 := by
  intro p hp
  have h : env31869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31868_31869 : H12AffineEnvironment.transform 2 3 env31868 = env31869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env31868 == env31869) = true)

theorem identity31869 : scanCanonicalize (H12AffineFastState.compose env31869 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound31869 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31870 : List Nat := [1,0,0,1,1,0,0,0,1,0,1,1,0,0,1,1,0,1,1,0,1,0,1,1,0,1,1,1,0,0,0,1,1,1,0,0]

theorem envBound31870 : H12AffineFastState.Bounded env31870 := by
  intro p hp
  have h : env31870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31869_31870 : H12AffineEnvironment.transform 0 1 env31869 = env31870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env31869 == env31870) = true)

def env31871 : List Nat := [2,4,8,16,32,64,128,69,512,1024,2048,3640,2597,1108,0,1052,2646,1180,3645,1,3640,152,3651,2612,145,1070,3650,2566,1108,3086,2601,1151,68,1092,1029,2109]

theorem envBound31871 : H12AffineFastState.Bounded env31871 := by
  intro p hp
  have h : env31871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31859_31871 : H12AffineEnvironment.transform 7 69 env31859 = env31871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env31859 == env31871) = true)

theorem identity31871 : scanCanonicalize (H12AffineFastState.compose env31871 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound31871 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env31872 : List Nat := [2,4,8,16,32,64,128,69,512,5,2048,2621,2597,81,0,25,2646,153,2616,1,2621,152,2630,2612,145,43,2631,2566,81,2059,2601,122,68,65,0,2109]

theorem envBound31872 : H12AffineFastState.Bounded env31872 := by
  intro p hp
  have h : env31872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31871_31872 : H12AffineEnvironment.transform 9 5 env31871 = env31872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env31871 == env31872) = true)

theorem identity31872 : scanCanonicalize (H12AffineFastState.compose env31872 (packedSelected [2,23,32] rootPS)) = affineNative (2^(8+1) ^^^ 216) := by decide +kernel

theorem selectedBound31872 : packedSelected [2,23,32] rootPS < 2^1333 := by decide +kernel

def env31873 : List Nat := [2,4,8,16,32,64,128,69,216,5,2048,2277,2301,81,0,25,2190,153,2272,1,2277,152,2206,2284,145,43,2207,2270,81,2059,2289,122,68,65,0,2109]

theorem envBound31873 : H12AffineFastState.Bounded env31873 := by
  intro p hp
  have h : env31873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31872_31873 : H12AffineEnvironment.transform 8 216 env31872 = env31873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env31872 == env31873) = true)

theorem identity31873 : scanCanonicalize (H12AffineFastState.compose env31873 (packedSelected [0,2,3,7,8,11,12,13,16,19,23,24] rootPS)) = affineNative (2^(10+1) ^^^ 133) := by decide +kernel

theorem selectedBound31873 : packedSelected [0,2,3,7,8,11,12,13,16,19,23,24] rootPS < 2^1333 := by decide +kernel

def env31874 : List Nat := [2,4,8,16,32,64,128,69,216,5,133,96,120,81,0,25,11,153,101,1,96,152,27,105,145,43,26,91,81,142,116,122,68,65,0,184]

theorem envBound31874 : H12AffineFastState.Bounded env31874 := by
  intro p hp
  have h : env31874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31873_31874 : H12AffineEnvironment.transform 10 133 env31873 = env31874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 133 env31873 == env31874) = true)

theorem identity31874 : scanCanonicalize (H12AffineFastState.compose env31874 (packedSelected [0,3,4,7,9,10,13,15,16,18] rootPS)) = affineNative (2^(6+1) ^^^ 68) := by decide +kernel

theorem selectedBound31874 : packedSelected [0,3,4,7,9,10,13,15,16,18] rootPS < 2^1333 := by decide +kernel

def env31875 : List Nat := [2,4,8,16,32,64,68,69,28,5,65,96,120,81,0,25,11,93,101,1,96,92,27,105,85,43,26,91,81,74,116,122,68,65,0,124]

theorem envBound31875 : H12AffineFastState.Bounded env31875 := by
  intro p hp
  have h : env31875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31874_31875 : H12AffineEnvironment.transform 6 68 env31874 = env31875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 68 env31874 == env31875) = true)

theorem identity31875 : scanCanonicalize (H12AffineFastState.compose env31875 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound31875 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env31876 : List Nat := [2,4,3,16,32,64,68,69,23,5,65,96,115,81,0,18,0,86,101,1,96,87,16,98,85,32,17,80,81,65,116,113,68,65,0,119]

theorem envBound31876 : H12AffineFastState.Bounded env31876 := by
  intro p hp
  have h : env31876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31875_31876 : H12AffineEnvironment.transform 2 3 env31875 = env31876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env31875 == env31876) = true)

theorem identity31876 : scanCanonicalize (H12AffineFastState.compose env31876 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound31876 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env31877 : List Nat := [2,4,3,16,6,64,68,69,23,5,65,70,85,81,0,18,0,86,67,1,70,87,16,68,85,6,17,80,81,65,82,87,68,65,0,81]

theorem envBound31877 : H12AffineFastState.Bounded env31877 := by
  intro p hp
  have h : env31877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31876_31877 : H12AffineEnvironment.transform 4 6 env31876 = env31877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env31876 == env31877) = true)

def env31878 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5464,1297,325,1053,5418,1181,4416,324,4096,477,4218,5133,145,1386,4415,5498,1297,3087,5460,1339,257,1281,1344,5952]

theorem envBound31878 : H12AffineFastState.Bounded env31878 := by
  intro p hp
  have h : env31878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31857_31878 : H12AffineEnvironment.transform 15 1053 env31857 = env31878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1053 env31857 == env31878) = true)

theorem identity31878 : scanCanonicalize (H12AffineFastState.compose env31878 (packedSelected [0,2,3,5,8,11,15,16,17,20,21,23,24,27,28] rootPS)) = affineNative (2^(11+1) ^^^ 3910) := by decide +kernel

theorem selectedBound31878 : packedSelected [0,2,3,5,8,11,15,16,17,20,21,23,24,27,28] rootPS < 2^1333 := by decide +kernel

def env31879 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3910,2590,1297,325,1053,2668,1181,3590,324,3910,477,3900,2891,145,1386,3705,2620,1297,3087,2578,1339,257,1281,1344,2054]

theorem envBound31879 : H12AffineFastState.Bounded env31879 := by
  intro p hp
  have h : env31879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31878_31879 : H12AffineEnvironment.transform 11 3910 env31878 = env31879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3910 env31878 == env31879) = true)

def env31880 : List Nat := [2,4,8,16,32,0,128,256,512,1024,2048,3846,2590,1297,261,1053,2604,1181,3590,260,3846,413,3900,2827,145,1322,3641,2620,1297,3087,2578,1339,257,1281,1280,2054]

theorem envBound31880 : H12AffineFastState.Bounded env31880 := by
  intro p hp
  have h : env31880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31879_31880 : H12AffineEnvironment.transform 5 0 env31879 = env31880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env31879 == env31880) = true)

def env31881 : List Nat := [2,4,8,16,32,0,128,256,512,1024,1080,830,1574,1297,261,1053,1556,1181,574,260,830,413,772,1843,145,1322,513,1540,1297,55,1578,1339,257,1281,1280,1086]

theorem envBound31881 : H12AffineFastState.Bounded env31881 := by
  intro p hp
  have h : env31881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31880_31881 : H12AffineEnvironment.transform 10 1080 env31880 = env31881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1080 env31880 == env31881) = true)

theorem identity31881 : scanCanonicalize (H12AffineFastState.compose env31881 (packedSelected [0,1,2,3,5,11,15,16,17,20,21,23,24,27] rootPS)) = affineNative (2^(9+1) ^^^ 446) := by decide +kernel

theorem selectedBound31881 : packedSelected [0,1,2,3,5,11,15,16,17,20,21,23,24,27] rootPS < 2^1333 := by decide +kernel

def env31882 : List Nat := [2,4,8,16,32,0,128,256,512,446,390,830,920,175,261,419,938,291,574,260,830,413,772,653,145,148,513,954,175,55,916,133,257,191,190,384]

theorem envBound31882 : H12AffineFastState.Bounded env31882 := by
  intro p hp
  have h : env31882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31881_31882 : H12AffineEnvironment.transform 9 446 env31881 = env31882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 446 env31881 == env31882) = true)

theorem identity31882 : scanCanonicalize (H12AffineFastState.compose env31882 (packedSelected [0,1,2,4,7,8,9,10,11,12,13,20,23,32] rootPS)) = affineNative (2^(8+1) ^^^ 426) := by decide +kernel

theorem selectedBound31882 : packedSelected [0,1,2,4,7,8,9,10,11,12,13,20,23,32] rootPS < 2^1333 := by decide +kernel

def env31883 : List Nat := [2,4,8,16,32,0,128,256,426,446,390,148,50,175,261,419,0,291,404,260,148,413,174,295,145,148,427,16,175,55,62,133,257,191,190,384]

theorem envBound31883 : H12AffineFastState.Bounded env31883 := by
  intro p hp
  have h : env31883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31882_31883 : H12AffineEnvironment.transform 8 426 env31882 = env31883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 426 env31882 == env31883) = true)

theorem identity31883 : scanCanonicalize (H12AffineFastState.compose env31883 (packedSelected [1,2,13,16,17,18] rootPS)) = affineNative (2^(7+1) ^^^ 18) := by decide +kernel

theorem selectedBound31883 : packedSelected [1,2,13,16,17,18] rootPS < 2^1333 := by decide +kernel

def env31884 : List Nat := [2,4,8,16,32,0,128,18,184,172,148,148,50,175,23,177,0,49,134,22,148,143,174,53,145,148,185,16,175,55,62,133,19,191,190,146]

theorem envBound31884 : H12AffineFastState.Bounded env31884 := by
  intro p hp
  have h : env31884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31883_31884 : H12AffineEnvironment.transform 7 18 env31883 = env31884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 18 env31883 == env31884) = true)

theorem identity31884 : scanCanonicalize (H12AffineFastState.compose env31884 (packedSelected [0,1,3,5,7,10,11] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound31884 : packedSelected [0,1,3,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env31885 : List Nat := [2,4,8,16,1,0,128,18,153,141,148,148,19,142,23,144,0,16,134,22,148,143,143,20,145,148,152,16,142,22,31,133,19,158,159,146]

theorem envBound31885 : H12AffineFastState.Bounded env31885 := by
  intro p hp
  have h : env31885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31884_31885 : H12AffineEnvironment.transform 4 1 env31884 = env31885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env31884 == env31885) = true)

theorem identity31885 : scanCanonicalize (H12AffineFastState.compose env31885 (packedSelected [2,5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound31885 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env31886 : List Nat := [2,4,2,16,1,0,128,18,147,135,148,148,19,132,23,144,0,16,134,22,148,133,133,20,145,148,146,16,132,22,21,133,19,148,149,146]

theorem envBound31886 : H12AffineFastState.Bounded env31886 := by
  intro p hp
  have h : env31886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31885_31886 : H12AffineEnvironment.transform 2 2 env31885 = env31886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env31885 == env31886) = true)

theorem identity31886 : scanCanonicalize (H12AffineFastState.compose env31886 (packedSelected [0,2] rootPS)) = affineNative (2^(6+1) ^^^ 7) := by decide +kernel

theorem selectedBound31886 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env31887 : List Nat := [2,4,2,16,1,0,7,18,20,0,19,19,19,3,23,23,0,16,1,22,19,2,2,20,22,19,21,16,3,22,21,2,19,19,18,21]

theorem envBound31887 : H12AffineFastState.Bounded env31887 := by
  intro p hp
  have h : env31887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31886_31887 : H12AffineEnvironment.transform 6 7 env31886 = env31887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 7 env31886 == env31887) = true)

theorem identity31887 : scanCanonicalize (H12AffineFastState.compose env31887 (packedSelected [0,4] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound31887 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env31888 : List Nat := [2,0,2,16,1,0,3,18,16,0,19,19,19,3,19,19,0,16,1,18,19,2,2,16,18,19,17,16,3,18,17,2,19,19,18,17]

theorem envBound31888 : H12AffineFastState.Bounded env31888 := by
  intro p hp
  have h : env31888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31887_31888 : H12AffineEnvironment.transform 1 0 env31887 = env31888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env31887 == env31888) = true)

theorem identity31888 : scanCanonicalize (H12AffineFastState.compose env31888 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound31888 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env31889 : List Nat := [1,0,1,16,1,0,0,17,16,0,16,16,16,0,16,16,0,16,1,17,16,1,1,16,17,16,17,16,0,17,17,1,16,16,17,17]

theorem envBound31889 : H12AffineFastState.Bounded env31889 := by
  intro p hp
  have h : env31889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31888_31889 : H12AffineEnvironment.transform 0 1 env31888 = env31889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env31888 == env31889) = true)

theorem identity31889 : scanCanonicalize (H12AffineFastState.compose env31889 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound31889 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31890 : List Nat := [1,0,1,0,1,0,0,1,0,0,0,0,0,0,0,0,0,0,1,1,0,1,1,0,1,0,1,0,0,1,1,1,0,0,1,1]

theorem envBound31890 : H12AffineFastState.Bounded env31890 := by
  intro p hp
  have h : env31890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31889_31890 : H12AffineEnvironment.transform 3 0 env31889 = env31890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env31889 == env31890) = true)

def env31891 : List Nat := [2,4,8,16,32,0,128,256,512,1024,1081,831,1575,1297,261,1053,1557,1181,575,260,831,413,773,1842,145,1322,512,1541,1297,54,1579,1339,257,1281,1280,1087]

theorem envBound31891 : H12AffineFastState.Bounded env31891 := by
  intro p hp
  have h : env31891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31880_31891 : H12AffineEnvironment.transform 10 1081 env31880 = env31891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1081 env31880 == env31891) = true)

theorem identity31891 : scanCanonicalize (H12AffineFastState.compose env31891 (packedSelected [0,1,2,3,5,11,15,16,17,20,21,23,24,27] rootPS)) = affineNative (2^(9+1) ^^^ 683) := by decide +kernel

theorem selectedBound31891 : packedSelected [0,1,2,3,5,11,15,16,17,20,21,23,24,27] rootPS < 2^1333 := by decide +kernel

def env31892 : List Nat := [2,4,8,16,32,0,128,256,512,683,658,831,140,954,261,694,190,566,575,260,831,413,773,409,145,897,512,174,954,54,128,912,257,938,939,660]

theorem envBound31892 : H12AffineFastState.Bounded env31892 := by
  intro p hp
  have h : env31892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31891_31892 : H12AffineEnvironment.transform 9 683 env31891 = env31892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 683 env31891 == env31892) = true)

theorem identity31892 : scanCanonicalize (H12AffineFastState.compose env31892 (packedSelected [5,10,11,12,13,15,17,18,20,21,23] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound31892 : packedSelected [5,10,11,12,13,15,17,18,20,21,23] rootPS < 2^1333 := by decide +kernel

def env31893 : List Nat := [2,4,8,16,32,0,18,256,512,569,512,831,30,808,261,548,44,566,575,260,831,271,773,267,3,787,512,60,808,54,18,770,257,824,825,518]

theorem envBound31893 : H12AffineFastState.Bounded env31893 := by
  intro p hp
  have h : env31893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31892_31893 : H12AffineEnvironment.transform 6 18 env31892 = env31893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env31892 == env31893) = true)

theorem identity31893 : scanCanonicalize (H12AffineFastState.compose env31893 (packedSelected [1,2,3,4,9,10,11,15] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound31893 : packedSelected [1,2,3,4,9,10,11,15] rootPS < 2^1333 := by decide +kernel

def env31894 : List Nat := [2,4,8,16,32,0,18,4,512,569,512,571,30,556,1,548,44,566,575,0,571,11,513,15,3,535,512,60,556,54,18,518,5,572,573,518]

theorem envBound31894 : H12AffineFastState.Bounded env31894 := by
  intro p hp
  have h : env31894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31893_31894 : H12AffineEnvironment.transform 7 4 env31893 = env31894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env31893 == env31894) = true)

theorem identity31894 : scanCanonicalize (H12AffineFastState.compose env31894 (packedSelected [2,12,13] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound31894 : packedSelected [2,12,13] rootPS < 2^1333 := by decide +kernel

def env31895 : List Nat := [2,4,8,16,32,0,18,4,1,56,1,58,30,45,1,37,44,55,62,0,58,11,0,15,3,22,1,60,45,54,18,7,5,61,60,7]

theorem envBound31895 : H12AffineFastState.Bounded env31895 := by
  intro p hp
  have h : env31895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31894_31895 : H12AffineEnvironment.transform 8 1 env31894 = env31895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env31894 == env31895) = true)

theorem identity31895 : scanCanonicalize (H12AffineFastState.compose env31895 (packedSelected [0,1,3,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound31895 : packedSelected [0,1,3,5,7] rootPS < 2^1333 := by decide +kernel

def env31896 : List Nat := [2,4,8,16,28,0,18,4,1,4,1,6,30,17,1,25,16,11,2,0,6,11,0,15,3,22,1,0,17,10,18,7,5,1,0,7]

theorem envBound31896 : H12AffineFastState.Bounded env31896 := by
  intro p hp
  have h : env31896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31895_31896 : H12AffineEnvironment.transform 4 28 env31895 = env31896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env31895 == env31896) = true)

theorem identity31896 : scanCanonicalize (H12AffineFastState.compose env31896 (packedSelected [0,2,4] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound31896 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env31897 : List Nat := [2,4,8,13,1,0,15,4,1,4,1,6,3,12,1,4,13,11,2,0,6,11,0,15,3,11,1,0,12,10,15,7,5,1,0,7]

theorem envBound31897 : H12AffineFastState.Bounded env31897 := by
  intro p hp
  have h : env31897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31896_31897 : H12AffineEnvironment.transform 3 13 env31896 = env31897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env31896 == env31897) = true)

theorem identity31897 : scanCanonicalize (H12AffineFastState.compose env31897 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound31897 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31898 : List Nat := [2,4,3,6,1,0,4,4,1,4,1,6,3,7,1,4,6,0,2,0,6,0,0,4,3,0,1,0,7,1,4,7,5,1,0,7]

theorem envBound31898 : H12AffineFastState.Bounded env31898 := by
  intro p hp
  have h : env31898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31897_31898 : H12AffineEnvironment.transform 2 3 env31897 = env31898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env31897 == env31898) = true)

def env31899 : List Nat := [2,4,8,16,32,1,128,256,512,1024,2048,3847,2590,1297,260,1053,2605,1181,3590,261,3847,412,3900,2826,145,1323,3640,2620,1297,3087,2578,1339,257,1281,1281,2054]

theorem envBound31899 : H12AffineFastState.Bounded env31899 := by
  intro p hp
  have h : env31899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31879_31899 : H12AffineEnvironment.transform 5 1 env31879 = env31899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env31879 == env31899) = true)

def env31900 : List Nat := [2,4,8,16,32,1,128,256,512,1024,1080,831,1574,1297,260,1053,1557,1181,574,261,831,412,772,1842,145,1323,512,1540,1297,55,1578,1339,257,1281,1281,1086]

theorem envBound31900 : H12AffineFastState.Bounded env31900 := by
  intro p hp
  have h : env31900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31899_31900 : H12AffineEnvironment.transform 10 1080 env31899 = env31900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1080 env31899 == env31900) = true)

theorem identity31900 : scanCanonicalize (H12AffineFastState.compose env31900 (packedSelected [0,1,2,3,5,11,15,16,17,20,21,23,24,27] rootPS)) = affineNative (2^(9+1) ^^^ 389) := by decide +kernel

theorem selectedBound31900 : packedSelected [0,1,2,3,5,11,15,16,17,20,21,23,24,27] rootPS < 2^1333 := by decide +kernel

def env31901 : List Nat := [2,4,8,16,32,1,128,256,512,389,445,831,931,148,260,408,912,280,574,261,831,412,772,695,145,174,512,897,148,55,943,190,257,132,132,443]

theorem envBound31901 : H12AffineFastState.Bounded env31901 := by
  intro p hp
  have h : env31901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31900_31901 : H12AffineEnvironment.transform 9 389 env31900 = env31901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 389 env31900 == env31901) = true)

theorem identity31901 : scanCanonicalize (H12AffineFastState.compose env31901 (packedSelected [4,8,9,10,11,13,17,19,20,32] rootPS)) = affineNative (2^(7+1) ^^^ 128) := by decide +kernel

theorem selectedBound31901 : packedSelected [4,8,9,10,11,13,17,19,20,32] rootPS < 2^1333 := by decide +kernel

def env31902 : List Nat := [2,4,8,16,32,1,128,128,512,5,61,703,547,148,132,24,528,152,574,133,703,28,644,695,145,174,512,513,148,55,559,190,129,132,132,59]

theorem envBound31902 : H12AffineFastState.Bounded env31902 := by
  intro p hp
  have h : env31902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31901_31902 : H12AffineEnvironment.transform 7 128 env31901 = env31902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 128 env31901 == env31902) = true)

theorem identity31902 : scanCanonicalize (H12AffineFastState.compose env31902 (packedSelected [2,7,9,12,13,16] rootPS)) = affineNative (2^(8+1) ^^^ 23) := by decide +kernel

theorem selectedBound31902 : packedSelected [2,7,9,12,13,16] rootPS < 2^1333 := by decide +kernel

def env31903 : List Nat := [2,4,8,16,32,1,128,128,23,5,61,168,52,148,132,24,7,152,41,133,168,28,147,160,145,174,23,22,148,55,56,190,129,132,132,59]

theorem envBound31903 : H12AffineFastState.Bounded env31903 := by
  intro p hp
  have h : env31903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31902_31903 : H12AffineEnvironment.transform 8 23 env31902 = env31903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 23 env31902 == env31903) = true)

theorem identity31903 : scanCanonicalize (H12AffineFastState.compose env31903 (packedSelected [0,1,2,3,4,7,8,9,11] rootPS)) = affineNative (2^(6+1) ^^^ 63) := by decide +kernel

theorem selectedBound31903 : packedSelected [0,1,2,3,4,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env31904 : List Nat := [2,4,8,16,32,1,63,63,23,5,61,23,52,43,59,24,7,39,41,58,23,28,44,31,46,17,23,22,43,55,56,1,62,59,59,59]

theorem envBound31904 : H12AffineFastState.Bounded env31904 := by
  intro p hp
  have h : env31904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31903_31904 : H12AffineEnvironment.transform 6 63 env31903 = env31904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 63 env31903 == env31904) = true)

theorem identity31904 : scanCanonicalize (H12AffineFastState.compose env31904 (packedSelected [2,8] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound31904 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env31905 : List Nat := [2,4,8,16,17,1,14,14,23,5,12,23,5,26,10,24,7,22,24,11,23,28,29,31,31,17,23,22,26,6,9,1,15,10,10,10]

theorem envBound31905 : H12AffineFastState.Bounded env31905 := by
  intro p hp
  have h : env31905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31904_31905 : H12AffineEnvironment.transform 4 17 env31904 = env31905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env31904 == env31905) = true)

theorem identity31905 : scanCanonicalize (H12AffineFastState.compose env31905 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound31905 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31906 : List Nat := [2,4,8,11,10,1,14,14,12,5,12,12,5,1,10,3,7,13,3,11,12,7,6,4,4,10,12,13,1,6,9,1,15,10,10,10]

theorem envBound31906 : H12AffineFastState.Bounded env31906 := by
  intro p hp
  have h : env31906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31905_31906 : H12AffineEnvironment.transform 3 11 env31905 = env31906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env31905 == env31906) = true)

theorem identity31906 : scanCanonicalize (H12AffineFastState.compose env31906 (packedSelected [2,3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound31906 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env31907 : List Nat := [2,4,5,6,7,1,3,3,1,5,1,1,5,1,7,3,7,0,3,6,1,7,6,4,4,7,1,0,1,6,4,1,2,7,7,7]

theorem envBound31907 : H12AffineFastState.Bounded env31907 := by
  intro p hp
  have h : env31907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31906_31907 : H12AffineEnvironment.transform 2 5 env31906 = env31907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env31906 == env31907) = true)

theorem identity31907 : scanCanonicalize (H12AffineFastState.compose env31907 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound31907 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env31908 : List Nat := [2,2,3,0,1,1,3,3,1,3,1,1,3,1,1,3,1,0,3,0,1,1,0,2,2,1,1,0,1,0,2,1,2,1,1,1]

theorem envBound31908 : H12AffineFastState.Bounded env31908 := by
  intro p hp
  have h : env31908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31907_31908 : H12AffineEnvironment.transform 1 2 env31907 = env31908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env31907 == env31908) = true)

def env31909 : List Nat := [2,4,8,16,32,1,128,256,512,1024,1081,830,1575,1297,260,1053,1556,1181,575,261,830,412,773,1843,145,1323,513,1541,1297,54,1579,1339,257,1281,1281,1087]

theorem envBound31909 : H12AffineFastState.Bounded env31909 := by
  intro p hp
  have h : env31909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31899_31909 : H12AffineEnvironment.transform 10 1081 env31899 = env31909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1081 env31899 == env31909) = true)

theorem identity31909 : scanCanonicalize (H12AffineFastState.compose env31909 (packedSelected [0,1,2,3,5,11,15,16,17,20,21,23,24,27] rootPS)) = affineNative (2^(9+1) ^^^ 656) := by decide +kernel

theorem selectedBound31909 : packedSelected [0,1,2,3,5,11,15,16,17,20,21,23,24,27] rootPS < 2^1333 := by decide +kernel

def env31910 : List Nat := [2,4,8,16,32,1,128,256,512,656,681,830,183,897,260,653,132,525,575,261,830,412,773,419,145,955,513,149,897,54,187,939,257,913,913,687]

theorem envBound31910 : H12AffineFastState.Bounded env31910 := by
  intro p hp
  have h : env31910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31909_31910 : H12AffineEnvironment.transform 9 656 env31909 = env31910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 656 env31909 == env31910) = true)

theorem identity31910 : scanCanonicalize (H12AffineFastState.compose env31910 (packedSelected [0,1,3,4,5,7,9,10,11,12,15,16,18,19,21,23,24] rootPS)) = affineNative (2^(8+1) ^^^ 130) := by decide +kernel

theorem selectedBound31910 : packedSelected [0,1,3,4,5,7,9,10,11,12,15,16,18,19,21,23,24] rootPS < 2^1333 := by decide +kernel

def env31911 : List Nat := [2,4,8,16,32,1,128,256,130,18,43,444,183,259,260,15,132,143,189,261,444,412,391,419,145,313,131,149,259,54,187,297,257,275,275,45]

theorem envBound31911 : H12AffineFastState.Bounded env31911 := by
  intro p hp
  have h : env31911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31910_31911 : H12AffineEnvironment.transform 8 130 env31910 = env31911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 130 env31910 == env31911) = true)

theorem identity31911 : scanCanonicalize (H12AffineFastState.compose env31911 (packedSelected [0,1,7,10,12,17,18] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound31911 : packedSelected [0,1,7,10,12,17,18] rootPS < 2^1333 := by decide +kernel

def env31912 : List Nat := [2,4,8,16,32,1,24,256,26,18,43,292,47,259,260,15,28,23,37,261,292,260,287,315,9,313,27,13,259,54,35,297,257,275,275,45]

theorem envBound31912 : H12AffineFastState.Bounded env31912 := by
  intro p hp
  have h : env31912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31911_31912 : H12AffineEnvironment.transform 6 24 env31911 = env31912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env31911 == env31912) = true)

theorem identity31912 : scanCanonicalize (H12AffineFastState.compose env31912 (packedSelected [2,12] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound31912 : packedSelected [2,12] rootPS < 2^1333 := by decide +kernel

def env31913 : List Nat := [2,4,5,16,32,1,21,256,23,18,38,292,34,259,260,2,17,23,37,261,292,260,274,310,4,308,22,0,259,54,35,292,257,275,275,32]

theorem envBound31913 : H12AffineFastState.Bounded env31913 := by
  intro p hp
  have h : env31913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31912_31913 : H12AffineEnvironment.transform 2 5 env31912 = env31913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env31912 == env31913) = true)

theorem identity31913 : scanCanonicalize (H12AffineFastState.compose env31913 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound31913 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env31914 : List Nat := [2,4,5,16,23,1,21,256,23,18,17,275,21,259,260,2,17,23,18,261,275,260,274,257,4,259,22,0,259,1,20,275,257,275,275,23]

theorem envBound31914 : H12AffineFastState.Bounded env31914 := by
  intro p hp
  have h : env31914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31913_31914 : H12AffineEnvironment.transform 4 23 env31913 = env31914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env31913 == env31914) = true)

theorem identity31914 : scanCanonicalize (H12AffineFastState.compose env31914 (packedSelected [0,2] rootPS)) = affineNative (2^(7+1) ^^^ 18) := by decide +kernel

theorem selectedBound31914 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env31915 : List Nat := [2,4,5,16,23,1,21,18,23,18,17,1,21,17,22,2,17,23,18,23,1,22,0,19,4,17,22,0,17,1,20,1,19,1,1,23]

theorem envBound31915 : H12AffineFastState.Bounded env31915 := by
  intro p hp
  have h : env31915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31914_31915 : H12AffineEnvironment.transform 7 18 env31914 = env31915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 18 env31914 == env31915) = true)

def env31916 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74863,65665,4416,13340,4096,477,74047,69648,13769,78895,4414,74815,1297,81226,8204,65830,257,1281,1344,5952]

theorem envBound31916 : H12AffineFastState.Bounded env31916 := by
  intro p hp
  have h : env31916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31855_31916 : H12AffineEnvironment.transform 17 65665 env31855 = env31916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env31855 == env31916) = true)

theorem identity31916 : scanCanonicalize (H12AffineFastState.compose env31916 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound31916 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env31917 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,25,1297,5124,65536,66678,65665,4416,5125,4096,477,65830,69648,5584,70710,4414,66598,1297,73043,21,65830,257,1281,1344,5952]

theorem envBound31917 : H12AffineFastState.Bounded env31917 := by
  intro p hp
  have h : env31917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31916_31917 : H12AffineEnvironment.transform 12 25 env31916 = env31917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env31916 == env31917) = true)

def env31918 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,25,1297,5124,1052,106,1181,4416,5125,4096,477,1338,5132,5584,4138,4414,58,1297,6479,21,1338,257,1281,1344,5952]

theorem envBound31918 : H12AffineFastState.Bounded env31918 := by
  intro p hp
  have h : env31918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31917_31918 : H12AffineEnvironment.transform 15 1052 env31917 = env31918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1052 env31917 == env31918) = true)

theorem identity31918 : scanCanonicalize (H12AffineFastState.compose env31918 (packedSelected [0,1,2,4,7,9,10,11,15,17,19,21,23,24,28] rootPS)) = affineNative (2^(11+1) ^^^ 3587) := by decide +kernel

theorem selectedBound31918 : packedSelected [0,1,2,4,7,9,10,11,15,17,19,21,23,24,28] rootPS < 2^1333 := by decide +kernel

def env31919 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3587,25,1297,2567,1052,106,1181,3907,2566,3587,477,1338,2575,3027,3625,3901,58,1297,1868,21,1338,257,1281,1344,2371]

theorem envBound31919 : H12AffineFastState.Bounded env31919 := by
  intro p hp
  have h : env31919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31918_31919 : H12AffineEnvironment.transform 11 3587 env31918 = env31919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3587 env31918 == env31919) = true)

def env31920 : List Nat := [2,4,8,16,32,64,128,256,512,580,2048,2119,25,853,2567,600,106,729,2311,2566,2119,477,894,2575,3027,2157,2425,58,853,264,21,894,257,837,772,2371]

theorem envBound31920 : H12AffineFastState.Bounded env31920 := by
  intro p hp
  have h : env31920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31919_31920 : H12AffineEnvironment.transform 9 580 env31919 = env31920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 580 env31919 == env31920) = true)

def env31921 : List Nat := [2,4,8,16,32,64,128,256,512,580,824,895,25,853,319,600,106,729,575,318,895,477,894,311,235,853,577,58,853,264,21,894,257,837,772,635]

theorem envBound31921 : H12AffineFastState.Bounded env31921 := by
  intro p hp
  have h : env31921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31920_31921 : H12AffineEnvironment.transform 10 824 env31920 = env31921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 824 env31920 == env31921) = true)

theorem identity31921 : scanCanonicalize (H12AffineFastState.compose env31921 (packedSelected [0,2,4,7,8,9,10,11,15,17,19,21,23,24] rootPS)) = affineNative (2^(8+1) ^^^ 448) := by decide +kernel

theorem selectedBound31921 : packedSelected [0,2,4,7,8,9,10,11,15,17,19,21,23,24] rootPS < 2^1333 := by decide +kernel

def env31922 : List Nat := [2,4,8,16,32,64,128,256,448,388,248,191,25,149,319,408,106,281,511,318,191,477,190,311,235,149,385,58,149,264,21,190,257,133,196,443]

theorem envBound31922 : H12AffineFastState.Bounded env31922 := by
  intro p hp
  have h : env31922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31921_31922 : H12AffineEnvironment.transform 8 448 env31921 = env31922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 448 env31921 == env31922) = true)

theorem identity31922 : scanCanonicalize (H12AffineFastState.compose env31922 (packedSelected [0,4,12,15,16,17,18,21,23] rootPS)) = affineNative (2^(7+1) ^^^ 50) := by decide +kernel

theorem selectedBound31922 : packedSelected [0,4,12,15,16,17,18,21,23] rootPS < 2^1333 := by decide +kernel

def env31923 : List Nat := [2,4,8,16,32,64,128,50,242,182,248,191,25,149,13,170,106,43,205,12,191,239,190,5,235,149,179,58,149,58,21,190,51,133,196,137]

theorem envBound31923 : H12AffineFastState.Bounded env31923 := by
  intro p hp
  have h : env31923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31922_31923 : H12AffineEnvironment.transform 7 50 env31922 = env31923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 50 env31922 == env31923) = true)

theorem identity31923 : scanCanonicalize (H12AffineFastState.compose env31923 (packedSelected [0,5,7,8,10,13,17] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound31923 : packedSelected [0,5,7,8,10,13,17] rootPS < 2^1333 := by decide +kernel

def env31924 : List Nat := [2,4,8,16,32,16,128,50,162,182,168,191,25,149,13,170,58,43,157,12,191,191,190,5,187,149,179,58,149,58,21,190,51,133,148,137]

theorem envBound31924 : H12AffineFastState.Bounded env31924 := by
  intro p hp
  have h : env31924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31923_31924 : H12AffineEnvironment.transform 5 16 env31923 = env31924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env31923 == env31924) = true)

theorem identity31924 : scanCanonicalize (H12AffineFastState.compose env31924 (packedSelected [0,1,3,9,10,12] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound31924 : packedSelected [0,1,3,9,10,12] rootPS < 2^1333 := by decide +kernel

def env31925 : List Nat := [2,4,8,16,32,16,35,50,1,21,11,28,25,54,13,9,58,43,62,12,28,28,29,5,24,54,16,58,54,58,21,29,51,38,55,42]

theorem envBound31925 : H12AffineFastState.Bounded env31925 := by
  intro p hp
  have h : env31925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31924_31925 : H12AffineEnvironment.transform 6 35 env31924 = env31925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env31924 == env31925) = true)

theorem identity31925 : scanCanonicalize (H12AffineFastState.compose env31925 (packedSelected [1,2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound31925 : packedSelected [1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env31926 : List Nat := [2,4,8,16,13,16,14,31,1,21,11,28,25,27,13,9,23,6,19,12,28,28,29,5,24,27,16,23,27,23,21,29,30,11,26,7]

theorem envBound31926 : H12AffineFastState.Bounded env31926 := by
  intro p hp
  have h : env31926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31925_31926 : H12AffineEnvironment.transform 4 13 env31925 = env31926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env31925 == env31926) = true)

theorem identity31926 : scanCanonicalize (H12AffineFastState.compose env31926 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound31926 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env31927 : List Nat := [2,4,2,16,7,16,4,21,1,21,1,22,19,17,7,3,23,6,19,6,22,22,23,5,18,17,16,23,17,23,21,23,20,1,16,7]

theorem envBound31927 : H12AffineFastState.Bounded env31927 := by
  intro p hp
  have h : env31927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31926_31927 : H12AffineEnvironment.transform 2 2 env31926 = env31927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env31926 == env31927) = true)

def env31928 : List Nat := [2,4,8,16,32,64,128,256,512,580,825,894,25,853,318,600,106,729,574,319,894,477,894,310,234,852,576,58,853,264,21,894,257,837,772,634]

theorem envBound31928 : H12AffineFastState.Bounded env31928 := by
  intro p hp
  have h : env31928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31920_31928 : H12AffineEnvironment.transform 10 825 env31920 = env31928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 825 env31920 == env31928) = true)

theorem identity31928 : scanCanonicalize (H12AffineFastState.compose env31928 (packedSelected [0,2,4,7,8,9,10,11,15,17,19,21,23,24] rootPS)) = affineNative (2^(6+1) ^^^ 20) := by decide +kernel

theorem selectedBound31928 : packedSelected [0,2,4,7,8,9,10,11,15,17,19,21,23,24] rootPS < 2^1333 := by decide +kernel

def env31929 : List Nat := [2,4,8,16,32,64,20,256,512,580,825,894,25,853,318,600,106,589,574,319,894,329,894,310,126,852,576,58,853,264,21,894,257,837,772,634]

theorem envBound31929 : H12AffineFastState.Bounded env31929 := by
  intro p hp
  have h : env31929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31928_31929 : H12AffineEnvironment.transform 6 20 env31928 = env31929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 20 env31928 == env31929) = true)

theorem identity31929 : scanCanonicalize (H12AffineFastState.compose env31929 (packedSelected [0,1,2,5,7,11,12,17] rootPS)) = affineNative (2^(7+1) ^^^ 104) := by decide +kernel

theorem selectedBound31929 : packedSelected [0,1,2,5,7,11,12,17] rootPS < 2^1333 := by decide +kernel

def env31930 : List Nat := [2,4,8,16,32,64,20,104,512,580,593,534,25,573,86,600,106,589,574,87,534,33,534,94,126,572,576,58,573,96,21,534,105,557,620,634]

theorem envBound31930 : H12AffineFastState.Bounded env31930 := by
  intro p hp
  have h : env31930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31929_31930 : H12AffineEnvironment.transform 7 104 env31929 = env31930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 104 env31929 == env31930) = true)

theorem identity31930 : scanCanonicalize (H12AffineFastState.compose env31930 (packedSelected [3,5,7,9,10,11,12,13] rootPS)) = affineNative (2^(5+1) ^^^ 6) := by decide +kernel

theorem selectedBound31930 : packedSelected [3,5,7,9,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env31931 : List Nat := [2,4,8,16,32,6,20,46,512,514,535,534,25,573,16,542,44,523,574,17,534,33,534,24,56,572,518,58,573,38,21,534,47,557,554,572]

theorem envBound31931 : H12AffineFastState.Bounded env31931 := by
  intro p hp
  have h : env31931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31930_31931 : H12AffineEnvironment.transform 5 6 env31930 = env31931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 6 env31930 == env31931) = true)

theorem identity31931 : scanCanonicalize (H12AffineFastState.compose env31931 (packedSelected [0,2,4,5,10,11] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound31931 : packedSelected [0,2,4,5,10,11] rootPS < 2^1333 := by decide +kernel

def env31932 : List Nat := [2,3,8,16,32,1,19,41,512,514,528,529,25,570,16,537,43,523,569,17,529,33,529,24,56,571,513,58,570,33,18,529,40,554,554,571]

theorem envBound31932 : H12AffineFastState.Bounded env31932 := by
  intro p hp
  have h : env31932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31931_31932 : H12AffineEnvironment.transform 1 3 env31931 = env31932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env31931 == env31932) = true)

theorem identity31932 : scanCanonicalize (H12AffineFastState.compose env31932 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound31932 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env31933 : List Nat := [2,3,8,1,32,1,2,41,512,514,513,512,8,555,1,520,43,523,552,0,512,33,512,9,41,554,513,43,555,33,3,512,40,554,554,554]

theorem envBound31933 : H12AffineFastState.Bounded env31933 := by
  intro p hp
  have h : env31933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31932_31933 : H12AffineEnvironment.transform 3 1 env31932 = env31933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env31932 == env31933) = true)

theorem identity31933 : scanCanonicalize (H12AffineFastState.compose env31933 (packedSelected [0,1,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound31933 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env31934 : List Nat := [2,3,8,1,32,1,2,41,0,2,1,0,8,43,1,8,43,11,40,0,0,33,0,9,41,42,1,43,43,33,3,0,40,42,42,42]

theorem envBound31934 : H12AffineFastState.Bounded env31934 := by
  intro p hp
  have h : env31934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31933_31934 : H12AffineEnvironment.transform 8 0 env31933 = env31934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env31933 == env31934) = true)

theorem identity31934 : scanCanonicalize (H12AffineFastState.compose env31934 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound31934 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env31935 : List Nat := [2,3,8,1,0,1,2,9,0,2,1,0,8,11,1,8,11,11,8,0,0,1,0,9,9,10,1,11,11,1,3,0,8,10,10,10]

theorem envBound31935 : H12AffineFastState.Bounded env31935 := by
  intro p hp
  have h : env31935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31934_31935 : H12AffineEnvironment.transform 4 0 env31934 = env31935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env31934 == env31935) = true)

def env31936 : List Nat := [2,4,8,16,32,64,128,256,512,581,2048,2118,25,852,2567,601,106,728,2310,2566,2118,477,895,2575,3027,2156,2424,58,852,265,21,895,257,836,773,2371]

theorem envBound31936 : H12AffineFastState.Bounded env31936 := by
  intro p hp
  have h : env31936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31919_31936 : H12AffineEnvironment.transform 9 581 env31919 = env31936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 581 env31919 == env31936) = true)

def env31937 : List Nat := [2,4,8,16,32,64,128,256,512,581,824,894,25,852,319,601,106,728,574,318,894,477,895,311,235,852,576,58,852,265,21,895,257,836,773,635]

theorem envBound31937 : H12AffineFastState.Bounded env31937 := by
  intro p hp
  have h : env31937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31936_31937 : H12AffineEnvironment.transform 10 824 env31936 = env31937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 824 env31936 == env31937) = true)

theorem identity31937 : scanCanonicalize (H12AffineFastState.compose env31937 (packedSelected [0,2,4,7,8,9,10,11,15,17,19,21,23,24] rootPS)) = affineNative (2^(6+1) ^^^ 46) := by decide +kernel

theorem selectedBound31937 : packedSelected [0,2,4,7,8,9,10,11,15,17,19,21,23,24] rootPS < 2^1333 := by decide +kernel

def env31938 : List Nat := [2,4,8,16,32,64,46,256,512,581,824,894,25,852,319,601,106,630,574,318,894,371,895,311,69,852,576,58,852,265,21,895,257,836,773,635]

theorem envBound31938 : H12AffineFastState.Bounded env31938 := by
  intro p hp
  have h : env31938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31937_31938 : H12AffineEnvironment.transform 6 46 env31937 = env31938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 46 env31937 == env31938) = true)

theorem identity31938 : scanCanonicalize (H12AffineFastState.compose env31938 (packedSelected [2,4,5,7,8,11,13,15,16,17,18,20] rootPS)) = affineNative (2^(8+1) ^^^ 259) := by decide +kernel

theorem selectedBound31938 : packedSelected [2,4,5,7,8,11,13,15,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env31939 : List Nat := [2,4,8,16,32,64,46,256,259,326,59,125,25,87,319,346,106,373,317,318,125,371,124,311,69,87,323,58,87,265,21,124,257,71,6,376]

theorem envBound31939 : H12AffineFastState.Bounded env31939 := by
  intro p hp
  have h : env31939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31938_31939 : H12AffineEnvironment.transform 8 259 env31938 = env31939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 259 env31938 == env31939) = true)

theorem identity31939 : scanCanonicalize (H12AffineFastState.compose env31939 (packedSelected [1,2,3,7,9,11,15] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound31939 : packedSelected [1,2,3,7,9,11,15] rootPS < 2^1333 := by decide +kernel

def env31940 : List Nat := [2,4,8,16,32,64,46,69,70,3,59,125,25,87,122,31,106,48,120,123,125,54,124,114,69,87,6,58,87,76,21,124,68,71,6,61]

theorem envBound31940 : H12AffineFastState.Bounded env31940 := by
  intro p hp
  have h : env31940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31939_31940 : H12AffineEnvironment.transform 7 69 env31939 = env31940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env31939 == env31940) = true)

theorem identity31940 : scanCanonicalize (H12AffineFastState.compose env31940 (packedSelected [3,10,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 29) := by decide +kernel

theorem selectedBound31940 : packedSelected [3,10,11,12] rootPS < 2^1333 := by decide +kernel

def env31941 : List Nat := [2,4,8,16,29,64,19,69,70,3,6,64,25,87,71,31,87,13,69,70,64,11,65,79,69,87,6,7,87,76,21,65,68,71,6,0]

theorem envBound31941 : H12AffineFastState.Bounded env31941 := by
  intro p hp
  have h : env31941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31940_31941 : H12AffineEnvironment.transform 4 29 env31940 = env31941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env31940 == env31941) = true)

theorem identity31941 : scanCanonicalize (H12AffineFastState.compose env31941 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound31941 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env31942 : List Nat := [2,3,8,16,26,64,19,66,65,3,1,64,25,80,64,24,80,10,66,65,64,11,65,72,66,80,1,0,80,75,18,65,67,64,1,0]

theorem envBound31942 : H12AffineFastState.Bounded env31942 := by
  intro p hp
  have h : env31942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31941_31942 : H12AffineEnvironment.transform 1 3 env31941 = env31942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env31941 == env31942) = true)

theorem identity31942 : scanCanonicalize (H12AffineFastState.compose env31942 (packedSelected [1,2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound31942 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env31943 : List Nat := [2,3,8,16,26,17,19,19,16,3,1,17,25,1,17,24,1,10,19,16,17,11,16,25,19,1,1,0,1,26,18,16,18,17,1,0]

theorem envBound31943 : H12AffineFastState.Bounded env31943 := by
  intro p hp
  have h : env31943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31942_31943 : H12AffineEnvironment.transform 5 17 env31942 = env31943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env31942 == env31943) = true)

def env31944 : List Nat := [2,4,8,16,32,64,128,256,512,581,825,895,25,852,318,601,106,728,575,319,895,477,895,310,234,853,577,58,852,265,21,895,257,836,773,634]

theorem envBound31944 : H12AffineFastState.Bounded env31944 := by
  intro p hp
  have h : env31944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31936_31944 : H12AffineEnvironment.transform 10 825 env31936 = env31944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 825 env31936 == env31944) = true)

theorem identity31944 : scanCanonicalize (H12AffineFastState.compose env31944 (packedSelected [0,2,4,7,8,9,10,11,15,17,19,21,23,24] rootPS)) = affineNative (2^(8+1) ^^^ 507) := by decide +kernel

theorem selectedBound31944 : packedSelected [0,2,4,7,8,9,10,11,15,17,19,21,23,24] rootPS < 2^1333 := by decide +kernel

def env31945 : List Nat := [2,4,8,16,32,64,128,256,507,446,194,132,25,175,318,418,106,291,452,319,132,477,132,310,234,174,442,58,175,265,21,132,257,191,254,385]

theorem envBound31945 : H12AffineFastState.Bounded env31945 := by
  intro p hp
  have h : env31945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31944_31945 : H12AffineEnvironment.transform 8 507 env31944 = env31945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 507 env31944 == env31945) = true)

theorem identity31945 : scanCanonicalize (H12AffineFastState.compose env31945 (packedSelected [0,1,2,5,7,11,12,13,17,21] rootPS)) = affineNative (2^(7+1) ^^^ 2) := by decide +kernel

theorem selectedBound31945 : packedSelected [0,1,2,5,7,11,12,13,17,21] rootPS < 2^1333 := by decide +kernel

def env31946 : List Nat := [2,4,8,16,32,64,128,2,249,188,194,132,25,175,60,160,106,33,198,61,132,223,132,52,234,174,184,58,175,11,21,132,3,191,254,131]

theorem envBound31946 : H12AffineFastState.Bounded env31946 := by
  intro p hp
  have h : env31946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31945_31946 : H12AffineEnvironment.transform 7 2 env31945 = env31946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 2 env31945 == env31946) = true)

theorem identity31946 : scanCanonicalize (H12AffineFastState.compose env31946 (packedSelected [0,2,3,4,5,7,8,9,10,11,16] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound31946 : packedSelected [0,2,3,4,5,7,8,9,10,11,16] rootPS < 2^1333 := by decide +kernel

def env31947 : List Nat := [2,4,8,16,32,64,14,2,119,50,76,10,25,33,60,46,106,33,72,61,10,81,10,52,100,32,54,58,33,11,21,10,3,49,112,13]

theorem envBound31947 : H12AffineFastState.Bounded env31947 := by
  intro p hp
  have h : env31947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31946_31947 : H12AffineEnvironment.transform 6 14 env31946 = env31947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env31946 == env31947) = true)

theorem identity31947 : scanCanonicalize (H12AffineFastState.compose env31947 (packedSelected [1,2,3,4,5,7,10,11] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound31947 : packedSelected [1,2,3,4,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env31948 : List Nat := [2,4,8,10,32,64,14,2,109,40,76,10,3,33,38,46,106,33,72,39,10,75,10,46,100,32,44,32,33,11,15,10,3,43,106,13]

theorem envBound31948 : H12AffineFastState.Bounded env31948 := by
  intro p hp
  have h : env31948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart2