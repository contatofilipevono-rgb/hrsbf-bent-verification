import H12CloudChart2Data061

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound15155 : H12AffineFastState.Bounded env15155 := by
  intro p hp
  have h : env15155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15154_15155 : H12AffineEnvironment.transform 8 32 env15154 = env15155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env15154 == env15155) = true)

theorem identity15155 : scanCanonicalize (H12AffineFastState.compose env15155 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound15155 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15156 : List Nat := [2,4,8,16,32,16,41,37,32,53,0,1,41,1,0,2,1,0,53,1,0,32,16,34,8,16,1,1,1,1,20,33,37,32,1,32]

theorem envBound15156 : H12AffineFastState.Bounded env15156 := by
  intro p hp
  have h : env15156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15155_15156 : H12AffineEnvironment.transform 6 41 env15155 = env15156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env15155 == env15156) = true)

theorem identity15156 : scanCanonicalize (H12AffineFastState.compose env15156 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound15156 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env15157 : List Nat := [2,4,8,16,0,16,9,5,0,21,0,1,9,1,0,2,1,0,21,1,0,0,16,2,8,16,1,1,1,1,20,1,5,0,1,0]

theorem envBound15157 : H12AffineFastState.Bounded env15157 := by
  intro p hp
  have h : env15157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15156_15157 : H12AffineEnvironment.transform 4 0 env15156 = env15157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15156 == env15157) = true)

def leafEnv15157 : List Nat := [2,4,8,16,0,16,9,5,0,21,0,1,9,1,0,2,1,0,21,1,0,0,16,2,20,8,1,16,1,1,1,1,20,1,5,0,4,2,1,0,0,0,1]

def active15157 : List Nat := [0,1,2,3]

def tree15157 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15157 : H12WitnessSearch.Good tree15157 := H12GlobalWitnessIndex.good

theorem leafIdentity15157 : H12AffineFastState.composeSystem env15157 rootObs = leafEnv15157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15157 rootObs == leafEnv15157) = true)

theorem terminalChecked15157 : H12PackedTerminal.terminalCheckFast leafEnv15157 active15157 tree15157 = true := by decide +kernel

def env15158 : List Nat := [2,4,8,16,32,16,128,37,33,53,0,1,129,1,0,171,1,168,53,1,0,136,16,139,9,16,1,1,1,169,20,32,37,137,1,33]

theorem envBound15158 : H12AffineFastState.Bounded env15158 := by
  intro p hp
  have h : env15158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15154_15158 : H12AffineEnvironment.transform 8 33 env15154 = env15158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env15154 == env15158) = true)

def env15159 : List Nat := [2,4,8,16,32,17,128,256,512,1024,0,1297,8192,1296,293,65536,1296,262144,271628,292,1296,8201,17,65568,8328,270620,1,1296,271389,262145,1284,4294967296,256,4295041155,1296,512]

theorem envBound15159 : H12AffineFastState.Bounded env15159 := by
  intro p hp
  have h : env15159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15121_15159 : H12AffineEnvironment.transform 5 17 env15121 = env15159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15121 == env15159) = true)

theorem identity15159 : scanCanonicalize (H12AffineFastState.compose env15159 (packedSelected [3,8,10,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 74151) := by decide +kernel

theorem selectedBound15159 : packedSelected [3,8,10,12,15] rootPS < 2^1333 := by decide +kernel

def env15160 : List Nat := [2,4,8,16,32,17,128,256,512,1024,0,1297,8192,1296,293,65536,1296,74151,66731,292,1296,8201,17,65568,8328,65723,1,1296,67002,74150,1284,4294967296,256,4295041155,1296,512]

theorem envBound15160 : H12AffineFastState.Bounded env15160 := by
  intro p hp
  have h : env15160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15159_15160 : H12AffineEnvironment.transform 17 74151 env15159 = env15160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 74151 env15159 == env15160) = true)

theorem identity15160 : scanCanonicalize (H12AffineFastState.compose env15160 (packedSelected [0,1,2,3,4,6] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound15160 : packedSelected [0,1,2,3,4,6] rootPS < 2^1333 := by decide +kernel

def env15161 : List Nat := [2,4,8,16,32,17,128,256,512,1024,0,1297,8192,1296,293,171,1296,8460,1024,292,1296,8201,17,139,8328,16,1,1296,1297,8461,1284,4294967296,256,4294975528,1296,512]

theorem envBound15161 : H12AffineFastState.Bounded env15161 := by
  intro p hp
  have h : env15161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15160_15161 : H12AffineEnvironment.transform 15 171 env15160 = env15161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env15160 == env15161) = true)

theorem identity15161 : scanCanonicalize (H12AffineFastState.compose env15161 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound15161 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15162 : List Nat := [2,4,8,16,32,17,128,37,512,1024,0,1076,8192,1077,0,171,1077,8233,1024,1,1077,8201,17,139,8328,16,1,1077,1076,8232,1057,4294967296,37,4294975528,1077,512]

theorem envBound15162 : H12AffineFastState.Bounded env15162 := by
  intro p hp
  have h : env15162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15161_15162 : H12AffineEnvironment.transform 7 37 env15161 = env15162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env15161 == env15162) = true)

theorem identity15162 : scanCanonicalize (H12AffineFastState.compose env15162 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound15162 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env15163 : List Nat := [2,4,8,16,32,17,128,37,512,1024,0,1076,40,1077,0,171,1077,1,1024,1,1077,33,17,139,160,16,1,1077,1076,0,1057,4294967296,37,4294967296,1077,512]

theorem envBound15163 : H12AffineFastState.Bounded env15163 := by
  intro p hp
  have h : env15163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15162_15163 : H12AffineEnvironment.transform 12 40 env15162 = env15163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env15162 == env15163) = true)

theorem identity15163 : scanCanonicalize (H12AffineFastState.compose env15163 (packedSelected [2] rootPS)) = affineNative (2^(31+1) ^^^ 513) := by decide +kernel

theorem selectedBound15163 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15164 : List Nat := [2,4,8,16,32,17,128,37,512,1024,0,1076,40,1077,0,171,1077,1,1024,1,1077,33,17,139,160,16,1,1077,1076,0,1057,513,37,513,1077,512]

theorem envBound15164 : H12AffineFastState.Bounded env15164 := by
  intro p hp
  have h : env15164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15163_15164 : H12AffineEnvironment.transform 31 513 env15163 = env15164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 513 env15163 == env15164) = true)

theorem identity15164 : scanCanonicalize (H12AffineFastState.compose env15164 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound15164 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env15165 : List Nat := [2,4,8,16,32,17,128,37,136,1024,0,1076,40,1077,0,171,1077,1,1024,1,1077,33,17,139,160,16,1,1077,1076,0,1057,137,37,137,1077,136]

theorem envBound15165 : H12AffineFastState.Bounded env15165 := by
  intro p hp
  have h : env15165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15164_15165 : H12AffineEnvironment.transform 8 136 env15164 = env15165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env15164 == env15165) = true)

def env15166 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,16384,32768,65536,16384,262144,524288,32769,4097,8200,17665,98565,8328,541009,795916,1345,529408,1073741824,16453,4294967296,17473,4295074215,16384,512]

theorem envBound15166 : H12AffineFastState.Bounded env15166 := by
  intro p hp
  have h : env15166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15078_15166 : H12AffineEnvironment.transform 10 1 env15078 = env15166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env15078 == env15166) = true)

def env15167 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,1344,32768,65536,1344,262144,524288,32769,4097,8200,65,98565,8328,525329,795916,1345,529408,1073741824,1285,4294967296,257,4295074215,1344,512]

theorem envBound15167 : H12AffineFastState.Bounded env15167 := by
  intro p hp
  have h : env15167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15166_15167 : H12AffineEnvironment.transform 13 1344 env15166 = env15167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env15166 == env15167) = true)

theorem identity15167 : scanCanonicalize (H12AffineFastState.compose env15167 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 790800) := by decide +kernel

theorem selectedBound15167 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env15168 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,1344,32768,65536,1344,262144,524288,32769,4097,8200,65,98565,8328,525329,795916,1345,529408,790800,1285,4294967296,257,4295074215,1344,512]

theorem envBound15168 : H12AffineFastState.Bounded env15168 := by
  intro p hp
  have h : env15168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15167_15168 : H12AffineEnvironment.transform 29 790800 env15167 = env15168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 790800 env15167 == env15168) = true)

theorem identity15168 : scanCanonicalize (H12AffineFastState.compose env15168 (packedSelected [4,9,16] rootPS)) = affineNative (2^(18+1) ^^^ 1025) := by decide +kernel

theorem selectedBound15168 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env15169 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,1344,32768,65536,1344,262144,1025,32769,4097,8200,65,98565,8328,16,270605,1345,4097,267537,1285,4294967296,257,4295074215,1344,512]

theorem envBound15169 : H12AffineFastState.Bounded env15169 := by
  intro p hp
  have h : env15169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15168_15169 : H12AffineEnvironment.transform 18 1025 env15168 = env15169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env15168 == env15169) = true)

theorem identity15169 : scanCanonicalize (H12AffineFastState.compose env15169 (packedSelected [1,5,15,17] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound15169 : packedSelected [1,5,15,17] rootPS < 2^1333 := by decide +kernel

def env15170 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,4096,8192,1344,32768,65536,1344,262144,1025,32769,4097,8200,65,98565,8328,16,270605,1345,4097,267537,1285,4294967296,257,4295074215,1344,137]

theorem envBound15170 : H12AffineFastState.Bounded env15170 := by
  intro p hp
  have h : env15170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15169_15170 : H12AffineEnvironment.transform 8 137 env15169 = env15170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env15169 == env15170) = true)

theorem identity15170 : scanCanonicalize (H12AffineFastState.compose env15170 (packedSelected [1,5,15,21] rootPS)) = affineNative (2^(17+1) ^^^ 46393) := by decide +kernel

theorem selectedBound15170 : packedSelected [1,5,15,21] rootPS < 2^1333 := by decide +kernel

def env15171 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,4096,8192,1344,32768,65536,1344,46393,1025,32769,4097,8200,65,98565,8328,16,37940,1345,4097,41000,1285,4294967296,257,4295074215,1344,137]

theorem envBound15171 : H12AffineFastState.Bounded env15171 := by
  intro p hp
  have h : env15171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15170_15171 : H12AffineEnvironment.transform 17 46393 env15170 = env15171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 46393 env15170 == env15171) = true)

theorem identity15171 : scanCanonicalize (H12AffineFastState.compose env15171 (packedSelected [0,2,4,6,18] rootPS)) = affineNative (2^(14+1) ^^^ 5172) := by decide +kernel

theorem selectedBound15171 : packedSelected [0,2,4,6,18] rootPS < 2^1333 := by decide +kernel

def env15172 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,4096,8192,1344,5172,65536,1344,8461,1025,5173,4097,8200,65,70961,8328,16,0,1345,4097,13340,1285,4294967296,257,4295046547,1344,137]

theorem envBound15172 : H12AffineFastState.Bounded env15172 := by
  intro p hp
  have h : env15172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15171_15172 : H12AffineEnvironment.transform 14 5172 env15171 = env15172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5172 env15171 == env15172) = true)

theorem identity15172 : scanCanonicalize (H12AffineFastState.compose env15172 (packedSelected [4,9] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound15172 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env15173 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,1296,8192,1344,292,65536,1344,8461,1025,293,1297,8200,65,65569,8328,16,0,1345,1297,8460,1285,4294967296,257,4295041155,1344,137]

theorem envBound15173 : H12AffineFastState.Bounded env15173 := by
  intro p hp
  have h : env15173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15172_15173 : H12AffineEnvironment.transform 11 1296 env15172 = env15173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env15172 == env15173) = true)

theorem identity15173 : scanCanonicalize (H12AffineFastState.compose env15173 (packedSelected [1,3,5] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound15173 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env15174 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,1296,9,1344,292,65536,1344,260,1025,293,1297,1,65,65569,129,16,0,1345,1297,261,1285,4294967296,257,4295032970,1344,137]

theorem envBound15174 : H12AffineFastState.Bounded env15174 := by
  intro p hp
  have h : env15174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15173_15174 : H12AffineEnvironment.transform 12 9 env15173 = env15174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env15173 == env15174) = true)

def env15175 : List Nat := [2,4,8,16,32,16,128,256,137,1024,1,1296,9,1296,292,65536,1296,260,1025,293,1297,1,17,65569,129,16,0,1297,1297,261,1285,4294967296,257,4295032970,1296,137]

theorem envBound15175 : H12AffineFastState.Bounded env15175 := by
  intro p hp
  have h : env15175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15174_15175 : H12AffineEnvironment.transform 5 16 env15174 = env15175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15174 == env15175) = true)

theorem identity15175 : scanCanonicalize (H12AffineFastState.compose env15175 (packedSelected [1,3] rootPS)) = affineNative (2^(31+1) ^^^ 137) := by decide +kernel

theorem selectedBound15175 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15176 : List Nat := [2,4,8,16,32,16,128,256,137,1024,1,1296,9,1296,292,65536,1296,260,1025,293,1297,1,17,65569,129,16,0,1297,1297,261,1285,137,257,65539,1296,137]

theorem envBound15176 : H12AffineFastState.Bounded env15176 := by
  intro p hp
  have h : env15176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15175_15176 : H12AffineEnvironment.transform 31 137 env15175 = env15176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 137 env15175 == env15176) = true)

def env15177 : List Nat := [2,4,8,16,32,16,128,256,137,272,1,0,9,0,292,65536,0,260,273,293,1,1,17,65569,129,16,0,1,1,261,21,137,257,65539,0,137]

theorem envBound15177 : H12AffineFastState.Bounded env15177 := by
  intro p hp
  have h : env15177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15176_15177 : H12AffineEnvironment.transform 9 272 env15176 = env15177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env15176 == env15177) = true)

theorem identity15177 : scanCanonicalize (H12AffineFastState.compose env15177 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound15177 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15178 : List Nat := [2,4,8,16,32,16,128,4,137,20,1,0,9,0,32,65536,0,0,21,33,1,1,17,65569,129,16,0,1,1,1,21,137,5,65539,0,137]

theorem envBound15178 : H12AffineFastState.Bounded env15178 := by
  intro p hp
  have h : env15178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15177_15178 : H12AffineEnvironment.transform 7 4 env15177 = env15178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env15177 == env15178) = true)

def env15179 : List Nat := [2,4,8,16,32,16,128,256,137,273,1,1,9,1,292,65536,1,260,272,293,0,1,17,65569,129,16,0,0,0,261,20,137,257,65539,1,137]

theorem envBound15179 : H12AffineFastState.Bounded env15179 := by
  intro p hp
  have h : env15179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15176_15179 : H12AffineEnvironment.transform 9 273 env15176 = env15179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env15176 == env15179) = true)

theorem identity15179 : scanCanonicalize (H12AffineFastState.compose env15179 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 430) := by decide +kernel

theorem selectedBound15179 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15180 : List Nat := [2,4,8,16,32,16,128,256,137,273,1,1,9,1,292,430,1,260,272,293,0,1,17,399,129,16,0,0,0,261,20,137,257,429,1,137]

theorem envBound15180 : H12AffineFastState.Bounded env15180 := by
  intro p hp
  have h : env15180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15179_15180 : H12AffineEnvironment.transform 15 430 env15179 = env15180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 430 env15179 == env15180) = true)

def env15181 : List Nat := [2,4,8,16,32,17,128,256,137,1024,1,1296,9,1297,292,65536,1297,260,1025,293,1297,1,16,65569,129,16,0,1296,1297,261,1285,4294967296,257,4295032970,1297,137]

theorem envBound15181 : H12AffineFastState.Bounded env15181 := by
  intro p hp
  have h : env15181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15174_15181 : H12AffineEnvironment.transform 5 17 env15174 = env15181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15174 == env15181) = true)

theorem identity15181 : scanCanonicalize (H12AffineFastState.compose env15181 (packedSelected [1,3] rootPS)) = affineNative (2^(31+1) ^^^ 65571) := by decide +kernel

theorem selectedBound15181 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15182 : List Nat := [2,4,8,16,32,17,128,256,137,1024,1,1296,9,1297,292,65536,1297,260,1025,293,1297,1,16,65569,129,16,0,1296,1297,261,1285,65571,257,169,1297,137]

theorem envBound15182 : H12AffineFastState.Bounded env15182 := by
  intro p hp
  have h : env15182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15181_15182 : H12AffineEnvironment.transform 31 65571 env15181 = env15182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 65571 env15181 == env15182) = true)

theorem identity15182 : scanCanonicalize (H12AffineFastState.compose env15182 (packedSelected [0,2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound15182 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env15183 : List Nat := [2,4,8,16,32,17,128,256,137,53,1,293,9,292,292,65536,292,260,52,293,292,1,16,65569,129,16,0,293,292,261,304,65571,257,169,292,137]

theorem envBound15183 : H12AffineFastState.Bounded env15183 := by
  intro p hp
  have h : env15183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15182_15183 : H12AffineEnvironment.transform 9 53 env15182 = env15183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env15182 == env15183) = true)

def env15184 : List Nat := [2,4,8,16,32,17,128,36,137,53,1,1,9,0,0,65536,0,32,52,1,0,1,16,65569,129,16,0,1,0,33,20,65571,37,169,0,137]

theorem envBound15184 : H12AffineFastState.Bounded env15184 := by
  intro p hp
  have h : env15184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15183_15184 : H12AffineEnvironment.transform 7 36 env15183 = env15184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env15183 == env15184) = true)

def env15185 : List Nat := [2,4,8,16,0,17,128,4,137,21,1,1,9,0,0,65536,0,0,20,1,0,1,16,65537,129,16,0,1,0,1,20,65539,5,137,0,137]

theorem envBound15185 : H12AffineFastState.Bounded env15185 := by
  intro p hp
  have h : env15185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15184_15185 : H12AffineEnvironment.transform 4 0 env15184 = env15185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15184 == env15185) = true)

theorem identity15185 : scanCanonicalize (H12AffineFastState.compose env15185 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 154) := by decide +kernel

theorem selectedBound15185 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15186 : List Nat := [2,4,8,16,0,17,128,4,137,21,1,1,9,0,0,154,0,0,20,1,0,1,16,155,129,16,0,1,0,1,20,153,5,137,0,137]

theorem envBound15186 : H12AffineFastState.Bounded env15186 := by
  intro p hp
  have h : env15186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15185_15186 : H12AffineEnvironment.transform 15 154 env15185 = env15186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 154 env15185 == env15186) = true)

def env15187 : List Nat := [2,4,8,16,1,17,128,5,137,20,1,1,9,0,0,65536,0,1,21,1,0,1,16,65536,129,16,0,1,0,0,20,65538,4,136,0,137]

theorem envBound15187 : H12AffineFastState.Bounded env15187 := by
  intro p hp
  have h : env15187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15184_15187 : H12AffineEnvironment.transform 4 1 env15184 = env15187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15184 == env15187) = true)

theorem identity15187 : scanCanonicalize (H12AffineFastState.compose env15187 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 19) := by decide +kernel

theorem selectedBound15187 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15188 : List Nat := [2,4,8,16,1,17,128,5,137,20,1,1,9,0,0,19,0,1,21,1,0,1,16,19,129,16,0,1,0,0,20,17,4,136,0,137]

theorem envBound15188 : H12AffineFastState.Bounded env15188 := by
  intro p hp
  have h : env15188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15187_15188 : H12AffineEnvironment.transform 15 19 env15187 = env15188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 19 env15187 == env15188) = true)

theorem identity15188 : scanCanonicalize (H12AffineFastState.compose env15188 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound15188 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env15189 : List Nat := [2,4,8,16,1,17,24,5,17,20,1,1,9,0,0,19,0,1,21,1,0,1,16,19,25,16,0,1,0,0,20,17,4,16,0,17]

theorem envBound15189 : H12AffineFastState.Bounded env15189 := by
  intro p hp
  have h : env15189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15188_15189 : H12AffineEnvironment.transform 6 24 env15188 = env15189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env15188 == env15189) = true)

def leafEnv15189 : List Nat := [2,4,8,16,1,17,24,5,17,20,1,1,9,0,0,19,0,1,21,1,0,1,16,19,20,25,1,16,0,1,0,0,20,17,4,16,4,2,0,17,0,0,1]

def active15189 : List Nat := [0,1,2,3]

def tree15189 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15189 : H12WitnessSearch.Good tree15189 := H12GlobalWitnessIndex.good

theorem leafIdentity15189 : H12AffineFastState.composeSystem env15189 rootObs = leafEnv15189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15189 rootObs == leafEnv15189) = true)

theorem terminalChecked15189 : H12PackedTerminal.terminalCheckFast leafEnv15189 active15189 tree15189 = true := by decide +kernel

def env15190 : List Nat := [2,4,8,16,32,17,128,37,137,53,1,0,9,1,1,65536,1,33,52,0,1,1,16,65569,129,16,0,0,1,32,21,65571,36,169,1,137]

theorem envBound15190 : H12AffineFastState.Bounded env15190 := by
  intro p hp
  have h : env15190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15183_15190 : H12AffineEnvironment.transform 7 37 env15183 = env15190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env15183 == env15190) = true)

theorem identity15190 : scanCanonicalize (H12AffineFastState.compose env15190 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound15190 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15191 : List Nat := [2,4,8,16,32,17,128,37,137,53,1,0,9,1,1,171,1,33,52,0,1,1,16,138,129,16,0,0,1,32,21,136,36,169,1,137]

theorem envBound15191 : H12AffineFastState.Bounded env15191 := by
  intro p hp
  have h : env15191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15190_15191 : H12AffineEnvironment.transform 15 171 env15190 = env15191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env15190 == env15191) = true)

def env15192 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,1345,32768,65536,1345,262144,524288,32769,4097,8200,64,98565,8328,525328,795916,1345,529408,1073741824,1284,4294967296,256,4295074215,1345,512]

theorem envBound15192 : H12AffineFastState.Bounded env15192 := by
  intro p hp
  have h : env15192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15166_15192 : H12AffineEnvironment.transform 13 1345 env15166 = env15192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env15166 == env15192) = true)

theorem identity15192 : scanCanonicalize (H12AffineFastState.compose env15192 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 262145) := by decide +kernel

theorem selectedBound15192 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env15193 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,1345,32768,65536,1345,262144,524288,32769,4097,8200,64,98565,8328,525328,795916,1345,529408,262145,1284,4294967296,256,4295074215,1345,512]

theorem envBound15193 : H12AffineFastState.Bounded env15193 := by
  intro p hp
  have h : env15193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15192_15193 : H12AffineEnvironment.transform 29 262145 env15192 = env15193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 262145 env15192 == env15193) = true)

theorem identity15193 : scanCanonicalize (H12AffineFastState.compose env15193 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound15193 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env15194 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,1345,292,65536,1345,262144,524288,293,4097,8200,64,65569,8328,525328,795916,1345,529408,262145,1284,4294967296,256,4295041155,1345,512]

theorem envBound15194 : H12AffineFastState.Bounded env15194 := by
  intro p hp
  have h : env15194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15193_15194 : H12AffineEnvironment.transform 14 292 env15193 = env15194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env15193 == env15194) = true)

theorem identity15194 : scanCanonicalize (H12AffineFastState.compose env15194 (packedSelected [18,23] rootPS)) = affineNative (2^(18+1) ^^^ 271628) := by decide +kernel

theorem selectedBound15194 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env15195 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,4096,8192,1345,292,65536,1345,262144,271628,293,4097,8200,64,65569,8328,270620,0,1345,274700,262145,1284,4294967296,256,4295041155,1345,512]

theorem envBound15195 : H12AffineFastState.Bounded env15195 := by
  intro p hp
  have h : env15195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15194_15195 : H12AffineEnvironment.transform 18 271628 env15194 = env15195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 271628 env15194 == env15195) = true)

def env15196 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1296,8192,1345,292,65536,1345,262144,271628,293,1297,8200,64,65569,8328,270620,0,1345,271388,262145,1284,4294967296,256,4295041155,1345,512]

theorem envBound15196 : H12AffineFastState.Bounded env15196 := by
  intro p hp
  have h : env15196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15195_15196 : H12AffineEnvironment.transform 11 1296 env15195 = env15196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env15195 == env15196) = true)

theorem identity15196 : scanCanonicalize (H12AffineFastState.compose env15196 (packedSelected [0,7] rootPS)) = affineNative (2^(17+1) ^^^ 8460) := by decide +kernel

theorem selectedBound15196 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env15197 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1296,8192,1345,292,65536,1345,8460,1024,293,1297,8200,64,65569,8328,16,0,1345,1296,8461,1284,4294967296,256,4295041155,1345,512]

theorem envBound15197 : H12AffineFastState.Bounded env15197 := by
  intro p hp
  have h : env15197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15196_15197 : H12AffineEnvironment.transform 17 8460 env15196 = env15197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8460 env15196 == env15197) = true)

theorem identity15197 : scanCanonicalize (H12AffineFastState.compose env15197 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound15197 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env15198 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1296,41,1345,292,65536,1345,293,1024,293,1297,33,64,65569,161,16,0,1345,1296,292,1284,4294967296,256,4295033002,1345,512]

theorem envBound15198 : H12AffineFastState.Bounded env15198 := by
  intro p hp
  have h : env15198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15197_15198 : H12AffineEnvironment.transform 12 41 env15197 = env15198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env15197 == env15198) = true)

theorem identity15198 : scanCanonicalize (H12AffineFastState.compose env15198 (packedSelected [1,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound15198 : packedSelected [1,5,10] rootPS < 2^1333 := by decide +kernel

def env15199 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1296,41,1345,292,170,1345,293,1024,293,1297,33,64,139,161,16,0,1345,1296,292,1284,4294967296,256,4294967296,1345,512]

theorem envBound15199 : H12AffineFastState.Bounded env15199 := by
  intro p hp
  have h : env15199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15198_15199 : H12AffineEnvironment.transform 15 170 env15198 = env15199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env15198 == env15199) = true)

theorem identity15199 : scanCanonicalize (H12AffineFastState.compose env15199 (packedSelected [2] rootPS)) = affineNative (2^(31+1) ^^^ 885) := by decide +kernel

theorem selectedBound15199 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15200 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1296,41,1345,292,170,1345,293,1024,293,1297,33,64,139,161,16,0,1345,1296,292,1284,885,256,885,1345,512]

theorem envBound15200 : H12AffineFastState.Bounded env15200 := by
  intro p hp
  have h : env15200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15199_15200 : H12AffineEnvironment.transform 31 885 env15199 = env15200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 885 env15199 == env15200) = true)

def env15201 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1,1297,8192,1345,292,65536,1345,262144,271628,293,1296,8200,64,65569,8328,270620,0,1345,271389,262145,1284,4294967296,256,4295041155,1345,512]

theorem envBound15201 : H12AffineFastState.Bounded env15201 := by
  intro p hp
  have h : env15201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15195_15201 : H12AffineEnvironment.transform 11 1297 env15195 = env15201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env15195 == env15201) = true)

def env15202 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1,1297,8192,1297,292,65536,1297,262144,271628,293,1296,8200,16,65569,8328,270620,0,1297,271389,262145,1284,4294967296,256,4295041155,1297,512]

theorem envBound15202 : H12AffineFastState.Bounded env15202 := by
  intro p hp
  have h : env15202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15201_15202 : H12AffineEnvironment.transform 5 16 env15201 = env15202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15201 == env15202) = true)

theorem identity15202 : scanCanonicalize (H12AffineFastState.compose env15202 (packedSelected [3,8,10,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 8460) := by decide +kernel

theorem selectedBound15202 : packedSelected [3,8,10,12,15] rootPS < 2^1333 := by decide +kernel

def env15203 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1,1297,8192,1297,292,65536,1297,8460,1024,293,1296,8200,16,65569,8328,16,0,1297,1297,8461,1284,4294967296,256,4295041155,1297,512]

theorem envBound15203 : H12AffineFastState.Bounded env15203 := by
  intro p hp
  have h : env15203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15202_15203 : H12AffineEnvironment.transform 17 8460 env15202 = env15203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8460 env15202 == env15203) = true)

theorem identity15203 : scanCanonicalize (H12AffineFastState.compose env15203 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 900) := by decide +kernel

theorem selectedBound15203 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env15204 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1,1297,900,1297,292,65536,1297,648,1024,293,1296,908,16,65569,780,16,0,1297,1297,649,1284,4294967296,256,4295033607,1297,512]

theorem envBound15204 : H12AffineFastState.Bounded env15204 := by
  intro p hp
  have h : env15204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15203_15204 : H12AffineEnvironment.transform 12 900 env15203 = env15204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 900 env15203 == env15204) = true)

def env15205 : List Nat := [2,4,8,16,32,16,128,36,512,1024,1,1077,672,1077,0,65536,1077,648,1024,1,1076,680,16,65569,552,16,0,1077,1077,649,1056,4294967296,36,4295033379,1077,512]

theorem envBound15205 : H12AffineFastState.Bounded env15205 := by
  intro p hp
  have h : env15205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15204_15205 : H12AffineEnvironment.transform 7 36 env15204 = env15205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env15204 == env15205) = true)

theorem identity15205 : scanCanonicalize (H12AffineFastState.compose env15205 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 0) := by decide +kernel

theorem selectedBound15205 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15206 : List Nat := [2,4,8,16,32,16,128,36,512,1024,1,1077,672,1077,0,65536,1077,648,1024,1,1076,680,16,65569,552,16,0,1077,1077,649,1056,0,36,66083,1077,512]

theorem envBound15206 : H12AffineFastState.Bounded env15206 := by
  intro p hp
  have h : env15206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15205_15206 : H12AffineEnvironment.transform 31 0 env15205 = env15206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 0 env15205 == env15206) = true)

def env15207 : List Nat := [2,4,8,16,32,16,128,36,512,52,1,1,672,1,0,65536,1,648,52,1,0,680,16,65569,552,16,0,1,1,649,20,0,36,66083,1,512]

theorem envBound15207 : H12AffineFastState.Bounded env15207 := by
  intro p hp
  have h : env15207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15206_15207 : H12AffineEnvironment.transform 9 52 env15206 = env15207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env15206 == env15207) = true)

theorem identity15207 : scanCanonicalize (H12AffineFastState.compose env15207 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound15207 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15208 : List Nat := [2,4,8,16,32,16,128,36,512,52,1,1,672,1,0,170,1,648,52,1,0,680,16,139,552,16,0,1,1,649,20,0,36,649,1,512]

theorem envBound15208 : H12AffineFastState.Bounded env15208 := by
  intro p hp
  have h : env15208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15207_15208 : H12AffineEnvironment.transform 15 170 env15207 = env15208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env15207 == env15208) = true)

def env15209 : List Nat := [2,4,8,16,0,16,128,4,512,20,1,1,640,1,0,138,1,648,20,1,0,648,16,139,520,16,0,1,1,649,20,0,4,649,1,512]

theorem envBound15209 : H12AffineFastState.Bounded env15209 := by
  intro p hp
  have h : env15209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15208_15209 : H12AffineEnvironment.transform 4 0 env15208 = env15209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15208 == env15209) = true)

theorem identity15209 : scanCanonicalize (H12AffineFastState.compose env15209 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound15209 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15210 : List Nat := [2,4,8,16,0,16,8,4,512,20,1,1,520,1,0,2,1,512,20,1,0,512,16,3,520,16,0,1,1,513,20,0,4,513,1,512]

theorem envBound15210 : H12AffineFastState.Bounded env15210 := by
  intro p hp
  have h : env15210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15209_15210 : H12AffineEnvironment.transform 6 8 env15209 = env15210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15209 == env15210) = true)

def env15211 : List Nat := [2,4,8,16,1,16,128,5,512,21,1,1,641,1,0,139,1,648,21,1,0,649,16,139,521,16,0,1,1,649,20,0,5,649,1,512]

theorem envBound15211 : H12AffineFastState.Bounded env15211 := by
  intro p hp
  have h : env15211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15208_15211 : H12AffineEnvironment.transform 4 1 env15208 = env15211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15208 == env15211) = true)

theorem identity15211 : scanCanonicalize (H12AffineFastState.compose env15211 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound15211 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15212 : List Nat := [2,4,8,16,1,16,128,5,1,21,1,1,128,1,0,139,1,137,21,1,0,136,16,139,8,16,0,1,1,136,20,0,5,136,1,1]

theorem envBound15212 : H12AffineFastState.Bounded env15212 := by
  intro p hp
  have h : env15212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15211_15212 : H12AffineEnvironment.transform 8 1 env15211 = env15212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env15211 == env15212) = true)

def env15213 : List Nat := [2,4,8,16,32,16,128,36,512,53,1,0,672,0,0,65536,0,648,53,1,1,680,16,65569,552,16,0,0,0,649,21,0,36,66083,0,512]

theorem envBound15213 : H12AffineFastState.Bounded env15213 := by
  intro p hp
  have h : env15213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15206_15213 : H12AffineEnvironment.transform 9 53 env15206 = env15213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env15206 == env15213) = true)

def env15214 : List Nat := [2,4,8,16,32,16,40,36,512,53,1,0,520,0,0,65536,0,544,53,1,1,512,16,65569,552,16,0,0,0,545,21,0,36,66083,0,512]

theorem envBound15214 : H12AffineFastState.Bounded env15214 := by
  intro p hp
  have h : env15214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15213_15214 : H12AffineEnvironment.transform 6 40 env15213 = env15214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env15213 == env15214) = true)

def env15215 : List Nat := [2,4,8,16,32,16,41,36,512,53,1,0,521,0,0,65536,0,545,53,1,1,513,16,65569,552,16,0,0,0,544,21,0,36,66083,0,512]

theorem envBound15215 : H12AffineFastState.Bounded env15215 := by
  intro p hp
  have h : env15215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15213_15215 : H12AffineEnvironment.transform 6 41 env15213 = env15215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env15213 == env15215) = true)

theorem identity15215 : scanCanonicalize (H12AffineFastState.compose env15215 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 546) := by decide +kernel

theorem selectedBound15215 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env15216 : List Nat := [2,4,8,16,32,16,41,36,512,53,1,0,521,0,0,546,0,545,53,1,1,513,16,515,552,16,0,0,0,544,21,0,36,1,0,512]

theorem envBound15216 : H12AffineFastState.Bounded env15216 := by
  intro p hp
  have h : env15216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15215_15216 : H12AffineEnvironment.transform 15 546 env15215 = env15216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 546 env15215 == env15216) = true)

def env15217 : List Nat := [2,4,8,16,32,16,128,37,512,1024,1,1076,673,1076,1,65536,1076,648,1024,0,1077,681,16,65569,553,16,0,1076,1076,649,1057,4294967296,37,4295033378,1076,512]

theorem envBound15217 : H12AffineFastState.Bounded env15217 := by
  intro p hp
  have h : env15217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15204_15217 : H12AffineEnvironment.transform 7 37 env15204 = env15217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env15204 == env15217) = true)

theorem identity15217 : scanCanonicalize (H12AffineFastState.compose env15217 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 66219) := by decide +kernel

theorem selectedBound15217 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15218 : List Nat := [2,4,8,16,32,16,128,37,512,1024,1,1076,673,1076,1,65536,1076,648,1024,0,1077,681,16,65569,553,16,0,1076,1076,649,1057,66219,37,137,1076,512]

theorem envBound15218 : H12AffineFastState.Bounded env15218 := by
  intro p hp
  have h : env15218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15217_15218 : H12AffineEnvironment.transform 31 66219 env15217 = env15218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 66219 env15217 == env15218) = true)

def env15219 : List Nat := [2,4,8,16,32,16,128,37,512,52,1,0,673,0,1,65536,0,648,52,0,1,681,16,65569,553,16,0,0,0,649,21,66219,37,137,0,512]

theorem envBound15219 : H12AffineFastState.Bounded env15219 := by
  intro p hp
  have h : env15219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15218_15219 : H12AffineEnvironment.transform 9 52 env15218 = env15219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env15218 == env15219) = true)

def env15220 : List Nat := [2,4,8,16,32,16,128,37,136,52,1,0,41,0,1,65536,0,0,52,0,1,33,16,65569,161,16,0,0,0,1,21,65571,37,137,0,136]

theorem envBound15220 : H12AffineFastState.Bounded env15220 := by
  intro p hp
  have h : env15220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15219_15220 : H12AffineEnvironment.transform 8 136 env15219 = env15220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env15219 == env15220) = true)

theorem identity15220 : scanCanonicalize (H12AffineFastState.compose env15220 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound15220 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15221 : List Nat := [2,4,8,16,32,16,128,37,136,52,1,0,41,0,1,171,0,0,52,0,1,33,16,138,161,16,0,0,0,1,21,136,37,137,0,136]

theorem envBound15221 : H12AffineFastState.Bounded env15221 := by
  intro p hp
  have h : env15221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15220_15221 : H12AffineEnvironment.transform 15 171 env15220 = env15221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env15220 == env15221) = true)

theorem identity15221 : scanCanonicalize (H12AffineFastState.compose env15221 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound15221 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env15222 : List Nat := [2,4,8,16,0,16,128,5,136,20,1,0,9,0,1,139,0,0,20,0,1,1,16,138,129,16,0,0,0,1,21,136,5,137,0,136]

theorem envBound15222 : H12AffineFastState.Bounded env15222 := by
  intro p hp
  have h : env15222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15221_15222 : H12AffineEnvironment.transform 4 0 env15221 = env15222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15221 == env15222) = true)

def leafEnv15222 : List Nat := [2,4,8,16,0,16,128,5,136,20,1,0,9,0,1,139,0,0,20,0,1,1,16,138,21,129,1,16,0,0,0,1,21,136,5,137,4,3,0,136,0,1,1]

def active15222 : List Nat := [0,1,2,3,6]

def tree15222 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15222 : H12WitnessSearch.Good tree15222 := H12GlobalWitnessIndex.good

theorem leafIdentity15222 : H12AffineFastState.composeSystem env15222 rootObs = leafEnv15222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15222 rootObs == leafEnv15222) = true)

theorem terminalChecked15222 : H12PackedTerminal.terminalCheckFast leafEnv15222 active15222 tree15222 = true := by decide +kernel

def env15223 : List Nat := [2,4,8,16,32,16,128,37,137,52,1,0,40,0,1,65536,0,1,52,0,1,32,16,65569,160,16,0,0,0,0,21,65570,37,137,0,137]

theorem envBound15223 : H12AffineFastState.Bounded env15223 := by
  intro p hp
  have h : env15223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15219_15223 : H12AffineEnvironment.transform 8 137 env15219 = env15223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env15219 == env15223) = true)

theorem identity15223 : scanCanonicalize (H12AffineFastState.compose env15223 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound15223 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15224 : List Nat := [2,4,8,16,32,16,41,37,32,52,1,0,40,0,1,65536,0,1,52,0,1,32,16,65569,9,16,0,0,0,0,21,65570,37,32,0,32]

theorem envBound15224 : H12AffineFastState.Bounded env15224 := by
  intro p hp
  have h : env15224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15223_15224 : H12AffineEnvironment.transform 6 41 env15223 = env15224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env15223 == env15224) = true)

theorem identity15224 : scanCanonicalize (H12AffineFastState.compose env15224 (packedSelected [4,6] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound15224 : packedSelected [4,6] rootPS < 2^1333 := by decide +kernel

def env15225 : List Nat := [2,4,8,16,32,16,41,37,32,52,1,0,40,0,1,3,0,1,52,0,1,32,16,34,9,16,0,0,0,0,21,33,37,32,0,32]

theorem envBound15225 : H12AffineFastState.Bounded env15225 := by
  intro p hp
  have h : env15225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15224_15225 : H12AffineEnvironment.transform 15 3 env15224 = env15225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env15224 == env15225) = true)

theorem identity15225 : scanCanonicalize (H12AffineFastState.compose env15225 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound15225 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env15226 : List Nat := [2,4,8,16,0,16,9,5,0,20,1,0,8,0,1,3,0,1,20,0,1,0,16,2,9,16,0,0,0,0,21,1,5,0,0,0]

theorem envBound15226 : H12AffineFastState.Bounded env15226 := by
  intro p hp
  have h : env15226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15225_15226 : H12AffineEnvironment.transform 4 0 env15225 = env15226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15225 == env15226) = true)

def leafEnv15226 : List Nat := [2,4,8,16,0,16,9,5,0,20,1,0,8,0,1,3,0,1,20,0,1,0,16,2,21,9,1,16,0,0,0,0,21,1,5,0,4,3,0,0,0,1,1]

def active15226 : List Nat := [0,1,2,3]

def tree15226 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15226 : H12WitnessSearch.Good tree15226 := H12GlobalWitnessIndex.good

theorem leafIdentity15226 : H12AffineFastState.composeSystem env15226 rootObs = leafEnv15226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15226 rootObs == leafEnv15226) = true)

theorem terminalChecked15226 : H12PackedTerminal.terminalCheckFast leafEnv15226 active15226 tree15226 = true := by decide +kernel

def env15227 : List Nat := [2,4,8,16,32,16,128,37,512,53,1,1,673,1,1,65536,1,648,53,0,0,681,16,65569,553,16,0,1,1,649,20,66219,37,137,1,512]

theorem envBound15227 : H12AffineFastState.Bounded env15227 := by
  intro p hp
  have h : env15227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15218_15227 : H12AffineEnvironment.transform 9 53 env15218 = env15227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env15218 == env15227) = true)

theorem identity15227 : scanCanonicalize (H12AffineFastState.compose env15227 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound15227 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15228 : List Nat := [2,4,8,16,32,16,128,37,512,53,1,1,673,1,1,170,1,648,53,0,0,681,16,139,553,16,0,1,1,649,20,513,37,137,1,512]

theorem envBound15228 : H12AffineFastState.Bounded env15228 := by
  intro p hp
  have h : env15228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15227_15228 : H12AffineEnvironment.transform 15 170 env15227 = env15228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env15227 == env15228) = true)

def env15229 : List Nat := [2,4,8,16,32,16,128,37,32,53,1,1,129,1,1,170,1,168,53,0,0,137,16,139,9,16,0,1,1,169,20,33,37,137,1,32]

theorem envBound15229 : H12AffineFastState.Bounded env15229 := by
  intro p hp
  have h : env15229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15228_15229 : H12AffineEnvironment.transform 8 32 env15228 = env15229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env15228 == env15229) = true)

theorem identity15229 : scanCanonicalize (H12AffineFastState.compose env15229 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound15229 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15230 : List Nat := [2,4,8,16,32,16,41,37,32,53,1,1,40,1,1,3,1,1,53,0,0,32,16,34,9,16,0,1,1,0,20,33,37,32,1,32]

theorem envBound15230 : H12AffineFastState.Bounded env15230 := by
  intro p hp
  have h : env15230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15229_15230 : H12AffineEnvironment.transform 6 41 env15229 = env15230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env15229 == env15230) = true)

theorem identity15230 : scanCanonicalize (H12AffineFastState.compose env15230 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound15230 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env15231 : List Nat := [2,4,8,16,0,16,9,5,0,21,1,1,8,1,1,3,1,1,21,0,0,0,16,2,9,16,0,1,1,0,20,1,5,0,1,0]

theorem envBound15231 : H12AffineFastState.Bounded env15231 := by
  intro p hp
  have h : env15231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15230_15231 : H12AffineEnvironment.transform 4 0 env15230 = env15231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15230 == env15231) = true)

def leafEnv15231 : List Nat := [2,4,8,16,0,16,9,5,0,21,1,1,8,1,1,3,1,1,21,0,0,0,16,2,20,9,1,16,0,1,1,0,20,1,5,0,4,3,1,0,0,0,1]

def active15231 : List Nat := [0,1,2,3]

def tree15231 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15231 : H12WitnessSearch.Good tree15231 := H12GlobalWitnessIndex.good

theorem leafIdentity15231 : H12AffineFastState.composeSystem env15231 rootObs = leafEnv15231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15231 rootObs == leafEnv15231) = true)

theorem terminalChecked15231 : H12PackedTerminal.terminalCheckFast leafEnv15231 active15231 tree15231 = true := by decide +kernel

def env15232 : List Nat := [2,4,8,16,32,16,128,37,33,53,1,1,128,1,1,170,1,169,53,0,0,136,16,139,8,16,0,1,1,168,20,32,37,137,1,33]

theorem envBound15232 : H12AffineFastState.Bounded env15232 := by
  intro p hp
  have h : env15232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15228_15232 : H12AffineEnvironment.transform 8 33 env15228 = env15232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env15228 == env15232) = true)

def env15233 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1,1297,8192,1296,292,65536,1296,262144,271628,293,1296,8200,17,65569,8328,270620,0,1296,271389,262145,1284,4294967296,256,4295041155,1296,512]

theorem envBound15233 : H12AffineFastState.Bounded env15233 := by
  intro p hp
  have h : env15233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15201_15233 : H12AffineEnvironment.transform 5 17 env15201 = env15233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15201 == env15233) = true)

theorem identity15233 : scanCanonicalize (H12AffineFastState.compose env15233 (packedSelected [3,8,10,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 74150) := by decide +kernel

theorem selectedBound15233 : packedSelected [3,8,10,12,15] rootPS < 2^1333 := by decide +kernel

def env15234 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1,1297,8192,1296,292,65536,1296,74150,66730,293,1296,8200,17,65569,8328,65722,0,1296,67003,74151,1284,4294967296,256,4295041155,1296,512]

theorem envBound15234 : H12AffineFastState.Bounded env15234 := by
  intro p hp
  have h : env15234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15233_15234 : H12AffineEnvironment.transform 17 74150 env15233 = env15234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 74150 env15233 == env15234) = true)

theorem identity15234 : scanCanonicalize (H12AffineFastState.compose env15234 (packedSelected [0,1,2,3,4,6] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound15234 : packedSelected [0,1,2,3,4,6] rootPS < 2^1333 := by decide +kernel

def env15235 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1,1297,8192,1296,292,170,1296,8460,1024,293,1296,8200,17,139,8328,16,0,1296,1297,8461,1284,4294967296,256,4294975529,1296,512]

theorem envBound15235 : H12AffineFastState.Bounded env15235 := by
  intro p hp
  have h : env15235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15234_15235 : H12AffineEnvironment.transform 15 170 env15234 = env15235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env15234 == env15235) = true)

theorem identity15235 : scanCanonicalize (H12AffineFastState.compose env15235 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound15235 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15236 : List Nat := [2,4,8,16,32,17,128,37,512,1024,1,1076,8192,1077,1,170,1077,8233,1024,0,1077,8200,17,139,8328,16,0,1077,1076,8232,1057,4294967296,37,4294975529,1077,512]

theorem envBound15236 : H12AffineFastState.Bounded env15236 := by
  intro p hp
  have h : env15236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15235_15236 : H12AffineEnvironment.transform 7 37 env15235 = env15236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env15235 == env15236) = true)

theorem identity15236 : scanCanonicalize (H12AffineFastState.compose env15236 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound15236 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env15237 : List Nat := [2,4,8,16,32,17,128,37,512,1024,1,1076,41,1077,1,170,1077,0,1024,0,1077,33,17,139,161,16,0,1077,1076,1,1057,4294967296,37,4294967296,1077,512]

theorem envBound15237 : H12AffineFastState.Bounded env15237 := by
  intro p hp
  have h : env15237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15236_15237 : H12AffineEnvironment.transform 12 41 env15236 = env15237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env15236 == env15237) = true)

theorem identity15237 : scanCanonicalize (H12AffineFastState.compose env15237 (packedSelected [2] rootPS)) = affineNative (2^(31+1) ^^^ 513) := by decide +kernel

theorem selectedBound15237 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15238 : List Nat := [2,4,8,16,32,17,128,37,512,1024,1,1076,41,1077,1,170,1077,0,1024,0,1077,33,17,139,161,16,0,1077,1076,1,1057,513,37,513,1077,512]

theorem envBound15238 : H12AffineFastState.Bounded env15238 := by
  intro p hp
  have h : env15238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15237_15238 : H12AffineEnvironment.transform 31 513 env15237 = env15238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 513 env15237 == env15238) = true)

theorem identity15238 : scanCanonicalize (H12AffineFastState.compose env15238 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound15238 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env15239 : List Nat := [2,4,8,16,32,17,128,37,136,1024,1,1076,41,1077,1,170,1077,0,1024,0,1077,33,17,139,161,16,0,1077,1076,1,1057,137,37,137,1077,136]

theorem envBound15239 : H12AffineFastState.Bounded env15239 := by
  intro p hp
  have h : env15239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15238_15239 : H12AffineEnvironment.transform 8 136 env15238 = env15239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env15238 == env15239) = true)

def env15240 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16385,262144,524288,32769,4097,4194304,17665,98565,8328,541009,4982020,1344,529409,1073741824,16452,4294967296,17472,4299260335,16385,512]

theorem envBound15240 : H12AffineFastState.Bounded env15240 := by
  intro p hp
  have h : env15240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14867_15240 : H12AffineEnvironment.transform 16 16385 env14867 = env15240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16385 env14867 == env15240) = true)

theorem identity15240 : scanCanonicalize (H12AffineFastState.compose env15240 (packedSelected [0,4,7,9,16,20] rootPS)) = affineNative (2^(18+1) ^^^ 4368) := by decide +kernel

theorem selectedBound15240 : packedSelected [0,4,7,9,16,20] rootPS < 2^1333 := by decide +kernel

def env15241 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16385,262144,4368,32769,4097,4194304,17665,98565,8328,20545,4461588,1344,1297,1073741824,16452,4294967296,17472,4299260335,16385,512]

theorem envBound15241 : H12AffineFastState.Bounded env15241 := by
  intro p hp
  have h : env15241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15240_15241 : H12AffineEnvironment.transform 18 4368 env15240 = env15241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4368 env15240 == env15241) = true)

theorem identity15241 : scanCanonicalize (H12AffineFastState.compose env15241 (packedSelected [5,15,17,24] rootPS)) = affineNative (2^(17+1) ^^^ 48441) := by decide +kernel

theorem selectedBound15241 : packedSelected [5,15,17,24] rootPS < 2^1333 := by decide +kernel

def env15242 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16385,48441,4368,32769,4097,4194304,17665,98565,8328,20545,4237613,1344,1297,1073741824,16452,4294967296,17472,4299260335,16385,512]

theorem envBound15242 : H12AffineFastState.Bounded env15242 := by
  intro p hp
  have h : env15242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15241_15242 : H12AffineEnvironment.transform 17 48441 env15241 = env15242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 48441 env15241 == env15242) = true)

theorem identity15242 : scanCanonicalize (H12AffineFastState.compose env15242 (packedSelected [8,12,13,28] rootPS)) = affineNative (2^(29+1) ^^^ 4201492) := by decide +kernel

theorem selectedBound15242 : packedSelected [8,12,13,28] rootPS < 2^1333 := by decide +kernel

def env15243 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16385,48441,4368,32769,4097,4194304,17665,98565,8328,20545,4237613,1344,1297,4201492,16452,4294967296,17472,4299260335,16385,512]

theorem envBound15243 : H12AffineFastState.Bounded env15243 := by
  intro p hp
  have h : env15243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15242_15243 : H12AffineEnvironment.transform 29 4201492 env15242 = env15243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4201492 env15242 == env15243) = true)

def env15244 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16385,48441,4368,32769,4097,10248,17665,98565,8328,20545,33061,1344,1297,13340,16452,4294967296,17472,4295076263,16385,512]

theorem envBound15244 : H12AffineFastState.Bounded env15244 := by
  intro p hp
  have h : env15244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15243_15244 : H12AffineEnvironment.transform 21 10248 env15243 = env15244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10248 env15243 == env15244) = true)

def env15245 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16385,48441,4368,32769,4097,10249,17665,98565,8328,20545,33060,1344,1297,13341,16452,4294967296,17472,4295076262,16385,512]

theorem envBound15245 : H12AffineFastState.Bounded env15245 := by
  intro p hp
  have h : env15245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15243_15245 : H12AffineEnvironment.transform 21 10249 env15243 = env15245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10249 env15243 == env15245) = true)

theorem identity15245 : scanCanonicalize (H12AffineFastState.compose env15245 (packedSelected [11] rootPS)) = affineNative (2^(14+1) ^^^ 2340) := by decide +kernel

theorem selectedBound15245 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env15246 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,2340,65536,16385,13341,4368,2341,4097,10249,17665,67617,8328,20545,2048,1344,1297,13341,16452,4294967296,17472,4295041154,16385,512]

theorem envBound15246 : H12AffineFastState.Bounded env15246 := by
  intro p hp
  have h : env15246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15245_15246 : H12AffineEnvironment.transform 14 2340 env15245 = env15246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2340 env15245 == env15246) = true)

theorem identity15246 : scanCanonicalize (H12AffineFastState.compose env15246 (packedSelected [4,9] rootPS)) = affineNative (2^(13+1) ^^^ 11340) := by decide +kernel

theorem selectedBound15246 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env15247 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,11340,2340,65536,11341,13341,4368,2341,4097,10249,10573,67617,8328,15373,2048,1344,1297,13341,11272,4294967296,10252,4295041154,11341,512]

theorem envBound15247 : H12AffineFastState.Bounded env15247 := by
  intro p hp
  have h : env15247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15246_15247 : H12AffineEnvironment.transform 13 11340 env15246 = env15247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11340 env15246 == env15247) = true)

theorem identity15247 : scanCanonicalize (H12AffineFastState.compose env15247 (packedSelected [3,5,12,13] rootPS)) = affineNative (2^(15+1) ^^^ 8614) := by decide +kernel

theorem selectedBound15247 : packedSelected [3,5,12,13] rootPS < 2^1333 := by decide +kernel

def env15248 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,11340,2340,8614,11341,13341,4368,2341,4097,10249,10573,10631,8328,15373,2048,1344,1297,13341,11272,4294967296,10252,4294967588,11341,512]

theorem envBound15248 : H12AffineFastState.Bounded env15248 := by
  intro p hp
  have h : env15248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15247_15248 : H12AffineEnvironment.transform 15 8614 env15247 = env15248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8614 env15247 == env15248) = true)

theorem identity15248 : scanCanonicalize (H12AffineFastState.compose env15248 (packedSelected [0,1,2,3,4,6,12] rootPS)) = affineNative (2^(12+1) ^^^ 7196) := by decide +kernel

theorem selectedBound15248 : packedSelected [0,1,2,3,4,6,12] rootPS < 2^1333 := by decide +kernel

def env15249 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,7196,4176,2340,7610,4177,2049,4368,2341,4097,5141,5457,5531,7316,17,2048,1344,1297,2049,4116,4294967296,5136,4294967588,4177,512]

theorem envBound15249 : H12AffineFastState.Bounded env15249 := by
  intro p hp
  have h : env15249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15248_15249 : H12AffineEnvironment.transform 12 7196 env15248 = env15249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7196 env15248 == env15249) = true)

def env15250 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,2316,1344,2340,2218,1345,2049,1024,2341,1297,261,65,139,2436,17,2048,1344,1297,2049,1284,4294967296,256,4294967588,1345,512]

theorem envBound15250 : H12AffineFastState.Bounded env15250 := by
  intro p hp
  have h : env15250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15249_15250 : H12AffineEnvironment.transform 11 1296 env15249 = env15250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env15249 == env15250) = true)

def env15251 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1296,2316,1344,2340,2082,1345,2049,1024,2341,1297,261,65,3,2316,17,2048,1344,1297,2049,1284,4294967296,256,4294967588,1345,512]

theorem envBound15251 : H12AffineFastState.Bounded env15251 := by
  intro p hp
  have h : env15251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15250_15251 : H12AffineEnvironment.transform 6 8 env15250 = env15251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15250 == env15251) = true)

theorem identity15251 : scanCanonicalize (H12AffineFastState.compose env15251 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 593) := by decide +kernel

theorem selectedBound15251 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15252 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1296,2316,1344,2340,2082,1345,2049,1024,2341,1297,261,65,3,2316,17,2048,1344,1297,2049,1284,593,256,885,1345,512]

theorem envBound15252 : H12AffineFastState.Bounded env15252 := by
  intro p hp
  have h : env15252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15251_15252 : H12AffineEnvironment.transform 31 593 env15251 = env15252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 593 env15251 == env15252) = true)

theorem identity15252 : scanCanonicalize (H12AffineFastState.compose env15252 (packedSelected [2,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound15252 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env15253 : List Nat := [2,4,8,16,32,64,8,256,0,1024,2048,1296,2316,1344,2340,2082,1345,2049,1024,2341,1297,261,65,3,2316,17,2048,1344,1297,2049,1284,81,256,373,1345,0]

theorem envBound15253 : H12AffineFastState.Bounded env15253 := by
  intro p hp
  have h : env15253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15252_15253 : H12AffineEnvironment.transform 8 0 env15252 = env15253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env15252 == env15253) = true)

def env15254 : List Nat := [2,4,8,16,32,16,8,256,0,1024,2048,1296,2316,1296,2340,2082,1297,2049,1024,2341,1297,261,17,3,2316,17,2048,1296,1297,2049,1284,1,256,293,1297,0]

theorem envBound15254 : H12AffineFastState.Bounded env15254 := by
  intro p hp
  have h : env15254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15253_15254 : H12AffineEnvironment.transform 5 16 env15253 = env15254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15253 == env15254) = true)

theorem identity15254 : scanCanonicalize (H12AffineFastState.compose env15254 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound15254 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15255 : List Nat := [2,4,8,16,32,16,8,37,0,1024,2048,1077,2089,1077,2049,2082,1076,2049,1024,2048,1076,32,17,3,2089,17,2048,1077,1076,2049,1057,1,37,0,1076,0]

theorem envBound15255 : H12AffineFastState.Bounded env15255 := by
  intro p hp
  have h : env15255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15254_15255 : H12AffineEnvironment.transform 7 37 env15254 = env15255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env15254 == env15255) = true)

theorem identity15255 : scanCanonicalize (H12AffineFastState.compose env15255 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound15255 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15256 : List Nat := [2,4,8,16,1,16,8,4,0,1024,2048,1044,2056,1044,2049,2051,1045,2049,1024,2048,1045,1,17,3,2056,17,2048,1044,1045,2049,1024,1,4,0,1045,0]

theorem envBound15256 : H12AffineFastState.Bounded env15256 := by
  intro p hp
  have h : env15256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15255_15256 : H12AffineEnvironment.transform 4 1 env15255 = env15256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15255 == env15256) = true)

def leafEnv15256 : List Nat := [2,4,8,16,1,16,8,4,0,1024,2048,1044,2056,1044,2049,2051,1045,2049,1024,2048,1045,1,17,3,1024,2056,1,17,2048,1044,1045,2049,1024,1,4,0,4,2050,1045,0,0,1044,1]

def active15256 : List Nat := [0,1,2,3,9,10]

def tree15256 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15256 : H12WitnessSearch.Good tree15256 := H12GlobalWitnessIndex.good

theorem leafIdentity15256 : H12AffineFastState.composeSystem env15256 rootObs = leafEnv15256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15256 rootObs == leafEnv15256) = true)

theorem terminalChecked15256 : H12PackedTerminal.terminalCheckFast leafEnv15256 active15256 tree15256 = true := by decide +kernel

def env15257 : List Nat := [2,4,8,16,32,17,8,256,0,1024,2048,1296,2316,1297,2340,2082,1296,2049,1024,2341,1297,261,16,3,2316,17,2048,1297,1297,2049,1284,0,256,292,1296,0]

theorem envBound15257 : H12AffineFastState.Bounded env15257 := by
  intro p hp
  have h : env15257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15253_15257 : H12AffineEnvironment.transform 5 17 env15253 = env15257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15253 == env15257) = true)

def env15258 : List Nat := [2,4,8,16,0,17,8,256,0,1024,2048,1296,2316,1297,2308,2050,1296,2049,1024,2309,1297,261,16,3,2316,17,2048,1297,1297,2049,1284,0,256,260,1296,0]

theorem envBound15258 : H12AffineFastState.Bounded env15258 := by
  intro p hp
  have h : env15258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15257_15258 : H12AffineEnvironment.transform 4 0 env15257 = env15258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15257 == env15258) = true)

theorem identity15258 : scanCanonicalize (H12AffineFastState.compose env15258 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound15258 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15259 : List Nat := [2,4,8,16,0,17,8,4,0,1024,2048,1044,2056,1045,2048,2050,1044,2049,1024,2049,1045,1,16,3,2056,17,2048,1045,1045,2049,1024,0,4,0,1044,0]

theorem envBound15259 : H12AffineFastState.Bounded env15259 := by
  intro p hp
  have h : env15259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15258_15259 : H12AffineEnvironment.transform 7 4 env15258 = env15259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env15258 == env15259) = true)

def leafEnv15259 : List Nat := [2,4,8,16,0,17,8,4,0,1024,2048,1044,2056,1045,2048,2050,1044,2049,1024,2049,1045,1,16,3,1024,2056,1,17,2048,1045,1045,2049,1024,0,4,0,4,2051,1044,0,0,1044,1]

def active15259 : List Nat := [0,1,2,3,9,10]

def tree15259 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15259 : H12WitnessSearch.Good tree15259 := H12GlobalWitnessIndex.good

theorem leafIdentity15259 : H12AffineFastState.composeSystem env15259 rootObs = leafEnv15259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15259 rootObs == leafEnv15259) = true)

theorem terminalChecked15259 : H12PackedTerminal.terminalCheckFast leafEnv15259 active15259 tree15259 = true := by decide +kernel

def env15260 : List Nat := [2,4,8,16,1,17,8,256,0,1024,2048,1296,2316,1297,2309,2051,1296,2049,1024,2308,1297,261,16,3,2316,17,2048,1297,1297,2049,1284,0,256,261,1296,0]

theorem envBound15260 : H12AffineFastState.Bounded env15260 := by
  intro p hp
  have h : env15260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15257_15260 : H12AffineEnvironment.transform 4 1 env15257 = env15260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15257 == env15260) = true)

def leafEnv15260 : List Nat := [2,4,8,16,1,17,8,256,0,1024,2048,1296,2316,1297,2309,2051,1296,2049,1024,2308,1297,261,16,3,1284,2316,1,17,2048,1297,1297,2049,1284,0,256,261,4,2050,1296,0,0,1296,1]

def active15260 : List Nat := [0,1,2,3,7,9,10]

def tree15260 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15260 : H12WitnessSearch.Good tree15260 := H12GlobalWitnessIndex.good

theorem leafIdentity15260 : H12AffineFastState.composeSystem env15260 rootObs = leafEnv15260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15260 rootObs == leafEnv15260) = true)

theorem terminalChecked15260 : H12PackedTerminal.terminalCheckFast leafEnv15260 active15260 tree15260 = true := by decide +kernel

def env15261 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1296,2316,1344,2340,2083,1345,2049,1024,2341,1297,261,65,2,2317,17,2048,1344,1297,2049,1284,4294967296,256,4294967588,1345,512]

theorem envBound15261 : H12AffineFastState.Bounded env15261 := by
  intro p hp
  have h : env15261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15250_15261 : H12AffineEnvironment.transform 6 9 env15250 = env15261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15250 == env15261) = true)

theorem identity15261 : scanCanonicalize (H12AffineFastState.compose env15261 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 373) := by decide +kernel

theorem selectedBound15261 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15262 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1296,2316,1344,2340,2083,1345,2049,1024,2341,1297,261,65,2,2317,17,2048,1344,1297,2049,1284,373,256,81,1345,512]

theorem envBound15262 : H12AffineFastState.Bounded env15262 := by
  intro p hp
  have h : env15262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15261_15262 : H12AffineEnvironment.transform 31 373 env15261 = env15262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 373 env15261 == env15262) = true)

def env15263 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1296,2316,1296,2340,2083,1297,2049,1024,2341,1297,261,17,2,2317,17,2048,1296,1297,2049,1284,293,256,1,1297,512]

theorem envBound15263 : H12AffineFastState.Bounded env15263 := by
  intro p hp
  have h : env15263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15262_15263 : H12AffineEnvironment.transform 5 16 env15262 = env15263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15262 == env15263) = true)

theorem identity15263 : scanCanonicalize (H12AffineFastState.compose env15263 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound15263 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15264 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,1076,2088,1076,2048,2083,1077,2049,1024,2049,1077,33,17,2,2089,17,2048,1076,1077,2049,1056,1,36,1,1077,512]

theorem envBound15264 : H12AffineFastState.Bounded env15264 := by
  intro p hp
  have h : env15264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15263_15264 : H12AffineEnvironment.transform 7 36 env15263 = env15264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env15263 == env15264) = true)

theorem identity15264 : scanCanonicalize (H12AffineFastState.compose env15264 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound15264 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15265 : List Nat := [2,4,8,16,32,16,9,36,1,1024,2048,1076,2088,1076,2048,2083,1077,2049,1024,2049,1077,33,17,2,2089,17,2048,1076,1077,2049,1056,1,36,1,1077,1]

theorem envBound15265 : H12AffineFastState.Bounded env15265 := by
  intro p hp
  have h : env15265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15264_15265 : H12AffineEnvironment.transform 8 1 env15264 = env15265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env15264 == env15265) = true)

def leafEnv15265 : List Nat := [2,4,8,16,32,16,9,36,1,1024,2048,1076,2088,1076,2048,2083,1077,2049,1024,2049,1077,33,17,2,1056,2089,1,17,2048,1076,1077,2049,1056,1,36,1,4,2083,1077,1,0,1076,1]

def active15265 : List Nat := [0,1,2,3,4,9,10]

def tree15265 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15265 : H12WitnessSearch.Good tree15265 := H12GlobalWitnessIndex.good

theorem leafIdentity15265 : H12AffineFastState.composeSystem env15265 rootObs = leafEnv15265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15265 rootObs == leafEnv15265) = true)

theorem terminalChecked15265 : H12PackedTerminal.terminalCheckFast leafEnv15265 active15265 tree15265 = true := by decide +kernel

def env15266 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,1296,2316,1297,2340,2083,1296,2049,1024,2341,1297,261,16,2,2317,17,2048,1297,1297,2049,1284,292,256,0,1296,512]

theorem envBound15266 : H12AffineFastState.Bounded env15266 := by
  intro p hp
  have h : env15266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15262_15266 : H12AffineEnvironment.transform 5 17 env15262 = env15266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15262 == env15266) = true)

theorem identity15266 : scanCanonicalize (H12AffineFastState.compose env15266 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound15266 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15267 : List Nat := [2,4,8,16,32,17,9,256,0,1024,2048,1296,2316,1297,2340,2083,1296,2049,1024,2341,1297,261,16,2,2317,17,2048,1297,1297,2049,1284,292,256,0,1296,0]

theorem envBound15267 : H12AffineFastState.Bounded env15267 := by
  intro p hp
  have h : env15267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15266_15267 : H12AffineEnvironment.transform 8 0 env15266 = env15267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env15266 == env15267) = true)

def env15268 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,2317,1345,2340,2219,1344,2049,1025,2341,1296,260,64,138,2437,17,2048,1344,1297,2049,1285,4294967296,257,4294967588,1344,512]

theorem envBound15268 : H12AffineFastState.Bounded env15268 := by
  intro p hp
  have h : env15268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15249_15268 : H12AffineEnvironment.transform 11 1297 env15249 = env15268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env15249 == env15268) = true)

theorem identity15268 : scanCanonicalize (H12AffineFastState.compose env15268 (packedSelected [1,3] rootPS)) = affineNative (2^(31+1) ^^^ 852) := by decide +kernel

theorem selectedBound15268 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15269 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,2317,1345,2340,2219,1344,2049,1025,2341,1296,260,64,138,2437,17,2048,1344,1297,2049,1285,852,257,624,1344,512]

theorem envBound15269 : H12AffineFastState.Bounded env15269 := by
  intro p hp
  have h : env15269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15268_15269 : H12AffineEnvironment.transform 31 852 env15268 = env15269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 852 env15268 == env15269) = true)

theorem identity15269 : scanCanonicalize (H12AffineFastState.compose env15269 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound15269 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env15270 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1297,2317,1345,2340,2219,1344,2049,1025,2341,1296,260,64,138,2437,17,2048,1344,1297,2049,1285,477,257,249,1344,137]

theorem envBound15270 : H12AffineFastState.Bounded env15270 := by
  intro p hp
  have h : env15270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15269_15270 : H12AffineEnvironment.transform 8 137 env15269 = env15270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env15269 == env15270) = true)

def env15271 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,8914000,134217728,8519745,536870912,1073741824,562663488,4294967296,545789249,4315938986,34359738368,512]

theorem envBound15271 : H12AffineFastState.Bounded env15271 := by
  intro p hp
  have h : env15271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12205_15271 : H12AffineEnvironment.transform 27 8519745 env12205 = env15271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 8519745 env12205 == env15271) = true)

def env15272 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,8914000,134217728,8519745,536870912,1073741824,562663488,4294967296,545789249,4315938986,702907648,512]

theorem envBound15272 : H12AffineFastState.Bounded env15272 := by
  intro p hp
  have h : env15272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15271_15272 : H12AffineEnvironment.transform 34 702907648 env15271 = env15272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 702907648 env15271 == env15272) = true)

def env15273 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,8914000,134217728,8519745,2769920,1073741824,27513920,4294967296,10637633,4315938986,164610304,512]

theorem envBound15273 : H12AffineFastState.Bounded env15273 := by
  intro p hp
  have h : env15273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15272_15273 : H12AffineEnvironment.transform 28 2769920 env15272 = env15273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 2769920 env15272 == env15273) = true)

def env15274 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,4194304,8388608,16777216,8328,8914000,134217728,8519745,676864,1073741824,25412672,4294967296,8536385,4315938986,164610304,512]

theorem envBound15274 : H12AffineFastState.Bounded env15274 := by
  intro p hp
  have h : env15274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15273_15274 : H12AffineEnvironment.transform 20 4096 env15273 = env15274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env15273 == env15274) = true)

theorem identity15274 : scanCanonicalize (H12AffineFastState.compose env15274 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 644437) := by decide +kernel

theorem selectedBound15274 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env15275 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,4194304,8388608,644437,8328,8914000,134217728,8519745,676864,1073741824,9048341,4294967296,8536385,4299806207,147199061,512]

theorem envBound15275 : H12AffineFastState.Bounded env15275 := by
  intro p hp
  have h : env15275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15274_15275 : H12AffineEnvironment.transform 23 644437 env15274 = env15275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 644437 env15274 == env15275) = true)

def env15276 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,4194304,672832,644437,8328,147472,134217728,541697,676864,1073741824,21845,4294967296,525569,4299806207,139218965,512]

theorem envBound15276 : H12AffineFastState.Bounded env15276 := by
  intro p hp
  have h : env15276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15275_15276 : H12AffineEnvironment.transform 22 672832 env15275 = env15276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 672832 env15275 == env15276) = true)

theorem identity15276 : scanCanonicalize (H12AffineFastState.compose env15276 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 4176) := by decide +kernel

theorem selectedBound15276 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env15277 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,524288,32769,4096,4194304,660496,623877,8328,135232,134217728,529489,656464,1073741824,1285,4294967296,525569,4299785647,139198533,512]

theorem envBound15277 : H12AffineFastState.Bounded env15277 := by
  intro p hp
  have h : env15277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15276_15277 : H12AffineEnvironment.transform 13 4176 env15276 = env15277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env15276 == env15277) = true)

theorem identity15277 : scanCanonicalize (H12AffineFastState.compose env15277 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(29+1) ^^^ 135105934) := by decide +kernel

theorem selectedBound15277 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env15278 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,524288,32769,4096,4194304,660496,623877,8328,135232,134217728,529489,656464,135105934,1285,4294967296,525569,4299785647,139198533,512]

theorem envBound15278 : H12AffineFastState.Bounded env15278 := by
  intro p hp
  have h : env15278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15277_15278 : H12AffineEnvironment.transform 29 135105934 env15277 = env15278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 135105934 env15277 == env15278) = true)

theorem identity15278 : scanCanonicalize (H12AffineFastState.compose env15278 (packedSelected [3,5,10] rootPS)) = affineNative (2^(26+1) ^^^ 4498049) := by decide +kernel

theorem selectedBound15278 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env15279 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,524288,32769,4096,4194304,660496,623877,8328,135232,4498049,529489,656464,4796175,1285,4294967296,525569,4299785647,565956,512]

theorem envBound15279 : H12AffineFastState.Bounded env15279 := by
  intro p hp
  have h : env15279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15278_15279 : H12AffineEnvironment.transform 26 4498049 env15278 = env15279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4498049 env15278 == env15279) = true)

theorem identity15279 : scanCanonicalize (H12AffineFastState.compose env15279 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(18+1) ^^^ 42884) := by decide +kernel

theorem selectedBound15279 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env15280 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,42884,32769,4096,4194304,177044,74369,8328,135232,4498049,46037,173012,4294795,1285,4294967296,41605,4299235883,1344,512]

theorem envBound15280 : H12AffineFastState.Bounded env15280 := by
  intro p hp
  have h : env15280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15279_15280 : H12AffineEnvironment.transform 18 42884 env15279 = env15280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 42884 env15279 == env15280) = true)

def env15281 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,4194304,672833,644437,8328,147473,134217728,541696,676864,1073741824,21844,4294967296,525568,4299806207,139218964,512]

theorem envBound15281 : H12AffineFastState.Bounded env15281 := by
  intro p hp
  have h : env15281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15275_15281 : H12AffineEnvironment.transform 22 672833 env15275 = env15281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 672833 env15275 == env15281) = true)

def env15282 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,524288,32769,4096,4194304,540929,644437,8328,17745,134217728,541696,545088,1073741824,21844,4294967296,525568,4299806207,139218964,512]

theorem envBound15282 : H12AffineFastState.Bounded env15282 := by
  intro p hp
  have h : env15282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15281_15282 : H12AffineEnvironment.transform 16 1344 env15281 = env15282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env15281 == env15282) = true)

def env15283 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,1024,32769,4096,4194304,17665,119125,8328,17745,134217728,16384,21824,1073741824,21844,4294967296,256,4299280895,138695700,512]

theorem envBound15283 : H12AffineFastState.Bounded env15283 := by
  intro p hp
  have h : env15283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15282_15283 : H12AffineEnvironment.transform 18 1024 env15282 = env15283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env15282 == env15283) = true)

theorem identity15283 : scanCanonicalize (H12AffineFastState.compose env15283 (packedSelected [7,20,27] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound15283 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env15284 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,1344,262144,1024,32769,4096,4194304,5456,98564,8328,5376,134217728,4177,1297,1073741824,1285,4294967296,256,4299260334,138675269,512]

theorem envBound15284 : H12AffineFastState.Bounded env15284 := by
  intro p hp
  have h : env15284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15283_15284 : H12AffineEnvironment.transform 13 4177 env15283 = env15284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env15283 == env15284) = true)

def env15285 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4177,32768,65536,1344,262144,1024,32769,4096,4194304,5456,98564,8192,5376,134217728,4177,1297,1073741824,1285,4294967296,256,4299260198,138675269,512]

theorem envBound15285 : H12AffineFastState.Bounded env15285 := by
  intro p hp
  have h : env15285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15284_15285 : H12AffineEnvironment.transform 6 8 env15284 = env15285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15284 == env15285) = true)

theorem identity15285 : scanCanonicalize (H12AffineFastState.compose env15285 (packedSelected [10,17,41] rootPS)) = affineNative (2^(29+1) ^^^ 4530219) := by decide +kernel

theorem selectedBound15285 : packedSelected [10,17,41] rootPS < 2^1333 := by decide +kernel

def env15286 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4177,32768,65536,1344,262144,1024,32769,4096,4194304,5456,98564,8192,5376,134217728,4177,1297,4530219,1285,4294967296,256,4299260198,138675269,512]

theorem envBound15286 : H12AffineFastState.Bounded env15286 := by
  intro p hp
  have h : env15286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15285_15286 : H12AffineEnvironment.transform 29 4530219 env15285 = env15286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4530219 env15285 == env15286) = true)

theorem identity15286 : scanCanonicalize (H12AffineFastState.compose env15286 (packedSelected [3,5,8,28] rootPS)) = affineNative (2^(26+1) ^^^ 4456709) := by decide +kernel

theorem selectedBound15286 : packedSelected [3,5,8,28] rootPS < 2^1333 := by decide +kernel

def env15287 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4177,32768,65536,1344,262144,1024,32769,4096,4194304,5456,98564,8192,5376,4456709,4177,1297,4530219,1285,4294967296,256,4299260198,1344,512]

theorem envBound15287 : H12AffineFastState.Bounded env15287 := by
  intro p hp
  have h : env15287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15286_15287 : H12AffineEnvironment.transform 26 4456709 env15286 = env15287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4456709 env15286 == env15287) = true)

theorem identity15287 : scanCanonicalize (H12AffineFastState.compose env15287 (packedSelected [1,5,15,17] rootPS)) = affineNative (2^(17+1) ^^^ 76078) := by decide +kernel

theorem selectedBound15287 : packedSelected [1,5,15,17] rootPS < 2^1333 := by decide +kernel

def env15288 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4177,32768,65536,1344,76078,1024,32769,4096,4194304,5456,98564,8192,5376,4270123,4177,1297,4196613,1285,4294967296,256,4299260198,1344,512]

theorem envBound15288 : H12AffineFastState.Bounded env15288 := by
  intro p hp
  have h : env15288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15287_15288 : H12AffineEnvironment.transform 17 76078 env15287 = env15288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76078 env15287 == env15288) = true)

theorem identity15288 : scanCanonicalize (H12AffineFastState.compose env15288 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 33031) := by decide +kernel

theorem selectedBound15288 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env15289 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4177,32768,33031,1344,43049,1024,32769,4096,4194304,5456,3,8192,5376,4237612,4177,1297,4196613,1285,4294967296,256,4299161633,1344,512]

theorem envBound15289 : H12AffineFastState.Bounded env15289 := by
  intro p hp
  have h : env15289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15288_15289 : H12AffineEnvironment.transform 15 33031 env15288 = env15289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33031 env15288 == env15289) = true)

def env15290 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4177,2560,2823,1344,8745,1024,2561,4096,4194304,5456,3,8192,5376,4203308,4177,1297,4196613,1285,4294967296,256,4299161633,1344,512]

theorem envBound15290 : H12AffineFastState.Bounded env15290 := by
  intro p hp
  have h : env15290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15289_15290 : H12AffineEnvironment.transform 14 2560 env15289 = env15290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2560 env15289 == env15290) = true)

theorem identity15290 : scanCanonicalize (H12AffineFastState.compose env15290 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 5905) := by decide +kernel

theorem selectedBound15290 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15291 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4177,2560,2823,1344,8745,1024,2561,4096,4194304,5456,3,8192,5376,4203308,4177,1297,4196613,1285,5905,256,4200240,1344,512]

theorem envBound15291 : H12AffineFastState.Bounded env15291 := by
  intro p hp
  have h : env15291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15290_15291 : H12AffineEnvironment.transform 31 5905 env15290 = env15291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 5905 env15290 == env15291) = true)

def env15292 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4177,2560,2823,1344,8745,1024,2561,4096,10760,5456,3,8192,5376,2340,4177,1297,8973,1285,5905,256,15672,1344,512]

theorem envBound15292 : H12AffineFastState.Bounded env15292 := by
  intro p hp
  have h : env15292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15291_15292 : H12AffineEnvironment.transform 21 10760 env15291 = env15292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10760 env15291 == env15292) = true)

theorem identity15292 : scanCanonicalize (H12AffineFastState.compose env15292 (packedSelected [6] rootPS)) = affineNative (2^(8+1) ^^^ 373) := by decide +kernel

theorem selectedBound15292 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env15293 : List Nat := [2,4,8,16,32,64,8,256,373,1024,2048,4096,8192,4177,2421,2162,1344,8540,1024,2420,4096,10621,5456,3,8192,5376,2340,4177,1297,8312,1285,5220,256,15672,1344,373]

theorem envBound15293 : H12AffineFastState.Bounded env15293 := by
  intro p hp
  have h : env15293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15292_15293 : H12AffineEnvironment.transform 8 373 env15292 = env15293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 373 env15292 == env15293) = true)

def env15294 : List Nat := [2,4,8,16,32,64,8,256,373,1024,2048,1344,8192,1297,2421,2162,1344,8540,1024,2420,1344,10621,16,3,8192,64,2340,1297,1297,8312,1285,292,256,10360,1344,373]

theorem envBound15294 : H12AffineFastState.Bounded env15294 := by
  intro p hp
  have h : env15294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15293_15294 : H12AffineEnvironment.transform 11 1344 env15293 = env15294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env15293 == env15294) = true)

theorem identity15294 : scanCanonicalize (H12AffineFastState.compose env15294 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound15294 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env15295 : List Nat := [2,4,8,16,32,64,8,85,32,1024,2048,1045,8192,1092,2080,2162,1045,8201,1024,2081,1045,10280,16,3,8192,64,2161,1092,1092,8312,1104,113,85,10360,1045,32]

theorem envBound15295 : H12AffineFastState.Bounded env15295 := by
  intro p hp
  have h : env15295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15294_15295 : H12AffineEnvironment.transform 7 85 env15294 = env15295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env15294 == env15295) = true)

theorem identity15295 : scanCanonicalize (H12AffineFastState.compose env15295 (packedSelected [1,4] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound15295 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env15296 : List Nat := [2,4,8,16,32,64,8,85,32,1024,2048,1045,2088,1092,2080,2162,1045,2081,1024,2081,1045,0,16,3,2088,64,2161,1092,1092,2128,1104,113,85,80,1045,32]

theorem envBound15296 : H12AffineFastState.Bounded env15296 := by
  intro p hp
  have h : env15296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15295_15296 : H12AffineEnvironment.transform 12 2088 env15295 = env15296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env15295 == env15296) = true)

theorem identity15296 : scanCanonicalize (H12AffineFastState.compose env15296 (packedSelected [5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound15296 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env15297 : List Nat := [2,4,8,16,32,17,8,4,32,1024,2048,1045,2088,1045,2080,2083,1045,2081,1024,2081,1045,0,16,3,2088,17,2080,1045,1045,2049,1025,32,4,1,1045,32]

theorem envBound15297 : H12AffineFastState.Bounded env15297 := by
  intro p hp
  have h : env15297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15296_15297 : H12AffineEnvironment.transform 5 17 env15296 = env15297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15296 == env15297) = true)

theorem identity15297 : scanCanonicalize (H12AffineFastState.compose env15297 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound15297 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env15298 : List Nat := [2,4,8,16,1,17,8,4,1,1024,2048,1045,2057,1045,2049,2050,1045,2048,1024,2048,1045,0,16,3,2057,17,2049,1045,1045,2049,1025,1,4,1,1045,1]

theorem envBound15298 : H12AffineFastState.Bounded env15298 := by
  intro p hp
  have h : env15298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15297_15298 : H12AffineEnvironment.transform 4 1 env15297 = env15298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15297 == env15298) = true)

def leafEnv15298 : List Nat := [2,4,8,16,1,17,8,4,1,1024,2048,1045,2057,1045,2049,2050,1045,2048,1024,2048,1045,0,16,3,1025,2057,1,17,2049,1045,1045,2049,1025,1,4,1,4,2051,1045,1,0,1045,1]

def active15298 : List Nat := [0,1,2,3,9,10]

def tree15298 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15298 : H12WitnessSearch.Good tree15298 := H12GlobalWitnessIndex.good

theorem leafIdentity15298 : H12AffineFastState.composeSystem env15298 rootObs = leafEnv15298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15298 rootObs == leafEnv15298) = true)

theorem terminalChecked15298 : H12PackedTerminal.terminalCheckFast leafEnv15298 active15298 tree15298 = true := by decide +kernel

def env15299 : List Nat := [2,4,8,16,32,64,8,256,373,1024,2048,1345,8192,1296,2421,2162,1344,8540,1024,2420,1345,10621,17,3,8192,65,2340,1296,1297,8312,1285,293,256,10361,1344,373]

theorem envBound15299 : H12AffineFastState.Bounded env15299 := by
  intro p hp
  have h : env15299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15293_15299 : H12AffineEnvironment.transform 11 1345 env15293 = env15299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env15293 == env15299) = true)

theorem identity15299 : scanCanonicalize (H12AffineFastState.compose env15299 (packedSelected [3] rootPS)) = affineNative (2^(12+1) ^^^ 2057) := by decide +kernel

theorem selectedBound15299 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env15300 : List Nat := [2,4,8,16,32,64,8,256,373,1024,2048,1345,2057,1296,2421,2162,1344,2389,1024,2420,1345,372,17,3,2057,65,2340,1296,1297,2161,1285,293,256,112,1344,373]

theorem envBound15300 : H12AffineFastState.Bounded env15300 := by
  intro p hp
  have h : env15300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15299_15300 : H12AffineEnvironment.transform 12 2057 env15299 = env15300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2057 env15299 == env15300) = true)

theorem identity15300 : scanCanonicalize (H12AffineFastState.compose env15300 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound15300 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env15301 : List Nat := [2,4,8,16,32,64,8,5,112,1024,2048,1092,2057,1045,2160,2162,1093,2128,1024,2161,1092,113,17,3,2057,65,2081,1045,1044,2161,1024,32,5,112,1093,112]

theorem envBound15301 : H12AffineFastState.Bounded env15301 := by
  intro p hp
  have h : env15301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15300_15301 : H12AffineEnvironment.transform 7 5 env15300 = env15301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env15300 == env15301) = true)

theorem identity15301 : scanCanonicalize (H12AffineFastState.compose env15301 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound15301 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15302 : List Nat := [2,4,8,16,32,48,8,5,0,1024,2048,1076,2057,1045,2048,2050,1077,2080,1024,2049,1076,1,17,3,2057,49,2081,1045,1044,2049,1024,32,5,0,1077,0]

theorem envBound15302 : H12AffineFastState.Bounded env15302 := by
  intro p hp
  have h : env15302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15301_15302 : H12AffineEnvironment.transform 5 48 env15301 = env15302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env15301 == env15302) = true)

theorem identity15302 : scanCanonicalize (H12AffineFastState.compose env15302 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound15302 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15303 : List Nat := [2,4,8,16,0,16,8,5,0,1024,2048,1044,2057,1045,2048,2050,1045,2048,1024,2049,1044,1,17,3,2057,17,2049,1045,1044,2049,1024,0,5,0,1045,0]

theorem envBound15303 : H12AffineFastState.Bounded env15303 := by
  intro p hp
  have h : env15303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15302_15303 : H12AffineEnvironment.transform 4 0 env15302 = env15303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15302 == env15303) = true)

def leafEnv15303 : List Nat := [2,4,8,16,0,16,8,5,0,1024,2048,1044,2057,1045,2048,2050,1045,2048,1024,2049,1044,1,17,3,1024,2057,1,17,2049,1045,1044,2049,1024,0,5,0,4,2051,1045,0,0,1044,1]

def active15303 : List Nat := [0,1,2,3,9,10]

def tree15303 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15303 : H12WitnessSearch.Good tree15303 := H12GlobalWitnessIndex.good

theorem leafIdentity15303 : H12AffineFastState.composeSystem env15303 rootObs = leafEnv15303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15303 rootObs == leafEnv15303) = true)

theorem terminalChecked15303 : H12PackedTerminal.terminalCheckFast leafEnv15303 active15303 tree15303 = true := by decide +kernel

def env15304 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4177,2560,2823,1344,8745,1024,2561,4096,10761,5456,3,8192,5376,2341,4177,1297,8972,1285,5905,256,15673,1344,512]

theorem envBound15304 : H12AffineFastState.Bounded env15304 := by
  intro p hp
  have h : env15304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15291_15304 : H12AffineEnvironment.transform 21 10761 env15291 = env15304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10761 env15291 == env15304) = true)

theorem identity15304 : scanCanonicalize (H12AffineFastState.compose env15304 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 2169) := by decide +kernel

theorem selectedBound15304 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env15305 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,2169,4177,2560,2823,1344,2640,1024,2561,4096,624,5456,3,2169,5376,2341,4177,1297,2933,1285,5905,256,5440,1344,512]

theorem envBound15305 : H12AffineFastState.Bounded env15305 := by
  intro p hp
  have h : env15305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15304_15305 : H12AffineEnvironment.transform 12 2169 env15304 = env15305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2169 env15304 == env15305) = true)

def env15306 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1344,2169,1297,2560,2823,1344,2640,1024,2561,1344,624,16,3,2169,64,2341,1297,1297,2933,1285,593,256,0,1344,512]

theorem envBound15306 : H12AffineFastState.Bounded env15306 := by
  intro p hp
  have h : env15306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15305_15306 : H12AffineEnvironment.transform 11 1344 env15305 = env15306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env15305 == env15306) = true)

theorem identity15306 : scanCanonicalize (H12AffineFastState.compose env15306 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound15306 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15307 : List Nat := [2,4,8,16,32,64,8,256,32,1024,2048,1344,2169,1297,2080,2343,1344,2160,1024,2081,1344,80,16,3,2169,64,2341,1297,1297,2389,1285,113,256,0,1344,32]

theorem envBound15307 : H12AffineFastState.Bounded env15307 := by
  intro p hp
  have h : env15307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15306_15307 : H12AffineEnvironment.transform 8 32 env15306 = env15307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env15306 == env15307) = true)

theorem identity15307 : scanCanonicalize (H12AffineFastState.compose env15307 (packedSelected [3,5] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound15307 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env15308 : List Nat := [2,4,8,16,32,64,8,85,32,1024,2048,1045,2169,1092,2080,2162,1045,2160,1024,2081,1045,80,16,3,2169,64,2160,1092,1092,2048,1104,113,85,0,1045,32]

theorem envBound15308 : H12AffineFastState.Bounded env15308 := by
  intro p hp
  have h : env15308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15307_15308 : H12AffineEnvironment.transform 7 85 env15307 = env15308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env15307 == env15308) = true)

def env15309 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1345,2169,1296,2560,2823,1344,2640,1024,2561,1345,624,17,3,2169,65,2341,1296,1297,2933,1285,592,256,1,1344,512]

theorem envBound15309 : H12AffineFastState.Bounded env15309 := by
  intro p hp
  have h : env15309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15305_15309 : H12AffineEnvironment.transform 11 1345 env15305 = env15309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env15305 == env15309) = true)

theorem identity15309 : scanCanonicalize (H12AffineFastState.compose env15309 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound15309 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15310 : List Nat := [2,4,8,16,32,64,8,256,261,1024,2048,1345,2169,1296,2309,2050,1344,2389,1024,2308,1345,373,17,3,2169,65,2341,1296,1297,2160,1285,341,256,1,1344,261]

theorem envBound15310 : H12AffineFastState.Bounded env15310 := by
  intro p hp
  have h : env15310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15309_15310 : H12AffineEnvironment.transform 8 261 env15309 = env15310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env15309 == env15310) = true)

theorem identity15310 : scanCanonicalize (H12AffineFastState.compose env15310 (packedSelected [3,4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound15310 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env15311 : List Nat := [2,4,8,16,32,64,8,5,0,1024,2048,1092,2169,1045,2048,2050,1093,2128,1024,2049,1092,112,17,3,2169,65,2080,1045,1044,2160,1024,80,5,1,1093,0]

theorem envBound15311 : H12AffineFastState.Bounded env15311 := by
  intro p hp
  have h : env15311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15310_15311 : H12AffineEnvironment.transform 7 5 env15310 = env15311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env15310 == env15311) = true)

theorem identity15311 : scanCanonicalize (H12AffineFastState.compose env15311 (packedSelected [2,3] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound15311 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env15312 : List Nat := [2,4,8,16,32,49,8,5,0,1024,2048,1077,2056,1045,2048,2050,1076,2081,1024,2049,1077,1,17,3,2056,48,2080,1045,1044,2049,1024,33,5,1,1076,0]

theorem envBound15312 : H12AffineFastState.Bounded env15312 := by
  intro p hp
  have h : env15312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15311_15312 : H12AffineEnvironment.transform 5 49 env15311 = env15312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env15311 == env15312) = true)

theorem identity15312 : scanCanonicalize (H12AffineFastState.compose env15312 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound15312 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15313 : List Nat := [2,4,8,16,1,16,8,5,0,1024,2048,1044,2056,1045,2048,2050,1045,2048,1024,2049,1044,1,17,3,2056,17,2049,1045,1044,2049,1024,0,5,1,1045,0]

theorem envBound15313 : H12AffineFastState.Bounded env15313 := by
  intro p hp
  have h : env15313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15312_15313 : H12AffineEnvironment.transform 4 1 env15312 = env15313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15312 == env15313) = true)

def env15314 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4177,2561,2822,1344,8744,1024,2560,4096,4194304,5456,3,8192,5376,4203309,4177,1297,4196613,1285,4294967296,256,4299161633,1344,512]

theorem envBound15314 : H12AffineFastState.Bounded env15314 := by
  intro p hp
  have h : env15314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15289_15314 : H12AffineEnvironment.transform 14 2561 env15289 = env15314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2561 env15289 == env15314) = true)

theorem identity15314 : scanCanonicalize (H12AffineFastState.compose env15314 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 4199957) := by decide +kernel

theorem selectedBound15314 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15315 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4177,2561,2822,1344,8744,1024,2560,4096,4194304,5456,3,8192,5376,4203309,4177,1297,4196613,1285,4199957,256,5684,1344,512]

theorem envBound15315 : H12AffineFastState.Bounded env15315 := by
  intro p hp
  have h : env15315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15314_15315 : H12AffineEnvironment.transform 31 4199957 env15314 = env15315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4199957 env15314 == env15315) = true)

def env15316 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4177,2561,2822,1344,8744,1024,2560,4096,10760,5456,3,8192,5376,2341,4177,1297,8973,1285,15389,256,5684,1344,512]

theorem envBound15316 : H12AffineFastState.Bounded env15316 := by
  intro p hp
  have h : env15316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15315_15316 : H12AffineEnvironment.transform 21 10760 env15315 = env15316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10760 env15315 == env15316) = true)

theorem identity15316 : scanCanonicalize (H12AffineFastState.compose env15316 (packedSelected [6] rootPS)) = affineNative (2^(8+1) ^^^ 372) := by decide +kernel

theorem selectedBound15316 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env15317 : List Nat := [2,4,8,16,32,64,8,256,372,1024,2048,4096,8192,4177,2421,2162,1344,8540,1024,2420,4096,10620,5456,3,8192,5376,2341,4177,1297,8313,1285,15389,256,5440,1344,372]

theorem envBound15317 : H12AffineFastState.Bounded env15317 := by
  intro p hp
  have h : env15317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15316_15317 : H12AffineEnvironment.transform 8 372 env15316 = env15317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 372 env15316 == env15317) = true)

def env15318 : List Nat := [2,4,8,16,32,64,8,256,372,1024,2048,1344,8192,1297,2421,2162,1344,8540,1024,2420,1344,10620,16,3,8192,64,2341,1297,1297,8313,1285,10589,256,0,1344,372]

theorem envBound15318 : H12AffineFastState.Bounded env15318 := by
  intro p hp
  have h : env15318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15317_15318 : H12AffineEnvironment.transform 11 1344 env15317 = env15318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env15317 == env15318) = true)

theorem identity15318 : scanCanonicalize (H12AffineFastState.compose env15318 (packedSelected [3] rootPS)) = affineNative (2^(12+1) ^^^ 2348) := by decide +kernel

theorem selectedBound15318 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env15319 : List Nat := [2,4,8,16,32,64,8,256,372,1024,2048,1344,2348,1297,2421,2162,1344,2160,1024,2420,1344,80,16,3,2348,64,2341,1297,1297,2389,1285,113,256,0,1344,372]

theorem envBound15319 : H12AffineFastState.Bounded env15319 := by
  intro p hp
  have h : env15319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15318_15319 : H12AffineEnvironment.transform 12 2348 env15318 = env15319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2348 env15318 == env15319) = true)

theorem identity15319 : scanCanonicalize (H12AffineFastState.compose env15319 (packedSelected [1,4] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound15319 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env15320 : List Nat := [2,4,8,16,32,64,8,85,33,1024,2048,1045,2169,1092,2080,2162,1045,2160,1024,2081,1045,80,16,3,2169,64,2160,1092,1092,2048,1104,113,85,0,1045,33]

theorem envBound15320 : H12AffineFastState.Bounded env15320 := by
  intro p hp
  have h : env15320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15319_15320 : H12AffineEnvironment.transform 7 85 env15319 = env15320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env15319 == env15320) = true)

theorem identity15320 : scanCanonicalize (H12AffineFastState.compose env15320 (packedSelected [12] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound15320 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env15321 : List Nat := [2,4,8,16,0,64,8,85,1,1024,2048,1045,2137,1092,2048,2130,1045,2128,1024,2049,1045,80,16,3,2137,64,2128,1092,1092,2048,1104,81,85,0,1045,1]

theorem envBound15321 : H12AffineFastState.Bounded env15321 := by
  intro p hp
  have h : env15321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15320_15321 : H12AffineEnvironment.transform 4 0 env15320 = env15321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15320 == env15321) = true)

def leafEnv15321 : List Nat := [2,4,8,16,0,64,8,85,1,1024,2048,1045,2137,1092,2048,2130,1045,2128,1024,2049,1045,80,16,3,1104,2137,1,64,2128,1092,1092,2048,1104,81,85,0,4,2131,1045,1,0,1092,1]

def active15321 : List Nat := [0,1,2,3,5,9,10]

def tree15321 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15321 : H12WitnessSearch.Good tree15321 := H12GlobalWitnessIndex.good

theorem leafIdentity15321 : H12AffineFastState.composeSystem env15321 rootObs = leafEnv15321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15321 rootObs == leafEnv15321) = true)

theorem terminalChecked15321 : H12PackedTerminal.terminalCheckFast leafEnv15321 active15321 tree15321 = true := by decide +kernel

def env15322 : List Nat := [2,4,8,16,32,64,8,256,372,1024,2048,1345,8192,1296,2421,2162,1344,8540,1024,2420,1345,10620,17,3,8192,65,2341,1296,1297,8313,1285,10588,256,1,1344,372]

theorem envBound15322 : H12AffineFastState.Bounded env15322 := by
  intro p hp
  have h : env15322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15317_15322 : H12AffineEnvironment.transform 11 1345 env15317 = env15322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env15317 == env15322) = true)

theorem identity15322 : scanCanonicalize (H12AffineFastState.compose env15322 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound15322 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env15323 : List Nat := [2,4,8,16,32,49,8,256,261,1024,2048,1328,8192,1296,2308,2051,1329,8493,1024,2309,1328,10509,17,3,8192,48,2341,1296,1297,8200,1285,10541,256,1,1329,261]

theorem envBound15323 : H12AffineFastState.Bounded env15323 := by
  intro p hp
  have h : env15323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15322_15323 : H12AffineEnvironment.transform 5 49 env15322 = env15323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env15322 == env15323) = true)

theorem identity15323 : scanCanonicalize (H12AffineFastState.compose env15323 (packedSelected [1,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound15323 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env15324 : List Nat := [2,4,8,16,1,16,8,256,261,1024,2048,1297,8192,1296,2308,2051,1296,8460,1024,2309,1297,10509,17,3,8192,17,2308,1296,1297,8200,1285,10508,256,1,1296,261]

theorem envBound15324 : H12AffineFastState.Bounded env15324 := by
  intro p hp
  have h : env15324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15323_15324 : H12AffineEnvironment.transform 4 1 env15323 = env15324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15323 == env15324) = true)

theorem identity15324 : scanCanonicalize (H12AffineFastState.compose env15324 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound15324 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15325 : List Nat := [2,4,8,16,1,16,8,5,0,1024,2048,1044,8192,1045,2049,2051,1045,8201,1024,2048,1044,10248,17,3,8192,17,2049,1045,1044,8200,1024,10249,5,1,1045,0]

theorem envBound15325 : H12AffineFastState.Bounded env15325 := by
  intro p hp
  have h : env15325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15324_15325 : H12AffineEnvironment.transform 7 5 env15324 = env15325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env15324 == env15325) = true)

theorem identity15325 : scanCanonicalize (H12AffineFastState.compose env15325 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 2056) := by decide +kernel

theorem selectedBound15325 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env15326 : List Nat := [2,4,8,16,1,16,8,5,0,1024,2048,1044,2056,1045,2049,2051,1045,2049,1024,2048,1044,0,17,3,2056,17,2049,1045,1044,2048,1024,1,5,1,1045,0]

theorem envBound15326 : H12AffineFastState.Bounded env15326 := by
  intro p hp
  have h : env15326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15325_15326 : H12AffineEnvironment.transform 12 2056 env15325 = env15326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2056 env15325 == env15326) = true)

def leafEnv15326 : List Nat := [2,4,8,16,1,16,8,5,0,1024,2048,1044,2056,1045,2049,2051,1045,2049,1024,2048,1044,0,17,3,1024,2056,1,17,2049,1045,1044,2048,1024,1,5,1,4,2050,1045,0,0,1044,1]

def active15326 : List Nat := [0,1,2,3,9,10]

def tree15326 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15326 : H12WitnessSearch.Good tree15326 := H12GlobalWitnessIndex.good

theorem leafIdentity15326 : H12AffineFastState.composeSystem env15326 rootObs = leafEnv15326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15326 rootObs == leafEnv15326) = true)

theorem terminalChecked15326 : H12PackedTerminal.terminalCheckFast leafEnv15326 active15326 tree15326 = true := by decide +kernel

def env15327 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4177,2561,2822,1344,8744,1024,2560,4096,10761,5456,3,8192,5376,2340,4177,1297,8972,1285,15388,256,5684,1344,512]

theorem envBound15327 : H12AffineFastState.Bounded env15327 := by
  intro p hp
  have h : env15327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15315_15327 : H12AffineEnvironment.transform 21 10761 env15315 = env15327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10761 env15315 == env15327) = true)

theorem identity15327 : scanCanonicalize (H12AffineFastState.compose env15327 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 2168) := by decide +kernel

theorem selectedBound15327 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env15328 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,2168,4177,2561,2822,1344,2640,1024,2560,4096,625,5456,3,2168,5376,2340,4177,1297,2932,1285,5220,256,5684,1344,512]

theorem envBound15328 : H12AffineFastState.Bounded env15328 := by
  intro p hp
  have h : env15328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15327_15328 : H12AffineEnvironment.transform 12 2168 env15327 = env15328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2168 env15327 == env15328) = true)

def env15329 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1344,2168,1297,2561,2822,1344,2640,1024,2560,1344,625,16,3,2168,64,2340,1297,1297,2932,1285,292,256,884,1344,512]

theorem envBound15329 : H12AffineFastState.Bounded env15329 := by
  intro p hp
  have h : env15329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15328_15329 : H12AffineEnvironment.transform 11 1344 env15328 = env15329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env15328 == env15329) = true)

theorem identity15329 : scanCanonicalize (H12AffineFastState.compose env15329 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound15329 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15330 : List Nat := [2,4,8,16,32,64,8,85,512,1024,2048,1045,2168,1092,2561,2643,1045,2640,1024,2560,1045,625,16,3,2168,64,2161,1092,1092,2593,1104,113,85,545,1045,512]

theorem envBound15330 : H12AffineFastState.Bounded env15330 := by
  intro p hp
  have h : env15330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15329_15330 : H12AffineEnvironment.transform 7 85 env15329 = env15330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env15329 == env15330) = true)

theorem identity15330 : scanCanonicalize (H12AffineFastState.compose env15330 (packedSelected [3,5] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound15330 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env15331 : List Nat := [2,4,8,16,32,64,8,85,32,1024,2048,1045,2168,1092,2081,2163,1045,2160,1024,2080,1045,81,16,3,2168,64,2161,1092,1092,2049,1104,113,85,1,1045,32]

theorem envBound15331 : H12AffineFastState.Bounded env15331 := by
  intro p hp
  have h : env15331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15330_15331 : H12AffineEnvironment.transform 8 32 env15330 = env15331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env15330 == env15331) = true)

theorem identity15331 : scanCanonicalize (H12AffineFastState.compose env15331 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound15331 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env15332 : List Nat := [2,4,8,16,32,17,8,4,32,1024,2048,1045,2089,1045,2081,2082,1045,2081,1024,2080,1045,0,16,3,2089,17,2080,1045,1045,2049,1025,32,4,1,1045,32]

theorem envBound15332 : H12AffineFastState.Bounded env15332 := by
  intro p hp
  have h : env15332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15331_15332 : H12AffineEnvironment.transform 5 17 env15331 = env15332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15331 == env15332) = true)

theorem identity15332 : scanCanonicalize (H12AffineFastState.compose env15332 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound15332 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env15333 : List Nat := [2,4,8,16,1,17,8,4,1,1024,2048,1045,2056,1045,2048,2051,1045,2048,1024,2049,1045,0,16,3,2056,17,2049,1045,1045,2049,1025,1,4,1,1045,1]

theorem envBound15333 : H12AffineFastState.Bounded env15333 := by
  intro p hp
  have h : env15333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15332_15333 : H12AffineEnvironment.transform 4 1 env15332 = env15333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15332 == env15333) = true)

def leafEnv15333 : List Nat := [2,4,8,16,1,17,8,4,1,1024,2048,1045,2056,1045,2048,2051,1045,2048,1024,2049,1045,0,16,3,1025,2056,1,17,2049,1045,1045,2049,1025,1,4,1,4,2050,1045,1,0,1045,1]

def active15333 : List Nat := [0,1,2,3,9,10]

def tree15333 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15333 : H12WitnessSearch.Good tree15333 := H12GlobalWitnessIndex.good

theorem leafIdentity15333 : H12AffineFastState.composeSystem env15333 rootObs = leafEnv15333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15333 rootObs == leafEnv15333) = true)

theorem terminalChecked15333 : H12PackedTerminal.terminalCheckFast leafEnv15333 active15333 tree15333 = true := by decide +kernel

def env15334 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1345,2168,1296,2561,2822,1344,2640,1024,2560,1345,625,17,3,2168,65,2340,1296,1297,2932,1285,293,256,885,1344,512]

theorem envBound15334 : H12AffineFastState.Bounded env15334 := by
  intro p hp
  have h : env15334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15328_15334 : H12AffineEnvironment.transform 11 1345 env15328 = env15334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env15328 == env15334) = true)

theorem identity15334 : scanCanonicalize (H12AffineFastState.compose env15334 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound15334 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15335 : List Nat := [2,4,8,16,32,48,8,256,512,1024,2048,1329,2056,1296,2561,2822,1328,2592,1024,2560,1329,513,17,3,2056,49,2340,1296,1297,2820,1285,293,256,773,1328,512]

theorem envBound15335 : H12AffineFastState.Bounded env15335 := by
  intro p hp
  have h : env15335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15334_15335 : H12AffineEnvironment.transform 5 48 env15334 = env15335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env15334 == env15335) = true)

theorem identity15335 : scanCanonicalize (H12AffineFastState.compose env15335 (packedSelected [3,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound15335 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env15336 : List Nat := [2,4,8,16,32,48,8,37,512,1024,2048,1044,2056,1077,2561,2595,1045,2592,1024,2560,1044,513,17,3,2056,49,2049,1077,1076,2593,1056,0,37,544,1045,512]

theorem envBound15336 : H12AffineFastState.Bounded env15336 := by
  intro p hp
  have h : env15336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15335_15336 : H12AffineEnvironment.transform 7 37 env15335 = env15336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env15335 == env15336) = true)

theorem identity15336 : scanCanonicalize (H12AffineFastState.compose env15336 (packedSelected [2,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound15336 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env15337 : List Nat := [2,4,8,16,0,16,8,5,512,1024,2048,1044,2056,1045,2561,2563,1045,2560,1024,2560,1044,513,17,3,2056,17,2049,1045,1044,2561,1024,0,5,512,1045,512]

theorem envBound15337 : H12AffineFastState.Bounded env15337 := by
  intro p hp
  have h : env15337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15336_15337 : H12AffineEnvironment.transform 4 0 env15336 = env15337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15336 == env15337) = true)

def leafEnv15337 : List Nat := [2,4,8,16,0,16,8,5,512,1024,2048,1044,2056,1045,2561,2563,1045,2560,1024,2560,1044,513,17,3,1024,2056,1,17,2049,1045,1044,2561,1024,0,5,512,4,2562,1045,512,0,1044,1]

def active15337 : List Nat := [0,1,2,3,8,9,10]

def tree15337 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15337 : H12WitnessSearch.Good tree15337 := H12GlobalWitnessIndex.good

theorem leafIdentity15337 : H12AffineFastState.composeSystem env15337 rootObs = leafEnv15337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15337 rootObs == leafEnv15337) = true)

theorem terminalChecked15337 : H12PackedTerminal.terminalCheckFast leafEnv15337 active15337 tree15337 = true := by decide +kernel

def env15338 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4177,32768,65536,1344,262144,1024,32769,4096,4194304,5456,98564,8193,5376,134217728,4177,1297,1073741824,1285,4294967296,256,4299260199,138675269,512]

theorem envBound15338 : H12AffineFastState.Bounded env15338 := by
  intro p hp
  have h : env15338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15284_15338 : H12AffineEnvironment.transform 6 9 env15284 = env15338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15284 == env15338) = true)

theorem identity15338 : scanCanonicalize (H12AffineFastState.compose env15338 (packedSelected [10,17,41] rootPS)) = affineNative (2^(29+1) ^^^ 134291759) := by decide +kernel

theorem selectedBound15338 : packedSelected [10,17,41] rootPS < 2^1333 := by decide +kernel

def env15339 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4177,32768,65536,1344,262144,1024,32769,4096,4194304,5456,98564,8193,5376,134217728,4177,1297,134291759,1285,4294967296,256,4299260199,138675269,512]

theorem envBound15339 : H12AffineFastState.Bounded env15339 := by
  intro p hp
  have h : env15339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15338_15339 : H12AffineEnvironment.transform 29 134291759 env15338 = env15339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 134291759 env15338 == env15339) = true)

theorem identity15339 : scanCanonicalize (H12AffineFastState.compose env15339 (packedSelected [1,5,8,15,17,21,24,38] rootPS)) = affineNative (2^(26+1) ^^^ 4456709) := by decide +kernel

theorem selectedBound15339 : packedSelected [1,5,8,15,17,21,24,38] rootPS < 2^1333 := by decide +kernel

def env15340 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4177,32768,65536,1344,262144,1024,32769,4096,4194304,5456,98564,8193,5376,4456709,4177,1297,4530218,1285,4294967296,256,4299260199,1344,512]

theorem envBound15340 : H12AffineFastState.Bounded env15340 := by
  intro p hp
  have h : env15340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15339_15340 : H12AffineEnvironment.transform 26 4456709 env15339 = env15340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4456709 env15339 == env15340) = true)

theorem identity15340 : scanCanonicalize (H12AffineFastState.compose env15340 (packedSelected [1,5,15,17] rootPS)) = affineNative (2^(17+1) ^^^ 76079) := by decide +kernel

theorem selectedBound15340 : packedSelected [1,5,15,17] rootPS < 2^1333 := by decide +kernel

def env15341 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4177,32768,65536,1344,76079,1024,32769,4096,4194304,5456,98564,8193,5376,4270122,4177,1297,4196613,1285,4294967296,256,4299260199,1344,512]

theorem envBound15341 : H12AffineFastState.Bounded env15341 := by
  intro p hp
  have h : env15341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15340_15341 : H12AffineEnvironment.transform 17 76079 env15340 = env15341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76079 env15340 == env15341) = true)

theorem identity15341 : scanCanonicalize (H12AffineFastState.compose env15341 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 33030) := by decide +kernel

theorem selectedBound15341 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env15342 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4177,32768,33030,1344,43049,1024,32769,4096,4194304,5456,2,8193,5376,4237612,4177,1297,4196613,1285,4294967296,256,4299161633,1344,512]

theorem envBound15342 : H12AffineFastState.Bounded env15342 := by
  intro p hp
  have h : env15342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15341_15342 : H12AffineEnvironment.transform 15 33030 env15341 = env15342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33030 env15341 == env15342) = true)

def env15343 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4177,2560,2822,1344,8745,1024,2561,4096,4194304,5456,2,8193,5376,4203308,4177,1297,4196613,1285,4294967296,256,4299161633,1344,512]

theorem envBound15343 : H12AffineFastState.Bounded env15343 := by
  intro p hp
  have h : env15343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15342_15343 : H12AffineEnvironment.transform 14 2560 env15342 = env15343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2560 env15342 == env15343) = true)

theorem identity15343 : scanCanonicalize (H12AffineFastState.compose env15343 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 4210456) := by decide +kernel

theorem selectedBound15343 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15344 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4177,2560,2822,1344,8745,1024,2561,4096,4194304,5456,2,8193,5376,4203308,4177,1297,4196613,1285,4210456,256,16185,1344,512]

theorem envBound15344 : H12AffineFastState.Bounded env15344 := by
  intro p hp
  have h : env15344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15343_15344 : H12AffineEnvironment.transform 31 4210456 env15343 = env15344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4210456 env15343 == env15344) = true)

def env15345 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4177,2560,2822,1344,8745,1024,2561,4096,10760,5456,2,8193,5376,2340,4177,1297,8973,1285,5392,256,16185,1344,512]

theorem envBound15345 : H12AffineFastState.Bounded env15345 := by
  intro p hp
  have h : env15345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15344_15345 : H12AffineEnvironment.transform 21 10760 env15344 = env15345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10760 env15344 == env15345) = true)

theorem identity15345 : scanCanonicalize (H12AffineFastState.compose env15345 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 2681) := by decide +kernel

theorem selectedBound15345 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env15346 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,2681,4177,2560,2822,1344,2128,1024,2561,4096,113,5456,2,2680,5376,2340,4177,1297,2420,1285,5392,256,5440,1344,512]

theorem envBound15346 : H12AffineFastState.Bounded env15346 := by
  intro p hp
  have h : env15346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15345_15346 : H12AffineEnvironment.transform 12 2681 env15345 = env15346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2681 env15345 == env15346) = true)

theorem identity15346 : scanCanonicalize (H12AffineFastState.compose env15346 (packedSelected [1,5,7,12] rootPS)) = affineNative (2^(11+1) ^^^ 1092) := by decide +kernel

theorem selectedBound15346 : packedSelected [1,5,7,12] rootPS < 2^1333 := by decide +kernel

def env15347 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1092,2681,1045,2560,2822,1344,2128,1024,2561,1092,113,276,2,2680,324,2340,1045,1297,2420,1285,340,256,260,1344,512]

theorem envBound15347 : H12AffineFastState.Bounded env15347 := by
  intro p hp
  have h : env15347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15346_15347 : H12AffineEnvironment.transform 11 1092 env15346 = env15347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1092 env15346 == env15347) = true)

def env15348 : List Nat := [2,4,8,16,0,64,9,256,512,1024,2048,1092,2649,1045,2560,2822,1344,2128,1024,2561,1092,81,276,2,2648,324,2308,1045,1297,2388,1285,340,256,260,1344,512]

theorem envBound15348 : H12AffineFastState.Bounded env15348 := by
  intro p hp
  have h : env15348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15347_15348 : H12AffineEnvironment.transform 4 0 env15347 = env15348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15347 == env15348) = true)

theorem identity15348 : scanCanonicalize (H12AffineFastState.compose env15348 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound15348 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15349 : List Nat := [2,4,8,16,0,64,9,256,81,1024,2048,1092,2056,1045,2129,2391,1344,2128,1024,2128,1092,81,276,2,2057,324,2308,1045,1297,2388,1285,340,256,260,1344,81]

theorem envBound15349 : H12AffineFastState.Bounded env15349 := by
  intro p hp
  have h : env15349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15348_15349 : H12AffineEnvironment.transform 8 81 env15348 = env15349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env15348 == env15349) = true)

theorem identity15349 : scanCanonicalize (H12AffineFastState.compose env15349 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound15349 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15350 : List Nat := [2,4,8,16,0,64,9,84,81,1024,2048,1092,2056,1045,2129,2051,1044,2128,1024,2128,1092,81,64,2,2057,16,2128,1045,1093,2048,1105,0,84,80,1044,81]

theorem envBound15350 : H12AffineFastState.Bounded env15350 := by
  intro p hp
  have h : env15350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15349_15350 : H12AffineEnvironment.transform 7 84 env15349 = env15350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env15349 == env15350) = true)

theorem identity15350 : scanCanonicalize (H12AffineFastState.compose env15350 (packedSelected [4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound15350 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env15351 : List Nat := [2,4,8,16,0,16,9,4,1,1024,2048,1044,2056,1045,2049,2051,1044,2048,1024,2048,1044,1,16,2,2057,16,2048,1045,1045,2048,1025,0,4,0,1044,1]

theorem envBound15351 : H12AffineFastState.Bounded env15351 := by
  intro p hp
  have h : env15351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15350_15351 : H12AffineEnvironment.transform 5 16 env15350 = env15351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15350 == env15351) = true)

def leafEnv15351 : List Nat := [2,4,8,16,0,16,9,4,1,1024,2048,1044,2056,1045,2049,2051,1044,2048,1024,2048,1044,1,16,2,1025,2057,1,16,2048,1045,1045,2048,1025,0,4,0,4,2051,1044,1,0,1045,1]

def active15351 : List Nat := [0,1,2,3,9,10]

def tree15351 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15351 : H12WitnessSearch.Good tree15351 := H12GlobalWitnessIndex.good

theorem leafIdentity15351 : H12AffineFastState.composeSystem env15351 rootObs = leafEnv15351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15351 rootObs == leafEnv15351) = true)

theorem terminalChecked15351 : H12PackedTerminal.terminalCheckFast leafEnv15351 active15351 tree15351 = true := by decide +kernel

def env15352 : List Nat := [2,4,8,16,1,64,9,256,512,1024,2048,1092,2648,1045,2560,2822,1344,2128,1024,2561,1092,80,276,2,2649,324,2309,1045,1297,2389,1285,340,256,260,1344,512]

theorem envBound15352 : H12AffineFastState.Bounded env15352 := by
  intro p hp
  have h : env15352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15347_15352 : H12AffineEnvironment.transform 4 1 env15347 = env15352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15347 == env15352) = true)

theorem identity15352 : scanCanonicalize (H12AffineFastState.compose env15352 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound15352 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15353 : List Nat := [2,4,8,16,1,64,9,256,0,1024,2048,1092,2136,1045,2048,2310,1344,2128,1024,2049,1092,80,276,2,2137,324,2309,1045,1297,2389,1285,340,256,260,1344,0]

theorem envBound15353 : H12AffineFastState.Bounded env15353 := by
  intro p hp
  have h : env15353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15352_15353 : H12AffineEnvironment.transform 8 0 env15352 = env15353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env15352 == env15353) = true)

theorem identity15353 : scanCanonicalize (H12AffineFastState.compose env15353 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound15353 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env15354 : List Nat := [2,4,8,16,1,64,9,85,0,1024,2048,1092,2136,1045,2048,2131,1045,2128,1024,2049,1092,80,65,2,2137,17,2128,1045,1092,2048,1104,1,85,81,1045,0]

theorem envBound15354 : H12AffineFastState.Bounded env15354 := by
  intro p hp
  have h : env15354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15353_15354 : H12AffineEnvironment.transform 7 85 env15353 = env15354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env15353 == env15354) = true)

theorem identity15354 : scanCanonicalize (H12AffineFastState.compose env15354 (packedSelected [5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound15354 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env15355 : List Nat := [2,4,8,16,1,17,9,4,0,1024,2048,1045,2057,1045,2048,2050,1045,2049,1024,2049,1045,1,16,2,2056,17,2049,1045,1045,2048,1025,1,4,0,1045,0]

theorem envBound15355 : H12AffineFastState.Bounded env15355 := by
  intro p hp
  have h : env15355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15354_15355 : H12AffineEnvironment.transform 5 17 env15354 = env15355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15354 == env15355) = true)

def leafEnv15355 : List Nat := [2,4,8,16,1,17,9,4,0,1024,2048,1045,2057,1045,2048,2050,1045,2049,1024,2049,1045,1,16,2,1025,2056,1,17,2049,1045,1045,2048,1025,1,4,0,4,2050,1045,0,0,1045,1]

def active15355 : List Nat := [0,1,2,3,9,10]

def tree15355 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15355 : H12WitnessSearch.Good tree15355 := H12GlobalWitnessIndex.good

theorem leafIdentity15355 : H12AffineFastState.composeSystem env15355 rootObs = leafEnv15355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15355 rootObs == leafEnv15355) = true)

theorem terminalChecked15355 : H12PackedTerminal.terminalCheckFast leafEnv15355 active15355 tree15355 = true := by decide +kernel

def env15356 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4177,2560,2822,1344,8745,1024,2561,4096,10761,5456,2,8193,5376,2341,4177,1297,8972,1285,5393,256,16185,1344,512]

theorem envBound15356 : H12AffineFastState.Bounded env15356 := by
  intro p hp
  have h : env15356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15344_15356 : H12AffineEnvironment.transform 21 10761 env15344 = env15356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10761 env15344 == env15356) = true)

theorem identity15356 : scanCanonicalize (H12AffineFastState.compose env15356 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound15356 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env15357 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,4177,2560,2674,1076,8745,1024,2561,4096,10761,5156,2,8193,5236,2129,4177,1125,8824,1137,5221,116,15949,1076,512]

theorem envBound15357 : H12AffineFastState.Bounded env15357 := by
  intro p hp
  have h : env15357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15356_15357 : H12AffineEnvironment.transform 7 116 env15356 = env15357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env15356 == env15357) = true)

theorem identity15357 : scanCanonicalize (H12AffineFastState.compose env15357 (packedSelected [1,5,7,12] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound15357 : packedSelected [1,5,7,12] rootPS < 2^1333 := by decide +kernel

def env15358 : List Nat := [2,4,8,16,32,49,9,5,512,1024,2048,4096,8192,4128,2560,2563,1076,8745,1024,2561,4096,10761,5156,2,8193,5125,2080,4128,1044,8713,1024,5140,5,15932,1076,512]

theorem envBound15358 : H12AffineFastState.Bounded env15358 := by
  intro p hp
  have h : env15358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15357_15358 : H12AffineEnvironment.transform 5 49 env15357 = env15358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env15357 == env15358) = true)

theorem identity15358 : scanCanonicalize (H12AffineFastState.compose env15358 (packedSelected [1,2,3,7] rootPS)) = affineNative (2^(12+1) ^^^ 7196) := by decide +kernel

theorem selectedBound15358 : packedSelected [1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env15359 : List Nat := [2,4,8,16,32,49,9,5,512,1024,2048,4096,7196,4128,2560,2563,1076,7733,1024,2561,4096,5653,5156,2,7197,5125,2080,4128,1044,7701,1024,5140,5,544,1076,512]

theorem envBound15359 : H12AffineFastState.Bounded env15359 := by
  intro p hp
  have h : env15359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15358_15359 : H12AffineEnvironment.transform 12 7196 env15358 = env15359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7196 env15358 == env15359) = true)

theorem identity15359 : scanCanonicalize (H12AffineFastState.compose env15359 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound15359 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15360 : List Nat := [2,4,8,16,0,17,9,5,512,1024,2048,4096,7196,4096,2560,2563,1044,7701,1024,2561,4096,5653,5124,2,7197,5125,2048,4096,1044,7701,1024,5140,5,512,1044,512]

theorem envBound15360 : H12AffineFastState.Bounded env15360 := by
  intro p hp
  have h : env15360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15359_15360 : H12AffineEnvironment.transform 4 0 env15359 = env15360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15359 == env15360) = true)

theorem identity15360 : scanCanonicalize (H12AffineFastState.compose env15360 (packedSelected [2,3] rootPS)) = affineNative (2^(11+1) ^^^ 1557) := by decide +kernel

theorem selectedBound15360 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env15361 : List Nat := [2,4,8,16,0,17,9,5,512,1024,2048,1557,2569,1557,2560,2563,1044,2048,1024,2561,1557,0,529,2,2568,528,2048,1557,1044,2048,1024,513,5,512,1044,512]

theorem envBound15361 : H12AffineFastState.Bounded env15361 := by
  intro p hp
  have h : env15361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15360_15361 : H12AffineEnvironment.transform 11 1557 env15360 = env15361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env15360 == env15361) = true)

theorem identity15361 : scanCanonicalize (H12AffineFastState.compose env15361 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound15361 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env15362 : List Nat := [2,4,8,16,0,17,9,5,0,1024,2048,1045,2057,1045,2048,2051,1044,2048,1024,2049,1045,0,17,2,2056,16,2048,1045,1044,2048,1024,1,5,0,1044,0]

theorem envBound15362 : H12AffineFastState.Bounded env15362 := by
  intro p hp
  have h : env15362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15361_15362 : H12AffineEnvironment.transform 8 0 env15361 = env15362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env15361 == env15362) = true)

def leafEnv15362 : List Nat := [2,4,8,16,0,17,9,5,0,1024,2048,1045,2057,1045,2048,2051,1044,2048,1024,2049,1045,0,17,2,1024,2056,1,16,2048,1045,1044,2048,1024,1,5,0,4,2051,1044,0,0,1044,1]

def active15362 : List Nat := [0,1,2,3,9,10]

def tree15362 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15362 : H12WitnessSearch.Good tree15362 := H12GlobalWitnessIndex.good

theorem leafIdentity15362 : H12AffineFastState.composeSystem env15362 rootObs = leafEnv15362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15362 rootObs == leafEnv15362) = true)

theorem terminalChecked15362 : H12PackedTerminal.terminalCheckFast leafEnv15362 active15362 tree15362 = true := by decide +kernel

def env15363 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4177,2561,2823,1344,8744,1024,2560,4096,4194304,5456,2,8193,5376,4203309,4177,1297,4196613,1285,4294967296,256,4299161633,1344,512]

theorem envBound15363 : H12AffineFastState.Bounded env15363 := by
  intro p hp
  have h : env15363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15342_15363 : H12AffineEnvironment.transform 14 2561 env15342 = env15363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2561 env15342 == env15363) = true)

theorem identity15363 : scanCanonicalize (H12AffineFastState.compose env15363 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 15901) := by decide +kernel

theorem selectedBound15363 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15364 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4177,2561,2823,1344,8744,1024,2560,4096,4194304,5456,2,8193,5376,4203309,4177,1297,4196613,1285,15901,256,4210236,1344,512]

theorem envBound15364 : H12AffineFastState.Bounded env15364 := by
  intro p hp
  have h : env15364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15363_15364 : H12AffineEnvironment.transform 31 15901 env15363 = env15364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 15901 env15363 == env15364) = true)

def env15365 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4177,2561,2823,1344,8744,1024,2560,4096,10760,5456,2,8193,5376,2341,4177,1297,8973,1285,15901,256,5172,1344,512]

theorem envBound15365 : H12AffineFastState.Bounded env15365 := by
  intro p hp
  have h : env15365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15364_15365 : H12AffineEnvironment.transform 21 10760 env15364 = env15365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10760 env15364 == env15365) = true)

theorem identity15365 : scanCanonicalize (H12AffineFastState.compose env15365 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 2680) := by decide +kernel

theorem selectedBound15365 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env15366 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,2680,4177,2561,2823,1344,2128,1024,2560,4096,112,5456,2,2681,5376,2341,4177,1297,2421,1285,5221,256,5172,1344,512]

theorem envBound15366 : H12AffineFastState.Bounded env15366 := by
  intro p hp
  have h : env15366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15365_15366 : H12AffineEnvironment.transform 12 2680 env15365 = env15366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2680 env15365 == env15366) = true)

theorem identity15366 : scanCanonicalize (H12AffineFastState.compose env15366 (packedSelected [1,5,7,12] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound15366 : packedSelected [1,5,7,12] rootPS < 2^1333 := by decide +kernel

def env15367 : List Nat := [2,4,8,16,32,49,9,256,512,1024,2048,4096,2569,4128,2561,2823,1329,2081,1024,2560,4096,1,5409,2,2568,5376,2341,4128,1297,2308,1285,5140,256,5172,1329,512]

theorem envBound15367 : H12AffineFastState.Bounded env15367 := by
  intro p hp
  have h : env15367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15366_15367 : H12AffineEnvironment.transform 5 49 env15366 = env15367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env15366 == env15367) = true)

theorem identity15367 : scanCanonicalize (H12AffineFastState.compose env15367 (packedSelected [2,7] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound15367 : packedSelected [2,7] rootPS < 2^1333 := by decide +kernel

def env15368 : List Nat := [2,4,8,16,32,49,9,256,0,1024,2048,4096,2057,4128,2049,2311,1329,2081,1024,2048,4096,1,5409,2,2056,5376,2341,4128,1297,2308,1285,5140,256,5172,1329,0]

theorem envBound15368 : H12AffineFastState.Bounded env15368 := by
  intro p hp
  have h : env15368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15367_15368 : H12AffineEnvironment.transform 8 0 env15367 = env15368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env15367 == env15368) = true)

theorem identity15368 : scanCanonicalize (H12AffineFastState.compose env15368 (packedSelected [2,4] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound15368 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env15369 : List Nat := [2,4,8,16,32,49,9,256,0,1024,2048,1297,2057,1329,2049,2311,1329,2081,1024,2048,1297,1,48,2,2056,17,2341,1329,1297,2308,1285,261,256,293,1329,0]

theorem envBound15369 : H12AffineFastState.Bounded env15369 := by
  intro p hp
  have h : env15369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15368_15369 : H12AffineEnvironment.transform 11 1297 env15368 = env15369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env15368 == env15369) = true)

def env15370 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4177,2561,2823,1344,8744,1024,2560,4096,10761,5456,2,8193,5376,2340,4177,1297,8972,1285,15901,256,5173,1344,512]

theorem envBound15370 : H12AffineFastState.Bounded env15370 := by
  intro p hp
  have h : env15370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15364_15370 : H12AffineEnvironment.transform 21 10761 env15364 = env15370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10761 env15364 == env15370) = true)

theorem identity15370 : scanCanonicalize (H12AffineFastState.compose env15370 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound15370 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env15371 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,4177,2561,2674,1077,8744,1024,2560,4096,10761,5157,2,8193,5237,2129,4177,1124,8825,1136,15901,117,5173,1077,512]

theorem envBound15371 : H12AffineFastState.Bounded env15371 := by
  intro p hp
  have h : env15371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15370_15371 : H12AffineEnvironment.transform 7 117 env15370 = env15371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env15370 == env15371) = true)

theorem identity15371 : scanCanonicalize (H12AffineFastState.compose env15371 (packedSelected [1,5,7,12] rootPS)) = affineNative (2^(12+1) ^^^ 7740) := by decide +kernel

theorem selectedBound15371 : packedSelected [1,5,7,12] rootPS < 2^1333 := by decide +kernel

def env15372 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,7740,4177,2561,2674,1077,7188,1024,2560,4096,5173,5157,2,7741,5237,2129,4177,1124,7237,1136,33,117,5173,1077,512]

theorem envBound15372 : H12AffineFastState.Bounded env15372 := by
  intro p hp
  have h : env15372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15371_15372 : H12AffineEnvironment.transform 12 7740 env15371 = env15372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7740 env15371 == env15372) = true)

theorem identity15372 : scanCanonicalize (H12AffineFastState.compose env15372 (packedSelected [1,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 1125) := by decide +kernel

theorem selectedBound15372 : packedSelected [1,4,7] rootPS < 2^1333 := by decide +kernel

def env15373 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,1125,2649,1076,2561,2674,1077,2161,1024,2560,1125,80,64,2,2648,16,2129,1076,1124,2080,1136,33,117,80,1077,512]

theorem envBound15373 : H12AffineFastState.Bounded env15373 := by
  intro p hp
  have h : env15373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15372_15373 : H12AffineEnvironment.transform 11 1125 env15372 = env15373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1125 env15372 == env15373) = true)

theorem identity15373 : scanCanonicalize (H12AffineFastState.compose env15373 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound15373 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15374 : List Nat := [2,4,8,16,32,64,9,117,33,1024,2048,1125,2168,1076,2080,2131,1077,2161,1024,2081,1125,80,64,2,2169,16,2129,1076,1124,2080,1136,33,117,80,1077,33]

theorem envBound15374 : H12AffineFastState.Bounded env15374 := by
  intro p hp
  have h : env15374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15373_15374 : H12AffineEnvironment.transform 8 33 env15373 = env15374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env15373 == env15374) = true)

def env15375 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,1025,32769,4096,4194304,17664,119124,8328,17745,134217728,16385,21825,1073741824,21844,4294967296,257,4299280894,138695701,512]

theorem envBound15375 : H12AffineFastState.Bounded env15375 := by
  intro p hp
  have h : env15375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15282_15375 : H12AffineEnvironment.transform 18 1025 env15282 = env15375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env15282 == env15375) = true)

def env15376 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,524288,32769,4096,4194304,540928,644437,8328,17744,134217728,541696,545089,1073741824,21844,4294967296,525568,4299806207,139218964,512]

theorem envBound15376 : H12AffineFastState.Bounded env15376 := by
  intro p hp
  have h : env15376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15281_15376 : H12AffineEnvironment.transform 16 1345 env15281 = env15376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env15281 == env15376) = true)

def env15377 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,1024,32769,4096,4194304,17664,119125,8328,17744,134217728,16384,21825,1073741824,21844,4294967296,256,4299280895,138695700,512]

theorem envBound15377 : H12AffineFastState.Bounded env15377 := by
  intro p hp
  have h : env15377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15376_15377 : H12AffineEnvironment.transform 18 1024 env15376 = env15377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env15376 == env15377) = true)

theorem identity15377 : scanCanonicalize (H12AffineFastState.compose env15377 (packedSelected [7,20,27] rootPS)) = affineNative (2^(26+1) ^^^ 4456708) := by decide +kernel

theorem selectedBound15377 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env15378 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,1024,32769,4096,4194304,17664,119125,8328,17744,4456708,16384,21825,1073741824,21844,4294967296,256,4299280895,21776,512]

theorem envBound15378 : H12AffineFastState.Bounded env15378 := by
  intro p hp
  have h : env15378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15377_15378 : H12AffineEnvironment.transform 26 4456708 env15377 = env15378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4456708 env15377 == env15378) = true)

def env15379 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,1345,262144,1024,32769,4096,4194304,64,103445,8328,16,4456708,1344,4097,1073741824,4116,4294967296,256,4299265215,4176,512]

theorem envBound15379 : H12AffineFastState.Bounded env15379 := by
  intro p hp
  have h : env15379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15378_15379 : H12AffineEnvironment.transform 13 1344 env15378 = env15379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env15378 == env15379) = true)

theorem identity15379 : scanCanonicalize (H12AffineFastState.compose env15379 (packedSelected [0,7,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound15379 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env15380 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,1296,32768,65536,1297,262144,1024,32769,4096,4194304,16,103445,8328,16,4456708,1296,4097,1073741824,4116,4294967296,256,4299265215,4096,512]

theorem envBound15380 : H12AffineFastState.Bounded env15380 := by
  intro p hp
  have h : env15380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15379_15380 : H12AffineEnvironment.transform 5 16 env15379 = env15380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15379 == env15380) = true)

def env15381 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,1345,262144,1024,32769,4096,4194304,65,103444,8328,17,4456708,1345,4096,1073741824,4117,4294967296,256,4299265214,4177,512]

theorem envBound15381 : H12AffineFastState.Bounded env15381 := by
  intro p hp
  have h : env15381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15378_15381 : H12AffineEnvironment.transform 13 1345 env15378 = env15381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env15378 == env15381) = true)

theorem identity15381 : scanCanonicalize (H12AffineFastState.compose env15381 (packedSelected [0,7,20] rootPS)) = affineNative (2^(11+1) ^^^ 1345) := by decide +kernel

theorem selectedBound15381 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env15382 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,65536,1345,262144,1024,32769,1345,4194304,65,98645,8328,17,4456708,1345,1345,1073741824,1364,4294967296,256,4299260415,1296,512]

theorem envBound15382 : H12AffineFastState.Bounded env15382 := by
  intro p hp
  have h : env15382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15381_15382 : H12AffineEnvironment.transform 11 1345 env15381 = env15382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env15381 == env15382) = true)

theorem identity15382 : scanCanonicalize (H12AffineFastState.compose env15382 (packedSelected [17,21] rootPS)) = affineNative (2^(15+1) ^^^ 33247) := by decide +kernel

theorem selectedBound15382 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env15383 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,33247,1345,262144,1024,32769,1345,4194304,65,138,8328,17,4456708,1345,1345,1073741824,1364,4294967296,256,4299161632,1296,512]

theorem envBound15383 : H12AffineFastState.Bounded env15383 := by
  intro p hp
  have h : env15383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15382_15383 : H12AffineEnvironment.transform 15 33247 env15382 = env15383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33247 env15382 == env15383) = true)

theorem identity15383 : scanCanonicalize (H12AffineFastState.compose env15383 (packedSelected [1,5,10,13,15,17,24,28,38] rootPS)) = affineNative (2^(31+1) ^^^ 264589) := by decide +kernel

theorem selectedBound15383 : packedSelected [1,5,10,13,15,17,24,28,38] rootPS < 2^1333 := by decide +kernel

def env15384 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,33247,1345,262144,1024,32769,1345,4194304,65,138,8328,17,4456708,1345,1345,1073741824,1364,264589,256,4458925,1296,512]

theorem envBound15384 : H12AffineFastState.Bounded env15384 := by
  intro p hp
  have h : env15384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15383_15384 : H12AffineEnvironment.transform 31 264589 env15383 = env15384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 264589 env15383 == env15384) = true)

theorem identity15384 : scanCanonicalize (H12AffineFastState.compose env15384 (packedSelected [12,13,17,41] rootPS)) = affineNative (2^(17+1) ^^^ 43129) := by decide +kernel

theorem selectedBound15384 : packedSelected [12,13,17,41] rootPS < 2^1333 := by decide +kernel

def env15385 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,33247,1345,43129,1024,32769,1345,4194304,65,138,8328,17,4237693,1345,1345,1073741824,1364,41460,256,4235732,1296,512]

theorem envBound15385 : H12AffineFastState.Bounded env15385 := by
  intro p hp
  have h : env15385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15384_15385 : H12AffineEnvironment.transform 17 43129 env15384 = env15385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43129 env15384 == env15385) = true)

theorem identity15385 : scanCanonicalize (H12AffineFastState.compose env15385 (packedSelected [1,3,5,8,12,13,17] rootPS)) = affineNative (2^(21+1) ^^^ 10248) := by decide +kernel

theorem selectedBound15385 : packedSelected [1,3,5,8,12,13,17] rootPS < 2^1333 := by decide +kernel

def env15386 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,33247,1345,43129,1024,32769,1345,10248,65,138,8328,17,33141,1345,1345,1073741824,1364,41460,256,35292,1296,512]

theorem envBound15386 : H12AffineFastState.Bounded env15386 := by
  intro p hp
  have h : env15386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15385_15386 : H12AffineEnvironment.transform 21 10248 env15385 = env15386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10248 env15385 == env15386) = true)

theorem identity15386 : scanCanonicalize (H12AffineFastState.compose env15386 (packedSelected [11] rootPS)) = affineNative (2^(29+1) ^^^ 8541) := by decide +kernel

theorem selectedBound15386 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env15387 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,33247,1345,43129,1024,32769,1345,10248,65,138,8328,17,33141,1345,1345,8541,1364,41460,256,35292,1296,512]

theorem envBound15387 : H12AffineFastState.Bounded env15387 := by
  intro p hp
  have h : env15387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15386_15387 : H12AffineEnvironment.transform 29 8541 env15386 = env15387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 8541 env15386 == env15387) = true)

theorem identity15387 : scanCanonicalize (H12AffineFastState.compose env15387 (packedSelected [0,1,3,4,5,7,8,9,12] rootPS)) = affineNative (2^(14+1) ^^^ 2341) := by decide +kernel

theorem selectedBound15387 : packedSelected [0,1,3,4,5,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env15388 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,2341,2298,1345,8540,1024,2340,1345,10248,65,138,8328,17,2128,1345,1345,8541,1364,10449,256,249,1296,512]

theorem envBound15388 : H12AffineFastState.Bounded env15388 := by
  intro p hp
  have h : env15388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15387_15388 : H12AffineEnvironment.transform 14 2341 env15387 = env15388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2341 env15387 == env15388) = true)

theorem identity15388 : scanCanonicalize (H12AffineFastState.compose env15388 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 900) := by decide +kernel

theorem selectedBound15388 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15389 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,900,1345,2341,2298,1345,728,1024,2340,1345,2956,65,138,780,17,2128,1345,1345,729,1364,2901,256,249,1296,512]

theorem envBound15389 : H12AffineFastState.Bounded env15389 := by
  intro p hp
  have h : env15389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15388_15389 : H12AffineEnvironment.transform 12 900 env15388 = env15389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 900 env15388 == env15389) = true)

theorem identity15389 : scanCanonicalize (H12AffineFastState.compose env15389 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 1345) := by decide +kernel

theorem selectedBound15389 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env15390 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1345,1345,900,1345,1124,1467,1345,728,1024,1125,1345,1741,65,138,780,17,1297,1345,1345,729,1364,1556,256,249,1296,512]

theorem envBound15390 : H12AffineFastState.Bounded env15390 := by
  intro p hp
  have h : env15390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15389_15390 : H12AffineEnvironment.transform 10 1345 env15389 = env15390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1345 env15389 == env15390) = true)

theorem identity15390 : scanCanonicalize (H12AffineFastState.compose env15390 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound15390 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env15391 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1296,1296,900,1296,1077,1467,1296,649,1024,1076,1296,1692,16,138,780,17,1297,1296,1296,648,1285,1556,256,168,1296,512]

theorem envBound15391 : H12AffineFastState.Bounded env15391 := by
  intro p hp
  have h : env15391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15390_15391 : H12AffineEnvironment.transform 5 17 env15390 = env15391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15390 == env15391) = true)

theorem identity15391 : scanCanonicalize (H12AffineFastState.compose env15391 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 784) := by decide +kernel

theorem selectedBound15391 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15392 : List Nat := [2,4,8,16,32,17,128,256,512,784,512,512,900,512,805,683,512,649,784,804,512,396,16,138,780,17,513,512,512,648,533,260,256,168,512,512]

theorem envBound15392 : H12AffineFastState.Bounded env15392 := by
  intro p hp
  have h : env15392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15391_15392 : H12AffineEnvironment.transform 9 784 env15391 = env15392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 784 env15391 == env15392) = true)

theorem identity15392 : scanCanonicalize (H12AffineFastState.compose env15392 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 396) := by decide +kernel

theorem selectedBound15392 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15393 : List Nat := [2,4,8,16,32,17,128,256,396,156,396,396,8,396,169,295,396,261,156,168,396,396,16,138,128,17,397,396,396,260,409,260,256,168,396,396]

theorem envBound15393 : H12AffineFastState.Bounded env15393 := by
  intro p hp
  have h : env15393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15392_15393 : H12AffineEnvironment.transform 8 396 env15392 = env15393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 396 env15392 == env15393) = true)

theorem identity15393 : scanCanonicalize (H12AffineFastState.compose env15393 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound15393 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15394 : List Nat := [2,4,8,16,32,17,25,256,277,5,277,277,8,277,48,295,277,261,5,49,277,277,16,19,25,17,276,277,277,260,256,260,256,49,277,277]

theorem envBound15394 : H12AffineFastState.Bounded env15394 := by
  intro p hp
  have h : env15394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15393_15394 : H12AffineEnvironment.transform 6 25 env15393 = env15394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env15393 == env15394) = true)

theorem identity15394 : scanCanonicalize (H12AffineFastState.compose env15394 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound15394 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env15395 : List Nat := [2,4,8,16,32,17,25,37,48,5,48,48,8,48,48,2,48,32,5,49,48,48,16,19,25,17,49,48,48,33,37,33,37,49,48,48]

theorem envBound15395 : H12AffineFastState.Bounded env15395 := by
  intro p hp
  have h : env15395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15394_15395 : H12AffineEnvironment.transform 7 37 env15394 = env15395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env15394 == env15395) = true)

theorem identity15395 : scanCanonicalize (H12AffineFastState.compose env15395 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound15395 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env15396 : List Nat := [2,4,8,16,1,17,25,4,17,5,17,17,8,17,17,2,17,1,5,16,17,17,16,19,25,17,16,17,17,0,4,0,4,16,17,17]

theorem envBound15396 : H12AffineFastState.Bounded env15396 := by
  intro p hp
  have h : env15396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15395_15396 : H12AffineEnvironment.transform 4 1 env15395 = env15396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15395 == env15396) = true)

theorem identity15396 : scanCanonicalize (H12AffineFastState.compose env15396 (packedSelected [7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound15396 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env15397 : List Nat := [2,4,8,1,1,0,8,4,0,5,0,0,8,0,0,2,0,1,5,1,0,0,1,2,8,0,1,0,0,0,4,0,4,1,0,0]

theorem envBound15397 : H12AffineFastState.Bounded env15397 := by
  intro p hp
  have h : env15397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15396_15397 : H12AffineEnvironment.transform 3 1 env15396 = env15397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env15396 == env15397) = true)

def env15398 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,1025,32769,4096,4194304,17665,119124,8328,17744,134217728,16385,21824,1073741824,21844,4294967296,257,4299280894,138695701,512]

theorem envBound15398 : H12AffineFastState.Bounded env15398 := by
  intro p hp
  have h : env15398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15376_15398 : H12AffineEnvironment.transform 18 1025 env15376 = env15398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env15376 == env15398) = true)

theorem identity15398 : scanCanonicalize (H12AffineFastState.compose env15398 (packedSelected [7,20,27] rootPS)) = affineNative (2^(26+1) ^^^ 4477268) := by decide +kernel

theorem selectedBound15398 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env15399 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,1025,32769,4096,4194304,17665,119124,8328,17744,4477268,16385,21824,1073741824,21844,4294967296,257,4299280894,1345,512]

theorem envBound15399 : H12AffineFastState.Bounded env15399 := by
  intro p hp
  have h : env15399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15398_15399 : H12AffineEnvironment.transform 26 4477268 env15398 = env15399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4477268 env15398 == env15399) = true)

def env15400 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4096,32768,65536,1345,262144,1025,32769,4096,4194304,5377,98644,8328,5456,4456788,4097,1344,1073741824,1364,4294967296,257,4299260414,1345,512]

theorem envBound15400 : H12AffineFastState.Bounded env15400 := by
  intro p hp
  have h : env15400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15399_15400 : H12AffineEnvironment.transform 13 4096 env15399 = env15400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env15399 == env15400) = true)

theorem identity15400 : scanCanonicalize (H12AffineFastState.compose env15400 (packedSelected [0,7,20] rootPS)) = affineNative (2^(11+1) ^^^ 1345) := by decide +kernel

theorem selectedBound15400 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env15401 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,65536,1345,262144,1025,32769,1345,4194304,64,98644,8328,17,4456788,1344,1344,1073741824,1364,4294967296,257,4299260414,1345,512]

theorem envBound15401 : H12AffineFastState.Bounded env15401 := by
  intro p hp
  have h : env15401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15400_15401 : H12AffineEnvironment.transform 11 1345 env15400 = env15401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env15400 == env15401) = true)

theorem identity15401 : scanCanonicalize (H12AffineFastState.compose env15401 (packedSelected [12,13,15,17,38,41] rootPS)) = affineNative (2^(31+1) ^^^ 73771) := by decide +kernel

theorem selectedBound15401 : packedSelected [12,13,15,17,38,41] rootPS < 2^1333 := by decide +kernel

def env15402 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1345,32768,65536,1345,262144,1025,32769,1345,4194304,64,98644,8328,17,4456788,1344,1344,1073741824,1364,73771,257,4235733,1345,512]

theorem envBound15402 : H12AffineFastState.Bounded env15402 := by
  intro p hp
  have h : env15402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15401_15402 : H12AffineEnvironment.transform 31 73771 env15401 = env15402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 73771 env15401 == env15402) = true)

def env15403 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,32768,65536,1297,262144,1025,32769,1297,4194304,16,98564,8328,17,4456708,1296,1296,1073741824,1284,73771,257,4235653,1297,512]

theorem envBound15403 : H12AffineFastState.Bounded env15403 := by
  intro p hp
  have h : env15403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15402_15403 : H12AffineEnvironment.transform 5 16 env15402 = env15403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15402 == env15403) = true)

theorem identity15403 : scanCanonicalize (H12AffineFastState.compose env15403 (packedSelected [1,3,5] rootPS)) = affineNative (2^(29+1) ^^^ 4295589) := by decide +kernel

theorem selectedBound15403 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env15404 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,32768,65536,1297,262144,1025,32769,1297,4194304,16,98564,8328,17,4456708,1296,1296,4295589,1284,73771,257,4235653,1297,512]

theorem envBound15404 : H12AffineFastState.Bounded env15404 := by
  intro p hp
  have h : env15404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15403_15404 : H12AffineEnvironment.transform 29 4295589 env15403 = env15404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4295589 env15403 == env15404) = true)

theorem identity15404 : scanCanonicalize (H12AffineFastState.compose env15404 (packedSelected [1,3,8] rootPS)) = affineNative (2^(14+1) ^^^ 9093) := by decide +kernel

theorem selectedBound15404 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env15405 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,9093,65536,1297,262144,1025,9092,1297,4194304,16,74369,8328,17,4456708,1296,1296,4270112,1284,73771,257,4194816,1297,512]

theorem envBound15405 : H12AffineFastState.Bounded env15405 := by
  intro p hp
  have h : env15405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15404_15405 : H12AffineEnvironment.transform 14 9093 env15404 = env15405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9093 env15404 == env15405) = true)

theorem identity15405 : scanCanonicalize (H12AffineFastState.compose env15405 (packedSelected [1,12,13] rootPS)) = affineNative (2^(17+1) ^^^ 75776) := by decide +kernel

theorem selectedBound15405 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env15406 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,9093,65536,1297,75776,1025,9092,1297,4194304,16,74369,8328,17,4270340,1296,1296,4270112,1284,73771,257,4194816,1297,512]

theorem envBound15406 : H12AffineFastState.Bounded env15406 := by
  intro p hp
  have h : env15406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15405_15406 : H12AffineEnvironment.transform 17 75776 env15405 = env15406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 75776 env15405 == env15406) = true)

theorem identity15406 : scanCanonicalize (H12AffineFastState.compose env15406 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound15406 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env15407 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1297,9093,8323,1297,2179,1025,9092,1297,4194304,16,514,8328,17,4196743,1296,1296,4196515,1284,168,257,4194816,1297,512]

end H12CloudChart2