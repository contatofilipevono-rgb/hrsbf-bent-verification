import H12CloudChart2Data041

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env10236 : List Nat := [2,4,8,16,32,16,128,182,136,1024,2048,1190,9,1191,2216,2192,1190,136,1025,2216,1190,2074,16,138,128,17,2081,1191,1190,168,1202,136,183,2226,1190,137]

theorem envBound10236 : H12AffineFastState.Bounded env10236 := by
  intro p hp
  have h : env10236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10235_10236 : H12AffineEnvironment.transform 7 182 env10235 = env10236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 182 env10235 == env10236) = true)

theorem identity10236 : scanCanonicalize (H12AffineFastState.compose env10236 (packedSelected [10] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound10236 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env10237 : List Nat := [2,4,8,16,32,16,128,182,136,1024,32,1190,9,1191,136,176,1190,136,1025,136,1190,58,16,138,128,17,1,1191,1190,168,1202,136,183,146,1190,137]

theorem envBound10237 : H12AffineFastState.Bounded env10237 := by
  intro p hp
  have h : env10237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10236_10237 : H12AffineEnvironment.transform 10 32 env10236 = env10237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env10236 == env10237) = true)

theorem identity10237 : scanCanonicalize (H12AffineFastState.compose env10237 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound10237 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env10238 : List Nat := [2,4,8,16,10,16,128,156,136,1024,10,1164,9,1165,136,154,1164,136,1025,136,1164,16,16,138,128,17,1,1165,1164,130,1176,136,157,146,1164,137]

theorem envBound10238 : H12AffineFastState.Bounded env10238 := by
  intro p hp
  have h : env10238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10237_10238 : H12AffineEnvironment.transform 4 10 env10237 = env10238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env10237 == env10238) = true)

theorem identity10238 : scanCanonicalize (H12AffineFastState.compose env10238 (packedSelected [12] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound10238 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env10239 : List Nat := [2,4,8,16,10,16,3,31,11,1024,10,1039,9,1038,11,25,1039,11,1025,11,1039,16,16,9,3,17,1,1038,1039,1,1051,11,30,17,1039,10]

theorem envBound10239 : H12AffineFastState.Bounded env10239 := by
  intro p hp
  have h : env10239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10238_10239 : H12AffineEnvironment.transform 6 3 env10238 = env10239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env10238 == env10239) = true)

theorem identity10239 : scanCanonicalize (H12AffineFastState.compose env10239 (packedSelected [0,2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound10239 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env10240 : List Nat := [2,4,3,16,1,16,3,20,0,1024,1,1028,2,1029,0,18,1028,0,1025,0,1028,16,16,2,3,17,1,1029,1028,1,1040,0,21,17,1028,1]

theorem envBound10240 : H12AffineFastState.Bounded env10240 := by
  intro p hp
  have h : env10240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10239_10240 : H12AffineEnvironment.transform 2 3 env10239 = env10240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env10239 == env10240) = true)

theorem identity10240 : scanCanonicalize (H12AffineFastState.compose env10240 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound10240 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10241 : List Nat := [2,4,3,0,1,0,3,4,0,1024,1,1028,2,1029,0,2,1028,0,1025,0,1028,0,0,2,3,1,1,1029,1028,1,1024,0,5,1,1028,1]

theorem envBound10241 : H12AffineFastState.Bounded env10241 := by
  intro p hp
  have h : env10241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10240_10241 : H12AffineEnvironment.transform 3 0 env10240 = env10241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env10240 == env10241) = true)

def leafEnv10241 : List Nat := [2,4,3,0,1,0,3,4,0,1024,1,1028,2,1029,0,2,1028,0,1025,0,1028,0,0,2,1025,3,1,1,1,1029,1028,1,1024,0,5,1,5,3,1028,1,0,1028,1]

def active10241 : List Nat := [0,1,9]

def tree10241 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood10241 : H12WitnessSearch.Good tree10241 := H12GlobalWitnessIndex.good

theorem leafIdentity10241 : H12AffineFastState.composeSystem env10241 rootObs = leafEnv10241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env10241 rootObs == leafEnv10241) = true)

theorem terminalChecked10241 : H12PackedTerminal.terminalCheckFast leafEnv10241 active10241 tree10241 = true := by decide +kernel

def env10242 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,8,4096,32768,65536,4096,262144,1025,32768,4096,4194304,5377,16777216,33554432,16875797,21331968,16876564,4096,20978846,16876544,4294967296,257,4332819518,4096,33554441]

theorem envBound10242 : H12AffineFastState.Bounded env10242 := by
  intro p hp
  have h : env10242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10226_10242 : H12AffineEnvironment.transform 8 137 env10226 = env10242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env10226 == env10242) = true)

def env10243 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,8,4096,32768,65536,4096,262144,1025,32768,4096,65544,5377,16777216,33554432,16875797,17072136,16876564,4096,16850070,16876544,4294967296,257,4328559670,4096,33554441]

theorem envBound10243 : H12AffineFastState.Bounded env10243 := by
  intro p hp
  have h : env10243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10242_10243 : H12AffineEnvironment.transform 21 65544 env10242 = env10243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65544 env10242 == env10243) = true)

def env10244 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,8,1296,32768,65536,1296,262144,1025,32768,1296,65544,17,16777216,33554432,16875797,17072136,16876564,1296,16845190,16876544,4294967296,257,4328554790,1296,33554441]

theorem envBound10244 : H12AffineFastState.Bounded env10244 := by
  intro p hp
  have h : env10244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10243_10244 : H12AffineEnvironment.transform 11 1296 env10243 = env10244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env10243 == env10244) = true)

theorem identity10244 : scanCanonicalize (H12AffineFastState.compose env10244 (packedSelected [3,5,24] rootPS)) = affineNative (2^(23+1) ^^^ 32777) := by decide +kernel

theorem selectedBound10244 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env10245 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,8,1296,32768,65536,1296,262144,1025,32768,1296,65544,17,32777,33554432,65820,262145,66589,1296,100751,66569,4294967296,257,4328554790,1296,33554441]

theorem envBound10245 : H12AffineFastState.Bounded env10245 := by
  intro p hp
  have h : env10245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10244_10245 : H12AffineEnvironment.transform 23 32777 env10244 = env10245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 32777 env10244 == env10245) = true)

theorem identity10245 : scanCanonicalize (H12AffineFastState.compose env10245 (packedSelected [5,8,13,15,17,19,21] rootPS)) = affineNative (2^(24+1) ^^^ 330030) := by decide +kernel

theorem selectedBound10245 : packedSelected [5,8,13,15,17,19,21] rootPS < 2^1333 := by decide +kernel

def env10246 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,8,1296,32768,65536,1296,262144,1025,32768,1296,65544,17,32777,330030,65820,262145,66589,1296,100751,66569,4294967296,257,4295329800,1296,330023]

theorem envBound10246 : H12AffineFastState.Bounded env10246 := by
  intro p hp
  have h : env10246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10245_10246 : H12AffineEnvironment.transform 24 330030 env10245 = env10246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 330030 env10245 == env10246) = true)

theorem identity10246 : scanCanonicalize (H12AffineFastState.compose env10246 (packedSelected [1,10,12,13,15,19] rootPS)) = affineNative (2^(17+1) ^^^ 34946) := by decide +kernel

theorem selectedBound10246 : packedSelected [1,10,12,13,15,19] rootPS < 2^1333 := by decide +kernel

def env10247 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,8,1296,32768,65536,1296,34946,1025,32768,1296,65544,17,32777,98732,65820,34947,66589,1296,100751,66569,4294967296,257,4295032970,1296,98725]

theorem envBound10247 : H12AffineFastState.Bounded env10247 := by
  intro p hp
  have h : env10247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10246_10247 : H12AffineEnvironment.transform 17 34946 env10246 = env10247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 34946 env10246 == env10247) = true)

theorem identity10247 : scanCanonicalize (H12AffineFastState.compose env10247 (packedSelected [0,1,2,3,5,6,9,10,11,12,16,17,18] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound10247 : packedSelected [0,1,2,3,5,6,9,10,11,12,16,17,18] rootPS < 2^1333 := by decide +kernel

def env10248 : List Nat := [2,4,8,16,32,16,34,256,43,1024,2048,1296,8,1296,32768,65536,1296,34848,1025,32768,1296,65544,17,32777,98574,65820,34849,66589,1296,100653,66569,4294967296,257,4295032872,1296,98567]

theorem envBound10248 : H12AffineFastState.Bounded env10248 := by
  intro p hp
  have h : env10248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10247_10248 : H12AffineEnvironment.transform 6 34 env10247 = env10248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env10247 == env10248) = true)

theorem identity10248 : scanCanonicalize (H12AffineFastState.compose env10248 (packedSelected [8,10,13,15,16,20] rootPS)) = affineNative (2^(15+1) ^^^ 269) := by decide +kernel

theorem selectedBound10248 : packedSelected [8,10,13,15,16,20] rootPS < 2^1333 := by decide +kernel

def env10249 : List Nat := [2,4,8,16,32,16,34,256,43,1024,2048,1296,8,1296,32768,269,1296,34848,1025,32768,1296,261,17,32777,32771,17,34849,1296,1296,34848,1284,4294967296,257,4294967589,1296,32778]

theorem envBound10249 : H12AffineFastState.Bounded env10249 := by
  intro p hp
  have h : env10249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10248_10249 : H12AffineEnvironment.transform 15 269 env10248 = env10249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 269 env10248 == env10249) = true)

theorem identity10249 : scanCanonicalize (H12AffineFastState.compose env10249 (packedSelected [2,4,6,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 261) := by decide +kernel

theorem selectedBound10249 : packedSelected [2,4,6,7,11] rootPS < 2^1333 := by decide +kernel

def env10250 : List Nat := [2,4,8,16,32,16,34,256,43,1024,261,1296,8,1296,32768,269,1296,33061,1025,32768,1296,261,17,32777,32771,17,33060,1296,1296,33061,1284,4294967296,257,4294967589,1296,32778]

theorem envBound10250 : H12AffineFastState.Bounded env10250 := by
  intro p hp
  have h : env10250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10249_10250 : H12AffineEnvironment.transform 10 261 env10249 = env10250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env10249 == env10250) = true)

theorem identity10250 : scanCanonicalize (H12AffineFastState.compose env10250 (packedSelected [1,13] rootPS)) = affineNative (2^(14+1) ^^^ 33) := by decide +kernel

theorem selectedBound10250 : packedSelected [1,13] rootPS < 2^1333 := by decide +kernel

def env10251 : List Nat := [2,4,8,16,32,16,34,256,43,1024,261,1296,8,1296,33,269,1296,260,1025,33,1296,261,17,40,34,17,261,1296,1296,260,1284,4294967296,257,4294967589,1296,43]

theorem envBound10251 : H12AffineFastState.Bounded env10251 := by
  intro p hp
  have h : env10251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10250_10251 : H12AffineEnvironment.transform 14 33 env10250 = env10251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 33 env10250 == env10251) = true)

theorem identity10251 : scanCanonicalize (H12AffineFastState.compose env10251 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 303) := by decide +kernel

theorem selectedBound10251 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10252 : List Nat := [2,4,8,16,32,16,34,256,43,1024,261,1296,8,1296,33,269,1296,260,1025,33,1296,261,17,40,34,17,261,1296,1296,260,1284,303,257,10,1296,43]

theorem envBound10252 : H12AffineFastState.Bounded env10252 := by
  intro p hp
  have h : env10252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10251_10252 : H12AffineEnvironment.transform 31 303 env10251 = env10252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 303 env10251 == env10252) = true)

theorem identity10252 : scanCanonicalize (H12AffineFastState.compose env10252 (packedSelected [0,2] rootPS)) = affineNative (2^(7+1) ^^^ 38) := by decide +kernel

theorem selectedBound10252 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env10253 : List Nat := [2,4,8,16,32,16,34,38,43,1024,35,1078,8,1078,33,43,1078,34,1025,33,1078,35,17,40,34,17,35,1078,1078,34,1058,9,39,10,1078,43]

theorem envBound10253 : H12AffineFastState.Bounded env10253 := by
  intro p hp
  have h : env10253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10252_10253 : H12AffineEnvironment.transform 7 38 env10252 = env10253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 38 env10252 == env10253) = true)

theorem identity10253 : scanCanonicalize (H12AffineFastState.compose env10253 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound10253 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env10254 : List Nat := [2,4,8,16,2,16,0,4,9,1024,1,1044,8,1044,3,9,1044,0,1025,3,1044,1,17,10,0,17,1,1044,1044,0,1024,9,5,10,1044,9]

theorem envBound10254 : H12AffineFastState.Bounded env10254 := by
  intro p hp
  have h : env10254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10253_10254 : H12AffineEnvironment.transform 4 2 env10253 = env10254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env10253 == env10254) = true)

theorem identity10254 : scanCanonicalize (H12AffineFastState.compose env10254 (packedSelected [0,6] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound10254 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env10255 : List Nat := [2,4,0,16,2,16,0,4,1,1024,1,1044,0,1044,3,1,1044,0,1025,3,1044,1,17,2,0,17,1,1044,1044,0,1024,1,5,2,1044,1]

theorem envBound10255 : H12AffineFastState.Bounded env10255 := by
  intro p hp
  have h : env10255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10254_10255 : H12AffineEnvironment.transform 2 0 env10254 = env10255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env10254 == env10255) = true)

theorem identity10255 : scanCanonicalize (H12AffineFastState.compose env10255 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound10255 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10256 : List Nat := [0,4,0,16,0,16,0,4,1,1024,1,1044,0,1044,1,1,1044,0,1025,1,1044,1,17,0,0,17,1,1044,1044,0,1024,1,5,0,1044,1]

theorem envBound10256 : H12AffineFastState.Bounded env10256 := by
  intro p hp
  have h : env10256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10255_10256 : H12AffineEnvironment.transform 0 0 env10255 = env10256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env10255 == env10256) = true)

def env10257 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,8,1297,32768,65536,1297,262144,1025,32768,1297,65544,16,16777216,33554432,16875797,17072136,16876564,1297,16845191,16876544,4294967296,257,4328554791,1297,33554441]

theorem envBound10257 : H12AffineFastState.Bounded env10257 := by
  intro p hp
  have h : env10257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10243_10257 : H12AffineEnvironment.transform 11 1297 env10243 = env10257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env10243 == env10257) = true)

theorem identity10257 : scanCanonicalize (H12AffineFastState.compose env10257 (packedSelected [3,5,24] rootPS)) = affineNative (2^(24+1) ^^^ 16809985) := by decide +kernel

theorem selectedBound10257 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env10258 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,8,1297,32768,65536,1297,262144,1025,32768,1297,65544,16,16777216,16809985,16875797,17072136,16876564,1297,16845191,16876544,4294967296,257,4311744806,1297,16809992]

theorem envBound10258 : H12AffineFastState.Bounded env10258 := by
  intro p hp
  have h : env10258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10257_10258 : H12AffineEnvironment.transform 24 16809985 env10257 = env10258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 16809985 env10257 == env10258) = true)

theorem identity10258 : scanCanonicalize (H12AffineFastState.compose env10258 (packedSelected [1,3,4,9,12,13,15,16,17] rootPS)) = affineNative (2^(17+1) ^^^ 2340) := by decide +kernel

theorem selectedBound10258 : packedSelected [1,3,4,9,12,13,15,16,17] rootPS < 2^1333 := by decide +kernel

def env10259 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,8,1297,32768,65536,1297,2340,1025,32768,1297,65544,16,16777216,16809985,16875797,16812332,16876564,1297,16845191,16876544,4294967296,257,4311744806,1297,16809992]

theorem envBound10259 : H12AffineFastState.Bounded env10259 := by
  intro p hp
  have h : env10259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10258_10259 : H12AffineEnvironment.transform 17 2340 env10258 = env10259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2340 env10258 == env10259) = true)

theorem identity10259 : scanCanonicalize (H12AffineFastState.compose env10259 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(23+1) ^^^ 32896) := by decide +kernel

theorem selectedBound10259 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env10260 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,8,1297,32768,65536,1297,2340,1025,32768,1297,65544,16,32896,129,65941,2476,66708,1297,100615,66688,4294967296,257,4295000486,1297,136]

theorem envBound10260 : H12AffineFastState.Bounded env10260 := by
  intro p hp
  have h : env10260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10259_10260 : H12AffineEnvironment.transform 23 32896 env10259 = env10260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 32896 env10259 == env10260) = true)

theorem identity10260 : scanCanonicalize (H12AffineFastState.compose env10260 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 389) := by decide +kernel

theorem selectedBound10260 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env10261 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,8,1297,32768,389,1297,2340,1025,32768,1297,397,16,32896,129,16,2476,1297,1297,34946,1285,4294967296,257,4295000486,1297,136]

theorem envBound10261 : H12AffineFastState.Bounded env10261 := by
  intro p hp
  have h : env10261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10260_10261 : H12AffineEnvironment.transform 15 389 env10260 = env10261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 389 env10260 == env10261) = true)

theorem identity10261 : scanCanonicalize (H12AffineFastState.compose env10261 (packedSelected [1,3,5] rootPS)) = affineNative (2^(14+1) ^^^ 260) := by decide +kernel

theorem selectedBound10261 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env10262 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,8,1297,260,389,1297,2340,1025,260,1297,397,16,388,129,16,2476,1297,1297,2438,1285,4294967296,257,4294967458,1297,136]

theorem envBound10262 : H12AffineFastState.Bounded env10262 := by
  intro p hp
  have h : env10262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10261_10262 : H12AffineEnvironment.transform 14 260 env10261 = env10262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 260 env10261 == env10262) = true)

theorem identity10262 : scanCanonicalize (H12AffineFastState.compose env10262 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound10262 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10263 : List Nat := [2,4,8,16,32,16,128,21,137,1024,2048,1028,8,1028,17,144,1028,2097,1025,17,1028,152,16,145,129,16,2233,1028,1028,2195,1040,4294967296,20,4294967458,1028,136]

theorem envBound10263 : H12AffineFastState.Bounded env10263 := by
  intro p hp
  have h : env10263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10262_10263 : H12AffineEnvironment.transform 7 21 env10262 = env10263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env10262 == env10263) = true)

theorem identity10263 : scanCanonicalize (H12AffineFastState.compose env10263 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 2179) := by decide +kernel

theorem selectedBound10263 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env10264 : List Nat := [2,4,8,16,32,16,128,21,137,1024,2048,1028,8,1028,17,144,1028,2097,1025,17,1028,152,16,145,129,16,2233,1028,1028,2195,1040,2179,20,2081,1028,136]

theorem envBound10264 : H12AffineFastState.Bounded env10264 := by
  intro p hp
  have h : env10264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10263_10264 : H12AffineEnvironment.transform 31 2179 env10263 = env10264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 2179 env10263 == env10264) = true)

theorem identity10264 : scanCanonicalize (H12AffineFastState.compose env10264 (packedSelected [10] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound10264 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env10265 : List Nat := [2,4,8,16,32,16,35,21,42,1024,2048,1028,8,1028,17,51,1028,2097,1025,17,1028,59,16,50,34,16,2074,1028,1028,2096,1040,2080,20,2081,1028,43]

theorem envBound10265 : H12AffineFastState.Bounded env10265 := by
  intro p hp
  have h : env10265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10264_10265 : H12AffineEnvironment.transform 6 35 env10264 = env10265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env10264 == env10265) = true)

theorem identity10265 : scanCanonicalize (H12AffineFastState.compose env10265 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound10265 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env10266 : List Nat := [2,4,8,10,32,10,35,15,42,1024,2048,1028,8,1028,11,41,1028,2091,1025,11,1028,33,10,40,34,10,2048,1028,1028,2090,1034,2080,14,2081,1028,43]

theorem envBound10266 : H12AffineFastState.Bounded env10266 := by
  intro p hp
  have h : env10266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10265_10266 : H12AffineEnvironment.transform 3 10 env10265 = env10266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env10265 == env10266) = true)

theorem identity10266 : scanCanonicalize (H12AffineFastState.compose env10266 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound10266 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10267 : List Nat := [2,4,8,10,32,10,35,15,42,1024,0,1028,8,1028,11,41,1028,43,1025,11,1028,33,10,40,34,10,0,1028,1028,42,1034,32,14,33,1028,43]

theorem envBound10267 : H12AffineFastState.Bounded env10267 := by
  intro p hp
  have h : env10267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10266_10267 : H12AffineEnvironment.transform 10 0 env10266 = env10267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env10266 == env10267) = true)

theorem identity10267 : scanCanonicalize (H12AffineFastState.compose env10267 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound10267 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env10268 : List Nat := [2,4,8,10,10,10,9,15,0,1024,0,1028,8,1028,11,3,1028,1,1025,11,1028,11,10,2,8,10,0,1028,1028,0,1034,10,14,11,1028,1]

theorem envBound10268 : H12AffineFastState.Bounded env10268 := by
  intro p hp
  have h : env10268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10267_10268 : H12AffineEnvironment.transform 4 10 env10267 = env10268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env10267 == env10268) = true)

def env10269 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,8,4096,32768,65536,4096,262144,1025,32768,4096,65545,5377,16777216,33554432,16875797,17072137,16876564,4096,16850071,16876544,4294967296,257,4328559671,4096,33554441]

theorem envBound10269 : H12AffineFastState.Bounded env10269 := by
  intro p hp
  have h : env10269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10242_10269 : H12AffineEnvironment.transform 21 65545 env10242 = env10269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65545 env10242 == env10269) = true)

def env10270 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,8,1296,32768,65536,1296,262144,1025,32768,1296,65545,17,16777216,33554432,16875797,17072137,16876564,1296,16845191,16876544,4294967296,257,4328554791,1296,33554441]

theorem envBound10270 : H12AffineFastState.Bounded env10270 := by
  intro p hp
  have h : env10270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10269_10270 : H12AffineEnvironment.transform 11 1296 env10269 = env10270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env10269 == env10270) = true)

theorem identity10270 : scanCanonicalize (H12AffineFastState.compose env10270 (packedSelected [3,5,24] rootPS)) = affineNative (2^(15+1) ^^^ 268) := by decide +kernel

theorem selectedBound10270 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env10271 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,8,1296,32768,268,1296,262144,1025,32768,1296,261,17,16777216,33554432,16810009,17072137,16811288,1296,16779403,16811276,4294967296,257,4328554791,1296,33554441]

theorem envBound10271 : H12AffineFastState.Bounded env10271 := by
  intro p hp
  have h : env10271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10270_10271 : H12AffineEnvironment.transform 15 268 env10270 = env10271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 268 env10270 == env10271) = true)

theorem identity10271 : scanCanonicalize (H12AffineFastState.compose env10271 (packedSelected [5,8,13,15,17,19,21] rootPS)) = affineNative (2^(24+1) ^^^ 17074218) := by decide +kernel

theorem selectedBound10271 : packedSelected [5,8,13,15,17,19,21] rootPS < 2^1333 := by decide +kernel

def env10272 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,8,1296,32768,268,1296,262144,1025,32768,1296,261,17,16777216,17074218,16810009,17072137,16811288,1296,16779403,16811276,4294967296,257,4312008973,1296,17074211]

theorem envBound10272 : H12AffineFastState.Bounded env10272 := by
  intro p hp
  have h : env10272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10271_10272 : H12AffineEnvironment.transform 24 17074218 env10271 = env10272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 17074218 env10271 == env10272) = true)

theorem identity10272 : scanCanonicalize (H12AffineFastState.compose env10272 (packedSelected [1,3,5,6,8,10,19,25] rootPS)) = affineNative (2^(23+1) ^^^ 32776) := by decide +kernel

theorem selectedBound10272 : packedSelected [1,3,5,6,8,10,19,25] rootPS < 2^1333 := by decide +kernel

def env10273 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,8,1296,32768,268,1296,262144,1025,32768,1296,261,17,32776,264226,17,262145,1296,1296,34947,1284,4294967296,257,4295264517,1296,264235]

theorem envBound10273 : H12AffineFastState.Bounded env10273 := by
  intro p hp
  have h : env10273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10272_10273 : H12AffineEnvironment.transform 23 32776 env10272 = env10273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 32776 env10272 == env10273) = true)

theorem identity10273 : scanCanonicalize (H12AffineFastState.compose env10273 (packedSelected [1,10,12] rootPS)) = affineNative (2^(17+1) ^^^ 34947) := by decide +kernel

theorem selectedBound10273 : packedSelected [1,10,12] rootPS < 2^1333 := by decide +kernel

def env10274 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,8,1296,32768,268,1296,34947,1025,32768,1296,261,17,32776,32929,17,34946,1296,1296,34947,1284,4294967296,257,4294967686,1296,32936]

theorem envBound10274 : H12AffineFastState.Bounded env10274 := by
  intro p hp
  have h : env10274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10273_10274 : H12AffineEnvironment.transform 17 34947 env10273 = env10274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 34947 env10273 == env10274) = true)

theorem identity10274 : scanCanonicalize (H12AffineFastState.compose env10274 (packedSelected [1,13] rootPS)) = affineNative (2^(14+1) ^^^ 130) := by decide +kernel

theorem selectedBound10274 : packedSelected [1,13] rootPS < 2^1333 := by decide +kernel

def env10275 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,8,1296,130,268,1296,2049,1025,130,1296,261,17,138,35,17,2048,1296,1296,2049,1284,4294967296,257,4294967686,1296,42]

theorem envBound10275 : H12AffineFastState.Bounded env10275 := by
  intro p hp
  have h : env10275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10274_10275 : H12AffineEnvironment.transform 14 130 env10274 = env10275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 130 env10274 == env10275) = true)

theorem identity10275 : scanCanonicalize (H12AffineFastState.compose env10275 (packedSelected [0,4,7,9,10,11] rootPS)) = affineNative (2^(31+1) ^^^ 3464) := by decide +kernel

theorem selectedBound10275 : packedSelected [0,4,7,9,10,11] rootPS < 2^1333 := by decide +kernel

def env10276 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,8,1296,130,268,1296,2049,1025,130,1296,261,17,138,35,17,2048,1296,1296,2049,1284,3464,257,3086,1296,42]

theorem envBound10276 : H12AffineFastState.Bounded env10276 := by
  intro p hp
  have h : env10276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10275_10276 : H12AffineEnvironment.transform 31 3464 env10275 = env10276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 3464 env10275 == env10276) = true)

theorem identity10276 : scanCanonicalize (H12AffineFastState.compose env10276 (packedSelected [10,16] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound10276 : packedSelected [10,16] rootPS < 2^1333 := by decide +kernel

def env10277 : List Nat := [2,4,8,16,32,16,128,256,137,1024,260,1296,8,1296,130,268,1296,261,1025,130,1296,261,17,138,35,17,260,1296,1296,261,1284,1164,257,1290,1296,42]

theorem envBound10277 : H12AffineFastState.Bounded env10277 := by
  intro p hp
  have h : env10277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10276_10277 : H12AffineEnvironment.transform 10 260 env10276 = env10277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env10276 == env10277) = true)

def env10278 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,8,1297,32768,65536,1297,262144,1025,32768,1297,65545,16,16777216,33554432,16875797,17072137,16876564,1297,16845190,16876544,4294967296,257,4328554790,1297,33554441]

theorem envBound10278 : H12AffineFastState.Bounded env10278 := by
  intro p hp
  have h : env10278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10269_10278 : H12AffineEnvironment.transform 11 1297 env10269 = env10278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env10269 == env10278) = true)

theorem identity10278 : scanCanonicalize (H12AffineFastState.compose env10278 (packedSelected [3,5,24] rootPS)) = affineNative (2^(24+1) ^^^ 65796) := by decide +kernel

theorem selectedBound10278 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env10279 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,8,1297,32768,65536,1297,262144,1025,32768,1297,65545,16,16777216,65796,16875797,17072137,16876564,1297,16845190,16876544,4294967296,257,4295065634,1297,65805]

theorem envBound10279 : H12AffineFastState.Bounded env10279 := by
  intro p hp
  have h : env10279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10278_10279 : H12AffineEnvironment.transform 24 65796 env10278 = env10279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 65796 env10278 == env10279) = true)

theorem identity10279 : scanCanonicalize (H12AffineFastState.compose env10279 (packedSelected [5,8,10,12,13,15,17,19] rootPS)) = affineNative (2^(17+1) ^^^ 67745) := by decide +kernel

theorem selectedBound10279 : packedSelected [5,8,10,12,13,15,17,19] rootPS < 2^1333 := by decide +kernel

def env10280 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,8,1297,32768,65536,1297,67745,1025,32768,1297,65545,16,16777216,65796,16875797,16877736,16876564,1297,16845190,16876544,4294967296,257,4295065634,1297,65805]

theorem envBound10280 : H12AffineFastState.Bounded env10280 := by
  intro p hp
  have h : env10280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10279_10280 : H12AffineEnvironment.transform 17 67745 env10279 = env10280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67745 env10279 == env10280) = true)

theorem identity10280 : scanCanonicalize (H12AffineFastState.compose env10280 (packedSelected [1,3,5,10,12,13,15,17,26] rootPS)) = affineNative (2^(23+1) ^^^ 98565) := by decide +kernel

theorem selectedBound10280 : packedSelected [1,3,5,10,12,13,15,17,26] rootPS < 2^1333 := by decide +kernel

def env10281 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,8,1297,32768,65536,1297,67745,1025,32768,1297,65545,16,98565,65796,16,2477,1297,1297,34947,1285,4294967296,257,4295065634,1297,65805]

theorem envBound10281 : H12AffineFastState.Bounded env10281 := by
  intro p hp
  have h : env10281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10280_10281 : H12AffineEnvironment.transform 23 98565 env10280 = env10281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98565 env10280 == env10281) = true)

theorem identity10281 : scanCanonicalize (H12AffineFastState.compose env10281 (packedSelected [1,3,5] rootPS)) = affineNative (2^(15+1) ^^^ 32897) := by decide +kernel

theorem selectedBound10281 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env10282 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,8,1297,32768,32897,1297,34848,1025,32768,1297,32904,16,388,33157,16,2477,1297,1297,34947,1285,4294967296,257,4294967459,1297,33164]

theorem envBound10282 : H12AffineFastState.Bounded env10282 := by
  intro p hp
  have h : env10282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10281_10282 : H12AffineEnvironment.transform 15 32897 env10281 = env10282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32897 env10281 == env10282) = true)

theorem identity10282 : scanCanonicalize (H12AffineFastState.compose env10282 (packedSelected [3,10,12] rootPS)) = affineNative (2^(14+1) ^^^ 11) := by decide +kernel

theorem selectedBound10282 : packedSelected [3,10,12] rootPS < 2^1333 := by decide +kernel

def env10283 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,8,1297,11,138,1297,2091,1025,11,1297,131,16,388,398,16,2477,1297,1297,2184,1285,4294967296,257,4294967459,1297,391]

theorem envBound10283 : H12AffineFastState.Bounded env10283 := by
  intro p hp
  have h : env10283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10282_10283 : H12AffineEnvironment.transform 14 11 env10282 = env10283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 11 env10282 == env10283) = true)

theorem identity10283 : scanCanonicalize (H12AffineFastState.compose env10283 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound10283 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env10284 : List Nat := [2,4,8,16,32,16,128,173,137,1024,2048,1212,8,1212,11,138,1212,2091,1025,11,1212,131,16,41,35,16,2048,1212,1212,2184,1192,4294967296,172,4294967459,1212,42]

theorem envBound10284 : H12AffineFastState.Bounded env10284 := by
  intro p hp
  have h : env10284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10283_10284 : H12AffineEnvironment.transform 7 173 env10283 = env10284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env10283 == env10284) = true)

theorem identity10284 : scanCanonicalize (H12AffineFastState.compose env10284 (packedSelected [0,6,7] rootPS)) = affineNative (2^(31+1) ^^^ 42) := by decide +kernel

theorem selectedBound10284 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env10285 : List Nat := [2,4,8,16,32,16,128,173,137,1024,2048,1212,8,1212,11,138,1212,2091,1025,11,1212,131,16,41,35,16,2048,1212,1212,2184,1192,42,172,137,1212,42]

theorem envBound10285 : H12AffineFastState.Bounded env10285 := by
  intro p hp
  have h : env10285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10284_10285 : H12AffineEnvironment.transform 31 42 env10284 = env10285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 42 env10284 == env10285) = true)

theorem identity10285 : scanCanonicalize (H12AffineFastState.compose env10285 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound10285 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env10286 : List Nat := [2,4,8,16,32,16,2,47,11,1024,2048,1086,8,1086,11,8,1086,2091,1025,11,1086,1,16,41,35,16,2048,1086,1086,2058,1066,42,46,11,1086,42]

theorem envBound10286 : H12AffineFastState.Bounded env10286 := by
  intro p hp
  have h : env10286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10285_10286 : H12AffineEnvironment.transform 6 2 env10285 = env10286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env10285 == env10286) = true)

theorem identity10286 : scanCanonicalize (H12AffineFastState.compose env10286 (packedSelected [2,11] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound10286 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env10287 : List Nat := [2,4,8,16,32,16,2,47,11,1024,42,1086,8,1086,11,8,1086,1,1025,11,1086,1,16,41,35,16,42,1086,1086,32,1066,42,46,11,1086,42]

theorem envBound10287 : H12AffineFastState.Bounded env10287 := by
  intro p hp
  have h : env10287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10286_10287 : H12AffineEnvironment.transform 10 42 env10286 = env10287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env10286 == env10287) = true)

theorem identity10287 : scanCanonicalize (H12AffineFastState.compose env10287 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound10287 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10288 : List Nat := [2,4,2,16,32,16,2,37,1,1024,32,1076,2,1076,1,2,1076,1,1025,1,1076,1,16,35,35,16,32,1076,1076,32,1056,32,36,1,1076,32]

theorem envBound10288 : H12AffineFastState.Bounded env10288 := by
  intro p hp
  have h : env10288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10287_10288 : H12AffineEnvironment.transform 2 2 env10287 = env10288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env10287 == env10288) = true)

theorem identity10288 : scanCanonicalize (H12AffineFastState.compose env10288 (packedSelected [1,13] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound10288 : packedSelected [1,13] rootPS < 2^1333 := by decide +kernel

def env10289 : List Nat := [2,4,2,16,1,16,2,4,1,1024,1,1045,2,1045,1,2,1045,1,1025,1,1045,1,16,2,2,16,1,1045,1045,1,1025,1,5,1,1045,1]

theorem envBound10289 : H12AffineFastState.Bounded env10289 := by
  intro p hp
  have h : env10289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10288_10289 : H12AffineEnvironment.transform 4 1 env10288 = env10289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env10288 == env10289) = true)

theorem identity10289 : scanCanonicalize (H12AffineFastState.compose env10289 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound10289 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10290 : List Nat := [2,4,2,3,1,3,2,4,1,1024,1,1030,2,1030,1,2,1030,1,1025,1,1030,1,3,2,2,3,1,1030,1030,1,1025,1,5,1,1030,1]

theorem envBound10290 : H12AffineFastState.Bounded env10290 := by
  intro p hp
  have h : env10290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10289_10290 : H12AffineEnvironment.transform 3 3 env10289 = env10290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env10289 == env10290) = true)

theorem identity10290 : scanCanonicalize (H12AffineFastState.compose env10290 (packedSelected [10] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound10290 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env10291 : List Nat := [2,4,2,3,1,3,2,4,1,5,1,3,2,3,1,2,3,1,4,1,3,1,3,2,2,3,1,3,3,1,4,1,5,1,3,1]

theorem envBound10291 : H12AffineFastState.Bounded env10291 := by
  intro p hp
  have h : env10291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10290_10291 : H12AffineEnvironment.transform 9 5 env10290 = env10291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env10290 == env10291) = true)

def leafEnv10291 : List Nat := [2,4,2,3,1,3,2,4,1,5,1,3,2,3,1,2,3,1,4,1,3,1,3,2,5,2,1,3,1,3,3,1,4,1,5,1,5,2,3,1,0,3,1]

def active10291 : List Nat := [0,1]

def tree10291 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood10291 : H12WitnessSearch.Good tree10291 := H12GlobalWitnessIndex.good

theorem leafIdentity10291 : H12AffineFastState.composeSystem env10291 rootObs = leafEnv10291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env10291 rootObs == leafEnv10291) = true)

theorem terminalChecked10291 : H12PackedTerminal.terminalCheckFast leafEnv10291 active10291 tree10291 = true := by decide +kernel

def env10292 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,641,16384,32768,65536,4097,262144,1025,32768,4096,4194304,17665,16777216,33554432,16875796,21352448,16897045,4097,20978847,16876544,4294967296,257,4332832438,4097,33554441]

theorem envBound10292 : H12AffineFastState.Bounded env10292 := by
  intro p hp
  have h : env10292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10224_10292 : H12AffineEnvironment.transform 16 4097 env10224 = env10292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4097 env10224 == env10292) = true)

theorem identity10292 : scanCanonicalize (H12AffineFastState.compose env10292 (packedSelected [1,3,5,8,9,10,19,22] rootPS)) = affineNative (2^(13+1) ^^^ 1944) := by decide +kernel

theorem selectedBound10292 : packedSelected [1,3,5,8,9,10,19,22] rootPS < 2^1333 := by decide +kernel

def env10293 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,641,1944,32768,65536,4097,262144,1025,32768,4096,4194304,665,16777216,33554432,16875796,21338008,16880525,4097,20978847,16876544,4294967296,257,4332814638,4097,33554441]

theorem envBound10293 : H12AffineFastState.Bounded env10293 := by
  intro p hp
  have h : env10293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10292_10293 : H12AffineEnvironment.transform 13 1944 env10292 = env10293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1944 env10292 == env10293) = true)

def env10294 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,9,1296,32768,65536,4097,262144,1025,32768,4096,4194304,17,16777216,33554432,16875796,21337360,16879877,4097,20978847,16876544,4294967296,257,4332814638,4097,33554441]

theorem envBound10294 : H12AffineFastState.Bounded env10294 := by
  intro p hp
  have h : env10294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10293_10294 : H12AffineEnvironment.transform 8 136 env10293 = env10294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env10293 == env10294) = true)

theorem identity10294 : scanCanonicalize (H12AffineFastState.compose env10294 (packedSelected [3,6,10,24,25,26] rootPS)) = affineNative (2^(23+1) ^^^ 103445) := by decide +kernel

theorem selectedBound10294 : packedSelected [3,6,10,24,25,26] rootPS < 2^1333 := by decide +kernel

def env10295 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,9,1296,32768,65536,4097,262144,1025,32768,4096,4194304,17,103445,33554432,5377,4456709,1296,4097,4294794,4117,4294967296,257,4332814638,4097,33554441]

theorem envBound10295 : H12AffineFastState.Bounded env10295 := by
  intro p hp
  have h : env10295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10294_10295 : H12AffineEnvironment.transform 23 103445 env10294 = env10295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 103445 env10294 == env10295) = true)

theorem identity10295 : scanCanonicalize (H12AffineFastState.compose env10295 (packedSelected [3,5,8,10,13,15,17,21,24] rootPS)) = affineNative (2^(24+1) ^^^ 128) := by decide +kernel

theorem selectedBound10295 : packedSelected [3,5,8,10,13,15,17,21,24] rootPS < 2^1333 := by decide +kernel

def env10296 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,9,1296,32768,65536,4097,262144,1025,32768,4096,4194304,17,103445,128,5377,4456709,1296,4097,4294794,4117,4294967296,257,4299260334,4097,137]

theorem envBound10296 : H12AffineFastState.Bounded env10296 := by
  intro p hp
  have h : env10296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10295_10296 : H12AffineEnvironment.transform 24 128 env10295 = env10296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 128 env10295 == env10296) = true)

theorem identity10296 : scanCanonicalize (H12AffineFastState.compose env10296 (packedSelected [5,8,17,21] rootPS)) = affineNative (2^(14+1) ^^^ 261) := by decide +kernel

theorem selectedBound10296 : packedSelected [5,8,17,21] rootPS < 2^1333 := by decide +kernel

def env10297 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,9,1296,261,65536,4097,262144,1025,261,4096,4194304,17,70928,128,5377,4456709,1296,4097,4262287,4117,4294967296,257,4299227307,4097,137]

theorem envBound10297 : H12AffineFastState.Bounded env10297 := by
  intro p hp
  have h : env10297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10296_10297 : H12AffineEnvironment.transform 14 261 env10296 = env10297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 261 env10296 == env10297) = true)

theorem identity10297 : scanCanonicalize (H12AffineFastState.compose env10297 (packedSelected [5,6,8,10,12,13] rootPS)) = affineNative (2^(31+1) ^^^ 4456491) := by decide +kernel

theorem selectedBound10297 : packedSelected [5,6,8,10,12,13] rootPS < 2^1333 := by decide +kernel

def env10298 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,9,1296,261,65536,4097,262144,1025,261,4096,4194304,17,70928,128,5377,4456709,1296,4097,4262287,4117,4456491,257,327808,4097,137]

theorem envBound10298 : H12AffineFastState.Bounded env10298 := by
  intro p hp
  have h : env10298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10297_10298 : H12AffineEnvironment.transform 31 4456491 env10297 = env10298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4456491 env10297 == env10298) = true)

def env10299 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,1296,9,1296,261,65536,1297,262144,1025,261,1296,4194304,17,65536,128,17,4456709,1296,1297,4262287,1285,4456491,257,327808,1297,137]

theorem envBound10299 : H12AffineFastState.Bounded env10299 := by
  intro p hp
  have h : env10299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10298_10299 : H12AffineEnvironment.transform 11 1296 env10298 = env10299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env10298 == env10299) = true)

theorem identity10299 : scanCanonicalize (H12AffineFastState.compose env10299 (packedSelected [1,3,5] rootPS)) = affineNative (2^(17+1) ^^^ 67744) := by decide +kernel

theorem selectedBound10299 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env10300 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,1296,9,1296,261,65536,1297,67744,1025,261,1296,4194304,17,65536,128,17,4262309,1296,1297,4262287,1285,4262027,257,2080,1297,137]

theorem envBound10300 : H12AffineFastState.Bounded env10300 := by
  intro p hp
  have h : env10300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10299_10300 : H12AffineEnvironment.transform 17 67744 env10299 = env10300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67744 env10299 == env10300) = true)

theorem identity10300 : scanCanonicalize (H12AffineFastState.compose env10300 (packedSelected [1,3,8] rootPS)) = affineNative (2^(15+1) ^^^ 139) := by decide +kernel

theorem selectedBound10300 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env10301 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,1296,9,1296,261,139,1297,2091,1025,261,1296,4194304,17,139,128,17,4196654,1296,1297,4196612,1285,4196352,257,2080,1297,137]

theorem envBound10301 : H12AffineFastState.Bounded env10301 := by
  intro p hp
  have h : env10301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10300_10301 : H12AffineEnvironment.transform 15 139 env10300 = env10301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 139 env10300 == env10301) = true)

theorem identity10301 : scanCanonicalize (H12AffineFastState.compose env10301 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound10301 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env10302 : List Nat := [2,4,8,16,32,16,128,36,136,1024,2048,1076,9,1076,33,139,1077,2091,1025,33,1076,4194304,17,139,128,17,4196362,1076,1077,4196384,1057,4196352,37,2080,1077,137]

theorem envBound10302 : H12AffineFastState.Bounded env10302 := by
  intro p hp
  have h : env10302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10301_10302 : H12AffineEnvironment.transform 7 36 env10301 = env10302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env10301 == env10302) = true)

theorem identity10302 : scanCanonicalize (H12AffineFastState.compose env10302 (packedSelected [1,10] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound10302 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env10303 : List Nat := [2,4,8,16,32,16,128,36,136,1024,2048,1076,9,1076,33,139,1077,2091,1025,33,1076,32,17,139,128,17,2090,1076,1077,2048,1057,2080,37,2080,1077,137]

theorem envBound10303 : H12AffineFastState.Bounded env10303 := by
  intro p hp
  have h : env10303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10302_10303 : H12AffineEnvironment.transform 21 32 env10302 = env10303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env10302 == env10303) = true)

theorem identity10303 : scanCanonicalize (H12AffineFastState.compose env10303 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound10303 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10304 : List Nat := [2,4,8,16,32,16,19,36,27,1024,2048,1076,9,1076,33,24,1077,2091,1025,33,1076,32,17,24,19,17,2090,1076,1077,2048,1057,2080,37,2080,1077,26]

theorem envBound10304 : H12AffineFastState.Bounded env10304 := by
  intro p hp
  have h : env10304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10303_10304 : H12AffineEnvironment.transform 6 19 env10303 = env10304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env10303 == env10304) = true)

def env10305 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,1297,9,1296,261,65536,1296,262144,1025,261,1297,4194304,17,65537,128,16,4456709,1296,1296,4262287,1284,4456491,257,327808,1296,137]

theorem envBound10305 : H12AffineFastState.Bounded env10305 := by
  intro p hp
  have h : env10305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10298_10305 : H12AffineEnvironment.transform 11 1297 env10298 = env10305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env10298 == env10305) = true)

theorem identity10305 : scanCanonicalize (H12AffineFastState.compose env10305 (packedSelected [1,3,5] rootPS)) = affineNative (2^(21+1) ^^^ 65675) := by decide +kernel

theorem selectedBound10305 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env10306 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,1297,9,1296,261,65536,1296,262144,1025,261,1297,65675,17,65537,128,16,328078,1296,1296,2308,1284,327840,257,327808,1296,137]

theorem envBound10306 : H12AffineFastState.Bounded env10306 := by
  intro p hp
  have h : env10306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10305_10306 : H12AffineEnvironment.transform 21 65675 env10305 = env10306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65675 env10305 == env10306) = true)

theorem identity10306 : scanCanonicalize (H12AffineFastState.compose env10306 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound10306 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env10307 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,1297,9,1296,261,263,1296,262144,1025,261,1297,396,17,262,128,16,262281,1296,1296,2308,1284,262567,257,262535,1296,137]

theorem envBound10307 : H12AffineFastState.Bounded env10307 := by
  intro p hp
  have h : env10307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10306_10307 : H12AffineEnvironment.transform 15 263 env10306 = env10307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env10306 == env10307) = true)

theorem identity10307 : scanCanonicalize (H12AffineFastState.compose env10307 (packedSelected [1,3,8] rootPS)) = affineNative (2^(17+1) ^^^ 2217) := by decide +kernel

theorem selectedBound10307 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env10308 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,1297,9,1296,261,263,1296,2217,1025,261,1297,396,17,262,128,16,2080,1296,1296,2308,1284,2318,257,2350,1296,137]

theorem envBound10308 : H12AffineFastState.Bounded env10308 := by
  intro p hp
  have h : env10308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10307_10308 : H12AffineEnvironment.transform 17 2217 env10307 = env10308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2217 env10307 == env10308) = true)

theorem identity10308 : scanCanonicalize (H12AffineFastState.compose env10308 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound10308 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env10309 : List Nat := [2,4,8,16,32,16,34,256,42,1024,2048,1297,9,1296,261,263,1296,2059,1025,261,1297,302,17,262,34,16,2080,1296,1296,2308,1284,2318,257,2350,1296,43]

theorem envBound10309 : H12AffineFastState.Bounded env10309 := by
  intro p hp
  have h : env10309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10308_10309 : H12AffineEnvironment.transform 6 34 env10308 = env10309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env10308 == env10309) = true)

theorem identity10309 : scanCanonicalize (H12AffineFastState.compose env10309 (packedSelected [12] rootPS)) = affineNative (2^(10+1) ^^^ 302) := by decide +kernel

theorem selectedBound10309 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env10310 : List Nat := [2,4,8,16,32,16,34,256,42,1024,302,1297,9,1296,261,263,1296,293,1025,261,1297,302,17,262,34,16,270,1296,1296,42,1284,32,257,0,1296,43]

theorem envBound10310 : H12AffineFastState.Bounded env10310 := by
  intro p hp
  have h : env10310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10309_10310 : H12AffineEnvironment.transform 10 302 env10309 = env10310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 302 env10309 == env10310) = true)

theorem identity10310 : scanCanonicalize (H12AffineFastState.compose env10310 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound10310 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10311 : List Nat := [2,4,8,16,10,16,8,256,0,1024,260,1297,9,1296,261,263,1296,271,1025,261,1297,260,17,262,8,16,270,1296,1296,0,1284,10,257,0,1296,1]

theorem envBound10311 : H12AffineFastState.Bounded env10311 := by
  intro p hp
  have h : env10311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10310_10311 : H12AffineEnvironment.transform 4 10 env10310 = env10311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env10310 == env10311) = true)

theorem identity10311 : scanCanonicalize (H12AffineFastState.compose env10311 (packedSelected [2,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound10311 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env10312 : List Nat := [2,4,3,16,1,16,3,256,0,1024,260,1297,2,1296,261,263,1296,260,1025,261,1297,260,17,262,3,16,261,1296,1296,0,1284,1,257,0,1296,1]

theorem envBound10312 : H12AffineFastState.Bounded env10312 := by
  intro p hp
  have h : env10312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10311_10312 : H12AffineEnvironment.transform 2 3 env10311 = env10312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env10311 == env10312) = true)

theorem identity10312 : scanCanonicalize (H12AffineFastState.compose env10312 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound10312 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10313 : List Nat := [2,4,3,0,1,0,3,256,0,1024,260,1281,2,1280,261,263,1280,260,1025,261,1281,260,1,262,3,0,261,1280,1280,0,1284,1,257,0,1280,1]

theorem envBound10313 : H12AffineFastState.Bounded env10313 := by
  intro p hp
  have h : env10313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10312_10313 : H12AffineEnvironment.transform 3 0 env10312 = env10313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env10312 == env10313) = true)

theorem identity10313 : scanCanonicalize (H12AffineFastState.compose env10313 (packedSelected [7] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound10313 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env10314 : List Nat := [2,4,3,0,1,0,3,4,0,1024,0,1029,2,1028,1,3,1028,0,1025,1,1029,0,1,2,3,0,1,1028,1028,0,1024,1,5,0,1028,1]

theorem envBound10314 : H12AffineFastState.Bounded env10314 := by
  intro p hp
  have h : env10314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10313_10314 : H12AffineEnvironment.transform 7 4 env10313 = env10314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env10313 == env10314) = true)

def leafEnv10314 : List Nat := [2,4,3,0,1,0,3,4,0,1024,0,1029,2,1028,1,3,1028,0,1025,1,1029,0,1,2,1025,3,1,0,1,1028,1028,0,1024,1,5,0,5,2,1028,1,0,1028,1]

def active10314 : List Nat := [0,1,9]

def tree10314 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood10314 : H12WitnessSearch.Good tree10314 := H12GlobalWitnessIndex.good

theorem leafIdentity10314 : H12AffineFastState.composeSystem env10314 rootObs = leafEnv10314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env10314 rootObs == leafEnv10314) = true)

theorem terminalChecked10314 : H12PackedTerminal.terminalCheckFast leafEnv10314 active10314 tree10314 = true := by decide +kernel

def env10315 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,8,1297,32768,65536,4097,262144,1025,32768,4096,4194304,16,16777216,33554432,16875796,21337361,16879876,4097,20978847,16876544,4294967296,257,4332814638,4097,33554441]

theorem envBound10315 : H12AffineFastState.Bounded env10315 := by
  intro p hp
  have h : env10315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10293_10315 : H12AffineEnvironment.transform 8 137 env10293 = env10315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env10293 == env10315) = true)

theorem identity10315 : scanCanonicalize (H12AffineFastState.compose env10315 (packedSelected [3,6,10,24,25,26] rootPS)) = affineNative (2^(24+1) ^^^ 5520) := by decide +kernel

theorem selectedBound10315 : packedSelected [3,6,10,24,25,26] rootPS < 2^1333 := by decide +kernel

def env10316 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,8,1297,32768,65536,4097,262144,1025,32768,4096,4194304,16,16777216,5520,16875796,21337361,16879876,4097,20978847,16876544,4294967296,257,4299265214,4097,5529]

theorem envBound10316 : H12AffineFastState.Bounded env10316 := by
  intro p hp
  have h : env10316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10315_10316 : H12AffineEnvironment.transform 24 5520 env10315 = env10316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 5520 env10315 == env10316) = true)

theorem identity10316 : scanCanonicalize (H12AffineFastState.compose env10316 (packedSelected [1,3,5,6,8,10,19,25] rootPS)) = affineNative (2^(23+1) ^^^ 103445) := by decide +kernel

theorem selectedBound10316 : packedSelected [1,3,5,6,8,10,19,25] rootPS < 2^1333 := by decide +kernel

def env10317 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,8,1297,32768,65536,4097,262144,1025,32768,4096,4194304,16,103445,5520,5377,4456708,1297,4097,4294794,4117,4294967296,257,4299265214,4097,5529]

theorem envBound10317 : H12AffineFastState.Bounded env10317 := by
  intro p hp
  have h : env10317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10316_10317 : H12AffineEnvironment.transform 23 103445 env10316 = env10317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 103445 env10316 == env10317) = true)

theorem identity10317 : scanCanonicalize (H12AffineFastState.compose env10317 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound10317 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env10318 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,8,1297,32768,65536,1296,262144,1025,32768,1297,4194304,16,98564,129,16,4456708,1297,1296,4294794,1284,4294967296,257,4299260335,1296,136]

theorem envBound10318 : H12AffineFastState.Bounded env10318 := by
  intro p hp
  have h : env10318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10317_10318 : H12AffineEnvironment.transform 11 1297 env10317 = env10318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env10317 == env10318) = true)

theorem identity10318 : scanCanonicalize (H12AffineFastState.compose env10318 (packedSelected [1,3,5] rootPS)) = affineNative (2^(21+1) ^^^ 297253) := by decide +kernel

theorem selectedBound10318 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env10319 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,8,1297,32768,65536,1296,262144,1025,32768,1297,297253,16,98564,129,16,34849,1297,1296,328111,1284,4294967296,257,4295297162,1296,136]

theorem envBound10319 : H12AffineFastState.Bounded env10319 := by
  intro p hp
  have h : env10319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10318_10319 : H12AffineEnvironment.transform 21 297253 env10318 = env10319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 297253 env10318 == env10319) = true)

theorem identity10319 : scanCanonicalize (H12AffineFastState.compose env10319 (packedSelected [1,3,8] rootPS)) = affineNative (2^(15+1) ^^^ 33167) := by decide +kernel

theorem selectedBound10319 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env10320 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,8,1297,32768,33167,1296,262144,1025,32768,1297,297253,16,139,129,16,34849,1297,1296,294944,1284,4294967296,257,4295264517,1296,136]

theorem envBound10320 : H12AffineFastState.Bounded env10320 := by
  intro p hp
  have h : env10320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10319_10320 : H12AffineEnvironment.transform 15 33167 env10319 = env10320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33167 env10319 == env10320) = true)

theorem identity10320 : scanCanonicalize (H12AffineFastState.compose env10320 (packedSelected [1,3] rootPS)) = affineNative (2^(17+1) ^^^ 34849) := by decide +kernel

theorem selectedBound10320 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env10321 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,8,1297,32768,33167,1296,34849,1025,32768,1297,260,16,139,129,16,34849,1297,1296,2049,1284,4294967296,257,4294967588,1296,136]

theorem envBound10321 : H12AffineFastState.Bounded env10321 := by
  intro p hp
  have h : env10321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10320_10321 : H12AffineEnvironment.transform 17 34849 env10320 = env10321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 34849 env10320 == env10321) = true)

theorem identity10321 : scanCanonicalize (H12AffineFastState.compose env10321 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 3361) := by decide +kernel

theorem selectedBound10321 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10322 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,8,1297,32768,33167,1296,34849,1025,32768,1297,260,16,139,129,16,34849,1297,1296,2049,1284,3361,257,3077,1296,136]

theorem envBound10322 : H12AffineFastState.Bounded env10322 := by
  intro p hp
  have h : env10322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10321_10322 : H12AffineEnvironment.transform 31 3361 env10321 = env10322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 3361 env10321 == env10322) = true)

theorem identity10322 : scanCanonicalize (H12AffineFastState.compose env10322 (packedSelected [0,6] rootPS)) = affineNative (2^(10+1) ^^^ 261) := by decide +kernel

theorem selectedBound10322 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env10323 : List Nat := [2,4,8,16,32,16,128,256,137,1024,261,1297,8,1297,32768,33167,1296,33060,1025,32768,1297,260,16,139,129,16,33060,1297,1296,260,1284,1060,257,1280,1296,136]

theorem envBound10323 : H12AffineFastState.Bounded env10323 := by
  intro p hp
  have h : env10323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10322_10323 : H12AffineEnvironment.transform 10 261 env10322 = env10323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env10322 == env10323) = true)

theorem identity10323 : scanCanonicalize (H12AffineFastState.compose env10323 (packedSelected [2,4] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound10323 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env10324 : List Nat := [2,4,8,16,32,16,128,256,137,1024,261,1297,8,1297,292,171,1296,0,1025,292,1297,260,16,139,129,16,0,1297,1296,260,1284,1060,257,1280,1296,136]

theorem envBound10324 : H12AffineFastState.Bounded env10324 := by
  intro p hp
  have h : env10324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10323_10324 : H12AffineEnvironment.transform 14 292 env10323 = env10324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env10323 == env10324) = true)

def env10325 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,4096,4194304,17665,16777216,33554432,17010964,21352449,17024021,131073,21105823,16876544,4294967296,257,4332975158,131072,33563272]

theorem envBound10325 : H12AffineFastState.Bounded env10325 := by
  intro p hp
  have h : env10325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10137_10325 : H12AffineEnvironment.transform 5 17 env10137 = env10325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10137 == env10325) = true)

def env10326 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,640,16384,32768,65536,131072,262144,1025,32768,4096,4194304,17665,16777216,33554432,17010964,21352449,17024021,131073,21105823,16876544,4294967296,257,4332967606,131072,33554440]

theorem envBound10326 : H12AffineFastState.Bounded env10326 := by
  intro p hp
  have h : env10326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10325_10326 : H12AffineEnvironment.transform 12 640 env10325 = env10326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 640 env10325 == env10326) = true)

def env10327 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,640,16384,32768,65536,4096,262144,1025,32768,4096,4194304,17665,16777216,33554432,16875796,21352449,16897045,4097,20978847,16876544,4294967296,257,4332832438,4096,33554440]

theorem envBound10327 : H12AffineFastState.Bounded env10327 := by
  intro p hp
  have h : env10327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10326_10327 : H12AffineEnvironment.transform 16 4096 env10326 = env10327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env10326 == env10327) = true)

theorem identity10327 : scanCanonicalize (H12AffineFastState.compose env10327 (packedSelected [1,3,5,8,9,10,19,22] rootPS)) = affineNative (2^(24+1) ^^^ 16896389) := by decide +kernel

theorem selectedBound10327 : packedSelected [1,3,5,8,9,10,19,22] rootPS < 2^1333 := by decide +kernel

def env10328 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,640,16384,32768,65536,4096,262144,1025,32768,4096,4194304,17665,16777216,16896389,16875796,21352449,16897045,4097,20978847,16876544,4294967296,257,4315944755,4096,16896397]

theorem envBound10328 : H12AffineFastState.Bounded env10328 := by
  intro p hp
  have h : env10328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10327_10328 : H12AffineEnvironment.transform 24 16896389 env10327 = env10328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 16896389 env10327 == env10328) = true)

def env10329 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,4096,8,16384,32768,65536,4096,262144,1025,32768,4096,4194304,17665,16777216,16896389,16875796,21352449,16897045,4097,20978847,16876544,4294967296,257,4315944379,4096,16896397]

theorem envBound10329 : H12AffineFastState.Bounded env10329 := by
  intro p hp
  have h : env10329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10328_10329 : H12AffineEnvironment.transform 8 136 env10328 = env10329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env10328 == env10329) = true)

theorem identity10329 : scanCanonicalize (H12AffineFastState.compose env10329 (packedSelected [1,5,6,8,19,24,25,26] rootPS)) = affineNative (2^(13+1) ^^^ 1297) := by decide +kernel

theorem selectedBound10329 : packedSelected [1,5,6,8,19,24,25,26] rootPS < 2^1333 := by decide +kernel

def env10330 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,4096,8,1297,32768,65536,4096,262144,1025,32768,4096,4194304,16,16777216,16880788,16875796,21337360,16879876,4097,20978847,16876544,4294967296,257,4315944379,4096,16880796]

theorem envBound10330 : H12AffineFastState.Bounded env10330 := by
  intro p hp
  have h : env10330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10329_10330 : H12AffineEnvironment.transform 13 1297 env10329 = env10330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env10329 == env10330) = true)

theorem identity10330 : scanCanonicalize (H12AffineFastState.compose env10330 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(23+1) ^^^ 103445) := by decide +kernel

theorem selectedBound10330 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env10331 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,4096,8,1297,32768,65536,4096,262144,1025,32768,4096,4194304,16,103445,129,5377,4456709,1297,4097,4294794,4117,4294967296,257,4299260334,4096,137]

theorem envBound10331 : H12AffineFastState.Bounded env10331 := by
  intro p hp
  have h : env10331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10330_10331 : H12AffineEnvironment.transform 23 103445 env10330 = env10331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 103445 env10330 == env10331) = true)

theorem identity10331 : scanCanonicalize (H12AffineFastState.compose env10331 (packedSelected [5,8,17,21] rootPS)) = affineNative (2^(14+1) ^^^ 260) := by decide +kernel

theorem selectedBound10331 : packedSelected [5,8,17,21] rootPS < 2^1333 := by decide +kernel

def env10332 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,4096,8,1297,260,65536,4096,262144,1025,260,4096,4194304,16,70929,129,5377,4456709,1297,4097,4262286,4117,4294967296,257,4299227306,4096,137]

theorem envBound10332 : H12AffineFastState.Bounded env10332 := by
  intro p hp
  have h : env10332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10331_10332 : H12AffineEnvironment.transform 14 260 env10331 = env10332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 260 env10331 == env10332) = true)

theorem identity10332 : scanCanonicalize (H12AffineFastState.compose env10332 (packedSelected [5,6,8,10,12,13] rootPS)) = affineNative (2^(31+1) ^^^ 4461883) := by decide +kernel

theorem selectedBound10332 : packedSelected [5,6,8,10,12,13] rootPS < 2^1333 := by decide +kernel

def env10333 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,4096,8,1297,260,65536,4096,262144,1025,260,4096,4194304,16,70929,129,5377,4456709,1297,4097,4262286,4117,4461883,257,333201,4096,137]

theorem envBound10333 : H12AffineFastState.Bounded env10333 := by
  intro p hp
  have h : env10333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10332_10333 : H12AffineEnvironment.transform 31 4461883 env10332 = env10333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4461883 env10332 == env10333) = true)

def env10334 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1296,8,1297,260,65536,1296,262144,1025,260,1296,4194304,16,65537,129,17,4456709,1297,1297,4262286,1285,4456491,257,327809,1296,137]

theorem envBound10334 : H12AffineFastState.Bounded env10334 := by
  intro p hp
  have h : env10334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10333_10334 : H12AffineEnvironment.transform 11 1296 env10333 = env10334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env10333 == env10334) = true)

theorem identity10334 : scanCanonicalize (H12AffineFastState.compose env10334 (packedSelected [1,3,5] rootPS)) = affineNative (2^(17+1) ^^^ 67744) := by decide +kernel

theorem selectedBound10334 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env10335 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1296,8,1297,260,65536,1296,67744,1025,260,1296,4194304,16,65537,129,17,4262309,1297,1297,4262286,1285,4262027,257,2081,1296,137]

theorem envBound10335 : H12AffineFastState.Bounded env10335 := by
  intro p hp
  have h : env10335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10334_10335 : H12AffineEnvironment.transform 17 67744 env10334 = env10335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67744 env10334 == env10335) = true)

theorem identity10335 : scanCanonicalize (H12AffineFastState.compose env10335 (packedSelected [1,3,8] rootPS)) = affineNative (2^(15+1) ^^^ 138) := by decide +kernel

theorem selectedBound10335 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env10336 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1296,8,1297,260,138,1296,2090,1025,260,1296,4194304,16,139,129,17,4196655,1297,1297,4196612,1285,4196353,257,2081,1296,137]

theorem envBound10336 : H12AffineFastState.Bounded env10336 := by
  intro p hp
  have h : env10336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10335_10336 : H12AffineEnvironment.transform 15 138 env10335 = env10336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 138 env10335 == env10336) = true)

theorem identity10336 : scanCanonicalize (H12AffineFastState.compose env10336 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound10336 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env10337 : List Nat := [2,4,8,16,10,17,128,256,136,1024,2048,1296,8,1297,260,138,1296,2048,1025,260,1296,4194304,16,139,129,17,4196613,1297,1297,4196612,1285,4196353,257,2059,1296,137]

theorem envBound10337 : H12AffineFastState.Bounded env10337 := by
  intro p hp
  have h : env10337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10336_10337 : H12AffineEnvironment.transform 4 10 env10336 = env10337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env10336 == env10337) = true)

theorem identity10337 : scanCanonicalize (H12AffineFastState.compose env10337 (packedSelected [0,7] rootPS)) = affineNative (2^(21+1) ^^^ 2319) := by decide +kernel

theorem selectedBound10337 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env10338 : List Nat := [2,4,8,16,10,17,128,256,136,1024,2048,1296,8,1297,260,138,1296,2048,1025,260,1296,2319,16,139,129,17,10,1297,1297,11,1285,270,257,2059,1296,137]

theorem envBound10338 : H12AffineFastState.Bounded env10338 := by
  intro p hp
  have h : env10338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10337_10338 : H12AffineEnvironment.transform 21 2319 env10337 = env10338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2319 env10337 == env10338) = true)

theorem identity10338 : scanCanonicalize (H12AffineFastState.compose env10338 (packedSelected [1,10] rootPS)) = affineNative (2^(10+1) ^^^ 261) := by decide +kernel

theorem selectedBound10338 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env10339 : List Nat := [2,4,8,16,10,17,128,256,136,1024,261,1296,8,1297,260,138,1296,261,1025,260,1296,10,16,139,129,17,10,1297,1297,11,1285,270,257,270,1296,137]

theorem envBound10339 : H12AffineFastState.Bounded env10339 := by
  intro p hp
  have h : env10339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10338_10339 : H12AffineEnvironment.transform 10 261 env10338 = env10339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env10338 == env10339) = true)

theorem identity10339 : scanCanonicalize (H12AffineFastState.compose env10339 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound10339 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10340 : List Nat := [2,4,8,16,10,17,19,256,27,1024,261,1296,8,1297,260,25,1296,261,1025,260,1296,10,16,24,18,17,10,1297,1297,11,1285,270,257,270,1296,26]

theorem envBound10340 : H12AffineFastState.Bounded env10340 := by
  intro p hp
  have h : env10340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10339_10340 : H12AffineEnvironment.transform 6 19 env10339 = env10340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env10339 == env10340) = true)

def env10341 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1297,8,1297,260,65536,1297,262144,1025,260,1297,4194304,16,65536,129,16,4456709,1297,1296,4262286,1284,4456490,257,327808,1297,137]

theorem envBound10341 : H12AffineFastState.Bounded env10341 := by
  intro p hp
  have h : env10341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10333_10341 : H12AffineEnvironment.transform 11 1297 env10333 = env10341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env10333 == env10341) = true)

theorem identity10341 : scanCanonicalize (H12AffineFastState.compose env10341 (packedSelected [1,3,5] rootPS)) = affineNative (2^(21+1) ^^^ 65674) := by decide +kernel

theorem selectedBound10341 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env10342 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1297,8,1297,260,65536,1297,262144,1025,260,1297,65674,16,65536,129,16,328079,1297,1296,2308,1284,327840,257,327808,1297,137]

theorem envBound10342 : H12AffineFastState.Bounded env10342 := by
  intro p hp
  have h : env10342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10341_10342 : H12AffineEnvironment.transform 21 65674 env10341 = env10342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65674 env10341 == env10342) = true)

theorem identity10342 : scanCanonicalize (H12AffineFastState.compose env10342 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound10342 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env10343 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1297,8,1297,260,263,1297,262144,1025,260,1297,397,16,263,129,16,262280,1297,1296,2308,1284,262567,257,262535,1297,137]

theorem envBound10343 : H12AffineFastState.Bounded env10343 := by
  intro p hp
  have h : env10343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10342_10343 : H12AffineEnvironment.transform 15 263 env10342 = env10343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env10342 == env10343) = true)

theorem identity10343 : scanCanonicalize (H12AffineFastState.compose env10343 (packedSelected [1,3,8] rootPS)) = affineNative (2^(17+1) ^^^ 2216) := by decide +kernel

theorem selectedBound10343 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env10344 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1297,8,1297,260,263,1297,2216,1025,260,1297,397,16,263,129,16,2080,1297,1296,2308,1284,2319,257,2351,1297,137]

theorem envBound10344 : H12AffineFastState.Bounded env10344 := by
  intro p hp
  have h : env10344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10343_10344 : H12AffineEnvironment.transform 17 2216 env10343 = env10344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2216 env10343 == env10344) = true)

theorem identity10344 : scanCanonicalize (H12AffineFastState.compose env10344 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 47) := by decide +kernel

theorem selectedBound10344 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env10345 : List Nat := [2,4,8,16,32,17,128,47,136,1024,2048,1086,8,1086,43,40,1086,2216,1025,43,1086,162,16,40,129,16,2080,1086,1087,2091,1067,2080,46,2048,1086,137]

theorem envBound10345 : H12AffineFastState.Bounded env10345 := by
  intro p hp
  have h : env10345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10344_10345 : H12AffineEnvironment.transform 7 47 env10344 = env10345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 47 env10344 == env10345) = true)

theorem identity10345 : scanCanonicalize (H12AffineFastState.compose env10345 (packedSelected [12] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound10345 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env10346 : List Nat := [2,4,8,16,32,17,128,47,136,1024,1,1086,8,1086,43,40,1086,169,1025,43,1086,162,16,40,129,16,33,1086,1087,42,1067,33,46,1,1086,137]

theorem envBound10346 : H12AffineFastState.Bounded env10346 := by
  intro p hp
  have h : env10346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10345_10346 : H12AffineEnvironment.transform 10 1 env10345 = env10346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env10345 == env10346) = true)

theorem identity10346 : scanCanonicalize (H12AffineFastState.compose env10346 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 50) := by decide +kernel

theorem selectedBound10346 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env10347 : List Nat := [2,4,8,16,32,17,50,47,58,1024,1,1086,8,1086,43,40,1086,27,1025,43,1086,16,16,40,51,16,33,1086,1087,42,1067,33,46,1,1086,59]

theorem envBound10347 : H12AffineFastState.Bounded env10347 := by
  intro p hp
  have h : env10347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10346_10347 : H12AffineEnvironment.transform 6 50 env10346 = env10347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 50 env10346 == env10347) = true)

theorem identity10347 : scanCanonicalize (H12AffineFastState.compose env10347 (packedSelected [0,2,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound10347 : packedSelected [0,2,7,9] rootPS < 2^1333 := by decide +kernel

def env10348 : List Nat := [2,4,8,16,1,17,19,14,27,1024,1,1055,8,1055,10,9,1055,27,1025,10,1055,16,16,9,18,16,0,1055,1054,11,1034,0,15,1,1055,26]

theorem envBound10348 : H12AffineFastState.Bounded env10348 := by
  intro p hp
  have h : env10348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10347_10348 : H12AffineEnvironment.transform 4 1 env10347 = env10348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env10347 == env10348) = true)

theorem identity10348 : scanCanonicalize (H12AffineFastState.compose env10348 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound10348 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env10349 : List Nat := [2,4,8,0,1,1,3,14,11,1024,1,1039,8,1039,10,9,1039,11,1025,10,1039,0,0,9,2,0,0,1039,1038,11,1034,0,15,1,1039,10]

theorem envBound10349 : H12AffineFastState.Bounded env10349 := by
  intro p hp
  have h : env10349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10348_10349 : H12AffineEnvironment.transform 3 0 env10348 = env10349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env10348 == env10349) = true)

theorem identity10349 : scanCanonicalize (H12AffineFastState.compose env10349 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound10349 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10350 : List Nat := [2,4,2,0,1,1,3,4,1,1024,1,1029,2,1029,0,3,1029,1,1025,0,1029,0,0,3,2,0,0,1029,1028,1,1024,0,5,1,1029,0]

theorem envBound10350 : H12AffineFastState.Bounded env10350 := by
  intro p hp
  have h : env10350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10349_10350 : H12AffineEnvironment.transform 2 2 env10349 = env10350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env10349 == env10350) = true)

def leafEnv10350 : List Nat := [2,4,2,0,1,1,3,4,1,1024,1,1029,2,1029,0,3,1029,1,1025,0,1029,0,0,3,1025,2,1,0,0,1029,1028,1,1024,0,5,1,5,3,1029,0,0,1028,1]

def active10350 : List Nat := [0,1,9]

def tree10350 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood10350 : H12WitnessSearch.Good tree10350 := H12GlobalWitnessIndex.good

theorem leafIdentity10350 : H12AffineFastState.composeSystem env10350 rootObs = leafEnv10350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env10350 rootObs == leafEnv10350) = true)

theorem terminalChecked10350 : H12PackedTerminal.terminalCheckFast leafEnv10350 active10350 tree10350 = true := by decide +kernel

def env10351 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,4096,9,16384,32768,65536,4096,262144,1025,32768,4096,4194304,17665,16777216,16896389,16875796,21352449,16897045,4097,20978847,16876544,4294967296,257,4315944378,4096,16896397]

theorem envBound10351 : H12AffineFastState.Bounded env10351 := by
  intro p hp
  have h : env10351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10328_10351 : H12AffineEnvironment.transform 8 137 env10328 = env10351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env10328 == env10351) = true)

theorem identity10351 : scanCanonicalize (H12AffineFastState.compose env10351 (packedSelected [1,5,6,8,19,24,25,26] rootPS)) = affineNative (2^(23+1) ^^^ 103445) := by decide +kernel

theorem selectedBound10351 : packedSelected [1,5,6,8,19,24,25,26] rootPS < 2^1333 := by decide +kernel

def env10352 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,4096,9,16384,32768,65536,4096,262144,1025,32768,4096,4194304,17665,103445,17808,5377,4473876,16384,4097,4294794,4117,4294967296,257,4299260335,4096,17816]

theorem envBound10352 : H12AffineFastState.Bounded env10352 := by
  intro p hp
  have h : env10352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10351_10352 : H12AffineEnvironment.transform 23 103445 env10351 = env10352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 103445 env10351 == env10352) = true)

theorem identity10352 : scanCanonicalize (H12AffineFastState.compose env10352 (packedSelected [0,1,3,4,7,9,10,16,17,19,20,21] rootPS)) = affineNative (2^(13+1) ^^^ 4097) := by decide +kernel

theorem selectedBound10352 : packedSelected [0,1,3,4,7,9,10,16,17,19,20,21] rootPS < 2^1333 := by decide +kernel

def env10353 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,4096,9,4097,32768,65536,4096,262144,1025,32768,4096,4194304,5376,103445,5521,5377,4461589,4097,4097,4294794,4117,4294967296,257,4299260335,4096,5529]

theorem envBound10353 : H12AffineFastState.Bounded env10353 := by
  intro p hp
  have h : env10353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10352_10353 : H12AffineEnvironment.transform 13 4097 env10352 = env10353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4097 env10352 == env10353) = true)

theorem identity10353 : scanCanonicalize (H12AffineFastState.compose env10353 (packedSelected [13,17] rootPS)) = affineNative (2^(15+1) ^^^ 33167) := by decide +kernel

theorem selectedBound10353 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env10354 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,4096,9,4097,32768,33167,4096,262144,1025,32768,4096,4194304,5376,5530,5521,5377,4461589,4097,4097,4196613,4117,4294967296,257,4299161632,4096,5529]

theorem envBound10354 : H12AffineFastState.Bounded env10354 := by
  intro p hp
  have h : env10354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10353_10354 : H12AffineEnvironment.transform 15 33167 env10353 = env10354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33167 env10353 == env10354) = true)

theorem identity10354 : scanCanonicalize (H12AffineFastState.compose env10354 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(17+1) ^^^ 34849) := by decide +kernel

theorem selectedBound10354 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env10355 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,4096,9,4097,32768,33167,4096,34849,1025,32768,4096,4194304,5376,5530,5521,5377,4234292,4097,4097,4196613,4117,4294967296,257,4299161632,4096,5529]

theorem envBound10355 : H12AffineFastState.Bounded env10355 := by
  intro p hp
  have h : env10355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10354_10355 : H12AffineEnvironment.transform 17 34849 env10354 = env10355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 34849 env10354 == env10355) = true)

theorem identity10355 : scanCanonicalize (H12AffineFastState.compose env10355 (packedSelected [3,5,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound10355 : packedSelected [3,5,10,12] rootPS < 2^1333 := by decide +kernel

def env10356 : List Nat := [2,4,8,16,32,17,128,256,137,1024,260,4096,9,4097,32768,33167,4096,33061,1025,32768,4096,4194304,5376,5530,5521,5377,4232496,4097,4097,4194305,4117,4294967296,257,4299161632,4096,5529]

theorem envBound10356 : H12AffineFastState.Bounded env10356 := by
  intro p hp
  have h : env10356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10355_10356 : H12AffineEnvironment.transform 10 260 env10355 = env10356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env10355 == env10356) = true)

theorem identity10356 : scanCanonicalize (H12AffineFastState.compose env10356 (packedSelected [0,2,4,6,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound10356 : packedSelected [0,2,4,6,8,11] rootPS < 2^1333 := by decide +kernel

def env10357 : List Nat := [2,4,8,16,32,17,128,256,137,1024,260,1296,9,1297,32768,33167,1296,33061,1025,32768,1296,4194304,16,138,129,17,4227104,1297,1297,4194305,1285,4294967296,257,4299161632,1296,137]

theorem envBound10357 : H12AffineFastState.Bounded env10357 := by
  intro p hp
  have h : env10357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10356_10357 : H12AffineEnvironment.transform 11 1296 env10356 = env10357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env10356 == env10357) = true)

theorem identity10357 : scanCanonicalize (H12AffineFastState.compose env10357 (packedSelected [1] rootPS)) = affineNative (2^(21+1) ^^^ 32930) := by decide +kernel

theorem selectedBound10357 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10358 : List Nat := [2,4,8,16,32,17,128,256,137,1024,260,1296,9,1297,32768,33167,1296,33061,1025,32768,1296,32930,16,138,129,17,130,1297,1297,32931,1285,4294967296,257,4295000194,1296,137]

theorem envBound10358 : H12AffineFastState.Bounded env10358 := by
  intro p hp
  have h : env10358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10357_10358 : H12AffineEnvironment.transform 21 32930 env10357 = env10358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32930 env10357 == env10358) = true)

theorem identity10358 : scanCanonicalize (H12AffineFastState.compose env10358 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound10358 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env10359 : List Nat := [2,4,8,16,32,17,128,37,137,1024,33,1077,9,1076,32768,32938,1077,32768,1025,32768,1077,32930,16,138,129,17,130,1076,1076,32931,1056,4294967296,36,4295000194,1077,137]

theorem envBound10359 : H12AffineFastState.Bounded env10359 := by
  intro p hp
  have h : env10359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10358_10359 : H12AffineEnvironment.transform 7 37 env10358 = env10359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env10358 == env10359) = true)

theorem identity10359 : scanCanonicalize (H12AffineFastState.compose env10359 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound10359 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env10360 : List Nat := [2,4,8,16,11,17,128,14,137,1024,10,1054,9,1055,32768,32897,1054,32768,1025,32768,1054,32905,16,138,129,17,130,1055,1055,32904,1035,4294967296,15,4295000194,1054,137]

theorem envBound10360 : H12AffineFastState.Bounded env10360 := by
  intro p hp
  have h : env10360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10359_10360 : H12AffineEnvironment.transform 4 11 env10359 = env10360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env10359 == env10360) = true)

theorem identity10360 : scanCanonicalize (H12AffineFastState.compose env10360 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 32913) := by decide +kernel

theorem selectedBound10360 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10361 : List Nat := [2,4,8,16,11,17,128,14,137,1024,10,1054,9,1055,32768,32897,1054,32768,1025,32768,1054,32905,16,138,129,17,130,1055,1055,32904,1035,32913,15,19,1054,137]

theorem envBound10361 : H12AffineFastState.Bounded env10361 := by
  intro p hp
  have h : env10361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10360_10361 : H12AffineEnvironment.transform 31 32913 env10360 = env10361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 32913 env10360 == env10361) = true)

theorem identity10361 : scanCanonicalize (H12AffineFastState.compose env10361 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 24) := by decide +kernel

theorem selectedBound10361 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env10362 : List Nat := [2,4,8,16,11,17,128,14,137,1024,10,1054,9,1055,24,153,1054,24,1025,24,1054,145,16,138,129,17,130,1055,1055,144,1035,137,15,19,1054,137]

theorem envBound10362 : H12AffineFastState.Bounded env10362 := by
  intro p hp
  have h : env10362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10361_10362 : H12AffineEnvironment.transform 14 24 env10361 = env10362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 24 env10361 == env10362) = true)

def env10363 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,640,16384,32768,65536,4097,262144,1025,32768,4096,4194304,17665,16777216,33554432,16875797,21352449,16897044,4096,20978846,16876544,4294967296,257,4332832439,4097,33554440]

theorem envBound10363 : H12AffineFastState.Bounded env10363 := by
  intro p hp
  have h : env10363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10326_10363 : H12AffineEnvironment.transform 16 4097 env10326 = env10363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4097 env10326 == env10363) = true)

theorem identity10363 : scanCanonicalize (H12AffineFastState.compose env10363 (packedSelected [1,3,5,8,9,10,19,22] rootPS)) = affineNative (2^(24+1) ^^^ 16893077) := by decide +kernel

theorem selectedBound10363 : packedSelected [1,3,5,8,9,10,19,22] rootPS < 2^1333 := by decide +kernel

def env10364 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,640,16384,32768,65536,4097,262144,1025,32768,4096,4194304,17665,16777216,16893077,16875797,21352449,16897044,4096,20978846,16876544,4294967296,257,4315939362,4097,16893085]

theorem envBound10364 : H12AffineFastState.Bounded env10364 := by
  intro p hp
  have h : env10364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10363_10364 : H12AffineEnvironment.transform 24 16893077 env10363 = env10364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 16893077 env10363 == env10364) = true)

def env10365 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,4096,8,16384,32768,65536,4097,262144,1025,32768,4096,4194304,17665,16777216,16893077,16875797,21352449,16897044,4096,20978846,16876544,4294967296,257,4315938986,4097,16893085]

theorem envBound10365 : H12AffineFastState.Bounded env10365 := by
  intro p hp
  have h : env10365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10364_10365 : H12AffineEnvironment.transform 8 136 env10364 = env10365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env10364 == env10365) = true)

theorem identity10365 : scanCanonicalize (H12AffineFastState.compose env10365 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(23+1) ^^^ 119044) := by decide +kernel

theorem selectedBound10365 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env10366 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,4096,8,16384,32768,65536,4097,262144,1025,32768,4096,4194304,17665,119044,5521,20497,4456709,1296,4096,4312474,21764,4294967296,257,4299280814,4097,5529]

theorem envBound10366 : H12AffineFastState.Bounded env10366 := by
  intro p hp
  have h : env10366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10365_10366 : H12AffineEnvironment.transform 23 119044 env10365 = env10366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 119044 env10365 == env10366) = true)

theorem identity10366 : scanCanonicalize (H12AffineFastState.compose env10366 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 1296) := by decide +kernel

theorem selectedBound10366 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env10367 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,4096,8,1296,32768,65536,4097,262144,1025,32768,4096,4194304,17,103444,5521,5377,4456709,1296,4096,4294794,4116,4294967296,257,4299265214,4097,5529]

theorem envBound10367 : H12AffineFastState.Bounded env10367 := by
  intro p hp
  have h : env10367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10366_10367 : H12AffineEnvironment.transform 13 1296 env10366 = env10367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env10366 == env10367) = true)

theorem identity10367 : scanCanonicalize (H12AffineFastState.compose env10367 (packedSelected [4,5,8,9,13,16,17] rootPS)) = affineNative (2^(21+1) ^^^ 32904) := by decide +kernel

theorem selectedBound10367 : packedSelected [4,5,8,9,13,16,17] rootPS < 2^1333 := by decide +kernel

def env10368 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,4096,8,1296,32768,65536,4097,262144,1025,32768,4096,32904,17,103444,5521,5377,295309,1296,4096,67586,4116,4294967296,257,4295038006,4097,5529]

theorem envBound10368 : H12AffineFastState.Bounded env10368 := by
  intro p hp
  have h : env10368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10367_10368 : H12AffineEnvironment.transform 21 32904 env10367 = env10368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32904 env10367 == env10368) = true)

theorem identity10368 : scanCanonicalize (H12AffineFastState.compose env10368 (packedSelected [5,8,10,12,13] rootPS)) = affineNative (2^(17+1) ^^^ 72895) := by decide +kernel

theorem selectedBound10368 : packedSelected [5,8,10,12,13] rootPS < 2^1333 := by decide +kernel

def env10369 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,4096,8,1296,32768,65536,4097,72895,1025,32768,4096,32904,17,103444,5521,5377,105778,1296,4096,67586,4116,4294967296,257,4295038006,4097,5529]

theorem envBound10369 : H12AffineFastState.Bounded env10369 := by
  intro p hp
  have h : env10369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10368_10369 : H12AffineEnvironment.transform 17 72895 env10368 = env10369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 72895 env10368 == env10369) = true)

theorem identity10369 : scanCanonicalize (H12AffineFastState.compose env10369 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound10369 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env10370 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,4096,8,1296,32768,33166,4097,40241,1025,32768,4096,32904,17,5530,5521,5377,7356,1296,4096,35212,4116,4294967296,257,4295005624,4097,5529]

theorem envBound10370 : H12AffineFastState.Bounded env10370 := by
  intro p hp
  have h : env10370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10369_10370 : H12AffineEnvironment.transform 15 33166 env10369 = env10370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env10369 == env10370) = true)

theorem identity10370 : scanCanonicalize (H12AffineFastState.compose env10370 (packedSelected [0,1,2,4,8,10,11,12] rootPS)) = affineNative (2^(31+1) ^^^ 32898) := by decide +kernel

theorem selectedBound10370 : packedSelected [0,1,2,4,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env10371 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,4096,8,1296,32768,33166,4097,40241,1025,32768,4096,32904,17,5530,5521,5377,7356,1296,4096,35212,4116,32898,257,5434,4097,5529]

theorem envBound10371 : H12AffineFastState.Bounded env10371 := by
  intro p hp
  have h : env10371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10370_10371 : H12AffineEnvironment.transform 31 32898 env10370 = env10371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 32898 env10370 == env10371) = true)

theorem identity10371 : scanCanonicalize (H12AffineFastState.compose env10371 (packedSelected [3,6,8] rootPS)) = affineNative (2^(14+1) ^^^ 303) := by decide +kernel

theorem selectedBound10371 : packedSelected [3,6,8] rootPS < 2^1333 := by decide +kernel

def env10372 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,4096,8,1296,303,161,4097,7198,1025,303,4096,423,17,5530,5521,5377,7356,1296,4096,2211,4116,429,257,5434,4097,5529]

theorem envBound10372 : H12AffineFastState.Bounded env10372 := by
  intro p hp
  have h : env10372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10371_10372 : H12AffineEnvironment.transform 14 303 env10371 = env10372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 303 env10371 == env10372) = true)

theorem identity10372 : scanCanonicalize (H12AffineFastState.compose env10372 (packedSelected [0,2,4,6,11] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound10372 : packedSelected [0,2,4,6,11] rootPS < 2^1333 := by decide +kernel

def env10373 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1296,8,1296,303,161,1297,2318,1025,303,1296,423,17,138,129,17,2476,1296,1296,2211,1284,429,257,42,1297,137]

theorem envBound10373 : H12AffineFastState.Bounded env10373 := by
  intro p hp
  have h : env10373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10372_10373 : H12AffineEnvironment.transform 11 1296 env10372 = env10373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env10372 == env10373) = true)

theorem identity10373 : scanCanonicalize (H12AffineFastState.compose env10373 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound10373 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10374 : List Nat := [2,4,8,16,32,17,128,256,136,1024,137,1296,8,1296,303,161,1297,391,1025,303,1296,423,17,138,129,17,293,1296,1296,42,1284,429,257,42,1297,137]

theorem envBound10374 : H12AffineFastState.Bounded env10374 := by
  intro p hp
  have h : env10374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10373_10374 : H12AffineEnvironment.transform 10 137 env10373 = env10374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env10373 == env10374) = true)

theorem identity10374 : scanCanonicalize (H12AffineFastState.compose env10374 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound10374 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env10375 : List Nat := [2,4,8,16,32,17,2,256,10,1024,11,1296,8,1296,303,35,1297,261,1025,303,1296,293,17,8,3,17,293,1296,1296,42,1284,303,257,42,1297,11]

theorem envBound10375 : H12AffineFastState.Bounded env10375 := by
  intro p hp
  have h : env10375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10374_10375 : H12AffineEnvironment.transform 6 2 env10374 = env10375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env10374 == env10375) = true)

theorem identity10375 : scanCanonicalize (H12AffineFastState.compose env10375 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound10375 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env10376 : List Nat := [2,4,8,16,32,17,2,15,10,1024,11,1055,8,1055,32,35,1054,10,1025,32,1055,42,17,8,3,17,42,1055,1055,42,1035,32,14,42,1054,11]

theorem envBound10376 : H12AffineFastState.Bounded env10376 := by
  intro p hp
  have h : env10376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10375_10376 : H12AffineEnvironment.transform 7 15 env10375 = env10376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env10375 == env10376) = true)

theorem identity10376 : scanCanonicalize (H12AffineFastState.compose env10376 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound10376 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10377 : List Nat := [2,4,3,16,32,17,2,4,1,1024,0,1044,3,1044,32,35,1045,1,1025,32,1044,33,17,3,3,17,33,1044,1044,33,1024,32,5,33,1045,0]

theorem envBound10377 : H12AffineFastState.Bounded env10377 := by
  intro p hp
  have h : env10377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10376_10377 : H12AffineEnvironment.transform 2 3 env10376 = env10377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env10376 == env10377) = true)

theorem identity10377 : scanCanonicalize (H12AffineFastState.compose env10377 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound10377 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10378 : List Nat := [2,4,3,16,16,17,2,4,1,1024,0,1044,3,1044,16,19,1045,1,1025,16,1044,17,17,3,3,17,17,1044,1044,17,1024,16,5,17,1045,0]

theorem envBound10378 : H12AffineFastState.Bounded env10378 := by
  intro p hp
  have h : env10378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10377_10378 : H12AffineEnvironment.transform 4 16 env10377 = env10378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env10377 == env10378) = true)

theorem identity10378 : scanCanonicalize (H12AffineFastState.compose env10378 (packedSelected [10] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound10378 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env10379 : List Nat := [2,4,3,1,1,0,2,4,1,1024,0,1029,3,1029,1,2,1028,1,1025,1,1029,0,0,3,3,0,0,1029,1029,0,1024,1,5,0,1028,0]

theorem envBound10379 : H12AffineFastState.Bounded env10379 := by
  intro p hp
  have h : env10379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10378_10379 : H12AffineEnvironment.transform 3 1 env10378 = env10379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env10378 == env10379) = true)

def leafEnv10379 : List Nat := [2,4,3,1,1,0,2,4,1,1024,0,1029,3,1029,1,2,1028,1,1025,1,1029,0,0,3,1025,3,1,0,0,1029,1029,0,1024,1,5,0,5,2,1028,0,0,1029,1]

def active10379 : List Nat := [0,1,9]

def tree10379 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood10379 : H12WitnessSearch.Good tree10379 := H12GlobalWitnessIndex.good

theorem leafIdentity10379 : H12AffineFastState.composeSystem env10379 rootObs = leafEnv10379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env10379 rootObs == leafEnv10379) = true)

theorem terminalChecked10379 : H12PackedTerminal.terminalCheckFast leafEnv10379 active10379 tree10379 = true := by decide +kernel

def env10380 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,4096,9,16384,32768,65536,4097,262144,1025,32768,4096,4194304,17665,16777216,16893077,16875797,21352449,16897044,4096,20978846,16876544,4294967296,257,4315938987,4097,16893085]

theorem envBound10380 : H12AffineFastState.Bounded env10380 := by
  intro p hp
  have h : env10380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10364_10380 : H12AffineEnvironment.transform 8 137 env10364 = env10380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env10364 == env10380) = true)

theorem identity10380 : scanCanonicalize (H12AffineFastState.compose env10380 (packedSelected [6,25] rootPS)) = affineNative (2^(23+1) ^^^ 115733) := by decide +kernel

theorem selectedBound10380 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env10381 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,4096,9,16384,32768,65536,4097,262144,1025,32768,4096,4194304,17665,115733,128,17664,4461588,4097,4096,4315275,16405,4294967296,257,4299277502,4097,136]

theorem envBound10381 : H12AffineFastState.Bounded env10381 := by
  intro p hp
  have h : env10381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10380_10381 : H12AffineEnvironment.transform 23 115733 env10380 = env10381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 115733 env10380 == env10381) = true)

theorem identity10381 : scanCanonicalize (H12AffineFastState.compose env10381 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 4097) := by decide +kernel

theorem selectedBound10381 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env10382 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,4096,9,4097,32768,65536,4097,262144,1025,32768,4096,4194304,5376,103444,128,5377,4461588,4097,4096,4294794,4116,4294967296,257,4299265215,4097,136]

theorem envBound10382 : H12AffineFastState.Bounded env10382 := by
  intro p hp
  have h : env10382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10381_10382 : H12AffineEnvironment.transform 13 4097 env10381 = env10382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4097 env10381 == env10382) = true)

def env10383 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,641,16384,32768,65536,131072,262144,1025,32768,4096,4194304,17665,16777216,33554432,17010964,21352449,17024021,131073,21105823,16876544,4294967296,257,4332967607,131072,33554441]

theorem envBound10383 : H12AffineFastState.Bounded env10383 := by
  intro p hp
  have h : env10383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10325_10383 : H12AffineEnvironment.transform 12 641 env10325 = env10383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 641 env10325 == env10383) = true)

def env10384 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,641,16384,32768,65536,4096,262144,1025,32768,4096,4194304,17665,16777216,33554432,16875796,21352449,16897045,4097,20978847,16876544,4294967296,257,4332832439,4096,33554441]

theorem envBound10384 : H12AffineFastState.Bounded env10384 := by
  intro p hp
  have h : env10384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10383_10384 : H12AffineEnvironment.transform 16 4096 env10383 = env10384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env10383 == env10384) = true)

theorem identity10384 : scanCanonicalize (H12AffineFastState.compose env10384 (packedSelected [1,3,5,8,9,10,19,22] rootPS)) = affineNative (2^(23+1) ^^^ 119692) := by decide +kernel

theorem selectedBound10384 : packedSelected [1,3,5,8,9,10,19,22] rootPS < 2^1333 := by decide +kernel

def env10385 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,641,16384,32768,65536,4096,262144,1025,32768,4096,4194304,17665,119692,33554432,21144,4457357,1945,4097,4312851,22412,4294967296,257,4332832439,4096,33554441]

theorem envBound10385 : H12AffineFastState.Bounded env10385 := by
  intro p hp
  have h : env10385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10384_10385 : H12AffineEnvironment.transform 23 119692 env10384 = env10385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 119692 env10384 == env10385) = true)

def env10386 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,641,16384,32768,65536,4096,262144,1025,32768,4096,4194304,17665,119692,128,21144,4457357,1945,4097,4312851,22412,4294967296,257,4299277879,4096,137]

theorem envBound10386 : H12AffineFastState.Bounded env10386 := by
  intro p hp
  have h : env10386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10385_10386 : H12AffineEnvironment.transform 24 128 env10385 = env10386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 128 env10385 == env10386) = true)

theorem identity10386 : scanCanonicalize (H12AffineFastState.compose env10386 (packedSelected [1,5,6,8,19,24,25,26] rootPS)) = affineNative (2^(13+1) ^^^ 1297) := by decide +kernel

theorem selectedBound10386 : packedSelected [1,5,6,8,19,24,25,26] rootPS < 2^1333 := by decide +kernel

def env10387 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,641,1297,32768,65536,4096,262144,1025,32768,4096,4194304,16,104093,128,6025,4457357,1945,4097,4295170,4765,4294967296,257,4299260710,4096,137]

theorem envBound10387 : H12AffineFastState.Bounded env10387 := by
  intro p hp
  have h : env10387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10386_10387 : H12AffineEnvironment.transform 13 1297 env10386 = env10387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env10386 == env10387) = true)

theorem identity10387 : scanCanonicalize (H12AffineFastState.compose env10387 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound10387 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env10388 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,4096,9,1297,32768,65536,4096,262144,1025,32768,4096,4194304,16,103445,128,5377,4456709,1297,4097,4294794,4117,4294967296,257,4299260334,4096,137]

theorem envBound10388 : H12AffineFastState.Bounded env10388 := by
  intro p hp
  have h : env10388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10387_10388 : H12AffineEnvironment.transform 8 136 env10387 = env10388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env10387 == env10388) = true)

theorem identity10388 : scanCanonicalize (H12AffineFastState.compose env10388 (packedSelected [5,8,17,21] rootPS)) = affineNative (2^(14+1) ^^^ 261) := by decide +kernel

theorem selectedBound10388 : packedSelected [5,8,17,21] rootPS < 2^1333 := by decide +kernel

def env10389 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,4096,9,1297,261,65536,4096,262144,1025,261,4096,4194304,16,70928,128,5377,4456709,1297,4097,4262287,4117,4294967296,257,4299227307,4096,137]

theorem envBound10389 : H12AffineFastState.Bounded env10389 := by
  intro p hp
  have h : env10389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10388_10389 : H12AffineEnvironment.transform 14 261 env10388 = env10389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 261 env10388 == env10389) = true)

theorem identity10389 : scanCanonicalize (H12AffineFastState.compose env10389 (packedSelected [5,6,8,10,12,13] rootPS)) = affineNative (2^(31+1) ^^^ 4456490) := by decide +kernel

theorem selectedBound10389 : packedSelected [5,6,8,10,12,13] rootPS < 2^1333 := by decide +kernel

def env10390 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,4096,9,1297,261,65536,4096,262144,1025,261,4096,4194304,16,70928,128,5377,4456709,1297,4097,4262287,4117,4456490,257,327809,4096,137]

theorem envBound10390 : H12AffineFastState.Bounded env10390 := by
  intro p hp
  have h : env10390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10389_10390 : H12AffineEnvironment.transform 31 4456490 env10389 = env10390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4456490 env10389 == env10390) = true)

def env10391 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1296,9,1297,261,65536,1296,262144,1025,261,1296,4194304,16,65536,128,17,4456709,1297,1297,4262287,1285,4456490,257,327809,1296,137]

theorem envBound10391 : H12AffineFastState.Bounded env10391 := by
  intro p hp
  have h : env10391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10390_10391 : H12AffineEnvironment.transform 11 1296 env10390 = env10391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env10390 == env10391) = true)

theorem identity10391 : scanCanonicalize (H12AffineFastState.compose env10391 (packedSelected [1,3,5] rootPS)) = affineNative (2^(17+1) ^^^ 67745) := by decide +kernel

theorem selectedBound10391 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env10392 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1296,9,1297,261,65536,1296,67745,1025,261,1296,4194304,16,65536,128,17,4262308,1297,1297,4262287,1285,4262027,257,2080,1296,137]

theorem envBound10392 : H12AffineFastState.Bounded env10392 := by
  intro p hp
  have h : env10392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10391_10392 : H12AffineEnvironment.transform 17 67745 env10391 = env10392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67745 env10391 == env10392) = true)

theorem identity10392 : scanCanonicalize (H12AffineFastState.compose env10392 (packedSelected [1,3,8] rootPS)) = affineNative (2^(15+1) ^^^ 139) := by decide +kernel

theorem selectedBound10392 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env10393 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1296,9,1297,261,139,1296,2090,1025,261,1296,4194304,16,139,128,17,4196655,1297,1297,4196612,1285,4196352,257,2080,1296,137]

theorem envBound10393 : H12AffineFastState.Bounded env10393 := by
  intro p hp
  have h : env10393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10392_10393 : H12AffineEnvironment.transform 15 139 env10392 = env10393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 139 env10392 == env10393) = true)

theorem identity10393 : scanCanonicalize (H12AffineFastState.compose env10393 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound10393 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env10394 : List Nat := [2,4,8,16,10,17,128,256,136,1024,2048,1296,9,1297,261,139,1296,2048,1025,261,1296,4194304,16,139,128,17,4196613,1297,1297,4196612,1285,4196352,257,2058,1296,137]

theorem envBound10394 : H12AffineFastState.Bounded env10394 := by
  intro p hp
  have h : env10394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10393_10394 : H12AffineEnvironment.transform 4 10 env10393 = env10394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env10393 == env10394) = true)

theorem identity10394 : scanCanonicalize (H12AffineFastState.compose env10394 (packedSelected [0,7] rootPS)) = affineNative (2^(21+1) ^^^ 2318) := by decide +kernel

theorem selectedBound10394 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env10395 : List Nat := [2,4,8,16,10,17,128,256,136,1024,2048,1296,9,1297,261,139,1296,2048,1025,261,1296,2318,16,139,128,17,11,1297,1297,10,1285,270,257,2058,1296,137]

theorem envBound10395 : H12AffineFastState.Bounded env10395 := by
  intro p hp
  have h : env10395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10394_10395 : H12AffineEnvironment.transform 21 2318 env10394 = env10395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2318 env10394 == env10395) = true)

theorem identity10395 : scanCanonicalize (H12AffineFastState.compose env10395 (packedSelected [1,10] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound10395 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env10396 : List Nat := [2,4,8,16,10,17,128,256,136,1024,260,1296,9,1297,261,139,1296,260,1025,261,1296,10,16,139,128,17,11,1297,1297,10,1285,270,257,270,1296,137]

theorem envBound10396 : H12AffineFastState.Bounded env10396 := by
  intro p hp
  have h : env10396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10395_10396 : H12AffineEnvironment.transform 10 260 env10395 = env10396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env10395 == env10396) = true)

theorem identity10396 : scanCanonicalize (H12AffineFastState.compose env10396 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound10396 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10397 : List Nat := [2,4,8,16,10,17,19,256,27,1024,260,1296,9,1297,261,24,1296,260,1025,261,1296,10,16,24,19,17,11,1297,1297,10,1285,270,257,270,1296,26]

theorem envBound10397 : H12AffineFastState.Bounded env10397 := by
  intro p hp
  have h : env10397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10396_10397 : H12AffineEnvironment.transform 6 19 env10396 = env10397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env10396 == env10397) = true)

def env10398 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1297,9,1297,261,65536,1297,262144,1025,261,1297,4194304,16,65537,128,16,4456709,1297,1296,4262287,1284,4456490,257,327809,1297,137]

theorem envBound10398 : H12AffineFastState.Bounded env10398 := by
  intro p hp
  have h : env10398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10390_10398 : H12AffineEnvironment.transform 11 1297 env10390 = env10398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env10390 == env10398) = true)

theorem identity10398 : scanCanonicalize (H12AffineFastState.compose env10398 (packedSelected [1,3,5] rootPS)) = affineNative (2^(21+1) ^^^ 65675) := by decide +kernel

theorem selectedBound10398 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env10399 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1297,9,1297,261,65536,1297,262144,1025,261,1297,65675,16,65537,128,16,328078,1297,1296,2308,1284,327841,257,327809,1297,137]

theorem envBound10399 : H12AffineFastState.Bounded env10399 := by
  intro p hp
  have h : env10399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10398_10399 : H12AffineEnvironment.transform 21 65675 env10398 = env10399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65675 env10398 == env10399) = true)

theorem identity10399 : scanCanonicalize (H12AffineFastState.compose env10399 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound10399 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env10400 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1297,9,1297,261,262,1297,262144,1025,261,1297,397,16,263,128,16,262280,1297,1296,2308,1284,262567,257,262535,1297,137]

theorem envBound10400 : H12AffineFastState.Bounded env10400 := by
  intro p hp
  have h : env10400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10399_10400 : H12AffineEnvironment.transform 15 262 env10399 = env10400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env10399 == env10400) = true)

theorem identity10400 : scanCanonicalize (H12AffineFastState.compose env10400 (packedSelected [1,3,8] rootPS)) = affineNative (2^(17+1) ^^^ 2216) := by decide +kernel

theorem selectedBound10400 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env10401 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1297,9,1297,261,262,1297,2216,1025,261,1297,397,16,263,128,16,2080,1297,1296,2308,1284,2319,257,2351,1297,137]

theorem envBound10401 : H12AffineFastState.Bounded env10401 := by
  intro p hp
  have h : env10401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10400_10401 : H12AffineEnvironment.transform 17 2216 env10400 = env10401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2216 env10400 == env10401) = true)

theorem identity10401 : scanCanonicalize (H12AffineFastState.compose env10401 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 47) := by decide +kernel

theorem selectedBound10401 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env10402 : List Nat := [2,4,8,16,32,17,128,47,136,1024,2048,1086,9,1086,42,41,1086,2216,1025,42,1086,162,16,40,128,16,2080,1086,1087,2091,1067,2080,46,2048,1086,137]

theorem envBound10402 : H12AffineFastState.Bounded env10402 := by
  intro p hp
  have h : env10402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10401_10402 : H12AffineEnvironment.transform 7 47 env10401 = env10402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 47 env10401 == env10402) = true)

theorem identity10402 : scanCanonicalize (H12AffineFastState.compose env10402 (packedSelected [12] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound10402 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env10403 : List Nat := [2,4,8,16,32,17,128,47,136,1024,0,1086,9,1086,42,41,1086,168,1025,42,1086,162,16,40,128,16,32,1086,1087,43,1067,32,46,0,1086,137]

theorem envBound10403 : H12AffineFastState.Bounded env10403 := by
  intro p hp
  have h : env10403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10402_10403 : H12AffineEnvironment.transform 10 0 env10402 = env10403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env10402 == env10403) = true)

theorem identity10403 : scanCanonicalize (H12AffineFastState.compose env10403 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound10403 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env10404 : List Nat := [2,4,8,16,32,17,19,47,27,1024,0,1086,9,1086,42,41,1086,59,1025,42,1086,49,16,40,19,16,32,1086,1087,43,1067,32,46,0,1086,26]

theorem envBound10404 : H12AffineFastState.Bounded env10404 := by
  intro p hp
  have h : env10404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10403_10404 : H12AffineEnvironment.transform 6 19 env10403 = env10404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env10403 == env10404) = true)

theorem identity10404 : scanCanonicalize (H12AffineFastState.compose env10404 (packedSelected [0,2,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound10404 : packedSelected [0,2,7,9] rootPS < 2^1333 := by decide +kernel

def env10405 : List Nat := [2,4,8,16,1,17,19,14,27,1024,0,1055,9,1055,11,8,1055,26,1025,11,1055,16,16,9,19,16,1,1055,1054,10,1034,1,15,0,1055,26]

theorem envBound10405 : H12AffineFastState.Bounded env10405 := by
  intro p hp
  have h : env10405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10404_10405 : H12AffineEnvironment.transform 4 1 env10404 = env10405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env10404 == env10405) = true)

theorem identity10405 : scanCanonicalize (H12AffineFastState.compose env10405 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound10405 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env10406 : List Nat := [2,4,8,0,1,1,3,14,11,1024,0,1039,9,1039,11,8,1039,10,1025,11,1039,0,0,9,3,0,1,1039,1038,10,1034,1,15,0,1039,10]

theorem envBound10406 : H12AffineFastState.Bounded env10406 := by
  intro p hp
  have h : env10406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10405_10406 : H12AffineEnvironment.transform 3 0 env10405 = env10406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env10405 == env10406) = true)

theorem identity10406 : scanCanonicalize (H12AffineFastState.compose env10406 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound10406 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10407 : List Nat := [2,4,2,0,1,1,3,4,1,1024,0,1029,3,1029,1,2,1029,0,1025,1,1029,0,0,3,3,0,1,1029,1028,0,1024,1,5,0,1029,0]

theorem envBound10407 : H12AffineFastState.Bounded env10407 := by
  intro p hp
  have h : env10407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10406_10407 : H12AffineEnvironment.transform 2 2 env10406 = env10407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env10406 == env10407) = true)

def leafEnv10407 : List Nat := [2,4,2,0,1,1,3,4,1,1024,0,1029,3,1029,1,2,1029,0,1025,1,1029,0,0,3,1025,3,1,0,1,1029,1028,0,1024,1,5,0,5,2,1029,0,0,1028,1]

def active10407 : List Nat := [0,1,9]

def tree10407 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood10407 : H12WitnessSearch.Good tree10407 := H12GlobalWitnessIndex.good

theorem leafIdentity10407 : H12AffineFastState.composeSystem env10407 rootObs = leafEnv10407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env10407 rootObs == leafEnv10407) = true)

theorem terminalChecked10407 : H12PackedTerminal.terminalCheckFast leafEnv10407 active10407 tree10407 = true := by decide +kernel

def env10408 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,641,16384,32768,65536,4096,262144,1025,32768,4096,4194304,17665,119692,129,21144,4457357,1945,4097,4312851,22412,4294967296,257,4299277878,4096,136]

theorem envBound10408 : H12AffineFastState.Bounded env10408 := by
  intro p hp
  have h : env10408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10385_10408 : H12AffineEnvironment.transform 24 129 env10385 = env10408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 129 env10385 == env10408) = true)

theorem identity10408 : scanCanonicalize (H12AffineFastState.compose env10408 (packedSelected [1,5,6,8,19,24,25,26] rootPS)) = affineNative (2^(13+1) ^^^ 1945) := by decide +kernel

theorem selectedBound10408 : packedSelected [1,5,6,8,19,24,25,26] rootPS < 2^1333 := by decide +kernel

def env10409 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,641,1945,32768,65536,4096,262144,1025,32768,4096,4194304,664,103445,129,5377,4457357,1945,4097,4294794,4117,4294967296,257,4299260335,4096,136]

theorem envBound10409 : H12AffineFastState.Bounded env10409 := by
  intro p hp
  have h : env10409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10408_10409 : H12AffineEnvironment.transform 13 1945 env10408 = env10409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1945 env10408 == env10409) = true)

theorem identity10409 : scanCanonicalize (H12AffineFastState.compose env10409 (packedSelected [1,3,5,6,8,10,19,25] rootPS)) = affineNative (2^(11+1) ^^^ 1944) := by decide +kernel

theorem selectedBound10409 : packedSelected [1,3,5,6,8,10,19,25] rootPS < 2^1333 := by decide +kernel

def env10410 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1944,641,1945,32768,65536,1944,262144,1025,32768,1944,4194304,664,99213,129,665,4457357,1945,1945,4294794,1933,4294967296,257,4299260335,1944,136]

theorem envBound10410 : H12AffineFastState.Bounded env10410 := by
  intro p hp
  have h : env10410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10409_10410 : H12AffineEnvironment.transform 11 1944 env10409 = env10410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1944 env10409 == env10410) = true)

theorem identity10410 : scanCanonicalize (H12AffineFastState.compose env10410 (packedSelected [13,17] rootPS)) = affineNative (2^(15+1) ^^^ 33167) := by decide +kernel

theorem selectedBound10410 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env10411 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1944,641,1945,32768,33167,1944,262144,1025,32768,1944,4194304,664,514,129,665,4457357,1945,1945,4196613,1933,4294967296,257,4299161632,1944,136]

theorem envBound10411 : H12AffineFastState.Bounded env10411 := by
  intro p hp
  have h : env10411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10410_10411 : H12AffineEnvironment.transform 15 33167 env10410 = env10411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33167 env10410 == env10411) = true)

theorem identity10411 : scanCanonicalize (H12AffineFastState.compose env10411 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(17+1) ^^^ 35497) := by decide +kernel

theorem selectedBound10411 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env10412 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1944,641,1945,32768,33167,1944,35497,1025,32768,1944,4194304,664,514,129,665,4229412,1945,1945,4196613,1933,4294967296,257,4299161632,1944,136]

theorem envBound10412 : H12AffineFastState.Bounded env10412 := by
  intro p hp
  have h : env10412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10411_10412 : H12AffineEnvironment.transform 17 35497 env10411 = env10412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35497 env10411 == env10412) = true)

theorem identity10412 : scanCanonicalize (H12AffineFastState.compose env10412 (packedSelected [3,5,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 908) := by decide +kernel

theorem selectedBound10412 : packedSelected [3,5,10,12] rootPS < 2^1333 := by decide +kernel

def env10413 : List Nat := [2,4,8,16,32,17,128,256,512,1024,908,1944,641,1945,32768,33167,1944,33061,1025,32768,1944,4194304,664,514,129,665,4227752,1945,1945,4194953,1933,4294967296,257,4299161632,1944,136]

theorem envBound10413 : H12AffineFastState.Bounded env10413 := by
  intro p hp
  have h : env10413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10412_10413 : H12AffineEnvironment.transform 10 908 env10412 = env10413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 908 env10412 == env10413) = true)

theorem identity10413 : scanCanonicalize (H12AffineFastState.compose env10413 (packedSelected [0,2,4,6,8,11] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound10413 : packedSelected [0,2,4,6,8,11] rootPS < 2^1333 := by decide +kernel

def env10414 : List Nat := [2,4,8,16,32,17,128,256,136,1024,260,1296,9,1297,32768,33167,1296,33061,1025,32768,1296,4194304,16,138,129,17,4227104,1297,1297,4194305,1285,4294967296,257,4299161632,1296,136]

theorem envBound10414 : H12AffineFastState.Bounded env10414 := by
  intro p hp
  have h : env10414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10413_10414 : H12AffineEnvironment.transform 8 136 env10413 = env10414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env10413 == env10414) = true)

theorem identity10414 : scanCanonicalize (H12AffineFastState.compose env10414 (packedSelected [1] rootPS)) = affineNative (2^(21+1) ^^^ 32931) := by decide +kernel

theorem selectedBound10414 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10415 : List Nat := [2,4,8,16,32,17,128,256,136,1024,260,1296,9,1297,32768,33167,1296,33061,1025,32768,1296,32931,16,138,129,17,131,1297,1297,32930,1285,4294967296,257,4295000195,1296,136]

theorem envBound10415 : H12AffineFastState.Bounded env10415 := by
  intro p hp
  have h : env10415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10414_10415 : H12AffineEnvironment.transform 21 32931 env10414 = env10415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32931 env10414 == env10415) = true)

theorem identity10415 : scanCanonicalize (H12AffineFastState.compose env10415 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound10415 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env10416 : List Nat := [2,4,8,16,32,17,128,37,136,1024,33,1077,9,1076,32768,32938,1077,32768,1025,32768,1077,32931,16,138,129,17,131,1076,1076,32930,1056,4294967296,36,4295000195,1077,136]

theorem envBound10416 : H12AffineFastState.Bounded env10416 := by
  intro p hp
  have h : env10416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10415_10416 : H12AffineEnvironment.transform 7 37 env10415 = env10416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env10415 == env10416) = true)

theorem identity10416 : scanCanonicalize (H12AffineFastState.compose env10416 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound10416 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env10417 : List Nat := [2,4,8,16,10,17,128,15,136,1024,11,1055,9,1054,32768,32896,1055,32768,1025,32768,1055,32905,16,138,129,17,131,1054,1054,32904,1034,4294967296,14,4295000195,1055,136]

theorem envBound10417 : H12AffineFastState.Bounded env10417 := by
  intro p hp
  have h : env10417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10416_10417 : H12AffineEnvironment.transform 4 10 env10416 = env10417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env10416 == env10417) = true)

theorem identity10417 : scanCanonicalize (H12AffineFastState.compose env10417 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 155) := by decide +kernel

theorem selectedBound10417 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10418 : List Nat := [2,4,8,16,10,17,128,15,136,1024,11,1055,9,1054,32768,32896,1055,32768,1025,32768,1055,32905,16,138,129,17,131,1054,1054,32904,1034,155,14,32792,1055,136]

theorem envBound10418 : H12AffineFastState.Bounded env10418 := by
  intro p hp
  have h : env10418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10417_10418 : H12AffineEnvironment.transform 31 155 env10417 = env10418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 155 env10417 == env10418) = true)

theorem identity10418 : scanCanonicalize (H12AffineFastState.compose env10418 (packedSelected [6] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound10418 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env10419 : List Nat := [2,4,8,2,10,3,128,15,136,1024,11,1037,9,1036,32768,32896,1037,32768,1025,32768,1037,32905,2,138,129,3,131,1036,1036,32904,1034,137,14,32778,1037,136]

theorem envBound10419 : H12AffineFastState.Bounded env10419 := by
  intro p hp
  have h : env10419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10418_10419 : H12AffineEnvironment.transform 3 2 env10418 = env10419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env10418 == env10419) = true)

def env10420 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,641,16384,32768,65536,4097,262144,1025,32768,4096,4194304,17665,16777216,33554432,16875797,21352449,16897044,4096,20978846,16876544,4294967296,257,4332832438,4097,33554441]

theorem envBound10420 : H12AffineFastState.Bounded env10420 := by
  intro p hp
  have h : env10420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10383_10420 : H12AffineEnvironment.transform 16 4097 env10383 = env10420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4097 env10383 == env10420) = true)

theorem identity10420 : scanCanonicalize (H12AffineFastState.compose env10420 (packedSelected [1,3,5,8,9,10,19,22] rootPS)) = affineNative (2^(23+1) ^^^ 116380) := by decide +kernel

theorem selectedBound10420 : packedSelected [1,3,5,8,9,10,19,22] rootPS < 2^1333 := by decide +kernel

def env10421 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,641,16384,32768,65536,4097,262144,1025,32768,4096,4194304,17665,116380,33554432,18313,4462237,4744,4096,4315650,17052,4294967296,257,4332832438,4097,33554441]

theorem envBound10421 : H12AffineFastState.Bounded env10421 := by
  intro p hp
  have h : env10421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10420_10421 : H12AffineEnvironment.transform 23 116380 env10420 = env10421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 116380 env10420 == env10421) = true)

def env10422 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,641,16384,32768,65536,4097,262144,1025,32768,4096,4194304,17665,116380,128,18313,4462237,4744,4096,4315650,17052,4294967296,257,4299277878,4097,137]

theorem envBound10422 : H12AffineFastState.Bounded env10422 := by
  intro p hp
  have h : env10422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10421_10422 : H12AffineEnvironment.transform 24 128 env10421 = env10422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 128 env10421 == env10422) = true)

theorem identity10422 : scanCanonicalize (H12AffineFastState.compose env10422 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(11+1) ^^^ 1944) := by decide +kernel

theorem selectedBound10422 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env10423 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1944,641,16384,32768,65536,1945,262144,1025,32768,1944,4194304,17665,116380,128,18313,4456709,1296,1944,4312474,17052,4294967296,257,4299277878,1945,137]

theorem envBound10423 : H12AffineFastState.Bounded env10423 := by
  intro p hp
  have h : env10423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10422_10423 : H12AffineEnvironment.transform 11 1944 env10422 = env10423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1944 env10422 == env10423) = true)

theorem identity10423 : scanCanonicalize (H12AffineFastState.compose env10423 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 1296) := by decide +kernel

theorem selectedBound10423 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env10424 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1944,641,1296,32768,65536,1945,262144,1025,32768,1944,4194304,17,99212,128,665,4456709,1296,1944,4294794,1932,4294967296,257,4299260710,1945,137]

theorem envBound10424 : H12AffineFastState.Bounded env10424 := by
  intro p hp
  have h : env10424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10423_10424 : H12AffineEnvironment.transform 13 1296 env10423 = env10424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env10423 == env10424) = true)

theorem identity10424 : scanCanonicalize (H12AffineFastState.compose env10424 (packedSelected [4,5,8,9,13,16,17] rootPS)) = affineNative (2^(21+1) ^^^ 33281) := by decide +kernel

theorem selectedBound10424 : packedSelected [4,5,8,9,13,16,17] rootPS < 2^1333 := by decide +kernel

def env10425 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1944,641,1296,32768,65536,1945,262144,1025,32768,1944,33281,17,99212,128,665,295684,1296,1944,68235,1932,4294967296,257,4295033127,1945,137]

theorem envBound10425 : H12AffineFastState.Bounded env10425 := by
  intro p hp
  have h : env10425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10424_10425 : H12AffineEnvironment.transform 21 33281 env10424 = env10425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33281 env10424 == env10425) = true)

theorem identity10425 : scanCanonicalize (H12AffineFastState.compose env10425 (packedSelected [5,8,10,12,13] rootPS)) = affineNative (2^(17+1) ^^^ 68014) := by decide +kernel

theorem selectedBound10425 : packedSelected [5,8,10,12,13] rootPS < 2^1333 := by decide +kernel

def env10426 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1944,641,1296,32768,65536,1945,68014,1025,32768,1944,33281,17,99212,128,665,101034,1296,1944,68235,1932,4294967296,257,4295033127,1945,137]

theorem envBound10426 : H12AffineFastState.Bounded env10426 := by
  intro p hp
  have h : env10426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10425_10426 : H12AffineEnvironment.transform 17 68014 env10425 = env10426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 68014 env10425 == env10426) = true)

theorem identity10426 : scanCanonicalize (H12AffineFastState.compose env10426 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound10426 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env10427 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1944,641,1296,32768,33166,1945,34848,1025,32768,1944,33281,17,514,128,665,2852,1296,1944,35589,1932,4294967296,257,4295000233,1945,137]

theorem envBound10427 : H12AffineFastState.Bounded env10427 := by
  intro p hp
  have h : env10427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10426_10427 : H12AffineEnvironment.transform 15 33166 env10426 = env10427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env10426 == env10427) = true)

theorem identity10427 : scanCanonicalize (H12AffineFastState.compose env10427 (packedSelected [0,1,2,4,8,10,11,12] rootPS)) = affineNative (2^(31+1) ^^^ 33290) := by decide +kernel

theorem selectedBound10427 : packedSelected [0,1,2,4,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env10428 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1944,641,1296,32768,33166,1945,34848,1025,32768,1944,33281,17,514,128,665,2852,1296,1944,35589,1932,33290,257,675,1945,137]

theorem envBound10428 : H12AffineFastState.Bounded env10428 := by
  intro p hp
  have h : env10428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10427_10428 : H12AffineEnvironment.transform 31 33290 env10427 = env10428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 33290 env10427 == env10428) = true)

theorem identity10428 : scanCanonicalize (H12AffineFastState.compose env10428 (packedSelected [3,6,8] rootPS)) = affineNative (2^(14+1) ^^^ 302) := by decide +kernel

theorem selectedBound10428 : packedSelected [3,6,8] rootPS < 2^1333 := by decide +kernel

def env10429 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1944,641,1296,302,160,1945,2318,1025,302,1944,815,17,514,128,665,2852,1296,1944,2603,1932,804,257,675,1945,137]

theorem envBound10429 : H12AffineFastState.Bounded env10429 := by
  intro p hp
  have h : env10429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10428_10429 : H12AffineEnvironment.transform 14 302 env10428 = env10429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 302 env10428 == env10429) = true)

theorem identity10429 : scanCanonicalize (H12AffineFastState.compose env10429 (packedSelected [0,2,4,6,11] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound10429 : packedSelected [0,2,4,6,11] rootPS < 2^1333 := by decide +kernel

def env10430 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1296,9,1296,302,160,1297,2318,1025,302,1296,423,17,138,128,17,2476,1296,1296,2211,1284,428,257,43,1297,137]

theorem envBound10430 : H12AffineFastState.Bounded env10430 := by
  intro p hp
  have h : env10430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10429_10430 : H12AffineEnvironment.transform 8 136 env10429 = env10430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env10429 == env10430) = true)

theorem identity10430 : scanCanonicalize (H12AffineFastState.compose env10430 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound10430 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10431 : List Nat := [2,4,8,16,32,17,128,256,136,1024,136,1296,9,1296,302,160,1297,390,1025,302,1296,423,17,138,128,17,292,1296,1296,43,1284,428,257,43,1297,137]

theorem envBound10431 : H12AffineFastState.Bounded env10431 := by
  intro p hp
  have h : env10431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10430_10431 : H12AffineEnvironment.transform 10 136 env10430 = env10431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env10430 == env10431) = true)

theorem identity10431 : scanCanonicalize (H12AffineFastState.compose env10431 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound10431 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env10432 : List Nat := [2,4,8,16,32,17,2,256,10,1024,10,1296,9,1296,302,34,1297,260,1025,302,1296,293,17,8,2,17,292,1296,1296,43,1284,302,257,43,1297,11]

theorem envBound10432 : H12AffineFastState.Bounded env10432 := by
  intro p hp
  have h : env10432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10431_10432 : H12AffineEnvironment.transform 6 2 env10431 = env10432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env10431 == env10432) = true)

theorem identity10432 : scanCanonicalize (H12AffineFastState.compose env10432 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound10432 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env10433 : List Nat := [2,4,8,16,32,17,2,15,10,1024,10,1055,9,1055,33,34,1054,11,1025,33,1055,42,17,8,2,17,43,1055,1055,43,1035,33,14,43,1054,11]

theorem envBound10433 : H12AffineFastState.Bounded env10433 := by
  intro p hp
  have h : env10433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10432_10433 : H12AffineEnvironment.transform 7 15 env10432 = env10433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env10432 == env10433) = true)

theorem identity10433 : scanCanonicalize (H12AffineFastState.compose env10433 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound10433 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10434 : List Nat := [2,4,3,16,32,17,2,4,1,1024,1,1044,2,1044,33,34,1045,0,1025,33,1044,33,17,3,2,17,32,1044,1044,32,1024,33,5,32,1045,0]

theorem envBound10434 : H12AffineFastState.Bounded env10434 := by
  intro p hp
  have h : env10434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10433_10434 : H12AffineEnvironment.transform 2 3 env10433 = env10434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env10433 == env10434) = true)

theorem identity10434 : scanCanonicalize (H12AffineFastState.compose env10434 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound10434 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10435 : List Nat := [2,4,3,16,16,17,2,4,1,1024,1,1044,2,1044,17,18,1045,0,1025,17,1044,17,17,3,2,17,16,1044,1044,16,1024,17,5,16,1045,0]

theorem envBound10435 : H12AffineFastState.Bounded env10435 := by
  intro p hp
  have h : env10435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10434_10435 : H12AffineEnvironment.transform 4 16 env10434 = env10435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env10434 == env10435) = true)

theorem identity10435 : scanCanonicalize (H12AffineFastState.compose env10435 (packedSelected [10] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound10435 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env10436 : List Nat := [2,4,3,1,1,0,2,4,1,1024,1,1029,2,1029,0,3,1028,0,1025,0,1029,0,0,3,2,0,1,1029,1029,1,1024,0,5,1,1028,0]

theorem envBound10436 : H12AffineFastState.Bounded env10436 := by
  intro p hp
  have h : env10436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10435_10436 : H12AffineEnvironment.transform 3 1 env10435 = env10436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env10435 == env10436) = true)

def leafEnv10436 : List Nat := [2,4,3,1,1,0,2,4,1,1024,1,1029,2,1029,0,3,1028,0,1025,0,1029,0,0,3,1025,2,1,0,1,1029,1029,1,1024,0,5,1,5,3,1028,0,0,1029,1]

def active10436 : List Nat := [0,1,9]

def tree10436 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood10436 : H12WitnessSearch.Good tree10436 := H12GlobalWitnessIndex.good

theorem leafIdentity10436 : H12AffineFastState.composeSystem env10436 rootObs = leafEnv10436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env10436 rootObs == leafEnv10436) = true)

theorem terminalChecked10436 : H12PackedTerminal.terminalCheckFast leafEnv10436 active10436 tree10436 = true := by decide +kernel

def env10437 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,641,16384,32768,65536,4097,262144,1025,32768,4096,4194304,17665,116380,129,18313,4462237,4744,4096,4315650,17052,4294967296,257,4299277879,4097,136]

theorem envBound10437 : H12AffineFastState.Bounded env10437 := by
  intro p hp
  have h : env10437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10421_10437 : H12AffineEnvironment.transform 24 129 env10421 = env10437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 129 env10421 == env10437) = true)

theorem identity10437 : scanCanonicalize (H12AffineFastState.compose env10437 (packedSelected [6,25] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound10437 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env10438 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,4096,8,16384,32768,65536,4097,262144,1025,32768,4096,4194304,17665,115733,129,17664,4461588,4097,4096,4315275,16405,4294967296,257,4299277502,4097,136]

theorem envBound10438 : H12AffineFastState.Bounded env10438 := by
  intro p hp
  have h : env10438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10437_10438 : H12AffineEnvironment.transform 8 137 env10437 = env10438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env10437 == env10438) = true)

theorem identity10438 : scanCanonicalize (H12AffineFastState.compose env10438 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 4097) := by decide +kernel

theorem selectedBound10438 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env10439 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,4096,8,4097,32768,65536,4097,262144,1025,32768,4096,4194304,5376,103444,129,5377,4461588,4097,4096,4294794,4116,4294967296,257,4299265215,4097,136]

theorem envBound10439 : H12AffineFastState.Bounded env10439 := by
  intro p hp
  have h : env10439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10438_10439 : H12AffineEnvironment.transform 13 4097 env10438 = env10439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4097 env10438 == env10439) = true)

def env10440 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,4097,4194304,17665,16777216,33554432,67108864,21352529,67130625,131152,1073741824,16876544,4294967296,257,4417151346,131072,33563272]

theorem envBound10440 : H12AffineFastState.Bounded env10440 := by
  intro p hp
  have h : env10440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10093_10440 : H12AffineEnvironment.transform 20 4097 env10093 = env10440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env10093 == env10440) = true)

theorem identity10440 : scanCanonicalize (H12AffineFastState.compose env10440 (packedSelected [35] rootPS)) = affineNative (2^(23+1) ^^^ 230468) := by decide +kernel

theorem selectedBound10440 : packedSelected [35] rootPS < 2^1333 := by decide +kernel

def env10441 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,4097,4194304,17665,230468,33554432,67108864,4609045,67130625,131152,1073741824,131140,4294967296,257,4400604470,131072,33563272]

theorem envBound10441 : H12AffineFastState.Bounded env10441 := by
  intro p hp
  have h : env10441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10440_10441 : H12AffineEnvironment.transform 23 230468 env10440 = env10441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 230468 env10440 == env10441) = true)

def env10442 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,4097,4194304,17665,230468,33554432,67108864,4609045,67130625,131152,1073741824,131140,4294967296,257,4400079158,131072,33563272]

theorem envBound10442 : H12AffineFastState.Bounded env10442 := by
  intro p hp
  have h : env10442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10441_10442 : H12AffineEnvironment.transform 18 1024 env10441 = env10442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env10441 == env10442) = true)

theorem identity10442 : scanCanonicalize (H12AffineFastState.compose env10442 (packedSelected [4,6,7,9,16,20,25,27] rootPS)) = affineNative (2^(29+1) ^^^ 71421403) := by decide +kernel

theorem selectedBound10442 : packedSelected [4,6,7,9,16,20,25,27] rootPS < 2^1333 := by decide +kernel

def env10443 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,4097,4194304,17665,230468,33554432,67108864,4609045,67130625,131152,71421403,131140,4294967296,257,4400079158,131072,33563272]

theorem envBound10443 : H12AffineFastState.Bounded env10443 := by
  intro p hp
  have h : env10443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10442_10443 : H12AffineEnvironment.transform 29 71421403 env10442 = env10443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 71421403 env10442 == env10443) = true)

def env10444 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1024,32768,4097,4194304,5457,230468,33554432,67108864,4588613,67110225,131152,71409035,131140,4294967296,257,4400066918,131072,33563272]

theorem envBound10444 : H12AffineFastState.Bounded env10444 := by
  intro p hp
  have h : env10444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10443_10444 : H12AffineEnvironment.transform 13 4176 env10443 = env10444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env10443 == env10444) = true)

theorem identity10444 : scanCanonicalize (H12AffineFastState.compose env10444 (packedSelected [13,17,21,33] rootPS)) = affineNative (2^(25+1) ^^^ 5376) := by decide +kernel

theorem selectedBound10444 : packedSelected [13,17,21,33] rootPS < 2^1333 := by decide +kernel

def env10445 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1024,32768,4097,4194304,5457,230468,33554432,5376,4588613,4177,131152,4294795,131140,4294967296,257,4332954726,131072,33563272]

theorem envBound10445 : H12AffineFastState.Bounded env10445 := by
  intro p hp
  have h : env10445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10444_10445 : H12AffineEnvironment.transform 25 5376 env10444 = env10445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 5376 env10444 == env10445) = true)

def env10446 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1024,32768,4097,4194304,5456,230468,33554432,67108864,4588612,67110224,131152,71409034,131140,4294967296,257,4400066919,131072,33563272]

theorem envBound10446 : H12AffineFastState.Bounded env10446 := by
  intro p hp
  have h : env10446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10443_10446 : H12AffineEnvironment.transform 13 4177 env10443 = env10446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env10443 == env10446) = true)

theorem identity10446 : scanCanonicalize (H12AffineFastState.compose env10446 (packedSelected [13,17,21,33] rootPS)) = affineNative (2^(25+1) ^^^ 33568136) := by decide +kernel

theorem selectedBound10446 : packedSelected [13,17,21,33] rootPS < 2^1333 := by decide +kernel

def env10447 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1024,32768,4097,4194304,5456,230468,33554432,33568136,4588612,33566936,131152,37857282,131140,4294967296,257,4299392239,131072,33563272]

theorem envBound10447 : H12AffineFastState.Bounded env10447 := by
  intro p hp
  have h : env10447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10446_10447 : H12AffineEnvironment.transform 25 33568136 env10446 = env10447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 33568136 env10446 == env10447) = true)

theorem identity10447 : scanCanonicalize (H12AffineFastState.compose env10447 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(24+1) ^^^ 8328) := by decide +kernel

theorem selectedBound10447 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env10448 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1024,32768,4097,4194304,5456,230468,8328,5376,4588612,4176,131152,4294794,131140,4294967296,257,4299392239,131072,512]

theorem envBound10448 : H12AffineFastState.Bounded env10448 := by
  intro p hp
  have h : env10448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10447_10448 : H12AffineEnvironment.transform 24 8328 env10447 = env10448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8328 env10447 == env10448) = true)

theorem identity10448 : scanCanonicalize (H12AffineFastState.compose env10448 (packedSelected [4,9,16] rootPS)) = affineNative (2^(21+1) ^^^ 396) := by decide +kernel

theorem selectedBound10448 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env10449 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1024,32768,4097,396,5456,230468,8328,5376,394696,4176,131152,100614,131140,4294967296,257,4295198051,131072,512]

theorem envBound10449 : H12AffineFastState.Bounded env10449 := by
  intro p hp
  have h : env10449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10448_10449 : H12AffineEnvironment.transform 21 396 env10448 = env10449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 396 env10448 == env10449) = true)

theorem identity10449 : scanCanonicalize (H12AffineFastState.compose env10449 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 1344) := by decide +kernel

theorem selectedBound10449 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env10450 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,1344,262144,1024,32768,4097,396,5456,98564,8328,5376,262280,4176,1296,100614,1284,4294967296,257,4295065635,1344,512]

theorem envBound10450 : H12AffineFastState.Bounded env10450 := by
  intro p hp
  have h : env10450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10449_10450 : H12AffineEnvironment.transform 16 1344 env10449 = env10450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env10449 == env10450) = true)

theorem identity10450 : scanCanonicalize (H12AffineFastState.compose env10450 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 70711) := by decide +kernel

theorem selectedBound10450 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env10451 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,1344,262144,1024,32768,4097,396,5456,98564,8328,5376,262280,4176,1296,100614,1284,70711,257,37908,1344,512]

theorem envBound10451 : H12AffineFastState.Bounded env10451 := by
  intro p hp
  have h : env10451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10450_10451 : H12AffineEnvironment.transform 31 70711 env10450 = env10451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 70711 env10450 == env10451) = true)

theorem identity10451 : scanCanonicalize (H12AffineFastState.compose env10451 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 2009) := by decide +kernel

theorem selectedBound10451 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env10452 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,2009,65536,1344,262144,1024,2009,4097,396,5456,67293,8328,5376,262280,4176,1296,69343,1284,70711,257,5069,1344,512]

theorem envBound10452 : H12AffineFastState.Bounded env10452 := by
  intro p hp
  have h : env10452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10451_10452 : H12AffineEnvironment.transform 14 2009 env10451 = env10452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2009 env10451 == env10452) = true)

theorem identity10452 : scanCanonicalize (H12AffineFastState.compose env10452 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 653) := by decide +kernel

theorem selectedBound10452 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env10453 : List Nat := [2,4,8,16,32,64,128,256,512,653,2048,4096,8192,4177,340,65536,973,262144,653,340,4097,396,5085,65616,8328,5005,262280,4176,925,67666,905,70330,257,5069,973,512]

theorem envBound10453 : H12AffineFastState.Bounded env10453 := by
  intro p hp
  have h : env10453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10452_10453 : H12AffineEnvironment.transform 9 653 env10452 = env10453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 653 env10452 == env10453) = true)

theorem identity10453 : scanCanonicalize (H12AffineFastState.compose env10453 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 89) := by decide +kernel

theorem selectedBound10453 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env10454 : List Nat := [2,4,8,16,32,64,128,256,512,653,2048,4096,89,4177,340,65536,973,262144,653,340,4097,396,5085,65616,209,5005,262280,4176,925,67666,905,70330,257,5069,973,512]

theorem envBound10454 : H12AffineFastState.Bounded env10454 := by
  intro p hp
  have h : env10454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10453_10454 : H12AffineEnvironment.transform 12 89 env10453 = env10454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 89 env10453 == env10454) = true)

theorem identity10454 : scanCanonicalize (H12AffineFastState.compose env10454 (packedSelected [1,8,12] rootPS)) = affineNative (2^(17+1) ^^^ 65744) := by decide +kernel

theorem selectedBound10454 : packedSelected [1,8,12] rootPS < 2^1333 := by decide +kernel

def env10455 : List Nat := [2,4,8,16,32,64,128,256,512,653,2048,4096,89,4177,340,65536,973,65744,653,340,4097,396,5085,65616,209,5005,65624,4176,925,67666,905,70330,257,5069,973,512]

theorem envBound10455 : H12AffineFastState.Bounded env10455 := by
  intro p hp
  have h : env10455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10454_10455 : H12AffineEnvironment.transform 17 65744 env10454 = env10455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65744 env10454 == env10455) = true)

theorem identity10455 : scanCanonicalize (H12AffineFastState.compose env10455 (packedSelected [3,5,8,13,24] rootPS)) = affineNative (2^(11+1) ^^^ 325) := by decide +kernel

theorem selectedBound10455 : packedSelected [3,5,8,13,24] rootPS < 2^1333 := by decide +kernel

def env10456 : List Nat := [2,4,8,16,32,64,128,256,512,653,2048,325,89,276,340,65536,973,65744,653,340,324,396,664,65616,209,712,65624,277,925,67666,905,66559,257,648,973,512]

theorem envBound10456 : H12AffineFastState.Bounded env10456 := by
  intro p hp
  have h : env10456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10455_10456 : H12AffineEnvironment.transform 11 325 env10455 = env10456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 325 env10455 == env10456) = true)

theorem identity10456 : scanCanonicalize (H12AffineFastState.compose env10456 (packedSelected [8,13] rootPS)) = affineNative (2^(8+1) ^^^ 397) := by decide +kernel

theorem selectedBound10456 : packedSelected [8,13] rootPS < 2^1333 := by decide +kernel

def env10457 : List Nat := [2,4,8,16,32,64,128,256,397,256,2048,325,89,276,340,65536,64,65744,256,340,324,396,277,65616,209,325,65624,277,16,67666,4,65650,257,261,64,397]

theorem envBound10457 : H12AffineFastState.Bounded env10457 := by
  intro p hp
  have h : env10457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10456_10457 : H12AffineEnvironment.transform 8 397 env10456 = env10457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 397 env10456 == env10457) = true)

def env10458 : List Nat := [2,4,8,16,32,64,8,256,261,256,2048,325,89,276,340,65536,64,65624,256,340,324,260,277,65616,89,325,65624,277,16,67666,4,65650,257,261,64,261]

theorem envBound10458 : H12AffineFastState.Bounded env10458 := by
  intro p hp
  have h : env10458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10457_10458 : H12AffineEnvironment.transform 6 8 env10457 = env10458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env10457 == env10458) = true)

theorem identity10458 : scanCanonicalize (H12AffineFastState.compose env10458 (packedSelected [7] rootPS)) = affineNative (2^(7+1) ^^^ 93) := by decide +kernel

theorem selectedBound10458 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env10459 : List Nat := [2,4,8,16,32,64,8,93,88,93,2048,24,89,73,9,65536,64,65624,93,9,25,89,72,65616,89,24,65624,72,16,67666,4,65650,92,88,64,88]

theorem envBound10459 : H12AffineFastState.Bounded env10459 := by
  intro p hp
  have h : env10459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10458_10459 : H12AffineEnvironment.transform 7 93 env10458 = env10459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 93 env10458 == env10459) = true)

theorem identity10459 : scanCanonicalize (H12AffineFastState.compose env10459 (packedSelected [5,8,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 82) := by decide +kernel

theorem selectedBound10459 : packedSelected [5,8,23,32] rootPS < 2^1333 := by decide +kernel

def env10460 : List Nat := [2,4,8,16,32,64,8,93,88,93,2048,24,89,73,9,82,64,10,93,9,25,89,72,2,89,24,10,72,16,2048,4,32,92,88,64,88]

theorem envBound10460 : H12AffineFastState.Bounded env10460 := by
  intro p hp
  have h : env10460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10459_10460 : H12AffineEnvironment.transform 15 82 env10459 = env10460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 82 env10459 == env10460) = true)

theorem identity10460 : scanCanonicalize (H12AffineFastState.compose env10460 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 114) := by decide +kernel

theorem selectedBound10460 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10461 : List Nat := [2,4,8,16,32,64,8,93,88,93,114,24,89,73,9,82,64,10,93,9,25,89,72,2,89,24,10,72,16,114,4,32,92,88,64,88]

theorem envBound10461 : H12AffineFastState.Bounded env10461 := by
  intro p hp
  have h : env10461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10460_10461 : H12AffineEnvironment.transform 10 114 env10460 = env10461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 114 env10460 == env10461) = true)

def env10462 : List Nat := [2,4,0,16,32,64,0,85,80,85,114,16,81,65,1,82,64,2,85,1,17,81,64,2,81,16,2,64,16,114,4,32,84,80,64,80]

theorem envBound10462 : H12AffineFastState.Bounded env10462 := by
  intro p hp
  have h : env10462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10461_10462 : H12AffineEnvironment.transform 2 0 env10461 = env10462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env10461 == env10462) = true)

theorem identity10462 : scanCanonicalize (H12AffineFastState.compose env10462 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound10462 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10463 : List Nat := [2,4,0,16,32,49,0,36,33,36,3,16,32,48,1,35,49,2,36,1,17,32,49,2,32,16,2,49,16,3,4,32,37,33,49,33]

theorem envBound10463 : H12AffineFastState.Bounded env10463 := by
  intro p hp
  have h : env10463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10462_10463 : H12AffineEnvironment.transform 5 49 env10462 = env10463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env10462 == env10463) = true)

def leafEnv10463 : List Nat := [2,4,0,16,32,49,0,36,33,36,3,16,32,48,1,35,49,2,36,1,17,32,49,2,4,32,1,16,2,49,16,3,4,32,37,33,5,35,49,33,0,16,1]

def active10463 : List Nat := [0,1,3,4]

def tree10463 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood10463 : H12WitnessSearch.Good tree10463 := H12GlobalWitnessIndex.good

theorem leafIdentity10463 : H12AffineFastState.composeSystem env10463 rootObs = leafEnv10463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env10463 rootObs == leafEnv10463) = true)

theorem terminalChecked10463 : H12PackedTerminal.terminalCheckFast leafEnv10463 active10463 tree10463 = true := by decide +kernel

def env10464 : List Nat := [2,4,1,16,32,64,1,84,81,84,114,17,80,64,0,82,64,3,84,0,16,80,65,2,80,17,3,65,16,114,4,32,85,81,64,81]

theorem envBound10464 : H12AffineFastState.Bounded env10464 := by
  intro p hp
  have h : env10464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10461_10464 : H12AffineEnvironment.transform 2 1 env10461 = env10464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env10461 == env10464) = true)

theorem identity10464 : scanCanonicalize (H12AffineFastState.compose env10464 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound10464 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10465 : List Nat := [0,4,1,16,32,64,1,84,81,84,112,17,80,64,0,80,64,1,84,0,16,80,65,0,80,17,1,65,16,112,4,32,85,81,64,81]

theorem envBound10465 : H12AffineFastState.Bounded env10465 := by
  intro p hp
  have h : env10465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10464_10465 : H12AffineEnvironment.transform 0 0 env10464 = env10465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env10464 == env10465) = true)

theorem identity10465 : scanCanonicalize (H12AffineFastState.compose env10465 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound10465 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10466 : List Nat := [0,4,1,16,1,64,1,84,81,84,81,17,80,64,0,80,64,1,84,0,16,80,65,0,80,17,1,65,16,81,4,1,85,81,64,81]

theorem envBound10466 : H12AffineFastState.Bounded env10466 := by
  intro p hp
  have h : env10466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10465_10466 : H12AffineEnvironment.transform 4 1 env10465 = env10466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env10465 == env10466) = true)

def leafEnv10466 : List Nat := [0,4,1,16,1,64,1,84,81,84,81,17,80,64,0,80,64,1,84,0,16,80,65,0,4,80,1,17,1,65,16,81,4,1,85,81,5,80,64,81,0,16,1]

def active10466 : List Nat := [1,3,5]

def tree10466 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood10466 : H12WitnessSearch.Good tree10466 := H12GlobalWitnessIndex.good

theorem leafIdentity10466 : H12AffineFastState.composeSystem env10466 rootObs = leafEnv10466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env10466 rootObs == leafEnv10466) = true)

theorem terminalChecked10466 : H12PackedTerminal.terminalCheckFast leafEnv10466 active10466 tree10466 = true := by decide +kernel

def env10467 : List Nat := [2,4,8,16,32,64,9,256,260,256,2048,325,89,276,340,65536,64,65625,256,340,324,261,277,65616,88,325,65624,277,16,67666,4,65650,257,261,64,260]

theorem envBound10467 : H12AffineFastState.Bounded env10467 := by
  intro p hp
  have h : env10467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10457_10467 : H12AffineEnvironment.transform 6 9 env10457 = env10467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env10457 == env10467) = true)

theorem identity10467 : scanCanonicalize (H12AffineFastState.compose env10467 (packedSelected [7] rootPS)) = affineNative (2^(15+1) ^^^ 81) := by decide +kernel

theorem selectedBound10467 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env10468 : List Nat := [2,4,8,16,32,64,9,256,260,256,2048,325,89,276,340,81,64,8,256,340,324,261,277,1,88,325,9,277,16,2051,4,35,257,261,64,260]

theorem envBound10468 : H12AffineFastState.Bounded env10468 := by
  intro p hp
  have h : env10468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10467_10468 : H12AffineEnvironment.transform 15 81 env10467 = env10468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 81 env10467 == env10468) = true)

theorem identity10468 : scanCanonicalize (H12AffineFastState.compose env10468 (packedSelected [5,8,23,32] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound10468 : packedSelected [5,8,23,32] rootPS < 2^1333 := by decide +kernel

def env10469 : List Nat := [2,4,8,16,32,64,9,37,33,37,2048,96,89,49,113,81,64,8,37,113,97,32,48,1,88,96,9,48,16,2051,4,35,36,32,64,33]

theorem envBound10469 : H12AffineFastState.Bounded env10469 := by
  intro p hp
  have h : env10469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10468_10469 : H12AffineEnvironment.transform 7 37 env10468 = env10469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env10468 == env10469) = true)

theorem identity10469 : scanCanonicalize (H12AffineFastState.compose env10469 (packedSelected [1,3,5,11] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound10469 : packedSelected [1,3,5,11] rootPS < 2^1333 := by decide +kernel

def env10470 : List Nat := [2,4,8,16,32,64,9,37,33,37,10,96,89,49,113,81,64,8,37,113,97,32,48,1,88,96,9,48,16,9,4,35,36,32,64,33]

theorem envBound10470 : H12AffineFastState.Bounded env10470 := by
  intro p hp
  have h : env10470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10469_10470 : H12AffineEnvironment.transform 10 10 env10469 = env10470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env10469 == env10470) = true)

theorem identity10470 : scanCanonicalize (H12AffineFastState.compose env10470 (packedSelected [0,1,2,3,4,5] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound10470 : packedSelected [0,1,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env10471 : List Nat := [0,4,8,16,32,64,9,37,33,37,8,96,89,49,113,81,64,8,37,113,97,32,48,1,88,96,9,48,16,9,4,33,36,32,64,33]

theorem envBound10471 : H12AffineFastState.Bounded env10471 := by
  intro p hp
  have h : env10471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10470_10471 : H12AffineEnvironment.transform 0 0 env10470 = env10471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env10470 == env10471) = true)

theorem identity10471 : scanCanonicalize (H12AffineFastState.compose env10471 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound10471 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env10472 : List Nat := [0,4,8,16,32,48,9,37,33,37,8,16,41,49,1,33,48,8,37,1,17,32,48,1,40,16,9,48,16,9,4,33,36,32,48,33]

theorem envBound10472 : H12AffineFastState.Bounded env10472 := by
  intro p hp
  have h : env10472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10471_10472 : H12AffineEnvironment.transform 5 48 env10471 = env10472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env10471 == env10472) = true)

def leafEnv10472 : List Nat := [0,4,8,16,32,48,9,37,33,37,8,16,41,49,1,33,48,8,37,1,17,32,48,1,4,40,1,16,9,48,16,9,4,33,36,32,5,32,48,33,0,16,1]

def active10472 : List Nat := [1,2,3,4]

def tree10472 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood10472 : H12WitnessSearch.Good tree10472 := H12GlobalWitnessIndex.good

theorem leafIdentity10472 : H12AffineFastState.composeSystem env10472 rootObs = leafEnv10472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env10472 rootObs == leafEnv10472) = true)

theorem terminalChecked10472 : H12PackedTerminal.terminalCheckFast leafEnv10472 active10472 tree10472 = true := by decide +kernel

def env10473 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,4097,4194304,17665,230468,33554432,67108864,4609045,67130625,131152,1073741824,131140,4294967296,257,4400079159,131072,33563272]

theorem envBound10473 : H12AffineFastState.Bounded env10473 := by
  intro p hp
  have h : env10473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10441_10473 : H12AffineEnvironment.transform 18 1025 env10441 = env10473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env10441 == env10473) = true)

theorem identity10473 : scanCanonicalize (H12AffineFastState.compose env10473 (packedSelected [4,6,7,9,16,20,25,27] rootPS)) = affineNative (2^(29+1) ^^^ 71409034) := by decide +kernel

theorem selectedBound10473 : packedSelected [4,6,7,9,16,20,25,27] rootPS < 2^1333 := by decide +kernel

def env10474 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,4097,4194304,17665,230468,33554432,67108864,4609045,67130625,131152,71409034,131140,4294967296,257,4400079159,131072,33563272]

theorem envBound10474 : H12AffineFastState.Bounded env10474 := by
  intro p hp
  have h : env10474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10473_10474 : H12AffineEnvironment.transform 29 71409034 env10473 = env10474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 71409034 env10473 == env10474) = true)

def env10475 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1025,32768,4097,4194304,5457,230468,33554432,67108864,4588613,67110225,131152,71409034,131140,4294967296,257,4400066919,131072,33563272]

theorem envBound10475 : H12AffineFastState.Bounded env10475 := by
  intro p hp
  have h : env10475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10474_10475 : H12AffineEnvironment.transform 13 4176 env10474 = env10475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4176 env10474 == env10475) = true)

theorem identity10475 : scanCanonicalize (H12AffineFastState.compose env10475 (packedSelected [1,3,6,10,19,24,25,26,28,31] rootPS)) = affineNative (2^(24+1) ^^^ 8329) := by decide +kernel

theorem selectedBound10475 : packedSelected [1,3,6,10,19,24,25,26,28,31] rootPS < 2^1333 := by decide +kernel

def env10476 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1025,32768,4097,4194304,5457,230468,8329,67108864,4588613,67110225,131152,71409034,131140,4294967296,257,4366504430,131072,513]

theorem envBound10476 : H12AffineFastState.Bounded env10476 := by
  intro p hp
  have h : env10476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10475_10476 : H12AffineEnvironment.transform 24 8329 env10475 = env10476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8329 env10475 == env10476) = true)

theorem identity10476 : scanCanonicalize (H12AffineFastState.compose env10476 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(25+1) ^^^ 5377) := by decide +kernel

theorem selectedBound10476 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env10477 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1025,32768,4097,4194304,5457,230468,8329,5377,4588613,4176,131152,4294795,131140,4294967296,257,4299392239,131072,513]

theorem envBound10477 : H12AffineFastState.Bounded env10477 := by
  intro p hp
  have h : env10477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10476_10477 : H12AffineEnvironment.transform 25 5377 env10476 = env10477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 5377 env10476 == env10477) = true)

theorem identity10477 : scanCanonicalize (H12AffineFastState.compose env10477 (packedSelected [13,21] rootPS)) = affineNative (2^(31+1) ^^^ 4329688) := by decide +kernel

theorem selectedBound10477 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env10478 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,32768,65536,131072,262144,1025,32768,4097,4194304,5457,230468,8329,5377,4588613,4176,131152,4294795,131140,4329688,257,103479,131072,513]

theorem envBound10478 : H12AffineFastState.Bounded env10478 := by
  intro p hp
  have h : env10478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10477_10478 : H12AffineEnvironment.transform 31 4329688 env10477 = env10478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4329688 env10477 == env10478) = true)

def env10479 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1025,32768,4097,4194304,5456,230468,33554432,67108864,4588612,67110224,131152,71409034,131140,4294967296,257,4400066918,131072,33563272]

theorem envBound10479 : H12AffineFastState.Bounded env10479 := by
  intro p hp
  have h : env10479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10474_10479 : H12AffineEnvironment.transform 13 4177 env10474 = env10479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env10474 == env10479) = true)

def env10480 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,131072,262144,1025,32768,4097,4194304,5456,230468,4259840,67108864,4588612,67110224,131152,71409034,131140,4294967296,257,4362252646,131072,4268680]

theorem envBound10480 : H12AffineFastState.Bounded env10480 := by
  intro p hp
  have h : env10480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10479_10480 : H12AffineEnvironment.transform 24 4259840 env10479 = env10480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 4259840 env10479 == env10480) = true)

def env10481 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,4096,262144,1025,32768,4097,4194304,5456,103492,4259840,67108864,4461636,67110224,4176,71409034,4164,4294967296,257,4362117478,4096,4268680]

theorem envBound10481 : H12AffineFastState.Bounded env10481 := by
  intro p hp
  have h : env10481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10480_10481 : H12AffineEnvironment.transform 16 4096 env10480 = env10481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env10480 == env10481) = true)

end H12CloudChart2