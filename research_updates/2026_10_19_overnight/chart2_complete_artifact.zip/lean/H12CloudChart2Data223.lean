import H12CloudChart2Data222

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans56249_56250 : H12AffineEnvironment.transform 13 1296 env56249 = env56250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env56249 == env56250) = true)

def env56251 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74862,65664,4417,8540,4097,5277,74046,66897,13769,78894,1151,74815,1296,81226,8205,74799,256,8201,1344,5952]

theorem envBound56251 : H12AffineFastState.Bounded env56251 := by
  intro p hp
  have h : env56251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56250_56251 : H12AffineEnvironment.transform 17 65664 env56250 = env56251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env56250 == env56251) = true)

theorem identity56251 : scanCanonicalize (H12AffineFastState.compose env56251 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5384) := by decide +kernel

theorem selectedBound56251 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env56252 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5384,1296,5205,65536,69990,65664,4417,5204,4097,5277,70710,66897,193,65830,1151,69943,1296,67650,5381,69927,256,5377,1344,5952]

theorem envBound56252 : H12AffineFastState.Bounded env56252 := by
  intro p hp
  have h : env56252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56251_56252 : H12AffineEnvironment.transform 12 5384 env56251 = env56252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5384 env56251 == env56252) = true)

def env56253 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1556,796,1296,577,65536,67442,65664,1877,576,1557,649,66082,66897,193,65830,1151,67363,1296,67650,785,67379,256,789,1344,340]

theorem envBound56253 : H12AffineFastState.Bounded env56253 := by
  intro p hp
  have h : env56253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56252_56253 : H12AffineEnvironment.transform 11 1556 env56252 = env56253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env56252 == env56253) = true)

def env56254 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,836,796,64,577,65536,66082,65664,517,576,837,649,66082,65537,193,65830,303,66163,64,67650,785,66147,256,789,16,340]

theorem envBound56254 : H12AffineFastState.Bounded env56254 := by
  intro p hp
  have h : env56254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56253_56254 : H12AffineEnvironment.transform 9 336 env56253 = env56254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env56253 == env56254) = true)

theorem identity56254 : scanCanonicalize (H12AffineFastState.compose env56254 (packedSelected [1,8,28] rootPS)) = affineNative (2^(8+1) ^^^ 490) := by decide +kernel

theorem selectedBound56254 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env56255 : List Nat := [2,4,8,16,32,64,128,256,490,336,2048,174,246,64,427,65536,65992,65664,495,426,175,355,65992,65537,193,65830,303,65945,64,67650,251,65929,256,255,16,340]

theorem envBound56255 : H12AffineFastState.Bounded env56255 := by
  intro p hp
  have h : env56255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56254_56255 : H12AffineEnvironment.transform 8 490 env56254 = env56255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 490 env56254 == env56255) = true)

def env56256 : List Nat := [2,4,8,0,32,64,128,256,490,320,2048,174,230,64,427,65536,65992,65664,495,426,175,355,65992,65537,193,65830,303,65929,64,67650,235,65929,256,239,0,324]

theorem envBound56256 : H12AffineFastState.Bounded env56256 := by
  intro p hp
  have h : env56256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56255_56256 : H12AffineEnvironment.transform 3 0 env56255 = env56256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env56255 == env56256) = true)

theorem identity56256 : scanCanonicalize (H12AffineFastState.compose env56256 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 204) := by decide +kernel

theorem selectedBound56256 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env56257 : List Nat := [2,4,8,0,32,64,128,256,490,320,2048,174,230,64,427,204,260,76,495,426,175,355,260,205,193,490,303,325,64,2190,235,325,256,239,0,324]

theorem envBound56257 : H12AffineFastState.Bounded env56257 := by
  intro p hp
  have h : env56257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56256_56257 : H12AffineEnvironment.transform 15 204 env56256 = env56257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 204 env56256 == env56257) = true)

theorem identity56257 : scanCanonicalize (H12AffineFastState.compose env56257 (packedSelected [0,2,3,4,5,7,9,10,11,13,16,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 75) := by decide +kernel

theorem selectedBound56257 : packedSelected [0,2,3,4,5,7,9,10,11,13,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env56258 : List Nat := [2,4,8,0,32,64,128,256,490,320,75,174,230,64,427,204,260,76,495,426,175,355,260,205,193,490,303,325,64,197,235,325,256,239,0,324]

theorem envBound56258 : H12AffineFastState.Bounded env56258 := by
  intro p hp
  have h : env56258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56257_56258 : H12AffineEnvironment.transform 10 75 env56257 = env56258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 75 env56257 == env56258) = true)

theorem identity56258 : scanCanonicalize (H12AffineFastState.compose env56258 (packedSelected [1,2,11,15,17,18] rootPS)) = affineNative (2^(7+1) ^^^ 40) := by decide +kernel

theorem selectedBound56258 : packedSelected [1,2,11,15,17,18] rootPS < 2^1333 := by decide +kernel

def env56259 : List Nat := [2,4,8,0,32,64,128,40,194,104,75,174,230,64,131,204,44,76,199,130,175,75,44,205,193,194,7,109,64,197,235,109,40,239,0,108]

theorem envBound56259 : H12AffineFastState.Bounded env56259 := by
  intro p hp
  have h : env56259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56258_56259 : H12AffineEnvironment.transform 7 40 env56258 = env56259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 40 env56258 == env56259) = true)

theorem identity56259 : scanCanonicalize (H12AffineFastState.compose env56259 (packedSelected [0,5,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound56259 : packedSelected [0,5,9,11] rootPS < 2^1333 := by decide +kernel

def env56260 : List Nat := [2,4,8,0,32,32,128,40,162,8,43,174,134,32,131,172,44,44,167,130,175,43,44,173,161,162,7,13,32,165,139,13,40,143,0,12]

theorem envBound56260 : H12AffineFastState.Bounded env56260 := by
  intro p hp
  have h : env56260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56259_56260 : H12AffineEnvironment.transform 5 32 env56259 = env56260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env56259 == env56260) = true)

theorem identity56260 : scanCanonicalize (H12AffineFastState.compose env56260 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound56260 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env56261 : List Nat := [2,4,3,0,32,32,128,35,162,3,32,165,134,32,131,167,39,39,167,130,164,32,39,166,161,162,7,6,32,165,128,6,35,132,0,7]

theorem envBound56261 : H12AffineFastState.Bounded env56261 := by
  intro p hp
  have h : env56261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56260_56261 : H12AffineEnvironment.transform 2 3 env56260 = env56261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env56260 == env56261) = true)

theorem identity56261 : scanCanonicalize (H12AffineFastState.compose env56261 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound56261 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env56262 : List Nat := [2,4,3,0,32,32,2,35,32,3,32,39,4,32,1,37,39,39,37,0,38,32,39,36,35,32,7,6,32,39,2,6,35,6,0,7]

theorem envBound56262 : H12AffineFastState.Bounded env56262 := by
  intro p hp
  have h : env56262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56261_56262 : H12AffineEnvironment.transform 6 2 env56261 = env56262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env56261 == env56262) = true)

theorem identity56262 : scanCanonicalize (H12AffineFastState.compose env56262 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound56262 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56263 : List Nat := [2,3,3,0,32,32,2,35,32,3,32,32,3,32,1,34,32,32,34,0,33,32,32,35,35,32,0,1,32,32,2,1,35,1,0,0]

theorem envBound56263 : H12AffineFastState.Bounded env56263 := by
  intro p hp
  have h : env56263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56262_56263 : H12AffineEnvironment.transform 1 3 env56262 = env56263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env56262 == env56263) = true)

def env56264 : List Nat := [2,4,8,1,32,64,128,256,490,321,2048,174,231,64,427,65536,65992,65664,495,426,175,355,65992,65537,193,65830,303,65928,64,67650,234,65929,256,238,1,325]

theorem envBound56264 : H12AffineFastState.Bounded env56264 := by
  intro p hp
  have h : env56264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56255_56264 : H12AffineEnvironment.transform 3 1 env56255 = env56264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env56255 == env56264) = true)

theorem identity56264 : scanCanonicalize (H12AffineFastState.compose env56264 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 99) := by decide +kernel

theorem selectedBound56264 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env56265 : List Nat := [2,4,8,1,32,64,128,256,490,321,2048,174,231,64,427,99,427,227,495,426,175,355,427,98,193,325,303,491,64,2081,234,490,256,238,1,325]

theorem envBound56265 : H12AffineFastState.Bounded env56265 := by
  intro p hp
  have h : env56265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56264_56265 : H12AffineEnvironment.transform 15 99 env56264 = env56265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 99 env56264 == env56265) = true)

theorem identity56265 : scanCanonicalize (H12AffineFastState.compose env56265 (packedSelected [2,4,9,11,13,16,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 265) := by decide +kernel

theorem selectedBound56265 : packedSelected [2,4,9,11,13,16,17,18] rootPS < 2^1333 := by decide +kernel

def env56266 : List Nat := [2,4,8,1,32,64,128,256,490,321,265,174,231,64,427,99,427,227,495,426,175,355,427,98,193,325,303,491,64,296,234,490,256,238,1,325]

theorem envBound56266 : H12AffineFastState.Bounded env56266 := by
  intro p hp
  have h : env56266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56265_56266 : H12AffineEnvironment.transform 10 265 env56265 = env56266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 265 env56265 == env56266) = true)

theorem identity56266 : scanCanonicalize (H12AffineFastState.compose env56266 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(6+1) ^^^ 110) := by decide +kernel

theorem selectedBound56266 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env56267 : List Nat := [2,4,8,1,32,64,110,256,260,321,265,64,9,64,325,99,325,13,257,324,65,355,325,98,47,325,303,261,64,296,4,260,256,0,1,325]

theorem envBound56267 : H12AffineFastState.Bounded env56267 := by
  intro p hp
  have h : env56267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56266_56267 : H12AffineEnvironment.transform 6 110 env56266 = env56267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 110 env56266 == env56267) = true)

theorem identity56267 : scanCanonicalize (H12AffineFastState.compose env56267 (packedSelected [0,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 73) := by decide +kernel

theorem selectedBound56267 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env56268 : List Nat := [2,4,8,1,32,64,110,73,77,8,64,64,9,64,12,99,12,13,72,13,65,42,12,98,47,12,102,76,64,97,4,77,73,0,1,12]

theorem envBound56268 : H12AffineFastState.Bounded env56268 := by
  intro p hp
  have h : env56268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56267_56268 : H12AffineEnvironment.transform 7 73 env56267 = env56268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 73 env56267 == env56268) = true)

theorem identity56268 : scanCanonicalize (H12AffineFastState.compose env56268 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound56268 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env56269 : List Nat := [2,4,5,1,32,64,99,68,64,5,64,64,4,64,1,99,1,0,69,0,65,39,1,98,34,1,102,65,64,97,4,64,68,0,1,1]

theorem envBound56269 : H12AffineFastState.Bounded env56269 := by
  intro p hp
  have h : env56269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56268_56269 : H12AffineEnvironment.transform 2 5 env56268 = env56269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env56268 == env56269) = true)

theorem identity56269 : scanCanonicalize (H12AffineFastState.compose env56269 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 38) := by decide +kernel

theorem selectedBound56269 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56270 : List Nat := [2,4,5,1,32,38,5,34,38,5,38,38,4,38,1,5,1,0,35,0,39,39,1,4,34,1,0,39,38,7,4,38,34,0,1,1]

theorem envBound56270 : H12AffineFastState.Bounded env56270 := by
  intro p hp
  have h : env56270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56269_56270 : H12AffineEnvironment.transform 5 38 env56269 = env56270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 38 env56269 == env56270) = true)

theorem identity56270 : scanCanonicalize (H12AffineFastState.compose env56270 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound56270 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56271 : List Nat := [2,3,2,1,32,33,2,34,33,2,33,33,3,33,1,2,1,0,35,0,32,32,1,3,34,1,0,32,33,0,3,33,34,0,1,1]

theorem envBound56271 : H12AffineFastState.Bounded env56271 := by
  intro p hp
  have h : env56271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56270_56271 : H12AffineEnvironment.transform 1 3 env56270 = env56271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env56270 == env56271) = true)

theorem identity56271 : scanCanonicalize (H12AffineFastState.compose env56271 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound56271 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env56272 : List Nat := [2,3,2,1,0,1,2,2,1,2,1,1,3,1,1,2,1,0,3,0,0,0,1,3,2,1,0,0,1,0,3,1,2,0,1,1]

theorem envBound56272 : H12AffineFastState.Bounded env56272 := by
  intro p hp
  have h : env56272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56271_56272 : H12AffineEnvironment.transform 4 0 env56271 = env56272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env56271 == env56272) = true)

def env56273 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,837,796,65,577,65536,66083,65664,516,576,836,649,66082,65536,193,65830,302,66162,65,67650,785,66146,256,789,17,340]

theorem envBound56273 : H12AffineFastState.Bounded env56273 := by
  intro p hp
  have h : env56273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56253_56273 : H12AffineEnvironment.transform 9 337 env56253 = env56273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env56253 == env56273) = true)

theorem identity56273 : scanCanonicalize (H12AffineFastState.compose env56273 (packedSelected [1,8,28] rootPS)) = affineNative (2^(6+1) ^^^ 46) := by decide +kernel

theorem selectedBound56273 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env56274 : List Nat := [2,4,8,16,32,64,46,256,512,337,2048,837,796,65,577,65536,66083,65582,516,576,836,551,66082,65536,111,65830,302,66162,65,67650,785,66146,256,789,17,340]

theorem envBound56274 : H12AffineFastState.Bounded env56274 := by
  intro p hp
  have h : env56274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56273_56274 : H12AffineEnvironment.transform 6 46 env56273 = env56274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 46 env56273 == env56274) = true)

def env56275 : List Nat := [2,4,8,0,32,64,46,256,512,321,2048,837,780,65,577,65536,66083,65582,516,576,836,551,66082,65536,111,65830,302,66146,65,67650,769,66146,256,773,1,324]

theorem envBound56275 : H12AffineFastState.Bounded env56275 := by
  intro p hp
  have h : env56275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56274_56275 : H12AffineEnvironment.transform 3 0 env56274 = env56275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env56274 == env56275) = true)

theorem identity56275 : scanCanonicalize (H12AffineFastState.compose env56275 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 98) := by decide +kernel

theorem selectedBound56275 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env56276 : List Nat := [2,4,8,0,32,64,46,256,512,321,2048,837,780,65,577,98,577,76,516,576,836,551,576,98,111,324,302,512,65,2080,769,512,256,773,1,324]

theorem envBound56276 : H12AffineFastState.Bounded env56276 := by
  intro p hp
  have h : env56276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56275_56276 : H12AffineEnvironment.transform 15 98 env56275 = env56276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 98 env56275 == env56276) = true)

theorem identity56276 : scanCanonicalize (H12AffineFastState.compose env56276 (packedSelected [2,4,9,11,13,16,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 588) := by decide +kernel

theorem selectedBound56276 : packedSelected [2,4,9,11,13,16,17,18] rootPS < 2^1333 := by decide +kernel

def env56277 : List Nat := [2,4,8,0,32,64,46,256,512,321,588,837,780,65,577,98,577,76,516,576,836,551,576,98,111,324,302,512,65,620,769,512,256,773,1,324]

theorem envBound56277 : H12AffineFastState.Bounded env56277 := by
  intro p hp
  have h : env56277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56276_56277 : H12AffineEnvironment.transform 10 588 env56276 = env56277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 588 env56276 == env56277) = true)

theorem identity56277 : scanCanonicalize (H12AffineFastState.compose env56277 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound56277 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env56278 : List Nat := [2,4,8,0,32,64,46,256,260,321,328,65,8,65,325,98,325,76,256,324,64,291,324,98,111,324,302,260,65,360,5,260,256,1,1,324]

theorem envBound56278 : H12AffineFastState.Bounded env56278 := by
  intro p hp
  have h : env56278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56277_56278 : H12AffineEnvironment.transform 8 260 env56277 = env56278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env56277 == env56278) = true)

theorem identity56278 : scanCanonicalize (H12AffineFastState.compose env56278 (packedSelected [0,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 72) := by decide +kernel

theorem selectedBound56278 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env56279 : List Nat := [2,4,8,0,32,64,46,72,76,9,0,65,8,65,13,98,13,76,72,12,64,107,12,98,111,12,102,76,65,32,5,76,72,1,1,12]

theorem envBound56279 : H12AffineFastState.Bounded env56279 := by
  intro p hp
  have h : env56279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56278_56279 : H12AffineEnvironment.transform 7 72 env56278 = env56279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 72 env56278 == env56279) = true)

theorem identity56279 : scanCanonicalize (H12AffineFastState.compose env56279 (packedSelected [0,2,3,5,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 6) := by decide +kernel

theorem selectedBound56279 : packedSelected [0,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env56280 : List Nat := [2,4,8,0,32,6,46,14,10,9,0,7,8,7,13,36,13,10,14,12,6,45,12,36,41,12,32,10,7,32,5,10,14,1,1,12]

theorem envBound56280 : H12AffineFastState.Bounded env56280 := by
  intro p hp
  have h : env56280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56279_56280 : H12AffineEnvironment.transform 5 6 env56279 = env56280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 6 env56279 == env56280) = true)

theorem identity56280 : scanCanonicalize (H12AffineFastState.compose env56280 (packedSelected [2,3] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound56280 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env56281 : List Nat := [2,4,8,0,12,6,2,14,10,9,0,7,8,7,13,8,13,10,14,12,6,1,12,8,5,12,12,10,7,12,5,10,14,1,1,12]

theorem envBound56281 : H12AffineFastState.Bounded env56281 := by
  intro p hp
  have h : env56281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56280_56281 : H12AffineEnvironment.transform 4 12 env56280 = env56281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env56280 == env56281) = true)

theorem identity56281 : scanCanonicalize (H12AffineFastState.compose env56281 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound56281 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56282 : List Nat := [2,4,5,0,1,6,2,3,7,4,0,7,5,7,0,5,0,7,3,1,6,1,1,5,5,1,1,7,7,1,5,7,3,1,1,1]

theorem envBound56282 : H12AffineFastState.Bounded env56282 := by
  intro p hp
  have h : env56282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56281_56282 : H12AffineEnvironment.transform 2 5 env56281 = env56282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env56281 == env56282) = true)

theorem identity56282 : scanCanonicalize (H12AffineFastState.compose env56282 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound56282 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56283 : List Nat := [2,3,2,0,1,1,2,3,0,3,0,0,2,0,0,2,0,0,3,1,1,1,1,2,2,1,1,0,0,1,2,0,3,1,1,1]

theorem envBound56283 : H12AffineFastState.Bounded env56283 := by
  intro p hp
  have h : env56283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56282_56283 : H12AffineEnvironment.transform 1 3 env56282 = env56283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env56282 == env56283) = true)

theorem identity56283 : scanCanonicalize (H12AffineFastState.compose env56283 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound56283 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56284 : List Nat := [1,0,1,0,1,1,1,0,0,0,0,0,1,0,0,1,0,0,0,1,1,1,1,1,1,1,1,0,0,1,1,0,0,1,1,1]

theorem envBound56284 : H12AffineFastState.Bounded env56284 := by
  intro p hp
  have h : env56284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56283_56284 : H12AffineEnvironment.transform 0 1 env56283 = env56284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env56283 == env56284) = true)

def env56285 : List Nat := [2,4,8,1,32,64,46,256,512,320,2048,837,781,65,577,65536,66083,65582,516,576,836,551,66082,65536,111,65830,302,66147,65,67650,768,66146,256,772,0,325]

theorem envBound56285 : H12AffineFastState.Bounded env56285 := by
  intro p hp
  have h : env56285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56274_56285 : H12AffineEnvironment.transform 3 1 env56274 = env56285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env56274 == env56285) = true)

theorem identity56285 : scanCanonicalize (H12AffineFastState.compose env56285 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 806) := by decide +kernel

theorem selectedBound56285 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env56286 : List Nat := [2,4,8,1,32,64,46,256,512,320,2048,837,781,65,577,806,261,776,516,576,836,551,260,806,111,512,302,325,65,2916,768,324,256,772,0,325]

theorem envBound56286 : H12AffineFastState.Bounded env56286 := by
  intro p hp
  have h : env56286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56285_56286 : H12AffineEnvironment.transform 15 806 env56285 = env56286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 806 env56285 == env56286) = true)

theorem identity56286 : scanCanonicalize (H12AffineFastState.compose env56286 (packedSelected [0,2,3,4,5,7,9,10,11,13,16,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 74) := by decide +kernel

theorem selectedBound56286 : packedSelected [0,2,3,4,5,7,9,10,11,13,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env56287 : List Nat := [2,4,8,1,32,64,46,256,512,320,74,837,781,65,577,806,261,776,516,576,836,551,260,806,111,512,302,325,65,814,768,324,256,772,0,325]

theorem envBound56287 : H12AffineFastState.Bounded env56287 := by
  intro p hp
  have h : env56287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56286_56287 : H12AffineEnvironment.transform 10 74 env56286 = env56287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 74 env56286 == env56287) = true)

theorem identity56287 : scanCanonicalize (H12AffineFastState.compose env56287 (packedSelected [1,2,11,15,17,18] rootPS)) = affineNative (2^(8+1) ^^^ 296) := by decide +kernel

theorem selectedBound56287 : packedSelected [1,2,11,15,17,18] rootPS < 2^1333 := by decide +kernel

def env56288 : List Nat := [2,4,8,1,32,64,46,256,296,320,74,109,37,65,361,14,261,32,300,360,108,271,260,14,111,296,302,325,65,6,40,324,256,44,0,325]

theorem envBound56288 : H12AffineFastState.Bounded env56288 := by
  intro p hp
  have h : env56288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56287_56288 : H12AffineEnvironment.transform 8 296 env56287 = env56288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 296 env56287 == env56288) = true)

theorem identity56288 : scanCanonicalize (H12AffineFastState.compose env56288 (packedSelected [1,2,3,5,12] rootPS)) = affineNative (2^(5+1) ^^^ 39) := by decide +kernel

theorem selectedBound56288 : packedSelected [1,2,3,5,12] rootPS < 2^1333 := by decide +kernel

def env56289 : List Nat := [2,4,8,1,32,39,46,256,296,295,45,10,37,38,270,14,261,32,300,271,11,271,260,14,8,296,302,290,38,6,40,291,256,44,0,290]

theorem envBound56289 : H12AffineFastState.Bounded env56289 := by
  intro p hp
  have h : env56289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56288_56289 : H12AffineEnvironment.transform 5 39 env56288 = env56289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 39 env56288 == env56289) = true)

theorem identity56289 : scanCanonicalize (H12AffineFastState.compose env56289 (packedSelected [3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound56289 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env56290 : List Nat := [2,4,8,1,32,39,46,37,13,2,45,10,37,38,43,14,32,32,9,42,11,42,33,14,8,13,11,7,38,6,40,6,37,44,0,7]

theorem envBound56290 : H12AffineFastState.Bounded env56290 := by
  intro p hp
  have h : env56290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56289_56290 : H12AffineEnvironment.transform 7 37 env56289 = env56290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env56289 == env56290) = true)

theorem identity56290 : scanCanonicalize (H12AffineFastState.compose env56290 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound56290 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env56291 : List Nat := [2,4,3,1,32,39,37,37,6,2,38,1,37,38,32,5,32,32,2,33,0,33,33,5,3,6,0,7,38,6,35,6,37,39,0,7]

theorem envBound56291 : H12AffineFastState.Bounded env56291 := by
  intro p hp
  have h : env56291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56290_56291 : H12AffineEnvironment.transform 2 3 env56290 = env56291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env56290 == env56291) = true)

theorem identity56291 : scanCanonicalize (H12AffineFastState.compose env56291 (packedSelected [0,1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound56291 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env56292 : List Nat := [2,0,3,1,32,35,33,33,2,2,34,1,33,34,32,1,32,32,2,33,0,33,33,1,3,2,0,3,34,2,35,2,33,35,0,3]

theorem envBound56292 : H12AffineFastState.Bounded env56292 := by
  intro p hp
  have h : env56292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56291_56292 : H12AffineEnvironment.transform 1 0 env56291 = env56292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env56291 == env56292) = true)

theorem identity56292 : scanCanonicalize (H12AffineFastState.compose env56292 (packedSelected [0,4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound56292 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env56293 : List Nat := [1,0,0,1,32,32,33,33,1,1,33,1,33,33,32,1,32,32,1,33,0,33,33,1,0,1,0,0,33,1,32,1,33,32,0,0]

theorem envBound56293 : H12AffineFastState.Bounded env56293 := by
  intro p hp
  have h : env56293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56292_56293 : H12AffineEnvironment.transform 0 1 env56292 = env56293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env56292 == env56293) = true)

theorem identity56293 : scanCanonicalize (H12AffineFastState.compose env56293 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound56293 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env56294 : List Nat := [1,0,0,1,0,0,1,1,1,1,1,1,1,1,0,1,0,0,1,1,0,1,1,1,0,1,0,0,1,1,0,1,1,0,0,0]

theorem envBound56294 : H12AffineFastState.Bounded env56294 := by
  intro p hp
  have h : env56294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56293_56294 : H12AffineEnvironment.transform 4 0 env56293 = env56294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env56293 == env56294) = true)

def env56295 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1557,797,1296,576,65536,67443,65664,1876,577,1556,648,66083,66897,193,65830,1151,67362,1296,67650,784,67378,256,788,1344,341]

theorem envBound56295 : H12AffineFastState.Bounded env56295 := by
  intro p hp
  have h : env56295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56252_56295 : H12AffineEnvironment.transform 11 1557 env56252 = env56295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env56252 == env56295) = true)

def env56296 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,837,797,64,576,65536,66083,65664,516,577,836,648,66083,65537,193,65830,303,66162,64,67650,784,66146,256,788,16,341]

theorem envBound56296 : H12AffineFastState.Bounded env56296 := by
  intro p hp
  have h : env56296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56295_56296 : H12AffineEnvironment.transform 9 336 env56295 = env56296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env56295 == env56296) = true)

theorem identity56296 : scanCanonicalize (H12AffineFastState.compose env56296 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 472) := by decide +kernel

theorem selectedBound56296 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env56297 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,837,797,64,576,472,1019,344,516,577,836,648,1019,473,193,254,303,938,64,2458,784,954,256,788,16,341]

theorem envBound56297 : H12AffineFastState.Bounded env56297 := by
  intro p hp
  have h : env56297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56296_56297 : H12AffineEnvironment.transform 15 472 env56296 = env56297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 472 env56296 == env56297) = true)

def env56298 : List Nat := [2,4,8,0,32,64,128,256,512,320,2048,837,781,64,576,456,1003,328,516,577,836,648,1003,457,193,238,303,938,64,2442,768,938,256,772,0,325]

theorem envBound56298 : H12AffineFastState.Bounded env56298 := by
  intro p hp
  have h : env56298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56297_56298 : H12AffineEnvironment.transform 3 0 env56297 = env56298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env56297 == env56298) = true)

theorem identity56298 : scanCanonicalize (H12AffineFastState.compose env56298 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 239) := by decide +kernel

theorem selectedBound56298 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env56299 : List Nat := [2,4,8,0,32,64,128,256,239,320,2048,426,482,64,175,456,260,328,235,174,427,103,260,457,193,238,303,325,64,2442,495,325,256,491,0,325]

theorem envBound56299 : H12AffineFastState.Bounded env56299 := by
  intro p hp
  have h : env56299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56298_56299 : H12AffineEnvironment.transform 8 239 env56298 = env56299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 239 env56298 == env56299) = true)

theorem identity56299 : scanCanonicalize (H12AffineFastState.compose env56299 (packedSelected [0,2,3,4,5,7,9,10,11,13,16,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 74) := by decide +kernel

theorem selectedBound56299 : packedSelected [0,2,3,4,5,7,9,10,11,13,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env56300 : List Nat := [2,4,8,0,32,64,128,256,239,320,74,426,482,64,175,456,260,328,235,174,427,103,260,457,193,238,303,325,64,448,495,325,256,491,0,325]

theorem envBound56300 : H12AffineFastState.Bounded env56300 := by
  intro p hp
  have h : env56300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56299_56300 : H12AffineEnvironment.transform 10 74 env56299 = env56300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 74 env56299 == env56300) = true)

theorem identity56300 : scanCanonicalize (H12AffineFastState.compose env56300 (packedSelected [1,2,11,15,17,18] rootPS)) = affineNative (2^(6+1) ^^^ 67) := by decide +kernel

theorem selectedBound56300 : packedSelected [1,2,11,15,17,18] rootPS < 2^1333 := by decide +kernel

def env56301 : List Nat := [2,4,8,0,32,64,67,256,44,320,74,361,289,64,108,267,260,328,40,109,360,103,260,266,2,45,303,325,64,259,300,325,256,296,0,325]

theorem envBound56301 : H12AffineFastState.Bounded env56301 := by
  intro p hp
  have h : env56301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56300_56301 : H12AffineEnvironment.transform 6 67 env56300 = env56301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 67 env56300 == env56301) = true)

theorem identity56301 : scanCanonicalize (H12AffineFastState.compose env56301 (packedSelected [0,3,5,9,11] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound56301 : packedSelected [0,3,5,9,11] rootPS < 2^1333 := by decide +kernel

def env56302 : List Nat := [2,4,8,0,10,64,67,256,6,320,74,323,267,64,70,267,260,328,2,71,322,77,260,266,2,7,261,325,64,259,262,325,256,258,0,325]

theorem envBound56302 : H12AffineFastState.Bounded env56302 := by
  intro p hp
  have h : env56302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56301_56302 : H12AffineEnvironment.transform 4 10 env56301 = env56302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env56301 == env56302) = true)

theorem identity56302 : scanCanonicalize (H12AffineFastState.compose env56302 (packedSelected [3,4,7] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound56302 : packedSelected [3,4,7] rootPS < 2^1333 := by decide +kernel

def env56303 : List Nat := [2,4,8,0,10,12,15,256,6,268,6,271,267,12,10,267,260,260,2,11,270,1,260,266,2,7,261,265,12,259,262,265,256,258,0,265]

theorem envBound56303 : H12AffineFastState.Bounded env56303 := by
  intro p hp
  have h : env56303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56302_56303 : H12AffineEnvironment.transform 5 12 env56302 = env56303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env56302 == env56303) = true)

theorem identity56303 : scanCanonicalize (H12AffineFastState.compose env56303 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound56303 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56304 : List Nat := [2,4,8,0,10,12,15,4,6,8,6,11,15,12,10,15,0,0,2,11,10,1,0,14,2,7,1,13,12,7,2,13,4,6,0,13]

theorem envBound56304 : H12AffineFastState.Bounded env56304 := by
  intro p hp
  have h : env56304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56303_56304 : H12AffineEnvironment.transform 7 4 env56303 = env56304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env56303 == env56304) = true)

def env56305 : List Nat := [2,4,8,1,32,64,128,256,512,321,2048,837,780,64,576,457,1002,329,516,577,836,648,1002,456,193,239,303,938,64,2443,769,939,256,773,1,324]

theorem envBound56305 : H12AffineFastState.Bounded env56305 := by
  intro p hp
  have h : env56305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56297_56305 : H12AffineEnvironment.transform 3 1 env56297 = env56305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env56297 == env56305) = true)

theorem identity56305 : scanCanonicalize (H12AffineFastState.compose env56305 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 170) := by decide +kernel

theorem selectedBound56305 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env56306 : List Nat := [2,4,8,1,32,64,128,170,512,235,2048,751,678,64,576,99,576,227,516,577,750,648,576,98,193,239,133,512,64,2081,683,513,170,687,1,238]

theorem envBound56306 : H12AffineFastState.Bounded env56306 := by
  intro p hp
  have h : env56306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56305_56306 : H12AffineEnvironment.transform 7 170 env56305 = env56306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 170 env56305 == env56306) = true)

theorem identity56306 : scanCanonicalize (H12AffineFastState.compose env56306 (packedSelected [2,4,9,11,13,16,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 739) := by decide +kernel

theorem selectedBound56306 : packedSelected [2,4,9,11,13,16,17,18] rootPS < 2^1333 := by decide +kernel

def env56307 : List Nat := [2,4,8,1,32,64,128,170,512,235,739,751,678,64,576,99,576,227,516,577,750,648,576,98,193,239,133,512,64,706,683,513,170,687,1,238]

theorem envBound56307 : H12AffineFastState.Bounded env56307 := by
  intro p hp
  have h : env56307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56306_56307 : H12AffineEnvironment.transform 10 739 env56306 = env56307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 739 env56306 == env56307) = true)

theorem identity56307 : scanCanonicalize (H12AffineFastState.compose env56307 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(8+1) ^^^ 175) := by decide +kernel

theorem selectedBound56307 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env56308 : List Nat := [2,4,8,1,32,64,128,170,175,235,76,64,9,64,239,99,239,227,171,238,65,39,239,98,193,239,133,175,64,109,4,174,170,0,1,238]

theorem envBound56308 : H12AffineFastState.Bounded env56308 := by
  intro p hp
  have h : env56308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56307_56308 : H12AffineEnvironment.transform 8 175 env56307 = env56308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 175 env56307 == env56308) = true)

theorem identity56308 : scanCanonicalize (H12AffineFastState.compose env56308 (packedSelected [0,7,11] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound56308 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env56309 : List Nat := [2,4,8,1,32,12,128,170,175,167,0,12,9,12,163,47,163,175,171,162,13,39,163,46,141,163,133,175,12,33,4,174,170,0,1,162]

theorem envBound56309 : H12AffineFastState.Bounded env56309 := by
  intro p hp
  have h : env56309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56308_56309 : H12AffineEnvironment.transform 5 12 env56308 = env56309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env56308 == env56309) = true)

theorem identity56309 : scanCanonicalize (H12AffineFastState.compose env56309 (packedSelected [0,2,3,5,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound56309 : packedSelected [0,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env56310 : List Nat := [2,4,8,1,32,12,41,3,6,14,0,12,9,12,10,47,10,6,2,11,13,39,10,46,36,10,44,6,12,33,4,7,3,0,1,11]

theorem envBound56310 : H12AffineFastState.Bounded env56310 := by
  intro p hp
  have h : env56310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56309_56310 : H12AffineEnvironment.transform 6 41 env56309 = env56310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env56309 == env56310) = true)

theorem identity56310 : scanCanonicalize (H12AffineFastState.compose env56310 (packedSelected [2,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound56310 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env56311 : List Nat := [2,4,8,1,10,12,3,3,6,14,0,12,9,12,10,5,10,6,2,11,13,13,10,4,14,10,6,6,12,11,4,7,3,0,1,11]

theorem envBound56311 : H12AffineFastState.Bounded env56311 := by
  intro p hp
  have h : env56311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56310_56311 : H12AffineEnvironment.transform 4 10 env56310 = env56311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env56310 == env56311) = true)

theorem identity56311 : scanCanonicalize (H12AffineFastState.compose env56311 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound56311 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56312 : List Nat := [2,4,2,1,0,6,3,3,6,4,0,6,3,6,0,5,0,6,2,1,7,7,0,4,4,0,6,6,6,1,4,7,3,0,1,1]

theorem envBound56312 : H12AffineFastState.Bounded env56312 := by
  intro p hp
  have h : env56312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56311_56312 : H12AffineEnvironment.transform 2 2 env56311 = env56312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env56311 == env56312) = true)

def env56313 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,836,797,65,576,65536,66082,65664,517,577,837,648,66083,65536,193,65830,302,66163,65,67650,784,66147,256,788,17,341]

theorem envBound56313 : H12AffineFastState.Bounded env56313 := by
  intro p hp
  have h : env56313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56295_56313 : H12AffineEnvironment.transform 9 337 env56295 = env56313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env56295 == env56313) = true)

theorem identity56313 : scanCanonicalize (H12AffineFastState.compose env56313 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 669) := by decide +kernel

theorem selectedBound56313 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env56314 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,836,797,65,576,669,191,541,517,577,837,648,190,669,193,955,302,238,65,2783,784,254,256,788,17,341]

theorem envBound56314 : H12AffineFastState.Bounded env56314 := by
  intro p hp
  have h : env56314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56313_56314 : H12AffineEnvironment.transform 15 669 env56313 = env56314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 669 env56313 == env56314) = true)

def env56315 : List Nat := [2,4,8,0,32,64,128,256,512,321,2048,836,781,65,576,653,175,525,517,577,837,648,174,653,193,939,302,238,65,2767,768,238,256,772,1,325]

theorem envBound56315 : H12AffineFastState.Bounded env56315 := by
  intro p hp
  have h : env56315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56314_56315 : H12AffineEnvironment.transform 3 0 env56314 = env56315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env56314 == env56315) = true)

theorem identity56315 : scanCanonicalize (H12AffineFastState.compose env56315 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 239) := by decide +kernel

theorem selectedBound56315 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env56316 : List Nat := [2,4,8,0,32,64,128,256,239,321,2048,427,482,65,175,98,175,226,234,174,426,103,174,98,193,324,302,238,65,2080,495,238,256,491,1,325]

theorem envBound56316 : H12AffineFastState.Bounded env56316 := by
  intro p hp
  have h : env56316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56315_56316 : H12AffineEnvironment.transform 8 239 env56315 = env56316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 239 env56315 == env56316) = true)

theorem identity56316 : scanCanonicalize (H12AffineFastState.compose env56316 (packedSelected [2,4,9,11,13,16,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 13) := by decide +kernel

theorem selectedBound56316 : packedSelected [2,4,9,11,13,16,17,18] rootPS < 2^1333 := by decide +kernel

def env56317 : List Nat := [2,4,8,0,32,64,128,256,239,321,13,427,482,65,175,98,175,226,234,174,426,103,174,98,193,324,302,238,65,45,495,238,256,491,1,325]

theorem envBound56317 : H12AffineFastState.Bounded env56317 := by
  intro p hp
  have h : env56317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56316_56317 : H12AffineEnvironment.transform 10 13 env56316 = env56317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 13 env56316 == env56317) = true)

theorem identity56317 : scanCanonicalize (H12AffineFastState.compose env56317 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 234) := by decide +kernel

theorem selectedBound56317 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env56318 : List Nat := [2,4,8,0,32,64,128,234,239,171,13,65,8,65,175,98,175,226,234,174,64,103,174,98,193,174,196,238,65,45,5,238,234,1,1,175]

theorem envBound56318 : H12AffineFastState.Bounded env56318 := by
  intro p hp
  have h : env56318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56317_56318 : H12AffineEnvironment.transform 7 234 env56317 = env56318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 234 env56317 == env56318) = true)

theorem identity56318 : scanCanonicalize (H12AffineFastState.compose env56318 (packedSelected [0,7,11] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound56318 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env56319 : List Nat := [2,4,8,0,32,12,128,166,163,171,13,13,8,13,175,46,175,174,166,174,12,43,174,46,141,174,136,162,13,45,5,162,166,1,1,175]

theorem envBound56319 : H12AffineFastState.Bounded env56319 := by
  intro p hp
  have h : env56319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56318_56319 : H12AffineEnvironment.transform 5 12 env56318 = env56319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env56318 == env56319) = true)

theorem identity56319 : scanCanonicalize (H12AffineFastState.compose env56319 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound56319 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env56320 : List Nat := [2,4,8,0,32,12,34,4,1,9,13,13,8,13,13,46,13,12,4,12,12,43,12,46,47,12,42,0,13,45,5,0,4,1,1,13]

theorem envBound56320 : H12AffineFastState.Bounded env56320 := by
  intro p hp
  have h : env56320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56319_56320 : H12AffineEnvironment.transform 6 34 env56319 = env56320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env56319 == env56320) = true)

theorem identity56320 : scanCanonicalize (H12AffineFastState.compose env56320 (packedSelected [1,2,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound56320 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env56321 : List Nat := [2,4,3,0,32,7,34,4,1,2,6,6,3,6,6,37,6,7,4,7,7,32,7,37,36,7,33,0,6,38,5,0,4,1,1,6]

theorem envBound56321 : H12AffineFastState.Bounded env56321 := by
  intro p hp
  have h : env56321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56320_56321 : H12AffineEnvironment.transform 2 3 env56320 = env56321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env56320 == env56321) = true)

theorem identity56321 : scanCanonicalize (H12AffineFastState.compose env56321 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound56321 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56322 : List Nat := [2,4,3,0,6,7,4,4,1,2,6,6,3,6,6,3,6,7,4,7,7,6,7,3,2,7,7,0,6,0,5,0,4,1,1,6]

theorem envBound56322 : H12AffineFastState.Bounded env56322 := by
  intro p hp
  have h : env56322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56321_56322 : H12AffineEnvironment.transform 4 6 env56321 = env56322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env56321 == env56322) = true)

theorem identity56322 : scanCanonicalize (H12AffineFastState.compose env56322 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound56322 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56323 : List Nat := [2,3,3,0,1,0,3,3,1,2,1,1,3,1,1,3,1,0,3,0,0,1,0,3,2,0,0,0,1,0,2,0,3,1,1,1]

theorem envBound56323 : H12AffineFastState.Bounded env56323 := by
  intro p hp
  have h : env56323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56322_56323 : H12AffineEnvironment.transform 1 3 env56322 = env56323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env56322 == env56323) = true)

def env56324 : List Nat := [2,4,8,1,32,64,128,256,512,320,2048,836,780,65,576,652,174,524,517,577,837,648,175,652,193,938,302,238,65,2766,769,239,256,773,0,324]

theorem envBound56324 : H12AffineFastState.Bounded env56324 := by
  intro p hp
  have h : env56324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56314_56324 : H12AffineEnvironment.transform 3 1 env56314 = env56324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env56314 == env56324) = true)

theorem identity56324 : scanCanonicalize (H12AffineFastState.compose env56324 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 171) := by decide +kernel

theorem selectedBound56324 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env56325 : List Nat := [2,4,8,1,32,64,128,171,512,235,2048,751,679,65,576,652,174,524,517,577,750,648,175,652,193,513,133,238,65,2766,682,239,171,686,0,239]

theorem envBound56325 : H12AffineFastState.Bounded env56325 := by
  intro p hp
  have h : env56325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56324_56325 : H12AffineEnvironment.transform 7 171 env56324 = env56325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 171 env56324 == env56325) = true)

theorem identity56325 : scanCanonicalize (H12AffineFastState.compose env56325 (packedSelected [0,2,3,4,5,7,9,10,11,13,16,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 75) := by decide +kernel

theorem selectedBound56325 : packedSelected [0,2,3,4,5,7,9,10,11,13,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env56326 : List Nat := [2,4,8,1,32,64,128,171,512,235,75,751,679,65,576,652,174,524,517,577,750,648,175,652,193,513,133,238,65,645,682,239,171,686,0,239]

theorem envBound56326 : H12AffineFastState.Bounded env56326 := by
  intro p hp
  have h : env56326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56325_56326 : H12AffineEnvironment.transform 10 75 env56325 = env56326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 75 env56325 == env56326) = true)

theorem identity56326 : scanCanonicalize (H12AffineFastState.compose env56326 (packedSelected [1,2,11,15,17,18] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound56326 : packedSelected [1,2,11,15,17,18] rootPS < 2^1333 := by decide +kernel

def env56327 : List Nat := [2,4,8,1,13,64,128,134,512,198,75,706,650,65,576,652,131,524,517,577,707,648,130,652,193,513,133,195,65,645,647,194,134,643,0,194]

theorem envBound56327 : H12AffineFastState.Bounded env56327 := by
  intro p hp
  have h : env56327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56326_56327 : H12AffineEnvironment.transform 4 13 env56326 = env56327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env56326 == env56327) = true)

theorem identity56327 : scanCanonicalize (H12AffineFastState.compose env56327 (packedSelected [2,3,7,8,9,12] rootPS)) = affineNative (2^(8+1) ^^^ 200) := by decide +kernel

theorem selectedBound56327 : packedSelected [2,3,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env56328 : List Nat := [2,4,8,1,13,64,128,134,200,198,75,10,66,65,136,68,131,196,205,137,11,64,130,68,193,201,133,195,65,77,79,194,134,75,0,194]

theorem envBound56328 : H12AffineFastState.Bounded env56328 := by
  intro p hp
  have h : env56328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56327_56328 : H12AffineEnvironment.transform 8 200 env56327 = env56328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 200 env56327 == env56328) = true)

theorem identity56328 : scanCanonicalize (H12AffineFastState.compose env56328 (packedSelected [3,4,7] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound56328 : packedSelected [3,4,7] rootPS < 2^1333 := by decide +kernel

def env56329 : List Nat := [2,4,8,1,13,64,15,9,71,73,75,10,66,65,7,68,12,75,66,6,11,64,13,68,78,70,10,76,65,77,79,77,9,75,0,77]

theorem envBound56329 : H12AffineFastState.Bounded env56329 := by
  intro p hp
  have h : env56329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56328_56329 : H12AffineEnvironment.transform 6 15 env56328 = env56329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env56328 == env56329) = true)

theorem identity56329 : scanCanonicalize (H12AffineFastState.compose env56329 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound56329 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56330 : List Nat := [2,4,5,1,0,64,2,4,71,68,70,7,66,65,7,68,1,70,66,6,6,64,0,68,67,70,7,65,65,64,66,64,4,70,0,64]

theorem envBound56330 : H12AffineFastState.Bounded env56330 := by
  intro p hp
  have h : env56330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56329_56330 : H12AffineEnvironment.transform 2 5 env56329 = env56330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env56329 == env56330) = true)

theorem identity56330 : scanCanonicalize (H12AffineFastState.compose env56330 (packedSelected [1,2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound56330 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env56331 : List Nat := [2,3,2,1,0,64,2,3,64,67,65,0,66,65,0,67,1,65,66,1,1,64,0,67,67,65,0,65,65,64,66,64,3,65,0,64]

theorem envBound56331 : H12AffineFastState.Bounded env56331 := by
  intro p hp
  have h : env56331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56330_56331 : H12AffineEnvironment.transform 1 3 env56330 = env56331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env56330 == env56331) = true)

theorem identity56331 : scanCanonicalize (H12AffineFastState.compose env56331 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound56331 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56332 : List Nat := [2,3,2,1,0,1,2,3,1,2,0,0,3,0,0,2,1,0,3,1,1,1,0,2,2,0,0,0,0,1,3,1,3,0,0,1]

theorem envBound56332 : H12AffineFastState.Bounded env56332 := by
  intro p hp
  have h : env56332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56331_56332 : H12AffineEnvironment.transform 5 1 env56331 = env56332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env56331 == env56332) = true)

def env56333 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74862,65665,4417,8540,4097,5277,74046,66897,13769,78894,1150,74815,1296,81226,8205,74799,256,8201,1344,5952]

theorem envBound56333 : H12AffineFastState.Bounded env56333 := by
  intro p hp
  have h : env56333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56250_56333 : H12AffineEnvironment.transform 17 65665 env56250 = env56333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env56250 == env56333) = true)

theorem identity56333 : scanCanonicalize (H12AffineFastState.compose env56333 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 73) := by decide +kernel

theorem selectedBound56333 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env56334 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,73,1296,276,65536,66599,65665,4417,277,4097,5277,65911,66897,5504,70759,1150,66678,1296,72963,68,66662,256,64,1344,5952]

theorem envBound56334 : H12AffineFastState.Bounded env56334 := by
  intro p hp
  have h : env56334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56333_56334 : H12AffineEnvironment.transform 12 73 env56333 = env56334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env56333 == env56334) = true)

def env56335 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1556,73,1296,276,65536,66599,65665,1877,277,1557,649,65911,66897,916,66163,1150,66678,1296,68375,68,66662,256,64,1344,340]

theorem envBound56335 : H12AffineFastState.Bounded env56335 := by
  intro p hp
  have h : env56335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56334_56335 : H12AffineEnvironment.transform 11 1556 env56334 = env56335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env56334 == env56335) = true)

def env56336 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,852,73,80,276,65536,65895,65665,533,277,853,649,65911,65553,916,66163,318,65846,80,68375,68,65830,256,64,0,340]

theorem envBound56336 : H12AffineFastState.Bounded env56336 := by
  intro p hp
  have h : env56336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56335_56336 : H12AffineEnvironment.transform 9 320 env56335 = env56336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env56335 == env56336) = true)

theorem identity56336 : scanCanonicalize (H12AffineFastState.compose env56336 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 806) := by decide +kernel

theorem selectedBound56336 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env56337 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,852,73,80,276,806,577,935,533,277,853,649,593,823,916,341,318,528,80,2097,68,512,256,64,0,340]

theorem envBound56337 : H12AffineFastState.Bounded env56337 := by
  intro p hp
  have h : env56337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56336_56337 : H12AffineEnvironment.transform 15 806 env56336 = env56337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 806 env56336 == env56337) = true)

theorem identity56337 : scanCanonicalize (H12AffineFastState.compose env56337 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(8+1) ^^^ 65) := by decide +kernel

theorem selectedBound56337 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env56338 : List Nat := [2,4,8,16,32,64,128,256,65,320,2048,277,73,80,276,359,0,486,84,277,276,200,16,374,469,341,318,81,80,2097,68,65,256,64,0,340]

theorem envBound56338 : H12AffineFastState.Bounded env56338 := by
  intro p hp
  have h : env56338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56337_56338 : H12AffineEnvironment.transform 8 65 env56337 = env56338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env56337 == env56338) = true)

theorem identity56338 : scanCanonicalize (H12AffineFastState.compose env56338 (packedSelected [8,13] rootPS)) = affineNative (2^(10+1) ^^^ 7) := by decide +kernel

theorem selectedBound56338 : packedSelected [8,13] rootPS < 2^1333 := by decide +kernel

def env56339 : List Nat := [2,4,8,16,32,64,128,256,65,320,7,277,73,80,276,359,0,486,84,277,276,200,16,374,469,341,318,81,80,54,68,65,256,64,0,340]

theorem envBound56339 : H12AffineFastState.Bounded env56339 := by
  intro p hp
  have h : env56339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56338_56339 : H12AffineEnvironment.transform 10 7 env56338 = env56339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 7 env56338 == env56339) = true)

theorem identity56339 : scanCanonicalize (H12AffineFastState.compose env56339 (packedSelected [1,3,4,5,8,9,12,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 18) := by decide +kernel

theorem selectedBound56339 : packedSelected [1,3,4,5,8,9,12,15,16] rootPS < 2^1333 := by decide +kernel

def env56340 : List Nat := [2,4,8,16,32,64,128,18,65,82,7,7,73,80,6,117,0,244,84,7,6,200,16,100,199,71,44,81,80,54,68,65,18,64,0,70]

theorem envBound56340 : H12AffineFastState.Bounded env56340 := by
  intro p hp
  have h : env56340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56339_56340 : H12AffineEnvironment.transform 7 18 env56339 = env56340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 18 env56339 == env56340) = true)

theorem identity56340 : scanCanonicalize (H12AffineFastState.compose env56340 (packedSelected [5,10] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound56340 : packedSelected [5,10] rootPS < 2^1333 := by decide +kernel

def env56341 : List Nat := [2,4,8,1,32,64,128,3,65,67,7,7,73,65,6,100,0,229,69,7,6,200,1,100,199,71,44,64,65,39,68,65,3,64,0,70]

theorem envBound56341 : H12AffineFastState.Bounded env56341 := by
  intro p hp
  have h : env56341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56340_56341 : H12AffineEnvironment.transform 3 1 env56340 = env56341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env56340 == env56341) = true)

theorem identity56341 : scanCanonicalize (H12AffineFastState.compose env56341 (packedSelected [3,5,15] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound56341 : packedSelected [3,5,15] rootPS < 2^1333 := by decide +kernel

def env56342 : List Nat := [2,4,8,1,32,12,128,3,13,15,7,7,5,13,6,40,0,169,9,7,6,132,1,40,139,11,44,12,13,39,8,13,3,12,0,10]

theorem envBound56342 : H12AffineFastState.Bounded env56342 := by
  intro p hp
  have h : env56342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56341_56342 : H12AffineEnvironment.transform 5 12 env56341 = env56342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env56341 == env56342) = true)

theorem identity56342 : scanCanonicalize (H12AffineFastState.compose env56342 (packedSelected [1,2,3,8] rootPS)) = affineNative (2^(6+1) ^^^ 37) := by decide +kernel

theorem selectedBound56342 : packedSelected [1,2,3,8] rootPS < 2^1333 := by decide +kernel

def env56343 : List Nat := [2,4,8,1,32,12,37,3,13,15,7,7,5,13,6,40,0,12,9,7,6,33,1,40,46,11,44,12,13,39,8,13,3,12,0,10]

theorem envBound56343 : H12AffineFastState.Bounded env56343 := by
  intro p hp
  have h : env56343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56342_56343 : H12AffineEnvironment.transform 6 37 env56342 = env56343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 37 env56342 == env56343) = true)

theorem identity56343 : scanCanonicalize (H12AffineFastState.compose env56343 (packedSelected [0,1,4] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound56343 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env56344 : List Nat := [2,4,8,1,6,12,3,3,13,15,7,7,5,13,6,14,0,12,9,7,6,7,1,14,8,11,10,12,13,1,8,13,3,12,0,10]

theorem envBound56344 : H12AffineFastState.Bounded env56344 := by
  intro p hp
  have h : env56344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56343_56344 : H12AffineEnvironment.transform 4 6 env56343 = env56344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env56343 == env56344) = true)

theorem identity56344 : scanCanonicalize (H12AffineFastState.compose env56344 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound56344 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56345 : List Nat := [2,2,8,1,0,10,3,3,11,9,1,1,3,11,0,8,0,10,9,1,0,1,1,8,8,11,10,10,11,1,8,11,3,10,0,10]

theorem envBound56345 : H12AffineFastState.Bounded env56345 := by
  intro p hp
  have h : env56345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56344_56345 : H12AffineEnvironment.transform 1 2 env56344 = env56345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env56344 == env56345) = true)

theorem identity56345 : scanCanonicalize (H12AffineFastState.compose env56345 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound56345 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56346 : List Nat := [2,2,0,1,0,2,3,3,3,1,1,1,3,3,0,0,0,2,1,1,0,1,1,0,0,3,2,2,3,1,0,3,3,2,0,2]

theorem envBound56346 : H12AffineFastState.Bounded env56346 := by
  intro p hp
  have h : env56346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56345_56346 : H12AffineEnvironment.transform 2 0 env56345 = env56346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env56345 == env56346) = true)

theorem identity56346 : scanCanonicalize (H12AffineFastState.compose env56346 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound56346 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56347 : List Nat := [0,0,0,1,0,0,1,1,1,1,1,1,1,1,0,0,0,0,1,1,0,1,1,0,0,1,0,0,1,1,0,1,1,0,0,0]

theorem envBound56347 : H12AffineFastState.Bounded env56347 := by
  intro p hp
  have h : env56347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56346_56347 : H12AffineEnvironment.transform 0 0 env56346 = env56347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env56346 == env56347) = true)

def env56348 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,853,73,81,276,65536,65894,65665,532,277,852,649,65911,65552,916,66163,319,65847,81,68375,68,65831,256,64,1,340]

theorem envBound56348 : H12AffineFastState.Bounded env56348 := by
  intro p hp
  have h : env56348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56335_56348 : H12AffineEnvironment.transform 9 321 env56335 = env56348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env56335 == env56348) = true)

theorem identity56348 : scanCanonicalize (H12AffineFastState.compose env56348 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound56348 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env56349 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,853,73,81,276,114,276,243,532,277,852,649,261,98,916,513,319,325,81,2917,68,341,256,64,1,340]

theorem envBound56349 : H12AffineFastState.Bounded env56349 := by
  intro p hp
  have h : env56349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56348_56349 : H12AffineEnvironment.transform 15 114 env56348 = env56349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env56348 == env56349) = true)

theorem identity56349 : scanCanonicalize (H12AffineFastState.compose env56349 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound56349 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env56350 : List Nat := [2,4,8,16,32,64,128,256,260,321,2048,81,73,81,276,114,276,243,272,277,80,397,261,98,144,261,319,325,81,2145,68,341,256,64,1,340]

theorem envBound56350 : H12AffineFastState.Bounded env56350 := by
  intro p hp
  have h : env56350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56349_56350 : H12AffineEnvironment.transform 8 260 env56349 = env56350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env56349 == env56350) = true)

theorem identity56350 : scanCanonicalize (H12AffineFastState.compose env56350 (packedSelected [0,3,5,7,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 341) := by decide +kernel

theorem selectedBound56350 : packedSelected [0,3,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env56351 : List Nat := [2,4,8,16,32,64,128,256,260,321,341,81,73,81,276,114,276,243,272,277,80,397,261,98,144,261,319,325,81,308,68,341,256,64,1,340]

theorem envBound56351 : H12AffineFastState.Bounded env56351 := by
  intro p hp
  have h : env56351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56350_56351 : H12AffineEnvironment.transform 10 341 env56350 = env56351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 341 env56350 == env56351) = true)

theorem identity56351 : scanCanonicalize (H12AffineFastState.compose env56351 (packedSelected [2,3] rootPS)) = affineNative (2^(7+1) ^^^ 120) := by decide +kernel

theorem selectedBound56351 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env56352 : List Nat := [2,4,8,16,32,64,128,120,124,57,45,81,73,81,108,114,108,243,104,109,80,245,125,98,144,125,71,61,81,76,68,45,120,64,1,44]

theorem envBound56352 : H12AffineFastState.Bounded env56352 := by
  intro p hp
  have h : env56352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56351_56352 : H12AffineEnvironment.transform 7 120 env56351 = env56352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 120 env56351 == env56352) = true)

theorem identity56352 : scanCanonicalize (H12AffineFastState.compose env56352 (packedSelected [4,8,9,15,16,17] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound56352 : packedSelected [4,8,9,15,16,17] rootPS < 2^1333 := by decide +kernel

def env56353 : List Nat := [2,4,8,16,32,64,40,120,124,57,45,81,73,81,108,114,108,91,104,109,80,93,125,98,56,125,71,61,81,76,68,45,120,64,1,44]

theorem envBound56353 : H12AffineFastState.Bounded env56353 := by
  intro p hp
  have h : env56353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56352_56353 : H12AffineEnvironment.transform 6 40 env56352 = env56353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env56352 == env56353) = true)

theorem identity56353 : scanCanonicalize (H12AffineFastState.compose env56353 (packedSelected [8,13] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound56353 : packedSelected [8,13] rootPS < 2^1333 := by decide +kernel

def env56354 : List Nat := [2,4,2,16,32,64,34,114,118,51,39,81,67,81,102,114,102,81,98,103,80,87,119,98,50,119,71,55,81,70,68,39,114,64,1,38]

theorem envBound56354 : H12AffineFastState.Bounded env56354 := by
  intro p hp
  have h : env56354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56353_56354 : H12AffineEnvironment.transform 2 2 env56353 = env56354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env56353 == env56354) = true)

theorem identity56354 : scanCanonicalize (H12AffineFastState.compose env56354 (packedSelected [2,4,5,9] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound56354 : packedSelected [2,4,5,9] rootPS < 2^1333 := by decide +kernel

def env56355 : List Nat := [2,4,2,16,32,48,34,2,6,51,39,33,51,33,22,2,22,33,18,23,32,39,7,18,50,7,55,55,33,54,52,39,2,48,1,38]

theorem envBound56355 : H12AffineFastState.Bounded env56355 := by
  intro p hp
  have h : env56355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56354_56355 : H12AffineEnvironment.transform 5 48 env56354 = env56355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env56354 == env56355) = true)

theorem identity56355 : scanCanonicalize (H12AffineFastState.compose env56355 (packedSelected [1,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound56355 : packedSelected [1,4,7] rootPS < 2^1333 := by decide +kernel

def env56356 : List Nat := [2,4,2,16,7,23,5,2,6,20,0,6,20,6,22,2,22,6,18,23,7,0,7,18,21,7,16,16,6,17,19,0,2,23,1,1]

theorem envBound56356 : H12AffineFastState.Bounded env56356 := by
  intro p hp
  have h : env56356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56355_56356 : H12AffineEnvironment.transform 4 7 env56355 = env56356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env56355 == env56356) = true)

theorem identity56356 : scanCanonicalize (H12AffineFastState.compose env56356 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound56356 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56357 : List Nat := [2,2,2,16,1,17,3,2,0,18,0,0,18,0,16,2,16,0,18,17,1,0,1,18,19,1,16,16,0,17,19,0,2,17,1,1]

theorem envBound56357 : H12AffineFastState.Bounded env56357 := by
  intro p hp
  have h : env56357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56356_56357 : H12AffineEnvironment.transform 1 2 env56356 = env56357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env56356 == env56357) = true)

theorem identity56357 : scanCanonicalize (H12AffineFastState.compose env56357 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound56357 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56358 : List Nat := [2,2,2,3,1,2,3,2,0,1,0,0,1,0,3,2,3,0,1,2,1,0,1,1,0,1,3,3,0,2,0,0,2,2,1,1]

theorem envBound56358 : H12AffineFastState.Bounded env56358 := by
  intro p hp
  have h : env56358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56357_56358 : H12AffineEnvironment.transform 3 3 env56357 = env56358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env56357 == env56358) = true)

theorem identity56358 : scanCanonicalize (H12AffineFastState.compose env56358 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound56358 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env56359 : List Nat := [0,0,0,1,1,0,1,0,0,1,0,0,1,0,1,0,1,0,1,0,1,0,1,1,0,1,1,1,0,0,0,0,0,0,1,1]

theorem envBound56359 : H12AffineFastState.Bounded env56359 := by
  intro p hp
  have h : env56359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56358_56359 : H12AffineEnvironment.transform 0 0 env56358 = env56359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env56358 == env56359) = true)

def env56360 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1557,73,1296,276,65536,66599,65665,1876,277,1556,648,65911,66897,917,66162,1150,66678,1296,68374,68,66662,256,64,1344,341]

theorem envBound56360 : H12AffineFastState.Bounded env56360 := by
  intro p hp
  have h : env56360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56334_56360 : H12AffineEnvironment.transform 11 1557 env56334 = env56360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env56334 == env56360) = true)

def env56361 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,853,73,80,276,65536,65895,65665,532,277,852,648,65911,65553,917,66162,318,65846,80,68374,68,65830,256,64,0,341]

theorem envBound56361 : H12AffineFastState.Bounded env56361 := by
  intro p hp
  have h : env56361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56360_56361 : H12AffineEnvironment.transform 9 320 env56360 = env56361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env56360 == env56361) = true)

theorem identity56361 : scanCanonicalize (H12AffineFastState.compose env56361 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 807) := by decide +kernel

theorem selectedBound56361 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env56362 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,853,73,80,276,807,576,934,532,277,852,648,592,822,917,341,318,529,80,2097,68,513,256,64,0,341]

theorem envBound56362 : H12AffineFastState.Bounded env56362 := by
  intro p hp
  have h : env56362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56361_56362 : H12AffineEnvironment.transform 15 807 env56361 = env56362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 807 env56361 == env56362) = true)

theorem identity56362 : scanCanonicalize (H12AffineFastState.compose env56362 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound56362 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env56363 : List Nat := [2,4,8,16,32,64,128,256,64,320,2048,277,73,80,276,359,0,486,84,277,276,200,16,374,469,341,318,81,80,2097,68,65,256,64,0,341]

theorem envBound56363 : H12AffineFastState.Bounded env56363 := by
  intro p hp
  have h : env56363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56362_56363 : H12AffineEnvironment.transform 8 64 env56362 = env56363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env56362 == env56363) = true)

theorem identity56363 : scanCanonicalize (H12AffineFastState.compose env56363 (packedSelected [8,13] rootPS)) = affineNative (2^(10+1) ^^^ 7) := by decide +kernel

theorem selectedBound56363 : packedSelected [8,13] rootPS < 2^1333 := by decide +kernel

def env56364 : List Nat := [2,4,8,16,32,64,128,256,64,320,7,277,73,80,276,359,0,486,84,277,276,200,16,374,469,341,318,81,80,54,68,65,256,64,0,341]

theorem envBound56364 : H12AffineFastState.Bounded env56364 := by
  intro p hp
  have h : env56364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56363_56364 : H12AffineEnvironment.transform 10 7 env56363 = env56364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 7 env56363 == env56364) = true)

theorem identity56364 : scanCanonicalize (H12AffineFastState.compose env56364 (packedSelected [1,3,4,5,8,9,12,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 18) := by decide +kernel

theorem selectedBound56364 : packedSelected [1,3,4,5,8,9,12,15,16] rootPS < 2^1333 := by decide +kernel

def env56365 : List Nat := [2,4,8,16,32,64,128,18,64,82,7,7,73,80,6,117,0,244,84,7,6,200,16,100,199,71,44,81,80,54,68,65,18,64,0,71]

theorem envBound56365 : H12AffineFastState.Bounded env56365 := by
  intro p hp
  have h : env56365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56364_56365 : H12AffineEnvironment.transform 7 18 env56364 = env56365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 18 env56364 == env56365) = true)

theorem identity56365 : scanCanonicalize (H12AffineFastState.compose env56365 (packedSelected [5,10] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound56365 : packedSelected [5,10] rootPS < 2^1333 := by decide +kernel

def env56366 : List Nat := [2,4,8,7,32,64,128,5,64,69,7,7,73,71,6,98,0,227,67,7,6,200,7,100,199,71,44,70,71,33,68,65,5,64,0,71]

theorem envBound56366 : H12AffineFastState.Bounded env56366 := by
  intro p hp
  have h : env56366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56365_56366 : H12AffineEnvironment.transform 3 7 env56365 = env56366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env56365 == env56366) = true)

theorem identity56366 : scanCanonicalize (H12AffineFastState.compose env56366 (packedSelected [3,5,15] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound56366 : packedSelected [3,5,15] rootPS < 2^1333 := by decide +kernel

def env56367 : List Nat := [2,4,8,7,32,12,128,5,12,9,7,7,5,11,6,46,0,175,15,7,6,132,7,40,139,11,44,10,11,33,8,13,5,12,0,11]

theorem envBound56367 : H12AffineFastState.Bounded env56367 := by
  intro p hp
  have h : env56367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56366_56367 : H12AffineEnvironment.transform 5 12 env56366 = env56367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env56366 == env56367) = true)

theorem identity56367 : scanCanonicalize (H12AffineFastState.compose env56367 (packedSelected [1,2,3,8] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound56367 : packedSelected [1,2,3,8] rootPS < 2^1333 := by decide +kernel

def env56368 : List Nat := [2,4,8,7,32,12,34,5,12,9,7,7,5,11,6,46,0,13,15,7,6,38,7,40,41,11,44,10,11,33,8,13,5,12,0,11]

theorem envBound56368 : H12AffineFastState.Bounded env56368 := by
  intro p hp
  have h : env56368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56367_56368 : H12AffineEnvironment.transform 6 34 env56367 = env56368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env56367 == env56368) = true)

theorem identity56368 : scanCanonicalize (H12AffineFastState.compose env56368 (packedSelected [2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound56368 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env56369 : List Nat := [2,4,8,7,6,12,4,5,12,9,7,7,5,11,6,8,0,13,15,7,6,0,7,14,15,11,10,10,11,7,8,13,5,12,0,11]

theorem envBound56369 : H12AffineFastState.Bounded env56369 := by
  intro p hp
  have h : env56369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56368_56369 : H12AffineEnvironment.transform 4 6 env56368 = env56369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env56368 == env56369) = true)

theorem identity56369 : scanCanonicalize (H12AffineFastState.compose env56369 (packedSelected [2,3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound56369 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env56370 : List Nat := [2,2,8,1,0,10,2,3,10,9,1,1,3,11,0,8,0,11,9,1,0,0,1,8,9,11,10,10,11,1,8,11,3,10,0,11]

theorem envBound56370 : H12AffineFastState.Bounded env56370 := by
  intro p hp
  have h : env56370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56369_56370 : H12AffineEnvironment.transform 1 2 env56369 = env56370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env56369 == env56370) = true)

theorem identity56370 : scanCanonicalize (H12AffineFastState.compose env56370 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound56370 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56371 : List Nat := [0,0,8,1,0,8,0,1,8,9,1,1,1,9,0,8,0,9,9,1,0,0,1,8,9,9,8,8,9,1,8,9,1,8,0,9]

theorem envBound56371 : H12AffineFastState.Bounded env56371 := by
  intro p hp
  have h : env56371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56370_56371 : H12AffineEnvironment.transform 0 0 env56370 = env56371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env56370 == env56371) = true)

def env56372 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,852,73,81,276,65536,65894,65665,533,277,853,648,65911,65552,917,66162,319,65847,81,68374,68,65831,256,64,1,341]

theorem envBound56372 : H12AffineFastState.Bounded env56372 := by
  intro p hp
  have h : env56372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56360_56372 : H12AffineEnvironment.transform 9 321 env56360 = env56372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env56360 == env56372) = true)

theorem identity56372 : scanCanonicalize (H12AffineFastState.compose env56372 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound56372 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env56373 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,852,73,81,276,114,276,243,533,277,853,648,261,98,917,512,319,325,81,2916,68,341,256,64,1,341]

theorem envBound56373 : H12AffineFastState.Bounded env56373 := by
  intro p hp
  have h : env56373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56372_56373 : H12AffineEnvironment.transform 15 114 env56372 = env56373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env56372 == env56373) = true)

theorem identity56373 : scanCanonicalize (H12AffineFastState.compose env56373 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound56373 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env56374 : List Nat := [2,4,8,16,32,64,128,256,261,321,2048,81,73,81,276,114,276,243,272,277,80,397,261,98,144,261,319,325,81,2145,68,341,256,64,1,341]

theorem envBound56374 : H12AffineFastState.Bounded env56374 := by
  intro p hp
  have h : env56374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56373_56374 : H12AffineEnvironment.transform 8 261 env56373 = env56374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env56373 == env56374) = true)

theorem identity56374 : scanCanonicalize (H12AffineFastState.compose env56374 (packedSelected [0,3,5,7,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound56374 : packedSelected [0,3,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env56375 : List Nat := [2,4,8,16,32,64,128,256,261,321,260,81,73,81,276,114,276,243,272,277,80,397,261,98,144,261,319,325,81,357,68,341,256,64,1,341]

theorem envBound56375 : H12AffineFastState.Bounded env56375 := by
  intro p hp
  have h : env56375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56374_56375 : H12AffineEnvironment.transform 10 260 env56374 = env56375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env56374 == env56375) = true)

theorem identity56375 : scanCanonicalize (H12AffineFastState.compose env56375 (packedSelected [2,3,4,9,16] rootPS)) = affineNative (2^(4+1) ^^^ 29) := by decide +kernel

theorem selectedBound56375 : packedSelected [2,3,4,9,16] rootPS < 2^1333 := by decide +kernel

def env56376 : List Nat := [2,4,8,16,29,64,128,256,261,321,260,81,73,81,276,79,276,206,272,277,80,397,261,95,144,261,258,325,81,344,68,341,256,64,1,341]

theorem envBound56376 : H12AffineFastState.Bounded env56376 := by
  intro p hp
  have h : env56376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56375_56376 : H12AffineEnvironment.transform 4 29 env56375 = env56376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env56375 == env56376) = true)

theorem identity56376 : scanCanonicalize (H12AffineFastState.compose env56376 (packedSelected [2,3,8,15,17] rootPS)) = affineNative (2^(6+1) ^^^ 20) := by decide +kernel

theorem selectedBound56376 : packedSelected [2,3,8,15,17] rootPS < 2^1333 := by decide +kernel

def env56377 : List Nat := [2,4,8,16,29,64,20,256,261,321,260,81,73,81,276,79,276,90,272,277,80,281,261,95,4,261,258,325,81,344,68,341,256,64,1,341]

theorem envBound56377 : H12AffineFastState.Bounded env56377 := by
  intro p hp
  have h : env56377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56376_56377 : H12AffineEnvironment.transform 6 20 env56376 = env56377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 20 env56376 == env56377) = true)

theorem identity56377 : scanCanonicalize (H12AffineFastState.compose env56377 (packedSelected [2,3,8,13] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound56377 : packedSelected [2,3,8,13] rootPS < 2^1333 := by decide +kernel

def env56378 : List Nat := [2,4,3,16,22,64,20,256,261,321,260,81,66,81,276,68,276,81,272,277,80,274,261,84,4,261,258,325,81,339,68,341,256,64,1,341]

theorem envBound56378 : H12AffineFastState.Bounded env56378 := by
  intro p hp
  have h : env56378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56377_56378 : H12AffineEnvironment.transform 2 3 env56377 = env56378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env56377 == env56378) = true)

theorem identity56378 : scanCanonicalize (H12AffineFastState.compose env56378 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 83) := by decide +kernel

theorem selectedBound56378 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env56379 : List Nat := [2,4,3,16,22,64,20,83,86,18,87,81,66,81,71,68,71,81,67,70,80,65,86,84,4,86,81,22,81,0,68,6,83,64,1,6]

theorem envBound56379 : H12AffineFastState.Bounded env56379 := by
  intro p hp
  have h : env56379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56378_56379 : H12AffineEnvironment.transform 7 83 env56378 = env56379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 83 env56378 == env56379) = true)

theorem identity56379 : scanCanonicalize (H12AffineFastState.compose env56379 (packedSelected [0,2,3,7] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound56379 : packedSelected [0,2,3,7] rootPS < 2^1333 := by decide +kernel

def env56380 : List Nat := [2,2,3,16,16,64,18,83,80,18,81,81,66,81,65,66,65,81,67,64,80,65,80,82,2,80,81,16,81,0,66,0,83,64,1,0]

theorem envBound56380 : H12AffineFastState.Bounded env56380 := by
  intro p hp
  have h : env56380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56379_56380 : H12AffineEnvironment.transform 1 2 env56379 = env56380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env56379 == env56380) = true)

theorem identity56380 : scanCanonicalize (H12AffineFastState.compose env56380 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound56380 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env56381 : List Nat := [2,2,3,0,0,64,2,67,64,2,65,65,66,65,65,66,65,65,67,64,64,65,64,66,2,64,65,0,65,0,66,0,67,64,1,0]

theorem envBound56381 : H12AffineFastState.Bounded env56381 := by
  intro p hp
  have h : env56381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56380_56381 : H12AffineEnvironment.transform 3 0 env56380 = env56381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env56380 == env56381) = true)

theorem identity56381 : scanCanonicalize (H12AffineFastState.compose env56381 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound56381 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56382 : List Nat := [2,2,3,0,0,0,2,3,0,2,1,1,2,1,1,2,1,1,3,0,0,1,0,2,2,0,1,0,1,0,2,0,3,0,1,0]

theorem envBound56382 : H12AffineFastState.Bounded env56382 := by
  intro p hp
  have h : env56382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56381_56382 : H12AffineEnvironment.transform 5 0 env56381 = env56382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env56381 == env56382) = true)

def env56383 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74862,262144,4416,8541,4097,5277,74047,66897,13768,78894,328959,74814,1296,81227,8204,74799,256,8200,1344,5953]

theorem envBound56383 : H12AffineFastState.Bounded env56383 := by
  intro p hp
  have h : env56383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56249_56383 : H12AffineEnvironment.transform 13 1297 env56249 = env56383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env56249 == env56383) = true)

def env56384 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74862,65664,4416,8541,4097,5277,74047,66897,13768,78894,1151,74814,1296,81227,8204,74799,256,8200,1344,5953]

theorem envBound56384 : H12AffineFastState.Bounded env56384 := by
  intro p hp
  have h : env56384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56383_56384 : H12AffineEnvironment.transform 17 65664 env56383 = env56384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env56383 == env56384) = true)

theorem identity56384 : scanCanonicalize (H12AffineFastState.compose env56384 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound56384 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env56385 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,80,8540,65536,74031,65664,4416,8541,4097,4572,74047,65552,12425,78191,318,74111,81,79882,8204,74094,256,8200,1,4608]

theorem envBound56385 : H12AffineFastState.Bounded env56385 := by
  intro p hp
  have h : env56385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56384_56385 : H12AffineEnvironment.transform 9 321 env56384 = env56385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env56384 == env56385) = true)

def env56386 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,852,8192,80,8540,65536,74031,65664,532,8541,853,648,74047,65552,9181,74299,318,74111,81,76638,8204,74094,256,8200,1,340]

theorem envBound56386 : H12AffineFastState.Bounded env56386 := by
  intro p hp
  have h : env56386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56385_56386 : H12AffineEnvironment.transform 11 852 env56385 = env56386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 852 env56385 == env56386) = true)

def env56387 : List Nat := [2,4,8,0,32,64,128,256,512,321,2048,836,8192,64,8524,65536,74031,65664,516,8525,837,648,74031,65536,9165,74283,302,74095,65,76622,8204,74094,256,8200,1,324]

theorem envBound56387 : H12AffineFastState.Bounded env56387 := by
  intro p hp
  have h : env56387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56386_56387 : H12AffineEnvironment.transform 3 0 env56386 = env56387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env56386 == env56387) = true)

theorem identity56387 : scanCanonicalize (H12AffineFastState.compose env56387 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 298) := by decide +kernel

theorem selectedBound56387 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env56388 : List Nat := [2,4,8,0,32,64,128,256,512,321,2048,836,298,64,102,65536,65541,65664,516,103,837,648,65541,65536,743,66305,302,65605,65,68196,294,65604,256,290,1,324]

theorem envBound56388 : H12AffineFastState.Bounded env56388 := by
  intro p hp
  have h : env56388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56387_56388 : H12AffineEnvironment.transform 12 298 env56387 = env56388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 298 env56387 == env56388) = true)

def env56389 : List Nat := [2,4,8,0,32,64,128,104,512,41,2048,556,66,64,102,65536,65541,65664,516,103,557,648,65541,65536,743,66153,70,65605,65,68196,78,65604,104,74,1,44]

theorem envBound56389 : H12AffineFastState.Bounded env56389 := by
  intro p hp
  have h : env56389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56388_56389 : H12AffineEnvironment.transform 7 104 env56388 = env56389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 104 env56388 == env56389) = true)

theorem identity56389 : scanCanonicalize (H12AffineFastState.compose env56389 (packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS)) = affineNative (2^(15+1) ^^^ 717) := by decide +kernel

theorem selectedBound56389 : packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS < 2^1333 := by decide +kernel

def env56390 : List Nat := [2,4,8,0,32,64,128,104,512,41,2048,556,66,64,102,717,712,589,516,103,557,648,712,717,743,164,70,648,65,2217,78,649,104,74,1,44]

theorem envBound56390 : H12AffineFastState.Bounded env56390 := by
  intro p hp
  have h : env56390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56389_56390 : H12AffineEnvironment.transform 15 717 env56389 = env56390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 717 env56389 == env56390) = true)

theorem identity56390 : scanCanonicalize (H12AffineFastState.compose env56390 (packedSelected [0,1,2,4,5,7,9,10,11,12,17,19] rootPS)) = affineNative (2^(8+1) ^^^ 74) := by decide +kernel

theorem selectedBound56390 : packedSelected [0,1,2,4,5,7,9,10,11,12,17,19] rootPS < 2^1333 := by decide +kernel

def env56391 : List Nat := [2,4,8,0,32,64,128,104,74,41,2048,102,66,64,102,135,130,7,78,103,103,194,130,135,173,164,70,194,65,2217,78,195,104,74,1,44]

theorem envBound56391 : H12AffineFastState.Bounded env56391 := by
  intro p hp
  have h : env56391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56390_56391 : H12AffineEnvironment.transform 8 74 env56390 = env56391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 74 env56390 == env56391) = true)

theorem identity56391 : scanCanonicalize (H12AffineFastState.compose env56391 (packedSelected [1,2,3,7,8,9,13,15,18] rootPS)) = affineNative (2^(10+1) ^^^ 7) := by decide +kernel

theorem selectedBound56391 : packedSelected [1,2,3,7,8,9,13,15,18] rootPS < 2^1333 := by decide +kernel

def env56392 : List Nat := [2,4,8,0,32,64,128,104,74,41,7,102,66,64,102,135,130,7,78,103,103,194,130,135,173,164,70,194,65,174,78,195,104,74,1,44]

theorem envBound56392 : H12AffineFastState.Bounded env56392 := by
  intro p hp
  have h : env56392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56391_56392 : H12AffineEnvironment.transform 10 7 env56391 = env56392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 7 env56391 == env56392) = true)

theorem identity56392 : scanCanonicalize (H12AffineFastState.compose env56392 (packedSelected [0,1,2,3,4,5,10,12] rootPS)) = affineNative (2^(6+1) ^^^ 73) := by decide +kernel

theorem selectedBound56392 : packedSelected [0,1,2,3,4,5,10,12] rootPS < 2^1333 := by decide +kernel

def env56393 : List Nat := [2,4,8,0,32,64,73,104,74,41,7,102,66,64,102,78,75,7,78,103,103,11,75,78,100,109,70,11,65,103,78,10,104,74,1,44]

theorem envBound56393 : H12AffineFastState.Bounded env56393 := by
  intro p hp
  have h : env56393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56392_56393 : H12AffineEnvironment.transform 6 73 env56392 = env56393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 73 env56392 == env56393) = true)

theorem identity56393 : scanCanonicalize (H12AffineFastState.compose env56393 (packedSelected [1,2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound56393 : packedSelected [1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env56394 : List Nat := [2,4,8,0,10,64,73,66,74,3,7,76,66,64,76,78,75,7,78,77,77,11,75,78,78,71,70,11,65,77,78,10,66,74,1,6]

theorem envBound56394 : H12AffineFastState.Bounded env56394 := by
  intro p hp
  have h : env56394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56393_56394 : H12AffineEnvironment.transform 4 10 env56393 = env56394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env56393 == env56394) = true)

theorem identity56394 : scanCanonicalize (H12AffineFastState.compose env56394 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound56394 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56395 : List Nat := [2,4,4,0,6,64,69,66,70,3,7,64,66,64,64,66,71,7,66,65,65,7,71,66,66,71,70,7,65,65,66,6,66,70,1,6]

theorem envBound56395 : H12AffineFastState.Bounded env56395 := by
  intro p hp
  have h : env56395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56394_56395 : H12AffineEnvironment.transform 2 4 env56394 = env56395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env56394 == env56395) = true)

def env56396 : List Nat := [2,4,8,0,32,64,128,105,512,40,2048,557,67,64,102,65536,65541,65664,516,103,556,648,65541,65536,743,66152,71,65605,65,68196,79,65604,105,75,1,45]

theorem envBound56396 : H12AffineFastState.Bounded env56396 := by
  intro p hp
  have h : env56396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56388_56396 : H12AffineEnvironment.transform 7 105 env56388 = env56396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 105 env56388 == env56396) = true)

theorem identity56396 : scanCanonicalize (H12AffineFastState.compose env56396 (packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS)) = affineNative (2^(15+1) ^^^ 711) := by decide +kernel

theorem selectedBound56396 : packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS < 2^1333 := by decide +kernel

def env56397 : List Nat := [2,4,8,0,32,64,128,105,512,40,2048,557,67,64,102,711,706,583,516,103,556,648,706,711,743,175,71,642,65,2211,79,643,105,75,1,45]

theorem envBound56397 : H12AffineFastState.Bounded env56397 := by
  intro p hp
  have h : env56397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56396_56397 : H12AffineEnvironment.transform 15 711 env56396 = env56397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 711 env56396 == env56397) = true)

theorem identity56397 : scanCanonicalize (H12AffineFastState.compose env56397 (packedSelected [0,2,10,11,15,18,19,27] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound56397 : packedSelected [0,2,10,11,15,18,19,27] rootPS < 2^1333 := by decide +kernel

def env56398 : List Nat := [2,4,8,0,32,64,128,105,7,40,2048,42,67,64,102,192,197,64,3,103,43,143,197,192,224,175,71,133,65,2211,79,132,105,75,1,45]

theorem envBound56398 : H12AffineFastState.Bounded env56398 := by
  intro p hp
  have h : env56398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56397_56398 : H12AffineEnvironment.transform 8 7 env56397 = env56398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env56397 == env56398) = true)

theorem identity56398 : scanCanonicalize (H12AffineFastState.compose env56398 (packedSelected [0,3,7,8,11,12,13,16,18] rootPS)) = affineNative (2^(6+1) ^^^ 67) := by decide +kernel

theorem selectedBound56398 : packedSelected [0,3,7,8,11,12,13,16,18] rootPS < 2^1333 := by decide +kernel

def env56399 : List Nat := [2,4,8,0,32,64,67,105,7,40,2048,42,67,64,102,3,6,64,3,103,43,76,6,3,35,108,71,70,65,2144,79,71,105,75,1,45]

theorem envBound56399 : H12AffineFastState.Bounded env56399 := by
  intro p hp
  have h : env56399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56398_56399 : H12AffineEnvironment.transform 6 67 env56398 = env56399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 67 env56398 == env56399) = true)

theorem identity56399 : scanCanonicalize (H12AffineFastState.compose env56399 (packedSelected [2,8] rootPS)) = affineNative (2^(10+1) ^^^ 6) := by decide +kernel

theorem selectedBound56399 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env56400 : List Nat := [2,4,8,0,32,64,67,105,7,40,6,42,67,64,102,3,6,64,3,103,43,76,6,3,35,108,71,70,65,102,79,71,105,75,1,45]

theorem envBound56400 : H12AffineFastState.Bounded env56400 := by
  intro p hp
  have h : env56400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56399_56400 : H12AffineEnvironment.transform 10 6 env56399 = env56400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 6 env56399 == env56400) = true)

theorem identity56400 : scanCanonicalize (H12AffineFastState.compose env56400 (packedSelected [1,2,4,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound56400 : packedSelected [1,2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env56401 : List Nat := [2,4,8,0,11,64,67,66,7,3,6,1,67,64,77,3,6,64,3,76,0,76,6,3,8,71,71,70,65,77,79,71,66,75,1,6]

theorem envBound56401 : H12AffineFastState.Bounded env56401 := by
  intro p hp
  have h : env56401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56400_56401 : H12AffineEnvironment.transform 4 11 env56400 = env56401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env56400 == env56401) = true)

theorem identity56401 : scanCanonicalize (H12AffineFastState.compose env56401 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound56401 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56402 : List Nat := [2,4,1,0,2,64,67,66,7,3,6,1,67,64,68,3,6,64,3,69,0,69,6,3,1,71,71,70,65,68,70,71,66,66,1,6]

theorem envBound56402 : H12AffineFastState.Bounded env56402 := by
  intro p hp
  have h : env56402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56401_56402 : H12AffineEnvironment.transform 2 1 env56401 = env56402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env56401 == env56402) = true)

def env56403 : List Nat := [2,4,8,1,32,64,128,256,512,321,2048,837,8192,65,8525,65536,74031,65664,517,8524,836,648,74030,65537,9164,74282,303,74094,64,76623,8204,74094,256,8200,1,325]

theorem envBound56403 : H12AffineFastState.Bounded env56403 := by
  intro p hp
  have h : env56403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56386_56403 : H12AffineEnvironment.transform 3 1 env56386 = env56403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env56386 == env56403) = true)

theorem identity56403 : scanCanonicalize (H12AffineFastState.compose env56403 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 99) := by decide +kernel

theorem selectedBound56403 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env56404 : List Nat := [2,4,8,1,32,64,128,99,512,34,2048,550,8192,65,8238,65536,73804,65664,517,8239,551,648,73805,65537,8879,74282,76,73741,64,76332,8204,73741,99,8200,1,38]

theorem envBound56404 : H12AffineFastState.Bounded env56404 := by
  intro p hp
  have h : env56404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56403_56404 : H12AffineEnvironment.transform 7 99 env56403 = env56404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 99 env56403 == env56404) = true)

def env56405 : List Nat := [2,4,8,1,32,64,128,99,512,34,2048,550,72,65,102,65536,65540,65664,517,103,551,648,65541,65537,743,66146,76,65605,64,68196,68,65605,99,64,1,38]

theorem envBound56405 : H12AffineFastState.Bounded env56405 := by
  intro p hp
  have h : env56405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56404_56405 : H12AffineEnvironment.transform 12 72 env56404 = env56405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env56404 == env56405) = true)

theorem identity56405 : scanCanonicalize (H12AffineFastState.compose env56405 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 98) := by decide +kernel

theorem selectedBound56405 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env56406 : List Nat := [2,4,8,1,32,64,128,99,512,34,2048,550,72,65,102,98,102,226,517,103,551,648,103,99,743,512,76,39,64,2566,68,39,99,64,1,38]

theorem envBound56406 : H12AffineFastState.Bounded env56406 := by
  intro p hp
  have h : env56406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56405_56406 : H12AffineEnvironment.transform 15 98 env56405 = env56406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 98 env56405 == env56406) = true)

theorem identity56406 : scanCanonicalize (H12AffineFastState.compose env56406 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound56406 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env56407 : List Nat := [2,4,8,1,32,1,128,34,512,34,2048,550,9,0,39,35,39,163,517,38,551,648,38,34,678,512,13,39,1,2566,5,39,34,1,1,38]

theorem envBound56407 : H12AffineFastState.Bounded env56407 := by
  intro p hp
  have h : env56407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56406_56407 : H12AffineEnvironment.transform 5 1 env56406 = env56407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env56406 == env56407) = true)

theorem identity56407 : scanCanonicalize (H12AffineFastState.compose env56407 (packedSelected [0,2,3,7,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 554) := by decide +kernel

theorem selectedBound56407 : packedSelected [0,2,3,7,11,12] rootPS < 2^1333 := by decide +kernel

def env56408 : List Nat := [2,4,8,1,32,1,128,34,512,34,554,550,9,0,39,35,39,163,517,38,551,648,38,34,678,512,13,39,1,44,5,39,34,1,1,38]

theorem envBound56408 : H12AffineFastState.Bounded env56408 := by
  intro p hp
  have h : env56408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56407_56408 : H12AffineEnvironment.transform 10 554 env56407 = env56408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 554 env56407 == env56408) = true)

theorem identity56408 : scanCanonicalize (H12AffineFastState.compose env56408 (packedSelected [0,2,4,5,7,8,9,10] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound56408 : packedSelected [0,2,4,5,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env56409 : List Nat := [2,4,8,1,32,1,128,34,0,34,42,38,9,0,39,35,39,163,5,38,39,136,38,34,166,0,13,39,1,44,5,39,34,1,1,38]

theorem envBound56409 : H12AffineFastState.Bounded env56409 := by
  intro p hp
  have h : env56409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56408_56409 : H12AffineEnvironment.transform 8 0 env56408 = env56409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env56408 == env56409) = true)

theorem identity56409 : scanCanonicalize (H12AffineFastState.compose env56409 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound56409 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56410 : List Nat := [2,4,8,1,32,1,41,34,0,34,42,38,9,0,39,35,39,10,5,38,39,33,38,34,15,0,13,39,1,44,5,39,34,1,1,38]

theorem envBound56410 : H12AffineFastState.Bounded env56410 := by
  intro p hp
  have h : env56410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56409_56410 : H12AffineEnvironment.transform 6 41 env56409 = env56410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env56409 == env56410) = true)

theorem identity56410 : scanCanonicalize (H12AffineFastState.compose env56410 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound56410 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env56411 : List Nat := [2,4,8,1,12,1,5,14,0,14,6,10,9,0,11,15,11,10,5,10,11,13,10,14,15,0,13,11,1,0,5,11,14,1,1,10]

theorem envBound56411 : H12AffineFastState.Bounded env56411 := by
  intro p hp
  have h : env56411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56410_56411 : H12AffineEnvironment.transform 4 12 env56410 = env56411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env56410 == env56411) = true)

theorem identity56411 : scanCanonicalize (H12AffineFastState.compose env56411 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound56411 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env56412 : List Nat := [2,4,5,1,1,1,5,3,0,3,6,7,4,0,6,2,6,7,5,7,6,0,7,3,2,0,0,6,1,0,5,6,3,1,1,7]

theorem envBound56412 : H12AffineFastState.Bounded env56412 := by
  intro p hp
  have h : env56412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56411_56412 : H12AffineEnvironment.transform 2 5 env56411 = env56412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env56411 == env56412) = true)

def env56413 : List Nat := [2,4,8,1,32,64,128,99,512,34,2048,550,73,65,103,65536,65541,65664,517,102,551,648,65540,65537,742,66147,76,65604,64,68197,69,65604,99,65,1,38]

theorem envBound56413 : H12AffineFastState.Bounded env56413 := by
  intro p hp
  have h : env56413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56404_56413 : H12AffineEnvironment.transform 12 73 env56404 = env56413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env56404 == env56413) = true)

theorem identity56413 : scanCanonicalize (H12AffineFastState.compose env56413 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 580) := by decide +kernel

theorem selectedBound56413 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env56414 : List Nat := [2,4,8,1,32,64,128,99,512,34,2048,550,73,65,103,580,577,708,517,102,551,648,576,581,742,39,76,512,64,2081,69,512,99,65,1,38]

theorem envBound56414 : H12AffineFastState.Bounded env56414 := by
  intro p hp
  have h : env56414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56413_56414 : H12AffineEnvironment.transform 15 580 env56413 = env56414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 580 env56413 == env56414) = true)

theorem identity56414 : scanCanonicalize (H12AffineFastState.compose env56414 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound56414 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env56415 : List Nat := [2,4,8,1,32,64,128,99,64,34,2048,102,73,65,103,4,1,132,69,102,103,200,0,5,166,39,76,64,64,2081,69,64,99,65,1,38]

theorem envBound56415 : H12AffineFastState.Bounded env56415 := by
  intro p hp
  have h : env56415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56414_56415 : H12AffineEnvironment.transform 8 64 env56414 = env56415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env56414 == env56415) = true)

theorem identity56415 : scanCanonicalize (H12AffineFastState.compose env56415 (packedSelected [8,13] rootPS)) = affineNative (2^(10+1) ^^^ 143) := by decide +kernel

theorem selectedBound56415 : packedSelected [8,13] rootPS < 2^1333 := by decide +kernel

def env56416 : List Nat := [2,4,8,1,32,64,128,99,64,34,143,102,73,65,103,4,1,132,69,102,103,200,0,5,166,39,76,64,64,174,69,64,99,65,1,38]

theorem envBound56416 : H12AffineFastState.Bounded env56416 := by
  intro p hp
  have h : env56416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56415_56416 : H12AffineEnvironment.transform 10 143 env56415 = env56416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 143 env56415 == env56416) = true)

theorem identity56416 : scanCanonicalize (H12AffineFastState.compose env56416 (packedSelected [0,1,7,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound56416 : packedSelected [0,1,7,10,11] rootPS < 2^1333 := by decide +kernel

def env56417 : List Nat := [2,4,8,1,32,13,128,46,13,34,143,43,4,12,42,4,1,132,8,43,42,133,0,5,166,39,1,13,13,174,8,13,46,12,1,38]

theorem envBound56417 : H12AffineFastState.Bounded env56417 := by
  intro p hp
  have h : env56417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56416_56417 : H12AffineEnvironment.transform 5 13 env56416 = env56417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env56416 == env56417) = true)

theorem identity56417 : scanCanonicalize (H12AffineFastState.compose env56417 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound56417 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env56418 : List Nat := [2,4,8,1,32,13,41,46,13,34,38,43,4,12,42,4,1,45,8,43,42,44,0,5,15,39,1,13,13,7,8,13,46,12,1,38]

theorem envBound56418 : H12AffineFastState.Bounded env56418 := by
  intro p hp
  have h : env56418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56417_56418 : H12AffineEnvironment.transform 6 41 env56417 = env56418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env56417 == env56418) = true)

theorem identity56418 : scanCanonicalize (H12AffineFastState.compose env56418 (packedSelected [0,1,7] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound56418 : packedSelected [0,1,7] rootPS < 2^1333 := by decide +kernel

def env56419 : List Nat := [2,4,8,1,13,13,4,3,13,15,11,6,4,12,7,4,1,0,8,6,7,1,0,5,15,10,1,13,13,7,8,13,3,12,1,11]

theorem envBound56419 : H12AffineFastState.Bounded env56419 := by
  intro p hp
  have h : env56419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56418_56419 : H12AffineEnvironment.transform 4 13 env56418 = env56419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env56418 == env56419) = true)

theorem identity56419 : scanCanonicalize (H12AffineFastState.compose env56419 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound56419 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56420 : List Nat := [2,2,8,1,11,11,2,3,11,9,11,0,2,10,1,2,1,0,8,0,1,1,0,3,9,10,1,11,11,1,8,11,3,10,1,11]

theorem envBound56420 : H12AffineFastState.Bounded env56420 := by
  intro p hp
  have h : env56420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56419_56420 : H12AffineEnvironment.transform 1 2 env56419 = env56420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env56419 == env56420) = true)

theorem identity56420 : scanCanonicalize (H12AffineFastState.compose env56420 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound56420 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56421 : List Nat := [2,2,3,1,0,0,2,3,0,2,0,0,2,1,1,2,1,0,3,0,1,1,0,3,2,1,1,0,0,1,3,0,3,1,1,0]

theorem envBound56421 : H12AffineFastState.Bounded env56421 := by
  intro p hp
  have h : env56421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56420_56421 : H12AffineEnvironment.transform 2 3 env56420 = env56421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env56420 == env56421) = true)

def env56422 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,853,8192,80,8540,65536,74031,65664,533,8541,852,649,74047,65552,9180,74298,318,74111,81,76639,8204,74094,256,8200,1,341]

theorem envBound56422 : H12AffineFastState.Bounded env56422 := by
  intro p hp
  have h : env56422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56385_56422 : H12AffineEnvironment.transform 11 853 env56385 = env56422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 853 env56385 == env56422) = true)

def env56423 : List Nat := [2,4,8,0,32,64,128,256,512,321,2048,837,8192,64,8524,65536,74031,65664,517,8525,836,649,74031,65536,9164,74282,302,74095,65,76623,8204,74094,256,8200,1,325]

theorem envBound56423 : H12AffineFastState.Bounded env56423 := by
  intro p hp
  have h : env56423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56422_56423 : H12AffineEnvironment.transform 3 0 env56422 = env56423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env56422 == env56423) = true)

theorem identity56423 : scanCanonicalize (H12AffineFastState.compose env56423 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 5) := by decide +kernel

theorem selectedBound56423 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env56424 : List Nat := [2,4,8,0,32,64,128,256,512,321,2048,837,8192,64,8524,5,8490,133,517,8525,836,649,8490,5,9164,8751,302,8554,65,11082,8204,8555,256,8200,1,325]

theorem envBound56424 : H12AffineFastState.Bounded env56424 := by
  intro p hp
  have h : env56424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56423_56424 : H12AffineEnvironment.transform 15 5 env56423 = env56424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5 env56423 == env56424) = true)

def env56425 : List Nat := [2,4,8,0,32,64,128,256,512,321,2048,837,72,64,260,5,354,133,517,261,836,649,354,5,900,615,302,290,65,2818,68,291,256,64,1,325]

theorem envBound56425 : H12AffineFastState.Bounded env56425 := by
  intro p hp
  have h : env56425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56424_56425 : H12AffineEnvironment.transform 12 72 env56424 = env56425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env56424 == env56425) = true)

theorem identity56425 : scanCanonicalize (H12AffineFastState.compose env56425 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(5+1) ^^^ 38) := by decide +kernel

theorem selectedBound56425 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env56426 : List Nat := [2,4,8,0,32,38,128,256,512,295,2048,803,46,38,260,5,260,133,517,261,802,649,260,5,900,513,302,290,39,2818,34,291,256,38,1,291]

theorem envBound56426 : H12AffineFastState.Bounded env56426 := by
  intro p hp
  have h : env56426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56425_56426 : H12AffineEnvironment.transform 5 38 env56425 = env56426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 38 env56425 == env56426) = true)

theorem identity56426 : scanCanonicalize (H12AffineFastState.compose env56426 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound56426 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env56427 : List Nat := [2,4,8,0,6,0,128,256,512,257,2048,773,8,0,260,5,260,133,517,261,772,649,260,5,900,513,264,260,1,2818,4,261,256,0,1,261]

theorem envBound56427 : H12AffineFastState.Bounded env56427 := by
  intro p hp
  have h : env56427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56426_56427 : H12AffineEnvironment.transform 4 6 env56426 = env56427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env56426 == env56427) = true)

theorem identity56427 : scanCanonicalize (H12AffineFastState.compose env56427 (packedSelected [0,2,3,7,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 265) := by decide +kernel

theorem selectedBound56427 : packedSelected [0,2,3,7,11,12] rootPS < 2^1333 := by decide +kernel

def env56428 : List Nat := [2,4,8,0,6,0,128,256,512,257,265,773,8,0,260,5,260,133,517,261,772,649,260,5,900,513,264,260,1,523,4,261,256,0,1,261]

theorem envBound56428 : H12AffineFastState.Bounded env56428 := by
  intro p hp
  have h : env56428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56427_56428 : H12AffineEnvironment.transform 10 265 env56427 = env56428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 265 env56427 == env56428) = true)

theorem identity56428 : scanCanonicalize (H12AffineFastState.compose env56428 (packedSelected [0,5,7,8,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound56428 : packedSelected [0,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env56429 : List Nat := [2,4,8,0,6,0,2,256,512,257,265,773,8,0,260,5,260,7,517,261,772,523,260,5,774,513,264,260,1,523,4,261,256,0,1,261]

theorem envBound56429 : H12AffineFastState.Bounded env56429 := by
  intro p hp
  have h : env56429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56428_56429 : H12AffineEnvironment.transform 6 2 env56428 = env56429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env56428 == env56429) = true)

theorem identity56429 : scanCanonicalize (H12AffineFastState.compose env56429 (packedSelected [0,2,3,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound56429 : packedSelected [0,2,3,7,8] rootPS < 2^1333 := by decide +kernel

def env56430 : List Nat := [2,4,8,0,6,0,2,256,10,257,265,271,8,0,260,5,260,7,15,261,270,1,260,5,268,11,264,260,1,1,4,261,256,0,1,261]

theorem envBound56430 : H12AffineFastState.Bounded env56430 := by
  intro p hp
  have h : env56430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56429_56430 : H12AffineEnvironment.transform 8 10 env56429 = env56430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env56429 == env56430) = true)

theorem identity56430 : scanCanonicalize (H12AffineFastState.compose env56430 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 9) := by decide +kernel

theorem selectedBound56430 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56431 : List Nat := [2,4,8,0,6,0,2,9,10,8,0,6,8,0,13,5,13,7,15,12,7,1,13,5,5,11,1,13,1,1,4,12,9,0,1,12]

theorem envBound56431 : H12AffineFastState.Bounded env56431 := by
  intro p hp
  have h : env56431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56430_56431 : H12AffineEnvironment.transform 7 9 env56430 = env56431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 9 env56430 == env56431) = true)

theorem identity56431 : scanCanonicalize (H12AffineFastState.compose env56431 (packedSelected [2,3] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound56431 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env56432 : List Nat := [2,4,4,0,6,0,2,5,6,4,0,6,4,0,1,5,1,7,3,0,7,1,1,5,5,7,1,1,1,1,4,0,5,0,1,0]

theorem envBound56432 : H12AffineFastState.Bounded env56432 := by
  intro p hp
  have h : env56432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56431_56432 : H12AffineEnvironment.transform 2 4 env56431 = env56432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env56431 == env56432) = true)

theorem identity56432 : scanCanonicalize (H12AffineFastState.compose env56432 (packedSelected [0,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound56432 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env56433 : List Nat := [2,3,3,0,1,0,2,2,1,3,0,1,3,0,1,2,1,0,3,0,0,1,1,2,2,0,1,1,1,1,3,0,2,0,1,0]

theorem envBound56433 : H12AffineFastState.Bounded env56433 := by
  intro p hp
  have h : env56433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56432_56433 : H12AffineEnvironment.transform 1 3 env56432 = env56433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env56432 == env56433) = true)

theorem identity56433 : scanCanonicalize (H12AffineFastState.compose env56433 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound56433 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56434 : List Nat := [1,0,0,0,1,0,1,1,1,0,0,1,0,0,1,1,1,0,0,0,0,1,1,1,1,0,1,1,1,1,0,0,1,0,1,0]

theorem envBound56434 : H12AffineFastState.Bounded env56434 := by
  intro p hp
  have h : env56434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56433_56434 : H12AffineEnvironment.transform 0 1 env56433 = env56434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env56433 == env56434) = true)

def env56435 : List Nat := [2,4,8,0,32,64,128,256,512,321,2048,837,73,64,261,5,355,133,517,260,836,649,355,5,901,614,302,291,65,2819,69,290,256,65,1,325]

theorem envBound56435 : H12AffineFastState.Bounded env56435 := by
  intro p hp
  have h : env56435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56424_56435 : H12AffineEnvironment.transform 12 73 env56424 = env56435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env56424 == env56435) = true)

theorem identity56435 : scanCanonicalize (H12AffineFastState.compose env56435 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 291) := by decide +kernel

theorem selectedBound56435 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env56436 : List Nat := [2,4,8,0,32,64,128,256,291,321,2048,102,73,64,261,5,355,133,294,260,103,426,355,5,166,325,302,291,65,2080,69,290,256,65,1,325]

theorem envBound56436 : H12AffineFastState.Bounded env56436 := by
  intro p hp
  have h : env56436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56435_56436 : H12AffineEnvironment.transform 8 291 env56435 = env56436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 291 env56435 == env56436) = true)

theorem identity56436 : scanCanonicalize (H12AffineFastState.compose env56436 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 98) := by decide +kernel

theorem selectedBound56436 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env56437 : List Nat := [2,4,8,0,32,64,128,98,65,35,2048,102,73,64,103,5,1,133,68,102,103,200,1,5,166,39,76,65,65,2080,69,64,98,65,1,39]

theorem envBound56437 : H12AffineFastState.Bounded env56437 := by
  intro p hp
  have h : env56437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56436_56437 : H12AffineEnvironment.transform 7 98 env56436 = env56437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 98 env56436 == env56437) = true)

theorem identity56437 : scanCanonicalize (H12AffineFastState.compose env56437 (packedSelected [8,13] rootPS)) = affineNative (2^(10+1) ^^^ 143) := by decide +kernel

theorem selectedBound56437 : packedSelected [8,13] rootPS < 2^1333 := by decide +kernel

def env56438 : List Nat := [2,4,8,0,32,64,128,98,65,35,143,102,73,64,103,5,1,133,68,102,103,200,1,5,166,39,76,65,65,175,69,64,98,65,1,39]

theorem envBound56438 : H12AffineFastState.Bounded env56438 := by
  intro p hp
  have h : env56438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56437_56438 : H12AffineEnvironment.transform 10 143 env56437 = env56438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 143 env56437 == env56438) = true)

theorem identity56438 : scanCanonicalize (H12AffineFastState.compose env56438 (packedSelected [0,1,7,10,11] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound56438 : packedSelected [0,1,7,10,11] rootPS < 2^1333 := by decide +kernel

def env56439 : List Nat := [2,4,8,0,11,64,128,73,65,8,143,77,73,64,76,5,1,133,68,77,76,200,1,5,141,12,76,65,65,132,69,64,73,65,1,12]

theorem envBound56439 : H12AffineFastState.Bounded env56439 := by
  intro p hp
  have h : env56439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56438_56439 : H12AffineEnvironment.transform 4 11 env56438 = env56439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env56438 == env56439) = true)

theorem identity56439 : scanCanonicalize (H12AffineFastState.compose env56439 (packedSelected [1,2,4,7] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound56439 : packedSelected [1,2,4,7] rootPS < 2^1333 := by decide +kernel

def env56440 : List Nat := [2,4,8,0,11,13,128,4,12,8,143,0,4,13,1,5,1,133,9,0,1,133,1,5,141,12,1,12,12,132,8,13,4,12,1,12]

theorem envBound56440 : H12AffineFastState.Bounded env56440 := by
  intro p hp
  have h : env56440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56439_56440 : H12AffineEnvironment.transform 5 13 env56439 = env56440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env56439 == env56440) = true)

theorem identity56440 : scanCanonicalize (H12AffineFastState.compose env56440 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound56440 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env56441 : List Nat := [2,4,8,0,11,13,3,4,12,8,12,0,4,13,1,5,1,6,9,0,1,6,1,5,14,12,1,12,12,7,8,13,4,12,1,12]

theorem envBound56441 : H12AffineFastState.Bounded env56441 := by
  intro p hp
  have h : env56441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56440_56441 : H12AffineEnvironment.transform 6 3 env56440 = env56441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env56440 == env56441) = true)

def env56442 : List Nat := [2,4,8,1,32,64,128,256,512,321,2048,836,8192,65,8525,65536,74031,65664,516,8524,837,649,74030,65537,9165,74283,303,74094,64,76622,8204,74094,256,8200,1,324]

theorem envBound56442 : H12AffineFastState.Bounded env56442 := by
  intro p hp
  have h : env56442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56422_56442 : H12AffineEnvironment.transform 3 1 env56422 = env56442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env56422 == env56442) = true)

theorem identity56442 : scanCanonicalize (H12AffineFastState.compose env56442 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8268) := by decide +kernel

theorem selectedBound56442 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env56443 : List Nat := [2,4,8,1,32,64,128,256,512,321,2048,836,8192,65,8525,8268,355,8396,516,8524,837,649,354,8269,9165,615,303,290,64,2818,8204,290,256,8200,1,324]

theorem envBound56443 : H12AffineFastState.Bounded env56443 := by
  intro p hp
  have h : env56443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56442_56443 : H12AffineEnvironment.transform 15 8268 env56442 = env56443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8268 env56442 == env56443) = true)

def env56444 : List Nat := [2,4,8,1,32,64,128,256,512,321,2048,836,72,65,261,4,355,132,516,260,837,649,354,5,901,615,303,290,64,2818,68,290,256,64,1,324]

theorem envBound56444 : H12AffineFastState.Bounded env56444 := by
  intro p hp
  have h : env56444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56443_56444 : H12AffineEnvironment.transform 12 72 env56443 = env56444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env56443 == env56444) = true)

theorem identity56444 : scanCanonicalize (H12AffineFastState.compose env56444 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(5+1) ^^^ 38) := by decide +kernel

theorem selectedBound56444 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env56445 : List Nat := [2,4,8,1,32,38,128,256,512,295,2048,802,46,39,261,4,261,132,516,260,803,649,260,5,901,513,303,290,38,2818,34,290,256,38,1,290]

theorem envBound56445 : H12AffineFastState.Bounded env56445 := by
  intro p hp
  have h : env56445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56444_56445 : H12AffineEnvironment.transform 5 38 env56444 = env56445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 38 env56444 == env56445) = true)

theorem identity56445 : scanCanonicalize (H12AffineFastState.compose env56445 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound56445 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env56446 : List Nat := [2,4,8,1,7,1,128,256,512,256,2048,773,9,0,261,4,261,132,516,260,772,649,260,5,901,513,264,261,1,2818,5,261,256,1,1,261]

theorem envBound56446 : H12AffineFastState.Bounded env56446 := by
  intro p hp
  have h : env56446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56445_56446 : H12AffineEnvironment.transform 4 7 env56445 = env56446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env56445 == env56446) = true)

theorem identity56446 : scanCanonicalize (H12AffineFastState.compose env56446 (packedSelected [0,2,3,7,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 13) := by decide +kernel

theorem selectedBound56446 : packedSelected [0,2,3,7,11,12] rootPS < 2^1333 := by decide +kernel

def env56447 : List Nat := [2,4,8,1,7,1,128,256,512,256,13,773,9,0,261,4,261,132,516,260,772,649,260,5,901,513,264,261,1,783,5,261,256,1,1,261]

theorem envBound56447 : H12AffineFastState.Bounded env56447 := by
  intro p hp
  have h : env56447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56446_56447 : H12AffineEnvironment.transform 10 13 env56446 = env56447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 13 env56446 == env56447) = true)

theorem identity56447 : scanCanonicalize (H12AffineFastState.compose env56447 (packedSelected [0,1,2,3,4,7,8,9,10] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound56447 : packedSelected [0,1,2,3,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env56448 : List Nat := [2,4,8,1,7,1,128,256,0,256,13,261,9,0,261,4,261,132,4,260,260,137,260,5,389,1,264,261,1,271,5,261,256,1,1,261]

theorem envBound56448 : H12AffineFastState.Bounded env56448 := by
  intro p hp
  have h : env56448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56447_56448 : H12AffineEnvironment.transform 8 0 env56447 = env56448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env56447 == env56448) = true)

theorem identity56448 : scanCanonicalize (H12AffineFastState.compose env56448 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 128) := by decide +kernel

theorem selectedBound56448 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56449 : List Nat := [2,4,8,1,7,1,128,128,0,128,13,133,9,0,133,4,133,132,4,132,132,137,132,5,5,1,136,133,1,143,5,133,128,1,1,133]

theorem envBound56449 : H12AffineFastState.Bounded env56449 := by
  intro p hp
  have h : env56449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56448_56449 : H12AffineEnvironment.transform 7 128 env56448 = env56449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 128 env56448 == env56449) = true)

theorem identity56449 : scanCanonicalize (H12AffineFastState.compose env56449 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound56449 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env56450 : List Nat := [2,4,8,1,7,1,4,4,0,4,13,1,9,0,1,4,1,0,4,0,0,13,0,5,5,1,12,1,1,11,5,1,4,1,1,1]

theorem envBound56450 : H12AffineFastState.Bounded env56450 := by
  intro p hp
  have h : env56450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56449_56450 : H12AffineEnvironment.transform 6 4 env56449 = env56450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env56449 == env56450) = true)

def env56451 : List Nat := [2,4,8,1,32,64,128,256,512,321,2048,836,73,65,260,5,355,133,516,261,837,649,354,4,900,615,303,290,64,2818,69,290,256,65,1,324]

theorem envBound56451 : H12AffineFastState.Bounded env56451 := by
  intro p hp
  have h : env56451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56443_56451 : H12AffineEnvironment.transform 12 73 env56443 = env56451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env56443 == env56451) = true)

theorem identity56451 : scanCanonicalize (H12AffineFastState.compose env56451 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 291) := by decide +kernel

theorem selectedBound56451 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env56452 : List Nat := [2,4,8,1,32,64,128,256,291,321,2048,103,73,65,260,5,355,133,295,261,102,426,354,4,167,324,303,290,64,2081,69,290,256,65,1,324]

theorem envBound56452 : H12AffineFastState.Bounded env56452 := by
  intro p hp
  have h : env56452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56451_56452 : H12AffineEnvironment.transform 8 291 env56451 = env56452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 291 env56451 == env56452) = true)

theorem identity56452 : scanCanonicalize (H12AffineFastState.compose env56452 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 98) := by decide +kernel

theorem selectedBound56452 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env56453 : List Nat := [2,4,8,1,32,64,128,98,65,35,2048,103,73,65,102,5,1,133,69,103,102,200,0,4,167,38,77,64,64,2081,69,64,98,65,1,38]

theorem envBound56453 : H12AffineFastState.Bounded env56453 := by
  intro p hp
  have h : env56453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56452_56453 : H12AffineEnvironment.transform 7 98 env56452 = env56453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 98 env56452 == env56453) = true)

theorem identity56453 : scanCanonicalize (H12AffineFastState.compose env56453 (packedSelected [8,13] rootPS)) = affineNative (2^(10+1) ^^^ 142) := by decide +kernel

theorem selectedBound56453 : packedSelected [8,13] rootPS < 2^1333 := by decide +kernel

def env56454 : List Nat := [2,4,8,1,32,64,128,98,65,35,142,103,73,65,102,5,1,133,69,103,102,200,0,4,167,38,77,64,64,175,69,64,98,65,1,38]

theorem envBound56454 : H12AffineFastState.Bounded env56454 := by
  intro p hp
  have h : env56454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56453_56454 : H12AffineEnvironment.transform 10 142 env56453 = env56454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 142 env56453 == env56454) = true)

theorem identity56454 : scanCanonicalize (H12AffineFastState.compose env56454 (packedSelected [0,1,7,10,11] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound56454 : packedSelected [0,1,7,10,11] rootPS < 2^1333 := by decide +kernel

def env56455 : List Nat := [2,4,8,1,10,64,128,72,65,9,142,77,73,65,76,5,1,133,69,77,76,200,0,4,141,12,77,64,64,133,69,64,72,65,1,12]

theorem envBound56455 : H12AffineFastState.Bounded env56455 := by
  intro p hp
  have h : env56455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56454_56455 : H12AffineEnvironment.transform 4 10 env56454 = env56455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env56454 == env56455) = true)

theorem identity56455 : scanCanonicalize (H12AffineFastState.compose env56455 (packedSelected [1,2,4,7] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound56455 : packedSelected [1,2,4,7] rootPS < 2^1333 := by decide +kernel

def env56456 : List Nat := [2,4,8,1,10,11,128,3,10,9,142,6,2,10,7,5,1,133,14,6,7,131,0,4,141,12,6,11,11,133,14,11,3,10,1,12]

theorem envBound56456 : H12AffineFastState.Bounded env56456 := by
  intro p hp
  have h : env56456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56455_56456 : H12AffineEnvironment.transform 5 11 env56455 = env56456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env56455 == env56456) = true)

theorem identity56456 : scanCanonicalize (H12AffineFastState.compose env56456 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound56456 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env56457 : List Nat := [2,4,8,1,10,11,14,3,10,9,0,6,2,10,7,5,1,11,14,6,7,13,0,4,3,12,6,11,11,11,14,11,3,10,1,12]

theorem envBound56457 : H12AffineFastState.Bounded env56457 := by
  intro p hp
  have h : env56457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56456_56457 : H12AffineEnvironment.transform 6 14 env56456 = env56457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env56456 == env56457) = true)

theorem identity56457 : scanCanonicalize (H12AffineFastState.compose env56457 (packedSelected [1,2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound56457 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env56458 : List Nat := [2,3,8,1,10,11,9,3,10,9,0,1,2,10,0,2,1,11,9,1,0,10,0,3,3,11,1,11,11,11,9,11,3,10,1,11]

theorem envBound56458 : H12AffineFastState.Bounded env56458 := by
  intro p hp
  have h : env56458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56457_56458 : H12AffineEnvironment.transform 1 3 env56457 = env56458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env56457 == env56458) = true)

theorem identity56458 : scanCanonicalize (H12AffineFastState.compose env56458 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound56458 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56459 : List Nat := [2,3,0,1,2,3,1,3,2,1,0,1,2,2,0,2,1,3,1,1,0,2,0,3,3,3,1,3,3,3,1,3,3,2,1,3]

theorem envBound56459 : H12AffineFastState.Bounded env56459 := by
  intro p hp
  have h : env56459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56458_56459 : H12AffineEnvironment.transform 2 0 env56458 = env56459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env56458 == env56459) = true)

theorem identity56459 : scanCanonicalize (H12AffineFastState.compose env56459 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound56459 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56460 : List Nat := [0,1,0,1,0,1,1,1,0,1,0,1,0,0,0,0,1,1,1,1,0,0,0,1,1,1,1,1,1,1,1,1,1,0,1,1]

theorem envBound56460 : H12AffineFastState.Bounded env56460 := by
  intro p hp
  have h : env56460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56459_56460 : H12AffineEnvironment.transform 0 0 env56459 = env56460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env56459 == env56460) = true)

def env56461 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74862,65665,4416,8541,4097,5277,74047,66897,13768,78894,1150,74814,1296,81227,8204,74799,256,8200,1344,5953]

theorem envBound56461 : H12AffineFastState.Bounded env56461 := by
  intro p hp
  have h : env56461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56383_56461 : H12AffineEnvironment.transform 17 65665 env56383 = env56461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env56383 == env56461) = true)

theorem identity56461 : scanCanonicalize (H12AffineFastState.compose env56461 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound56461 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env56462 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,8192,1297,8540,65536,74862,65665,321,8541,0,1180,74047,66897,9673,74799,1150,74814,1296,77130,8204,74799,256,8200,1344,1856]

theorem envBound56462 : H12AffineFastState.Bounded env56462 := by
  intro p hp
  have h : env56462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56461_56462 : H12AffineEnvironment.transform 11 1 env56461 = env56462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env56461 == env56462) = true)

def env56463 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,8192,81,8540,65536,74030,65665,321,8541,0,476,74047,65553,8329,74095,318,74110,80,75786,8204,74095,256,8200,0,512]

theorem envBound56463 : H12AffineFastState.Bounded env56463 := by
  intro p hp
  have h : env56463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56462_56463 : H12AffineEnvironment.transform 9 320 env56462 = env56463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env56462 == env56463) = true)

theorem identity56463 : scanCanonicalize (H12AffineFastState.compose env56463 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound56463 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env56464 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,1,8192,81,8540,115,8541,242,321,8541,0,476,8524,98,8329,8476,318,8461,80,10361,8204,8476,256,8200,0,512]

theorem envBound56464 : H12AffineFastState.Bounded env56464 := by
  intro p hp
  have h : env56464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56463_56464 : H12AffineEnvironment.transform 15 115 env56463 = env56464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env56463 == env56464) = true)

theorem identity56464 : scanCanonicalize (H12AffineFastState.compose env56464 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound56464 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env56465 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,1,8192,1,8460,35,8461,162,273,8461,0,396,8476,50,8329,8476,318,8461,0,10281,8204,8476,256,8200,0,512]

theorem envBound56465 : H12AffineFastState.Bounded env56465 := by
  intro p hp
  have h : env56465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56464_56465 : H12AffineEnvironment.transform 5 16 env56464 = env56465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env56464 == env56465) = true)

theorem identity56465 : scanCanonicalize (H12AffineFastState.compose env56465 (packedSelected [2,13,17] rootPS)) = affineNative (2^(12+1) ^^^ 2585) := by decide +kernel

theorem selectedBound56465 : packedSelected [2,13,17] rootPS < 2^1333 := by decide +kernel

def env56466 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,1,2585,1,2837,35,2836,162,273,2836,0,396,2821,50,2704,2821,318,2836,0,560,2581,2821,256,2577,0,512]

theorem envBound56466 : H12AffineFastState.Bounded env56466 := by
  intro p hp
  have h : env56466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56465_56466 : H12AffineEnvironment.transform 12 2585 env56465 = env56466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2585 env56465 == env56466) = true)

theorem identity56466 : scanCanonicalize (H12AffineFastState.compose env56466 (packedSelected [2,3,5,10,11,18] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound56466 : packedSelected [2,3,5,10,11,18] rootPS < 2^1333 := by decide +kernel

def env56467 : List Nat := [2,4,8,16,32,16,128,256,43,272,2048,1,2098,1,2366,35,2367,162,273,2367,0,396,2350,50,2235,2350,318,2367,0,27,2110,2350,256,2106,0,43]

theorem envBound56467 : H12AffineFastState.Bounded env56467 := by
  intro p hp
  have h : env56467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56466_56467 : H12AffineEnvironment.transform 8 43 env56466 = env56467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env56466 == env56467) = true)

theorem identity56467 : scanCanonicalize (H12AffineFastState.compose env56467 (packedSelected [0,1,2,3,4,7,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 27) := by decide +kernel

theorem selectedBound56467 : packedSelected [0,1,2,3,4,7,9,10] rootPS < 2^1333 := by decide +kernel

def env56468 : List Nat := [2,4,8,16,32,16,128,256,43,272,27,1,41,1,293,35,292,162,273,292,0,396,309,50,160,309,318,292,0,27,37,309,256,33,0,43]

theorem envBound56468 : H12AffineFastState.Bounded env56468 := by
  intro p hp
  have h : env56468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56467_56468 : H12AffineEnvironment.transform 10 27 env56467 = env56468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 27 env56467 == env56468) = true)

theorem identity56468 : scanCanonicalize (H12AffineFastState.compose env56468 (packedSelected [1,8] rootPS)) = affineNative (2^(7+1) ^^^ 157) := by decide +kernel

theorem selectedBound56468 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env56469 : List Nat := [2,4,8,16,32,16,128,157,43,141,27,1,41,1,184,35,185,162,140,185,0,17,168,50,160,168,163,185,0,27,37,168,157,33,0,43]

theorem envBound56469 : H12AffineFastState.Bounded env56469 := by
  intro p hp
  have h : env56469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56468_56469 : H12AffineEnvironment.transform 7 157 env56468 = env56469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 157 env56468 == env56469) = true)

theorem identity56469 : scanCanonicalize (H12AffineFastState.compose env56469 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound56469 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56470 : List Nat := [2,4,8,16,32,16,8,21,43,5,27,1,41,1,48,35,49,42,4,49,0,17,32,50,40,32,43,49,0,27,37,32,21,33,0,43]

theorem envBound56470 : H12AffineFastState.Bounded env56470 := by
  intro p hp
  have h : env56470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56469_56470 : H12AffineEnvironment.transform 6 8 env56469 = env56470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env56469 == env56470) = true)

theorem identity56470 : scanCanonicalize (H12AffineFastState.compose env56470 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound56470 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56471 : List Nat := [2,4,8,16,13,16,8,21,6,5,27,1,4,1,29,14,28,7,4,28,0,17,13,31,5,13,6,28,0,27,8,13,21,12,0,6]

theorem envBound56471 : H12AffineFastState.Bounded env56471 := by
  intro p hp
  have h : env56471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56470_56471 : H12AffineEnvironment.transform 4 13 env56470 = env56471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env56470 == env56471) = true)

theorem identity56471 : scanCanonicalize (H12AffineFastState.compose env56471 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound56471 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56472 : List Nat := [2,4,8,10,13,10,8,15,6,5,1,1,4,1,7,14,6,7,4,6,0,11,13,5,5,13,6,6,0,1,8,13,15,12,0,6]

theorem envBound56472 : H12AffineFastState.Bounded env56472 := by
  intro p hp
  have h : env56472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56471_56472 : H12AffineEnvironment.transform 3 10 env56471 = env56472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env56471 == env56472) = true)

def env56473 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,8192,80,8540,65536,74031,65665,321,8541,0,477,74047,65552,8328,74094,319,74111,81,75787,8204,74094,256,8200,1,513]

theorem envBound56473 : H12AffineFastState.Bounded env56473 := by
  intro p hp
  have h : env56473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56462_56473 : H12AffineEnvironment.transform 9 321 env56462 = env56473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env56462 == env56473) = true)

theorem identity56473 : scanCanonicalize (H12AffineFastState.compose env56473 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound56473 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env56474 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,269,80,81,65536,65570,65665,321,80,0,477,65586,65552,389,65635,319,65650,81,67846,257,65635,256,261,1,513]

theorem envBound56474 : H12AffineFastState.Bounded env56474 := by
  intro p hp
  have h : env56474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56473_56474 : H12AffineEnvironment.transform 12 269 env56473 = env56474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env56473 == env56474) = true)

theorem identity56474 : scanCanonicalize (H12AffineFastState.compose env56474 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 310) := by decide +kernel

theorem selectedBound56474 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env56475 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,1,269,80,81,310,276,439,321,80,0,477,260,294,389,341,319,324,81,2096,257,341,256,261,1,513]

theorem envBound56475 : H12AffineFastState.Bounded env56475 := by
  intro p hp
  have h : env56475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56474_56475 : H12AffineEnvironment.transform 15 310 env56474 = env56475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 310 env56474 == env56475) = true)

theorem identity56475 : scanCanonicalize (H12AffineFastState.compose env56475 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound56475 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env56476 : List Nat := [2,4,8,16,32,64,128,5,512,68,2048,1,8,80,81,51,17,178,68,80,0,216,1,35,128,80,58,65,81,2096,4,80,5,0,1,513]

theorem envBound56476 : H12AffineFastState.Bounded env56476 := by
  intro p hp
  have h : env56476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56475_56476 : H12AffineEnvironment.transform 7 5 env56475 = env56476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env56475 == env56476) = true)

theorem identity56476 : scanCanonicalize (H12AffineFastState.compose env56476 (packedSelected [2,11,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 152) := by decide +kernel

theorem selectedBound56476 : packedSelected [2,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env56477 : List Nat := [2,4,8,16,32,64,128,5,152,68,2048,1,8,80,81,51,17,178,68,80,0,216,1,35,128,80,58,65,81,2096,4,80,5,0,1,153]

theorem envBound56477 : H12AffineFastState.Bounded env56477 := by
  intro p hp
  have h : env56477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56476_56477 : H12AffineEnvironment.transform 8 152 env56476 = env56477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 152 env56476 == env56477) = true)

theorem identity56477 : scanCanonicalize (H12AffineFastState.compose env56477 (packedSelected [0,3,5,7,8,11,12,13,17] rootPS)) = affineNative (2^(6+1) ^^^ 101) := by decide +kernel

theorem selectedBound56477 : packedSelected [0,3,5,7,8,11,12,13,17] rootPS < 2^1333 := by decide +kernel

def env56478 : List Nat := [2,4,8,16,32,64,101,5,125,68,2048,1,8,80,81,51,17,87,68,80,0,61,1,35,101,80,58,65,81,2096,4,80,5,0,1,124]

theorem envBound56478 : H12AffineFastState.Bounded env56478 := by
  intro p hp
  have h : env56478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56477_56478 : H12AffineEnvironment.transform 6 101 env56477 = env56478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 101 env56477 == env56478) = true)

theorem identity56478 : scanCanonicalize (H12AffineFastState.compose env56478 (packedSelected [1,2,5,8,11,12,13,15,20] rootPS)) = affineNative (2^(10+1) ^^^ 107) := by decide +kernel

theorem selectedBound56478 : packedSelected [1,2,5,8,11,12,13,15,20] rootPS < 2^1333 := by decide +kernel

def env56479 : List Nat := [2,4,8,16,32,64,101,5,125,68,107,1,8,80,81,51,17,87,68,80,0,61,1,35,101,80,58,65,81,91,4,80,5,0,1,124]

theorem envBound56479 : H12AffineFastState.Bounded env56479 := by
  intro p hp
  have h : env56479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56478_56479 : H12AffineEnvironment.transform 10 107 env56478 = env56479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 107 env56478 == env56479) = true)

theorem identity56479 : scanCanonicalize (H12AffineFastState.compose env56479 (packedSelected [0,4,5,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound56479 : packedSelected [0,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env56480 : List Nat := [2,4,8,16,32,16,53,5,45,20,59,1,8,0,1,51,17,7,20,0,0,61,1,35,53,0,58,17,1,11,4,0,5,0,1,44]

theorem envBound56480 : H12AffineFastState.Bounded env56480 := by
  intro p hp
  have h : env56480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56479_56480 : H12AffineEnvironment.transform 5 16 env56479 = env56480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env56479 == env56480) = true)

theorem identity56480 : scanCanonicalize (H12AffineFastState.compose env56480 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound56480 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env56481 : List Nat := [2,4,8,16,28,16,9,5,17,20,7,1,8,0,1,15,17,7,20,0,0,1,1,31,9,0,6,17,1,11,4,0,5,0,1,16]

theorem envBound56481 : H12AffineFastState.Bounded env56481 := by
  intro p hp
  have h : env56481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56480_56481 : H12AffineEnvironment.transform 4 28 env56480 = env56481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env56480 == env56481) = true)

theorem identity56481 : scanCanonicalize (H12AffineFastState.compose env56481 (packedSelected [1,3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound56481 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56482 : List Nat := [2,2,8,16,26,16,9,3,17,18,1,1,8,0,1,9,17,1,18,0,0,1,1,25,9,0,0,17,1,11,2,0,3,0,1,16]

theorem envBound56482 : H12AffineFastState.Bounded env56482 := by
  intro p hp
  have h : env56482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56481_56482 : H12AffineEnvironment.transform 1 2 env56481 = env56482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env56481 == env56482) = true)

theorem identity56482 : scanCanonicalize (H12AffineFastState.compose env56482 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound56482 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env56483 : List Nat := [2,2,8,9,3,9,9,3,8,11,1,1,8,0,1,9,8,1,11,0,0,1,1,0,9,0,0,8,1,11,2,0,3,0,1,9]

theorem envBound56483 : H12AffineFastState.Bounded env56483 := by
  intro p hp
  have h : env56483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56482_56483 : H12AffineEnvironment.transform 3 9 env56482 = env56483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env56482 == env56483) = true)

theorem identity56483 : scanCanonicalize (H12AffineFastState.compose env56483 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound56483 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env56484 : List Nat := [1,1,8,9,0,9,9,0,8,8,1,1,8,0,1,9,8,1,8,0,0,1,1,0,9,0,0,8,1,8,1,0,0,0,1,9]

theorem envBound56484 : H12AffineFastState.Bounded env56484 := by
  intro p hp
  have h : env56484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56483_56484 : H12AffineEnvironment.transform 0 1 env56483 = env56484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env56483 == env56484) = true)

def env56485 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,524288,32769,4097,61648,91182,123165,533640,614527,385203,90415,545089,96346,25884,618622,256,25880,1344,525825]

theorem envBound56485 : H12AffineFastState.Bounded env56485 := by
  intro p hp
  have h : env56485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56004_56485 : H12AffineEnvironment.transform 23 123165 env56004 = env56485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123165 env56004 == env56485) = true)

def env56486 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,21584,32769,4097,61648,91182,123165,28888,78895,385203,90415,1297,96346,25884,74798,256,25880,1344,21073]

theorem envBound56486 : H12AffineFastState.Bounded env56486 := by
  intro p hp
  have h : env56486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56485_56486 : H12AffineEnvironment.transform 18 21584 env56485 = env56486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env56485 == env56486) = true)

theorem identity56486 : scanCanonicalize (H12AffineFastState.compose env56486 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound56486 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env56487 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13340,65536,74862,262144,21584,13341,4097,17612,91182,87297,28888,78895,349359,90415,1297,96346,25884,74798,256,25880,1344,21073]

theorem envBound56487 : H12AffineFastState.Bounded env56487 := by
  intro p hp
  have h : env56487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56486_56487 : H12AffineEnvironment.transform 14 13340 env56486 = env56487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env56486 == env56487) = true)

def env56488 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74862,262144,4416,13341,4097,476,74046,69649,13768,78895,332223,74815,1297,81226,8204,74798,256,8200,1344,5953]

theorem envBound56488 : H12AffineFastState.Bounded env56488 := by
  intro p hp
  have h : env56488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56487_56488 : H12AffineEnvironment.transform 13 1296 env56487 = env56488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env56487 == env56488) = true)

def env56489 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74862,65664,4416,13341,4097,476,74046,69649,13768,78895,4415,74815,1297,81226,8204,74798,256,8200,1344,5953]

theorem envBound56489 : H12AffineFastState.Bounded env56489 := by
  intro p hp
  have h : env56489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56488_56489 : H12AffineEnvironment.transform 17 65664 env56488 = env56489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env56488 == env56489) = true)

theorem identity56489 : scanCanonicalize (H12AffineFastState.compose env56489 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5159) := by decide +kernel

theorem selectedBound56489 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env56490 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,5159,12361,5287,4416,13341,4097,476,13593,1078,13768,8200,4415,12312,1297,10605,8204,12297,256,8200,1344,5953]

theorem envBound56490 : H12AffineFastState.Bounded env56490 := by
  intro p hp
  have h : env56490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56489_56490 : H12AffineEnvironment.transform 15 5159 env56489 = env56490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5159 env56489 == env56490) = true)

def env56491 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5384,1296,276,5159,1345,5287,4416,277,4097,476,17,1078,192,5376,4415,1296,1297,7269,5380,1281,256,5376,1344,5953]

theorem envBound56491 : H12AffineFastState.Bounded env56491 := by
  intro p hp
  have h : env56491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56490_56491 : H12AffineEnvironment.transform 12 5384 env56490 = env56491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5384 env56490 == env56491) = true)

theorem identity56491 : scanCanonicalize (H12AffineFastState.compose env56491 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound56491 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env56492 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1028,268,1296,276,35,1345,163,1348,277,1029,476,17,1078,192,260,1339,1296,1297,2145,256,1281,256,260,1344,837]

theorem envBound56492 : H12AffineFastState.Bounded env56492 := by
  intro p hp
  have h : env56492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56491_56492 : H12AffineEnvironment.transform 11 1028 env56491 = env56492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env56491 == env56492) = true)

theorem identity56492 : scanCanonicalize (H12AffineFastState.compose env56492 (packedSelected [2,5,8,10,11,20] rootPS)) = affineNative (2^(10+1) ^^^ 1882) := by decide +kernel

theorem selectedBound56492 : packedSelected [2,5,8,10,11,20] rootPS < 2^1333 := by decide +kernel

def env56493 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1882,1028,268,1296,276,35,1345,163,1348,277,1029,476,17,1078,192,260,1339,1296,1297,1851,256,1281,256,260,1344,837]

theorem envBound56493 : H12AffineFastState.Bounded env56493 := by
  intro p hp
  have h : env56493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56492_56493 : H12AffineEnvironment.transform 10 1882 env56492 = env56493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1882 env56492 == env56493) = true)

theorem identity56493 : scanCanonicalize (H12AffineFastState.compose env56493 (packedSelected [1,2,3,4,9,10,13,17,23] rootPS)) = affineNative (2^(9+1) ^^^ 969) := by decide +kernel

theorem selectedBound56493 : packedSelected [1,2,3,4,9,10,13,17,23] rootPS < 2^1333 := by decide +kernel

def env56494 : List Nat := [2,4,8,16,32,64,128,256,512,969,147,973,268,729,276,35,648,163,653,277,972,476,17,1023,192,260,754,729,728,242,256,712,256,260,649,837]

theorem envBound56494 : H12AffineFastState.Bounded env56494 := by
  intro p hp
  have h : env56494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56493_56494 : H12AffineEnvironment.transform 9 969 env56493 = env56494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 969 env56493 == env56494) = true)

theorem identity56494 : scanCanonicalize (H12AffineFastState.compose env56494 (packedSelected [1,2,3,4,5,8,9,12,13,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound56494 : packedSelected [1,2,3,4,5,8,9,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env56495 : List Nat := [2,4,8,16,32,64,128,173,512,612,147,608,161,729,185,35,648,163,653,184,609,113,17,594,192,169,754,729,728,242,173,712,173,169,649,744]

theorem envBound56495 : H12AffineFastState.Bounded env56495 := by
  intro p hp
  have h : env56495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56494_56495 : H12AffineEnvironment.transform 7 173 env56494 = env56495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env56494 == env56495) = true)

theorem identity56495 : scanCanonicalize (H12AffineFastState.compose env56495 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound56495 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env56496 : List Nat := [2,4,8,16,32,64,105,68,512,612,122,608,72,560,80,35,609,74,612,81,609,113,17,594,41,64,539,560,561,27,68,545,68,64,608,513]

theorem envBound56496 : H12AffineFastState.Bounded env56496 := by
  intro p hp
  have h : env56496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56495_56496 : H12AffineEnvironment.transform 6 105 env56495 = env56496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env56495 == env56496) = true)

def env56497 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5385,1296,277,5159,1344,5287,4416,276,4097,476,16,1078,193,5377,4415,1297,1297,7268,5381,1280,256,5377,1344,5953]

theorem envBound56497 : H12AffineFastState.Bounded env56497 := by
  intro p hp
  have h : env56497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56490_56497 : H12AffineEnvironment.transform 12 5385 env56490 = env56497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5385 env56490 == env56497) = true)

theorem identity56497 : scanCanonicalize (H12AffineFastState.compose env56497 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound56497 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env56498 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,4121,0,277,4407,80,4535,4416,276,4097,476,16,294,193,4113,4415,1,1,6516,4117,16,256,4113,80,4689]

theorem envBound56498 : H12AffineFastState.Bounded env56498 := by
  intro p hp
  have h : env56498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56497_56498 : H12AffineEnvironment.transform 9 272 env56497 = env56498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env56497 == env56498) = true)

theorem identity56498 : scanCanonicalize (H12AffineFastState.compose env56498 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound56498 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env56499 : List Nat := [2,4,8,16,32,64,128,172,512,188,2048,4096,4121,0,185,4251,80,4123,4332,184,4097,112,16,138,193,4113,4243,1,1,6360,4117,16,172,4113,80,4689]

theorem envBound56499 : H12AffineFastState.Bounded env56499 := by
  intro p hp
  have h : env56499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56498_56499 : H12AffineEnvironment.transform 7 172 env56498 = env56499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env56498 == env56499) = true)

theorem identity56499 : scanCanonicalize (H12AffineFastState.compose env56499 (packedSelected [0,2,3,4,5,7,9,10,11,12,15,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 538) := by decide +kernel

theorem selectedBound56499 : packedSelected [0,2,3,4,5,7,9,10,11,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env56500 : List Nat := [2,4,8,16,32,64,128,172,512,188,538,4096,4121,0,185,4251,80,4123,4332,184,4097,112,16,138,193,4113,4243,1,1,4802,4117,16,172,4113,80,4689]

theorem envBound56500 : H12AffineFastState.Bounded env56500 := by
  intro p hp
  have h : env56500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56499_56500 : H12AffineEnvironment.transform 10 538 env56499 = env56500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 538 env56499 == env56500) = true)

theorem identity56500 : scanCanonicalize (H12AffineFastState.compose env56500 (packedSelected [0,2,3,7,8,10,16,17] rootPS)) = affineNative (2^(6+1) ^^^ 67) := by decide +kernel

theorem selectedBound56500 : packedSelected [0,2,3,7,8,10,16,17] rootPS < 2^1333 := by decide +kernel

def env56501 : List Nat := [2,4,8,16,32,64,67,111,512,127,538,4096,4121,0,122,4184,80,4123,4143,123,4097,112,16,73,2,4113,4176,1,1,4609,4117,16,111,4113,80,4689]

theorem envBound56501 : H12AffineFastState.Bounded env56501 := by
  intro p hp
  have h : env56501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56500_56501 : H12AffineEnvironment.transform 6 67 env56500 = env56501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 67 env56500 == env56501) = true)

theorem identity56501 : scanCanonicalize (H12AffineFastState.compose env56501 (packedSelected [0,3,4,7,8,9,12] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound56501 : packedSelected [0,3,4,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env56502 : List Nat := [2,4,8,16,32,64,67,111,1,127,27,4096,4121,0,122,4184,80,4123,4143,123,4097,112,16,73,2,4113,4176,1,1,4096,4117,16,111,4113,80,4176]

theorem envBound56502 : H12AffineFastState.Bounded env56502 := by
  intro p hp
  have h : env56502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56501_56502 : H12AffineEnvironment.transform 8 1 env56501 = env56502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env56501 == env56502) = true)

theorem identity56502 : scanCanonicalize (H12AffineFastState.compose env56502 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 97) := by decide +kernel

theorem selectedBound56502 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env56503 : List Nat := [2,4,8,16,32,64,67,111,1,127,27,97,120,0,122,57,80,122,78,123,96,112,16,73,2,112,49,1,1,97,116,16,111,112,80,49]

theorem envBound56503 : H12AffineFastState.Bounded env56503 := by
  intro p hp
  have h : env56503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56502_56503 : H12AffineEnvironment.transform 11 97 env56502 = env56503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 97 env56502 == env56503) = true)

theorem identity56503 : scanCanonicalize (H12AffineFastState.compose env56503 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound56503 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env56504 : List Nat := [2,4,8,11,32,64,67,111,1,100,0,97,99,0,97,34,75,97,78,96,96,107,11,73,2,107,42,1,1,97,111,11,111,107,75,42]

theorem envBound56504 : H12AffineFastState.Bounded env56504 := by
  intro p hp
  have h : env56504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56503_56504 : H12AffineEnvironment.transform 3 11 env56503 = env56504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env56503 == env56504) = true)

theorem identity56504 : scanCanonicalize (H12AffineFastState.compose env56504 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound56504 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env56505 : List Nat := [2,4,8,11,32,11,8,36,1,47,0,42,40,0,42,34,0,42,5,43,43,32,11,2,2,32,42,1,1,42,36,11,36,32,0,42]

theorem envBound56505 : H12AffineFastState.Bounded env56505 := by
  intro p hp
  have h : env56505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56504_56505 : H12AffineEnvironment.transform 5 11 env56504 = env56505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env56504 == env56505) = true)

theorem identity56505 : scanCanonicalize (H12AffineFastState.compose env56505 (packedSelected [0,1,4] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound56505 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env56506 : List Nat := [2,4,8,11,12,11,8,8,1,3,0,6,4,0,6,14,0,6,5,7,7,12,11,2,2,12,6,1,1,6,8,11,8,12,0,6]

theorem envBound56506 : H12AffineFastState.Bounded env56506 := by
  intro p hp
  have h : env56506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56505_56506 : H12AffineEnvironment.transform 4 12 env56505 = env56506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env56505 == env56506) = true)

def env56507 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,65536,74862,65665,4416,13341,4097,476,74046,69649,13768,78895,4414,74815,1297,81226,8204,74798,256,8200,1344,5953]

theorem envBound56507 : H12AffineFastState.Bounded env56507 := by
  intro p hp
  have h : env56507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56488_56507 : H12AffineEnvironment.transform 17 65665 env56488 = env56507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env56488 == env56507) = true)

theorem identity56507 : scanCanonicalize (H12AffineFastState.compose env56507 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 359) := by decide +kernel

theorem selectedBound56507 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env56508 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13340,359,9481,486,4416,13341,4097,476,8281,4470,13768,13640,4414,9560,1297,15405,8204,9545,256,8200,1344,5953]

theorem envBound56508 : H12AffineFastState.Bounded env56508 := by
  intro p hp
  have h : env56508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56507_56508 : H12AffineEnvironment.transform 15 359 env56507 = env56508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 359 env56507 == env56508) = true)

def env56509 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,72,1296,5204,359,1345,486,4416,5205,4097,476,17,4470,5504,5376,4414,1296,1297,7269,68,1281,256,64,1344,5953]

theorem envBound56509 : H12AffineFastState.Bounded env56509 := by
  intro p hp
  have h : env56509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans56508_56509 : H12AffineEnvironment.transform 12 72 env56508 = env56509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env56508 == env56509) = true)

theorem identity56509 : scanCanonicalize (H12AffineFastState.compose env56509 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound56509 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

end H12CloudChart2