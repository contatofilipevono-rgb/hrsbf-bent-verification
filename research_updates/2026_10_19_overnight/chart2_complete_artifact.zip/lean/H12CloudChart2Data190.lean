import H12CloudChart2Data189

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity47717 : scanCanonicalize (H12AffineFastState.compose env47717 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1213) := by decide +kernel

theorem selectedBound47717 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env47718 : List Nat := [2,4,8,16,32,17,128,173,512,1024,1213,184,1684,1212,1589,531,184,1582,1024,1588,185,1060,1045,139,1565,1045,1703,184,185,1077,173,1196,172,169,1213,512]

theorem envBound47718 : H12AffineFastState.Bounded env47718 := by
  intro p hp
  have h : env47718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47717_47718 : H12AffineEnvironment.transform 10 1213 env47717 = env47718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1213 env47717 == env47718) = true)

theorem identity47718 : scanCanonicalize (H12AffineFastState.compose env47718 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound47718 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env47719 : List Nat := [2,4,8,16,32,17,128,173,0,1024,1213,184,1172,1212,1077,19,184,1070,1024,1076,185,1060,1045,139,1053,1045,1191,184,185,1077,173,1196,172,169,1213,0]

theorem envBound47719 : H12AffineFastState.Bounded env47719 := by
  intro p hp
  have h : env47719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47718_47719 : H12AffineEnvironment.transform 8 0 env47718 = env47719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env47718 == env47719) = true)

theorem identity47719 : scanCanonicalize (H12AffineFastState.compose env47719 (packedSelected [3,4] rootPS)) = affineNative (2^(9+1) ^^^ 31) := by decide +kernel

theorem selectedBound47719 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env47720 : List Nat := [2,4,8,16,32,17,128,173,0,31,162,184,139,163,42,19,184,49,31,43,185,59,10,139,2,10,184,184,185,42,173,179,172,169,162,0]

theorem envBound47720 : H12AffineFastState.Bounded env47720 := by
  intro p hp
  have h : env47720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47719_47720 : H12AffineEnvironment.transform 9 31 env47719 = env47720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 31 env47719 == env47720) = true)

theorem identity47720 : scanCanonicalize (H12AffineFastState.compose env47720 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound47720 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env47721 : List Nat := [2,4,8,16,32,17,18,63,0,31,48,42,25,49,42,19,42,49,31,43,43,59,10,25,2,10,42,42,43,42,63,33,62,59,48,0]

theorem envBound47721 : H12AffineFastState.Bounded env47721 := by
  intro p hp
  have h : env47721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47720_47721 : H12AffineEnvironment.transform 6 18 env47720 = env47721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env47720 == env47721) = true)

theorem identity47721 : scanCanonicalize (H12AffineFastState.compose env47721 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound47721 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47722 : List Nat := [2,4,8,16,7,17,18,24,0,31,23,13,25,22,13,19,13,22,31,12,12,28,10,25,2,10,13,13,12,13,24,6,25,28,23,0]

theorem envBound47722 : H12AffineFastState.Bounded env47722 := by
  intro p hp
  have h : env47722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47721_47722 : H12AffineEnvironment.transform 4 7 env47721 = env47722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env47721 == env47722) = true)

theorem identity47722 : scanCanonicalize (H12AffineFastState.compose env47722 (packedSelected [9] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound47722 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env47723 : List Nat := [2,4,8,10,7,11,8,2,0,5,13,13,3,12,13,9,13,12,5,12,12,6,10,3,2,10,13,13,12,13,2,6,3,6,13,0]

theorem envBound47723 : H12AffineFastState.Bounded env47723 := by
  intro p hp
  have h : env47723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47722_47723 : H12AffineEnvironment.transform 3 10 env47722 = env47723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env47722 == env47723) = true)

theorem identity47723 : scanCanonicalize (H12AffineFastState.compose env47723 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound47723 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47724 : List Nat := [2,4,4,6,7,7,4,2,0,5,1,1,3,0,1,5,1,0,5,0,0,6,6,3,2,6,1,1,0,1,2,6,3,6,1,0]

theorem envBound47724 : H12AffineFastState.Bounded env47724 := by
  intro p hp
  have h : env47724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47723_47724 : H12AffineEnvironment.transform 2 4 env47723 = env47724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env47723 == env47724) = true)

def env47725 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147520,41002,143496,20496,493035,148800,148800,96346,74794,222335,257,74798,1345,135681]

theorem envBound47725 : H12AffineFastState.Bounded env47725 := by
  intro p hp
  have h : env47725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47680_47725 : H12AffineEnvironment.transform 18 136193 env47680 = env47725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env47680 == env47725) = true)

def env47726 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147520,41002,143496,20496,492615,148716,148716,96346,74794,222335,173,74798,1261,135681]

theorem envBound47726 : H12AffineFastState.Bounded env47726 := by
  intro p hp
  have h : env47726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47725_47726 : H12AffineEnvironment.transform 7 172 env47725 = env47726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env47725 == env47726) = true)

def env47727 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61568,147472,41002,143496,20496,492567,148668,148668,96266,74794,222255,173,74798,1213,135681]

theorem envBound47727 : H12AffineFastState.Bounded env47727 := by
  intro p hp
  have h : env47727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47726_47727 : H12AffineEnvironment.transform 5 16 env47726 = env47727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47726 == env47727) = true)

theorem identity47727 : scanCanonicalize (H12AffineFastState.compose env47727 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 114722) := by decide +kernel

theorem selectedBound47727 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env47728 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,114722,262144,119843,32769,4097,61568,98354,41002,127146,20496,279605,99486,99486,96266,74794,41997,173,74798,1213,119331]

theorem envBound47728 : H12AffineFastState.Bounded env47728 := by
  intro p hp
  have h : env47728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47727_47728 : H12AffineEnvironment.transform 16 114722 env47727 = env47728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114722 env47727 == env47728) = true)

theorem identity47728 : scanCanonicalize (H12AffineFastState.compose env47728 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 101551) := by decide +kernel

theorem selectedBound47728 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env47729 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,114722,101551,119843,32769,4097,61568,98354,41002,127146,20496,116890,99486,99486,96266,74794,41997,173,74798,1213,119331]

theorem envBound47729 : H12AffineFastState.Bounded env47729 := by
  intro p hp
  have h : env47729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47728_47729 : H12AffineEnvironment.transform 17 101551 env47728 = env47729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 101551 env47728 == env47729) = true)

theorem identity47729 : scanCanonicalize (H12AffineFastState.compose env47729 (packedSelected [7,16,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound47729 : packedSelected [7,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env47730 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,53283,4097,23692,1024,32769,4097,61568,20497,41002,8329,20496,6329,21693,21693,43049,62473,41997,173,62477,1213,512]

theorem envBound47730 : H12AffineFastState.Bounded env47730 := by
  intro p hp
  have h : env47730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47729_47730 : H12AffineEnvironment.transform 15 53283 env47729 = env47730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env47729 == env47730) = true)

theorem identity47730 : scanCanonicalize (H12AffineFastState.compose env47730 (packedSelected [4,9,16] rootPS)) = affineNative (2^(14+1) ^^^ 12312) := by decide +kernel

theorem selectedBound47730 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env47731 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,12312,24635,4097,23692,1024,12313,4097,16536,20497,4146,8329,20496,6329,21693,21693,6193,17425,5141,173,17429,1213,512]

theorem envBound47731 : H12AffineFastState.Bounded env47731 := by
  intro p hp
  have h : env47731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47730_47731 : H12AffineEnvironment.transform 14 12312 env47730 = env47731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12312 env47730 == env47731) = true)

theorem identity47731 : scanCanonicalize (H12AffineFastState.compose env47731 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 12945) := by decide +kernel

theorem selectedBound47731 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env47732 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,12945,12312,4778,4097,11805,1024,12313,4097,12809,8832,4146,8329,8833,6329,9772,9772,6193,13952,5141,173,13956,1213,512]

theorem envBound47732 : H12AffineFastState.Bounded env47732 := by
  intro p hp
  have h : env47732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47731_47732 : H12AffineEnvironment.transform 13 12945 env47731 = env47732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12945 env47731 == env47732) = true)

theorem identity47732 : scanCanonicalize (H12AffineFastState.compose env47732 (packedSelected [0,3,4,8,13] rootPS)) = affineNative (2^(12+1) ^^^ 1166) := by decide +kernel

theorem selectedBound47732 : packedSelected [0,3,4,8,13] rootPS < 2^1333 := by decide +kernel

def env47733 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,1166,5663,5270,4778,4097,2707,1024,5271,4097,5767,1550,4146,1031,1551,6329,674,674,6193,4622,5141,173,4618,1213,512]

theorem envBound47733 : H12AffineFastState.Bounded env47733 := by
  intro p hp
  have h : env47733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47732_47733 : H12AffineEnvironment.transform 12 1166 env47732 = env47733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1166 env47732 == env47733) = true)

theorem identity47733 : scanCanonicalize (H12AffineFastState.compose env47733 (packedSelected [0,1,2,5,9,11,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 3077) := by decide +kernel

theorem selectedBound47733 : packedSelected [0,1,2,5,9,11,12,15] rootPS < 2^1333 := by decide +kernel

def env47734 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,3077,1166,2586,2195,3759,3076,2707,1024,2194,3076,2690,1550,3127,1031,1551,1212,674,674,1076,3595,2064,173,3599,1213,512]

theorem envBound47734 : H12AffineFastState.Bounded env47734 := by
  intro p hp
  have h : env47734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47733_47734 : H12AffineEnvironment.transform 11 3077 env47733 = env47734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3077 env47733 == env47734) = true)

theorem identity47734 : scanCanonicalize (H12AffineFastState.compose env47734 (packedSelected [0,3,4,5,7,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 652) := by decide +kernel

theorem selectedBound47734 : packedSelected [0,3,4,5,7,9,11] rootPS < 2^1333 := by decide +kernel

def env47735 : List Nat := [2,4,8,16,32,16,128,172,512,652,2048,2697,514,2586,2195,2083,2696,2707,652,2194,2696,2690,130,2747,651,131,560,674,674,696,2183,2064,173,2179,561,512]

theorem envBound47735 : H12AffineFastState.Bounded env47735 := by
  intro p hp
  have h : env47735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47734_47735 : H12AffineEnvironment.transform 9 652 env47734 = env47735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 652 env47734 == env47735) = true)

theorem identity47735 : scanCanonicalize (H12AffineFastState.compose env47735 (packedSelected [2,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 674) := by decide +kernel

theorem selectedBound47735 : packedSelected [2,5,7] rootPS < 2^1333 := by decide +kernel

def env47736 : List Nat := [2,4,8,16,32,16,128,172,512,652,674,43,514,184,561,641,42,49,652,560,42,32,130,25,651,131,560,674,674,696,549,690,173,545,561,512]

theorem envBound47736 : H12AffineFastState.Bounded env47736 := by
  intro p hp
  have h : env47736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47735_47736 : H12AffineEnvironment.transform 10 674 env47735 = env47736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 674 env47735 == env47736) = true)

theorem identity47736 : scanCanonicalize (H12AffineFastState.compose env47736 (packedSelected [4,5] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound47736 : packedSelected [4,5] rootPS < 2^1333 := by decide +kernel

def env47737 : List Nat := [2,4,8,16,32,16,128,172,137,5,43,43,139,184,184,8,42,49,5,185,42,32,130,25,2,131,185,43,43,49,172,59,173,168,184,137]

theorem envBound47737 : H12AffineFastState.Bounded env47737 := by
  intro p hp
  have h : env47737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47736_47737 : H12AffineEnvironment.transform 8 137 env47736 = env47737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env47736 == env47737) = true)

theorem identity47737 : scanCanonicalize (H12AffineFastState.compose env47737 (packedSelected [0,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound47737 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env47738 : List Nat := [2,4,8,16,32,16,34,14,43,5,43,43,41,26,26,8,42,49,5,27,42,32,32,25,2,33,27,43,43,49,14,59,15,10,26,43]

theorem envBound47738 : H12AffineFastState.Bounded env47738 := by
  intro p hp
  have h : env47738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47737_47738 : H12AffineEnvironment.transform 6 34 env47737 = env47738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env47737 == env47738) = true)

theorem identity47738 : scanCanonicalize (H12AffineFastState.compose env47738 (packedSelected [0,1,2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound47738 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env47739 : List Nat := [2,4,8,16,11,16,9,14,0,5,0,0,2,26,26,8,1,26,5,27,1,11,11,25,2,10,27,0,0,26,14,16,15,10,26,0]

theorem envBound47739 : H12AffineFastState.Bounded env47739 := by
  intro p hp
  have h : env47739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47738_47739 : H12AffineEnvironment.transform 4 11 env47738 = env47739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env47738 == env47739) = true)

theorem identity47739 : scanCanonicalize (H12AffineFastState.compose env47739 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound47739 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env47740 : List Nat := [2,4,8,10,11,10,9,14,0,5,0,0,2,0,0,8,1,0,5,1,1,11,11,3,2,10,1,0,0,0,14,10,15,10,0,0]

theorem envBound47740 : H12AffineFastState.Bounded env47740 := by
  intro p hp
  have h : env47740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47739_47740 : H12AffineEnvironment.transform 3 10 env47739 = env47740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env47739 == env47740) = true)

theorem identity47740 : scanCanonicalize (H12AffineFastState.compose env47740 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound47740 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47741 : List Nat := [2,2,8,10,11,10,9,8,0,3,0,0,2,0,0,8,1,0,3,1,1,11,11,3,2,10,1,0,0,0,8,10,9,10,0,0]

theorem envBound47741 : H12AffineFastState.Bounded env47741 := by
  intro p hp
  have h : env47741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47740_47741 : H12AffineEnvironment.transform 1 2 env47740 = env47741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env47740 == env47741) = true)

def env47742 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61569,147473,41002,143496,20496,492566,148669,148669,96267,74794,222254,173,74798,1212,135681]

theorem envBound47742 : H12AffineFastState.Bounded env47742 := by
  intro p hp
  have h : env47742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47726_47742 : H12AffineEnvironment.transform 5 17 env47726 = env47742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47726 == env47742) = true)

theorem identity47742 : scanCanonicalize (H12AffineFastState.compose env47742 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 223243) := by decide +kernel

theorem selectedBound47742 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env47743 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,223243,136193,32769,4097,61569,147473,41002,143496,20496,60445,148669,148669,96267,74794,222254,173,74798,1212,135681]

theorem envBound47743 : H12AffineFastState.Bounded env47743 := by
  intro p hp
  have h : env47743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47742_47743 : H12AffineEnvironment.transform 17 223243 env47742 = env47743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223243 env47742 == env47743) = true)

theorem identity47743 : scanCanonicalize (H12AffineFastState.compose env47743 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 28802) := by decide +kernel

theorem selectedBound47743 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env47744 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,28802,131072,137353,136193,32769,4097,61569,147473,41002,143496,20496,60445,148669,148669,2185,21672,136364,173,21676,1212,135681]

theorem envBound47744 : H12AffineFastState.Bounded env47744 := by
  intro p hp
  have h : env47744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47743_47744 : H12AffineEnvironment.transform 15 28802 env47743 = env47744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28802 env47743 == env47744) = true)

theorem identity47744 : scanCanonicalize (H12AffineFastState.compose env47744 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(16+1) ^^^ 58532) := by decide +kernel

theorem selectedBound47744 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env47745 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,28802,58532,64557,61605,32769,4097,61569,42165,41002,54316,20496,60445,40985,40985,2185,21672,61448,173,21676,1212,63141]

theorem envBound47745 : H12AffineFastState.Bounded env47745 := by
  intro p hp
  have h : env47745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47744_47745 : H12AffineEnvironment.transform 16 58532 env47744 = env47745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 58532 env47744 == env47745) = true)

theorem identity47745 : scanCanonicalize (H12AffineFastState.compose env47745 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound47745 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env47746 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1212,32768,13374,40984,47249,46105,32769,4097,46141,42165,41002,37008,5292,43169,40985,40985,2185,4116,46260,173,4112,1212,45593]

theorem envBound47746 : H12AffineFastState.Bounded env47746 := by
  intro p hp
  have h : env47746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47745_47746 : H12AffineEnvironment.transform 13 1212 env47745 = env47746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env47745 == env47746) = true)

theorem identity47746 : scanCanonicalize (H12AffineFastState.compose env47746 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(14+1) ^^^ 2195) := by decide +kernel

theorem selectedBound47746 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env47747 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1212,2195,13374,10379,12290,15498,2194,4097,15534,11302,10425,6147,5292,8242,10378,10378,2185,4116,15399,173,4112,1212,14986]

theorem envBound47747 : H12AffineFastState.Bounded env47747 := by
  intro p hp
  have h : env47747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47746_47747 : H12AffineEnvironment.transform 14 2195 env47746 = env47747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2195 env47746 == env47747) = true)

theorem identity47747 : scanCanonicalize (H12AffineFastState.compose env47747 (packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 7310) := by decide +kernel

theorem selectedBound47747 : packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env47748 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,7310,1212,2195,2224,5125,3212,4,2194,4097,32,4264,5175,6147,5292,7356,5124,5124,2185,4116,169,173,4112,1212,1540]

theorem envBound47748 : H12AffineFastState.Bounded env47748 := by
  intro p hp
  have h : env47748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47747_47748 : H12AffineEnvironment.transform 12 7310 env47747 = env47748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7310 env47747 == env47748) = true)

theorem identity47748 : scanCanonicalize (H12AffineFastState.compose env47748 (packedSelected [1,2,3,6,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 696) := by decide +kernel

theorem selectedBound47748 : packedSelected [1,2,3,6,10,11] rootPS < 2^1333 := by decide +kernel

def env47749 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,696,3638,1212,2195,2224,1725,3212,4,2194,697,32,528,1679,2747,1556,3588,1724,1724,2185,684,169,173,680,1212,1540]

theorem envBound47749 : H12AffineFastState.Bounded env47749 := by
  intro p hp
  have h : env47749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47748_47749 : H12AffineEnvironment.transform 11 696 env47748 = env47749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 696 env47748 == env47749) = true)

theorem identity47749 : scanCanonicalize (H12AffineFastState.compose env47749 (packedSelected [5,6,7,9,12] rootPS)) = affineNative (2^(6+1) ^^^ 46) := by decide +kernel

theorem selectedBound47749 : packedSelected [5,6,7,9,12] rootPS < 2^1333 := by decide +kernel

def env47750 : List Nat := [2,4,8,16,32,17,46,2,512,1024,2048,534,3638,1042,2109,2078,1555,3106,4,2108,535,32,528,1569,2581,1556,3588,1554,1554,2087,514,7,3,518,1042,1540]

theorem envBound47750 : H12AffineFastState.Bounded env47750 := by
  intro p hp
  have h : env47750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47749_47750 : H12AffineEnvironment.transform 6 46 env47749 = env47750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 46 env47749 == env47750) = true)

theorem identity47750 : scanCanonicalize (H12AffineFastState.compose env47750 (packedSelected [4,5,8,9,16] rootPS)) = affineNative (2^(10+1) ^^^ 524) := by decide +kernel

theorem selectedBound47750 : packedSelected [4,5,8,9,16] rootPS < 2^1333 := by decide +kernel

def env47751 : List Nat := [2,4,8,16,32,17,46,2,512,1024,524,534,1082,1042,561,530,1555,1582,4,560,535,32,528,1569,25,1556,1032,1554,1554,555,514,7,3,518,1042,1540]

theorem envBound47751 : H12AffineFastState.Bounded env47751 := by
  intro p hp
  have h : env47751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47750_47751 : H12AffineEnvironment.transform 10 524 env47750 = env47751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 524 env47750 == env47751) = true)

theorem identity47751 : scanCanonicalize (H12AffineFastState.compose env47751 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound47751 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env47752 : List Nat := [2,4,8,16,28,17,18,2,512,1024,524,534,1030,1042,525,530,1555,1554,4,524,535,28,528,1565,25,1556,1032,1554,1554,535,514,7,3,518,1042,1540]

theorem envBound47752 : H12AffineFastState.Bounded env47752 := by
  intro p hp
  have h : env47752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47751_47752 : H12AffineEnvironment.transform 4 28 env47751 = env47752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env47751 == env47752) = true)

theorem identity47752 : scanCanonicalize (H12AffineFastState.compose env47752 (packedSelected [0,1,2,3,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound47752 : packedSelected [0,1,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env47753 : List Nat := [2,4,8,16,28,17,18,2,512,517,524,534,515,535,525,530,22,23,4,524,535,28,528,24,25,17,525,23,23,535,514,7,3,518,535,1]

theorem envBound47753 : H12AffineFastState.Bounded env47753 := by
  intro p hp
  have h : env47753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47752_47753 : H12AffineEnvironment.transform 9 517 env47752 = env47753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env47752 == env47753) = true)

theorem identity47753 : scanCanonicalize (H12AffineFastState.compose env47753 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound47753 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env47754 : List Nat := [2,4,8,16,28,17,18,2,0,5,12,22,3,23,13,18,22,23,4,12,23,28,16,24,25,17,13,23,23,23,2,7,3,6,23,1]

theorem envBound47754 : H12AffineFastState.Bounded env47754 := by
  intro p hp
  have h : env47754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47753_47754 : H12AffineEnvironment.transform 8 0 env47753 = env47754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env47753 == env47754) = true)

theorem identity47754 : scanCanonicalize (H12AffineFastState.compose env47754 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound47754 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47755 : List Nat := [0,4,8,16,28,17,16,0,0,5,12,20,1,21,13,16,20,21,4,12,21,28,16,24,25,17,13,21,21,21,0,5,1,4,21,1]

theorem envBound47755 : H12AffineFastState.Bounded env47755 := by
  intro p hp
  have h : env47755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47754_47755 : H12AffineEnvironment.transform 0 0 env47754 = env47755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env47754 == env47755) = true)

theorem identity47755 : scanCanonicalize (H12AffineFastState.compose env47755 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound47755 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47756 : List Nat := [0,0,8,16,24,17,16,0,0,1,8,16,1,17,9,16,16,17,0,8,17,24,16,24,25,17,9,17,17,17,0,1,1,0,17,1]

theorem envBound47756 : H12AffineFastState.Bounded env47756 := by
  intro p hp
  have h : env47756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47755_47756 : H12AffineEnvironment.transform 1 0 env47755 = env47756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env47755 == env47756) = true)

theorem identity47756 : scanCanonicalize (H12AffineFastState.compose env47756 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound47756 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47757 : List Nat := [0,0,8,8,0,9,8,0,0,1,8,8,1,9,9,8,8,9,0,8,9,0,8,0,1,9,9,9,9,9,0,1,1,0,9,1]

theorem envBound47757 : H12AffineFastState.Bounded env47757 := by
  intro p hp
  have h : env47757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47756_47757 : H12AffineEnvironment.transform 3 8 env47756 = env47757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env47756 == env47757) = true)

theorem identity47757 : scanCanonicalize (H12AffineFastState.compose env47757 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound47757 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env47758 : List Nat := [0,0,0,0,0,1,0,0,0,1,0,0,1,1,1,0,0,1,0,0,1,0,0,0,1,1,1,1,1,1,0,1,1,0,1,1]

theorem envBound47758 : H12AffineFastState.Bounded env47758 := by
  intro p hp
  have h : env47758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47757_47758 : H12AffineEnvironment.transform 2 0 env47757 = env47758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env47757 == env47758) = true)

def env47759 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61648,147520,41002,143496,20496,492614,148717,148717,96346,74794,222335,172,74798,1260,135681]

theorem envBound47759 : H12AffineFastState.Bounded env47759 := by
  intro p hp
  have h : env47759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47725_47759 : H12AffineEnvironment.transform 7 173 env47725 = env47759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env47725 == env47759) = true)

def env47760 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61568,147472,41002,143496,20496,492566,148669,148669,96266,74794,222255,172,74798,1212,135681]

theorem envBound47760 : H12AffineFastState.Bounded env47760 := by
  intro p hp
  have h : env47760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47759_47760 : H12AffineEnvironment.transform 5 16 env47759 = env47760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47759 == env47760) = true)

theorem identity47760 : scanCanonicalize (H12AffineFastState.compose env47760 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound47760 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env47761 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,45216,262144,42145,32769,4097,61568,61616,41002,32808,20496,341174,62493,62493,96266,74794,119951,172,74798,1212,41633]

theorem envBound47761 : H12AffineFastState.Bounded env47761 := by
  intro p hp
  have h : env47761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47760_47761 : H12AffineEnvironment.transform 16 45216 env47760 = env47761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env47760 == env47761) = true)

theorem identity47761 : scanCanonicalize (H12AffineFastState.compose env47761 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound47761 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env47762 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,1213,32768,65536,45216,262144,42145,32769,4097,46141,46093,41002,32808,5293,341174,45216,45216,81079,74794,102450,172,74798,1212,41633]

theorem envBound47762 : H12AffineFastState.Bounded env47762 := by
  intro p hp
  have h : env47762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47761_47762 : H12AffineEnvironment.transform 13 1213 env47761 = env47762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env47761 == env47762) = true)

theorem identity47762 : scanCanonicalize (H12AffineFastState.compose env47762 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound47762 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env47763 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,185,8192,1213,32768,65536,40985,262144,42145,32769,184,42116,42164,41002,32808,1044,336911,40985,40985,76814,74794,98443,172,74798,1212,41633]

theorem envBound47763 : H12AffineFastState.Bounded env47763 := by
  intro p hp
  have h : env47763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47762_47763 : H12AffineEnvironment.transform 11 185 env47762 = env47763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env47762 == env47763) = true)

theorem identity47763 : scanCanonicalize (H12AffineFastState.compose env47763 (packedSelected [4,9,20] rootPS)) = affineNative (2^(15+1) ^^^ 33831) := by decide +kernel

theorem selectedBound47763 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env47764 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,185,8192,1213,32768,33831,40985,262144,42145,32769,184,42116,42164,41002,32808,1044,303144,40985,40985,43049,40973,1196,172,40969,1212,41633]

theorem envBound47764 : H12AffineFastState.Bounded env47764 := by
  intro p hp
  have h : env47764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47763_47764 : H12AffineEnvironment.transform 15 33831 env47763 = env47764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33831 env47763 == env47764) = true)

theorem identity47764 : scanCanonicalize (H12AffineFastState.compose env47764 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 8353) := by decide +kernel

theorem selectedBound47764 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env47765 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,185,8192,1213,8353,9350,184,262144,1024,8352,184,1061,1045,139,8329,1044,262281,184,184,2184,172,1196,172,168,1212,512]

theorem envBound47765 : H12AffineFastState.Bounded env47765 := by
  intro p hp
  have h : env47765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47764_47765 : H12AffineEnvironment.transform 14 8353 env47764 = env47765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8353 env47764 == env47765) = true)

theorem identity47765 : scanCanonicalize (H12AffineFastState.compose env47765 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2600) := by decide +kernel

theorem selectedBound47765 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47766 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,185,2600,1213,2697,3758,184,262144,1024,2696,184,1061,1045,139,2721,1044,262281,184,184,2184,172,1196,172,168,1212,512]

theorem envBound47766 : H12AffineFastState.Bounded env47766 := by
  intro p hp
  have h : env47766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47765_47766 : H12AffineEnvironment.transform 12 2600 env47765 = env47766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2600 env47765 == env47766) = true)

theorem identity47766 : scanCanonicalize (H12AffineFastState.compose env47766 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 2707) := by decide +kernel

theorem selectedBound47766 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env47767 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,185,2600,1213,2697,3758,184,2707,1024,2696,184,1061,1045,139,2721,1044,2586,184,184,2184,172,1196,172,168,1212,512]

theorem envBound47767 : H12AffineFastState.Bounded env47767 := by
  intro p hp
  have h : env47767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47766_47767 : H12AffineEnvironment.transform 17 2707 env47766 = env47767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2707 env47766 == env47767) = true)

theorem identity47767 : scanCanonicalize (H12AffineFastState.compose env47767 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1213) := by decide +kernel

theorem selectedBound47767 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env47768 : List Nat := [2,4,8,16,32,16,128,173,512,1024,1213,185,1685,1213,1588,531,184,1582,1024,1589,184,1061,1045,139,1564,1044,1703,184,184,1077,172,1196,172,168,1212,512]

theorem envBound47768 : H12AffineFastState.Bounded env47768 := by
  intro p hp
  have h : env47768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47767_47768 : H12AffineEnvironment.transform 10 1213 env47767 = env47768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1213 env47767 == env47768) = true)

theorem identity47768 : scanCanonicalize (H12AffineFastState.compose env47768 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound47768 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env47769 : List Nat := [2,4,8,16,32,16,128,173,0,1024,1213,185,1173,1213,1076,19,184,1070,1024,1077,184,1061,1045,139,1052,1044,1191,184,184,1077,172,1196,172,168,1212,0]

theorem envBound47769 : H12AffineFastState.Bounded env47769 := by
  intro p hp
  have h : env47769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47768_47769 : H12AffineEnvironment.transform 8 0 env47768 = env47769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env47768 == env47769) = true)

theorem identity47769 : scanCanonicalize (H12AffineFastState.compose env47769 (packedSelected [3,4] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound47769 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env47770 : List Nat := [2,4,8,11,32,11,128,173,0,1024,1190,162,1166,1190,1071,8,163,1070,1024,1070,163,1061,1038,139,1031,1039,1191,163,163,1070,172,1196,172,168,1191,0]

theorem envBound47770 : H12AffineFastState.Bounded env47770 := by
  intro p hp
  have h : env47770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47769_47770 : H12AffineEnvironment.transform 3 11 env47769 = env47770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env47769 == env47770) = true)

def env47771 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4097,61569,147473,41002,143496,20496,492567,148668,148668,96267,74794,222254,172,74798,1213,135681]

theorem envBound47771 : H12AffineFastState.Bounded env47771 := by
  intro p hp
  have h : env47771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47759_47771 : H12AffineEnvironment.transform 5 17 env47759 = env47771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47759 == env47771) = true)

theorem identity47771 : scanCanonicalize (H12AffineFastState.compose env47771 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 137352) := by decide +kernel

theorem selectedBound47771 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env47772 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,137352,136193,32769,4097,61569,147473,41002,143496,20496,105631,148668,148668,96267,74794,222254,172,74798,1213,135681]

theorem envBound47772 : H12AffineFastState.Bounded env47772 := by
  intro p hp
  have h : env47772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47771_47772 : H12AffineEnvironment.transform 17 137352 env47771 = env47772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137352 env47771 == env47772) = true)

theorem identity47772 : scanCanonicalize (H12AffineFastState.compose env47772 (packedSelected [1,5,8,18,19,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 13375) := by decide +kernel

theorem selectedBound47772 : packedSelected [1,5,8,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env47773 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,13375,131072,137352,136193,32769,4097,61569,147473,41002,143496,20496,43168,148668,148668,19508,4117,151569,172,4113,1213,135681]

theorem envBound47773 : H12AffineFastState.Bounded env47773 := by
  intro p hp
  have h : env47773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47772_47773 : H12AffineEnvironment.transform 15 13375 env47772 = env47773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13375 env47772 == env47773) = true)

theorem identity47773 : scanCanonicalize (H12AffineFastState.compose env47773 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound47773 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env47774 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1213,32768,13375,131072,137352,136193,32769,4097,46140,132268,41002,143496,5293,43168,131073,131073,2185,4117,136364,172,4113,1213,135681]

theorem envBound47774 : H12AffineFastState.Bounded env47774 := by
  intro p hp
  have h : env47774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47773_47774 : H12AffineEnvironment.transform 13 1213 env47773 = env47774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env47773 == env47774) = true)

theorem identity47774 : scanCanonicalize (H12AffineFastState.compose env47774 (packedSelected [13,17] rootPS)) = affineNative (2^(16+1) ^^^ 46245) := by decide +kernel

theorem selectedBound47774 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env47775 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,1213,32768,13375,46245,44077,41124,32769,4097,46140,45065,41002,33837,5293,43168,46244,46244,2185,4117,40969,172,4113,1213,42660]

theorem envBound47775 : H12AffineFastState.Bounded env47775 := by
  intro p hp
  have h : env47775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47774_47775 : H12AffineEnvironment.transform 16 46245 env47774 = env47775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46245 env47774 == env47775) = true)

theorem identity47775 : scanCanonicalize (H12AffineFastState.compose env47775 (packedSelected [6,12,13,15] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound47775 : packedSelected [6,12,13,15] rootPS < 2^1333 := by decide +kernel

def env47776 : List Nat := [2,4,8,16,32,17,128,173,512,5,2048,4096,8192,184,32768,12346,45216,43048,41124,32769,4097,45113,45065,41002,32808,4264,43168,45217,45217,2185,4117,40969,172,4113,184,41633]

theorem envBound47776 : H12AffineFastState.Bounded env47776 := by
  intro p hp
  have h : env47776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47775_47776 : H12AffineEnvironment.transform 9 5 env47775 = env47776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env47775 == env47776) = true)

theorem identity47776 : scanCanonicalize (H12AffineFastState.compose env47776 (packedSelected [2,3,6,7,8,9] rootPS)) = affineNative (2^(14+1) ^^^ 6187) := by decide +kernel

theorem selectedBound47776 : packedSelected [2,3,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env47777 : List Nat := [2,4,8,16,32,17,128,173,512,5,2048,4096,8192,184,6187,12346,10379,12291,14479,6186,4097,10258,10274,14337,6147,4264,12427,10378,10378,2185,4117,14370,172,4113,184,14986]

theorem envBound47777 : H12AffineFastState.Bounded env47777 := by
  intro p hp
  have h : env47777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47776_47777 : H12AffineEnvironment.transform 14 6187 env47776 = env47777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 6187 env47776 == env47777) = true)

theorem identity47777 : scanCanonicalize (H12AffineFastState.compose env47777 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(12+1) ^^^ 6169) := by decide +kernel

theorem selectedBound47777 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env47778 : List Nat := [2,4,8,16,32,17,128,173,512,5,2048,4096,6169,184,6187,2083,4242,2074,150,6186,4097,4107,4155,24,6147,4264,2194,4243,4243,2185,4117,59,172,4113,184,659]

theorem envBound47778 : H12AffineFastState.Bounded env47778 := by
  intro p hp
  have h : env47778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47777_47778 : H12AffineEnvironment.transform 12 6169 env47777 = env47778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6169 env47777 == env47778) = true)

theorem identity47778 : scanCanonicalize (H12AffineFastState.compose env47778 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 697) := by decide +kernel

theorem selectedBound47778 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env47779 : List Nat := [2,4,8,16,32,17,128,173,512,5,2048,697,2720,184,2706,2083,555,2074,150,2707,696,690,642,24,2746,529,2194,554,554,2185,684,59,172,680,184,659]

theorem envBound47779 : H12AffineFastState.Bounded env47779 := by
  intro p hp
  have h : env47779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47778_47779 : H12AffineEnvironment.transform 11 697 env47778 = env47779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 697 env47778 == env47779) = true)

theorem identity47779 : scanCanonicalize (H12AffineFastState.compose env47779 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 185) := by decide +kernel

theorem selectedBound47779 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env47780 : List Nat := [2,4,8,16,32,17,128,173,512,5,185,697,537,184,555,154,555,163,150,554,696,690,642,24,515,529,43,554,554,48,684,59,172,680,184,659]

theorem envBound47780 : H12AffineFastState.Bounded env47780 := by
  intro p hp
  have h : env47780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47779_47780 : H12AffineEnvironment.transform 10 185 env47779 = env47780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 185 env47779 == env47780) = true)

theorem identity47780 : scanCanonicalize (H12AffineFastState.compose env47780 (packedSelected [3,5,6] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound47780 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env47781 : List Nat := [2,4,8,16,32,17,18,63,512,5,43,555,537,42,555,8,555,49,4,554,554,544,528,24,515,529,43,554,554,48,574,59,62,570,42,513]

theorem envBound47781 : H12AffineFastState.Bounded env47781 := by
  intro p hp
  have h : env47781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47780_47781 : H12AffineEnvironment.transform 6 18 env47780 = env47781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env47780 == env47781) = true)

def env47782 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,2154705,147520,16777216,33554432,672785,134217728,148800,33584584,2189403,50962569,4294967296,34088328,4347445490,151462017,33563273]

theorem envBound47782 : H12AffineFastState.Bounded env47782 := by
  intro p hp
  have h : env47782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans45452_47782 : H12AffineEnvironment.transform 34 151462017 env45452 = env47782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 151462017 env45452 == env47782) = true)

def env47783 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,33554432,672785,134217728,148800,33584584,96347,50962569,4294967296,34088328,4345352434,151462017,33563273]

theorem envBound47783 : H12AffineFastState.Bounded env47783 := by
  intro p hp
  have h : env47783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47782_47783 : H12AffineEnvironment.transform 20 4096 env47782 = env47783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env47782 == env47783) = true)

theorem identity47783 : scanCanonicalize (H12AffineFastState.compose env47783 (packedSelected [14] rootPS)) = affineNative (2^(31+1) ^^^ 33641719) := by decide +kernel

theorem selectedBound47783 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env47784 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,33554432,672785,134217728,148800,33584584,96347,50962569,33641719,34088328,16876549,151462017,33563273]

theorem envBound47784 : H12AffineFastState.Bounded env47784 := by
  intro p hp
  have h : env47784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47783_47784 : H12AffineEnvironment.transform 31 33641719 env47783 = env47784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 33641719 env47783 == env47784) = true)

def env47785 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,533640,672785,134217728,148800,545088,96347,16876545,618623,256,16876549,151462017,525825]

theorem envBound47785 : H12AffineFastState.Bounded env47785 := by
  intro p hp
  have h : env47785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47784_47785 : H12AffineEnvironment.transform 24 533640 env47784 = env47785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533640 env47784 == env47785) = true)

def env47786 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147520,16777216,533640,672785,17245632,148800,545088,96347,16876545,618623,256,16876549,1345,525825]

theorem envBound47786 : H12AffineFastState.Bounded env47786 := by
  intro p hp
  have h : env47786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47785_47786 : H12AffineEnvironment.transform 26 17245632 env47785 = env47786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env47785 == env47786) = true)

theorem identity47786 : scanCanonicalize (H12AffineFastState.compose env47786 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 74862) := by decide +kernel

theorem selectedBound47786 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env47787 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,524288,32769,4096,61649,91182,16777216,533640,614527,17039790,90414,545088,96347,16876545,618623,256,16876549,1345,525825]

theorem envBound47787 : H12AffineFastState.Bounded env47787 := by
  intro p hp
  have h : env47787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47786_47787 : H12AffineEnvironment.transform 16 74862 env47786 = env47787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 74862 env47786 == env47787) = true)

def env47788 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,524288,32769,4096,61649,91182,123164,533640,614527,385202,90414,545088,96347,25885,618623,256,25881,1345,525825]

theorem envBound47788 : H12AffineFastState.Bounded env47788 := by
  intro p hp
  have h : env47788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47787_47788 : H12AffineEnvironment.transform 23 123164 env47787 = env47788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123164 env47787 == env47788) = true)

def env47789 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,21584,32769,4096,61649,91182,123164,28888,78895,385202,90414,1296,96347,25885,74799,256,25881,1345,21073]

theorem envBound47789 : H12AffineFastState.Bounded env47789 := by
  intro p hp
  have h : env47789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47788_47789 : H12AffineEnvironment.transform 18 21584 env47788 = env47789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env47788 == env47789) = true)

theorem identity47789 : scanCanonicalize (H12AffineFastState.compose env47789 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound47789 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env47790 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,13341,65536,74862,262144,21584,13340,4096,17612,91182,87297,28888,78895,349359,90414,1296,96347,25885,74799,256,25881,1345,21073]

theorem envBound47790 : H12AffineFastState.Bounded env47790 := by
  intro p hp
  have h : env47790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47789_47790 : H12AffineEnvironment.transform 14 13341 env47789 = env47790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env47789 == env47790) = true)

def env47791 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74862,262144,4416,13340,4096,476,74046,69649,13768,78895,332223,74814,1296,81227,8205,74799,256,8201,1345,5953]

theorem envBound47791 : H12AffineFastState.Bounded env47791 := by
  intro p hp
  have h : env47791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47790_47791 : H12AffineEnvironment.transform 13 1296 env47790 = env47791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env47790 == env47791) = true)

def env47792 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74862,65664,4416,13340,4096,476,74046,69649,13768,78895,4415,74814,1296,81227,8205,74799,256,8201,1345,5953]

theorem envBound47792 : H12AffineFastState.Bounded env47792 := by
  intro p hp
  have h : env47792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47791_47792 : H12AffineEnvironment.transform 17 65664 env47791 = env47792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env47791 == env47792) = true)

theorem identity47792 : scanCanonicalize (H12AffineFastState.compose env47792 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9279) := by decide +kernel

theorem selectedBound47792 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env47793 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,9279,81,9407,4416,13340,4096,476,1281,13358,13768,4112,4415,1,1296,6516,8205,16,256,8201,1345,5953]

theorem envBound47793 : H12AffineFastState.Bounded env47793 := by
  intro p hp
  have h : env47793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47792_47793 : H12AffineEnvironment.transform 15 9279 env47792 = env47793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9279 env47792 == env47793) = true)

def env47794 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,0,12557,8495,81,8623,4416,12556,4096,476,17,12606,12504,4112,4415,1,0,6516,8205,16,256,8201,81,4689]

theorem envBound47794 : H12AffineFastState.Bounded env47794 := by
  intro p hp
  have h : env47794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47793_47794 : H12AffineEnvironment.transform 9 272 env47793 = env47794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env47793 == env47794) = true)

theorem identity47794 : scanCanonicalize (H12AffineFastState.compose env47794 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 73) := by decide +kernel

theorem selectedBound47794 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env47795 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,73,0,4420,358,81,486,4416,4421,4096,476,17,4471,4241,4112,4415,1,0,6516,68,16,256,64,81,4689]

theorem envBound47795 : H12AffineFastState.Bounded env47795 := by
  intro p hp
  have h : env47795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47794_47795 : H12AffineEnvironment.transform 12 73 env47794 = env47795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env47794 == env47795) = true)

theorem identity47795 : scanCanonicalize (H12AffineFastState.compose env47795 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(11+1) ^^^ 509) := by decide +kernel

theorem selectedBound47795 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env47796 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,509,73,0,185,358,81,486,189,184,509,476,17,138,364,493,194,1,0,2185,68,16,256,64,81,940]

theorem envBound47796 : H12AffineFastState.Bounded env47796 := by
  intro p hp
  have h : env47796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47795_47796 : H12AffineEnvironment.transform 11 509 env47795 = env47796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 509 env47795 == env47796) = true)

theorem identity47796 : scanCanonicalize (H12AffineFastState.compose env47796 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 372) := by decide +kernel

theorem selectedBound47796 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env47797 : List Nat := [2,4,8,16,32,64,128,256,372,272,2048,509,73,0,185,358,81,486,189,184,509,476,17,138,364,493,194,1,0,2185,68,16,256,64,81,216]

theorem envBound47797 : H12AffineFastState.Bounded env47797 := by
  intro p hp
  have h : env47797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47796_47797 : H12AffineEnvironment.transform 8 372 env47796 = env47797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 372 env47796 == env47797) = true)

theorem identity47797 : scanCanonicalize (H12AffineFastState.compose env47797 (packedSelected [0,2,3,7,8,10,13,16] rootPS)) = affineNative (2^(6+1) ^^^ 66) := by decide +kernel

theorem selectedBound47797 : packedSelected [0,2,3,7,8,10,13,16] rootPS < 2^1333 := by decide +kernel

def env47798 : List Nat := [2,4,8,16,32,64,66,256,372,272,2048,319,73,0,123,358,81,292,127,122,319,286,17,72,364,303,0,1,0,2123,68,16,256,64,81,26]

theorem envBound47798 : H12AffineFastState.Bounded env47798 := by
  intro p hp
  have h : env47798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47797_47798 : H12AffineEnvironment.transform 6 66 env47797 = env47798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 66 env47797 == env47798) = true)

theorem identity47798 : scanCanonicalize (H12AffineFastState.compose env47798 (packedSelected [0,3,4,7,8,9,12,13] rootPS)) = affineNative (2^(10+1) ^^^ 324) := by decide +kernel

theorem selectedBound47798 : packedSelected [0,3,4,7,8,9,12,13] rootPS < 2^1333 := by decide +kernel

def env47799 : List Nat := [2,4,8,16,32,64,66,256,372,272,324,319,73,0,123,358,81,292,127,122,319,286,17,72,364,303,0,1,0,271,68,16,256,64,81,26]

theorem envBound47799 : H12AffineFastState.Bounded env47799 := by
  intro p hp
  have h : env47799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47798_47799 : H12AffineEnvironment.transform 10 324 env47798 = env47799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 324 env47798 == env47799) = true)

theorem identity47799 : scanCanonicalize (H12AffineFastState.compose env47799 (packedSelected [2,3,7,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound47799 : packedSelected [2,3,7,8,9] rootPS < 2^1333 := by decide +kernel

def env47800 : List Nat := [2,4,8,16,32,64,66,116,0,100,48,75,73,0,123,18,81,80,127,122,75,106,17,72,24,91,0,1,0,123,68,16,116,64,81,26]

theorem envBound47800 : H12AffineFastState.Bounded env47800 := by
  intro p hp
  have h : env47800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47799_47800 : H12AffineEnvironment.transform 7 116 env47799 = env47800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env47799 == env47800) = true)

theorem identity47800 : scanCanonicalize (H12AffineFastState.compose env47800 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound47800 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env47801 : List Nat := [2,4,8,10,32,64,66,110,0,100,42,75,73,0,97,8,75,74,101,96,75,106,11,72,2,65,0,1,0,97,68,10,110,64,75,0]

theorem envBound47801 : H12AffineFastState.Bounded env47801 := by
  intro p hp
  have h : env47801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47800_47801 : H12AffineEnvironment.transform 3 10 env47800 = env47801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env47800 == env47801) = true)

theorem identity47801 : scanCanonicalize (H12AffineFastState.compose env47801 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound47801 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env47802 : List Nat := [2,4,8,10,32,10,8,36,0,46,42,1,3,0,43,8,1,0,47,42,1,32,11,2,2,11,0,1,0,43,14,10,36,10,1,0]

theorem envBound47802 : H12AffineFastState.Bounded env47802 := by
  intro p hp
  have h : env47802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47801_47802 : H12AffineEnvironment.transform 5 10 env47801 = env47802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env47801 == env47802) = true)

theorem identity47802 : scanCanonicalize (H12AffineFastState.compose env47802 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound47802 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47803 : List Nat := [2,4,8,10,12,10,8,8,0,2,6,1,3,0,7,8,1,0,3,6,1,12,11,2,2,11,0,1,0,7,14,10,8,10,1,0]

theorem envBound47803 : H12AffineFastState.Bounded env47803 := by
  intro p hp
  have h : env47803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47802_47803 : H12AffineEnvironment.transform 4 12 env47802 = env47803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env47802 == env47803) = true)

theorem identity47803 : scanCanonicalize (H12AffineFastState.compose env47803 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound47803 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47804 : List Nat := [2,3,8,10,11,10,8,8,0,2,1,1,3,0,0,8,1,0,3,1,1,11,11,2,2,11,0,1,0,0,9,10,8,10,1,0]

theorem envBound47804 : H12AffineFastState.Bounded env47804 := by
  intro p hp
  have h : env47804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47803_47804 : H12AffineEnvironment.transform 1 3 env47803 = env47804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env47803 == env47804) = true)

def env47805 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,1,12556,8494,81,8622,4416,12557,4096,476,16,12607,12505,4112,4415,1,1,6516,8205,16,256,8201,80,4688]

theorem envBound47805 : H12AffineFastState.Bounded env47805 := by
  intro p hp
  have h : env47805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47793_47805 : H12AffineEnvironment.transform 9 273 env47793 = env47805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env47793 == env47805) = true)

theorem identity47805 : scanCanonicalize (H12AffineFastState.compose env47805 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 4444) := by decide +kernel

theorem selectedBound47805 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env47806 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,4444,1,80,4210,81,4338,4416,81,4096,476,16,99,389,4112,4415,1,1,6516,4433,16,256,4437,80,4688]

theorem envBound47806 : H12AffineFastState.Bounded env47806 := by
  intro p hp
  have h : env47806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47805_47806 : H12AffineEnvironment.transform 12 4444 env47805 = env47806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4444 env47805 == env47806) = true)

theorem identity47806 : scanCanonicalize (H12AffineFastState.compose env47806 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound47806 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env47807 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,80,268,1,80,34,81,162,272,81,80,476,16,99,389,64,367,1,1,2340,257,16,256,261,80,512]

theorem envBound47807 : H12AffineFastState.Bounded env47807 := by
  intro p hp
  have h : env47807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47806_47807 : H12AffineEnvironment.transform 11 80 env47806 = env47807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env47806 == env47807) = true)

def env47808 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,65536,74862,65665,4416,13340,4096,476,74046,69649,13768,78895,4414,74814,1296,81227,8205,74799,256,8201,1345,5953]

theorem envBound47808 : H12AffineFastState.Bounded env47808 := by
  intro p hp
  have h : env47808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47791_47808 : H12AffineEnvironment.transform 17 65665 env47791 = env47808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env47791 == env47808) = true)

theorem identity47808 : scanCanonicalize (H12AffineFastState.compose env47808 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12671) := by decide +kernel

theorem selectedBound47808 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env47809 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,13341,12671,5393,12798,4416,13340,4096,476,4161,8558,13768,1360,4414,5441,1296,3124,8205,5456,256,8201,1345,5953]

theorem envBound47809 : H12AffineFastState.Bounded env47809 := by
  intro p hp
  have h : env47809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47808_47809 : H12AffineEnvironment.transform 15 12671 env47808 = env47809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12671 env47808 == env47809) = true)

def env47810 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1296,9293,8495,1345,8622,272,9292,80,476,17,8558,9624,1360,366,1297,1296,3124,8205,1280,256,8201,1345,1809]

theorem envBound47810 : H12AffineFastState.Bounded env47810 := by
  intro p hp
  have h : env47810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47809_47810 : H12AffineEnvironment.transform 11 80 env47809 = env47810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env47809 == env47810) = true)

theorem identity47810 : scanCanonicalize (H12AffineFastState.compose env47810 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 1369) := by decide +kernel

theorem selectedBound47810 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env47811 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,1369,1296,276,1142,1345,1271,272,277,80,476,17,1079,193,1360,366,1297,1296,3124,1364,1280,256,1360,1345,1809]

theorem envBound47811 : H12AffineFastState.Bounded env47811 := by
  intro p hp
  have h : env47811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47810_47811 : H12AffineEnvironment.transform 12 1369 env47810 = env47811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1369 env47810 == env47811) = true)

theorem identity47811 : scanCanonicalize (H12AffineFastState.compose env47811 (packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound47811 : packedSelected [1,5,8,13,16,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env47812 : List Nat := [2,4,8,16,32,64,128,256,512,189,2048,80,484,429,276,203,508,74,272,277,80,476,17,138,193,493,366,428,429,2185,489,445,256,493,508,940]

theorem envBound47812 : H12AffineFastState.Bounded env47812 := by
  intro p hp
  have h : env47812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47811_47812 : H12AffineEnvironment.transform 9 189 env47811 = env47812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env47811 == env47812) = true)

theorem identity47812 : scanCanonicalize (H12AffineFastState.compose env47812 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS)) = affineNative (2^(8+1) ^^^ 372) := by decide +kernel

theorem selectedBound47812 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env47813 : List Nat := [2,4,8,16,32,64,128,256,372,189,2048,80,484,429,276,203,508,74,272,277,80,476,17,138,193,493,366,428,429,2185,489,445,256,493,508,216]

theorem envBound47813 : H12AffineFastState.Bounded env47813 := by
  intro p hp
  have h : env47813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47812_47813 : H12AffineEnvironment.transform 8 372 env47812 = env47813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 372 env47812 == env47813) = true)

theorem identity47813 : scanCanonicalize (H12AffineFastState.compose env47813 (packedSelected [0,2,3,7,8,10,13,16] rootPS)) = affineNative (2^(7+1) ^^^ 111) := by decide +kernel

theorem selectedBound47813 : packedSelected [0,2,3,7,8,10,13,16] rootPS < 2^1333 := by decide +kernel

def env47814 : List Nat := [2,4,8,16,32,64,128,111,27,189,2048,80,139,194,123,203,147,74,127,122,80,179,17,138,193,130,1,195,194,2185,134,210,111,130,147,216]

theorem envBound47814 : H12AffineFastState.Bounded env47814 := by
  intro p hp
  have h : env47814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47813_47814 : H12AffineEnvironment.transform 7 111 env47813 = env47814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 111 env47813 == env47814) = true)

theorem identity47814 : scanCanonicalize (H12AffineFastState.compose env47814 (packedSelected [0,2,4,7,9,12] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound47814 : packedSelected [0,2,4,7,9,12] rootPS < 2^1333 := by decide +kernel

def env47815 : List Nat := [2,4,8,16,32,64,128,111,27,189,0,80,139,194,123,203,147,74,127,122,80,179,17,138,193,130,1,195,194,137,134,210,111,130,147,216]

theorem envBound47815 : H12AffineFastState.Bounded env47815 := by
  intro p hp
  have h : env47815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47814_47815 : H12AffineEnvironment.transform 10 0 env47814 = env47815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env47814 == env47815) = true)

theorem identity47815 : scanCanonicalize (H12AffineFastState.compose env47815 (packedSelected [1,3,4,9] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound47815 : packedSelected [1,3,4,9] rootPS < 2^1333 := by decide +kernel

def env47816 : List Nat := [2,4,8,16,32,64,18,111,27,47,0,80,25,80,123,89,1,74,127,122,80,33,17,24,83,16,1,81,80,27,20,64,111,16,1,74]

theorem envBound47816 : H12AffineFastState.Bounded env47816 := by
  intro p hp
  have h : env47816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47815_47816 : H12AffineEnvironment.transform 6 18 env47815 = env47816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env47815 == env47816) = true)

theorem identity47816 : scanCanonicalize (H12AffineFastState.compose env47816 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 29) := by decide +kernel

theorem selectedBound47816 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env47817 : List Nat := [2,4,8,16,29,64,18,82,27,18,0,80,25,80,70,89,1,74,66,71,80,28,17,24,83,16,1,81,80,27,20,64,82,16,1,74]

theorem envBound47817 : H12AffineFastState.Bounded env47817 := by
  intro p hp
  have h : env47817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47816_47817 : H12AffineEnvironment.transform 4 29 env47816 = env47817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env47816 == env47817) = true)

theorem identity47817 : scanCanonicalize (H12AffineFastState.compose env47817 (packedSelected [2,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 6) := by decide +kernel

theorem selectedBound47817 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env47818 : List Nat := [2,4,8,16,29,6,18,20,27,18,0,22,25,22,0,31,1,12,4,1,22,28,17,24,21,16,1,23,22,27,20,6,20,16,1,12]

theorem envBound47818 : H12AffineFastState.Bounded env47818 := by
  intro p hp
  have h : env47818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47817_47818 : H12AffineEnvironment.transform 5 6 env47817 = env47818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 6 env47817 == env47818) = true)

theorem identity47818 : scanCanonicalize (H12AffineFastState.compose env47818 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound47818 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47819 : List Nat := [2,4,8,7,10,6,5,3,12,5,0,1,14,1,0,8,1,12,4,1,1,11,6,15,2,7,1,0,1,12,3,6,3,7,1,12]

theorem envBound47819 : H12AffineFastState.Bounded env47819 := by
  intro p hp
  have h : env47819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47818_47819 : H12AffineEnvironment.transform 3 7 env47818 = env47819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env47818 == env47819) = true)

theorem identity47819 : scanCanonicalize (H12AffineFastState.compose env47819 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound47819 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47820 : List Nat := [2,4,5,7,7,6,5,3,1,5,0,1,3,1,0,5,1,1,4,1,1,6,6,2,2,7,1,0,1,1,3,6,3,7,1,1]

theorem envBound47820 : H12AffineFastState.Bounded env47820 := by
  intro p hp
  have h : env47820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47819_47820 : H12AffineEnvironment.transform 2 5 env47819 = env47820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env47819 == env47820) = true)

def env47821 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1296,9292,8494,1344,8623,273,9293,81,476,16,8558,9625,1360,367,1296,1296,3124,8205,1281,256,8201,1345,1808]

theorem envBound47821 : H12AffineFastState.Bounded env47821 := by
  intro p hp
  have h : env47821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47809_47821 : H12AffineEnvironment.transform 11 81 env47809 = env47821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env47809 == env47821) = true)

theorem identity47821 : scanCanonicalize (H12AffineFastState.compose env47821 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound47821 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env47822 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,1052,1296,80,1330,1344,1459,273,81,81,476,16,1394,389,1360,367,1296,1296,3124,1041,1281,256,1045,1345,1808]

theorem envBound47822 : H12AffineFastState.Bounded env47822 := by
  intro p hp
  have h : env47822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47821_47822 : H12AffineEnvironment.transform 12 1052 env47821 = env47822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env47821 == env47822) = true)

theorem identity47822 : scanCanonicalize (H12AffineFastState.compose env47822 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound47822 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env47823 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,81,268,0,80,34,80,163,273,81,81,476,16,98,389,64,367,0,0,2340,257,17,256,261,81,512]

theorem envBound47823 : H12AffineFastState.Bounded env47823 := by
  intro p hp
  have h : env47823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47822_47823 : H12AffineEnvironment.transform 9 272 env47822 = env47823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env47822 == env47823) = true)

theorem identity47823 : scanCanonicalize (H12AffineFastState.compose env47823 (packedSelected [2,5,8,13] rootPS)) = affineNative (2^(6+1) ^^^ 104) := by decide +kernel

theorem selectedBound47823 : packedSelected [2,5,8,13] rootPS < 2^1333 := by decide +kernel

def env47824 : List Nat := [2,4,8,16,32,64,104,256,512,272,2048,81,268,0,80,34,80,75,273,81,81,308,16,98,365,64,367,0,0,2340,257,17,256,261,81,512]

theorem envBound47824 : H12AffineFastState.Bounded env47824 := by
  intro p hp
  have h : env47824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47823_47824 : H12AffineEnvironment.transform 6 104 env47823 = env47824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 104 env47823 == env47824) = true)

theorem identity47824 : scanCanonicalize (H12AffineFastState.compose env47824 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 862) := by decide +kernel

theorem selectedBound47824 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env47825 : List Nat := [2,4,8,16,32,64,104,256,512,272,862,81,268,0,80,34,80,75,273,81,81,308,16,98,365,64,367,0,0,634,257,17,256,261,81,512]

theorem envBound47825 : H12AffineFastState.Bounded env47825 := by
  intro p hp
  have h : env47825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47824_47825 : H12AffineEnvironment.transform 10 862 env47824 = env47825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 862 env47824 == env47825) = true)

theorem identity47825 : scanCanonicalize (H12AffineFastState.compose env47825 (packedSelected [0,7,10,11,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound47825 : packedSelected [0,7,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env47826 : List Nat := [2,4,8,16,32,17,57,256,512,272,783,0,268,0,1,34,1,26,273,0,0,308,16,51,316,17,318,0,0,555,257,17,256,261,0,512]

theorem envBound47826 : H12AffineFastState.Bounded env47826 := by
  intro p hp
  have h : env47826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47825_47826 : H12AffineEnvironment.transform 5 17 env47825 = env47826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47825 == env47826) = true)

theorem identity47826 : scanCanonicalize (H12AffineFastState.compose env47826 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound47826 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47827 : List Nat := [2,4,8,16,32,17,57,62,512,46,561,0,50,0,1,34,1,26,47,0,0,10,16,51,2,17,0,0,0,555,63,17,62,59,0,512]

theorem envBound47827 : H12AffineFastState.Bounded env47827 := by
  intro p hp
  have h : env47827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47826_47827 : H12AffineEnvironment.transform 7 62 env47826 = env47827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env47826 == env47827) = true)

theorem identity47827 : scanCanonicalize (H12AffineFastState.compose env47827 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound47827 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env47828 : List Nat := [2,4,8,16,32,17,57,62,27,46,42,0,50,0,1,34,1,26,47,0,0,10,16,51,2,17,0,0,0,48,63,17,62,59,0,27]

theorem envBound47828 : H12AffineFastState.Bounded env47828 := by
  intro p hp
  have h : env47828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47827_47828 : H12AffineEnvironment.transform 8 27 env47827 = env47828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env47827 == env47828) = true)

theorem identity47828 : scanCanonicalize (H12AffineFastState.compose env47828 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound47828 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env47829 : List Nat := [2,4,8,11,32,10,34,37,0,46,42,0,41,0,1,34,1,1,47,0,0,10,11,40,2,10,0,0,0,43,36,10,37,32,0,0]

theorem envBound47829 : H12AffineFastState.Bounded env47829 := by
  intro p hp
  have h : env47829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47828_47829 : H12AffineEnvironment.transform 3 11 env47828 = env47829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env47828 == env47829) = true)

theorem identity47829 : scanCanonicalize (H12AffineFastState.compose env47829 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound47829 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env47830 : List Nat := [2,4,8,11,10,10,8,15,0,4,0,0,3,0,1,8,1,1,5,0,0,10,11,2,2,10,0,0,0,1,14,10,15,10,0,0]

theorem envBound47830 : H12AffineFastState.Bounded env47830 := by
  intro p hp
  have h : env47830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47829_47830 : H12AffineEnvironment.transform 4 10 env47829 = env47830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env47829 == env47830) = true)

theorem identity47830 : scanCanonicalize (H12AffineFastState.compose env47830 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound47830 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47831 : List Nat := [2,2,8,11,10,10,8,9,0,2,0,0,3,0,1,8,1,1,3,0,0,10,11,2,2,10,0,0,0,1,8,10,9,10,0,0]

theorem envBound47831 : H12AffineFastState.Bounded env47831 := by
  intro p hp
  have h : env47831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47830_47831 : H12AffineEnvironment.transform 1 2 env47830 = env47831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env47830 == env47831) = true)

def env47832 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74862,262144,4417,13340,4096,477,74047,69648,13769,78895,332222,74815,1296,81226,8204,74799,256,8200,1345,5952]

theorem envBound47832 : H12AffineFastState.Bounded env47832 := by
  intro p hp
  have h : env47832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47790_47832 : H12AffineEnvironment.transform 13 1297 env47790 = env47832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env47790 == env47832) = true)

def env47833 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74862,65664,4417,13340,4096,477,74047,69648,13769,78895,4414,74815,1296,81226,8204,74799,256,8200,1345,5952]

theorem envBound47833 : H12AffineFastState.Bounded env47833 := by
  intro p hp
  have h : env47833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47832_47833 : H12AffineEnvironment.transform 17 65664 env47832 = env47833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env47832 == env47833) = true)

theorem identity47833 : scanCanonicalize (H12AffineFastState.compose env47833 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5239) := by decide +kernel

theorem selectedBound47833 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env47834 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,5239,12313,5367,4417,13340,4096,477,13640,1127,13769,8280,4414,12360,1296,10557,8204,12376,256,8200,1345,5952]

theorem envBound47834 : H12AffineFastState.Bounded env47834 := by
  intro p hp
  have h : env47834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47833_47834 : H12AffineEnvironment.transform 15 5239 env47833 = env47834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5239 env47833 == env47834) = true)

def env47835 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1297,9293,1063,8265,1191,273,9292,80,477,9496,1127,9625,8280,366,8216,1296,10557,8204,8200,256,8200,1345,1808]

theorem envBound47835 : H12AffineFastState.Bounded env47835 := by
  intro p hp
  have h : env47835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47834_47835 : H12AffineEnvironment.transform 11 80 env47834 = env47835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env47834 == env47835) = true)

theorem identity47835 : scanCanonicalize (H12AffineFastState.compose env47835 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 1368) := by decide +kernel

theorem selectedBound47835 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env47836 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,1368,1297,277,1063,1297,1191,273,276,80,477,64,1127,193,1280,366,1344,1296,3173,1364,1360,256,1360,1345,1808]

theorem envBound47836 : H12AffineFastState.Bounded env47836 := by
  intro p hp
  have h : env47836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47835_47836 : H12AffineEnvironment.transform 12 1368 env47835 = env47836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1368 env47835 == env47836) = true)

theorem identity47836 : scanCanonicalize (H12AffineFastState.compose env47836 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound47836 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env47837 : List Nat := [2,4,8,16,32,64,128,69,512,1024,2048,80,1053,1108,80,1063,1108,1191,84,81,80,152,64,1127,193,1093,43,1029,1109,3173,1041,1045,69,1045,1028,1621]

theorem envBound47837 : H12AffineFastState.Bounded env47837 := by
  intro p hp
  have h : env47837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47836_47837 : H12AffineEnvironment.transform 7 69 env47836 = env47837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env47836 == env47837) = true)

theorem identity47837 : scanCanonicalize (H12AffineFastState.compose env47837 (packedSelected [0,1,2,5,7,8,11,13,17] rootPS)) = affineNative (2^(9+1) ^^^ 536) := by decide +kernel

theorem selectedBound47837 : packedSelected [0,1,2,5,7,8,11,13,17] rootPS < 2^1333 := by decide +kernel

def env47838 : List Nat := [2,4,8,16,32,64,128,69,512,536,2048,80,517,588,80,575,588,703,84,81,80,152,64,639,193,605,43,541,589,2685,521,525,69,525,540,77]

theorem envBound47838 : H12AffineFastState.Bounded env47838 := by
  intro p hp
  have h : env47838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47837_47838 : H12AffineEnvironment.transform 9 536 env47837 = env47838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 536 env47837 == env47838) = true)

theorem identity47838 : scanCanonicalize (H12AffineFastState.compose env47838 (packedSelected [13,21] rootPS)) = affineNative (2^(8+1) ^^^ 77) := by decide +kernel

theorem selectedBound47838 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env47839 : List Nat := [2,4,8,16,32,64,128,69,77,85,2048,80,72,1,80,114,1,242,84,81,80,152,64,50,193,16,43,80,0,2096,68,64,69,64,81,77]

theorem envBound47839 : H12AffineFastState.Bounded env47839 := by
  intro p hp
  have h : env47839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47838_47839 : H12AffineEnvironment.transform 8 77 env47838 = env47839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 77 env47838 == env47839) = true)

theorem identity47839 : scanCanonicalize (H12AffineFastState.compose env47839 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound47839 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env47840 : List Nat := [2,4,8,16,32,64,128,69,77,85,49,80,72,1,80,114,1,242,84,81,80,152,64,50,193,16,43,80,0,1,68,64,69,64,81,77]

theorem envBound47840 : H12AffineFastState.Bounded env47840 := by
  intro p hp
  have h : env47840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47839_47840 : H12AffineEnvironment.transform 10 49 env47839 = env47840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env47839 == env47840) = true)

theorem identity47840 : scanCanonicalize (H12AffineFastState.compose env47840 (packedSelected [0,2,3,8] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound47840 : packedSelected [0,2,3,8] rootPS < 2^1333 := by decide +kernel

def env47841 : List Nat := [2,4,8,16,32,64,89,69,77,85,49,80,72,1,80,114,1,43,84,81,80,65,64,50,24,16,43,80,0,1,68,64,69,64,81,77]

theorem envBound47841 : H12AffineFastState.Bounded env47841 := by
  intro p hp
  have h : env47841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47840_47841 : H12AffineEnvironment.transform 6 89 env47840 = env47841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env47840 == env47841) = true)

theorem identity47841 : scanCanonicalize (H12AffineFastState.compose env47841 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 12) := by decide +kernel

theorem selectedBound47841 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47842 : List Nat := [2,4,8,16,32,12,21,9,1,25,49,28,4,1,28,62,1,43,24,29,28,13,12,50,24,16,43,28,0,1,8,12,9,12,29,1]

theorem envBound47842 : H12AffineFastState.Bounded env47842 := by
  intro p hp
  have h : env47842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47841_47842 : H12AffineEnvironment.transform 5 12 env47841 = env47842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 12 env47841 == env47842) = true)

theorem identity47842 : scanCanonicalize (H12AffineFastState.compose env47842 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound47842 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47843 : List Nat := [2,4,8,16,13,12,21,9,1,25,28,28,4,1,28,19,1,6,24,29,28,13,12,31,24,16,6,28,0,1,8,12,9,12,29,1]

theorem envBound47843 : H12AffineFastState.Bounded env47843 := by
  intro p hp
  have h : env47843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47842_47843 : H12AffineEnvironment.transform 4 13 env47842 = env47843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env47842 == env47843) = true)

theorem identity47843 : scanCanonicalize (H12AffineFastState.compose env47843 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound47843 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47844 : List Nat := [2,4,8,10,13,12,15,9,1,3,6,6,4,1,6,9,1,6,2,7,6,13,12,5,2,10,6,6,0,1,8,12,9,12,7,1]

theorem envBound47844 : H12AffineFastState.Bounded env47844 := by
  intro p hp
  have h : env47844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47843_47844 : H12AffineEnvironment.transform 3 10 env47843 = env47844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env47843 == env47844) = true)

theorem identity47844 : scanCanonicalize (H12AffineFastState.compose env47844 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound47844 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env47845 : List Nat := [2,3,8,10,10,11,8,9,1,3,1,1,3,1,1,9,1,1,2,0,1,10,11,2,2,10,1,1,0,1,8,11,9,11,0,1]

theorem envBound47845 : H12AffineFastState.Bounded env47845 := by
  intro p hp
  have h : env47845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47844_47845 : H12AffineEnvironment.transform 1 3 env47844 = env47845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env47844 == env47845) = true)

def env47846 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1297,9292,1062,8264,1190,272,9293,81,477,9497,1127,9624,8280,367,8217,1296,10557,8204,8201,256,8200,1345,1809]

theorem envBound47846 : H12AffineFastState.Bounded env47846 := by
  intro p hp
  have h : env47846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47834_47846 : H12AffineEnvironment.transform 11 81 env47834 = env47846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env47834 == env47846) = true)

theorem identity47846 : scanCanonicalize (H12AffineFastState.compose env47846 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound47846 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env47847 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,1052,1297,80,1062,1108,1190,272,81,81,477,261,1127,388,1092,367,1029,1296,3361,1040,1045,256,1044,1345,1809]

theorem envBound47847 : H12AffineFastState.Bounded env47847 := by
  intro p hp
  have h : env47847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47846_47847 : H12AffineEnvironment.transform 12 1052 env47846 = env47847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env47846 == env47847) = true)

theorem identity47847 : scanCanonicalize (H12AffineFastState.compose env47847 (packedSelected [0,3,4,5,7,9,10,12,13,15,18,23] rootPS)) = affineNative (2^(9+1) ^^^ 425) := by decide +kernel

theorem selectedBound47847 : packedSelected [0,3,4,5,7,9,10,12,13,15,18,23] rootPS < 2^1333 := by decide +kernel

def env47848 : List Nat := [2,4,8,16,32,64,128,256,512,425,2048,81,437,184,80,399,509,271,272,81,81,477,261,462,388,493,367,428,185,2184,441,444,256,445,232,696]

theorem envBound47848 : H12AffineFastState.Bounded env47848 := by
  intro p hp
  have h : env47848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47847_47848 : H12AffineEnvironment.transform 9 425 env47847 = env47848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 425 env47847 == env47848) = true)

theorem identity47848 : scanCanonicalize (H12AffineFastState.compose env47848 (packedSelected [1,3,4,8,9,10,12,15,17,18] rootPS)) = affineNative (2^(10+1) ^^^ 174) := by decide +kernel

theorem selectedBound47848 : packedSelected [1,3,4,8,9,10,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env47849 : List Nat := [2,4,8,16,32,64,128,256,512,425,174,81,437,184,80,399,509,271,272,81,81,477,261,462,388,493,367,428,185,38,441,444,256,445,232,696]

theorem envBound47849 : H12AffineFastState.Bounded env47849 := by
  intro p hp
  have h : env47849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47848_47849 : H12AffineEnvironment.transform 10 174 env47848 = env47849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 174 env47848 == env47849) = true)

theorem identity47849 : scanCanonicalize (H12AffineFastState.compose env47849 (packedSelected [0,1,7,8,12,15,16,17,19] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound47849 : packedSelected [0,1,7,8,12,15,16,17,19] rootPS < 2^1333 := by decide +kernel

def env47850 : List Nat := [2,4,8,16,32,64,56,256,512,273,22,81,269,0,80,311,325,271,272,81,81,357,261,374,316,341,367,276,1,38,257,260,256,261,80,512]

theorem envBound47850 : H12AffineFastState.Bounded env47850 := by
  intro p hp
  have h : env47850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47849_47850 : H12AffineEnvironment.transform 6 56 env47849 = env47850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env47849 == env47850) = true)

theorem identity47850 : scanCanonicalize (H12AffineFastState.compose env47850 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 97) := by decide +kernel

theorem selectedBound47850 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env47851 : List Nat := [2,4,8,16,32,64,56,256,97,273,22,81,269,0,80,311,325,271,272,81,81,357,261,374,316,341,367,276,1,38,257,260,256,261,80,97]

theorem envBound47851 : H12AffineFastState.Bounded env47851 := by
  intro p hp
  have h : env47851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47850_47851 : H12AffineEnvironment.transform 8 97 env47850 = env47851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env47850 == env47851) = true)

theorem identity47851 : scanCanonicalize (H12AffineFastState.compose env47851 (packedSelected [0,1,2,5,7,8,11] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound47851 : packedSelected [0,1,2,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env47852 : List Nat := [2,4,8,16,28,64,4,256,93,273,22,81,269,0,80,267,325,271,272,81,81,345,261,330,256,341,339,276,1,26,257,260,256,261,80,93]

theorem envBound47852 : H12AffineFastState.Bounded env47852 := by
  intro p hp
  have h : env47852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47851_47852 : H12AffineEnvironment.transform 4 28 env47851 = env47852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env47851 == env47852) = true)

theorem identity47852 : scanCanonicalize (H12AffineFastState.compose env47852 (packedSelected [1,2,4,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound47852 : packedSelected [1,2,4,7] rootPS < 2^1333 := by decide +kernel

def env47853 : List Nat := [2,4,8,16,28,17,4,256,12,273,22,0,269,0,1,267,276,271,272,0,0,264,261,283,256,260,258,276,1,26,257,260,256,261,1,12]

theorem envBound47853 : H12AffineFastState.Bounded env47853 := by
  intro p hp
  have h : env47853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47852_47853 : H12AffineEnvironment.transform 5 17 env47852 = env47853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47852 == env47853) = true)

theorem identity47853 : scanCanonicalize (H12AffineFastState.compose env47853 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound47853 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47854 : List Nat := [2,4,8,16,28,17,4,15,12,30,22,0,2,0,1,4,27,0,31,0,0,7,10,20,15,11,13,27,1,26,14,11,15,10,1,12]

theorem envBound47854 : H12AffineFastState.Bounded env47854 := by
  intro p hp
  have h : env47854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47853_47854 : H12AffineEnvironment.transform 7 15 env47853 = env47854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env47853 == env47854) = true)

theorem identity47854 : scanCanonicalize (H12AffineFastState.compose env47854 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound47854 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47855 : List Nat := [2,4,5,16,17,17,4,2,1,19,22,0,2,0,1,4,22,0,18,0,0,7,7,20,2,6,0,22,1,23,3,6,2,7,1,1]

theorem envBound47855 : H12AffineFastState.Bounded env47855 := by
  intro p hp
  have h : env47855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47854_47855 : H12AffineEnvironment.transform 2 5 env47854 = env47855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env47854 == env47855) = true)

def env47856 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74862,65665,4417,13340,4096,477,74047,69648,13769,78895,4415,74815,1296,81226,8204,74799,256,8200,1345,5952]

theorem envBound47856 : H12AffineFastState.Bounded env47856 := by
  intro p hp
  have h : env47856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47832_47856 : H12AffineEnvironment.transform 17 65665 env47832 = env47856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env47832 == env47856) = true)

theorem identity47856 : scanCanonicalize (H12AffineFastState.compose env47856 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 310) := by decide +kernel

theorem selectedBound47856 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env47857 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,310,9560,439,4417,13340,4096,477,8201,4390,13769,13593,4415,9481,1296,15484,8204,9497,256,8200,1345,5952]

theorem envBound47857 : H12AffineFastState.Bounded env47857 := by
  intro p hp
  have h : env47857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47856_47857 : H12AffineEnvironment.transform 15 310 env47856 = env47857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 310 env47856 == env47857) = true)

def env47858 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,1,12557,310,8264,439,4417,12556,4096,477,8201,4390,12505,12297,4415,8217,0,14700,8204,8201,256,8200,81,4688]

theorem envBound47858 : H12AffineFastState.Bounded env47858 := by
  intro p hp
  have h : env47858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47857_47858 : H12AffineEnvironment.transform 9 272 env47857 = env47858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env47857 == env47858) = true)

theorem identity47858 : scanCanonicalize (H12AffineFastState.compose env47858 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 4445) := by decide +kernel

theorem selectedBound47858 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env47859 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,4445,1,80,310,4373,439,4417,81,4096,477,4436,4390,388,340,4415,4420,0,2097,4433,4436,256,4437,81,4688]

theorem envBound47859 : H12AffineFastState.Bounded env47859 := by
  intro p hp
  have h : env47859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47858_47859 : H12AffineEnvironment.transform 12 4445 env47858 = env47859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4445 env47858 == env47859) = true)

theorem identity47859 : scanCanonicalize (H12AffineFastState.compose env47859 (packedSelected [0,1,4,7,8,9,12,13,15,18,19,23] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound47859 : packedSelected [0,1,4,7,8,9,12,13,15,18,19,23] rootPS < 2^1333 := by decide +kernel

def env47860 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,184,485,1,80,310,429,439,505,81,184,477,492,414,388,340,391,508,0,2097,489,492,256,493,81,744]

theorem envBound47860 : H12AffineFastState.Bounded env47860 := by
  intro p hp
  have h : env47860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47859_47860 : H12AffineEnvironment.transform 11 184 env47859 = env47860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env47859 == env47860) = true)

theorem identity47860 : scanCanonicalize (H12AffineFastState.compose env47860 (packedSelected [0,1,2,5,7,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 818) := by decide +kernel

theorem selectedBound47860 : packedSelected [0,1,2,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env47861 : List Nat := [2,4,8,16,32,64,128,256,512,272,818,184,485,1,80,310,429,439,505,81,184,477,492,414,388,340,391,508,0,771,489,492,256,493,81,744]

theorem envBound47861 : H12AffineFastState.Bounded env47861 := by
  intro p hp
  have h : env47861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47860_47861 : H12AffineEnvironment.transform 10 818 env47860 = env47861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 818 env47860 == env47861) = true)

theorem identity47861 : scanCanonicalize (H12AffineFastState.compose env47861 (packedSelected [0,3,7,10,13,17,18,19] rootPS)) = affineNative (2^(5+1) ^^^ 45) := by decide +kernel

theorem selectedBound47861 : packedSelected [0,3,7,10,13,17,18,19] rootPS < 2^1333 := by decide +kernel

def env47862 : List Nat := [2,4,8,16,32,45,128,256,512,272,818,184,392,1,61,310,429,439,404,60,184,432,385,414,388,313,391,401,0,771,388,385,256,384,60,645]

theorem envBound47862 : H12AffineFastState.Bounded env47862 := by
  intro p hp
  have h : env47862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47861_47862 : H12AffineEnvironment.transform 5 45 env47861 = env47862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 45 env47861 == env47862) = true)

theorem identity47862 : scanCanonicalize (H12AffineFastState.compose env47862 (packedSelected [0,1,2,4,7,8,9,12,17] rootPS)) = affineNative (2^(7+1) ^^^ 134) := by decide +kernel

theorem selectedBound47862 : packedSelected [0,1,2,4,7,8,9,12,17] rootPS < 2^1333 := by decide +kernel

def env47863 : List Nat := [2,4,8,16,32,45,128,134,512,150,692,184,14,1,61,176,43,49,18,60,184,54,7,24,2,191,1,23,0,645,2,7,134,6,60,645]

theorem envBound47863 : H12AffineFastState.Bounded env47863 := by
  intro p hp
  have h : env47863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47862_47863 : H12AffineEnvironment.transform 7 134 env47862 = env47863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 134 env47862 == env47863) = true)

theorem identity47863 : scanCanonicalize (H12AffineFastState.compose env47863 (packedSelected [1,3,8,12,13,15] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound47863 : packedSelected [1,3,8,12,13,15] rootPS < 2^1333 := by decide +kernel

def env47864 : List Nat := [2,4,8,16,32,45,128,134,43,150,159,184,14,1,61,176,43,49,18,60,184,54,7,24,2,191,1,23,0,174,2,7,134,6,60,174]

theorem envBound47864 : H12AffineFastState.Bounded env47864 := by
  intro p hp
  have h : env47864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47863_47864 : H12AffineEnvironment.transform 8 43 env47863 = env47864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env47863 == env47864) = true)

theorem identity47864 : scanCanonicalize (H12AffineFastState.compose env47864 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound47864 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env47865 : List Nat := [2,4,8,16,28,17,128,134,23,150,159,132,14,1,1,140,23,13,18,0,132,10,7,24,2,131,1,23,0,146,2,7,134,6,0,146]

theorem envBound47865 : H12AffineFastState.Bounded env47865 := by
  intro p hp
  have h : env47865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47864_47865 : H12AffineEnvironment.transform 4 28 env47864 = env47865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env47864 == env47865) = true)

theorem identity47865 : scanCanonicalize (H12AffineFastState.compose env47865 (packedSelected [2,4,5,9] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound47865 : packedSelected [2,4,5,9] rootPS < 2^1333 := by decide +kernel

def env47866 : List Nat := [2,4,4,16,16,17,128,134,23,150,147,132,2,1,1,128,23,1,18,0,132,6,7,20,2,131,1,23,0,146,2,7,134,6,0,146]

theorem envBound47866 : H12AffineFastState.Bounded env47866 := by
  intro p hp
  have h : env47866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47865_47866 : H12AffineEnvironment.transform 2 4 env47865 = env47866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env47865 == env47866) = true)

theorem identity47866 : scanCanonicalize (H12AffineFastState.compose env47866 (packedSelected [1,2] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound47866 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env47867 : List Nat := [2,4,4,6,6,7,128,134,1,128,133,132,2,1,1,128,1,1,4,0,132,6,7,2,2,131,1,1,0,132,2,7,134,6,0,132]

theorem envBound47867 : H12AffineFastState.Bounded env47867 := by
  intro p hp
  have h : env47867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47866_47867 : H12AffineEnvironment.transform 3 6 env47866 = env47867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env47866 == env47867) = true)

theorem identity47867 : scanCanonicalize (H12AffineFastState.compose env47867 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound47867 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47868 : List Nat := [2,4,4,6,6,7,4,2,1,4,1,0,2,1,1,4,1,1,4,0,0,6,7,2,2,7,1,1,0,0,2,7,2,6,0,0]

theorem envBound47868 : H12AffineFastState.Bounded env47868 := by
  intro p hp
  have h : env47868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47867_47868 : H12AffineEnvironment.transform 6 4 env47867 = env47868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env47867 == env47868) = true)

theorem identity47868 : scanCanonicalize (H12AffineFastState.compose env47868 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound47868 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47869 : List Nat := [2,1,1,3,3,2,1,2,1,1,1,0,2,1,1,1,1,1,1,0,0,3,2,2,2,2,1,1,0,0,2,2,2,3,0,0]

theorem envBound47869 : H12AffineFastState.Bounded env47869 := by
  intro p hp
  have h : env47869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47868_47869 : H12AffineEnvironment.transform 1 1 env47868 = env47869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env47868 == env47869) = true)

theorem identity47869 : scanCanonicalize (H12AffineFastState.compose env47869 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound47869 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env47870 : List Nat := [1,1,1,0,0,1,1,1,1,1,1,0,1,1,1,1,1,1,1,0,0,0,1,1,1,1,1,1,0,0,1,1,1,0,0,0]

theorem envBound47870 : H12AffineFastState.Bounded env47870 := by
  intro p hp
  have h : env47870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47869_47870 : H12AffineEnvironment.transform 0 1 env47869 = env47870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env47869 == env47870) = true)

def env47871 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,0,12556,310,8265,439,4417,12557,4096,477,8201,4390,12504,12296,4415,8216,1,14701,8204,8200,256,8200,80,4689]

theorem envBound47871 : H12AffineFastState.Bounded env47871 := by
  intro p hp
  have h : env47871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47857_47871 : H12AffineEnvironment.transform 9 273 env47857 = env47871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env47857 == env47871) = true)

theorem identity47871 : scanCanonicalize (H12AffineFastState.compose env47871 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 73) := by decide +kernel

theorem selectedBound47871 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env47872 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,73,0,4421,310,0,439,4417,4420,4096,477,64,4390,4241,4161,4415,81,1,6436,69,65,256,65,80,4689]

theorem envBound47872 : H12AffineFastState.Bounded env47872 := by
  intro p hp
  have h : env47872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47871_47872 : H12AffineEnvironment.transform 12 73 env47871 = env47872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env47871 == env47872) = true)

theorem identity47872 : scanCanonicalize (H12AffineFastState.compose env47872 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound47872 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env47873 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,277,73,0,80,310,0,439,84,81,277,477,64,51,388,340,42,81,1,2097,69,65,256,65,80,836]

theorem envBound47873 : H12AffineFastState.Bounded env47873 := by
  intro p hp
  have h : env47873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47872_47873 : H12AffineEnvironment.transform 11 277 env47872 = env47873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env47872 == env47873) = true)

theorem identity47873 : scanCanonicalize (H12AffineFastState.compose env47873 (packedSelected [0,1,7,8,15,18,19] rootPS)) = affineNative (2^(10+1) ^^^ 412) := by decide +kernel

theorem selectedBound47873 : packedSelected [0,1,7,8,15,18,19] rootPS < 2^1333 := by decide +kernel

def env47874 : List Nat := [2,4,8,16,32,64,128,256,512,273,412,277,73,0,80,310,0,439,84,81,277,477,64,51,388,340,42,81,1,429,69,65,256,65,80,836]

theorem envBound47874 : H12AffineFastState.Bounded env47874 := by
  intro p hp
  have h : env47874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47873_47874 : H12AffineEnvironment.transform 10 412 env47873 = env47874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 412 env47873 == env47874) = true)

theorem identity47874 : scanCanonicalize (H12AffineFastState.compose env47874 (packedSelected [0,1,2,7,8,10,11,12,17] rootPS)) = affineNative (2^(8+1) ^^^ 391) := by decide +kernel

theorem selectedBound47874 : packedSelected [0,1,2,7,8,10,11,12,17] rootPS < 2^1333 := by decide +kernel

def env47875 : List Nat := [2,4,8,16,32,64,128,256,391,273,412,277,73,0,80,310,0,439,84,81,277,477,64,51,388,340,42,81,1,429,69,65,256,65,80,195]

theorem envBound47875 : H12AffineFastState.Bounded env47875 := by
  intro p hp
  have h : env47875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47874_47875 : H12AffineEnvironment.transform 8 391 env47874 = env47875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 391 env47874 == env47875) = true)

theorem identity47875 : scanCanonicalize (H12AffineFastState.compose env47875 (packedSelected [1,2,3,8] rootPS)) = affineNative (2^(6+1) ^^^ 110) := by decide +kernel

theorem selectedBound47875 : packedSelected [1,2,3,8] rootPS < 2^1333 := by decide +kernel

def env47876 : List Nat := [2,4,8,16,32,64,110,256,361,273,370,277,73,0,80,310,0,345,84,81,277,307,64,51,362,340,42,81,1,323,69,65,256,65,80,45]

theorem envBound47876 : H12AffineFastState.Bounded env47876 := by
  intro p hp
  have h : env47876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47875_47876 : H12AffineEnvironment.transform 6 110 env47875 = env47876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 110 env47875 == env47876) = true)

theorem identity47876 : scanCanonicalize (H12AffineFastState.compose env47876 (packedSelected [0,1,5,7,11,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 104) := by decide +kernel

theorem selectedBound47876 : packedSelected [0,1,5,7,11,12,15] rootPS < 2^1333 := by decide +kernel

def env47877 : List Nat := [2,4,8,16,32,64,110,104,1,121,26,125,73,0,80,94,0,49,84,81,125,91,64,51,2,60,42,81,1,43,69,65,104,65,80,45]

theorem envBound47877 : H12AffineFastState.Bounded env47877 := by
  intro p hp
  have h : env47877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47876_47877 : H12AffineEnvironment.transform 7 104 env47876 = env47877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 104 env47876 == env47877) = true)

theorem identity47877 : scanCanonicalize (H12AffineFastState.compose env47877 (packedSelected [0,2,3,5,9,10] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound47877 : packedSelected [0,2,3,5,9,10] rootPS < 2^1333 := by decide +kernel

def env47878 : List Nat := [2,2,8,16,32,64,104,104,1,121,26,123,73,0,80,88,0,49,82,81,123,91,64,51,2,58,42,81,1,43,67,65,104,65,80,43]

theorem envBound47878 : H12AffineFastState.Bounded env47878 := by
  intro p hp
  have h : env47878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47877_47878 : H12AffineEnvironment.transform 1 2 env47877 = env47878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env47877 == env47878) = true)

theorem identity47878 : scanCanonicalize (H12AffineFastState.compose env47878 (packedSelected [1,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound47878 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env47879 : List Nat := [2,2,8,16,32,10,34,34,1,51,26,49,3,0,26,18,0,49,24,27,49,17,10,51,2,58,42,27,1,43,9,11,34,11,26,43]

theorem envBound47879 : H12AffineFastState.Bounded env47879 := by
  intro p hp
  have h : env47879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47878_47879 : H12AffineEnvironment.transform 5 10 env47878 = env47879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env47878 == env47879) = true)

theorem identity47879 : scanCanonicalize (H12AffineFastState.compose env47879 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound47879 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47880 : List Nat := [2,2,8,10,32,10,34,34,1,41,0,43,3,0,0,8,0,43,2,1,43,11,10,41,2,32,42,1,1,43,9,11,34,11,0,43]

theorem envBound47880 : H12AffineFastState.Bounded env47880 := by
  intro p hp
  have h : env47880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47879_47880 : H12AffineEnvironment.transform 3 10 env47879 = env47880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env47879 == env47880) = true)

def env47881 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,21585,32769,4096,61649,91182,123164,28889,78894,385202,90414,1297,96347,25885,74798,256,25881,1345,21072]

theorem envBound47881 : H12AffineFastState.Bounded env47881 := by
  intro p hp
  have h : env47881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47788_47881 : H12AffineEnvironment.transform 18 21585 env47788 = env47881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21585 env47788 == env47881) = true)

theorem identity47881 : scanCanonicalize (H12AffineFastState.compose env47881 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25676) := by decide +kernel

theorem selectedBound47881 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env47882 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25676,65536,74862,262144,21585,25677,4096,5277,91182,66896,28889,78894,328958,90414,1297,96347,25885,74798,256,25881,1345,21072]

theorem envBound47882 : H12AffineFastState.Bounded env47882 := by
  intro p hp
  have h : env47882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47881_47882 : H12AffineEnvironment.transform 14 25676 env47881 = env47882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25676 env47881 == env47882) = true)

def env47883 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74862,262144,4417,8541,4096,5277,74046,66896,13769,78894,328958,74814,1297,81227,8205,74798,256,8201,1345,5952]

theorem envBound47883 : H12AffineFastState.Bounded env47883 := by
  intro p hp
  have h : env47883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47882_47883 : H12AffineEnvironment.transform 13 1296 env47882 = env47883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env47882 == env47883) = true)

def env47884 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74862,65664,4417,8541,4096,5277,74046,66896,13769,78894,1150,74814,1297,81227,8205,74798,256,8201,1345,5952]

theorem envBound47884 : H12AffineFastState.Bounded env47884 := by
  intro p hp
  have h : env47884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47883_47884 : H12AffineEnvironment.transform 17 65664 env47883 = env47884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env47883 == env47884) = true)

theorem identity47884 : scanCanonicalize (H12AffineFastState.compose env47884 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 12671) := by decide +kernel

theorem selectedBound47884 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env47885 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,12671,5393,12799,4417,8541,4096,5277,4161,13359,13769,1361,1150,5441,1297,3124,8205,5457,256,8201,1345,5952]

theorem envBound47885 : H12AffineFastState.Bounded env47885 := by
  intro p hp
  have h : env47885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47884_47885 : H12AffineEnvironment.transform 15 12671 env47884 = env47885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12671 env47884 == env47885) = true)

def env47886 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1296,8540,8495,1345,8623,273,8541,80,1229,17,9343,9625,1361,1150,1297,1297,3124,8205,1281,256,8201,1345,1808]

theorem envBound47886 : H12AffineFastState.Bounded env47886 := by
  intro p hp
  have h : env47886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47885_47886 : H12AffineEnvironment.transform 11 80 env47885 = env47886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env47885 == env47886) = true)

theorem identity47886 : scanCanonicalize (H12AffineFastState.compose env47886 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound47886 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env47887 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,1053,1296,1345,1330,1345,1458,273,1344,80,1229,17,98,388,1361,1150,1297,1297,3124,1040,1281,256,1044,1345,1808]

theorem envBound47887 : H12AffineFastState.Bounded env47887 := by
  intro p hp
  have h : env47887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47886_47887 : H12AffineEnvironment.transform 12 1053 env47886 = env47887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env47886 == env47887) = true)

theorem identity47887 : scanCanonicalize (H12AffineFastState.compose env47887 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound47887 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env47888 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,80,269,0,81,34,81,162,273,80,80,477,17,98,388,65,366,1,1,2340,256,17,256,260,81,512]

theorem envBound47888 : H12AffineFastState.Bounded env47888 := by
  intro p hp
  have h : env47888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47887_47888 : H12AffineEnvironment.transform 9 272 env47887 = env47888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env47887 == env47888) = true)

theorem identity47888 : scanCanonicalize (H12AffineFastState.compose env47888 (packedSelected [2,5,8,13] rootPS)) = affineNative (2^(10+1) ^^^ 366) := by decide +kernel

theorem selectedBound47888 : packedSelected [2,5,8,13] rootPS < 2^1333 := by decide +kernel

def env47889 : List Nat := [2,4,8,16,32,64,128,256,512,272,366,80,269,0,81,34,81,162,273,80,80,477,17,98,388,65,366,1,1,74,256,17,256,260,81,512]

theorem envBound47889 : H12AffineFastState.Bounded env47889 := by
  intro p hp
  have h : env47889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47888_47889 : H12AffineEnvironment.transform 10 366 env47888 = env47889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 366 env47888 == env47889) = true)

theorem identity47889 : scanCanonicalize (H12AffineFastState.compose env47889 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 97) := by decide +kernel

theorem selectedBound47889 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env47890 : List Nat := [2,4,8,16,32,64,128,256,97,272,366,80,269,0,81,34,81,162,273,80,80,477,17,98,388,65,366,1,1,74,256,17,256,260,81,97]

theorem envBound47890 : H12AffineFastState.Bounded env47890 := by
  intro p hp
  have h : env47890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47889_47890 : H12AffineEnvironment.transform 8 97 env47889 = env47890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env47889 == env47890) = true)

theorem identity47890 : scanCanonicalize (H12AffineFastState.compose env47890 (packedSelected [1,2,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound47890 : packedSelected [1,2,8,10] rootPS < 2^1333 := by decide +kernel

def env47891 : List Nat := [2,4,8,16,32,64,128,21,97,5,123,80,24,0,81,34,81,162,4,80,80,200,17,98,145,65,123,1,1,74,21,17,21,17,81,97]

theorem envBound47891 : H12AffineFastState.Bounded env47891 := by
  intro p hp
  have h : env47891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47890_47891 : H12AffineEnvironment.transform 7 21 env47890 = env47891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env47890 == env47891) = true)

theorem identity47891 : scanCanonicalize (H12AffineFastState.compose env47891 (packedSelected [2,5] rootPS)) = affineNative (2^(5+1) ^^^ 55) := by decide +kernel

theorem selectedBound47891 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env47892 : List Nat := [2,4,8,16,32,55,128,21,22,5,12,39,24,0,38,34,38,162,4,39,39,191,17,21,145,54,12,1,1,61,21,17,21,17,38,22]

theorem envBound47892 : H12AffineFastState.Bounded env47892 := by
  intro p hp
  have h : env47892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47891_47892 : H12AffineEnvironment.transform 5 55 env47891 = env47892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 55 env47891 == env47892) = true)

theorem identity47892 : scanCanonicalize (H12AffineFastState.compose env47892 (packedSelected [1,3,8] rootPS)) = affineNative (2^(6+1) ^^^ 31) := by decide +kernel

theorem selectedBound47892 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env47893 : List Nat := [2,4,8,16,32,55,31,21,22,5,12,39,24,0,38,34,38,61,4,39,39,32,17,21,14,54,12,1,1,61,21,17,21,17,38,22]

theorem envBound47893 : H12AffineFastState.Bounded env47893 := by
  intro p hp
  have h : env47893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47892_47893 : H12AffineEnvironment.transform 6 31 env47892 = env47893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 31 env47892 == env47893) = true)

theorem identity47893 : scanCanonicalize (H12AffineFastState.compose env47893 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound47893 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env47894 : List Nat := [2,4,8,16,28,11,31,21,22,5,12,27,24,0,26,30,26,1,4,27,27,28,17,21,14,10,12,1,1,1,21,17,21,17,26,22]

theorem envBound47894 : H12AffineFastState.Bounded env47894 := by
  intro p hp
  have h : env47894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47893_47894 : H12AffineEnvironment.transform 4 28 env47893 = env47894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env47893 == env47894) = true)

def env47895 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1296,8540,8494,1344,8622,272,8541,81,1228,16,9342,9624,1361,1150,1296,1297,3124,8205,1280,256,8201,1345,1809]

theorem envBound47895 : H12AffineFastState.Bounded env47895 := by
  intro p hp
  have h : env47895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47885_47895 : H12AffineEnvironment.transform 11 81 env47885 = env47895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env47885 == env47895) = true)

theorem identity47895 : scanCanonicalize (H12AffineFastState.compose env47895 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 73) := by decide +kernel

theorem selectedBound47895 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env47896 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,73,1296,277,359,1344,487,272,276,81,1228,16,1079,1489,1361,1150,1296,1297,3124,68,1280,256,64,1345,1809]

theorem envBound47896 : H12AffineFastState.Bounded env47896 := by
  intro p hp
  have h : env47896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47895_47896 : H12AffineEnvironment.transform 12 73 env47895 = env47896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env47895 == env47896) = true)

theorem identity47896 : scanCanonicalize (H12AffineFastState.compose env47896 (packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS)) = affineNative (2^(8+1) ^^^ 413) := by decide +kernel

theorem selectedBound47896 : packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS < 2^1333 := by decide +kernel

def env47897 : List Nat := [2,4,8,16,32,64,128,256,413,1024,2048,81,73,1296,277,359,1344,487,272,276,81,1228,16,1079,1489,1361,1150,1296,1297,3124,68,1280,256,64,1345,1164]

theorem envBound47897 : H12AffineFastState.Bounded env47897 := by
  intro p hp
  have h : env47897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47896_47897 : H12AffineEnvironment.transform 8 413 env47896 = env47897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 413 env47896 == env47897) = true)

theorem identity47897 : scanCanonicalize (H12AffineFastState.compose env47897 (packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound47897 : packedSelected [0,1,2,3,4,7,8,9,10,11,12,13,15,23,24] rootPS < 2^1333 := by decide +kernel

def env47898 : List Nat := [2,4,8,16,32,64,128,21,136,1024,2048,81,73,1029,0,114,1109,242,5,1,81,1228,16,1079,1220,1092,1150,1029,1028,3124,68,1045,21,64,1108,1164]

theorem envBound47898 : H12AffineFastState.Bounded env47898 := by
  intro p hp
  have h : env47898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47897_47898 : H12AffineEnvironment.transform 7 21 env47897 = env47898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env47897 == env47898) = true)

theorem identity47898 : scanCanonicalize (H12AffineFastState.compose env47898 (packedSelected [2,3,4,5,9,10,15,16,17] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound47898 : packedSelected [2,3,4,5,9,10,15,16,17] rootPS < 2^1333 := by decide +kernel

def env47899 : List Nat := [2,4,8,16,32,64,19,21,27,1024,2048,81,73,1029,0,114,1109,97,5,1,81,1119,16,1079,1111,1092,1150,1029,1028,3124,68,1045,21,64,1108,1055]

theorem envBound47899 : H12AffineFastState.Bounded env47899 := by
  intro p hp
  have h : env47899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47898_47899 : H12AffineEnvironment.transform 6 19 env47898 = env47899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env47898 == env47899) = true)

theorem identity47899 : scanCanonicalize (H12AffineFastState.compose env47899 (packedSelected [2,3,5,10,15] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound47899 : packedSelected [2,3,5,10,15] rootPS < 2^1333 := by decide +kernel

def env47900 : List Nat := [2,4,8,16,32,64,19,21,27,84,2048,81,73,81,0,114,1,97,5,1,81,11,16,99,3,16,42,81,80,2144,68,65,21,64,0,75]

theorem envBound47900 : H12AffineFastState.Bounded env47900 := by
  intro p hp
  have h : env47900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47899_47900 : H12AffineEnvironment.transform 9 84 env47899 = env47900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env47899 == env47900) = true)

theorem identity47900 : scanCanonicalize (H12AffineFastState.compose env47900 (packedSelected [2,3] rootPS)) = affineNative (2^(10+1) ^^^ 125) := by decide +kernel

theorem selectedBound47900 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env47901 : List Nat := [2,4,8,16,32,64,19,21,27,84,125,81,73,81,0,114,1,97,5,1,81,11,16,99,3,16,42,81,80,29,68,65,21,64,0,75]

theorem envBound47901 : H12AffineFastState.Bounded env47901 := by
  intro p hp
  have h : env47901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47900_47901 : H12AffineEnvironment.transform 10 125 env47900 = env47901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 125 env47900 == env47901) = true)

theorem identity47901 : scanCanonicalize (H12AffineFastState.compose env47901 (packedSelected [5] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound47901 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env47902 : List Nat := [2,4,8,16,32,10,19,21,27,30,55,27,3,27,0,56,1,43,5,1,27,11,16,41,3,16,42,27,26,29,14,11,21,10,0,1]

theorem envBound47902 : H12AffineFastState.Bounded env47902 := by
  intro p hp
  have h : env47902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47901_47902 : H12AffineEnvironment.transform 5 10 env47901 = env47902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env47901 == env47902) = true)

theorem identity47902 : scanCanonicalize (H12AffineFastState.compose env47902 (packedSelected [2,8] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound47902 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env47903 : List Nat := [2,3,8,16,32,10,19,18,27,25,48,27,3,27,0,56,1,43,2,1,27,11,16,41,3,16,42,27,26,26,9,11,18,10,0,1]

theorem envBound47903 : H12AffineFastState.Bounded env47903 := by
  intro p hp
  have h : env47903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47902_47903 : H12AffineEnvironment.transform 1 3 env47902 = env47903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env47902 == env47903) = true)

theorem identity47903 : scanCanonicalize (H12AffineFastState.compose env47903 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound47903 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env47904 : List Nat := [2,3,8,16,10,10,19,18,27,25,26,27,3,27,0,18,1,1,2,1,27,11,16,3,3,16,0,27,26,26,9,11,18,10,0,1]

theorem envBound47904 : H12AffineFastState.Bounded env47904 := by
  intro p hp
  have h : env47904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47903_47904 : H12AffineEnvironment.transform 4 10 env47903 = env47904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env47903 == env47904) = true)

def env47905 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,65536,74862,65665,4417,8541,4096,5277,74046,66896,13769,78894,1151,74814,1297,81227,8205,74798,256,8201,1345,5952]

theorem envBound47905 : H12AffineFastState.Bounded env47905 := by
  intro p hp
  have h : env47905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47883_47905 : H12AffineEnvironment.transform 17 65665 env47883 = env47905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env47883 == env47905) = true)

theorem identity47905 : scanCanonicalize (H12AffineFastState.compose env47905 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 9278) := by decide +kernel

theorem selectedBound47905 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env47906 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8540,9278,80,9407,4417,8541,4096,5277,1280,8558,13769,4112,1151,0,1297,6517,8205,16,256,8201,1345,5952]

theorem envBound47906 : H12AffineFastState.Bounded env47906 := by
  intro p hp
  have h : env47906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47905_47906 : H12AffineEnvironment.transform 15 9278 env47905 = env47906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9278 env47905 == env47906) = true)

def env47907 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1296,8540,9278,80,9407,1025,8541,1344,477,1280,8558,8329,1360,1151,0,1297,3125,8205,16,256,8201,1345,512]

theorem envBound47907 : H12AffineFastState.Bounded env47907 := by
  intro p hp
  have h : env47907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47906_47907 : H12AffineEnvironment.transform 11 1344 env47906 = env47907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env47906 == env47907) = true)

theorem identity47907 : scanCanonicalize (H12AffineFastState.compose env47907 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound47907 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env47908 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,1100,1296,1296,114,80,243,1025,1297,1344,477,1280,1314,1221,1360,1151,0,1297,3125,1089,16,256,1093,1345,512]

theorem envBound47908 : H12AffineFastState.Bounded env47908 := by
  intro p hp
  have h : env47908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47907_47908 : H12AffineEnvironment.transform 12 1100 env47907 = env47908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env47907 == env47908) = true)

theorem identity47908 : scanCanonicalize (H12AffineFastState.compose env47908 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound47908 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env47909 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,1052,1296,1296,34,0,163,1025,1297,1296,397,1280,1314,1173,1280,1071,0,1297,3125,1041,16,256,1045,1297,512]

theorem envBound47909 : H12AffineFastState.Bounded env47909 := by
  intro p hp
  have h : env47909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47908_47909 : H12AffineEnvironment.transform 5 16 env47908 = env47909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47908 == env47909) = true)

theorem identity47909 : scanCanonicalize (H12AffineFastState.compose env47909 (packedSelected [2,13,17] rootPS)) = affineNative (2^(10+1) ^^^ 789) := by decide +kernel

theorem selectedBound47909 : packedSelected [2,13,17] rootPS < 2^1333 := by decide +kernel

def env47910 : List Nat := [2,4,8,16,32,16,128,256,512,1024,789,1296,1052,1296,1296,34,0,163,1025,1297,1296,397,1280,1314,1173,1280,1071,0,1297,1824,1041,16,256,1045,1297,512]

theorem envBound47910 : H12AffineFastState.Bounded env47910 := by
  intro p hp
  have h : env47910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47909_47910 : H12AffineEnvironment.transform 10 789 env47909 = env47910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 789 env47909 == env47910) = true)

theorem identity47910 : scanCanonicalize (H12AffineFastState.compose env47910 (packedSelected [2,3,5,10,11,18] rootPS)) = affineNative (2^(9+1) ^^^ 558) := by decide +kernel

theorem selectedBound47910 : packedSelected [2,3,5,10,11,18] rootPS < 2^1333 := by decide +kernel

def env47911 : List Nat := [2,4,8,16,32,16,128,256,512,558,789,830,562,830,830,34,0,163,559,831,830,397,814,780,699,814,513,0,831,270,575,16,256,571,831,512]

theorem envBound47911 : H12AffineFastState.Bounded env47911 := by
  intro p hp
  have h : env47911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47910_47911 : H12AffineEnvironment.transform 9 558 env47910 = env47911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 558 env47910 == env47911) = true)

theorem identity47911 : scanCanonicalize (H12AffineFastState.compose env47911 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(8+1) ^^^ 319) := by decide +kernel

theorem selectedBound47911 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env47912 : List Nat := [2,4,8,16,32,16,128,256,319,273,42,1,269,1,1,34,0,163,272,0,1,397,17,51,388,17,318,0,0,270,256,16,256,260,0,319]

theorem envBound47912 : H12AffineFastState.Bounded env47912 := by
  intro p hp
  have h : env47912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47911_47912 : H12AffineEnvironment.transform 8 319 env47911 = env47912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 319 env47911 == env47912) = true)

theorem identity47912 : scanCanonicalize (H12AffineFastState.compose env47912 (packedSelected [1,2,5] rootPS)) = affineNative (2^(7+1) ^^^ 157) := by decide +kernel

theorem selectedBound47912 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env47913 : List Nat := [2,4,8,16,32,16,128,157,162,140,42,1,144,1,1,34,0,163,141,0,1,16,17,51,25,17,163,0,0,147,157,16,157,153,0,162]

theorem envBound47913 : H12AffineFastState.Bounded env47913 := by
  intro p hp
  have h : env47913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47912_47913 : H12AffineEnvironment.transform 7 157 env47912 = env47913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 157 env47912 == env47913) = true)

theorem identity47913 : scanCanonicalize (H12AffineFastState.compose env47913 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound47913 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env47914 : List Nat := [2,4,8,10,32,10,128,135,162,140,42,1,138,1,1,34,0,163,141,0,1,10,11,41,3,11,163,0,0,137,135,10,135,131,0,162]

theorem envBound47914 : H12AffineFastState.Bounded env47914 := by
  intro p hp
  have h : env47914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47913_47914 : H12AffineEnvironment.transform 3 10 env47913 = env47914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env47913 == env47914) = true)

theorem identity47914 : scanCanonicalize (H12AffineFastState.compose env47914 (packedSelected [0,1,2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound47914 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env47915 : List Nat := [2,4,8,10,32,10,8,15,42,4,42,1,2,1,1,34,0,43,5,0,1,10,11,41,3,11,43,0,0,1,15,10,15,11,0,42]

theorem envBound47915 : H12AffineFastState.Bounded env47915 := by
  intro p hp
  have h : env47915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47914_47915 : H12AffineEnvironment.transform 6 8 env47914 = env47915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47914 == env47915) = true)

theorem identity47915 : scanCanonicalize (H12AffineFastState.compose env47915 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound47915 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47916 : List Nat := [2,4,8,10,13,10,8,15,7,4,7,1,2,1,1,15,0,6,5,0,1,10,11,4,3,11,6,0,0,1,15,10,15,11,0,7]

theorem envBound47916 : H12AffineFastState.Bounded env47916 := by
  intro p hp
  have h : env47916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47915_47916 : H12AffineEnvironment.transform 4 13 env47915 = env47916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env47915 == env47916) = true)

theorem identity47916 : scanCanonicalize (H12AffineFastState.compose env47916 (packedSelected [7] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound47916 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env47917 : List Nat := [2,3,8,10,10,10,8,8,0,3,0,1,2,1,1,8,0,1,2,0,1,10,11,3,3,11,1,0,0,1,8,10,8,11,0,0]

theorem envBound47917 : H12AffineFastState.Bounded env47917 := by
  intro p hp
  have h : env47917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47916_47917 : H12AffineEnvironment.transform 1 3 env47916 = env47917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env47916 == env47917) = true)

def env47918 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,8540,9278,80,9407,1024,8541,1345,476,1280,8558,8328,1361,1151,0,1297,3124,8205,16,256,8201,1345,513]

theorem envBound47918 : H12AffineFastState.Bounded env47918 := by
  intro p hp
  have h : env47918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47906_47918 : H12AffineEnvironment.transform 11 1345 env47906 = env47918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env47906 == env47918) = true)

theorem identity47918 : scanCanonicalize (H12AffineFastState.compose env47918 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound47918 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env47919 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,268,1296,80,1330,80,1459,1024,81,1345,476,1280,98,388,1361,1151,0,1297,3124,257,16,256,261,1345,513]

theorem envBound47919 : H12AffineFastState.Bounded env47919 := by
  intro p hp
  have h : env47919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47918_47919 : H12AffineEnvironment.transform 12 268 env47918 = env47919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env47918 == env47919) = true)

theorem identity47919 : scanCanonicalize (H12AffineFastState.compose env47919 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound47919 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env47920 : List Nat := [2,4,8,16,32,64,128,69,512,1024,2048,1028,73,1109,80,1143,80,1270,1024,81,1028,153,1093,98,193,1044,1151,0,1108,3124,68,16,69,64,1028,513]

theorem envBound47920 : H12AffineFastState.Bounded env47920 := by
  intro p hp
  have h : env47920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47919_47920 : H12AffineEnvironment.transform 7 69 env47919 = env47920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env47919 == env47920) = true)

theorem identity47920 : scanCanonicalize (H12AffineFastState.compose env47920 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound47920 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env47921 : List Nat := [2,4,8,16,32,64,128,69,512,20,2048,16,73,65,80,99,80,226,20,81,16,153,81,98,193,0,107,0,64,2080,68,16,69,64,16,513]

theorem envBound47921 : H12AffineFastState.Bounded env47921 := by
  intro p hp
  have h : env47921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47920_47921 : H12AffineEnvironment.transform 9 20 env47920 = env47921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env47920 == env47921) = true)

theorem identity47921 : scanCanonicalize (H12AffineFastState.compose env47921 (packedSelected [2,12,13] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound47921 : packedSelected [2,12,13] rootPS < 2^1333 := by decide +kernel

def env47922 : List Nat := [2,4,8,16,32,64,128,69,49,20,2048,16,73,65,80,99,80,226,20,81,16,153,81,98,193,0,107,0,64,2080,68,16,69,64,16,48]

theorem envBound47922 : H12AffineFastState.Bounded env47922 := by
  intro p hp
  have h : env47922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47921_47922 : H12AffineEnvironment.transform 8 49 env47921 = env47922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env47921 == env47922) = true)

theorem identity47922 : scanCanonicalize (H12AffineFastState.compose env47922 (packedSelected [11,15,18] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound47922 : packedSelected [11,15,18] rootPS < 2^1333 := by decide +kernel

def env47923 : List Nat := [2,4,8,16,32,64,56,69,49,20,2048,16,73,65,80,99,80,90,20,81,16,33,81,98,121,0,107,0,64,2080,68,16,69,64,16,48]

theorem envBound47923 : H12AffineFastState.Bounded env47923 := by
  intro p hp
  have h : env47923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47922_47923 : H12AffineEnvironment.transform 6 56 env47922 = env47923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env47922 == env47923) = true)

theorem identity47923 : scanCanonicalize (H12AffineFastState.compose env47923 (packedSelected [1,2,4,5,8,9,11] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound47923 : packedSelected [1,2,4,5,8,9,11] rootPS < 2^1333 := by decide +kernel

def env47924 : List Nat := [2,4,8,16,7,64,31,69,22,20,2048,16,73,65,80,68,80,90,20,81,16,6,81,69,94,0,76,0,64,2055,68,16,69,64,16,23]

theorem envBound47924 : H12AffineFastState.Bounded env47924 := by
  intro p hp
  have h : env47924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47923_47924 : H12AffineEnvironment.transform 4 7 env47923 = env47924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env47923 == env47924) = true)

theorem identity47924 : scanCanonicalize (H12AffineFastState.compose env47924 (packedSelected [0,1,3,4,7,9,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 29) := by decide +kernel

theorem selectedBound47924 : packedSelected [0,1,3,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env47925 : List Nat := [2,4,8,16,7,64,31,69,22,20,29,16,73,65,80,68,80,90,20,81,16,6,81,69,94,0,76,0,64,26,68,16,69,64,16,23]

theorem envBound47925 : H12AffineFastState.Bounded env47925 := by
  intro p hp
  have h : env47925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47924_47925 : H12AffineEnvironment.transform 10 29 env47924 = env47925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 29 env47924 == env47925) = true)

theorem identity47925 : scanCanonicalize (H12AffineFastState.compose env47925 (packedSelected [5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound47925 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env47926 : List Nat := [2,4,8,16,7,17,31,20,22,20,29,16,24,16,1,21,1,11,20,0,16,6,0,20,15,0,29,0,17,26,21,16,20,17,16,23]

theorem envBound47926 : H12AffineFastState.Bounded env47926 := by
  intro p hp
  have h : env47926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47925_47926 : H12AffineEnvironment.transform 5 17 env47925 = env47926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47925 == env47926) = true)

theorem identity47926 : scanCanonicalize (H12AffineFastState.compose env47926 (packedSelected [0,1,4] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound47926 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env47927 : List Nat := [2,4,4,16,7,17,19,20,22,20,17,16,20,16,1,21,1,7,20,0,16,6,0,20,3,0,17,0,17,22,21,16,20,17,16,23]

theorem envBound47927 : H12AffineFastState.Bounded env47927 := by
  intro p hp
  have h : env47927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47926_47927 : H12AffineEnvironment.transform 2 4 env47926 = env47927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env47926 == env47927) = true)

theorem identity47927 : scanCanonicalize (H12AffineFastState.compose env47927 (packedSelected [0,1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound47927 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env47928 : List Nat := [2,0,0,16,3,17,19,16,18,16,17,16,16,16,1,17,1,3,16,0,16,2,0,16,3,0,17,0,17,18,17,16,16,17,16,19]

theorem envBound47928 : H12AffineFastState.Bounded env47928 := by
  intro p hp
  have h : env47928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47927_47928 : H12AffineEnvironment.transform 1 0 env47927 = env47928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env47927 == env47928) = true)

theorem identity47928 : scanCanonicalize (H12AffineFastState.compose env47928 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound47928 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env47929 : List Nat := [0,0,0,16,1,17,17,16,16,16,17,16,16,16,1,17,1,1,16,0,16,0,0,16,1,0,17,0,17,16,17,16,16,17,16,17]

theorem envBound47929 : H12AffineFastState.Bounded env47929 := by
  intro p hp
  have h : env47929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47928_47929 : H12AffineEnvironment.transform 0 0 env47928 = env47929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env47928 == env47929) = true)

theorem identity47929 : scanCanonicalize (H12AffineFastState.compose env47929 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound47929 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47930 : List Nat := [0,0,0,1,1,0,0,1,1,1,0,1,1,1,1,0,1,1,1,0,1,0,0,1,1,0,0,0,0,1,0,1,1,0,1,0]

theorem envBound47930 : H12AffineFastState.Bounded env47930 := by
  intro p hp
  have h : env47930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47929_47930 : H12AffineEnvironment.transform 3 1 env47929 = env47930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env47929 == env47930) = true)

def env47931 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74862,262144,4416,8540,4096,5277,74047,66896,13768,78894,328958,74815,1297,81226,8204,74798,256,8200,1345,5953]

theorem envBound47931 : H12AffineFastState.Bounded env47931 := by
  intro p hp
  have h : env47931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47882_47931 : H12AffineEnvironment.transform 13 1297 env47882 = env47931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env47882 == env47931) = true)

def env47932 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74862,65664,4416,8540,4096,5277,74047,66896,13768,78894,1150,74815,1297,81226,8204,74798,256,8200,1345,5953]

theorem envBound47932 : H12AffineFastState.Bounded env47932 := by
  intro p hp
  have h : env47932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47931_47932 : H12AffineEnvironment.transform 17 65664 env47931 = env47932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env47931 == env47932) = true)

theorem identity47932 : scanCanonicalize (H12AffineFastState.compose env47932 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 310) := by decide +kernel

theorem selectedBound47932 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env47933 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,310,9560,438,4416,8540,4096,5277,8201,1126,13768,13592,1150,9481,1297,15484,8204,9496,256,8200,1345,5953]

theorem envBound47933 : H12AffineFastState.Bounded env47933 := by
  intro p hp
  have h : env47933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47932_47933 : H12AffineEnvironment.transform 15 310 env47932 = env47933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 310 env47932 == env47933) = true)

def env47934 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,24,1297,325,310,1344,438,4416,324,4096,5277,17,1126,5584,5376,1150,1297,1297,7268,20,1280,256,16,1345,5953]

theorem envBound47934 : H12AffineFastState.Bounded env47934 := by
  intro p hp
  have h : env47934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47933_47934 : H12AffineEnvironment.transform 12 24 env47933 = env47934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env47933 == env47934) = true)

theorem identity47934 : scanCanonicalize (H12AffineFastState.compose env47934 (packedSelected [13,21] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound47934 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env47935 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,24,80,325,310,1,438,4416,324,4096,4572,17,295,4241,4161,319,80,80,6437,20,65,256,16,0,4608]

theorem envBound47935 : H12AffineFastState.Bounded env47935 := by
  intro p hp
  have h : env47935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47934_47935 : H12AffineEnvironment.transform 9 321 env47934 = env47935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env47934 == env47935) = true)

theorem identity47935 : scanCanonicalize (H12AffineFastState.compose env47935 (packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 951) := by decide +kernel

theorem selectedBound47935 : packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env47936 : List Nat := [2,4,8,16,32,64,128,256,512,321,951,4096,24,80,325,310,1,438,4416,324,4096,4572,17,295,4241,4161,319,80,80,4754,20,65,256,16,0,4608]

theorem envBound47936 : H12AffineFastState.Bounded env47936 := by
  intro p hp
  have h : env47936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47935_47936 : H12AffineEnvironment.transform 10 951 env47935 = env47936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 951 env47935 == env47936) = true)

theorem identity47936 : scanCanonicalize (H12AffineFastState.compose env47936 (packedSelected [0,1,2,4,5,7,9,10,11,13,23] rootPS)) = affineNative (2^(11+1) ^^^ 804) := by decide +kernel

theorem selectedBound47936 : packedSelected [0,1,2,4,5,7,9,10,11,13,23] rootPS < 2^1333 := by decide +kernel

def env47937 : List Nat := [2,4,8,16,32,64,128,256,512,321,951,804,24,80,325,310,1,438,612,324,804,760,17,295,949,869,319,80,80,438,20,65,256,16,0,292]

theorem envBound47937 : H12AffineFastState.Bounded env47937 := by
  intro p hp
  have h : env47937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47936_47937 : H12AffineEnvironment.transform 11 804 env47936 = env47937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 804 env47936 == env47937) = true)

theorem identity47937 : scanCanonicalize (H12AffineFastState.compose env47937 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(8+1) ^^^ 216) := by decide +kernel

theorem selectedBound47937 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env47938 : List Nat := [2,4,8,16,32,64,128,256,216,321,367,508,24,80,325,310,1,438,188,324,508,32,17,295,365,445,319,80,80,438,20,65,256,16,0,292]

theorem envBound47938 : H12AffineFastState.Bounded env47938 := by
  intro p hp
  have h : env47938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47937_47938 : H12AffineEnvironment.transform 8 216 env47937 = env47938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env47937 == env47938) = true)

theorem identity47938 : scanCanonicalize (H12AffineFastState.compose env47938 (packedSelected [0,4,11] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound47938 : packedSelected [0,4,11] rootPS < 2^1333 := by decide +kernel

def env47939 : List Nat := [2,4,8,16,32,64,128,69,216,4,42,185,24,80,0,115,1,243,188,1,185,32,17,98,40,248,122,80,80,243,20,65,69,16,0,97]

theorem envBound47939 : H12AffineFastState.Bounded env47939 := by
  intro p hp
  have h : env47939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47938_47939 : H12AffineEnvironment.transform 7 69 env47938 = env47939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env47938 == env47939) = true)

def env47940 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,25,1297,324,310,1345,438,4416,325,4096,5277,16,1126,5585,5377,1150,1296,1297,7269,21,1281,256,17,1345,5953]

theorem envBound47940 : H12AffineFastState.Bounded env47940 := by
  intro p hp
  have h : env47940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47933_47940 : H12AffineEnvironment.transform 12 25 env47933 = env47940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env47933 == env47940) = true)

theorem identity47940 : scanCanonicalize (H12AffineFastState.compose env47940 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound47940 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env47941 : List Nat := [2,4,8,16,32,64,128,21,512,1024,2048,4096,25,1028,81,35,1108,163,4181,80,4096,5277,16,1126,5316,5140,1150,1029,1028,7269,21,1044,21,17,1108,5716]

theorem envBound47941 : H12AffineFastState.Bounded env47941 := by
  intro p hp
  have h : env47941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47940_47941 : H12AffineEnvironment.transform 7 21 env47940 = env47941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env47940 == env47941) = true)

theorem identity47941 : scanCanonicalize (H12AffineFastState.compose env47941 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 1108) := by decide +kernel

theorem selectedBound47941 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env47942 : List Nat := [2,4,8,16,32,64,128,21,512,1024,2048,1108,25,1028,81,35,1108,163,1025,80,1108,201,16,1126,144,64,1150,1029,1028,2097,21,1044,21,17,1108,512]

theorem envBound47942 : H12AffineFastState.Bounded env47942 := by
  intro p hp
  have h : env47942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47941_47942 : H12AffineEnvironment.transform 11 1108 env47941 = env47942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1108 env47941 == env47942) = true)

theorem identity47942 : scanCanonicalize (H12AffineFastState.compose env47942 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound47942 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env47943 : List Nat := [2,4,8,16,32,16,128,21,512,1024,2048,1028,25,1028,1,35,1028,163,1025,0,1028,153,16,1078,144,16,1070,1029,1028,2097,21,1044,21,17,1028,512]

theorem envBound47943 : H12AffineFastState.Bounded env47943 := by
  intro p hp
  have h : env47943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47942_47943 : H12AffineEnvironment.transform 5 16 env47942 = env47943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47942 == env47943) = true)

theorem identity47943 : scanCanonicalize (H12AffineFastState.compose env47943 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound47943 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env47944 : List Nat := [2,4,8,16,32,16,128,21,512,47,2048,43,25,43,1,35,43,163,46,0,43,153,16,25,144,16,1,42,43,2097,21,59,21,17,43,512]

theorem envBound47944 : H12AffineFastState.Bounded env47944 := by
  intro p hp
  have h : env47944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47943_47944 : H12AffineEnvironment.transform 9 47 env47943 = env47944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env47943 == env47944) = true)

theorem identity47944 : scanCanonicalize (H12AffineFastState.compose env47944 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 162) := by decide +kernel

theorem selectedBound47944 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env47945 : List Nat := [2,4,8,16,32,16,128,21,162,47,2048,43,25,43,1,35,43,163,46,0,43,153,16,25,144,16,1,42,43,2097,21,59,21,17,43,162]

theorem envBound47945 : H12AffineFastState.Bounded env47945 := by
  intro p hp
  have h : env47945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47944_47945 : H12AffineEnvironment.transform 8 162 env47944 = env47945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 162 env47944 == env47945) = true)

theorem identity47945 : scanCanonicalize (H12AffineFastState.compose env47945 (packedSelected [2,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound47945 : packedSelected [2,5,7] rootPS < 2^1333 := by decide +kernel

def env47946 : List Nat := [2,4,8,16,32,16,34,21,0,47,2048,43,25,43,1,35,43,1,46,0,43,59,16,25,50,16,1,42,43,2097,21,59,21,17,43,0]

theorem envBound47946 : H12AffineFastState.Bounded env47946 := by
  intro p hp
  have h : env47946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47945_47946 : H12AffineEnvironment.transform 6 34 env47945 = env47946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env47945 == env47946) = true)

theorem identity47946 : scanCanonicalize (H12AffineFastState.compose env47946 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound47946 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env47947 : List Nat := [2,4,8,16,32,16,34,21,0,47,26,43,25,43,1,35,43,1,46,0,43,59,16,25,50,16,1,42,43,43,21,59,21,17,43,0]

theorem envBound47947 : H12AffineFastState.Bounded env47947 := by
  intro p hp
  have h : env47947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47946_47947 : H12AffineEnvironment.transform 10 26 env47946 = env47947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env47946 == env47947) = true)

theorem identity47947 : scanCanonicalize (H12AffineFastState.compose env47947 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound47947 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env47948 : List Nat := [2,4,8,10,32,10,34,15,0,47,0,43,3,43,1,35,43,1,46,0,43,33,10,3,40,10,1,42,43,43,15,33,15,11,43,0]

theorem envBound47948 : H12AffineFastState.Bounded env47948 := by
  intro p hp
  have h : env47948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47947_47948 : H12AffineEnvironment.transform 3 10 env47947 = env47948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env47947 == env47948) = true)

theorem identity47948 : scanCanonicalize (H12AffineFastState.compose env47948 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound47948 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47949 : List Nat := [2,4,8,10,10,10,8,15,0,5,0,1,3,1,1,9,1,1,4,0,1,11,10,3,2,10,1,0,1,1,15,11,15,11,1,0]

theorem envBound47949 : H12AffineFastState.Bounded env47949 := by
  intro p hp
  have h : env47949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47948_47949 : H12AffineEnvironment.transform 4 10 env47948 = env47949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env47948 == env47949) = true)

theorem identity47949 : scanCanonicalize (H12AffineFastState.compose env47949 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound47949 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47950 : List Nat := [2,4,4,6,6,6,4,3,0,5,0,1,3,1,1,5,1,1,4,0,1,7,6,3,2,6,1,0,1,1,3,7,3,7,1,0]

theorem envBound47950 : H12AffineFastState.Bounded env47950 := by
  intro p hp
  have h : env47950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47949_47950 : H12AffineEnvironment.transform 2 4 env47949 = env47950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env47949 == env47950) = true)

def env47951 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,65536,74862,65665,4416,8540,4096,5277,74047,66896,13768,78894,1151,74815,1297,81226,8204,74798,256,8200,1345,5953]

theorem envBound47951 : H12AffineFastState.Bounded env47951 := by
  intro p hp
  have h : env47951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47931_47951 : H12AffineEnvironment.transform 17 65665 env47931 = env47951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env47931 == env47951) = true)

theorem identity47951 : scanCanonicalize (H12AffineFastState.compose env47951 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 5238) := by decide +kernel

theorem selectedBound47951 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env47952 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8541,5238,12312,5367,4416,8540,4096,5277,13641,4390,13768,8280,1151,12361,1297,10556,8204,12376,256,8200,1345,5953]

theorem envBound47952 : H12AffineFastState.Bounded env47952 := by
  intro p hp
  have h : env47952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47951_47952 : H12AffineEnvironment.transform 15 5238 env47951 = env47952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5238 env47951 == env47952) = true)

def env47953 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5464,1297,5125,5238,1344,5367,4416,5124,4096,5277,17,4390,144,5376,1151,1297,1297,7268,5460,1280,256,5456,1345,5953]

theorem envBound47953 : H12AffineFastState.Bounded env47953 := by
  intro p hp
  have h : env47953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47952_47953 : H12AffineEnvironment.transform 12 5464 env47952 = env47953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5464 env47952 == env47953) = true)

theorem identity47953 : scanCanonicalize (H12AffineFastState.compose env47953 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound47953 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env47954 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,1369,1297,1028,1143,1344,1270,321,1029,1,1180,17,295,144,1281,1151,1297,1297,3173,1365,1280,256,1361,1345,1856]

theorem envBound47954 : H12AffineFastState.Bounded env47954 := by
  intro p hp
  have h : env47954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47953_47954 : H12AffineEnvironment.transform 11 1 env47953 = env47954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env47953 == env47954) = true)

theorem identity47954 : scanCanonicalize (H12AffineFastState.compose env47954 (packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS)) = affineNative (2^(10+1) ^^^ 1783) := by decide +kernel

theorem selectedBound47954 : packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env47955 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1783,1,1369,1297,1028,1143,1344,1270,321,1029,1,1180,17,295,144,1281,1151,1297,1297,658,1365,1280,256,1361,1345,1856]

theorem envBound47955 : H12AffineFastState.Bounded env47955 := by
  intro p hp
  have h : env47955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47954_47955 : H12AffineEnvironment.transform 10 1783 env47954 = env47955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1783 env47954 == env47955) = true)

theorem identity47955 : scanCanonicalize (H12AffineFastState.compose env47955 (packedSelected [0,1,2,4,5,7,9,10,11,13,23] rootPS)) = affineNative (2^(9+1) ^^^ 613) := by decide +kernel

theorem selectedBound47955 : packedSelected [0,1,2,4,5,7,9,10,11,13,23] rootPS < 2^1333 := by decide +kernel

def env47956 : List Nat := [2,4,8,16,32,64,128,256,512,613,146,1,828,884,609,530,805,659,321,608,1,761,17,295,144,868,538,884,884,658,816,869,256,820,804,293]

theorem envBound47956 : H12AffineFastState.Bounded env47956 := by
  intro p hp
  have h : env47956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47955_47956 : H12AffineEnvironment.transform 9 613 env47955 = env47956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 613 env47955 == env47956) = true)

theorem identity47956 : scanCanonicalize (H12AffineFastState.compose env47956 (packedSelected [0,1,2,7,8,11] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound47956 : packedSelected [0,1,2,7,8,11] rootPS < 2^1333 := by decide +kernel

def env47957 : List Nat := [2,4,8,16,32,64,105,256,512,613,123,1,828,884,609,530,805,634,321,608,1,528,17,295,121,868,538,884,884,635,816,869,256,820,804,293]

theorem envBound47957 : H12AffineFastState.Bounded env47957 := by
  intro p hp
  have h : env47957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47956_47957 : H12AffineEnvironment.transform 6 105 env47956 = env47957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env47956 == env47957) = true)

theorem identity47957 : scanCanonicalize (H12AffineFastState.compose env47957 (packedSelected [0,1,4,5,7,9,10,13] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound47957 : packedSelected [0,1,4,5,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env47958 : List Nat := [2,4,8,16,32,16,57,256,512,565,43,1,828,804,561,530,805,554,273,560,1,528,17,295,41,820,538,804,804,555,816,821,256,820,804,293]

theorem envBound47958 : H12AffineFastState.Bounded env47958 := by
  intro p hp
  have h : env47958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47957_47958 : H12AffineEnvironment.transform 5 16 env47957 = env47958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47957 == env47958) = true)

theorem identity47958 : scanCanonicalize (H12AffineFastState.compose env47958 (packedSelected [2,3,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound47958 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env47959 : List Nat := [2,4,8,10,32,10,35,256,512,559,43,1,806,804,555,520,805,554,267,554,1,522,11,295,41,814,512,804,804,555,810,815,256,814,804,293]

theorem envBound47959 : H12AffineFastState.Bounded env47959 := by
  intro p hp
  have h : env47959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47958_47959 : H12AffineEnvironment.transform 3 10 env47958 = env47959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env47958 == env47959) = true)

theorem identity47959 : scanCanonicalize (H12AffineFastState.compose env47959 (packedSelected [2,3] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound47959 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env47960 : List Nat := [2,4,8,10,13,10,14,256,512,514,6,1,779,777,518,520,776,519,267,519,1,522,11,266,4,771,512,777,777,518,775,770,256,771,777,264]

theorem envBound47960 : H12AffineFastState.Bounded env47960 := by
  intro p hp
  have h : env47960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47959_47960 : H12AffineEnvironment.transform 4 13 env47959 = env47960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env47959 == env47960) = true)

theorem identity47960 : scanCanonicalize (H12AffineFastState.compose env47960 (packedSelected [8] rootPS)) = affineNative (2^(8+1) ^^^ 271) := by decide +kernel

theorem selectedBound47960 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env47961 : List Nat := [2,4,8,10,13,10,14,256,271,269,6,1,4,6,265,263,7,264,267,264,1,261,11,266,4,12,271,6,6,265,8,13,256,12,6,264]

theorem envBound47961 : H12AffineFastState.Bounded env47961 := by
  intro p hp
  have h : env47961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47960_47961 : H12AffineEnvironment.transform 8 271 env47960 = env47961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 271 env47960 == env47961) = true)

theorem identity47961 : scanCanonicalize (H12AffineFastState.compose env47961 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound47961 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47962 : List Nat := [2,4,8,10,13,10,14,14,1,3,6,1,4,6,7,9,7,6,5,6,1,11,11,4,4,12,1,6,6,7,8,13,14,12,6,6]

theorem envBound47962 : H12AffineFastState.Bounded env47962 := by
  intro p hp
  have h : env47962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47961_47962 : H12AffineEnvironment.transform 7 14 env47961 = env47962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env47961 == env47962) = true)

theorem identity47962 : scanCanonicalize (H12AffineFastState.compose env47962 (packedSelected [4,7] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound47962 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env47963 : List Nat := [2,2,8,10,11,10,8,8,1,3,0,1,2,0,1,9,1,0,3,0,1,11,11,2,2,10,1,0,0,1,8,11,8,10,0,0]

theorem envBound47963 : H12AffineFastState.Bounded env47963 := by
  intro p hp
  have h : env47963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47962_47963 : H12AffineEnvironment.transform 1 2 env47962 = env47963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env47962 == env47963) = true)

theorem identity47963 : scanCanonicalize (H12AffineFastState.compose env47963 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound47963 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47964 : List Nat := [2,2,0,2,3,2,0,0,1,3,0,1,2,0,1,1,1,0,3,0,1,3,3,2,2,2,1,0,0,1,0,3,0,2,0,0]

theorem envBound47964 : H12AffineFastState.Bounded env47964 := by
  intro p hp
  have h : env47964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47963_47964 : H12AffineEnvironment.transform 2 0 env47963 = env47964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env47963 == env47964) = true)

theorem identity47964 : scanCanonicalize (H12AffineFastState.compose env47964 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound47964 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env47965 : List Nat := [1,1,0,1,0,1,0,0,1,0,0,1,1,0,1,1,1,0,0,0,1,0,0,1,1,1,1,0,0,1,0,0,0,1,0,0]

theorem envBound47965 : H12AffineFastState.Bounded env47965 := by
  intro p hp
  have h : env47965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47964_47965 : H12AffineEnvironment.transform 0 1 env47964 = env47965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env47964 == env47965) = true)

def env47966 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5465,1297,5124,5238,1345,5367,4416,5125,4096,5277,16,4390,145,5377,1151,1296,1297,7269,5461,1281,256,5457,1345,5953]

theorem envBound47966 : H12AffineFastState.Bounded env47966 := by
  intro p hp
  have h : env47966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47952_47966 : H12AffineEnvironment.transform 12 5465 env47952 = env47966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5465 env47952 == env47966) = true)

theorem identity47966 : scanCanonicalize (H12AffineFastState.compose env47966 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1109) := by decide +kernel

theorem selectedBound47966 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env47967 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1109,268,1297,81,35,1345,162,1301,80,1109,200,16,1395,145,340,1151,1296,1297,2096,256,1281,256,260,1345,788]

theorem envBound47967 : H12AffineFastState.Bounded env47967 := by
  intro p hp
  have h : env47967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47966_47967 : H12AffineEnvironment.transform 11 1109 env47966 = env47967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1109 env47966 == env47967) = true)

theorem identity47967 : scanCanonicalize (H12AffineFastState.compose env47967 (packedSelected [4,7,9,16,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound47967 : packedSelected [4,7,9,16,20,27] rootPS < 2^1333 := by decide +kernel

def env47968 : List Nat := [2,4,8,16,32,64,128,20,512,1024,2048,1109,24,1029,81,35,1109,162,1025,80,1109,200,16,1127,145,64,1151,1028,1029,2096,20,1045,20,16,1109,512]

theorem envBound47968 : H12AffineFastState.Bounded env47968 := by
  intro p hp
  have h : env47968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47967_47968 : H12AffineEnvironment.transform 7 20 env47967 = env47968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env47967 == env47968) = true)

theorem identity47968 : scanCanonicalize (H12AffineFastState.compose env47968 (packedSelected [4,9,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound47968 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env47969 : List Nat := [2,4,8,16,32,16,128,20,512,1024,2048,1029,24,1029,1,35,1029,162,1025,0,1029,152,16,1079,145,16,1071,1028,1029,2096,20,1045,20,16,1029,512]

theorem envBound47969 : H12AffineFastState.Bounded env47969 := by
  intro p hp
  have h : env47969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47968_47969 : H12AffineEnvironment.transform 5 16 env47968 = env47969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47968 == env47969) = true)

theorem identity47969 : scanCanonicalize (H12AffineFastState.compose env47969 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound47969 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env47970 : List Nat := [2,4,8,16,32,16,18,20,512,1024,2048,1029,24,1029,1,35,1029,48,1025,0,1029,10,16,1079,3,16,1071,1028,1029,2096,20,1045,20,16,1029,512]

theorem envBound47970 : H12AffineFastState.Bounded env47970 := by
  intro p hp
  have h : env47970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47969_47970 : H12AffineEnvironment.transform 6 18 env47969 = env47970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env47969 == env47970) = true)

theorem identity47970 : scanCanonicalize (H12AffineFastState.compose env47970 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 542) := by decide +kernel

theorem selectedBound47970 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env47971 : List Nat := [2,4,8,16,32,16,18,20,512,542,2048,539,24,539,1,35,539,48,543,0,539,10,16,553,3,16,561,538,539,2096,20,523,20,16,539,512]

theorem envBound47971 : H12AffineFastState.Bounded env47971 := by
  intro p hp
  have h : env47971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47970_47971 : H12AffineEnvironment.transform 9 542 env47970 = env47971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 542 env47970 == env47971) = true)

theorem identity47971 : scanCanonicalize (H12AffineFastState.compose env47971 (packedSelected [1,2,4,11] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound47971 : packedSelected [1,2,4,11] rootPS < 2^1333 := by decide +kernel

def env47972 : List Nat := [2,4,8,16,32,16,18,20,512,542,42,539,24,539,1,35,539,48,543,0,539,10,16,553,3,16,561,538,539,26,20,523,20,16,539,512]

theorem envBound47972 : H12AffineFastState.Bounded env47972 := by
  intro p hp
  have h : env47972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47971_47972 : H12AffineEnvironment.transform 10 42 env47971 = env47972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env47971 == env47972) = true)

theorem identity47972 : scanCanonicalize (H12AffineFastState.compose env47972 (packedSelected [3,4] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound47972 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env47973 : List Nat := [2,4,8,16,16,16,18,20,512,542,26,539,24,539,1,19,539,0,543,0,539,10,16,537,3,16,513,538,539,26,20,523,20,16,539,512]

theorem envBound47973 : H12AffineFastState.Bounded env47973 := by
  intro p hp
  have h : env47973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47972_47973 : H12AffineEnvironment.transform 4 16 env47972 = env47973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env47972 == env47973) = true)

def env47974 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,524288,32769,4096,61649,91182,123165,533640,614527,385203,90414,545088,96347,25884,618623,256,25880,1345,525825]

theorem envBound47974 : H12AffineFastState.Bounded env47974 := by
  intro p hp
  have h : env47974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47787_47974 : H12AffineEnvironment.transform 23 123165 env47787 = env47974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123165 env47787 == env47974) = true)

def env47975 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,21584,32769,4096,61649,91182,123165,28888,78895,385203,90414,1296,96347,25884,74799,256,25880,1345,21073]

end H12CloudChart2