import H12CloudChart2Data103

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound25493 : H12AffineFastState.Bounded env25493 := by
  intro p hp
  have h : env25493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25492_25493 : H12AffineEnvironment.transform 8 42 env25492 = env25493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env25492 == env25493) = true)

theorem identity25493 : scanCanonicalize (H12AffineFastState.compose env25493 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 271) := by decide +kernel

theorem selectedBound25493 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env25494 : List Nat := [2,4,8,16,32,17,128,256,42,424,438,271,24,276,276,300,162,318,425,276,162,406,10,139,144,10,26,163,270,147,283,178,257,260,184,43]

theorem envBound25494 : H12AffineFastState.Bounded env25494 := by
  intro p hp
  have h : env25494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25493_25494 : H12AffineEnvironment.transform 11 271 env25493 = env25494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 271 env25493 == env25494) = true)

theorem identity25494 : scanCanonicalize (H12AffineFastState.compose env25494 (packedSelected [0,2,4] rootPS)) = affineNative (2^(7+1) ^^^ 135) := by decide +kernel

theorem selectedBound25494 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env25495 : List Nat := [2,4,8,16,32,17,128,135,42,47,49,136,24,147,147,171,162,185,46,147,162,17,10,139,144,10,26,163,137,147,156,178,134,131,184,43]

theorem envBound25495 : H12AffineFastState.Bounded env25495 := by
  intro p hp
  have h : env25495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25494_25495 : H12AffineEnvironment.transform 7 135 env25494 = env25495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 135 env25494 == env25495) = true)

theorem identity25495 : scanCanonicalize (H12AffineFastState.compose env25495 (packedSelected [0,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound25495 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env25496 : List Nat := [2,4,8,16,32,17,57,62,42,47,49,49,24,42,42,18,27,0,46,42,27,17,10,50,41,10,26,26,48,42,37,11,63,58,1,43]

theorem envBound25496 : H12AffineFastState.Bounded env25496 := by
  intro p hp
  have h : env25496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25495_25496 : H12AffineEnvironment.transform 6 57 env25495 = env25496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env25495 == env25496) = true)

theorem identity25496 : scanCanonicalize (H12AffineFastState.compose env25496 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound25496 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env25497 : List Nat := [2,4,8,16,16,17,9,14,26,31,1,1,24,26,26,18,27,0,30,26,27,17,10,2,25,10,26,26,0,26,21,11,15,10,1,27]

theorem envBound25497 : H12AffineFastState.Bounded env25497 := by
  intro p hp
  have h : env25497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25496_25497 : H12AffineEnvironment.transform 4 16 env25496 = env25497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env25496 == env25497) = true)

theorem identity25497 : scanCanonicalize (H12AffineFastState.compose env25497 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound25497 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25498 : List Nat := [2,4,8,11,11,10,9,14,1,4,1,1,3,1,1,9,0,0,5,1,0,10,10,2,2,10,1,1,0,1,14,11,15,10,1,0]

theorem envBound25498 : H12AffineFastState.Bounded env25498 := by
  intro p hp
  have h : env25498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25497_25498 : H12AffineEnvironment.transform 3 11 env25497 = env25498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env25497 == env25498) = true)

theorem identity25498 : scanCanonicalize (H12AffineFastState.compose env25498 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound25498 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25499 : List Nat := [2,4,5,6,6,7,4,3,1,4,1,1,3,1,1,4,0,0,5,1,0,7,7,2,2,7,1,1,0,1,3,6,2,7,1,0]

theorem envBound25499 : H12AffineFastState.Bounded env25499 := by
  intro p hp
  have h : env25499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25498_25499 : H12AffineEnvironment.transform 2 5 env25498 = env25499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env25498 == env25499) = true)

def env25500 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,1457,16384,17833,65536,4524,262144,1025,17833,66598,82951,83355,138,1337,83355,262437,20665,20757,2341,82211,83234,257,260,16813,513]

theorem envBound25500 : H12AffineFastState.Bounded env25500 := by
  intro p hp
  have h : env25500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25486_25500 : H12AffineEnvironment.transform 12 1457 env25486 = env25500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1457 env25486 == env25500) = true)

theorem identity25500 : scanCanonicalize (H12AffineFastState.compose env25500 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(17+1) ^^^ 18480) := by decide +kernel

theorem selectedBound25500 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env25501 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,1457,16384,17833,65536,4524,18480,1025,17833,66598,82951,83355,138,1337,83355,18709,20665,20757,2341,82211,83234,257,260,16813,513]

theorem envBound25501 : H12AffineFastState.Bounded env25501 := by
  intro p hp
  have h : env25501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25500_25501 : H12AffineEnvironment.transform 17 18480 env25500 = env25501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 18480 env25500 == env25501) = true)

def env25502 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,1457,48,1433,65536,4524,2048,1025,1433,66598,66615,66987,138,1337,66987,2341,4233,4389,2341,65811,66834,257,260,413,513]

theorem envBound25502 : H12AffineFastState.Bounded env25502 := by
  intro p hp
  have h : env25502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25501_25502 : H12AffineEnvironment.transform 13 48 env25501 = env25502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 48 env25501 == env25502) = true)

theorem identity25502 : scanCanonicalize (H12AffineFastState.compose env25502 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 182) := by decide +kernel

theorem selectedBound25502 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env25503 : List Nat := [2,4,8,16,32,17,128,182,512,1024,2048,4096,1031,48,1071,65536,4122,2048,1025,1071,66598,66615,66589,138,1167,66589,2195,4233,4243,2195,65701,66724,183,178,43,513]

theorem envBound25503 : H12AffineFastState.Bounded env25503 := by
  intro p hp
  have h : env25503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25502_25503 : H12AffineEnvironment.transform 7 182 env25502 = env25503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 182 env25502 == env25503) = true)

theorem identity25503 : scanCanonicalize (H12AffineFastState.compose env25503 (packedSelected [4,9] rootPS)) = affineNative (2^(9+1) ^^^ 30) := by decide +kernel

theorem selectedBound25503 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env25504 : List Nat := [2,4,8,16,32,17,128,182,512,30,2048,4096,25,48,49,65536,4122,2048,31,49,65592,65577,65539,138,145,65539,2195,4233,4243,2195,65701,65722,183,178,43,513]

theorem envBound25504 : H12AffineFastState.Bounded env25504 := by
  intro p hp
  have h : env25504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25503_25504 : H12AffineEnvironment.transform 9 30 env25503 = env25504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 30 env25503 == env25504) = true)

def env25505 : List Nat := [2,4,8,16,32,17,128,182,512,30,2048,4096,25,48,49,128,4122,2048,31,49,184,169,131,138,145,131,2195,4233,4243,2195,37,58,183,178,43,513]

theorem envBound25505 : H12AffineFastState.Bounded env25505 := by
  intro p hp
  have h : env25505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25504_25505 : H12AffineEnvironment.transform 15 128 env25504 = env25505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 128 env25504 == env25505) = true)

theorem identity25505 : scanCanonicalize (H12AffineFastState.compose env25505 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound25505 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25506 : List Nat := [2,4,8,16,32,17,128,182,137,30,2048,4096,25,48,49,128,4122,2048,31,49,184,169,131,138,145,131,2195,4233,4243,2195,37,58,183,178,43,136]

theorem envBound25506 : H12AffineFastState.Bounded env25506 := by
  intro p hp
  have h : env25506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25505_25506 : H12AffineEnvironment.transform 8 137 env25505 = env25506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env25505 == env25506) = true)

theorem identity25506 : scanCanonicalize (H12AffineFastState.compose env25506 (packedSelected [0,1] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound25506 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env25507 : List Nat := [2,4,8,16,32,17,128,182,137,30,2048,184,25,48,49,128,162,2048,31,49,184,169,131,138,145,131,2195,49,43,2195,37,58,183,178,43,136]

theorem envBound25507 : H12AffineFastState.Bounded env25507 := by
  intro p hp
  have h : env25507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25506_25507 : H12AffineEnvironment.transform 11 184 env25506 = env25507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env25506 == env25507) = true)

theorem identity25507 : scanCanonicalize (H12AffineFastState.compose env25507 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound25507 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env25508 : List Nat := [2,4,8,11,32,10,128,173,137,5,2048,163,2,43,42,128,162,2048,4,42,163,169,131,138,138,131,2184,42,43,2184,37,33,172,169,43,136]

theorem envBound25508 : H12AffineFastState.Bounded env25508 := by
  intro p hp
  have h : env25508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25507_25508 : H12AffineEnvironment.transform 3 11 env25507 = env25508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env25507 == env25508) = true)

theorem identity25508 : scanCanonicalize (H12AffineFastState.compose env25508 (packedSelected [0,5] rootPS)) = affineNative (2^(10+1) ^^^ 162) := by decide +kernel

theorem selectedBound25508 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env25509 : List Nat := [2,4,8,11,32,10,128,173,137,5,162,163,2,43,42,128,162,162,4,42,163,169,131,138,138,131,42,42,43,42,37,33,172,169,43,136]

theorem envBound25509 : H12AffineFastState.Bounded env25509 := by
  intro p hp
  have h : env25509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25508_25509 : H12AffineEnvironment.transform 10 162 env25508 = env25509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 162 env25508 == env25509) = true)

theorem identity25509 : scanCanonicalize (H12AffineFastState.compose env25509 (packedSelected [0,8] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound25509 : packedSelected [0,8] rootPS < 2^1333 := by decide +kernel

def env25510 : List Nat := [2,4,8,11,32,10,8,37,1,5,42,43,2,43,42,8,42,42,4,42,43,33,11,2,2,11,42,42,43,42,37,33,36,33,43,0]

theorem envBound25510 : H12AffineFastState.Bounded env25510 := by
  intro p hp
  have h : env25510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25509_25510 : H12AffineEnvironment.transform 6 8 env25509 = env25510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env25509 == env25510) = true)

theorem identity25510 : scanCanonicalize (H12AffineFastState.compose env25510 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound25510 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25511 : List Nat := [2,4,8,11,12,10,8,9,1,5,6,7,2,7,6,8,6,6,4,6,7,13,11,2,2,11,6,6,7,6,9,13,8,13,7,0]

theorem envBound25511 : H12AffineFastState.Bounded env25511 := by
  intro p hp
  have h : env25511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25510_25511 : H12AffineEnvironment.transform 4 12 env25510 = env25511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env25510 == env25511) = true)

def leafEnv25511 : List Nat := [2,4,8,11,12,10,8,9,1,5,6,7,2,7,6,8,6,6,4,6,7,13,11,2,8,2,1,11,6,6,7,6,9,13,8,13,5,8,7,0,0,6,1]

def active25511 : List Nat := [0,1,2]

def tree25511 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25511 : H12WitnessSearch.Good tree25511 := H12GlobalWitnessIndex.good

theorem leafIdentity25511 : H12AffineFastState.composeSystem env25511 rootObs = leafEnv25511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25511 rootObs == leafEnv25511) = true)

theorem terminalChecked25511 : H12PackedTerminal.terminalCheckFast leafEnv25511 active25511 tree25511 = true := by decide +kernel

def env25512 : List Nat := [2,4,8,16,32,17,128,182,512,30,2048,4096,25,48,49,129,4122,2048,31,49,185,168,130,138,145,130,2195,4233,4243,2195,36,59,183,178,43,513]

theorem envBound25512 : H12AffineFastState.Bounded env25512 := by
  intro p hp
  have h : env25512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25504_25512 : H12AffineEnvironment.transform 15 129 env25504 = env25512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 129 env25504 == env25512) = true)

theorem identity25512 : scanCanonicalize (H12AffineFastState.compose env25512 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 147) := by decide +kernel

theorem selectedBound25512 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25513 : List Nat := [2,4,8,16,32,17,128,182,147,30,2048,4096,25,48,49,129,4122,2048,31,49,185,168,130,138,145,130,2195,4233,4243,2195,36,59,183,178,43,146]

theorem envBound25513 : H12AffineFastState.Bounded env25513 := by
  intro p hp
  have h : env25513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25512_25513 : H12AffineEnvironment.transform 8 147 env25512 = env25513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 147 env25512 == env25513) = true)

theorem identity25513 : scanCanonicalize (H12AffineFastState.compose env25513 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound25513 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env25514 : List Nat := [2,4,8,16,32,17,128,182,147,30,2048,48,25,48,49,129,42,2048,31,49,185,168,130,138,145,130,2195,185,163,2195,36,59,183,178,43,146]

theorem envBound25514 : H12AffineFastState.Bounded env25514 := by
  intro p hp
  have h : env25514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25513_25514 : H12AffineEnvironment.transform 11 48 env25513 = env25514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env25513 == env25514) = true)

theorem identity25514 : scanCanonicalize (H12AffineFastState.compose env25514 (packedSelected [0,1,5,8] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound25514 : packedSelected [0,1,5,8] rootPS < 2^1333 := by decide +kernel

def env25515 : List Nat := [2,4,8,11,32,10,128,173,136,5,2048,43,2,43,42,129,42,2048,4,42,162,168,130,138,138,130,2184,162,163,2184,36,32,172,169,43,137]

theorem envBound25515 : H12AffineFastState.Bounded env25515 := by
  intro p hp
  have h : env25515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25514_25515 : H12AffineEnvironment.transform 3 11 env25514 = env25515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env25514 == env25515) = true)

theorem identity25515 : scanCanonicalize (H12AffineFastState.compose env25515 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound25515 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env25516 : List Nat := [2,4,8,11,32,10,128,173,136,5,43,43,2,43,42,129,42,43,4,42,162,168,130,138,138,130,163,162,163,163,36,32,172,169,43,137]

theorem envBound25516 : H12AffineFastState.Bounded env25516 := by
  intro p hp
  have h : env25516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25515_25516 : H12AffineEnvironment.transform 10 43 env25515 = env25516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env25515 == env25516) = true)

theorem identity25516 : scanCanonicalize (H12AffineFastState.compose env25516 (packedSelected [0,5] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound25516 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env25517 : List Nat := [2,4,8,11,32,10,8,37,0,5,43,43,2,43,42,9,42,43,4,42,42,32,10,2,2,10,43,42,43,43,36,32,36,33,43,1]

theorem envBound25517 : H12AffineFastState.Bounded env25517 := by
  intro p hp
  have h : env25517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25516_25517 : H12AffineEnvironment.transform 6 8 env25516 = env25517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env25516 == env25517) = true)

theorem identity25517 : scanCanonicalize (H12AffineFastState.compose env25517 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound25517 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25518 : List Nat := [2,2,8,11,32,10,8,35,0,3,43,43,2,43,42,9,42,43,2,42,42,32,10,2,2,10,43,42,43,43,34,32,34,33,43,1]

theorem envBound25518 : H12AffineFastState.Bounded env25518 := by
  intro p hp
  have h : env25518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25517_25518 : H12AffineEnvironment.transform 1 2 env25517 = env25518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env25517 == env25518) = true)

def leafEnv25518 : List Nat := [2,2,8,11,32,10,8,35,0,3,43,43,2,43,42,9,42,43,2,42,42,32,10,2,35,2,1,10,43,42,43,43,34,32,34,33,3,9,43,1,0,43,1]

def active25518 : List Nat := [0,2,4]

def tree25518 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25518 : H12WitnessSearch.Good tree25518 := H12GlobalWitnessIndex.good

theorem leafIdentity25518 : H12AffineFastState.composeSystem env25518 rootObs = leafEnv25518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25518 rootObs == leafEnv25518) = true)

theorem terminalChecked25518 : H12PackedTerminal.terminalCheckFast leafEnv25518 active25518 tree25518 = true := by decide +kernel

def env25519 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,1457,49,1432,65536,4524,2049,1025,1432,66598,66614,66986,138,1337,66986,2340,4232,4388,2341,65810,66835,257,260,412,513]

theorem envBound25519 : H12AffineFastState.Bounded env25519 := by
  intro p hp
  have h : env25519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25501_25519 : H12AffineEnvironment.transform 13 49 env25501 = env25519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 49 env25501 == env25519) = true)

theorem identity25519 : scanCanonicalize (H12AffineFastState.compose env25519 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 63) := by decide +kernel

theorem selectedBound25519 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env25520 : List Nat := [2,4,8,16,32,17,128,63,512,1024,2048,4096,1166,49,1191,65536,4243,2049,1025,1191,66598,66614,66709,138,1030,66709,2075,4232,4123,2074,65581,66604,62,59,163,513]

theorem envBound25520 : H12AffineFastState.Bounded env25520 := by
  intro p hp
  have h : env25520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25519_25520 : H12AffineEnvironment.transform 7 63 env25519 = env25520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env25519 == env25520) = true)

theorem identity25520 : scanCanonicalize (H12AffineFastState.compose env25520 (packedSelected [4,9] rootPS)) = affineNative (2^(9+1) ^^^ 140) := by decide +kernel

theorem selectedBound25520 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env25521 : List Nat := [2,4,8,16,32,17,128,63,512,140,2048,4096,2,49,43,65536,4243,2049,141,43,65706,65722,65561,138,138,65561,2075,4232,4123,2074,65581,65696,62,59,163,513]

theorem envBound25521 : H12AffineFastState.Bounded env25521 := by
  intro p hp
  have h : env25521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25520_25521 : H12AffineEnvironment.transform 9 140 env25520 = env25521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 140 env25520 == env25521) = true)

def env25522 : List Nat := [2,4,8,16,32,17,128,63,512,140,2048,4096,2,49,43,128,4243,2049,141,43,42,58,153,138,138,153,2075,4232,4123,2074,173,32,62,59,163,513]

theorem envBound25522 : H12AffineFastState.Bounded env25522 := by
  intro p hp
  have h : env25522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25521_25522 : H12AffineEnvironment.transform 15 128 env25521 = env25522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 128 env25521 == env25522) = true)

theorem identity25522 : scanCanonicalize (H12AffineFastState.compose env25522 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound25522 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25523 : List Nat := [2,4,8,16,32,17,128,63,137,140,2048,4096,2,49,43,128,4243,2049,141,43,42,58,153,138,138,153,2075,4232,4123,2074,173,32,62,59,163,136]

theorem envBound25523 : H12AffineFastState.Bounded env25523 := by
  intro p hp
  have h : env25523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25522_25523 : H12AffineEnvironment.transform 8 137 env25522 = env25523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env25522 == env25523) = true)

theorem identity25523 : scanCanonicalize (H12AffineFastState.compose env25523 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2185) := by decide +kernel

theorem selectedBound25523 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env25524 : List Nat := [2,4,8,16,32,17,128,63,137,140,2048,2185,2,49,43,128,2074,2049,141,43,42,58,153,138,138,153,2075,2049,2194,2074,173,32,62,59,163,136]

theorem envBound25524 : H12AffineFastState.Bounded env25524 := by
  intro p hp
  have h : env25524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25523_25524 : H12AffineEnvironment.transform 11 2185 env25523 = env25524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2185 env25523 == env25524) = true)

theorem identity25524 : scanCanonicalize (H12AffineFastState.compose env25524 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound25524 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env25525 : List Nat := [2,4,8,16,32,17,18,63,27,30,2048,2075,2,49,43,18,2074,2049,31,43,42,58,11,24,24,11,2075,2049,2048,2074,63,32,62,59,49,26]

theorem envBound25525 : H12AffineFastState.Bounded env25525 := by
  intro p hp
  have h : env25525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25524_25525 : H12AffineEnvironment.transform 6 18 env25524 = env25525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env25524 == env25525) = true)

theorem identity25525 : scanCanonicalize (H12AffineFastState.compose env25525 (packedSelected [0,5] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound25525 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env25526 : List Nat := [2,4,8,16,32,17,18,63,27,30,48,43,2,49,43,18,42,49,31,43,42,58,11,24,24,11,43,49,48,42,63,32,62,59,49,26]

theorem envBound25526 : H12AffineFastState.Bounded env25526 := by
  intro p hp
  have h : env25526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25525_25526 : H12AffineEnvironment.transform 10 48 env25525 = env25526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env25525 == env25526) = true)

theorem identity25526 : scanCanonicalize (H12AffineFastState.compose env25526 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound25526 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env25527 : List Nat := [2,4,8,10,32,11,8,37,1,4,42,43,2,43,43,8,42,43,5,43,42,32,11,2,2,11,43,43,42,42,37,32,36,33,43,0]

theorem envBound25527 : H12AffineFastState.Bounded env25527 := by
  intro p hp
  have h : env25527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25526_25527 : H12AffineEnvironment.transform 3 10 env25526 = env25527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env25526 == env25527) = true)

theorem identity25527 : scanCanonicalize (H12AffineFastState.compose env25527 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound25527 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25528 : List Nat := [2,4,5,7,32,6,5,37,1,4,39,38,2,38,38,5,39,38,5,38,39,32,6,2,2,6,38,38,39,39,37,32,36,33,38,0]

theorem envBound25528 : H12AffineFastState.Bounded env25528 := by
  intro p hp
  have h : env25528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25527_25528 : H12AffineEnvironment.transform 2 5 env25527 = env25528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env25527 == env25528) = true)

def leafEnv25528 : List Nat := [2,4,5,7,32,6,5,37,1,4,39,38,2,38,38,5,39,38,5,38,39,32,6,2,36,2,1,6,38,38,39,39,37,32,36,33,5,5,38,0,0,38,1]

def active25528 : List Nat := [0,1,4]

def tree25528 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25528 : H12WitnessSearch.Good tree25528 := H12GlobalWitnessIndex.good

theorem leafIdentity25528 : H12AffineFastState.composeSystem env25528 rootObs = leafEnv25528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25528 rootObs == leafEnv25528) = true)

theorem terminalChecked25528 : H12PackedTerminal.terminalCheckFast leafEnv25528 active25528 tree25528 = true := by decide +kernel

def env25529 : List Nat := [2,4,8,16,32,17,128,63,512,140,2048,4096,2,49,43,129,4243,2049,141,43,43,59,152,138,138,152,2075,4232,4123,2074,172,33,62,59,163,513]

theorem envBound25529 : H12AffineFastState.Bounded env25529 := by
  intro p hp
  have h : env25529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25521_25529 : H12AffineEnvironment.transform 15 129 env25521 = env25529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 129 env25521 == env25529) = true)

theorem identity25529 : scanCanonicalize (H12AffineFastState.compose env25529 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound25529 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25530 : List Nat := [2,4,8,16,32,17,128,63,26,140,2048,4096,2,49,43,129,4243,2049,141,43,43,59,152,138,138,152,2075,4232,4123,2074,172,33,62,59,163,27]

theorem envBound25530 : H12AffineFastState.Bounded env25530 := by
  intro p hp
  have h : env25530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25529_25530 : H12AffineEnvironment.transform 8 26 env25529 = env25530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env25529 == env25530) = true)

theorem identity25530 : scanCanonicalize (H12AffineFastState.compose env25530 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2195) := by decide +kernel

theorem selectedBound25530 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env25531 : List Nat := [2,4,8,16,32,17,128,63,26,140,2048,2195,2,49,43,129,2048,2049,141,43,43,59,152,138,138,152,2075,2075,2184,2074,172,33,62,59,163,27]

theorem envBound25531 : H12AffineFastState.Bounded env25531 := by
  intro p hp
  have h : env25531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25530_25531 : H12AffineEnvironment.transform 11 2195 env25530 = env25531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2195 env25530 == env25531) = true)

theorem identity25531 : scanCanonicalize (H12AffineFastState.compose env25531 (packedSelected [0,1] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound25531 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env25532 : List Nat := [2,4,8,16,32,17,18,63,26,30,2048,2049,2,49,43,19,2048,2049,31,43,43,59,10,24,24,10,2075,2075,2074,2074,62,33,62,59,49,27]

theorem envBound25532 : H12AffineFastState.Bounded env25532 := by
  intro p hp
  have h : env25532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25531_25532 : H12AffineEnvironment.transform 6 18 env25531 = env25532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env25531 == env25532) = true)

theorem identity25532 : scanCanonicalize (H12AffineFastState.compose env25532 (packedSelected [0,5] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound25532 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env25533 : List Nat := [2,4,8,16,32,17,18,63,26,30,49,48,2,49,43,19,49,48,31,43,43,59,10,24,24,10,42,42,43,43,62,33,62,59,49,27]

theorem envBound25533 : H12AffineFastState.Bounded env25533 := by
  intro p hp
  have h : env25533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25532_25533 : H12AffineEnvironment.transform 10 49 env25532 = env25533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env25532 == env25533) = true)

theorem identity25533 : scanCanonicalize (H12AffineFastState.compose env25533 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound25533 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env25534 : List Nat := [2,4,8,10,32,11,8,37,0,4,43,42,2,43,43,9,43,42,5,43,43,33,10,2,2,10,42,42,43,43,36,33,36,33,43,1]

theorem envBound25534 : H12AffineFastState.Bounded env25534 := by
  intro p hp
  have h : env25534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25533_25534 : H12AffineEnvironment.transform 3 10 env25533 = env25534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env25533 == env25534) = true)

theorem identity25534 : scanCanonicalize (H12AffineFastState.compose env25534 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound25534 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25535 : List Nat := [2,4,8,10,7,11,8,2,0,4,12,13,2,12,12,9,12,13,5,12,12,6,10,2,2,10,13,13,12,12,3,6,3,6,12,1]

theorem envBound25535 : H12AffineFastState.Bounded env25535 := by
  intro p hp
  have h : env25535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25534_25535 : H12AffineEnvironment.transform 4 7 env25534 = env25535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env25534 == env25535) = true)

def leafEnv25535 : List Nat := [2,4,8,10,7,11,8,2,0,4,12,13,2,12,12,9,12,13,5,12,12,6,10,2,2,2,1,10,13,13,12,12,3,6,3,6,5,9,12,1,0,13,1]

def active25535 : List Nat := [0,1,2]

def tree25535 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25535 : H12WitnessSearch.Good tree25535 := H12GlobalWitnessIndex.good

theorem leafIdentity25535 : H12AffineFastState.composeSystem env25535 rootObs = leafEnv25535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25535 rootObs == leafEnv25535) = true)

theorem terminalChecked25535 : H12PackedTerminal.terminalCheckFast leafEnv25535 active25535 tree25535 = true := by decide +kernel

def env25536 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,2248769,16777216,8328,2774033,134217728,151954595,151827619,4294795,17399809,151490696,525568,138907683,156226641,513]

theorem envBound25536 : H12AffineFastState.Bounded env25536 := by
  intro p hp
  have h : env25536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25408_25536 : H12AffineEnvironment.transform 22 2248769 env25408 = env25536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2248769 env25408 == env25536) = true)

def env25537 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,2248769,16777216,8328,2248721,134217728,151429283,151302307,4294795,16876545,151490696,256,138907683,155701329,513]

theorem envBound25537 : H12AffineFastState.Bounded env25537 := by
  intro p hp
  have h : env25537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25536_25537 : H12AffineEnvironment.transform 18 1024 env25536 = env25537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env25536 == env25537) = true)

def env25538 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,2248769,16777216,8328,2248721,21331968,4399267,4272291,4294795,16876545,4329608,256,16912419,151633,513]

theorem envBound25538 : H12AffineFastState.Bounded env25538 := by
  intro p hp
  have h : env25538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25537_25538 : H12AffineEnvironment.transform 26 21331968 env25537 = env25538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21331968 env25537 == env25538) = true)

theorem identity25538 : scanCanonicalize (H12AffineFastState.compose env25538 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 6370769) := by decide +kernel

theorem selectedBound25538 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env25539 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,2248769,6370769,8328,2248721,2405841,4399267,4272291,4294795,6336976,4329608,256,6497778,151633,513]

theorem envBound25539 : H12AffineFastState.Bounded env25539 := by
  intro p hp
  have h : env25539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25538_25539 : H12AffineEnvironment.transform 23 6370769 env25538 = env25539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 6370769 env25538 == env25539) = true)

theorem identity25539 : scanCanonicalize (H12AffineFastState.compose env25539 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(13+1) ^^^ 5204) := by decide +kernel

theorem selectedBound25539 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env25540 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5204,32768,65536,131072,262144,1024,32768,2097152,4194304,2229269,6370769,8328,2229317,2405841,4399267,4272291,4294795,6336976,4329608,256,6497778,132101,513]

theorem envBound25540 : H12AffineFastState.Bounded env25540 := by
  intro p hp
  have h : env25540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25539_25540 : H12AffineEnvironment.transform 13 5204 env25539 = env25540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5204 env25539 == env25540) = true)

theorem identity25540 : scanCanonicalize (H12AffineFastState.compose env25540 (packedSelected [13,21] rootPS)) = affineNative (2^(16+1) ^^^ 45405) := by decide +kernel

theorem selectedBound25540 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env25541 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5204,32768,65536,45405,262144,1024,32768,2097152,4194304,2143560,6370769,8328,2143512,2405841,4297214,4272291,4294795,6336976,4235733,256,6395055,46424,513]

theorem envBound25541 : H12AffineFastState.Bounded env25541 := by
  intro p hp
  have h : env25541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25540_25541 : H12AffineEnvironment.transform 16 45405 env25540 = env25541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45405 env25540 == env25541) = true)

theorem identity25541 : scanCanonicalize (H12AffineFastState.compose env25541 (packedSelected [0,3,5,10,27] rootPS)) = affineNative (2^(21+1) ^^^ 41168) := by decide +kernel

theorem selectedBound25541 : packedSelected [0,3,5,10,27] rootPS < 2^1333 := by decide +kernel

def env25542 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5204,32768,65536,45405,262144,1024,32768,2097152,41168,2143560,2200833,8328,2143512,2405841,78126,102515,75867,2101504,261,256,2176127,46424,513]

theorem envBound25542 : H12AffineFastState.Bounded env25542 := by
  intro p hp
  have h : env25542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25541_25542 : H12AffineEnvironment.transform 21 41168 env25541 = env25542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41168 env25541 == env25542) = true)

theorem identity25542 : scanCanonicalize (H12AffineFastState.compose env25542 (packedSelected [1,5,8,12,15,17,24] rootPS)) = affineNative (2^(15+1) ^^^ 32882) := by decide +kernel

theorem selectedBound25542 : packedSelected [1,5,8,12,15,17,24] rootPS < 2^1333 := by decide +kernel

def env25543 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5204,32768,32882,45405,262144,1024,32768,2097152,41168,2143560,2102643,8328,2143512,2405841,45404,4097,43049,2101504,261,256,2143245,46424,513]

theorem envBound25543 : H12AffineFastState.Bounded env25543 := by
  intro p hp
  have h : env25543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25542_25543 : H12AffineEnvironment.transform 15 32882 env25542 = env25543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32882 env25542 == env25543) = true)

theorem identity25543 : scanCanonicalize (H12AffineFastState.compose env25543 (packedSelected [2,3,6,8,10,11,13,17,18] rootPS)) = affineNative (2^(17+1) ^^^ 9783) := by decide +kernel

theorem selectedBound25543 : packedSelected [2,3,6,8,10,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env25544 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5204,32768,32882,45405,9783,1024,32768,2097152,41168,2143560,2102643,8328,2143512,2135014,45404,4097,43049,2101504,261,256,2143245,46424,513]

theorem envBound25544 : H12AffineFastState.Bounded env25544 := by
  intro p hp
  have h : env25544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25543_25544 : H12AffineEnvironment.transform 17 9783 env25543 = env25544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 9783 env25543 == env25544) = true)

def env25545 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5204,32768,32882,45405,9783,1024,32768,46424,41168,16,41003,8328,64,9918,45404,4097,43049,42072,261,256,341,46424,513]

theorem envBound25545 : H12AffineFastState.Bounded env25545 := by
  intro p hp
  have h : env25545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25544_25545 : H12AffineEnvironment.transform 20 46424 env25544 = env25545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 46424 env25544 == env25545) = true)

theorem identity25545 : scanCanonicalize (H12AffineFastState.compose env25545 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound25545 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env25546 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1029,32768,32882,41228,9783,1024,32768,42249,41168,16,41003,8328,64,9918,41229,80,43049,42072,261,256,341,42249,513]

theorem envBound25546 : H12AffineFastState.Bounded env25546 := by
  intro p hp
  have h : env25546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25545_25546 : H12AffineEnvironment.transform 11 81 env25545 = env25546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env25545 == env25546) = true)

theorem identity25546 : scanCanonicalize (H12AffineFastState.compose env25546 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(14+1) ^^^ 1993) := by decide +kernel

theorem selectedBound25546 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env25547 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,81,8192,1029,1993,1979,9925,9783,1024,1993,8896,10009,16,10210,8328,64,9918,9924,80,12256,9105,261,256,341,8896,513]

theorem envBound25547 : H12AffineFastState.Bounded env25547 := by
  intro p hp
  have h : env25547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25546_25547 : H12AffineEnvironment.transform 14 1993 env25546 = env25547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1993 env25546 == env25547) = true)

def env25548 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1,8192,1029,1945,1979,9877,9783,1024,1945,8848,10009,16,10162,8328,16,9918,9876,0,12208,9105,261,256,261,8848,513]

theorem envBound25548 : H12AffineFastState.Bounded env25548 := by
  intro p hp
  have h : env25548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25547_25548 : H12AffineEnvironment.transform 5 16 env25547 = env25548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env25547 == env25548) = true)

theorem identity25548 : scanCanonicalize (H12AffineFastState.compose env25548 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 921) := by decide +kernel

theorem selectedBound25548 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env25549 : List Nat := [2,4,8,16,32,16,128,256,512,921,2048,1,8192,924,0,34,8460,8622,921,0,8848,8320,16,8235,8328,16,8487,8461,0,10281,9105,261,256,261,8848,513]

theorem envBound25549 : H12AffineFastState.Bounded env25549 := by
  intro p hp
  have h : env25549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25548_25549 : H12AffineEnvironment.transform 9 921 env25548 = env25549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 921 env25548 == env25549) = true)

theorem identity25549 : scanCanonicalize (H12AffineFastState.compose env25549 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 437) := by decide +kernel

theorem selectedBound25549 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25550 : List Nat := [2,4,8,16,32,16,128,256,512,921,2048,1,437,924,0,34,185,27,921,0,805,309,16,414,317,16,146,184,0,2460,548,261,256,261,805,513]

theorem envBound25550 : H12AffineFastState.Bounded env25550 := by
  intro p hp
  have h : env25550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25549_25550 : H12AffineEnvironment.transform 12 437 env25549 = env25550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 437 env25549 == env25550) = true)

def env25551 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,0,8192,1029,1944,1979,9876,9783,1024,1944,8849,10009,16,10163,8328,17,9918,9877,1,12209,9105,261,256,260,8849,513]

theorem envBound25551 : H12AffineFastState.Bounded env25551 := by
  intro p hp
  have h : env25551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25547_25551 : H12AffineEnvironment.transform 5 17 env25547 = env25551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env25547 == env25551) = true)

theorem identity25551 : scanCanonicalize (H12AffineFastState.compose env25551 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound25551 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env25552 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,0,269,1029,1944,1979,1945,1850,1024,1944,924,1556,16,1726,389,17,1971,1944,1,3772,668,261,256,260,924,513]

theorem envBound25552 : H12AffineFastState.Bounded env25552 := by
  intro p hp
  have h : env25552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25551_25552 : H12AffineEnvironment.transform 12 269 env25551 = env25552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env25551 == env25552) = true)

theorem identity25552 : scanCanonicalize (H12AffineFastState.compose env25552 (packedSelected [2,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1703) := by decide +kernel

theorem selectedBound25552 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env25553 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1703,0,269,1029,1944,1979,1945,1850,1024,1944,924,1556,16,1726,389,17,1971,1944,1,27,668,261,256,260,924,513]

theorem envBound25553 : H12AffineFastState.Bounded env25553 := by
  intro p hp
  have h : env25553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25552_25553 : H12AffineEnvironment.transform 10 1703 env25552 = env25553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1703 env25552 == env25553) = true)

def env25554 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5204,32768,32882,45405,9783,1024,32768,46425,41168,17,41002,8328,65,9919,45404,4097,43049,42073,261,256,340,46424,513]

theorem envBound25554 : H12AffineFastState.Bounded env25554 := by
  intro p hp
  have h : env25554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25544_25554 : H12AffineEnvironment.transform 20 46425 env25544 = env25554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 46425 env25544 == env25554) = true)

theorem identity25554 : scanCanonicalize (H12AffineFastState.compose env25554 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 12556) := by decide +kernel

theorem selectedBound25554 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env25555 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5204,12556,12670,81,9783,1024,12556,1109,4572,17,4390,8328,65,9919,80,4097,6437,5461,261,256,340,1108,513]

theorem envBound25555 : H12AffineFastState.Bounded env25555 := by
  intro p hp
  have h : env25555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25554_25555 : H12AffineEnvironment.transform 14 12556 env25554 = env25555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12556 env25554 == env25555) = true)

theorem identity25555 : scanCanonicalize (H12AffineFastState.compose env25555 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(12+1) ^^^ 1732) := by decide +kernel

theorem selectedBound25555 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env25556 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1732,5204,6088,6074,81,243,1024,6088,1109,4572,17,4390,1612,65,123,80,4097,6437,5461,261,256,340,1108,513]

theorem envBound25556 : H12AffineFastState.Bounded env25556 := by
  intro p hp
  have h : env25556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25555_25556 : H12AffineEnvironment.transform 12 1732 env25555 = env25556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1732 env25555 == env25556) = true)

def env25557 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,0,1732,1108,1992,1978,81,243,1024,1992,1109,476,17,294,1612,65,123,80,1,2341,1365,261,256,340,1108,513]

theorem envBound25557 : H12AffineFastState.Bounded env25557 := by
  intro p hp
  have h : env25557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25556_25557 : H12AffineEnvironment.transform 11 0 env25556 = env25557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env25556 == env25557) = true)

theorem identity25557 : scanCanonicalize (H12AffineFastState.compose env25557 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 470) := by decide +kernel

theorem selectedBound25557 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env25558 : List Nat := [2,4,8,16,32,64,128,256,512,1024,470,0,1732,1108,1992,1978,81,243,1024,1992,1109,476,17,294,1612,65,123,80,1,243,1365,261,256,340,1108,513]

theorem envBound25558 : H12AffineFastState.Bounded env25558 := by
  intro p hp
  have h : env25558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25557_25558 : H12AffineEnvironment.transform 10 470 env25557 = env25558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 470 env25557 == env25558) = true)

theorem identity25558 : scanCanonicalize (H12AffineFastState.compose env25558 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 612) := by decide +kernel

theorem selectedBound25558 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env25559 : List Nat := [2,4,8,16,32,64,128,256,512,612,470,0,160,560,428,478,81,243,612,428,561,476,17,294,40,65,123,80,1,243,817,261,256,340,560,513]

theorem envBound25559 : H12AffineFastState.Bounded env25559 := by
  intro p hp
  have h : env25559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25558_25559 : H12AffineEnvironment.transform 9 612 env25558 = env25559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 612 env25558 == env25559) = true)

theorem identity25559 : scanCanonicalize (H12AffineFastState.compose env25559 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound25559 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env25560 : List Nat := [2,4,8,16,32,64,128,173,512,612,123,0,160,560,1,115,81,243,612,1,561,113,17,139,40,65,123,80,1,243,668,168,173,249,560,513]

theorem envBound25560 : H12AffineFastState.Bounded env25560 := by
  intro p hp
  have h : env25560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25559_25560 : H12AffineEnvironment.transform 7 173 env25559 = env25560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env25559 == env25560) = true)

theorem identity25560 : scanCanonicalize (H12AffineFastState.compose env25560 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound25560 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25561 : List Nat := [2,4,8,16,32,64,57,20,512,612,123,0,25,560,1,115,81,74,612,1,561,113,17,50,40,65,123,80,1,74,549,17,20,64,560,513]

theorem envBound25561 : H12AffineFastState.Bounded env25561 := by
  intro p hp
  have h : env25561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25560_25561 : H12AffineEnvironment.transform 6 57 env25560 = env25561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env25560 == env25561) = true)

theorem identity25561 : scanCanonicalize (H12AffineFastState.compose env25561 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound25561 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25562 : List Nat := [2,4,8,10,32,64,35,14,512,612,97,0,3,554,1,105,75,74,612,1,555,107,11,40,40,65,97,74,1,74,549,11,14,64,554,513]

theorem envBound25562 : H12AffineFastState.Bounded env25562 := by
  intro p hp
  have h : env25562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25561_25562 : H12AffineEnvironment.transform 3 10 env25561 = env25562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env25561 == env25562) = true)

theorem identity25562 : scanCanonicalize (H12AffineFastState.compose env25562 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound25562 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env25563 : List Nat := [2,4,8,10,11,64,8,14,512,591,74,0,3,513,1,66,75,74,591,1,512,64,11,3,3,65,74,74,1,74,526,11,14,64,513,513]

theorem envBound25563 : H12AffineFastState.Bounded env25563 := by
  intro p hp
  have h : env25563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25562_25563 : H12AffineEnvironment.transform 4 11 env25562 = env25563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env25562 == env25563) = true)

def env25564 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1,1732,1109,1993,1979,81,243,1024,1993,1109,477,17,295,1612,65,123,80,0,2340,1364,261,256,340,1108,513]

theorem envBound25564 : H12AffineFastState.Bounded env25564 := by
  intro p hp
  have h : env25564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25556_25564 : H12AffineEnvironment.transform 11 1 env25556 = env25564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env25556 == env25564) = true)

theorem identity25564 : scanCanonicalize (H12AffineFastState.compose env25564 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 123) := by decide +kernel

theorem selectedBound25564 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env25565 : List Nat := [2,4,8,16,32,64,128,256,512,1024,123,1,1732,1109,1993,1979,81,243,1024,1993,1109,477,17,295,1612,65,123,80,0,351,1364,261,256,340,1108,513]

theorem envBound25565 : H12AffineFastState.Bounded env25565 := by
  intro p hp
  have h : env25565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25564_25565 : H12AffineEnvironment.transform 10 123 env25564 = env25565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 123 env25564 == env25565) = true)

theorem identity25565 : scanCanonicalize (H12AffineFastState.compose env25565 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound25565 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env25566 : List Nat := [2,4,8,16,32,64,128,256,512,565,123,1,241,608,508,398,81,243,565,508,608,477,17,295,121,65,123,80,0,351,865,261,256,340,609,513]

theorem envBound25566 : H12AffineFastState.Bounded env25566 := by
  intro p hp
  have h : env25566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25565_25566 : H12AffineEnvironment.transform 9 565 env25565 = env25566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env25565 == env25566) = true)

theorem identity25566 : scanCanonicalize (H12AffineFastState.compose env25566 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound25566 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25567 : List Nat := [2,4,8,16,32,64,128,21,512,565,123,1,241,608,233,155,81,243,565,233,608,200,17,50,121,65,123,80,0,74,628,16,21,65,609,513]

theorem envBound25567 : H12AffineFastState.Bounded env25567 := by
  intro p hp
  have h : env25567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25566_25567 : H12AffineEnvironment.transform 7 21 env25566 = env25567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env25566 == env25567) = true)

theorem identity25567 : scanCanonicalize (H12AffineFastState.compose env25567 (packedSelected [1,5] rootPS)) = affineNative (2^(6+1) ^^^ 114) := by decide +kernel

theorem selectedBound25567 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env25568 : List Nat := [2,4,8,16,32,64,114,21,512,565,123,1,3,608,27,105,81,1,565,27,608,58,17,50,121,65,123,80,0,74,628,16,21,65,609,513]

theorem envBound25568 : H12AffineFastState.Bounded env25568 := by
  intro p hp
  have h : env25568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25567_25568 : H12AffineEnvironment.transform 6 114 env25567 = env25568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 114 env25567 == env25568) = true)

theorem identity25568 : scanCanonicalize (H12AffineFastState.compose env25568 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound25568 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env25569 : List Nat := [2,4,8,16,32,10,56,21,512,565,49,1,3,554,27,35,27,1,565,27,554,58,17,50,51,11,49,26,0,0,574,16,21,11,555,513]

theorem envBound25569 : H12AffineFastState.Bounded env25569 := by
  intro p hp
  have h : env25569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25568_25569 : H12AffineEnvironment.transform 5 10 env25568 = env25569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env25568 == env25569) = true)

theorem identity25569 : scanCanonicalize (H12AffineFastState.compose env25569 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound25569 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env25570 : List Nat := [2,4,8,16,32,10,56,21,42,31,49,1,3,0,27,35,27,1,31,27,0,58,17,50,51,11,49,26,0,0,20,16,21,11,1,43]

theorem envBound25570 : H12AffineFastState.Bounded env25570 := by
  intro p hp
  have h : env25570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25569_25570 : H12AffineEnvironment.transform 8 42 env25569 = env25570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env25569 == env25570) = true)

theorem identity25570 : scanCanonicalize (H12AffineFastState.compose env25570 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound25570 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25571 : List Nat := [2,4,8,12,32,10,36,9,42,3,45,1,3,0,7,35,7,1,3,7,0,38,13,46,47,11,45,6,0,0,8,12,9,11,1,43]

theorem envBound25571 : H12AffineFastState.Bounded env25571 := by
  intro p hp
  have h : env25571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25570_25571 : H12AffineEnvironment.transform 3 12 env25570 = env25571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env25570 == env25571) = true)

theorem identity25571 : scanCanonicalize (H12AffineFastState.compose env25571 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound25571 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env25572 : List Nat := [2,4,8,12,11,10,15,9,1,3,6,1,3,0,7,8,7,1,3,7,0,13,13,5,4,11,6,6,0,0,8,12,9,11,1,0]

theorem envBound25572 : H12AffineFastState.Bounded env25572 := by
  intro p hp
  have h : env25572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25571_25572 : H12AffineEnvironment.transform 4 11 env25571 = env25572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env25571 == env25572) = true)

theorem identity25572 : scanCanonicalize (H12AffineFastState.compose env25572 (packedSelected [7] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound25572 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env25573 : List Nat := [2,2,8,10,11,10,9,9,1,3,0,1,3,0,1,8,1,1,3,1,0,11,11,3,2,11,0,0,0,0,8,10,9,11,1,0]

theorem envBound25573 : H12AffineFastState.Bounded env25573 := by
  intro p hp
  have h : env25573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25572_25573 : H12AffineEnvironment.transform 1 2 env25572 = env25573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env25572 == env25573) = true)

def env25574 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,2248769,16777216,8328,2248721,21331969,4399266,4272290,4294795,16876545,4329609,256,16912418,151632,513]

theorem envBound25574 : H12AffineFastState.Bounded env25574 := by
  intro p hp
  have h : env25574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25537_25574 : H12AffineEnvironment.transform 26 21331969 env25537 = env25574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21331969 env25537 == env25574) = true)

theorem identity25574 : scanCanonicalize (H12AffineFastState.compose env25574 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 4269521) := by decide +kernel

theorem selectedBound25574 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env25575 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,2248769,4269521,8328,2248721,304592,4399266,4272290,4294795,4235728,4329609,256,4404723,151632,513]

theorem envBound25575 : H12AffineFastState.Bounded env25575 := by
  intro p hp
  have h : env25575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25574_25575 : H12AffineEnvironment.transform 23 4269521 env25574 = env25575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4269521 env25574 == env25575) = true)

theorem identity25575 : scanCanonicalize (H12AffineFastState.compose env25575 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(20+1) ^^^ 249970) := by decide +kernel

theorem selectedBound25575 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env25576 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,249970,4194304,98355,4269521,8328,98403,304592,4399266,4272290,4294795,4235728,4329609,256,4404723,151632,513]

theorem envBound25576 : H12AffineFastState.Bounded env25576 := by
  intro p hp
  have h : env25576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25575_25576 : H12AffineEnvironment.transform 20 249970 env25575 = env25576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 249970 env25575 == env25576) = true)

theorem identity25576 : scanCanonicalize (H12AffineFastState.compose env25576 (packedSelected [13,21] rootPS)) = affineNative (2^(16+1) ^^^ 46425) := by decide +kernel

theorem selectedBound25576 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env25577 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,46425,262144,1024,32768,91435,4194304,98355,4269521,8328,98403,304592,4298235,4272290,4294795,4235728,4236752,256,4292778,58633,513]

theorem envBound25577 : H12AffineFastState.Bounded env25577 := by
  intro p hp
  have h : env25577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25576_25577 : H12AffineEnvironment.transform 16 46425 env25576 = env25577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46425 env25576 == env25577) = true)

def env25578 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,2248769,16777216,8328,2248720,134217728,151429282,151302306,4294795,16876544,151490696,257,138907683,155701328,513]

theorem envBound25578 : H12AffineFastState.Bounded env25578 := by
  intro p hp
  have h : env25578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25536_25578 : H12AffineEnvironment.transform 18 1025 env25536 = env25578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env25536 == env25578) = true)

def env25579 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,2248769,16777216,8328,2248720,21331968,4399266,4272290,4294795,16876544,4329608,257,16912419,151632,513]

theorem envBound25579 : H12AffineFastState.Bounded env25579 := by
  intro p hp
  have h : env25579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25578_25579 : H12AffineEnvironment.transform 26 21331968 env25578 = env25579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21331968 env25578 == env25579) = true)

theorem identity25579 : scanCanonicalize (H12AffineFastState.compose env25579 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 4399249) := by decide +kernel

theorem selectedBound25579 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env25580 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,2248769,4399249,8328,2248720,434321,4399266,4272290,4294795,4367505,4329608,257,4272306,151632,513]

theorem envBound25580 : H12AffineFastState.Bounded env25580 := by
  intro p hp
  have h : env25580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25579_25580 : H12AffineEnvironment.transform 23 4399249 env25579 = env25580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4399249 env25579 == env25580) = true)

theorem identity25580 : scanCanonicalize (H12AffineFastState.compose env25580 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(20+1) ^^^ 147733) := by decide +kernel

theorem selectedBound25580 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env25581 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,147733,4194304,4436,4399249,8328,4357,434321,4399266,4272290,4294795,4367505,4329608,257,4272306,151632,513]

theorem envBound25581 : H12AffineFastState.Bounded env25581 := by
  intro p hp
  have h : env25581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25580_25581 : H12AffineEnvironment.transform 20 147733 env25580 = env25581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 147733 env25580 == env25581) = true)

theorem identity25581 : scanCanonicalize (H12AffineFastState.compose env25581 (packedSelected [13,21] rootPS)) = affineNative (2^(16+1) ^^^ 45405) := by decide +kernel

theorem selectedBound25581 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env25582 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,45405,262144,1025,32768,61512,4194304,4436,4297164,8328,4357,266700,4297215,4272290,4294795,4199884,4235733,257,4272306,57613,513]

theorem envBound25582 : H12AffineFastState.Bounded env25582 := by
  intro p hp
  have h : env25582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25581_25582 : H12AffineEnvironment.transform 16 45405 env25581 = env25582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45405 env25581 == env25582) = true)

def env25583 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,2248769,16777216,8328,2248720,21331969,4399267,4272291,4294795,16876544,4329609,257,16912418,151633,513]

theorem envBound25583 : H12AffineFastState.Bounded env25583 := by
  intro p hp
  have h : env25583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25578_25583 : H12AffineEnvironment.transform 26 21331969 env25578 = env25583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21331969 env25578 == env25583) = true)

theorem identity25583 : scanCanonicalize (H12AffineFastState.compose env25583 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 6500497) := by decide +kernel

theorem selectedBound25583 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env25584 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,2248769,6500497,8328,2248720,2535568,4399267,4272291,4294795,6468753,4329609,257,6365363,151633,513]

theorem envBound25584 : H12AffineFastState.Bounded env25584 := by
  intro p hp
  have h : env25584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25583_25584 : H12AffineEnvironment.transform 23 6500497 env25583 = env25584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 6500497 env25583 == env25584) = true)

theorem identity25584 : scanCanonicalize (H12AffineFastState.compose env25584 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(20+1) ^^^ 249970) := by decide +kernel

theorem selectedBound25584 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env25585 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,249970,4194304,98355,4251875,8328,98402,352482,4399267,4272291,4294795,4285667,4329609,257,4387009,151633,513]

theorem envBound25585 : H12AffineFastState.Bounded env25585 := by
  intro p hp
  have h : env25585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25584_25585 : H12AffineEnvironment.transform 20 249970 env25584 = env25585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 249970 env25584 == env25585) = true)

theorem identity25585 : scanCanonicalize (H12AffineFastState.compose env25585 (packedSelected [13,21] rootPS)) = affineNative (2^(16+1) ^^^ 94315) := by decide +kernel

theorem selectedBound25585 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env25586 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,94315,262144,1025,32768,40985,4194304,98355,4251875,8328,98402,352482,4214984,4272291,4294795,4285667,4284642,257,4292778,73786,513]

theorem envBound25586 : H12AffineFastState.Bounded env25586 := by
  intro p hp
  have h : env25586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25585_25586 : H12AffineEnvironment.transform 16 94315 env25585 = env25586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 94315 env25585 == env25586) = true)

theorem identity25586 : scanCanonicalize (H12AffineFastState.compose env25586 (packedSelected [0,3,5,10,27] rootPS)) = affineNative (2^(21+1) ^^^ 98734) := by decide +kernel

theorem selectedBound25586 : packedSelected [0,3,5,10,27] rootPS < 2^1333 := by decide +kernel

def env25587 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,94315,262144,1025,32768,40985,98734,98355,90445,8328,98402,352482,119142,45325,2341,58701,57676,257,260,73786,513]

theorem envBound25587 : H12AffineFastState.Bounded env25587 := by
  intro p hp
  have h : env25587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25586_25587 : H12AffineEnvironment.transform 21 98734 env25586 = env25587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 98734 env25586 == env25587) = true)

def env25588 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,94267,262144,1025,32768,40985,98734,98355,90397,8328,98354,352434,119094,45325,2341,58653,57628,257,260,73786,513]

theorem envBound25588 : H12AffineFastState.Bounded env25588 := by
  intro p hp
  have h : env25588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25587_25588 : H12AffineEnvironment.transform 5 16 env25587 = env25588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env25587 == env25588) = true)

theorem identity25588 : scanCanonicalize (H12AffineFastState.compose env25588 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound25588 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env25589 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,1052,16384,32768,65536,87079,262144,1025,32768,33797,98734,98355,83201,1172,98354,345262,119094,38161,2341,49409,50432,257,260,66598,513]

theorem envBound25589 : H12AffineFastState.Bounded env25589 := by
  intro p hp
  have h : env25589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25588_25589 : H12AffineEnvironment.transform 12 1052 env25588 = env25589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env25588 == env25589) = true)

def env25590 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,1052,16384,32768,65536,87079,262144,1025,32768,33797,98306,98355,83117,1172,98354,345262,118938,38077,2185,49325,50348,173,168,66598,513]

theorem envBound25590 : H12AffineFastState.Bounded env25590 := by
  intro p hp
  have h : env25590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25589_25590 : H12AffineEnvironment.transform 7 172 env25589 = env25590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env25589 == env25590) = true)

theorem identity25590 : scanCanonicalize (H12AffineFastState.compose env25590 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 35892) := by decide +kernel

theorem selectedBound25590 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env25591 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,1052,16384,32768,65536,87079,35892,1025,32768,33797,98306,98355,83117,1172,98354,116890,118938,38077,2185,49325,50348,173,168,66598,513]

theorem envBound25591 : H12AffineFastState.Bounded env25591 := by
  intro p hp
  have h : env25591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25590_25591 : H12AffineEnvironment.transform 17 35892 env25590 = env25591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35892 env25590 == env25591) = true)

theorem identity25591 : scanCanonicalize (H12AffineFastState.compose env25591 (packedSelected [3,5,12,13] rootPS)) = affineNative (2^(15+1) ^^^ 17447) := by decide +kernel

theorem selectedBound25591 : packedSelected [3,5,12,13] rootPS < 2^1333 := by decide +kernel

def env25592 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,1052,16384,32768,17447,4096,35892,1025,32768,33797,50213,50196,138,1172,50197,36029,38077,38077,2185,49325,50348,173,168,16385,513]

theorem envBound25592 : H12AffineFastState.Bounded env25592 := by
  intro p hp
  have h : env25592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25591_25592 : H12AffineEnvironment.transform 15 17447 env25591 = env25592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 17447 env25591 == env25592) = true)

theorem identity25592 : scanCanonicalize (H12AffineFastState.compose env25592 (packedSelected [1,3] rootPS)) = affineNative (2^(14+1) ^^^ 16922) := by decide +kernel

theorem selectedBound25592 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25593 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,1052,16384,16922,17447,4096,20014,1025,16922,17951,1599,1550,138,1172,1551,20135,22183,22183,2185,695,1718,173,168,16385,513]

theorem envBound25593 : H12AffineFastState.Bounded env25593 := by
  intro p hp
  have h : env25593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25592_25593 : H12AffineEnvironment.transform 14 16922 env25592 = env25593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 16922 env25592 == env25593) = true)

theorem identity25593 : scanCanonicalize (H12AffineFastState.compose env25593 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 3076) := by decide +kernel

theorem selectedBound25593 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env25594 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,1052,3076,3614,2083,4096,554,1025,3614,2587,1599,1550,138,1172,1551,675,6819,6819,2185,695,1718,173,168,3077,513]

theorem envBound25594 : H12AffineFastState.Bounded env25594 := by
  intro p hp
  have h : env25594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25593_25594 : H12AffineEnvironment.transform 13 3076 env25593 = env25594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3076 env25593 == env25594) = true)

theorem identity25594 : scanCanonicalize (H12AffineFastState.compose env25594 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound25594 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env25595 : List Nat := [2,4,8,16,32,16,128,172,136,1024,2048,4096,1052,3076,3222,2083,4096,162,1025,3222,2195,1207,1158,138,1172,1159,43,6187,6187,2185,63,1086,173,168,3077,137]

theorem envBound25595 : H12AffineFastState.Bounded env25595 := by
  intro p hp
  have h : env25595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25594_25595 : H12AffineEnvironment.transform 8 136 env25594 = env25595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env25594 == env25595) = true)

def env25596 : List Nat := [2,4,8,16,32,16,8,36,0,1024,2048,4096,1052,3076,3102,2083,4096,42,1025,3102,2075,1087,1038,2,1052,1039,43,6187,6187,2049,63,1086,37,32,3077,1]

theorem envBound25596 : H12AffineFastState.Bounded env25596 := by
  intro p hp
  have h : env25596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25595_25596 : H12AffineEnvironment.transform 6 8 env25595 = env25596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env25595 == env25596) = true)

theorem identity25596 : scanCanonicalize (H12AffineFastState.compose env25596 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound25596 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25597 : List Nat := [2,4,8,10,32,10,8,36,0,1024,2048,4096,1030,3076,3076,2083,4096,42,1025,3076,2049,1061,1038,2,1030,1039,43,6187,6187,2049,37,1060,37,32,3077,1]

theorem envBound25597 : H12AffineFastState.Bounded env25597 := by
  intro p hp
  have h : env25597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25596_25597 : H12AffineEnvironment.transform 3 10 env25596 = env25597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env25596 == env25597) = true)

def env25598 : List Nat := [2,4,8,16,32,16,9,37,1,1024,2048,4096,1052,3076,3103,2083,4096,43,1025,3103,2074,1086,1039,3,1053,1038,43,6187,6187,2048,63,1086,36,33,3077,0]

theorem envBound25598 : H12AffineFastState.Bounded env25598 := by
  intro p hp
  have h : env25598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25595_25598 : H12AffineEnvironment.transform 6 9 env25595 = env25598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env25595 == env25598) = true)

theorem identity25598 : scanCanonicalize (H12AffineFastState.compose env25598 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound25598 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25599 : List Nat := [2,4,8,16,32,16,9,37,1,1024,48,4096,1052,1076,1071,19,4096,43,1025,1071,42,1086,1039,3,1053,1038,43,4123,4123,48,63,1086,36,33,1077,0]

theorem envBound25599 : H12AffineFastState.Bounded env25599 := by
  intro p hp
  have h : env25599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25598_25599 : H12AffineEnvironment.transform 10 48 env25598 = env25599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env25598 == env25599) = true)

def env25600 : List Nat := [2,4,8,16,32,16,9,37,1,4,48,4096,24,48,43,19,4096,43,5,43,42,58,11,3,25,10,43,4123,4123,48,63,58,36,33,49,0]

theorem envBound25600 : H12AffineFastState.Bounded env25600 := by
  intro p hp
  have h : env25600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25599_25600 : H12AffineEnvironment.transform 9 4 env25599 = env25600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env25599 == env25600) = true)

theorem identity25600 : scanCanonicalize (H12AffineFastState.compose env25600 (packedSelected [0,1] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound25600 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env25601 : List Nat := [2,4,8,16,32,16,9,37,1,4,48,48,24,48,43,19,48,43,5,43,42,58,11,3,25,10,43,43,43,48,63,58,36,33,49,0]

theorem envBound25601 : H12AffineFastState.Bounded env25601 := by
  intro p hp
  have h : env25601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25600_25601 : H12AffineEnvironment.transform 11 48 env25600 = env25601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env25600 == env25601) = true)

def env25602 : List Nat := [2,4,8,16,32,16,9,37,1,5,48,4096,25,49,42,19,4096,43,4,42,42,59,10,3,24,11,43,4123,4123,48,63,59,36,33,48,0]

theorem envBound25602 : H12AffineFastState.Bounded env25602 := by
  intro p hp
  have h : env25602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25599_25602 : H12AffineEnvironment.transform 9 5 env25599 = env25602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env25599 == env25602) = true)

def env25603 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,1052,16384,32768,65536,87079,262144,1025,32768,33797,98307,98355,83116,1172,98354,345262,118939,38076,2184,49324,50349,172,169,66598,513]

theorem envBound25603 : H12AffineFastState.Bounded env25603 := by
  intro p hp
  have h : env25603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25589_25603 : H12AffineEnvironment.transform 7 173 env25589 = env25603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env25589 == env25603) = true)

theorem identity25603 : scanCanonicalize (H12AffineFastState.compose env25603 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 116754) := by decide +kernel

theorem selectedBound25603 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env25604 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,1052,16384,32768,65536,87079,116754,1025,32768,33797,98307,98355,83116,1172,98354,36028,118939,38076,2184,49324,50349,172,169,66598,513]

theorem envBound25604 : H12AffineFastState.Bounded env25604 := by
  intro p hp
  have h : env25604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25603_25604 : H12AffineEnvironment.transform 17 116754 env25603 = env25604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 116754 env25603 == env25604) = true)

theorem identity25604 : scanCanonicalize (H12AffineFastState.compose env25604 (packedSelected [1,8,13,15] rootPS)) = affineNative (2^(15+1) ^^^ 17446) := by decide +kernel

theorem selectedBound25604 : packedSelected [1,8,13,15] rootPS < 2^1333 := by decide +kernel

def env25605 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,1052,16384,32768,17446,4097,35892,1025,32768,33797,50213,50197,138,1172,50196,36028,38077,38076,2184,49324,50349,172,169,16384,513]

theorem envBound25605 : H12AffineFastState.Bounded env25605 := by
  intro p hp
  have h : env25605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25604_25605 : H12AffineEnvironment.transform 15 17446 env25604 = env25605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 17446 env25604 == env25605) = true)

theorem identity25605 : scanCanonicalize (H12AffineFastState.compose env25605 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 662) := by decide +kernel

theorem selectedBound25605 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25606 : List Nat := [2,4,8,16,32,16,128,173,512,662,2048,4096,650,16384,32768,17072,4097,35490,663,32768,33427,49843,49795,138,514,49794,35370,37419,37418,2184,49324,49723,172,169,16384,513]

theorem envBound25606 : H12AffineFastState.Bounded env25606 := by
  intro p hp
  have h : env25606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25605_25606 : H12AffineEnvironment.transform 9 662 env25605 = env25606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 662 env25605 == env25606) = true)

theorem identity25606 : scanCanonicalize (H12AffineFastState.compose env25606 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 2586) := by decide +kernel

theorem selectedBound25606 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env25607 : List Nat := [2,4,8,16,32,16,128,173,512,662,2048,4096,650,2586,32768,2218,4097,35490,663,32768,33427,34985,34969,138,514,34968,35370,37419,37418,2184,35510,34849,172,169,2586,513]

theorem envBound25607 : H12AffineFastState.Bounded env25607 := by
  intro p hp
  have h : env25607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25606_25607 : H12AffineEnvironment.transform 13 2586 env25606 = env25607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2586 env25606 == env25607) = true)

theorem identity25607 : scanCanonicalize (H12AffineFastState.compose env25607 (packedSelected [0,9] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound25607 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env25608 : List Nat := [2,4,8,16,32,16,128,173,512,662,42,4096,650,560,32768,128,4097,33416,663,32768,33427,32899,32947,138,514,32946,33280,37419,37418,162,33436,32779,172,169,560,513]

theorem envBound25608 : H12AffineFastState.Bounded env25608 := by
  intro p hp
  have h : env25608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25607_25608 : H12AffineEnvironment.transform 10 42 env25607 = env25608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env25607 == env25608) = true)

def env25609 : List Nat := [2,4,8,16,32,16,8,37,512,542,42,4096,514,560,32768,8,4097,33280,543,32768,33307,32779,32827,2,514,32826,33280,37419,37418,42,33300,32779,36,33,560,513]

theorem envBound25609 : H12AffineFastState.Bounded env25609 := by
  intro p hp
  have h : env25609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25608_25609 : H12AffineEnvironment.transform 6 8 env25608 = env25609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env25608 == env25609) = true)

theorem identity25609 : scanCanonicalize (H12AffineFastState.compose env25609 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound25609 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25610 : List Nat := [2,4,8,11,32,11,8,37,512,517,42,4096,514,555,32768,8,4097,33280,516,32768,33280,32779,32800,2,514,32801,33280,37419,37418,42,33295,32779,36,33,555,513]

theorem envBound25610 : H12AffineFastState.Bounded env25610 := by
  intro p hp
  have h : env25610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25609_25610 : H12AffineEnvironment.transform 3 11 env25609 = env25610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env25609 == env25610) = true)

def env25611 : List Nat := [2,4,8,11,32,11,8,37,0,5,42,4096,2,43,32768,8,4097,32768,4,32768,32768,32779,32800,2,2,32801,32768,36907,36906,42,32783,32779,36,33,43,1]

theorem envBound25611 : H12AffineFastState.Bounded env25611 := by
  intro p hp
  have h : env25611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25610_25611 : H12AffineEnvironment.transform 8 0 env25610 = env25611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env25610 == env25611) = true)

theorem identity25611 : scanCanonicalize (H12AffineFastState.compose env25611 (packedSelected [0,7] rootPS)) = affineNative (2^(14+1) ^^^ 4097) := by decide +kernel

theorem selectedBound25611 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env25612 : List Nat := [2,4,8,11,32,11,8,37,0,5,42,4096,2,43,4097,8,4097,4097,4,4097,4097,4106,4129,2,2,4128,4097,42,43,42,4110,4106,36,33,43,1]

theorem envBound25612 : H12AffineFastState.Bounded env25612 := by
  intro p hp
  have h : env25612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25611_25612 : H12AffineEnvironment.transform 14 4097 env25611 = env25612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 4097 env25611 == env25612) = true)

def env25613 : List Nat := [2,4,8,11,0,11,8,5,0,5,10,4096,2,11,4097,8,4097,4097,4,4097,4097,4106,4097,2,2,4096,4097,10,11,10,4110,4106,4,1,11,1]

theorem envBound25613 : H12AffineFastState.Bounded env25613 := by
  intro p hp
  have h : env25613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25612_25613 : H12AffineEnvironment.transform 4 0 env25612 = env25613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env25612 == env25613) = true)

theorem identity25613 : scanCanonicalize (H12AffineFastState.compose env25613 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 13) := by decide +kernel

theorem selectedBound25613 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25614 : List Nat := [2,4,8,11,0,11,8,5,0,5,10,13,2,11,12,8,12,12,4,12,12,7,12,2,2,13,12,10,11,10,3,7,4,1,11,1]

theorem envBound25614 : H12AffineFastState.Bounded env25614 := by
  intro p hp
  have h : env25614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25613_25614 : H12AffineEnvironment.transform 11 13 env25613 = env25614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 13 env25613 == env25614) = true)

def leafEnv25614 : List Nat := [2,4,8,11,0,11,8,5,0,5,10,13,2,11,12,8,12,12,4,12,12,7,12,2,2,2,1,13,12,10,11,10,3,7,4,1,5,8,11,1,0,13,1]

def active25614 : List Nat := [0,1,2]

def tree25614 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25614 : H12WitnessSearch.Good tree25614 := H12GlobalWitnessIndex.good

theorem leafIdentity25614 : H12AffineFastState.composeSystem env25614 rootObs = leafEnv25614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25614 rootObs == leafEnv25614) = true)

theorem terminalChecked25614 : H12PackedTerminal.terminalCheckFast leafEnv25614 active25614 tree25614 = true := by decide +kernel

def env25615 : List Nat := [2,4,8,11,1,11,8,4,0,5,11,4096,2,10,4097,8,4097,4097,4,4097,4097,4106,4096,2,2,4097,4097,11,10,11,4110,4106,5,0,10,1]

theorem envBound25615 : H12AffineFastState.Bounded env25615 := by
  intro p hp
  have h : env25615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25612_25615 : H12AffineEnvironment.transform 4 1 env25612 = env25615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env25612 == env25615) = true)

theorem identity25615 : scanCanonicalize (H12AffineFastState.compose env25615 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound25615 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25616 : List Nat := [2,2,8,11,1,11,8,2,0,3,11,4096,2,10,4097,8,4097,4097,2,4097,4097,4106,4096,2,2,4097,4097,11,10,11,4104,4106,3,0,10,1]

theorem envBound25616 : H12AffineFastState.Bounded env25616 := by
  intro p hp
  have h : env25616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25615_25616 : H12AffineEnvironment.transform 1 2 env25615 = env25616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env25615 == env25616) = true)

def leafEnv25616 : List Nat := [2,2,8,11,1,11,8,2,0,3,11,4096,2,10,4097,8,4097,4097,2,4097,4097,4106,4096,2,4105,2,1,4097,4097,11,10,11,4104,4106,3,0,3,8,10,1,0,4096,1]

def active25616 : List Nat := [0,2,11]

def tree25616 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25616 : H12WitnessSearch.Good tree25616 := H12GlobalWitnessIndex.good

theorem leafIdentity25616 : H12AffineFastState.composeSystem env25616 rootObs = leafEnv25616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25616 rootObs == leafEnv25616) = true)

theorem terminalChecked25616 : H12PackedTerminal.terminalCheckFast leafEnv25616 active25616 tree25616 = true := by decide +kernel

def env25617 : List Nat := [2,4,8,11,32,11,8,37,1,4,42,4096,3,42,32768,8,4097,32769,5,32768,32769,32779,32800,2,3,32801,32769,36906,36907,42,32782,32779,36,33,42,0]

theorem envBound25617 : H12AffineFastState.Bounded env25617 := by
  intro p hp
  have h : env25617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25610_25617 : H12AffineEnvironment.transform 8 1 env25610 = env25617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env25610 == env25617) = true)

theorem identity25617 : scanCanonicalize (H12AffineFastState.compose env25617 (packedSelected [0,1] rootPS)) = affineNative (2^(11+1) ^^^ 42) := by decide +kernel

theorem selectedBound25617 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env25618 : List Nat := [2,4,8,11,32,11,8,37,1,4,42,42,3,42,32768,8,43,32769,5,32768,32769,32779,32800,2,3,32801,32769,32768,32769,42,32782,32779,36,33,42,0]

theorem envBound25618 : H12AffineFastState.Bounded env25618 := by
  intro p hp
  have h : env25618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25617_25618 : H12AffineEnvironment.transform 11 42 env25617 = env25618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 42 env25617 == env25618) = true)

def env25619 : List Nat := [2,4,8,11,0,11,8,5,1,4,10,10,3,10,32768,8,11,32769,5,32768,32769,32779,32768,2,3,32769,32769,32768,32769,10,32782,32779,4,1,10,0]

theorem envBound25619 : H12AffineFastState.Bounded env25619 := by
  intro p hp
  have h : env25619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25618_25619 : H12AffineEnvironment.transform 4 0 env25618 = env25619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env25618 == env25619) = true)

theorem identity25619 : scanCanonicalize (H12AffineFastState.compose env25619 (packedSelected [0] rootPS)) = affineNative (2^(14+1) ^^^ 7) := by decide +kernel

theorem selectedBound25619 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25620 : List Nat := [2,4,8,11,0,11,8,5,1,4,10,10,3,10,7,8,11,6,5,7,6,12,7,2,3,6,6,7,6,10,9,12,4,1,10,0]

theorem envBound25620 : H12AffineFastState.Bounded env25620 := by
  intro p hp
  have h : env25620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25619_25620 : H12AffineEnvironment.transform 14 7 env25619 = env25620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7 env25619 == env25620) = true)

def leafEnv25620 : List Nat := [2,4,8,11,0,11,8,5,1,4,10,10,3,10,7,8,11,6,5,7,6,12,7,2,8,3,1,6,6,7,6,10,9,12,4,1,5,8,10,0,0,7,1]

def active25620 : List Nat := [0,1,2]

def tree25620 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25620 : H12WitnessSearch.Good tree25620 := H12GlobalWitnessIndex.good

theorem leafIdentity25620 : H12AffineFastState.composeSystem env25620 rootObs = leafEnv25620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25620 rootObs == leafEnv25620) = true)

theorem terminalChecked25620 : H12PackedTerminal.terminalCheckFast leafEnv25620 active25620 tree25620 = true := by decide +kernel

def env25621 : List Nat := [2,4,8,11,1,11,8,4,1,4,11,11,3,11,32768,8,10,32769,5,32768,32769,32779,32769,2,3,32768,32769,32768,32769,11,32782,32779,5,0,11,0]

theorem envBound25621 : H12AffineFastState.Bounded env25621 := by
  intro p hp
  have h : env25621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25618_25621 : H12AffineEnvironment.transform 4 1 env25618 = env25621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env25618 == env25621) = true)

theorem identity25621 : scanCanonicalize (H12AffineFastState.compose env25621 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound25621 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25622 : List Nat := [2,4,5,6,1,6,5,4,1,4,6,6,3,6,32768,5,7,32769,5,32768,32769,32774,32769,2,3,32768,32769,32768,32769,6,32771,32774,5,0,6,0]

theorem envBound25622 : H12AffineFastState.Bounded env25622 := by
  intro p hp
  have h : env25622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25621_25622 : H12AffineEnvironment.transform 2 5 env25621 = env25622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env25621 == env25622) = true)

def leafEnv25622 : List Nat := [2,4,5,6,1,6,5,4,1,4,6,6,3,6,32768,5,7,32769,5,32768,32769,32774,32769,2,32770,3,1,32768,32769,32768,32769,6,32771,32774,5,0,5,5,6,0,0,32768,1]

def active25622 : List Nat := [0,1,14]

def tree25622 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25622 : H12WitnessSearch.Good tree25622 := H12GlobalWitnessIndex.good

theorem leafIdentity25622 : H12AffineFastState.composeSystem env25622 rootObs = leafEnv25622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25622 rootObs == leafEnv25622) = true)

theorem terminalChecked25622 : H12PackedTerminal.terminalCheckFast leafEnv25622 active25622 tree25622 = true := by decide +kernel

def env25623 : List Nat := [2,4,8,16,32,16,9,36,512,543,42,4096,515,560,32768,9,4097,33281,542,32768,33306,32778,32826,3,514,32827,33280,37419,37418,43,33301,32779,37,32,560,513]

theorem envBound25623 : H12AffineFastState.Bounded env25623 := by
  intro p hp
  have h : env25623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25608_25623 : H12AffineEnvironment.transform 6 9 env25608 = env25623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env25608 == env25623) = true)

theorem identity25623 : scanCanonicalize (H12AffineFastState.compose env25623 (packedSelected [2] rootPS)) = affineNative (2^(14+1) ^^^ 561) := by decide +kernel

theorem selectedBound25623 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25624 : List Nat := [2,4,8,16,32,16,9,36,512,543,42,4096,515,560,561,9,4097,48,542,561,43,571,523,3,514,522,49,4122,4123,43,36,570,37,32,560,513]

theorem envBound25624 : H12AffineFastState.Bounded env25624 := by
  intro p hp
  have h : env25624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25623_25624 : H12AffineEnvironment.transform 14 561 env25623 = env25624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 561 env25623 == env25624) = true)

def env25625 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,94266,262144,1025,32768,40985,98734,98355,90396,8328,98355,352435,119095,45325,2341,58652,57629,257,260,73786,513]

theorem envBound25625 : H12AffineFastState.Bounded env25625 := by
  intro p hp
  have h : env25625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25587_25625 : H12AffineEnvironment.transform 5 17 env25587 = env25625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env25587 == env25625) = true)

theorem identity25625 : scanCanonicalize (H12AffineFastState.compose env25625 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 42046) := by decide +kernel

theorem selectedBound25625 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env25626 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,42046,54276,262144,1025,32768,40985,9616,9229,50466,8328,9229,312461,29961,45325,2341,58652,57629,257,260,33796,513]

theorem envBound25626 : H12AffineFastState.Bounded env25626 := by
  intro p hp
  have h : env25626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25625_25626 : H12AffineEnvironment.transform 15 42046 env25625 = env25626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 42046 env25625 == env25626) = true)

def env25627 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,17832,24982,4524,262144,1025,17832,26033,9616,9229,138,8328,9229,262437,29961,29861,2341,8372,9397,257,260,16812,513]

theorem envBound25627 : H12AffineFastState.Bounded env25627 := by
  intro p hp
  have h : env25627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25626_25627 : H12AffineEnvironment.transform 14 17832 env25626 = env25627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 17832 env25626 == env25627) = true)

theorem identity25627 : scanCanonicalize (H12AffineFastState.compose env25627 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(17+1) ^^^ 28032) := by decide +kernel

theorem selectedBound25627 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env25628 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,17832,24982,4524,28032,1025,17832,26033,9616,9229,138,8328,9229,27813,29961,29861,2341,8372,9397,257,260,16812,513]

theorem envBound25628 : H12AffineFastState.Bounded env25628 := by
  intro p hp
  have h : env25628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25627_25628 : H12AffineEnvironment.transform 17 28032 env25627 = env25628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 28032 env25627 == env25628) = true)

def env25629 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,9600,8232,1046,4524,2048,1025,8232,49,9616,9229,138,8328,9229,2341,4233,4389,2341,8372,9397,257,260,9260,513]

theorem envBound25629 : H12AffineFastState.Bounded env25629 := by
  intro p hp
  have h : env25629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25628_25629 : H12AffineEnvironment.transform 13 9600 env25628 = env25629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9600 env25628 == env25629) = true)

theorem identity25629 : scanCanonicalize (H12AffineFastState.compose env25629 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 63) := by decide +kernel

theorem selectedBound25629 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env25630 : List Nat := [2,4,8,16,32,17,128,63,512,1024,2048,4096,8192,9407,8232,1046,4243,2048,1025,8232,49,9391,9229,138,8328,9229,2074,4233,4122,2074,8372,9397,62,59,9260,513]

theorem envBound25630 : H12AffineFastState.Bounded env25630 := by
  intro p hp
  have h : env25630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25629_25630 : H12AffineEnvironment.transform 7 63 env25629 = env25630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env25629 == env25630) = true)

theorem identity25630 : scanCanonicalize (H12AffineFastState.compose env25630 (packedSelected [4,9] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound25630 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env25631 : List Nat := [2,4,8,16,32,17,128,63,512,1024,2048,4096,24,1191,48,1046,4243,2048,1025,48,49,1207,1045,138,144,1045,2074,4233,4122,2074,172,1197,62,59,1076,513]

theorem envBound25631 : H12AffineFastState.Bounded env25631 := by
  intro p hp
  have h : env25631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25630_25631 : H12AffineEnvironment.transform 12 24 env25630 = env25631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env25630 == env25631) = true)

def env25632 : List Nat := [2,4,8,16,32,17,128,63,512,140,2048,4096,24,43,48,154,4243,2048,141,48,49,59,153,138,144,153,2074,4233,4122,2074,172,33,62,59,184,513]

theorem envBound25632 : H12AffineFastState.Bounded env25632 := by
  intro p hp
  have h : env25632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25631_25632 : H12AffineEnvironment.transform 9 140 env25631 = env25632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 140 env25631 == env25632) = true)

theorem identity25632 : scanCanonicalize (H12AffineFastState.compose env25632 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound25632 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25633 : List Nat := [2,4,8,16,32,17,128,63,137,140,2048,4096,24,43,48,154,4243,2048,141,48,49,59,153,138,144,153,2074,4233,4122,2074,172,33,62,59,184,136]

theorem envBound25633 : H12AffineFastState.Bounded env25633 := by
  intro p hp
  have h : env25633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25632_25633 : H12AffineEnvironment.transform 8 137 env25632 = env25633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env25632 == env25633) = true)

theorem identity25633 : scanCanonicalize (H12AffineFastState.compose env25633 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2184) := by decide +kernel

theorem selectedBound25633 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env25634 : List Nat := [2,4,8,16,32,17,128,63,137,140,2048,2184,24,43,48,154,2075,2048,141,48,49,59,153,138,144,153,2074,2049,2194,2074,172,33,62,59,184,136]

theorem envBound25634 : H12AffineFastState.Bounded env25634 := by
  intro p hp
  have h : env25634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25633_25634 : H12AffineEnvironment.transform 11 2184 env25633 = env25634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2184 env25633 == env25634) = true)

theorem identity25634 : scanCanonicalize (H12AffineFastState.compose env25634 (packedSelected [1,7] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound25634 : packedSelected [1,7] rootPS < 2^1333 := by decide +kernel

def env25635 : List Nat := [2,4,8,16,32,17,18,63,27,30,2048,2074,24,43,48,8,2075,2048,31,48,49,59,11,24,2,11,2074,2049,2048,2074,62,33,62,59,42,26]

theorem envBound25635 : H12AffineFastState.Bounded env25635 := by
  intro p hp
  have h : env25635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25634_25635 : H12AffineEnvironment.transform 6 18 env25634 = env25635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env25634 == env25635) = true)

theorem identity25635 : scanCanonicalize (H12AffineFastState.compose env25635 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound25635 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env25636 : List Nat := [2,4,8,16,32,17,18,63,27,30,42,48,24,43,48,8,49,42,31,48,49,59,11,24,2,11,48,43,42,48,62,33,62,59,42,26]

theorem envBound25636 : H12AffineFastState.Bounded env25636 := by
  intro p hp
  have h : env25636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25635_25636 : H12AffineEnvironment.transform 10 42 env25635 = env25636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env25635 == env25636) = true)

theorem identity25636 : scanCanonicalize (H12AffineFastState.compose env25636 (packedSelected [0,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound25636 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env25637 : List Nat := [2,4,8,10,32,11,8,37,1,4,42,42,2,43,42,8,43,42,5,42,43,33,11,2,2,11,42,43,42,42,36,33,36,33,42,0]

theorem envBound25637 : H12AffineFastState.Bounded env25637 := by
  intro p hp
  have h : env25637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25636_25637 : H12AffineEnvironment.transform 3 10 env25636 = env25637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env25636 == env25637) = true)

theorem identity25637 : scanCanonicalize (H12AffineFastState.compose env25637 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound25637 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25638 : List Nat := [2,4,5,7,32,6,5,37,1,4,39,39,2,38,39,5,38,39,5,39,38,33,6,2,2,6,39,38,39,39,36,33,36,33,39,0]

theorem envBound25638 : H12AffineFastState.Bounded env25638 := by
  intro p hp
  have h : env25638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25637_25638 : H12AffineEnvironment.transform 2 5 env25637 = env25638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env25637 == env25638) = true)

def leafEnv25638 : List Nat := [2,4,5,7,32,6,5,37,1,4,39,39,2,38,39,5,38,39,5,39,38,33,6,2,37,2,1,6,39,38,39,39,36,33,36,33,5,5,39,0,0,38,1]

def active25638 : List Nat := [0,1,4]

def tree25638 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25638 : H12WitnessSearch.Good tree25638 := H12GlobalWitnessIndex.good

theorem leafIdentity25638 : H12AffineFastState.composeSystem env25638 rootObs = leafEnv25638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25638 rootObs == leafEnv25638) = true)

theorem terminalChecked25638 : H12PackedTerminal.terminalCheckFast leafEnv25638 active25638 tree25638 = true := by decide +kernel

def env25639 : List Nat := [2,4,8,16,32,17,128,63,512,141,2048,4096,24,42,48,155,4243,2048,140,48,49,58,152,138,144,152,2074,4233,4122,2074,172,32,62,59,185,513]

theorem envBound25639 : H12AffineFastState.Bounded env25639 := by
  intro p hp
  have h : env25639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25631_25639 : H12AffineEnvironment.transform 9 141 env25631 = env25639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 141 env25631 == env25639) = true)

theorem identity25639 : scanCanonicalize (H12AffineFastState.compose env25639 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound25639 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25640 : List Nat := [2,4,8,16,32,17,128,63,26,141,2048,4096,24,42,48,155,4243,2048,140,48,49,58,152,138,144,152,2074,4233,4122,2074,172,32,62,59,185,27]

theorem envBound25640 : H12AffineFastState.Bounded env25640 := by
  intro p hp
  have h : env25640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25639_25640 : H12AffineEnvironment.transform 8 26 env25639 = env25640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env25639 == env25640) = true)

theorem identity25640 : scanCanonicalize (H12AffineFastState.compose env25640 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2195) := by decide +kernel

theorem selectedBound25640 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env25641 : List Nat := [2,4,8,16,32,17,128,63,26,141,2048,2195,24,42,48,155,2048,2048,140,48,49,58,152,138,144,152,2074,2074,2185,2074,172,32,62,59,185,27]

theorem envBound25641 : H12AffineFastState.Bounded env25641 := by
  intro p hp
  have h : env25641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25640_25641 : H12AffineEnvironment.transform 11 2195 env25640 = env25641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2195 env25640 == env25641) = true)

theorem identity25641 : scanCanonicalize (H12AffineFastState.compose env25641 (packedSelected [1,7] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound25641 : packedSelected [1,7] rootPS < 2^1333 := by decide +kernel

def env25642 : List Nat := [2,4,8,16,32,17,18,63,26,31,2048,2049,24,42,48,9,2048,2048,30,48,49,58,10,24,2,10,2074,2074,2075,2074,62,32,62,59,43,27]

theorem envBound25642 : H12AffineFastState.Bounded env25642 := by
  intro p hp
  have h : env25642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25641_25642 : H12AffineEnvironment.transform 6 18 env25641 = env25642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env25641 == env25642) = true)

theorem identity25642 : scanCanonicalize (H12AffineFastState.compose env25642 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound25642 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env25643 : List Nat := [2,4,8,16,32,17,18,63,26,31,43,42,24,42,48,9,43,43,30,48,49,58,10,24,2,10,49,49,48,49,62,32,62,59,43,27]

theorem envBound25643 : H12AffineFastState.Bounded env25643 := by
  intro p hp
  have h : env25643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25642_25643 : H12AffineEnvironment.transform 10 43 env25642 = env25643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env25642 == env25643) = true)

theorem identity25643 : scanCanonicalize (H12AffineFastState.compose env25643 (packedSelected [0,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound25643 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env25644 : List Nat := [2,4,8,10,32,11,8,37,0,5,43,42,2,42,42,9,43,43,4,42,43,32,10,2,2,10,43,43,42,43,36,32,36,33,43,1]

theorem envBound25644 : H12AffineFastState.Bounded env25644 := by
  intro p hp
  have h : env25644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25643_25644 : H12AffineEnvironment.transform 3 10 env25643 = env25644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env25643 == env25644) = true)

theorem identity25644 : scanCanonicalize (H12AffineFastState.compose env25644 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound25644 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25645 : List Nat := [2,4,8,10,7,11,8,2,0,5,12,13,2,13,13,9,12,12,4,13,12,7,10,2,2,10,12,12,13,12,3,7,3,6,12,1]

theorem envBound25645 : H12AffineFastState.Bounded env25645 := by
  intro p hp
  have h : env25645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25644_25645 : H12AffineEnvironment.transform 4 7 env25644 = env25645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env25644 == env25645) = true)

def leafEnv25645 : List Nat := [2,4,8,10,7,11,8,2,0,5,12,13,2,13,13,9,12,12,4,13,12,7,10,2,2,2,1,10,12,12,13,12,3,7,3,6,5,9,12,1,0,12,1]

def active25645 : List Nat := [0,1,2]

def tree25645 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25645 : H12WitnessSearch.Good tree25645 := H12GlobalWitnessIndex.good

theorem leafIdentity25645 : H12AffineFastState.composeSystem env25645 rootObs = leafEnv25645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25645 rootObs == leafEnv25645) = true)

theorem terminalChecked25645 : H12PackedTerminal.terminalCheckFast leafEnv25645 active25645 tree25645 = true := by decide +kernel

def env25646 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,9601,8233,1047,4524,2049,1025,8233,48,9616,9229,138,8328,9229,2340,4232,4388,2341,8372,9397,257,260,9261,513]

theorem envBound25646 : H12AffineFastState.Bounded env25646 := by
  intro p hp
  have h : env25646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25628_25646 : H12AffineEnvironment.transform 13 9601 env25628 = env25646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9601 env25628 == env25646) = true)

theorem identity25646 : scanCanonicalize (H12AffineFastState.compose env25646 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 182) := by decide +kernel

theorem selectedBound25646 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env25647 : List Nat := [2,4,8,16,32,17,128,182,512,1024,2048,4096,8192,9271,8233,1047,4122,2049,1025,8233,48,9254,9229,138,8328,9229,2194,4232,4242,2195,8372,9397,183,178,9261,513]

theorem envBound25647 : H12AffineFastState.Bounded env25647 := by
  intro p hp
  have h : env25647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25646_25647 : H12AffineEnvironment.transform 7 182 env25646 = env25647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 182 env25646 == env25647) = true)

theorem identity25647 : scanCanonicalize (H12AffineFastState.compose env25647 (packedSelected [4,9] rootPS)) = affineNative (2^(12+1) ^^^ 138) := by decide +kernel

theorem selectedBound25647 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env25648 : List Nat := [2,4,8,16,32,17,128,182,512,1024,2048,4096,138,1213,163,1047,4122,2049,1025,163,48,1196,1159,138,2,1159,2194,4232,4242,2195,62,1087,183,178,1191,513]

theorem envBound25648 : H12AffineFastState.Bounded env25648 := by
  intro p hp
  have h : env25648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25647_25648 : H12AffineEnvironment.transform 12 138 env25647 = env25648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 138 env25647 == env25648) = true)

def env25649 : List Nat := [2,4,8,16,32,17,128,182,512,4,2048,4096,138,185,163,19,4122,2049,5,163,48,168,131,138,2,131,2194,4232,4242,2195,62,59,183,178,163,513]

theorem envBound25649 : H12AffineFastState.Bounded env25649 := by
  intro p hp
  have h : env25649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25648_25649 : H12AffineEnvironment.transform 9 4 env25648 = env25649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env25648 == env25649) = true)

theorem identity25649 : scanCanonicalize (H12AffineFastState.compose env25649 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound25649 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25650 : List Nat := [2,4,8,16,32,17,128,182,137,4,2048,4096,138,185,163,19,4122,2049,5,163,48,168,131,138,2,131,2194,4232,4242,2195,62,59,183,178,163,136]

theorem envBound25650 : H12AffineFastState.Bounded env25650 := by
  intro p hp
  have h : env25650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25649_25650 : H12AffineEnvironment.transform 8 137 env25649 = env25650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env25649 == env25650) = true)

theorem identity25650 : scanCanonicalize (H12AffineFastState.compose env25650 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound25650 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env25651 : List Nat := [2,4,8,16,32,17,128,182,137,4,2048,184,138,185,163,19,162,2049,5,163,48,168,131,138,2,131,2194,48,42,2195,62,59,183,178,163,136]

theorem envBound25651 : H12AffineFastState.Bounded env25651 := by
  intro p hp
  have h : env25651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25650_25651 : H12AffineEnvironment.transform 11 184 env25650 = env25651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env25650 == env25651) = true)

theorem identity25651 : scanCanonicalize (H12AffineFastState.compose env25651 (packedSelected [0,1,5,8] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound25651 : packedSelected [0,1,5,8] rootPS < 2^1333 := by decide +kernel

def env25652 : List Nat := [2,4,8,11,32,10,128,173,137,4,2048,163,138,162,163,8,162,2049,5,163,43,168,131,138,2,131,2185,43,42,2184,37,32,172,169,163,136]

theorem envBound25652 : H12AffineFastState.Bounded env25652 := by
  intro p hp
  have h : env25652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25651_25652 : H12AffineEnvironment.transform 3 11 env25651 = env25652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env25651 == env25652) = true)

theorem identity25652 : scanCanonicalize (H12AffineFastState.compose env25652 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound25652 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env25653 : List Nat := [2,4,8,11,32,10,128,173,137,4,42,163,138,162,163,8,162,43,5,163,43,168,131,138,2,131,163,43,42,162,37,32,172,169,163,136]

theorem envBound25653 : H12AffineFastState.Bounded env25653 := by
  intro p hp
  have h : env25653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25652_25653 : H12AffineEnvironment.transform 10 42 env25652 = env25653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env25652 == env25653) = true)

theorem identity25653 : scanCanonicalize (H12AffineFastState.compose env25653 (packedSelected [0,5] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound25653 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env25654 : List Nat := [2,4,8,11,32,10,8,37,1,4,42,43,2,42,43,8,42,43,5,43,43,32,11,2,2,11,43,43,42,42,37,32,36,33,43,0]

theorem envBound25654 : H12AffineFastState.Bounded env25654 := by
  intro p hp
  have h : env25654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25653_25654 : H12AffineEnvironment.transform 6 8 env25653 = env25654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env25653 == env25654) = true)

theorem identity25654 : scanCanonicalize (H12AffineFastState.compose env25654 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound25654 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25655 : List Nat := [2,4,8,11,12,10,8,9,1,4,6,7,2,6,7,8,6,7,5,7,7,12,11,2,2,11,7,7,6,6,9,12,8,13,7,0]

theorem envBound25655 : H12AffineFastState.Bounded env25655 := by
  intro p hp
  have h : env25655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25654_25655 : H12AffineEnvironment.transform 4 12 env25654 = env25655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env25654 == env25655) = true)

def leafEnv25655 : List Nat := [2,4,8,11,12,10,8,9,1,4,6,7,2,6,7,8,6,7,5,7,7,12,11,2,8,2,1,11,7,7,6,6,9,12,8,13,5,8,7,0,0,7,1]

def active25655 : List Nat := [0,1,2]

def tree25655 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25655 : H12WitnessSearch.Good tree25655 := H12GlobalWitnessIndex.good

theorem leafIdentity25655 : H12AffineFastState.composeSystem env25655 rootObs = leafEnv25655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25655 rootObs == leafEnv25655) = true)

theorem terminalChecked25655 : H12PackedTerminal.terminalCheckFast leafEnv25655 active25655 tree25655 = true := by decide +kernel

def env25656 : List Nat := [2,4,8,16,32,17,128,182,512,5,2048,4096,138,184,163,18,4122,2049,4,163,48,169,130,138,2,130,2194,4232,4242,2195,62,58,183,178,162,513]

theorem envBound25656 : H12AffineFastState.Bounded env25656 := by
  intro p hp
  have h : env25656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25648_25656 : H12AffineEnvironment.transform 9 5 env25648 = env25656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env25648 == env25656) = true)

theorem identity25656 : scanCanonicalize (H12AffineFastState.compose env25656 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 147) := by decide +kernel

theorem selectedBound25656 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25657 : List Nat := [2,4,8,16,32,17,128,182,147,5,2048,4096,138,184,163,18,4122,2049,4,163,48,169,130,138,2,130,2194,4232,4242,2195,62,58,183,178,162,146]

theorem envBound25657 : H12AffineFastState.Bounded env25657 := by
  intro p hp
  have h : env25657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25656_25657 : H12AffineEnvironment.transform 8 147 env25656 = env25657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 147 env25656 == env25657) = true)

theorem identity25657 : scanCanonicalize (H12AffineFastState.compose env25657 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound25657 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env25658 : List Nat := [2,4,8,11,32,10,128,173,136,5,2048,4096,138,163,163,9,4097,2049,4,163,43,169,130,138,2,130,2185,4232,4233,2184,37,33,172,169,162,137]

theorem envBound25658 : H12AffineFastState.Bounded env25658 := by
  intro p hp
  have h : env25658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25657_25658 : H12AffineEnvironment.transform 3 11 env25657 = env25658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env25657 == env25658) = true)

theorem identity25658 : scanCanonicalize (H12AffineFastState.compose env25658 (packedSelected [0,5] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound25658 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env25659 : List Nat := [2,4,8,11,32,10,8,37,0,5,2048,4096,2,43,43,9,4097,2049,4,43,43,33,10,2,2,10,2049,4096,4097,2048,37,33,36,33,42,1]

theorem envBound25659 : H12AffineFastState.Bounded env25659 := by
  intro p hp
  have h : env25659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25658_25659 : H12AffineEnvironment.transform 6 8 env25658 = env25659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env25658 == env25659) = true)

theorem identity25659 : scanCanonicalize (H12AffineFastState.compose env25659 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2055) := by decide +kernel

theorem selectedBound25659 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25660 : List Nat := [2,4,8,11,32,10,8,37,0,5,2048,2055,2,43,43,9,2054,2049,4,43,43,33,10,2,2,10,2049,2055,2054,2048,37,33,36,33,42,1]

theorem envBound25660 : H12AffineFastState.Bounded env25660 := by
  intro p hp
  have h : env25660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25659_25660 : H12AffineEnvironment.transform 11 2055 env25659 = env25660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2055 env25659 == env25660) = true)

theorem identity25660 : scanCanonicalize (H12AffineFastState.compose env25660 (packedSelected [7] rootPS)) = affineNative (2^(10+1) ^^^ 45) := by decide +kernel

theorem selectedBound25660 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env25661 : List Nat := [2,4,8,11,32,10,8,37,0,5,45,42,2,43,43,9,43,44,4,43,43,33,10,2,2,10,44,42,43,45,37,33,36,33,42,1]

theorem envBound25661 : H12AffineFastState.Bounded env25661 := by
  intro p hp
  have h : env25661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25660_25661 : H12AffineEnvironment.transform 10 45 env25660 = env25661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 45 env25660 == env25661) = true)

theorem identity25661 : scanCanonicalize (H12AffineFastState.compose env25661 (packedSelected [8] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound25661 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env25662 : List Nat := [2,2,8,11,32,10,8,35,0,3,43,42,2,43,43,9,43,42,2,43,43,33,10,2,2,10,42,42,43,43,35,33,34,33,42,1]

theorem envBound25662 : H12AffineFastState.Bounded env25662 := by
  intro p hp
  have h : env25662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25661_25662 : H12AffineEnvironment.transform 1 2 env25661 = env25662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env25661 == env25662) = true)

def leafEnv25662 : List Nat := [2,2,8,11,32,10,8,35,0,3,43,42,2,43,43,9,43,42,2,43,43,33,10,2,34,2,1,10,42,42,43,43,35,33,34,33,3,9,42,1,0,43,1]

def active25662 : List Nat := [0,2,4]

def tree25662 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood25662 : H12WitnessSearch.Good tree25662 := H12GlobalWitnessIndex.good

theorem leafIdentity25662 : H12AffineFastState.composeSystem env25662 rootObs = leafEnv25662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env25662 rootObs == leafEnv25662) = true)

theorem terminalChecked25662 : H12PackedTerminal.terminalCheckFast leafEnv25662 active25662 tree25662 = true := by decide +kernel

def env25663 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,17833,24983,4525,262144,1025,17833,26032,9616,9229,139,8328,9229,262436,29961,29860,2341,8373,9396,257,260,16813,513]

theorem envBound25663 : H12AffineFastState.Bounded env25663 := by
  intro p hp
  have h : env25663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25626_25663 : H12AffineEnvironment.transform 14 17833 env25626 = env25663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 17833 env25626 == env25663) = true)

theorem identity25663 : scanCanonicalize (H12AffineFastState.compose env25663 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 9381) := by decide +kernel

theorem selectedBound25663 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env25664 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,9381,8460,1330,4525,262144,1025,8460,277,9616,9229,139,8328,9229,262436,4524,4097,2341,8373,9396,257,260,9480,513]

theorem envBound25664 : H12AffineFastState.Bounded env25664 := by
  intro p hp
  have h : env25664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25663_25664 : H12AffineEnvironment.transform 13 9381 env25663 = env25664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9381 env25663 == env25664) = true)

theorem identity25664 : scanCanonicalize (H12AffineFastState.compose env25664 (packedSelected [2,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound25664 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env25665 : List Nat := [2,4,8,16,32,17,128,256,512,1024,26,4096,8192,9381,8460,1330,4525,262144,1025,8460,277,9616,9229,139,8328,9229,262436,4524,4097,319,8373,9396,257,260,9480,513]

theorem envBound25665 : H12AffineFastState.Bounded env25665 := by
  intro p hp
  have h : env25665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25664_25665 : H12AffineEnvironment.transform 10 26 env25664 = env25665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env25664 == env25665) = true)

theorem identity25665 : scanCanonicalize (H12AffineFastState.compose env25665 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1213) := by decide +kernel

theorem selectedBound25665 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env25666 : List Nat := [2,4,8,16,32,17,128,256,512,1024,26,1213,8192,9381,8460,1330,1296,262144,1025,8460,277,9616,9229,139,8328,9229,262436,1297,1212,319,8373,9396,257,260,9480,513]

theorem envBound25666 : H12AffineFastState.Bounded env25666 := by
  intro p hp
  have h : env25666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25665_25666 : H12AffineEnvironment.transform 11 1213 env25665 = env25666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1213 env25665 == env25666) = true)

theorem identity25666 : scanCanonicalize (H12AffineFastState.compose env25666 (packedSelected [1,2,3,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound25666 : packedSelected [1,2,3,12,15] rootPS < 2^1333 := by decide +kernel

def env25667 : List Nat := [2,4,8,16,32,17,128,256,512,1024,26,1213,25,1212,277,1330,1296,262144,1025,277,277,1417,1044,139,145,1044,262436,1297,1212,319,172,1197,257,260,1297,513]

theorem envBound25667 : H12AffineFastState.Bounded env25667 := by
  intro p hp
  have h : env25667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25666_25667 : H12AffineEnvironment.transform 12 25 env25666 = env25667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env25666 == env25667) = true)

theorem identity25667 : scanCanonicalize (H12AffineFastState.compose env25667 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 147) := by decide +kernel

theorem selectedBound25667 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env25668 : List Nat := [2,4,8,16,32,17,128,256,512,1024,26,1213,25,1212,277,1330,1296,147,1025,277,277,1417,1044,139,145,1044,439,1297,1212,319,172,1197,257,260,1297,513]

theorem envBound25668 : H12AffineFastState.Bounded env25668 := by
  intro p hp
  have h : env25668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25667_25668 : H12AffineEnvironment.transform 17 147 env25667 = env25668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 147 env25667 == env25668) = true)

theorem identity25668 : scanCanonicalize (H12AffineFastState.compose env25668 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 150) := by decide +kernel

theorem selectedBound25668 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env25669 : List Nat := [2,4,8,16,32,17,128,256,512,150,26,43,25,42,277,420,390,147,151,277,277,287,130,139,145,130,439,391,42,319,172,59,257,260,391,513]

theorem envBound25669 : H12AffineFastState.Bounded env25669 := by
  intro p hp
  have h : env25669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25668_25669 : H12AffineEnvironment.transform 9 150 env25668 = env25669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 150 env25668 == env25669) = true)

theorem identity25669 : scanCanonicalize (H12AffineFastState.compose env25669 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound25669 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env25670 : List Nat := [2,4,8,16,32,17,128,15,512,150,26,43,25,42,26,171,137,147,151,26,26,16,130,139,145,130,184,136,42,48,172,59,14,11,136,513]

theorem envBound25670 : H12AffineFastState.Bounded env25670 := by
  intro p hp
  have h : env25670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25669_25670 : H12AffineEnvironment.transform 7 15 env25669 = env25670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env25669 == env25670) = true)

theorem identity25670 : scanCanonicalize (H12AffineFastState.compose env25670 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(8+1) ^^^ 162) := by decide +kernel

theorem selectedBound25670 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env25671 : List Nat := [2,4,8,16,32,17,128,15,162,150,26,43,25,42,26,171,137,147,151,26,26,16,130,139,145,130,184,136,42,48,172,59,14,11,136,163]

theorem envBound25671 : H12AffineFastState.Bounded env25671 := by
  intro p hp
  have h : env25671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25670_25671 : H12AffineEnvironment.transform 8 162 env25670 = env25671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 162 env25670 == env25671) = true)

theorem identity25671 : scanCanonicalize (H12AffineFastState.compose env25671 (packedSelected [0,1,2] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound25671 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env25672 : List Nat := [2,4,8,16,32,17,56,15,26,46,26,43,25,42,26,19,49,43,47,26,26,16,58,51,41,58,0,48,42,48,20,59,14,11,48,27]

theorem envBound25672 : H12AffineFastState.Bounded env25672 := by
  intro p hp
  have h : env25672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25671_25672 : H12AffineEnvironment.transform 6 56 env25671 = env25672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env25671 == env25672) = true)

theorem identity25672 : scanCanonicalize (H12AffineFastState.compose env25672 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound25672 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env25673 : List Nat := [2,4,8,16,17,17,9,15,26,31,26,26,25,27,26,19,0,26,30,26,26,16,11,2,24,11,0,1,27,1,20,10,14,11,1,27]

theorem envBound25673 : H12AffineFastState.Bounded env25673 := by
  intro p hp
  have h : env25673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25672_25673 : H12AffineEnvironment.transform 4 17 env25672 = env25673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env25672 == env25673) = true)

theorem identity25673 : scanCanonicalize (H12AffineFastState.compose env25673 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound25673 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env25674 : List Nat := [2,4,8,11,10,10,9,15,1,4,1,1,2,0,1,8,0,1,5,1,1,11,11,2,3,11,0,1,0,1,15,10,14,11,1,0]

theorem envBound25674 : H12AffineFastState.Bounded env25674 := by
  intro p hp
  have h : env25674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25673_25674 : H12AffineEnvironment.transform 3 11 env25673 = env25674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env25673 == env25674) = true)

theorem identity25674 : scanCanonicalize (H12AffineFastState.compose env25674 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound25674 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env25675 : List Nat := [2,3,8,11,10,10,9,8,1,3,1,1,2,0,1,8,0,1,2,1,1,11,11,2,3,11,0,1,0,1,8,10,9,11,1,0]

theorem envBound25675 : H12AffineFastState.Bounded env25675 := by
  intro p hp
  have h : env25675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25674_25675 : H12AffineEnvironment.transform 1 3 env25674 = env25675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env25674 == env25675) = true)

def env25676 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8328,8914001,134217728,151954594,151827618,4294795,17399808,151490696,525568,138907683,166560785,513]

theorem envBound25676 : H12AffineFastState.Bounded env25676 := by
  intro p hp
  have h : env25676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25407_25676 : H12AffineEnvironment.transform 25 8914001 env25407 = env25676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 8914001 env25407 == env25676) = true)

def env25677 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,2248768,16777216,8328,2774033,134217728,151954594,151827618,4294795,17399808,151490696,525568,138907683,156226641,513]

theorem envBound25677 : H12AffineFastState.Bounded env25677 := by
  intro p hp
  have h : env25677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25676_25677 : H12AffineEnvironment.transform 22 2248768 env25676 = env25677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2248768 env25676 == env25677) = true)

def env25678 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,2248768,16777216,8328,2248721,134217728,151429282,151302306,4294795,16876544,151490696,256,138907683,155701329,513]

theorem envBound25678 : H12AffineFastState.Bounded env25678 := by
  intro p hp
  have h : env25678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25677_25678 : H12AffineEnvironment.transform 18 1024 env25677 = env25678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env25677 == env25678) = true)

def env25679 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,2248768,16777216,8328,2248721,21331968,4399266,4272290,4294795,16876544,4329608,256,16912419,151633,513]

theorem envBound25679 : H12AffineFastState.Bounded env25679 := by
  intro p hp
  have h : env25679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25678_25679 : H12AffineEnvironment.transform 26 21331968 env25678 = env25679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21331968 env25678 == env25679) = true)

theorem identity25679 : scanCanonicalize (H12AffineFastState.compose env25679 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 2286021) := by decide +kernel

theorem selectedBound25679 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env25680 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,2286021,2248768,16777216,8328,2248721,19358149,2212199,2347367,2320718,16876544,2158925,256,16912419,151633,513]

theorem envBound25680 : H12AffineFastState.Bounded env25680 := by
  intro p hp
  have h : env25680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25679_25680 : H12AffineEnvironment.transform 21 2286021 env25679 = env25680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2286021 env25679 == env25680) = true)

theorem identity25680 : scanCanonicalize (H12AffineFastState.compose env25680 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(23+1) ^^^ 229441) := by decide +kernel

theorem selectedBound25680 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env25681 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,2286021,2248768,229441,8328,2248721,2417028,2212199,2347367,2320718,132161,2158925,256,102498,151633,513]

theorem envBound25681 : H12AffineFastState.Bounded env25681 := by
  intro p hp
  have h : env25681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25680_25681 : H12AffineEnvironment.transform 23 229441 env25680 = env25681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 229441 env25680 == env25681) = true)

theorem identity25681 : scanCanonicalize (H12AffineFastState.compose env25681 (packedSelected [13,21] rootPS)) = affineNative (2^(16+1) ^^^ 45405) := by decide +kernel

theorem selectedBound25681 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env25682 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,45405,262144,1024,32768,2097152,2117784,2154781,78108,8328,2154828,2417028,2212199,2187322,2218003,46364,2158925,256,102498,57612,513]

theorem envBound25682 : H12AffineFastState.Bounded env25682 := by
  intro p hp
  have h : env25682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25681_25682 : H12AffineEnvironment.transform 16 45405 env25681 = env25682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45405 env25681 == env25682) = true)

def env25683 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,2248768,16777216,8328,2248721,21331969,4399267,4272291,4294795,16876544,4329609,256,16912418,151632,513]

theorem envBound25683 : H12AffineFastState.Bounded env25683 := by
  intro p hp
  have h : env25683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25678_25683 : H12AffineEnvironment.transform 26 21331969 env25678 = env25683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21331969 env25678 == env25683) = true)

theorem identity25683 : scanCanonicalize (H12AffineFastState.compose env25683 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 192965) := by decide +kernel

theorem selectedBound25683 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env25684 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,192965,2248768,16777216,8328,2248721,17265092,119142,246118,227662,16876544,57676,256,16912418,151632,513]

theorem envBound25684 : H12AffineFastState.Bounded env25684 := by
  intro p hp
  have h : env25684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25683_25684 : H12AffineEnvironment.transform 21 192965 env25683 = env25684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 192965 env25683 == env25684) = true)

theorem identity25684 : scanCanonicalize (H12AffineFastState.compose env25684 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(20+1) ^^^ 249970) := by decide +kernel

theorem selectedBound25684 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env25685 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,249970,192965,98354,16777216,8328,98403,17265092,119142,246118,227662,16876544,57676,256,16912418,151632,513]

theorem envBound25685 : H12AffineFastState.Bounded env25685 := by
  intro p hp
  have h : env25685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25684_25685 : H12AffineEnvironment.transform 20 249970 env25684 = env25685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 249970 env25684 == env25685) = true)

theorem identity25685 : scanCanonicalize (H12AffineFastState.compose env25685 (packedSelected [13,21] rootPS)) = affineNative (2^(23+1) ^^^ 90445) := by decide +kernel

theorem selectedBound25685 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env25686 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,249970,192965,98354,90445,8328,98403,397449,119142,246118,227662,58701,57676,256,225647,151632,513]

theorem envBound25686 : H12AffineFastState.Bounded env25686 := by
  intro p hp
  have h : env25686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25685_25686 : H12AffineEnvironment.transform 23 90445 env25685 = env25686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 90445 env25685 == env25686) = true)

theorem identity25686 : scanCanonicalize (H12AffineFastState.compose env25686 (packedSelected [0,3,5,10,27] rootPS)) = affineNative (2^(16+1) ^^^ 94314) := by decide +kernel

theorem selectedBound25686 : packedSelected [0,3,5,10,27] rootPS < 2^1333 := by decide +kernel

def env25687 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,94314,262144,1024,32768,40984,98735,98354,90445,8328,98403,352483,119142,45324,2340,58701,57676,256,261,73786,513]

theorem envBound25687 : H12AffineFastState.Bounded env25687 := by
  intro p hp
  have h : env25687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25686_25687 : H12AffineEnvironment.transform 16 94314 env25686 = env25687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 94314 env25686 == env25687) = true)

def env25688 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,94266,262144,1024,32768,40984,98735,98354,90397,8328,98355,352435,119094,45324,2340,58653,57628,256,261,73786,513]

theorem envBound25688 : H12AffineFastState.Bounded env25688 := by
  intro p hp
  have h : env25688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25687_25688 : H12AffineEnvironment.transform 5 16 env25687 = env25688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env25687 == env25688) = true)

theorem identity25688 : scanCanonicalize (H12AffineFastState.compose env25688 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 42047) := by decide +kernel

theorem selectedBound25688 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env25689 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,42047,54277,262144,1024,32768,40984,9616,9229,50466,8328,9228,312460,29961,45324,2340,58653,57628,256,261,33797,513]

theorem envBound25689 : H12AffineFastState.Bounded env25689 := by
  intro p hp
  have h : env25689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25688_25689 : H12AffineEnvironment.transform 15 42047 env25688 = env25689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 42047 env25688 == env25689) = true)

def env25690 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,17832,24983,4525,262144,1024,17832,26032,9616,9229,138,8328,9228,262436,29961,29860,2340,8373,9396,256,261,16813,513]

theorem envBound25690 : H12AffineFastState.Bounded env25690 := by
  intro p hp
  have h : env25690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25689_25690 : H12AffineEnvironment.transform 14 17832 env25689 = env25690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 17832 env25689 == env25690) = true)

theorem identity25690 : scanCanonicalize (H12AffineFastState.compose env25690 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(17+1) ^^^ 28032) := by decide +kernel

theorem selectedBound25690 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env25691 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,17832,24983,4525,28032,1024,17832,26032,9616,9229,138,8328,9228,27812,29961,29860,2340,8373,9396,256,261,16813,513]

theorem envBound25691 : H12AffineFastState.Bounded env25691 := by
  intro p hp
  have h : env25691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25690_25691 : H12AffineEnvironment.transform 17 28032 env25690 = env25691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 28032 env25690 == env25691) = true)

def env25692 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,9600,8232,1047,4525,2048,1024,8232,48,9616,9229,138,8328,9228,2340,4233,4388,2340,8373,9396,256,261,9261,513]

theorem envBound25692 : H12AffineFastState.Bounded env25692 := by
  intro p hp
  have h : env25692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25691_25692 : H12AffineEnvironment.transform 13 9600 env25691 = env25692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9600 env25691 == env25692) = true)

theorem identity25692 : scanCanonicalize (H12AffineFastState.compose env25692 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 182) := by decide +kernel

theorem selectedBound25692 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env25693 : List Nat := [2,4,8,16,32,16,128,182,512,1024,2048,4096,8192,9270,8232,1047,4123,2048,1024,8232,48,9254,9229,138,8328,9228,2194,4233,4242,2194,8373,9396,182,179,9261,513]

theorem envBound25693 : H12AffineFastState.Bounded env25693 := by
  intro p hp
  have h : env25693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25692_25693 : H12AffineEnvironment.transform 7 182 env25692 = env25693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 182 env25692 == env25693) = true)

theorem identity25693 : scanCanonicalize (H12AffineFastState.compose env25693 (packedSelected [4,9] rootPS)) = affineNative (2^(12+1) ^^^ 3) := by decide +kernel

theorem selectedBound25693 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env25694 : List Nat := [2,4,8,16,32,16,128,182,512,1024,2048,4096,3,1077,43,1047,4123,2048,1024,43,48,1061,1038,138,139,1039,2194,4233,4242,2194,182,1207,182,179,1070,513]

theorem envBound25694 : H12AffineFastState.Bounded env25694 := by
  intro p hp
  have h : env25694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25693_25694 : H12AffineEnvironment.transform 12 3 env25693 = env25694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3 env25693 == env25694) = true)

def env25695 : List Nat := [2,4,8,16,32,16,128,182,512,140,2048,4096,3,185,43,155,4123,2048,140,43,48,169,130,138,139,131,2194,4233,4242,2194,182,59,182,179,162,513]

theorem envBound25695 : H12AffineFastState.Bounded env25695 := by
  intro p hp
  have h : env25695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25694_25695 : H12AffineEnvironment.transform 9 140 env25694 = env25695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 140 env25694 == env25695) = true)

theorem identity25695 : scanCanonicalize (H12AffineFastState.compose env25695 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound25695 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25696 : List Nat := [2,4,8,16,32,16,128,182,137,140,2048,4096,3,185,43,155,4123,2048,140,43,48,169,130,138,139,131,2194,4233,4242,2194,182,59,182,179,162,136]

theorem envBound25696 : H12AffineFastState.Bounded env25696 := by
  intro p hp
  have h : env25696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25695_25696 : H12AffineEnvironment.transform 8 137 env25695 = env25696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env25695 == env25696) = true)

theorem identity25696 : scanCanonicalize (H12AffineFastState.compose env25696 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound25696 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env25697 : List Nat := [2,4,8,16,32,16,128,182,137,140,2048,48,3,185,43,155,43,2048,140,43,48,169,130,138,139,131,2194,185,162,2194,182,59,182,179,162,136]

theorem envBound25697 : H12AffineFastState.Bounded env25697 := by
  intro p hp
  have h : env25697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25696_25697 : H12AffineEnvironment.transform 11 48 env25696 = env25697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env25696 == env25697) = true)

theorem identity25697 : scanCanonicalize (H12AffineFastState.compose env25697 (packedSelected [0,1,5,8] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound25697 : packedSelected [0,1,5,8] rootPS < 2^1333 := by decide +kernel

def env25698 : List Nat := [2,4,8,11,32,11,128,173,137,140,2048,43,3,162,43,128,43,2048,140,43,43,169,130,138,139,131,2185,162,162,2185,173,32,173,168,162,136]

theorem envBound25698 : H12AffineFastState.Bounded env25698 := by
  intro p hp
  have h : env25698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25697_25698 : H12AffineEnvironment.transform 3 11 env25697 = env25698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env25697 == env25698) = true)

theorem identity25698 : scanCanonicalize (H12AffineFastState.compose env25698 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 162) := by decide +kernel

theorem selectedBound25698 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env25699 : List Nat := [2,4,8,11,32,11,128,173,137,140,162,43,3,162,43,128,43,162,140,43,43,169,130,138,139,131,43,162,162,43,173,32,173,168,162,136]

theorem envBound25699 : H12AffineFastState.Bounded env25699 := by
  intro p hp
  have h : env25699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25698_25699 : H12AffineEnvironment.transform 10 162 env25698 = env25699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 162 env25698 == env25699) = true)

def env25700 : List Nat := [2,4,8,16,32,16,128,182,512,141,2048,4096,3,184,43,154,4123,2048,141,43,48,168,131,138,139,130,2194,4233,4242,2194,182,58,182,179,163,513]

theorem envBound25700 : H12AffineFastState.Bounded env25700 := by
  intro p hp
  have h : env25700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25694_25700 : H12AffineEnvironment.transform 9 141 env25694 = env25700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 141 env25694 == env25700) = true)

theorem identity25700 : scanCanonicalize (H12AffineFastState.compose env25700 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 146) := by decide +kernel

theorem selectedBound25700 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25701 : List Nat := [2,4,8,16,32,16,128,182,146,141,2048,4096,3,184,43,154,4123,2048,141,43,48,168,131,138,139,130,2194,4233,4242,2194,182,58,182,179,163,147]

theorem envBound25701 : H12AffineFastState.Bounded env25701 := by
  intro p hp
  have h : env25701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25700_25701 : H12AffineEnvironment.transform 8 146 env25700 = env25701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 146 env25700 == env25701) = true)

theorem identity25701 : scanCanonicalize (H12AffineFastState.compose env25701 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound25701 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env25702 : List Nat := [2,4,8,11,32,11,128,173,137,141,2048,4096,3,163,43,129,4096,2048,141,43,43,168,131,138,139,130,2185,4233,4233,2185,173,33,173,168,163,136]

theorem envBound25702 : H12AffineFastState.Bounded env25702 := by
  intro p hp
  have h : env25702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25701_25702 : H12AffineEnvironment.transform 3 11 env25701 = env25702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env25701 == env25702) = true)

theorem identity25702 : scanCanonicalize (H12AffineFastState.compose env25702 (packedSelected [0,5] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound25702 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env25703 : List Nat := [2,4,8,11,32,11,128,173,137,141,42,4096,3,163,43,129,4096,42,141,43,43,168,131,138,139,130,163,4233,4233,163,173,33,173,168,163,136]

theorem envBound25703 : H12AffineFastState.Bounded env25703 := by
  intro p hp
  have h : env25703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25702_25703 : H12AffineEnvironment.transform 10 42 env25702 = env25703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env25702 == env25703) = true)

def env25704 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,9601,8233,1046,4525,2049,1024,8233,49,9616,9229,138,8328,9228,2341,4232,4389,2340,8373,9396,256,261,9260,513]

theorem envBound25704 : H12AffineFastState.Bounded env25704 := by
  intro p hp
  have h : env25704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25691_25704 : H12AffineEnvironment.transform 13 9601 env25691 = env25704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9601 env25691 == env25704) = true)

theorem identity25704 : scanCanonicalize (H12AffineFastState.compose env25704 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound25704 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env25705 : List Nat := [2,4,8,16,32,16,128,62,512,1024,2048,4096,8192,9407,8233,1046,4243,2049,1024,8233,49,9390,9229,138,8328,9228,2075,4232,4123,2074,8373,9396,62,59,9260,513]

theorem envBound25705 : H12AffineFastState.Bounded env25705 := by
  intro p hp
  have h : env25705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25704_25705 : H12AffineEnvironment.transform 7 62 env25704 = env25705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env25704 == env25705) = true)

theorem identity25705 : scanCanonicalize (H12AffineFastState.compose env25705 (packedSelected [4,9] rootPS)) = affineNative (2^(12+1) ^^^ 144) := by decide +kernel

theorem selectedBound25705 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env25706 : List Nat := [2,4,8,16,32,16,128,62,512,1024,2048,4096,144,1071,185,1046,4243,2049,1024,185,49,1086,1181,138,24,1180,2075,4232,4123,2074,37,1060,62,59,1212,513]

theorem envBound25706 : H12AffineFastState.Bounded env25706 := by
  intro p hp
  have h : env25706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25705_25706 : H12AffineEnvironment.transform 12 144 env25705 = env25706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 144 env25705 == env25706) = true)

def env25707 : List Nat := [2,4,8,16,32,16,128,62,512,4,2048,4096,144,43,185,18,4243,2049,4,185,49,58,153,138,24,152,2075,4232,4123,2074,37,32,62,59,184,513]

theorem envBound25707 : H12AffineFastState.Bounded env25707 := by
  intro p hp
  have h : env25707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25706_25707 : H12AffineEnvironment.transform 9 4 env25706 = env25707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env25706 == env25707) = true)

theorem identity25707 : scanCanonicalize (H12AffineFastState.compose env25707 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound25707 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25708 : List Nat := [2,4,8,16,32,16,128,62,137,4,2048,4096,144,43,185,18,4243,2049,4,185,49,58,153,138,24,152,2075,4232,4123,2074,37,32,62,59,184,136]

theorem envBound25708 : H12AffineFastState.Bounded env25708 := by
  intro p hp
  have h : env25708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25707_25708 : H12AffineEnvironment.transform 8 137 env25707 = env25708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env25707 == env25708) = true)

theorem identity25708 : scanCanonicalize (H12AffineFastState.compose env25708 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2048) := by decide +kernel

theorem selectedBound25708 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env25709 : List Nat := [2,4,8,16,32,16,128,62,137,4,2048,2048,144,43,185,18,2195,2049,4,185,49,58,153,138,24,152,2075,2184,2075,2074,37,32,62,59,184,136]

theorem envBound25709 : H12AffineFastState.Bounded env25709 := by
  intro p hp
  have h : env25709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25708_25709 : H12AffineEnvironment.transform 11 2048 env25708 = env25709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2048 env25708 == env25709) = true)

theorem identity25709 : scanCanonicalize (H12AffineFastState.compose env25709 (packedSelected [1,7] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound25709 : packedSelected [1,7] rootPS < 2^1333 := by decide +kernel

def env25710 : List Nat := [2,4,8,16,32,16,19,62,26,4,2048,2048,3,43,42,18,2048,2049,4,42,49,58,10,25,24,11,2075,2075,2075,2074,37,32,62,59,43,27]

theorem envBound25710 : H12AffineFastState.Bounded env25710 := by
  intro p hp
  have h : env25710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25709_25710 : H12AffineEnvironment.transform 6 19 env25709 = env25710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env25709 == env25710) = true)

theorem identity25710 : scanCanonicalize (H12AffineFastState.compose env25710 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound25710 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env25711 : List Nat := [2,4,8,16,32,16,19,62,26,4,49,49,3,43,42,18,49,48,4,42,49,58,10,25,24,11,42,42,42,43,37,32,62,59,43,27]

theorem envBound25711 : H12AffineFastState.Bounded env25711 := by
  intro p hp
  have h : env25711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25710_25711 : H12AffineEnvironment.transform 10 49 env25710 = env25711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env25710 == env25711) = true)

def env25712 : List Nat := [2,4,8,16,32,16,128,62,512,5,2048,4096,144,42,185,19,4243,2049,5,185,49,59,152,138,24,153,2075,4232,4123,2074,37,33,62,59,185,513]

theorem envBound25712 : H12AffineFastState.Bounded env25712 := by
  intro p hp
  have h : env25712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25706_25712 : H12AffineEnvironment.transform 9 5 env25706 = env25712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env25706 == env25712) = true)

theorem identity25712 : scanCanonicalize (H12AffineFastState.compose env25712 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound25712 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env25713 : List Nat := [2,4,8,16,32,16,128,62,26,5,2048,4096,144,42,185,19,4243,2049,5,185,49,59,152,138,24,153,2075,4232,4123,2074,37,33,62,59,185,27]

theorem envBound25713 : H12AffineFastState.Bounded env25713 := by
  intro p hp
  have h : env25713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25712_25713 : H12AffineEnvironment.transform 8 26 env25712 = env25713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env25712 == env25713) = true)

theorem identity25713 : scanCanonicalize (H12AffineFastState.compose env25713 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2074) := by decide +kernel

theorem selectedBound25713 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env25714 : List Nat := [2,4,8,16,32,16,128,62,26,5,2048,2074,144,42,185,19,2185,2049,5,185,49,59,152,138,24,153,2075,2194,2049,2074,37,33,62,59,185,27]

theorem envBound25714 : H12AffineFastState.Bounded env25714 := by
  intro p hp
  have h : env25714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25713_25714 : H12AffineEnvironment.transform 11 2074 env25713 = env25714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2074 env25713 == env25714) = true)

theorem identity25714 : scanCanonicalize (H12AffineFastState.compose env25714 (packedSelected [1,7] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound25714 : packedSelected [1,7] rootPS < 2^1333 := by decide +kernel

def env25715 : List Nat := [2,4,8,16,32,16,19,62,26,5,2048,2074,3,42,42,19,2074,2049,5,42,49,59,11,25,24,10,2075,2049,2049,2074,37,33,62,59,42,27]

theorem envBound25715 : H12AffineFastState.Bounded env25715 := by
  intro p hp
  have h : env25715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25714_25715 : H12AffineEnvironment.transform 6 19 env25714 = env25715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env25714 == env25715) = true)

theorem identity25715 : scanCanonicalize (H12AffineFastState.compose env25715 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound25715 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env25716 : List Nat := [2,4,8,16,32,16,19,62,26,5,48,42,3,42,42,19,42,49,5,42,49,59,11,25,24,10,43,49,49,42,37,33,62,59,42,27]

theorem envBound25716 : H12AffineFastState.Bounded env25716 := by
  intro p hp
  have h : env25716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25715_25716 : H12AffineEnvironment.transform 10 48 env25715 = env25716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env25715 == env25716) = true)

def env25717 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,17833,24982,4524,262144,1024,17833,26033,9616,9229,139,8328,9228,262437,29961,29861,2340,8372,9397,256,261,16812,513]

theorem envBound25717 : H12AffineFastState.Bounded env25717 := by
  intro p hp
  have h : env25717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25689_25717 : H12AffineEnvironment.transform 14 17833 env25689 = env25717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 17833 env25689 == env25717) = true)

theorem identity25717 : scanCanonicalize (H12AffineFastState.compose env25717 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 9380) := by decide +kernel

theorem selectedBound25717 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env25718 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,9380,8461,1330,4524,262144,1024,8461,277,9616,9229,139,8328,9228,262437,4525,4097,2340,8372,9397,256,261,9480,513]

theorem envBound25718 : H12AffineFastState.Bounded env25718 := by
  intro p hp
  have h : env25718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25717_25718 : H12AffineEnvironment.transform 13 9380 env25717 = env25718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9380 env25717 == env25718) = true)

theorem identity25718 : scanCanonicalize (H12AffineFastState.compose env25718 (packedSelected [2,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 438) := by decide +kernel

theorem selectedBound25718 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env25719 : List Nat := [2,4,8,16,32,16,128,256,512,1024,438,4096,8192,9380,8461,1330,4524,262144,1024,8461,277,9616,9229,139,8328,9228,262437,4525,4097,146,8372,9397,256,261,9480,513]

theorem envBound25719 : H12AffineFastState.Bounded env25719 := by
  intro p hp
  have h : env25719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25718_25719 : H12AffineEnvironment.transform 10 438 env25718 = env25719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 438 env25718 == env25719) = true)

theorem identity25719 : scanCanonicalize (H12AffineFastState.compose env25719 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1213) := by decide +kernel

theorem selectedBound25719 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env25720 : List Nat := [2,4,8,16,32,16,128,256,512,1024,438,1213,8192,9380,8461,1330,1297,262144,1024,8461,277,9616,9229,139,8328,9228,262437,1296,1212,146,8372,9397,256,261,9480,513]

theorem envBound25720 : H12AffineFastState.Bounded env25720 := by
  intro p hp
  have h : env25720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25719_25720 : H12AffineEnvironment.transform 11 1213 env25719 = env25720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1213 env25719 == env25720) = true)

theorem identity25720 : scanCanonicalize (H12AffineFastState.compose env25720 (packedSelected [1,2,3,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 8331) := by decide +kernel

theorem selectedBound25720 : packedSelected [1,2,3,12,15] rootPS < 2^1333 := by decide +kernel

def env25721 : List Nat := [2,4,8,16,32,16,128,256,512,1024,438,1213,8192,9380,8461,1330,1297,8331,1024,8461,277,9616,9229,139,8328,9228,8622,1296,1212,146,8372,9397,256,261,9480,513]

theorem envBound25721 : H12AffineFastState.Bounded env25721 := by
  intro p hp
  have h : env25721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25720_25721 : H12AffineEnvironment.transform 17 8331 env25720 = env25721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8331 env25720 == env25721) = true)

def env25722 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,94267,262144,1024,32768,40984,98735,98354,90396,8328,98354,352434,119095,45324,2340,58652,57629,256,261,73786,513]

theorem envBound25722 : H12AffineFastState.Bounded env25722 := by
  intro p hp
  have h : env25722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25687_25722 : H12AffineEnvironment.transform 5 17 env25687 = env25722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env25687 == env25722) = true)

theorem identity25722 : scanCanonicalize (H12AffineFastState.compose env25722 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound25722 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env25723 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,1053,16384,32768,65536,87078,262144,1024,32768,33797,98735,98354,83201,1173,98354,345263,119095,38161,2340,49409,50432,256,261,66599,513]

theorem envBound25723 : H12AffineFastState.Bounded env25723 := by
  intro p hp
  have h : env25723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25722_25723 : H12AffineEnvironment.transform 12 1053 env25722 = env25723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env25722 == env25723) = true)

def env25724 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,1053,16384,32768,65536,87078,262144,1024,32768,33797,98307,98354,83117,1173,98354,345263,118939,38077,2184,49325,50348,172,169,66599,513]

theorem envBound25724 : H12AffineFastState.Bounded env25724 := by
  intro p hp
  have h : env25724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25723_25724 : H12AffineEnvironment.transform 7 172 env25723 = env25724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env25723 == env25724) = true)

theorem identity25724 : scanCanonicalize (H12AffineFastState.compose env25724 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 116754) := by decide +kernel

theorem selectedBound25724 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env25725 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,1053,16384,32768,65536,87078,116754,1024,32768,33797,98307,98354,83117,1173,98354,36029,118939,38077,2184,49325,50348,172,169,66599,513]

theorem envBound25725 : H12AffineFastState.Bounded env25725 := by
  intro p hp
  have h : env25725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25724_25725 : H12AffineEnvironment.transform 17 116754 env25724 = env25725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 116754 env25724 == env25725) = true)

theorem identity25725 : scanCanonicalize (H12AffineFastState.compose env25725 (packedSelected [1,3,5,8,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 17447) := by decide +kernel

theorem selectedBound25725 : packedSelected [1,3,5,8,10,12] rootPS < 2^1333 := by decide +kernel

def env25726 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,1053,16384,32768,17447,4097,35893,1024,32768,33797,50212,50197,138,1173,50197,36029,38076,38077,2184,49325,50348,172,169,16384,513]

theorem envBound25726 : H12AffineFastState.Bounded env25726 := by
  intro p hp
  have h : env25726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25725_25726 : H12AffineEnvironment.transform 15 17447 env25725 = env25726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 17447 env25725 == env25726) = true)

theorem identity25726 : scanCanonicalize (H12AffineFastState.compose env25726 (packedSelected [1,3] rootPS)) = affineNative (2^(14+1) ^^^ 555) := by decide +kernel

theorem selectedBound25726 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25727 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,1053,16384,555,17447,4097,3614,1024,555,1582,17935,17982,138,1173,17982,3734,5783,5782,2184,17030,18055,172,169,16384,513]

theorem envBound25727 : H12AffineFastState.Bounded env25727 := by
  intro p hp
  have h : env25727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25726_25727 : H12AffineEnvironment.transform 14 555 env25726 = env25727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 555 env25726 == env25727) = true)

theorem identity25727 : scanCanonicalize (H12AffineFastState.compose env25727 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 2586) := by decide +kernel

theorem selectedBound25727 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env25728 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,1053,2586,555,3645,4097,3614,1024,555,1582,3093,3108,138,1173,3108,3734,5783,5782,2184,2204,3229,172,169,2586,513]

theorem envBound25728 : H12AffineFastState.Bounded env25728 := by
  intro p hp
  have h : env25728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25727_25728 : H12AffineEnvironment.transform 13 2586 env25727 = env25728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2586 env25727 == env25728) = true)

def env25729 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,1053,16384,32768,65536,87078,262144,1024,32768,33797,98306,98354,83116,1173,98354,345263,118938,38076,2185,49324,50349,173,168,66599,513]

theorem envBound25729 : H12AffineFastState.Bounded env25729 := by
  intro p hp
  have h : env25729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25723_25729 : H12AffineEnvironment.transform 7 173 env25723 = env25729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env25723 == env25729) = true)

theorem identity25729 : scanCanonicalize (H12AffineFastState.compose env25729 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 35893) := by decide +kernel

theorem selectedBound25729 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env25730 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,1053,16384,32768,65536,87078,35893,1024,32768,33797,98306,98354,83116,1173,98354,116890,118938,38076,2185,49324,50349,173,168,66599,513]

theorem envBound25730 : H12AffineFastState.Bounded env25730 := by
  intro p hp
  have h : env25730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25729_25730 : H12AffineEnvironment.transform 17 35893 env25729 = env25730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35893 env25729 == env25730) = true)

theorem identity25730 : scanCanonicalize (H12AffineFastState.compose env25730 (packedSelected [10,15] rootPS)) = affineNative (2^(15+1) ^^^ 17446) := by decide +kernel

theorem selectedBound25730 : packedSelected [10,15] rootPS < 2^1333 := by decide +kernel

def env25731 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,1053,16384,32768,17446,4096,35893,1024,32768,33797,50212,50196,138,1173,50196,36028,38076,38076,2185,49324,50349,173,168,16385,513]

theorem envBound25731 : H12AffineFastState.Bounded env25731 := by
  intro p hp
  have h : env25731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25730_25731 : H12AffineEnvironment.transform 15 17446 env25730 = env25731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 17446 env25730 == env25731) = true)

theorem identity25731 : scanCanonicalize (H12AffineFastState.compose env25731 (packedSelected [1,3] rootPS)) = affineNative (2^(13+1) ^^^ 1703) := by decide +kernel

theorem selectedBound25731 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env25732 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,1053,1703,32768,641,4096,35893,1024,32768,33797,33411,33459,138,1173,33459,36028,38076,38076,2185,34315,33290,173,168,1702,513]

theorem envBound25732 : H12AffineFastState.Bounded env25732 := by
  intro p hp
  have h : env25732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25731_25732 : H12AffineEnvironment.transform 13 1703 env25731 = env25732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1703 env25731 == env25732) = true)

theorem identity25732 : scanCanonicalize (H12AffineFastState.compose env25732 (packedSelected [5,8] rootPS)) = affineNative (2^(14+1) ^^^ 3615) := by decide +kernel

theorem selectedBound25732 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env25733 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,1053,1703,3615,641,4096,554,1024,3615,2586,3228,3244,138,1173,3244,675,6819,6819,2185,2068,3093,173,168,1702,513]

theorem envBound25733 : H12AffineFastState.Bounded env25733 := by
  intro p hp
  have h : env25733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25732_25733 : H12AffineEnvironment.transform 14 3615 env25732 = env25733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3615 env25732 == env25733) = true)

theorem identity25733 : scanCanonicalize (H12AffineFastState.compose env25733 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound25733 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env25734 : List Nat := [2,4,8,16,32,17,128,173,137,1024,2048,4096,1053,1070,3222,8,4096,163,1024,3222,2195,3228,3244,138,1173,3244,42,6186,6186,2185,2068,3093,173,168,1071,136]

theorem envBound25734 : H12AffineFastState.Bounded env25734 := by
  intro p hp
  have h : env25734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25733_25734 : H12AffineEnvironment.transform 8 137 env25733 = env25734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env25733 == env25734) = true)

def env25735 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,2248768,16777216,8328,2248720,134217728,151429283,151302307,4294795,16876545,151490696,257,138907683,155701328,513]

theorem envBound25735 : H12AffineFastState.Bounded env25735 := by
  intro p hp
  have h : env25735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25677_25735 : H12AffineEnvironment.transform 18 1025 env25677 = env25735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env25677 == env25735) = true)

def env25736 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,4194304,2248768,16777216,8328,2248720,21331968,4399267,4272291,4294795,16876545,4329608,257,16912419,151632,513]

theorem envBound25736 : H12AffineFastState.Bounded env25736 := by
  intro p hp
  have h : env25736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25735_25736 : H12AffineEnvironment.transform 26 21331968 env25735 = env25736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21331968 env25735 == env25736) = true)

theorem identity25736 : scanCanonicalize (H12AffineFastState.compose env25736 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 62596) := by decide +kernel

theorem selectedBound25736 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env25737 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,62596,2248768,16777216,8328,2248720,17134724,250919,115751,97295,16876545,189452,257,16912419,151632,513]

theorem envBound25737 : H12AffineFastState.Bounded env25737 := by
  intro p hp
  have h : env25737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25736_25737 : H12AffineEnvironment.transform 21 62596 env25736 = env25737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 62596 env25736 == env25737) = true)

theorem identity25737 : scanCanonicalize (H12AffineFastState.compose env25737 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(23+1) ^^^ 2200833) := by decide +kernel

theorem selectedBound25737 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env25738 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,2097152,62596,2248768,2200833,8328,2248720,2417029,250919,115751,97295,2101504,189452,257,2327842,151632,513]

theorem envBound25738 : H12AffineFastState.Bounded env25738 := by
  intro p hp
  have h : env25738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25737_25738 : H12AffineEnvironment.transform 23 2200833 env25737 = env25738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2200833 env25737 == env25738) = true)

theorem identity25738 : scanCanonicalize (H12AffineFastState.compose env25738 (packedSelected [13,21] rootPS)) = affineNative (2^(16+1) ^^^ 45405) := by decide +kernel

theorem selectedBound25738 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env25739 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,45405,262144,1025,32768,2097152,62596,2154781,2200833,8328,2154829,2417029,91514,115751,97295,2101504,21841,257,2176127,57613,513]

theorem envBound25739 : H12AffineFastState.Bounded env25739 := by
  intro p hp
  have h : env25739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25738_25739 : H12AffineEnvironment.transform 16 45405 env25738 = env25739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45405 env25738 == env25739) = true)

theorem identity25739 : scanCanonicalize (H12AffineFastState.compose env25739 (packedSelected [0,3,5,10,27] rootPS)) = affineNative (2^(13+1) ^^^ 5205) := by decide +kernel

theorem selectedBound25739 : packedSelected [0,3,5,10,27] rootPS < 2^1333 := by decide +kernel

def env25740 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5205,32768,65536,45405,262144,1025,32768,2097152,41169,2143560,2200833,8328,2143512,2405840,78127,102514,75866,2101504,260,257,2176127,46424,513]

theorem envBound25740 : H12AffineFastState.Bounded env25740 := by
  intro p hp
  have h : env25740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25739_25740 : H12AffineEnvironment.transform 13 5205 env25739 = env25740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5205 env25739 == env25740) = true)

theorem identity25740 : scanCanonicalize (H12AffineFastState.compose env25740 (packedSelected [1,5,8,12,15,17,24] rootPS)) = affineNative (2^(15+1) ^^^ 32883) := by decide +kernel

theorem selectedBound25740 : packedSelected [1,5,8,12,15,17,24] rootPS < 2^1333 := by decide +kernel

def env25741 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5205,32768,32883,45405,262144,1025,32768,2097152,41169,2143560,2102642,8328,2143512,2405840,45404,4097,43049,2101504,260,257,2143244,46424,513]

theorem envBound25741 : H12AffineFastState.Bounded env25741 := by
  intro p hp
  have h : env25741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25740_25741 : H12AffineEnvironment.transform 15 32883 env25740 = env25741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32883 env25740 == env25741) = true)

theorem identity25741 : scanCanonicalize (H12AffineFastState.compose env25741 (packedSelected [2,3,6,8,10,11,13,17,18] rootPS)) = affineNative (2^(17+1) ^^^ 9782) := by decide +kernel

theorem selectedBound25741 : packedSelected [2,3,6,8,10,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env25742 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5205,32768,32883,45405,9782,1025,32768,2097152,41169,2143560,2102642,8328,2143512,2135014,45404,4097,43049,2101504,260,257,2143244,46424,513]

theorem envBound25742 : H12AffineFastState.Bounded env25742 := by
  intro p hp
  have h : env25742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25741_25742 : H12AffineEnvironment.transform 17 9782 env25741 = env25742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 9782 env25741 == env25742) = true)

def env25743 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5205,32768,32883,45405,9782,1025,32768,46424,41169,16,41002,8328,64,9918,45404,4097,43049,42072,260,257,340,46424,513]

theorem envBound25743 : H12AffineFastState.Bounded env25743 := by
  intro p hp
  have h : env25743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans25742_25743 : H12AffineEnvironment.transform 20 46424 env25742 = env25743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 46424 env25742 == env25743) = true)

theorem identity25743 : scanCanonicalize (H12AffineFastState.compose env25743 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 12556) := by decide +kernel

theorem selectedBound25743 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env25744 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5205,12556,12671,81,9782,1025,12556,1108,4573,16,4390,8328,64,9918,80,4097,6437,5460,260,257,340,1108,513]

theorem envBound25744 : H12AffineFastState.Bounded env25744 := by
  intro p hp
  have h : env25744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart2