import H12CloudChart2Data044

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity10967 : scanCanonicalize (H12AffineFastState.compose env10967 (packedSelected [3,12] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound10967 : packedSelected [3,12] rootPS < 2^1333 := by decide +kernel

def env10968 : List Nat := [2,4,8,16,32,16,34,21,43,1024,2048,1029,9,1028,16,65536,1029,65571,1025,16,1029,65544,16,65536,34,16,59,1029,1029,2096,1040,0,20,1,1028,42]

theorem envBound10968 : H12AffineFastState.Bounded env10968 := by
  intro p hp
  have h : env10968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10967_10968 : H12AffineEnvironment.transform 7 21 env10967 = env10968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env10967 == env10968) = true)

def env10969 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,9,1296,32768,65536,1297,262144,1025,32768,1297,65544,17,16777216,33554432,16875797,17072136,16876565,1297,16845190,16876544,4294967296,257,4328554791,1296,33554440]

theorem envBound10969 : H12AffineFastState.Bounded env10969 := by
  intro p hp
  have h : env10969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10960_10969 : H12AffineEnvironment.transform 11 1297 env10960 = env10969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env10960 == env10969) = true)

theorem identity10969 : scanCanonicalize (H12AffineFastState.compose env10969 (packedSelected [3,5,24] rootPS)) = affineNative (2^(17+1) ^^^ 65545) := by decide +kernel

theorem selectedBound10969 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env10970 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,9,1296,32768,65536,1297,65545,1025,32768,1297,65544,17,16777216,33554432,16875797,16875521,16876565,1297,16845190,16876544,4294967296,257,4328554791,1296,33554440]

theorem envBound10970 : H12AffineFastState.Bounded env10970 := by
  intro p hp
  have h : env10970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10969_10970 : H12AffineEnvironment.transform 17 65545 env10969 = env10970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65545 env10969 == env10970) = true)

theorem identity10970 : scanCanonicalize (H12AffineFastState.compose env10970 (packedSelected [1,3,8,10,12,13,15,19,21] rootPS)) = affineNative (2^(24+1) ^^^ 16877603) := by decide +kernel

theorem selectedBound10970 : packedSelected [1,3,8,10,12,13,15,19,21] rootPS < 2^1333 := by decide +kernel

def env10971 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,9,1296,32768,65536,1297,65545,1025,32768,1297,65544,17,16777216,16877603,16875797,16875521,16876565,1297,16845190,16876544,4294967296,257,4311812356,1296,16877611]

theorem envBound10971 : H12AffineFastState.Bounded env10971 := by
  intro p hp
  have h : env10971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10970_10971 : H12AffineEnvironment.transform 24 16877603 env10970 = env10971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 16877603 env10970 == env10971) = true)

theorem identity10971 : scanCanonicalize (H12AffineFastState.compose env10971 (packedSelected [1,3,5,6,8,10,19,25] rootPS)) = affineNative (2^(10+1) ^^^ 423) := by decide +kernel

theorem selectedBound10971 : packedSelected [1,3,5,6,8,10,19,25] rootPS < 2^1333 := by decide +kernel

def env10972 : List Nat := [2,4,8,16,32,16,128,256,137,1024,423,1297,9,1296,32768,65536,1297,65545,1025,32768,1297,65544,17,16777216,16875908,16875797,16875521,16876565,1297,16842785,16876544,4294967296,257,4311810211,1296,16875916]

theorem envBound10972 : H12AffineFastState.Bounded env10972 := by
  intro p hp
  have h : env10972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10971_10972 : H12AffineEnvironment.transform 10 423 env10971 = env10972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 423 env10971 == env10972) = true)

theorem identity10972 : scanCanonicalize (H12AffineFastState.compose env10972 (packedSelected [1,3,4,9,12,13,15,16,17] rootPS)) = affineNative (2^(23+1) ^^^ 98564) := by decide +kernel

theorem selectedBound10972 : packedSelected [1,3,4,9,12,13,15,16,17] rootPS < 2^1333 := by decide +kernel

def env10973 : List Nat := [2,4,8,16,32,16,128,256,137,1024,423,1297,9,1296,32768,65536,1297,65545,1025,32768,1297,65544,17,98564,128,17,261,1297,1297,33061,1284,4294967296,257,4295000487,1296,136]

theorem envBound10973 : H12AffineFastState.Bounded env10973 := by
  intro p hp
  have h : env10973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10972_10973 : H12AffineEnvironment.transform 23 98564 env10972 = env10973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98564 env10972 == env10973) = true)

theorem identity10973 : scanCanonicalize (H12AffineFastState.compose env10973 (packedSelected [3] rootPS)) = affineNative (2^(31+1) ^^^ 32794) := by decide +kernel

theorem selectedBound10973 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env10974 : List Nat := [2,4,8,16,32,16,128,256,137,1024,423,1297,9,1296,32768,65536,1297,65545,1025,32768,1297,65544,17,98564,128,17,261,1297,1297,33061,1284,32794,257,445,1296,136]

theorem envBound10974 : H12AffineFastState.Bounded env10974 := by
  intro p hp
  have h : env10974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10973_10974 : H12AffineEnvironment.transform 31 32794 env10973 = env10974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 32794 env10973 == env10974) = true)

theorem identity10974 : scanCanonicalize (H12AffineFastState.compose env10974 (packedSelected [6,7] rootPS)) = affineNative (2^(15+1) ^^^ 268) := by decide +kernel

theorem selectedBound10974 : packedSelected [6,7] rootPS < 2^1333 := by decide +kernel

def env10975 : List Nat := [2,4,8,16,32,16,128,256,137,1024,423,1297,9,1296,32768,268,1297,261,1025,32768,1297,260,17,32776,128,17,261,1297,1297,33061,1284,32794,257,445,1296,136]

theorem envBound10975 : H12AffineFastState.Bounded env10975 := by
  intro p hp
  have h : env10975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10974_10975 : H12AffineEnvironment.transform 15 268 env10974 = env10975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 268 env10974 == env10975) = true)

def env10976 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,9,4097,32768,65536,4096,262144,1025,32768,4096,65545,5376,16777216,33554432,16875797,17072137,16876565,4096,16850070,16876544,4294967296,257,4328559671,4097,33554440]

theorem envBound10976 : H12AffineFastState.Bounded env10976 := by
  intro p hp
  have h : env10976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10959_10976 : H12AffineEnvironment.transform 21 65545 env10959 = env10976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65545 env10959 == env10976) = true)

def env10977 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,9,1297,32768,65536,1296,262144,1025,32768,1296,65545,16,16777216,33554432,16875797,17072137,16876565,1296,16845190,16876544,4294967296,257,4328554791,1297,33554440]

theorem envBound10977 : H12AffineFastState.Bounded env10977 := by
  intro p hp
  have h : env10977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10976_10977 : H12AffineEnvironment.transform 11 1296 env10976 = env10977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env10976 == env10977) = true)

theorem identity10977 : scanCanonicalize (H12AffineFastState.compose env10977 (packedSelected [3,5,24] rootPS)) = affineNative (2^(24+1) ^^^ 17072388) := by decide +kernel

theorem selectedBound10977 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env10978 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,9,1297,32768,65536,1296,262144,1025,32768,1296,65545,16,16777216,17072388,16875797,17072137,16876565,1296,16845190,16876544,4294967296,257,4312006691,1297,17072396]

theorem envBound10978 : H12AffineFastState.Bounded env10978 := by
  intro p hp
  have h : env10978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10977_10978 : H12AffineEnvironment.transform 24 17072388 env10977 = env10978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 17072388 env10977 == env10978) = true)

theorem identity10978 : scanCanonicalize (H12AffineFastState.compose env10978 (packedSelected [1,3,8,13,15,19] rootPS)) = affineNative (2^(14+1) ^^^ 261) := by decide +kernel

theorem selectedBound10978 : packedSelected [1,3,8,13,15,19] rootPS < 2^1333 := by decide +kernel

def env10979 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,9,1297,261,65536,1296,262144,1025,261,1296,65545,16,16777216,17039361,16842768,17039628,16844048,1296,16845190,16844037,4294967296,257,4312006691,1297,17039369]

theorem envBound10979 : H12AffineFastState.Bounded env10979 := by
  intro p hp
  have h : env10979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10978_10979 : H12AffineEnvironment.transform 14 261 env10978 = env10979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 261 env10978 == env10979) = true)

theorem identity10979 : scanCanonicalize (H12AffineFastState.compose env10979 (packedSelected [0,4,7,9,16,20] rootPS)) = affineNative (2^(23+1) ^^^ 65536) := by decide +kernel

theorem selectedBound10979 : packedSelected [0,4,7,9,16,20] rootPS < 2^1333 := by decide +kernel

def env10980 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,9,1297,261,65536,1296,262144,1025,261,1296,65545,16,65536,327681,16,327948,1296,1296,2438,1285,4294967296,257,4295295011,1297,327689]

theorem envBound10980 : H12AffineFastState.Bounded env10980 := by
  intro p hp
  have h : env10980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10979_10980 : H12AffineEnvironment.transform 23 65536 env10979 = env10980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 65536 env10979 == env10980) = true)

theorem identity10980 : scanCanonicalize (H12AffineFastState.compose env10980 (packedSelected [1,3,5] rootPS)) = affineNative (2^(17+1) ^^^ 65665) := by decide +kernel

theorem selectedBound10980 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env10981 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,9,1297,261,65536,1296,65665,1025,261,1296,65545,16,65536,128,16,397,1296,1296,2438,1285,4294967296,257,4294967458,1297,136]

theorem envBound10981 : H12AffineFastState.Bounded env10981 := by
  intro p hp
  have h : env10981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10980_10981 : H12AffineEnvironment.transform 17 65665 env10980 = env10981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env10980 == env10981) = true)

theorem identity10981 : scanCanonicalize (H12AffineFastState.compose env10981 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 163) := by decide +kernel

theorem selectedBound10981 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env10982 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,9,1297,261,65536,1296,65665,1025,261,1296,65545,16,65536,128,16,397,1296,1296,2438,1285,163,257,1,1297,136]

theorem envBound10982 : H12AffineFastState.Bounded env10982 := by
  intro p hp
  have h : env10982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10981_10982 : H12AffineEnvironment.transform 31 163 env10981 = env10982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 163 env10981 == env10982) = true)

theorem identity10982 : scanCanonicalize (H12AffineFastState.compose env10982 (packedSelected [1,10] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound10982 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env10983 : List Nat := [2,4,8,16,32,16,35,256,42,1024,2048,1296,9,1297,261,65536,1296,65570,1025,261,1296,65545,16,65536,35,16,302,1296,1296,2341,1285,0,257,1,1297,43]

theorem envBound10983 : H12AffineFastState.Bounded env10983 := by
  intro p hp
  have h : env10983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10982_10983 : H12AffineEnvironment.transform 6 35 env10982 = env10983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env10982 == env10983) = true)

theorem identity10983 : scanCanonicalize (H12AffineFastState.compose env10983 (packedSelected [3,12] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound10983 : packedSelected [3,12] rootPS < 2^1333 := by decide +kernel

def env10984 : List Nat := [2,4,8,16,32,16,35,21,42,1024,2048,1029,9,1028,16,65536,1029,65570,1025,16,1029,65545,16,65536,35,16,59,1029,1029,2096,1040,0,20,1,1028,43]

theorem envBound10984 : H12AffineFastState.Bounded env10984 := by
  intro p hp
  have h : env10984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10983_10984 : H12AffineEnvironment.transform 7 21 env10983 = env10984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env10983 == env10984) = true)

def env10985 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,9,1296,32768,65536,1297,262144,1025,32768,1297,65545,17,16777216,33554432,16875797,17072137,16876565,1297,16845191,16876544,4294967296,257,4328554790,1296,33554440]

theorem envBound10985 : H12AffineFastState.Bounded env10985 := by
  intro p hp
  have h : env10985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10976_10985 : H12AffineEnvironment.transform 11 1297 env10976 = env10985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env10976 == env10985) = true)

theorem identity10985 : scanCanonicalize (H12AffineFastState.compose env10985 (packedSelected [3,5,24] rootPS)) = affineNative (2^(23+1) ^^^ 295180) := by decide +kernel

theorem selectedBound10985 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env10986 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,9,1296,32768,65536,1297,262144,1025,32768,1297,65545,17,295180,33554432,327705,261,328985,1297,362635,328972,4294967296,257,4328554790,1296,33554440]

theorem envBound10986 : H12AffineFastState.Bounded env10986 := by
  intro p hp
  have h : env10986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10985_10986 : H12AffineEnvironment.transform 23 295180 env10985 = env10986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 295180 env10985 == env10986) = true)

theorem identity10986 : scanCanonicalize (H12AffineFastState.compose env10986 (packedSelected [1,3,8,10,12,13,15,19,21] rootPS)) = affineNative (2^(24+1) ^^^ 330030) := by decide +kernel

theorem selectedBound10986 : packedSelected [1,3,8,10,12,13,15,19,21] rootPS < 2^1333 := by decide +kernel

def env10987 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,9,1296,32768,65536,1297,262144,1025,32768,1297,65545,17,295180,330030,327705,261,328985,1297,362635,328972,4294967296,257,4295329800,1296,330022]

theorem envBound10987 : H12AffineFastState.Bounded env10987 := by
  intro p hp
  have h : env10987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10986_10987 : H12AffineEnvironment.transform 24 330030 env10986 = env10987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 330030 env10986 == env10987) = true)

theorem identity10987 : scanCanonicalize (H12AffineFastState.compose env10987 (packedSelected [1,10,12,13,15,19] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound10987 : packedSelected [1,10,12,13,15,19] rootPS < 2^1333 := by decide +kernel

def env10988 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,9,1296,32768,33166,1297,262144,1025,32768,1297,33159,17,295180,297120,295319,261,296087,1297,264453,296066,4294967296,257,4295231878,1296,297128]

theorem envBound10988 : H12AffineFastState.Bounded env10988 := by
  intro p hp
  have h : env10988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10987_10988 : H12AffineEnvironment.transform 15 33166 env10987 = env10988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env10987 == env10988) = true)

theorem identity10988 : scanCanonicalize (H12AffineFastState.compose env10988 (packedSelected [2,3,4,5,6,7,8,12,13,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 130) := by decide +kernel

theorem selectedBound10988 : packedSelected [2,3,4,5,6,7,8,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env10989 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1297,9,1296,130,268,1297,262144,1025,130,1297,261,17,262542,264226,262421,261,263189,1297,264453,263168,4294967296,257,4295231878,1296,264234]

theorem envBound10989 : H12AffineFastState.Bounded env10989 := by
  intro p hp
  have h : env10989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10988_10989 : H12AffineEnvironment.transform 14 130 env10988 = env10989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 130 env10988 == env10989) = true)

theorem identity10989 : scanCanonicalize (H12AffineFastState.compose env10989 (packedSelected [0,4,7,8,9,10,11,13,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 423) := by decide +kernel

theorem selectedBound10989 : packedSelected [0,4,7,8,9,10,11,13,15,16] rootPS < 2^1333 := by decide +kernel

def env10990 : List Nat := [2,4,8,16,32,16,128,256,137,1024,423,1297,9,1296,130,268,1297,262144,1025,130,1297,261,17,262542,262533,262421,261,263189,1297,262306,263168,4294967296,257,4295229473,1296,262541]

theorem envBound10990 : H12AffineFastState.Bounded env10990 := by
  intro p hp
  have h : env10990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10989_10990 : H12AffineEnvironment.transform 10 423 env10989 = env10990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 423 env10989 == env10990) = true)

theorem identity10990 : scanCanonicalize (H12AffineFastState.compose env10990 (packedSelected [0,2,4,5,6] rootPS)) = affineNative (2^(17+1) ^^^ 397) := by decide +kernel

theorem selectedBound10990 : packedSelected [0,2,4,5,6] rootPS < 2^1333 := by decide +kernel

def env10991 : List Nat := [2,4,8,16,32,16,128,256,137,1024,423,1297,9,1296,130,268,1297,397,1025,130,1297,261,17,3,8,152,261,1432,1297,303,1421,4294967296,257,4294967724,1296,0]

theorem envBound10991 : H12AffineFastState.Bounded env10991 := by
  intro p hp
  have h : env10991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10990_10991 : H12AffineEnvironment.transform 17 397 env10990 = env10991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 397 env10990 == env10991) = true)

theorem identity10991 : scanCanonicalize (H12AffineFastState.compose env10991 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound10991 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env10992 : List Nat := [2,4,8,16,32,16,128,14,137,1024,169,1055,9,1054,130,2,1055,131,1025,130,1055,11,17,3,8,152,11,1174,1055,33,1155,4294967296,15,4294967458,1054,0]

theorem envBound10992 : H12AffineFastState.Bounded env10992 := by
  intro p hp
  have h : env10992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10991_10992 : H12AffineEnvironment.transform 7 14 env10991 = env10992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env10991 == env10992) = true)

theorem identity10992 : scanCanonicalize (H12AffineFastState.compose env10992 (packedSelected [1,3,4,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound10992 : packedSelected [1,3,4,9] rootPS < 2^1333 := by decide +kernel

def env10993 : List Nat := [2,4,8,16,32,16,8,14,1,1024,33,1055,9,1054,10,2,1055,11,1025,10,1055,11,17,3,8,16,11,1054,1055,33,1035,4294967296,15,4294967338,1054,0]

theorem envBound10993 : H12AffineFastState.Bounded env10993 := by
  intro p hp
  have h : env10993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10992_10993 : H12AffineEnvironment.transform 6 8 env10992 = env10993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env10992 == env10993) = true)

theorem identity10993 : scanCanonicalize (H12AffineFastState.compose env10993 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 48) := by decide +kernel

theorem selectedBound10993 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10994 : List Nat := [2,4,8,16,32,16,8,14,1,1024,33,1055,9,1054,10,2,1055,11,1025,10,1055,11,17,3,8,16,11,1054,1055,33,1035,48,15,26,1054,0]

theorem envBound10994 : H12AffineFastState.Bounded env10994 := by
  intro p hp
  have h : env10994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10993_10994 : H12AffineEnvironment.transform 31 48 env10993 = env10994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 48 env10993 == env10994) = true)

theorem identity10994 : scanCanonicalize (H12AffineFastState.compose env10994 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound10994 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10995 : List Nat := [2,4,8,16,32,16,8,14,1,21,33,10,9,11,10,2,10,11,20,10,10,11,17,3,8,16,11,11,10,33,30,48,15,26,11,0]

theorem envBound10995 : H12AffineFastState.Bounded env10995 := by
  intro p hp
  have h : env10995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10994_10995 : H12AffineEnvironment.transform 9 21 env10994 = env10995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env10994 == env10995) = true)

theorem identity10995 : scanCanonicalize (H12AffineFastState.compose env10995 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound10995 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env10996 : List Nat := [2,4,8,16,10,16,8,14,1,21,11,10,9,11,10,2,10,11,20,10,10,11,17,3,8,16,11,11,10,11,30,26,15,26,11,0]

theorem envBound10996 : H12AffineFastState.Bounded env10996 := by
  intro p hp
  have h : env10996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10995_10996 : H12AffineEnvironment.transform 4 10 env10995 = env10996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env10995 == env10996) = true)

theorem identity10996 : scanCanonicalize (H12AffineFastState.compose env10996 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound10996 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10997 : List Nat := [2,4,8,11,10,11,8,14,1,14,11,10,9,11,10,2,10,11,15,10,10,11,10,3,8,11,11,11,10,11,5,1,15,1,11,0]

theorem envBound10997 : H12AffineFastState.Bounded env10997 := by
  intro p hp
  have h : env10997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10996_10997 : H12AffineEnvironment.transform 3 11 env10996 = env10997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env10996 == env10997) = true)

theorem identity10997 : scanCanonicalize (H12AffineFastState.compose env10997 (packedSelected [13] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound10997 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env10998 : List Nat := [2,4,2,1,0,1,2,4,1,4,1,0,3,1,0,2,0,1,5,0,0,1,0,3,2,1,1,1,0,1,5,1,5,1,1,0]

theorem envBound10998 : H12AffineFastState.Bounded env10998 := by
  intro p hp
  have h : env10998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10997_10998 : H12AffineEnvironment.transform 2 2 env10997 = env10998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env10997 == env10998) = true)

def env10999 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,640,16384,32768,65536,4097,262144,1025,32768,4096,4194304,17665,16777216,33554432,16875796,21352449,16897045,4097,20978846,16876544,4294967296,257,4332832439,4096,33554440]

theorem envBound10999 : H12AffineFastState.Bounded env10999 := by
  intro p hp
  have h : env10999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10941_10999 : H12AffineEnvironment.transform 16 4097 env10941 = env10999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4097 env10941 == env10999) = true)

theorem identity10999 : scanCanonicalize (H12AffineFastState.compose env10999 (packedSelected [1,3,5,8,9,10,19,22] rootPS)) = affineNative (2^(13+1) ^^^ 1944) := by decide +kernel

theorem selectedBound10999 : packedSelected [1,3,5,8,9,10,19,22] rootPS < 2^1333 := by decide +kernel

def env11000 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,640,1944,32768,65536,4097,262144,1025,32768,4096,4194304,665,16777216,33554432,16875796,21338009,16880525,4097,20978846,16876544,4294967296,257,4332814639,4096,33554440]

theorem envBound11000 : H12AffineFastState.Bounded env11000 := by
  intro p hp
  have h : env11000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10999_11000 : H12AffineEnvironment.transform 13 1944 env10999 = env11000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1944 env10999 == env11000) = true)

def env11001 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,8,1296,32768,65536,4097,262144,1025,32768,4096,4194304,17,16777216,33554432,16875796,21337361,16879877,4097,20978846,16876544,4294967296,257,4332814639,4096,33554440]

theorem envBound11001 : H12AffineFastState.Bounded env11001 := by
  intro p hp
  have h : env11001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11000_11001 : H12AffineEnvironment.transform 8 136 env11000 = env11001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env11000 == env11001) = true)

theorem identity11001 : scanCanonicalize (H12AffineFastState.compose env11001 (packedSelected [3,6,10,24,25,26] rootPS)) = affineNative (2^(24+1) ^^^ 16880789) := by decide +kernel

theorem selectedBound11001 : packedSelected [3,6,10,24,25,26] rootPS < 2^1333 := by decide +kernel

def env11002 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,8,1296,32768,65536,4097,262144,1025,32768,4096,4194304,17,16777216,16880789,16875796,21337361,16879877,4097,20978846,16876544,4294967296,257,4315944378,4096,16880797]

theorem envBound11002 : H12AffineFastState.Bounded env11002 := by
  intro p hp
  have h : env11002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11001_11002 : H12AffineEnvironment.transform 24 16880789 env11001 = env11002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 16880789 env11001 == env11002) = true)

theorem identity11002 : scanCanonicalize (H12AffineFastState.compose env11002 (packedSelected [3,5,6,8,10,25,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 103444) := by decide +kernel

theorem selectedBound11002 : packedSelected [3,5,6,8,10,25,28,31] rootPS < 2^1333 := by decide +kernel

def env11003 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,8,1296,32768,65536,4097,262144,1025,32768,4096,4194304,17,103444,129,5376,4456709,1297,4097,4294794,4116,4294967296,257,4299260334,4096,137]

theorem envBound11003 : H12AffineFastState.Bounded env11003 := by
  intro p hp
  have h : env11003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11002_11003 : H12AffineEnvironment.transform 23 103444 env11002 = env11003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 103444 env11002 == env11003) = true)

theorem identity11003 : scanCanonicalize (H12AffineFastState.compose env11003 (packedSelected [5,8,17,21] rootPS)) = affineNative (2^(14+1) ^^^ 260) := by decide +kernel

theorem selectedBound11003 : packedSelected [5,8,17,21] rootPS < 2^1333 := by decide +kernel

def env11004 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,8,1296,260,65536,4097,262144,1025,260,4096,4194304,17,70928,129,5376,4456709,1297,4097,4262286,4116,4294967296,257,4299227306,4096,137]

theorem envBound11004 : H12AffineFastState.Bounded env11004 := by
  intro p hp
  have h : env11004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11003_11004 : H12AffineEnvironment.transform 14 260 env11003 = env11004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 260 env11003 == env11004) = true)

theorem identity11004 : scanCanonicalize (H12AffineFastState.compose env11004 (packedSelected [5,6,8,10,12,13] rootPS)) = affineNative (2^(31+1) ^^^ 4267157) := by decide +kernel

theorem selectedBound11004 : packedSelected [5,6,8,10,12,13] rootPS < 2^1333 := by decide +kernel

def env11005 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,8,1296,260,65536,4097,262144,1025,260,4096,4194304,17,70928,129,5376,4456709,1297,4097,4262286,4116,4267157,257,7231,4096,137]

theorem envBound11005 : H12AffineFastState.Bounded env11005 := by
  intro p hp
  have h : env11005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11004_11005 : H12AffineEnvironment.transform 31 4267157 env11004 = env11005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4267157 env11004 == env11005) = true)

theorem identity11005 : scanCanonicalize (H12AffineFastState.compose env11005 (packedSelected [10,12,17] rootPS)) = affineNative (2^(17+1) ^^^ 72895) := by decide +kernel

theorem selectedBound11005 : packedSelected [10,12,17] rootPS < 2^1333 := by decide +kernel

def env11006 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,8,1296,260,65536,4097,72895,1025,260,4096,4194304,17,70928,129,5376,4267450,1297,4097,4262286,4116,4267157,257,7231,4096,137]

theorem envBound11006 : H12AffineFastState.Bounded env11006 := by
  intro p hp
  have h : env11006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11005_11006 : H12AffineEnvironment.transform 17 72895 env11005 = env11006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 72895 env11005 == env11006) = true)

theorem identity11006 : scanCanonicalize (H12AffineFastState.compose env11006 (packedSelected [1,24] rootPS)) = affineNative (2^(15+1) ^^^ 138) := by decide +kernel

theorem selectedBound11006 : packedSelected [1,24] rootPS < 2^1333 := by decide +kernel

def env11007 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,8,1296,260,138,4097,7221,1025,260,4096,4194304,17,5530,129,5376,4201776,1297,4097,4196612,4116,4201503,257,7231,4096,137]

theorem envBound11007 : H12AffineFastState.Bounded env11007 := by
  intro p hp
  have h : env11007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11006_11007 : H12AffineEnvironment.transform 15 138 env11006 = env11007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 138 env11006 == env11007) = true)

def env11008 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,8,1296,260,138,4097,7221,1025,260,4096,5408,17,5530,129,5376,2064,1297,4097,7204,4116,2367,257,7231,4096,137]

theorem envBound11008 : H12AffineFastState.Bounded env11008 := by
  intro p hp
  have h : env11008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11007_11008 : H12AffineEnvironment.transform 21 5408 env11007 = env11008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 5408 env11007 == env11008) = true)

theorem identity11008 : scanCanonicalize (H12AffineFastState.compose env11008 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 182) := by decide +kernel

theorem selectedBound11008 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11009 : List Nat := [2,4,8,16,32,16,128,182,136,1024,2048,4096,8,1190,178,138,4097,7221,1025,178,4096,5270,17,5164,129,5302,2064,1191,4097,7204,4116,2185,183,7231,4096,137]

theorem envBound11009 : H12AffineFastState.Bounded env11009 := by
  intro p hp
  have h : env11009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11008_11009 : H12AffineEnvironment.transform 7 182 env11008 = env11009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 182 env11008 == env11009) = true)

theorem identity11009 : scanCanonicalize (H12AffineFastState.compose env11009 (packedSelected [6,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 1180) := by decide +kernel

theorem selectedBound11009 : packedSelected [6,10,12] rootPS < 2^1333 := by decide +kernel

def env11010 : List Nat := [2,4,8,16,32,16,128,182,136,1024,2048,1180,8,1190,178,138,1181,2217,1025,178,1180,10,17,176,129,42,2064,1191,1181,2232,1160,2185,183,2211,1180,137]

theorem envBound11010 : H12AffineFastState.Bounded env11010 := by
  intro p hp
  have h : env11010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11009_11010 : H12AffineEnvironment.transform 11 1180 env11009 = env11010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1180 env11009 == env11010) = true)

def env11011 : List Nat := [2,4,8,16,32,16,128,182,136,1024,0,1180,8,1190,178,138,1181,169,1025,178,1180,10,17,176,129,42,16,1191,1181,184,1160,137,183,163,1180,137]

theorem envBound11011 : H12AffineFastState.Bounded env11011 := by
  intro p hp
  have h : env11011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11010_11011 : H12AffineEnvironment.transform 10 0 env11010 = env11011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env11010 == env11011) = true)

theorem identity11011 : scanCanonicalize (H12AffineFastState.compose env11011 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound11011 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env11012 : List Nat := [2,4,8,16,32,16,3,53,11,1024,0,1055,8,1061,49,9,1054,42,1025,49,1055,10,17,51,2,42,16,1060,1054,59,1035,10,52,32,1055,10]

theorem envBound11012 : H12AffineFastState.Bounded env11012 := by
  intro p hp
  have h : env11012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11011_11012 : H12AffineEnvironment.transform 6 3 env11011 = env11012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env11011 == env11012) = true)

theorem identity11012 : scanCanonicalize (H12AffineFastState.compose env11012 (packedSelected [0,2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound11012 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env11013 : List Nat := [2,4,8,16,11,16,3,30,11,1024,0,1055,8,1038,26,9,1054,1,1025,26,1055,10,17,24,2,1,16,1039,1054,16,1035,10,31,11,1055,10]

theorem envBound11013 : H12AffineFastState.Bounded env11013 := by
  intro p hp
  have h : env11013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11012_11013 : H12AffineEnvironment.transform 4 11 env11012 = env11013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env11012 == env11013) = true)

theorem identity11013 : scanCanonicalize (H12AffineFastState.compose env11013 (packedSelected [0,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound11013 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env11014 : List Nat := [2,4,3,16,0,16,3,21,0,1024,0,1044,3,1029,17,2,1045,1,1025,17,1044,1,17,19,2,1,16,1028,1045,16,1024,1,20,0,1044,1]

theorem envBound11014 : H12AffineFastState.Bounded env11014 := by
  intro p hp
  have h : env11014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11013_11014 : H12AffineEnvironment.transform 2 3 env11013 = env11014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env11013 == env11014) = true)

theorem identity11014 : scanCanonicalize (H12AffineFastState.compose env11014 (packedSelected [10] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound11014 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env11015 : List Nat := [2,4,3,1,0,1,3,4,0,1024,0,1029,3,1029,0,2,1028,1,1025,0,1029,1,0,2,2,1,1,1028,1028,1,1024,1,5,0,1029,1]

theorem envBound11015 : H12AffineFastState.Bounded env11015 := by
  intro p hp
  have h : env11015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11014_11015 : H12AffineEnvironment.transform 3 1 env11014 = env11015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env11014 == env11015) = true)

def leafEnv11015 : List Nat := [2,4,3,1,0,1,3,4,0,1024,0,1029,3,1029,0,2,1028,1,1025,0,1029,1,0,2,1025,2,1,1,1,1028,1028,1,1024,1,5,0,5,3,1029,1,0,1028,1]

def active11015 : List Nat := [0,1,9]

def tree11015 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11015 : H12WitnessSearch.Good tree11015 := H12GlobalWitnessIndex.good

theorem leafIdentity11015 : H12AffineFastState.composeSystem env11015 rootObs = leafEnv11015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11015 rootObs == leafEnv11015) = true)

theorem terminalChecked11015 : H12PackedTerminal.terminalCheckFast leafEnv11015 active11015 tree11015 = true := by decide +kernel

def env11016 : List Nat := [2,4,8,16,32,16,128,182,136,1024,1,1180,8,1190,178,138,1181,168,1025,178,1180,10,17,176,129,42,17,1191,1181,185,1160,136,183,162,1180,137]

theorem envBound11016 : H12AffineFastState.Bounded env11016 := by
  intro p hp
  have h : env11016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11010_11016 : H12AffineEnvironment.transform 10 1 env11010 = env11016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env11010 == env11016) = true)

theorem identity11016 : scanCanonicalize (H12AffineFastState.compose env11016 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound11016 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env11017 : List Nat := [2,4,8,16,32,16,56,14,48,1024,1,1060,8,1054,10,50,1061,16,1025,10,1060,10,17,8,57,42,17,1055,1061,1,1072,48,15,26,1060,49]

theorem envBound11017 : H12AffineFastState.Bounded env11017 := by
  intro p hp
  have h : env11017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11016_11017 : H12AffineEnvironment.transform 6 56 env11016 = env11017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env11016 == env11017) = true)

theorem identity11017 : scanCanonicalize (H12AffineFastState.compose env11017 (packedSelected [2,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound11017 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env11018 : List Nat := [2,4,8,16,16,16,8,14,0,1024,1,1044,8,1054,10,2,1045,16,1025,10,1044,10,17,8,9,26,17,1055,1045,1,1024,0,15,26,1044,1]

theorem envBound11018 : H12AffineFastState.Bounded env11018 := by
  intro p hp
  have h : env11018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11017_11018 : H12AffineEnvironment.transform 4 16 env11017 = env11018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env11017 == env11018) = true)

theorem identity11018 : scanCanonicalize (H12AffineFastState.compose env11018 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound11018 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11019 : List Nat := [2,4,8,10,10,10,8,14,0,1024,1,1038,8,1028,10,2,1039,10,1025,10,1038,10,11,8,9,0,11,1029,1039,1,1024,0,15,0,1038,1]

theorem envBound11019 : H12AffineFastState.Bounded env11019 := by
  intro p hp
  have h : env11019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11018_11019 : H12AffineEnvironment.transform 3 10 env11018 = env11019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env11018 == env11019) = true)

def env11020 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,8,1296,260,138,4097,7221,1025,260,4096,5409,17,5530,129,5376,2065,1297,4097,7205,4116,2366,257,7231,4096,137]

theorem envBound11020 : H12AffineFastState.Bounded env11020 := by
  intro p hp
  have h : env11020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11007_11020 : H12AffineEnvironment.transform 21 5409 env11007 = env11020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 5409 env11007 == env11020) = true)

theorem identity11020 : scanCanonicalize (H12AffineFastState.compose env11020 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 1191) := by decide +kernel

theorem selectedBound11020 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11021 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,1191,8,1296,260,138,1190,2194,1025,260,1191,390,17,317,129,423,2065,1297,1190,2178,1203,2366,257,2200,1191,137]

theorem envBound11021 : H12AffineFastState.Bounded env11021 := by
  intro p hp
  have h : env11021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11020_11021 : H12AffineEnvironment.transform 11 1191 env11020 = env11021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1191 env11020 == env11021) = true)

theorem identity11021 : scanCanonicalize (H12AffineFastState.compose env11021 (packedSelected [6,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound11021 : packedSelected [6,10,12] rootPS < 2^1333 := by decide +kernel

def env11022 : List Nat := [2,4,8,16,32,16,128,140,136,1024,2048,1191,8,1180,136,138,1190,2194,1025,136,1191,10,17,177,129,43,2065,1181,1190,2178,1203,2226,141,2200,1191,137]

theorem envBound11022 : H12AffineFastState.Bounded env11022 := by
  intro p hp
  have h : env11022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11021_11022 : H12AffineEnvironment.transform 7 140 env11021 = env11022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env11021 == env11022) = true)

def env11023 : List Nat := [2,4,8,16,32,16,128,140,136,1024,0,1191,8,1180,136,138,1190,146,1025,136,1191,10,17,177,129,43,17,1181,1190,130,1203,178,141,152,1191,137]

theorem envBound11023 : H12AffineFastState.Bounded env11023 := by
  intro p hp
  have h : env11023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11022_11023 : H12AffineEnvironment.transform 10 0 env11022 = env11023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env11022 == env11023) = true)

theorem identity11023 : scanCanonicalize (H12AffineFastState.compose env11023 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound11023 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env11024 : List Nat := [2,4,8,16,32,16,56,52,48,1024,0,1055,8,1060,48,50,1054,42,1025,48,1055,10,17,9,57,43,17,1061,1054,58,1035,10,53,32,1055,49]

theorem envBound11024 : H12AffineFastState.Bounded env11024 := by
  intro p hp
  have h : env11024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11023_11024 : H12AffineEnvironment.transform 6 56 env11023 = env11024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env11023 == env11024) = true)

theorem identity11024 : scanCanonicalize (H12AffineFastState.compose env11024 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound11024 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env11025 : List Nat := [2,4,8,1,32,1,41,37,33,1024,0,1038,8,1060,33,35,1039,42,1025,33,1038,10,0,9,40,43,0,1061,1039,43,1035,10,36,32,1038,32]

theorem envBound11025 : H12AffineFastState.Bounded env11025 := by
  intro p hp
  have h : env11025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11024_11025 : H12AffineEnvironment.transform 3 1 env11024 = env11025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env11024 == env11025) = true)

theorem identity11025 : scanCanonicalize (H12AffineFastState.compose env11025 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound11025 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env11026 : List Nat := [2,4,8,1,11,1,2,14,10,1024,0,1038,8,1039,10,8,1039,1,1025,10,1038,10,0,9,3,0,0,1038,1039,0,1035,10,15,11,1038,11]

theorem envBound11026 : H12AffineFastState.Bounded env11026 := by
  intro p hp
  have h : env11026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11025_11026 : H12AffineEnvironment.transform 4 11 env11025 = env11026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env11025 == env11026) = true)

theorem identity11026 : scanCanonicalize (H12AffineFastState.compose env11026 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound11026 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env11027 : List Nat := [2,4,3,1,0,1,2,5,1,1024,0,1029,3,1028,1,3,1028,1,1025,1,1029,1,0,2,3,0,0,1029,1028,0,1024,1,4,0,1029,0]

theorem envBound11027 : H12AffineFastState.Bounded env11027 := by
  intro p hp
  have h : env11027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11026_11027 : H12AffineEnvironment.transform 2 3 env11026 = env11027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env11026 == env11027) = true)

def env11028 : List Nat := [2,4,8,16,32,16,128,140,136,1024,1,1191,8,1180,136,138,1190,147,1025,136,1191,10,17,177,129,43,16,1181,1190,131,1203,179,141,153,1191,137]

theorem envBound11028 : H12AffineFastState.Bounded env11028 := by
  intro p hp
  have h : env11028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11022_11028 : H12AffineEnvironment.transform 10 1 env11022 = env11028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env11022 == env11028) = true)

theorem identity11028 : scanCanonicalize (H12AffineFastState.compose env11028 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound11028 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env11029 : List Nat := [2,4,8,16,32,16,2,14,10,1024,1,1061,8,1054,10,8,1060,17,1025,10,1061,10,17,51,3,43,16,1055,1060,1,1073,49,15,27,1061,11]

theorem envBound11029 : H12AffineFastState.Bounded env11029 := by
  intro p hp
  have h : env11029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11028_11029 : H12AffineEnvironment.transform 6 2 env11028 = env11029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env11028 == env11029) = true)

theorem identity11029 : scanCanonicalize (H12AffineFastState.compose env11029 (packedSelected [2,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound11029 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env11030 : List Nat := [2,4,3,16,32,16,2,5,1,1024,1,1061,3,1045,1,3,1060,17,1025,1,1061,1,17,51,3,32,16,1044,1060,1,1073,49,4,16,1061,0]

theorem envBound11030 : H12AffineFastState.Bounded env11030 := by
  intro p hp
  have h : env11030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11029_11030 : H12AffineEnvironment.transform 2 3 env11029 = env11030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env11029 == env11030) = true)

theorem identity11030 : scanCanonicalize (H12AffineFastState.compose env11030 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound11030 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11031 : List Nat := [2,4,3,16,1,16,2,5,1,1024,1,1028,3,1045,1,3,1029,17,1025,1,1028,1,17,18,3,1,16,1044,1029,1,1040,16,4,16,1028,0]

theorem envBound11031 : H12AffineFastState.Bounded env11031 := by
  intro p hp
  have h : env11031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11030_11031 : H12AffineEnvironment.transform 4 1 env11030 = env11031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env11030 == env11031) = true)

def env11032 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,9,1297,32768,65536,4097,262144,1025,32768,4096,4194304,16,16777216,33554432,16875796,21337360,16879876,4097,20978846,16876544,4294967296,257,4332814639,4096,33554440]

theorem envBound11032 : H12AffineFastState.Bounded env11032 := by
  intro p hp
  have h : env11032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11000_11032 : H12AffineEnvironment.transform 8 137 env11000 = env11032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env11000 == env11032) = true)

theorem identity11032 : scanCanonicalize (H12AffineFastState.compose env11032 (packedSelected [3,6,10,24,25,26] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound11032 : packedSelected [3,6,10,24,25,26] rootPS < 2^1333 := by decide +kernel

def env11033 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,9,1297,32768,65536,1297,262144,1025,32768,1296,4194304,16,16777216,33554432,16875796,21331968,16876564,1297,20973966,16876544,4294967296,257,4332814639,1296,33554440]

theorem envBound11033 : H12AffineFastState.Bounded env11033 := by
  intro p hp
  have h : env11033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11032_11033 : H12AffineEnvironment.transform 11 1296 env11032 = env11033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env11032 == env11033) = true)

theorem identity11033 : scanCanonicalize (H12AffineFastState.compose env11033 (packedSelected [1,3,5,6,8,10,19,25] rootPS)) = affineNative (2^(24+1) ^^^ 16875908) := by decide +kernel

theorem selectedBound11033 : packedSelected [1,3,5,6,8,10,19,25] rootPS < 2^1333 := by decide +kernel

def env11034 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,9,1297,32768,65536,1297,262144,1025,32768,1296,4194304,16,16777216,16875908,16875796,21331968,16876564,1297,20973966,16876544,4294967296,257,4315938987,1296,16875916]

theorem envBound11034 : H12AffineFastState.Bounded env11034 := by
  intro p hp
  have h : env11034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11033_11034 : H12AffineEnvironment.transform 24 16875908 env11033 = env11034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 16875908 env11033 == env11034) = true)

theorem identity11034 : scanCanonicalize (H12AffineFastState.compose env11034 (packedSelected [1,3,4,9,12,13,15,16,17] rootPS)) = affineNative (2^(23+1) ^^^ 297130) := by decide +kernel

theorem selectedBound11034 : packedSelected [1,3,4,9,12,13,15,16,17] rootPS < 2^1333 := by decide +kernel

def env11035 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,9,1297,32768,65536,1297,262144,1025,32768,1296,4194304,16,297130,330030,330174,4262058,330942,1297,4489508,330922,4294967296,257,4299458561,1296,330022]

theorem envBound11035 : H12AffineFastState.Bounded env11035 := by
  intro p hp
  have h : env11035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11034_11035 : H12AffineEnvironment.transform 23 297130 env11034 = env11035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 297130 env11034 == env11035) = true)

theorem identity11035 : scanCanonicalize (H12AffineFastState.compose env11035 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(17+1) ^^^ 68014) := by decide +kernel

theorem selectedBound11035 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env11036 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,9,1297,32768,65536,1297,68014,1025,32768,1296,4194304,16,98564,128,16,4262058,1296,1297,4294794,1284,4294967296,257,4299260335,1296,136]

theorem envBound11036 : H12AffineFastState.Bounded env11036 := by
  intro p hp
  have h : env11036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11035_11036 : H12AffineEnvironment.transform 17 68014 env11035 = env11036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 68014 env11035 == env11036) = true)

theorem identity11036 : scanCanonicalize (H12AffineFastState.compose env11036 (packedSelected [3] rootPS)) = affineNative (2^(31+1) ^^^ 33044) := by decide +kernel

theorem selectedBound11036 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env11037 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,9,1297,32768,65536,1297,68014,1025,32768,1296,4194304,16,98564,128,16,4262058,1296,1297,4294794,1284,33044,257,4260027,1296,136]

theorem envBound11037 : H12AffineFastState.Bounded env11037 := by
  intro p hp
  have h : env11037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11036_11037 : H12AffineEnvironment.transform 31 33044 env11036 = env11037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 33044 env11036 == env11037) = true)

theorem identity11037 : scanCanonicalize (H12AffineFastState.compose env11037 (packedSelected [1,5] rootPS)) = affineNative (2^(21+1) ^^^ 34848) := by decide +kernel

theorem selectedBound11037 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env11038 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,9,1297,32768,65536,1297,68014,1025,32768,1296,34848,16,98564,128,16,98442,1296,1297,65706,1284,33044,257,100507,1296,136]

theorem envBound11038 : H12AffineFastState.Bounded env11038 := by
  intro p hp
  have h : env11038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11037_11038 : H12AffineEnvironment.transform 21 34848 env11037 = env11038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 34848 env11037 == env11038) = true)

theorem identity11038 : scanCanonicalize (H12AffineFastState.compose env11038 (packedSelected [1,8] rootPS)) = affineNative (2^(15+1) ^^^ 33167) := by decide +kernel

theorem selectedBound11038 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env11039 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,9,1297,32768,33167,1297,34849,1025,32768,1296,34848,16,139,128,16,261,1296,1297,33061,1284,33044,257,2324,1296,136]

theorem envBound11039 : H12AffineFastState.Bounded env11039 := by
  intro p hp
  have h : env11039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11038_11039 : H12AffineEnvironment.transform 15 33167 env11038 = env11039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33167 env11038 == env11039) = true)

theorem identity11039 : scanCanonicalize (H12AffineFastState.compose env11039 (packedSelected [1] rootPS)) = affineNative (2^(14+1) ^^^ 32) := by decide +kernel

theorem selectedBound11039 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11040 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,9,1297,32,431,1297,2049,1025,32,1296,2048,16,139,128,16,261,1296,1297,261,1284,308,257,2324,1296,136]

theorem envBound11040 : H12AffineFastState.Bounded env11040 := by
  intro p hp
  have h : env11040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11039_11040 : H12AffineEnvironment.transform 14 32 env11039 = env11040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 32 env11039 == env11040) = true)

def env11041 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,641,16384,32768,65536,131072,262144,1025,32768,4096,4194304,17665,16777216,33554432,17010965,21352449,17024020,131072,21105823,16876544,4294967296,257,4332967607,131073,33554441]

theorem envBound11041 : H12AffineFastState.Bounded env11041 := by
  intro p hp
  have h : env11041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10940_11041 : H12AffineEnvironment.transform 12 641 env10940 = env11041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 641 env10940 == env11041) = true)

def env11042 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,641,16384,32768,65536,4096,262144,1025,32768,4096,4194304,17665,16777216,33554432,16875797,21352449,16897044,4096,20978847,16876544,4294967296,257,4332832439,4097,33554441]

theorem envBound11042 : H12AffineFastState.Bounded env11042 := by
  intro p hp
  have h : env11042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11041_11042 : H12AffineEnvironment.transform 16 4096 env11041 = env11042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env11041 == env11042) = true)

theorem identity11042 : scanCanonicalize (H12AffineFastState.compose env11042 (packedSelected [1,3,5,8,9,10,19,22] rootPS)) = affineNative (2^(24+1) ^^^ 20608) := by decide +kernel

theorem selectedBound11042 : packedSelected [1,3,5,8,9,10,19,22] rootPS < 2^1333 := by decide +kernel

def env11043 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,641,16384,32768,65536,4096,262144,1025,32768,4096,4194304,17665,16777216,20608,16875797,21352449,16897044,4096,20978847,16876544,4294967296,257,4299265591,4097,20617]

theorem envBound11043 : H12AffineFastState.Bounded env11043 := by
  intro p hp
  have h : env11043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11042_11043 : H12AffineEnvironment.transform 24 20608 env11042 = env11043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 20608 env11042 == env11043) = true)

def env11044 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,641,4096,32768,65536,4096,262144,1025,32768,4096,4194304,5377,16777216,128,16875797,21331969,16876564,4096,20978847,16876544,4294967296,257,4299265591,4097,137]

theorem envBound11044 : H12AffineFastState.Bounded env11044 := by
  intro p hp
  have h : env11044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11043_11044 : H12AffineEnvironment.transform 13 4096 env11043 = env11044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env11043 == env11044) = true)

theorem identity11044 : scanCanonicalize (H12AffineFastState.compose env11044 (packedSelected [3,5,8,17,21,28] rootPS)) = affineNative (2^(23+1) ^^^ 138) := by decide +kernel

theorem selectedBound11044 : packedSelected [3,5,8,17,21,28] rootPS < 2^1333 := by decide +kernel

def env11045 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,641,4096,32768,65536,4096,262144,1025,32768,4096,4194304,5377,138,128,98719,4554891,99486,4096,4201493,99466,4294967296,257,4299265591,4097,137]

theorem envBound11045 : H12AffineFastState.Bounded env11045 := by
  intro p hp
  have h : env11045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11044_11045 : H12AffineEnvironment.transform 23 138 env11044 = env11045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 138 env11044 == env11045) = true)

theorem identity11045 : scanCanonicalize (H12AffineFastState.compose env11045 (packedSelected [1,5,6,8,10,17,19,21,24,25,26,31] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound11045 : packedSelected [1,5,6,8,10,17,19,21,24,25,26,31] rootPS < 2^1333 := by decide +kernel

def env11046 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,9,4096,32768,65536,4096,262144,1025,32768,4096,4194304,5377,138,128,98719,4554891,99486,4096,4201493,99466,4294967296,257,4299265215,4097,137]

theorem envBound11046 : H12AffineFastState.Bounded env11046 := by
  intro p hp
  have h : env11046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11045_11046 : H12AffineEnvironment.transform 8 136 env11045 = env11046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env11045 == env11046) = true)

theorem identity11046 : scanCanonicalize (H12AffineFastState.compose env11046 (packedSelected [3,4,9,10,16,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 38047) := by decide +kernel

theorem selectedBound11046 : packedSelected [3,4,9,10,16,24,26] rootPS < 2^1333 := by decide +kernel

def env11047 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,9,4096,32768,38047,4096,262144,1025,32768,4096,4194304,5377,138,128,5376,4461588,4097,4096,4201493,4117,4294967296,257,4299161632,4097,137]

theorem envBound11047 : H12AffineFastState.Bounded env11047 := by
  intro p hp
  have h : env11047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11046_11047 : H12AffineEnvironment.transform 15 38047 env11046 = env11047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38047 env11046 == env11047) = true)

theorem identity11047 : scanCanonicalize (H12AffineFastState.compose env11047 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound11047 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env11048 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,1297,9,1297,32768,33166,1297,262144,1025,32768,1297,4194304,16,138,128,17,4456709,1296,1297,4196612,1284,4294967296,257,4299161632,1296,137]

theorem envBound11048 : H12AffineFastState.Bounded env11048 := by
  intro p hp
  have h : env11048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11047_11048 : H12AffineEnvironment.transform 11 1297 env11047 = env11048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env11047 == env11048) = true)

theorem identity11048 : scanCanonicalize (H12AffineFastState.compose env11048 (packedSelected [1,3] rootPS)) = affineNative (2^(14+1) ^^^ 2184) := by decide +kernel

theorem selectedBound11048 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11049 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,1297,9,1297,2184,2310,1297,262144,1025,2184,1297,4194304,16,138,128,17,4456709,1296,1297,4196612,1284,4294967296,257,4299161632,1296,137]

theorem envBound11049 : H12AffineFastState.Bounded env11049 := by
  intro p hp
  have h : env11049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11048_11049 : H12AffineEnvironment.transform 14 2184 env11048 = env11049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2184 env11048 == env11049) = true)

theorem identity11049 : scanCanonicalize (H12AffineFastState.compose env11049 (packedSelected [5] rootPS)) = affineNative (2^(21+1) ^^^ 2081) := by decide +kernel

theorem selectedBound11049 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env11050 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,1297,9,1297,2184,2310,1297,262144,1025,2184,1297,2081,16,138,128,17,264484,1296,1297,293,1284,4294967296,257,4294969345,1296,137]

theorem envBound11050 : H12AffineFastState.Bounded env11050 := by
  intro p hp
  have h : env11050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11049_11050 : H12AffineEnvironment.transform 21 2081 env11049 = env11050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2081 env11049 == env11050) = true)

theorem identity11050 : scanCanonicalize (H12AffineFastState.compose env11050 (packedSelected [8] rootPS)) = affineNative (2^(17+1) ^^^ 168) := by decide +kernel

theorem selectedBound11050 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env11051 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,1297,9,1297,2184,2310,1297,168,1025,2184,1297,2081,16,138,128,17,2444,1296,1297,293,1284,4294967296,257,4294969345,1296,137]

theorem envBound11051 : H12AffineFastState.Bounded env11051 := by
  intro p hp
  have h : env11051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11050_11051 : H12AffineEnvironment.transform 17 168 env11050 = env11051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 168 env11050 == env11051) = true)

theorem identity11051 : scanCanonicalize (H12AffineFastState.compose env11051 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 137) := by decide +kernel

theorem selectedBound11051 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11052 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,1297,9,1297,2184,2310,1297,168,1025,2184,1297,2081,16,138,128,17,2444,1296,1297,293,1284,137,257,2184,1296,137]

theorem envBound11052 : H12AffineFastState.Bounded env11052 := by
  intro p hp
  have h : env11052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11051_11052 : H12AffineEnvironment.transform 31 137 env11051 = env11052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 137 env11051 == env11052) = true)

theorem identity11052 : scanCanonicalize (H12AffineFastState.compose env11052 (packedSelected [10] rootPS)) = affineNative (2^(10+1) ^^^ 428) := by decide +kernel

theorem selectedBound11052 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env11053 : List Nat := [2,4,8,16,32,16,128,256,136,1024,428,1297,9,1297,292,170,1297,168,1025,292,1297,397,16,138,128,17,32,1296,1297,293,1284,137,257,292,1296,137]

theorem envBound11053 : H12AffineFastState.Bounded env11053 := by
  intro p hp
  have h : env11053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11052_11053 : H12AffineEnvironment.transform 10 428 env11052 = env11053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 428 env11052 == env11053) = true)

theorem identity11053 : scanCanonicalize (H12AffineFastState.compose env11053 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 134) := by decide +kernel

theorem selectedBound11053 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env11054 : List Nat := [2,4,8,16,32,16,128,134,136,1024,42,1175,9,1175,162,170,1175,168,1025,162,1175,11,16,138,128,17,32,1174,1175,163,1154,137,135,162,1174,137]

theorem envBound11054 : H12AffineFastState.Bounded env11054 := by
  intro p hp
  have h : env11054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11053_11054 : H12AffineEnvironment.transform 7 134 env11053 = env11054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 134 env11053 == env11054) = true)

theorem identity11054 : scanCanonicalize (H12AffineFastState.compose env11054 (packedSelected [4,7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound11054 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env11055 : List Nat := [2,4,8,0,32,0,128,134,136,1024,42,1159,9,1159,162,170,1159,168,1025,162,1159,11,0,138,128,1,32,1158,1159,163,1154,137,135,162,1158,137]

theorem envBound11055 : H12AffineFastState.Bounded env11055 := by
  intro p hp
  have h : env11055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11054_11055 : H12AffineEnvironment.transform 3 0 env11054 = env11055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env11054 == env11055) = true)

theorem identity11055 : scanCanonicalize (H12AffineFastState.compose env11055 (packedSelected [12] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound11055 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env11056 : List Nat := [2,4,8,0,32,0,8,14,0,1024,42,1039,9,1039,42,34,1039,32,1025,42,1039,11,0,2,8,1,32,1038,1039,43,1034,1,15,42,1038,1]

theorem envBound11056 : H12AffineFastState.Bounded env11056 := by
  intro p hp
  have h : env11056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11055_11056 : H12AffineEnvironment.transform 6 8 env11055 = env11056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env11055 == env11056) = true)

theorem identity11056 : scanCanonicalize (H12AffineFastState.compose env11056 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound11056 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11057 : List Nat := [2,4,8,0,10,0,8,14,0,1024,0,1039,9,1039,0,8,1039,10,1025,0,1039,11,0,2,8,1,10,1038,1039,1,1034,1,15,0,1038,1]

theorem envBound11057 : H12AffineFastState.Bounded env11057 := by
  intro p hp
  have h : env11057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11056_11057 : H12AffineEnvironment.transform 4 10 env11056 = env11057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env11056 == env11057) = true)

theorem identity11057 : scanCanonicalize (H12AffineFastState.compose env11057 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound11057 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env11058 : List Nat := [2,4,2,0,0,0,2,4,0,1024,0,1029,3,1029,0,2,1029,0,1025,0,1029,1,0,2,2,1,0,1028,1029,1,1024,1,5,0,1028,1]

theorem envBound11058 : H12AffineFastState.Bounded env11058 := by
  intro p hp
  have h : env11058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11057_11058 : H12AffineEnvironment.transform 2 2 env11057 = env11058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env11057 == env11058) = true)

def leafEnv11058 : List Nat := [2,4,2,0,0,0,2,4,0,1024,0,1029,3,1029,0,2,1029,0,1025,0,1029,1,0,2,1025,2,1,1,0,1028,1029,1,1024,1,5,0,5,3,1028,1,0,1029,1]

def active11058 : List Nat := [0,1,9]

def tree11058 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11058 : H12WitnessSearch.Good tree11058 := H12GlobalWitnessIndex.good

theorem leafIdentity11058 : H12AffineFastState.composeSystem env11058 rootObs = leafEnv11058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11058 rootObs == leafEnv11058) = true)

theorem terminalChecked11058 : H12PackedTerminal.terminalCheckFast leafEnv11058 active11058 tree11058 = true := by decide +kernel

def env11059 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,641,4097,32768,65536,4096,262144,1025,32768,4096,4194304,5376,16777216,129,16875797,21331968,16876565,4096,20978847,16876544,4294967296,257,4299265591,4097,136]

theorem envBound11059 : H12AffineFastState.Bounded env11059 := by
  intro p hp
  have h : env11059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11043_11059 : H12AffineEnvironment.transform 13 4097 env11043 = env11059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4097 env11043 == env11059) = true)

def env11060 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,641,4097,32768,65536,4096,262144,1025,32768,4096,4194304,5376,4293120,129,4195093,262656,4195861,4096,106143,4195840,4294967296,257,4299265591,4097,136]

theorem envBound11060 : H12AffineFastState.Bounded env11060 := by
  intro p hp
  have h : env11060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11059_11060 : H12AffineEnvironment.transform 23 4293120 env11059 = env11060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4293120 env11059 == env11060) = true)

theorem identity11060 : scanCanonicalize (H12AffineFastState.compose env11060 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound11060 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env11061 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,8,4097,32768,65536,4096,262144,1025,32768,4096,4194304,5376,4292745,129,4194716,262281,4195484,4096,105494,4195465,4294967296,257,4299265214,4097,136]

theorem envBound11061 : H12AffineFastState.Bounded env11061 := by
  intro p hp
  have h : env11061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11060_11061 : H12AffineEnvironment.transform 8 137 env11060 = env11061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env11060 == env11061) = true)

theorem identity11061 : scanCanonicalize (H12AffineFastState.compose env11061 (packedSelected [0,7,20] rootPS)) = affineNative (2^(21+1) ^^^ 5276) := by decide +kernel

theorem selectedBound11061 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env11062 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,8,4097,32768,65536,4096,262144,1025,32768,4096,5276,5376,103445,129,5376,262281,4096,4096,105494,4117,4294967296,257,4295065634,4097,136]

theorem envBound11062 : H12AffineFastState.Bounded env11062 := by
  intro p hp
  have h : env11062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11061_11062 : H12AffineEnvironment.transform 21 5276 env11061 = env11062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 5276 env11061 == env11062) = true)

theorem identity11062 : scanCanonicalize (H12AffineFastState.compose env11062 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 262566) := by decide +kernel

theorem selectedBound11062 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env11063 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,8,4097,32768,65536,4096,262144,1025,32768,4096,5276,5376,103445,129,5376,262281,4096,4096,105494,4117,262566,257,360836,4097,136]

theorem envBound11063 : H12AffineFastState.Bounded env11063 := by
  intro p hp
  have h : env11063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11062_11063 : H12AffineEnvironment.transform 31 262566 env11062 = env11063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 262566 env11062 == env11063) = true)

def env11064 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,641,4097,32768,65536,4096,262144,1025,32768,4096,4194304,5376,4293121,129,4195092,262657,4195860,4096,106142,4195841,4294967296,257,4299265591,4097,136]

theorem envBound11064 : H12AffineFastState.Bounded env11064 := by
  intro p hp
  have h : env11064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11059_11064 : H12AffineEnvironment.transform 23 4293121 env11059 = env11064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4293121 env11059 == env11064) = true)

def env11065 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,641,1297,32768,65536,1296,262144,1025,32768,1296,4194304,16,4293121,129,4195092,262657,4195860,1296,101262,4195841,4294967296,257,4299260711,1297,136]

theorem envBound11065 : H12AffineFastState.Bounded env11065 := by
  intro p hp
  have h : env11065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11064_11065 : H12AffineEnvironment.transform 11 1296 env11064 = env11065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env11064 == env11065) = true)

theorem identity11065 : scanCanonicalize (H12AffineFastState.compose env11065 (packedSelected [1,3,4,9,12,13,15,16,17] rootPS)) = affineNative (2^(14+1) ^^^ 260) := by decide +kernel

theorem selectedBound11065 : packedSelected [1,3,4,9,12,13,15,16,17] rootPS < 2^1333 := by decide +kernel

def env11066 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,641,1297,260,65536,1296,262144,1025,260,1296,4194304,16,4260613,129,4195092,262657,4195860,1296,68234,4195841,4294967296,257,4299227683,1297,136]

theorem envBound11066 : H12AffineFastState.Bounded env11066 := by
  intro p hp
  have h : env11066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11065_11066 : H12AffineEnvironment.transform 14 260 env11065 = env11066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 260 env11065 == env11066) = true)

theorem identity11066 : scanCanonicalize (H12AffineFastState.compose env11066 (packedSelected [0,4,7,9,16,20] rootPS)) = affineNative (2^(21+1) ^^^ 397) := by decide +kernel

theorem selectedBound11066 : packedSelected [0,4,7,9,16,20] rootPS < 2^1333 := by decide +kernel

def env11067 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,641,1297,260,65536,1296,262144,1025,260,1296,397,16,66184,129,665,262657,1945,1296,68234,1932,4294967296,257,4295033774,1297,136]

theorem envBound11067 : H12AffineFastState.Bounded env11067 := by
  intro p hp
  have h : env11067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11066_11067 : H12AffineEnvironment.transform 21 397 env11066 = env11067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 397 env11066 == env11067) = true)

theorem identity11067 : scanCanonicalize (H12AffineFastState.compose env11067 (packedSelected [5,6,8,12,21,24] rootPS)) = affineNative (2^(31+1) ^^^ 0) := by decide +kernel

theorem selectedBound11067 : packedSelected [5,6,8,12,21,24] rootPS < 2^1333 := by decide +kernel

def env11068 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,641,1297,260,65536,1296,262144,1025,260,1296,397,16,66184,129,665,262657,1945,1296,68234,1932,0,257,66478,1297,136]

theorem envBound11068 : H12AffineFastState.Bounded env11068 := by
  intro p hp
  have h : env11068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11067_11068 : H12AffineEnvironment.transform 31 0 env11067 = env11068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 0 env11067 == env11068) = true)

theorem identity11068 : scanCanonicalize (H12AffineFastState.compose env11068 (packedSelected [6,25] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound11068 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env11069 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,8,1297,260,65536,1296,262144,1025,260,1296,397,16,65537,129,16,262280,1296,1296,67587,1285,0,257,65831,1297,136]

theorem envBound11069 : H12AffineFastState.Bounded env11069 := by
  intro p hp
  have h : env11069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11068_11069 : H12AffineEnvironment.transform 8 137 env11068 = env11069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env11068 == env11069) = true)

theorem identity11069 : scanCanonicalize (H12AffineFastState.compose env11069 (packedSelected [1,3,5] rootPS)) = affineNative (2^(17+1) ^^^ 65665) := by decide +kernel

theorem selectedBound11069 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env11070 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,8,1297,260,65536,1296,65665,1025,260,1296,397,16,65537,129,16,65545,1296,1296,67587,1285,0,257,65831,1297,136]

theorem envBound11070 : H12AffineFastState.Bounded env11070 := by
  intro p hp
  have h : env11070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11069_11070 : H12AffineEnvironment.transform 17 65665 env11069 = env11070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env11069 == env11070) = true)

theorem identity11070 : scanCanonicalize (H12AffineFastState.compose env11070 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 294) := by decide +kernel

theorem selectedBound11070 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env11071 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,8,1297,260,294,1296,423,1025,260,1296,397,16,295,129,16,303,1296,1296,2341,1285,0,257,1,1297,136]

theorem envBound11071 : H12AffineFastState.Bounded env11071 := by
  intro p hp
  have h : env11071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11070_11071 : H12AffineEnvironment.transform 15 294 env11070 = env11071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 294 env11070 == env11071) = true)

theorem identity11071 : scanCanonicalize (H12AffineFastState.compose env11071 (packedSelected [3,12] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound11071 : packedSelected [3,12] rootPS < 2^1333 := by decide +kernel

def env11072 : List Nat := [2,4,8,16,32,16,128,21,137,1024,2048,1029,8,1028,17,51,1029,178,1025,17,1029,152,16,50,129,16,58,1029,1029,2096,1040,0,20,1,1028,136]

theorem envBound11072 : H12AffineFastState.Bounded env11072 := by
  intro p hp
  have h : env11072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11071_11072 : H12AffineEnvironment.transform 7 21 env11071 = env11072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env11071 == env11072) = true)

def env11073 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,641,1296,32768,65536,1297,262144,1025,32768,1297,4194304,17,4293121,129,4195092,262657,4195860,1297,101263,4195841,4294967296,257,4299260710,1296,136]

theorem envBound11073 : H12AffineFastState.Bounded env11073 := by
  intro p hp
  have h : env11073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11064_11073 : H12AffineEnvironment.transform 11 1297 env11064 = env11073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env11064 == env11073) = true)

theorem identity11073 : scanCanonicalize (H12AffineFastState.compose env11073 (packedSelected [1,3,4,9,12,13,15,16,17] rootPS)) = affineNative (2^(17+1) ^^^ 68015) := by decide +kernel

theorem selectedBound11073 : packedSelected [1,3,4,9,12,13,15,16,17] rootPS < 2^1333 := by decide +kernel

def env11074 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,641,1296,32768,65536,1297,68015,1025,32768,1297,4194304,17,4293121,129,4195092,68526,4195860,1297,101263,4195841,4294967296,257,4299260710,1296,136]

theorem envBound11074 : H12AffineFastState.Bounded env11074 := by
  intro p hp
  have h : env11074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11073_11074 : H12AffineEnvironment.transform 17 68015 env11073 = env11074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 68015 env11073 == env11074) = true)

theorem identity11074 : scanCanonicalize (H12AffineFastState.compose env11074 (packedSelected [4,8,9,12,13,15,16,24] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound11074 : packedSelected [4,8,9,12,13,15,16,24] rootPS < 2^1333 := by decide +kernel

def env11075 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,641,1296,32768,33166,1297,34849,1025,32768,1297,4194304,17,4195215,129,4195092,35360,4195860,1297,2561,4195841,4294967296,257,4299162280,1296,136]

theorem envBound11075 : H12AffineFastState.Bounded env11075 := by
  intro p hp
  have h : env11075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11074_11075 : H12AffineEnvironment.transform 15 33166 env11074 = env11075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env11074 == env11075) = true)

theorem identity11075 : scanCanonicalize (H12AffineFastState.compose env11075 (packedSelected [0,4,7,9,16,18,20,23] rootPS)) = affineNative (2^(21+1) ^^^ 396) := by decide +kernel

theorem selectedBound11075 : packedSelected [0,4,7,9,16,18,20,23] rootPS < 2^1333 := by decide +kernel

def env11076 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,641,1296,32768,33166,1297,34849,1025,32768,1297,396,17,515,129,664,35360,1944,1297,2561,1933,4294967296,257,4294968100,1296,136]

theorem envBound11076 : H12AffineFastState.Bounded env11076 := by
  intro p hp
  have h : env11076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11075_11076 : H12AffineEnvironment.transform 21 396 env11075 = env11076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 396 env11075 == env11076) = true)

theorem identity11076 : scanCanonicalize (H12AffineFastState.compose env11076 (packedSelected [0,1,2,3,4,5,6,11] rootPS)) = affineNative (2^(14+1) ^^^ 2341) := by decide +kernel

theorem selectedBound11076 : packedSelected [0,1,2,3,4,5,6,11] rootPS < 2^1333 := by decide +kernel

def env11077 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,641,1296,2341,2219,1297,260,1025,2341,1297,396,17,515,129,664,773,1944,1297,2561,1933,4294967296,257,4294968100,1296,136]

theorem envBound11077 : H12AffineFastState.Bounded env11077 := by
  intro p hp
  have h : env11077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11076_11077 : H12AffineEnvironment.transform 14 2341 env11076 = env11077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2341 env11076 == env11077) = true)

theorem identity11077 : scanCanonicalize (H12AffineFastState.compose env11077 (packedSelected [1,5,6,8,10] rootPS)) = affineNative (2^(31+1) ^^^ 2691) := by decide +kernel

theorem selectedBound11077 : packedSelected [1,5,6,8,10] rootPS < 2^1333 := by decide +kernel

def env11078 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,641,1296,2341,2219,1297,260,1025,2341,1297,396,17,515,129,664,773,1944,1297,2561,1933,2691,257,2471,1296,136]

theorem envBound11078 : H12AffineFastState.Bounded env11078 := by
  intro p hp
  have h : env11078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11077_11078 : H12AffineEnvironment.transform 31 2691 env11077 = env11078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 2691 env11077 == env11078) = true)

def env11079 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,641,16384,32768,65536,4097,262144,1025,32768,4096,4194304,17665,16777216,33554432,16875796,21352449,16897045,4097,20978846,16876544,4294967296,257,4332832438,4096,33554441]

theorem envBound11079 : H12AffineFastState.Bounded env11079 := by
  intro p hp
  have h : env11079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11041_11079 : H12AffineEnvironment.transform 16 4097 env11041 = env11079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4097 env11041 == env11079) = true)

theorem identity11079 : scanCanonicalize (H12AffineFastState.compose env11079 (packedSelected [1,3,5,8,9,10,19,22] rootPS)) = affineNative (2^(24+1) ^^^ 17808) := by decide +kernel

theorem selectedBound11079 : packedSelected [1,3,5,8,9,10,19,22] rootPS < 2^1333 := by decide +kernel

def env11080 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,641,16384,32768,65536,4097,262144,1025,32768,4096,4194304,17665,16777216,17808,16875796,21352449,16897045,4097,20978846,16876544,4294967296,257,4299260710,4096,17817]

theorem envBound11080 : H12AffineFastState.Bounded env11080 := by
  intro p hp
  have h : env11080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11079_11080 : H12AffineEnvironment.transform 24 17808 env11079 = env11080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 17808 env11079 == env11080) = true)

def env11081 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,9,16384,32768,65536,4097,262144,1025,32768,4096,4194304,17665,16777216,17808,16875796,21352449,16897045,4097,20978846,16876544,4294967296,257,4299260334,4096,17817]

theorem envBound11081 : H12AffineFastState.Bounded env11081 := by
  intro p hp
  have h : env11081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11080_11081 : H12AffineEnvironment.transform 8 136 env11080 = env11081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env11080 == env11081) = true)

theorem identity11081 : scanCanonicalize (H12AffineFastState.compose env11081 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(23+1) ^^^ 103444) := by decide +kernel

theorem selectedBound11081 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env11082 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,9,16384,32768,65536,4097,262144,1025,32768,4096,4194304,17665,103444,17808,5376,4473877,16385,4097,4294794,4116,4294967296,257,4299260334,4096,17817]

theorem envBound11082 : H12AffineFastState.Bounded env11082 := by
  intro p hp
  have h : env11082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11081_11082 : H12AffineEnvironment.transform 23 103444 env11081 = env11082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 103444 env11081 == env11082) = true)

theorem identity11082 : scanCanonicalize (H12AffineFastState.compose env11082 (packedSelected [0,1,3,4,7,9,10,16,17,19,20,21] rootPS)) = affineNative (2^(14+1) ^^^ 261) := by decide +kernel

theorem selectedBound11082 : packedSelected [0,1,3,4,7,9,10,16,17,19,20,21] rootPS < 2^1333 := by decide +kernel

def env11083 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,9,16384,261,65536,4097,262144,1025,261,4096,4194304,17665,70929,17808,5376,4473877,16385,4097,4262287,4116,4294967296,257,4299227307,4096,17817]

theorem envBound11083 : H12AffineFastState.Bounded env11083 := by
  intro p hp
  have h : env11083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11082_11083 : H12AffineEnvironment.transform 14 261 env11082 = env11083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 261 env11082 == env11083) = true)

theorem identity11083 : scanCanonicalize (H12AffineFastState.compose env11083 (packedSelected [0,4,7,9,16,20] rootPS)) = affineNative (2^(13+1) ^^^ 1296) := by decide +kernel

theorem selectedBound11083 : packedSelected [0,4,7,9,16,20] rootPS < 2^1333 := by decide +kernel

def env11084 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,9,1296,261,65536,4097,262144,1025,261,4096,4194304,17,70929,128,5376,4456709,1297,4097,4262287,4116,4294967296,257,4299227307,4096,137]

theorem envBound11084 : H12AffineFastState.Bounded env11084 := by
  intro p hp
  have h : env11084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11083_11084 : H12AffineEnvironment.transform 13 1296 env11083 = env11084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env11083 == env11084) = true)

theorem identity11084 : scanCanonicalize (H12AffineFastState.compose env11084 (packedSelected [5,6,8,10,12,13] rootPS)) = affineNative (2^(31+1) ^^^ 4262276) := by decide +kernel

theorem selectedBound11084 : packedSelected [5,6,8,10,12,13] rootPS < 2^1333 := by decide +kernel

def env11085 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,9,1296,261,65536,4097,262144,1025,261,4096,4194304,17,70929,128,5376,4456709,1297,4097,4262287,4116,4262276,257,2351,4096,137]

theorem envBound11085 : H12AffineFastState.Bounded env11085 := by
  intro p hp
  have h : env11085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11084_11085 : H12AffineEnvironment.transform 31 4262276 env11084 = env11085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4262276 env11084 == env11085) = true)

theorem identity11085 : scanCanonicalize (H12AffineFastState.compose env11085 (packedSelected [10,12,17] rootPS)) = affineNative (2^(17+1) ^^^ 72894) := by decide +kernel

theorem selectedBound11085 : packedSelected [10,12,17] rootPS < 2^1333 := by decide +kernel

def env11086 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,9,1296,261,65536,4097,72894,1025,261,4096,4194304,17,70929,128,5376,4267451,1297,4097,4262287,4116,4262276,257,2351,4096,137]

theorem envBound11086 : H12AffineFastState.Bounded env11086 := by
  intro p hp
  have h : env11086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11085_11086 : H12AffineEnvironment.transform 17 72894 env11085 = env11086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 72894 env11085 == env11086) = true)

theorem identity11086 : scanCanonicalize (H12AffineFastState.compose env11086 (packedSelected [1,24] rootPS)) = affineNative (2^(15+1) ^^^ 139) := by decide +kernel

theorem selectedBound11086 : packedSelected [1,24] rootPS < 2^1333 := by decide +kernel

def env11087 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,9,1296,261,139,4097,7221,1025,261,4096,4194304,17,5530,128,5376,4201776,1297,4097,4196612,4116,4196623,257,2351,4096,137]

theorem envBound11087 : H12AffineFastState.Bounded env11087 := by
  intro p hp
  have h : env11087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11086_11087 : H12AffineEnvironment.transform 15 139 env11086 = env11087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 139 env11086 == env11087) = true)

def env11088 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,9,1296,261,139,4097,7221,1025,261,4096,5408,17,5530,128,5376,2064,1297,4097,7204,4116,7215,257,2351,4096,137]

theorem envBound11088 : H12AffineFastState.Bounded env11088 := by
  intro p hp
  have h : env11088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11087_11088 : H12AffineEnvironment.transform 21 5408 env11087 = env11088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 5408 env11087 == env11088) = true)

theorem identity11088 : scanCanonicalize (H12AffineFastState.compose env11088 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 182) := by decide +kernel

theorem selectedBound11088 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11089 : List Nat := [2,4,8,16,32,16,128,182,136,1024,2048,4096,9,1190,179,139,4097,7221,1025,179,4096,5270,17,5164,128,5302,2064,1191,4097,7204,4116,7215,183,2201,4096,137]

theorem envBound11089 : H12AffineFastState.Bounded env11089 := by
  intro p hp
  have h : env11089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11088_11089 : H12AffineEnvironment.transform 7 182 env11088 = env11089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 182 env11088 == env11089) = true)

theorem identity11089 : scanCanonicalize (H12AffineFastState.compose env11089 (packedSelected [6,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 1180) := by decide +kernel

theorem selectedBound11089 : packedSelected [6,10,12] rootPS < 2^1333 := by decide +kernel

def env11090 : List Nat := [2,4,8,16,32,16,128,182,136,1024,2048,1180,9,1190,179,139,1181,2217,1025,179,1180,10,17,176,128,42,2064,1191,1181,2232,1160,2227,183,2201,1180,137]

theorem envBound11090 : H12AffineFastState.Bounded env11090 := by
  intro p hp
  have h : env11090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11089_11090 : H12AffineEnvironment.transform 11 1180 env11089 = env11090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1180 env11089 == env11090) = true)

def env11091 : List Nat := [2,4,8,16,32,16,128,182,136,1024,0,1180,9,1190,179,139,1181,169,1025,179,1180,10,17,176,128,42,16,1191,1181,184,1160,179,183,153,1180,137]

theorem envBound11091 : H12AffineFastState.Bounded env11091 := by
  intro p hp
  have h : env11091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11090_11091 : H12AffineEnvironment.transform 10 0 env11090 = env11091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env11090 == env11091) = true)

theorem identity11091 : scanCanonicalize (H12AffineFastState.compose env11091 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound11091 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env11092 : List Nat := [2,4,8,16,32,16,56,14,48,1024,0,1060,9,1054,11,51,1061,17,1025,11,1060,10,17,8,56,42,16,1055,1061,0,1072,11,15,33,1060,49]

theorem envBound11092 : H12AffineFastState.Bounded env11092 := by
  intro p hp
  have h : env11092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11091_11092 : H12AffineEnvironment.transform 6 56 env11091 = env11092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env11091 == env11092) = true)

theorem identity11092 : scanCanonicalize (H12AffineFastState.compose env11092 (packedSelected [0,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound11092 : packedSelected [0,2,5] rootPS < 2^1333 := by decide +kernel

def env11093 : List Nat := [2,4,8,16,0,16,24,14,16,1024,0,1028,9,1054,11,19,1029,17,1025,11,1028,10,17,8,24,10,16,1055,1029,0,1040,11,15,1,1028,17]

theorem envBound11093 : H12AffineFastState.Bounded env11093 := by
  intro p hp
  have h : env11093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11092_11093 : H12AffineEnvironment.transform 4 0 env11092 = env11093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env11092 == env11093) = true)

theorem identity11093 : scanCanonicalize (H12AffineFastState.compose env11093 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound11093 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11094 : List Nat := [2,4,8,1,0,1,9,14,1,1024,0,1028,9,1039,11,2,1029,0,1025,11,1028,10,0,8,9,10,1,1038,1029,0,1025,11,15,1,1028,0]

theorem envBound11094 : H12AffineFastState.Bounded env11094 := by
  intro p hp
  have h : env11094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11093_11094 : H12AffineEnvironment.transform 3 1 env11093 = env11094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env11093 == env11094) = true)

def env11095 : List Nat := [2,4,8,16,32,16,128,182,136,1024,1,1180,9,1190,179,139,1181,168,1025,179,1180,10,17,176,128,42,17,1191,1181,185,1160,178,183,152,1180,137]

theorem envBound11095 : H12AffineFastState.Bounded env11095 := by
  intro p hp
  have h : env11095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11090_11095 : H12AffineEnvironment.transform 10 1 env11090 = env11095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env11090 == env11095) = true)

theorem identity11095 : scanCanonicalize (H12AffineFastState.compose env11095 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound11095 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env11096 : List Nat := [2,4,8,16,32,16,3,53,11,1024,1,1055,9,1061,48,8,1054,43,1025,48,1055,10,17,51,3,42,17,1060,1054,58,1035,49,52,27,1055,10]

theorem envBound11096 : H12AffineFastState.Bounded env11096 := by
  intro p hp
  have h : env11096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11095_11096 : H12AffineEnvironment.transform 6 3 env11095 = env11096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env11095 == env11096) = true)

theorem identity11096 : scanCanonicalize (H12AffineFastState.compose env11096 (packedSelected [2,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound11096 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env11097 : List Nat := [2,4,8,16,0,16,3,21,11,1024,1,1055,9,1029,16,8,1054,11,1025,16,1055,10,17,19,3,10,17,1028,1054,26,1035,17,20,27,1055,10]

theorem envBound11097 : H12AffineFastState.Bounded env11097 := by
  intro p hp
  have h : env11097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11096_11097 : H12AffineEnvironment.transform 4 0 env11096 = env11097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env11096 == env11097) = true)

theorem identity11097 : scanCanonicalize (H12AffineFastState.compose env11097 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound11097 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11098 : List Nat := [2,4,3,16,0,16,3,21,0,1024,1,1044,2,1029,16,3,1045,0,1025,16,1044,1,17,19,3,1,17,1028,1045,17,1024,17,20,16,1044,1]

theorem envBound11098 : H12AffineFastState.Bounded env11098 := by
  intro p hp
  have h : env11098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11097_11098 : H12AffineEnvironment.transform 2 3 env11097 = env11098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env11097 == env11098) = true)

theorem identity11098 : scanCanonicalize (H12AffineFastState.compose env11098 (packedSelected [10] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound11098 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env11099 : List Nat := [2,4,3,1,0,1,3,4,0,1024,1,1029,2,1029,1,3,1028,0,1025,1,1029,1,0,2,3,1,0,1028,1028,0,1024,0,5,1,1029,1]

theorem envBound11099 : H12AffineFastState.Bounded env11099 := by
  intro p hp
  have h : env11099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11098_11099 : H12AffineEnvironment.transform 3 1 env11098 = env11099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env11098 == env11099) = true)

def leafEnv11099 : List Nat := [2,4,3,1,0,1,3,4,0,1024,1,1029,2,1029,1,3,1028,0,1025,1,1029,1,0,2,1025,3,1,1,0,1028,1028,0,1024,0,5,1,5,2,1029,1,0,1028,1]

def active11099 : List Nat := [0,1,9]

def tree11099 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11099 : H12WitnessSearch.Good tree11099 := H12GlobalWitnessIndex.good

theorem leafIdentity11099 : H12AffineFastState.composeSystem env11099 rootObs = leafEnv11099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11099 rootObs == leafEnv11099) = true)

theorem terminalChecked11099 : H12PackedTerminal.terminalCheckFast leafEnv11099 active11099 tree11099 = true := by decide +kernel

def env11100 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,4096,9,1296,261,139,4097,7221,1025,261,4096,5409,17,5530,128,5376,2065,1297,4097,7205,4116,7214,257,2351,4096,137]

theorem envBound11100 : H12AffineFastState.Bounded env11100 := by
  intro p hp
  have h : env11100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11087_11100 : H12AffineEnvironment.transform 21 5409 env11087 = env11100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 5409 env11087 == env11100) = true)

theorem identity11100 : scanCanonicalize (H12AffineFastState.compose env11100 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 1191) := by decide +kernel

theorem selectedBound11100 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11101 : List Nat := [2,4,8,16,32,16,128,256,136,1024,2048,1191,9,1296,261,139,1190,2194,1025,261,1191,390,17,317,128,423,2065,1297,1190,2178,1203,2185,257,2351,1191,137]

theorem envBound11101 : H12AffineFastState.Bounded env11101 := by
  intro p hp
  have h : env11101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11100_11101 : H12AffineEnvironment.transform 11 1191 env11100 = env11101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1191 env11100 == env11101) = true)

theorem identity11101 : scanCanonicalize (H12AffineFastState.compose env11101 (packedSelected [6,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound11101 : packedSelected [6,10,12] rootPS < 2^1333 := by decide +kernel

def env11102 : List Nat := [2,4,8,16,32,16,128,140,136,1024,2048,1191,9,1180,137,139,1190,2194,1025,137,1191,10,17,177,128,43,2065,1181,1190,2178,1203,2185,141,2211,1191,137]

theorem envBound11102 : H12AffineFastState.Bounded env11102 := by
  intro p hp
  have h : env11102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11101_11102 : H12AffineEnvironment.transform 7 140 env11101 = env11102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env11101 == env11102) = true)

def env11103 : List Nat := [2,4,8,16,32,16,128,140,136,1024,0,1191,9,1180,137,139,1190,146,1025,137,1191,10,17,177,128,43,17,1181,1190,130,1203,137,141,163,1191,137]

theorem envBound11103 : H12AffineFastState.Bounded env11103 := by
  intro p hp
  have h : env11103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11102_11103 : H12AffineEnvironment.transform 10 0 env11102 = env11103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env11102 == env11103) = true)

theorem identity11103 : scanCanonicalize (H12AffineFastState.compose env11103 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound11103 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env11104 : List Nat := [2,4,8,16,32,16,2,14,10,1024,0,1061,9,1054,11,9,1060,16,1025,11,1061,10,17,51,2,43,17,1055,1060,0,1073,11,15,33,1061,11]

theorem envBound11104 : H12AffineFastState.Bounded env11104 := by
  intro p hp
  have h : env11104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11103_11104 : H12AffineEnvironment.transform 6 2 env11103 = env11104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env11103 == env11104) = true)

theorem identity11104 : scanCanonicalize (H12AffineFastState.compose env11104 (packedSelected [0,2,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound11104 : packedSelected [0,2,5] rootPS < 2^1333 := by decide +kernel

def env11105 : List Nat := [2,4,8,10,32,10,2,14,10,1024,0,1061,9,1028,11,9,1060,10,1025,11,1061,10,11,41,2,43,11,1029,1060,0,1067,11,15,33,1061,11]

theorem envBound11105 : H12AffineFastState.Bounded env11105 := by
  intro p hp
  have h : env11105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11104_11105 : H12AffineEnvironment.transform 3 10 env11104 = env11105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env11104 == env11105) = true)

theorem identity11105 : scanCanonicalize (H12AffineFastState.compose env11105 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound11105 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11106 : List Nat := [2,4,2,0,32,0,2,4,0,1024,0,1061,3,1028,1,3,1060,0,1025,1,1061,0,1,35,2,33,1,1029,1060,0,1057,1,5,33,1061,1]

theorem envBound11106 : H12AffineFastState.Bounded env11106 := by
  intro p hp
  have h : env11106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11105_11106 : H12AffineEnvironment.transform 2 2 env11105 = env11106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env11105 == env11106) = true)

def env11107 : List Nat := [2,4,8,16,32,16,128,140,136,1024,1,1191,9,1180,137,139,1190,147,1025,137,1191,10,17,177,128,43,16,1181,1190,131,1203,136,141,162,1191,137]

theorem envBound11107 : H12AffineFastState.Bounded env11107 := by
  intro p hp
  have h : env11107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11102_11107 : H12AffineEnvironment.transform 10 1 env11102 = env11107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env11102 == env11107) = true)

theorem identity11107 : scanCanonicalize (H12AffineFastState.compose env11107 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound11107 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env11108 : List Nat := [2,4,8,16,32,16,56,52,48,1024,1,1055,9,1060,49,51,1054,43,1025,49,1055,10,17,9,56,43,16,1061,1054,59,1035,48,53,26,1055,49]

theorem envBound11108 : H12AffineFastState.Bounded env11108 := by
  intro p hp
  have h : env11108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11107_11108 : H12AffineEnvironment.transform 6 56 env11107 = env11108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env11107 == env11108) = true)

theorem identity11108 : scanCanonicalize (H12AffineFastState.compose env11108 (packedSelected [2,5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound11108 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env11109 : List Nat := [2,4,8,10,32,10,34,46,42,1024,1,1029,9,1060,43,41,1028,43,1025,43,1029,10,11,9,34,43,10,1061,1028,33,1035,42,47,0,1029,43]

theorem envBound11109 : H12AffineFastState.Bounded env11109 := by
  intro p hp
  have h : env11109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11108_11109 : H12AffineEnvironment.transform 3 10 env11108 = env11109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env11108 == env11109) = true)

theorem identity11109 : scanCanonicalize (H12AffineFastState.compose env11109 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound11109 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11110 : List Nat := [2,4,3,1,32,1,34,37,33,1024,1,1029,2,1060,32,34,1028,32,1025,32,1029,1,0,2,34,32,1,1061,1028,33,1024,33,36,0,1029,32]

theorem envBound11110 : H12AffineFastState.Bounded env11110 := by
  intro p hp
  have h : env11110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11109_11110 : H12AffineEnvironment.transform 2 3 env11109 = env11110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env11109 == env11110) = true)

theorem identity11110 : scanCanonicalize (H12AffineFastState.compose env11110 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound11110 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11111 : List Nat := [2,4,3,1,0,1,2,5,1,1024,1,1029,2,1028,0,2,1028,0,1025,0,1029,1,0,2,2,0,1,1029,1028,1,1024,1,4,0,1029,0]

theorem envBound11111 : H12AffineFastState.Bounded env11111 := by
  intro p hp
  have h : env11111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11110_11111 : H12AffineEnvironment.transform 4 0 env11110 = env11111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env11110 == env11111) = true)

def env11112 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,4096,8,16384,32768,65536,4097,262144,1025,32768,4096,4194304,17665,16777216,17808,16875796,21352449,16897045,4097,20978846,16876544,4294967296,257,4299260335,4096,17817]

theorem envBound11112 : H12AffineFastState.Bounded env11112 := by
  intro p hp
  have h : env11112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11080_11112 : H12AffineEnvironment.transform 8 137 env11080 = env11112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env11080 == env11112) = true)

theorem identity11112 : scanCanonicalize (H12AffineFastState.compose env11112 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound11112 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env11113 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,8,16384,32768,65536,1297,262144,1025,32768,1296,4194304,17665,16777216,17808,16875796,21349649,16892165,1297,20973966,16876544,4294967296,257,4299260335,1296,17817]

theorem envBound11113 : H12AffineFastState.Bounded env11113 := by
  intro p hp
  have h : env11113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11112_11113 : H12AffineEnvironment.transform 11 1296 env11112 = env11113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env11112 == env11113) = true)

theorem identity11113 : scanCanonicalize (H12AffineFastState.compose env11113 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(23+1) ^^^ 115733) := by decide +kernel

theorem selectedBound11113 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env11114 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,8,16384,32768,65536,1297,262144,1025,32768,1296,4194304,17665,115733,17808,17665,4456708,1296,1297,4312475,16405,4294967296,257,4299260335,1296,17817]

theorem envBound11114 : H12AffineFastState.Bounded env11114 := by
  intro p hp
  have h : env11114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11113_11114 : H12AffineEnvironment.transform 23 115733 env11113 = env11114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 115733 env11113 == env11114) = true)

theorem identity11114 : scanCanonicalize (H12AffineFastState.compose env11114 (packedSelected [1,3,4,9,12,13,15,16,17] rootPS)) = affineNative (2^(17+1) ^^^ 85182) := by decide +kernel

theorem selectedBound11114 : packedSelected [1,3,4,9,12,13,15,16,17] rootPS < 2^1333 := by decide +kernel

def env11115 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,8,16384,32768,65536,1297,85182,1025,32768,1296,4194304,17665,115733,17808,17665,4279738,1296,1297,4312475,16405,4294967296,257,4299260335,1296,17817]

theorem envBound11115 : H12AffineFastState.Bounded env11115 := by
  intro p hp
  have h : env11115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11114_11115 : H12AffineEnvironment.transform 17 85182 env11114 = env11115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 85182 env11114 == env11115) = true)

theorem identity11115 : scanCanonicalize (H12AffineFastState.compose env11115 (packedSelected [0,1,3,7,12,13,15,18,20,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 50334) := by decide +kernel

theorem selectedBound11115 : packedSelected [0,1,3,7,12,13,15,18,20,21,23] rootPS < 2^1333 := by decide +kernel

def env11116 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,8,16384,32768,50334,1297,34848,1025,32768,1296,4194304,17665,139,17808,17665,4229412,1296,1297,4196613,16405,4294967296,257,4299179313,1296,17817]

theorem envBound11116 : H12AffineFastState.Bounded env11116 := by
  intro p hp
  have h : env11116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11115_11116 : H12AffineEnvironment.transform 15 50334 env11115 = env11116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50334 env11115 == env11116) = true)

theorem identity11116 : scanCanonicalize (H12AffineFastState.compose env11116 (packedSelected [2,3,4,6,7,11,15,16] rootPS)) = affineNative (2^(31+1) ^^^ 4246532) := by decide +kernel

theorem selectedBound11116 : packedSelected [2,3,4,6,7,11,15,16] rootPS < 2^1333 := by decide +kernel

def env11117 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,8,16384,32768,50334,1297,34848,1025,32768,1296,4194304,17665,139,17808,17665,4229412,1296,1297,4196613,16405,4246532,257,35125,1296,17817]

theorem envBound11117 : H12AffineFastState.Bounded env11117 := by
  intro p hp
  have h : env11117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11116_11117 : H12AffineEnvironment.transform 31 4246532 env11116 = env11117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4246532 env11116 == env11117) = true)

theorem identity11117 : scanCanonicalize (H12AffineFastState.compose env11117 (packedSelected [0,3,4,7,8,9,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 17712) := by decide +kernel

theorem selectedBound11117 : packedSelected [0,3,4,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env11118 : List Nat := [2,4,8,16,32,16,128,256,137,1024,2048,1296,8,16384,17712,430,1297,19728,1025,17712,1296,4194304,17665,139,17808,17665,4213780,1296,1297,4196613,16405,4196660,257,19461,1296,17817]

theorem envBound11118 : H12AffineFastState.Bounded env11118 := by
  intro p hp
  have h : env11118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11117_11118 : H12AffineEnvironment.transform 14 17712 env11117 = env11118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 17712 env11117 == env11118) = true)

theorem identity11118 : scanCanonicalize (H12AffineFastState.compose env11118 (packedSelected [1,3,4,9] rootPS)) = affineNative (2^(10+1) ^^^ 261) := by decide +kernel

theorem selectedBound11118 : packedSelected [1,3,4,9] rootPS < 2^1333 := by decide +kernel

def env11119 : List Nat := [2,4,8,16,32,16,128,256,137,1024,261,1296,8,16384,17712,430,1297,17429,1025,17712,1296,4194304,17665,139,17808,17665,4211985,1296,1297,4194304,16405,4194353,257,17664,1296,17817]

theorem envBound11119 : H12AffineFastState.Bounded env11119 := by
  intro p hp
  have h : env11119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11118_11119 : H12AffineEnvironment.transform 10 261 env11118 = env11119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env11118 == env11119) = true)

theorem identity11119 : scanCanonicalize (H12AffineFastState.compose env11119 (packedSelected [2,3,4,5,6,7,8] rootPS)) = affineNative (2^(21+1) ^^^ 17429) := by decide +kernel

theorem selectedBound11119 : packedSelected [2,3,4,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env11120 : List Nat := [2,4,8,16,32,16,128,256,137,1024,261,1296,8,16384,17712,430,1297,17429,1025,17712,1296,17429,17665,139,17808,17665,260,1296,1297,17429,16405,17444,257,17664,1296,17817]

theorem envBound11120 : H12AffineFastState.Bounded env11120 := by
  intro p hp
  have h : env11120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11119_11120 : H12AffineEnvironment.transform 21 17429 env11119 = env11120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 17429 env11119 == env11120) = true)

def env11121 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,4096,4194304,17665,16777216,33554432,17010964,21352448,17024021,131073,21105822,16876544,4294967296,257,4332975158,131073,33563272]

theorem envBound11121 : H12AffineFastState.Bounded env11121 := by
  intro p hp
  have h : env11121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10939_11121 : H12AffineEnvironment.transform 5 17 env10939 = env11121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10939 == env11121) = true)

def env11122 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,640,16384,32768,65536,131072,262144,1025,32768,4096,4194304,17665,16777216,33554432,17010964,21352448,17024021,131073,21105822,16876544,4294967296,257,4332967606,131073,33554440]

theorem envBound11122 : H12AffineFastState.Bounded env11122 := by
  intro p hp
  have h : env11122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11121_11122 : H12AffineEnvironment.transform 12 640 env11121 = env11122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 640 env11121 == env11122) = true)

def env11123 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,640,16384,32768,65536,4096,262144,1025,32768,4096,4194304,17665,16777216,33554432,16875796,21352448,16897045,4097,20978846,16876544,4294967296,257,4332832438,4097,33554440]

theorem envBound11123 : H12AffineFastState.Bounded env11123 := by
  intro p hp
  have h : env11123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11122_11123 : H12AffineEnvironment.transform 16 4096 env11122 = env11123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env11122 == env11123) = true)

theorem identity11123 : scanCanonicalize (H12AffineFastState.compose env11123 (packedSelected [1,3,5,8,9,10,19,22] rootPS)) = affineNative (2^(23+1) ^^^ 119693) := by decide +kernel

theorem selectedBound11123 : packedSelected [1,3,5,8,9,10,19,22] rootPS < 2^1333 := by decide +kernel

def env11124 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,640,16384,32768,65536,4096,262144,1025,32768,4096,4194304,17665,119693,33554432,21145,4457357,1944,4097,4312851,22413,4294967296,257,4332832438,4097,33554440]

theorem envBound11124 : H12AffineFastState.Bounded env11124 := by
  intro p hp
  have h : env11124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11123_11124 : H12AffineEnvironment.transform 23 119693 env11123 = env11124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 119693 env11123 == env11124) = true)

def env11125 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,640,16384,32768,65536,4096,262144,1025,32768,4096,4194304,17665,119693,128,21145,4457357,1944,4097,4312851,22413,4294967296,257,4299277878,4097,136]

theorem envBound11125 : H12AffineFastState.Bounded env11125 := by
  intro p hp
  have h : env11125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11124_11125 : H12AffineEnvironment.transform 24 128 env11124 = env11125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 128 env11124 == env11125) = true)

theorem identity11125 : scanCanonicalize (H12AffineFastState.compose env11125 (packedSelected [1,5,6,8,19,24,25,26] rootPS)) = affineNative (2^(13+1) ^^^ 1945) := by decide +kernel

theorem selectedBound11125 : packedSelected [1,5,6,8,19,24,25,26] rootPS < 2^1333 := by decide +kernel

def env11126 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,640,1945,32768,65536,4096,262144,1025,32768,4096,4194304,664,103444,128,5376,4457357,1944,4097,4294794,4116,4294967296,257,4299260335,4097,136]

theorem envBound11126 : H12AffineFastState.Bounded env11126 := by
  intro p hp
  have h : env11126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11125_11126 : H12AffineEnvironment.transform 13 1945 env11125 = env11126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1945 env11125 == env11126) = true)

theorem identity11126 : scanCanonicalize (H12AffineFastState.compose env11126 (packedSelected [0,4,5,7,8,9,16,17,20,21] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound11126 : packedSelected [0,4,5,7,8,9,16,17,20,21] rootPS < 2^1333 := by decide +kernel

def env11127 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,4096,9,1296,32768,65536,4096,262144,1025,32768,4096,4194304,17,103444,128,5376,4456708,1297,4097,4294794,4116,4294967296,257,4299260335,4097,136]

theorem envBound11127 : H12AffineFastState.Bounded env11127 := by
  intro p hp
  have h : env11127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11126_11127 : H12AffineEnvironment.transform 8 137 env11126 = env11127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env11126 == env11127) = true)

theorem identity11127 : scanCanonicalize (H12AffineFastState.compose env11127 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound11127 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env11128 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1296,9,1296,32768,65536,1296,262144,1025,32768,1296,4194304,17,98564,128,16,4456708,1297,1297,4294794,1284,4294967296,257,4299260335,1297,136]

theorem envBound11128 : H12AffineFastState.Bounded env11128 := by
  intro p hp
  have h : env11128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11127_11128 : H12AffineEnvironment.transform 11 1296 env11127 = env11128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env11127 == env11128) = true)

theorem identity11128 : scanCanonicalize (H12AffineFastState.compose env11128 (packedSelected [1,3,5] rootPS)) = affineNative (2^(21+1) ^^^ 34848) := by decide +kernel

theorem selectedBound11128 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env11129 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1296,9,1296,32768,65536,1296,262144,1025,32768,1296,34848,17,98564,128,16,297252,1297,1297,65706,1284,4294967296,257,4295035279,1297,136]

theorem envBound11129 : H12AffineFastState.Bounded env11129 := by
  intro p hp
  have h : env11129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11128_11129 : H12AffineEnvironment.transform 21 34848 env11128 = env11129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 34848 env11128 == env11129) = true)

theorem identity11129 : scanCanonicalize (H12AffineFastState.compose env11129 (packedSelected [1,3,8] rootPS)) = affineNative (2^(15+1) ^^^ 33167) := by decide +kernel

theorem selectedBound11129 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env11130 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1296,9,1296,32768,33167,1296,262144,1025,32768,1296,34848,17,139,128,16,297252,1297,1297,33061,1284,4294967296,257,4295002112,1297,136]

theorem envBound11130 : H12AffineFastState.Bounded env11130 := by
  intro p hp
  have h : env11130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11129_11130 : H12AffineEnvironment.transform 15 33167 env11129 = env11130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33167 env11129 == env11130) = true)

theorem identity11130 : scanCanonicalize (H12AffineFastState.compose env11130 (packedSelected [1,3] rootPS)) = affineNative (2^(14+1) ^^^ 32) := by decide +kernel

theorem selectedBound11130 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env11131 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1296,9,1296,32,431,1296,262144,1025,32,1296,2048,17,139,128,16,264452,1297,1297,261,1284,4294967296,257,4294969376,1297,136]

theorem envBound11131 : H12AffineFastState.Bounded env11131 := by
  intro p hp
  have h : env11131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11130_11131 : H12AffineEnvironment.transform 14 32 env11130 = env11131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 32 env11130 == env11131) = true)

theorem identity11131 : scanCanonicalize (H12AffineFastState.compose env11131 (packedSelected [0,6] rootPS)) = affineNative (2^(17+1) ^^^ 2049) := by decide +kernel

theorem selectedBound11131 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env11132 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1296,9,1296,32,431,1296,2049,1025,32,1296,2048,17,139,128,16,261,1297,1297,261,1284,4294967296,257,4294969376,1297,136]

theorem envBound11132 : H12AffineFastState.Bounded env11132 := by
  intro p hp
  have h : env11132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11131_11132 : H12AffineEnvironment.transform 17 2049 env11131 = env11132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2049 env11131 == env11132) = true)

theorem identity11132 : scanCanonicalize (H12AffineFastState.compose env11132 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 17) := by decide +kernel

theorem selectedBound11132 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11133 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,1296,9,1296,32,431,1296,2049,1025,32,1296,2048,17,139,128,16,261,1297,1297,261,1284,17,257,2097,1297,136]

theorem envBound11133 : H12AffineFastState.Bounded env11133 := by
  intro p hp
  have h : env11133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11132_11133 : H12AffineEnvironment.transform 31 17 env11132 = env11133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 17 env11132 == env11133) = true)

def env11134 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,640,16384,32768,65536,4096,262144,1025,32768,4096,4194304,17665,119693,129,21145,4457357,1944,4097,4312851,22413,4294967296,257,4299277879,4097,137]

theorem envBound11134 : H12AffineFastState.Bounded env11134 := by
  intro p hp
  have h : env11134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11124_11134 : H12AffineEnvironment.transform 24 129 env11124 = env11134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 129 env11124 == env11134) = true)

theorem identity11134 : scanCanonicalize (H12AffineFastState.compose env11134 (packedSelected [1,5,6,8,19,24,25,26] rootPS)) = affineNative (2^(13+1) ^^^ 1297) := by decide +kernel

theorem selectedBound11134 : packedSelected [1,5,6,8,19,24,25,26] rootPS < 2^1333 := by decide +kernel

def env11135 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,640,1297,32768,65536,4096,262144,1025,32768,4096,4194304,16,104092,129,6024,4457357,1944,4097,4295170,4764,4294967296,257,4299260710,4097,137]

theorem envBound11135 : H12AffineFastState.Bounded env11135 := by
  intro p hp
  have h : env11135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11134_11135 : H12AffineEnvironment.transform 13 1297 env11134 = env11135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env11134 == env11135) = true)

theorem identity11135 : scanCanonicalize (H12AffineFastState.compose env11135 (packedSelected [3,5,6,8,10,25,28,31] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound11135 : packedSelected [3,5,6,8,10,25,28,31] rootPS < 2^1333 := by decide +kernel

def env11136 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,4096,8,1297,32768,65536,4096,262144,1025,32768,4096,4194304,16,103444,129,5376,4456709,1296,4097,4294794,4116,4294967296,257,4299260334,4097,137]

theorem envBound11136 : H12AffineFastState.Bounded env11136 := by
  intro p hp
  have h : env11136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11135_11136 : H12AffineEnvironment.transform 8 136 env11135 = env11136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env11135 == env11136) = true)

theorem identity11136 : scanCanonicalize (H12AffineFastState.compose env11136 (packedSelected [5,8,17,21] rootPS)) = affineNative (2^(14+1) ^^^ 260) := by decide +kernel

theorem selectedBound11136 : packedSelected [5,8,17,21] rootPS < 2^1333 := by decide +kernel

def env11137 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,4096,8,1297,260,65536,4096,262144,1025,260,4096,4194304,16,70928,129,5376,4456709,1296,4097,4262286,4116,4294967296,257,4299227306,4097,137]

theorem envBound11137 : H12AffineFastState.Bounded env11137 := by
  intro p hp
  have h : env11137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11136_11137 : H12AffineEnvironment.transform 14 260 env11136 = env11137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 260 env11136 == env11137) = true)

theorem identity11137 : scanCanonicalize (H12AffineFastState.compose env11137 (packedSelected [5,6,8,10,12,13] rootPS)) = affineNative (2^(31+1) ^^^ 4267156) := by decide +kernel

theorem selectedBound11137 : packedSelected [5,6,8,10,12,13] rootPS < 2^1333 := by decide +kernel

def env11138 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,4096,8,1297,260,65536,4096,262144,1025,260,4096,4194304,16,70928,129,5376,4456709,1296,4097,4262286,4116,4267156,257,7230,4097,137]

theorem envBound11138 : H12AffineFastState.Bounded env11138 := by
  intro p hp
  have h : env11138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11137_11138 : H12AffineEnvironment.transform 31 4267156 env11137 = env11138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4267156 env11137 == env11138) = true)

theorem identity11138 : scanCanonicalize (H12AffineFastState.compose env11138 (packedSelected [10,12,17] rootPS)) = affineNative (2^(17+1) ^^^ 72895) := by decide +kernel

theorem selectedBound11138 : packedSelected [10,12,17] rootPS < 2^1333 := by decide +kernel

def env11139 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,4096,8,1297,260,65536,4096,72895,1025,260,4096,4194304,16,70928,129,5376,4267450,1296,4097,4262286,4116,4267156,257,7230,4097,137]

theorem envBound11139 : H12AffineFastState.Bounded env11139 := by
  intro p hp
  have h : env11139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11138_11139 : H12AffineEnvironment.transform 17 72895 env11138 = env11139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 72895 env11138 == env11139) = true)

theorem identity11139 : scanCanonicalize (H12AffineFastState.compose env11139 (packedSelected [1,24] rootPS)) = affineNative (2^(15+1) ^^^ 138) := by decide +kernel

theorem selectedBound11139 : packedSelected [1,24] rootPS < 2^1333 := by decide +kernel

def env11140 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,4096,8,1297,260,138,4096,7221,1025,260,4096,4194304,16,5530,129,5376,4201776,1296,4097,4196612,4116,4201502,257,7230,4097,137]

theorem envBound11140 : H12AffineFastState.Bounded env11140 := by
  intro p hp
  have h : env11140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11139_11140 : H12AffineEnvironment.transform 15 138 env11139 = env11140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 138 env11139 == env11140) = true)

def env11141 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,4096,8,1297,260,138,4096,7221,1025,260,4096,5408,16,5530,129,5376,2064,1296,4097,7204,4116,2366,257,7230,4097,137]

theorem envBound11141 : H12AffineFastState.Bounded env11141 := by
  intro p hp
  have h : env11141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11140_11141 : H12AffineEnvironment.transform 21 5408 env11140 = env11141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 5408 env11140 == env11141) = true)

theorem identity11141 : scanCanonicalize (H12AffineFastState.compose env11141 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 182) := by decide +kernel

theorem selectedBound11141 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11142 : List Nat := [2,4,8,16,32,17,128,182,136,1024,2048,4096,8,1191,178,138,4096,7221,1025,178,4096,5270,16,5164,129,5302,2064,1190,4097,7204,4116,2184,183,7230,4097,137]

theorem envBound11142 : H12AffineFastState.Bounded env11142 := by
  intro p hp
  have h : env11142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11141_11142 : H12AffineEnvironment.transform 7 182 env11141 = env11142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 182 env11141 == env11142) = true)

theorem identity11142 : scanCanonicalize (H12AffineFastState.compose env11142 (packedSelected [6,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 1181) := by decide +kernel

theorem selectedBound11142 : packedSelected [6,10,12] rootPS < 2^1333 := by decide +kernel

def env11143 : List Nat := [2,4,8,16,32,17,128,182,136,1024,2048,1181,8,1191,178,138,1181,2216,1025,178,1181,11,16,177,129,43,2064,1190,1180,2233,1161,2184,183,2211,1180,137]

theorem envBound11143 : H12AffineFastState.Bounded env11143 := by
  intro p hp
  have h : env11143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11142_11143 : H12AffineEnvironment.transform 11 1181 env11142 = env11143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1181 env11142 == env11143) = true)

def env11144 : List Nat := [2,4,8,16,32,17,128,182,136,1024,0,1181,8,1191,178,138,1181,168,1025,178,1181,11,16,177,129,43,16,1190,1180,185,1161,136,183,163,1180,137]

theorem envBound11144 : H12AffineFastState.Bounded env11144 := by
  intro p hp
  have h : env11144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11143_11144 : H12AffineEnvironment.transform 10 0 env11143 = env11144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env11143 == env11144) = true)

theorem identity11144 : scanCanonicalize (H12AffineFastState.compose env11144 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound11144 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env11145 : List Nat := [2,4,8,16,32,17,3,53,11,1024,0,1054,8,1060,49,9,1054,43,1025,49,1054,11,16,50,2,43,16,1061,1055,58,1034,11,52,32,1055,10]

theorem envBound11145 : H12AffineFastState.Bounded env11145 := by
  intro p hp
  have h : env11145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11144_11145 : H12AffineEnvironment.transform 6 3 env11144 = env11145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env11144 == env11145) = true)

theorem identity11145 : scanCanonicalize (H12AffineFastState.compose env11145 (packedSelected [0,2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound11145 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env11146 : List Nat := [2,4,8,16,10,17,3,31,11,1024,0,1054,8,1038,27,9,1054,1,1025,27,1054,11,16,24,2,1,16,1039,1055,16,1034,11,30,10,1055,10]

theorem envBound11146 : H12AffineFastState.Bounded env11146 := by
  intro p hp
  have h : env11146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11145_11146 : H12AffineEnvironment.transform 4 10 env11145 = env11146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env11145 == env11146) = true)

theorem identity11146 : scanCanonicalize (H12AffineFastState.compose env11146 (packedSelected [0,5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound11146 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env11147 : List Nat := [2,4,2,16,0,17,3,21,1,1024,0,1044,2,1028,17,3,1044,1,1025,17,1044,1,16,18,2,1,16,1029,1045,16,1024,1,20,0,1045,0]

theorem envBound11147 : H12AffineFastState.Bounded env11147 := by
  intro p hp
  have h : env11147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11146_11147 : H12AffineEnvironment.transform 2 2 env11146 = env11147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env11146 == env11147) = true)

theorem identity11147 : scanCanonicalize (H12AffineFastState.compose env11147 (packedSelected [10] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound11147 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env11148 : List Nat := [2,4,2,1,0,0,3,4,1,1024,0,1029,2,1028,0,3,1029,1,1025,0,1029,1,1,3,2,1,1,1029,1028,1,1024,1,5,0,1028,0]

theorem envBound11148 : H12AffineFastState.Bounded env11148 := by
  intro p hp
  have h : env11148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11147_11148 : H12AffineEnvironment.transform 3 1 env11147 = env11148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env11147 == env11148) = true)

def leafEnv11148 : List Nat := [2,4,2,1,0,0,3,4,1,1024,0,1029,2,1028,0,3,1029,1,1025,0,1029,1,1,3,1025,2,1,1,1,1029,1028,1,1024,1,5,0,5,3,1028,0,0,1028,1]

def active11148 : List Nat := [0,1,9]

def tree11148 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11148 : H12WitnessSearch.Good tree11148 := H12GlobalWitnessIndex.good

theorem leafIdentity11148 : H12AffineFastState.composeSystem env11148 rootObs = leafEnv11148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11148 rootObs == leafEnv11148) = true)

theorem terminalChecked11148 : H12PackedTerminal.terminalCheckFast leafEnv11148 active11148 tree11148 = true := by decide +kernel

def env11149 : List Nat := [2,4,8,16,32,17,128,182,136,1024,1,1181,8,1191,178,138,1181,169,1025,178,1181,11,16,177,129,43,17,1190,1180,184,1161,137,183,162,1180,137]

theorem envBound11149 : H12AffineFastState.Bounded env11149 := by
  intro p hp
  have h : env11149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11143_11149 : H12AffineEnvironment.transform 10 1 env11143 = env11149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env11143 == env11149) = true)

theorem identity11149 : scanCanonicalize (H12AffineFastState.compose env11149 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound11149 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env11150 : List Nat := [2,4,8,16,32,17,57,15,49,1024,1,1060,8,1054,11,51,1060,16,1025,11,1060,11,16,8,56,43,17,1055,1061,1,1072,48,14,27,1061,48]

theorem envBound11150 : H12AffineFastState.Bounded env11150 := by
  intro p hp
  have h : env11150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11149_11150 : H12AffineEnvironment.transform 6 57 env11149 = env11150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env11149 == env11150) = true)

theorem identity11150 : scanCanonicalize (H12AffineFastState.compose env11150 (packedSelected [2,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound11150 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env11151 : List Nat := [2,4,8,16,16,17,9,15,1,1024,1,1044,8,1054,11,3,1044,16,1025,11,1044,11,16,8,8,27,17,1055,1045,1,1024,0,14,27,1045,0]

theorem envBound11151 : H12AffineFastState.Bounded env11151 := by
  intro p hp
  have h : env11151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11150_11151 : H12AffineEnvironment.transform 4 16 env11150 = env11151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env11150 == env11151) = true)

theorem identity11151 : scanCanonicalize (H12AffineFastState.compose env11151 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound11151 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11152 : List Nat := [2,4,8,11,11,10,9,15,1,1024,1,1039,8,1029,11,3,1039,11,1025,11,1039,11,11,8,8,0,10,1028,1038,1,1024,0,14,0,1038,0]

theorem envBound11152 : H12AffineFastState.Bounded env11152 := by
  intro p hp
  have h : env11152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11151_11152 : H12AffineEnvironment.transform 3 11 env11151 = env11152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env11151 == env11152) = true)

def env11153 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,4096,8,1297,260,138,4096,7221,1025,260,4096,5409,16,5530,129,5376,2065,1296,4097,7205,4116,2367,257,7230,4097,137]

theorem envBound11153 : H12AffineFastState.Bounded env11153 := by
  intro p hp
  have h : env11153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11140_11153 : H12AffineEnvironment.transform 21 5409 env11140 = env11153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 5409 env11140 == env11153) = true)

theorem identity11153 : scanCanonicalize (H12AffineFastState.compose env11153 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 1191) := by decide +kernel

theorem selectedBound11153 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11154 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1191,8,1297,260,138,1191,2194,1025,260,1191,390,16,317,129,423,2065,1296,1190,2178,1203,2367,257,2201,1190,137]

theorem envBound11154 : H12AffineFastState.Bounded env11154 := by
  intro p hp
  have h : env11154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11153_11154 : H12AffineEnvironment.transform 11 1191 env11153 = env11154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1191 env11153 == env11154) = true)

theorem identity11154 : scanCanonicalize (H12AffineFastState.compose env11154 (packedSelected [6,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound11154 : packedSelected [6,10,12] rootPS < 2^1333 := by decide +kernel

def env11155 : List Nat := [2,4,8,16,32,17,128,141,136,1024,2048,1191,8,1180,137,138,1191,2194,1025,137,1191,11,16,176,129,42,2065,1181,1190,2178,1203,2226,140,2201,1190,137]

theorem envBound11155 : H12AffineFastState.Bounded env11155 := by
  intro p hp
  have h : env11155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11154_11155 : H12AffineEnvironment.transform 7 141 env11154 = env11155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env11154 == env11155) = true)

def env11156 : List Nat := [2,4,8,16,32,17,128,141,136,1024,0,1191,8,1180,137,138,1191,146,1025,137,1191,11,16,176,129,42,17,1181,1190,130,1203,178,140,153,1190,137]

theorem envBound11156 : H12AffineFastState.Bounded env11156 := by
  intro p hp
  have h : env11156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11155_11156 : H12AffineEnvironment.transform 10 0 env11155 = env11156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env11155 == env11156) = true)

theorem identity11156 : scanCanonicalize (H12AffineFastState.compose env11156 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound11156 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env11157 : List Nat := [2,4,8,16,32,17,57,52,49,1024,0,1054,8,1061,48,51,1054,43,1025,48,1054,11,16,9,56,42,17,1060,1055,59,1034,11,53,32,1055,48]

theorem envBound11157 : H12AffineFastState.Bounded env11157 := by
  intro p hp
  have h : env11157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11156_11157 : H12AffineEnvironment.transform 6 57 env11156 = env11157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env11156 == env11157) = true)

theorem identity11157 : scanCanonicalize (H12AffineFastState.compose env11157 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound11157 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env11158 : List Nat := [2,4,8,1,32,0,40,37,32,1024,0,1039,8,1061,33,34,1039,43,1025,33,1039,11,1,9,41,42,0,1060,1038,42,1034,11,36,32,1038,33]

theorem envBound11158 : H12AffineFastState.Bounded env11158 := by
  intro p hp
  have h : env11158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11157_11158 : H12AffineEnvironment.transform 3 1 env11157 = env11158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env11157 == env11158) = true)

theorem identity11158 : scanCanonicalize (H12AffineFastState.compose env11158 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound11158 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env11159 : List Nat := [2,4,8,1,10,0,2,15,10,1024,0,1039,8,1039,11,8,1039,1,1025,11,1039,11,1,9,3,0,0,1038,1038,0,1034,11,14,10,1038,11]

theorem envBound11159 : H12AffineFastState.Bounded env11159 := by
  intro p hp
  have h : env11159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11158_11159 : H12AffineEnvironment.transform 4 10 env11158 = env11159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env11158 == env11159) = true)

theorem identity11159 : scanCanonicalize (H12AffineFastState.compose env11159 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound11159 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env11160 : List Nat := [2,4,2,1,0,0,2,5,0,1024,0,1029,2,1029,1,2,1029,1,1025,1,1029,1,1,3,3,0,0,1028,1028,0,1024,1,4,0,1028,1]

theorem envBound11160 : H12AffineFastState.Bounded env11160 := by
  intro p hp
  have h : env11160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11159_11160 : H12AffineEnvironment.transform 2 2 env11159 = env11160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env11159 == env11160) = true)

def env11161 : List Nat := [2,4,8,16,32,17,128,141,136,1024,1,1191,8,1180,137,138,1191,147,1025,137,1191,11,16,176,129,42,16,1181,1190,131,1203,179,140,152,1190,137]

theorem envBound11161 : H12AffineFastState.Bounded env11161 := by
  intro p hp
  have h : env11161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11155_11161 : H12AffineEnvironment.transform 10 1 env11155 = env11161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env11155 == env11161) = true)

theorem identity11161 : scanCanonicalize (H12AffineFastState.compose env11161 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound11161 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env11162 : List Nat := [2,4,8,16,32,17,2,15,10,1024,1,1061,8,1054,11,8,1061,17,1025,11,1061,11,16,50,3,42,16,1055,1060,1,1073,49,14,26,1060,11]

theorem envBound11162 : H12AffineFastState.Bounded env11162 := by
  intro p hp
  have h : env11162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11161_11162 : H12AffineEnvironment.transform 6 2 env11161 = env11162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env11161 == env11162) = true)

theorem identity11162 : scanCanonicalize (H12AffineFastState.compose env11162 (packedSelected [2,5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound11162 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env11163 : List Nat := [2,4,2,16,32,17,2,5,0,1024,1,1061,2,1044,1,2,1061,17,1025,1,1061,1,16,50,3,32,16,1045,1060,1,1073,49,4,16,1060,1]

theorem envBound11163 : H12AffineFastState.Bounded env11163 := by
  intro p hp
  have h : env11163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11162_11163 : H12AffineEnvironment.transform 2 2 env11162 = env11163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env11162 == env11163) = true)

theorem identity11163 : scanCanonicalize (H12AffineFastState.compose env11163 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound11163 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11164 : List Nat := [2,4,2,16,1,17,2,5,0,1024,1,1028,2,1044,1,2,1028,17,1025,1,1028,1,16,19,3,1,16,1045,1029,1,1040,16,4,16,1029,1]

theorem envBound11164 : H12AffineFastState.Bounded env11164 := by
  intro p hp
  have h : env11164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11163_11164 : H12AffineEnvironment.transform 4 1 env11163 = env11164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env11163 == env11164) = true)

def env11165 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,640,16384,32768,65536,4097,262144,1025,32768,4096,4194304,17665,16777216,33554432,16875797,21352448,16897044,4096,20978847,16876544,4294967296,257,4332832439,4096,33554440]

theorem envBound11165 : H12AffineFastState.Bounded env11165 := by
  intro p hp
  have h : env11165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11122_11165 : H12AffineEnvironment.transform 16 4097 env11122 = env11165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4097 env11122 == env11165) = true)

theorem identity11165 : scanCanonicalize (H12AffineFastState.compose env11165 (packedSelected [1,3,5,8,9,10,19,22] rootPS)) = affineNative (2^(23+1) ^^^ 116380) := by decide +kernel

theorem selectedBound11165 : packedSelected [1,3,5,8,9,10,19,22] rootPS < 2^1333 := by decide +kernel

def env11166 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,640,16384,32768,65536,4097,262144,1025,32768,4096,4194304,17665,116380,33554432,18313,4462236,4744,4096,4315651,17052,4294967296,257,4332832439,4096,33554440]

theorem envBound11166 : H12AffineFastState.Bounded env11166 := by
  intro p hp
  have h : env11166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11165_11166 : H12AffineEnvironment.transform 23 116380 env11165 = env11166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 116380 env11165 == env11166) = true)

def env11167 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,640,16384,32768,65536,4097,262144,1025,32768,4096,4194304,17665,116380,128,18313,4462236,4744,4096,4315651,17052,4294967296,257,4299277879,4096,136]

theorem envBound11167 : H12AffineFastState.Bounded env11167 := by
  intro p hp
  have h : env11167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11166_11167 : H12AffineEnvironment.transform 24 128 env11166 = env11167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 128 env11166 == env11167) = true)

theorem identity11167 : scanCanonicalize (H12AffineFastState.compose env11167 (packedSelected [6,25] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound11167 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env11168 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,4096,9,16384,32768,65536,4097,262144,1025,32768,4096,4194304,17665,115733,128,17664,4461589,4097,4096,4315274,16405,4294967296,257,4299277502,4096,136]

theorem envBound11168 : H12AffineFastState.Bounded env11168 := by
  intro p hp
  have h : env11168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11167_11168 : H12AffineEnvironment.transform 8 137 env11167 = env11168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env11167 == env11168) = true)

theorem identity11168 : scanCanonicalize (H12AffineFastState.compose env11168 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 4096) := by decide +kernel

theorem selectedBound11168 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env11169 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,4096,9,4096,32768,65536,4097,262144,1025,32768,4096,4194304,5377,103445,128,5376,4461589,4097,4096,4294794,4117,4294967296,257,4299265214,4096,136]

theorem envBound11169 : H12AffineFastState.Bounded env11169 := by
  intro p hp
  have h : env11169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11168_11169 : H12AffineEnvironment.transform 13 4096 env11168 = env11169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env11168 == env11169) = true)

def env11170 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,640,16384,32768,65536,4097,262144,1025,32768,4096,4194304,17665,116380,129,18313,4462236,4744,4096,4315651,17052,4294967296,257,4299277878,4096,137]

theorem envBound11170 : H12AffineFastState.Bounded env11170 := by
  intro p hp
  have h : env11170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11166_11170 : H12AffineEnvironment.transform 24 129 env11166 = env11170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 129 env11166 == env11170) = true)

theorem identity11170 : scanCanonicalize (H12AffineFastState.compose env11170 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound11170 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env11171 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,640,16384,32768,65536,1296,262144,1025,32768,1297,4194304,17665,116380,129,18313,4457357,1945,1297,4312850,17052,4294967296,257,4299277878,1297,137]

theorem envBound11171 : H12AffineFastState.Bounded env11171 := by
  intro p hp
  have h : env11171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11170_11171 : H12AffineEnvironment.transform 11 1297 env11170 = env11171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env11170 == env11171) = true)

theorem identity11171 : scanCanonicalize (H12AffineFastState.compose env11171 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 1296) := by decide +kernel

theorem selectedBound11171 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env11172 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,640,1296,32768,65536,1296,262144,1025,32768,1297,4194304,17,99212,129,665,4457357,1945,1297,4295170,1932,4294967296,257,4299260710,1297,137]

theorem envBound11172 : H12AffineFastState.Bounded env11172 := by
  intro p hp
  have h : env11172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11171_11172 : H12AffineEnvironment.transform 13 1296 env11171 = env11172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env11171 == env11172) = true)

theorem identity11172 : scanCanonicalize (H12AffineFastState.compose env11172 (packedSelected [1,3,4,9,12,13,15,16,17] rootPS)) = affineNative (2^(17+1) ^^^ 68015) := by decide +kernel

theorem selectedBound11172 : packedSelected [1,3,4,9,12,13,15,16,17] rootPS < 2^1333 := by decide +kernel

def env11173 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,640,1296,32768,65536,1296,68015,1025,32768,1297,4194304,17,99212,129,665,4262434,1945,1297,4295170,1932,4294967296,257,4299260710,1297,137]

theorem envBound11173 : H12AffineFastState.Bounded env11173 := by
  intro p hp
  have h : env11173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11172_11173 : H12AffineEnvironment.transform 17 68015 env11172 = env11173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 68015 env11172 == env11173) = true)

theorem identity11173 : scanCanonicalize (H12AffineFastState.compose env11173 (packedSelected [0,1,3,7,12,13,15,20,21] rootPS)) = affineNative (2^(15+1) ^^^ 139) := by decide +kernel

theorem selectedBound11173 : packedSelected [0,1,3,7,12,13,15,20,21] rootPS < 2^1333 := by decide +kernel

def env11174 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,640,1296,32768,139,1296,2340,1025,32768,1297,4194304,17,33543,129,665,4197033,1945,1297,4229769,1932,4294967296,257,4299195309,1297,137]

theorem envBound11174 : H12AffineFastState.Bounded env11174 := by
  intro p hp
  have h : env11174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11173_11174 : H12AffineEnvironment.transform 15 139 env11173 = env11174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 139 env11173 == env11174) = true)

theorem identity11174 : scanCanonicalize (H12AffineFastState.compose env11174 (packedSelected [0,1,3,7,13,20] rootPS)) = affineNative (2^(31+1) ^^^ 33677) := by decide +kernel

theorem selectedBound11174 : packedSelected [0,1,3,7,13,20] rootPS < 2^1333 := by decide +kernel

def env11175 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1297,640,1296,32768,139,1296,2340,1025,32768,1297,4194304,17,33543,129,665,4197033,1945,1297,4229769,1932,33677,257,4194336,1297,137]

theorem envBound11175 : H12AffineFastState.Bounded env11175 := by
  intro p hp
  have h : env11175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11174_11175 : H12AffineEnvironment.transform 31 33677 env11174 = env11175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 33677 env11174 == env11175) = true)

theorem identity11175 : scanCanonicalize (H12AffineFastState.compose env11175 (packedSelected [18,23] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound11175 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env11176 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1297,8,1296,32768,139,1296,2340,1025,32768,1297,4194304,17,33167,129,17,4196385,1297,1297,4229121,1284,33029,257,4194336,1297,137]

theorem envBound11176 : H12AffineFastState.Bounded env11176 := by
  intro p hp
  have h : env11176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11175_11176 : H12AffineEnvironment.transform 8 136 env11175 = env11176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env11175 == env11176) = true)

theorem identity11176 : scanCanonicalize (H12AffineFastState.compose env11176 (packedSelected [3] rootPS)) = affineNative (2^(21+1) ^^^ 2217) := by decide +kernel

theorem selectedBound11176 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env11177 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1297,8,1296,32768,139,1296,2340,1025,32768,1297,2217,17,33167,129,17,136,1297,1297,32936,1284,33029,257,2185,1297,137]

theorem envBound11177 : H12AffineFastState.Bounded env11177 := by
  intro p hp
  have h : env11177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11176_11177 : H12AffineEnvironment.transform 21 2217 env11176 = env11177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2217 env11176 == env11177) = true)

theorem identity11177 : scanCanonicalize (H12AffineFastState.compose env11177 (packedSelected [1,5] rootPS)) = affineNative (2^(14+1) ^^^ 396) := by decide +kernel

theorem selectedBound11177 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env11178 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1297,8,1296,396,139,1296,2340,1025,396,1297,2217,17,3,129,17,136,1297,1297,292,1284,137,257,2185,1297,137]

theorem envBound11178 : H12AffineFastState.Bounded env11178 := by
  intro p hp
  have h : env11178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11177_11178 : H12AffineEnvironment.transform 14 396 env11177 = env11178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 396 env11177 == env11178) = true)

theorem identity11178 : scanCanonicalize (H12AffineFastState.compose env11178 (packedSelected [1,8] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound11178 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env11179 : List Nat := [2,4,8,16,32,17,9,256,1,1024,2048,1297,8,1296,261,2,1296,2340,1025,261,1297,2080,17,3,8,17,1,1297,1297,292,1284,0,257,2048,1297,0]

theorem envBound11179 : H12AffineFastState.Bounded env11179 := by
  intro p hp
  have h : env11179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11178_11179 : H12AffineEnvironment.transform 6 9 env11178 = env11179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env11178 == env11179) = true)

theorem identity11179 : scanCanonicalize (H12AffineFastState.compose env11179 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 261) := by decide +kernel

theorem selectedBound11179 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11180 : List Nat := [2,4,8,16,32,17,9,256,1,1024,261,1297,8,1296,261,2,1296,33,1025,261,1297,293,17,3,8,17,1,1297,1297,292,1284,0,257,261,1297,0]

theorem envBound11180 : H12AffineFastState.Bounded env11180 := by
  intro p hp
  have h : env11180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11179_11180 : H12AffineEnvironment.transform 10 261 env11179 = env11180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env11179 == env11180) = true)

theorem identity11180 : scanCanonicalize (H12AffineFastState.compose env11180 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound11180 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11181 : List Nat := [2,4,2,16,32,17,3,256,1,1024,261,1297,2,1296,261,2,1296,33,1025,261,1297,293,17,3,2,17,1,1297,1297,292,1284,0,257,261,1297,0]

theorem envBound11181 : H12AffineFastState.Bounded env11181 := by
  intro p hp
  have h : env11181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11180_11181 : H12AffineEnvironment.transform 2 2 env11180 = env11181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env11180 == env11181) = true)

theorem identity11181 : scanCanonicalize (H12AffineFastState.compose env11181 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound11181 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env11182 : List Nat := [2,4,2,16,17,17,3,256,1,1024,261,1297,2,1296,261,2,1296,16,1025,261,1297,276,17,3,2,17,1,1297,1297,277,1284,0,257,261,1297,0]

theorem envBound11182 : H12AffineFastState.Bounded env11182 := by
  intro p hp
  have h : env11182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11181_11182 : H12AffineEnvironment.transform 4 17 env11181 = env11182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env11181 == env11182) = true)

theorem identity11182 : scanCanonicalize (H12AffineFastState.compose env11182 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound11182 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env11183 : List Nat := [2,4,2,16,17,17,3,21,1,1024,16,1028,2,1029,16,2,1029,16,1025,16,1028,1,17,3,2,17,1,1028,1028,0,1041,0,20,16,1028,0]

theorem envBound11183 : H12AffineFastState.Bounded env11183 := by
  intro p hp
  have h : env11183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11182_11183 : H12AffineEnvironment.transform 7 21 env11182 = env11183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env11182 == env11183) = true)

theorem identity11183 : scanCanonicalize (H12AffineFastState.compose env11183 (packedSelected [7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound11183 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env11184 : List Nat := [2,4,2,1,0,0,3,4,1,1024,1,1028,2,1029,1,2,1029,1,1025,1,1028,1,0,3,2,0,1,1028,1028,0,1024,0,5,1,1028,0]

theorem envBound11184 : H12AffineFastState.Bounded env11184 := by
  intro p hp
  have h : env11184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11183_11184 : H12AffineEnvironment.transform 3 1 env11183 = env11184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env11183 == env11184) = true)

def leafEnv11184 : List Nat := [2,4,2,1,0,0,3,4,1,1024,1,1028,2,1029,1,2,1029,1,1025,1,1028,1,0,3,1025,2,1,0,1,1028,1028,0,1024,0,5,1,5,2,1028,0,0,1028,1]

def active11184 : List Nat := [0,1,9]

def tree11184 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11184 : H12WitnessSearch.Good tree11184 := H12GlobalWitnessIndex.good

theorem leafIdentity11184 : H12AffineFastState.composeSystem env11184 rootObs = leafEnv11184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11184 rootObs == leafEnv11184) = true)

theorem terminalChecked11184 : H12PackedTerminal.terminalCheckFast leafEnv11184 active11184 tree11184 = true := by decide +kernel

def env11185 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,641,16384,32768,65536,131072,262144,1025,32768,4096,4194304,17665,16777216,33554432,17010964,21352448,17024021,131073,21105822,16876544,4294967296,257,4332967607,131073,33554441]

theorem envBound11185 : H12AffineFastState.Bounded env11185 := by
  intro p hp
  have h : env11185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11121_11185 : H12AffineEnvironment.transform 12 641 env11121 = env11185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 641 env11121 == env11185) = true)

def env11186 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,641,16384,32768,65536,4096,262144,1025,32768,4096,4194304,17665,16777216,33554432,16875796,21352448,16897045,4097,20978846,16876544,4294967296,257,4332832439,4097,33554441]

theorem envBound11186 : H12AffineFastState.Bounded env11186 := by
  intro p hp
  have h : env11186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11185_11186 : H12AffineEnvironment.transform 16 4096 env11185 = env11186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env11185 == env11186) = true)

theorem identity11186 : scanCanonicalize (H12AffineFastState.compose env11186 (packedSelected [1,3,5,8,9,10,19,22] rootPS)) = affineNative (2^(24+1) ^^^ 16896389) := by decide +kernel

theorem selectedBound11186 : packedSelected [1,3,5,8,9,10,19,22] rootPS < 2^1333 := by decide +kernel

def env11187 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,641,16384,32768,65536,4096,262144,1025,32768,4096,4194304,17665,16777216,16896389,16875796,21352448,16897045,4097,20978846,16876544,4294967296,257,4315944754,4097,16896396]

theorem envBound11187 : H12AffineFastState.Bounded env11187 := by
  intro p hp
  have h : env11187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11186_11187 : H12AffineEnvironment.transform 24 16896389 env11186 = env11187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 16896389 env11186 == env11187) = true)

def env11188 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,4096,9,16384,32768,65536,4096,262144,1025,32768,4096,4194304,17665,16777216,16896389,16875796,21352448,16897045,4097,20978846,16876544,4294967296,257,4315944378,4097,16896396]

theorem envBound11188 : H12AffineFastState.Bounded env11188 := by
  intro p hp
  have h : env11188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11187_11188 : H12AffineEnvironment.transform 8 136 env11187 = env11188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env11187 == env11188) = true)

theorem identity11188 : scanCanonicalize (H12AffineFastState.compose env11188 (packedSelected [1,5,6,8,19,24,25,26] rootPS)) = affineNative (2^(13+1) ^^^ 1297) := by decide +kernel

theorem selectedBound11188 : packedSelected [1,5,6,8,19,24,25,26] rootPS < 2^1333 := by decide +kernel

def env11189 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,4096,9,1297,32768,65536,4096,262144,1025,32768,4096,4194304,16,16777216,16880788,16875796,21337361,16879876,4097,20978846,16876544,4294967296,257,4315944378,4097,16880797]

theorem envBound11189 : H12AffineFastState.Bounded env11189 := by
  intro p hp
  have h : env11189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11188_11189 : H12AffineEnvironment.transform 13 1297 env11188 = env11189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env11188 == env11189) = true)

theorem identity11189 : scanCanonicalize (H12AffineFastState.compose env11189 (packedSelected [3,5,6,8,10,25,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 103444) := by decide +kernel

theorem selectedBound11189 : packedSelected [3,5,6,8,10,25,28,31] rootPS < 2^1333 := by decide +kernel

def env11190 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,4096,9,1297,32768,65536,4096,262144,1025,32768,4096,4194304,16,103444,128,5376,4456709,1296,4097,4294794,4116,4294967296,257,4299260334,4097,137]

theorem envBound11190 : H12AffineFastState.Bounded env11190 := by
  intro p hp
  have h : env11190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11189_11190 : H12AffineEnvironment.transform 23 103444 env11189 = env11190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 103444 env11189 == env11190) = true)

theorem identity11190 : scanCanonicalize (H12AffineFastState.compose env11190 (packedSelected [5,8,17,21] rootPS)) = affineNative (2^(14+1) ^^^ 261) := by decide +kernel

theorem selectedBound11190 : packedSelected [5,8,17,21] rootPS < 2^1333 := by decide +kernel

def env11191 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,4096,9,1297,261,65536,4096,262144,1025,261,4096,4194304,16,70929,128,5376,4456709,1296,4097,4262287,4116,4294967296,257,4299227307,4097,137]

theorem envBound11191 : H12AffineFastState.Bounded env11191 := by
  intro p hp
  have h : env11191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11190_11191 : H12AffineEnvironment.transform 14 261 env11190 = env11191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 261 env11190 == env11191) = true)

theorem identity11191 : scanCanonicalize (H12AffineFastState.compose env11191 (packedSelected [5,6,8,10,12,13] rootPS)) = affineNative (2^(31+1) ^^^ 4262277) := by decide +kernel

theorem selectedBound11191 : packedSelected [5,6,8,10,12,13] rootPS < 2^1333 := by decide +kernel

def env11192 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,4096,9,1297,261,65536,4096,262144,1025,261,4096,4194304,16,70929,128,5376,4456709,1296,4097,4262287,4116,4262277,257,2350,4097,137]

theorem envBound11192 : H12AffineFastState.Bounded env11192 := by
  intro p hp
  have h : env11192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11191_11192 : H12AffineEnvironment.transform 31 4262277 env11191 = env11192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4262277 env11191 == env11192) = true)

theorem identity11192 : scanCanonicalize (H12AffineFastState.compose env11192 (packedSelected [10,12,17] rootPS)) = affineNative (2^(17+1) ^^^ 72894) := by decide +kernel

theorem selectedBound11192 : packedSelected [10,12,17] rootPS < 2^1333 := by decide +kernel

def env11193 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,4096,9,1297,261,65536,4096,72894,1025,261,4096,4194304,16,70929,128,5376,4267451,1296,4097,4262287,4116,4262277,257,2350,4097,137]

theorem envBound11193 : H12AffineFastState.Bounded env11193 := by
  intro p hp
  have h : env11193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11192_11193 : H12AffineEnvironment.transform 17 72894 env11192 = env11193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 72894 env11192 == env11193) = true)

theorem identity11193 : scanCanonicalize (H12AffineFastState.compose env11193 (packedSelected [1,24] rootPS)) = affineNative (2^(15+1) ^^^ 139) := by decide +kernel

theorem selectedBound11193 : packedSelected [1,24] rootPS < 2^1333 := by decide +kernel

def env11194 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,4096,9,1297,261,139,4096,7221,1025,261,4096,4194304,16,5530,128,5376,4201776,1296,4097,4196612,4116,4196622,257,2350,4097,137]

theorem envBound11194 : H12AffineFastState.Bounded env11194 := by
  intro p hp
  have h : env11194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11193_11194 : H12AffineEnvironment.transform 15 139 env11193 = env11194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 139 env11193 == env11194) = true)

def env11195 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,4096,9,1297,261,139,4096,7221,1025,261,4096,5408,16,5530,128,5376,2064,1296,4097,7204,4116,7214,257,2350,4097,137]

theorem envBound11195 : H12AffineFastState.Bounded env11195 := by
  intro p hp
  have h : env11195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11194_11195 : H12AffineEnvironment.transform 21 5408 env11194 = env11195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 5408 env11194 == env11195) = true)

theorem identity11195 : scanCanonicalize (H12AffineFastState.compose env11195 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 182) := by decide +kernel

theorem selectedBound11195 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11196 : List Nat := [2,4,8,16,32,17,128,182,136,1024,2048,4096,9,1191,179,139,4096,7221,1025,179,4096,5270,16,5164,128,5302,2064,1190,4097,7204,4116,7214,183,2200,4097,137]

theorem envBound11196 : H12AffineFastState.Bounded env11196 := by
  intro p hp
  have h : env11196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11195_11196 : H12AffineEnvironment.transform 7 182 env11195 = env11196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 182 env11195 == env11196) = true)

theorem identity11196 : scanCanonicalize (H12AffineFastState.compose env11196 (packedSelected [6,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 1181) := by decide +kernel

theorem selectedBound11196 : packedSelected [6,10,12] rootPS < 2^1333 := by decide +kernel

def env11197 : List Nat := [2,4,8,16,32,17,128,182,136,1024,2048,1181,9,1191,179,139,1181,2216,1025,179,1181,11,16,177,128,43,2064,1190,1180,2233,1161,2227,183,2200,1180,137]

theorem envBound11197 : H12AffineFastState.Bounded env11197 := by
  intro p hp
  have h : env11197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11196_11197 : H12AffineEnvironment.transform 11 1181 env11196 = env11197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1181 env11196 == env11197) = true)

def env11198 : List Nat := [2,4,8,16,32,17,128,182,136,1024,0,1181,9,1191,179,139,1181,168,1025,179,1181,11,16,177,128,43,16,1190,1180,185,1161,179,183,152,1180,137]

theorem envBound11198 : H12AffineFastState.Bounded env11198 := by
  intro p hp
  have h : env11198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11197_11198 : H12AffineEnvironment.transform 10 0 env11197 = env11198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env11197 == env11198) = true)

theorem identity11198 : scanCanonicalize (H12AffineFastState.compose env11198 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound11198 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env11199 : List Nat := [2,4,8,16,32,17,57,15,49,1024,0,1060,9,1054,10,50,1060,17,1025,10,1060,11,16,8,57,43,16,1055,1061,0,1072,10,14,33,1061,48]

theorem envBound11199 : H12AffineFastState.Bounded env11199 := by
  intro p hp
  have h : env11199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11198_11199 : H12AffineEnvironment.transform 6 57 env11198 = env11199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env11198 == env11199) = true)

theorem identity11199 : scanCanonicalize (H12AffineFastState.compose env11199 (packedSelected [0,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound11199 : packedSelected [0,2,5] rootPS < 2^1333 := by decide +kernel

def env11200 : List Nat := [2,4,8,16,0,17,25,15,17,1024,0,1028,9,1054,10,18,1028,17,1025,10,1028,11,16,8,25,11,16,1055,1029,0,1040,10,14,1,1029,16]

theorem envBound11200 : H12AffineFastState.Bounded env11200 := by
  intro p hp
  have h : env11200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11199_11200 : H12AffineEnvironment.transform 4 0 env11199 = env11200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env11199 == env11200) = true)

theorem identity11200 : scanCanonicalize (H12AffineFastState.compose env11200 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound11200 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11201 : List Nat := [2,4,8,1,0,0,8,15,0,1024,0,1028,9,1039,10,3,1028,0,1025,10,1028,11,1,8,8,11,1,1038,1029,0,1025,10,14,1,1029,1]

theorem envBound11201 : H12AffineFastState.Bounded env11201 := by
  intro p hp
  have h : env11201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11200_11201 : H12AffineEnvironment.transform 3 1 env11200 = env11201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env11200 == env11201) = true)

def env11202 : List Nat := [2,4,8,16,32,17,128,182,136,1024,1,1181,9,1191,179,139,1181,169,1025,179,1181,11,16,177,128,43,17,1190,1180,184,1161,178,183,153,1180,137]

theorem envBound11202 : H12AffineFastState.Bounded env11202 := by
  intro p hp
  have h : env11202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11197_11202 : H12AffineEnvironment.transform 10 1 env11197 = env11202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env11197 == env11202) = true)

theorem identity11202 : scanCanonicalize (H12AffineFastState.compose env11202 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound11202 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env11203 : List Nat := [2,4,8,16,32,17,3,53,11,1024,1,1054,9,1060,48,8,1054,42,1025,48,1054,11,16,50,3,43,17,1061,1055,59,1034,49,52,26,1055,10]

theorem envBound11203 : H12AffineFastState.Bounded env11203 := by
  intro p hp
  have h : env11203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11202_11203 : H12AffineEnvironment.transform 6 3 env11202 = env11203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env11202 == env11203) = true)

theorem identity11203 : scanCanonicalize (H12AffineFastState.compose env11203 (packedSelected [2,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound11203 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env11204 : List Nat := [2,4,8,16,0,17,3,21,11,1024,1,1054,9,1028,16,8,1054,10,1025,16,1054,11,16,18,3,11,17,1029,1055,27,1034,17,20,26,1055,10]

theorem envBound11204 : H12AffineFastState.Bounded env11204 := by
  intro p hp
  have h : env11204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11203_11204 : H12AffineEnvironment.transform 4 0 env11203 = env11204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env11203 == env11204) = true)

theorem identity11204 : scanCanonicalize (H12AffineFastState.compose env11204 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound11204 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11205 : List Nat := [2,4,2,16,0,17,3,21,1,1024,1,1044,3,1028,16,2,1044,0,1025,16,1044,1,16,18,3,1,17,1029,1045,17,1024,17,20,16,1045,0]

theorem envBound11205 : H12AffineFastState.Bounded env11205 := by
  intro p hp
  have h : env11205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11204_11205 : H12AffineEnvironment.transform 2 2 env11204 = env11205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env11204 == env11205) = true)

theorem identity11205 : scanCanonicalize (H12AffineFastState.compose env11205 (packedSelected [10] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound11205 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env11206 : List Nat := [2,4,2,1,0,0,3,4,1,1024,1,1029,3,1028,1,2,1029,0,1025,1,1029,1,1,3,3,1,0,1029,1028,0,1024,0,5,1,1028,0]

theorem envBound11206 : H12AffineFastState.Bounded env11206 := by
  intro p hp
  have h : env11206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11205_11206 : H12AffineEnvironment.transform 3 1 env11205 = env11206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env11205 == env11206) = true)

def leafEnv11206 : List Nat := [2,4,2,1,0,0,3,4,1,1024,1,1029,3,1028,1,2,1029,0,1025,1,1029,1,1,3,1025,3,1,1,0,1029,1028,0,1024,0,5,1,5,2,1028,0,0,1028,1]

def active11206 : List Nat := [0,1,9]

def tree11206 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood11206 : H12WitnessSearch.Good tree11206 := H12GlobalWitnessIndex.good

theorem leafIdentity11206 : H12AffineFastState.composeSystem env11206 rootObs = leafEnv11206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env11206 rootObs == leafEnv11206) = true)

theorem terminalChecked11206 : H12PackedTerminal.terminalCheckFast leafEnv11206 active11206 tree11206 = true := by decide +kernel

def env11207 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,4096,9,1297,261,139,4096,7221,1025,261,4096,5409,16,5530,128,5376,2065,1296,4097,7205,4116,7215,257,2350,4097,137]

theorem envBound11207 : H12AffineFastState.Bounded env11207 := by
  intro p hp
  have h : env11207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11194_11207 : H12AffineEnvironment.transform 21 5409 env11194 = env11207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 5409 env11194 == env11207) = true)

theorem identity11207 : scanCanonicalize (H12AffineFastState.compose env11207 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 1191) := by decide +kernel

theorem selectedBound11207 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env11208 : List Nat := [2,4,8,16,32,17,128,256,136,1024,2048,1191,9,1297,261,139,1191,2194,1025,261,1191,390,16,317,128,423,2065,1296,1190,2178,1203,2184,257,2350,1190,137]

theorem envBound11208 : H12AffineFastState.Bounded env11208 := by
  intro p hp
  have h : env11208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11207_11208 : H12AffineEnvironment.transform 11 1191 env11207 = env11208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1191 env11207 == env11208) = true)

theorem identity11208 : scanCanonicalize (H12AffineFastState.compose env11208 (packedSelected [6,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound11208 : packedSelected [6,10,12] rootPS < 2^1333 := by decide +kernel

def env11209 : List Nat := [2,4,8,16,32,17,128,141,136,1024,2048,1191,9,1180,136,139,1191,2194,1025,136,1191,11,16,176,128,42,2065,1181,1190,2178,1203,2184,140,2211,1190,137]

theorem envBound11209 : H12AffineFastState.Bounded env11209 := by
  intro p hp
  have h : env11209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11208_11209 : H12AffineEnvironment.transform 7 141 env11208 = env11209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env11208 == env11209) = true)

def env11210 : List Nat := [2,4,8,16,32,17,128,141,136,1024,0,1191,9,1180,136,139,1191,146,1025,136,1191,11,16,176,128,42,17,1181,1190,130,1203,136,140,163,1190,137]

theorem envBound11210 : H12AffineFastState.Bounded env11210 := by
  intro p hp
  have h : env11210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11209_11210 : H12AffineEnvironment.transform 10 0 env11209 = env11210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env11209 == env11210) = true)

theorem identity11210 : scanCanonicalize (H12AffineFastState.compose env11210 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound11210 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env11211 : List Nat := [2,4,8,16,32,17,2,15,10,1024,0,1061,9,1054,10,9,1061,16,1025,10,1061,11,16,50,2,42,17,1055,1060,0,1073,10,14,33,1060,11]

theorem envBound11211 : H12AffineFastState.Bounded env11211 := by
  intro p hp
  have h : env11211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11210_11211 : H12AffineEnvironment.transform 6 2 env11210 = env11211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env11210 == env11211) = true)

theorem identity11211 : scanCanonicalize (H12AffineFastState.compose env11211 (packedSelected [0,2,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound11211 : packedSelected [0,2,5] rootPS < 2^1333 := by decide +kernel

def env11212 : List Nat := [2,4,8,11,32,10,2,15,10,1024,0,1061,9,1029,10,9,1061,11,1025,10,1061,11,11,41,2,42,10,1028,1060,0,1066,10,14,33,1060,11]

theorem envBound11212 : H12AffineFastState.Bounded env11212 := by
  intro p hp
  have h : env11212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11211_11212 : H12AffineEnvironment.transform 3 11 env11211 = env11212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env11211 == env11212) = true)

theorem identity11212 : scanCanonicalize (H12AffineFastState.compose env11212 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound11212 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11213 : List Nat := [2,4,3,0,32,1,2,4,1,1024,0,1061,2,1029,1,2,1061,0,1025,1,1061,0,0,34,2,33,1,1028,1060,0,1057,1,5,33,1060,0]

theorem envBound11213 : H12AffineFastState.Bounded env11213 := by
  intro p hp
  have h : env11213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11212_11213 : H12AffineEnvironment.transform 2 3 env11212 = env11213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env11212 == env11213) = true)

def env11214 : List Nat := [2,4,8,16,32,17,128,141,136,1024,1,1191,9,1180,136,139,1191,147,1025,136,1191,11,16,176,128,42,16,1181,1190,131,1203,137,140,162,1190,137]

theorem envBound11214 : H12AffineFastState.Bounded env11214 := by
  intro p hp
  have h : env11214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11209_11214 : H12AffineEnvironment.transform 10 1 env11209 = env11214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env11209 == env11214) = true)

theorem identity11214 : scanCanonicalize (H12AffineFastState.compose env11214 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound11214 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env11215 : List Nat := [2,4,8,16,32,17,57,52,49,1024,1,1054,9,1061,49,50,1054,42,1025,49,1054,11,16,9,57,42,16,1060,1055,58,1034,48,53,27,1055,48]

theorem envBound11215 : H12AffineFastState.Bounded env11215 := by
  intro p hp
  have h : env11215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11214_11215 : H12AffineEnvironment.transform 6 57 env11214 = env11215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env11214 == env11215) = true)

theorem identity11215 : scanCanonicalize (H12AffineFastState.compose env11215 (packedSelected [2,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound11215 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env11216 : List Nat := [2,4,8,11,32,10,34,47,42,1024,1,1029,9,1061,42,41,1029,42,1025,42,1029,11,11,9,34,42,11,1060,1028,33,1034,43,46,0,1028,43]

theorem envBound11216 : H12AffineFastState.Bounded env11216 := by
  intro p hp
  have h : env11216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11215_11216 : H12AffineEnvironment.transform 3 11 env11215 = env11216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env11215 == env11216) = true)

theorem identity11216 : scanCanonicalize (H12AffineFastState.compose env11216 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound11216 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env11217 : List Nat := [2,4,2,1,32,0,34,37,32,1024,1,1029,3,1061,32,35,1029,32,1025,32,1029,1,1,3,34,32,1,1060,1028,33,1024,33,36,0,1028,33]

theorem envBound11217 : H12AffineFastState.Bounded env11217 := by
  intro p hp
  have h : env11217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11216_11217 : H12AffineEnvironment.transform 2 2 env11216 = env11217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env11216 == env11217) = true)

theorem identity11217 : scanCanonicalize (H12AffineFastState.compose env11217 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound11217 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env11218 : List Nat := [2,4,2,1,0,0,2,5,0,1024,1,1029,3,1029,0,3,1029,0,1025,0,1029,1,1,3,2,0,1,1028,1028,1,1024,1,4,0,1028,1]

theorem envBound11218 : H12AffineFastState.Bounded env11218 := by
  intro p hp
  have h : env11218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11217_11218 : H12AffineEnvironment.transform 4 0 env11217 = env11218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env11217 == env11218) = true)

def env11219 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,4096,8,16384,32768,65536,4096,262144,1025,32768,4096,4194304,17665,16777216,16896389,16875796,21352448,16897045,4097,20978846,16876544,4294967296,257,4315944379,4097,16896396]

theorem envBound11219 : H12AffineFastState.Bounded env11219 := by
  intro p hp
  have h : env11219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11187_11219 : H12AffineEnvironment.transform 8 137 env11187 = env11219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env11187 == env11219) = true)

theorem identity11219 : scanCanonicalize (H12AffineFastState.compose env11219 (packedSelected [1,5,6,8,19,24,25,26] rootPS)) = affineNative (2^(23+1) ^^^ 103444) := by decide +kernel

theorem selectedBound11219 : packedSelected [1,5,6,8,19,24,25,26] rootPS < 2^1333 := by decide +kernel

def env11220 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,4096,8,16384,32768,65536,4096,262144,1025,32768,4096,4194304,17665,103444,17809,5376,4473876,16385,4097,4294794,4116,4294967296,257,4299260335,4097,17816]

theorem envBound11220 : H12AffineFastState.Bounded env11220 := by
  intro p hp
  have h : env11220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11219_11220 : H12AffineEnvironment.transform 23 103444 env11219 = env11220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 103444 env11219 == env11220) = true)

theorem identity11220 : scanCanonicalize (H12AffineFastState.compose env11220 (packedSelected [0,1,3,4,7,9,10,16,17,19,20,21] rootPS)) = affineNative (2^(13+1) ^^^ 4096) := by decide +kernel

theorem selectedBound11220 : packedSelected [0,1,3,4,7,9,10,16,17,19,20,21] rootPS < 2^1333 := by decide +kernel

def env11221 : List Nat := [2,4,8,16,32,17,128,256,137,1024,2048,4096,8,4096,32768,65536,4096,262144,1025,32768,4096,4194304,5377,103444,5521,5376,4461588,4097,4097,4294794,4116,4294967296,257,4299260335,4097,5528]

theorem envBound11221 : H12AffineFastState.Bounded env11221 := by
  intro p hp
  have h : env11221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11220_11221 : H12AffineEnvironment.transform 13 4096 env11220 = env11221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env11220 == env11221) = true)

theorem identity11221 : scanCanonicalize (H12AffineFastState.compose env11221 (packedSelected [13,17] rootPS)) = affineNative (2^(15+1) ^^^ 33167) := by decide +kernel

theorem selectedBound11221 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

end H12CloudChart2