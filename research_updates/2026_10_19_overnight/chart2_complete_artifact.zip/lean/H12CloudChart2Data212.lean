import H12CloudChart2Data211

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound53403 : H12AffineFastState.Bounded env53403 := by
  intro p hp
  have h : env53403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53381_53403 : H12AffineEnvironment.transform 3 1 env53381 = env53403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env53381 == env53403) = true)

theorem identity53403 : scanCanonicalize (H12AffineFastState.compose env53403 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 1225) := by decide +kernel

theorem selectedBound53403 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env53404 : List Nat := [2,4,8,1,32,64,128,256,324,1024,2048,1,8192,1280,9229,1225,8358,1097,321,9228,1,460,9703,1224,9673,8422,303,8423,1281,10626,8205,1280,256,1518,1344,1028]

theorem envBound53404 : H12AffineFastState.Bounded env53404 := by
  intro p hp
  have h : env53404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53403_53404 : H12AffineEnvironment.transform 15 1225 env53403 = env53404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1225 env53403 == env53404) = true)

def env53405 : List Nat := [2,4,8,1,32,64,128,256,324,1024,2048,1,1504,1280,493,1225,1350,1097,321,492,1,460,7,1224,41,1286,303,1287,1281,3170,1517,1280,256,1518,1344,1028]

theorem envBound53405 : H12AffineFastState.Bounded env53405 := by
  intro p hp
  have h : env53405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53404_53405 : H12AffineEnvironment.transform 12 1504 env53404 = env53405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1504 env53404 == env53405) = true)

theorem identity53405 : scanCanonicalize (H12AffineFastState.compose env53405 (packedSelected [3,7,10,13,16,17,18,19,23,24,27] rootPS)) = affineNative (2^(9+1) ^^^ 234) := by decide +kernel

theorem selectedBound53405 : packedSelected [3,7,10,13,16,17,18,19,23,24,27] rootPS < 2^1333 := by decide +kernel

def env53406 : List Nat := [2,4,8,1,32,64,128,256,324,234,2048,1,266,490,493,35,428,163,321,492,1,460,7,34,41,492,303,493,491,2184,263,490,256,260,426,238]

theorem envBound53406 : H12AffineFastState.Bounded env53406 := by
  intro p hp
  have h : env53406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53405_53406 : H12AffineEnvironment.transform 9 234 env53405 = env53406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 234 env53405 == env53406) = true)

theorem identity53406 : scanCanonicalize (H12AffineFastState.compose env53406 (packedSelected [0,1,2,4,5,7,9,10,11,12,13,15,18,19,20,23] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound53406 : packedSelected [0,1,2,4,5,7,9,10,11,12,13,15,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env53407 : List Nat := [2,4,8,1,32,64,15,256,324,101,2048,1,266,357,354,35,291,44,321,355,1,323,7,34,41,355,303,354,356,2055,263,357,256,260,293,97]

theorem envBound53407 : H12AffineFastState.Bounded env53407 := by
  intro p hp
  have h : env53407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53406_53407 : H12AffineEnvironment.transform 6 15 env53406 = env53407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env53406 == env53407) = true)

theorem identity53407 : scanCanonicalize (H12AffineFastState.compose env53407 (packedSelected [1,2,8,13,16,17,18] rootPS)) = affineNative (2^(7+1) ^^^ 111) := by decide +kernel

theorem selectedBound53407 : packedSelected [1,2,8,13,16,17,18] rootPS < 2^1333 := by decide +kernel

def env53408 : List Nat := [2,4,8,1,32,64,15,111,43,101,2048,1,101,10,13,35,76,44,46,12,1,44,7,34,41,12,64,13,11,2055,104,10,111,107,74,97]

theorem envBound53408 : H12AffineFastState.Bounded env53408 := by
  intro p hp
  have h : env53408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53407_53408 : H12AffineEnvironment.transform 7 111 env53407 = env53408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 111 env53407 == env53408) = true)

theorem identity53408 : scanCanonicalize (H12AffineFastState.compose env53408 (packedSelected [0,3,7,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 39) := by decide +kernel

theorem selectedBound53408 : packedSelected [0,3,7,11,12] rootPS < 2^1333 := by decide +kernel

def env53409 : List Nat := [2,4,8,1,32,39,15,8,43,2,2048,1,2,10,13,35,43,44,46,12,1,44,7,34,41,12,39,13,11,2055,15,10,8,12,45,6]

theorem envBound53409 : H12AffineFastState.Bounded env53409 := by
  intro p hp
  have h : env53409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53408_53409 : H12AffineEnvironment.transform 5 39 env53408 = env53409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 39 env53408 == env53409) = true)

theorem identity53409 : scanCanonicalize (H12AffineFastState.compose env53409 (packedSelected [0,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 39) := by decide +kernel

theorem selectedBound53409 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env53410 : List Nat := [2,4,8,1,32,39,15,8,43,2,39,1,2,10,13,35,43,44,46,12,1,44,7,34,41,12,39,13,11,32,15,10,8,12,45,6]

theorem envBound53410 : H12AffineFastState.Bounded env53410 := by
  intro p hp
  have h : env53410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53409_53410 : H12AffineEnvironment.transform 10 39 env53409 = env53410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 39 env53409 == env53410) = true)

theorem identity53410 : scanCanonicalize (H12AffineFastState.compose env53410 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound53410 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env53411 : List Nat := [2,4,8,1,6,1,15,8,13,2,1,1,2,10,13,5,13,10,8,12,1,10,7,4,15,12,1,13,11,6,15,10,8,12,11,6]

theorem envBound53411 : H12AffineFastState.Bounded env53411 := by
  intro p hp
  have h : env53411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53410_53411 : H12AffineEnvironment.transform 4 6 env53410 = env53411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env53410 == env53411) = true)

theorem identity53411 : scanCanonicalize (H12AffineFastState.compose env53411 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound53411 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53412 : List Nat := [2,4,5,1,6,1,2,5,0,2,1,1,2,7,0,5,0,7,5,1,1,7,7,4,2,1,1,0,6,6,2,7,5,1,6,6]

theorem envBound53412 : H12AffineFastState.Bounded env53412 := by
  intro p hp
  have h : env53412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53411_53412 : H12AffineEnvironment.transform 2 5 env53411 = env53412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env53411 == env53412) = true)

theorem identity53412 : scanCanonicalize (H12AffineFastState.compose env53412 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound53412 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53413 : List Nat := [2,3,2,1,1,1,2,2,0,2,1,1,2,0,0,2,0,0,2,1,1,0,0,3,2,1,1,0,1,1,2,0,2,1,1,1]

theorem envBound53413 : H12AffineFastState.Bounded env53413 := by
  intro p hp
  have h : env53413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53412_53413 : H12AffineEnvironment.transform 1 3 env53412 = env53413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env53412 == env53413) = true)

theorem identity53413 : scanCanonicalize (H12AffineFastState.compose env53413 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound53413 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53414 : List Nat := [0,1,0,1,1,1,0,0,0,0,1,1,0,0,0,0,0,0,0,1,1,0,0,1,0,1,1,0,1,1,0,0,0,1,1,1]

theorem envBound53414 : H12AffineFastState.Bounded env53414 := by
  intro p hp
  have h : env53414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53413_53414 : H12AffineEnvironment.transform 0 0 env53413 = env53414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env53413 == env53414) = true)

def env53415 : List Nat := [2,4,8,1,32,64,128,256,324,1024,2048,1,1505,1280,492,1225,1351,1097,321,493,1,460,6,1224,40,1287,303,1286,1281,3171,1516,1280,256,1518,1344,1028]

theorem envBound53415 : H12AffineFastState.Bounded env53415 := by
  intro p hp
  have h : env53415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53404_53415 : H12AffineEnvironment.transform 12 1505 env53404 = env53415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1505 env53404 == env53415) = true)

theorem identity53415 : scanCanonicalize (H12AffineFastState.compose env53415 (packedSelected [3,7,10,13,16,17,18,19,23,24,27] rootPS)) = affineNative (2^(9+1) ^^^ 237) := by decide +kernel

theorem selectedBound53415 : packedSelected [3,7,10,13,16,17,18,19,23,24,27] rootPS < 2^1333 := by decide +kernel

def env53416 : List Nat := [2,4,8,1,32,64,128,256,324,237,2048,1,268,493,492,36,426,164,321,493,1,460,6,37,40,490,303,491,492,2190,257,493,256,259,429,233]

theorem envBound53416 : H12AffineFastState.Bounded env53416 := by
  intro p hp
  have h : env53416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53415_53416 : H12AffineEnvironment.transform 9 237 env53415 = env53416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 237 env53415 == env53416) = true)

theorem identity53416 : scanCanonicalize (H12AffineFastState.compose env53416 (packedSelected [1,2,3,4,9,11,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(7+1) ^^^ 99) := by decide +kernel

theorem selectedBound53416 : packedSelected [1,2,3,4,9,11,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env53417 : List Nat := [2,4,8,1,32,64,128,99,39,237,2048,1,111,142,143,36,201,164,34,142,1,175,6,37,40,137,76,136,143,2190,98,142,99,96,206,233]

theorem envBound53417 : H12AffineFastState.Bounded env53417 := by
  intro p hp
  have h : env53417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53416_53417 : H12AffineEnvironment.transform 7 99 env53416 = env53417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 99 env53416 == env53417) = true)

theorem identity53417 : scanCanonicalize (H12AffineFastState.compose env53417 (packedSelected [0,1,4,7,9,11,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 226) := by decide +kernel

theorem selectedBound53417 : packedSelected [0,1,4,7,9,11,13,15] rootPS < 2^1333 := by decide +kernel

def env53418 : List Nat := [2,4,8,1,32,64,128,99,39,237,226,1,111,142,143,36,201,164,34,142,1,175,6,37,40,137,76,136,143,108,98,142,99,96,206,233]

theorem envBound53418 : H12AffineFastState.Bounded env53418 := by
  intro p hp
  have h : env53418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53417_53418 : H12AffineEnvironment.transform 10 226 env53417 = env53418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 226 env53417 == env53418) = true)

theorem identity53418 : scanCanonicalize (H12AffineFastState.compose env53418 (packedSelected [0,1,2,5,7,8,10,12] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound53418 : packedSelected [0,1,2,5,7,8,10,12] rootPS < 2^1333 := by decide +kernel

def env53419 : List Nat := [2,4,8,1,32,64,40,99,39,69,74,1,111,38,39,36,97,12,34,38,1,7,6,37,40,33,76,32,39,108,98,38,99,96,102,65]

theorem envBound53419 : H12AffineFastState.Bounded env53419 := by
  intro p hp
  have h : env53419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53418_53419 : H12AffineEnvironment.transform 6 40 env53418 = env53419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env53418 == env53419) = true)

theorem identity53419 : scanCanonicalize (H12AffineFastState.compose env53419 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound53419 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env53420 : List Nat := [2,4,8,1,11,64,3,72,12,69,74,1,68,13,12,15,74,12,9,13,1,7,6,14,3,10,76,11,12,71,73,13,72,75,77,65]

theorem envBound53420 : H12AffineFastState.Bounded env53420 := by
  intro p hp
  have h : env53420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53419_53420 : H12AffineEnvironment.transform 4 11 env53419 = env53420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env53419 == env53420) = true)

theorem identity53420 : scanCanonicalize (H12AffineFastState.compose env53420 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound53420 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env53421 : List Nat := [2,3,8,1,11,64,3,72,11,66,74,1,67,10,11,8,74,11,9,10,1,0,1,9,3,10,75,11,11,64,73,10,72,75,74,65]

theorem envBound53421 : H12AffineFastState.Bounded env53421 := by
  intro p hp
  have h : env53421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53420_53421 : H12AffineEnvironment.transform 1 3 env53420 = env53421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env53420 == env53421) = true)

theorem identity53421 : scanCanonicalize (H12AffineFastState.compose env53421 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound53421 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53422 : List Nat := [2,3,8,1,11,1,3,9,11,3,11,1,2,10,11,8,11,11,9,10,1,0,1,9,3,10,10,11,11,1,8,10,9,10,11,0]

theorem envBound53422 : H12AffineFastState.Bounded env53422 := by
  intro p hp
  have h : env53422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53421_53422 : H12AffineEnvironment.transform 5 1 env53421 = env53422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env53421 == env53422) = true)

theorem identity53422 : scanCanonicalize (H12AffineFastState.compose env53422 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound53422 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env53423 : List Nat := [2,3,3,1,0,1,3,2,0,3,0,1,2,1,0,3,0,0,2,1,1,0,1,2,3,1,1,0,0,1,3,1,2,1,0,0]

theorem envBound53423 : H12AffineFastState.Bounded env53423 := by
  intro p hp
  have h : env53423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53422_53423 : H12AffineEnvironment.transform 2 3 env53422 = env53423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env53422 == env53423) = true)

def env53424 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,13341,65536,74863,65665,4416,13340,4096,477,74047,69649,13768,78894,4414,74815,1296,81226,8205,1280,256,65831,1344,5953]

theorem envBound53424 : H12AffineFastState.Bounded env53424 := by
  intro p hp
  have h : env53424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53347_53424 : H12AffineEnvironment.transform 17 65665 env53347 = env53424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env53347 == env53424) = true)

theorem identity53424 : scanCanonicalize (H12AffineFastState.compose env53424 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound53424 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env53425 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,80,12636,65536,74030,65665,4416,12637,4096,477,74047,69649,12425,78191,4414,74110,81,79883,8205,65,256,65831,1,4608]

theorem envBound53425 : H12AffineFastState.Bounded env53425 := by
  intro p hp
  have h : env53425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53424_53425 : H12AffineEnvironment.transform 9 321 env53424 = env53425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env53424 == env53425) = true)

def env53426 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,4096,8192,80,12636,65536,74030,65665,4416,12637,4096,477,74047,69649,12425,78191,4414,74110,81,79883,8205,65,256,65831,1,4436]

theorem envBound53426 : H12AffineFastState.Bounded env53426 := by
  intro p hp
  have h : env53426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53425_53426 : H12AffineEnvironment.transform 8 340 env53425 = env53426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 340 env53425 == env53426) = true)

def env53427 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,16,8192,80,8524,65536,74030,65665,336,8525,16,477,74047,65537,8345,74111,302,74110,81,75803,8205,65,256,65831,1,324]

theorem envBound53427 : H12AffineFastState.Bounded env53427 := by
  intro p hp
  have h : env53427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53426_53427 : H12AffineEnvironment.transform 11 16 env53426 = env53427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env53426 == env53427) = true)

theorem identity53427 : scanCanonicalize (H12AffineFastState.compose env53427 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 167) := by decide +kernel

theorem selectedBound53427 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env53428 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,16,167,80,491,65536,65929,65665,336,490,16,477,65944,65537,62,66008,302,66009,81,67772,170,65,256,65831,1,324]

theorem envBound53428 : H12AffineFastState.Bounded env53428 := by
  intro p hp
  have h : env53428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53427_53428 : H12AffineEnvironment.transform 12 167 env53427 = env53428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 167 env53427 == env53428) = true)

def env53429 : List Nat := [2,4,8,0,32,64,128,256,324,321,2048,0,167,64,491,65536,65929,65665,320,490,0,461,65928,65537,46,65992,302,65993,65,67756,170,65,256,65831,1,324]

theorem envBound53429 : H12AffineFastState.Bounded env53429 := by
  intro p hp
  have h : env53429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53428_53429 : H12AffineEnvironment.transform 3 0 env53428 = env53429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env53428 == env53429) = true)

theorem identity53429 : scanCanonicalize (H12AffineFastState.compose env53429 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 234) := by decide +kernel

theorem selectedBound53429 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env53430 : List Nat := [2,4,8,0,32,64,128,234,174,171,2048,0,167,64,1,65536,65635,65665,170,0,0,39,65634,65537,46,65570,196,65571,65,67756,170,65,234,65741,1,174]

theorem envBound53430 : H12AffineFastState.Bounded env53430 := by
  intro p hp
  have h : env53430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53429_53430 : H12AffineEnvironment.transform 7 234 env53429 = env53430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 234 env53429 == env53430) = true)

theorem identity53430 : scanCanonicalize (H12AffineFastState.compose env53430 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound53430 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env53431 : List Nat := [2,4,8,0,32,64,128,234,174,171,2048,0,167,64,1,35,64,162,170,0,0,39,65,34,46,1,196,0,65,2191,170,65,234,238,1,174]

theorem envBound53431 : H12AffineFastState.Bounded env53431 := by
  intro p hp
  have h : env53431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53430_53431 : H12AffineEnvironment.transform 15 35 env53430 = env53431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env53430 == env53431) = true)

theorem identity53431 : scanCanonicalize (H12AffineFastState.compose env53431 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 207) := by decide +kernel

theorem selectedBound53431 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env53432 : List Nat := [2,4,8,0,32,64,128,234,174,171,207,0,167,64,1,35,64,162,170,0,0,39,65,34,46,1,196,0,65,64,170,65,234,238,1,174]

theorem envBound53432 : H12AffineFastState.Bounded env53432 := by
  intro p hp
  have h : env53432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53431_53432 : H12AffineEnvironment.transform 10 207 env53431 = env53432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 207 env53431 == env53432) = true)

theorem identity53432 : scanCanonicalize (H12AffineFastState.compose env53432 (packedSelected [0,1,2,8,10,12] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound53432 : packedSelected [0,1,2,8,10,12] rootPS < 2^1333 := by decide +kernel

def env53433 : List Nat := [2,4,8,0,32,1,128,171,174,171,142,0,167,1,1,35,1,162,170,0,0,39,0,34,46,1,133,0,0,1,170,0,171,175,1,174]

theorem envBound53433 : H12AffineFastState.Bounded env53433 := by
  intro p hp
  have h : env53433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53432_53433 : H12AffineEnvironment.transform 5 1 env53432 = env53433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env53432 == env53433) = true)

theorem identity53433 : scanCanonicalize (H12AffineFastState.compose env53433 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound53433 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53434 : List Nat := [2,4,2,0,32,1,128,161,164,161,132,0,167,1,1,35,1,162,160,0,0,39,0,34,36,1,133,0,0,1,160,0,161,165,1,164]

theorem envBound53434 : H12AffineFastState.Bounded env53434 := by
  intro p hp
  have h : env53434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53433_53434 : H12AffineEnvironment.transform 2 2 env53433 = env53434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env53433 == env53434) = true)

theorem identity53434 : scanCanonicalize (H12AffineFastState.compose env53434 (packedSelected [2,4] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound53434 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env53435 : List Nat := [2,2,2,0,32,1,128,161,162,161,130,0,161,1,1,35,1,162,160,0,0,33,0,34,34,1,131,0,0,1,160,0,161,163,1,162]

theorem envBound53435 : H12AffineFastState.Bounded env53435 := by
  intro p hp
  have h : env53435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53434_53435 : H12AffineEnvironment.transform 1 2 env53434 = env53435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env53434 == env53435) = true)

theorem identity53435 : scanCanonicalize (H12AffineFastState.compose env53435 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound53435 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53436 : List Nat := [2,2,2,0,32,1,35,2,1,2,33,0,2,1,1,35,1,1,3,0,0,33,0,34,34,1,32,0,0,1,3,0,2,0,1,1]

theorem envBound53436 : H12AffineFastState.Bounded env53436 := by
  intro p hp
  have h : env53436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53435_53436 : H12AffineEnvironment.transform 6 35 env53435 = env53436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env53435 == env53436) = true)

theorem identity53436 : scanCanonicalize (H12AffineFastState.compose env53436 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound53436 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53437 : List Nat := [2,2,2,0,1,1,2,2,1,2,0,0,2,1,1,2,1,1,3,0,0,0,0,3,3,1,1,0,0,1,3,0,2,0,1,1]

theorem envBound53437 : H12AffineFastState.Bounded env53437 := by
  intro p hp
  have h : env53437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53436_53437 : H12AffineEnvironment.transform 4 1 env53436 = env53437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env53436 == env53437) = true)

def env53438 : List Nat := [2,4,8,1,32,64,128,256,325,321,2048,1,167,65,491,65536,65929,65665,321,490,1,460,65929,65537,47,65993,302,65992,64,67757,170,65,256,65831,1,324]

theorem envBound53438 : H12AffineFastState.Bounded env53438 := by
  intro p hp
  have h : env53438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53428_53438 : H12AffineEnvironment.transform 3 1 env53428 = env53438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env53428 == env53438) = true)

theorem identity53438 : scanCanonicalize (H12AffineFastState.compose env53438 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound53438 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env53439 : List Nat := [2,4,8,1,32,64,128,256,325,321,2048,1,167,65,491,34,427,163,321,490,1,460,427,35,47,491,302,490,64,2191,170,65,256,261,1,324]

theorem envBound53439 : H12AffineFastState.Bounded env53439 := by
  intro p hp
  have h : env53439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53438_53439 : H12AffineEnvironment.transform 15 34 env53438 = env53439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env53438 == env53439) = true)

theorem identity53439 : scanCanonicalize (H12AffineFastState.compose env53439 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound53439 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env53440 : List Nat := [2,4,8,1,32,64,128,5,64,68,2048,1,167,65,238,34,174,163,68,239,1,201,174,35,47,238,43,239,64,2191,170,65,5,0,1,65]

theorem envBound53440 : H12AffineFastState.Bounded env53440 := by
  intro p hp
  have h : env53440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53439_53440 : H12AffineEnvironment.transform 7 5 env53439 = env53440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env53439 == env53440) = true)

theorem identity53440 : scanCanonicalize (H12AffineFastState.compose env53440 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 110) := by decide +kernel

theorem selectedBound53440 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env53441 : List Nat := [2,4,8,1,32,64,110,5,64,68,2048,1,73,65,0,34,64,77,68,1,1,39,64,35,47,0,43,1,64,2145,68,65,5,0,1,65]

theorem envBound53441 : H12AffineFastState.Bounded env53441 := by
  intro p hp
  have h : env53441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53440_53441 : H12AffineEnvironment.transform 6 110 env53440 = env53441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 110 env53440 == env53441) = true)

theorem identity53441 : scanCanonicalize (H12AffineFastState.compose env53441 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound53441 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env53442 : List Nat := [2,2,8,1,32,64,104,3,64,66,2048,1,73,65,0,34,64,75,66,1,1,33,64,35,41,0,43,1,64,2145,66,65,3,0,1,65]

theorem envBound53442 : H12AffineFastState.Bounded env53442 := by
  intro p hp
  have h : env53442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53441_53442 : H12AffineEnvironment.transform 1 2 env53441 = env53442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env53441 == env53442) = true)

theorem identity53442 : scanCanonicalize (H12AffineFastState.compose env53442 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 106) := by decide +kernel

theorem selectedBound53442 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env53443 : List Nat := [2,2,8,1,32,64,104,3,64,66,106,1,73,65,0,34,64,75,66,1,1,33,64,35,41,0,43,1,64,11,66,65,3,0,1,65]

theorem envBound53443 : H12AffineFastState.Bounded env53443 := by
  intro p hp
  have h : env53443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53442_53443 : H12AffineEnvironment.transform 10 106 env53442 = env53443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 106 env53442 == env53443) = true)

theorem identity53443 : scanCanonicalize (H12AffineFastState.compose env53443 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 43) := by decide +kernel

theorem selectedBound53443 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53444 : List Nat := [2,2,8,1,32,43,3,3,43,41,1,1,34,42,0,34,43,32,41,1,1,33,43,35,41,0,43,1,43,11,41,42,3,0,1,42]

theorem envBound53444 : H12AffineFastState.Bounded env53444 := by
  intro p hp
  have h : env53444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53443_53444 : H12AffineEnvironment.transform 5 43 env53443 = env53444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 43 env53443 == env53444) = true)

theorem identity53444 : scanCanonicalize (H12AffineFastState.compose env53444 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound53444 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53445 : List Nat := [2,2,8,1,3,8,3,3,8,10,1,1,1,9,0,1,8,3,10,1,1,2,8,0,10,0,8,1,8,11,10,9,3,0,1,9]

theorem envBound53445 : H12AffineFastState.Bounded env53445 := by
  intro p hp
  have h : env53445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53444_53445 : H12AffineEnvironment.transform 4 3 env53444 = env53445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env53444 == env53445) = true)

theorem identity53445 : scanCanonicalize (H12AffineFastState.compose env53445 (packedSelected [2,4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound53445 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env53446 : List Nat := [1,1,8,1,0,8,0,0,8,9,1,1,1,9,0,1,8,0,9,1,1,1,8,0,9,0,8,1,8,8,9,9,0,0,1,9]

theorem envBound53446 : H12AffineFastState.Bounded env53446 := by
  intro p hp
  have h : env53446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53445_53446 : H12AffineEnvironment.transform 0 1 env53445 = env53446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env53445 == env53446) = true)

theorem identity53446 : scanCanonicalize (H12AffineFastState.compose env53446 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound53446 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53447 : List Nat := [1,1,1,1,0,1,0,0,1,0,1,1,1,0,0,1,1,0,0,1,1,1,1,0,0,0,1,1,1,1,0,0,0,0,1,0]

theorem envBound53447 : H12AffineFastState.Bounded env53447 := by
  intro p hp
  have h : env53447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53446_53447 : H12AffineEnvironment.transform 2 1 env53446 = env53447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env53446 == env53447) = true)

def env53448 : List Nat := [2,4,8,16,32,64,128,256,340,321,2048,17,8192,80,8525,65536,74030,65665,337,8524,17,477,74047,65536,8344,74110,303,74110,81,75802,8205,65,256,65831,1,325]

theorem envBound53448 : H12AffineFastState.Bounded env53448 := by
  intro p hp
  have h : env53448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53426_53448 : H12AffineEnvironment.transform 11 17 env53426 = env53448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env53426 == env53448) = true)

theorem identity53448 : scanCanonicalize (H12AffineFastState.compose env53448 (packedSelected [1,8,28] rootPS)) = affineNative (2^(6+1) ^^^ 110) := by decide +kernel

theorem selectedBound53448 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env53449 : List Nat := [2,4,8,16,32,64,110,256,340,321,2048,17,8192,80,8525,65536,74030,65647,337,8524,17,307,74047,65536,8310,74110,303,74110,81,75802,8205,65,256,65831,1,325]

theorem envBound53449 : H12AffineFastState.Bounded env53449 := by
  intro p hp
  have h : env53449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53448_53449 : H12AffineEnvironment.transform 6 110 env53448 = env53449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 110 env53448 == env53449) = true)

def env53450 : List Nat := [2,4,8,0,32,64,110,256,324,321,2048,1,8192,64,8525,65536,74030,65647,321,8524,1,291,74031,65536,8294,74094,303,74094,65,75786,8205,65,256,65831,1,325]

theorem envBound53450 : H12AffineFastState.Bounded env53450 := by
  intro p hp
  have h : env53450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53449_53450 : H12AffineEnvironment.transform 3 0 env53449 = env53450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env53449 == env53450) = true)

theorem identity53450 : scanCanonicalize (H12AffineFastState.compose env53450 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound53450 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env53451 : List Nat := [2,4,8,0,32,64,110,256,324,321,2048,1,8192,64,8525,34,8460,77,321,8524,1,291,8461,34,8294,8524,303,8524,65,10280,8205,65,256,261,1,325]

theorem envBound53451 : H12AffineFastState.Bounded env53451 := by
  intro p hp
  have h : env53451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53450_53451 : H12AffineEnvironment.transform 15 34 env53450 = env53451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env53450 == env53451) = true)

theorem identity53451 : scanCanonicalize (H12AffineFastState.compose env53451 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound53451 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env53452 : List Nat := [2,4,8,0,32,64,110,4,64,69,2048,1,8192,64,8265,34,8200,77,69,8264,1,39,8201,34,8294,8264,43,8264,65,10280,8205,65,4,1,1,65]

theorem envBound53452 : H12AffineFastState.Bounded env53452 := by
  intro p hp
  have h : env53452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53451_53452 : H12AffineEnvironment.transform 7 4 env53451 = env53452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env53451 == env53452) = true)

theorem identity53452 : scanCanonicalize (H12AffineFastState.compose env53452 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 72) := by decide +kernel

theorem selectedBound53452 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env53453 : List Nat := [2,4,8,0,32,64,110,4,64,69,2048,1,72,64,1,34,64,77,69,0,1,39,65,34,46,0,43,0,65,2144,69,65,4,1,1,65]

theorem envBound53453 : H12AffineFastState.Bounded env53453 := by
  intro p hp
  have h : env53453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53452_53453 : H12AffineEnvironment.transform 12 72 env53452 = env53453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 72 env53452 == env53453) = true)

theorem identity53453 : scanCanonicalize (H12AffineFastState.compose env53453 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 71) := by decide +kernel

theorem selectedBound53453 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env53454 : List Nat := [2,4,8,0,32,64,110,4,64,69,71,1,72,64,1,34,64,77,69,0,1,39,65,34,46,0,43,0,65,39,69,65,4,1,1,65]

theorem envBound53454 : H12AffineFastState.Bounded env53454 := by
  intro p hp
  have h : env53454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53453_53454 : H12AffineEnvironment.transform 10 71 env53453 = env53454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 71 env53453 == env53454) = true)

theorem identity53454 : scanCanonicalize (H12AffineFastState.compose env53454 (packedSelected [1,2,8] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound53454 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env53455 : List Nat := [2,4,5,0,32,64,99,4,64,69,71,1,69,64,1,34,64,64,69,0,1,39,65,34,35,0,38,0,65,39,69,65,4,1,1,65]

theorem envBound53455 : H12AffineFastState.Bounded env53455 := by
  intro p hp
  have h : env53455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53454_53455 : H12AffineEnvironment.transform 2 5 env53454 = env53455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env53454 == env53455) = true)

theorem identity53455 : scanCanonicalize (H12AffineFastState.compose env53455 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound53455 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env53456 : List Nat := [2,4,5,0,6,64,69,4,64,69,71,1,69,64,1,4,64,64,69,0,1,1,65,4,5,0,0,0,65,1,69,65,4,1,1,65]

theorem envBound53456 : H12AffineFastState.Bounded env53456 := by
  intro p hp
  have h : env53456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53455_53456 : H12AffineEnvironment.transform 4 6 env53455 = env53456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env53455 == env53456) = true)

theorem identity53456 : scanCanonicalize (H12AffineFastState.compose env53456 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 3) := by decide +kernel

theorem selectedBound53456 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53457 : List Nat := [2,4,5,0,6,3,6,4,3,6,4,1,6,3,1,4,3,3,6,0,1,1,2,4,5,0,0,0,2,1,6,2,4,1,1,2]

theorem envBound53457 : H12AffineFastState.Bounded env53457 := by
  intro p hp
  have h : env53457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53456_53457 : H12AffineEnvironment.transform 5 3 env53456 = env53457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 3 env53456 == env53457) = true)

theorem identity53457 : scanCanonicalize (H12AffineFastState.compose env53457 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound53457 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53458 : List Nat := [2,1,0,0,3,3,3,1,3,3,1,1,3,3,1,1,3,3,3,0,1,1,2,1,0,0,0,0,2,1,3,2,1,1,1,2]

theorem envBound53458 : H12AffineFastState.Bounded env53458 := by
  intro p hp
  have h : env53458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53457_53458 : H12AffineEnvironment.transform 1 1 env53457 = env53458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env53457 == env53458) = true)

theorem identity53458 : scanCanonicalize (H12AffineFastState.compose env53458 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound53458 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env53459 : List Nat := [0,1,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,1,0,1,0,0,0,0,0,1,1,0,1,1,1,0]

theorem envBound53459 : H12AffineFastState.Bounded env53459 := by
  intro p hp
  have h : env53459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53458_53459 : H12AffineEnvironment.transform 0 0 env53458 = env53459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env53458 == env53459) = true)

def env53460 : List Nat := [2,4,8,1,32,64,110,256,325,321,2048,0,8192,65,8525,65536,74030,65647,320,8524,0,290,74030,65536,8295,74095,303,74095,64,75787,8205,65,256,65831,1,325]

theorem envBound53460 : H12AffineFastState.Bounded env53460 := by
  intro p hp
  have h : env53460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53449_53460 : H12AffineEnvironment.transform 3 1 env53449 = env53460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env53449 == env53460) = true)

theorem identity53460 : scanCanonicalize (H12AffineFastState.compose env53460 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 332) := by decide +kernel

theorem selectedBound53460 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env53461 : List Nat := [2,4,8,1,32,64,110,256,325,321,2048,0,332,65,1,65536,65634,65647,320,0,0,290,65634,65536,299,65571,303,65571,64,67911,321,65,256,65831,1,325]

theorem envBound53461 : H12AffineFastState.Bounded env53461 := by
  intro p hp
  have h : env53461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53460_53461 : H12AffineEnvironment.transform 12 332 env53460 = env53461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 332 env53460 == env53461) = true)

theorem identity53461 : scanCanonicalize (H12AffineFastState.compose env53461 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound53461 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env53462 : List Nat := [2,4,8,1,32,64,110,256,325,321,2048,0,332,65,1,35,65,76,320,0,0,290,65,35,299,0,303,0,64,2404,321,65,256,260,1,325]

theorem envBound53462 : H12AffineFastState.Bounded env53462 := by
  intro p hp
  have h : env53462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53461_53462 : H12AffineEnvironment.transform 15 35 env53461 = env53462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env53461 == env53462) = true)

theorem identity53462 : scanCanonicalize (H12AffineFastState.compose env53462 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 357) := by decide +kernel

theorem selectedBound53462 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env53463 : List Nat := [2,4,8,1,32,64,110,256,325,321,357,0,332,65,1,35,65,76,320,0,0,290,65,35,299,0,303,0,64,1,321,65,256,260,1,325]

theorem envBound53463 : H12AffineFastState.Bounded env53463 := by
  intro p hp
  have h : env53463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53462_53463 : H12AffineEnvironment.transform 10 357 env53462 = env53463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 357 env53462 == env53463) = true)

theorem identity53463 : scanCanonicalize (H12AffineFastState.compose env53463 (packedSelected [0,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 105) := by decide +kernel

theorem selectedBound53463 : packedSelected [0,5,10] rootPS < 2^1333 := by decide +kernel

def env53464 : List Nat := [2,4,8,1,32,64,110,105,44,40,12,0,37,65,1,35,65,76,41,0,0,75,65,35,66,0,70,0,64,1,40,65,105,109,1,44]

theorem envBound53464 : H12AffineFastState.Bounded env53464 := by
  intro p hp
  have h : env53464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53463_53464 : H12AffineEnvironment.transform 7 105 env53463 = env53464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 105 env53463 == env53464) = true)

theorem identity53464 : scanCanonicalize (H12AffineFastState.compose env53464 (packedSelected [0,1,4,5,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 44) := by decide +kernel

theorem selectedBound53464 : packedSelected [0,1,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env53465 : List Nat := [2,4,8,1,32,44,2,5,44,40,12,0,37,45,1,35,45,32,41,0,0,39,45,35,46,0,42,0,44,1,40,45,5,1,1,44]

theorem envBound53465 : H12AffineFastState.Bounded env53465 := by
  intro p hp
  have h : env53465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53464_53465 : H12AffineEnvironment.transform 5 44 env53464 = env53465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 44 env53464 == env53465) = true)

theorem identity53465 : scanCanonicalize (H12AffineFastState.compose env53465 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound53465 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53466 : List Nat := [2,4,3,1,32,39,2,5,39,35,7,0,37,38,1,35,38,32,34,0,0,39,38,35,37,0,33,0,39,1,35,38,5,1,1,39]

theorem envBound53466 : H12AffineFastState.Bounded env53466 := by
  intro p hp
  have h : env53466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53465_53466 : H12AffineEnvironment.transform 2 3 env53465 = env53466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env53465 == env53466) = true)

theorem identity53466 : scanCanonicalize (H12AffineFastState.compose env53466 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound53466 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53467 : List Nat := [2,4,3,1,0,7,2,5,7,3,7,0,5,6,1,3,6,0,2,0,0,7,6,3,5,0,1,0,7,1,3,6,5,1,1,7]

theorem envBound53467 : H12AffineFastState.Bounded env53467 := by
  intro p hp
  have h : env53467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53466_53467 : H12AffineEnvironment.transform 4 0 env53466 = env53467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env53466 == env53467) = true)

def env53468 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,4096,8192,80,12636,65536,74030,65665,4416,12637,4096,477,74047,69649,12425,78191,4414,74110,81,79883,8205,65,256,65831,1,4437]

theorem envBound53468 : H12AffineFastState.Bounded env53468 := by
  intro p hp
  have h : env53468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53425_53468 : H12AffineEnvironment.transform 8 341 env53425 = env53468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env53425 == env53468) = true)

def env53469 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,16,8192,80,8524,65536,74030,65665,336,8525,16,477,74047,65537,8345,74111,302,74110,81,75803,8205,65,256,65831,1,325]

theorem envBound53469 : H12AffineFastState.Bounded env53469 := by
  intro p hp
  have h : env53469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53468_53469 : H12AffineEnvironment.transform 11 16 env53468 = env53469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env53468 == env53469) = true)

theorem identity53469 : scanCanonicalize (H12AffineFastState.compose env53469 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 392) := by decide +kernel

theorem selectedBound53469 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env53470 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,16,8192,80,8524,392,8358,265,336,8525,16,477,8375,393,8345,8439,302,8438,81,10643,8205,65,256,175,1,325]

theorem envBound53470 : H12AffineFastState.Bounded env53470 := by
  intro p hp
  have h : env53470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53469_53470 : H12AffineEnvironment.transform 15 392 env53469 = env53470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 392 env53469 == env53470) = true)

def env53471 : List Nat := [2,4,8,0,32,64,128,256,325,321,2048,0,8192,64,8524,392,8358,265,320,8525,0,461,8359,393,8329,8423,302,8422,65,10627,8205,65,256,175,1,325]

theorem envBound53471 : H12AffineFastState.Bounded env53471 := by
  intro p hp
  have h : env53471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53470_53471 : H12AffineEnvironment.transform 3 0 env53470 = env53471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env53470 == env53471) = true)

theorem identity53471 : scanCanonicalize (H12AffineFastState.compose env53471 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 333) := by decide +kernel

theorem selectedBound53471 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env53472 : List Nat := [2,4,8,0,32,64,128,256,325,321,2048,0,333,64,1,392,491,265,320,0,0,461,490,393,452,426,302,427,65,2254,320,65,256,175,1,325]

theorem envBound53472 : H12AffineFastState.Bounded env53472 := by
  intro p hp
  have h : env53472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53471_53472 : H12AffineEnvironment.transform 12 333 env53471 = env53472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 333 env53471 == env53472) = true)

theorem identity53472 : scanCanonicalize (H12AffineFastState.compose env53472 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 171) := by decide +kernel

theorem selectedBound53472 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env53473 : List Nat := [2,4,8,0,32,64,128,171,238,234,2048,0,230,64,1,35,64,162,235,0,0,102,65,34,111,1,133,0,65,2254,235,65,171,175,1,238]

theorem envBound53473 : H12AffineFastState.Bounded env53473 := by
  intro p hp
  have h : env53473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53472_53473 : H12AffineEnvironment.transform 7 171 env53472 = env53473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 171 env53472 == env53473) = true)

theorem identity53473 : scanCanonicalize (H12AffineFastState.compose env53473 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 207) := by decide +kernel

theorem selectedBound53473 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env53474 : List Nat := [2,4,8,0,32,64,128,171,238,234,207,0,230,64,1,35,64,162,235,0,0,102,65,34,111,1,133,0,65,1,235,65,171,175,1,238]

theorem envBound53474 : H12AffineFastState.Bounded env53474 := by
  intro p hp
  have h : env53474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53473_53474 : H12AffineEnvironment.transform 10 207 env53473 = env53474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 207 env53473 == env53474) = true)

theorem identity53474 : scanCanonicalize (H12AffineFastState.compose env53474 (packedSelected [0,5,10] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound53474 : packedSelected [0,5,10] rootPS < 2^1333 := by decide +kernel

def env53475 : List Nat := [2,4,8,0,12,64,128,135,194,198,207,0,202,64,1,15,64,142,199,0,0,74,65,14,67,1,133,0,65,1,199,65,135,131,1,194]

theorem envBound53475 : H12AffineFastState.Bounded env53475 := by
  intro p hp
  have h : env53475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53474_53475 : H12AffineEnvironment.transform 4 12 env53474 = env53475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env53474 == env53475) = true)

theorem identity53475 : scanCanonicalize (H12AffineFastState.compose env53475 (packedSelected [0,1,4,5,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound53475 : packedSelected [0,1,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env53476 : List Nat := [2,4,8,0,12,64,3,4,65,69,76,0,73,64,1,15,64,13,68,0,0,74,65,14,67,1,6,0,65,1,68,65,4,0,1,65]

theorem envBound53476 : H12AffineFastState.Bounded env53476 := by
  intro p hp
  have h : env53476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53475_53476 : H12AffineEnvironment.transform 6 3 env53475 = env53476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env53475 == env53476) = true)

theorem identity53476 : scanCanonicalize (H12AffineFastState.compose env53476 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound53476 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53477 : List Nat := [2,4,2,0,6,64,3,4,65,69,70,0,67,64,1,5,64,7,68,0,0,64,65,4,67,1,6,0,65,1,68,65,4,0,1,65]

theorem envBound53477 : H12AffineFastState.Bounded env53477 := by
  intro p hp
  have h : env53477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53476_53477 : H12AffineEnvironment.transform 2 2 env53476 = env53477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env53476 == env53477) = true)

theorem identity53477 : scanCanonicalize (H12AffineFastState.compose env53477 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound53477 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53478 : List Nat := [2,3,2,0,1,64,3,3,65,66,65,0,67,64,1,2,64,0,67,0,0,64,65,3,67,1,1,0,65,1,67,65,3,0,1,65]

theorem envBound53478 : H12AffineFastState.Bounded env53478 := by
  intro p hp
  have h : env53478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53477_53478 : H12AffineEnvironment.transform 1 3 env53477 = env53478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env53477 == env53478) = true)

def env53479 : List Nat := [2,4,8,1,32,64,128,256,324,321,2048,1,8192,65,8524,392,8358,265,321,8525,1,460,8358,393,8328,8422,302,8423,64,10626,8205,65,256,175,1,325]

theorem envBound53479 : H12AffineFastState.Bounded env53479 := by
  intro p hp
  have h : env53479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53470_53479 : H12AffineEnvironment.transform 3 1 env53470 = env53479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env53470 == env53479) = true)

theorem identity53479 : scanCanonicalize (H12AffineFastState.compose env53479 (packedSelected [4,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 170) := by decide +kernel

theorem selectedBound53479 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env53480 : List Nat := [2,4,8,1,32,64,128,170,238,235,2048,1,8192,65,8422,34,8358,163,235,8423,1,102,8358,35,8328,8422,132,8423,64,10280,8205,65,170,175,1,239]

theorem envBound53480 : H12AffineFastState.Bounded env53480 := by
  intro p hp
  have h : env53480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53479_53480 : H12AffineEnvironment.transform 7 170 env53479 = env53480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 170 env53479 == env53480) = true)

theorem identity53480 : scanCanonicalize (H12AffineFastState.compose env53480 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 47) := by decide +kernel

theorem selectedBound53480 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env53481 : List Nat := [2,4,8,1,32,64,47,5,65,68,2048,1,8192,65,8265,34,8201,12,68,8264,1,102,8201,35,8231,8265,43,8264,64,10280,8205,65,5,0,1,64]

theorem envBound53481 : H12AffineFastState.Bounded env53481 := by
  intro p hp
  have h : env53481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53480_53481 : H12AffineEnvironment.transform 6 47 env53480 = env53481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 47 env53480 == env53481) = true)

theorem identity53481 : scanCanonicalize (H12AffineFastState.compose env53481 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 73) := by decide +kernel

theorem selectedBound53481 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env53482 : List Nat := [2,4,8,1,32,64,47,5,65,68,2048,1,73,65,0,34,64,12,68,1,1,102,64,35,110,0,43,1,64,2145,68,65,5,0,1,64]

theorem envBound53482 : H12AffineFastState.Bounded env53482 := by
  intro p hp
  have h : env53482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53481_53482 : H12AffineEnvironment.transform 12 73 env53481 = env53482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 73 env53481 == env53482) = true)

theorem identity53482 : scanCanonicalize (H12AffineFastState.compose env53482 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound53482 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env53483 : List Nat := [2,2,8,1,32,64,41,3,65,66,2048,1,73,65,0,34,64,10,66,1,1,96,64,35,104,0,43,1,64,2145,66,65,3,0,1,64]

theorem envBound53483 : H12AffineFastState.Bounded env53483 := by
  intro p hp
  have h : env53483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53482_53483 : H12AffineEnvironment.transform 1 2 env53482 = env53483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env53482 == env53483) = true)

theorem identity53483 : scanCanonicalize (H12AffineFastState.compose env53483 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 106) := by decide +kernel

theorem selectedBound53483 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env53484 : List Nat := [2,2,8,1,32,64,41,3,65,66,106,1,73,65,0,34,64,10,66,1,1,96,64,35,104,0,43,1,64,11,66,65,3,0,1,64]

theorem envBound53484 : H12AffineFastState.Bounded env53484 := by
  intro p hp
  have h : env53484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53483_53484 : H12AffineEnvironment.transform 10 106 env53483 = env53484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 106 env53483 == env53484) = true)

theorem identity53484 : scanCanonicalize (H12AffineFastState.compose env53484 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 43) := by decide +kernel

theorem selectedBound53484 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53485 : List Nat := [2,2,8,1,32,43,41,3,42,41,1,1,34,42,0,34,43,10,41,1,1,11,43,35,3,0,43,1,43,11,41,42,3,0,1,43]

theorem envBound53485 : H12AffineFastState.Bounded env53485 := by
  intro p hp
  have h : env53485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53484_53485 : H12AffineEnvironment.transform 5 43 env53484 = env53485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 43 env53484 == env53485) = true)

theorem identity53485 : scanCanonicalize (H12AffineFastState.compose env53485 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound53485 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53486 : List Nat := [2,2,8,1,3,8,10,3,9,10,1,1,1,9,0,1,8,10,10,1,1,11,8,0,3,0,8,1,8,11,10,9,3,0,1,8]

theorem envBound53486 : H12AffineFastState.Bounded env53486 := by
  intro p hp
  have h : env53486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53485_53486 : H12AffineEnvironment.transform 4 3 env53485 = env53486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env53485 == env53486) = true)

theorem identity53486 : scanCanonicalize (H12AffineFastState.compose env53486 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound53486 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env53487 : List Nat := [2,2,0,1,3,0,2,3,1,2,1,1,1,1,0,1,0,2,2,1,1,3,0,0,3,0,0,1,0,3,2,1,3,0,1,0]

theorem envBound53487 : H12AffineFastState.Bounded env53487 := by
  intro p hp
  have h : env53487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53486_53487 : H12AffineEnvironment.transform 2 0 env53486 = env53487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env53486 == env53487) = true)

theorem identity53487 : scanCanonicalize (H12AffineFastState.compose env53487 (packedSelected [7] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound53487 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env53488 : List Nat := [0,0,0,1,1,0,0,1,1,0,1,1,1,1,0,1,0,0,0,1,1,1,0,0,1,0,0,1,0,1,0,1,1,0,1,0]

theorem envBound53488 : H12AffineFastState.Bounded env53488 := by
  intro p hp
  have h : env53488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53487_53488 : H12AffineEnvironment.transform 0 0 env53487 = env53488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env53487 == env53488) = true)

def env53489 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,17,8192,80,8525,65536,74030,65665,337,8524,17,477,74047,65536,8344,74110,303,74110,81,75802,8205,65,256,65831,1,324]

theorem envBound53489 : H12AffineFastState.Bounded env53489 := by
  intro p hp
  have h : env53489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53468_53489 : H12AffineEnvironment.transform 11 17 env53468 = env53489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env53468 == env53489) = true)

theorem identity53489 : scanCanonicalize (H12AffineFastState.compose env53489 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8641) := by decide +kernel

theorem selectedBound53489 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env53490 : List Nat := [2,4,8,16,32,64,128,256,341,321,2048,17,8192,80,8525,8641,239,8512,337,8524,17,477,254,8641,8344,191,303,191,81,2523,8205,65,256,8422,1,324]

theorem envBound53490 : H12AffineFastState.Bounded env53490 := by
  intro p hp
  have h : env53490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53489_53490 : H12AffineEnvironment.transform 15 8641 env53489 = env53490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8641 env53489 == env53490) = true)

def env53491 : List Nat := [2,4,8,0,32,64,128,256,325,321,2048,1,8192,64,8525,8641,239,8512,321,8524,1,461,238,8641,8328,175,303,175,65,2507,8205,65,256,8422,1,324]

theorem envBound53491 : H12AffineFastState.Bounded env53491 := by
  intro p hp
  have h : env53491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53490_53491 : H12AffineEnvironment.transform 3 0 env53490 = env53491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env53490 == env53491) = true)

theorem identity53491 : scanCanonicalize (H12AffineFastState.compose env53491 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 483) := by decide +kernel

theorem selectedBound53491 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env53492 : List Nat := [2,4,8,0,32,64,128,256,325,321,2048,1,483,64,174,34,239,163,321,175,1,461,238,34,363,175,303,175,65,2507,494,65,256,261,1,324]

theorem envBound53492 : H12AffineFastState.Bounded env53492 := by
  intro p hp
  have h : env53492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53491_53492 : H12AffineEnvironment.transform 12 483 env53491 = env53492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 483 env53491 == env53492) = true)

theorem identity53492 : scanCanonicalize (H12AffineFastState.compose env53492 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound53492 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env53493 : List Nat := [2,4,8,0,32,64,128,4,65,69,2048,1,231,64,174,34,239,163,69,175,1,201,238,34,111,175,43,175,65,2255,234,65,4,1,1,64]

theorem envBound53493 : H12AffineFastState.Bounded env53493 := by
  intro p hp
  have h : env53493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53492_53493 : H12AffineEnvironment.transform 7 4 env53492 = env53493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env53492 == env53493) = true)

theorem identity53493 : scanCanonicalize (H12AffineFastState.compose env53493 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 47) := by decide +kernel

theorem selectedBound53493 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env53494 : List Nat := [2,4,8,0,32,64,47,4,65,69,2048,1,72,64,1,34,64,12,69,0,1,102,65,34,111,0,43,0,65,2144,69,65,4,1,1,64]

theorem envBound53494 : H12AffineFastState.Bounded env53494 := by
  intro p hp
  have h : env53494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53493_53494 : H12AffineEnvironment.transform 6 47 env53493 = env53494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 47 env53493 == env53494) = true)

theorem identity53494 : scanCanonicalize (H12AffineFastState.compose env53494 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 71) := by decide +kernel

theorem selectedBound53494 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env53495 : List Nat := [2,4,8,0,32,64,47,4,65,69,71,1,72,64,1,34,64,12,69,0,1,102,65,34,111,0,43,0,65,39,69,65,4,1,1,64]

theorem envBound53495 : H12AffineFastState.Bounded env53495 := by
  intro p hp
  have h : env53495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53494_53495 : H12AffineEnvironment.transform 10 71 env53494 = env53495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 71 env53494 == env53495) = true)

theorem identity53495 : scanCanonicalize (H12AffineFastState.compose env53495 (packedSelected [1,2,8] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound53495 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env53496 : List Nat := [2,4,8,0,32,13,47,4,12,8,10,1,5,13,1,34,13,12,8,0,1,43,12,34,34,0,43,0,12,39,8,12,4,1,1,13]

theorem envBound53496 : H12AffineFastState.Bounded env53496 := by
  intro p hp
  have h : env53496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53495_53496 : H12AffineEnvironment.transform 5 13 env53495 = env53496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env53495 == env53496) = true)

theorem identity53496 : scanCanonicalize (H12AffineFastState.compose env53496 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound53496 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env53497 : List Nat := [2,4,8,0,6,13,9,4,12,8,10,1,5,13,1,4,13,12,8,0,1,13,12,4,4,0,13,0,12,1,8,12,4,1,1,13]

theorem envBound53497 : H12AffineFastState.Bounded env53497 := by
  intro p hp
  have h : env53497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53496_53497 : H12AffineEnvironment.transform 4 6 env53496 = env53497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env53496 == env53497) = true)

theorem identity53497 : scanCanonicalize (H12AffineFastState.compose env53497 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound53497 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53498 : List Nat := [0,4,8,0,4,13,9,4,12,8,8,1,5,13,1,4,13,12,8,0,1,13,12,4,4,0,13,0,12,1,8,12,4,1,1,13]

theorem envBound53498 : H12AffineFastState.Bounded env53498 := by
  intro p hp
  have h : env53498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53497_53498 : H12AffineEnvironment.transform 0 0 env53497 = env53498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env53497 == env53498) = true)

theorem identity53498 : scanCanonicalize (H12AffineFastState.compose env53498 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound53498 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53499 : List Nat := [0,4,0,0,4,5,1,4,4,0,0,1,5,5,1,4,5,4,0,0,1,5,4,4,4,0,5,0,4,1,0,4,4,1,1,5]

theorem envBound53499 : H12AffineFastState.Bounded env53499 := by
  intro p hp
  have h : env53499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53498_53499 : H12AffineEnvironment.transform 2 0 env53498 = env53499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env53498 == env53499) = true)

def env53500 : List Nat := [2,4,8,1,32,64,128,256,324,321,2048,0,8192,65,8525,8641,239,8512,320,8524,0,460,239,8641,8329,174,303,174,64,2506,8205,65,256,8422,1,324]

theorem envBound53500 : H12AffineFastState.Bounded env53500 := by
  intro p hp
  have h : env53500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53490_53500 : H12AffineEnvironment.transform 3 1 env53490 = env53500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env53490 == env53500) = true)

theorem identity53500 : scanCanonicalize (H12AffineFastState.compose env53500 (packedSelected [4,9,16] rootPS)) = affineNative (2^(12+1) ^^^ 332) := by decide +kernel

theorem selectedBound53500 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env53501 : List Nat := [2,4,8,1,32,64,128,256,324,321,2048,0,332,65,1,141,239,12,320,0,0,460,239,141,453,174,303,174,64,2506,321,65,256,426,1,324]

theorem envBound53501 : H12AffineFastState.Bounded env53501 := by
  intro p hp
  have h : env53501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53500_53501 : H12AffineEnvironment.transform 12 332 env53500 = env53501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 332 env53500 == env53501) = true)

theorem identity53501 : scanCanonicalize (H12AffineFastState.compose env53501 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(6+1) ^^^ 46) := by decide +kernel

theorem selectedBound53501 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env53502 : List Nat := [2,4,8,1,32,64,46,256,324,321,2048,0,332,65,1,35,65,12,320,0,0,354,65,35,363,0,303,0,64,2404,321,65,256,260,1,324]

theorem envBound53502 : H12AffineFastState.Bounded env53502 := by
  intro p hp
  have h : env53502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53501_53502 : H12AffineEnvironment.transform 6 46 env53501 = env53502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 46 env53501 == env53502) = true)

theorem identity53502 : scanCanonicalize (H12AffineFastState.compose env53502 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound53502 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env53503 : List Nat := [2,4,8,1,32,64,46,256,324,321,293,0,332,65,1,35,65,12,320,0,0,354,65,35,363,0,303,0,64,65,321,65,256,260,1,324]

theorem envBound53503 : H12AffineFastState.Bounded env53503 := by
  intro p hp
  have h : env53503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53502_53503 : H12AffineEnvironment.transform 10 293 env53502 = env53503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env53502 == env53503) = true)

theorem identity53503 : scanCanonicalize (H12AffineFastState.compose env53503 (packedSelected [0,1,2,8,10,12] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound53503 : packedSelected [0,1,2,8,10,12] rootPS < 2^1333 := by decide +kernel

def env53504 : List Nat := [2,4,8,1,32,0,46,256,260,257,293,0,268,1,1,35,1,12,256,0,0,290,1,35,299,0,303,0,0,1,257,1,256,260,1,260]

theorem envBound53504 : H12AffineFastState.Bounded env53504 := by
  intro p hp
  have h : env53504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53503_53504 : H12AffineEnvironment.transform 5 0 env53503 = env53504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env53503 == env53504) = true)

theorem identity53504 : scanCanonicalize (H12AffineFastState.compose env53504 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound53504 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53505 : List Nat := [2,4,3,1,32,0,37,256,260,257,293,0,263,1,1,35,1,7,256,0,0,290,1,35,288,0,292,0,0,1,257,1,256,260,1,260]

theorem envBound53505 : H12AffineFastState.Bounded env53505 := by
  intro p hp
  have h : env53505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53504_53505 : H12AffineEnvironment.transform 2 3 env53504 = env53505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env53504 == env53505) = true)

theorem identity53505 : scanCanonicalize (H12AffineFastState.compose env53505 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 3) := by decide +kernel

theorem selectedBound53505 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env53506 : List Nat := [2,4,3,1,32,0,37,3,7,2,38,0,4,1,1,35,1,7,3,0,0,33,1,35,35,0,39,0,0,1,2,1,3,7,1,7]

theorem envBound53506 : H12AffineFastState.Bounded env53506 := by
  intro p hp
  have h : env53506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53505_53506 : H12AffineEnvironment.transform 7 3 env53505 = env53506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 3 env53505 == env53506) = true)

theorem identity53506 : scanCanonicalize (H12AffineFastState.compose env53506 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound53506 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53507 : List Nat := [2,2,3,1,32,0,35,3,1,2,32,0,2,1,1,35,1,1,3,0,0,33,1,35,35,0,33,0,0,1,2,1,3,1,1,1]

theorem envBound53507 : H12AffineFastState.Bounded env53507 := by
  intro p hp
  have h : env53507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53506_53507 : H12AffineEnvironment.transform 1 2 env53506 = env53507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env53506 == env53507) = true)

theorem identity53507 : scanCanonicalize (H12AffineFastState.compose env53507 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound53507 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53508 : List Nat := [2,2,3,1,0,0,3,3,1,2,0,0,2,1,1,3,1,1,3,0,0,1,1,3,3,0,1,0,0,1,2,1,3,1,1,1]

theorem envBound53508 : H12AffineFastState.Bounded env53508 := by
  intro p hp
  have h : env53508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53507_53508 : H12AffineEnvironment.transform 4 0 env53507 = env53508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env53507 == env53508) = true)

def env53509 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,16777216,533641,672784,134217728,148801,545088,96347,16876544,205166,257,17552661,151462017,525824]

theorem envBound53509 : H12AffineFastState.Bounded env53509 := by
  intro p hp
  have h : env53509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans52552_53509 : H12AffineEnvironment.transform 24 533641 env52552 = env53509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 533641 env52552 == env53509) = true)

def env53510 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,16777216,533641,672784,17245632,148801,545088,96347,16876544,205166,257,17552661,1345,525824]

theorem envBound53510 : H12AffineFastState.Bounded env53510 := by
  intro p hp
  have h : env53510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53509_53510 : H12AffineEnvironment.transform 26 17245632 env53509 = env53510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245632 env53509 == env53510) = true)

theorem identity53510 : scanCanonicalize (H12AffineFastState.compose env53510 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 717114) := by decide +kernel

theorem selectedBound53510 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env53511 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,717114,533641,672784,906490,148801,545088,96347,750906,205166,257,74799,1345,525824]

theorem envBound53511 : H12AffineFastState.Bounded env53511 := by
  intro p hp
  have h : env53511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53510_53511 : H12AffineEnvironment.transform 23 717114 env53510 = env53511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 717114 env53510 == env53511) = true)

def env53512 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147521,58682,143497,20496,508154,148801,148800,96347,90426,205166,257,74799,1345,135680]

theorem envBound53512 : H12AffineFastState.Bounded env53512 := by
  intro p hp
  have h : env53512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53511_53512 : H12AffineEnvironment.transform 18 136192 env53511 = env53512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env53511 == env53512) = true)

def env53513 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147521,58518,143497,20496,508154,148717,148716,96347,90262,204994,173,74799,1261,135680]

theorem envBound53513 : H12AffineFastState.Bounded env53513 := by
  intro p hp
  have h : env53513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53512_53513 : H12AffineEnvironment.transform 7 172 env53512 = env53513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env53512 == env53513) = true)

def env53514 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147473,58518,143497,20496,508074,148669,148668,96267,90262,204946,173,74799,1213,135680]

theorem envBound53514 : H12AffineFastState.Bounded env53514 := by
  intro p hp
  have h : env53514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53513_53514 : H12AffineEnvironment.transform 5 16 env53513 = env53514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env53513 == env53514) = true)

theorem identity53514 : scanCanonicalize (H12AffineFastState.compose env53514 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 208054) := by decide +kernel

theorem selectedBound53514 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env53515 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,208054,136192,32769,4096,61569,147473,58518,143497,20496,60444,148669,148668,96267,90262,204946,173,74799,1213,135680]

theorem envBound53515 : H12AffineFastState.Bounded env53515 := by
  intro p hp
  have h : env53515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53514_53515 : H12AffineEnvironment.transform 17 208054 env53514 = env53515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 208054 env53514 == env53515) = true)

theorem identity53515 : scanCanonicalize (H12AffineFastState.compose env53515 (packedSelected [1,3,5,7,8,10,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound53515 : packedSelected [1,3,5,7,8,10,20,26,27] rootPS < 2^1333 := by decide +kernel

def env53516 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,53283,131072,195733,136192,32769,4096,61569,147473,58518,143497,20496,60444,148669,148668,43048,45237,192689,173,62476,1213,135680]

theorem envBound53516 : H12AffineFastState.Bounded env53516 := by
  intro p hp
  have h : env53516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53515_53516 : H12AffineEnvironment.transform 15 53283 env53515 = env53516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env53515 == env53516) = true)

theorem identity53516 : scanCanonicalize (H12AffineFastState.compose env53516 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 21693) := by decide +kernel

theorem selectedBound53516 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env53517 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,53283,21693,43048,16573,32769,4096,61569,5292,58518,25652,20496,60444,4096,4097,43048,45237,41996,173,62476,1213,18109]

theorem envBound53517 : H12AffineFastState.Bounded env53517 := by
  intro p hp
  have h : env53517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53516_53517 : H12AffineEnvironment.transform 16 21693 env53516 = env53517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21693 env53516 == env53517) = true)

theorem identity53517 : scanCanonicalize (H12AffineFastState.compose env53517 (packedSelected [4,9,20] rootPS)) = affineNative (2^(14+1) ^^^ 29860) := by decide +kernel

theorem selectedBound53517 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env53518 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,29860,9351,21693,23692,16573,29861,4096,1061,5292,4146,25652,20496,6328,4096,4097,23692,17425,20648,173,168,1213,18109]

theorem envBound53518 : H12AffineFastState.Bounded env53518 := by
  intro p hp
  have h : env53518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53517_53518 : H12AffineEnvironment.transform 14 29860 env53517 = env53518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29860 env53517 == env53518) = true)

theorem identity53518 : scanCanonicalize (H12AffineFastState.compose env53518 (packedSelected [0,2,3,5,6,9,11,13,17] rootPS)) = affineNative (2^(13+1) ^^^ 13989) := by decide +kernel

theorem selectedBound53518 : packedSelected [0,2,3,5,6,9,11,13,17] rootPS < 2^1333 := by decide +kernel

def env53519 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,13989,513,9351,8728,10793,13848,512,4096,1061,5292,4146,4753,9909,6328,4096,4097,10793,12980,9741,173,168,1213,12312]

theorem envBound53519 : H12AffineFastState.Bounded env53519 := by
  intro p hp
  have h : env53519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53518_53519 : H12AffineEnvironment.transform 13 13989 env53518 = env53519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13989 env53518 == env53519) = true)

theorem identity53519 : scanCanonicalize (H12AffineFastState.compose env53519 (packedSelected [1,3,4,6,7,11,13,15,16] rootPS)) = affineNative (2^(11+1) ^^^ 3118) := by decide +kernel

theorem selectedBound53519 : packedSelected [1,3,4,6,7,11,13,15,16] rootPS < 2^1333 := by decide +kernel

def env53520 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,3118,8192,10891,513,9351,8728,10793,10806,512,3118,1061,2178,3100,3775,9909,1174,3118,3119,10793,11930,9741,173,168,1213,11318]

theorem envBound53520 : H12AffineFastState.Bounded env53520 := by
  intro p hp
  have h : env53520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53519_53520 : H12AffineEnvironment.transform 11 3118 env53519 = env53520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3118 env53519 == env53520) = true)

theorem identity53520 : scanCanonicalize (H12AffineFastState.compose env53520 (packedSelected [6,7,9,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 1685) := by decide +kernel

theorem selectedBound53520 : packedSelected [6,7,9,11,15] rootPS < 2^1333 := by decide +kernel

def env53521 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,3118,1685,3102,513,530,1165,3260,3235,512,3118,1061,2178,3100,3775,32,1174,3118,3119,3260,2063,152,173,168,1213,2723]

theorem envBound53521 : H12AffineFastState.Bounded env53521 := by
  intro p hp
  have h : env53521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53520_53521 : H12AffineEnvironment.transform 12 1685 env53520 = env53521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1685 env53520 == env53521) = true)

theorem identity53521 : scanCanonicalize (H12AffineFastState.compose env53521 (packedSelected [1,4,6,7,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 697) := by decide +kernel

theorem selectedBound53521 : packedSelected [1,4,6,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env53522 : List Nat := [2,4,8,16,32,16,128,172,512,1024,697,1687,1685,1703,513,530,1165,1541,1562,512,1687,1061,571,1701,1030,32,1174,1687,1686,1541,694,152,173,168,1213,26]

theorem envBound53522 : H12AffineFastState.Bounded env53522 := by
  intro p hp
  have h : env53522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53521_53522 : H12AffineEnvironment.transform 10 697 env53521 = env53522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 697 env53521 == env53522) = true)

theorem identity53522 : scanCanonicalize (H12AffineFastState.compose env53522 (packedSelected [4,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound53522 : packedSelected [4,6,7] rootPS < 2^1333 := by decide +kernel

def env53523 : List Nat := [2,4,8,16,32,16,128,172,512,517,697,146,144,162,513,530,648,0,31,512,146,544,571,160,515,32,659,146,147,0,694,152,173,168,696,26]

theorem envBound53523 : H12AffineFastState.Bounded env53523 := by
  intro p hp
  have h : env53523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53522_53523 : H12AffineEnvironment.transform 9 517 env53522 = env53523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env53522 == env53523) = true)

theorem identity53523 : scanCanonicalize (H12AffineFastState.compose env53523 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound53523 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53524 : List Nat := [2,4,8,16,32,16,56,20,512,517,513,42,40,26,513,530,560,0,31,512,42,544,571,24,515,32,555,42,43,0,526,32,21,16,512,26]

theorem envBound53524 : H12AffineFastState.Bounded env53524 := by
  intro p hp
  have h : env53524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53523_53524 : H12AffineEnvironment.transform 6 56 env53523 = env53524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env53523 == env53524) = true)

theorem identity53524 : scanCanonicalize (H12AffineFastState.compose env53524 (packedSelected [3,6,8] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound53524 : packedSelected [3,6,8] rootPS < 2^1333 := by decide +kernel

def env53525 : List Nat := [2,4,8,16,32,16,56,20,49,52,48,42,40,26,48,35,1,0,31,49,42,17,10,24,50,32,26,42,43,0,63,32,21,16,49,26]

theorem envBound53525 : H12AffineFastState.Bounded env53525 := by
  intro p hp
  have h : env53525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53524_53525 : H12AffineEnvironment.transform 8 49 env53524 = env53525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env53524 == env53525) = true)

def env53526 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147472,58518,143497,20496,508075,148668,148669,96266,90262,204947,173,74799,1212,135680]

theorem envBound53526 : H12AffineFastState.Bounded env53526 := by
  intro p hp
  have h : env53526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53513_53526 : H12AffineEnvironment.transform 5 17 env53513 = env53526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53513 == env53526) = true)

theorem identity53526 : scanCanonicalize (H12AffineFastState.compose env53526 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 99487) := by decide +kernel

theorem selectedBound53526 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env53527 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,99487,262144,102559,32769,4096,61568,115855,58518,111638,20496,279604,114723,114722,96266,90262,41996,173,74799,1212,104095]

theorem envBound53527 : H12AffineFastState.Bounded env53527 := by
  intro p hp
  have h : env53527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53526_53527 : H12AffineEnvironment.transform 16 99487 env53526 = env53527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 99487 env53526 == env53527) = true)

theorem identity53527 : scanCanonicalize (H12AffineFastState.compose env53527 (packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 24634) := by decide +kernel

theorem selectedBound53527 : packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env53528 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,24634,58533,262144,61605,32769,4096,61568,42165,58518,54316,20496,279604,40985,40984,6192,172,41996,173,17429,1212,63141]

theorem envBound53528 : H12AffineFastState.Bounded env53528 := by
  intro p hp
  have h : env53528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53527_53528 : H12AffineEnvironment.transform 15 24634 env53527 = env53528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24634 env53527 == env53528) = true)

theorem identity53528 : scanCanonicalize (H12AffineFastState.compose env53528 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 29861) := by decide +kernel

theorem selectedBound53528 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env53529 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,29861,24634,4096,262144,1024,29860,4096,1061,20496,4147,8329,20496,279604,21692,21693,6192,172,20649,173,17429,1212,512]

theorem envBound53529 : H12AffineFastState.Bounded env53529 := by
  intro p hp
  have h : env53529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53528_53529 : H12AffineEnvironment.transform 14 29861 env53528 = env53529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29861 env53528 == env53529) = true)

theorem identity53529 : scanCanonicalize (H12AffineFastState.compose env53529 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 1213) := by decide +kernel

theorem selectedBound53529 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env53530 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,1213,12312,9351,4096,262144,1024,12313,4096,1061,5293,4147,8329,5293,262281,4097,4096,6192,172,5140,173,168,1212,512]

theorem envBound53530 : H12AffineFastState.Bounded env53530 := by
  intro p hp
  have h : env53530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53529_53530 : H12AffineEnvironment.transform 13 1213 env53529 = env53530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1213 env53529 == env53530) = true)

theorem identity53530 : scanCanonicalize (H12AffineFastState.compose env53530 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 4648) := by decide +kernel

theorem selectedBound53530 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env53531 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,4648,1213,560,5807,4096,262144,1024,561,4096,1061,5293,4147,4769,5293,262281,4097,4096,6192,172,5140,173,168,1212,512]

theorem envBound53531 : H12AffineFastState.Bounded env53531 := by
  intro p hp
  have h : env53531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53530_53531 : H12AffineEnvironment.transform 12 4648 env53530 = env53531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4648 env53530 == env53531) = true)

theorem identity53531 : scanCanonicalize (H12AffineFastState.compose env53531 (packedSelected [1,3,13] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound53531 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env53532 : List Nat := [2,4,8,16,32,17,128,172,512,5,2048,4096,4648,184,560,4778,4096,262144,5,561,4096,32,4264,4147,4769,4264,262281,4097,4096,6192,172,4113,173,168,185,512]

theorem envBound53532 : H12AffineFastState.Bounded env53532 := by
  intro p hp
  have h : env53532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53531_53532 : H12AffineEnvironment.transform 9 5 env53531 = env53532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env53531 == env53532) = true)

theorem identity53532 : scanCanonicalize (H12AffineFastState.compose env53532 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 554) := by decide +kernel

theorem selectedBound53532 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env53533 : List Nat := [2,4,8,16,32,17,128,172,512,5,2048,4096,4648,184,560,4778,4096,554,5,561,4096,32,4264,4147,4769,4264,675,4097,4096,6192,172,4113,173,168,185,512]

theorem envBound53533 : H12AffineFastState.Bounded env53533 := by
  intro p hp
  have h : env53533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53532_53533 : H12AffineEnvironment.transform 17 554 env53532 = env53533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 554 env53532 == env53533) = true)

theorem identity53533 : scanCanonicalize (H12AffineFastState.compose env53533 (packedSelected [0,1,3,4,7,9,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound53533 : packedSelected [0,1,3,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env53534 : List Nat := [2,4,8,16,32,17,128,172,512,5,2048,185,657,184,560,531,185,554,5,561,185,32,17,138,536,17,675,184,185,2185,172,168,173,168,185,512]

theorem envBound53534 : H12AffineFastState.Bounded env53534 := by
  intro p hp
  have h : env53534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53533_53534 : H12AffineEnvironment.transform 11 185 env53533 = env53534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env53533 == env53534) = true)

theorem identity53534 : scanCanonicalize (H12AffineFastState.compose env53534 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound53534 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53535 : List Nat := [2,4,8,16,32,17,128,172,512,5,512,185,657,184,560,531,185,554,5,561,185,32,17,138,536,17,675,184,185,649,172,168,173,168,185,512]

theorem envBound53535 : H12AffineFastState.Bounded env53535 := by
  intro p hp
  have h : env53535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53534_53535 : H12AffineEnvironment.transform 10 512 env53534 = env53535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env53534 == env53535) = true)

theorem identity53535 : scanCanonicalize (H12AffineFastState.compose env53535 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound53535 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env53536 : List Nat := [2,4,8,16,32,17,57,21,512,5,512,0,552,1,560,531,0,554,5,561,0,32,17,51,536,17,538,1,0,560,21,17,20,17,0,512]

theorem envBound53536 : H12AffineFastState.Bounded env53536 := by
  intro p hp
  have h : env53536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53535_53536 : H12AffineEnvironment.transform 6 57 env53535 = env53536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env53535 == env53536) = true)

theorem identity53536 : scanCanonicalize (H12AffineFastState.compose env53536 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 12) := by decide +kernel

theorem selectedBound53536 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53537 : List Nat := [2,4,8,16,32,17,57,21,12,5,12,0,36,1,60,31,0,38,5,61,0,32,17,51,20,17,22,1,0,60,21,17,20,17,0,12]

theorem envBound53537 : H12AffineFastState.Bounded env53537 := by
  intro p hp
  have h : env53537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53536_53537 : H12AffineEnvironment.transform 8 12 env53536 = env53537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 12 env53536 == env53537) = true)

theorem identity53537 : scanCanonicalize (H12AffineFastState.compose env53537 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 29) := by decide +kernel

theorem selectedBound53537 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53538 : List Nat := [2,4,8,16,29,17,4,21,12,5,12,0,25,1,1,31,0,27,5,0,0,29,17,14,20,17,22,1,0,1,21,17,20,17,0,12]

theorem envBound53538 : H12AffineFastState.Bounded env53538 := by
  intro p hp
  have h : env53538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53537_53538 : H12AffineEnvironment.transform 4 29 env53537 = env53538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 29 env53537 == env53538) = true)

theorem identity53538 : scanCanonicalize (H12AffineFastState.compose env53538 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound53538 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env53539 : List Nat := [2,4,8,7,10,6,4,2,12,5,12,0,14,1,1,8,0,12,5,0,0,10,6,14,3,6,1,1,0,1,2,6,3,6,0,12]

theorem envBound53539 : H12AffineFastState.Bounded env53539 := by
  intro p hp
  have h : env53539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53538_53539 : H12AffineEnvironment.transform 3 7 env53538 = env53539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env53538 == env53539) = true)

theorem identity53539 : scanCanonicalize (H12AffineFastState.compose env53539 (packedSelected [7] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound53539 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env53540 : List Nat := [2,4,5,7,7,6,4,2,1,5,1,0,3,1,1,5,0,1,5,0,0,7,6,3,3,6,1,1,0,1,2,6,3,6,0,1]

theorem envBound53540 : H12AffineFastState.Bounded env53540 := by
  intro p hp
  have h : env53540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53539_53540 : H12AffineEnvironment.transform 2 5 env53539 = env53540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env53539 == env53540) = true)

def env53541 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147521,58519,143497,20496,508154,148716,148717,96347,90263,204995,172,74799,1260,135680]

theorem envBound53541 : H12AffineFastState.Bounded env53541 := by
  intro p hp
  have h : env53541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53512_53541 : H12AffineEnvironment.transform 7 173 env53512 = env53541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env53512 == env53541) = true)

def env53542 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147473,58519,143497,20496,508074,148668,148669,96267,90263,204947,172,74799,1212,135680]

theorem envBound53542 : H12AffineFastState.Bounded env53542 := by
  intro p hp
  have h : env53542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53541_53542 : H12AffineEnvironment.transform 5 16 env53541 = env53542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env53541 == env53542) = true)

theorem identity53542 : scanCanonicalize (H12AffineFastState.compose env53542 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 137353) := by decide +kernel

theorem selectedBound53542 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env53543 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,137353,136192,32769,4096,61569,147473,58519,143497,20496,120867,148668,148669,96267,90263,204947,172,74799,1212,135680]

theorem envBound53543 : H12AffineFastState.Bounded env53543 := by
  intro p hp
  have h : env53543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53542_53543 : H12AffineEnvironment.transform 17 137353 env53542 = env53543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137353 env53542 == env53543) = true)

theorem identity53543 : scanCanonicalize (H12AffineFastState.compose env53543 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(16+1) ^^^ 62492) := by decide +kernel

theorem selectedBound53543 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env53544 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,62492,60565,57372,32769,4096,61569,46093,58519,50325,20496,120867,45216,45217,96267,90263,119951,172,74799,1212,58908]

theorem envBound53544 : H12AffineFastState.Bounded env53544 := by
  intro p hp
  have h : env53544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53543_53544 : H12AffineEnvironment.transform 16 62492 env53543 = env53544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 62492 env53543 == env53544) = true)

theorem identity53544 : scanCanonicalize (H12AffineFastState.compose env53544 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 5125) := by decide +kernel

theorem selectedBound53544 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env53545 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,5125,32768,65536,40985,47248,46105,32769,4096,42116,46093,45202,37008,1045,101414,45216,45217,76814,78994,98442,172,74799,1212,45593]

theorem envBound53545 : H12AffineFastState.Bounded env53545 := by
  intro p hp
  have h : env53545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53544_53545 : H12AffineEnvironment.transform 13 5125 env53544 = env53545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5125 env53544 == env53545) = true)

theorem identity53545 : scanCanonicalize (H12AffineFastState.compose env53545 (packedSelected [0,1,2,4,6,7,8,9,13,18,19,23] rootPS)) = affineNative (2^(14+1) ^^^ 3724) := by decide +kernel

theorem selectedBound53545 : packedSelected [0,1,2,4,6,7,8,9,13,18,19,23] rootPS < 2^1333 := by decide +kernel

def env53546 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,5125,3724,65536,11925,13852,14997,3725,4096,10760,14977,15902,7708,1045,66218,15916,15917,76814,78994,69126,172,74799,1212,15509]

theorem envBound53546 : H12AffineFastState.Bounded env53546 := by
  intro p hp
  have h : env53546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53545_53546 : H12AffineEnvironment.transform 14 3724 env53545 = env53546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3724 env53545 == env53546) = true)

theorem identity53546 : scanCanonicalize (H12AffineFastState.compose env53546 (packedSelected [0,1,2,4,6,7,8,9,13,17,21,26] rootPS)) = affineNative (2^(15+1) ^^^ 2731) := by decide +kernel

theorem selectedBound53546 : packedSelected [0,1,2,4,6,7,8,9,13,17,21,26] rootPS < 2^1333 := by decide +kernel

def env53547 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,5125,3724,2731,11925,13852,14997,3725,4096,10760,14977,15902,7708,1045,2049,15916,15917,9893,15929,1197,172,11908,1212,15509]

theorem envBound53547 : H12AffineFastState.Bounded env53547 := by
  intro p hp
  have h : env53547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53546_53547 : H12AffineEnvironment.transform 15 2731 env53546 = env53547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2731 env53546 == env53547) = true)

theorem identity53547 : scanCanonicalize (H12AffineFastState.compose env53547 (packedSelected [3,5,6,10,11,12,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 7708) := by decide +kernel

theorem selectedBound53547 : packedSelected [3,5,6,10,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env53548 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,7708,5125,3724,2731,4233,2048,1161,3725,4096,5140,1181,2,7708,1045,2049,48,49,6329,37,1197,172,4248,1212,649]

theorem envBound53548 : H12AffineFastState.Bounded env53548 := by
  intro p hp
  have h : env53548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53547_53548 : H12AffineEnvironment.transform 12 7708 env53547 = env53548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7708 env53547 == env53548) = true)

theorem identity53548 : scanCanonicalize (H12AffineFastState.compose env53548 (packedSelected [0,2,3,4,6,7,8,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 1703) := by decide +kernel

theorem selectedBound53548 : packedSelected [0,2,3,4,6,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env53549 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,1703,2235,674,3724,2731,1582,2048,1161,3725,1703,691,1181,2,2235,1045,2049,48,49,3614,37,1197,172,1599,1212,649]

theorem envBound53549 : H12AffineFastState.Bounded env53549 := by
  intro p hp
  have h : env53549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53548_53549 : H12AffineEnvironment.transform 11 1703 env53548 = env53549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1703 env53548 == env53549) = true)

theorem identity53549 : scanCanonicalize (H12AffineFastState.compose env53549 (packedSelected [0,1,3,5,8,9,12] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound53549 : packedSelected [0,1,3,5,8,9,12] rootPS < 2^1333 := by decide +kernel

def env53550 : List Nat := [2,4,8,16,32,16,128,173,1,1024,2048,1190,2235,163,3213,2218,1071,2048,1161,3212,1190,178,1181,2,2235,1045,2049,48,49,3103,37,1197,172,1086,1212,136]

theorem envBound53550 : H12AffineFastState.Bounded env53550 := by
  intro p hp
  have h : env53550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53549_53550 : H12AffineEnvironment.transform 8 1 env53549 = env53550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env53549 == env53550) = true)

theorem identity53550 : scanCanonicalize (H12AffineFastState.compose env53550 (packedSelected [1,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 150) := by decide +kernel

theorem selectedBound53550 : packedSelected [1,5,6] rootPS < 2^1333 := by decide +kernel

def env53551 : List Nat := [2,4,8,16,32,16,128,173,1,150,2048,48,2235,163,2075,2218,185,2048,31,2074,48,178,11,2,2235,131,2049,48,49,2185,37,59,172,168,42,136]

theorem envBound53551 : H12AffineFastState.Bounded env53551 := by
  intro p hp
  have h : env53551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53550_53551 : H12AffineEnvironment.transform 9 150 env53550 = env53551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 150 env53550 == env53551) = true)

theorem identity53551 : scanCanonicalize (H12AffineFastState.compose env53551 (packedSelected [2,4,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound53551 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env53552 : List Nat := [2,4,8,10,32,10,128,173,1,140,2048,42,2209,163,2049,2218,163,2048,5,2048,42,168,11,2,2209,131,2049,42,43,2185,37,33,172,168,42,136]

theorem envBound53552 : H12AffineFastState.Bounded env53552 := by
  intro p hp
  have h : env53552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53551_53552 : H12AffineEnvironment.transform 3 10 env53551 = env53552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env53551 == env53552) = true)

theorem identity53552 : scanCanonicalize (H12AffineFastState.compose env53552 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 37) := by decide +kernel

theorem selectedBound53552 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env53553 : List Nat := [2,4,8,10,32,10,37,8,1,41,2048,42,2052,6,2049,2063,6,2048,5,2048,42,13,11,2,2052,38,2049,42,43,2092,37,33,9,13,42,45]

theorem envBound53553 : H12AffineFastState.Bounded env53553 := by
  intro p hp
  have h : env53553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53552_53553 : H12AffineEnvironment.transform 6 37 env53552 = env53553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 37 env53552 == env53553) = true)

theorem identity53553 : scanCanonicalize (H12AffineFastState.compose env53553 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 7) := by decide +kernel

theorem selectedBound53553 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env53554 : List Nat := [2,4,8,10,32,10,37,8,1,41,7,42,3,6,6,8,6,7,5,7,42,13,11,2,3,38,6,42,43,43,37,33,9,13,42,45]

theorem envBound53554 : H12AffineFastState.Bounded env53554 := by
  intro p hp
  have h : env53554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53553_53554 : H12AffineEnvironment.transform 10 7 env53553 = env53554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 7 env53553 == env53554) = true)

theorem identity53554 : scanCanonicalize (H12AffineFastState.compose env53554 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound53554 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env53555 : List Nat := [2,4,8,10,12,10,9,8,1,5,7,6,3,6,6,8,6,7,5,7,6,13,11,2,3,10,6,6,7,7,9,13,9,13,6,1]

theorem envBound53555 : H12AffineFastState.Bounded env53555 := by
  intro p hp
  have h : env53555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53554_53555 : H12AffineEnvironment.transform 4 12 env53554 = env53555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env53554 == env53555) = true)

def env53556 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147472,58519,143497,20496,508075,148669,148668,96266,90263,204946,172,74799,1213,135680]

theorem envBound53556 : H12AffineFastState.Bounded env53556 := by
  intro p hp
  have h : env53556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53541_53556 : H12AffineEnvironment.transform 5 17 env53541 = env53556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53541 == env53556) = true)

theorem identity53556 : scanCanonicalize (H12AffineFastState.compose env53556 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 45217) := by decide +kernel

theorem selectedBound53556 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env53557 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,45217,262144,42145,32769,4096,61568,61617,58519,32808,20496,356362,62492,62493,96266,90263,102451,172,74799,1213,41633]

theorem envBound53557 : H12AffineFastState.Bounded env53557 := by
  intro p hp
  have h : env53557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53556_53557 : H12AffineEnvironment.transform 16 45217 env53556 = env53557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45217 env53556 == env53557) = true)

theorem identity53557 : scanCanonicalize (H12AffineFastState.compose env53557 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound53557 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env53558 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,45217,2184,42145,32769,4096,61568,61617,58519,32808,20496,96386,62492,62493,96266,90263,102451,172,74799,1213,41633]

theorem envBound53558 : H12AffineFastState.Bounded env53558 := by
  intro p hp
  have h : env53558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53557_53558 : H12AffineEnvironment.transform 17 2184 env53557 = env53558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env53557 == env53558) = true)

theorem identity53558 : scanCanonicalize (H12AffineFastState.compose env53558 (packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 33830) := by decide +kernel

theorem selectedBound53558 : packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env53559 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,33830,45217,2184,42145,32769,4096,61568,61617,58519,32808,20496,64676,62492,62493,64556,58545,5141,172,40969,1213,41633]

theorem envBound53559 : H12AffineFastState.Bounded env53559 := by
  intro p hp
  have h : env53559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53558_53559 : H12AffineEnvironment.transform 15 33830 env53558 = env53559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33830 env53558 == env53559) = true)

theorem identity53559 : scanCanonicalize (H12AffineFastState.compose env53559 (packedSelected [1,4,5,8,9,16,17,21,24] rootPS)) = affineNative (2^(14+1) ^^^ 12312) := by decide +kernel

theorem selectedBound53559 : packedSelected [1,4,5,8,9,16,17,21,24] rootPS < 2^1333 := by decide +kernel

def env53560 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,12312,13374,185,2184,5305,12313,4096,16536,16553,21647,12336,20496,19644,17412,17413,19508,21673,5141,172,4113,1213,4793]

theorem envBound53560 : H12AffineFastState.Bounded env53560 := by
  intro p hp
  have h : env53560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53559_53560 : H12AffineEnvironment.transform 14 12312 env53559 = env53560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12312 env53559 == env53560) = true)

theorem identity53560 : scanCanonicalize (H12AffineFastState.compose env53560 (packedSelected [0,6,7,11,13,16] rootPS)) = affineNative (2^(12+1) ^^^ 3237) := by decide +kernel

theorem selectedBound53560 : packedSelected [0,6,7,11,13,16] rootPS < 2^1333 := by decide +kernel

def env53561 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,3237,16384,7357,6299,185,2184,5305,7356,4096,16536,16553,21647,7317,20496,19644,17412,17413,19508,21673,5141,172,4113,1213,4793]

theorem envBound53561 : H12AffineFastState.Bounded env53561 := by
  intro p hp
  have h : env53561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53560_53561 : H12AffineEnvironment.transform 12 3237 env53560 = env53561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3237 env53560 == env53561) = true)

theorem identity53561 : scanCanonicalize (H12AffineFastState.compose env53561 (packedSelected [2,3,5,6,10,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 1540) := by decide +kernel

theorem selectedBound53561 : packedSelected [2,3,5,6,10,15,17] rootPS < 2^1333 := by decide +kernel

def env53562 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,3237,1540,7357,6299,185,2184,5305,7356,4096,1692,1709,4747,7317,5652,2744,512,513,2608,4781,5141,172,4113,1213,4793]

theorem envBound53562 : H12AffineFastState.Bounded env53562 := by
  intro p hp
  have h : env53562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53561_53562 : H12AffineEnvironment.transform 13 1540 env53561 = env53562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1540 env53561 == env53562) = true)

theorem identity53562 : scanCanonicalize (H12AffineFastState.compose env53562 (packedSelected [0,1,2,3,5,7,8,10,11,12,13] rootPS)) = affineNative (2^(10+1) ^^^ 1676) := by decide +kernel

theorem selectedBound53562 : packedSelected [0,1,2,3,5,7,8,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env53563 : List Nat := [2,4,8,16,32,17,128,173,512,1024,1676,4096,553,1540,4657,5655,185,1540,5305,4656,4096,1692,1709,4747,4633,5652,1076,512,513,1212,4781,5141,172,4113,1213,4793]

theorem envBound53563 : H12AffineFastState.Bounded env53563 := by
  intro p hp
  have h : env53563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53562_53563 : H12AffineEnvironment.transform 10 1676 env53562 = env53563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1676 env53562 == env53563) = true)

theorem identity53563 : scanCanonicalize (H12AffineFastState.compose env53563 (packedSelected [0,1,2,4,5,10] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound53563 : packedSelected [0,1,2,4,5,10] rootPS < 2^1333 := by decide +kernel

def env53564 : List Nat := [2,4,8,16,11,17,128,134,512,1024,1676,4096,514,1540,4634,5655,146,1540,5266,4635,4096,1692,1670,4747,4633,5652,1055,512,513,1175,4742,5141,135,4113,1174,4754]

theorem envBound53564 : H12AffineFastState.Bounded env53564 := by
  intro p hp
  have h : env53564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53563_53564 : H12AffineEnvironment.transform 4 11 env53563 = env53564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env53563 == env53564) = true)

theorem identity53564 : scanCanonicalize (H12AffineFastState.compose env53564 (packedSelected [0,2,3,5,6,7,11] rootPS)) = affineNative (2^(9+1) ^^^ 543) := by decide +kernel

theorem selectedBound53564 : packedSelected [0,2,3,5,6,7,11] rootPS < 2^1333 := by decide +kernel

def env53565 : List Nat := [2,4,8,16,11,17,128,134,512,543,147,4096,514,27,4634,4104,146,27,4749,4635,4096,131,153,4747,4633,4107,512,512,513,648,4742,4618,135,4113,649,4754]

theorem envBound53565 : H12AffineFastState.Bounded env53565 := by
  intro p hp
  have h : env53565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53564_53565 : H12AffineEnvironment.transform 9 543 env53564 = env53565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 543 env53564 == env53565) = true)

theorem identity53565 : scanCanonicalize (H12AffineFastState.compose env53565 (packedSelected [3,5] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound53565 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env53566 : List Nat := [2,4,8,16,11,17,19,21,512,543,0,4096,514,27,4634,4104,1,27,4638,4635,4096,16,10,4632,4633,4107,512,512,513,539,4629,4618,20,4113,538,4609]

theorem envBound53566 : H12AffineFastState.Bounded env53566 := by
  intro p hp
  have h : env53566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53565_53566 : H12AffineEnvironment.transform 6 19 env53565 = env53566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env53565 == env53566) = true)

theorem identity53566 : scanCanonicalize (H12AffineFastState.compose env53566 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound53566 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env53567 : List Nat := [2,4,8,10,11,11,9,15,512,517,0,4096,514,1,4608,4104,1,1,4612,4609,4096,10,10,4610,4611,4107,512,512,513,513,4623,4618,14,4107,512,4609]

theorem envBound53567 : H12AffineFastState.Bounded env53567 := by
  intro p hp
  have h : env53567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53566_53567 : H12AffineEnvironment.transform 3 10 env53566 = env53567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env53566 == env53567) = true)

def env53568 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147521,58683,143496,20497,508155,148801,148801,96347,90427,205166,257,74799,1345,135681]

theorem envBound53568 : H12AffineFastState.Bounded env53568 := by
  intro p hp
  have h : env53568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53511_53568 : H12AffineEnvironment.transform 18 136193 env53511 = env53568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136193 env53511 == env53568) = true)

def env53569 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147521,58519,143496,20497,508155,148717,148717,96347,90263,204994,173,74799,1261,135681]

theorem envBound53569 : H12AffineFastState.Bounded env53569 := by
  intro p hp
  have h : env53569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53568_53569 : H12AffineEnvironment.transform 7 172 env53568 = env53569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env53568 == env53569) = true)

def env53570 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147473,58519,143496,20497,508075,148669,148669,96267,90263,204946,173,74799,1213,135681]

theorem envBound53570 : H12AffineFastState.Bounded env53570 := by
  intro p hp
  have h : env53570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53569_53570 : H12AffineEnvironment.transform 5 16 env53569 = env53570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env53569 == env53570) = true)

theorem identity53570 : scanCanonicalize (H12AffineFastState.compose env53570 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 99486) := by decide +kernel

theorem selectedBound53570 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env53571 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,99486,262144,102559,32769,4096,61569,115855,58519,111638,20497,279605,114723,114723,96267,90263,41996,173,74799,1213,104095]

theorem envBound53571 : H12AffineFastState.Bounded env53571 := by
  intro p hp
  have h : env53571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53570_53571 : H12AffineEnvironment.transform 16 99486 env53570 = env53571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 99486 env53570 == env53571) = true)

theorem identity53571 : scanCanonicalize (H12AffineFastState.compose env53571 (packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 24634) := by decide +kernel

theorem selectedBound53571 : packedSelected [1,3,5,8,10,16,17,18,19,20,21,23] rootPS < 2^1333 := by decide +kernel

def env53572 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,24634,58532,262144,61605,32769,4096,61569,42165,58519,54316,20497,279605,40985,40985,6193,173,41996,173,17429,1213,63141]

theorem envBound53572 : H12AffineFastState.Bounded env53572 := by
  intro p hp
  have h : env53572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53571_53572 : H12AffineEnvironment.transform 15 24634 env53571 = env53572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24634 env53571 == env53572) = true)

theorem identity53572 : scanCanonicalize (H12AffineFastState.compose env53572 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 29861) := by decide +kernel

theorem selectedBound53572 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env53573 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,29861,24634,4097,262144,1024,29860,4096,1060,20496,4146,8329,20497,279605,21692,21692,6193,173,20649,173,17429,1213,512]

theorem envBound53573 : H12AffineFastState.Bounded env53573 := by
  intro p hp
  have h : env53573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53572_53573 : H12AffineEnvironment.transform 14 29861 env53572 = env53573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29861 env53572 == env53573) = true)

theorem identity53573 : scanCanonicalize (H12AffineFastState.compose env53573 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound53573 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env53574 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1212,12313,9350,4097,262144,1024,12312,4096,1060,5292,4146,8329,5293,262281,4096,4096,6193,173,5141,173,169,1213,512]

theorem envBound53574 : H12AffineFastState.Bounded env53574 := by
  intro p hp
  have h : env53574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53573_53574 : H12AffineEnvironment.transform 13 1212 env53573 = env53574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env53573 == env53574) = true)

theorem identity53574 : scanCanonicalize (H12AffineFastState.compose env53574 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 657) := by decide +kernel

theorem selectedBound53574 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env53575 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,657,1212,4744,1559,4097,262144,1024,4745,4096,1060,5292,4146,536,5293,262281,4096,4096,6193,173,5141,173,169,1213,512]

theorem envBound53575 : H12AffineFastState.Bounded env53575 := by
  intro p hp
  have h : env53575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53574_53575 : H12AffineEnvironment.transform 12 657 env53574 = env53575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 657 env53574 == env53575) = true)

theorem identity53575 : scanCanonicalize (H12AffineFastState.compose env53575 (packedSelected [1,3,13] rootPS)) = affineNative (2^(11+1) ^^^ 1212) := by decide +kernel

theorem selectedBound53575 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env53576 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,1212,657,1212,1588,1559,1213,262144,1024,1589,1212,1060,16,1166,536,17,262281,1212,1212,3213,173,169,173,169,1213,512]

theorem envBound53576 : H12AffineFastState.Bounded env53576 := by
  intro p hp
  have h : env53576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53575_53576 : H12AffineEnvironment.transform 11 1212 env53575 = env53576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1212 env53575 == env53576) = true)

theorem identity53576 : scanCanonicalize (H12AffineFastState.compose env53576 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 555) := by decide +kernel

theorem selectedBound53576 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env53577 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,1212,657,1212,1588,1559,1213,555,1024,1589,1212,1060,16,1166,536,17,674,1212,1212,3213,173,169,173,169,1213,512]

theorem envBound53577 : H12AffineFastState.Bounded env53577 := by
  intro p hp
  have h : env53577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53576_53577 : H12AffineEnvironment.transform 17 555 env53576 = env53577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 555 env53576 == env53577) = true)

def env53578 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147472,58519,143496,20497,508074,148668,148668,96266,90263,204947,173,74799,1212,135681]

theorem envBound53578 : H12AffineFastState.Bounded env53578 := by
  intro p hp
  have h : env53578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53569_53578 : H12AffineEnvironment.transform 5 17 env53569 = env53578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53569 == env53578) = true)

theorem identity53578 : scanCanonicalize (H12AffineFastState.compose env53578 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 208055) := by decide +kernel

theorem selectedBound53578 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env53579 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,208055,136193,32769,4096,61568,147472,58519,143496,20497,60445,148668,148668,96266,90263,204947,173,74799,1212,135681]

theorem envBound53579 : H12AffineFastState.Bounded env53579 := by
  intro p hp
  have h : env53579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53578_53579 : H12AffineEnvironment.transform 17 208055 env53578 = env53579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 208055 env53578 == env53579) = true)

theorem identity53579 : scanCanonicalize (H12AffineFastState.compose env53579 (packedSelected [1,3,5,7,8,10,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound53579 : packedSelected [1,3,5,7,8,10,20,26,27] rootPS < 2^1333 := by decide +kernel

def env53580 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,53282,131072,195733,136193,32769,4096,61568,147472,58519,143496,20497,60445,148668,148668,43048,45237,192689,173,62477,1212,135681]

theorem envBound53580 : H12AffineFastState.Bounded env53580 := by
  intro p hp
  have h : env53580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53579_53580 : H12AffineEnvironment.transform 15 53282 env53579 = env53580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env53579 == env53580) = true)

theorem identity53580 : scanCanonicalize (H12AffineFastState.compose env53580 (packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 21693) := by decide +kernel

theorem selectedBound53580 : packedSelected [1,3,4,5,8,9,10,16,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env53581 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,53282,21693,43048,16572,32769,4096,61568,5293,58519,25653,20497,60445,4097,4097,43048,45237,41996,173,62477,1212,18108]

theorem envBound53581 : H12AffineFastState.Bounded env53581 := by
  intro p hp
  have h : env53581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53580_53581 : H12AffineEnvironment.transform 16 21693 env53580 = env53581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21693 env53580 == env53581) = true)

theorem identity53581 : scanCanonicalize (H12AffineFastState.compose env53581 (packedSelected [4,9,20] rootPS)) = affineNative (2^(14+1) ^^^ 29860) := by decide +kernel

theorem selectedBound53581 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env53582 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,29860,9350,21693,23692,16572,29861,4096,1060,5293,4147,25653,20497,6329,4097,4097,23692,17425,20648,173,169,1212,18108]

theorem envBound53582 : H12AffineFastState.Bounded env53582 := by
  intro p hp
  have h : env53582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53581_53582 : H12AffineEnvironment.transform 14 29860 env53581 = env53582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29860 env53581 == env53582) = true)

theorem identity53582 : scanCanonicalize (H12AffineFastState.compose env53582 (packedSelected [0,2,3,5,6,9,11,13,17] rootPS)) = affineNative (2^(12+1) ^^^ 672) := by decide +kernel

theorem selectedBound53582 : packedSelected [0,2,3,5,6,9,11,13,17] rootPS < 2^1333 := by decide +kernel

def env53583 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,672,16384,22020,1574,21693,23692,16572,22021,4096,1060,5293,4147,18069,20497,6329,4097,4097,23692,17425,20648,173,169,1212,18108]

theorem envBound53583 : H12AffineFastState.Bounded env53583 := by
  intro p hp
  have h : env53583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53582_53583 : H12AffineEnvironment.transform 12 672 env53582 = env53583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 672 env53582 == env53583) = true)

theorem identity53583 : scanCanonicalize (H12AffineFastState.compose env53583 (packedSelected [1,3,6,7,9,11,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 1175) := by decide +kernel

theorem selectedBound53583 : packedSelected [1,3,6,7,9,11,13,15] rootPS < 2^1333 := by decide +kernel

def env53584 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1175,4096,672,16384,22020,1574,21693,20507,16572,22021,4096,1060,5293,4147,18069,20497,5166,4097,4097,20507,17425,20648,173,169,1212,18108]

theorem envBound53584 : H12AffineFastState.Bounded env53584 := by
  intro p hp
  have h : env53584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53583_53584 : H12AffineEnvironment.transform 10 1175 env53583 = env53584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1175 env53583 == env53584) = true)

theorem identity53584 : scanCanonicalize (H12AffineFastState.compose env53584 (packedSelected [1,3,13] rootPS)) = affineNative (2^(13+1) ^^^ 136) := by decide +kernel

theorem selectedBound53584 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env53585 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1175,4096,672,136,5772,1574,5173,4243,52,5773,4096,1060,5293,4147,1565,4249,5166,4097,4097,4243,1177,4128,173,169,1212,1588]

theorem envBound53585 : H12AffineFastState.Bounded env53585 := by
  intro p hp
  have h : env53585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53584_53585 : H12AffineEnvironment.transform 13 136 env53584 = env53585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 136 env53584 == env53585) = true)

theorem identity53585 : scanCanonicalize (H12AffineFastState.compose env53585 (packedSelected [1,4,6,7,8,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 674) := by decide +kernel

theorem selectedBound53585 : packedSelected [1,4,6,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env53586 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1175,674,672,136,1070,1574,1687,561,52,1071,674,1060,1551,657,1565,571,1676,675,675,561,1177,642,173,169,1212,1588]

theorem envBound53586 : H12AffineFastState.Bounded env53586 := by
  intro p hp
  have h : env53586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53585_53586 : H12AffineEnvironment.transform 11 674 env53585 = env53586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 674 env53585 == env53586) = true)

theorem identity53586 : scanCanonicalize (H12AffineFastState.compose env53586 (packedSelected [4,6,7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound53586 : packedSelected [4,6,7] rootPS < 2^1333 := by decide +kernel

def env53587 : List Nat := [2,4,8,16,10,17,128,134,512,1024,1175,648,650,136,1028,1548,1687,539,30,1029,648,1038,1551,657,1565,529,1676,649,649,539,1177,642,135,131,1174,1566]

theorem envBound53587 : H12AffineFastState.Bounded env53587 := by
  intro p hp
  have h : env53587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53586_53587 : H12AffineEnvironment.transform 4 10 env53586 = env53587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env53586 == env53587) = true)

theorem identity53587 : scanCanonicalize (H12AffineFastState.compose env53587 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 663) := by decide +kernel

theorem selectedBound53587 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53588 : List Nat := [2,4,8,16,10,17,128,134,512,663,512,648,650,136,659,155,0,539,30,658,648,665,152,657,138,529,27,649,649,539,526,642,135,131,513,137]

theorem envBound53588 : H12AffineFastState.Bounded env53588 := by
  intro p hp
  have h : env53588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53587_53588 : H12AffineEnvironment.transform 9 663 env53587 = env53588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 663 env53587 == env53588) = true)

theorem identity53588 : scanCanonicalize (H12AffineFastState.compose env53588 (packedSelected [3,6,8] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound53588 : packedSelected [3,6,8] rootPS < 2^1333 := by decide +kernel

def env53589 : List Nat := [2,4,8,16,10,17,128,134,26,141,26,146,144,136,137,155,0,1,30,136,146,131,152,139,138,11,27,147,147,1,20,152,135,131,27,137]

theorem envBound53589 : H12AffineFastState.Bounded env53589 := by
  intro p hp
  have h : env53589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53588_53589 : H12AffineEnvironment.transform 8 26 env53588 = env53589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env53588 == env53589) = true)

theorem identity53589 : scanCanonicalize (H12AffineFastState.compose env53589 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound53589 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env53590 : List Nat := [2,4,8,16,10,17,14,8,26,3,26,28,30,6,7,21,0,1,30,6,28,13,22,5,4,11,27,29,29,1,20,22,9,13,27,7]

theorem envBound53590 : H12AffineFastState.Bounded env53590 := by
  intro p hp
  have h : env53590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53589_53590 : H12AffineEnvironment.transform 6 14 env53589 = env53590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env53589 == env53590) = true)

theorem identity53590 : scanCanonicalize (H12AffineFastState.compose env53590 (packedSelected [1,6] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound53590 : packedSelected [1,6] rootPS < 2^1333 := by decide +kernel

def env53591 : List Nat := [2,4,8,10,10,11,14,8,0,3,0,6,4,6,7,15,0,1,4,6,6,13,12,5,4,11,1,7,7,1,14,12,9,13,1,7]

theorem envBound53591 : H12AffineFastState.Bounded env53591 := by
  intro p hp
  have h : env53591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53590_53591 : H12AffineEnvironment.transform 3 10 env53590 = env53591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env53590 == env53591) = true)

theorem identity53591 : scanCanonicalize (H12AffineFastState.compose env53591 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound53591 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53592 : List Nat := [2,2,8,10,10,11,8,8,0,3,0,0,2,0,1,9,0,1,2,0,0,11,10,3,2,11,1,1,1,1,8,10,9,11,1,1]

theorem envBound53592 : H12AffineFastState.Bounded env53592 := by
  intro p hp
  have h : env53592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53591_53592 : H12AffineEnvironment.transform 1 2 env53591 = env53592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env53591 == env53592) = true)

theorem identity53592 : scanCanonicalize (H12AffineFastState.compose env53592 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound53592 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53593 : List Nat := [2,2,0,2,2,3,0,0,0,3,0,0,2,0,1,1,0,1,2,0,0,3,2,3,2,3,1,1,1,1,0,2,1,3,1,1]

theorem envBound53593 : H12AffineFastState.Bounded env53593 := by
  intro p hp
  have h : env53593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53592_53593 : H12AffineEnvironment.transform 2 0 env53592 = env53593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env53592 == env53593) = true)

theorem identity53593 : scanCanonicalize (H12AffineFastState.compose env53593 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound53593 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env53594 : List Nat := [0,0,0,0,0,1,0,0,0,1,0,0,0,0,1,1,0,1,0,0,0,1,0,1,0,1,1,1,1,1,0,0,1,1,1,1]

theorem envBound53594 : H12AffineFastState.Bounded env53594 := by
  intro p hp
  have h : env53594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53593_53594 : H12AffineEnvironment.transform 0 0 env53593 = env53594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env53593 == env53594) = true)

def env53595 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61649,147521,58518,143496,20497,508155,148716,148716,96347,90262,204995,172,74799,1260,135681]

theorem envBound53595 : H12AffineFastState.Bounded env53595 := by
  intro p hp
  have h : env53595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53568_53595 : H12AffineEnvironment.transform 7 173 env53568 = env53595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env53568 == env53595) = true)

def env53596 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61569,147473,58518,143496,20497,508075,148668,148668,96267,90262,204947,172,74799,1212,135681]

theorem envBound53596 : H12AffineFastState.Bounded env53596 := by
  intro p hp
  have h : env53596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53595_53596 : H12AffineEnvironment.transform 5 16 env53595 = env53596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env53595 == env53596) = true)

theorem identity53596 : scanCanonicalize (H12AffineFastState.compose env53596 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound53596 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env53597 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,45216,262144,42145,32769,4096,61569,61617,58518,32808,20497,356363,62492,62492,96267,90262,102451,172,74799,1212,41633]

theorem envBound53597 : H12AffineFastState.Bounded env53597 := by
  intro p hp
  have h : env53597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53596_53597 : H12AffineEnvironment.transform 16 45216 env53596 = env53597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env53596 == env53597) = true)

theorem identity53597 : scanCanonicalize (H12AffineFastState.compose env53597 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound53597 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env53598 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,45216,2184,42145,32769,4096,61569,61617,58518,32808,20497,96387,62492,62492,96267,90262,102451,172,74799,1212,41633]

theorem envBound53598 : H12AffineFastState.Bounded env53598 := by
  intro p hp
  have h : env53598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53597_53598 : H12AffineEnvironment.transform 17 2184 env53597 = env53598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env53597 == env53598) = true)

theorem identity53598 : scanCanonicalize (H12AffineFastState.compose env53598 (packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS)) = affineNative (2^(15+1) ^^^ 33831) := by decide +kernel

theorem selectedBound53598 : packedSelected [1,3,5,8,10,17,18,19,21,23] rootPS < 2^1333 := by decide +kernel

def env53599 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,33831,45216,2184,42145,32769,4096,61569,61617,58518,32808,20497,64676,62492,62492,64556,58545,5140,172,40968,1212,41633]

theorem envBound53599 : H12AffineFastState.Bounded env53599 := by
  intro p hp
  have h : env53599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53598_53599 : H12AffineEnvironment.transform 15 33831 env53598 = env53599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33831 env53598 == env53599) = true)

theorem identity53599 : scanCanonicalize (H12AffineFastState.compose env53599 (packedSelected [1,4,5,8,9,16,17,21,24] rootPS)) = affineNative (2^(14+1) ^^^ 12313) := by decide +kernel

theorem selectedBound53599 : packedSelected [1,4,5,8,9,16,17,21,24] rootPS < 2^1333 := by decide +kernel

def env53600 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,12313,13374,185,2184,5304,12312,4096,16536,16552,21647,12337,20497,19645,17413,17413,19509,21672,5140,172,4113,1212,4792]

theorem envBound53600 : H12AffineFastState.Bounded env53600 := by
  intro p hp
  have h : env53600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53599_53600 : H12AffineEnvironment.transform 14 12313 env53599 = env53600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12313 env53599 == env53600) = true)

theorem identity53600 : scanCanonicalize (H12AffineFastState.compose env53600 (packedSelected [0,6,7,11,13,16] rootPS)) = affineNative (2^(13+1) ^^^ 10265) := by decide +kernel

theorem selectedBound53600 : packedSelected [0,6,7,11,13,16] rootPS < 2^1333 := by decide +kernel

def env53601 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,10265,12313,13374,185,2184,5304,12312,4096,10369,10417,15510,12337,14344,9380,11292,11292,9260,15537,5140,172,4113,1212,4792]

theorem envBound53601 : H12AffineFastState.Bounded env53601 := by
  intro p hp
  have h : env53601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53600_53601 : H12AffineEnvironment.transform 13 10265 env53600 = env53601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10265 env53600 == env53601) = true)

theorem identity53601 : scanCanonicalize (H12AffineFastState.compose env53601 (packedSelected [2,3,5,6,10,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 7844) := by decide +kernel

theorem selectedBound53601 : packedSelected [2,3,5,6,10,15,17] rootPS < 2^1333 := by decide +kernel

def env53602 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,7844,5821,3773,2714,185,2184,5304,3772,4096,5669,5653,562,3733,1708,6656,4792,4792,6792,533,5140,172,4113,1212,4792]

theorem envBound53602 : H12AffineFastState.Bounded env53602 := by
  intro p hp
  have h : env53602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53601_53602 : H12AffineEnvironment.transform 12 7844 env53601 = env53602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7844 env53601 == env53602) = true)

theorem identity53602 : scanCanonicalize (H12AffineFastState.compose env53602 (packedSelected [0,1,2,3,5,7,8,10,11,12,13] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound53602 : packedSelected [0,1,2,3,5,7,8,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env53603 : List Nat := [2,4,8,16,32,16,128,173,512,1024,1076,4096,4752,5821,649,1710,185,1212,5304,648,4096,5669,5653,562,673,1708,5684,4792,4792,5820,533,5140,172,4113,1212,4792]

theorem envBound53603 : H12AffineFastState.Bounded env53603 := by
  intro p hp
  have h : env53603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53602_53603 : H12AffineEnvironment.transform 10 1076 env53602 = env53603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env53602 == env53603) = true)

theorem identity53603 : scanCanonicalize (H12AffineFastState.compose env53603 (packedSelected [1,3,4,6,7,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 1702) := by decide +kernel

theorem selectedBound53603 : packedSelected [1,3,4,6,7,10,11] rootPS < 2^1333 := by decide +kernel

def env53604 : List Nat := [2,4,8,16,32,16,128,173,512,1024,1076,1702,1078,27,649,1710,185,1212,542,648,1702,131,179,562,673,1708,146,1054,1054,26,533,690,172,1719,1212,1054]

theorem envBound53604 : H12AffineFastState.Bounded env53604 := by
  intro p hp
  have h : env53604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53603_53604 : H12AffineEnvironment.transform 11 1702 env53603 = env53604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1702 env53603 == env53604) = true)

theorem identity53604 : scanCanonicalize (H12AffineFastState.compose env53604 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 679) := by decide +kernel

theorem selectedBound53604 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env53605 : List Nat := [2,4,8,16,32,16,128,173,512,679,659,1,657,27,649,9,185,539,542,648,1,131,179,562,673,11,146,697,697,26,533,690,172,16,539,697]

theorem envBound53605 : H12AffineFastState.Bounded env53605 := by
  intro p hp
  have h : env53605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53604_53605 : H12AffineEnvironment.transform 9 679 env53604 = env53605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 679 env53604 == env53605) = true)

theorem identity53605 : scanCanonicalize (H12AffineFastState.compose env53605 (packedSelected [2,3,7,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound53605 : packedSelected [2,3,7,8,9] rootPS < 2^1333 := by decide +kernel

def env53606 : List Nat := [2,4,8,16,32,16,57,20,512,542,554,1,552,27,560,9,0,539,542,561,1,58,10,562,536,11,43,512,512,26,533,523,21,16,539,512]

theorem envBound53606 : H12AffineFastState.Bounded env53606 := by
  intro p hp
  have h : env53606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53605_53606 : H12AffineEnvironment.transform 6 57 env53605 = env53606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env53605 == env53606) = true)

theorem identity53606 : scanCanonicalize (H12AffineFastState.compose env53606 (packedSelected [0,1,2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound53606 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env53607 : List Nat := [2,4,8,16,17,16,8,20,512,542,539,1,537,27,513,9,0,539,542,512,1,11,10,515,536,11,26,512,512,26,533,523,21,16,539,512]

theorem envBound53607 : H12AffineFastState.Bounded env53607 := by
  intro p hp
  have h : env53607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53606_53607 : H12AffineEnvironment.transform 4 17 env53606 = env53607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env53606 == env53607) = true)

theorem identity53607 : scanCanonicalize (H12AffineFastState.compose env53607 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound53607 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env53608 : List Nat := [2,4,8,11,10,11,8,15,512,517,512,1,514,0,513,9,0,512,517,512,1,11,10,515,515,11,1,512,512,1,526,523,14,11,512,512]

theorem envBound53608 : H12AffineFastState.Bounded env53608 := by
  intro p hp
  have h : env53608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53607_53608 : H12AffineEnvironment.transform 3 11 env53607 = env53608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env53607 == env53608) = true)

theorem identity53608 : scanCanonicalize (H12AffineFastState.compose env53608 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound53608 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env53609 : List Nat := [2,4,8,11,10,11,8,15,1,4,1,1,3,0,0,9,0,1,4,1,1,11,10,2,2,11,1,1,1,1,15,10,14,11,1,1]

theorem envBound53609 : H12AffineFastState.Bounded env53609 := by
  intro p hp
  have h : env53609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53608_53609 : H12AffineEnvironment.transform 8 1 env53608 = env53609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env53608 == env53609) = true)

theorem identity53609 : scanCanonicalize (H12AffineFastState.compose env53609 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound53609 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53610 : List Nat := [2,4,5,6,7,6,5,2,1,4,1,1,3,0,0,4,0,1,4,1,1,6,7,2,2,6,1,1,1,1,2,7,3,6,1,1]

theorem envBound53610 : H12AffineFastState.Bounded env53610 := by
  intro p hp
  have h : env53610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53609_53610 : H12AffineEnvironment.transform 2 5 env53609 = env53610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env53609 == env53610) = true)

def env53611 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136193,32769,4096,61568,147472,58518,143496,20497,508074,148669,148669,96266,90262,204946,172,74799,1213,135681]

theorem envBound53611 : H12AffineFastState.Bounded env53611 := by
  intro p hp
  have h : env53611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53595_53611 : H12AffineEnvironment.transform 5 17 env53595 = env53611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53595 == env53611) = true)

theorem identity53611 : scanCanonicalize (H12AffineFastState.compose env53611 (packedSelected [5,7,8,10,20,24,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 137352) := by decide +kernel

theorem selectedBound53611 : packedSelected [5,7,8,10,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env53612 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,137352,136193,32769,4096,61568,147472,58518,143496,20497,120866,148669,148669,96266,90262,204946,172,74799,1213,135681]

theorem envBound53612 : H12AffineFastState.Bounded env53612 := by
  intro p hp
  have h : env53612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53611_53612 : H12AffineEnvironment.transform 17 137352 env53611 = env53612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 137352 env53611 == env53612) = true)

theorem identity53612 : scanCanonicalize (H12AffineFastState.compose env53612 (packedSelected [1,5,8,16,17,20,21,24] rootPS)) = affineNative (2^(16+1) ^^^ 62492) := by decide +kernel

theorem selectedBound53612 : packedSelected [1,5,8,16,17,20,21,24] rootPS < 2^1333 := by decide +kernel

def env53613 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,65536,62492,60564,57373,32769,4096,61568,46092,58518,50324,20497,120866,45217,45217,96266,90262,119950,172,74799,1213,58909]

theorem envBound53613 : H12AffineFastState.Bounded env53613 := by
  intro p hp
  have h : env53613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53612_53613 : H12AffineEnvironment.transform 16 62492 env53612 = env53613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 62492 env53612 == env53613) = true)

theorem identity53613 : scanCanonicalize (H12AffineFastState.compose env53613 (packedSelected [4,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 5125) := by decide +kernel

theorem selectedBound53613 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env53614 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,5125,32768,65536,40985,47249,46104,32769,4096,42117,46092,45203,37009,1044,101415,45217,45217,76815,78995,98443,172,74799,1213,45592]

theorem envBound53614 : H12AffineFastState.Bounded env53614 := by
  intro p hp
  have h : env53614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53613_53614 : H12AffineEnvironment.transform 13 5125 env53613 = env53614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5125 env53613 == env53614) = true)

theorem identity53614 : scanCanonicalize (H12AffineFastState.compose env53614 (packedSelected [0,1,2,4,6,7,8,9,13,18,19,23] rootPS)) = affineNative (2^(15+1) ^^^ 43530) := by decide +kernel

theorem selectedBound53614 : packedSelected [0,1,2,4,6,7,8,9,13,18,19,23] rootPS < 2^1333 := by decide +kernel

def env53615 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,5125,32768,43530,40985,47249,46104,32769,4096,42117,46092,45203,37009,1044,9773,45217,45217,34309,40601,10881,172,36389,1213,45592]

theorem envBound53615 : H12AffineFastState.Bounded env53615 := by
  intro p hp
  have h : env53615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53614_53615 : H12AffineEnvironment.transform 15 43530 env53614 = env53615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 43530 env53614 == env53615) = true)

theorem identity53615 : scanCanonicalize (H12AffineFastState.compose env53615 (packedSelected [0,1,2,4,6,7,8,9,13,17,21,26] rootPS)) = affineNative (2^(12+1) ^^^ 3628) := by decide +kernel

theorem selectedBound53615 : packedSelected [0,1,2,4,6,7,8,9,13,17,21,26] rootPS < 2^1333 := by decide +kernel

def env53616 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,3628,5125,32768,33830,36405,38589,39476,32769,4096,35497,39456,40639,37009,1044,2049,40589,40589,34309,40601,1197,172,36389,1213,39988]

theorem envBound53616 : H12AffineFastState.Bounded env53616 := by
  intro p hp
  have h : env53616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53615_53616 : H12AffineEnvironment.transform 12 3628 env53615 = env53616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3628 env53615 == env53616) = true)

theorem identity53616 : scanCanonicalize (H12AffineFastState.compose env53616 (packedSelected [3,5,6,10,11,12,13,15] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound53616 : packedSelected [3,5,6,10,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env53617 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,3628,5125,32768,33830,36405,38452,39476,32769,4096,35360,39456,40502,36888,1044,2049,40452,40452,34309,40464,1060,37,36389,1076,39988]

theorem envBound53617 : H12AffineFastState.Bounded env53617 := by
  intro p hp
  have h : env53617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53616_53617 : H12AffineEnvironment.transform 6 9 env53616 = env53617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env53616 == env53617) = true)

theorem identity53617 : scanCanonicalize (H12AffineFastState.compose env53617 (packedSelected [0,2,3,4,6,7,8,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 6186) := by decide +kernel

theorem selectedBound53617 : packedSelected [0,2,3,4,6,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env53618 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,3628,5125,6186,7180,5663,3614,542,6187,4096,4618,522,1564,2098,1044,2049,1582,1582,7727,1594,1060,37,5647,1076,1054]

theorem envBound53618 : H12AffineFastState.Bounded env53618 := by
  intro p hp
  have h : env53618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53617_53618 : H12AffineEnvironment.transform 14 6186 env53617 = env53618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 6186 env53617 == env53618) = true)

theorem identity53618 : scanCanonicalize (H12AffineFastState.compose env53618 (packedSelected [10,12] rootPS)) = affineNative (2^(10+1) ^^^ 554) := by decide +kernel

theorem selectedBound53618 : packedSelected [10,12] rootPS < 2^1333 := by decide +kernel

def env53619 : List Nat := [2,4,8,16,32,17,9,36,512,1024,554,4096,1030,5125,4608,5670,5663,1076,542,4609,4096,4618,522,1564,536,1044,555,1582,1582,5125,1594,1060,37,5647,1076,1054]

theorem envBound53619 : H12AffineFastState.Bounded env53619 := by
  intro p hp
  have h : env53619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53618_53619 : H12AffineEnvironment.transform 10 554 env53618 = env53619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 554 env53618 == env53619) = true)

theorem identity53619 : scanCanonicalize (H12AffineFastState.compose env53619 (packedSelected [1,7,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound53619 : packedSelected [1,7,8,9] rootPS < 2^1333 := by decide +kernel

def env53620 : List Nat := [2,4,8,16,32,17,9,36,512,1024,554,48,1030,1077,560,1558,1583,1076,542,561,48,570,522,1564,536,1044,555,1582,1582,1077,1594,1060,37,1599,1076,1054]

theorem envBound53620 : H12AffineFastState.Bounded env53620 := by
  intro p hp
  have h : env53620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53619_53620 : H12AffineEnvironment.transform 11 48 env53619 = env53620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env53619 == env53620) = true)

theorem identity53620 : scanCanonicalize (H12AffineFastState.compose env53620 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound53620 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53621 : List Nat := [2,4,8,16,32,17,9,36,48,1024,26,48,1030,1077,0,1062,1055,1076,46,1,48,10,58,1068,40,1044,27,1054,1054,1077,1034,1060,37,1039,1076,1054]

theorem envBound53621 : H12AffineFastState.Bounded env53621 := by
  intro p hp
  have h : env53621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53620_53621 : H12AffineEnvironment.transform 8 48 env53620 = env53621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env53620 == env53621) = true)

theorem identity53621 : scanCanonicalize (H12AffineFastState.compose env53621 (packedSelected [1,3,5] rootPS)) = affineNative (2^(9+1) ^^^ 35) := by decide +kernel

theorem selectedBound53621 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env53622 : List Nat := [2,4,8,16,32,17,9,36,48,35,26,48,37,22,0,5,60,23,46,1,48,10,58,15,40,55,27,61,61,22,41,7,37,44,23,61]

theorem envBound53622 : H12AffineFastState.Bounded env53622 := by
  intro p hp
  have h : env53622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53621_53622 : H12AffineEnvironment.transform 9 35 env53621 = env53622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 35 env53621 == env53622) = true)

theorem identity53622 : scanCanonicalize (H12AffineFastState.compose env53622 (packedSelected [3,6] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound53622 : packedSelected [3,6] rootPS < 2^1333 := by decide +kernel

def env53623 : List Nat := [2,4,8,16,16,17,9,20,0,19,26,0,21,22,0,5,12,23,30,1,0,10,10,15,24,7,27,13,13,22,25,7,21,28,23,13]

theorem envBound53623 : H12AffineFastState.Bounded env53623 := by
  intro p hp
  have h : env53623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53622_53623 : H12AffineEnvironment.transform 4 16 env53622 = env53623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env53622 == env53623) = true)

theorem identity53623 : scanCanonicalize (H12AffineFastState.compose env53623 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound53623 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env53624 : List Nat := [2,4,5,16,16,17,4,20,0,19,23,0,21,22,0,5,1,23,19,1,0,7,7,2,21,7,22,0,0,22,20,7,21,17,23,0]

theorem envBound53624 : H12AffineFastState.Bounded env53624 := by
  intro p hp
  have h : env53624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53623_53624 : H12AffineEnvironment.transform 2 5 env53623 = env53624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env53623 == env53624) = true)

def env53625 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,16777216,533641,672784,17245633,148801,545088,96347,16876544,205166,257,17552661,1344,525824]

theorem envBound53625 : H12AffineFastState.Bounded env53625 := by
  intro p hp
  have h : env53625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53509_53625 : H12AffineEnvironment.transform 26 17245633 env53509 = env53625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 17245633 env53509 == env53625) = true)

theorem identity53625 : scanCanonicalize (H12AffineFastState.compose env53625 (packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 41002) := by decide +kernel

theorem selectedBound53625 : packedSelected [1,3,4,7,9,10,16,19,20,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env53626 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,4096,61649,147521,41002,533641,672784,493035,148801,545088,96347,74794,205166,257,750911,1344,525824]

theorem envBound53626 : H12AffineFastState.Bounded env53626 := by
  intro p hp
  have h : env53626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53625_53626 : H12AffineEnvironment.transform 23 41002 env53625 = env53626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41002 env53625 == env53626) = true)

def env53627 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147521,41002,143497,20496,493035,148801,148800,96347,74794,205166,257,90431,1344,135680]

theorem envBound53627 : H12AffineFastState.Bounded env53627 := by
  intro p hp
  have h : env53627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53626_53627 : H12AffineEnvironment.transform 18 136192 env53626 = env53627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 136192 env53626 == env53627) = true)

def env53628 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147521,41002,143497,20496,492615,148717,148716,96347,74794,204994,173,90259,1260,135680]

theorem envBound53628 : H12AffineFastState.Bounded env53628 := by
  intro p hp
  have h : env53628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53627_53628 : H12AffineEnvironment.transform 7 172 env53627 = env53628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env53627 == env53628) = true)

def env53629 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147473,41002,143497,20496,492567,148669,148668,96267,74794,204946,173,90259,1212,135680]

theorem envBound53629 : H12AffineFastState.Bounded env53629 := by
  intro p hp
  have h : env53629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53628_53629 : H12AffineEnvironment.transform 5 16 env53628 = env53629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env53628 == env53629) = true)

theorem identity53629 : scanCanonicalize (H12AffineFastState.compose env53629 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 223242) := by decide +kernel

theorem selectedBound53629 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env53630 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,223242,136192,32769,4096,61569,147473,41002,143497,20496,60445,148669,148668,96267,74794,204946,173,90259,1212,135680]

theorem envBound53630 : H12AffineFastState.Bounded env53630 := by
  intro p hp
  have h : env53630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53629_53630 : H12AffineEnvironment.transform 17 223242 env53629 = env53630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223242 env53629 == env53630) = true)

theorem identity53630 : scanCanonicalize (H12AffineFastState.compose env53630 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 28802) := by decide +kernel

theorem selectedBound53630 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env53631 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,28802,131072,137352,136192,32769,4096,61569,147473,41002,143497,20496,60445,148669,148668,2185,21672,151568,173,4113,1212,135680]

theorem envBound53631 : H12AffineFastState.Bounded env53631 := by
  intro p hp
  have h : env53631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53630_53631 : H12AffineEnvironment.transform 15 28802 env53630 = env53631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28802 env53630 == env53631) = true)

theorem identity53631 : scanCanonicalize (H12AffineFastState.compose env53631 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(16+1) ^^^ 40985) := by decide +kernel

theorem selectedBound53631 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env53632 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,16384,32768,28802,40985,47249,46105,32769,4096,61569,57352,41002,37008,20496,60445,58532,58533,2185,21672,61449,173,4113,1212,45593]

theorem envBound53632 : H12AffineFastState.Bounded env53632 := by
  intro p hp
  have h : env53632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53631_53632 : H12AffineEnvironment.transform 16 40985 env53631 = env53632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 40985 env53631 == env53632) = true)

theorem identity53632 : scanCanonicalize (H12AffineFastState.compose env53632 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1212) := by decide +kernel

theorem selectedBound53632 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env53633 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,1212,32768,13374,40985,47249,46105,32769,4096,46141,42164,41002,37008,5292,43169,40984,40985,2185,4116,46261,173,4113,1212,45593]

theorem envBound53633 : H12AffineFastState.Bounded env53633 := by
  intro p hp
  have h : env53633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53632_53633 : H12AffineEnvironment.transform 13 1212 env53632 = env53633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1212 env53632 == env53633) = true)

theorem identity53633 : scanCanonicalize (H12AffineFastState.compose env53633 (packedSelected [0,4,5,7,8,9,10,13] rootPS)) = affineNative (2^(12+1) ^^^ 6283) := by decide +kernel

theorem selectedBound53633 : packedSelected [0,4,5,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env53634 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,6283,1212,32768,3253,39058,32794,35986,32769,4096,36022,39999,39073,37008,5292,36906,39059,39058,2185,4116,35902,173,4113,1212,35474]

theorem envBound53634 : H12AffineFastState.Bounded env53634 := by
  intro p hp
  have h : env53634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53633_53634 : H12AffineEnvironment.transform 12 6283 env53633 = env53634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6283 env53633 == env53634) = true)

theorem identity53634 : scanCanonicalize (H12AffineFastState.compose env53634 (packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 7215) := by decide +kernel

theorem selectedBound53634 : packedSelected [0,4,5,6,7,8,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env53635 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,6283,1212,7215,3253,1213,7221,4285,7214,4096,4249,16,1166,3263,5292,3077,1212,1213,2185,4116,4113,173,4113,1212,5821]

theorem envBound53635 : H12AffineFastState.Bounded env53635 := by
  intro p hp
  have h : env53635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53634_53635 : H12AffineEnvironment.transform 14 7215 env53634 = env53635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7215 env53634 == env53635) = true)

theorem identity53635 : scanCanonicalize (H12AffineFastState.compose env53635 (packedSelected [6,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 1058) := by decide +kernel

theorem selectedBound53635 : packedSelected [6,8,10] rootPS < 2^1333 := by decide +kernel

def env53636 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,1058,3241,1212,2061,3253,1213,2071,1183,2060,1058,1211,16,1166,3263,142,3077,1212,1213,2185,1078,1075,173,1075,1212,671]

theorem envBound53636 : H12AffineFastState.Bounded env53636 := by
  intro p hp
  have h : env53636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53635_53636 : H12AffineEnvironment.transform 11 1058 env53635 = env53636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1058 env53635 == env53636) = true)

theorem identity53636 : scanCanonicalize (H12AffineFastState.compose env53636 (packedSelected [1,2,3,4,8,9,11,16] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound53636 : packedSelected [1,2,3,4,8,9,11,16] rootPS < 2^1333 := by decide +kernel

def env53637 : List Nat := [2,4,8,16,32,16,128,172,512,516,2048,550,2733,696,2061,2737,697,2071,667,2060,550,703,16,650,2747,142,2561,696,697,2185,562,567,173,567,696,671]

theorem envBound53637 : H12AffineFastState.Bounded env53637 := by
  intro p hp
  have h : env53637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53636_53637 : H12AffineEnvironment.transform 9 516 env53636 = env53637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env53636 == env53637) = true)

theorem identity53637 : scanCanonicalize (H12AffineFastState.compose env53637 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 675) := by decide +kernel

theorem selectedBound53637 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env53638 : List Nat := [2,4,8,16,32,16,128,172,512,516,675,550,14,696,686,18,697,692,667,687,550,703,16,650,24,142,162,696,697,554,562,567,173,567,696,671]

theorem envBound53638 : H12AffineFastState.Bounded env53638 := by
  intro p hp
  have h : env53638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53637_53638 : H12AffineEnvironment.transform 10 675 env53637 = env53638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 675 env53637 == env53638) = true)

theorem identity53638 : scanCanonicalize (H12AffineFastState.compose env53638 (packedSelected [1,5] rootPS)) = affineNative (2^(6+1) ^^^ 31) := by decide +kernel

theorem selectedBound53638 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env53639 : List Nat := [2,4,8,16,32,16,31,51,512,516,572,550,14,551,561,18,550,555,516,560,550,544,16,533,24,17,61,551,550,554,562,567,50,567,551,512]

theorem envBound53639 : H12AffineFastState.Bounded env53639 := by
  intro p hp
  have h : env53639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53638_53639 : H12AffineEnvironment.transform 6 31 env53638 = env53639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 31 env53638 == env53639) = true)

theorem identity53639 : scanCanonicalize (H12AffineFastState.compose env53639 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound53639 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env53640 : List Nat := [2,4,4,16,32,16,19,51,512,516,560,550,2,551,561,18,550,551,516,560,550,544,16,533,20,17,49,551,550,550,562,567,50,567,551,512]

theorem envBound53640 : H12AffineFastState.Bounded env53640 := by
  intro p hp
  have h : env53640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53639_53640 : H12AffineEnvironment.transform 2 4 env53639 = env53640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env53639 == env53640) = true)

theorem identity53640 : scanCanonicalize (H12AffineFastState.compose env53640 (packedSelected [1,4] rootPS)) = affineNative (2^(8+1) ^^^ 22) := by decide +kernel

theorem selectedBound53640 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env53641 : List Nat := [2,4,4,16,32,16,19,51,22,18,38,48,2,49,39,18,48,49,18,38,48,54,16,3,20,17,49,49,48,48,36,33,50,33,49,22]

theorem envBound53641 : H12AffineFastState.Bounded env53641 := by
  intro p hp
  have h : env53641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53640_53641 : H12AffineEnvironment.transform 8 22 env53640 = env53641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 22 env53640 == env53641) = true)

def env53642 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61568,147472,41002,143497,20496,492566,148668,148669,96266,74794,204947,173,90259,1213,135680]

theorem envBound53642 : H12AffineFastState.Bounded env53642 := by
  intro p hp
  have h : env53642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53628_53642 : H12AffineEnvironment.transform 5 17 env53628 = env53642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env53628 == env53642) = true)

theorem identity53642 : scanCanonicalize (H12AffineFastState.compose env53642 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 114723) := by decide +kernel

theorem selectedBound53642 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env53643 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,114723,262144,119843,32769,4096,61568,98355,41002,127146,20496,279605,99487,99486,96266,74794,57520,173,90259,1213,119331]

theorem envBound53643 : H12AffineFastState.Bounded env53643 := by
  intro p hp
  have h : env53643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53642_53643 : H12AffineEnvironment.transform 16 114723 env53642 = env53643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114723 env53642 == env53643) = true)

theorem identity53643 : scanCanonicalize (H12AffineFastState.compose env53643 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 116755) := by decide +kernel

theorem selectedBound53643 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env53644 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,65536,114723,116755,119843,32769,4096,61568,98355,41002,127146,20496,101414,99487,99486,96266,74794,57520,173,90259,1213,119331]

theorem envBound53644 : H12AffineFastState.Bounded env53644 := by
  intro p hp
  have h : env53644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53643_53644 : H12AffineEnvironment.transform 17 116755 env53643 = env53644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 116755 env53643 == env53644) = true)

theorem identity53644 : scanCanonicalize (H12AffineFastState.compose env53644 (packedSelected [7,16,18,19,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 53283) := by decide +kernel

theorem selectedBound53644 : packedSelected [7,16,18,19,23,26,27] rootPS < 2^1333 := by decide +kernel

def env53645 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,32768,53283,4096,6192,1024,32769,4096,61568,20496,41002,8329,20496,23557,21692,21693,43049,62473,57520,173,45232,1213,512]

theorem envBound53645 : H12AffineFastState.Bounded env53645 := by
  intro p hp
  have h : env53645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53644_53645 : H12AffineEnvironment.transform 15 53283 env53644 = env53645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53283 env53644 == env53645) = true)

theorem identity53645 : scanCanonicalize (H12AffineFastState.compose env53645 (packedSelected [4,9,16] rootPS)) = affineNative (2^(14+1) ^^^ 29860) := by decide +kernel

theorem selectedBound53645 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env53646 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,29860,9351,4096,6192,1024,29861,4096,1060,20496,21646,8329,20496,23557,21692,21693,23693,173,5140,173,17428,1213,512]

theorem envBound53646 : H12AffineFastState.Bounded env53646 := by
  intro p hp
  have h : env53646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53645_53646 : H12AffineEnvironment.transform 14 29860 env53645 = env53646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29860 env53645 == env53646) = true)

theorem identity53646 : scanCanonicalize (H12AffineFastState.compose env53646 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 8744) := by decide +kernel

theorem selectedBound53646 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env53647 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,8744,5772,9351,4096,6192,1024,5773,4096,1060,12856,13990,8329,12856,15917,13972,13973,16037,173,5140,173,9788,1213,512]

theorem envBound53647 : H12AffineFastState.Bounded env53647 := by
  intro p hp
  have h : env53647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53646_53647 : H12AffineEnvironment.transform 13 8744 env53646 = env53647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8744 env53646 == env53647) = true)

theorem identity53647 : scanCanonicalize (H12AffineFastState.compose env53647 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 674) := by decide +kernel

theorem selectedBound53647 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env53648 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,674,8192,8744,1070,9351,674,2706,1024,1071,674,1060,8346,9220,8329,8346,11407,9270,9271,11271,173,1718,173,9788,1213,512]

theorem envBound53648 : H12AffineFastState.Bounded env53648 := by
  intro p hp
  have h : env53648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53647_53648 : H12AffineEnvironment.transform 11 674 env53647 = env53648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 674 env53647 == env53648) = true)

theorem identity53648 : scanCanonicalize (H12AffineFastState.compose env53648 (packedSelected [1,3,13] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound53648 : packedSelected [1,3,13] rootPS < 2^1333 := by decide +kernel

def env53649 : List Nat := [2,4,8,16,32,17,128,172,26,1024,2048,184,8192,8242,1070,9351,184,2184,1024,1071,184,1060,8346,9220,8329,8346,11407,9270,9271,11271,173,1196,173,9254,1213,26]

theorem envBound53649 : H12AffineFastState.Bounded env53649 := by
  intro p hp
  have h : env53649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53648_53649 : H12AffineEnvironment.transform 8 26 env53648 = env53649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env53648 == env53649) = true)

theorem identity53649 : scanCanonicalize (H12AffineFastState.compose env53649 (packedSelected [1,2,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound53649 : packedSelected [1,2,5,6] rootPS < 2^1333 := by decide +kernel

def env53650 : List Nat := [2,4,8,16,32,17,128,172,26,1024,1,184,8192,8242,1070,9351,184,137,1024,1071,184,1060,8346,9220,8329,8346,9358,9270,9271,9222,173,1196,173,9254,1213,26]

theorem envBound53650 : H12AffineFastState.Bounded env53650 := by
  intro p hp
  have h : env53650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53649_53650 : H12AffineEnvironment.transform 10 1 env53649 = env53650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env53649 == env53650) = true)

theorem identity53650 : scanCanonicalize (H12AffineFastState.compose env53650 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound53650 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env53651 : List Nat := [2,4,8,16,16,17,128,156,26,1024,1,136,8192,8194,1054,9351,136,137,1024,1055,136,1044,8346,9220,8329,8346,9358,9222,9223,9222,157,1180,157,9238,1165,26]

theorem envBound53651 : H12AffineFastState.Bounded env53651 := by
  intro p hp
  have h : env53651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53650_53651 : H12AffineEnvironment.transform 4 16 env53650 = env53651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env53650 == env53651) = true)

theorem identity53651 : scanCanonicalize (H12AffineFastState.compose env53651 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound53651 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env53652 : List Nat := [2,4,8,10,10,11,128,134,0,1024,1,136,8192,8194,1028,9351,136,137,1024,1029,136,1038,8320,9220,8329,8320,9358,9222,9223,9222,135,1158,135,9228,1165,0]

theorem envBound53652 : H12AffineFastState.Bounded env53652 := by
  intro p hp
  have h : env53652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53651_53652 : H12AffineEnvironment.transform 3 10 env53651 = env53652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env53651 == env53652) = true)

theorem identity53652 : scanCanonicalize (H12AffineFastState.compose env53652 (packedSelected [0,2,5] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound53652 : packedSelected [0,2,5] rootPS < 2^1333 := by decide +kernel

def env53653 : List Nat := [2,4,8,10,10,11,128,134,0,5,1,136,8192,8194,1,8322,136,137,5,0,136,11,8320,8193,8329,8320,8331,8195,8194,8195,135,131,135,8201,136,0]

theorem envBound53653 : H12AffineFastState.Bounded env53653 := by
  intro p hp
  have h : env53653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53652_53653 : H12AffineEnvironment.transform 9 5 env53652 = env53653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env53652 == env53653) = true)

theorem identity53653 : scanCanonicalize (H12AffineFastState.compose env53653 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound53653 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env53654 : List Nat := [2,4,4,6,6,7,128,134,0,5,1,132,8192,8194,1,8322,132,133,5,0,132,7,8320,8193,8325,8320,8327,8195,8194,8195,135,131,135,8197,132,0]

theorem envBound53654 : H12AffineFastState.Bounded env53654 := by
  intro p hp
  have h : env53654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53653_53654 : H12AffineEnvironment.transform 2 4 env53653 = env53654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env53653 == env53654) = true)

theorem identity53654 : scanCanonicalize (H12AffineFastState.compose env53654 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound53654 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env53655 : List Nat := [2,4,4,6,6,7,5,3,0,5,1,1,8192,8194,1,8199,1,0,5,0,1,7,8197,8193,8192,8197,8194,8195,8194,8195,2,6,2,8197,1,0]

theorem envBound53655 : H12AffineFastState.Bounded env53655 := by
  intro p hp
  have h : env53655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53654_53655 : H12AffineEnvironment.transform 6 5 env53654 = env53655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env53654 == env53655) = true)

theorem identity53655 : scanCanonicalize (H12AffineFastState.compose env53655 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2) := by decide +kernel

theorem selectedBound53655 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env53656 : List Nat := [2,4,4,6,6,7,5,3,0,5,1,1,2,0,1,5,1,0,5,0,1,7,7,3,2,7,0,1,0,1,2,6,2,7,1,0]

theorem envBound53656 : H12AffineFastState.Bounded env53656 := by
  intro p hp
  have h : env53656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53655_53656 : H12AffineEnvironment.transform 12 2 env53655 = env53656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2 env53655 == env53656) = true)

def env53657 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61649,147521,41002,143497,20496,492614,148716,148717,96347,74794,204995,172,90258,1261,135680]

theorem envBound53657 : H12AffineFastState.Bounded env53657 := by
  intro p hp
  have h : env53657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53627_53657 : H12AffineEnvironment.transform 7 173 env53627 = env53657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env53627 == env53657) = true)

def env53658 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,136192,32769,4096,61569,147473,41002,143497,20496,492566,148668,148669,96267,74794,204947,172,90258,1213,135680]

theorem envBound53658 : H12AffineFastState.Bounded env53658 := by
  intro p hp
  have h : env53658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans53657_53658 : H12AffineEnvironment.transform 5 16 env53657 = env53658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env53657 == env53658) = true)

theorem identity53658 : scanCanonicalize (H12AffineFastState.compose env53658 (packedSelected [4,5,8,9,10,16,24,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 137353) := by decide +kernel

theorem selectedBound53658 : packedSelected [4,5,8,9,10,16,24,26,28] rootPS < 2^1333 := by decide +kernel

def env53659 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,4096,8192,16384,32768,65536,131072,137353,136192,32769,4096,61569,147473,41002,143497,20496,105631,148668,148669,96267,74794,204947,172,90258,1213,135680]

end H12CloudChart2