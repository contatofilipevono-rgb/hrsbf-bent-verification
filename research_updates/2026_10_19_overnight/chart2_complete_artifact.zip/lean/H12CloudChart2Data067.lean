import H12CloudChart2Data066

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def tree16413 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16413 : H12WitnessSearch.Good tree16413 := H12GlobalWitnessIndex.good

theorem leafIdentity16413 : H12AffineFastState.composeSystem env16413 rootObs = leafEnv16413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16413 rootObs == leafEnv16413) = true)

theorem terminalChecked16413 : H12PackedTerminal.terminalCheckFast leafEnv16413 active16413 tree16413 = true := by decide +kernel

def env16414 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,1345,8192,16384,32768,65536,1345,1,16656,32769,1345,4194304,17664,98564,8328,64,134217728,16384,1296,0,1285,4294967296,256,4299260334,138428757,1]

theorem envBound16414 : H12AffineFastState.Bounded env16414 := by
  intro p hp
  have h : env16414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16389_16414 : H12AffineEnvironment.transform 8 1 env16389 = env16414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env16389 == env16414) = true)

theorem identity16414 : scanCanonicalize (H12AffineFastState.compose env16414 (packedSelected [18] rootPS)) = affineNative (2^(26+1) ^^^ 4237612) := by decide +kernel

theorem selectedBound16414 : packedSelected [18] rootPS < 2^1333 := by decide +kernel

def env16415 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,1345,8192,16384,32768,65536,1345,1,16656,32769,1345,4194304,17664,98564,8328,64,4237612,16384,1296,0,1285,4294967296,256,4299260334,59513,1]

theorem envBound16415 : H12AffineFastState.Bounded env16415 := by
  intro p hp
  have h : env16415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16414_16415 : H12AffineEnvironment.transform 26 4237612 env16414 = env16415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4237612 env16414 == env16415) = true)

theorem identity16415 : scanCanonicalize (H12AffineFastState.compose env16415 (packedSelected [23] rootPS)) = affineNative (2^(21+1) ^^^ 19477) := by decide +kernel

theorem selectedBound16415 : packedSelected [23] rootPS < 2^1333 := by decide +kernel

def env16416 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,1345,8192,16384,32768,65536,1345,1,16656,32769,1345,19477,17664,98564,8328,64,58681,16384,1296,0,1285,4294967296,256,4295085499,59513,1]

theorem envBound16416 : H12AffineFastState.Bounded env16416 := by
  intro p hp
  have h : env16416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16415_16416 : H12AffineEnvironment.transform 21 19477 env16415 = env16416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 19477 env16415 == env16416) = true)

theorem identity16416 : scanCanonicalize (H12AffineFastState.compose env16416 (packedSelected [3,4,8,9,10,19,20,28] rootPS)) = affineNative (2^(14+1) ^^^ 27960) := by decide +kernel

theorem selectedBound16416 : packedSelected [3,4,8,9,10,19,20,28] rootPS < 2^1333 := by decide +kernel

def env16417 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,1345,8192,16384,27960,65536,1345,1,16656,27961,1345,19477,17664,93244,8328,64,2049,16384,1296,0,1285,4294967296,256,4295041155,1345,1]

theorem envBound16417 : H12AffineFastState.Bounded env16417 := by
  intro p hp
  have h : env16417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16416_16417 : H12AffineEnvironment.transform 14 27960 env16416 = env16417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 27960 env16416 == env16417) = true)

def env16418 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,1345,8192,1296,10280,65536,1345,1,1024,10281,1345,2309,16,76076,8328,64,2049,1296,1296,0,1285,4294967296,256,4295041155,1345,1]

theorem envBound16418 : H12AffineFastState.Bounded env16418 := by
  intro p hp
  have h : env16418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16417_16418 : H12AffineEnvironment.transform 13 1296 env16417 = env16418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env16417 == env16418) = true)

def env16419 : List Nat := [2,4,8,16,32,64,128,256,1,1024,0,1345,8192,1296,8232,65536,1345,1,1024,8233,1345,261,16,74028,8328,64,1,1296,1296,0,1285,4294967296,256,4295041155,1345,1]

theorem envBound16419 : H12AffineFastState.Bounded env16419 := by
  intro p hp
  have h : env16419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16418_16419 : H12AffineEnvironment.transform 10 0 env16418 = env16419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env16418 == env16419) = true)

def env16420 : List Nat := [2,4,8,16,32,64,128,256,1,1024,0,1345,8192,1296,8232,65536,1345,1,1024,8233,1345,261,16,74028,8328,64,1,1296,1296,0,1285,260,256,74119,1345,1]

theorem envBound16420 : H12AffineFastState.Bounded env16420 := by
  intro p hp
  have h : env16420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16419_16420 : H12AffineEnvironment.transform 31 260 env16419 = env16420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 260 env16419 == env16420) = true)

theorem identity16420 : scanCanonicalize (H12AffineFastState.compose env16420 (packedSelected [4] rootPS)) = affineNative (2^(12+1) ^^^ 300) := by decide +kernel

theorem selectedBound16420 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env16421 : List Nat := [2,4,8,16,32,64,128,256,1,1024,0,1345,300,1296,260,65536,1345,1,1024,261,1345,261,16,65536,420,64,1,1296,1296,0,1285,260,256,65707,1345,1]

theorem envBound16421 : H12AffineFastState.Bounded env16421 := by
  intro p hp
  have h : env16421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16420_16421 : H12AffineEnvironment.transform 12 300 env16420 = env16421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 300 env16420 == env16421) = true)

def env16422 : List Nat := [2,4,8,16,32,64,128,140,1,1024,0,1229,160,1180,136,65536,1229,1,1024,137,1229,137,16,65536,40,64,1,1180,1180,0,1161,136,140,65707,1229,1]

theorem envBound16422 : H12AffineFastState.Bounded env16422 := by
  intro p hp
  have h : env16422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16421_16422 : H12AffineEnvironment.transform 7 140 env16421 = env16422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env16421 == env16422) = true)

theorem identity16422 : scanCanonicalize (H12AffineFastState.compose env16422 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound16422 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16423 : List Nat := [2,4,8,16,0,64,128,140,1,1024,0,1229,128,1180,136,65536,1229,1,1024,137,1229,137,16,65536,8,64,1,1180,1180,0,1161,136,140,65675,1229,1]

theorem envBound16423 : H12AffineFastState.Bounded env16423 := by
  intro p hp
  have h : env16423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16422_16423 : H12AffineEnvironment.transform 4 0 env16422 = env16423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16422 == env16423) = true)

theorem identity16423 : scanCanonicalize (H12AffineFastState.compose env16423 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 139) := by decide +kernel

theorem selectedBound16423 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env16424 : List Nat := [2,4,8,16,0,64,128,140,1,1024,0,1229,128,1180,136,139,1229,1,1024,137,1229,137,16,139,8,64,1,1180,1180,0,1161,136,140,0,1229,1]

theorem envBound16424 : H12AffineFastState.Bounded env16424 := by
  intro p hp
  have h : env16424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16423_16424 : H12AffineEnvironment.transform 15 139 env16423 = env16424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 139 env16423 == env16424) = true)

def env16425 : List Nat := [2,4,8,16,0,16,128,140,1,1024,0,1181,128,1180,136,139,1181,1,1024,137,1181,137,16,139,8,16,1,1180,1180,0,1161,136,140,0,1181,1]

theorem envBound16425 : H12AffineFastState.Bounded env16425 := by
  intro p hp
  have h : env16425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16424_16425 : H12AffineEnvironment.transform 5 16 env16424 = env16425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env16424 == env16425) = true)

def env16426 : List Nat := [2,4,8,16,0,17,128,140,1,1024,0,1180,128,1180,136,139,1180,1,1024,137,1180,137,16,139,8,17,1,1180,1180,0,1161,136,140,0,1180,1]

theorem envBound16426 : H12AffineFastState.Bounded env16426 := by
  intro p hp
  have h : env16426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16424_16426 : H12AffineEnvironment.transform 5 17 env16424 = env16426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env16424 == env16426) = true)

theorem identity16426 : scanCanonicalize (H12AffineFastState.compose env16426 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound16426 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16427 : List Nat := [2,4,8,16,0,17,9,5,1,1024,0,1045,9,1045,1,2,1045,1,1024,0,1045,0,16,2,8,17,1,1045,1045,0,1024,1,5,0,1045,1]

theorem envBound16427 : H12AffineFastState.Bounded env16427 := by
  intro p hp
  have h : env16427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16426_16427 : H12AffineEnvironment.transform 6 9 env16426 = env16427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16426 == env16427) = true)

def leafEnv16427 : List Nat := [2,4,8,16,0,17,9,5,1,1024,0,1045,9,1045,1,2,1045,1,1024,0,1045,0,16,2,1024,8,1,17,1,1045,1045,0,1024,1,5,0,4,2,1045,1,0,1045,1]

def active16427 : List Nat := [0,1,2,3,9]

def tree16427 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16427 : H12WitnessSearch.Good tree16427 := H12GlobalWitnessIndex.good

theorem leafIdentity16427 : H12AffineFastState.composeSystem env16427 rootObs = leafEnv16427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16427 rootObs == leafEnv16427) = true)

theorem terminalChecked16427 : H12PackedTerminal.terminalCheckFast leafEnv16427 active16427 tree16427 = true := by decide +kernel

def env16428 : List Nat := [2,4,8,16,32,64,128,141,1,1024,0,1228,161,1181,137,65536,1228,1,1024,136,1228,136,16,65536,41,64,1,1181,1181,0,1160,137,141,65707,1228,1]

theorem envBound16428 : H12AffineFastState.Bounded env16428 := by
  intro p hp
  have h : env16428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16421_16428 : H12AffineEnvironment.transform 7 141 env16421 = env16428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env16421 == env16428) = true)

theorem identity16428 : scanCanonicalize (H12AffineFastState.compose env16428 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound16428 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16429 : List Nat := [2,4,8,16,32,64,128,141,1,1024,0,1228,161,1181,137,171,1228,1,1024,136,1228,136,16,171,41,64,1,1181,1181,0,1160,137,141,0,1228,1]

theorem envBound16429 : H12AffineFastState.Bounded env16429 := by
  intro p hp
  have h : env16429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16428_16429 : H12AffineEnvironment.transform 15 171 env16428 = env16429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env16428 == env16429) = true)

theorem identity16429 : scanCanonicalize (H12AffineFastState.compose env16429 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound16429 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16430 : List Nat := [2,4,8,16,32,64,40,37,1,1024,0,1124,9,1077,33,3,1124,1,1024,32,1124,32,16,3,41,64,1,1077,1077,0,1056,33,37,0,1124,1]

theorem envBound16430 : H12AffineFastState.Bounded env16430 := by
  intro p hp
  have h : env16430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16429_16430 : H12AffineEnvironment.transform 6 40 env16429 = env16430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env16429 == env16430) = true)

def env16431 : List Nat := [2,4,8,16,0,64,8,5,1,1024,0,1092,9,1045,1,3,1092,1,1024,0,1092,0,16,3,9,64,1,1045,1045,0,1024,1,5,0,1092,1]

theorem envBound16431 : H12AffineFastState.Bounded env16431 := by
  intro p hp
  have h : env16431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16430_16431 : H12AffineEnvironment.transform 4 0 env16430 = env16431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16430 == env16431) = true)

def env16432 : List Nat := [2,4,8,16,1,64,9,4,1,1024,0,1093,9,1044,0,3,1093,1,1024,1,1093,1,16,3,8,64,1,1044,1044,0,1025,0,4,0,1093,1]

theorem envBound16432 : H12AffineFastState.Bounded env16432 := by
  intro p hp
  have h : env16432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16430_16432 : H12AffineEnvironment.transform 4 1 env16430 = env16432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16430 == env16432) = true)

theorem identity16432 : scanCanonicalize (H12AffineFastState.compose env16432 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound16432 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16433 : List Nat := [2,4,8,16,1,64,9,4,1,69,0,0,9,81,0,3,0,1,69,1,0,1,16,3,8,64,1,81,81,0,68,0,4,0,0,1]

theorem envBound16433 : H12AffineFastState.Bounded env16433 := by
  intro p hp
  have h : env16433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16432_16433 : H12AffineEnvironment.transform 9 69 env16432 = env16433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env16432 == env16433) = true)

theorem identity16433 : scanCanonicalize (H12AffineFastState.compose env16433 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound16433 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env16434 : List Nat := [2,4,8,16,1,17,9,4,1,20,0,0,9,0,0,3,0,1,20,1,0,1,16,3,8,17,1,0,0,0,21,0,4,0,0,1]

theorem envBound16434 : H12AffineFastState.Bounded env16434 := by
  intro p hp
  have h : env16434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16433_16434 : H12AffineEnvironment.transform 5 17 env16433 = env16434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env16433 == env16434) = true)

def leafEnv16434 : List Nat := [2,4,8,16,1,17,9,4,1,20,0,0,9,0,0,3,0,1,20,1,0,1,16,3,21,8,1,17,1,0,0,0,21,0,4,0,4,2,0,1,0,0,1]

def active16434 : List Nat := [0,1,2,3]

def tree16434 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16434 : H12WitnessSearch.Good tree16434 := H12GlobalWitnessIndex.good

theorem leafIdentity16434 : H12AffineFastState.composeSystem env16434 rootObs = leafEnv16434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16434 rootObs == leafEnv16434) = true)

theorem terminalChecked16434 : H12PackedTerminal.terminalCheckFast leafEnv16434 active16434 tree16434 = true := by decide +kernel

def env16435 : List Nat := [2,4,8,16,32,64,128,256,1,1024,0,1345,8192,1296,8232,65536,1345,1,1024,8233,1345,261,16,74028,8328,64,1,1296,1296,0,1285,261,256,74118,1345,1]

theorem envBound16435 : H12AffineFastState.Bounded env16435 := by
  intro p hp
  have h : env16435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16419_16435 : H12AffineEnvironment.transform 31 261 env16419 = env16435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 261 env16419 == env16435) = true)

theorem identity16435 : scanCanonicalize (H12AffineFastState.compose env16435 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 430) := by decide +kernel

theorem selectedBound16435 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env16436 : List Nat := [2,4,8,16,32,64,128,256,1,1024,0,1345,8192,1296,8232,430,1345,1,1024,8233,1345,261,16,8322,8328,64,1,1296,1296,0,1285,261,256,8232,1345,1]

theorem envBound16436 : H12AffineFastState.Bounded env16436 := by
  intro p hp
  have h : env16436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16435_16436 : H12AffineEnvironment.transform 15 430 env16435 = env16436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 430 env16435 == env16436) = true)

def env16437 : List Nat := [2,4,8,16,32,64,128,256,1,1024,0,1345,8,1296,32,430,1345,1,1024,33,1345,261,16,138,128,64,1,1296,1296,0,1285,261,256,32,1345,1]

theorem envBound16437 : H12AffineFastState.Bounded env16437 := by
  intro p hp
  have h : env16437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16436_16437 : H12AffineEnvironment.transform 12 8 env16436 = env16437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env16436 == env16437) = true)

theorem identity16437 : scanCanonicalize (H12AffineFastState.compose env16437 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound16437 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16438 : List Nat := [2,4,8,16,32,64,8,256,1,1024,0,1345,8,1296,32,294,1345,1,1024,33,1345,261,16,2,8,64,1,1296,1296,0,1285,261,256,32,1345,1]

theorem envBound16438 : H12AffineFastState.Bounded env16438 := by
  intro p hp
  have h : env16438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16437_16438 : H12AffineEnvironment.transform 6 8 env16437 = env16438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16437 == env16438) = true)

theorem identity16438 : scanCanonicalize (H12AffineFastState.compose env16438 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound16438 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16439 : List Nat := [2,4,8,16,32,64,8,5,1,1024,0,1092,8,1045,32,35,1092,1,1024,33,1092,0,16,2,8,64,1,1045,1045,0,1024,0,5,32,1092,1]

theorem envBound16439 : H12AffineFastState.Bounded env16439 := by
  intro p hp
  have h : env16439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16438_16439 : H12AffineEnvironment.transform 7 5 env16438 = env16439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env16438 == env16439) = true)

theorem identity16439 : scanCanonicalize (H12AffineFastState.compose env16439 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound16439 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16440 : List Nat := [2,4,8,16,32,64,8,5,1,21,0,81,8,0,32,35,81,1,21,33,81,0,16,2,8,64,1,0,0,0,21,0,5,32,81,1]

theorem envBound16440 : H12AffineFastState.Bounded env16440 := by
  intro p hp
  have h : env16440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16439_16440 : H12AffineEnvironment.transform 9 21 env16439 = env16440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env16439 == env16440) = true)

theorem identity16440 : scanCanonicalize (H12AffineFastState.compose env16440 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound16440 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env16441 : List Nat := [2,4,8,16,32,17,8,5,1,21,0,0,8,0,32,35,0,1,21,33,0,0,16,2,8,17,1,0,0,0,21,0,5,32,0,1]

theorem envBound16441 : H12AffineFastState.Bounded env16441 := by
  intro p hp
  have h : env16441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16440_16441 : H12AffineEnvironment.transform 5 17 env16440 = env16441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env16440 == env16441) = true)

def env16442 : List Nat := [2,4,8,16,32,64,128,256,1,1024,0,1345,9,1296,33,430,1345,1,1024,32,1345,261,16,139,129,64,1,1296,1296,0,1285,261,256,33,1345,1]

theorem envBound16442 : H12AffineFastState.Bounded env16442 := by
  intro p hp
  have h : env16442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16436_16442 : H12AffineEnvironment.transform 12 9 env16436 = env16442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env16436 == env16442) = true)

theorem identity16442 : scanCanonicalize (H12AffineFastState.compose env16442 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound16442 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16443 : List Nat := [2,4,8,16,32,64,128,5,1,1024,0,1092,9,1045,33,171,1092,1,1024,32,1092,0,16,139,129,64,1,1045,1045,0,1024,0,5,33,1092,1]

theorem envBound16443 : H12AffineFastState.Bounded env16443 := by
  intro p hp
  have h : env16443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16442_16443 : H12AffineEnvironment.transform 7 5 env16442 = env16443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env16442 == env16443) = true)

def env16444 : List Nat := [2,4,8,16,0,64,128,5,1,1024,0,1092,9,1045,1,139,1092,1,1024,0,1092,0,16,139,129,64,1,1045,1045,0,1024,0,5,1,1092,1]

theorem envBound16444 : H12AffineFastState.Bounded env16444 := by
  intro p hp
  have h : env16444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16443_16444 : H12AffineEnvironment.transform 4 0 env16443 = env16444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16443 == env16444) = true)

def env16445 : List Nat := [2,4,8,16,1,64,128,5,1,1024,0,1092,9,1045,0,138,1092,1,1024,1,1092,0,16,139,129,64,1,1045,1045,0,1024,0,5,0,1092,1]

theorem envBound16445 : H12AffineFastState.Bounded env16445 := by
  intro p hp
  have h : env16445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16443_16445 : H12AffineEnvironment.transform 4 1 env16443 = env16445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16443 == env16445) = true)

theorem identity16445 : scanCanonicalize (H12AffineFastState.compose env16445 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound16445 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16446 : List Nat := [2,4,8,16,1,64,8,5,1,1024,0,1092,9,1045,0,2,1092,1,1024,1,1092,0,16,3,9,64,1,1045,1045,0,1024,0,5,0,1092,1]

theorem envBound16446 : H12AffineFastState.Bounded env16446 := by
  intro p hp
  have h : env16446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16445_16446 : H12AffineEnvironment.transform 6 8 env16445 = env16446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16445 == env16446) = true)

def leafEnv16446 : List Nat := [2,4,8,16,1,64,8,5,1,1024,0,1092,9,1045,0,2,1092,1,1024,1,1092,0,16,3,1024,9,1,64,1,1045,1045,0,1024,0,5,0,4,3,1092,1,0,1045,1]

def active16446 : List Nat := [0,1,2,3,5,9]

def tree16446 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16446 : H12WitnessSearch.Good tree16446 := H12GlobalWitnessIndex.good

theorem leafIdentity16446 : H12AffineFastState.composeSystem env16446 rootObs = leafEnv16446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16446 rootObs == leafEnv16446) = true)

theorem terminalChecked16446 : H12PackedTerminal.terminalCheckFast leafEnv16446 active16446 tree16446 = true := by decide +kernel

def env16447 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1,1345,8192,1296,8233,65536,1345,1,1024,8232,1345,260,16,74029,8328,64,0,1296,1296,0,1285,4294967296,256,4295041155,1345,1]

theorem envBound16447 : H12AffineFastState.Bounded env16447 := by
  intro p hp
  have h : env16447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16418_16447 : H12AffineEnvironment.transform 10 1 env16418 = env16447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env16418 == env16447) = true)

theorem identity16447 : scanCanonicalize (H12AffineFastState.compose env16447 (packedSelected [5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound16447 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env16448 : List Nat := [2,4,8,16,32,17,128,256,1,1024,1,1296,8192,1296,8233,65536,1296,1,1024,8232,1296,260,16,74029,8328,17,0,1296,1296,0,1285,4294967296,256,4295041155,1296,1]

theorem envBound16448 : H12AffineFastState.Bounded env16448 := by
  intro p hp
  have h : env16448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16447_16448 : H12AffineEnvironment.transform 5 17 env16447 = env16448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env16447 == env16448) = true)

def env16449 : List Nat := [2,4,8,16,32,17,128,256,1,272,1,0,8192,0,8233,65536,0,1,272,8232,0,260,16,74029,8328,17,0,0,0,0,21,4294967296,256,4295041155,0,1]

theorem envBound16449 : H12AffineFastState.Bounded env16449 := by
  intro p hp
  have h : env16449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16448_16449 : H12AffineEnvironment.transform 9 272 env16448 = env16449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env16448 == env16449) = true)

theorem identity16449 : scanCanonicalize (H12AffineFastState.compose env16449 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 396) := by decide +kernel

theorem selectedBound16449 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16450 : List Nat := [2,4,8,16,32,17,128,256,1,272,1,0,8192,0,8233,65536,0,1,272,8232,0,260,16,74029,8328,17,0,0,0,0,21,396,256,73999,0,1]

theorem envBound16450 : H12AffineFastState.Bounded env16450 := by
  intro p hp
  have h : env16450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16449_16450 : H12AffineEnvironment.transform 31 396 env16449 = env16450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 396 env16449 == env16450) = true)

def env16451 : List Nat := [2,4,8,16,32,17,8,256,1,272,1,0,8192,0,8233,65536,0,1,272,8232,0,260,16,74029,8192,17,0,0,0,0,21,260,256,73999,0,1]

theorem envBound16451 : H12AffineFastState.Bounded env16451 := by
  intro p hp
  have h : env16451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16450_16451 : H12AffineEnvironment.transform 6 8 env16450 = env16451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16450 == env16451) = true)

theorem identity16451 : scanCanonicalize (H12AffineFastState.compose env16451 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 8462) := by decide +kernel

theorem selectedBound16451 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env16452 : List Nat := [2,4,8,16,32,17,8,256,1,272,1,0,8192,0,8233,8462,0,1,272,8232,0,260,16,35,8192,17,0,0,0,0,21,260,256,1,0,1]

theorem envBound16452 : H12AffineFastState.Bounded env16452 := by
  intro p hp
  have h : env16452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16451_16452 : H12AffineEnvironment.transform 15 8462 env16451 = env16452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8462 env16451 == env16452) = true)

theorem identity16452 : scanCanonicalize (H12AffineFastState.compose env16452 (packedSelected [0,2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound16452 : packedSelected [0,2,6] rootPS < 2^1333 := by decide +kernel

def env16453 : List Nat := [2,4,8,16,0,17,8,256,1,272,1,0,8192,0,8201,8462,0,1,272,8200,0,260,16,3,8192,17,0,0,0,0,21,260,256,1,0,1]

theorem envBound16453 : H12AffineFastState.Bounded env16453 := by
  intro p hp
  have h : env16453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16452_16453 : H12AffineEnvironment.transform 4 0 env16452 = env16453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16452 == env16453) = true)

theorem identity16453 : scanCanonicalize (H12AffineFastState.compose env16453 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound16453 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16454 : List Nat := [2,4,8,16,0,17,8,5,1,21,1,0,8192,0,8201,8203,0,1,21,8200,0,1,16,3,8192,17,0,0,0,0,21,1,5,1,0,1]

theorem envBound16454 : H12AffineFastState.Bounded env16454 := by
  intro p hp
  have h : env16454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16453_16454 : H12AffineEnvironment.transform 7 5 env16453 = env16454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env16453 == env16454) = true)

def leafEnv16454 : List Nat := [2,4,8,16,0,17,8,5,1,21,1,0,8192,0,8201,8203,0,1,21,8200,0,1,16,3,21,8192,1,17,0,0,0,0,21,1,5,1,4,8202,0,1,0,0,1]

def active16454 : List Nat := [0,1,2,3,12]

def tree16454 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16454 : H12WitnessSearch.Good tree16454 := H12GlobalWitnessIndex.good

theorem leafIdentity16454 : H12AffineFastState.composeSystem env16454 rootObs = leafEnv16454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16454 rootObs == leafEnv16454) = true)

theorem terminalChecked16454 : H12PackedTerminal.terminalCheckFast leafEnv16454 active16454 tree16454 = true := by decide +kernel

def env16455 : List Nat := [2,4,8,16,32,17,9,256,1,272,1,0,8192,0,8233,65536,0,1,272,8232,0,260,16,74029,8193,17,0,0,0,0,21,261,256,73999,0,1]

theorem envBound16455 : H12AffineFastState.Bounded env16455 := by
  intro p hp
  have h : env16455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16450_16455 : H12AffineEnvironment.transform 6 9 env16450 = env16455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16450 == env16455) = true)

theorem identity16455 : scanCanonicalize (H12AffineFastState.compose env16455 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound16455 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env16456 : List Nat := [2,4,8,16,32,17,9,5,1,21,1,0,8192,0,8233,65536,0,1,21,8232,0,1,16,73768,8193,17,0,0,0,0,21,0,5,73738,0,1]

theorem envBound16456 : H12AffineFastState.Bounded env16456 := by
  intro p hp
  have h : env16456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16455_16456 : H12AffineEnvironment.transform 7 5 env16455 = env16456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env16455 == env16456) = true)

def env16457 : List Nat := [2,4,8,16,32,17,128,256,1,273,1,1,8192,1,8233,65536,1,1,273,8232,1,260,16,74029,8328,17,0,1,1,0,20,4294967296,256,4295041155,1,1]

theorem envBound16457 : H12AffineFastState.Bounded env16457 := by
  intro p hp
  have h : env16457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16448_16457 : H12AffineEnvironment.transform 9 273 env16448 = env16457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env16448 == env16457) = true)

theorem identity16457 : scanCanonicalize (H12AffineFastState.compose env16457 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 73770) := by decide +kernel

theorem selectedBound16457 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16458 : List Nat := [2,4,8,16,32,17,128,256,1,273,1,1,8192,1,8233,65536,1,1,273,8232,1,260,16,74029,8328,17,0,1,1,0,20,73770,256,169,1,1]

theorem envBound16458 : H12AffineFastState.Bounded env16458 := by
  intro p hp
  have h : env16458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16457_16458 : H12AffineEnvironment.transform 31 73770 env16457 = env16458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 73770 env16457 == env16458) = true)

def env16459 : List Nat := [2,4,8,16,32,17,128,172,1,189,1,1,8192,1,8233,65536,1,1,189,8232,1,168,16,73857,8328,17,0,1,1,0,20,73770,172,169,1,1]

theorem envBound16459 : H12AffineFastState.Bounded env16459 := by
  intro p hp
  have h : env16459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16458_16459 : H12AffineEnvironment.transform 7 172 env16458 = env16459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env16458 == env16459) = true)

theorem identity16459 : scanCanonicalize (H12AffineFastState.compose env16459 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound16459 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env16460 : List Nat := [2,4,8,16,0,17,128,140,1,157,1,1,8192,1,8201,65536,1,1,157,8200,1,136,16,73857,8328,17,0,1,1,0,20,73738,140,137,1,1]

theorem envBound16460 : H12AffineFastState.Bounded env16460 := by
  intro p hp
  have h : env16460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16459_16460 : H12AffineEnvironment.transform 4 0 env16459 = env16460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16459 == env16460) = true)

theorem identity16460 : scanCanonicalize (H12AffineFastState.compose env16460 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound16460 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16461 : List Nat := [2,4,8,16,0,17,8,4,1,21,1,1,8192,1,8201,65536,1,1,21,8200,1,0,16,73737,8192,17,0,1,1,0,20,73738,4,1,1,1]

theorem envBound16461 : H12AffineFastState.Bounded env16461 := by
  intro p hp
  have h : env16461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16460_16461 : H12AffineEnvironment.transform 6 8 env16460 = env16461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16460 == env16461) = true)

theorem identity16461 : scanCanonicalize (H12AffineFastState.compose env16461 (packedSelected [0,6] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound16461 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env16462 : List Nat := [2,4,8,16,0,17,8,4,1,21,1,1,8192,1,8201,8202,1,1,21,8200,1,0,16,3,8192,17,0,1,1,0,20,0,4,1,1,1]

theorem envBound16462 : H12AffineFastState.Bounded env16462 := by
  intro p hp
  have h : env16462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16461_16462 : H12AffineEnvironment.transform 15 8202 env16461 = env16462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env16461 == env16462) = true)

def env16463 : List Nat := [2,4,8,16,32,17,128,173,1,188,1,1,8192,1,8233,65536,1,1,188,8232,1,169,16,73856,8328,17,0,1,1,0,20,73770,173,169,1,1]

theorem envBound16463 : H12AffineFastState.Bounded env16463 := by
  intro p hp
  have h : env16463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16458_16463 : H12AffineEnvironment.transform 7 173 env16458 = env16463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env16458 == env16463) = true)

theorem identity16463 : scanCanonicalize (H12AffineFastState.compose env16463 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 8355) := by decide +kernel

theorem selectedBound16463 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env16464 : List Nat := [2,4,8,16,32,17,128,173,1,188,1,1,8192,1,8233,8355,1,1,188,8232,1,169,16,35,8328,17,0,1,1,0,20,137,173,169,1,1]

theorem envBound16464 : H12AffineFastState.Bounded env16464 := by
  intro p hp
  have h : env16464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16463_16464 : H12AffineEnvironment.transform 15 8355 env16463 = env16464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8355 env16463 == env16464) = true)

theorem identity16464 : scanCanonicalize (H12AffineFastState.compose env16464 (packedSelected [0,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound16464 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env16465 : List Nat := [2,4,8,16,0,17,128,141,1,156,1,1,8192,1,8201,8323,1,1,156,8200,1,137,16,3,8328,17,0,1,1,0,20,137,141,137,1,1]

theorem envBound16465 : H12AffineFastState.Bounded env16465 := by
  intro p hp
  have h : env16465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16464_16465 : H12AffineEnvironment.transform 4 0 env16464 = env16465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16464 == env16465) = true)

def env16466 : List Nat := [2,4,8,16,0,17,128,141,1,156,1,1,128,1,137,3,1,1,156,136,1,137,16,3,8,17,0,1,1,0,20,137,141,137,1,1]

theorem envBound16466 : H12AffineFastState.Bounded env16466 := by
  intro p hp
  have h : env16466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16465_16466 : H12AffineEnvironment.transform 12 128 env16465 = env16466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 128 env16465 == env16466) = true)

def leafEnv16466 : List Nat := [2,4,8,16,0,17,128,141,1,156,1,1,128,1,137,3,1,1,156,136,1,137,16,3,20,8,1,17,0,1,1,0,20,137,141,137,4,2,1,1,0,1,1]

def active16466 : List Nat := [0,1,2,3,6]

def tree16466 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16466 : H12WitnessSearch.Good tree16466 := H12GlobalWitnessIndex.good

theorem leafIdentity16466 : H12AffineFastState.composeSystem env16466 rootObs = leafEnv16466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16466 rootObs == leafEnv16466) = true)

theorem terminalChecked16466 : H12PackedTerminal.terminalCheckFast leafEnv16466 active16466 tree16466 = true := by decide +kernel

def env16467 : List Nat := [2,4,8,16,0,17,128,141,1,156,1,1,129,1,136,2,1,1,156,137,1,137,16,3,9,17,0,1,1,0,20,137,141,137,1,1]

theorem envBound16467 : H12AffineFastState.Bounded env16467 := by
  intro p hp
  have h : env16467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16465_16467 : H12AffineEnvironment.transform 12 129 env16465 = env16467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 129 env16465 == env16467) = true)

theorem identity16467 : scanCanonicalize (H12AffineFastState.compose env16467 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound16467 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16468 : List Nat := [2,4,8,16,0,17,8,5,1,20,1,1,9,1,0,2,1,1,20,1,1,1,16,3,9,17,0,1,1,0,20,1,5,1,1,1]

theorem envBound16468 : H12AffineFastState.Bounded env16468 := by
  intro p hp
  have h : env16468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16467_16468 : H12AffineEnvironment.transform 6 8 env16467 = env16468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16467 == env16468) = true)

def leafEnv16468 : List Nat := [2,4,8,16,0,17,8,5,1,20,1,1,9,1,0,2,1,1,20,1,1,1,16,3,20,9,1,17,0,1,1,0,20,1,5,1,4,3,1,1,0,1,1]

def active16468 : List Nat := [0,1,2,3]

def tree16468 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16468 : H12WitnessSearch.Good tree16468 := H12GlobalWitnessIndex.good

theorem leafIdentity16468 : H12AffineFastState.composeSystem env16468 rootObs = leafEnv16468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16468 rootObs == leafEnv16468) = true)

theorem terminalChecked16468 : H12PackedTerminal.terminalCheckFast leafEnv16468 active16468 tree16468 = true := by decide +kernel

def env16469 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,1345,8192,1297,10281,65536,1345,1,1025,10280,1345,2308,17,76077,8328,64,2049,1297,1296,0,1285,4294967296,256,4295041155,1345,1]

theorem envBound16469 : H12AffineFastState.Bounded env16469 := by
  intro p hp
  have h : env16469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16417_16469 : H12AffineEnvironment.transform 13 1297 env16417 = env16469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env16417 == env16469) = true)

theorem identity16469 : scanCanonicalize (H12AffineFastState.compose env16469 (packedSelected [5,8] rootPS)) = affineNative (2^(15+1) ^^^ 10542) := by decide +kernel

theorem selectedBound16469 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env16470 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,1345,8192,1297,10281,10542,1345,1,1025,10280,1345,2308,17,3,8328,64,2049,1297,1296,0,1285,4294967296,256,4294969773,1345,1]

theorem envBound16470 : H12AffineFastState.Bounded env16470 := by
  intro p hp
  have h : env16470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16469_16470 : H12AffineEnvironment.transform 15 10542 env16469 = env16470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 10542 env16469 == env16470) = true)

theorem identity16470 : scanCanonicalize (H12AffineFastState.compose env16470 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound16470 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env16471 : List Nat := [2,4,8,16,32,64,8,256,1,1024,2048,1345,8192,1297,10281,10542,1345,1,1025,10280,1345,2308,17,3,8192,64,2049,1297,1296,0,1285,4294967296,256,4294969637,1345,1]

theorem envBound16471 : H12AffineFastState.Bounded env16471 := by
  intro p hp
  have h : env16471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16470_16471 : H12AffineEnvironment.transform 6 8 env16470 = env16471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16470 == env16471) = true)

theorem identity16471 : scanCanonicalize (H12AffineFastState.compose env16471 (packedSelected [1,10] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound16471 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env16472 : List Nat := [2,4,8,16,32,64,8,256,1,1024,293,1345,8192,1297,8460,8203,1345,1,1025,8461,1345,33,17,3,8192,64,292,1297,1296,0,1285,4294967296,256,4294967296,1345,1]

theorem envBound16472 : H12AffineFastState.Bounded env16472 := by
  intro p hp
  have h : env16472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16471_16472 : H12AffineEnvironment.transform 10 293 env16471 = env16472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env16471 == env16472) = true)

theorem identity16472 : scanCanonicalize (H12AffineFastState.compose env16472 (packedSelected [2] rootPS)) = affineNative (2^(31+1) ^^^ 97) := by decide +kernel

theorem selectedBound16472 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16473 : List Nat := [2,4,8,16,32,64,8,256,1,1024,293,1345,8192,1297,8460,8203,1345,1,1025,8461,1345,33,17,3,8192,64,292,1297,1296,0,1285,97,256,97,1345,1]

theorem envBound16473 : H12AffineFastState.Bounded env16473 := by
  intro p hp
  have h : env16473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16472_16473 : H12AffineEnvironment.transform 31 97 env16472 = env16473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 97 env16472 == env16473) = true)

theorem identity16473 : scanCanonicalize (H12AffineFastState.compose env16473 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound16473 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env16474 : List Nat := [2,4,8,16,32,64,8,69,1,1024,96,1028,8192,1108,8265,8203,1028,1,1025,8264,1028,33,17,3,8192,64,97,1108,1109,0,1088,97,69,97,1028,1]

theorem envBound16474 : H12AffineFastState.Bounded env16474 := by
  intro p hp
  have h : env16474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16473_16474 : H12AffineEnvironment.transform 7 69 env16473 = env16474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env16473 == env16474) = true)

theorem identity16474 : scanCanonicalize (H12AffineFastState.compose env16474 (packedSelected [1,12] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound16474 : packedSelected [1,12] rootPS < 2^1333 := by decide +kernel

def env16475 : List Nat := [2,4,2,16,32,64,2,69,1,1024,96,1028,8192,1108,8259,8193,1028,1,1025,8258,1028,33,17,3,8192,64,97,1108,1109,0,1088,97,69,97,1028,1]

theorem envBound16475 : H12AffineFastState.Bounded env16475 := by
  intro p hp
  have h : env16475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16474_16475 : H12AffineEnvironment.transform 2 2 env16474 = env16475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env16474 == env16475) = true)

def env16476 : List Nat := [2,4,2,16,32,32,2,37,1,1024,0,1028,8192,1076,8227,8193,1028,1,1025,8226,1028,33,17,3,8192,32,1,1076,1077,0,1056,1,37,1,1028,1]

theorem envBound16476 : H12AffineFastState.Bounded env16476 := by
  intro p hp
  have h : env16476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16475_16476 : H12AffineEnvironment.transform 5 32 env16475 = env16476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env16475 == env16476) = true)

theorem identity16476 : scanCanonicalize (H12AffineFastState.compose env16476 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 34) := by decide +kernel

theorem selectedBound16476 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16477 : List Nat := [2,4,2,16,32,32,2,37,1,1024,0,1028,34,1076,1,35,1028,1,1025,0,1028,33,17,3,34,32,1,1076,1077,0,1056,1,37,1,1028,1]

theorem envBound16477 : H12AffineFastState.Bounded env16477 := by
  intro p hp
  have h : env16477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16476_16477 : H12AffineEnvironment.transform 12 34 env16476 = env16477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 34 env16476 == env16477) = true)

def leafEnv16477 : List Nat := [2,4,2,16,32,32,2,37,1,1024,0,1028,34,1076,1,35,1028,1,1025,0,1028,33,17,3,1057,34,1,32,1,1076,1077,0,1056,1,37,1,4,34,1028,1,0,1077,1]

def active16477 : List Nat := [0,1,3,4,9]

def tree16477 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16477 : H12WitnessSearch.Good tree16477 := H12GlobalWitnessIndex.good

theorem leafIdentity16477 : H12AffineFastState.composeSystem env16477 rootObs = leafEnv16477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16477 rootObs == leafEnv16477) = true)

theorem terminalChecked16477 : H12PackedTerminal.terminalCheckFast leafEnv16477 active16477 tree16477 = true := by decide +kernel

def env16478 : List Nat := [2,4,2,16,32,33,2,36,1,1024,1,1028,8192,1077,8226,8193,1028,1,1025,8227,1028,33,17,3,8192,33,0,1077,1076,0,1057,0,36,0,1028,1]

theorem envBound16478 : H12AffineFastState.Bounded env16478 := by
  intro p hp
  have h : env16478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16475_16478 : H12AffineEnvironment.transform 5 33 env16475 = env16478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env16475 == env16478) = true)

def env16479 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,16384,32768,65536,1345,512,16656,32769,1345,4194304,17664,98564,8328,64,134217728,16384,1296,1,1285,4294967296,256,4299260334,138429268,512]

theorem envBound16479 : H12AffineFastState.Bounded env16479 := by
  intro p hp
  have h : env16479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16388_16479 : H12AffineEnvironment.transform 29 1 env16388 = env16479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 1 env16388 == env16479) = true)

def env16480 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,1345,8192,16384,32768,65536,1345,0,16656,32769,1345,4194304,17664,98564,8328,64,134217728,16384,1296,1,1285,4294967296,256,4299260334,138428756,0]

theorem envBound16480 : H12AffineFastState.Bounded env16480 := by
  intro p hp
  have h : env16480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16479_16480 : H12AffineEnvironment.transform 8 0 env16479 = env16480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env16479 == env16480) = true)

theorem identity16480 : scanCanonicalize (H12AffineFastState.compose env16480 (packedSelected [18] rootPS)) = affineNative (2^(26+1) ^^^ 2049) := by decide +kernel

theorem selectedBound16480 : packedSelected [18] rootPS < 2^1333 := by decide +kernel

def env16481 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,1345,8192,16384,32768,65536,1345,0,16656,32769,1345,4194304,17664,98564,8328,64,2049,16384,1296,1,1285,4294967296,256,4299260334,4213077,0]

theorem envBound16481 : H12AffineFastState.Bounded env16481 := by
  intro p hp
  have h : env16481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16480_16481 : H12AffineEnvironment.transform 26 2049 env16480 = env16481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 2049 env16480 == env16481) = true)

theorem identity16481 : scanCanonicalize (H12AffineFastState.compose env16481 (packedSelected [23] rootPS)) = affineNative (2^(21+1) ^^^ 19476) := by decide +kernel

theorem selectedBound16481 : packedSelected [23] rootPS < 2^1333 := by decide +kernel

def env16482 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,1345,8192,16384,32768,65536,1345,0,16656,32769,1345,19476,17664,98564,8328,64,2049,16384,1296,1,1285,4294967296,256,4295085498,1345,0]

theorem envBound16482 : H12AffineFastState.Bounded env16482 := by
  intro p hp
  have h : env16482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16481_16482 : H12AffineEnvironment.transform 21 19476 env16481 = env16482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 19476 env16481 == env16482) = true)

theorem identity16482 : scanCanonicalize (H12AffineFastState.compose env16482 (packedSelected [0,7] rootPS)) = affineNative (2^(14+1) ^^^ 27961) := by decide +kernel

theorem selectedBound16482 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env16483 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,1345,8192,16384,27961,65536,1345,0,16656,27960,1345,19476,17664,93245,8328,64,2049,16384,1296,1,1285,4294967296,256,4295041155,1345,0]

theorem envBound16483 : H12AffineFastState.Bounded env16483 := by
  intro p hp
  have h : env16483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16482_16483 : H12AffineEnvironment.transform 14 27961 env16482 = env16483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 27961 env16482 == env16483) = true)

def env16484 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,1345,8192,1296,10281,65536,1345,0,1024,10280,1345,2308,16,76077,8328,64,2049,1296,1296,1,1285,4294967296,256,4295041155,1345,0]

theorem envBound16484 : H12AffineFastState.Bounded env16484 := by
  intro p hp
  have h : env16484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16483_16484 : H12AffineEnvironment.transform 13 1296 env16483 = env16484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env16483 == env16484) = true)

def env16485 : List Nat := [2,4,8,16,32,64,128,256,0,1024,0,1345,8192,1296,8233,65536,1345,0,1024,8232,1345,260,16,74029,8328,64,1,1296,1296,1,1285,4294967296,256,4295041155,1345,0]

theorem envBound16485 : H12AffineFastState.Bounded env16485 := by
  intro p hp
  have h : env16485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16484_16485 : H12AffineEnvironment.transform 10 0 env16484 = env16485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env16484 == env16485) = true)

theorem identity16485 : scanCanonicalize (H12AffineFastState.compose env16485 (packedSelected [5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound16485 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env16486 : List Nat := [2,4,8,16,32,17,128,256,0,1024,0,1296,8192,1296,8233,65536,1296,0,1024,8232,1296,260,16,74029,8328,17,1,1296,1296,1,1285,4294967296,256,4295041155,1296,0]

theorem envBound16486 : H12AffineFastState.Bounded env16486 := by
  intro p hp
  have h : env16486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16485_16486 : H12AffineEnvironment.transform 5 17 env16485 = env16486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env16485 == env16486) = true)

def env16487 : List Nat := [2,4,8,16,32,17,128,256,0,272,0,0,8192,0,8233,65536,0,0,272,8232,0,260,16,74029,8328,17,1,0,0,1,21,4294967296,256,4295041155,0,0]

theorem envBound16487 : H12AffineFastState.Bounded env16487 := by
  intro p hp
  have h : env16487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16486_16487 : H12AffineEnvironment.transform 9 272 env16486 = env16487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env16486 == env16487) = true)

theorem identity16487 : scanCanonicalize (H12AffineFastState.compose env16487 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 396) := by decide +kernel

theorem selectedBound16487 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16488 : List Nat := [2,4,8,16,32,17,128,256,0,272,0,0,8192,0,8233,65536,0,0,272,8232,0,260,16,74029,8328,17,1,0,0,1,21,396,256,73999,0,0]

theorem envBound16488 : H12AffineFastState.Bounded env16488 := by
  intro p hp
  have h : env16488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16487_16488 : H12AffineEnvironment.transform 31 396 env16487 = env16488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 396 env16487 == env16488) = true)

def env16489 : List Nat := [2,4,8,16,32,17,8,256,0,272,0,0,8192,0,8233,65536,0,0,272,8232,0,260,16,74029,8192,17,1,0,0,1,21,260,256,73999,0,0]

theorem envBound16489 : H12AffineFastState.Bounded env16489 := by
  intro p hp
  have h : env16489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16488_16489 : H12AffineEnvironment.transform 6 8 env16488 = env16489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16488 == env16489) = true)

theorem identity16489 : scanCanonicalize (H12AffineFastState.compose env16489 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound16489 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env16490 : List Nat := [2,4,8,16,0,17,8,256,0,272,0,0,8192,0,8201,65536,0,0,272,8200,0,260,16,73997,8192,17,1,0,0,1,21,260,256,73999,0,0]

theorem envBound16490 : H12AffineFastState.Bounded env16490 := by
  intro p hp
  have h : env16490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16489_16490 : H12AffineEnvironment.transform 4 0 env16489 = env16490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16489 == env16490) = true)

def env16491 : List Nat := [2,4,8,16,0,17,8,256,0,272,0,0,8,0,1,65536,0,0,272,0,0,260,16,65797,8,17,1,0,0,1,21,260,256,65799,0,0]

theorem envBound16491 : H12AffineFastState.Bounded env16491 := by
  intro p hp
  have h : env16491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16490_16491 : H12AffineEnvironment.transform 12 8 env16490 = env16491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env16490 == env16491) = true)

theorem identity16491 : scanCanonicalize (H12AffineFastState.compose env16491 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound16491 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16492 : List Nat := [2,4,8,16,0,17,8,256,0,272,0,0,8,0,1,2,0,0,272,0,0,260,16,263,8,17,1,0,0,1,21,260,256,261,0,0]

theorem envBound16492 : H12AffineFastState.Bounded env16492 := by
  intro p hp
  have h : env16492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16491_16492 : H12AffineEnvironment.transform 15 2 env16491 = env16492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env16491 == env16492) = true)

def env16493 : List Nat := [2,4,8,16,0,17,8,256,0,272,0,0,9,0,0,65536,0,0,272,1,0,260,16,65796,9,17,1,0,0,1,21,260,256,65798,0,0]

theorem envBound16493 : H12AffineFastState.Bounded env16493 := by
  intro p hp
  have h : env16493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16490_16493 : H12AffineEnvironment.transform 12 9 env16490 = env16493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env16490 == env16493) = true)

theorem identity16493 : scanCanonicalize (H12AffineFastState.compose env16493 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound16493 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16494 : List Nat := [2,4,8,16,0,17,8,4,0,20,0,0,9,0,0,65536,0,0,20,1,0,0,16,65536,9,17,1,0,0,1,21,0,4,65538,0,0]

theorem envBound16494 : H12AffineFastState.Bounded env16494 := by
  intro p hp
  have h : env16494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16493_16494 : H12AffineEnvironment.transform 7 4 env16493 = env16494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env16493 == env16494) = true)

theorem identity16494 : scanCanonicalize (H12AffineFastState.compose env16494 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound16494 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16495 : List Nat := [2,4,8,16,0,17,8,4,0,20,0,0,9,0,0,2,0,0,20,1,0,0,16,2,9,17,1,0,0,1,21,0,4,0,0,0]

theorem envBound16495 : H12AffineFastState.Bounded env16495 := by
  intro p hp
  have h : env16495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16494_16495 : H12AffineEnvironment.transform 15 2 env16494 = env16495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env16494 == env16495) = true)

def leafEnv16495 : List Nat := [2,4,8,16,0,17,8,4,0,20,0,0,9,0,0,2,0,0,20,1,0,0,16,2,21,9,1,17,1,0,0,1,21,0,4,0,4,2,0,0,0,0,1]

def active16495 : List Nat := [0,1,2,3]

def tree16495 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16495 : H12WitnessSearch.Good tree16495 := H12GlobalWitnessIndex.good

theorem leafIdentity16495 : H12AffineFastState.composeSystem env16495 rootObs = leafEnv16495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16495 rootObs == leafEnv16495) = true)

theorem terminalChecked16495 : H12PackedTerminal.terminalCheckFast leafEnv16495 active16495 tree16495 = true := by decide +kernel

def env16496 : List Nat := [2,4,8,16,32,17,9,256,0,272,0,0,8192,0,8233,65536,0,0,272,8232,0,260,16,74029,8193,17,1,0,0,1,21,261,256,73999,0,0]

theorem envBound16496 : H12AffineFastState.Bounded env16496 := by
  intro p hp
  have h : env16496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16488_16496 : H12AffineEnvironment.transform 6 9 env16488 = env16496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16488 == env16496) = true)

theorem identity16496 : scanCanonicalize (H12AffineFastState.compose env16496 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 8235) := by decide +kernel

theorem selectedBound16496 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env16497 : List Nat := [2,4,8,16,32,17,9,256,0,272,0,0,8192,0,8233,8235,0,0,272,8232,0,260,16,262,8193,17,1,0,0,1,21,261,256,292,0,0]

theorem envBound16497 : H12AffineFastState.Bounded env16497 := by
  intro p hp
  have h : env16497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16496_16497 : H12AffineEnvironment.transform 15 8235 env16496 = env16497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8235 env16496 == env16497) = true)

theorem identity16497 : scanCanonicalize (H12AffineFastState.compose env16497 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound16497 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16498 : List Nat := [2,4,8,16,32,17,9,5,0,21,0,0,8192,0,8233,8235,0,0,21,8232,0,1,16,3,8193,17,1,0,0,1,21,0,5,33,0,0]

theorem envBound16498 : H12AffineFastState.Bounded env16498 := by
  intro p hp
  have h : env16498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16497_16498 : H12AffineEnvironment.transform 7 5 env16497 = env16498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env16497 == env16498) = true)

theorem identity16498 : scanCanonicalize (H12AffineFastState.compose env16498 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound16498 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16499 : List Nat := [2,4,8,16,32,17,9,5,0,21,0,0,8,0,33,35,0,0,21,32,0,1,16,3,9,17,1,0,0,1,21,0,5,33,0,0]

theorem envBound16499 : H12AffineFastState.Bounded env16499 := by
  intro p hp
  have h : env16499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16498_16499 : H12AffineEnvironment.transform 12 8 env16498 = env16499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env16498 == env16499) = true)

def env16500 : List Nat := [2,4,8,16,32,17,128,256,0,273,0,1,8192,1,8233,65536,1,0,273,8232,1,260,16,74029,8328,17,1,1,1,1,20,4294967296,256,4295041155,1,0]

theorem envBound16500 : H12AffineFastState.Bounded env16500 := by
  intro p hp
  have h : env16500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16486_16500 : H12AffineEnvironment.transform 9 273 env16486 = env16500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env16486 == env16500) = true)

theorem identity16500 : scanCanonicalize (H12AffineFastState.compose env16500 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 73770) := by decide +kernel

theorem selectedBound16500 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16501 : List Nat := [2,4,8,16,32,17,128,256,0,273,0,1,8192,1,8233,65536,1,0,273,8232,1,260,16,74029,8328,17,1,1,1,1,20,73770,256,169,1,0]

theorem envBound16501 : H12AffineFastState.Bounded env16501 := by
  intro p hp
  have h : env16501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16500_16501 : H12AffineEnvironment.transform 31 73770 env16500 = env16501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 73770 env16500 == env16501) = true)

def env16502 : List Nat := [2,4,8,16,32,17,128,172,0,189,0,1,8192,1,8233,65536,1,0,189,8232,1,168,16,73857,8328,17,1,1,1,1,20,73770,172,169,1,0]

theorem envBound16502 : H12AffineFastState.Bounded env16502 := by
  intro p hp
  have h : env16502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16501_16502 : H12AffineEnvironment.transform 7 172 env16501 = env16502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env16501 == env16502) = true)

theorem identity16502 : scanCanonicalize (H12AffineFastState.compose env16502 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 8354) := by decide +kernel

theorem selectedBound16502 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env16503 : List Nat := [2,4,8,16,32,17,128,172,0,189,0,1,8192,1,8233,8354,1,0,189,8232,1,168,16,35,8328,17,1,1,1,1,20,136,172,169,1,0]

theorem envBound16503 : H12AffineFastState.Bounded env16503 := by
  intro p hp
  have h : env16503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16502_16503 : H12AffineEnvironment.transform 15 8354 env16502 = env16503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8354 env16502 == env16503) = true)

def env16504 : List Nat := [2,4,8,16,32,17,128,173,0,188,0,1,8192,1,8233,65536,1,0,188,8232,1,169,16,73856,8328,17,1,1,1,1,20,73770,173,169,1,0]

theorem envBound16504 : H12AffineFastState.Bounded env16504 := by
  intro p hp
  have h : env16504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16501_16504 : H12AffineEnvironment.transform 7 173 env16501 = env16504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env16501 == env16504) = true)

theorem identity16504 : scanCanonicalize (H12AffineFastState.compose env16504 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound16504 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env16505 : List Nat := [2,4,8,16,0,17,128,141,0,156,0,1,8192,1,8201,65536,1,0,156,8200,1,137,16,73856,8328,17,1,1,1,1,20,73738,141,137,1,0]

theorem envBound16505 : H12AffineFastState.Bounded env16505 := by
  intro p hp
  have h : env16505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16504_16505 : H12AffineEnvironment.transform 4 0 env16504 = env16505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16504 == env16505) = true)

def env16506 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1,1345,8192,1296,8232,65536,1345,0,1024,8233,1345,261,16,74028,8328,64,0,1296,1296,1,1285,4294967296,256,4295041155,1345,0]

theorem envBound16506 : H12AffineFastState.Bounded env16506 := by
  intro p hp
  have h : env16506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16484_16506 : H12AffineEnvironment.transform 10 1 env16484 = env16506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env16484 == env16506) = true)

def env16507 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1,1345,8192,1296,8232,65536,1345,0,1024,8233,1345,261,16,74028,8328,64,0,1296,1296,1,1285,260,256,74119,1345,0]

theorem envBound16507 : H12AffineFastState.Bounded env16507 := by
  intro p hp
  have h : env16507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16506_16507 : H12AffineEnvironment.transform 31 260 env16506 = env16507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 260 env16506 == env16507) = true)

theorem identity16507 : scanCanonicalize (H12AffineFastState.compose env16507 (packedSelected [4] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound16507 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env16508 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1,1345,8192,1296,8232,3,1345,0,1024,8233,1345,261,16,8495,8328,64,0,1296,1296,1,1285,260,256,8580,1345,0]

theorem envBound16508 : H12AffineFastState.Bounded env16508 := by
  intro p hp
  have h : env16508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16507_16508 : H12AffineEnvironment.transform 15 3 env16507 = env16508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env16507 == env16508) = true)

def env16509 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1,1345,40,1296,0,3,1345,0,1024,1,1345,261,16,263,160,64,0,1296,1296,1,1285,260,256,428,1345,0]

theorem envBound16509 : H12AffineFastState.Bounded env16509 := by
  intro p hp
  have h : env16509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16508_16509 : H12AffineEnvironment.transform 12 40 env16508 = env16509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env16508 == env16509) = true)

theorem identity16509 : scanCanonicalize (H12AffineFastState.compose env16509 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound16509 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16510 : List Nat := [2,4,8,16,32,64,128,173,0,1024,1,1260,40,1213,0,3,1260,0,1024,1,1260,168,16,170,160,64,0,1213,1213,1,1192,169,173,1,1260,0]

theorem envBound16510 : H12AffineFastState.Bounded env16510 := by
  intro p hp
  have h : env16510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16509_16510 : H12AffineEnvironment.transform 7 173 env16509 = env16510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env16509 == env16510) = true)

theorem identity16510 : scanCanonicalize (H12AffineFastState.compose env16510 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound16510 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16511 : List Nat := [2,4,8,16,32,64,40,5,0,1024,1,1092,40,1045,0,3,1092,0,1024,1,1092,0,16,2,8,64,0,1045,1045,1,1024,1,5,1,1092,0]

theorem envBound16511 : H12AffineFastState.Bounded env16511 := by
  intro p hp
  have h : env16511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16510_16511 : H12AffineEnvironment.transform 6 40 env16510 = env16511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env16510 == env16511) = true)

theorem identity16511 : scanCanonicalize (H12AffineFastState.compose env16511 (packedSelected [1,3,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound16511 : packedSelected [1,3,12] rootPS < 2^1333 := by decide +kernel

def env16512 : List Nat := [2,4,8,16,32,17,40,5,0,1024,1,1045,40,1045,0,3,1045,0,1024,1,1045,0,16,2,8,17,0,1045,1045,1,1024,1,5,1,1045,0]

theorem envBound16512 : H12AffineFastState.Bounded env16512 := by
  intro p hp
  have h : env16512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16511_16512 : H12AffineEnvironment.transform 5 17 env16511 = env16512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env16511 == env16512) = true)

def env16513 : List Nat := [2,4,8,16,0,17,8,5,0,1024,1,1045,8,1045,0,3,1045,0,1024,1,1045,0,16,2,8,17,0,1045,1045,1,1024,1,5,1,1045,0]

theorem envBound16513 : H12AffineFastState.Bounded env16513 := by
  intro p hp
  have h : env16513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16512_16513 : H12AffineEnvironment.transform 4 0 env16512 = env16513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16512 == env16513) = true)

theorem identity16513 : scanCanonicalize (H12AffineFastState.compose env16513 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound16513 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16514 : List Nat := [2,4,8,16,0,17,8,5,0,20,1,1,8,1,0,3,1,0,20,1,1,0,16,2,8,17,0,1,1,1,20,1,5,1,1,0]

theorem envBound16514 : H12AffineFastState.Bounded env16514 := by
  intro p hp
  have h : env16514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16513_16514 : H12AffineEnvironment.transform 9 20 env16513 = env16514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env16513 == env16514) = true)

def leafEnv16514 : List Nat := [2,4,8,16,0,17,8,5,0,20,1,1,8,1,0,3,1,0,20,1,1,0,16,2,20,8,1,17,0,1,1,1,20,1,5,1,4,3,1,0,0,1,1]

def active16514 : List Nat := [0,1,2,3]

def tree16514 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16514 : H12WitnessSearch.Good tree16514 := H12GlobalWitnessIndex.good

theorem leafIdentity16514 : H12AffineFastState.composeSystem env16514 rootObs = leafEnv16514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16514 rootObs == leafEnv16514) = true)

theorem terminalChecked16514 : H12PackedTerminal.terminalCheckFast leafEnv16514 active16514 tree16514 = true := by decide +kernel

def env16515 : List Nat := [2,4,8,16,1,17,9,5,0,1024,1,1045,9,1045,0,3,1045,0,1024,1,1045,0,16,2,8,17,0,1045,1045,1,1024,1,5,1,1045,0]

theorem envBound16515 : H12AffineFastState.Bounded env16515 := by
  intro p hp
  have h : env16515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16512_16515 : H12AffineEnvironment.transform 4 1 env16512 = env16515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16512 == env16515) = true)

def leafEnv16515 : List Nat := [2,4,8,16,1,17,9,5,0,1024,1,1045,9,1045,0,3,1045,0,1024,1,1045,0,16,2,1024,8,1,17,0,1045,1045,1,1024,1,5,1,4,3,1045,0,0,1045,1]

def active16515 : List Nat := [0,1,2,3,9]

def tree16515 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16515 : H12WitnessSearch.Good tree16515 := H12GlobalWitnessIndex.good

theorem leafIdentity16515 : H12AffineFastState.composeSystem env16515 rootObs = leafEnv16515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16515 rootObs == leafEnv16515) = true)

theorem terminalChecked16515 : H12PackedTerminal.terminalCheckFast leafEnv16515 active16515 tree16515 = true := by decide +kernel

def env16516 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1,1345,41,1296,1,3,1345,0,1024,0,1345,261,16,262,161,64,0,1296,1296,1,1285,260,256,429,1345,0]

theorem envBound16516 : H12AffineFastState.Bounded env16516 := by
  intro p hp
  have h : env16516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16508_16516 : H12AffineEnvironment.transform 12 41 env16508 = env16516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env16508 == env16516) = true)

theorem identity16516 : scanCanonicalize (H12AffineFastState.compose env16516 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound16516 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16517 : List Nat := [2,4,8,16,1,64,128,256,0,1024,1,1345,8,1296,1,3,1345,0,1024,0,1345,261,16,262,128,64,0,1296,1296,1,1285,260,256,396,1345,0]

theorem envBound16517 : H12AffineFastState.Bounded env16517 := by
  intro p hp
  have h : env16517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16516_16517 : H12AffineEnvironment.transform 4 1 env16516 = env16517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16516 == env16517) = true)

def env16518 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1,1345,8192,1296,8232,65536,1345,0,1024,8233,1345,261,16,74028,8328,64,0,1296,1296,1,1285,261,256,74118,1345,0]

theorem envBound16518 : H12AffineFastState.Bounded env16518 := by
  intro p hp
  have h : env16518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16506_16518 : H12AffineEnvironment.transform 31 261 env16506 = env16518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 261 env16506 == env16518) = true)

theorem identity16518 : scanCanonicalize (H12AffineFastState.compose env16518 (packedSelected [4] rootPS)) = affineNative (2^(12+1) ^^^ 129) := by decide +kernel

theorem selectedBound16518 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env16519 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1,1345,129,1296,169,65536,1345,0,1024,168,1345,261,16,65965,9,64,0,1296,1296,1,1285,261,256,65799,1345,0]

theorem envBound16519 : H12AffineFastState.Bounded env16519 := by
  intro p hp
  have h : env16519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16518_16519 : H12AffineEnvironment.transform 12 129 env16518 = env16519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 129 env16518 == env16519) = true)

def env16520 : List Nat := [2,4,8,16,32,64,128,140,0,1024,1,1229,129,1180,169,65536,1229,0,1024,168,1229,137,16,65569,9,64,0,1180,1180,1,1161,137,140,65675,1229,0]

theorem envBound16520 : H12AffineFastState.Bounded env16520 := by
  intro p hp
  have h : env16520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16519_16520 : H12AffineEnvironment.transform 7 140 env16519 = env16520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env16519 == env16520) = true)

theorem identity16520 : scanCanonicalize (H12AffineFastState.compose env16520 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound16520 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16521 : List Nat := [2,4,8,16,32,64,128,140,0,1024,1,1229,129,1180,169,34,1229,0,1024,168,1229,137,16,3,9,64,0,1180,1180,1,1161,137,140,169,1229,0]

theorem envBound16521 : H12AffineFastState.Bounded env16521 := by
  intro p hp
  have h : env16521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16520_16521 : H12AffineEnvironment.transform 15 34 env16520 = env16521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env16520 == env16521) = true)

theorem identity16521 : scanCanonicalize (H12AffineFastState.compose env16521 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound16521 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16522 : List Nat := [2,4,8,16,32,64,41,37,0,1024,1,1124,40,1077,0,34,1124,0,1024,1,1124,32,16,3,9,64,0,1077,1077,1,1056,32,37,0,1124,0]

theorem envBound16522 : H12AffineFastState.Bounded env16522 := by
  intro p hp
  have h : env16522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16521_16522 : H12AffineEnvironment.transform 6 41 env16521 = env16522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env16521 == env16522) = true)

theorem identity16522 : scanCanonicalize (H12AffineFastState.compose env16522 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound16522 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env16523 : List Nat := [2,4,8,16,1,64,8,4,0,1024,1,1093,9,1044,0,3,1093,0,1024,1,1093,1,16,3,9,64,0,1044,1044,1,1025,1,4,0,1093,0]

theorem envBound16523 : H12AffineFastState.Bounded env16523 := by
  intro p hp
  have h : env16523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16522_16523 : H12AffineEnvironment.transform 4 1 env16522 = env16523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16522 == env16523) = true)

def leafEnv16523 : List Nat := [2,4,8,16,1,64,8,4,0,1024,1,1093,9,1044,0,3,1093,0,1024,1,1093,1,16,3,1025,9,1,64,0,1044,1044,1,1025,1,4,0,4,2,1093,0,0,1044,1]

def active16523 : List Nat := [0,1,2,3,5,9]

def tree16523 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16523 : H12WitnessSearch.Good tree16523 := H12GlobalWitnessIndex.good

theorem leafIdentity16523 : H12AffineFastState.composeSystem env16523 rootObs = leafEnv16523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16523 rootObs == leafEnv16523) = true)

theorem terminalChecked16523 : H12PackedTerminal.terminalCheckFast leafEnv16523 active16523 tree16523 = true := by decide +kernel

def env16524 : List Nat := [2,4,8,16,32,64,128,141,0,1024,1,1228,129,1181,169,65536,1228,0,1024,168,1228,136,16,65568,9,64,0,1181,1181,1,1160,136,141,65674,1228,0]

theorem envBound16524 : H12AffineFastState.Bounded env16524 := by
  intro p hp
  have h : env16524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16519_16524 : H12AffineEnvironment.transform 7 141 env16519 = env16524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env16519 == env16524) = true)

theorem identity16524 : scanCanonicalize (H12AffineFastState.compose env16524 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound16524 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16525 : List Nat := [2,4,8,16,32,64,9,4,0,1024,1,1093,8,1044,32,65536,1093,0,1024,33,1093,1,16,65568,9,64,0,1044,1044,1,1025,1,4,65539,1093,0]

theorem envBound16525 : H12AffineFastState.Bounded env16525 := by
  intro p hp
  have h : env16525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16524_16525 : H12AffineEnvironment.transform 6 9 env16524 = env16525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16524 == env16525) = true)

theorem identity16525 : scanCanonicalize (H12AffineFastState.compose env16525 (packedSelected [0,6] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound16525 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env16526 : List Nat := [2,4,8,16,32,64,9,4,0,1024,1,1093,8,1044,32,34,1093,0,1024,33,1093,1,16,2,9,64,0,1044,1044,1,1025,1,4,33,1093,0]

theorem envBound16526 : H12AffineFastState.Bounded env16526 := by
  intro p hp
  have h : env16526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16525_16526 : H12AffineEnvironment.transform 15 34 env16525 = env16526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env16525 == env16526) = true)

def env16527 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,1345,8192,1297,10280,65536,1345,0,1025,10281,1345,2309,17,76076,8328,64,2049,1297,1296,1,1285,4294967296,256,4295041155,1345,0]

theorem envBound16527 : H12AffineFastState.Bounded env16527 := by
  intro p hp
  have h : env16527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16483_16527 : H12AffineEnvironment.transform 13 1297 env16483 = env16527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env16483 == env16527) = true)

theorem identity16527 : scanCanonicalize (H12AffineFastState.compose env16527 (packedSelected [5,8] rootPS)) = affineNative (2^(15+1) ^^^ 10542) := by decide +kernel

theorem selectedBound16527 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env16528 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,1345,8192,1297,10280,10542,1345,0,1025,10281,1345,2309,17,2,8328,64,2049,1297,1296,1,1285,4294967296,256,4294969773,1345,0]

theorem envBound16528 : H12AffineFastState.Bounded env16528 := by
  intro p hp
  have h : env16528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16527_16528 : H12AffineEnvironment.transform 15 10542 env16527 = env16528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 10542 env16527 == env16528) = true)

theorem identity16528 : scanCanonicalize (H12AffineFastState.compose env16528 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound16528 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env16529 : List Nat := [2,4,8,16,32,64,9,256,0,1024,2048,1345,8192,1297,10280,10542,1345,0,1025,10281,1345,2309,17,2,8193,64,2049,1297,1296,1,1285,4294967296,256,4294969636,1345,0]

theorem envBound16529 : H12AffineFastState.Bounded env16529 := by
  intro p hp
  have h : env16529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16528_16529 : H12AffineEnvironment.transform 6 9 env16528 = env16529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16528 == env16529) = true)

theorem identity16529 : scanCanonicalize (H12AffineFastState.compose env16529 (packedSelected [1,10] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound16529 : packedSelected [1,10] rootPS < 2^1333 := by decide +kernel

def env16530 : List Nat := [2,4,8,16,32,64,9,256,0,1024,292,1345,8192,1297,8460,8202,1345,0,1025,8461,1345,33,17,2,8193,64,293,1297,1296,1,1285,4294967296,256,4294967296,1345,0]

theorem envBound16530 : H12AffineFastState.Bounded env16530 := by
  intro p hp
  have h : env16530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16529_16530 : H12AffineEnvironment.transform 10 292 env16529 = env16530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env16529 == env16530) = true)

theorem identity16530 : scanCanonicalize (H12AffineFastState.compose env16530 (packedSelected [2] rootPS)) = affineNative (2^(31+1) ^^^ 96) := by decide +kernel

theorem selectedBound16530 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16531 : List Nat := [2,4,8,16,32,64,9,256,0,1024,292,1345,8192,1297,8460,8202,1345,0,1025,8461,1345,33,17,2,8193,64,293,1297,1296,1,1285,96,256,96,1345,0]

theorem envBound16531 : H12AffineFastState.Bounded env16531 := by
  intro p hp
  have h : env16531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16530_16531 : H12AffineEnvironment.transform 31 96 env16530 = env16531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 96 env16530 == env16531) = true)

theorem identity16531 : scanCanonicalize (H12AffineFastState.compose env16531 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound16531 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env16532 : List Nat := [2,4,8,16,32,64,9,69,0,1024,97,1028,8192,1108,8265,8202,1028,0,1025,8264,1028,33,17,2,8193,64,96,1108,1109,1,1088,96,69,96,1028,0]

theorem envBound16532 : H12AffineFastState.Bounded env16532 := by
  intro p hp
  have h : env16532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16531_16532 : H12AffineEnvironment.transform 7 69 env16531 = env16532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env16531 == env16532) = true)

theorem identity16532 : scanCanonicalize (H12AffineFastState.compose env16532 (packedSelected [1,12] rootPS)) = affineNative (2^(5+1) ^^^ 26) := by decide +kernel

theorem selectedBound16532 : packedSelected [1,12] rootPS < 2^1333 := by decide +kernel

def env16533 : List Nat := [2,4,8,16,32,26,9,31,0,1024,59,1028,8192,1038,8211,8202,1028,0,1025,8210,1028,33,17,2,8193,26,58,1038,1039,1,1050,58,31,58,1028,0]

theorem envBound16533 : H12AffineFastState.Bounded env16533 := by
  intro p hp
  have h : env16533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16532_16533 : H12AffineEnvironment.transform 5 26 env16532 = env16533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 26 env16532 == env16533) = true)

def env16534 : List Nat := [2,4,8,16,32,26,9,31,0,1024,59,1028,40,1038,59,34,1028,0,1025,58,1028,33,17,2,41,26,58,1038,1039,1,1050,58,31,58,1028,0]

theorem envBound16534 : H12AffineFastState.Bounded env16534 := by
  intro p hp
  have h : env16534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16533_16534 : H12AffineEnvironment.transform 12 40 env16533 = env16534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env16533 == env16534) = true)

def env16535 : List Nat := [2,4,8,16,32,26,9,31,0,1024,59,1028,41,1038,58,35,1028,0,1025,59,1028,33,17,2,40,26,58,1038,1039,1,1050,58,31,58,1028,0]

theorem envBound16535 : H12AffineFastState.Bounded env16535 := by
  intro p hp
  have h : env16535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16533_16535 : H12AffineEnvironment.transform 12 41 env16533 = env16535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env16533 == env16535) = true)

theorem identity16535 : scanCanonicalize (H12AffineFastState.compose env16535 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound16535 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16536 : List Nat := [2,4,8,16,26,26,9,31,0,1024,1,1028,19,1038,0,25,1028,0,1025,1,1028,27,17,2,18,26,0,1038,1039,1,1050,0,31,0,1028,0]

theorem envBound16536 : H12AffineFastState.Bounded env16536 := by
  intro p hp
  have h : env16536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16535_16536 : H12AffineEnvironment.transform 4 26 env16535 = env16536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env16535 == env16536) = true)

def leafEnv16536 : List Nat := [2,4,8,16,26,26,9,31,0,1024,1,1028,19,1038,0,25,1028,0,1025,1,1028,27,17,2,1051,18,1,26,0,1038,1039,1,1050,0,31,0,4,25,1028,0,0,1039,1]

def active16536 : List Nat := [0,1,2,3,9]

def tree16536 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16536 : H12WitnessSearch.Good tree16536 := H12GlobalWitnessIndex.good

theorem leafIdentity16536 : H12AffineFastState.composeSystem env16536 rootObs = leafEnv16536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16536 rootObs == leafEnv16536) = true)

theorem terminalChecked16536 : H12PackedTerminal.terminalCheckFast leafEnv16536 active16536 tree16536 = true := by decide +kernel

def env16537 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,1345,8192,16384,32768,65536,1345,1,16656,32769,1345,4194304,17664,98564,8328,64,134217728,16384,1296,1,1285,4294967296,256,4299260334,138428757,1]

theorem envBound16537 : H12AffineFastState.Bounded env16537 := by
  intro p hp
  have h : env16537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16479_16537 : H12AffineEnvironment.transform 8 1 env16479 = env16537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env16479 == env16537) = true)

theorem identity16537 : scanCanonicalize (H12AffineFastState.compose env16537 (packedSelected [18] rootPS)) = affineNative (2^(26+1) ^^^ 4204553) := by decide +kernel

theorem selectedBound16537 : packedSelected [18] rootPS < 2^1333 := by decide +kernel

def env16538 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,1345,8192,16384,32768,65536,1345,1,16656,32769,1345,4194304,17664,98564,8328,64,4204553,16384,1296,1,1285,4294967296,256,4299260334,26972,1]

theorem envBound16538 : H12AffineFastState.Bounded env16538 := by
  intro p hp
  have h : env16538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16537_16538 : H12AffineEnvironment.transform 26 4204553 env16537 = env16538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4204553 env16537 == env16538) = true)

theorem identity16538 : scanCanonicalize (H12AffineFastState.compose env16538 (packedSelected [23] rootPS)) = affineNative (2^(14+1) ^^^ 27960) := by decide +kernel

theorem selectedBound16538 : packedSelected [23] rootPS < 2^1333 := by decide +kernel

def env16539 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,1345,8192,16384,27960,65536,1345,1,16656,27961,1345,4194304,17664,93244,8328,64,4204553,16384,1296,1,1285,4294967296,256,4299254934,26972,1]

theorem envBound16539 : H12AffineFastState.Bounded env16539 := by
  intro p hp
  have h : env16539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16538_16539 : H12AffineEnvironment.transform 14 27960 env16538 = env16539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 27960 env16538 == env16539) = true)

theorem identity16539 : scanCanonicalize (H12AffineFastState.compose env16539 (packedSelected [1,12,13,21,28,38] rootPS)) = affineNative (2^(13+1) ^^^ 11293) := by decide +kernel

theorem selectedBound16539 : packedSelected [1,12,13,21,28,38] rootPS < 2^1333 := by decide +kernel

def env16540 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,1345,8192,11293,293,65536,1345,1,11533,292,1345,4194304,10525,65569,8328,64,4204553,11293,1296,1,1285,4294967296,256,4299227275,1345,1]

theorem envBound16540 : H12AffineFastState.Bounded env16540 := by
  intro p hp
  have h : env16540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16539_16540 : H12AffineEnvironment.transform 13 11293 env16539 = env16540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11293 env16539 == env16540) = true)

theorem identity16540 : scanCanonicalize (H12AffineFastState.compose env16540 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound16540 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env16541 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1,1345,8192,9244,293,65536,1345,1,9484,292,1345,4194304,8476,65569,8328,64,4202504,9244,1296,1,1285,4294967296,256,4299227275,1345,1]

theorem envBound16541 : H12AffineFastState.Bounded env16541 := by
  intro p hp
  have h : env16541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16540_16541 : H12AffineEnvironment.transform 10 1 env16540 = env16541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env16540 == env16541) = true)

theorem identity16541 : scanCanonicalize (H12AffineFastState.compose env16541 (packedSelected [11] rootPS)) = affineNative (2^(21+1) ^^^ 8201) := by decide +kernel

theorem selectedBound16541 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env16542 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1,1345,8192,9244,293,65536,1345,1,9484,292,1345,8201,8476,65569,8328,64,1,9244,1296,1,1285,4294967296,256,4295041154,1345,1]

theorem envBound16542 : H12AffineFastState.Bounded env16542 := by
  intro p hp
  have h : env16542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16541_16542 : H12AffineEnvironment.transform 21 8201 env16541 = env16542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8201 env16541 == env16542) = true)

def env16543 : List Nat := [2,4,8,16,32,64,128,36,1,1024,1,1125,8192,9244,1,65536,1125,1,9256,0,1125,8201,8248,65569,8328,64,1,9244,1076,1,1057,4294967296,36,4295041154,1125,1]

theorem envBound16543 : H12AffineFastState.Bounded env16543 := by
  intro p hp
  have h : env16543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16542_16543 : H12AffineEnvironment.transform 7 36 env16542 = env16543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env16542 == env16543) = true)

theorem identity16543 : scanCanonicalize (H12AffineFastState.compose env16543 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 65706) := by decide +kernel

theorem selectedBound16543 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16544 : List Nat := [2,4,8,16,32,64,128,36,1,1024,1,1125,8192,9244,1,65536,1125,1,9256,0,1125,8201,8248,65569,8328,64,1,9244,1076,1,1057,65706,36,8232,1125,1]

theorem envBound16544 : H12AffineFastState.Bounded env16544 := by
  intro p hp
  have h : env16544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16543_16544 : H12AffineEnvironment.transform 31 65706 env16543 = env16544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 65706 env16543 == env16544) = true)

def env16545 : List Nat := [2,4,8,16,32,64,128,36,1,1024,1,1125,40,1076,1,65536,1125,1,1024,0,1125,33,16,65569,160,64,1,1076,1076,1,1057,65706,36,0,1125,1]

theorem envBound16545 : H12AffineFastState.Bounded env16545 := by
  intro p hp
  have h : env16545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16544_16545 : H12AffineEnvironment.transform 12 40 env16544 = env16545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env16544 == env16545) = true)

theorem identity16545 : scanCanonicalize (H12AffineFastState.compose env16545 (packedSelected [4,6] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound16545 : packedSelected [4,6] rootPS < 2^1333 := by decide +kernel

def env16546 : List Nat := [2,4,8,16,32,64,128,36,1,1024,1,1125,40,1076,1,170,1125,1,1024,0,1125,33,16,139,160,64,1,1076,1076,1,1057,0,36,0,1125,1]

theorem envBound16546 : H12AffineFastState.Bounded env16546 := by
  intro p hp
  have h : env16546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16545_16546 : H12AffineEnvironment.transform 15 170 env16545 = env16546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env16545 == env16546) = true)

def env16547 : List Nat := [2,4,8,16,32,16,128,36,1,1024,1,1077,40,1076,1,170,1077,1,1024,0,1077,33,16,139,160,16,1,1076,1076,1,1057,0,36,0,1077,1]

theorem envBound16547 : H12AffineFastState.Bounded env16547 := by
  intro p hp
  have h : env16547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16546_16547 : H12AffineEnvironment.transform 5 16 env16546 = env16547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env16546 == env16547) = true)

theorem identity16547 : scanCanonicalize (H12AffineFastState.compose env16547 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound16547 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16548 : List Nat := [2,4,8,16,1,16,128,5,1,1024,1,1044,9,1045,1,139,1044,1,1024,0,1044,0,16,139,129,16,1,1045,1045,1,1024,0,5,0,1044,1]

theorem envBound16548 : H12AffineFastState.Bounded env16548 := by
  intro p hp
  have h : env16548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16547_16548 : H12AffineEnvironment.transform 4 1 env16547 = env16548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16547 == env16548) = true)

def leafEnv16548 : List Nat := [2,4,8,16,1,16,128,5,1,1024,1,1044,9,1045,1,139,1044,1,1024,0,1044,0,16,139,1024,129,1,16,1,1045,1045,1,1024,0,5,0,4,2,1044,1,0,1045,1]

def active16548 : List Nat := [0,1,2,3,6,9]

def tree16548 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16548 : H12WitnessSearch.Good tree16548 := H12GlobalWitnessIndex.good

theorem leafIdentity16548 : H12AffineFastState.composeSystem env16548 rootObs = leafEnv16548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16548 rootObs == leafEnv16548) = true)

theorem terminalChecked16548 : H12PackedTerminal.terminalCheckFast leafEnv16548 active16548 tree16548 = true := by decide +kernel

def env16549 : List Nat := [2,4,8,16,32,17,128,36,1,1024,1,1076,40,1076,1,170,1076,1,1024,0,1076,33,16,139,160,17,1,1076,1076,1,1057,0,36,0,1076,1]

theorem envBound16549 : H12AffineFastState.Bounded env16549 := by
  intro p hp
  have h : env16549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16546_16549 : H12AffineEnvironment.transform 5 17 env16546 = env16549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env16546 == env16549) = true)

theorem identity16549 : scanCanonicalize (H12AffineFastState.compose env16549 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound16549 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16550 : List Nat := [2,4,8,16,32,17,41,36,1,1024,1,1076,40,1076,1,3,1076,1,1024,0,1076,33,16,34,9,17,1,1076,1076,1,1057,0,36,0,1076,1]

theorem envBound16550 : H12AffineFastState.Bounded env16550 := by
  intro p hp
  have h : env16550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16549_16550 : H12AffineEnvironment.transform 6 41 env16549 = env16550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env16549 == env16550) = true)

def leafEnv16550 : List Nat := [2,4,8,16,32,17,41,36,1,1024,1,1076,40,1076,1,3,1076,1,1024,0,1076,33,16,34,1057,9,1,17,1,1076,1076,1,1057,0,36,0,4,35,1076,1,0,1076,1]

def active16550 : List Nat := [0,1,2,3,4,9]

def tree16550 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16550 : H12WitnessSearch.Good tree16550 := H12GlobalWitnessIndex.good

theorem leafIdentity16550 : H12AffineFastState.composeSystem env16550 rootObs = leafEnv16550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16550 rootObs == leafEnv16550) = true)

theorem terminalChecked16550 : H12PackedTerminal.terminalCheckFast leafEnv16550 active16550 tree16550 = true := by decide +kernel

def env16551 : List Nat := [2,4,8,16,32,64,128,36,1,1024,1,1125,41,1077,1,65536,1125,1,1025,0,1125,32,17,65569,161,64,1,1077,1076,1,1057,65706,36,1,1125,1]

theorem envBound16551 : H12AffineFastState.Bounded env16551 := by
  intro p hp
  have h : env16551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16544_16551 : H12AffineEnvironment.transform 12 41 env16544 = env16551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env16544 == env16551) = true)

theorem identity16551 : scanCanonicalize (H12AffineFastState.compose env16551 (packedSelected [5] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound16551 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env16552 : List Nat := [2,4,8,16,32,64,128,36,1,1024,1,1125,41,1077,1,170,1125,1,1025,0,1125,32,17,139,161,64,1,1077,1076,1,1057,0,36,1,1125,1]

theorem envBound16552 : H12AffineFastState.Bounded env16552 := by
  intro p hp
  have h : env16552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16551_16552 : H12AffineEnvironment.transform 15 170 env16551 = env16552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env16551 == env16552) = true)

theorem identity16552 : scanCanonicalize (H12AffineFastState.compose env16552 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound16552 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16553 : List Nat := [2,4,8,16,32,0,128,36,1,1024,1,1061,41,1077,1,170,1061,1,1025,0,1061,32,17,139,161,0,1,1077,1076,1,1057,0,36,1,1061,1]

theorem envBound16553 : H12AffineFastState.Bounded env16553 := by
  intro p hp
  have h : env16553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16552_16553 : H12AffineEnvironment.transform 5 0 env16552 = env16553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env16552 == env16553) = true)

theorem identity16553 : scanCanonicalize (H12AffineFastState.compose env16553 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound16553 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env16554 : List Nat := [2,4,8,16,32,0,8,36,1,1024,1,1061,41,1077,1,34,1061,1,1025,0,1061,32,17,3,41,0,1,1077,1076,1,1057,0,36,1,1061,1]

theorem envBound16554 : H12AffineFastState.Bounded env16554 := by
  intro p hp
  have h : env16554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16553_16554 : H12AffineEnvironment.transform 6 8 env16553 = env16554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16553 == env16554) = true)

theorem identity16554 : scanCanonicalize (H12AffineFastState.compose env16554 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound16554 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16555 : List Nat := [2,4,3,16,32,0,3,36,1,1024,1,1061,34,1077,1,34,1061,1,1025,0,1061,32,17,3,34,0,1,1077,1076,1,1057,0,36,1,1061,1]

theorem envBound16555 : H12AffineFastState.Bounded env16555 := by
  intro p hp
  have h : env16555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16554_16555 : H12AffineEnvironment.transform 2 3 env16554 = env16555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env16554 == env16555) = true)

def leafEnv16555 : List Nat := [2,4,3,16,32,0,3,36,1,1024,1,1061,34,1077,1,34,1061,1,1025,0,1061,32,17,3,1056,34,1,0,1,1077,1076,1,1057,0,36,1,4,35,1061,1,0,1076,1]

def active16555 : List Nat := [0,1,3,4,9]

def tree16555 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16555 : H12WitnessSearch.Good tree16555 := H12GlobalWitnessIndex.good

theorem leafIdentity16555 : H12AffineFastState.composeSystem env16555 rootObs = leafEnv16555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16555 rootObs == leafEnv16555) = true)

theorem terminalChecked16555 : H12PackedTerminal.terminalCheckFast leafEnv16555 active16555 tree16555 = true := by decide +kernel

def env16556 : List Nat := [2,4,8,16,32,64,128,37,1,1024,1,1124,8192,9244,0,65536,1124,1,9257,1,1124,8201,8249,65569,8328,64,1,9244,1077,1,1056,4294967296,37,4295041154,1124,1]

theorem envBound16556 : H12AffineFastState.Bounded env16556 := by
  intro p hp
  have h : env16556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16542_16556 : H12AffineEnvironment.transform 7 37 env16542 = env16556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env16542 == env16556) = true)

theorem identity16556 : scanCanonicalize (H12AffineFastState.compose env16556 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 137) := by decide +kernel

theorem selectedBound16556 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16557 : List Nat := [2,4,8,16,32,64,128,37,1,1024,1,1124,8192,9244,0,65536,1124,1,9257,1,1124,8201,8249,65569,8328,64,1,9244,1077,1,1056,137,37,73739,1124,1]

theorem envBound16557 : H12AffineFastState.Bounded env16557 := by
  intro p hp
  have h : env16557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16556_16557 : H12AffineEnvironment.transform 31 137 env16556 = env16557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 137 env16556 == env16557) = true)

theorem identity16557 : scanCanonicalize (H12AffineFastState.compose env16557 (packedSelected [3,8,10] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound16557 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env16558 : List Nat := [2,4,8,16,32,64,128,37,1,1024,1,1124,41,1077,0,65536,1124,1,1024,1,1124,32,16,65569,161,64,1,1077,1077,1,1056,137,37,65570,1124,1]

theorem envBound16558 : H12AffineFastState.Bounded env16558 := by
  intro p hp
  have h : env16558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16557_16558 : H12AffineEnvironment.transform 12 41 env16557 = env16558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env16557 == env16558) = true)

theorem identity16558 : scanCanonicalize (H12AffineFastState.compose env16558 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 138) := by decide +kernel

theorem selectedBound16558 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16559 : List Nat := [2,4,8,16,32,64,128,37,1,1024,1,1124,41,1077,0,138,1124,1,1024,1,1124,32,16,171,161,64,1,1077,1077,1,1056,137,37,168,1124,1]

theorem envBound16559 : H12AffineFastState.Bounded env16559 := by
  intro p hp
  have h : env16559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16558_16559 : H12AffineEnvironment.transform 15 138 env16558 = env16559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 138 env16558 == env16559) = true)

theorem identity16559 : scanCanonicalize (H12AffineFastState.compose env16559 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound16559 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env16560 : List Nat := [2,4,8,16,0,64,128,5,1,1024,1,1092,9,1045,0,138,1092,1,1024,1,1092,0,16,139,129,64,1,1045,1045,1,1024,137,5,136,1092,1]

theorem envBound16560 : H12AffineFastState.Bounded env16560 := by
  intro p hp
  have h : env16560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16559_16560 : H12AffineEnvironment.transform 4 0 env16559 = env16560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16559 == env16560) = true)

def env16561 : List Nat := [2,4,8,16,0,16,128,5,1,1024,1,1044,9,1045,0,138,1044,1,1024,1,1044,0,16,139,129,16,1,1045,1045,1,1024,137,5,136,1044,1]

theorem envBound16561 : H12AffineFastState.Bounded env16561 := by
  intro p hp
  have h : env16561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16560_16561 : H12AffineEnvironment.transform 5 16 env16560 = env16561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env16560 == env16561) = true)

theorem identity16561 : scanCanonicalize (H12AffineFastState.compose env16561 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound16561 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16562 : List Nat := [2,4,8,16,0,16,9,5,1,1024,1,1044,9,1045,0,3,1044,1,1024,1,1044,0,16,2,8,16,1,1045,1045,1,1024,0,5,1,1044,1]

theorem envBound16562 : H12AffineFastState.Bounded env16562 := by
  intro p hp
  have h : env16562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16561_16562 : H12AffineEnvironment.transform 6 9 env16561 = env16562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16561 == env16562) = true)

def leafEnv16562 : List Nat := [2,4,8,16,0,16,9,5,1,1024,1,1044,9,1045,0,3,1044,1,1024,1,1044,0,16,2,1024,8,1,16,1,1045,1045,1,1024,0,5,1,4,3,1044,1,0,1045,1]

def active16562 : List Nat := [0,1,2,3,9]

def tree16562 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16562 : H12WitnessSearch.Good tree16562 := H12GlobalWitnessIndex.good

theorem leafIdentity16562 : H12AffineFastState.composeSystem env16562 rootObs = leafEnv16562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16562 rootObs == leafEnv16562) = true)

theorem terminalChecked16562 : H12PackedTerminal.terminalCheckFast leafEnv16562 active16562 tree16562 = true := by decide +kernel

def env16563 : List Nat := [2,4,8,16,0,17,128,5,1,1024,1,1045,9,1045,0,138,1045,1,1024,1,1045,0,16,139,129,17,1,1045,1045,1,1024,137,5,136,1045,1]

theorem envBound16563 : H12AffineFastState.Bounded env16563 := by
  intro p hp
  have h : env16563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16560_16563 : H12AffineEnvironment.transform 5 17 env16560 = env16563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env16560 == env16563) = true)

def env16564 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,16384,32768,65536,1345,513,16656,32769,1345,4194304,17664,98564,8328,64,134217728,16384,1296,1073741824,1285,4294967296,256,4299260334,138429269,512]

theorem envBound16564 : H12AffineFastState.Bounded env16564 := by
  intro p hp
  have h : env16564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16387_16564 : H12AffineEnvironment.transform 17 513 env16387 = env16564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 513 env16387 == env16564) = true)

theorem identity16564 : scanCanonicalize (H12AffineFastState.compose env16564 (packedSelected [3,5,24] rootPS)) = affineNative (2^(26+1) ^^^ 4212244) := by decide +kernel

theorem selectedBound16564 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env16565 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,16384,32768,65536,1345,513,16656,32769,1345,4194304,17664,98564,8328,64,4212244,16384,1296,1073741824,1285,4294967296,256,4299260334,1345,512]

theorem envBound16565 : H12AffineFastState.Bounded env16565 := by
  intro p hp
  have h : env16565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16564_16565 : H12AffineEnvironment.transform 26 4212244 env16564 = env16565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 4212244 env16564 == env16565) = true)

def env16566 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,1296,32768,65536,1345,513,1024,32769,1345,4194304,16,98564,8328,64,4195076,1296,1296,1073741824,1285,4294967296,256,4299260334,1345,512]

theorem envBound16566 : H12AffineFastState.Bounded env16566 := by
  intro p hp
  have h : env16566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16565_16566 : H12AffineEnvironment.transform 13 1296 env16565 = env16566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env16565 == env16566) = true)

def env16567 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,32768,65536,1297,513,1024,32769,1297,4194304,16,98564,8328,16,4195076,1296,1296,1073741824,1285,4294967296,256,4299260334,1297,512]

theorem envBound16567 : H12AffineFastState.Bounded env16567 := by
  intro p hp
  have h : env16567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16566_16567 : H12AffineEnvironment.transform 5 16 env16566 = env16567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env16566 == env16567) = true)

theorem identity16567 : scanCanonicalize (H12AffineFastState.compose env16567 (packedSelected [1,3,5] rootPS)) = affineNative (2^(29+1) ^^^ 4268706) := by decide +kernel

theorem selectedBound16567 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env16568 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,32768,65536,1297,513,1024,32769,1297,4194304,16,98564,8328,16,4195076,1296,1296,4268706,1285,4294967296,256,4299260334,1297,512]

theorem envBound16568 : H12AffineFastState.Bounded env16568 := by
  intro p hp
  have h : env16568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16567_16568 : H12AffineEnvironment.transform 29 4268706 env16567 = env16568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4268706 env16567 == env16568) = true)

theorem identity16568 : scanCanonicalize (H12AffineFastState.compose env16568 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 8713) := by decide +kernel

theorem selectedBound16568 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16569 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,32768,65536,1297,513,1024,32769,1297,4194304,16,98564,8328,16,4195076,1296,1296,4268706,1285,8713,256,4301735,1297,512]

theorem envBound16569 : H12AffineFastState.Bounded env16569 := by
  intro p hp
  have h : env16569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16568_16569 : H12AffineEnvironment.transform 31 8713 env16568 = env16569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 8713 env16568 == env16569) = true)

theorem identity16569 : scanCanonicalize (H12AffineFastState.compose env16569 (packedSelected [3,8] rootPS)) = affineNative (2^(15+1) ^^^ 11175) := by decide +kernel

theorem selectedBound16569 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env16570 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,32768,11175,1297,513,1024,32769,1297,4194304,16,43683,8328,16,4195076,1296,1296,4196613,1285,8713,256,4229120,1297,512]

theorem envBound16570 : H12AffineFastState.Bounded env16570 := by
  intro p hp
  have h : env16570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16569_16570 : H12AffineEnvironment.transform 15 11175 env16569 = env16570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 11175 env16569 == env16570) = true)

theorem identity16570 : scanCanonicalize (H12AffineFastState.compose env16570 (packedSelected [3] rootPS)) = affineNative (2^(21+1) ^^^ 261) := by decide +kernel

theorem selectedBound16570 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env16571 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,32768,11175,1297,513,1024,32769,1297,261,16,43683,8328,16,513,1296,1296,2048,1285,8713,256,35077,1297,512]

theorem envBound16571 : H12AffineFastState.Bounded env16571 := by
  intro p hp
  have h : env16571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16570_16571 : H12AffineEnvironment.transform 21 261 env16570 = env16571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 261 env16570 == env16571) = true)

theorem identity16571 : scanCanonicalize (H12AffineFastState.compose env16571 (packedSelected [0,7] rootPS)) = affineNative (2^(14+1) ^^^ 10792) := by decide +kernel

theorem selectedBound16571 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env16572 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1296,10792,11175,1297,513,1024,10793,1297,261,16,139,8328,16,513,1296,1296,2048,1285,8713,256,9005,1297,512]

theorem envBound16572 : H12AffineFastState.Bounded env16572 := by
  intro p hp
  have h : env16572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16571_16572 : H12AffineEnvironment.transform 14 10792 env16571 = env16572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 10792 env16571 == env16572) = true)

theorem identity16572 : scanCanonicalize (H12AffineFastState.compose env16572 (packedSelected [12] rootPS)) = affineNative (2^(12+1) ^^^ 780) := by decide +kernel

theorem selectedBound16572 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env16573 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,780,1296,2340,2219,1297,513,1024,2341,1297,261,16,139,900,16,513,1296,1296,2048,1285,261,256,33,1297,512]

theorem envBound16573 : H12AffineFastState.Bounded env16573 := by
  intro p hp
  have h : env16573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16572_16573 : H12AffineEnvironment.transform 12 780 env16572 = env16573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 780 env16572 == env16573) = true)

theorem identity16573 : scanCanonicalize (H12AffineFastState.compose env16573 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound16573 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16574 : List Nat := [2,4,8,16,32,16,128,256,260,1024,2048,1297,8,1296,2340,2219,1297,261,1024,2341,1297,261,16,139,128,16,261,1296,1296,2048,1285,261,256,33,1297,260]

theorem envBound16574 : H12AffineFastState.Bounded env16574 := by
  intro p hp
  have h : env16574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16573_16574 : H12AffineEnvironment.transform 8 260 env16573 = env16574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env16573 == env16574) = true)

def env16575 : List Nat := [2,4,8,16,32,16,8,256,260,1024,2048,1297,8,1296,2340,2083,1297,261,1024,2341,1297,261,16,3,8,16,261,1296,1296,2048,1285,261,256,33,1297,260]

theorem envBound16575 : H12AffineFastState.Bounded env16575 := by
  intro p hp
  have h : env16575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16574_16575 : H12AffineEnvironment.transform 6 8 env16574 = env16575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16574 == env16575) = true)

theorem identity16575 : scanCanonicalize (H12AffineFastState.compose env16575 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound16575 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16576 : List Nat := [2,4,8,16,1,16,8,256,260,1024,2048,1297,8,1296,2309,2050,1297,261,1024,2308,1297,261,16,3,8,16,261,1296,1296,2048,1285,261,256,0,1297,260]

theorem envBound16576 : H12AffineFastState.Bounded env16576 := by
  intro p hp
  have h : env16576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16575_16576 : H12AffineEnvironment.transform 4 1 env16575 = env16576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16575 == env16576) = true)

def leafEnv16576 : List Nat := [2,4,8,16,1,16,8,256,260,1024,2048,1297,8,1296,2309,2050,1297,261,1024,2308,1297,261,16,3,1285,8,1,16,261,1296,1296,2048,1285,261,256,0,4,2051,1297,260,0,1296,1]

def active16576 : List Nat := [0,1,2,3,7,9,10]

def tree16576 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16576 : H12WitnessSearch.Good tree16576 := H12GlobalWitnessIndex.good

theorem leafIdentity16576 : H12AffineFastState.composeSystem env16576 rootObs = leafEnv16576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16576 rootObs == leafEnv16576) = true)

theorem terminalChecked16576 : H12PackedTerminal.terminalCheckFast leafEnv16576 active16576 tree16576 = true := by decide +kernel

def env16577 : List Nat := [2,4,8,16,32,16,9,256,260,1024,2048,1297,8,1296,2340,2082,1297,261,1024,2341,1297,261,16,2,9,16,261,1296,1296,2048,1285,261,256,33,1297,260]

theorem envBound16577 : H12AffineFastState.Bounded env16577 := by
  intro p hp
  have h : env16577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16574_16577 : H12AffineEnvironment.transform 6 9 env16574 = env16577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16574 == env16577) = true)

theorem identity16577 : scanCanonicalize (H12AffineFastState.compose env16577 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 261) := by decide +kernel

theorem selectedBound16577 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16578 : List Nat := [2,4,8,16,32,16,9,256,260,1024,261,1297,8,1296,33,295,1297,261,1024,32,1297,261,16,2,9,16,261,1296,1296,261,1285,261,256,33,1297,260]

theorem envBound16578 : H12AffineFastState.Bounded env16578 := by
  intro p hp
  have h : env16578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16577_16578 : H12AffineEnvironment.transform 10 261 env16577 = env16578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env16577 == env16578) = true)

theorem identity16578 : scanCanonicalize (H12AffineFastState.compose env16578 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound16578 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env16579 : List Nat := [2,4,8,16,32,16,9,5,1,1024,0,1044,8,1045,33,34,1044,0,1024,32,1044,0,16,2,9,16,0,1045,1045,0,1024,0,5,33,1044,1]

theorem envBound16579 : H12AffineFastState.Bounded env16579 := by
  intro p hp
  have h : env16579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16578_16579 : H12AffineEnvironment.transform 7 5 env16578 = env16579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env16578 == env16579) = true)

def leafEnv16579 : List Nat := [2,4,8,16,32,16,9,5,1,1024,0,1044,8,1045,33,34,1044,0,1024,32,1044,0,16,2,1024,9,1,16,0,1045,1045,0,1024,0,5,33,4,34,1044,1,0,1045,1]

def active16579 : List Nat := [0,1,2,3,4,9]

def tree16579 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16579 : H12WitnessSearch.Good tree16579 := H12GlobalWitnessIndex.good

theorem leafIdentity16579 : H12AffineFastState.composeSystem env16579 rootObs = leafEnv16579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16579 rootObs == leafEnv16579) = true)

theorem terminalChecked16579 : H12PackedTerminal.terminalCheckFast leafEnv16579 active16579 tree16579 = true := by decide +kernel

def env16580 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1296,8192,1296,32768,65536,1296,513,1024,32769,1296,4194304,16,98564,8328,17,4195076,1296,1296,1073741824,1285,4294967296,256,4299260334,1296,512]

theorem envBound16580 : H12AffineFastState.Bounded env16580 := by
  intro p hp
  have h : env16580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16566_16580 : H12AffineEnvironment.transform 5 17 env16566 = env16580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env16566 == env16580) = true)

def env16581 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,8192,0,32768,65536,0,513,272,32769,0,4194304,16,98564,8328,17,4195076,0,0,1073741824,21,4294967296,256,4299260334,0,512]

theorem envBound16581 : H12AffineFastState.Bounded env16581 := by
  intro p hp
  have h : env16581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16580_16581 : H12AffineEnvironment.transform 9 272 env16580 = env16581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env16580 == env16581) = true)

theorem identity16581 : scanCanonicalize (H12AffineFastState.compose env16581 (packedSelected [1] rootPS)) = affineNative (2^(31+1) ^^^ 4194440) := by decide +kernel

theorem selectedBound16581 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16582 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,8192,0,32768,65536,0,513,272,32769,0,4194304,16,98564,8328,17,4195076,0,0,1073741824,21,4194440,256,98598,0,512]

theorem envBound16582 : H12AffineFastState.Bounded env16582 := by
  intro p hp
  have h : env16582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16581_16582 : H12AffineEnvironment.transform 31 4194440 env16581 = env16582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4194440 env16581 == env16582) = true)

def env16583 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,8192,0,260,65536,0,513,272,261,0,4194304,16,65536,8328,17,4195076,0,0,1073741824,21,4194440,256,65570,0,512]

theorem envBound16583 : H12AffineFastState.Bounded env16583 := by
  intro p hp
  have h : env16583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16582_16583 : H12AffineEnvironment.transform 14 260 env16582 = env16583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 260 env16582 == env16583) = true)

def env16584 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,8,0,260,65536,0,513,272,261,0,4194304,16,65536,128,17,4195076,0,0,1073741824,21,4194440,256,65570,0,512]

theorem envBound16584 : H12AffineFastState.Bounded env16584 := by
  intro p hp
  have h : env16584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16583_16584 : H12AffineEnvironment.transform 12 8 env16583 = env16584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env16583 == env16584) = true)

theorem identity16584 : scanCanonicalize (H12AffineFastState.compose env16584 (packedSelected [6] rootPS)) = affineNative (2^(21+1) ^^^ 65967) := by decide +kernel

theorem selectedBound16584 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env16585 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,8,0,260,65536,0,513,272,261,0,65967,16,65536,128,17,66219,0,0,1073741824,21,65831,256,65570,0,512]

theorem envBound16585 : H12AffineFastState.Bounded env16585 := by
  intro p hp
  have h : env16585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16584_16585 : H12AffineEnvironment.transform 21 65967 env16584 = env16585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65967 env16584 == env16585) = true)

def env16586 : List Nat := [2,4,8,16,32,17,40,256,512,272,2048,0,8,0,260,65536,0,513,272,261,0,65799,16,65536,40,17,66051,0,0,1073741824,21,65831,256,65570,0,512]

theorem envBound16586 : H12AffineFastState.Bounded env16586 := by
  intro p hp
  have h : env16586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16585_16586 : H12AffineEnvironment.transform 6 40 env16585 = env16586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env16585 == env16586) = true)

theorem identity16586 : scanCanonicalize (H12AffineFastState.compose env16586 (packedSelected [2,11,18] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound16586 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env16587 : List Nat := [2,4,8,16,32,17,40,256,33,272,2048,0,8,0,260,65536,0,32,272,261,0,65799,16,65536,40,17,65570,0,0,1073741824,21,65831,256,65570,0,33]

theorem envBound16587 : H12AffineFastState.Bounded env16587 := by
  intro p hp
  have h : env16587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16586_16587 : H12AffineEnvironment.transform 8 33 env16586 = env16587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env16586 == env16587) = true)

def env16588 : List Nat := [2,4,8,16,0,17,8,256,1,272,2048,0,8,0,260,65536,0,0,272,261,0,65799,16,65536,8,17,65538,0,0,1073741824,21,65799,256,65538,0,1]

theorem envBound16588 : H12AffineFastState.Bounded env16588 := by
  intro p hp
  have h : env16588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16587_16588 : H12AffineEnvironment.transform 4 0 env16587 = env16588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16587 == env16588) = true)

theorem identity16588 : scanCanonicalize (H12AffineFastState.compose env16588 (packedSelected [2,4] rootPS)) = affineNative (2^(29+1) ^^^ 2049) := by decide +kernel

theorem selectedBound16588 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env16589 : List Nat := [2,4,8,16,0,17,8,256,1,272,2048,0,8,0,260,65536,0,0,272,261,0,65799,16,65536,8,17,65538,0,0,2049,21,65799,256,65538,0,1]

theorem envBound16589 : H12AffineFastState.Bounded env16589 := by
  intro p hp
  have h : env16589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16588_16589 : H12AffineEnvironment.transform 29 2049 env16588 = env16589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 2049 env16588 == env16589) = true)

theorem identity16589 : scanCanonicalize (H12AffineFastState.compose env16589 (packedSelected [0,2] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound16589 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env16590 : List Nat := [2,4,8,16,0,17,8,256,1,272,2048,0,8,0,260,3,0,0,272,261,0,260,16,3,8,17,1,0,0,2049,21,260,256,1,0,1]

theorem envBound16590 : H12AffineFastState.Bounded env16590 := by
  intro p hp
  have h : env16590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16589_16590 : H12AffineEnvironment.transform 15 3 env16589 = env16590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env16589 == env16590) = true)

theorem identity16590 : scanCanonicalize (H12AffineFastState.compose env16590 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound16590 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16591 : List Nat := [2,4,8,16,0,17,8,5,1,21,2048,0,8,0,1,3,0,0,21,0,0,1,16,3,8,17,1,0,0,2049,21,1,5,1,0,1]

theorem envBound16591 : H12AffineFastState.Bounded env16591 := by
  intro p hp
  have h : env16591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16590_16591 : H12AffineEnvironment.transform 7 5 env16590 = env16591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env16590 == env16591) = true)

theorem identity16591 : scanCanonicalize (H12AffineFastState.compose env16591 (packedSelected [9] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound16591 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env16592 : List Nat := [2,4,8,16,0,17,8,5,1,21,0,0,8,0,1,3,0,0,21,0,0,1,16,3,8,17,1,0,0,1,21,1,5,1,0,1]

theorem envBound16592 : H12AffineFastState.Bounded env16592 := by
  intro p hp
  have h : env16592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16591_16592 : H12AffineEnvironment.transform 10 0 env16591 = env16592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env16591 == env16592) = true)

def leafEnv16592 : List Nat := [2,4,8,16,0,17,8,5,1,21,0,0,8,0,1,3,0,0,21,0,0,1,16,3,21,8,1,17,1,0,0,1,21,1,5,1,4,2,0,1,0,0,1]

def active16592 : List Nat := [0,1,2,3]

def tree16592 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16592 : H12WitnessSearch.Good tree16592 := H12GlobalWitnessIndex.good

theorem leafIdentity16592 : H12AffineFastState.composeSystem env16592 rootObs = leafEnv16592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16592 rootObs == leafEnv16592) = true)

theorem terminalChecked16592 : H12PackedTerminal.terminalCheckFast leafEnv16592 active16592 tree16592 = true := by decide +kernel

def env16593 : List Nat := [2,4,8,16,1,17,9,256,0,272,2048,0,8,0,260,65536,0,1,272,261,0,65799,16,65536,9,17,65539,0,0,1073741824,21,65798,256,65539,0,0]

theorem envBound16593 : H12AffineFastState.Bounded env16593 := by
  intro p hp
  have h : env16593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16587_16593 : H12AffineEnvironment.transform 4 1 env16587 = env16593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16587 == env16593) = true)

theorem identity16593 : scanCanonicalize (H12AffineFastState.compose env16593 (packedSelected [2,4] rootPS)) = affineNative (2^(29+1) ^^^ 65538) := by decide +kernel

theorem selectedBound16593 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env16594 : List Nat := [2,4,8,16,1,17,9,256,0,272,2048,0,8,0,260,65536,0,1,272,261,0,65799,16,65536,9,17,65539,0,0,65538,21,65798,256,65539,0,0]

theorem envBound16594 : H12AffineFastState.Bounded env16594 := by
  intro p hp
  have h : env16594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16593_16594 : H12AffineEnvironment.transform 29 65538 env16593 = env16594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 65538 env16593 == env16594) = true)

theorem identity16594 : scanCanonicalize (H12AffineFastState.compose env16594 (packedSelected [2,9] rootPS)) = affineNative (2^(15+1) ^^^ 2050) := by decide +kernel

theorem selectedBound16594 : packedSelected [2,9] rootPS < 2^1333 := by decide +kernel

def env16595 : List Nat := [2,4,8,16,1,17,9,256,0,272,2048,0,8,0,260,2050,0,1,272,261,0,2309,16,2050,9,17,2049,0,0,2048,21,2308,256,2049,0,0]

theorem envBound16595 : H12AffineFastState.Bounded env16595 := by
  intro p hp
  have h : env16595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16594_16595 : H12AffineEnvironment.transform 15 2050 env16594 = env16595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2050 env16594 == env16595) = true)

theorem identity16595 : scanCanonicalize (H12AffineFastState.compose env16595 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 261) := by decide +kernel

theorem selectedBound16595 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env16596 : List Nat := [2,4,8,16,1,17,9,256,0,272,261,0,8,0,260,263,0,1,272,261,0,0,16,263,9,17,260,0,0,261,21,1,256,260,0,0]

theorem envBound16596 : H12AffineFastState.Bounded env16596 := by
  intro p hp
  have h : env16596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16595_16596 : H12AffineEnvironment.transform 10 261 env16595 = env16596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env16595 == env16596) = true)

theorem identity16596 : scanCanonicalize (H12AffineFastState.compose env16596 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound16596 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16597 : List Nat := [2,4,8,16,1,17,9,5,0,21,0,0,8,0,1,2,0,1,21,0,0,0,16,2,9,17,1,0,0,0,21,1,5,1,0,0]

theorem envBound16597 : H12AffineFastState.Bounded env16597 := by
  intro p hp
  have h : env16597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16596_16597 : H12AffineEnvironment.transform 7 5 env16596 = env16597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env16596 == env16597) = true)

def leafEnv16597 : List Nat := [2,4,8,16,1,17,9,5,0,21,0,0,8,0,1,2,0,1,21,0,0,0,16,2,21,9,1,17,1,0,0,0,21,1,5,1,4,2,0,0,0,0,1]

def active16597 : List Nat := [0,1,2,3]

def tree16597 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16597 : H12WitnessSearch.Good tree16597 := H12GlobalWitnessIndex.good

theorem leafIdentity16597 : H12AffineFastState.composeSystem env16597 rootObs = leafEnv16597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16597 rootObs == leafEnv16597) = true)

theorem terminalChecked16597 : H12PackedTerminal.terminalCheckFast leafEnv16597 active16597 tree16597 = true := by decide +kernel

def env16598 : List Nat := [2,4,8,16,32,17,41,256,512,272,2048,0,8,0,260,65536,0,513,272,261,0,65798,16,65536,41,17,66050,0,0,1073741824,21,65831,256,65570,0,512]

theorem envBound16598 : H12AffineFastState.Bounded env16598 := by
  intro p hp
  have h : env16598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16585_16598 : H12AffineEnvironment.transform 6 41 env16585 = env16598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env16585 == env16598) = true)

theorem identity16598 : scanCanonicalize (H12AffineFastState.compose env16598 (packedSelected [2,11,18] rootPS)) = affineNative (2^(29+1) ^^^ 2820) := by decide +kernel

theorem selectedBound16598 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env16599 : List Nat := [2,4,8,16,32,17,41,256,512,272,2048,0,8,0,260,65536,0,513,272,261,0,65798,16,65536,41,17,66050,0,0,2820,21,65831,256,65570,0,512]

theorem envBound16599 : H12AffineFastState.Bounded env16599 := by
  intro p hp
  have h : env16599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16598_16599 : H12AffineEnvironment.transform 29 2820 env16598 = env16599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 2820 env16598 == env16599) = true)

def env16600 : List Nat := [2,4,8,16,32,17,41,36,512,52,2048,0,8,0,32,65536,0,513,52,33,0,65570,16,65536,41,17,66050,0,0,2592,21,65539,36,65570,0,512]

theorem envBound16600 : H12AffineFastState.Bounded env16600 := by
  intro p hp
  have h : env16600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16599_16600 : H12AffineEnvironment.transform 7 36 env16599 = env16600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env16599 == env16600) = true)

theorem identity16600 : scanCanonicalize (H12AffineFastState.compose env16600 (packedSelected [7] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound16600 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env16601 : List Nat := [2,4,8,16,32,17,41,36,32,52,2048,0,8,0,32,65536,0,33,52,33,0,65570,16,65536,41,17,65570,0,0,2048,21,65539,36,65570,0,32]

theorem envBound16601 : H12AffineFastState.Bounded env16601 := by
  intro p hp
  have h : env16601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16600_16601 : H12AffineEnvironment.transform 8 32 env16600 = env16601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env16600 == env16601) = true)

theorem identity16601 : scanCanonicalize (H12AffineFastState.compose env16601 (packedSelected [0,2] rootPS)) = affineNative (2^(15+1) ^^^ 2083) := by decide +kernel

theorem selectedBound16601 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env16602 : List Nat := [2,4,8,16,32,17,41,36,32,52,2048,0,8,0,32,2083,0,33,52,33,0,2049,16,2083,41,17,2049,0,0,2048,21,2080,36,2049,0,32]

theorem envBound16602 : H12AffineFastState.Bounded env16602 := by
  intro p hp
  have h : env16602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16601_16602 : H12AffineEnvironment.transform 15 2083 env16601 = env16602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2083 env16601 == env16602) = true)

theorem identity16602 : scanCanonicalize (H12AffineFastState.compose env16602 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound16602 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env16603 : List Nat := [2,4,8,16,32,17,41,36,32,52,1,0,8,0,32,34,0,33,52,33,0,0,16,34,41,17,0,0,0,1,21,33,36,0,0,32]

theorem envBound16603 : H12AffineFastState.Bounded env16603 := by
  intro p hp
  have h : env16603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16602_16603 : H12AffineEnvironment.transform 10 1 env16602 = env16603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env16602 == env16603) = true)

theorem identity16603 : scanCanonicalize (H12AffineFastState.compose env16603 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound16603 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16604 : List Nat := [2,4,8,16,1,17,8,5,1,21,1,0,8,0,1,3,0,0,21,0,0,0,16,3,8,17,0,0,0,1,21,0,5,0,0,1]

theorem envBound16604 : H12AffineFastState.Bounded env16604 := by
  intro p hp
  have h : env16604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16603_16604 : H12AffineEnvironment.transform 4 1 env16603 = env16604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16603 == env16604) = true)

def leafEnv16604 : List Nat := [2,4,8,16,1,17,8,5,1,21,1,0,8,0,1,3,0,0,21,0,0,0,16,3,21,8,1,17,0,0,0,1,21,0,5,0,4,2,0,1,0,0,1]

def active16604 : List Nat := [0,1,2,3]

def tree16604 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16604 : H12WitnessSearch.Good tree16604 := H12GlobalWitnessIndex.good

theorem leafIdentity16604 : H12AffineFastState.composeSystem env16604 rootObs = leafEnv16604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16604 rootObs == leafEnv16604) = true)

theorem terminalChecked16604 : H12PackedTerminal.terminalCheckFast leafEnv16604 active16604 tree16604 = true := by decide +kernel

def env16605 : List Nat := [2,4,8,16,32,17,41,37,512,53,2048,0,8,0,33,65536,0,513,53,32,0,65571,16,65536,41,17,66050,0,0,2593,21,65538,37,65570,0,512]

theorem envBound16605 : H12AffineFastState.Bounded env16605 := by
  intro p hp
  have h : env16605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16599_16605 : H12AffineEnvironment.transform 7 37 env16599 = env16605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env16599 == env16605) = true)

theorem identity16605 : scanCanonicalize (H12AffineFastState.compose env16605 (packedSelected [7] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound16605 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env16606 : List Nat := [2,4,8,16,32,17,41,37,512,53,2048,0,8,0,33,3,0,513,53,32,0,32,16,3,41,17,513,0,0,2593,21,1,37,33,0,512]

theorem envBound16606 : H12AffineFastState.Bounded env16606 := by
  intro p hp
  have h : env16606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16605_16606 : H12AffineEnvironment.transform 15 3 env16605 = env16606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env16605 == env16606) = true)

theorem identity16606 : scanCanonicalize (H12AffineFastState.compose env16606 (packedSelected [2,4,9] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound16606 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env16607 : List Nat := [2,4,8,16,32,17,41,37,33,53,2048,0,8,0,33,3,0,32,53,32,0,32,16,3,41,17,32,0,0,2048,21,1,37,33,0,33]

theorem envBound16607 : H12AffineFastState.Bounded env16607 := by
  intro p hp
  have h : env16607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16606_16607 : H12AffineEnvironment.transform 8 33 env16606 = env16607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env16606 == env16607) = true)

theorem identity16607 : scanCanonicalize (H12AffineFastState.compose env16607 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound16607 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16608 : List Nat := [2,4,8,16,32,17,41,37,33,53,32,0,8,0,33,3,0,32,53,32,0,32,16,3,41,17,32,0,0,32,21,1,37,33,0,33]

theorem envBound16608 : H12AffineFastState.Bounded env16608 := by
  intro p hp
  have h : env16608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16607_16608 : H12AffineEnvironment.transform 10 32 env16607 = env16608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env16607 == env16608) = true)

def leafEnv16608 : List Nat := [2,4,8,16,32,17,41,37,33,53,32,0,8,0,33,3,0,32,53,32,0,32,16,3,21,41,1,17,32,0,0,32,21,1,37,33,4,2,0,33,0,0,1]

def active16608 : List Nat := [0,1,2,3,4]

def tree16608 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16608 : H12WitnessSearch.Good tree16608 := H12GlobalWitnessIndex.good

theorem leafIdentity16608 : H12AffineFastState.composeSystem env16608 rootObs = leafEnv16608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16608 rootObs == leafEnv16608) = true)

theorem terminalChecked16608 : H12PackedTerminal.terminalCheckFast leafEnv16608 active16608 tree16608 = true := by decide +kernel

def env16609 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,9,0,260,65536,0,513,272,261,0,4194304,16,65536,129,17,4195076,0,0,1073741824,21,4194440,256,65570,0,512]

theorem envBound16609 : H12AffineFastState.Bounded env16609 := by
  intro p hp
  have h : env16609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16583_16609 : H12AffineEnvironment.transform 12 9 env16583 = env16609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env16583 == env16609) = true)

theorem identity16609 : scanCanonicalize (H12AffineFastState.compose env16609 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound16609 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env16610 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,9,0,260,34,0,513,272,261,0,4194304,16,34,129,17,4195076,0,0,1073741824,21,4194440,256,0,0,512]

theorem envBound16610 : H12AffineFastState.Bounded env16610 := by
  intro p hp
  have h : env16610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16609_16610 : H12AffineEnvironment.transform 15 34 env16609 = env16610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env16609 == env16610) = true)

def env16611 : List Nat := [2,4,8,16,0,17,128,256,512,272,2048,0,9,0,260,2,0,513,272,261,0,4194304,16,2,129,17,4195076,0,0,1073741824,21,4194440,256,0,0,512]

theorem envBound16611 : H12AffineFastState.Bounded env16611 := by
  intro p hp
  have h : env16611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16610_16611 : H12AffineEnvironment.transform 4 0 env16610 = env16611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16610 == env16611) = true)

def env16612 : List Nat := [2,4,8,16,0,17,128,256,512,272,2048,0,9,0,260,2,0,513,272,261,0,4194304,16,2,129,17,4195076,0,0,2048,21,4194440,256,0,0,512]

theorem envBound16612 : H12AffineFastState.Bounded env16612 := by
  intro p hp
  have h : env16612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16611_16612 : H12AffineEnvironment.transform 29 2048 env16611 = env16612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 2048 env16611 == env16612) = true)

theorem identity16612 : scanCanonicalize (H12AffineFastState.compose env16612 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound16612 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16613 : List Nat := [2,4,8,16,0,17,128,256,1,272,2048,0,9,0,260,2,0,0,272,261,0,4194304,16,2,129,17,4194565,0,0,2048,21,4194440,256,0,0,1]

theorem envBound16613 : H12AffineFastState.Bounded env16613 := by
  intro p hp
  have h : env16613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16612_16613 : H12AffineEnvironment.transform 8 1 env16612 = env16613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env16612 == env16613) = true)

theorem identity16613 : scanCanonicalize (H12AffineFastState.compose env16613 (packedSelected [0,7] rootPS)) = affineNative (2^(21+1) ^^^ 2049) := by decide +kernel

theorem selectedBound16613 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env16614 : List Nat := [2,4,8,16,0,17,128,256,1,272,2048,0,9,0,260,2,0,0,272,261,0,2049,16,2,129,17,2308,0,0,2048,21,2185,256,0,0,1]

theorem envBound16614 : H12AffineFastState.Bounded env16614 := by
  intro p hp
  have h : env16614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16613_16614 : H12AffineEnvironment.transform 21 2049 env16613 = env16614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2049 env16613 == env16614) = true)

theorem identity16614 : scanCanonicalize (H12AffineFastState.compose env16614 (packedSelected [4,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound16614 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env16615 : List Nat := [2,4,8,16,0,17,128,256,1,272,260,0,9,0,260,2,0,0,272,261,0,261,16,2,129,17,0,0,0,260,21,397,256,0,0,1]

theorem envBound16615 : H12AffineFastState.Bounded env16615 := by
  intro p hp
  have h : env16615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16614_16615 : H12AffineEnvironment.transform 10 260 env16614 = env16615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env16614 == env16615) = true)

theorem identity16615 : scanCanonicalize (H12AffineFastState.compose env16615 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound16615 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env16616 : List Nat := [2,4,8,16,0,17,9,256,1,272,260,0,9,0,260,2,0,0,272,261,0,261,16,2,8,17,0,0,0,260,21,260,256,0,0,1]

theorem envBound16616 : H12AffineFastState.Bounded env16616 := by
  intro p hp
  have h : env16616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16615_16616 : H12AffineEnvironment.transform 6 9 env16615 = env16616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16615 == env16616) = true)

theorem identity16616 : scanCanonicalize (H12AffineFastState.compose env16616 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound16616 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16617 : List Nat := [2,4,8,16,0,17,9,4,1,20,0,0,9,0,0,2,0,0,20,1,0,1,16,2,8,17,0,0,0,0,21,0,4,0,0,1]

theorem envBound16617 : H12AffineFastState.Bounded env16617 := by
  intro p hp
  have h : env16617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16616_16617 : H12AffineEnvironment.transform 7 4 env16616 = env16617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env16616 == env16617) = true)

def leafEnv16617 : List Nat := [2,4,8,16,0,17,9,4,1,20,0,0,9,0,0,2,0,0,20,1,0,1,16,2,21,8,1,17,0,0,0,0,21,0,4,0,4,2,0,1,0,0,1]

def active16617 : List Nat := [0,1,2,3]

def tree16617 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16617 : H12WitnessSearch.Good tree16617 := H12GlobalWitnessIndex.good

theorem leafIdentity16617 : H12AffineFastState.composeSystem env16617 rootObs = leafEnv16617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16617 rootObs == leafEnv16617) = true)

theorem terminalChecked16617 : H12PackedTerminal.terminalCheckFast leafEnv16617 active16617 tree16617 = true := by decide +kernel

def env16618 : List Nat := [2,4,8,16,0,17,128,256,512,272,2048,0,9,0,260,2,0,513,272,261,0,4194304,16,2,129,17,4195076,0,0,2049,21,4194440,256,0,0,512]

theorem envBound16618 : H12AffineFastState.Bounded env16618 := by
  intro p hp
  have h : env16618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16611_16618 : H12AffineEnvironment.transform 29 2049 env16611 = env16618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 2049 env16611 == env16618) = true)

theorem identity16618 : scanCanonicalize (H12AffineFastState.compose env16618 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound16618 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16619 : List Nat := [2,4,8,16,0,17,128,256,136,272,2048,0,9,0,260,2,0,137,272,261,0,4194304,16,2,129,17,4194700,0,0,2049,21,4194440,256,0,0,136]

theorem envBound16619 : H12AffineFastState.Bounded env16619 := by
  intro p hp
  have h : env16619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16618_16619 : H12AffineEnvironment.transform 8 136 env16618 = env16619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env16618 == env16619) = true)

theorem identity16619 : scanCanonicalize (H12AffineFastState.compose env16619 (packedSelected [7,18] rootPS)) = affineNative (2^(21+1) ^^^ 396) := by decide +kernel

theorem selectedBound16619 : packedSelected [7,18] rootPS < 2^1333 := by decide +kernel

def env16620 : List Nat := [2,4,8,16,0,17,128,256,136,272,2048,0,9,0,260,2,0,137,272,261,0,396,16,2,129,17,0,0,0,2049,21,260,256,0,0,136]

theorem envBound16620 : H12AffineFastState.Bounded env16620 := by
  intro p hp
  have h : env16620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16619_16620 : H12AffineEnvironment.transform 21 396 env16619 = env16620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 396 env16619 == env16620) = true)

theorem identity16620 : scanCanonicalize (H12AffineFastState.compose env16620 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound16620 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env16621 : List Nat := [2,4,8,16,0,17,128,140,136,156,2048,0,9,0,136,2,0,137,156,137,0,0,16,2,129,17,0,0,0,2049,21,136,140,0,0,136]

theorem envBound16621 : H12AffineFastState.Bounded env16621 := by
  intro p hp
  have h : env16621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16620_16621 : H12AffineEnvironment.transform 7 140 env16620 = env16621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env16620 == env16621) = true)

theorem identity16621 : scanCanonicalize (H12AffineFastState.compose env16621 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound16621 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16622 : List Nat := [2,4,8,16,0,17,8,4,0,20,2048,0,9,0,0,2,0,1,20,1,0,0,16,2,9,17,0,0,0,2049,21,0,4,0,0,0]

theorem envBound16622 : H12AffineFastState.Bounded env16622 := by
  intro p hp
  have h : env16622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16621_16622 : H12AffineEnvironment.transform 6 8 env16621 = env16622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16621 == env16622) = true)

theorem identity16622 : scanCanonicalize (H12AffineFastState.compose env16622 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound16622 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env16623 : List Nat := [2,4,8,16,0,17,8,4,0,20,1,0,9,0,0,2,0,1,20,1,0,0,16,2,9,17,0,0,0,0,21,0,4,0,0,0]

theorem envBound16623 : H12AffineFastState.Bounded env16623 := by
  intro p hp
  have h : env16623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16622_16623 : H12AffineEnvironment.transform 10 1 env16622 = env16623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env16622 == env16623) = true)

def leafEnv16623 : List Nat := [2,4,8,16,0,17,8,4,0,20,1,0,9,0,0,2,0,1,20,1,0,0,16,2,21,9,1,17,0,0,0,0,21,0,4,0,4,2,0,0,0,0,1]

def active16623 : List Nat := [0,1,2,3]

def tree16623 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16623 : H12WitnessSearch.Good tree16623 := H12GlobalWitnessIndex.good

theorem leafIdentity16623 : H12AffineFastState.composeSystem env16623 rootObs = leafEnv16623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16623 rootObs == leafEnv16623) = true)

theorem terminalChecked16623 : H12PackedTerminal.terminalCheckFast leafEnv16623 active16623 tree16623 = true := by decide +kernel

def env16624 : List Nat := [2,4,8,16,1,17,128,256,512,272,2048,0,9,0,260,3,0,513,272,261,0,4194304,16,3,129,17,4195076,0,0,1073741824,21,4194440,256,0,0,512]

theorem envBound16624 : H12AffineFastState.Bounded env16624 := by
  intro p hp
  have h : env16624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16610_16624 : H12AffineEnvironment.transform 4 1 env16610 = env16624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16610 == env16624) = true)

def env16625 : List Nat := [2,4,8,16,1,17,128,256,512,272,2048,0,9,0,260,3,0,513,272,261,0,4194304,16,3,129,17,4195076,0,0,2048,21,4194440,256,0,0,512]

theorem envBound16625 : H12AffineFastState.Bounded env16625 := by
  intro p hp
  have h : env16625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16624_16625 : H12AffineEnvironment.transform 29 2048 env16624 = env16625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 2048 env16624 == env16625) = true)

theorem identity16625 : scanCanonicalize (H12AffineFastState.compose env16625 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 396) := by decide +kernel

theorem selectedBound16625 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16626 : List Nat := [2,4,8,16,1,17,128,256,396,272,2048,0,9,0,260,3,0,397,272,261,0,4194304,16,3,129,17,4194440,0,0,2048,21,4194440,256,0,0,396]

theorem envBound16626 : H12AffineFastState.Bounded env16626 := by
  intro p hp
  have h : env16626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16625_16626 : H12AffineEnvironment.transform 8 396 env16625 = env16626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 396 env16625 == env16626) = true)

theorem identity16626 : scanCanonicalize (H12AffineFastState.compose env16626 (packedSelected [0,11,18] rootPS)) = affineNative (2^(21+1) ^^^ 2444) := by decide +kernel

theorem selectedBound16626 : packedSelected [0,11,18] rootPS < 2^1333 := by decide +kernel

def env16627 : List Nat := [2,4,8,16,1,17,128,256,396,272,2048,0,9,0,260,3,0,397,272,261,0,2444,16,3,129,17,2308,0,0,2048,21,2308,256,0,0,396]

theorem envBound16627 : H12AffineFastState.Bounded env16627 := by
  intro p hp
  have h : env16627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16626_16627 : H12AffineEnvironment.transform 21 2444 env16626 = env16627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2444 env16626 == env16627) = true)

theorem identity16627 : scanCanonicalize (H12AffineFastState.compose env16627 (packedSelected [4,7] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound16627 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env16628 : List Nat := [2,4,8,16,1,17,128,256,396,272,0,0,9,0,260,3,0,397,272,261,0,396,16,3,129,17,260,0,0,0,21,260,256,0,0,396]

theorem envBound16628 : H12AffineFastState.Bounded env16628 := by
  intro p hp
  have h : env16628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16627_16628 : H12AffineEnvironment.transform 10 0 env16627 = env16628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env16627 == env16628) = true)

theorem identity16628 : scanCanonicalize (H12AffineFastState.compose env16628 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound16628 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env16629 : List Nat := [2,4,8,16,1,17,8,256,260,272,0,0,9,0,260,3,0,261,272,261,0,260,16,3,9,17,260,0,0,0,21,260,256,0,0,260]

theorem envBound16629 : H12AffineFastState.Bounded env16629 := by
  intro p hp
  have h : env16629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16628_16629 : H12AffineEnvironment.transform 6 8 env16628 = env16629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16628 == env16629) = true)

theorem identity16629 : scanCanonicalize (H12AffineFastState.compose env16629 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound16629 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16630 : List Nat := [2,4,8,16,1,17,8,4,0,20,0,0,9,0,0,3,0,1,20,1,0,0,16,3,9,17,0,0,0,0,21,0,4,0,0,0]

theorem envBound16630 : H12AffineFastState.Bounded env16630 := by
  intro p hp
  have h : env16630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16629_16630 : H12AffineEnvironment.transform 7 4 env16629 = env16630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env16629 == env16630) = true)

def env16631 : List Nat := [2,4,8,16,1,17,128,256,512,272,2048,0,9,0,260,3,0,513,272,261,0,4194304,16,3,129,17,4195076,0,0,2049,21,4194440,256,0,0,512]

theorem envBound16631 : H12AffineFastState.Bounded env16631 := by
  intro p hp
  have h : env16631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16624_16631 : H12AffineEnvironment.transform 29 2049 env16624 = env16631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 2049 env16624 == env16631) = true)

theorem identity16631 : scanCanonicalize (H12AffineFastState.compose env16631 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound16631 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16632 : List Nat := [2,4,8,16,1,17,128,256,261,272,2048,0,9,0,260,3,0,260,272,261,0,4194304,16,3,129,17,4194305,0,0,2049,21,4194440,256,0,0,261]

theorem envBound16632 : H12AffineFastState.Bounded env16632 := by
  intro p hp
  have h : env16632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16631_16632 : H12AffineEnvironment.transform 8 261 env16631 = env16632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env16631 == env16632) = true)

theorem identity16632 : scanCanonicalize (H12AffineFastState.compose env16632 (packedSelected [11] rootPS)) = affineNative (2^(21+1) ^^^ 2309) := by decide +kernel

theorem selectedBound16632 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env16633 : List Nat := [2,4,8,16,1,17,128,256,261,272,2048,0,9,0,260,3,0,260,272,261,0,2309,16,3,129,17,2308,0,0,2049,21,2445,256,0,0,261]

theorem envBound16633 : H12AffineFastState.Bounded env16633 := by
  intro p hp
  have h : env16633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16632_16633 : H12AffineEnvironment.transform 21 2309 env16632 = env16633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2309 env16632 == env16633) = true)

theorem identity16633 : scanCanonicalize (H12AffineFastState.compose env16633 (packedSelected [4,9] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound16633 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env16634 : List Nat := [2,4,8,16,1,17,128,256,261,272,260,0,9,0,260,3,0,260,272,261,0,1,16,3,129,17,0,0,0,261,21,137,256,0,0,261]

theorem envBound16634 : H12AffineFastState.Bounded env16634 := by
  intro p hp
  have h : env16634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16633_16634 : H12AffineEnvironment.transform 10 260 env16633 = env16634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env16633 == env16634) = true)

theorem identity16634 : scanCanonicalize (H12AffineFastState.compose env16634 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound16634 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env16635 : List Nat := [2,4,8,16,1,17,128,141,136,157,137,0,9,0,137,3,0,137,157,136,0,1,16,3,129,17,0,0,0,136,21,137,141,0,0,136]

theorem envBound16635 : H12AffineFastState.Bounded env16635 := by
  intro p hp
  have h : env16635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16634_16635 : H12AffineEnvironment.transform 7 141 env16634 = env16635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env16634 == env16635) = true)

theorem identity16635 : scanCanonicalize (H12AffineFastState.compose env16635 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound16635 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16636 : List Nat := [2,4,8,16,1,17,9,4,1,20,0,0,9,0,0,3,0,0,20,1,0,1,16,3,8,17,0,0,0,1,21,0,4,0,0,1]

theorem envBound16636 : H12AffineFastState.Bounded env16636 := by
  intro p hp
  have h : env16636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16635_16636 : H12AffineEnvironment.transform 6 9 env16635 = env16636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16635 == env16636) = true)

def env16637 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,8192,0,261,65536,0,513,272,260,0,4194304,16,65537,8328,17,4195076,0,0,1073741824,21,4194440,256,65571,0,512]

theorem envBound16637 : H12AffineFastState.Bounded env16637 := by
  intro p hp
  have h : env16637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16582_16637 : H12AffineEnvironment.transform 14 261 env16582 = env16637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 261 env16582 == env16637) = true)

def env16638 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,8,0,261,65536,0,513,272,260,0,4194304,16,65537,128,17,4195076,0,0,1073741824,21,4194440,256,65571,0,512]

theorem envBound16638 : H12AffineFastState.Bounded env16638 := by
  intro p hp
  have h : env16638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16637_16638 : H12AffineEnvironment.transform 12 8 env16637 = env16638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env16637 == env16638) = true)

theorem identity16638 : scanCanonicalize (H12AffineFastState.compose env16638 (packedSelected [6] rootPS)) = affineNative (2^(29+1) ^^^ 4196780) := by decide +kernel

theorem selectedBound16638 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env16639 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,0,8,0,261,65536,0,513,272,260,0,4194304,16,65537,128,17,4195076,0,0,4196780,21,4194440,256,65571,0,512]

theorem envBound16639 : H12AffineFastState.Bounded env16639 := by
  intro p hp
  have h : env16639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16638_16639 : H12AffineEnvironment.transform 29 4196780 env16638 = env16639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 4196780 env16638 == env16639) = true)

def env16640 : List Nat := [2,4,8,16,32,17,40,256,512,272,2048,0,8,0,261,65536,0,513,272,260,0,4194304,16,65537,40,17,4195076,0,0,4196612,21,4194336,256,65571,0,512]

theorem envBound16640 : H12AffineFastState.Bounded env16640 := by
  intro p hp
  have h : env16640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16639_16640 : H12AffineEnvironment.transform 6 40 env16639 = env16640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env16639 == env16640) = true)

theorem identity16640 : scanCanonicalize (H12AffineFastState.compose env16640 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound16640 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env16641 : List Nat := [2,4,8,16,32,17,40,256,512,272,2048,0,8,0,261,65536,0,513,272,260,0,32,16,65537,40,17,804,0,0,2340,21,0,256,65571,0,512]

theorem envBound16641 : H12AffineFastState.Bounded env16641 := by
  intro p hp
  have h : env16641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16640_16641 : H12AffineEnvironment.transform 21 32 env16640 = env16641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env16640 == env16641) = true)

theorem identity16641 : scanCanonicalize (H12AffineFastState.compose env16641 (packedSelected [11,18] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound16641 : packedSelected [11,18] rootPS < 2^1333 := by decide +kernel

def env16642 : List Nat := [2,4,8,16,1,17,9,256,512,272,2048,0,8,0,261,65536,0,513,272,260,0,1,16,65537,9,17,773,0,0,2309,21,0,256,65538,0,512]

theorem envBound16642 : H12AffineFastState.Bounded env16642 := by
  intro p hp
  have h : env16642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16641_16642 : H12AffineEnvironment.transform 4 1 env16641 = env16642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16641 == env16642) = true)

theorem identity16642 : scanCanonicalize (H12AffineFastState.compose env16642 (packedSelected [2,7] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound16642 : packedSelected [2,7] rootPS < 2^1333 := by decide +kernel

def env16643 : List Nat := [2,4,8,16,1,17,9,256,261,272,2048,0,8,0,261,65536,0,260,272,260,0,1,16,65537,9,17,0,0,0,2309,21,0,256,65538,0,261]

theorem envBound16643 : H12AffineFastState.Bounded env16643 := by
  intro p hp
  have h : env16643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16642_16643 : H12AffineEnvironment.transform 8 261 env16642 = env16643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env16642 == env16643) = true)

theorem identity16643 : scanCanonicalize (H12AffineFastState.compose env16643 (packedSelected [0,4] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound16643 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env16644 : List Nat := [2,4,8,16,1,17,9,256,261,272,2048,0,8,0,261,262,0,260,272,260,0,1,16,263,9,17,0,0,0,2309,21,0,256,260,0,261]

theorem envBound16644 : H12AffineFastState.Bounded env16644 := by
  intro p hp
  have h : env16644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16643_16644 : H12AffineEnvironment.transform 15 262 env16643 = env16644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env16643 == env16644) = true)

def env16645 : List Nat := [2,4,8,16,32,17,41,256,512,272,2048,0,8,0,261,65536,0,513,272,260,0,4194304,16,65537,41,17,4195076,0,0,4196613,21,4194337,256,65571,0,512]

theorem envBound16645 : H12AffineFastState.Bounded env16645 := by
  intro p hp
  have h : env16645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16639_16645 : H12AffineEnvironment.transform 6 41 env16639 = env16645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env16639 == env16645) = true)

theorem identity16645 : scanCanonicalize (H12AffineFastState.compose env16645 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 805) := by decide +kernel

theorem selectedBound16645 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env16646 : List Nat := [2,4,8,16,32,17,41,256,512,272,805,0,8,0,261,65536,0,513,272,260,0,4194304,16,65537,41,17,4195076,0,0,4194848,21,4194337,256,65571,0,512]

theorem envBound16646 : H12AffineFastState.Bounded env16646 := by
  intro p hp
  have h : env16646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16645_16646 : H12AffineEnvironment.transform 10 805 env16645 = env16646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 805 env16645 == env16646) = true)

def env16647 : List Nat := [2,4,8,16,32,17,41,256,512,272,805,0,8,0,261,65536,0,513,272,260,0,32,16,65537,41,17,804,0,0,512,21,1,256,65571,0,512]

theorem envBound16647 : H12AffineFastState.Bounded env16647 := by
  intro p hp
  have h : env16647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16646_16647 : H12AffineEnvironment.transform 21 32 env16646 = env16647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env16646 == env16647) = true)

def env16648 : List Nat := [2,4,8,16,32,17,41,4,512,20,545,0,8,0,1,65536,0,513,20,0,0,32,16,65537,41,17,544,0,0,512,21,1,4,65571,0,512]

theorem envBound16648 : H12AffineFastState.Bounded env16648 := by
  intro p hp
  have h : env16648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16647_16648 : H12AffineEnvironment.transform 7 4 env16647 = env16648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env16647 == env16648) = true)

theorem identity16648 : scanCanonicalize (H12AffineFastState.compose env16648 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 514) := by decide +kernel

theorem selectedBound16648 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16649 : List Nat := [2,4,8,16,32,17,41,4,512,20,545,0,8,0,1,514,0,513,20,0,0,32,16,515,41,17,544,0,0,512,21,1,4,545,0,512]

theorem envBound16649 : H12AffineFastState.Bounded env16649 := by
  intro p hp
  have h : env16649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16648_16649 : H12AffineEnvironment.transform 15 514 env16648 = env16649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 514 env16648 == env16649) = true)

theorem identity16649 : scanCanonicalize (H12AffineFastState.compose env16649 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound16649 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env16650 : List Nat := [2,4,8,16,32,17,41,4,33,20,0,0,8,0,1,35,0,32,20,0,0,32,16,34,41,17,1,0,0,33,21,1,4,0,0,33]

theorem envBound16650 : H12AffineFastState.Bounded env16650 := by
  intro p hp
  have h : env16650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16649_16650 : H12AffineEnvironment.transform 8 33 env16649 = env16650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env16649 == env16650) = true)

theorem identity16650 : scanCanonicalize (H12AffineFastState.compose env16650 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound16650 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16651 : List Nat := [2,4,8,16,1,17,8,4,0,20,0,0,8,0,1,2,0,1,20,0,0,1,16,3,8,17,1,0,0,0,21,1,4,0,0,0]

theorem envBound16651 : H12AffineFastState.Bounded env16651 := by
  intro p hp
  have h : env16651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16650_16651 : H12AffineEnvironment.transform 4 1 env16650 = env16651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16650 == env16651) = true)

def leafEnv16651 : List Nat := [2,4,8,16,1,17,8,4,0,20,0,0,8,0,1,2,0,1,20,0,0,1,16,3,21,8,1,17,1,0,0,0,21,1,4,0,4,3,0,0,0,0,1]

def active16651 : List Nat := [0,1,2,3]

def tree16651 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16651 : H12WitnessSearch.Good tree16651 := H12GlobalWitnessIndex.good

theorem leafIdentity16651 : H12AffineFastState.composeSystem env16651 rootObs = leafEnv16651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16651 rootObs == leafEnv16651) = true)

theorem terminalChecked16651 : H12PackedTerminal.terminalCheckFast leafEnv16651 active16651 tree16651 = true := by decide +kernel

def env16652 : List Nat := [2,4,8,16,32,17,41,5,512,21,544,0,8,0,0,65536,0,513,21,1,0,32,16,65537,41,17,545,0,0,512,21,1,5,65571,0,512]

theorem envBound16652 : H12AffineFastState.Bounded env16652 := by
  intro p hp
  have h : env16652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16647_16652 : H12AffineEnvironment.transform 7 5 env16647 = env16652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env16647 == env16652) = true)

theorem identity16652 : scanCanonicalize (H12AffineFastState.compose env16652 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound16652 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16653 : List Nat := [2,4,8,16,32,17,41,5,33,21,1,0,8,0,0,65536,0,32,21,1,0,32,16,65537,41,17,0,0,0,33,21,1,5,65571,0,33]

theorem envBound16653 : H12AffineFastState.Bounded env16653 := by
  intro p hp
  have h : env16653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16652_16653 : H12AffineEnvironment.transform 8 33 env16652 = env16653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env16652 == env16653) = true)

theorem identity16653 : scanCanonicalize (H12AffineFastState.compose env16653 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound16653 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16654 : List Nat := [2,4,8,16,0,17,9,5,1,21,1,0,8,0,0,65536,0,0,21,1,0,0,16,65537,9,17,0,0,0,1,21,1,5,65539,0,1]

theorem envBound16654 : H12AffineFastState.Bounded env16654 := by
  intro p hp
  have h : env16654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16653_16654 : H12AffineEnvironment.transform 4 0 env16653 = env16654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16653 == env16654) = true)

def leafEnv16654 : List Nat := [2,4,8,16,0,17,9,5,1,21,1,0,8,0,0,65536,0,0,21,1,0,0,16,65537,21,9,1,17,0,0,0,1,21,1,5,65539,4,3,0,1,0,0,1]

def active16654 : List Nat := [0,1,2,3,15]

def tree16654 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood16654 : H12WitnessSearch.Good tree16654 := H12GlobalWitnessIndex.good

theorem leafIdentity16654 : H12AffineFastState.composeSystem env16654 rootObs = leafEnv16654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env16654 rootObs == leafEnv16654) = true)

theorem terminalChecked16654 : H12PackedTerminal.terminalCheckFast leafEnv16654 active16654 tree16654 = true := by decide +kernel

def env16655 : List Nat := [2,4,8,16,32,17,41,256,512,272,805,0,8,0,261,65536,0,513,272,260,0,33,16,65537,41,17,805,0,0,513,21,0,256,65571,0,512]

theorem envBound16655 : H12AffineFastState.Bounded env16655 := by
  intro p hp
  have h : env16655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16646_16655 : H12AffineEnvironment.transform 21 33 env16646 = env16655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env16646 == env16655) = true)

theorem identity16655 : scanCanonicalize (H12AffineFastState.compose env16655 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound16655 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env16656 : List Nat := [2,4,8,16,32,17,41,36,512,52,513,0,8,0,33,65536,0,513,52,32,0,33,16,65537,41,17,513,0,0,513,21,0,36,65571,0,512]

theorem envBound16656 : H12AffineFastState.Bounded env16656 := by
  intro p hp
  have h : env16656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16655_16656 : H12AffineEnvironment.transform 7 36 env16655 = env16656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env16655 == env16656) = true)

theorem identity16656 : scanCanonicalize (H12AffineFastState.compose env16656 (packedSelected [11] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound16656 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env16657 : List Nat := [2,4,8,16,32,17,41,36,32,52,33,0,8,0,33,65536,0,33,52,32,0,33,16,65537,41,17,33,0,0,33,21,0,36,65571,0,32]

theorem envBound16657 : H12AffineFastState.Bounded env16657 := by
  intro p hp
  have h : env16657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16656_16657 : H12AffineEnvironment.transform 8 32 env16656 = env16657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env16656 == env16657) = true)

end H12CloudChart2