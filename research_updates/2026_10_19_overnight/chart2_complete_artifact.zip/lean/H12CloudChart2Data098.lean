import H12CloudChart2Data097

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env24070 : List Nat := [2,4,8,16,32,17,128,256,0,1024,2048,4096,8192,4097,8581,8203,1296,8460,1025,8580,4097,260,5376,139,8328,5377,8461,4096,1296,8352,1284,10368,257,10661,1296,0]

theorem envBound24070 : H12AffineFastState.Bounded env24070 := by
  intro p hp
  have h : env24070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24069_24070 : H12AffineEnvironment.transform 8 0 env24069 = env24070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env24069 == env24070) = true)

theorem identity24070 : scanCanonicalize (H12AffineFastState.compose env24070 (packedSelected [0,2,6] rootPS)) = affineNative (2^(12+1) ^^^ 7180) := by decide +kernel

theorem selectedBound24070 : packedSelected [0,2,6] rootPS < 2^1333 := by decide +kernel

def env24071 : List Nat := [2,4,8,16,32,17,128,256,0,1024,2048,4096,7180,4097,7561,7175,1296,7424,1025,7560,4097,260,5376,139,7300,5377,7425,4096,1296,7340,1284,5260,257,5545,1296,0]

theorem envBound24071 : H12AffineFastState.Bounded env24071 := by
  intro p hp
  have h : env24071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24070_24071 : H12AffineEnvironment.transform 12 7180 env24070 = env24071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7180 env24070 == env24071) = true)

def env24072 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,268435456,536870912,1073741824,897815633,4294967296,805967105,4315938987,34359738368,512]

theorem envBound24072 : H12AffineFastState.Bounded env24072 := by
  intro p hp
  have h : env24072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12203_24072 : H12AffineEnvironment.transform 32 805967105 env12203 = env24072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 32 805967105 env12203 == env24072) = true)

theorem identity24072 : scanCanonicalize (H12AffineFastState.compose env24072 (packedSelected [0,4,6,7,16,20,22,25] rootPS)) = affineNative (2^(27+1) ^^^ 147719493) := by decide +kernel

theorem selectedBound24072 : packedSelected [0,4,6,7,16,20,22,25] rootPS < 2^1333 := by decide +kernel

def env24073 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,147719493,536870912,1073741824,760058132,4294967296,683937860,4315938987,34359738368,512]

theorem envBound24073 : H12AffineFastState.Bounded env24073 := by
  intro p hp
  have h : env24073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24072_24073 : H12AffineEnvironment.transform 27 147719493 env24072 = env24073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 147719493 env24072 == env24073) = true)

theorem identity24073 : scanCanonicalize (H12AffineFastState.compose env24073 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(22+1) ^^^ 660497) := by decide +kernel

theorem selectedBound24073 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env24074 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,660497,16777216,8328,67108864,134217728,138678612,536870912,1073741824,760058132,4294967296,676201557,4315938987,34359738368,512]

theorem envBound24074 : H12AffineFastState.Bounded env24074 := by
  intro p hp
  have h : env24074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24073_24074 : H12AffineEnvironment.transform 22 660497 env24073 = env24074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 660497 env24073 == env24074) = true)

def env24075 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,660497,16777216,8328,67108864,134217728,138678612,536870912,1073741824,760058132,4294967296,676201557,4315938987,34359738368,136]

theorem envBound24075 : H12AffineFastState.Bounded env24075 := by
  intro p hp
  have h : env24075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24074_24075 : H12AffineEnvironment.transform 8 136 env24074 = env24075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env24074 == env24075) = true)

theorem identity24075 : scanCanonicalize (H12AffineFastState.compose env24075 (packedSelected [1,4,8,9,13,14,16,19,21] rootPS)) = affineNative (2^(34+1) ^^^ 86736900) := by decide +kernel

theorem selectedBound24075 : packedSelected [1,4,8,9,13,14,16,19,21] rootPS < 2^1333 := by decide +kernel

def env24076 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,660497,16777216,8328,67108864,134217728,138678612,536870912,1073741824,760058132,4294967296,676201557,4315938987,86736900,136]

theorem envBound24076 : H12AffineFastState.Bounded env24076 := by
  intro p hp
  have h : env24076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24075_24076 : H12AffineEnvironment.transform 34 86736900 env24075 = env24076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 86736900 env24075 == env24076) = true)

theorem identity24076 : scanCanonicalize (H12AffineFastState.compose env24076 (packedSelected [0,4,7,9,14,16,20] rootPS)) = affineNative (2^(28+1) ^^^ 138805588) := by decide +kernel

theorem selectedBound24076 : packedSelected [0,4,7,9,14,16,20] rootPS < 2^1333 := by decide +kernel

def env24077 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,660497,16777216,8328,67108864,134217728,138678612,138805588,1073741824,84643904,4294967296,525569,4315938987,86736900,136]

theorem envBound24077 : H12AffineFastState.Bounded env24077 := by
  intro p hp
  have h : env24077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24076_24077 : H12AffineEnvironment.transform 28 138805588 env24076 = env24077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 138805588 env24076 == env24077) = true)

theorem identity24077 : scanCanonicalize (H12AffineFastState.compose env24077 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(26+1) ^^^ 21331969) := by decide +kernel

theorem selectedBound24077 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env24078 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,660497,16777216,8328,67108864,21331969,16879957,17006933,1073741824,84643904,4294967296,525569,4315938987,86736900,136]

theorem envBound24078 : H12AffineFastState.Bounded env24078 := by
  intro p hp
  have h : env24078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24077_24078 : H12AffineEnvironment.transform 26 21331969 env24077 = env24078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 21331969 env24077 == env24078) = true)

def env24079 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,16384,32768,65536,4096,262144,524288,32769,2097152,4194304,525329,16777216,8328,67108864,21331969,16879957,16879957,1073741824,84508736,4294967296,525569,4315938987,86609924,136]

theorem envBound24079 : H12AffineFastState.Bounded env24079 := by
  intro p hp
  have h : env24079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24078_24079 : H12AffineEnvironment.transform 16 4096 env24078 = env24079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env24078 == env24079) = true)

theorem identity24079 : scanCanonicalize (H12AffineFastState.compose env24079 (packedSelected [3,5,10] rootPS)) = affineNative (2^(23+1) ^^^ 4796613) := by decide +kernel

theorem selectedBound24079 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env24080 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,16384,32768,65536,4096,262144,524288,32769,2097152,4194304,525329,4796613,8328,67108864,831684,4759952,4759952,1073741824,71348357,4294967296,525569,4295569518,73441473,136]

theorem envBound24080 : H12AffineFastState.Bounded env24080 := by
  intro p hp
  have h : env24080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24079_24080 : H12AffineEnvironment.transform 23 4796613 env24079 = env24080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4796613 env24079 == env24080) = true)

def env24081 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,16384,32768,65536,4096,262144,524288,32769,2097152,566400,525329,103493,8328,67108864,831684,1296,1296,1073741824,67638277,4294967296,525569,4295569518,69731393,136]

theorem envBound24081 : H12AffineFastState.Bounded env24081 := by
  intro p hp
  have h : env24081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24080_24081 : H12AffineEnvironment.transform 21 566400 env24080 = env24081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 566400 env24080 == env24081) = true)

def env24082 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,16384,32768,65536,4096,262144,524288,32769,529408,566400,525329,103493,8328,67108864,831684,1296,1296,1073741824,67638277,4294967296,525569,4295569518,67113025,136]

theorem envBound24082 : H12AffineFastState.Bounded env24082 := by
  intro p hp
  have h : env24082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24081_24082 : H12AffineEnvironment.transform 20 529408 env24081 = env24082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 529408 env24081 == env24082) = true)

theorem identity24082 : scanCanonicalize (H12AffineFastState.compose env24082 (packedSelected [14] rootPS)) = affineNative (2^(18+1) ^^^ 16656) := by decide +kernel

theorem selectedBound24082 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env24083 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,16384,32768,65536,4096,262144,16656,32769,21776,58768,17665,103493,8328,67108864,324052,1296,1296,1073741824,67130645,4294967296,17425,4295061886,67113025,136]

theorem envBound24083 : H12AffineFastState.Bounded env24083 := by
  intro p hp
  have h : env24083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24082_24083 : H12AffineEnvironment.transform 18 16656 env24082 = env24083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 16656 env24082 == env24083) = true)

theorem identity24083 : scanCanonicalize (H12AffineFastState.compose env24083 (packedSelected [0,27] rootPS)) = affineNative (2^(25+1) ^^^ 17745) := by decide +kernel

theorem selectedBound24083 : packedSelected [0,27] rootPS < 2^1333 := by decide +kernel

def env24084 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,16384,32768,65536,4096,262144,16656,32769,21776,58768,17665,103493,8328,17745,324052,1296,1296,1073741824,4164,4294967296,17425,4295061886,21776,136]

theorem envBound24084 : H12AffineFastState.Bounded env24084 := by
  intro p hp
  have h : env24084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24083_24084 : H12AffineEnvironment.transform 25 17745 env24083 = env24084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 17745 env24083 == env24084) = true)

theorem identity24084 : scanCanonicalize (H12AffineFastState.compose env24084 (packedSelected [1,12,13] rootPS)) = affineNative (2^(17+1) ^^^ 19897) := by decide +kernel

theorem selectedBound24084 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env24085 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,16384,32768,65536,4096,19897,16656,32769,21776,58768,17665,103493,8328,17745,48237,1296,1296,1073741824,4164,4294967296,17425,4295061886,21776,136]

theorem envBound24085 : H12AffineFastState.Bounded env24085 := by
  intro p hp
  have h : env24085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24084_24085 : H12AffineEnvironment.transform 17 19897 env24084 = env24085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 19897 env24084 == env24085) = true)

theorem identity24085 : scanCanonicalize (H12AffineFastState.compose env24085 (packedSelected [3,15,17] rootPS)) = affineNative (2^(29+1) ^^^ 63956) := by decide +kernel

theorem selectedBound24085 : packedSelected [3,15,17] rootPS < 2^1333 := by decide +kernel

def env24086 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,16384,32768,65536,4096,19897,16656,32769,21776,58768,17665,103493,8328,17745,48237,1296,1296,63956,4164,4294967296,17425,4295061886,21776,136]

theorem envBound24086 : H12AffineFastState.Bounded env24086 := by
  intro p hp
  have h : env24086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24085_24086 : H12AffineEnvironment.transform 29 63956 env24085 = env24086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 63956 env24085 == env24086) = true)

theorem identity24086 : scanCanonicalize (H12AffineFastState.compose env24086 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 26000) := by decide +kernel

theorem selectedBound24086 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env24087 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,16384,26000,65536,4096,19897,16656,26001,21776,0,17665,94677,8328,17745,23037,1296,1296,7236,4164,4294967296,17425,4295061886,21776,136]

theorem envBound24087 : H12AffineFastState.Bounded env24087 := by
  intro p hp
  have h : env24087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24086_24087 : H12AffineEnvironment.transform 14 26000 env24086 = env24087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26000 env24086 == env24087) = true)

def env24088 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,1296,8192,16384,26000,65536,1296,19897,16656,26001,16384,0,17665,91333,8328,17745,19693,1296,1296,2388,1364,4294967296,17425,4295058542,16384,136]

theorem envBound24088 : H12AffineFastState.Bounded env24088 := by
  intro p hp
  have h : env24088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24087_24088 : H12AffineEnvironment.transform 11 1296 env24087 = env24088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env24087 == env24088) = true)

theorem identity24088 : scanCanonicalize (H12AffineFastState.compose env24088 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound24088 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24089 : List Nat := [2,4,8,16,32,64,88,256,80,1024,2048,1296,8192,16384,25928,65536,1296,19809,16656,25929,16384,0,17665,91165,8272,17745,19509,1296,1296,2388,1364,4294967296,17425,4295058542,16384,80]

theorem envBound24089 : H12AffineFastState.Bounded env24089 := by
  intro p hp
  have h : env24089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24088_24089 : H12AffineEnvironment.transform 6 88 env24088 = env24089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env24088 == env24089) = true)

theorem identity24089 : scanCanonicalize (H12AffineFastState.compose env24089 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound24089 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env24090 : List Nat := [2,4,8,16,32,64,88,84,80,1024,2048,1092,8192,16384,25628,65536,1092,19509,16452,25629,16384,0,17493,91165,8272,17413,19509,1092,1092,2048,1024,4294967296,17425,4295058542,16384,80]

theorem envBound24090 : H12AffineFastState.Bounded env24090 := by
  intro p hp
  have h : env24090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24089_24090 : H12AffineEnvironment.transform 7 84 env24089 = env24090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env24089 == env24090) = true)

theorem identity24090 : scanCanonicalize (H12AffineFastState.compose env24090 (packedSelected [0,6] rootPS)) = affineNative (2^(13+1) ^^^ 11324) := by decide +kernel

theorem selectedBound24090 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env24091 : List Nat := [2,4,8,16,32,64,88,84,80,1024,2048,1092,8192,11324,2080,65536,1092,8201,11384,2081,11324,0,10345,67617,8272,10297,8201,1092,1092,2048,1024,4294967296,10285,4295034962,11324,80]

theorem envBound24091 : H12AffineFastState.Bounded env24091 := by
  intro p hp
  have h : env24091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24090_24091 : H12AffineEnvironment.transform 13 11324 env24090 = env24091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11324 env24090 == env24091) = true)

theorem identity24091 : scanCanonicalize (H12AffineFastState.compose env24091 (packedSelected [2,4] rootPS)) = affineNative (2^(12+1) ^^^ 2056) := by decide +kernel

theorem selectedBound24091 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env24092 : List Nat := [2,4,8,16,32,64,88,84,80,1024,2048,1092,2056,1076,2080,65536,1092,2049,1136,2081,1076,0,97,67617,2136,49,2049,1092,1092,2048,1024,4294967296,37,4295034962,1076,80]

theorem envBound24092 : H12AffineFastState.Bounded env24092 := by
  intro p hp
  have h : env24092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24091_24092 : H12AffineEnvironment.transform 12 2056 env24091 = env24092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2056 env24091 == env24092) = true)

def env24093 : List Nat := [2,4,8,16,32,64,88,84,80,1024,32,1092,40,1076,0,65536,1092,33,1136,1,1076,0,97,65537,120,49,33,1092,1092,32,1024,4294967296,37,4295032946,1076,80]

theorem envBound24093 : H12AffineFastState.Bounded env24093 := by
  intro p hp
  have h : env24093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24092_24093 : H12AffineEnvironment.transform 10 32 env24092 = env24093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env24092 == env24093) = true)

theorem identity24093 : scanCanonicalize (H12AffineFastState.compose env24093 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 80) := by decide +kernel

theorem selectedBound24093 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24094 : List Nat := [2,4,8,16,32,64,88,84,80,1024,32,1092,40,1076,0,65536,1092,33,1136,1,1076,0,97,65537,120,49,33,1092,1092,32,1024,80,37,65570,1076,80]

theorem envBound24094 : H12AffineFastState.Bounded env24094 := by
  intro p hp
  have h : env24094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24093_24094 : H12AffineEnvironment.transform 31 80 env24093 = env24094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 80 env24093 == env24094) = true)

def env24095 : List Nat := [2,4,8,16,32,64,88,84,80,52,32,112,40,0,0,65536,112,33,68,1,0,0,97,65537,120,49,33,112,112,32,52,80,37,65570,0,80]

theorem envBound24095 : H12AffineFastState.Bounded env24095 := by
  intro p hp
  have h : env24095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24094_24095 : H12AffineEnvironment.transform 9 52 env24094 = env24095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env24094 == env24095) = true)

theorem identity24095 : scanCanonicalize (H12AffineFastState.compose env24095 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound24095 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24096 : List Nat := [2,4,8,16,26,64,88,84,80,14,26,74,18,0,0,65536,74,27,68,1,0,0,91,65537,66,11,27,74,74,26,14,80,31,65560,0,80]

theorem envBound24096 : H12AffineFastState.Bounded env24096 := by
  intro p hp
  have h : env24096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24095_24096 : H12AffineEnvironment.transform 4 26 env24095 = env24096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env24095 == env24096) = true)

def leafEnv24096 : List Nat := [2,4,8,16,26,64,88,84,80,14,26,74,18,0,0,65536,74,27,68,1,0,0,91,65537,68,66,1,11,27,74,74,26,14,80,31,65560,79,3,0,80,0,0,1]

def active24096 : List Nat := [0,1,2,3,5,15]

def tree24096 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24096 : H12WitnessSearch.Good tree24096 := H12GlobalWitnessIndex.good

theorem leafIdentity24096 : H12AffineFastState.composeSystem env24096 rootObs = leafEnv24096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24096 rootObs == leafEnv24096) = true)

theorem terminalChecked24096 : H12PackedTerminal.terminalCheckFast leafEnv24096 active24096 tree24096 = true := by decide +kernel

def env24097 : List Nat := [2,4,8,16,32,64,88,84,80,53,32,113,40,1,0,65536,113,33,69,1,1,0,97,65537,120,49,33,113,113,32,53,80,37,65570,1,80]

theorem envBound24097 : H12AffineFastState.Bounded env24097 := by
  intro p hp
  have h : env24097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24094_24097 : H12AffineEnvironment.transform 9 53 env24094 = env24097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env24094 == env24097) = true)

theorem identity24097 : scanCanonicalize (H12AffineFastState.compose env24097 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 105) := by decide +kernel

theorem selectedBound24097 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24098 : List Nat := [2,4,8,16,32,64,88,84,80,53,32,113,40,1,0,105,113,33,69,1,1,0,97,104,120,49,33,113,113,32,53,80,37,75,1,80]

theorem envBound24098 : H12AffineFastState.Bounded env24098 := by
  intro p hp
  have h : env24098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24097_24098 : H12AffineEnvironment.transform 15 105 env24097 = env24098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 105 env24097 == env24098) = true)

def leafEnv24098 : List Nat := [2,4,8,16,32,64,88,84,80,53,32,113,40,1,0,105,113,33,69,1,1,0,97,104,69,120,1,49,33,113,113,32,53,80,37,75,117,3,1,80,0,1,1]

def active24098 : List Nat := [0,1,2,3,4,5]

def tree24098 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24098 : H12WitnessSearch.Good tree24098 := H12GlobalWitnessIndex.good

theorem leafIdentity24098 : H12AffineFastState.composeSystem env24098 rootObs = leafEnv24098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24098 rootObs == leafEnv24098) = true)

theorem terminalChecked24098 : H12PackedTerminal.terminalCheckFast leafEnv24098 active24098 tree24098 = true := by decide +kernel

def env24099 : List Nat := [2,4,8,16,32,64,88,84,80,1024,33,1092,41,1076,1,65536,1092,32,1136,0,1076,0,97,65536,121,49,32,1092,1092,33,1024,4294967296,37,4295032947,1076,80]

theorem envBound24099 : H12AffineFastState.Bounded env24099 := by
  intro p hp
  have h : env24099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24092_24099 : H12AffineEnvironment.transform 10 33 env24092 = env24099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env24092 == env24099) = true)

theorem identity24099 : scanCanonicalize (H12AffineFastState.compose env24099 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 65539) := by decide +kernel

theorem selectedBound24099 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24100 : List Nat := [2,4,8,16,32,64,88,84,80,1024,33,1092,41,1076,1,65536,1092,32,1136,0,1076,0,97,65536,121,49,32,1092,1092,33,1024,65539,37,112,1076,80]

theorem envBound24100 : H12AffineFastState.Bounded env24100 := by
  intro p hp
  have h : env24100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24099_24100 : H12AffineEnvironment.transform 31 65539 env24099 = env24100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 65539 env24099 == env24100) = true)

def env24101 : List Nat := [2,4,8,16,32,64,88,84,80,20,33,80,41,32,1,65536,80,32,100,0,32,0,97,65536,121,49,32,80,80,33,20,65539,37,112,32,80]

theorem envBound24101 : H12AffineFastState.Bounded env24101 := by
  intro p hp
  have h : env24101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24100_24101 : H12AffineEnvironment.transform 9 20 env24100 = env24101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env24100 == env24101) = true)

theorem identity24101 : scanCanonicalize (H12AffineFastState.compose env24101 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 72) := by decide +kernel

theorem selectedBound24101 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24102 : List Nat := [2,4,8,16,32,64,88,84,80,20,33,80,41,32,1,72,80,32,100,0,32,0,97,72,121,49,32,80,80,33,20,75,37,112,32,80]

theorem envBound24102 : H12AffineFastState.Bounded env24102 := by
  intro p hp
  have h : env24102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24101_24102 : H12AffineEnvironment.transform 15 72 env24101 = env24102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 72 env24101 == env24102) = true)

def env24103 : List Nat := [2,4,8,16,0,64,88,84,80,20,1,80,9,0,1,72,80,0,68,0,0,0,65,72,89,17,0,80,80,1,20,75,5,80,0,80]

theorem envBound24103 : H12AffineFastState.Bounded env24103 := by
  intro p hp
  have h : env24103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24102_24103 : H12AffineEnvironment.transform 4 0 env24102 = env24103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env24102 == env24103) = true)

def leafEnv24103 : List Nat := [2,4,8,16,0,64,88,84,80,20,1,80,9,0,1,72,80,0,68,0,0,0,65,72,68,89,1,17,0,80,80,1,20,75,5,80,85,2,0,80,0,0,1]

def active24103 : List Nat := [0,1,2,3,5]

def tree24103 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24103 : H12WitnessSearch.Good tree24103 := H12GlobalWitnessIndex.good

theorem leafIdentity24103 : H12AffineFastState.composeSystem env24103 rootObs = leafEnv24103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24103 rootObs == leafEnv24103) = true)

theorem terminalChecked24103 : H12PackedTerminal.terminalCheckFast leafEnv24103 active24103 tree24103 = true := by decide +kernel

def env24104 : List Nat := [2,4,8,16,1,64,88,84,80,20,0,80,8,1,1,72,80,1,69,0,1,0,64,72,88,16,1,80,80,0,20,75,4,81,1,80]

theorem envBound24104 : H12AffineFastState.Bounded env24104 := by
  intro p hp
  have h : env24104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24102_24104 : H12AffineEnvironment.transform 4 1 env24102 = env24104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24102 == env24104) = true)

theorem identity24104 : scanCanonicalize (H12AffineFastState.compose env24104 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound24104 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24105 : List Nat := [2,4,8,11,1,64,67,79,75,15,0,75,8,1,1,72,75,1,69,0,1,0,64,72,67,11,1,75,75,0,15,75,4,74,1,75]

theorem envBound24105 : H12AffineFastState.Bounded env24105 := by
  intro p hp
  have h : env24105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24104_24105 : H12AffineEnvironment.transform 3 11 env24104 = env24105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env24104 == env24105) = true)

def leafEnv24105 : List Nat := [2,4,8,11,1,64,67,79,75,15,0,75,8,1,1,72,75,1,69,0,1,0,64,72,69,67,1,11,1,75,75,0,15,75,4,74,79,2,1,75,0,1,1]

def active24105 : List Nat := [0,1,2,5]

def tree24105 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24105 : H12WitnessSearch.Good tree24105 := H12GlobalWitnessIndex.good

theorem leafIdentity24105 : H12AffineFastState.composeSystem env24105 rootObs = leafEnv24105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24105 rootObs == leafEnv24105) = true)

theorem terminalChecked24105 : H12PackedTerminal.terminalCheckFast leafEnv24105 active24105 tree24105 = true := by decide +kernel

def env24106 : List Nat := [2,4,8,16,32,64,88,84,80,21,33,81,41,33,1,65536,81,32,101,0,33,0,97,65536,121,49,32,81,81,33,21,65539,37,112,33,80]

theorem envBound24106 : H12AffineFastState.Bounded env24106 := by
  intro p hp
  have h : env24106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24100_24106 : H12AffineEnvironment.transform 9 21 env24100 = env24106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env24100 == env24106) = true)

theorem identity24106 : scanCanonicalize (H12AffineFastState.compose env24106 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound24106 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24107 : List Nat := [2,4,8,10,32,64,66,78,74,15,33,75,41,33,1,65536,75,32,101,0,33,0,97,65536,99,43,32,75,75,33,15,65539,37,106,33,74]

theorem envBound24107 : H12AffineFastState.Bounded env24107 := by
  intro p hp
  have h : env24107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24106_24107 : H12AffineEnvironment.transform 3 10 env24106 = env24107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env24106 == env24107) = true)

def env24108 : List Nat := [2,4,8,10,0,64,66,78,74,15,1,75,9,1,1,65536,75,0,69,0,1,0,65,65536,67,11,0,75,75,1,15,65539,5,74,1,74]

theorem envBound24108 : H12AffineFastState.Bounded env24108 := by
  intro p hp
  have h : env24108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24107_24108 : H12AffineEnvironment.transform 4 0 env24107 = env24108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env24107 == env24108) = true)

def leafEnv24108 : List Nat := [2,4,8,10,0,64,66,78,74,15,1,75,9,1,1,65536,75,0,69,0,1,0,65,65536,69,67,1,11,0,75,75,1,15,65539,5,74,79,2,1,74,0,1,1]

def active24108 : List Nat := [0,1,2,5,15]

def tree24108 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24108 : H12WitnessSearch.Good tree24108 := H12GlobalWitnessIndex.good

theorem leafIdentity24108 : H12AffineFastState.composeSystem env24108 rootObs = leafEnv24108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24108 rootObs == leafEnv24108) = true)

theorem terminalChecked24108 : H12PackedTerminal.terminalCheckFast leafEnv24108 active24108 tree24108 = true := by decide +kernel

def env24109 : List Nat := [2,4,8,10,1,64,66,78,74,15,0,75,8,0,1,65536,75,1,68,0,0,0,64,65536,66,10,1,75,75,0,15,65539,4,75,0,74]

theorem envBound24109 : H12AffineFastState.Bounded env24109 := by
  intro p hp
  have h : env24109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24107_24109 : H12AffineEnvironment.transform 4 1 env24107 = env24109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24107 == env24109) = true)

theorem identity24109 : scanCanonicalize (H12AffineFastState.compose env24109 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 73) := by decide +kernel

theorem selectedBound24109 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24110 : List Nat := [2,4,8,10,1,64,66,78,74,15,0,75,8,0,1,73,75,1,68,0,0,0,64,73,66,10,1,75,75,0,15,74,4,75,0,74]

theorem envBound24110 : H12AffineFastState.Bounded env24110 := by
  intro p hp
  have h : env24110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24109_24110 : H12AffineEnvironment.transform 15 73 env24109 = env24110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 73 env24109 == env24110) = true)

def leafEnv24110 : List Nat := [2,4,8,10,1,64,66,78,74,15,0,75,8,0,1,73,75,1,68,0,0,0,64,73,68,66,1,10,1,75,75,0,15,74,4,75,78,2,0,74,0,0,1]

def active24110 : List Nat := [0,1,2,5]

def tree24110 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24110 : H12WitnessSearch.Good tree24110 := H12GlobalWitnessIndex.good

theorem leafIdentity24110 : H12AffineFastState.composeSystem env24110 rootObs = leafEnv24110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24110 rootObs == leafEnv24110) = true)

theorem terminalChecked24110 : H12PackedTerminal.terminalCheckFast leafEnv24110 active24110 tree24110 = true := by decide +kernel

def env24111 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,1297,8192,16384,26000,65536,1297,19897,16656,26001,16385,0,17665,91332,8328,17745,19692,1296,1296,2389,1365,4294967296,17425,4295058543,16385,136]

theorem envBound24111 : H12AffineFastState.Bounded env24111 := by
  intro p hp
  have h : env24111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24087_24111 : H12AffineEnvironment.transform 11 1297 env24087 = env24111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env24087 == env24111) = true)

theorem identity24111 : scanCanonicalize (H12AffineFastState.compose env24111 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 26051) := by decide +kernel

theorem selectedBound24111 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24112 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,1297,8192,16384,26000,26051,1297,19897,16656,26001,16385,0,17665,263,8328,17745,19692,1296,1296,2389,1365,4294967296,17425,4294967724,16385,136]

theorem envBound24112 : H12AffineFastState.Bounded env24112 := by
  intro p hp
  have h : env24112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24111_24112 : H12AffineEnvironment.transform 15 26051 env24111 = env24112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 26051 env24111 == env24112) = true)

theorem identity24112 : scanCanonicalize (H12AffineFastState.compose env24112 (packedSelected [12] rootPS)) = affineNative (2^(13+1) ^^^ 1260) := by decide +kernel

theorem selectedBound24112 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env24113 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,1297,8192,1260,8572,8495,1297,2389,1532,8573,1261,0,493,263,8328,445,2048,1296,1296,2389,1365,4294967296,253,4294967724,1261,136]

theorem envBound24113 : H12AffineFastState.Bounded env24113 := by
  intro p hp
  have h : env24113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24112_24113 : H12AffineEnvironment.transform 13 1260 env24112 = env24113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1260 env24112 == env24113) = true)

theorem identity24113 : scanCanonicalize (H12AffineFastState.compose env24113 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(12+1) ^^^ 2057) := by decide +kernel

theorem selectedBound24113 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env24114 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,1297,2057,1260,2421,2342,1297,2389,1532,2420,1261,0,493,263,2177,445,2048,1296,1296,2389,1365,4294967296,253,4294967724,1261,136]

theorem envBound24114 : H12AffineFastState.Bounded env24114 := by
  intro p hp
  have h : env24114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24113_24114 : H12AffineEnvironment.transform 12 2057 env24113 = env24114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2057 env24113 == env24114) = true)

theorem identity24114 : scanCanonicalize (H12AffineFastState.compose env24114 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound24114 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env24115 : List Nat := [2,4,8,16,32,64,128,85,136,1024,2048,1092,2057,1260,2080,2163,1092,2048,1193,2081,1261,0,184,82,2177,232,2048,1093,1093,2048,1024,4294967296,253,4294967545,1261,136]

theorem envBound24115 : H12AffineFastState.Bounded env24115 := by
  intro p hp
  have h : env24115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24114_24115 : H12AffineEnvironment.transform 7 85 env24114 = env24115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env24114 == env24115) = true)

def env24116 : List Nat := [2,4,8,16,32,64,128,85,136,1024,80,1092,89,1260,112,35,1092,80,1193,113,1261,0,184,82,209,232,80,1093,1093,80,1024,4294967296,253,4294967545,1261,136]

theorem envBound24116 : H12AffineFastState.Bounded env24116 := by
  intro p hp
  have h : env24116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24115_24116 : H12AffineEnvironment.transform 10 80 env24115 = env24116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env24115 == env24116) = true)

theorem identity24116 : scanCanonicalize (H12AffineFastState.compose env24116 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 137) := by decide +kernel

theorem selectedBound24116 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24117 : List Nat := [2,4,8,16,32,64,128,85,136,1024,80,1092,89,1260,112,35,1092,80,1193,113,1261,0,184,82,209,232,80,1093,1093,80,1024,137,253,112,1261,136]

theorem envBound24117 : H12AffineFastState.Bounded env24117 := by
  intro p hp
  have h : env24117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24116_24117 : H12AffineEnvironment.transform 31 137 env24116 = env24117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 137 env24116 == env24117) = true)

def env24118 : List Nat := [2,4,8,16,32,64,88,85,80,1024,80,1092,89,1076,112,35,1092,80,1137,113,1077,0,96,82,9,48,80,1093,1093,80,1024,81,37,112,1077,80]

theorem envBound24118 : H12AffineFastState.Bounded env24118 := by
  intro p hp
  have h : env24118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24117_24118 : H12AffineEnvironment.transform 6 88 env24117 = env24118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env24117 == env24118) = true)

theorem identity24118 : scanCanonicalize (H12AffineFastState.compose env24118 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound24118 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24119 : List Nat := [2,4,8,16,32,10,18,31,26,1024,26,1038,19,1076,58,35,1038,26,1083,59,1077,0,42,24,9,48,26,1039,1039,26,1024,27,37,58,1077,26]

theorem envBound24119 : H12AffineFastState.Bounded env24119 := by
  intro p hp
  have h : env24119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24118_24119 : H12AffineEnvironment.transform 5 10 env24118 = env24119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env24118 == env24119) = true)

theorem identity24119 : scanCanonicalize (H12AffineFastState.compose env24119 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound24119 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24120 : List Nat := [2,4,8,16,27,10,18,31,26,1024,26,1038,19,1039,1,24,1038,26,1024,0,1038,0,17,24,9,11,26,1039,1039,26,1024,27,30,1,1038,26]

theorem envBound24120 : H12AffineFastState.Bounded env24120 := by
  intro p hp
  have h : env24120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24119_24120 : H12AffineEnvironment.transform 4 27 env24119 = env24120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env24119 == env24120) = true)

def leafEnv24120 : List Nat := [2,4,8,16,27,10,18,31,26,1024,26,1038,19,1039,1,24,1038,26,1024,0,1038,0,17,24,1024,9,1,11,26,1039,1039,26,1024,27,30,1,5,2,1038,26,0,1039,1]

def active24120 : List Nat := [0,1,2,3,9]

def tree24120 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24120 : H12WitnessSearch.Good tree24120 := H12GlobalWitnessIndex.good

theorem leafIdentity24120 : H12AffineFastState.composeSystem env24120 rootObs = leafEnv24120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24120 rootObs == leafEnv24120) = true)

theorem terminalChecked24120 : H12PackedTerminal.terminalCheckFast leafEnv24120 active24120 tree24120 = true := by decide +kernel

def env24121 : List Nat := [2,4,8,16,32,64,89,85,81,1024,80,1092,89,1077,112,35,1092,80,1136,113,1076,0,97,82,8,49,80,1093,1093,80,1024,80,36,112,1076,81]

theorem envBound24121 : H12AffineFastState.Bounded env24121 := by
  intro p hp
  have h : env24121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24117_24121 : H12AffineEnvironment.transform 6 89 env24117 = env24121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env24117 == env24121) = true)

theorem identity24121 : scanCanonicalize (H12AffineFastState.compose env24121 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 126) := by decide +kernel

theorem selectedBound24121 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24122 : List Nat := [2,4,8,16,32,64,89,85,81,126,80,58,89,75,112,35,58,80,14,113,74,0,97,82,8,49,80,59,59,80,126,80,36,112,74,81]

theorem envBound24122 : H12AffineFastState.Bounded env24122 := by
  intro p hp
  have h : env24122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24121_24122 : H12AffineEnvironment.transform 9 126 env24121 = env24122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 126 env24121 == env24122) = true)

def leafEnv24122 : List Nat := [2,4,8,16,32,64,89,85,81,126,80,58,89,75,112,35,58,80,14,113,74,0,97,82,14,8,1,49,80,59,59,80,126,80,36,112,117,115,74,81,0,75,1]

def active24122 : List Nat := [0,1,2,3,4,5]

def tree24122 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24122 : H12WitnessSearch.Good tree24122 := H12GlobalWitnessIndex.good

theorem leafIdentity24122 : H12AffineFastState.composeSystem env24122 rootObs = leafEnv24122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24122 rootObs == leafEnv24122) = true)

theorem terminalChecked24122 : H12PackedTerminal.terminalCheckFast leafEnv24122 active24122 tree24122 = true := by decide +kernel

def env24123 : List Nat := [2,4,8,16,32,64,128,85,136,1024,81,1092,88,1260,113,34,1092,81,1193,112,1261,0,184,82,208,232,81,1093,1093,81,1024,4294967296,253,4294967545,1261,136]

theorem envBound24123 : H12AffineFastState.Bounded env24123 := by
  intro p hp
  have h : env24123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24115_24123 : H12AffineEnvironment.transform 10 81 env24115 = env24123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env24115 == env24123) = true)

theorem identity24123 : scanCanonicalize (H12AffineFastState.compose env24123 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 80) := by decide +kernel

theorem selectedBound24123 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24124 : List Nat := [2,4,8,16,32,64,128,85,136,1024,81,1092,88,1260,113,34,1092,81,1193,112,1261,0,184,82,208,232,81,1093,1093,81,1024,80,253,169,1261,136]

theorem envBound24124 : H12AffineFastState.Bounded env24124 := by
  intro p hp
  have h : env24124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24123_24124 : H12AffineEnvironment.transform 31 80 env24123 = env24124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 80 env24123 == env24124) = true)

def env24125 : List Nat := [2,4,8,16,32,64,88,85,80,1024,81,1092,88,1076,113,34,1092,81,1137,112,1077,0,96,82,8,48,81,1093,1093,81,1024,80,37,113,1077,80]

theorem envBound24125 : H12AffineFastState.Bounded env24125 := by
  intro p hp
  have h : env24125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24124_24125 : H12AffineEnvironment.transform 6 88 env24124 = env24125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env24124 == env24125) = true)

theorem identity24125 : scanCanonicalize (H12AffineFastState.compose env24125 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 42) := by decide +kernel

theorem selectedBound24125 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24126 : List Nat := [2,4,8,16,32,42,50,63,58,1024,59,1070,50,1076,27,34,1070,59,1051,26,1077,0,10,56,8,48,59,1071,1071,59,1024,58,37,27,1077,58]

theorem envBound24126 : H12AffineFastState.Bounded env24126 := by
  intro p hp
  have h : env24126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24125_24126 : H12AffineEnvironment.transform 5 42 env24125 = env24126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 42 env24125 == env24126) = true)

theorem identity24126 : scanCanonicalize (H12AffineFastState.compose env24126 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound24126 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24127 : List Nat := [2,4,8,16,27,17,9,4,1,1024,0,1045,9,1039,27,25,1045,0,1051,26,1038,0,10,3,8,11,0,1044,1044,0,1024,1,30,27,1038,1]

theorem envBound24127 : H12AffineFastState.Bounded env24127 := by
  intro p hp
  have h : env24127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24126_24127 : H12AffineEnvironment.transform 4 27 env24126 = env24127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env24126 == env24127) = true)

def leafEnv24127 : List Nat := [2,4,8,16,27,17,9,4,1,1024,0,1045,9,1039,27,25,1045,0,1051,26,1038,0,10,3,1051,8,1,11,0,1044,1044,0,1024,1,30,27,30,24,1038,1,0,1039,1]

def active24127 : List Nat := [0,1,2,3,9]

def tree24127 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24127 : H12WitnessSearch.Good tree24127 := H12GlobalWitnessIndex.good

theorem leafIdentity24127 : H12AffineFastState.composeSystem env24127 rootObs = leafEnv24127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24127 rootObs == leafEnv24127) = true)

theorem terminalChecked24127 : H12PackedTerminal.terminalCheckFast leafEnv24127 active24127 tree24127 = true := by decide +kernel

def env24128 : List Nat := [2,4,8,16,32,64,89,85,81,1024,81,1092,88,1077,113,34,1092,81,1136,112,1076,0,97,82,9,49,81,1093,1093,81,1024,80,36,112,1076,81]

theorem envBound24128 : H12AffineFastState.Bounded env24128 := by
  intro p hp
  have h : env24128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24124_24128 : H12AffineEnvironment.transform 6 89 env24124 = env24128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env24124 == env24128) = true)

theorem identity24128 : scanCanonicalize (H12AffineFastState.compose env24128 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 127) := by decide +kernel

theorem selectedBound24128 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24129 : List Nat := [2,4,8,16,32,64,89,85,81,127,81,59,88,74,113,34,59,81,15,112,75,0,97,82,9,49,81,58,58,81,127,80,36,112,75,81]

theorem envBound24129 : H12AffineFastState.Bounded env24129 := by
  intro p hp
  have h : env24129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24128_24129 : H12AffineEnvironment.transform 9 127 env24128 = env24129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 127 env24128 == env24129) = true)

def leafEnv24129 : List Nat := [2,4,8,16,32,64,89,85,81,127,81,59,88,74,113,34,59,81,15,112,75,0,97,82,15,9,1,49,81,58,58,81,127,80,36,112,117,114,75,81,0,74,1]

def active24129 : List Nat := [0,1,2,3,4,5]

def tree24129 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24129 : H12WitnessSearch.Good tree24129 := H12GlobalWitnessIndex.good

theorem leafIdentity24129 : H12AffineFastState.composeSystem env24129 rootObs = leafEnv24129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24129 rootObs == leafEnv24129) = true)

theorem terminalChecked24129 : H12PackedTerminal.terminalCheckFast leafEnv24129 active24129 tree24129 = true := by decide +kernel

def env24130 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,16384,32768,65536,4096,262144,524288,32769,529409,566400,525329,103493,8328,67108864,831684,1296,1296,1073741824,67638277,4294967296,525569,4295569518,67113024,136]

theorem envBound24130 : H12AffineFastState.Bounded env24130 := by
  intro p hp
  have h : env24130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24081_24130 : H12AffineEnvironment.transform 20 529409 env24081 = env24130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 529409 env24081 == env24130) = true)

theorem identity24130 : scanCanonicalize (H12AffineFastState.compose env24130 (packedSelected [14] rootPS)) = affineNative (2^(25+1) ^^^ 17744) := by decide +kernel

theorem selectedBound24130 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env24131 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,16384,32768,65536,4096,262144,524288,32769,529409,566400,525329,103493,8328,17744,831684,1296,1296,1073741824,545109,4294967296,525569,4295569518,21776,136]

theorem envBound24131 : H12AffineFastState.Bounded env24131 := by
  intro p hp
  have h : env24131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24130_24131 : H12AffineEnvironment.transform 25 17744 env24130 = env24131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 17744 env24130 == env24131) = true)

theorem identity24131 : scanCanonicalize (H12AffineFastState.compose env24131 (packedSelected [0,27] rootPS)) = affineNative (2^(18+1) ^^^ 16657) := by decide +kernel

theorem selectedBound24131 : packedSelected [0,27] rootPS < 2^1333 := by decide +kernel

def env24132 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,16384,32768,65536,4096,262144,16657,32769,21776,58769,17664,103493,8328,17744,324053,1296,1296,1073741824,4164,4294967296,17424,4295061887,21776,136]

theorem envBound24132 : H12AffineFastState.Bounded env24132 := by
  intro p hp
  have h : env24132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24131_24132 : H12AffineEnvironment.transform 18 16657 env24131 = env24132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 16657 env24131 == env24132) = true)

theorem identity24132 : scanCanonicalize (H12AffineFastState.compose env24132 (packedSelected [1,12,13] rootPS)) = affineNative (2^(11+1) ^^^ 1092) := by decide +kernel

theorem selectedBound24132 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env24133 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,1092,8192,16384,32768,65536,1092,262144,16657,32769,16724,58769,17664,98305,8328,17744,320913,1296,1296,1073741824,1024,4294967296,17424,4295058747,16724,136]

theorem envBound24133 : H12AffineFastState.Bounded env24133 := by
  intro p hp
  have h : env24133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24132_24133 : H12AffineEnvironment.transform 11 1092 env24132 = env24133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1092 env24132 == env24133) = true)

def env24134 : List Nat := [2,4,8,16,32,64,128,84,136,1024,2048,1092,8192,16384,32768,65536,1092,262144,16453,32769,16384,58565,17492,98305,8328,17412,320709,1092,1092,1073741824,1024,4294967296,17424,4295058543,16384,136]

theorem envBound24134 : H12AffineFastState.Bounded env24134 := by
  intro p hp
  have h : env24134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24133_24134 : H12AffineEnvironment.transform 7 84 env24133 = env24134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env24133 == env24134) = true)

theorem identity24134 : scanCanonicalize (H12AffineFastState.compose env24134 (packedSelected [1,3,5] rootPS)) = affineNative (2^(14+1) ^^^ 25629) := by decide +kernel

theorem selectedBound24134 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env24135 : List Nat := [2,4,8,16,32,64,128,84,136,1024,2048,1092,8192,16384,25629,65536,1092,262144,16453,25628,16384,216,17492,91164,8328,17412,262360,1092,1092,1073741824,1024,4294967296,17424,4295058543,16384,136]

theorem envBound24135 : H12AffineFastState.Bounded env24135 := by
  intro p hp
  have h : env24135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24134_24135 : H12AffineEnvironment.transform 14 25629 env24134 = env24135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25629 env24134 == env24135) = true)

def env24136 : List Nat := [2,4,8,16,32,64,128,84,136,1024,2048,1092,8192,0,9245,65536,1092,262144,69,9244,0,216,1108,74780,8328,1028,262360,1092,1092,1073741824,1024,4294967296,1040,4295042159,0,136]

theorem envBound24136 : H12AffineFastState.Bounded env24136 := by
  intro p hp
  have h : env24136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24135_24136 : H12AffineEnvironment.transform 13 0 env24135 = env24136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 0 env24135 == env24136) = true)

theorem identity24136 : scanCanonicalize (H12AffineFastState.compose env24136 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound24136 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24137 : List Nat := [2,4,8,16,32,64,88,84,80,1024,2048,1092,8192,0,9245,65536,1092,262144,69,9244,0,0,1108,74780,8272,1028,262144,1092,1092,1073741824,1024,4294967296,1040,4295042159,0,80]

theorem envBound24137 : H12AffineFastState.Bounded env24137 := by
  intro p hp
  have h : env24137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24136_24137 : H12AffineEnvironment.transform 6 88 env24136 = env24137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env24136 == env24137) = true)

theorem identity24137 : scanCanonicalize (H12AffineFastState.compose env24137 (packedSelected [6,7] rootPS)) = affineNative (2^(17+1) ^^^ 8200) := by decide +kernel

theorem selectedBound24137 : packedSelected [6,7] rootPS < 2^1333 := by decide +kernel

def env24138 : List Nat := [2,4,8,16,32,64,88,84,80,1024,2048,1092,8192,0,9245,65536,1092,8200,69,9244,0,0,1108,74780,8272,1028,8200,1092,1092,1073741824,1024,4294967296,1040,4295042159,0,80]

theorem envBound24138 : H12AffineFastState.Bounded env24138 := by
  intro p hp
  have h : env24138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24137_24138 : H12AffineEnvironment.transform 17 8200 env24137 = env24138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8200 env24137 == env24138) = true)

def env24139 : List Nat := [2,4,8,16,32,64,88,84,80,1024,2048,1092,1052,0,1,65536,1092,1044,69,0,0,0,1108,65536,1100,1028,1044,1092,1092,1073741824,1024,4294967296,1040,4295032947,0,80]

theorem envBound24139 : H12AffineFastState.Bounded env24139 := by
  intro p hp
  have h : env24139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24138_24139 : H12AffineEnvironment.transform 12 1052 env24138 = env24139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env24138 == env24139) = true)

theorem identity24139 : scanCanonicalize (H12AffineFastState.compose env24139 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 66614) := by decide +kernel

theorem selectedBound24139 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env24140 : List Nat := [2,4,8,16,32,64,88,84,80,1024,2048,1092,1052,0,1,65536,1092,1044,69,0,0,0,1108,65536,1100,1028,1044,1092,1092,1073741824,1024,66614,1040,1093,0,80]

theorem envBound24140 : H12AffineFastState.Bounded env24140 := by
  intro p hp
  have h : env24140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24139_24140 : H12AffineEnvironment.transform 31 66614 env24139 = env24140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 66614 env24139 == env24140) = true)

def env24141 : List Nat := [2,4,8,16,32,64,88,84,80,1024,2048,1092,1052,0,1,65536,1092,1044,69,0,0,0,1108,65536,1100,1028,1044,1092,1092,0,1024,66614,1040,1093,0,80]

theorem envBound24141 : H12AffineFastState.Bounded env24141 := by
  intro p hp
  have h : env24141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24140_24141 : H12AffineEnvironment.transform 29 0 env24140 = env24141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 0 env24140 == env24141) = true)

theorem identity24141 : scanCanonicalize (H12AffineFastState.compose env24141 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound24141 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24142 : List Nat := [2,4,8,16,32,64,88,84,80,1024,32,1092,1052,0,1,65536,1092,1044,69,0,0,0,1108,65536,1100,1028,1044,1092,1092,0,1024,66614,1040,1093,0,80]

theorem envBound24142 : H12AffineFastState.Bounded env24142 := by
  intro p hp
  have h : env24142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24141_24142 : H12AffineEnvironment.transform 10 32 env24141 = env24142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env24141 == env24142) = true)

theorem identity24142 : scanCanonicalize (H12AffineFastState.compose env24142 (packedSelected [1,4] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound24142 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env24143 : List Nat := [2,4,8,16,26,64,88,84,80,1024,26,1092,1052,0,1,65536,1092,1044,69,0,0,0,1108,65536,1100,1028,1044,1092,1092,0,1024,66572,1040,1093,0,80]

theorem envBound24143 : H12AffineFastState.Bounded env24143 := by
  intro p hp
  have h : env24143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24142_24143 : H12AffineEnvironment.transform 4 26 env24142 = env24143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env24142 == env24143) = true)

theorem identity24143 : scanCanonicalize (H12AffineFastState.compose env24143 (packedSelected [11] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound24143 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env24144 : List Nat := [2,4,8,10,0,64,66,78,74,1024,0,1092,1030,0,1,65536,1092,1038,69,0,0,0,1102,65536,1100,1028,1038,1092,1092,0,1024,66572,1034,1093,0,74]

theorem envBound24144 : H12AffineFastState.Bounded env24144 := by
  intro p hp
  have h : env24144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24143_24144 : H12AffineEnvironment.transform 3 10 env24143 = env24144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env24143 == env24144) = true)

def env24145 : List Nat := [2,4,8,10,0,64,66,78,74,1024,0,1092,1030,0,1,1036,1092,1038,69,0,0,0,1102,1036,1100,1028,1038,1092,1092,0,1024,0,1034,1093,0,74]

theorem envBound24145 : H12AffineFastState.Bounded env24145 := by
  intro p hp
  have h : env24145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24144_24145 : H12AffineEnvironment.transform 15 1036 env24144 = env24145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1036 env24144 == env24145) = true)

def leafEnv24145 : List Nat := [2,4,8,10,0,64,66,78,74,1024,0,1092,1030,0,1,1036,1092,1038,69,0,0,0,1102,1036,69,1100,1,1028,1038,1092,1092,0,1024,0,1034,1093,1088,2,0,74,0,0,1]

def active24145 : List Nat := [0,1,2,5,9]

def tree24145 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24145 : H12WitnessSearch.Good tree24145 := H12GlobalWitnessIndex.good

theorem leafIdentity24145 : H12AffineFastState.composeSystem env24145 rootObs = leafEnv24145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24145 rootObs == leafEnv24145) = true)

theorem terminalChecked24145 : H12PackedTerminal.terminalCheckFast leafEnv24145 active24145 tree24145 = true := by decide +kernel

def env24146 : List Nat := [2,4,8,10,0,64,66,78,74,1024,0,1092,1030,0,1,1037,1092,1038,69,0,0,0,1102,1037,1100,1028,1038,1092,1092,0,1024,1,1034,1093,0,74]

theorem envBound24146 : H12AffineFastState.Bounded env24146 := by
  intro p hp
  have h : env24146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24144_24146 : H12AffineEnvironment.transform 15 1037 env24144 = env24146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1037 env24144 == env24146) = true)

theorem identity24146 : scanCanonicalize (H12AffineFastState.compose env24146 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound24146 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24147 : List Nat := [2,4,8,10,0,64,66,78,74,15,0,75,9,0,1,2,75,1,69,0,0,0,65,2,67,11,1,75,75,0,15,1,5,74,0,74]

theorem envBound24147 : H12AffineFastState.Bounded env24147 := by
  intro p hp
  have h : env24147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24146_24147 : H12AffineEnvironment.transform 9 15 env24146 = env24147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env24146 == env24147) = true)

def leafEnv24147 : List Nat := [2,4,8,10,0,64,66,78,74,15,0,75,9,0,1,2,75,1,69,0,0,0,65,2,69,67,1,11,1,75,75,0,15,1,5,74,79,2,0,74,0,0,1]

def active24147 : List Nat := [0,1,2,5]

def tree24147 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24147 : H12WitnessSearch.Good tree24147 := H12GlobalWitnessIndex.good

theorem leafIdentity24147 : H12AffineFastState.composeSystem env24147 rootObs = leafEnv24147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24147 rootObs == leafEnv24147) = true)

theorem terminalChecked24147 : H12PackedTerminal.terminalCheckFast leafEnv24147 active24147 tree24147 = true := by decide +kernel

def env24148 : List Nat := [2,4,8,16,32,64,88,84,80,1024,2048,1092,1052,0,1,65536,1092,1044,69,0,0,0,1108,65536,1100,1028,1044,1092,1092,1,1024,66614,1040,1093,0,80]

theorem envBound24148 : H12AffineFastState.Bounded env24148 := by
  intro p hp
  have h : env24148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24140_24148 : H12AffineEnvironment.transform 29 1 env24140 = env24148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 1 env24140 == env24148) = true)

theorem identity24148 : scanCanonicalize (H12AffineFastState.compose env24148 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound24148 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24149 : List Nat := [2,4,8,16,1,64,88,84,80,1024,2048,1092,1052,0,1,65536,1092,1044,69,0,0,0,1108,65536,1100,1028,1044,1092,1092,1,1024,66583,1040,1093,0,80]

theorem envBound24149 : H12AffineFastState.Bounded env24149 := by
  intro p hp
  have h : env24149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24148_24149 : H12AffineEnvironment.transform 4 1 env24148 = env24149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24148 == env24149) = true)

theorem identity24149 : scanCanonicalize (H12AffineFastState.compose env24149 (packedSelected [1,2] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound24149 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env24150 : List Nat := [2,4,8,16,1,64,88,84,80,15,2048,75,19,0,1,65536,75,27,69,0,0,0,91,65536,67,11,27,75,75,1,15,65560,31,74,0,80]

theorem envBound24150 : H12AffineFastState.Bounded env24150 := by
  intro p hp
  have h : env24150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24149_24150 : H12AffineEnvironment.transform 9 15 env24149 = env24150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env24149 == env24150) = true)

theorem identity24150 : scanCanonicalize (H12AffineFastState.compose env24150 (packedSelected [18] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound24150 : packedSelected [18] rootPS < 2^1333 := by decide +kernel

def env24151 : List Nat := [2,4,8,16,1,64,88,84,80,15,1,75,19,0,1,65536,75,27,69,0,0,0,91,65536,67,11,27,75,75,1,15,65560,31,74,0,80]

theorem envBound24151 : H12AffineFastState.Bounded env24151 := by
  intro p hp
  have h : env24151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24150_24151 : H12AffineEnvironment.transform 10 1 env24150 = env24151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env24150 == env24151) = true)

def env24152 : List Nat := [2,4,8,16,1,64,88,84,80,15,1,75,19,0,1,24,75,27,69,0,0,0,91,24,67,11,27,75,75,1,15,0,31,74,0,80]

theorem envBound24152 : H12AffineFastState.Bounded env24152 := by
  intro p hp
  have h : env24152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24151_24152 : H12AffineEnvironment.transform 15 24 env24151 = env24152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24 env24151 == env24152) = true)

theorem identity24152 : scanCanonicalize (H12AffineFastState.compose env24152 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound24152 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24153 : List Nat := [2,4,8,16,1,16,8,4,0,15,1,27,19,0,1,24,27,27,21,0,0,0,11,24,19,11,27,27,27,1,15,0,31,26,0,0]

theorem envBound24153 : H12AffineFastState.Bounded env24153 := by
  intro p hp
  have h : env24153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24152_24153 : H12AffineEnvironment.transform 5 16 env24152 = env24153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24152 == env24153) = true)

def leafEnv24153 : List Nat := [2,4,8,16,1,16,8,4,0,15,1,27,19,0,1,24,27,27,21,0,0,0,11,24,21,19,1,11,27,27,27,1,15,0,31,26,31,2,0,0,0,0,1]

def active24153 : List Nat := [0,1,2,3]

def tree24153 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24153 : H12WitnessSearch.Good tree24153 := H12GlobalWitnessIndex.good

theorem leafIdentity24153 : H12AffineFastState.composeSystem env24153 rootObs = leafEnv24153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24153 rootObs == leafEnv24153) = true)

theorem terminalChecked24153 : H12PackedTerminal.terminalCheckFast leafEnv24153 active24153 tree24153 = true := by decide +kernel

def env24154 : List Nat := [2,4,8,16,1,64,88,84,80,15,1,75,19,0,1,25,75,27,69,0,0,0,91,25,67,11,27,75,75,1,15,1,31,74,0,80]

theorem envBound24154 : H12AffineFastState.Bounded env24154 := by
  intro p hp
  have h : env24154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24151_24154 : H12AffineEnvironment.transform 15 25 env24151 = env24154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25 env24151 == env24154) = true)

theorem identity24154 : scanCanonicalize (H12AffineFastState.compose env24154 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound24154 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24155 : List Nat := [2,4,8,16,1,10,18,30,26,15,1,1,19,0,1,25,1,27,15,0,0,0,17,25,9,11,27,1,1,1,15,1,31,0,0,26]

theorem envBound24155 : H12AffineFastState.Bounded env24155 := by
  intro p hp
  have h : env24155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24154_24155 : H12AffineEnvironment.transform 5 10 env24154 = env24155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env24154 == env24155) = true)

def leafEnv24155 : List Nat := [2,4,8,16,1,10,18,30,26,15,1,1,19,0,1,25,1,27,15,0,0,0,17,25,15,9,1,11,27,1,1,1,15,1,31,0,5,2,0,26,0,0,1]

def active24155 : List Nat := [0,1,2,3]

def tree24155 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24155 : H12WitnessSearch.Good tree24155 := H12GlobalWitnessIndex.good

theorem leafIdentity24155 : H12AffineFastState.composeSystem env24155 rootObs = leafEnv24155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24155 rootObs == leafEnv24155) = true)

theorem terminalChecked24155 : H12PackedTerminal.terminalCheckFast leafEnv24155 active24155 tree24155 = true := by decide +kernel

def env24156 : List Nat := [2,4,8,16,32,64,88,84,80,1024,2048,1092,1053,0,0,65536,1092,1045,69,1,0,0,1108,65537,1101,1028,1045,1092,1092,1073741824,1024,4294967296,1040,4295032946,0,80]

theorem envBound24156 : H12AffineFastState.Bounded env24156 := by
  intro p hp
  have h : env24156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24138_24156 : H12AffineEnvironment.transform 12 1053 env24138 = env24156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env24138 == env24156) = true)

theorem identity24156 : scanCanonicalize (H12AffineFastState.compose env24156 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 1073744997) := by decide +kernel

theorem selectedBound24156 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env24157 : List Nat := [2,4,8,16,32,64,88,84,80,1024,2048,1092,1053,0,0,65536,1092,1045,69,1,0,0,1108,65537,1101,1028,1045,1092,1092,1073741824,1024,1073744997,1040,1073810455,0,80]

theorem envBound24157 : H12AffineFastState.Bounded env24157 := by
  intro p hp
  have h : env24157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24156_24157 : H12AffineEnvironment.transform 31 1073744997 env24156 = env24157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1073744997 env24156 == env24157) = true)

def env24158 : List Nat := [2,4,8,16,32,64,88,84,80,1024,2048,1092,1053,0,0,65536,1092,1045,69,1,0,0,1108,65537,1101,1028,1045,1092,1092,0,1024,3173,1040,68631,0,80]

theorem envBound24158 : H12AffineFastState.Bounded env24158 := by
  intro p hp
  have h : env24158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24157_24158 : H12AffineEnvironment.transform 29 0 env24157 = env24158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 0 env24157 == env24158) = true)

theorem identity24158 : scanCanonicalize (H12AffineFastState.compose env24158 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound24158 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24159 : List Nat := [2,4,8,16,32,64,88,84,80,1024,33,1092,1053,0,0,65536,1092,1045,69,1,0,0,1108,65537,1101,1028,1045,1092,1092,0,1024,1092,1040,66614,0,80]

theorem envBound24159 : H12AffineFastState.Bounded env24159 := by
  intro p hp
  have h : env24159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24158_24159 : H12AffineEnvironment.transform 10 33 env24158 = env24159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env24158 == env24159) = true)

theorem identity24159 : scanCanonicalize (H12AffineFastState.compose env24159 (packedSelected [11] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound24159 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env24160 : List Nat := [2,4,8,16,1,64,88,84,80,1024,0,1092,1053,0,0,65536,1092,1045,69,1,0,0,1108,65537,1101,1028,1045,1092,1092,0,1024,1092,1040,66583,0,80]

theorem envBound24160 : H12AffineFastState.Bounded env24160 := by
  intro p hp
  have h : env24160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24159_24160 : H12AffineEnvironment.transform 4 1 env24159 = env24160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24159 == env24160) = true)

def env24161 : List Nat := [2,4,8,16,1,16,8,4,0,1024,0,1044,1053,0,0,65536,1044,1045,21,1,0,0,1028,65537,1053,1028,1045,1044,1044,0,1024,1044,1040,66583,0,0]

theorem envBound24161 : H12AffineFastState.Bounded env24161 := by
  intro p hp
  have h : env24161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24160_24161 : H12AffineEnvironment.transform 5 16 env24160 = env24161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24160 == env24161) = true)

theorem identity24161 : scanCanonicalize (H12AffineFastState.compose env24161 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 1036) := by decide +kernel

theorem selectedBound24161 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24162 : List Nat := [2,4,8,16,1,16,8,4,0,1024,0,1044,1053,0,0,1036,1044,1045,21,1,0,0,1028,1037,1053,1028,1045,1044,1044,0,1024,1044,1040,27,0,0]

theorem envBound24162 : H12AffineFastState.Bounded env24162 := by
  intro p hp
  have h : env24162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24161_24162 : H12AffineEnvironment.transform 15 1036 env24161 = env24162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1036 env24161 == env24162) = true)

def env24163 : List Nat := [2,4,8,16,1,16,8,4,0,20,0,0,9,0,0,24,0,1,21,1,0,0,16,25,9,16,1,0,0,0,20,0,4,27,0,0]

theorem envBound24163 : H12AffineFastState.Bounded env24163 := by
  intro p hp
  have h : env24163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24162_24163 : H12AffineEnvironment.transform 9 20 env24162 = env24163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env24162 == env24163) = true)

def leafEnv24163 : List Nat := [2,4,8,16,1,16,8,4,0,20,0,0,9,0,0,24,0,1,21,1,0,0,16,25,21,9,1,16,1,0,0,0,20,0,4,27,4,3,0,0,0,0,1]

def active24163 : List Nat := [0,1,2,3]

def tree24163 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24163 : H12WitnessSearch.Good tree24163 := H12GlobalWitnessIndex.good

theorem leafIdentity24163 : H12AffineFastState.composeSystem env24163 rootObs = leafEnv24163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24163 rootObs == leafEnv24163) = true)

theorem terminalChecked24163 : H12PackedTerminal.terminalCheckFast leafEnv24163 active24163 tree24163 = true := by decide +kernel

def env24164 : List Nat := [2,4,8,16,1,16,8,4,0,21,0,1,8,0,0,25,1,0,21,1,0,0,17,24,8,17,0,1,1,0,21,1,5,27,0,0]

theorem envBound24164 : H12AffineFastState.Bounded env24164 := by
  intro p hp
  have h : env24164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24162_24164 : H12AffineEnvironment.transform 9 21 env24162 = env24164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env24162 == env24164) = true)

theorem identity24164 : scanCanonicalize (H12AffineFastState.compose env24164 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound24164 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24165 : List Nat := [2,4,8,11,1,11,8,4,0,14,0,1,8,0,0,2,1,0,14,1,0,0,10,3,8,10,0,1,1,0,14,1,5,0,0,0]

theorem envBound24165 : H12AffineFastState.Bounded env24165 := by
  intro p hp
  have h : env24165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24164_24165 : H12AffineEnvironment.transform 3 11 env24164 = env24165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env24164 == env24165) = true)

def leafEnv24165 : List Nat := [2,4,8,11,1,11,8,4,0,14,0,1,8,0,0,2,1,0,14,1,0,0,10,3,14,8,1,10,0,1,1,0,14,1,5,0,5,3,0,0,0,0,1]

def active24165 : List Nat := [0,1,2]

def tree24165 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24165 : H12WitnessSearch.Good tree24165 := H12GlobalWitnessIndex.good

theorem leafIdentity24165 : H12AffineFastState.composeSystem env24165 rootObs = leafEnv24165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24165 rootObs == leafEnv24165) = true)

theorem terminalChecked24165 : H12PackedTerminal.terminalCheckFast leafEnv24165 active24165 tree24165 = true := by decide +kernel

def env24166 : List Nat := [2,4,8,16,1,17,9,5,1,1024,0,1045,1053,0,0,65536,1045,1045,20,1,0,0,1029,65537,1052,1028,1045,1045,1045,0,1024,1045,1040,66583,0,1]

theorem envBound24166 : H12AffineFastState.Bounded env24166 := by
  intro p hp
  have h : env24166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24160_24166 : H12AffineEnvironment.transform 5 17 env24160 = env24166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env24160 == env24166) = true)

theorem identity24166 : scanCanonicalize (H12AffineFastState.compose env24166 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 25) := by decide +kernel

theorem selectedBound24166 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24167 : List Nat := [2,4,8,16,1,17,9,5,1,1024,0,1045,1053,0,0,25,1045,1045,20,1,0,0,1029,24,1052,1028,1045,1045,1045,0,1024,1045,1040,1038,0,1]

theorem envBound24167 : H12AffineFastState.Bounded env24167 := by
  intro p hp
  have h : env24167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24166_24167 : H12AffineEnvironment.transform 15 25 env24166 = env24167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25 env24166 == env24167) = true)

def env24168 : List Nat := [2,4,8,16,1,17,9,5,1,20,0,1,9,0,0,25,1,1,20,1,0,0,17,24,8,16,1,1,1,0,20,1,4,26,0,1]

theorem envBound24168 : H12AffineFastState.Bounded env24168 := by
  intro p hp
  have h : env24168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24167_24168 : H12AffineEnvironment.transform 9 20 env24167 = env24168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env24167 == env24168) = true)

def leafEnv24168 : List Nat := [2,4,8,16,1,17,9,5,1,20,0,1,9,0,0,25,1,1,20,1,0,0,17,24,20,8,1,16,1,1,1,0,20,1,4,26,5,3,0,1,0,0,1]

def active24168 : List Nat := [0,1,2,3]

def tree24168 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24168 : H12WitnessSearch.Good tree24168 := H12GlobalWitnessIndex.good

theorem leafIdentity24168 : H12AffineFastState.composeSystem env24168 rootObs = leafEnv24168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24168 rootObs == leafEnv24168) = true)

theorem terminalChecked24168 : H12PackedTerminal.terminalCheckFast leafEnv24168 active24168 tree24168 = true := by decide +kernel

def env24169 : List Nat := [2,4,8,16,1,17,9,5,1,21,0,0,8,0,0,25,0,0,20,1,0,0,16,24,9,17,0,0,0,0,21,0,5,27,0,1]

theorem envBound24169 : H12AffineFastState.Bounded env24169 := by
  intro p hp
  have h : env24169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24167_24169 : H12AffineEnvironment.transform 9 21 env24167 = env24169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env24167 == env24169) = true)

theorem identity24169 : scanCanonicalize (H12AffineFastState.compose env24169 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound24169 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24170 : List Nat := [2,4,8,11,1,10,9,5,1,14,0,0,8,0,0,2,0,0,15,1,0,0,11,3,9,10,0,0,0,0,14,0,5,0,0,1]

theorem envBound24170 : H12AffineFastState.Bounded env24170 := by
  intro p hp
  have h : env24170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24169_24170 : H12AffineEnvironment.transform 3 11 env24169 = env24170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env24169 == env24170) = true)

def leafEnv24170 : List Nat := [2,4,8,11,1,10,9,5,1,14,0,0,8,0,0,2,0,0,15,1,0,0,11,3,15,9,1,10,0,0,0,0,14,0,5,0,4,3,0,1,0,0,1]

def active24170 : List Nat := [0,1,2]

def tree24170 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24170 : H12WitnessSearch.Good tree24170 := H12GlobalWitnessIndex.good

theorem leafIdentity24170 : H12AffineFastState.composeSystem env24170 rootObs = leafEnv24170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24170 rootObs == leafEnv24170) = true)

theorem terminalChecked24170 : H12PackedTerminal.terminalCheckFast leafEnv24170 active24170 tree24170 = true := by decide +kernel

def env24171 : List Nat := [2,4,8,16,32,64,88,84,80,1024,2048,1092,1053,0,0,65536,1092,1045,69,1,0,0,1108,65537,1101,1028,1045,1092,1092,1,1024,3172,1040,68630,0,80]

theorem envBound24171 : H12AffineFastState.Bounded env24171 := by
  intro p hp
  have h : env24171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24157_24171 : H12AffineEnvironment.transform 29 1 env24157 = env24171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 1 env24157 == env24171) = true)

theorem identity24171 : scanCanonicalize (H12AffineFastState.compose env24171 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound24171 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24172 : List Nat := [2,4,8,16,0,64,88,84,80,1024,2048,1092,1053,0,0,65536,1092,1045,69,1,0,0,1108,65537,1101,1028,1045,1092,1092,1,1024,3140,1040,68630,0,80]

theorem envBound24172 : H12AffineFastState.Bounded env24172 := by
  intro p hp
  have h : env24172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24171_24172 : H12AffineEnvironment.transform 4 0 env24171 = env24172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env24171 == env24172) = true)

theorem identity24172 : scanCanonicalize (H12AffineFastState.compose env24172 (packedSelected [18] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound24172 : packedSelected [18] rootPS < 2^1333 := by decide +kernel

def env24173 : List Nat := [2,4,8,16,0,64,88,84,80,1024,1,1092,1053,0,0,65536,1092,1045,69,1,0,0,1108,65537,1101,1028,1045,1092,1092,1,1024,1093,1040,66583,0,80]

theorem envBound24173 : H12AffineFastState.Bounded env24173 := by
  intro p hp
  have h : env24173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24172_24173 : H12AffineEnvironment.transform 10 1 env24172 = env24173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env24172 == env24173) = true)

def env24174 : List Nat := [2,4,8,16,0,16,8,4,0,1024,1,1044,1053,0,0,65536,1044,1045,21,1,0,0,1028,65537,1053,1028,1045,1044,1044,1,1024,1045,1040,66583,0,0]

theorem envBound24174 : H12AffineFastState.Bounded env24174 := by
  intro p hp
  have h : env24174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24173_24174 : H12AffineEnvironment.transform 5 16 env24173 = env24174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24173 == env24174) = true)

theorem identity24174 : scanCanonicalize (H12AffineFastState.compose env24174 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 1036) := by decide +kernel

theorem selectedBound24174 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24175 : List Nat := [2,4,8,16,0,16,8,4,0,1024,1,1044,1053,0,0,1036,1044,1045,21,1,0,0,1028,1037,1053,1028,1045,1044,1044,1,1024,1045,1040,27,0,0]

theorem envBound24175 : H12AffineFastState.Bounded env24175 := by
  intro p hp
  have h : env24175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24174_24175 : H12AffineEnvironment.transform 15 1036 env24174 = env24175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1036 env24174 == env24175) = true)

def env24176 : List Nat := [2,4,8,16,0,16,8,4,0,20,1,0,9,0,0,24,0,1,21,1,0,0,16,25,9,16,1,0,0,1,20,1,4,27,0,0]

theorem envBound24176 : H12AffineFastState.Bounded env24176 := by
  intro p hp
  have h : env24176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24175_24176 : H12AffineEnvironment.transform 9 20 env24175 = env24176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env24175 == env24176) = true)

theorem identity24176 : scanCanonicalize (H12AffineFastState.compose env24176 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound24176 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24177 : List Nat := [2,4,8,11,0,11,8,4,0,15,1,0,9,0,0,3,0,1,14,1,0,0,11,2,9,11,1,0,0,1,15,1,4,0,0,0]

theorem envBound24177 : H12AffineFastState.Bounded env24177 := by
  intro p hp
  have h : env24177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24176_24177 : H12AffineEnvironment.transform 3 11 env24176 = env24177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env24176 == env24177) = true)

def leafEnv24177 : List Nat := [2,4,8,11,0,11,8,4,0,15,1,0,9,0,0,3,0,1,14,1,0,0,11,2,14,9,1,11,1,0,0,1,15,1,4,0,4,3,0,0,0,0,1]

def active24177 : List Nat := [0,1,2]

def tree24177 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24177 : H12WitnessSearch.Good tree24177 := H12GlobalWitnessIndex.good

theorem leafIdentity24177 : H12AffineFastState.composeSystem env24177 rootObs = leafEnv24177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24177 rootObs == leafEnv24177) = true)

theorem terminalChecked24177 : H12PackedTerminal.terminalCheckFast leafEnv24177 active24177 tree24177 = true := by decide +kernel

def env24178 : List Nat := [2,4,8,16,0,16,8,4,0,21,1,1,8,0,0,25,1,0,21,1,0,0,17,24,8,17,0,1,1,1,21,0,5,27,0,0]

theorem envBound24178 : H12AffineFastState.Bounded env24178 := by
  intro p hp
  have h : env24178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24175_24178 : H12AffineEnvironment.transform 9 21 env24175 = env24178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env24175 == env24178) = true)

def leafEnv24178 : List Nat := [2,4,8,16,0,16,8,4,0,21,1,1,8,0,0,25,1,0,21,1,0,0,17,24,21,8,1,17,0,1,1,1,21,0,5,27,5,3,0,0,0,0,1]

def active24178 : List Nat := [0,1,2,3]

def tree24178 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24178 : H12WitnessSearch.Good tree24178 := H12GlobalWitnessIndex.good

theorem leafIdentity24178 : H12AffineFastState.composeSystem env24178 rootObs = leafEnv24178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24178 rootObs == leafEnv24178) = true)

theorem terminalChecked24178 : H12PackedTerminal.terminalCheckFast leafEnv24178 active24178 tree24178 = true := by decide +kernel

def env24179 : List Nat := [2,4,8,16,0,17,9,5,1,1024,1,1045,1053,0,0,65536,1045,1045,20,1,0,0,1029,65537,1052,1028,1045,1045,1045,1,1024,1044,1040,66583,0,1]

theorem envBound24179 : H12AffineFastState.Bounded env24179 := by
  intro p hp
  have h : env24179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24173_24179 : H12AffineEnvironment.transform 5 17 env24173 = env24179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env24173 == env24179) = true)

theorem identity24179 : scanCanonicalize (H12AffineFastState.compose env24179 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 24) := by decide +kernel

theorem selectedBound24179 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24180 : List Nat := [2,4,8,16,0,17,9,5,1,1024,1,1045,1053,0,0,24,1045,1045,20,1,0,0,1029,25,1052,1028,1045,1045,1045,1,1024,1044,1040,1039,0,1]

theorem envBound24180 : H12AffineFastState.Bounded env24180 := by
  intro p hp
  have h : env24180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24179_24180 : H12AffineEnvironment.transform 15 24 env24179 = env24180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24 env24179 == env24180) = true)

def env24181 : List Nat := [2,4,8,16,0,17,9,5,1,20,1,1,9,0,0,24,1,1,20,1,0,0,17,25,8,16,1,1,1,1,20,0,4,27,0,1]

theorem envBound24181 : H12AffineFastState.Bounded env24181 := by
  intro p hp
  have h : env24181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24180_24181 : H12AffineEnvironment.transform 9 20 env24180 = env24181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env24180 == env24181) = true)

theorem identity24181 : scanCanonicalize (H12AffineFastState.compose env24181 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound24181 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24182 : List Nat := [2,4,8,11,0,10,9,5,1,15,1,1,9,0,0,3,1,1,15,1,0,0,10,2,8,11,1,1,1,1,15,0,4,0,0,1]

theorem envBound24182 : H12AffineFastState.Bounded env24182 := by
  intro p hp
  have h : env24182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24181_24182 : H12AffineEnvironment.transform 3 11 env24181 = env24182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env24181 == env24182) = true)

def leafEnv24182 : List Nat := [2,4,8,11,0,10,9,5,1,15,1,1,9,0,0,3,1,1,15,1,0,0,10,2,15,8,1,11,1,1,1,1,15,0,4,0,5,3,0,1,0,0,1]

def active24182 : List Nat := [0,1,2]

def tree24182 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24182 : H12WitnessSearch.Good tree24182 := H12GlobalWitnessIndex.good

theorem leafIdentity24182 : H12AffineFastState.composeSystem env24182 rootObs = leafEnv24182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24182 rootObs == leafEnv24182) = true)

theorem terminalChecked24182 : H12PackedTerminal.terminalCheckFast leafEnv24182 active24182 tree24182 = true := by decide +kernel

def env24183 : List Nat := [2,4,8,16,0,17,9,5,1,21,1,0,8,0,0,24,0,0,20,1,0,0,16,25,9,17,0,0,0,1,21,1,5,26,0,1]

theorem envBound24183 : H12AffineFastState.Bounded env24183 := by
  intro p hp
  have h : env24183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24180_24183 : H12AffineEnvironment.transform 9 21 env24180 = env24183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env24180 == env24183) = true)

def leafEnv24183 : List Nat := [2,4,8,16,0,17,9,5,1,21,1,0,8,0,0,24,0,0,20,1,0,0,16,25,20,9,1,17,0,0,0,1,21,1,5,26,4,3,0,1,0,0,1]

def active24183 : List Nat := [0,1,2,3]

def tree24183 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24183 : H12WitnessSearch.Good tree24183 := H12GlobalWitnessIndex.good

theorem leafIdentity24183 : H12AffineFastState.composeSystem env24183 rootObs = leafEnv24183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24183 rootObs == leafEnv24183) = true)

theorem terminalChecked24183 : H12PackedTerminal.terminalCheckFast leafEnv24183 active24183 tree24183 = true := by decide +kernel

def env24184 : List Nat := [2,4,8,16,32,64,128,84,136,1024,2048,1092,8192,1,9244,65536,1092,262144,68,9245,1,216,1109,74781,8328,1029,262360,1092,1092,1073741824,1024,4294967296,1041,4295042158,1,136]

theorem envBound24184 : H12AffineFastState.Bounded env24184 := by
  intro p hp
  have h : env24184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24135_24184 : H12AffineEnvironment.transform 13 1 env24135 = env24184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1 env24135 == env24184) = true)

theorem identity24184 : scanCanonicalize (H12AffineFastState.compose env24184 (packedSelected [1,3] rootPS)) = affineNative (2^(29+1) ^^^ 2048) := by decide +kernel

theorem selectedBound24184 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24185 : List Nat := [2,4,8,16,32,64,128,84,136,1024,2048,1092,8192,1,9244,65536,1092,262144,68,9245,1,216,1109,74781,8328,1029,262360,1092,1092,2048,1024,4294967296,1041,4295042158,1,136]

theorem envBound24185 : H12AffineFastState.Bounded env24185 := by
  intro p hp
  have h : env24185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24184_24185 : H12AffineEnvironment.transform 29 2048 env24184 = env24185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 2048 env24184 == env24185) = true)

theorem identity24185 : scanCanonicalize (H12AffineFastState.compose env24185 (packedSelected [12] rootPS)) = affineNative (2^(12+1) ^^^ 3133) := by decide +kernel

theorem selectedBound24185 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env24186 : List Nat := [2,4,8,16,32,64,128,84,136,1024,2048,1092,3133,1,2081,65536,1092,262144,68,2080,1,216,1109,67616,3253,1029,262360,1092,1092,2048,1024,4294967296,1041,4295034963,1,136]

theorem envBound24186 : H12AffineFastState.Bounded env24186 := by
  intro p hp
  have h : env24186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24185_24186 : H12AffineEnvironment.transform 12 3133 env24185 = env24186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3133 env24185 == env24186) = true)

def env24187 : List Nat := [2,4,8,16,32,64,128,84,136,1024,32,1092,1053,1,1,65536,1092,262144,68,0,1,216,1109,65536,1173,1029,262360,1092,1092,32,1024,4294967296,1041,4295032947,1,136]

theorem envBound24187 : H12AffineFastState.Bounded env24187 := by
  intro p hp
  have h : env24187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24186_24187 : H12AffineEnvironment.transform 10 32 env24186 = env24187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env24186 == env24187) = true)

theorem identity24187 : scanCanonicalize (H12AffineFastState.compose env24187 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 66615) := by decide +kernel

theorem selectedBound24187 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env24188 : List Nat := [2,4,8,16,32,64,128,84,136,1024,32,1092,1053,1,1,65536,1092,262144,68,0,1,216,1109,65536,1173,1029,262360,1092,1092,32,1024,66615,1041,1092,1,136]

theorem envBound24188 : H12AffineFastState.Bounded env24188 := by
  intro p hp
  have h : env24188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24187_24188 : H12AffineEnvironment.transform 31 66615 env24187 = env24188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 66615 env24187 == env24188) = true)

def env24189 : List Nat := [2,4,8,16,32,64,88,84,80,1024,32,1092,1053,1,1,65536,1092,262144,68,0,1,0,1109,65536,1101,1029,262144,1092,1092,32,1024,66615,1041,1092,1,80]

theorem envBound24189 : H12AffineFastState.Bounded env24189 := by
  intro p hp
  have h : env24189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24188_24189 : H12AffineEnvironment.transform 6 88 env24188 = env24189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env24188 == env24189) = true)

theorem identity24189 : scanCanonicalize (H12AffineFastState.compose env24189 (packedSelected [7] rootPS)) = affineNative (2^(17+1) ^^^ 1045) := by decide +kernel

theorem selectedBound24189 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env24190 : List Nat := [2,4,8,16,32,64,88,84,80,1024,32,1092,1053,1,1,65536,1092,1045,68,0,1,0,1109,65536,1101,1029,1045,1092,1092,32,1024,66615,1041,1092,1,80]

theorem envBound24190 : H12AffineFastState.Bounded env24190 := by
  intro p hp
  have h : env24190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24189_24190 : H12AffineEnvironment.transform 17 1045 env24189 = env24190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1045 env24189 == env24190) = true)

def env24191 : List Nat := [2,4,8,16,0,64,88,84,80,1024,0,1092,1053,1,1,65536,1092,1045,68,0,1,0,1109,65536,1101,1029,1045,1092,1092,0,1024,66583,1041,1092,1,80]

theorem envBound24191 : H12AffineFastState.Bounded env24191 := by
  intro p hp
  have h : env24191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24190_24191 : H12AffineEnvironment.transform 4 0 env24190 = env24191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env24190 == env24191) = true)

theorem identity24191 : scanCanonicalize (H12AffineFastState.compose env24191 (packedSelected [1,2] rootPS)) = affineNative (2^(15+1) ^^^ 72) := by decide +kernel

theorem selectedBound24191 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env24192 : List Nat := [2,4,8,16,0,64,88,84,80,1024,0,1092,1053,1,1,72,1092,1045,68,0,1,0,1109,72,1101,1029,1045,1092,1092,0,1024,1119,1041,1092,1,80]

theorem envBound24192 : H12AffineFastState.Bounded env24192 := by
  intro p hp
  have h : env24192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24191_24192 : H12AffineEnvironment.transform 15 72 env24191 = env24192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 72 env24191 == env24192) = true)

def env24193 : List Nat := [2,4,8,16,0,64,88,84,80,20,0,80,9,1,1,72,80,1,68,0,1,0,65,72,89,17,1,80,80,0,20,75,5,80,1,80]

theorem envBound24193 : H12AffineFastState.Bounded env24193 := by
  intro p hp
  have h : env24193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24192_24193 : H12AffineEnvironment.transform 9 20 env24192 = env24193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env24192 == env24193) = true)

def leafEnv24193 : List Nat := [2,4,8,16,0,64,88,84,80,20,0,80,9,1,1,72,80,1,68,0,1,0,65,72,68,89,1,17,1,80,80,0,20,75,5,80,85,2,1,80,0,1,1]

def active24193 : List Nat := [0,1,2,3,5]

def tree24193 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24193 : H12WitnessSearch.Good tree24193 := H12GlobalWitnessIndex.good

theorem leafIdentity24193 : H12AffineFastState.composeSystem env24193 rootObs = leafEnv24193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24193 rootObs == leafEnv24193) = true)

theorem terminalChecked24193 : H12PackedTerminal.terminalCheckFast leafEnv24193 active24193 tree24193 = true := by decide +kernel

def env24194 : List Nat := [2,4,8,16,0,64,88,84,80,21,0,81,8,1,1,72,81,0,68,0,1,0,64,72,88,16,0,81,81,0,21,74,4,81,1,80]

theorem envBound24194 : H12AffineFastState.Bounded env24194 := by
  intro p hp
  have h : env24194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24192_24194 : H12AffineEnvironment.transform 9 21 env24192 = env24194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env24192 == env24194) = true)

theorem identity24194 : scanCanonicalize (H12AffineFastState.compose env24194 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound24194 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24195 : List Nat := [2,4,8,16,0,10,18,30,26,21,0,27,8,1,1,2,27,0,14,0,1,0,10,2,18,16,0,27,27,0,21,0,4,27,1,26]

theorem envBound24195 : H12AffineFastState.Bounded env24195 := by
  intro p hp
  have h : env24195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24194_24195 : H12AffineEnvironment.transform 5 10 env24194 = env24195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env24194 == env24195) = true)

def leafEnv24195 : List Nat := [2,4,8,16,0,10,18,30,26,21,0,27,8,1,1,2,27,0,14,0,1,0,10,2,14,18,1,16,0,27,27,0,21,0,4,27,30,2,1,26,0,1,1]

def active24195 : List Nat := [0,1,2,3]

def tree24195 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24195 : H12WitnessSearch.Good tree24195 := H12GlobalWitnessIndex.good

theorem leafIdentity24195 : H12AffineFastState.composeSystem env24195 rootObs = leafEnv24195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24195 rootObs == leafEnv24195) = true)

theorem terminalChecked24195 : H12PackedTerminal.terminalCheckFast leafEnv24195 active24195 tree24195 = true := by decide +kernel

def env24196 : List Nat := [2,4,8,16,1,64,88,84,80,1024,1,1092,1053,1,1,65536,1092,1045,68,0,1,0,1109,65536,1101,1029,1045,1092,1092,1,1024,66582,1041,1092,1,80]

theorem envBound24196 : H12AffineFastState.Bounded env24196 := by
  intro p hp
  have h : env24196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24190_24196 : H12AffineEnvironment.transform 4 1 env24190 = env24196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24190 == env24196) = true)

theorem identity24196 : scanCanonicalize (H12AffineFastState.compose env24196 (packedSelected [1,2] rootPS)) = affineNative (2^(15+1) ^^^ 1116) := by decide +kernel

theorem selectedBound24196 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env24197 : List Nat := [2,4,8,16,1,64,88,84,80,1024,1,1092,1053,1,1,1116,1092,1045,68,0,1,0,1109,1116,1101,1029,1045,1092,1092,1,1024,74,1041,1092,1,80]

theorem envBound24197 : H12AffineFastState.Bounded env24197 := by
  intro p hp
  have h : env24197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24196_24197 : H12AffineEnvironment.transform 15 1116 env24196 = env24197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1116 env24196 == env24197) = true)

def env24198 : List Nat := [2,4,8,16,1,64,88,84,80,20,1,80,9,1,1,72,80,1,68,0,1,0,65,72,89,17,1,80,80,1,20,74,5,80,1,80]

theorem envBound24198 : H12AffineFastState.Bounded env24198 := by
  intro p hp
  have h : env24198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24197_24198 : H12AffineEnvironment.transform 9 20 env24197 = env24198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env24197 == env24198) = true)

theorem identity24198 : scanCanonicalize (H12AffineFastState.compose env24198 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound24198 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24199 : List Nat := [2,4,8,16,1,16,8,4,0,20,1,0,9,1,1,24,0,1,20,0,1,0,17,24,9,17,1,0,0,1,20,26,5,0,1,0]

theorem envBound24199 : H12AffineFastState.Bounded env24199 := by
  intro p hp
  have h : env24199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24198_24199 : H12AffineEnvironment.transform 5 16 env24198 = env24199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24198 == env24199) = true)

def leafEnv24199 : List Nat := [2,4,8,16,1,16,8,4,0,20,1,0,9,1,1,24,0,1,20,0,1,0,17,24,20,9,1,17,1,0,0,1,20,26,5,0,5,2,1,0,0,1,1]

def active24199 : List Nat := [0,1,2,3]

def tree24199 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24199 : H12WitnessSearch.Good tree24199 := H12GlobalWitnessIndex.good

theorem leafIdentity24199 : H12AffineFastState.composeSystem env24199 rootObs = leafEnv24199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24199 rootObs == leafEnv24199) = true)

theorem terminalChecked24199 : H12PackedTerminal.terminalCheckFast leafEnv24199 active24199 tree24199 = true := by decide +kernel

def env24200 : List Nat := [2,4,8,16,1,64,88,84,80,21,1,81,8,1,1,73,81,0,68,0,1,0,64,73,88,16,0,81,81,1,21,74,4,81,1,80]

theorem envBound24200 : H12AffineFastState.Bounded env24200 := by
  intro p hp
  have h : env24200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24197_24200 : H12AffineEnvironment.transform 9 21 env24197 = env24200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env24197 == env24200) = true)

theorem identity24200 : scanCanonicalize (H12AffineFastState.compose env24200 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound24200 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24201 : List Nat := [2,4,8,10,1,64,66,78,74,15,1,75,8,1,1,73,75,0,68,0,1,0,64,73,66,10,0,75,75,1,15,74,4,75,1,74]

theorem envBound24201 : H12AffineFastState.Bounded env24201 := by
  intro p hp
  have h : env24201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24200_24201 : H12AffineEnvironment.transform 3 10 env24200 = env24201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env24200 == env24201) = true)

def leafEnv24201 : List Nat := [2,4,8,10,1,64,66,78,74,15,1,75,8,1,1,73,75,0,68,0,1,0,64,73,68,66,1,10,0,75,75,1,15,74,4,75,78,2,1,74,0,1,1]

def active24201 : List Nat := [0,1,2,5]

def tree24201 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24201 : H12WitnessSearch.Good tree24201 := H12GlobalWitnessIndex.good

theorem leafIdentity24201 : H12AffineFastState.composeSystem env24201 rootObs = leafEnv24201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24201 rootObs == leafEnv24201) = true)

theorem terminalChecked24201 : H12PackedTerminal.terminalCheckFast leafEnv24201 active24201 tree24201 = true := by decide +kernel

def env24202 : List Nat := [2,4,8,16,32,64,89,84,81,1024,32,1092,1053,1,1,65536,1092,262144,68,0,1,1,1109,65536,1100,1029,262145,1092,1092,32,1024,66615,1041,1092,1,81]

theorem envBound24202 : H12AffineFastState.Bounded env24202 := by
  intro p hp
  have h : env24202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24188_24202 : H12AffineEnvironment.transform 6 89 env24188 = env24202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env24188 == env24202) = true)

theorem identity24202 : scanCanonicalize (H12AffineFastState.compose env24202 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound24202 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24203 : List Nat := [2,4,8,16,32,64,89,84,81,21,32,81,8,1,1,65536,81,262144,68,0,1,1,64,65536,89,16,262145,81,81,32,21,65570,4,81,1,81]

theorem envBound24203 : H12AffineFastState.Bounded env24203 := by
  intro p hp
  have h : env24203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24202_24203 : H12AffineEnvironment.transform 9 21 env24202 = env24203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env24202 == env24203) = true)

theorem identity24203 : scanCanonicalize (H12AffineFastState.compose env24203 (packedSelected [1,2] rootPS)) = affineNative (2^(17+1) ^^^ 65608) := by decide +kernel

theorem selectedBound24203 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env24204 : List Nat := [2,4,8,16,32,64,89,84,81,21,32,81,8,1,1,65536,81,65608,68,0,1,1,64,65536,89,16,65609,81,81,32,21,65570,4,81,1,81]

theorem envBound24204 : H12AffineFastState.Bounded env24204 := by
  intro p hp
  have h : env24204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24203_24204 : H12AffineEnvironment.transform 17 65608 env24203 = env24204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65608 env24203 == env24204) = true)

def env24205 : List Nat := [2,4,8,16,32,64,128,84,136,1024,33,1092,1052,1,0,65536,1092,262144,68,1,1,216,1109,65537,1172,1029,262360,1092,1092,33,1024,4294967296,1041,4295032946,1,136]

theorem envBound24205 : H12AffineFastState.Bounded env24205 := by
  intro p hp
  have h : env24205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24186_24205 : H12AffineEnvironment.transform 10 33 env24186 = env24205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env24186 == env24205) = true)

theorem identity24205 : scanCanonicalize (H12AffineFastState.compose env24205 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 1124) := by decide +kernel

theorem selectedBound24205 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env24206 : List Nat := [2,4,8,16,32,64,128,84,136,1024,33,1092,1052,1,0,65536,1092,262144,68,1,1,216,1109,65537,1172,1029,262360,1092,1092,33,1024,1124,1041,66582,1,136]

theorem envBound24206 : H12AffineFastState.Bounded env24206 := by
  intro p hp
  have h : env24206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24205_24206 : H12AffineEnvironment.transform 31 1124 env24205 = env24206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 1124 env24205 == env24206) = true)

def env24207 : List Nat := [2,4,8,16,32,64,88,84,80,1024,33,1092,1052,1,0,65536,1092,262144,68,1,1,0,1109,65537,1100,1029,262144,1092,1092,33,1024,1124,1041,66582,1,80]

theorem envBound24207 : H12AffineFastState.Bounded env24207 := by
  intro p hp
  have h : env24207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24206_24207 : H12AffineEnvironment.transform 6 88 env24206 = env24207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env24206 == env24207) = true)

theorem identity24207 : scanCanonicalize (H12AffineFastState.compose env24207 (packedSelected [7] rootPS)) = affineNative (2^(17+1) ^^^ 1044) := by decide +kernel

theorem selectedBound24207 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env24208 : List Nat := [2,4,8,16,32,64,88,84,80,1024,33,1092,1052,1,0,65536,1092,1044,68,1,1,0,1109,65537,1100,1029,1044,1092,1092,33,1024,1124,1041,66582,1,80]

theorem envBound24208 : H12AffineFastState.Bounded env24208 := by
  intro p hp
  have h : env24208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24207_24208 : H12AffineEnvironment.transform 17 1044 env24207 = env24208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1044 env24207 == env24208) = true)

def env24209 : List Nat := [2,4,8,16,32,16,8,4,0,1024,33,1044,1052,1,0,65536,1044,1044,20,1,1,0,1029,65537,1052,1029,1044,1044,1044,33,1024,1076,1041,66582,1,0]

theorem envBound24209 : H12AffineFastState.Bounded env24209 := by
  intro p hp
  have h : env24209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24208_24209 : H12AffineEnvironment.transform 5 16 env24208 = env24209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env24208 == env24209) = true)

theorem identity24209 : scanCanonicalize (H12AffineFastState.compose env24209 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound24209 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24210 : List Nat := [2,4,8,16,32,16,8,4,0,14,33,26,18,1,0,65536,26,26,20,1,1,0,11,65537,18,11,26,26,26,33,14,58,31,65560,1,0]

theorem envBound24210 : H12AffineFastState.Bounded env24210 := by
  intro p hp
  have h : env24210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24209_24210 : H12AffineEnvironment.transform 9 14 env24209 = env24210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env24209 == env24210) = true)

def env24211 : List Nat := [2,4,8,16,32,16,8,4,0,14,33,26,18,1,0,24,26,26,20,1,1,0,11,25,18,11,26,26,26,33,14,58,31,0,1,0]

theorem envBound24211 : H12AffineFastState.Bounded env24211 := by
  intro p hp
  have h : env24211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24210_24211 : H12AffineEnvironment.transform 15 24 env24210 = env24211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24 env24210 == env24211) = true)

def leafEnv24211 : List Nat := [2,4,8,16,32,16,8,4,0,14,33,26,18,1,0,24,26,26,20,1,1,0,11,25,20,18,1,11,26,26,26,33,14,58,31,0,31,3,1,0,0,1,1]

def active24211 : List Nat := [0,1,2,3,4]

def tree24211 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24211 : H12WitnessSearch.Good tree24211 := H12GlobalWitnessIndex.good

theorem leafIdentity24211 : H12AffineFastState.composeSystem env24211 rootObs = leafEnv24211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24211 rootObs == leafEnv24211) = true)

theorem terminalChecked24211 : H12PackedTerminal.terminalCheckFast leafEnv24211 active24211 tree24211 = true := by decide +kernel

def env24212 : List Nat := [2,4,8,16,32,16,8,4,0,14,33,26,18,1,0,25,26,26,20,1,1,0,11,24,18,11,26,26,26,33,14,58,31,1,1,0]

theorem envBound24212 : H12AffineFastState.Bounded env24212 := by
  intro p hp
  have h : env24212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24210_24212 : H12AffineEnvironment.transform 15 25 env24210 = env24212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25 env24210 == env24212) = true)

theorem identity24212 : scanCanonicalize (H12AffineFastState.compose env24212 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound24212 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24213 : List Nat := [2,4,8,16,26,16,8,4,0,14,27,26,18,1,0,25,26,26,20,1,1,0,11,24,18,11,26,26,26,27,14,0,31,1,1,0]

theorem envBound24213 : H12AffineFastState.Bounded env24213 := by
  intro p hp
  have h : env24213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24212_24213 : H12AffineEnvironment.transform 4 26 env24212 = env24213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env24212 == env24213) = true)

def leafEnv24213 : List Nat := [2,4,8,16,26,16,8,4,0,14,27,26,18,1,0,25,26,26,20,1,1,0,11,24,20,18,1,11,26,26,26,27,14,0,31,1,31,3,1,0,0,1,1]

def active24213 : List Nat := [0,1,2,3]

def tree24213 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24213 : H12WitnessSearch.Good tree24213 := H12GlobalWitnessIndex.good

theorem leafIdentity24213 : H12AffineFastState.composeSystem env24213 rootObs = leafEnv24213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24213 rootObs == leafEnv24213) = true)

theorem terminalChecked24213 : H12PackedTerminal.terminalCheckFast leafEnv24213 active24213 tree24213 = true := by decide +kernel

def env24214 : List Nat := [2,4,8,16,32,17,9,5,1,1024,33,1045,1052,1,0,65536,1045,1044,21,1,1,0,1028,65537,1053,1029,1044,1045,1045,33,1024,1077,1041,66582,1,1]

theorem envBound24214 : H12AffineFastState.Bounded env24214 := by
  intro p hp
  have h : env24214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24208_24214 : H12AffineEnvironment.transform 5 17 env24208 = env24214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env24208 == env24214) = true)

theorem identity24214 : scanCanonicalize (H12AffineFastState.compose env24214 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound24214 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24215 : List Nat := [2,4,8,16,26,17,9,5,1,1024,27,1045,1052,1,0,65536,1045,1044,21,1,1,0,1028,65537,1053,1029,1044,1045,1045,27,1024,1039,1041,66582,1,1]

theorem envBound24215 : H12AffineFastState.Bounded env24215 := by
  intro p hp
  have h : env24215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24214_24215 : H12AffineEnvironment.transform 4 26 env24214 = env24215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env24214 == env24215) = true)

def env24216 : List Nat := [2,4,8,16,26,17,9,5,1,1024,27,1045,1052,1,0,24,1045,1044,21,1,1,0,1028,25,1053,1029,1044,1045,1045,27,1024,1039,1041,1038,1,1]

theorem envBound24216 : H12AffineFastState.Bounded env24216 := by
  intro p hp
  have h : env24216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24215_24216 : H12AffineEnvironment.transform 15 24 env24215 = env24216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24 env24215 == env24216) = true)

theorem identity24216 : scanCanonicalize (H12AffineFastState.compose env24216 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound24216 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24217 : List Nat := [2,4,8,16,26,17,9,5,1,14,27,27,18,1,0,24,27,26,21,1,1,0,10,25,19,11,26,27,27,27,14,1,31,0,1,1]

theorem envBound24217 : H12AffineFastState.Bounded env24217 := by
  intro p hp
  have h : env24217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24216_24217 : H12AffineEnvironment.transform 9 14 env24216 = env24217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env24216 == env24217) = true)

def leafEnv24217 : List Nat := [2,4,8,16,26,17,9,5,1,14,27,27,18,1,0,24,27,26,21,1,1,0,10,25,21,19,1,11,26,27,27,27,14,1,31,0,30,3,1,1,0,1,1]

def active24217 : List Nat := [0,1,2,3]

def tree24217 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24217 : H12WitnessSearch.Good tree24217 := H12GlobalWitnessIndex.good

theorem leafIdentity24217 : H12AffineFastState.composeSystem env24217 rootObs = leafEnv24217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24217 rootObs == leafEnv24217) = true)

theorem terminalChecked24217 : H12PackedTerminal.terminalCheckFast leafEnv24217 active24217 tree24217 = true := by decide +kernel

def env24218 : List Nat := [2,4,8,16,26,17,9,5,1,1024,27,1045,1052,1,0,25,1045,1044,21,1,1,0,1028,24,1053,1029,1044,1045,1045,27,1024,1039,1041,1039,1,1]

theorem envBound24218 : H12AffineFastState.Bounded env24218 := by
  intro p hp
  have h : env24218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24215_24218 : H12AffineEnvironment.transform 15 25 env24215 = env24218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25 env24215 == env24218) = true)

def leafEnv24218 : List Nat := [2,4,8,16,26,17,9,5,1,1024,27,1045,1052,1,0,25,1045,1044,21,1,1,0,1028,24,21,1053,1,1029,1044,1045,1045,27,1024,1039,1041,1039,1040,3,1,1,0,1,1]

def active24218 : List Nat := [0,1,2,3,9]

def tree24218 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24218 : H12WitnessSearch.Good tree24218 := H12GlobalWitnessIndex.good

theorem leafIdentity24218 : H12AffineFastState.composeSystem env24218 rootObs = leafEnv24218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24218 rootObs == leafEnv24218) = true)

theorem terminalChecked24218 : H12PackedTerminal.terminalCheckFast leafEnv24218 active24218 tree24218 = true := by decide +kernel

def env24219 : List Nat := [2,4,8,16,32,64,89,84,81,1024,33,1092,1052,1,0,65536,1092,262144,68,1,1,1,1109,65537,1101,1029,262145,1092,1092,33,1024,1124,1041,66582,1,81]

theorem envBound24219 : H12AffineFastState.Bounded env24219 := by
  intro p hp
  have h : env24219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24206_24219 : H12AffineEnvironment.transform 6 89 env24206 = env24219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env24206 == env24219) = true)

theorem identity24219 : scanCanonicalize (H12AffineFastState.compose env24219 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound24219 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24220 : List Nat := [2,4,8,16,32,64,89,84,81,20,33,80,8,1,0,65536,80,262144,68,1,1,1,65,65537,89,17,262145,80,80,33,20,112,5,65538,1,81]

theorem envBound24220 : H12AffineFastState.Bounded env24220 := by
  intro p hp
  have h : env24220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24219_24220 : H12AffineEnvironment.transform 9 20 env24219 = env24220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env24219 == env24220) = true)

def env24221 : List Nat := [2,4,8,16,32,64,128,85,136,1024,2048,1092,8192,16384,32768,65536,1092,262144,16452,32769,16385,58564,17493,98305,8328,17413,320708,1093,1093,1073741824,1024,4294967296,17424,4295058542,16385,136]

theorem envBound24221 : H12AffineFastState.Bounded env24221 := by
  intro p hp
  have h : env24221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24133_24221 : H12AffineEnvironment.transform 7 85 env24133 = env24221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env24133 == env24221) = true)

theorem identity24221 : scanCanonicalize (H12AffineFastState.compose env24221 (packedSelected [1,3,5] rootPS)) = affineNative (2^(29+1) ^^^ 335994) := by decide +kernel

theorem selectedBound24221 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env24222 : List Nat := [2,4,8,16,32,64,128,85,136,1024,2048,1092,8192,16384,32768,65536,1092,262144,16452,32769,16385,58564,17493,98305,8328,17413,320708,1093,1093,335994,1024,4294967296,17424,4295058542,16385,136]

theorem envBound24222 : H12AffineFastState.Bounded env24222 := by
  intro p hp
  have h : env24222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24221_24222 : H12AffineEnvironment.transform 29 335994 env24221 = env24222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 335994 env24221 == env24222) = true)

theorem identity24222 : scanCanonicalize (H12AffineFastState.compose env24222 (packedSelected [1,3,8] rootPS)) = affineNative (2^(17+1) ^^^ 117950) := by decide +kernel

theorem selectedBound24222 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env24223 : List Nat := [2,4,8,16,32,64,128,85,136,1024,2048,1092,8192,16384,32768,65536,1092,117950,16452,32769,16385,58564,17493,98305,8328,17413,75898,1093,1093,60612,1024,4294967296,17424,4295058542,16385,136]

theorem envBound24223 : H12AffineFastState.Bounded env24223 := by
  intro p hp
  have h : env24223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24222_24223 : H12AffineEnvironment.transform 17 117950 env24222 = env24223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 117950 env24222 == env24223) = true)

theorem identity24223 : scanCanonicalize (H12AffineFastState.compose env24223 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 25751) := by decide +kernel

theorem selectedBound24223 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env24224 : List Nat := [2,4,8,16,32,64,128,85,136,1024,2048,1092,8192,16384,32768,25751,1092,43049,16452,32769,16385,58564,17493,58518,8328,17413,19693,1093,1093,60612,1024,4294967296,17424,4294967545,16385,136]

theorem envBound24224 : H12AffineFastState.Bounded env24224 := by
  intro p hp
  have h : env24224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24223_24224 : H12AffineEnvironment.transform 15 25751 env24223 = env24224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25751 env24223 == env24224) = true)

def env24225 : List Nat := [2,4,8,16,32,64,128,85,136,1024,2048,1092,88,16384,32768,17615,1092,34929,16452,32769,16385,50332,17493,50382,208,17413,19693,1093,1093,52380,1024,4294967296,17424,4294967545,16385,136]

theorem envBound24225 : H12AffineFastState.Bounded env24225 := by
  intro p hp
  have h : env24225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24224_24225 : H12AffineEnvironment.transform 12 88 env24224 = env24225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 88 env24224 == env24225) = true)

theorem identity24225 : scanCanonicalize (H12AffineFastState.compose env24225 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 17597) := by decide +kernel

theorem selectedBound24225 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env24226 : List Nat := [2,4,8,16,32,64,128,85,136,1024,2048,1092,88,16384,32768,17615,1092,34929,16452,32769,16385,50332,17493,50382,208,17413,19693,1093,1093,52380,1024,17597,17424,17476,16385,136]

theorem envBound24226 : H12AffineFastState.Bounded env24226 := by
  intro p hp
  have h : env24226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24225_24226 : H12AffineEnvironment.transform 31 17597 env24225 = env24226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 17597 env24225 == env24226) = true)

def env24227 : List Nat := [2,4,8,16,32,64,128,85,136,1024,80,1092,88,16384,32768,17615,1092,32801,16452,32769,16385,50332,17493,50382,208,17413,17597,1093,1093,50380,1024,17597,17424,17476,16385,136]

theorem envBound24227 : H12AffineFastState.Bounded env24227 := by
  intro p hp
  have h : env24227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24226_24227 : H12AffineEnvironment.transform 10 80 env24226 = env24227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env24226 == env24227) = true)

theorem identity24227 : scanCanonicalize (H12AffineFastState.compose env24227 (packedSelected [0] rootPS)) = affineNative (2^(13+1) ^^^ 1261) := by decide +kernel

theorem selectedBound24227 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24228 : List Nat := [2,4,8,16,32,64,128,85,136,1024,80,1092,88,1261,32768,34,1092,32801,1193,32769,1260,32881,184,32803,208,232,80,1093,1093,32801,1024,80,253,169,1260,136]

theorem envBound24228 : H12AffineFastState.Bounded env24228 := by
  intro p hp
  have h : env24228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24227_24228 : H12AffineEnvironment.transform 13 1261 env24227 = env24228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1261 env24227 == env24228) = true)

theorem identity24228 : scanCanonicalize (H12AffineFastState.compose env24228 (packedSelected [2,4] rootPS)) = affineNative (2^(14+1) ^^^ 113) := by decide +kernel

theorem selectedBound24228 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env24229 : List Nat := [2,4,8,16,32,64,128,85,136,1024,80,1092,88,1261,113,34,1092,80,1193,112,1260,0,184,82,208,232,80,1093,1093,80,1024,80,253,169,1260,136]

theorem envBound24229 : H12AffineFastState.Bounded env24229 := by
  intro p hp
  have h : env24229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24228_24229 : H12AffineEnvironment.transform 14 113 env24228 = env24229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 113 env24228 == env24229) = true)

def env24230 : List Nat := [2,4,8,16,32,64,88,85,80,1024,80,1092,88,1077,113,34,1092,80,1137,112,1076,0,96,82,8,48,80,1093,1093,80,1024,80,37,113,1076,80]

theorem envBound24230 : H12AffineFastState.Bounded env24230 := by
  intro p hp
  have h : env24230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24229_24230 : H12AffineEnvironment.transform 6 88 env24229 = env24230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env24229 == env24230) = true)

theorem identity24230 : scanCanonicalize (H12AffineFastState.compose env24230 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 42) := by decide +kernel

theorem selectedBound24230 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24231 : List Nat := [2,4,8,16,32,42,50,63,58,1024,58,1070,50,1077,27,34,1070,58,1051,26,1076,0,10,56,8,48,58,1071,1071,58,1024,58,37,27,1076,58]

theorem envBound24231 : H12AffineFastState.Bounded env24231 := by
  intro p hp
  have h : env24231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24230_24231 : H12AffineEnvironment.transform 5 42 env24230 = env24231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 42 env24230 == env24231) = true)

theorem identity24231 : scanCanonicalize (H12AffineFastState.compose env24231 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound24231 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24232 : List Nat := [2,4,8,16,27,17,9,4,1,1024,1,1045,9,1038,27,25,1045,1,1051,26,1039,0,10,3,8,11,1,1044,1044,1,1024,1,30,27,1039,1]

theorem envBound24232 : H12AffineFastState.Bounded env24232 := by
  intro p hp
  have h : env24232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24231_24232 : H12AffineEnvironment.transform 4 27 env24231 = env24232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env24231 == env24232) = true)

def leafEnv24232 : List Nat := [2,4,8,16,27,17,9,4,1,1024,1,1045,9,1038,27,25,1045,1,1051,26,1039,0,10,3,1051,8,1,11,1,1044,1044,1,1024,1,30,27,30,24,1039,1,0,1038,1]

def active24232 : List Nat := [0,1,2,3,9]

def tree24232 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24232 : H12WitnessSearch.Good tree24232 := H12GlobalWitnessIndex.good

theorem leafIdentity24232 : H12AffineFastState.composeSystem env24232 rootObs = leafEnv24232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24232 rootObs == leafEnv24232) = true)

theorem terminalChecked24232 : H12PackedTerminal.terminalCheckFast leafEnv24232 active24232 tree24232 = true := by decide +kernel

def env24233 : List Nat := [2,4,8,16,32,64,89,85,81,1024,80,1092,88,1076,113,34,1092,80,1136,112,1077,0,97,82,9,49,80,1093,1093,80,1024,80,36,112,1077,81]

theorem envBound24233 : H12AffineFastState.Bounded env24233 := by
  intro p hp
  have h : env24233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24229_24233 : H12AffineEnvironment.transform 6 89 env24229 = env24233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env24229 == env24233) = true)

theorem identity24233 : scanCanonicalize (H12AffineFastState.compose env24233 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 127) := by decide +kernel

theorem selectedBound24233 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24234 : List Nat := [2,4,8,16,32,64,89,85,81,127,80,59,88,75,113,34,59,80,15,112,74,0,97,82,9,49,80,58,58,80,127,80,36,112,74,81]

theorem envBound24234 : H12AffineFastState.Bounded env24234 := by
  intro p hp
  have h : env24234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24233_24234 : H12AffineEnvironment.transform 9 127 env24233 = env24234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 127 env24233 == env24234) = true)

def leafEnv24234 : List Nat := [2,4,8,16,32,64,89,85,81,127,80,59,88,75,113,34,59,80,15,112,74,0,97,82,15,9,1,49,80,58,58,80,127,80,36,112,117,114,74,81,0,75,1]

def active24234 : List Nat := [0,1,2,3,4,5]

def tree24234 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24234 : H12WitnessSearch.Good tree24234 := H12GlobalWitnessIndex.good

theorem leafIdentity24234 : H12AffineFastState.composeSystem env24234 rootObs = leafEnv24234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24234 rootObs == leafEnv24234) = true)

theorem terminalChecked24234 : H12PackedTerminal.terminalCheckFast leafEnv24234 active24234 tree24234 = true := by decide +kernel

def env24235 : List Nat := [2,4,8,16,32,64,128,85,136,1024,81,1092,88,16384,32768,17615,1092,32800,16452,32769,16385,50332,17493,50382,208,17413,17596,1093,1093,50381,1024,17597,17424,17476,16385,136]

theorem envBound24235 : H12AffineFastState.Bounded env24235 := by
  intro p hp
  have h : env24235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24226_24235 : H12AffineEnvironment.transform 10 81 env24226 = env24235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env24226 == env24235) = true)

theorem identity24235 : scanCanonicalize (H12AffineFastState.compose env24235 (packedSelected [0] rootPS)) = affineNative (2^(14+1) ^^^ 112) := by decide +kernel

theorem selectedBound24235 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24236 : List Nat := [2,4,8,16,32,64,128,85,136,1024,81,1092,88,16384,112,17615,1092,80,16452,113,16385,17644,17493,17598,208,17413,17596,1093,1093,17597,1024,17597,17424,17476,16385,136]

theorem envBound24236 : H12AffineFastState.Bounded env24236 := by
  intro p hp
  have h : env24236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24235_24236 : H12AffineEnvironment.transform 14 112 env24235 = env24236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 112 env24235 == env24236) = true)

theorem identity24236 : scanCanonicalize (H12AffineFastState.compose env24236 (packedSelected [7] rootPS)) = affineNative (2^(13+1) ^^^ 1260) := by decide +kernel

theorem selectedBound24236 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env24237 : List Nat := [2,4,8,16,32,64,128,85,136,1024,81,1092,88,1260,112,35,1092,80,1192,113,1261,0,185,82,208,233,80,1093,1093,81,1024,81,252,168,1261,136]

theorem envBound24237 : H12AffineFastState.Bounded env24237 := by
  intro p hp
  have h : env24237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24236_24237 : H12AffineEnvironment.transform 13 1260 env24236 = env24237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1260 env24236 == env24237) = true)

def env24238 : List Nat := [2,4,8,16,32,64,88,85,80,1024,81,1092,88,1076,112,35,1092,80,1136,113,1077,0,97,82,8,49,80,1093,1093,81,1024,81,36,112,1077,80]

theorem envBound24238 : H12AffineFastState.Bounded env24238 := by
  intro p hp
  have h : env24238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24237_24238 : H12AffineEnvironment.transform 6 88 env24237 = env24238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env24237 == env24238) = true)

theorem identity24238 : scanCanonicalize (H12AffineFastState.compose env24238 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound24238 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24239 : List Nat := [2,4,8,16,26,64,88,85,80,1024,81,1092,88,1038,74,25,1092,80,1098,75,1039,0,91,82,8,11,80,1093,1093,81,1024,81,30,74,1039,80]

theorem envBound24239 : H12AffineFastState.Bounded env24239 := by
  intro p hp
  have h : env24239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24238_24239 : H12AffineEnvironment.transform 4 26 env24238 = env24239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env24238 == env24239) = true)

theorem identity24239 : scanCanonicalize (H12AffineFastState.compose env24239 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound24239 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24240 : List Nat := [2,4,8,11,1,64,67,78,75,1024,74,1092,67,1038,74,2,1092,75,1098,75,1039,0,64,73,8,11,75,1093,1093,74,1024,74,5,74,1039,75]

theorem envBound24240 : H12AffineFastState.Bounded env24240 := by
  intro p hp
  have h : env24240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24239_24240 : H12AffineEnvironment.transform 3 11 env24239 = env24240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env24239 == env24240) = true)

def leafEnv24240 : List Nat := [2,4,8,11,1,64,67,78,75,1024,74,1092,67,1038,74,2,1092,75,1098,75,1039,0,64,73,1098,8,1,11,75,1093,1093,74,1024,74,5,74,79,73,1039,75,0,1038,1]

def active24240 : List Nat := [0,1,2,5,9]

def tree24240 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24240 : H12WitnessSearch.Good tree24240 := H12GlobalWitnessIndex.good

theorem leafIdentity24240 : H12AffineFastState.composeSystem env24240 rootObs = leafEnv24240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24240 rootObs == leafEnv24240) = true)

theorem terminalChecked24240 : H12PackedTerminal.terminalCheckFast leafEnv24240 active24240 tree24240 = true := by decide +kernel

def env24241 : List Nat := [2,4,8,16,32,64,89,85,81,1024,81,1092,88,1077,112,35,1092,80,1137,113,1076,0,96,82,9,48,80,1093,1093,81,1024,81,37,113,1076,81]

theorem envBound24241 : H12AffineFastState.Bounded env24241 := by
  intro p hp
  have h : env24241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24237_24241 : H12AffineEnvironment.transform 6 89 env24237 = env24241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env24237 == env24241) = true)

theorem identity24241 : scanCanonicalize (H12AffineFastState.compose env24241 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound24241 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24242 : List Nat := [2,4,8,16,32,64,89,85,81,47,81,107,88,26,112,35,107,80,94,113,27,0,96,82,9,48,80,106,106,81,47,81,37,113,27,81]

theorem envBound24242 : H12AffineFastState.Bounded env24242 := by
  intro p hp
  have h : env24242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24241_24242 : H12AffineEnvironment.transform 9 47 env24241 = env24242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env24241 == env24242) = true)

theorem identity24242 : scanCanonicalize (H12AffineFastState.compose env24242 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound24242 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24243 : List Nat := [2,4,8,16,32,49,40,36,32,47,32,26,41,26,1,35,26,33,47,0,27,0,17,35,9,48,33,27,27,32,47,32,37,0,27,32]

theorem envBound24243 : H12AffineFastState.Bounded env24243 := by
  intro p hp
  have h : env24243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24242_24243 : H12AffineEnvironment.transform 5 49 env24242 = env24243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env24242 == env24243) = true)

def leafEnv24243 : List Nat := [2,4,8,16,32,49,40,36,32,47,32,26,41,26,1,35,26,33,47,0,27,0,17,35,47,9,1,48,33,27,27,32,47,32,37,0,5,2,27,32,0,26,1]

def active24243 : List Nat := [0,1,2,3,4]

def tree24243 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24243 : H12WitnessSearch.Good tree24243 := H12GlobalWitnessIndex.good

theorem leafIdentity24243 : H12AffineFastState.composeSystem env24243 rootObs = leafEnv24243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24243 rootObs == leafEnv24243) = true)

theorem terminalChecked24243 : H12PackedTerminal.terminalCheckFast leafEnv24243 active24243 tree24243 = true := by decide +kernel

def env24244 : List Nat := [2,4,8,16,32,64,128,85,136,1024,2048,1092,89,16384,32768,17614,1092,34928,16452,32769,16385,50333,17493,50383,209,17413,19693,1093,1093,52381,1024,4294967296,17424,4294967545,16385,136]

theorem envBound24244 : H12AffineFastState.Bounded env24244 := by
  intro p hp
  have h : env24244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24224_24244 : H12AffineEnvironment.transform 12 89 env24224 = env24244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 89 env24224 == env24244) = true)

theorem identity24244 : scanCanonicalize (H12AffineFastState.compose env24244 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 33017) := by decide +kernel

theorem selectedBound24244 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env24245 : List Nat := [2,4,8,16,32,64,128,85,136,1024,2048,1092,89,16384,32768,17614,1092,34928,16452,32769,16385,50333,17493,50383,209,17413,19693,1093,1093,52381,1024,33017,17424,32768,16385,136]

theorem envBound24245 : H12AffineFastState.Bounded env24245 := by
  intro p hp
  have h : env24245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24244_24245 : H12AffineEnvironment.transform 31 33017 env24244 = env24245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 33017 env24244 == env24245) = true)

def env24246 : List Nat := [2,4,8,16,32,64,128,85,136,1024,80,1092,89,16384,32768,17614,1092,32800,16452,32769,16385,50333,17493,50383,209,17413,17597,1093,1093,50381,1024,33017,17424,32768,16385,136]

theorem envBound24246 : H12AffineFastState.Bounded env24246 := by
  intro p hp
  have h : env24246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24245_24246 : H12AffineEnvironment.transform 10 80 env24245 = env24246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env24245 == env24246) = true)

theorem identity24246 : scanCanonicalize (H12AffineFastState.compose env24246 (packedSelected [0] rootPS)) = affineNative (2^(14+1) ^^^ 113) := by decide +kernel

theorem selectedBound24246 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24247 : List Nat := [2,4,8,16,32,64,128,85,136,1024,80,1092,89,16384,113,17614,1092,81,16452,112,16385,17644,17493,17598,209,17413,17597,1093,1093,17596,1024,136,17424,113,16385,136]

theorem envBound24247 : H12AffineFastState.Bounded env24247 := by
  intro p hp
  have h : env24247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24246_24247 : H12AffineEnvironment.transform 14 113 env24246 = env24247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 113 env24246 == env24247) = true)

theorem identity24247 : scanCanonicalize (H12AffineFastState.compose env24247 (packedSelected [7] rootPS)) = affineNative (2^(13+1) ^^^ 1260) := by decide +kernel

theorem selectedBound24247 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env24248 : List Nat := [2,4,8,16,32,64,128,85,136,1024,80,1092,89,1260,113,34,1092,81,1192,112,1261,0,185,82,209,233,81,1093,1093,80,1024,136,252,113,1261,136]

theorem envBound24248 : H12AffineFastState.Bounded env24248 := by
  intro p hp
  have h : env24248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24247_24248 : H12AffineEnvironment.transform 13 1260 env24247 = env24248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1260 env24247 == env24248) = true)

def env24249 : List Nat := [2,4,8,16,32,64,88,85,80,1024,80,1092,89,1076,113,34,1092,81,1136,112,1077,0,97,82,9,49,81,1093,1093,80,1024,80,36,113,1077,80]

theorem envBound24249 : H12AffineFastState.Bounded env24249 := by
  intro p hp
  have h : env24249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24248_24249 : H12AffineEnvironment.transform 6 88 env24248 = env24249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env24248 == env24249) = true)

theorem identity24249 : scanCanonicalize (H12AffineFastState.compose env24249 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound24249 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24250 : List Nat := [2,4,8,11,32,64,67,78,75,1024,75,1092,66,1071,106,34,1092,74,1131,107,1070,0,97,73,9,42,74,1093,1093,75,1024,75,36,106,1070,75]

theorem envBound24250 : H12AffineFastState.Bounded env24250 := by
  intro p hp
  have h : env24250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24249_24250 : H12AffineEnvironment.transform 3 11 env24249 = env24250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env24249 == env24250) = true)

def env24251 : List Nat := [2,4,8,16,32,64,89,85,81,1024,80,1092,89,1077,113,34,1092,81,1137,112,1076,0,96,82,8,48,81,1093,1093,80,1024,81,37,113,1076,81]

theorem envBound24251 : H12AffineFastState.Bounded env24251 := by
  intro p hp
  have h : env24251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24248_24251 : H12AffineEnvironment.transform 6 89 env24248 = env24251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env24248 == env24251) = true)

theorem identity24251 : scanCanonicalize (H12AffineFastState.compose env24251 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound24251 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24252 : List Nat := [2,4,8,16,32,64,89,85,81,46,80,106,89,27,113,34,106,81,95,112,26,0,96,82,8,48,81,107,107,80,46,81,37,113,26,81]

theorem envBound24252 : H12AffineFastState.Bounded env24252 := by
  intro p hp
  have h : env24252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24251_24252 : H12AffineEnvironment.transform 9 46 env24251 = env24252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env24251 == env24252) = true)

theorem identity24252 : scanCanonicalize (H12AffineFastState.compose env24252 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound24252 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24253 : List Nat := [2,4,8,16,32,49,40,36,32,46,33,27,40,27,0,34,27,32,46,1,26,0,17,35,8,48,32,26,26,33,46,32,37,0,26,32]

theorem envBound24253 : H12AffineFastState.Bounded env24253 := by
  intro p hp
  have h : env24253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24252_24253 : H12AffineEnvironment.transform 5 49 env24252 = env24253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env24252 == env24253) = true)

def leafEnv24253 : List Nat := [2,4,8,16,32,49,40,36,32,46,33,27,40,27,0,34,27,32,46,1,26,0,17,35,46,8,1,48,32,26,26,33,46,32,37,0,5,3,26,32,0,27,1]

def active24253 : List Nat := [0,1,2,3,4]

def tree24253 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24253 : H12WitnessSearch.Good tree24253 := H12GlobalWitnessIndex.good

theorem leafIdentity24253 : H12AffineFastState.composeSystem env24253 rootObs = leafEnv24253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24253 rootObs == leafEnv24253) = true)

theorem terminalChecked24253 : H12PackedTerminal.terminalCheckFast leafEnv24253 active24253 tree24253 = true := by decide +kernel

def env24254 : List Nat := [2,4,8,16,32,64,128,85,136,1024,81,1092,89,16384,32768,17614,1092,32801,16452,32769,16385,50333,17493,50383,209,17413,17596,1093,1093,50380,1024,33017,17424,32768,16385,136]

theorem envBound24254 : H12AffineFastState.Bounded env24254 := by
  intro p hp
  have h : env24254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24245_24254 : H12AffineEnvironment.transform 10 81 env24245 = env24254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env24245 == env24254) = true)

theorem identity24254 : scanCanonicalize (H12AffineFastState.compose env24254 (packedSelected [0] rootPS)) = affineNative (2^(13+1) ^^^ 1261) := by decide +kernel

theorem selectedBound24254 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24255 : List Nat := [2,4,8,16,32,64,128,85,136,1024,81,1092,89,1261,32768,35,1092,32801,1193,32769,1260,32880,184,32802,209,232,81,1093,1093,32801,1024,33017,253,32768,1260,136]

theorem envBound24255 : H12AffineFastState.Bounded env24255 := by
  intro p hp
  have h : env24255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24254_24255 : H12AffineEnvironment.transform 13 1261 env24254 = env24255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1261 env24254 == env24255) = true)

theorem identity24255 : scanCanonicalize (H12AffineFastState.compose env24255 (packedSelected [2,4] rootPS)) = affineNative (2^(14+1) ^^^ 112) := by decide +kernel

theorem selectedBound24255 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env24256 : List Nat := [2,4,8,16,32,64,128,85,136,1024,81,1092,89,1261,112,35,1092,81,1193,113,1260,0,184,82,209,232,81,1093,1093,81,1024,137,253,112,1260,136]

theorem envBound24256 : H12AffineFastState.Bounded env24256 := by
  intro p hp
  have h : env24256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24255_24256 : H12AffineEnvironment.transform 14 112 env24255 = env24256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 112 env24255 == env24256) = true)

def env24257 : List Nat := [2,4,8,16,32,64,88,85,80,1024,81,1092,89,1077,112,35,1092,81,1137,113,1076,0,96,82,9,48,81,1093,1093,81,1024,81,37,112,1076,80]

theorem envBound24257 : H12AffineFastState.Bounded env24257 := by
  intro p hp
  have h : env24257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24256_24257 : H12AffineEnvironment.transform 6 88 env24256 = env24257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env24256 == env24257) = true)

theorem identity24257 : scanCanonicalize (H12AffineFastState.compose env24257 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound24257 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24258 : List Nat := [2,4,8,16,32,10,18,31,26,1024,27,1038,19,1077,58,35,1038,27,1083,59,1076,0,42,24,9,48,27,1039,1039,27,1024,27,37,58,1076,26]

theorem envBound24258 : H12AffineFastState.Bounded env24258 := by
  intro p hp
  have h : env24258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24257_24258 : H12AffineEnvironment.transform 5 10 env24257 = env24258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env24257 == env24258) = true)

theorem identity24258 : scanCanonicalize (H12AffineFastState.compose env24258 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound24258 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24259 : List Nat := [2,4,8,16,27,10,18,31,26,1024,27,1038,19,1038,1,24,1038,27,1024,0,1039,0,17,24,9,11,27,1039,1039,27,1024,27,30,1,1039,26]

theorem envBound24259 : H12AffineFastState.Bounded env24259 := by
  intro p hp
  have h : env24259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24258_24259 : H12AffineEnvironment.transform 4 27 env24258 = env24259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env24258 == env24259) = true)

def leafEnv24259 : List Nat := [2,4,8,16,27,10,18,31,26,1024,27,1038,19,1038,1,24,1038,27,1024,0,1039,0,17,24,1024,9,1,11,27,1039,1039,27,1024,27,30,1,5,2,1039,26,0,1038,1]

def active24259 : List Nat := [0,1,2,3,9]

def tree24259 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24259 : H12WitnessSearch.Good tree24259 := H12GlobalWitnessIndex.good

theorem leafIdentity24259 : H12AffineFastState.composeSystem env24259 rootObs = leafEnv24259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24259 rootObs == leafEnv24259) = true)

theorem terminalChecked24259 : H12PackedTerminal.terminalCheckFast leafEnv24259 active24259 tree24259 = true := by decide +kernel

def env24260 : List Nat := [2,4,8,16,32,64,89,85,81,1024,81,1092,89,1076,112,35,1092,81,1136,113,1077,0,97,82,8,49,81,1093,1093,81,1024,80,36,112,1077,81]

theorem envBound24260 : H12AffineFastState.Bounded env24260 := by
  intro p hp
  have h : env24260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24256_24260 : H12AffineEnvironment.transform 6 89 env24256 = env24260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env24256 == env24260) = true)

theorem identity24260 : scanCanonicalize (H12AffineFastState.compose env24260 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 126) := by decide +kernel

theorem selectedBound24260 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24261 : List Nat := [2,4,8,16,32,64,89,85,81,126,81,58,89,74,112,35,58,81,14,113,75,0,97,82,8,49,81,59,59,81,126,80,36,112,75,81]

theorem envBound24261 : H12AffineFastState.Bounded env24261 := by
  intro p hp
  have h : env24261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24260_24261 : H12AffineEnvironment.transform 9 126 env24260 = env24261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 126 env24260 == env24261) = true)

def leafEnv24261 : List Nat := [2,4,8,16,32,64,89,85,81,126,81,58,89,74,112,35,58,81,14,113,75,0,97,82,14,8,1,49,81,59,59,81,126,80,36,112,117,115,75,81,0,74,1]

def active24261 : List Nat := [0,1,2,3,4,5]

def tree24261 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24261 : H12WitnessSearch.Good tree24261 := H12GlobalWitnessIndex.good

theorem leafIdentity24261 : H12AffineFastState.composeSystem env24261 rootObs = leafEnv24261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24261 rootObs == leafEnv24261) = true)

theorem terminalChecked24261 : H12PackedTerminal.terminalCheckFast leafEnv24261 active24261 tree24261 = true := by decide +kernel

def env24262 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,16384,32768,65536,4096,262144,524288,32769,2097152,566401,525329,103492,8328,67108864,831684,1297,1297,1073741824,67638276,4294967296,525569,4295569518,69731392,136]

theorem envBound24262 : H12AffineFastState.Bounded env24262 := by
  intro p hp
  have h : env24262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24080_24262 : H12AffineEnvironment.transform 21 566401 env24080 = env24262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 566401 env24080 == env24262) = true)

def env24263 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,16384,32768,65536,4096,262144,524288,32769,529408,566401,525329,103492,8328,67108864,831684,1297,1297,1073741824,67638276,4294967296,525569,4295569518,67113024,136]

theorem envBound24263 : H12AffineFastState.Bounded env24263 := by
  intro p hp
  have h : env24263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24262_24263 : H12AffineEnvironment.transform 20 529408 env24262 = env24263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 529408 env24262 == env24263) = true)

theorem identity24263 : scanCanonicalize (H12AffineFastState.compose env24263 (packedSelected [14] rootPS)) = affineNative (2^(25+1) ^^^ 525377) := by decide +kernel

theorem selectedBound24263 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env24264 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,16384,32768,65536,4096,262144,524288,32769,529408,566401,525329,103492,8328,525377,831684,1297,1297,1073741824,4165,4294967296,525569,4295569518,529409,136]

theorem envBound24264 : H12AffineFastState.Bounded env24264 := by
  intro p hp
  have h : env24264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24263_24264 : H12AffineEnvironment.transform 25 525377 env24263 = env24264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 525377 env24263 == env24264) = true)

theorem identity24264 : scanCanonicalize (H12AffineFastState.compose env24264 (packedSelected [3,5,24] rootPS)) = affineNative (2^(18+1) ^^^ 299212) := by decide +kernel

theorem selectedBound24264 : packedSelected [3,5,24] rootPS < 2^1333 := by decide +kernel

def env24265 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,16384,32768,65536,4096,262144,299212,32769,296140,275533,300253,103492,8328,300173,8200,1297,1297,1073741824,4165,4294967296,300493,4295336098,296141,136]

theorem envBound24265 : H12AffineFastState.Bounded env24265 := by
  intro p hp
  have h : env24265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24264_24265 : H12AffineEnvironment.transform 18 299212 env24264 = env24265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 299212 env24264 == env24265) = true)

theorem identity24265 : scanCanonicalize (H12AffineFastState.compose env24265 (packedSelected [0,27] rootPS)) = affineNative (2^(17+1) ^^^ 53724) := by decide +kernel

theorem selectedBound24265 : packedSelected [0,27] rootPS < 2^1333 := by decide +kernel

def env24266 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,16384,32768,65536,4096,53724,16656,32769,21776,58769,17665,103492,8328,17745,8200,1297,1297,1073741824,4165,4294967296,17425,4295061886,21777,136]

theorem envBound24266 : H12AffineFastState.Bounded env24266 := by
  intro p hp
  have h : env24266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24265_24266 : H12AffineEnvironment.transform 17 53724 env24265 = env24266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 53724 env24265 == env24266) = true)

theorem identity24266 : scanCanonicalize (H12AffineFastState.compose env24266 (packedSelected [1,12,13] rootPS)) = affineNative (2^(29+1) ^^^ 63956) := by decide +kernel

theorem selectedBound24266 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env24267 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,16384,32768,65536,4096,53724,16656,32769,21776,58769,17665,103492,8328,17745,8200,1297,1297,63956,4165,4294967296,17425,4295061886,21777,136]

theorem envBound24267 : H12AffineFastState.Bounded env24267 := by
  intro p hp
  have h : env24267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24266_24267 : H12AffineEnvironment.transform 29 63956 env24266 = env24267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 63956 env24266 == env24267) = true)

theorem identity24267 : scanCanonicalize (H12AffineFastState.compose env24267 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 14837) := by decide +kernel

theorem selectedBound24267 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env24268 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,14837,32768,65536,4096,43049,14565,32769,11493,40036,15604,103492,8328,15524,8200,1297,1297,32801,4165,4294967296,15844,4295035019,11492,136]

theorem envBound24268 : H12AffineFastState.Bounded env24268 := by
  intro p hp
  have h : env24268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24267_24268 : H12AffineEnvironment.transform 13 14837 env24267 = env24268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 14837 env24267 == env24268) = true)

def env24269 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,14837,2080,65536,4096,8201,14565,2081,11493,5188,15604,72804,8328,15524,8200,1297,1297,2049,4165,4294967296,15844,4295035019,11492,136]

theorem envBound24269 : H12AffineFastState.Bounded env24269 := by
  intro p hp
  have h : env24269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24268_24269 : H12AffineEnvironment.transform 14 2080 env24268 = env24269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2080 env24268 == env24269) = true)

theorem identity24269 : scanCanonicalize (H12AffineFastState.compose env24269 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 7448) := by decide +kernel

theorem selectedBound24269 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env24270 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,7448,1261,2080,65536,4096,7441,1533,2081,4605,5188,492,72804,7568,444,7440,1297,1297,2049,4165,4294967296,252,4295035019,4604,136]

theorem envBound24270 : H12AffineFastState.Bounded env24270 := by
  intro p hp
  have h : env24270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24269_24270 : H12AffineEnvironment.transform 12 7448 env24269 = env24270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7448 env24269 == env24270) = true)

theorem identity24270 : scanCanonicalize (H12AffineFastState.compose env24270 (packedSelected [0,2,4,6,12] rootPS)) = affineNative (2^(11+1) ^^^ 1093) := by decide +kernel

theorem selectedBound24270 : packedSelected [0,2,4,6,12] rootPS < 2^1333 := by decide +kernel

def env24271 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,1093,2397,1261,2080,65536,1093,2388,1533,2081,1464,1,492,67617,2517,444,2389,1297,1297,2049,1024,4294967296,252,4295035019,1465,136]

theorem envBound24271 : H12AffineFastState.Bounded env24271 := by
  intro p hp
  have h : env24271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24270_24271 : H12AffineEnvironment.transform 11 1093 env24270 = env24271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1093 env24270 == env24271) = true)

def env24272 : List Nat := [2,4,8,16,32,64,128,84,136,1024,2048,1093,2057,1261,2080,65536,1093,2048,1193,2081,1260,1,184,67617,2177,232,2049,1093,1093,2049,1024,4294967296,252,4295035019,1261,136]

theorem envBound24272 : H12AffineFastState.Bounded env24272 := by
  intro p hp
  have h : env24272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24271_24272 : H12AffineEnvironment.transform 7 84 env24271 = env24272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env24271 == env24272) = true)

theorem identity24272 : scanCanonicalize (H12AffineFastState.compose env24272 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound24272 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24273 : List Nat := [2,4,8,16,32,64,88,84,80,1024,2048,1093,2057,1077,2080,65536,1093,2048,1137,2081,1076,1,96,67617,2137,48,2049,1093,1093,2049,1024,4294967296,36,4295034963,1077,80]

theorem envBound24273 : H12AffineFastState.Bounded env24273 := by
  intro p hp
  have h : env24273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24272_24273 : H12AffineEnvironment.transform 6 88 env24272 = env24273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env24272 == env24273) = true)

def env24274 : List Nat := [2,4,8,16,32,64,88,84,80,1024,32,1093,41,1077,0,65536,1093,32,1137,1,1076,1,96,65537,121,48,33,1093,1093,33,1024,4294967296,36,4295032947,1077,80]

theorem envBound24274 : H12AffineFastState.Bounded env24274 := by
  intro p hp
  have h : env24274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24273_24274 : H12AffineEnvironment.transform 10 32 env24273 = env24274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env24273 == env24274) = true)

theorem identity24274 : scanCanonicalize (H12AffineFastState.compose env24274 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 81) := by decide +kernel

theorem selectedBound24274 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24275 : List Nat := [2,4,8,16,32,64,88,84,80,1024,32,1093,41,1077,0,65536,1093,32,1137,1,1076,1,96,65537,121,48,33,1093,1093,33,1024,81,36,65570,1077,80]

theorem envBound24275 : H12AffineFastState.Bounded env24275 := by
  intro p hp
  have h : env24275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24274_24275 : H12AffineEnvironment.transform 31 81 env24274 = env24275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 81 env24274 == env24275) = true)

def env24276 : List Nat := [2,4,8,16,32,64,88,84,80,52,32,113,41,1,0,65536,113,32,69,1,0,1,96,65537,121,48,33,113,113,33,52,81,36,65570,1,80]

theorem envBound24276 : H12AffineFastState.Bounded env24276 := by
  intro p hp
  have h : env24276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24275_24276 : H12AffineEnvironment.transform 9 52 env24275 = env24276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env24275 == env24276) = true)

theorem identity24276 : scanCanonicalize (H12AffineFastState.compose env24276 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound24276 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24277 : List Nat := [2,4,8,16,26,64,88,84,80,14,26,75,19,1,0,65536,75,26,69,1,0,1,90,65537,67,10,27,75,75,27,14,81,30,65560,1,80]

theorem envBound24277 : H12AffineFastState.Bounded env24277 := by
  intro p hp
  have h : env24277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24276_24277 : H12AffineEnvironment.transform 4 26 env24276 = env24277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env24276 == env24277) = true)

def leafEnv24277 : List Nat := [2,4,8,16,26,64,88,84,80,14,26,75,19,1,0,65536,75,26,69,1,0,1,90,65537,69,67,1,10,27,75,75,27,14,81,30,65560,78,3,1,80,0,0,1]

def active24277 : List Nat := [0,1,2,3,5,15]

def tree24277 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24277 : H12WitnessSearch.Good tree24277 := H12GlobalWitnessIndex.good

theorem leafIdentity24277 : H12AffineFastState.composeSystem env24277 rootObs = leafEnv24277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24277 rootObs == leafEnv24277) = true)

theorem terminalChecked24277 : H12PackedTerminal.terminalCheckFast leafEnv24277 active24277 tree24277 = true := by decide +kernel

def env24278 : List Nat := [2,4,8,16,32,64,88,84,80,53,32,112,41,0,0,65536,112,32,68,1,1,1,96,65537,121,48,33,112,112,33,53,81,36,65570,0,80]

theorem envBound24278 : H12AffineFastState.Bounded env24278 := by
  intro p hp
  have h : env24278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24275_24278 : H12AffineEnvironment.transform 9 53 env24275 = env24278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env24275 == env24278) = true)

theorem identity24278 : scanCanonicalize (H12AffineFastState.compose env24278 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 105) := by decide +kernel

theorem selectedBound24278 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24279 : List Nat := [2,4,8,16,32,64,88,84,80,53,32,112,41,0,0,105,112,32,68,1,1,1,96,104,121,48,33,112,112,33,53,81,36,75,0,80]

theorem envBound24279 : H12AffineFastState.Bounded env24279 := by
  intro p hp
  have h : env24279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24278_24279 : H12AffineEnvironment.transform 15 105 env24278 = env24279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 105 env24278 == env24279) = true)

def leafEnv24279 : List Nat := [2,4,8,16,32,64,88,84,80,53,32,112,41,0,0,105,112,32,68,1,1,1,96,104,68,121,1,48,33,112,112,33,53,81,36,75,116,3,0,80,0,1,1]

def active24279 : List Nat := [0,1,2,3,4,5]

def tree24279 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24279 : H12WitnessSearch.Good tree24279 := H12GlobalWitnessIndex.good

theorem leafIdentity24279 : H12AffineFastState.composeSystem env24279 rootObs = leafEnv24279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24279 rootObs == leafEnv24279) = true)

theorem terminalChecked24279 : H12PackedTerminal.terminalCheckFast leafEnv24279 active24279 tree24279 = true := by decide +kernel

def env24280 : List Nat := [2,4,8,16,32,64,88,84,80,1024,33,1093,40,1077,1,65536,1093,33,1137,0,1076,1,96,65536,120,48,32,1093,1093,32,1024,4294967296,36,4295032946,1077,80]

theorem envBound24280 : H12AffineFastState.Bounded env24280 := by
  intro p hp
  have h : env24280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24273_24280 : H12AffineEnvironment.transform 10 33 env24273 = env24280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env24273 == env24280) = true)

theorem identity24280 : scanCanonicalize (H12AffineFastState.compose env24280 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 65538) := by decide +kernel

theorem selectedBound24280 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24281 : List Nat := [2,4,8,16,32,64,88,84,80,1024,33,1093,40,1077,1,65536,1093,33,1137,0,1076,1,96,65536,120,48,32,1093,1093,32,1024,65538,36,112,1077,80]

theorem envBound24281 : H12AffineFastState.Bounded env24281 := by
  intro p hp
  have h : env24281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24280_24281 : H12AffineEnvironment.transform 31 65538 env24280 = env24281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 65538 env24280 == env24281) = true)

def env24282 : List Nat := [2,4,8,16,32,64,88,84,80,20,33,81,40,33,1,65536,81,33,101,0,32,1,96,65536,120,48,32,81,81,32,20,65538,36,112,33,80]

theorem envBound24282 : H12AffineFastState.Bounded env24282 := by
  intro p hp
  have h : env24282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24281_24282 : H12AffineEnvironment.transform 9 20 env24281 = env24282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env24281 == env24282) = true)

theorem identity24282 : scanCanonicalize (H12AffineFastState.compose env24282 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound24282 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24283 : List Nat := [2,4,8,11,32,64,67,79,75,15,33,74,40,33,1,65536,74,33,101,0,32,1,96,65536,99,43,32,74,74,32,15,65538,36,107,33,75]

theorem envBound24283 : H12AffineFastState.Bounded env24283 := by
  intro p hp
  have h : env24283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24282_24283 : H12AffineEnvironment.transform 3 11 env24282 = env24283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env24282 == env24283) = true)

def env24284 : List Nat := [2,4,8,11,0,64,67,79,75,15,1,74,8,1,1,65536,74,1,69,0,0,1,64,65536,67,11,0,74,74,0,15,65538,4,75,1,75]

theorem envBound24284 : H12AffineFastState.Bounded env24284 := by
  intro p hp
  have h : env24284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24283_24284 : H12AffineEnvironment.transform 4 0 env24283 = env24284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env24283 == env24284) = true)

theorem identity24284 : scanCanonicalize (H12AffineFastState.compose env24284 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 72) := by decide +kernel

theorem selectedBound24284 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24285 : List Nat := [2,4,8,11,0,64,67,79,75,15,1,74,8,1,1,72,74,1,69,0,0,1,64,72,67,11,0,74,74,0,15,74,4,75,1,75]

theorem envBound24285 : H12AffineFastState.Bounded env24285 := by
  intro p hp
  have h : env24285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24284_24285 : H12AffineEnvironment.transform 15 72 env24284 = env24285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 72 env24284 == env24285) = true)

def leafEnv24285 : List Nat := [2,4,8,11,0,64,67,79,75,15,1,74,8,1,1,72,74,1,69,0,0,1,64,72,69,67,1,11,0,74,74,0,15,74,4,75,79,2,1,75,0,0,1]

def active24285 : List Nat := [0,1,2,5]

def tree24285 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24285 : H12WitnessSearch.Good tree24285 := H12GlobalWitnessIndex.good

theorem leafIdentity24285 : H12AffineFastState.composeSystem env24285 rootObs = leafEnv24285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24285 rootObs == leafEnv24285) = true)

theorem terminalChecked24285 : H12PackedTerminal.terminalCheckFast leafEnv24285 active24285 tree24285 = true := by decide +kernel

def env24286 : List Nat := [2,4,8,11,1,64,67,79,75,15,0,74,9,0,1,65536,74,0,68,0,1,1,65,65536,66,10,1,74,74,1,15,65538,5,74,0,75]

theorem envBound24286 : H12AffineFastState.Bounded env24286 := by
  intro p hp
  have h : env24286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24283_24286 : H12AffineEnvironment.transform 4 1 env24283 = env24286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24283 == env24286) = true)

def leafEnv24286 : List Nat := [2,4,8,11,1,64,67,79,75,15,0,74,9,0,1,65536,74,0,68,0,1,1,65,65536,68,66,1,10,1,74,74,1,15,65538,5,74,78,2,0,75,0,1,1]

def active24286 : List Nat := [0,1,2,5,15]

def tree24286 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24286 : H12WitnessSearch.Good tree24286 := H12GlobalWitnessIndex.good

theorem leafIdentity24286 : H12AffineFastState.composeSystem env24286 rootObs = leafEnv24286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24286 rootObs == leafEnv24286) = true)

theorem terminalChecked24286 : H12PackedTerminal.terminalCheckFast leafEnv24286 active24286 tree24286 = true := by decide +kernel

def env24287 : List Nat := [2,4,8,16,32,64,88,84,80,21,33,80,40,32,1,65536,80,33,100,0,33,1,96,65536,120,48,32,80,80,32,21,65538,36,112,32,80]

theorem envBound24287 : H12AffineFastState.Bounded env24287 := by
  intro p hp
  have h : env24287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24281_24287 : H12AffineEnvironment.transform 9 21 env24281 = env24287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env24281 == env24287) = true)

theorem identity24287 : scanCanonicalize (H12AffineFastState.compose env24287 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 73) := by decide +kernel

theorem selectedBound24287 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24288 : List Nat := [2,4,8,16,32,64,88,84,80,21,33,80,40,32,1,73,80,33,100,0,33,1,96,73,120,48,32,80,80,32,21,75,36,112,32,80]

theorem envBound24288 : H12AffineFastState.Bounded env24288 := by
  intro p hp
  have h : env24288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24287_24288 : H12AffineEnvironment.transform 15 73 env24287 = env24288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 73 env24287 == env24288) = true)

def env24289 : List Nat := [2,4,8,16,0,64,88,84,80,21,1,80,8,0,1,73,80,1,68,0,1,1,64,73,88,16,0,80,80,0,21,75,4,80,0,80]

theorem envBound24289 : H12AffineFastState.Bounded env24289 := by
  intro p hp
  have h : env24289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24288_24289 : H12AffineEnvironment.transform 4 0 env24288 = env24289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env24288 == env24289) = true)

theorem identity24289 : scanCanonicalize (H12AffineFastState.compose env24289 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound24289 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env24290 : List Nat := [2,4,8,10,0,64,66,78,74,15,1,74,8,0,1,73,74,1,68,0,1,1,64,73,66,10,0,74,74,0,15,75,4,74,0,74]

theorem envBound24290 : H12AffineFastState.Bounded env24290 := by
  intro p hp
  have h : env24290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24289_24290 : H12AffineEnvironment.transform 3 10 env24289 = env24290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env24289 == env24290) = true)

def leafEnv24290 : List Nat := [2,4,8,10,0,64,66,78,74,15,1,74,8,0,1,73,74,1,68,0,1,1,64,73,68,66,1,10,0,74,74,0,15,75,4,74,78,2,0,74,0,1,1]

def active24290 : List Nat := [0,1,2,5]

def tree24290 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24290 : H12WitnessSearch.Good tree24290 := H12GlobalWitnessIndex.good

theorem leafIdentity24290 : H12AffineFastState.composeSystem env24290 rootObs = leafEnv24290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24290 rootObs == leafEnv24290) = true)

theorem terminalChecked24290 : H12PackedTerminal.terminalCheckFast leafEnv24290 active24290 tree24290 = true := by decide +kernel

def env24291 : List Nat := [2,4,8,16,1,64,88,84,80,21,0,80,9,1,1,73,80,0,69,0,0,1,65,73,89,17,1,80,80,1,21,75,5,81,1,80]

theorem envBound24291 : H12AffineFastState.Bounded env24291 := by
  intro p hp
  have h : env24291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24288_24291 : H12AffineEnvironment.transform 4 1 env24288 = env24291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env24288 == env24291) = true)

def leafEnv24291 : List Nat := [2,4,8,16,1,64,88,84,80,21,0,80,9,1,1,73,80,0,69,0,0,1,65,73,69,89,1,17,1,80,80,1,21,75,5,81,85,2,1,80,0,0,1]

def active24291 : List Nat := [0,1,2,3,5]

def tree24291 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood24291 : H12WitnessSearch.Good tree24291 := H12GlobalWitnessIndex.good

theorem leafIdentity24291 : H12AffineFastState.composeSystem env24291 rootObs = leafEnv24291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env24291 rootObs == leafEnv24291) = true)

theorem terminalChecked24291 : H12PackedTerminal.terminalCheckFast leafEnv24291 active24291 tree24291 = true := by decide +kernel

def env24292 : List Nat := [2,4,8,16,32,64,128,85,136,1024,2048,1093,2056,1261,2080,65536,1093,2049,1192,2081,1261,1,185,67617,2176,233,2048,1092,1092,2049,1024,4294967296,252,4295035019,1260,136]

theorem envBound24292 : H12AffineFastState.Bounded env24292 := by
  intro p hp
  have h : env24292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24271_24292 : H12AffineEnvironment.transform 7 85 env24271 = env24292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env24271 == env24292) = true)

theorem identity24292 : scanCanonicalize (H12AffineFastState.compose env24292 (packedSelected [1,3] rootPS)) = affineNative (2^(15+1) ^^^ 2163) := by decide +kernel

theorem selectedBound24292 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env24293 : List Nat := [2,4,8,16,32,64,128,85,136,1024,2048,1093,2056,1261,2080,2163,1093,2049,1192,2081,1261,1,185,82,2176,233,2048,1092,1092,2049,1024,4294967296,252,4294967544,1260,136]

theorem envBound24293 : H12AffineFastState.Bounded env24293 := by
  intro p hp
  have h : env24293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24292_24293 : H12AffineEnvironment.transform 15 2163 env24292 = env24293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2163 env24292 == env24293) = true)

def env24294 : List Nat := [2,4,8,16,32,64,128,85,136,1024,80,1093,88,1261,112,35,1093,81,1192,113,1261,1,185,82,208,233,80,1092,1092,81,1024,4294967296,252,4294967544,1260,136]

theorem envBound24294 : H12AffineFastState.Bounded env24294 := by
  intro p hp
  have h : env24294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24293_24294 : H12AffineEnvironment.transform 10 80 env24293 = env24294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env24293 == env24294) = true)

theorem identity24294 : scanCanonicalize (H12AffineFastState.compose env24294 (packedSelected [0] rootPS)) = affineNative (2^(31+1) ^^^ 136) := by decide +kernel

theorem selectedBound24294 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env24295 : List Nat := [2,4,8,16,32,64,128,85,136,1024,80,1093,88,1261,112,35,1093,81,1192,113,1261,1,185,82,208,233,80,1092,1092,81,1024,136,252,112,1260,136]

theorem envBound24295 : H12AffineFastState.Bounded env24295 := by
  intro p hp
  have h : env24295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24294_24295 : H12AffineEnvironment.transform 31 136 env24294 = env24295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 136 env24294 == env24295) = true)

def env24296 : List Nat := [2,4,8,16,32,64,88,85,80,1024,80,1093,88,1077,112,35,1093,81,1136,113,1077,1,97,82,8,49,80,1092,1092,81,1024,80,36,112,1076,80]

theorem envBound24296 : H12AffineFastState.Bounded env24296 := by
  intro p hp
  have h : env24296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24295_24296 : H12AffineEnvironment.transform 6 88 env24295 = env24296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env24295 == env24296) = true)

theorem identity24296 : scanCanonicalize (H12AffineFastState.compose env24296 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound24296 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env24297 : List Nat := [2,4,8,16,32,10,18,31,26,1024,26,1039,18,1077,58,35,1039,27,1082,59,1077,1,43,24,8,49,26,1038,1038,27,1024,26,36,58,1076,26]

theorem envBound24297 : H12AffineFastState.Bounded env24297 := by
  intro p hp
  have h : env24297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans24296_24297 : H12AffineEnvironment.transform 5 10 env24296 = env24297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env24296 == env24297) = true)

theorem identity24297 : scanCanonicalize (H12AffineFastState.compose env24297 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound24297 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

end H12CloudChart2