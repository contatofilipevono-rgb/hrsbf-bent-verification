import H12CloudChart2Data165

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound41507 : H12AffineFastState.Bounded env41507 := by
  intro p hp
  have h : env41507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41506_41507 : H12AffineEnvironment.transform 10 863 env41506 = env41507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 863 env41506 == env41507) = true)

theorem identity41507 : scanCanonicalize (H12AffineFastState.compose env41507 (packedSelected [0,1,2,4,7,8,9,12,13] rootPS)) = affineNative (2^(9+1) ^^^ 127) := by decide +kernel

theorem selectedBound41507 : packedSelected [0,1,2,4,7,8,9,12,13] rootPS < 2^1333 := by decide +kernel

def env41508 : List Nat := [2,4,8,16,32,64,105,256,512,127,863,324,25,366,318,89,81,49,4,319,324,309,382,268,2,341,123,0,367,878,21,382,257,383,318,635]

theorem envBound41508 : H12AffineFastState.Bounded env41508 := by
  intro p hp
  have h : env41508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41507_41508 : H12AffineEnvironment.transform 9 127 env41507 = env41508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 127 env41507 == env41508) = true)

theorem identity41508 : scanCanonicalize (H12AffineFastState.compose env41508 (packedSelected [0,1,2,4,7,9,12] rootPS)) = affineNative (2^(7+1) ^^^ 120) := by decide +kernel

theorem selectedBound41508 : packedSelected [0,1,2,4,7,9,12] rootPS < 2^1333 := by decide +kernel

def env41509 : List Nat := [2,4,8,16,32,64,105,120,512,127,551,60,25,22,70,89,81,49,4,71,60,77,6,116,2,45,123,0,23,534,21,6,121,7,70,635]

theorem envBound41509 : H12AffineFastState.Bounded env41509 := by
  intro p hp
  have h : env41509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41508_41509 : H12AffineEnvironment.transform 7 120 env41508 = env41509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 120 env41508 == env41509) = true)

theorem identity41509 : scanCanonicalize (H12AffineFastState.compose env41509 (packedSelected [0,2,3,7,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 7) := by decide +kernel

theorem selectedBound41509 : packedSelected [0,2,3,7,15,16] rootPS < 2^1333 := by decide +kernel

def env41510 : List Nat := [2,4,8,16,32,7,46,63,512,56,551,60,25,22,1,30,22,49,4,0,60,10,6,51,2,45,60,0,23,534,21,6,62,7,1,572]

theorem envBound41510 : H12AffineFastState.Bounded env41510 := by
  intro p hp
  have h : env41510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41509_41510 : H12AffineEnvironment.transform 5 7 env41509 = env41510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 7 env41509 == env41510) = true)

theorem identity41510 : scanCanonicalize (H12AffineFastState.compose env41510 (packedSelected [2,3,5,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound41510 : packedSelected [2,3,5,7,9] rootPS < 2^1333 := by decide +kernel

def env41511 : List Nat := [2,4,8,16,32,7,46,63,49,56,22,60,25,22,1,30,22,49,4,0,60,10,6,51,2,45,60,0,23,39,21,6,62,7,1,13]

theorem envBound41511 : H12AffineFastState.Bounded env41511 := by
  intro p hp
  have h : env41511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41510_41511 : H12AffineEnvironment.transform 8 49 env41510 = env41511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env41510 == env41511) = true)

theorem identity41511 : scanCanonicalize (H12AffineFastState.compose env41511 (packedSelected [1,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound41511 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env41512 : List Nat := [2,4,8,16,16,7,30,15,1,8,22,12,25,22,1,30,22,1,4,0,12,10,6,3,2,29,12,0,23,23,21,6,14,7,1,13]

theorem envBound41512 : H12AffineFastState.Bounded env41512 := by
  intro p hp
  have h : env41512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41511_41512 : H12AffineEnvironment.transform 4 16 env41511 = env41512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env41511 == env41512) = true)

theorem identity41512 : scanCanonicalize (H12AffineFastState.compose env41512 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound41512 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41513 : List Nat := [2,4,8,10,10,7,4,15,1,8,12,12,3,12,1,4,12,1,4,0,12,10,6,3,2,7,12,0,13,13,15,6,14,7,1,13]

theorem envBound41513 : H12AffineFastState.Bounded env41513 := by
  intro p hp
  have h : env41513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41512_41513 : H12AffineEnvironment.transform 3 10 env41512 = env41513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env41512 == env41513) = true)

theorem identity41513 : scanCanonicalize (H12AffineFastState.compose env41513 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound41513 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41514 : List Nat := [2,4,4,6,6,7,4,3,1,4,0,0,3,0,1,4,0,1,4,0,0,6,6,3,2,7,0,0,1,1,3,6,2,7,1,1]

theorem envBound41514 : H12AffineFastState.Bounded env41514 := by
  intro p hp
  have h : env41514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41513_41514 : H12AffineEnvironment.transform 2 4 env41513 = env41514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env41513 == env41514) = true)

def env41515 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,524288,32769,4096,61649,91183,123165,533641,614527,385202,90414,545089,96347,25884,82999,257,545105,1345,525824]

theorem envBound41515 : H12AffineFastState.Bounded env41515 := by
  intro p hp
  have h : env41515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41314_41515 : H12AffineEnvironment.transform 23 123165 env41314 = env41515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 123165 env41314 == env41515) = true)

def env41516 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,74862,262144,21584,32769,4096,61649,91183,123165,28889,78895,385202,90414,1297,96347,25884,82999,257,1281,1345,21072]

theorem envBound41516 : H12AffineFastState.Bounded env41516 := by
  intro p hp
  have h : env41516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41515_41516 : H12AffineEnvironment.transform 18 21584 env41515 = env41516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21584 env41515 == env41516) = true)

theorem identity41516 : scanCanonicalize (H12AffineFastState.compose env41516 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 25677) := by decide +kernel

theorem selectedBound41516 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env41517 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,25677,65536,74862,262144,21584,25676,4096,5276,91183,66896,28889,78895,328959,90414,1297,96347,25884,82999,257,1281,1345,21072]

theorem envBound41517 : H12AffineFastState.Bounded env41517 := by
  intro p hp
  have h : env41517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41516_41517 : H12AffineEnvironment.transform 14 25677 env41516 = env41517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25677 env41516 == env41517) = true)

def env41518 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74862,262144,4416,8540,4096,5276,74047,66896,13769,78895,328959,74814,1297,81227,8204,65831,257,1281,1345,5952]

theorem envBound41518 : H12AffineFastState.Bounded env41518 := by
  intro p hp
  have h : env41518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41517_41518 : H12AffineEnvironment.transform 13 1296 env41517 = env41518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env41517 == env41518) = true)

def env41519 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74862,65664,4416,8540,4096,5276,74047,66896,13769,78895,1151,74814,1297,81227,8204,65831,257,1281,1345,5952]

theorem envBound41519 : H12AffineFastState.Bounded env41519 := by
  intro p hp
  have h : env41519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41518_41519 : H12AffineEnvironment.transform 17 65664 env41518 = env41519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env41518 == env41519) = true)

theorem identity41519 : scanCanonicalize (H12AffineFastState.compose env41519 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5464) := by decide +kernel

theorem selectedBound41519 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env41520 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5464,1296,5125,65536,69942,65664,4416,5124,4096,5276,70759,66896,145,65911,1151,69990,1297,67603,5460,65831,257,1281,1345,5952]

theorem envBound41520 : H12AffineFastState.Bounded env41520 := by
  intro p hp
  have h : env41520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41519_41520 : H12AffineEnvironment.transform 12 5464 env41519 = env41520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5464 env41519 == env41520) = true)

def env41521 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1556,844,1296,529,65536,67362,65664,1876,528,1556,648,66163,66896,145,65911,1151,67442,1297,67603,832,65831,257,1281,1345,340]

theorem envBound41521 : H12AffineFastState.Bounded env41521 := by
  intro p hp
  have h : env41521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41520_41521 : H12AffineEnvironment.transform 11 1556 env41520 = env41521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env41520 == env41521) = true)

def env41522 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,836,844,64,529,65536,66162,65664,516,528,836,648,66163,65536,145,65911,303,66082,65,67603,832,65831,257,81,17,340]

theorem envBound41522 : H12AffineFastState.Bounded env41522 := by
  intro p hp
  have h : env41522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41521_41522 : H12AffineEnvironment.transform 9 336 env41521 = env41522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env41521 == env41522) = true)

theorem identity41522 : scanCanonicalize (H12AffineFastState.compose env41522 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 187) := by decide +kernel

theorem selectedBound41522 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env41523 : List Nat := [2,4,8,16,32,64,128,187,512,235,2048,767,759,64,529,65536,66162,65664,516,528,767,648,66163,65536,145,65740,148,66082,65,67603,763,65692,186,81,17,239]

theorem envBound41523 : H12AffineFastState.Bounded env41523 := by
  intro p hp
  have h : env41523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41522_41523 : H12AffineEnvironment.transform 7 187 env41522 = env41523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 187 env41522 == env41523) = true)

def env41524 : List Nat := [2,4,8,16,32,0,128,187,512,171,2048,703,695,0,529,65536,66098,65664,516,528,703,648,66099,65536,145,65676,148,66082,1,67603,699,65692,186,17,17,175]

theorem envBound41524 : H12AffineFastState.Bounded env41524 := by
  intro p hp
  have h : env41524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41523_41524 : H12AffineEnvironment.transform 5 0 env41523 = env41524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env41523 == env41524) = true)

theorem identity41524 : scanCanonicalize (H12AffineFastState.compose env41524 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 668) := by decide +kernel

theorem selectedBound41524 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env41525 : List Nat := [2,4,8,16,32,0,128,187,512,171,2048,703,695,0,529,668,174,540,516,528,703,648,175,668,145,528,148,190,1,2703,699,512,186,17,17,175]

theorem envBound41525 : H12AffineFastState.Bounded env41525 := by
  intro p hp
  have h : env41525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41524_41525 : H12AffineEnvironment.transform 15 668 env41524 = env41525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 668 env41524 == env41525) = true)

theorem identity41525 : scanCanonicalize (H12AffineFastState.compose env41525 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound41525 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env41526 : List Nat := [2,4,8,1,32,0,128,170,512,171,2048,686,678,0,512,653,174,525,516,513,686,648,175,653,128,513,133,175,1,2703,682,512,171,0,0,175]

theorem envBound41526 : H12AffineFastState.Bounded env41526 := by
  intro p hp
  have h : env41526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41525_41526 : H12AffineEnvironment.transform 3 1 env41525 = env41526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env41525 == env41526) = true)

theorem identity41526 : scanCanonicalize (H12AffineFastState.compose env41526 (packedSelected [1,2,3,5,13] rootPS)) = affineNative (2^(10+1) ^^^ 7) := by decide +kernel

theorem selectedBound41526 : packedSelected [1,2,3,5,13] rootPS < 2^1333 := by decide +kernel

def env41527 : List Nat := [2,4,8,1,32,0,128,170,512,171,7,686,678,0,512,653,174,525,516,513,686,648,175,653,128,513,133,175,1,648,682,512,171,0,0,175]

theorem envBound41527 : H12AffineFastState.Bounded env41527 := by
  intro p hp
  have h : env41527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41526_41527 : H12AffineEnvironment.transform 10 7 env41526 = env41527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 7 env41526 == env41527) = true)

theorem identity41527 : scanCanonicalize (H12AffineFastState.compose env41527 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound41527 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41528 : List Nat := [2,4,8,1,32,0,8,34,512,35,7,550,558,0,512,517,38,525,516,513,550,512,39,517,8,513,13,39,1,512,546,512,35,0,0,39]

theorem envBound41528 : H12AffineFastState.Bounded env41528 := by
  intro p hp
  have h : env41528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41527_41528 : H12AffineEnvironment.transform 6 8 env41527 = env41528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env41527 == env41528) = true)

theorem identity41528 : scanCanonicalize (H12AffineFastState.compose env41528 (packedSelected [0,1,3,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 44) := by decide +kernel

theorem selectedBound41528 : packedSelected [0,1,3,7,8] rootPS < 2^1333 := by decide +kernel

def env41529 : List Nat := [2,4,8,1,32,0,8,34,44,35,7,10,2,0,44,41,38,33,40,45,10,44,39,41,8,45,13,39,1,44,14,44,35,0,0,39]

theorem envBound41529 : H12AffineFastState.Bounded env41529 := by
  intro p hp
  have h : env41529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41528_41529 : H12AffineEnvironment.transform 8 44 env41528 = env41529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 44 env41528 == env41529) = true)

theorem identity41529 : scanCanonicalize (H12AffineFastState.compose env41529 (packedSelected [0,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound41529 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env41530 : List Nat := [2,4,8,1,1,0,8,3,13,2,7,10,2,0,13,8,7,0,9,12,10,13,6,8,8,12,13,6,1,13,14,13,2,0,0,6]

theorem envBound41530 : H12AffineFastState.Bounded env41530 := by
  intro p hp
  have h : env41530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41529_41530 : H12AffineEnvironment.transform 4 1 env41529 = env41530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env41529 == env41530) = true)

theorem identity41530 : scanCanonicalize (H12AffineFastState.compose env41530 (packedSelected [1,3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound41530 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41531 : List Nat := [2,3,8,1,1,0,8,3,10,2,0,10,2,0,10,8,0,0,9,11,10,10,1,8,8,11,10,1,1,10,9,10,2,0,0,1]

theorem envBound41531 : H12AffineFastState.Bounded env41531 := by
  intro p hp
  have h : env41531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41530_41531 : H12AffineEnvironment.transform 1 3 env41530 = env41531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env41530 == env41531) = true)

theorem identity41531 : scanCanonicalize (H12AffineFastState.compose env41531 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound41531 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41532 : List Nat := [2,3,2,1,1,0,2,3,0,2,0,0,2,0,0,2,0,0,3,1,0,0,1,2,2,1,0,1,1,0,3,0,2,0,0,1]

theorem envBound41532 : H12AffineFastState.Bounded env41532 := by
  intro p hp
  have h : env41532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41531_41532 : H12AffineEnvironment.transform 2 2 env41531 = env41532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env41531 == env41532) = true)

theorem identity41532 : scanCanonicalize (H12AffineFastState.compose env41532 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound41532 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41533 : List Nat := [0,1,0,1,1,0,0,1,0,0,0,0,0,0,0,0,0,0,1,1,0,0,1,0,0,1,0,1,1,0,1,0,0,0,0,1]

theorem envBound41533 : H12AffineFastState.Bounded env41533 := by
  intro p hp
  have h : env41533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41532_41533 : H12AffineEnvironment.transform 0 0 env41532 = env41533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env41532 == env41533) = true)

def env41534 : List Nat := [2,4,8,16,32,1,128,187,512,170,2048,702,694,1,529,65536,66099,65664,516,528,702,648,66098,65536,145,65677,148,66082,0,67603,698,65692,186,16,17,174]

theorem envBound41534 : H12AffineFastState.Bounded env41534 := by
  intro p hp
  have h : env41534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41523_41534 : H12AffineEnvironment.transform 5 1 env41523 = env41534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env41523 == env41534) = true)

theorem identity41534 : scanCanonicalize (H12AffineFastState.compose env41534 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 51) := by decide +kernel

theorem selectedBound41534 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env41535 : List Nat := [2,4,8,16,32,1,128,187,512,170,2048,702,694,1,529,51,512,179,516,528,702,648,513,51,145,190,148,529,0,2080,698,175,186,16,17,174]

theorem envBound41535 : H12AffineFastState.Bounded env41535 := by
  intro p hp
  have h : env41535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41534_41535 : H12AffineEnvironment.transform 15 51 env41534 = env41535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 51 env41534 == env41535) = true)

theorem identity41535 : scanCanonicalize (H12AffineFastState.compose env41535 (packedSelected [13,21] rootPS)) = affineNative (2^(6+1) ^^^ 46) := by decide +kernel

theorem selectedBound41535 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env41536 : List Nat := [2,4,8,16,32,1,46,21,512,4,2048,528,536,1,529,51,512,29,516,528,528,550,513,51,63,16,58,529,0,2080,532,1,20,16,17,0]

theorem envBound41536 : H12AffineFastState.Bounded env41536 := by
  intro p hp
  have h : env41536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41535_41536 : H12AffineEnvironment.transform 6 46 env41535 = env41536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 46 env41535 == env41536) = true)

theorem identity41536 : scanCanonicalize (H12AffineFastState.compose env41536 (packedSelected [10] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound41536 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env41537 : List Nat := [2,4,8,13,32,1,46,8,512,4,2048,525,517,1,524,46,512,0,516,525,525,550,513,46,34,13,39,524,0,2080,521,1,9,13,12,0]

theorem envBound41537 : H12AffineFastState.Bounded env41537 := by
  intro p hp
  have h : env41537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41536_41537 : H12AffineEnvironment.transform 3 13 env41536 = env41537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env41536 == env41537) = true)

theorem identity41537 : scanCanonicalize (H12AffineFastState.compose env41537 (packedSelected [0,5,7,11,13] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound41537 : packedSelected [0,5,7,11,13] rootPS < 2^1333 := by decide +kernel

def env41538 : List Nat := [2,4,8,13,32,1,46,8,32,4,2048,45,37,1,44,46,32,0,36,45,45,6,33,46,34,13,39,44,0,2080,41,1,9,13,12,0]

theorem envBound41538 : H12AffineFastState.Bounded env41538 := by
  intro p hp
  have h : env41538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41537_41538 : H12AffineEnvironment.transform 8 32 env41537 = env41538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env41537 == env41538) = true)

theorem identity41538 : scanCanonicalize (H12AffineFastState.compose env41538 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound41538 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env41539 : List Nat := [2,4,8,13,32,1,46,8,32,4,0,45,37,1,44,46,32,0,36,45,45,6,33,46,34,13,39,44,0,32,41,1,9,13,12,0]

theorem envBound41539 : H12AffineFastState.Bounded env41539 := by
  intro p hp
  have h : env41539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41538_41539 : H12AffineEnvironment.transform 10 0 env41538 = env41539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env41538 == env41539) = true)

theorem identity41539 : scanCanonicalize (H12AffineFastState.compose env41539 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound41539 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41540 : List Nat := [2,4,5,0,32,1,35,5,32,4,0,32,37,1,33,35,32,0,36,32,32,6,33,35,34,0,39,33,0,32,36,1,4,0,1,0]

theorem envBound41540 : H12AffineFastState.Bounded env41540 := by
  intro p hp
  have h : env41540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41539_41540 : H12AffineEnvironment.transform 2 5 env41539 = env41540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env41539 == env41540) = true)

theorem identity41540 : scanCanonicalize (H12AffineFastState.compose env41540 (packedSelected [1,3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound41540 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41541 : List Nat := [2,3,2,0,32,1,35,2,32,3,0,32,34,1,33,35,32,0,35,32,32,1,33,35,34,0,32,33,0,32,35,1,3,0,1,0]

theorem envBound41541 : H12AffineFastState.Bounded env41541 := by
  intro p hp
  have h : env41541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41540_41541 : H12AffineEnvironment.transform 1 3 env41540 = env41541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env41540 == env41541) = true)

theorem identity41541 : scanCanonicalize (H12AffineFastState.compose env41541 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound41541 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41542 : List Nat := [2,3,2,0,1,1,2,2,1,3,0,1,3,1,0,2,1,0,2,1,1,1,0,2,3,0,1,0,0,1,2,1,3,0,1,0]

theorem envBound41542 : H12AffineFastState.Bounded env41542 := by
  intro p hp
  have h : env41542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41541_41542 : H12AffineEnvironment.transform 4 1 env41541 = env41542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env41541 == env41542) = true)

theorem identity41542 : scanCanonicalize (H12AffineFastState.compose env41542 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound41542 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41543 : List Nat := [1,0,1,0,1,1,1,1,1,0,0,1,0,1,0,1,1,0,1,1,1,1,0,1,0,0,1,0,0,1,1,1,0,0,1,0]

theorem envBound41543 : H12AffineFastState.Bounded env41543 := by
  intro p hp
  have h : env41543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41542_41543 : H12AffineEnvironment.transform 0 1 env41542 = env41543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env41542 == env41543) = true)

def env41544 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,837,844,65,529,65536,66163,65664,517,528,837,648,66163,65537,145,65911,302,66083,64,67603,832,65831,257,80,16,340]

theorem envBound41544 : H12AffineFastState.Bounded env41544 := by
  intro p hp
  have h : env41544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41521_41544 : H12AffineEnvironment.transform 9 337 env41521 = env41544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env41521 == env41544) = true)

theorem identity41544 : scanCanonicalize (H12AffineFastState.compose env41544 (packedSelected [1,8,28] rootPS)) = affineNative (2^(8+1) ^^^ 175) := by decide +kernel

theorem selectedBound41544 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env41545 : List Nat := [2,4,8,16,32,64,128,256,175,337,2048,490,483,65,190,65536,65756,65664,170,191,490,39,65756,65537,145,65911,302,65676,64,67603,495,65831,257,80,16,340]

theorem envBound41545 : H12AffineFastState.Bounded env41545 := by
  intro p hp
  have h : env41545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41544_41545 : H12AffineEnvironment.transform 8 175 env41544 = env41545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 175 env41544 == env41545) = true)

def env41546 : List Nat := [2,4,8,16,32,0,128,256,175,273,2048,426,419,1,190,65536,65692,65664,170,191,426,39,65692,65537,145,65847,302,65676,0,67603,431,65831,257,16,16,276]

theorem envBound41546 : H12AffineFastState.Bounded env41546 := by
  intro p hp
  have h : env41546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41545_41546 : H12AffineEnvironment.transform 5 0 env41545 = env41546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env41545 == env41546) = true)

theorem identity41546 : scanCanonicalize (H12AffineFastState.compose env41546 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 50) := by decide +kernel

theorem selectedBound41546 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env41547 : List Nat := [2,4,8,16,32,0,128,256,175,273,2048,426,419,1,190,50,174,178,170,191,426,39,174,51,145,261,302,190,0,2081,431,277,257,16,16,276]

theorem envBound41547 : H12AffineFastState.Bounded env41547 := by
  intro p hp
  have h : env41547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41546_41547 : H12AffineEnvironment.transform 15 50 env41546 = env41547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50 env41546 == env41547) = true)

theorem identity41547 : scanCanonicalize (H12AffineFastState.compose env41547 (packedSelected [13,21] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound41547 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env41548 : List Nat := [2,4,8,16,32,0,128,21,175,4,2048,191,182,1,190,50,174,178,170,191,191,39,174,51,145,16,59,190,0,2081,186,0,20,16,16,1]

theorem envBound41548 : H12AffineFastState.Bounded env41548 := by
  intro p hp
  have h : env41548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41547_41548 : H12AffineEnvironment.transform 7 21 env41547 = env41548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env41547 == env41548) = true)

theorem identity41548 : scanCanonicalize (H12AffineFastState.compose env41548 (packedSelected [10] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound41548 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env41549 : List Nat := [2,4,8,12,32,0,128,9,175,4,2048,163,170,1,162,46,174,174,170,163,163,39,174,47,141,12,39,162,0,2081,166,0,8,12,12,1]

theorem envBound41549 : H12AffineFastState.Bounded env41549 := by
  intro p hp
  have h : env41549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41548_41549 : H12AffineEnvironment.transform 3 12 env41548 = env41549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env41548 == env41549) = true)

theorem identity41549 : scanCanonicalize (H12AffineFastState.compose env41549 (packedSelected [2,3,8,12,13] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound41549 : packedSelected [2,3,8,12,13] rootPS < 2^1333 := by decide +kernel

def env41550 : List Nat := [2,4,8,12,0,0,128,9,143,4,2048,131,138,1,130,14,142,142,138,131,131,7,142,15,141,12,7,130,0,2049,134,0,8,12,12,1]

theorem envBound41550 : H12AffineFastState.Bounded env41550 := by
  intro p hp
  have h : env41550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41549_41550 : H12AffineEnvironment.transform 4 0 env41549 = env41550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env41549 == env41550) = true)

theorem identity41550 : scanCanonicalize (H12AffineFastState.compose env41550 (packedSelected [1,2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 130) := by decide +kernel

theorem selectedBound41550 : packedSelected [1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env41551 : List Nat := [2,4,8,12,0,0,128,9,143,4,130,131,138,1,130,14,142,142,138,131,131,7,142,15,141,12,7,130,0,131,134,0,8,12,12,1]

theorem envBound41551 : H12AffineFastState.Bounded env41551 := by
  intro p hp
  have h : env41551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41550_41551 : H12AffineEnvironment.transform 10 130 env41550 = env41551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 130 env41550 == env41551) = true)

theorem identity41551 : scanCanonicalize (H12AffineFastState.compose env41551 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound41551 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41552 : List Nat := [2,4,4,0,0,0,128,5,131,4,130,131,134,1,130,2,130,130,134,131,131,7,130,3,129,0,7,130,0,131,134,0,4,0,0,1]

theorem envBound41552 : H12AffineFastState.Bounded env41552 := by
  intro p hp
  have h : env41552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41551_41552 : H12AffineEnvironment.transform 2 4 env41551 = env41552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env41551 == env41552) = true)

theorem identity41552 : scanCanonicalize (H12AffineFastState.compose env41552 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 2) := by decide +kernel

theorem selectedBound41552 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41553 : List Nat := [2,4,4,0,0,0,2,5,1,4,0,1,4,1,0,2,0,0,4,1,1,7,0,3,3,0,7,0,0,1,4,0,4,0,0,1]

theorem envBound41553 : H12AffineFastState.Bounded env41553 := by
  intro p hp
  have h : env41553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41552_41553 : H12AffineEnvironment.transform 6 2 env41552 = env41553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 2 env41552 == env41553) = true)

def env41554 : List Nat := [2,4,8,16,32,1,128,256,175,272,2048,427,418,0,190,65536,65693,65664,170,191,427,39,65693,65537,145,65846,302,65676,1,67603,430,65831,257,17,16,277]

theorem envBound41554 : H12AffineFastState.Bounded env41554 := by
  intro p hp
  have h : env41554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41545_41554 : H12AffineEnvironment.transform 5 1 env41545 = env41554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env41545 == env41554) = true)

theorem identity41554 : scanCanonicalize (H12AffineFastState.compose env41554 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 392) := by decide +kernel

theorem selectedBound41554 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env41555 : List Nat := [2,4,8,16,32,1,128,256,175,272,2048,427,418,0,190,392,277,264,170,191,427,39,277,393,145,190,302,260,1,2459,430,175,257,17,16,277]

theorem envBound41555 : H12AffineFastState.Bounded env41555 := by
  intro p hp
  have h : env41555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41554_41555 : H12AffineEnvironment.transform 15 392 env41554 = env41555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 392 env41554 == env41555) = true)

theorem identity41555 : scanCanonicalize (H12AffineFastState.compose env41555 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound41555 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env41556 : List Nat := [2,4,8,0,32,1,128,256,175,256,2048,427,418,0,174,392,261,264,170,175,427,39,261,393,129,174,302,260,1,2443,430,175,257,1,0,261]

theorem envBound41556 : H12AffineFastState.Bounded env41556 := by
  intro p hp
  have h : env41556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41555_41556 : H12AffineEnvironment.transform 3 0 env41555 = env41556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env41555 == env41556) = true)

theorem identity41556 : scanCanonicalize (H12AffineFastState.compose env41556 (packedSelected [1,2,3,5,13] rootPS)) = affineNative (2^(10+1) ^^^ 428) := by decide +kernel

theorem selectedBound41556 : packedSelected [1,2,3,5,13] rootPS < 2^1333 := by decide +kernel

def env41557 : List Nat := [2,4,8,0,32,1,128,256,175,256,428,427,418,0,174,392,261,264,170,175,427,39,261,393,129,174,302,260,1,39,430,175,257,1,0,261]

theorem envBound41557 : H12AffineFastState.Bounded env41557 := by
  intro p hp
  have h : env41557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41556_41557 : H12AffineEnvironment.transform 10 428 env41556 = env41557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 428 env41556 == env41557) = true)

theorem identity41557 : scanCanonicalize (H12AffineFastState.compose env41557 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 34) := by decide +kernel

theorem selectedBound41557 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41558 : List Nat := [2,4,8,0,32,1,128,34,175,34,142,137,128,0,174,170,39,42,170,175,137,39,39,171,129,174,12,38,1,39,140,175,35,1,0,39]

theorem envBound41558 : H12AffineFastState.Bounded env41558 := by
  intro p hp
  have h : env41558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41557_41558 : H12AffineEnvironment.transform 7 34 env41557 = env41558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 34 env41557 == env41558) = true)

theorem identity41558 : scanCanonicalize (H12AffineFastState.compose env41558 (packedSelected [0,1,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound41558 : packedSelected [0,1,5,7] rootPS < 2^1333 := by decide +kernel

def env41559 : List Nat := [2,4,8,0,32,1,3,34,44,34,13,10,3,0,45,41,39,42,41,44,10,39,39,40,2,45,12,38,1,39,15,44,35,1,0,39]

theorem envBound41559 : H12AffineFastState.Bounded env41559 := by
  intro p hp
  have h : env41559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41558_41559 : H12AffineEnvironment.transform 6 3 env41558 = env41559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env41558 == env41559) = true)

theorem identity41559 : scanCanonicalize (H12AffineFastState.compose env41559 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound41559 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env41560 : List Nat := [2,4,8,0,7,1,3,5,11,5,13,10,3,0,10,14,0,13,14,11,10,0,0,15,2,10,12,1,1,0,15,11,4,1,0,0]

theorem envBound41560 : H12AffineFastState.Bounded env41560 := by
  intro p hp
  have h : env41560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41559_41560 : H12AffineEnvironment.transform 4 7 env41559 = env41560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env41559 == env41560) = true)

theorem identity41560 : scanCanonicalize (H12AffineFastState.compose env41560 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound41560 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env41561 : List Nat := [2,4,3,0,7,1,3,5,0,5,6,1,3,0,1,5,0,6,5,0,1,0,0,4,2,1,7,1,1,0,4,0,4,1,0,0]

theorem envBound41561 : H12AffineFastState.Bounded env41561 := by
  intro p hp
  have h : env41561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41560_41561 : H12AffineEnvironment.transform 2 3 env41560 = env41561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env41560 == env41561) = true)

theorem identity41561 : scanCanonicalize (H12AffineFastState.compose env41561 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound41561 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41562 : List Nat := [2,3,3,0,0,1,3,2,0,2,1,1,3,0,1,2,0,1,2,0,1,0,0,3,2,1,0,1,1,0,3,0,3,1,0,0]

theorem envBound41562 : H12AffineFastState.Bounded env41562 := by
  intro p hp
  have h : env41562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41561_41562 : H12AffineEnvironment.transform 1 3 env41561 = env41562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env41561 == env41562) = true)

def env41563 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1557,845,1296,528,65536,67363,65664,1877,529,1557,649,66162,66896,145,65911,1151,67443,1297,67603,833,65831,257,1281,1345,341]

theorem envBound41563 : H12AffineFastState.Bounded env41563 := by
  intro p hp
  have h : env41563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41520_41563 : H12AffineEnvironment.transform 11 1557 env41520 = env41563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env41520 == env41563) = true)

def env41564 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,837,845,64,528,65536,66163,65664,517,529,837,649,66162,65536,145,65911,303,66083,65,67603,833,65831,257,81,17,341]

theorem envBound41564 : H12AffineFastState.Bounded env41564 := by
  intro p hp
  have h : env41564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41563_41564 : H12AffineEnvironment.transform 9 336 env41563 = env41564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env41563 == env41564) = true)

theorem identity41564 : scanCanonicalize (H12AffineFastState.compose env41564 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 985) := by decide +kernel

theorem selectedBound41564 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env41565 : List Nat := [2,4,8,16,32,64,128,256,512,336,2048,837,845,64,528,985,426,857,517,529,837,649,427,985,145,686,303,506,65,3018,833,766,257,81,17,341]

theorem envBound41565 : H12AffineFastState.Bounded env41565 := by
  intro p hp
  have h : env41565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41564_41565 : H12AffineEnvironment.transform 15 985 env41564 = env41565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 985 env41564 == env41565) = true)

def env41566 : List Nat := [2,4,8,16,32,64,128,256,512,336,912,837,845,64,528,985,426,857,517,529,837,649,427,985,145,686,303,506,65,90,833,766,257,81,17,341]

theorem envBound41566 : H12AffineFastState.Bounded env41566 := by
  intro p hp
  have h : env41566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41565_41566 : H12AffineEnvironment.transform 10 912 env41565 = env41566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 912 env41565 == env41566) = true)

theorem identity41566 : scanCanonicalize (H12AffineFastState.compose env41566 (packedSelected [1,3,4,5,9,16,17,18,21,23] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound41566 : packedSelected [1,3,4,5,9,16,17,18,21,23] rootPS < 2^1333 := by decide +kernel

def env41567 : List Nat := [2,4,8,16,32,64,57,256,512,336,809,837,845,64,528,864,275,857,517,529,837,560,274,864,40,535,303,323,65,90,833,583,257,81,17,341]

theorem envBound41567 : H12AffineFastState.Bounded env41567 := by
  intro p hp
  have h : env41567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41566_41567 : H12AffineEnvironment.transform 6 57 env41566 = env41567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env41566 == env41567) = true)

theorem identity41567 : scanCanonicalize (H12AffineFastState.compose env41567 (packedSelected [1,2,5,7,8,11,16,18,24,27] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound41567 : packedSelected [1,2,5,7,8,11,16,18,24,27] rootPS < 2^1333 := by decide +kernel

def env41568 : List Nat := [2,4,8,16,32,64,57,36,512,116,525,609,617,64,528,580,55,637,517,529,609,560,54,580,40,535,11,103,65,90,613,583,37,81,17,113]

theorem envBound41568 : H12AffineFastState.Bounded env41568 := by
  intro p hp
  have h : env41568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41567_41568 : H12AffineEnvironment.transform 7 36 env41567 = env41568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env41567 == env41568) = true)

theorem identity41568 : scanCanonicalize (H12AffineFastState.compose env41568 (packedSelected [0,1,3,5,8,9,11,13,16,17] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound41568 : packedSelected [0,1,3,5,8,9,11,13,16,17] rootPS < 2^1333 := by decide +kernel

def env41569 : List Nat := [2,4,8,1,32,64,40,36,512,101,525,609,617,64,513,580,38,620,517,512,609,545,39,580,40,518,11,103,65,75,613,583,37,64,0,96]

theorem envBound41569 : H12AffineFastState.Bounded env41569 := by
  intro p hp
  have h : env41569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41568_41569 : H12AffineEnvironment.transform 3 1 env41568 = env41569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env41568 == env41569) = true)

theorem identity41569 : scanCanonicalize (H12AffineFastState.compose env41569 (packedSelected [0,2,3,4,7,9,10] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound41569 : packedSelected [0,2,3,4,7,9,10] rootPS < 2^1333 := by decide +kernel

def env41570 : List Nat := [2,4,8,1,32,64,40,36,42,101,39,75,67,64,43,110,38,70,47,42,75,11,39,110,40,44,11,103,65,75,79,109,37,64,0,96]

theorem envBound41570 : H12AffineFastState.Bounded env41570 := by
  intro p hp
  have h : env41570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41569_41570 : H12AffineEnvironment.transform 8 42 env41569 = env41570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env41569 == env41570) = true)

theorem identity41570 : scanCanonicalize (H12AffineFastState.compose env41570 (packedSelected [0,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound41570 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env41571 : List Nat := [2,4,8,1,13,64,5,9,7,72,10,75,67,64,6,67,11,70,2,7,75,11,10,67,5,1,11,74,65,75,79,64,8,64,0,77]

theorem envBound41571 : H12AffineFastState.Bounded env41571 := by
  intro p hp
  have h : env41571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41570_41571 : H12AffineEnvironment.transform 4 13 env41570 = env41571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env41570 == env41571) = true)

theorem identity41571 : scanCanonicalize (H12AffineFastState.compose env41571 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound41571 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41572 : List Nat := [2,4,2,1,7,64,5,3,7,66,0,65,67,64,6,67,1,70,2,7,65,1,0,67,5,1,1,64,65,65,69,64,2,64,0,71]

theorem envBound41572 : H12AffineFastState.Bounded env41572 := by
  intro p hp
  have h : env41572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41571_41572 : H12AffineEnvironment.transform 2 2 env41571 = env41572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env41571 == env41572) = true)

theorem identity41572 : scanCanonicalize (H12AffineFastState.compose env41572 (packedSelected [1,3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound41572 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41573 : List Nat := [2,2,2,1,1,64,3,3,1,66,0,65,67,64,0,67,1,64,2,1,65,1,0,67,3,1,1,64,65,65,67,64,2,64,0,65]

theorem envBound41573 : H12AffineFastState.Bounded env41573 := by
  intro p hp
  have h : env41573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41572_41573 : H12AffineEnvironment.transform 1 2 env41572 = env41573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env41572 == env41573) = true)

def env41574 : List Nat := [2,4,8,16,32,64,128,256,512,336,913,837,845,64,528,985,426,857,517,529,837,649,427,985,145,686,303,506,65,91,833,766,257,81,17,341]

theorem envBound41574 : H12AffineFastState.Bounded env41574 := by
  intro p hp
  have h : env41574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41565_41574 : H12AffineEnvironment.transform 10 913 env41565 = env41574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 913 env41565 == env41574) = true)

theorem identity41574 : scanCanonicalize (H12AffineFastState.compose env41574 (packedSelected [1,3,4,5,9,16,17,18,21,23] rootPS)) = affineNative (2^(6+1) ^^^ 63) := by decide +kernel

theorem selectedBound41574 : packedSelected [1,3,4,5,9,16,17,18,21,23] rootPS < 2^1333 := by decide +kernel

def env41575 : List Nat := [2,4,8,16,32,64,63,256,512,336,814,837,845,64,528,870,277,857,517,529,837,566,276,870,46,529,303,325,65,91,833,577,257,81,17,341]

theorem envBound41575 : H12AffineFastState.Bounded env41575 := by
  intro p hp
  have h : env41575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41574_41575 : H12AffineEnvironment.transform 6 63 env41574 = env41575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 63 env41574 == env41575) = true)

theorem identity41575 : scanCanonicalize (H12AffineFastState.compose env41575 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound41575 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env41576 : List Nat := [2,4,8,16,32,17,63,256,512,257,814,788,796,17,528,823,277,776,517,529,788,566,276,823,46,529,303,276,16,10,784,528,257,0,17,260]

theorem envBound41576 : H12AffineFastState.Bounded env41576 := by
  intro p hp
  have h : env41576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41575_41576 : H12AffineEnvironment.transform 5 17 env41575 = env41576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41575 == env41576) = true)

theorem identity41576 : scanCanonicalize (H12AffineFastState.compose env41576 (packedSelected [2,3,8,13,17] rootPS)) = affineNative (2^(8+1) ^^^ 45) := by decide +kernel

theorem selectedBound41576 : packedSelected [2,3,8,13,17] rootPS < 2^1333 := by decide +kernel

def env41577 : List Nat := [2,4,8,16,32,17,63,256,45,257,259,313,305,17,61,282,277,293,40,60,313,27,276,282,46,60,303,276,16,10,317,61,257,0,17,260]

theorem envBound41577 : H12AffineFastState.Bounded env41577 := by
  intro p hp
  have h : env41577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41576_41577 : H12AffineEnvironment.transform 8 45 env41576 = env41577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 45 env41576 == env41577) = true)

theorem identity41577 : scanCanonicalize (H12AffineFastState.compose env41577 (packedSelected [0,1,3,5,7,8,11] rootPS)) = affineNative (2^(7+1) ^^^ 25) := by decide +kernel

theorem selectedBound41577 : packedSelected [0,1,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env41578 : List Nat := [2,4,8,16,32,17,63,25,45,24,26,32,40,17,61,3,12,60,40,60,32,27,13,3,46,60,54,13,16,10,36,61,24,0,17,29]

theorem envBound41578 : H12AffineFastState.Bounded env41578 := by
  intro p hp
  have h : env41578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41577_41578 : H12AffineEnvironment.transform 7 25 env41577 = env41578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 25 env41577 == env41578) = true)

theorem identity41578 : scanCanonicalize (H12AffineFastState.compose env41578 (packedSelected [0,2,3,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound41578 : packedSelected [0,2,3,7] rootPS < 2^1333 := by decide +kernel

def env41579 : List Nat := [2,4,8,16,0,17,31,25,13,24,26,0,8,17,29,3,12,28,8,28,0,27,13,3,14,28,22,13,16,10,4,29,24,0,17,29]

theorem envBound41579 : H12AffineFastState.Bounded env41579 := by
  intro p hp
  have h : env41579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41578_41579 : H12AffineEnvironment.transform 4 0 env41578 = env41579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env41578 == env41579) = true)

theorem identity41579 : scanCanonicalize (H12AffineFastState.compose env41579 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound41579 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env41580 : List Nat := [2,4,8,0,0,1,15,9,13,8,10,0,8,1,13,3,12,12,8,12,0,11,13,3,14,12,6,13,0,10,4,13,8,0,1,13]

theorem envBound41580 : H12AffineFastState.Bounded env41580 := by
  intro p hp
  have h : env41580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41579_41580 : H12AffineEnvironment.transform 3 0 env41579 = env41580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env41579 == env41580) = true)

theorem identity41580 : scanCanonicalize (H12AffineFastState.compose env41580 (packedSelected [0,1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound41580 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env41581 : List Nat := [2,2,8,0,0,1,9,9,11,8,10,0,8,1,11,3,10,10,8,10,0,11,11,3,8,10,0,11,0,10,2,11,8,0,1,11]

theorem envBound41581 : H12AffineFastState.Bounded env41581 := by
  intro p hp
  have h : env41581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41580_41581 : H12AffineEnvironment.transform 1 2 env41580 = env41581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env41580 == env41581) = true)

theorem identity41581 : scanCanonicalize (H12AffineFastState.compose env41581 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound41581 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41582 : List Nat := [2,2,2,0,0,1,3,3,1,2,0,0,2,1,1,3,0,0,2,0,0,1,1,3,2,0,0,1,0,0,2,1,2,0,1,1]

theorem envBound41582 : H12AffineFastState.Bounded env41582 := by
  intro p hp
  have h : env41582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41581_41582 : H12AffineEnvironment.transform 2 2 env41581 = env41582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env41581 == env41582) = true)

def env41583 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,836,845,65,528,65536,66162,65664,516,529,836,649,66162,65537,145,65911,302,66082,64,67603,833,65831,257,80,16,341]

theorem envBound41583 : H12AffineFastState.Bounded env41583 := by
  intro p hp
  have h : env41583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41563_41583 : H12AffineEnvironment.transform 9 337 env41563 = env41583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 337 env41563 == env41583) = true)

theorem identity41583 : scanCanonicalize (H12AffineFastState.compose env41583 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 204) := by decide +kernel

theorem selectedBound41583 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env41584 : List Nat := [2,4,8,16,32,64,128,256,512,337,2048,836,845,65,528,204,702,76,516,529,836,649,702,205,145,443,302,750,64,2271,833,491,257,80,16,341]

theorem envBound41584 : H12AffineFastState.Bounded env41584 := by
  intro p hp
  have h : env41584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41583_41584 : H12AffineEnvironment.transform 15 204 env41583 = env41584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 204 env41583 == env41584) = true)

def env41585 : List Nat := [2,4,8,16,32,64,128,256,512,337,896,836,845,65,528,204,702,76,516,529,836,649,702,205,145,443,302,750,64,863,833,491,257,80,16,341]

theorem envBound41585 : H12AffineFastState.Bounded env41585 := by
  intro p hp
  have h : env41585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41584_41585 : H12AffineEnvironment.transform 10 896 env41584 = env41585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 896 env41584 == env41585) = true)

theorem identity41585 : scanCanonicalize (H12AffineFastState.compose env41585 (packedSelected [0,2,5,12,13,15,16,17,19,20,21,23,24,27,32] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound41585 : packedSelected [0,2,5,12,13,15,16,17,19,20,21,23,24,27,32] rootPS < 2^1333 := by decide +kernel

def env41586 : List Nat := [2,4,8,16,32,64,128,117,512,36,757,561,568,65,528,204,702,76,516,529,561,649,702,205,145,206,91,750,64,554,564,158,116,80,16,32]

theorem envBound41586 : H12AffineFastState.Bounded env41586 := by
  intro p hp
  have h : env41586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41585_41586 : H12AffineEnvironment.transform 7 117 env41585 = env41586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env41585 == env41586) = true)

theorem identity41586 : scanCanonicalize (H12AffineFastState.compose env41586 (packedSelected [2,3,5,10,11,13,16,20,21,23] rootPS)) = affineNative (2^(8+1) ^^^ 23) := by decide +kernel

theorem selectedBound41586 : packedSelected [2,3,5,10,11,13,16,20,21,23] rootPS < 2^1333 := by decide +kernel

def env41587 : List Nat := [2,4,8,16,32,64,128,117,23,36,226,38,47,65,7,204,169,76,19,6,38,158,169,205,145,206,91,249,64,61,35,158,116,80,16,32]

theorem envBound41587 : H12AffineFastState.Bounded env41587 := by
  intro p hp
  have h : env41587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41586_41587 : H12AffineEnvironment.transform 8 23 env41586 = env41587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 23 env41586 == env41587) = true)

theorem identity41587 : scanCanonicalize (H12AffineFastState.compose env41587 (packedSelected [0,2,3,4,5,8,10,11,16,18] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound41587 : packedSelected [0,2,3,4,5,8,10,11,16,18] rootPS < 2^1333 := by decide +kernel

def env41588 : List Nat := [2,4,8,16,32,58,128,15,23,36,152,38,47,59,7,182,169,54,19,6,38,158,169,183,145,180,33,131,58,61,35,158,14,42,16,32]

theorem envBound41588 : H12AffineFastState.Bounded env41588 := by
  intro p hp
  have h : env41588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41587_41588 : H12AffineEnvironment.transform 5 58 env41587 = env41588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env41587 == env41588) = true)

theorem identity41588 : scanCanonicalize (H12AffineFastState.compose env41588 (packedSelected [1,2,5,10,12] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound41588 : packedSelected [1,2,5,10,12] rootPS < 2^1333 := by decide +kernel

def env41589 : List Nat := [2,4,8,16,32,58,56,15,23,36,32,38,47,59,7,14,17,54,19,6,38,38,17,15,41,12,33,59,58,61,35,38,14,42,16,32]

theorem envBound41589 : H12AffineFastState.Bounded env41589 := by
  intro p hp
  have h : env41589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41588_41589 : H12AffineEnvironment.transform 6 56 env41588 = env41589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env41588 == env41589) = true)

theorem identity41589 : scanCanonicalize (H12AffineFastState.compose env41589 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound41589 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env41590 : List Nat := [2,4,8,16,16,10,8,15,23,20,16,22,31,11,7,14,17,6,19,6,22,22,17,15,25,12,17,11,10,13,19,22,14,26,16,16]

theorem envBound41590 : H12AffineFastState.Bounded env41590 := by
  intro p hp
  have h : env41590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41589_41590 : H12AffineEnvironment.transform 4 16 env41589 = env41590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env41589 == env41590) = true)

theorem identity41590 : scanCanonicalize (H12AffineFastState.compose env41590 (packedSelected [2,3] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound41590 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env41591 : List Nat := [2,4,8,6,6,10,8,15,1,2,6,0,9,11,7,14,7,6,5,6,0,0,7,15,15,12,7,11,10,13,5,0,14,12,6,6]

theorem envBound41591 : H12AffineFastState.Bounded env41591 := by
  intro p hp
  have h : env41591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41590_41591 : H12AffineEnvironment.transform 3 6 env41590 = env41591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env41590 == env41591) = true)

theorem identity41591 : scanCanonicalize (H12AffineFastState.compose env41591 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound41591 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41592 : List Nat := [2,3,8,1,1,10,8,8,1,2,1,0,9,11,0,9,0,1,2,1,0,0,0,8,8,11,0,11,10,10,2,0,9,11,1,1]

theorem envBound41592 : H12AffineFastState.Bounded env41592 := by
  intro p hp
  have h : env41592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41591_41592 : H12AffineEnvironment.transform 1 3 env41591 = env41592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env41591 == env41592) = true)

def env41593 : List Nat := [2,4,8,16,32,64,128,256,512,337,897,836,845,65,528,204,702,76,516,529,836,649,702,205,145,443,302,750,64,862,833,491,257,80,16,341]

theorem envBound41593 : H12AffineFastState.Bounded env41593 := by
  intro p hp
  have h : env41593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41584_41593 : H12AffineEnvironment.transform 10 897 env41584 = env41593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 897 env41584 == env41593) = true)

theorem identity41593 : scanCanonicalize (H12AffineFastState.compose env41593 (packedSelected [0,2,5,12,13,15,16,17,19,20,21,23,24,27,32] rootPS)) = affineNative (2^(7+1) ^^^ 114) := by decide +kernel

theorem selectedBound41593 : packedSelected [0,2,5,12,13,15,16,17,19,20,21,23,24,27,32] rootPS < 2^1333 := by decide +kernel

def env41594 : List Nat := [2,4,8,16,32,64,128,114,512,35,755,566,575,65,528,204,702,76,516,529,566,649,702,205,145,201,92,750,64,556,563,153,115,80,16,39]

theorem envBound41594 : H12AffineFastState.Bounded env41594 := by
  intro p hp
  have h : env41594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41593_41594 : H12AffineEnvironment.transform 7 114 env41593 = env41594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 114 env41593 == env41594) = true)

theorem identity41594 : scanCanonicalize (H12AffineFastState.compose env41594 (packedSelected [1,2,3,5,8,10,11,13,18,24] rootPS)) = affineNative (2^(6+1) ^^^ 95) := by decide +kernel

theorem selectedBound41594 : packedSelected [1,2,3,5,8,10,11,13,18,24] rootPS < 2^1333 := by decide +kernel

def env41595 : List Nat := [2,4,8,16,32,64,95,114,512,35,556,566,575,65,528,19,609,76,516,529,566,598,609,18,78,22,92,561,64,556,563,70,115,80,16,39]

theorem envBound41595 : H12AffineFastState.Bounded env41595 := by
  intro p hp
  have h : env41595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41594_41595 : H12AffineEnvironment.transform 6 95 env41594 = env41595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 95 env41594 == env41595) = true)

theorem identity41595 : scanCanonicalize (H12AffineFastState.compose env41595 (packedSelected [0,2,3,4,7,8,9,11,16,17] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound41595 : packedSelected [0,2,3,4,7,8,9,11,16,17] rootPS < 2^1333 := by decide +kernel

def env41596 : List Nat := [2,4,8,16,32,49,46,3,512,35,556,566,575,48,528,19,528,61,516,529,566,551,528,18,63,22,45,561,49,556,563,55,2,33,16,39]

theorem envBound41596 : H12AffineFastState.Bounded env41596 := by
  intro p hp
  have h : env41596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41595_41596 : H12AffineEnvironment.transform 5 49 env41595 = env41596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env41595 == env41596) = true)

theorem identity41596 : scanCanonicalize (H12AffineFastState.compose env41596 (packedSelected [1,2,3,4,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound41596 : packedSelected [1,2,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env41597 : List Nat := [2,4,8,16,32,49,46,3,42,35,6,28,21,48,58,19,58,61,46,59,28,13,58,18,63,22,45,27,49,6,25,55,2,33,16,39]

theorem envBound41597 : H12AffineFastState.Bounded env41597 := by
  intro p hp
  have h : env41597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41596_41597 : H12AffineEnvironment.transform 8 42 env41596 = env41597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env41596 == env41597) = true)

theorem identity41597 : scanCanonicalize (H12AffineFastState.compose env41597 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound41597 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env41598 : List Nat := [2,4,8,16,10,27,4,3,0,9,6,28,21,26,16,19,16,23,4,17,28,13,16,18,21,22,7,27,27,6,25,29,2,11,16,13]

theorem envBound41598 : H12AffineFastState.Bounded env41598 := by
  intro p hp
  have h : env41598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41597_41598 : H12AffineEnvironment.transform 4 10 env41597 = env41598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env41597 == env41598) = true)

theorem identity41598 : scanCanonicalize (H12AffineFastState.compose env41598 (packedSelected [0,1,4] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound41598 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env41599 : List Nat := [2,4,8,11,10,0,4,3,0,9,6,7,14,1,11,8,11,12,4,10,7,13,11,9,14,13,7,0,0,6,2,6,2,11,11,13]

theorem envBound41599 : H12AffineFastState.Bounded env41599 := by
  intro p hp
  have h : env41599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41598_41599 : H12AffineEnvironment.transform 3 11 env41598 = env41599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env41598 == env41599) = true)

theorem identity41599 : scanCanonicalize (H12AffineFastState.compose env41599 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound41599 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41600 : List Nat := [2,4,2,1,0,0,4,3,0,3,6,7,4,1,1,2,1,6,4,0,7,7,1,3,4,7,7,0,0,6,2,6,2,1,1,7]

theorem envBound41600 : H12AffineFastState.Bounded env41600 := by
  intro p hp
  have h : env41600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41599_41600 : H12AffineEnvironment.transform 2 2 env41599 = env41600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env41599 == env41600) = true)

theorem identity41600 : scanCanonicalize (H12AffineFastState.compose env41600 (packedSelected [5] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound41600 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env41601 : List Nat := [2,3,2,1,0,0,3,3,0,3,1,0,3,1,1,2,1,1,3,0,0,0,1,3,3,0,0,0,0,1,2,1,2,1,1,0]

theorem envBound41601 : H12AffineFastState.Bounded env41601 := by
  intro p hp
  have h : env41601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41600_41601 : H12AffineEnvironment.transform 1 3 env41600 = env41601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env41600 == env41601) = true)

def env41602 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1296,8541,65536,74862,65665,4416,8540,4096,5276,74047,66896,13769,78895,1150,74814,1297,81227,8204,65831,257,1281,1345,5952]

theorem envBound41602 : H12AffineFastState.Bounded env41602 := by
  intro p hp
  have h : env41602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41518_41602 : H12AffineEnvironment.transform 17 65665 env41518 = env41602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env41518 == env41602) = true)

theorem identity41602 : scanCanonicalize (H12AffineFastState.compose env41602 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound41602 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env41603 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,25,1296,324,65536,66679,65665,4416,325,4096,5276,65830,66896,5584,70710,1150,66599,1297,73042,21,65831,257,1281,1345,5952]

theorem envBound41603 : H12AffineFastState.Bounded env41603 := by
  intro p hp
  have h : env41603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41602_41603 : H12AffineEnvironment.transform 12 25 env41602 = env41603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env41602 == env41603) = true)

def env41604 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1556,25,1296,324,65536,66679,65665,1876,325,1556,648,65830,66896,964,66082,1150,66599,1297,68422,21,65831,257,1281,1345,340]

theorem envBound41604 : H12AffineFastState.Bounded env41604 := by
  intro p hp
  have h : env41604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41603_41604 : H12AffineEnvironment.transform 11 1556 env41603 = env41604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env41603 == env41604) = true)

def env41605 : List Nat := [2,4,8,16,32,0,128,256,512,1024,2048,1556,25,1296,260,65536,66615,65665,1812,261,1556,648,65830,66832,900,66082,1086,66599,1297,68358,21,65831,257,1281,1281,276]

theorem envBound41605 : H12AffineFastState.Bounded env41605 := by
  intro p hp
  have h : env41605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41604_41605 : H12AffineEnvironment.transform 5 0 env41604 = env41605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env41604 == env41605) = true)

theorem identity41605 : scanCanonicalize (H12AffineFastState.compose env41605 (packedSelected [1,8,28] rootPS)) = affineNative (2^(9+1) ^^^ 170) := by decide +kernel

theorem selectedBound41605 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env41606 : List Nat := [2,4,8,16,32,0,128,256,512,170,2048,702,25,442,260,65536,65693,65665,958,261,702,648,65830,65978,900,66082,148,65677,443,68358,21,65831,257,427,427,276]

theorem envBound41606 : H12AffineFastState.Bounded env41606 := by
  intro p hp
  have h : env41606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41605_41606 : H12AffineEnvironment.transform 9 170 env41605 = env41606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 170 env41605 == env41606) = true)

def env41607 : List Nat := [2,4,8,16,32,0,128,176,512,170,2048,702,25,10,180,65536,65693,65665,526,181,702,648,65686,65546,564,66082,148,65677,11,68278,21,65687,177,27,27,164]

theorem envBound41607 : H12AffineFastState.Bounded env41607 := by
  intro p hp
  have h : env41607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41606_41607 : H12AffineEnvironment.transform 7 176 env41606 = env41607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 176 env41606 == env41607) = true)

theorem identity41607 : scanCanonicalize (H12AffineFastState.compose env41607 (packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS)) = affineNative (2^(10+1) ^^^ 525) := by decide +kernel

theorem selectedBound41607 : packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS < 2^1333 := by decide +kernel

def env41608 : List Nat := [2,4,8,16,32,0,128,176,512,170,525,702,25,10,180,65536,65693,65665,526,181,702,648,65686,65546,564,66082,148,65677,11,65723,21,65687,177,27,27,164]

theorem envBound41608 : H12AffineFastState.Bounded env41608 := by
  intro p hp
  have h : env41608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41607_41608 : H12AffineEnvironment.transform 10 525 env41607 = env41608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 525 env41607 == env41608) = true)

theorem identity41608 : scanCanonicalize (H12AffineFastState.compose env41608 (packedSelected [1,2,3,5,7,8,11,15,18,20,27] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound41608 : packedSelected [1,2,3,5,7,8,11,15,18,20,27] rootPS < 2^1333 := by decide +kernel

def env41609 : List Nat := [2,4,8,16,22,0,128,134,512,156,525,648,25,10,130,65536,65693,65665,526,131,648,648,65686,65546,514,66068,148,65677,11,65677,21,65687,135,27,27,146]

theorem envBound41609 : H12AffineFastState.Bounded env41609 := by
  intro p hp
  have h : env41609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41608_41609 : H12AffineEnvironment.transform 4 22 env41608 = env41609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env41608 == env41609) = true)

theorem identity41609 : scanCanonicalize (H12AffineFastState.compose env41609 (packedSelected [2,4,5,7,8,11,12,15,18] rootPS)) = affineNative (2^(15+1) ^^^ 536) := by decide +kernel

theorem selectedBound41609 : packedSelected [2,4,5,7,8,11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env41610 : List Nat := [2,4,8,16,22,0,128,134,512,156,525,648,25,10,130,536,645,665,526,131,648,648,654,530,514,12,148,661,11,661,21,655,135,27,27,146]

theorem envBound41610 : H12AffineFastState.Bounded env41610 := by
  intro p hp
  have h : env41610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41609_41610 : H12AffineEnvironment.transform 15 536 env41609 = env41610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 536 env41609 == env41610) = true)

theorem identity41610 : scanCanonicalize (H12AffineFastState.compose env41610 (packedSelected [0,3,5,7,8,10,11] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound41610 : packedSelected [0,3,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env41611 : List Nat := [2,4,8,16,22,0,128,134,137,156,132,1,25,10,130,145,12,16,135,131,1,1,7,155,139,12,148,28,11,28,21,6,135,27,27,146]

theorem envBound41611 : H12AffineFastState.Bounded env41611 := by
  intro p hp
  have h : env41611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41610_41611 : H12AffineEnvironment.transform 8 137 env41610 = env41611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env41610 == env41611) = true)

theorem identity41611 : scanCanonicalize (H12AffineFastState.compose env41611 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound41611 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env41612 : List Nat := [2,4,8,12,10,0,128,134,137,128,132,1,5,10,130,141,12,12,135,131,1,1,7,135,139,12,136,0,11,0,9,6,135,7,7,142]

theorem envBound41612 : H12AffineFastState.Bounded env41612 := by
  intro p hp
  have h : env41612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41611_41612 : H12AffineEnvironment.transform 3 12 env41611 = env41612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env41611 == env41612) = true)

theorem identity41612 : scanCanonicalize (H12AffineFastState.compose env41612 (packedSelected [1,3,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound41612 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env41613 : List Nat := [2,4,3,7,1,0,128,134,130,128,132,1,5,1,130,134,7,7,135,131,1,1,7,135,128,7,131,0,0,0,2,6,135,7,7,133]

theorem envBound41613 : H12AffineFastState.Bounded env41613 := by
  intro p hp
  have h : env41613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41612_41613 : H12AffineEnvironment.transform 2 3 env41612 = env41613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env41612 == env41613) = true)

theorem identity41613 : scanCanonicalize (H12AffineFastState.compose env41613 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 5) := by decide +kernel

theorem selectedBound41613 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41614 : List Nat := [2,4,3,7,1,0,5,3,7,5,1,1,5,1,7,3,7,7,2,6,1,1,7,2,5,7,6,0,0,0,2,6,2,7,7,0]

theorem envBound41614 : H12AffineFastState.Bounded env41614 := by
  intro p hp
  have h : env41614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41613_41614 : H12AffineEnvironment.transform 6 5 env41613 = env41614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 5 env41613 == env41614) = true)

def env41615 : List Nat := [2,4,8,16,32,0,128,177,512,170,2048,702,25,11,181,65536,65693,65665,527,180,702,648,65687,65547,565,66082,148,65677,10,68279,21,65686,176,26,26,165]

theorem envBound41615 : H12AffineFastState.Bounded env41615 := by
  intro p hp
  have h : env41615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41606_41615 : H12AffineEnvironment.transform 7 177 env41606 = env41615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 177 env41606 == env41615) = true)

theorem identity41615 : scanCanonicalize (H12AffineFastState.compose env41615 (packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS)) = affineNative (2^(10+1) ^^^ 518) := by decide +kernel

theorem selectedBound41615 : packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS < 2^1333 := by decide +kernel

def env41616 : List Nat := [2,4,8,16,32,0,128,177,512,170,518,702,25,11,181,65536,65693,65665,527,180,702,648,65687,65547,565,66082,148,65677,10,65713,21,65686,176,26,26,165]

theorem envBound41616 : H12AffineFastState.Bounded env41616 := by
  intro p hp
  have h : env41616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41615_41616 : H12AffineEnvironment.transform 10 518 env41615 = env41616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 518 env41615 == env41616) = true)

theorem identity41616 : scanCanonicalize (H12AffineFastState.compose env41616 (packedSelected [0,1,5,15,16,18,19,20,21,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 527) := by decide +kernel

theorem selectedBound41616 : packedSelected [0,1,5,15,16,18,19,20,21,23,27] rootPS < 2^1333 := by decide +kernel

def env41617 : List Nat := [2,4,8,16,32,0,128,177,512,170,518,702,25,11,181,527,658,654,527,180,702,648,664,516,565,45,148,642,10,702,21,665,176,26,26,165]

theorem envBound41617 : H12AffineFastState.Bounded env41617 := by
  intro p hp
  have h : env41617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41616_41617 : H12AffineEnvironment.transform 15 527 env41616 = env41617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 527 env41616 == env41617) = true)

theorem identity41617 : scanCanonicalize (H12AffineFastState.compose env41617 (packedSelected [0,1,5,7,8,11,13,15,17,18] rootPS)) = affineNative (2^(6+1) ^^^ 62) := by decide +kernel

theorem selectedBound41617 : packedSelected [0,1,5,7,8,11,13,15,17,18] rootPS < 2^1333 := by decide +kernel

def env41618 : List Nat := [2,4,8,16,32,0,62,15,512,20,518,512,25,11,11,527,556,560,527,10,512,566,550,516,565,45,42,572,10,512,21,551,14,26,26,27]

theorem envBound41618 : H12AffineFastState.Bounded env41618 := by
  intro p hp
  have h : env41618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41617_41618 : H12AffineEnvironment.transform 6 62 env41617 = env41618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 62 env41617 == env41618) = true)

theorem identity41618 : scanCanonicalize (H12AffineFastState.compose env41618 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound41618 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env41619 : List Nat := [2,4,5,16,32,0,51,2,512,20,518,512,20,6,6,514,545,560,514,7,512,566,550,516,565,32,39,561,7,512,21,551,3,23,23,22]

theorem envBound41619 : H12AffineFastState.Bounded env41619 := by
  intro p hp
  have h : env41619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41618_41619 : H12AffineEnvironment.transform 2 5 env41618 = env41619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env41618 == env41619) = true)

theorem identity41619 : scanCanonicalize (H12AffineFastState.compose env41619 (packedSelected [0,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound41619 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env41620 : List Nat := [2,4,5,16,1,0,18,2,512,20,518,512,20,6,6,514,512,529,514,7,512,535,519,516,532,1,6,528,7,512,21,518,3,23,23,22]

theorem envBound41620 : H12AffineFastState.Bounded env41620 := by
  intro p hp
  have h : env41620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41619_41620 : H12AffineEnvironment.transform 4 1 env41619 = env41620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env41619 == env41620) = true)

theorem identity41620 : scanCanonicalize (H12AffineFastState.compose env41620 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound41620 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41621 : List Nat := [2,4,5,16,1,0,18,2,0,20,6,0,20,6,6,2,0,17,2,7,0,23,7,4,20,1,6,16,7,0,21,6,3,23,23,22]

theorem envBound41621 : H12AffineFastState.Bounded env41621 := by
  intro p hp
  have h : env41621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41620_41621 : H12AffineEnvironment.transform 8 0 env41620 = env41621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env41620 == env41621) = true)

theorem identity41621 : scanCanonicalize (H12AffineFastState.compose env41621 (packedSelected [2,3] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound41621 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env41622 : List Nat := [2,4,5,6,1,0,4,2,0,2,6,0,2,6,6,2,0,7,2,7,0,1,7,4,2,1,6,6,7,0,3,6,3,1,1,0]

theorem envBound41622 : H12AffineFastState.Bounded env41622 := by
  intro p hp
  have h : env41622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41621_41622 : H12AffineEnvironment.transform 3 6 env41621 = env41622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env41621 == env41622) = true)

theorem identity41622 : scanCanonicalize (H12AffineFastState.compose env41622 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound41622 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41623 : List Nat := [2,3,2,1,1,0,3,2,0,2,1,0,2,1,1,2,0,0,2,0,0,1,0,3,2,1,1,1,0,0,3,1,3,1,1,0]

theorem envBound41623 : H12AffineFastState.Bounded env41623 := by
  intro p hp
  have h : env41623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41622_41623 : H12AffineEnvironment.transform 1 3 env41622 = env41623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env41622 == env41623) = true)

def env41624 : List Nat := [2,4,8,16,32,1,128,256,512,1024,2048,1556,25,1296,261,65536,66614,65665,1813,260,1556,648,65830,66833,901,66082,1087,66599,1297,68359,21,65831,257,1281,1280,277]

theorem envBound41624 : H12AffineFastState.Bounded env41624 := by
  intro p hp
  have h : env41624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41604_41624 : H12AffineEnvironment.transform 5 1 env41604 = env41624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env41604 == env41624) = true)

theorem identity41624 : scanCanonicalize (H12AffineFastState.compose env41624 (packedSelected [1,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 186) := by decide +kernel

theorem selectedBound41624 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env41625 : List Nat := [2,4,8,16,32,1,128,186,512,1024,2048,1556,25,1194,191,65536,66614,65665,1711,190,1556,648,65692,66731,575,66082,1087,66599,1195,68285,21,65693,187,1211,1210,175]

theorem envBound41625 : H12AffineFastState.Bounded env41625 := by
  intro p hp
  have h : env41625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41624_41625 : H12AffineEnvironment.transform 7 186 env41624 = env41625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 186 env41624 == env41625) = true)

def env41626 : List Nat := [2,4,8,16,32,1,128,186,512,160,2048,692,25,10,191,65536,65686,65665,527,190,692,648,65692,65547,575,66082,159,65671,11,68285,21,65693,187,27,26,175]

theorem envBound41626 : H12AffineFastState.Bounded env41626 := by
  intro p hp
  have h : env41626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41625_41626 : H12AffineEnvironment.transform 9 160 env41625 = env41626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 160 env41625 == env41626) = true)

theorem identity41626 : scanCanonicalize (H12AffineFastState.compose env41626 (packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS)) = affineNative (2^(15+1) ^^^ 2689) := by decide +kernel

theorem selectedBound41626 : packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS < 2^1333 := by decide +kernel

def env41627 : List Nat := [2,4,8,16,32,1,128,186,512,160,2048,692,25,10,191,2689,2583,2560,527,190,692,648,2589,2698,575,2211,159,2566,11,60,21,2588,187,27,26,175]

theorem envBound41627 : H12AffineFastState.Bounded env41627 := by
  intro p hp
  have h : env41627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41626_41627 : H12AffineEnvironment.transform 15 2689 env41626 = env41627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2689 env41626 == env41627) = true)

theorem identity41627 : scanCanonicalize (H12AffineFastState.compose env41627 (packedSelected [0,1,2,3,9,10,11,12,13,17,19,21,23] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound41627 : packedSelected [0,1,2,3,9,10,11,12,13,17,19,21,23] rootPS < 2^1333 := by decide +kernel

def env41628 : List Nat := [2,4,8,16,32,1,25,35,512,57,2048,557,25,10,38,2584,2583,2560,527,39,557,529,2589,2579,575,2106,6,2566,11,60,21,2588,34,27,26,54]

theorem envBound41628 : H12AffineFastState.Bounded env41628 := by
  intro p hp
  have h : env41628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41627_41628 : H12AffineEnvironment.transform 6 25 env41627 = env41628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env41627 == env41628) = true)

theorem identity41628 : scanCanonicalize (H12AffineFastState.compose env41628 (packedSelected [0,2,3,7,12,13,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 551) := by decide +kernel

theorem selectedBound41628 : packedSelected [0,2,3,7,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env41629 : List Nat := [2,4,8,16,32,1,25,35,512,57,551,557,25,10,38,63,48,39,527,39,557,529,58,52,575,541,6,33,11,60,21,59,34,27,26,54]

theorem envBound41629 : H12AffineFastState.Bounded env41629 := by
  intro p hp
  have h : env41629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41628_41629 : H12AffineEnvironment.transform 10 551 env41628 = env41629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 551 env41628 == env41629) = true)

theorem identity41629 : scanCanonicalize (H12AffineFastState.compose env41629 (packedSelected [0,1,2,4,5,8] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound41629 : packedSelected [0,1,2,4,5,8] rootPS < 2^1333 := by decide +kernel

def env41630 : List Nat := [2,4,8,16,32,1,25,35,33,57,6,12,25,10,38,63,48,39,46,39,12,48,58,52,30,60,6,33,11,60,21,59,34,27,26,54]

theorem envBound41630 : H12AffineFastState.Bounded env41630 := by
  intro p hp
  have h : env41630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41629_41630 : H12AffineEnvironment.transform 8 33 env41629 = env41630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env41629 == env41630) = true)

theorem identity41630 : scanCanonicalize (H12AffineFastState.compose env41630 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound41630 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env41631 : List Nat := [2,4,8,16,7,1,25,4,6,30,6,12,25,10,1,24,23,0,9,0,12,23,29,19,30,27,6,6,11,27,21,28,5,27,26,17]

theorem envBound41631 : H12AffineFastState.Bounded env41631 := by
  intro p hp
  have h : env41631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41630_41631 : H12AffineEnvironment.transform 4 7 env41630 = env41631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env41630 == env41631) = true)

theorem identity41631 : scanCanonicalize (H12AffineFastState.compose env41631 (packedSelected [1,2,3] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound41631 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env41632 : List Nat := [2,4,4,16,7,1,21,4,6,18,6,0,21,6,1,20,23,0,5,0,0,23,17,19,18,23,6,6,7,23,21,16,5,23,22,17]

theorem envBound41632 : H12AffineFastState.Bounded env41632 := by
  intro p hp
  have h : env41632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41631_41632 : H12AffineEnvironment.transform 2 4 env41631 = env41632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env41631 == env41632) = true)

theorem identity41632 : scanCanonicalize (H12AffineFastState.compose env41632 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound41632 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41633 : List Nat := [2,4,4,0,7,1,5,4,6,2,6,0,5,6,1,4,7,0,5,0,0,7,1,3,2,7,6,6,7,7,5,0,5,7,6,1]

theorem envBound41633 : H12AffineFastState.Bounded env41633 := by
  intro p hp
  have h : env41633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41632_41633 : H12AffineEnvironment.transform 3 0 env41632 = env41633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env41632 == env41633) = true)

def env41634 : List Nat := [2,4,8,16,32,1,128,186,512,161,2048,693,25,11,191,65536,65687,65665,526,190,693,648,65692,65546,575,66082,158,65670,10,68285,21,65693,187,26,27,175]

theorem envBound41634 : H12AffineFastState.Bounded env41634 := by
  intro p hp
  have h : env41634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41625_41634 : H12AffineEnvironment.transform 9 161 env41625 = env41634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 161 env41625 == env41634) = true)

theorem identity41634 : scanCanonicalize (H12AffineFastState.compose env41634 (packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS)) = affineNative (2^(15+1) ^^^ 2698) := by decide +kernel

theorem selectedBound41634 : packedSelected [0,4,7,8,9,13,15,16,20,24] rootPS < 2^1333 := by decide +kernel

def env41635 : List Nat := [2,4,8,16,32,1,128,186,512,161,2048,693,25,11,191,2698,2589,2571,526,190,693,648,2582,2688,575,2216,158,2572,10,55,21,2583,187,26,27,175]

theorem envBound41635 : H12AffineFastState.Bounded env41635 := by
  intro p hp
  have h : env41635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41634_41635 : H12AffineEnvironment.transform 15 2698 env41634 = env41635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2698 env41634 == env41635) = true)

theorem identity41635 : scanCanonicalize (H12AffineFastState.compose env41635 (packedSelected [7,9,11,15,16,17,18,19,21,23,32] rootPS)) = affineNative (2^(10+1) ^^^ 132) := by decide +kernel

theorem selectedBound41635 : packedSelected [7,9,11,15,16,17,18,19,21,23,32] rootPS < 2^1333 := by decide +kernel

def env41636 : List Nat := [2,4,8,16,32,1,128,186,512,161,132,693,25,11,191,526,665,655,526,190,693,648,658,516,575,44,158,648,10,55,21,659,187,26,27,175]

theorem envBound41636 : H12AffineFastState.Bounded env41636 := by
  intro p hp
  have h : env41636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41635_41636 : H12AffineEnvironment.transform 10 132 env41635 = env41636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 132 env41635 == env41636) = true)

def env41637 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1557,25,1296,324,65536,66679,65665,1877,325,1557,649,65830,66896,965,66083,1150,66599,1297,68423,21,65831,257,1281,1345,341]

theorem envBound41637 : H12AffineFastState.Bounded env41637 := by
  intro p hp
  have h : env41637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41603_41637 : H12AffineEnvironment.transform 11 1557 env41603 = env41637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env41603 == env41637) = true)

def env41638 : List Nat := [2,4,8,16,32,0,128,256,512,1024,2048,1557,25,1296,260,65536,66615,65665,1813,261,1557,649,65830,66832,901,66083,1086,66599,1297,68359,21,65831,257,1281,1281,277]

theorem envBound41638 : H12AffineFastState.Bounded env41638 := by
  intro p hp
  have h : env41638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41637_41638 : H12AffineEnvironment.transform 5 0 env41637 = env41638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env41637 == env41638) = true)

theorem identity41638 : scanCanonicalize (H12AffineFastState.compose env41638 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 1436) := by decide +kernel

theorem selectedBound41638 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env41639 : List Nat := [2,4,8,16,32,0,128,256,512,1024,2048,1557,25,1296,260,1436,427,1309,1813,261,1557,649,1210,140,901,1983,1086,443,1297,3739,21,1211,257,1281,1281,277]

theorem envBound41639 : H12AffineFastState.Bounded env41639 := by
  intro p hp
  have h : env41639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41638_41639 : H12AffineEnvironment.transform 15 1436 env41638 = env41639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1436 env41638 == env41639) = true)

def env41640 : List Nat := [2,4,8,16,32,0,128,256,512,1024,1680,1557,25,1296,260,1436,427,1309,1813,261,1557,649,1210,140,901,1983,1086,443,1297,11,21,1211,257,1281,1281,277]

theorem envBound41640 : H12AffineFastState.Bounded env41640 := by
  intro p hp
  have h : env41640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41639_41640 : H12AffineEnvironment.transform 10 1680 env41639 = env41640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1680 env41639 == env41640) = true)

theorem identity41640 : scanCanonicalize (H12AffineFastState.compose env41640 (packedSelected [8,10,18,19,23] rootPS)) = affineNative (2^(8+1) ^^^ 429) := by decide +kernel

theorem selectedBound41640 : packedSelected [8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env41641 : List Nat := [2,4,8,16,32,0,128,256,429,1024,1341,1464,25,1296,260,1436,427,1309,1208,261,1464,292,1210,140,40,1042,1086,443,1297,11,21,1211,257,1281,1281,277]

theorem envBound41641 : H12AffineFastState.Bounded env41641 := by
  intro p hp
  have h : env41641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41640_41641 : H12AffineEnvironment.transform 8 429 env41640 = env41641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 429 env41640 == env41641) = true)

theorem identity41641 : scanCanonicalize (H12AffineFastState.compose env41641 (packedSelected [3,4,9,10,19,20,24] rootPS)) = affineNative (2^(7+1) ^^^ 186) := by decide +kernel

theorem selectedBound41641 : packedSelected [3,4,9,10,19,20,24] rootPS < 2^1333 := by decide +kernel

def env41642 : List Nat := [2,4,8,16,32,0,128,186,23,1024,1159,1026,25,1194,190,1062,17,1191,1208,191,1026,158,1210,140,40,1042,1086,1,1195,11,21,1211,187,1211,1211,175]

theorem envBound41642 : H12AffineFastState.Bounded env41642 := by
  intro p hp
  have h : env41642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41641_41642 : H12AffineEnvironment.transform 7 186 env41641 = env41642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 186 env41641 == env41642) = true)

theorem identity41642 : scanCanonicalize (H12AffineFastState.compose env41642 (packedSelected [1,2,3,5,8,10,12,13] rootPS)) = affineNative (2^(9+1) ^^^ 57) := by decide +kernel

theorem selectedBound41642 : packedSelected [1,2,3,5,8,10,12,13] rootPS < 2^1333 := by decide +kernel

def env41643 : List Nat := [2,4,8,16,32,0,128,186,23,57,190,59,25,147,190,31,17,158,129,191,59,158,131,140,40,43,7,1,146,11,21,130,187,130,130,175]

theorem envBound41643 : H12AffineFastState.Bounded env41643 := by
  intro p hp
  have h : env41643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41642_41643 : H12AffineEnvironment.transform 9 57 env41642 = env41643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 57 env41642 == env41643) = true)

theorem identity41643 : scanCanonicalize (H12AffineFastState.compose env41643 (packedSelected [0,1,3,7,8] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound41643 : packedSelected [0,1,3,7,8] rootPS < 2^1333 := by decide +kernel

def env41644 : List Nat := [2,4,4,16,32,0,128,182,23,53,178,55,21,147,178,19,17,146,129,179,55,146,131,128,36,39,7,1,146,7,21,130,183,130,130,163]

theorem envBound41644 : H12AffineFastState.Bounded env41644 := by
  intro p hp
  have h : env41644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41643_41644 : H12AffineEnvironment.transform 2 4 env41643 = env41644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env41643 == env41644) = true)

theorem identity41644 : scanCanonicalize (H12AffineFastState.compose env41644 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound41644 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env41645 : List Nat := [2,4,4,16,16,0,128,134,23,5,130,7,21,147,130,19,17,146,129,131,7,146,131,128,20,23,7,1,146,7,21,130,135,130,130,147]

theorem envBound41645 : H12AffineFastState.Bounded env41645 := by
  intro p hp
  have h : env41645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41644_41645 : H12AffineEnvironment.transform 4 16 env41644 = env41645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env41644 == env41645) = true)

theorem identity41645 : scanCanonicalize (H12AffineFastState.compose env41645 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound41645 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env41646 : List Nat := [2,4,4,1,1,0,128,134,6,5,130,7,4,130,130,2,0,131,129,131,7,131,131,128,5,6,7,1,131,7,4,130,135,130,130,130]

theorem envBound41646 : H12AffineFastState.Bounded env41646 := by
  intro p hp
  have h : env41646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41645_41646 : H12AffineEnvironment.transform 3 1 env41645 = env41646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env41645 == env41646) = true)

theorem identity41646 : scanCanonicalize (H12AffineFastState.compose env41646 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 4) := by decide +kernel

theorem selectedBound41646 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41647 : List Nat := [2,4,4,1,1,0,4,2,6,5,6,7,4,6,6,2,0,7,5,7,7,7,7,4,5,6,7,1,7,7,4,6,3,6,6,6]

theorem envBound41647 : H12AffineFastState.Bounded env41647 := by
  intro p hp
  have h : env41647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41646_41647 : H12AffineEnvironment.transform 6 4 env41646 = env41647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 4 env41646 == env41647) = true)

def env41648 : List Nat := [2,4,8,16,32,0,128,256,512,1024,1681,1557,25,1296,260,1436,427,1309,1813,261,1557,649,1210,140,901,1983,1086,443,1297,10,21,1211,257,1281,1281,277]

theorem envBound41648 : H12AffineFastState.Bounded env41648 := by
  intro p hp
  have h : env41648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41639_41648 : H12AffineEnvironment.transform 10 1681 env41639 = env41648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1681 env41639 == env41648) = true)

theorem identity41648 : scanCanonicalize (H12AffineFastState.compose env41648 (packedSelected [8,10,18,19,23] rootPS)) = affineNative (2^(8+1) ^^^ 427) := by decide +kernel

theorem selectedBound41648 : packedSelected [8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env41649 : List Nat := [2,4,8,16,32,0,128,256,427,1024,1338,1470,25,1296,260,1436,427,1309,1214,261,1470,290,1210,140,46,1044,1086,443,1297,10,21,1211,257,1281,1281,277]

theorem envBound41649 : H12AffineFastState.Bounded env41649 := by
  intro p hp
  have h : env41649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41648_41649 : H12AffineEnvironment.transform 8 427 env41648 = env41649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 427 env41648 == env41649) = true)

theorem identity41649 : scanCanonicalize (H12AffineFastState.compose env41649 (packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,18,20,21] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound41649 : packedSelected [0,2,3,4,5,7,9,10,11,12,15,16,18,20,21] rootPS < 2^1333 := by decide +kernel

def env41650 : List Nat := [2,4,8,16,6,0,128,256,397,1024,1308,1432,25,1296,260,1436,397,1309,1176,261,1432,260,1180,140,8,1044,1048,413,1297,10,21,1181,257,1281,1281,277]

theorem envBound41650 : H12AffineFastState.Bounded env41650 := by
  intro p hp
  have h : env41650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41649_41650 : H12AffineEnvironment.transform 4 6 env41649 = env41650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env41649 == env41650) = true)

theorem identity41650 : scanCanonicalize (H12AffineFastState.compose env41650 (packedSelected [2,3,5,10,11,12,13,15,18] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound41650 : packedSelected [2,3,5,10,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env41651 : List Nat := [2,4,8,16,6,0,128,5,136,1024,1049,1181,25,1045,1,1177,136,1048,1176,0,1181,1,1180,140,8,1044,1048,152,1044,10,21,1181,4,1028,1028,16]

theorem envBound41651 : H12AffineFastState.Bounded env41651 := by
  intro p hp
  have h : env41651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41650_41651 : H12AffineEnvironment.transform 7 5 env41650 = env41651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env41650 == env41651) = true)

theorem identity41651 : scanCanonicalize (H12AffineFastState.compose env41651 (packedSelected [3,5,7,8,9,11] rootPS)) = affineNative (2^(6+1) ^^^ 21) := by decide +kernel

theorem selectedBound41651 : packedSelected [3,5,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env41652 : List Nat := [2,4,8,16,6,0,21,5,29,1024,1049,1032,25,1045,1,1036,29,1048,1037,0,1032,1,1033,25,8,1044,1048,13,1044,10,21,1032,4,1028,1028,16]

theorem envBound41652 : H12AffineFastState.Bounded env41652 := by
  intro p hp
  have h : env41652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41651_41652 : H12AffineEnvironment.transform 6 21 env41651 = env41652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 21 env41651 == env41652) = true)

theorem identity41652 : scanCanonicalize (H12AffineFastState.compose env41652 (packedSelected [1,3,8] rootPS)) = affineNative (2^(9+1) ^^^ 3) := by decide +kernel

theorem selectedBound41652 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env41653 : List Nat := [2,4,8,16,6,0,21,5,29,3,26,11,25,22,1,15,29,27,14,0,11,1,10,25,8,23,27,13,23,10,21,11,4,7,7,16]

theorem envBound41653 : H12AffineFastState.Bounded env41653 := by
  intro p hp
  have h : env41653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41652_41653 : H12AffineEnvironment.transform 9 3 env41652 = env41653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 3 env41652 == env41653) = true)

theorem identity41653 : scanCanonicalize (H12AffineFastState.compose env41653 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound41653 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env41654 : List Nat := [2,4,8,12,6,0,9,5,1,3,6,11,5,10,1,15,1,7,14,0,11,1,10,5,8,11,7,13,11,10,9,11,4,7,7,12]

theorem envBound41654 : H12AffineFastState.Bounded env41654 := by
  intro p hp
  have h : env41654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41653_41654 : H12AffineEnvironment.transform 3 12 env41653 = env41654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env41653 == env41654) = true)

theorem identity41654 : scanCanonicalize (H12AffineFastState.compose env41654 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound41654 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env41655 : List Nat := [2,4,4,0,6,0,5,5,1,3,6,7,5,6,1,3,1,7,2,0,7,1,6,5,4,7,7,1,7,6,5,7,4,7,7,0]

theorem envBound41655 : H12AffineFastState.Bounded env41655 := by
  intro p hp
  have h : env41655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41654_41655 : H12AffineEnvironment.transform 2 4 env41654 = env41655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env41654 == env41655) = true)

theorem identity41655 : scanCanonicalize (H12AffineFastState.compose env41655 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound41655 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41656 : List Nat := [1,4,4,0,5,0,5,5,1,0,5,4,5,5,1,0,1,4,1,0,4,1,5,5,4,4,4,1,4,5,5,4,4,4,4,0]

theorem envBound41656 : H12AffineFastState.Bounded env41656 := by
  intro p hp
  have h : env41656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41655_41656 : H12AffineEnvironment.transform 0 1 env41655 = env41656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env41655 == env41656) = true)

def env41657 : List Nat := [2,4,8,16,32,1,128,256,512,1024,2048,1557,25,1296,261,65536,66614,65665,1812,260,1557,649,65830,66833,900,66083,1087,66599,1297,68358,21,65831,257,1281,1280,276]

theorem envBound41657 : H12AffineFastState.Bounded env41657 := by
  intro p hp
  have h : env41657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41637_41657 : H12AffineEnvironment.transform 5 1 env41637 = env41657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env41637 == env41657) = true)

theorem identity41657 : scanCanonicalize (H12AffineFastState.compose env41657 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 140) := by decide +kernel

theorem selectedBound41657 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env41658 : List Nat := [2,4,8,16,32,1,128,256,512,1024,2048,1557,25,1296,261,140,1210,13,1812,260,1557,649,426,1437,900,687,1087,1195,1297,2954,21,427,257,1281,1280,276]

theorem envBound41658 : H12AffineFastState.Bounded env41658 := by
  intro p hp
  have h : env41658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41657_41658 : H12AffineEnvironment.transform 15 140 env41657 = env41658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 140 env41657 == env41658) = true)

def env41659 : List Nat := [2,4,8,16,32,1,128,256,512,272,2048,773,25,0,261,140,426,13,516,260,773,649,426,141,900,687,303,443,1,2954,21,427,257,17,16,276]

theorem envBound41659 : H12AffineFastState.Bounded env41659 := by
  intro p hp
  have h : env41659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41658_41659 : H12AffineEnvironment.transform 9 272 env41658 = env41659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env41658 == env41659) = true)

theorem identity41659 : scanCanonicalize (H12AffineFastState.compose env41659 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 63) := by decide +kernel

theorem selectedBound41659 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env41660 : List Nat := [2,4,8,16,32,1,63,256,512,272,2048,773,25,0,261,51,277,13,516,260,773,566,277,50,827,528,303,260,1,2869,21,276,257,17,16,276]

theorem envBound41660 : H12AffineFastState.Bounded env41660 := by
  intro p hp
  have h : env41660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41659_41660 : H12AffineEnvironment.transform 6 63 env41659 = env41660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 63 env41659 == env41660) = true)

theorem identity41660 : scanCanonicalize (H12AffineFastState.compose env41660 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound41660 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env41661 : List Nat := [2,4,8,0,32,1,47,256,512,256,2048,773,9,0,261,35,261,13,516,260,773,550,261,34,811,512,303,260,1,2853,5,260,257,1,0,260]

theorem envBound41661 : H12AffineFastState.Bounded env41661 := by
  intro p hp
  have h : env41661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41660_41661 : H12AffineEnvironment.transform 3 0 env41660 = env41661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env41660 == env41661) = true)

theorem identity41661 : scanCanonicalize (H12AffineFastState.compose env41661 (packedSelected [0,2,3,7,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 556) := by decide +kernel

theorem selectedBound41661 : packedSelected [0,2,3,7,11,12] rootPS < 2^1333 := by decide +kernel

def env41662 : List Nat := [2,4,8,0,32,1,47,256,512,256,556,773,9,0,261,35,261,13,516,260,773,550,261,34,811,512,303,260,1,265,5,260,257,1,0,260]

theorem envBound41662 : H12AffineFastState.Bounded env41662 := by
  intro p hp
  have h : env41662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41661_41662 : H12AffineEnvironment.transform 10 556 env41661 = env41662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 556 env41661 == env41662) = true)

theorem identity41662 : scanCanonicalize (H12AffineFastState.compose env41662 (packedSelected [0,1,2,3,4,7,8,9,10] rootPS)) = affineNative (2^(8+1) ^^^ 297) := by decide +kernel

theorem selectedBound41662 : packedSelected [0,1,2,3,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env41663 : List Nat := [2,4,8,0,32,1,47,256,297,256,261,44,9,0,261,35,261,13,301,260,44,271,261,34,2,297,303,260,1,265,5,260,257,1,0,260]

theorem envBound41663 : H12AffineFastState.Bounded env41663 := by
  intro p hp
  have h : env41663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41662_41663 : H12AffineEnvironment.transform 8 297 env41662 = env41663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 297 env41662 == env41663) = true)

theorem identity41663 : scanCanonicalize (H12AffineFastState.compose env41663 (packedSelected [2,4,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound41663 : packedSelected [2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env41664 : List Nat := [2,4,8,0,32,1,47,36,13,36,33,44,9,0,33,35,33,13,9,32,44,43,33,34,2,13,11,32,1,45,5,32,37,1,0,32]

theorem envBound41664 : H12AffineFastState.Bounded env41664 := by
  intro p hp
  have h : env41664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41663_41664 : H12AffineEnvironment.transform 7 36 env41663 = env41664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env41663 == env41664) = true)

theorem identity41664 : scanCanonicalize (H12AffineFastState.compose env41664 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound41664 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env41665 : List Nat := [2,4,2,0,32,1,37,36,7,36,33,38,3,0,33,35,33,7,3,32,38,33,33,34,2,7,1,32,1,39,5,32,37,1,0,32]

theorem envBound41665 : H12AffineFastState.Bounded env41665 := by
  intro p hp
  have h : env41665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41664_41665 : H12AffineEnvironment.transform 2 2 env41664 = env41665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env41664 == env41665) = true)

def env41666 : List Nat := [2,4,8,16,32,1,128,256,512,273,2048,772,25,1,261,140,427,13,517,260,772,649,426,140,900,687,302,442,0,2954,21,427,257,16,17,276]

theorem envBound41666 : H12AffineFastState.Bounded env41666 := by
  intro p hp
  have h : env41666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41658_41666 : H12AffineEnvironment.transform 9 273 env41658 = env41666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env41658 == env41666) = true)

theorem identity41666 : scanCanonicalize (H12AffineFastState.compose env41666 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(8+1) ^^^ 426) := by decide +kernel

theorem selectedBound41666 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env41667 : List Nat := [2,4,8,16,32,1,128,256,426,273,2048,174,25,1,261,140,427,13,431,260,174,291,426,140,46,261,302,442,0,2080,21,427,257,16,17,276]

theorem envBound41667 : H12AffineFastState.Bounded env41667 := by
  intro p hp
  have h : env41667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41666_41667 : H12AffineEnvironment.transform 8 426 env41666 = env41667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 426 env41666 == env41667) = true)

theorem identity41667 : scanCanonicalize (H12AffineFastState.compose env41667 (packedSelected [0,1,2,3,7,10,12,17,20] rootPS)) = affineNative (2^(7+1) ^^^ 154) := by decide +kernel

theorem selectedBound41667 : packedSelected [0,1,2,3,7,10,12,17,20] rootPS < 2^1333 := by decide +kernel

def env41668 : List Nat := [2,4,8,16,32,1,128,154,48,139,2048,174,25,1,159,140,49,13,53,158,174,185,48,140,46,159,180,32,0,2080,21,49,155,16,17,142]

theorem envBound41668 : H12AffineFastState.Bounded env41668 := by
  intro p hp
  have h : env41668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41667_41668 : H12AffineEnvironment.transform 7 154 env41667 = env41668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 154 env41667 == env41668) = true)

theorem identity41668 : scanCanonicalize (H12AffineFastState.compose env41668 (packedSelected [0,1,2,4,5,7,8,9,11,12,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 148) := by decide +kernel

theorem selectedBound41668 : packedSelected [0,1,2,4,5,7,8,9,11,12,15,16] rootPS < 2^1333 := by decide +kernel

def env41669 : List Nat := [2,4,8,16,32,1,128,154,48,139,148,174,25,1,159,140,49,13,53,158,174,185,48,140,46,159,180,32,0,180,21,49,155,16,17,142]

theorem envBound41669 : H12AffineFastState.Bounded env41669 := by
  intro p hp
  have h : env41669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41668_41669 : H12AffineEnvironment.transform 10 148 env41668 = env41669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 148 env41668 == env41669) = true)

theorem identity41669 : scanCanonicalize (H12AffineFastState.compose env41669 (packedSelected [3,12] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound41669 : packedSelected [3,12] rootPS < 2^1333 := by decide +kernel

def env41670 : List Nat := [2,4,2,16,32,1,128,144,48,129,148,164,19,1,149,134,49,7,53,148,164,179,48,134,36,149,180,32,0,180,21,49,145,16,17,132]

theorem envBound41670 : H12AffineFastState.Bounded env41670 := by
  intro p hp
  have h : env41670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41669_41670 : H12AffineEnvironment.transform 2 2 env41669 = env41670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env41669 == env41670) = true)

theorem identity41670 : scanCanonicalize (H12AffineFastState.compose env41670 (packedSelected [0,3,7] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound41670 : packedSelected [0,3,7] rootPS < 2^1333 := by decide +kernel

def env41671 : List Nat := [2,4,2,16,32,1,19,3,48,18,7,55,19,1,6,21,49,7,53,7,55,32,48,21,36,6,39,32,0,39,21,49,2,16,17,23]

theorem envBound41671 : H12AffineFastState.Bounded env41671 := by
  intro p hp
  have h : env41671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41670_41671 : H12AffineEnvironment.transform 6 19 env41670 = env41671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env41670 == env41671) = true)

theorem identity41671 : scanCanonicalize (H12AffineFastState.compose env41671 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound41671 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env41672 : List Nat := [2,4,2,16,1,1,19,3,17,18,7,22,19,1,6,21,16,7,20,7,22,1,17,21,5,6,6,1,0,6,21,16,2,16,17,23]

theorem envBound41672 : H12AffineFastState.Bounded env41672 := by
  intro p hp
  have h : env41672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41671_41672 : H12AffineEnvironment.transform 4 1 env41671 = env41672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env41671 == env41672) = true)

theorem identity41672 : scanCanonicalize (H12AffineFastState.compose env41672 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound41672 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41673 : List Nat := [2,4,2,6,1,1,5,3,7,4,7,0,5,1,6,3,6,7,2,7,0,1,7,3,5,6,6,1,0,6,3,6,2,6,7,1]

theorem envBound41673 : H12AffineFastState.Bounded env41673 := by
  intro p hp
  have h : env41673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41672_41673 : H12AffineEnvironment.transform 3 6 env41672 = env41673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env41672 == env41673) = true)

theorem identity41673 : scanCanonicalize (H12AffineFastState.compose env41673 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound41673 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41674 : List Nat := [2,2,2,0,1,1,3,3,1,2,1,0,3,1,0,3,0,1,2,1,0,1,1,3,3,0,0,1,0,0,3,0,2,0,1,1]

theorem envBound41674 : H12AffineFastState.Bounded env41674 := by
  intro p hp
  have h : env41674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41673_41674 : H12AffineEnvironment.transform 1 2 env41673 = env41674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env41673 == env41674) = true)

def env41675 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74862,262144,4417,8541,4096,5276,74046,66896,13768,78895,328959,74815,1297,81226,8205,65830,257,1281,1345,5953]

theorem envBound41675 : H12AffineFastState.Bounded env41675 := by
  intro p hp
  have h : env41675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41517_41675 : H12AffineEnvironment.transform 13 1297 env41517 = env41675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env41517 == env41675) = true)

def env41676 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74862,65664,4417,8541,4096,5276,74046,66896,13768,78895,1151,74815,1297,81226,8205,65830,257,1281,1345,5953]

theorem envBound41676 : H12AffineFastState.Bounded env41676 := by
  intro p hp
  have h : env41676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41675_41676 : H12AffineEnvironment.transform 17 65664 env41675 = env41676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65664 env41675 == env41676) = true)

theorem identity41676 : scanCanonicalize (H12AffineFastState.compose env41676 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound41676 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env41677 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,1,8540,65536,74110,65664,4417,8541,4096,4492,74046,65600,12504,78143,367,74031,1,79962,8205,65830,257,17,81,4689]

theorem envBound41677 : H12AffineFastState.Bounded env41677 := by
  intro p hp
  have h : env41677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41676_41677 : H12AffineEnvironment.transform 9 272 env41676 = env41677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env41676 == env41677) = true)

def env41678 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,772,8192,1,8540,65536,74110,65664,581,8541,772,648,74046,65600,9180,74299,367,74031,1,76638,8205,65830,257,17,81,341]

theorem envBound41678 : H12AffineFastState.Bounded env41678 := by
  intro p hp
  have h : env41678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41677_41678 : H12AffineEnvironment.transform 11 772 env41677 = env41678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 772 env41677 == env41678) = true)

def env41679 : List Nat := [2,4,8,16,32,0,128,256,512,272,2048,772,8192,1,8476,65536,74046,65664,517,8477,772,648,74046,65536,9116,74299,303,74031,1,76574,8205,65830,257,17,17,277]

theorem envBound41679 : H12AffineFastState.Bounded env41679 := by
  intro p hp
  have h : env41679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41678_41679 : H12AffineEnvironment.transform 5 0 env41678 = env41679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env41678 == env41679) = true)

theorem identity41679 : scanCanonicalize (H12AffineFastState.compose env41679 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 8732) := by decide +kernel

theorem selectedBound41679 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env41680 : List Nat := [2,4,8,16,32,0,128,256,512,272,2048,772,8192,1,8476,8732,802,8860,517,8477,772,648,802,8732,9116,39,303,819,1,2306,8205,9018,257,17,17,277]

theorem envBound41680 : H12AffineFastState.Bounded env41680 := by
  intro p hp
  have h : env41680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41679_41680 : H12AffineEnvironment.transform 15 8732 env41679 = env41680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8732 env41679 == env41680) = true)

def env41681 : List Nat := [2,4,8,16,32,0,128,256,308,272,2048,48,8192,1,8476,8488,22,8616,305,8477,48,444,22,8488,8360,39,303,7,1,2306,8205,8206,257,17,17,277]

theorem envBound41681 : H12AffineFastState.Bounded env41681 := by
  intro p hp
  have h : env41681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41680_41681 : H12AffineEnvironment.transform 8 308 env41680 = env41681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env41680 == env41681) = true)

theorem identity41681 : scanCanonicalize (H12AffineFastState.compose env41681 (packedSelected [0,4,5,9,12,13,16,17,27,38] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound41681 : packedSelected [0,4,5,9,12,13,16,17,27,38] rootPS < 2^1333 := by decide +kernel

def env41682 : List Nat := [2,4,8,16,32,0,128,4,48,20,2048,48,8192,1,8216,8236,22,8364,53,8217,48,184,22,8236,8360,39,43,7,1,2054,8205,8206,5,17,17,17]

theorem envBound41682 : H12AffineFastState.Bounded env41682 := by
  intro p hp
  have h : env41682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41681_41682 : H12AffineEnvironment.transform 7 4 env41681 = env41682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env41681 == env41682) = true)

theorem identity41682 : scanCanonicalize (H12AffineFastState.compose env41682 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound41682 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env41683 : List Nat := [2,4,8,16,32,0,128,4,48,20,2048,48,25,1,1,53,22,181,53,0,48,184,22,53,177,39,43,7,1,2054,20,23,5,17,17,17]

theorem envBound41683 : H12AffineFastState.Bounded env41683 := by
  intro p hp
  have h : env41683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41682_41683 : H12AffineEnvironment.transform 12 25 env41682 = env41683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env41682 == env41683) = true)

theorem identity41683 : scanCanonicalize (H12AffineFastState.compose env41683 (packedSelected [3,11,15,18] rootPS)) = affineNative (2^(10+1) ^^^ 132) := by decide +kernel

theorem selectedBound41683 : packedSelected [3,11,15,18] rootPS < 2^1333 := by decide +kernel

def env41684 : List Nat := [2,4,8,16,32,0,128,4,48,20,132,48,25,1,1,53,22,181,53,0,48,184,22,53,177,39,43,7,1,130,20,23,5,17,17,17]

theorem envBound41684 : H12AffineFastState.Bounded env41684 := by
  intro p hp
  have h : env41684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41683_41684 : H12AffineEnvironment.transform 10 132 env41683 = env41684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 132 env41683 == env41684) = true)

theorem identity41684 : scanCanonicalize (H12AffineFastState.compose env41684 (packedSelected [0,2,4,5,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound41684 : packedSelected [0,2,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env41685 : List Nat := [2,4,8,16,32,0,3,4,48,20,7,48,25,1,1,53,22,54,53,0,48,59,22,53,50,39,43,7,1,1,20,23,5,17,17,17]

theorem envBound41685 : H12AffineFastState.Bounded env41685 := by
  intro p hp
  have h : env41685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41684_41685 : H12AffineEnvironment.transform 6 3 env41684 = env41685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env41684 == env41685) = true)

theorem identity41685 : scanCanonicalize (H12AffineFastState.compose env41685 (packedSelected [1,3,4,5,7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound41685 : packedSelected [1,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env41686 : List Nat := [2,4,8,0,32,0,3,4,32,4,7,32,9,1,1,37,6,38,37,0,32,43,6,37,34,39,43,7,1,1,4,7,5,1,1,1]

theorem envBound41686 : H12AffineFastState.Bounded env41686 := by
  intro p hp
  have h : env41686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41685_41686 : H12AffineEnvironment.transform 3 0 env41685 = env41686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env41685 == env41686) = true)

theorem identity41686 : scanCanonicalize (H12AffineFastState.compose env41686 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound41686 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env41687 : List Nat := [2,4,2,0,32,0,3,4,32,4,7,32,3,1,1,37,6,38,37,0,32,33,6,37,34,39,33,7,1,1,4,7,5,1,1,1]

theorem envBound41687 : H12AffineFastState.Bounded env41687 := by
  intro p hp
  have h : env41687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41686_41687 : H12AffineEnvironment.transform 2 2 env41686 = env41687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env41686 == env41687) = true)

def env41688 : List Nat := [2,4,8,16,32,0,128,256,309,272,2048,49,8192,1,8476,8489,23,8617,304,8477,49,445,23,8489,8361,39,303,6,1,2306,8205,8207,257,17,17,277]

theorem envBound41688 : H12AffineFastState.Bounded env41688 := by
  intro p hp
  have h : env41688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41680_41688 : H12AffineEnvironment.transform 8 309 env41680 = env41688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 309 env41680 == env41688) = true)

theorem identity41688 : scanCanonicalize (H12AffineFastState.compose env41688 (packedSelected [0,4,5,9,12,13,16,17,27,38] rootPS)) = affineNative (2^(7+1) ^^^ 3) := by decide +kernel

theorem selectedBound41688 : packedSelected [0,4,5,9,12,13,16,17,27,38] rootPS < 2^1333 := by decide +kernel

def env41689 : List Nat := [2,4,8,16,32,0,128,3,54,19,2048,49,8192,1,8223,8234,23,8362,51,8222,49,190,23,8234,8361,39,44,6,1,2049,8205,8207,2,17,17,22]

theorem envBound41689 : H12AffineFastState.Bounded env41689 := by
  intro p hp
  have h : env41689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41688_41689 : H12AffineEnvironment.transform 7 3 env41688 = env41689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 3 env41688 == env41689) = true)

theorem identity41689 : scanCanonicalize (H12AffineFastState.compose env41689 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 46) := by decide +kernel

theorem selectedBound41689 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env41690 : List Nat := [2,4,8,16,32,0,128,3,54,19,2048,49,46,1,49,4,23,132,51,48,49,190,23,4,135,39,44,6,1,2049,35,33,2,17,17,22]

theorem envBound41690 : H12AffineFastState.Bounded env41690 := by
  intro p hp
  have h : env41690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41689_41690 : H12AffineEnvironment.transform 12 46 env41689 = env41690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 46 env41689 == env41690) = true)

theorem identity41690 : scanCanonicalize (H12AffineFastState.compose env41690 (packedSelected [0,2,3,7,8,11,17] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound41690 : packedSelected [0,2,3,7,8,11,17] rootPS < 2^1333 := by decide +kernel

def env41691 : List Nat := [2,4,8,16,7,0,128,3,17,19,2048,22,9,1,22,4,23,132,20,23,22,153,23,4,135,0,11,6,1,2049,4,6,2,17,17,22]

theorem envBound41691 : H12AffineFastState.Bounded env41691 := by
  intro p hp
  have h : env41691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41690_41691 : H12AffineEnvironment.transform 4 7 env41690 = env41691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env41690 == env41691) = true)

theorem identity41691 : scanCanonicalize (H12AffineFastState.compose env41691 (packedSelected [0,5,7,8,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound41691 : packedSelected [0,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env41692 : List Nat := [2,4,8,16,7,0,19,3,17,19,2048,22,9,1,22,4,23,23,20,23,22,10,23,4,20,0,11,6,1,2049,4,6,2,17,17,22]

theorem envBound41692 : H12AffineFastState.Bounded env41692 := by
  intro p hp
  have h : env41692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41691_41692 : H12AffineEnvironment.transform 6 19 env41691 = env41692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env41691 == env41692) = true)

theorem identity41692 : scanCanonicalize (H12AffineFastState.compose env41692 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 6) := by decide +kernel

theorem selectedBound41692 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env41693 : List Nat := [2,4,8,16,7,0,19,3,17,19,6,22,9,1,22,4,23,23,20,23,22,10,23,4,20,0,11,6,1,7,4,6,2,17,17,22]

theorem envBound41693 : H12AffineFastState.Bounded env41693 := by
  intro p hp
  have h : env41693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41692_41693 : H12AffineEnvironment.transform 10 6 env41692 = env41693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 6 env41692 == env41693) = true)

theorem identity41693 : scanCanonicalize (H12AffineFastState.compose env41693 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound41693 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env41694 : List Nat := [2,4,2,16,7,0,19,3,17,19,6,22,3,1,22,4,23,23,20,23,22,0,23,4,20,0,1,6,1,7,4,6,2,17,17,22]

theorem envBound41694 : H12AffineFastState.Bounded env41694 := by
  intro p hp
  have h : env41694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41693_41694 : H12AffineEnvironment.transform 2 2 env41693 = env41694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env41693 == env41694) = true)

theorem identity41694 : scanCanonicalize (H12AffineFastState.compose env41694 (packedSelected [1,3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound41694 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41695 : List Nat := [2,3,2,16,0,0,19,3,17,19,1,17,3,1,17,3,16,16,19,16,17,0,16,3,19,0,1,1,1,0,3,1,2,17,17,17]

theorem envBound41695 : H12AffineFastState.Bounded env41695 := by
  intro p hp
  have h : env41695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41694_41695 : H12AffineEnvironment.transform 1 3 env41694 = env41695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env41694 == env41695) = true)

theorem identity41695 : scanCanonicalize (H12AffineFastState.compose env41695 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound41695 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41696 : List Nat := [2,3,2,0,0,0,3,3,1,3,1,1,3,1,1,3,0,0,3,0,1,0,0,3,3,0,1,1,1,0,3,1,2,1,1,1]

theorem envBound41696 : H12AffineFastState.Bounded env41696 := by
  intro p hp
  have h : env41696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41695_41696 : H12AffineEnvironment.transform 3 0 env41695 = env41696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env41695 == env41696) = true)

def env41697 : List Nat := [2,4,8,16,32,1,128,256,512,272,2048,772,8192,1,8477,65536,74047,65664,516,8476,772,648,74046,65537,9117,74299,302,74031,1,76575,8205,65830,257,17,16,276]

theorem envBound41697 : H12AffineFastState.Bounded env41697 := by
  intro p hp
  have h : env41697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41678_41697 : H12AffineEnvironment.transform 5 1 env41678 = env41697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env41678 == env41697) = true)

theorem identity41697 : scanCanonicalize (H12AffineFastState.compose env41697 (packedSelected [1,8,28] rootPS)) = affineNative (2^(15+1) ^^^ 516) := by decide +kernel

theorem selectedBound41697 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env41698 : List Nat := [2,4,8,16,32,1,128,256,512,272,2048,772,8192,1,8477,516,9019,644,516,8476,772,648,9018,517,9117,8255,302,9003,1,10523,8205,802,257,17,16,276]

theorem envBound41698 : H12AffineFastState.Bounded env41698 := by
  intro p hp
  have h : env41698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41697_41698 : H12AffineEnvironment.transform 15 516 env41697 = env41698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 516 env41697 == env41698) = true)

def env41699 : List Nat := [2,4,8,16,32,1,128,256,512,272,2048,772,812,1,561,516,23,644,516,560,772,648,22,517,177,787,302,7,1,2615,801,802,257,17,16,276]

theorem envBound41699 : H12AffineFastState.Bounded env41699 := by
  intro p hp
  have h : env41699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41698_41699 : H12AffineEnvironment.transform 12 812 env41698 = env41699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 812 env41698 == env41699) = true)

theorem identity41699 : scanCanonicalize (H12AffineFastState.compose env41699 (packedSelected [0,5,13,15,21,27,41] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound41699 : packedSelected [0,5,13,15,21,27,41] rootPS < 2^1333 := by decide +kernel

def env41700 : List Nat := [2,2,8,16,32,1,128,256,512,272,2048,770,810,1,561,514,17,642,514,560,770,648,16,515,177,787,296,1,1,2609,801,802,257,17,16,274]

theorem envBound41700 : H12AffineFastState.Bounded env41700 := by
  intro p hp
  have h : env41700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41699_41700 : H12AffineEnvironment.transform 1 2 env41699 = env41700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env41699 == env41700) = true)

theorem identity41700 : scanCanonicalize (H12AffineFastState.compose env41700 (packedSelected [3,8,10,13,17] rootPS)) = affineNative (2^(10+1) ^^^ 771) := by decide +kernel

theorem selectedBound41700 : packedSelected [3,8,10,13,17] rootPS < 2^1333 := by decide +kernel

def env41701 : List Nat := [2,2,8,16,32,1,128,256,512,272,771,770,810,1,561,514,17,642,514,560,770,648,16,515,177,787,296,1,1,306,801,802,257,17,16,274]

theorem envBound41701 : H12AffineFastState.Bounded env41701 := by
  intro p hp
  have h : env41701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41700_41701 : H12AffineEnvironment.transform 10 771 env41700 = env41701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 771 env41700 == env41701) = true)

theorem identity41701 : scanCanonicalize (H12AffineFastState.compose env41701 (packedSelected [0,4,7,9,11,15] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound41701 : packedSelected [0,4,7,9,11,15] rootPS < 2^1333 := by decide +kernel

def env41702 : List Nat := [2,2,8,16,32,1,35,256,512,272,771,770,810,1,561,514,17,545,514,560,770,555,16,515,18,787,296,1,1,306,801,802,257,17,16,274]

theorem envBound41702 : H12AffineFastState.Bounded env41702 := by
  intro p hp
  have h : env41702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41701_41702 : H12AffineEnvironment.transform 6 35 env41701 = env41702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env41701 == env41702) = true)

def env41703 : List Nat := [2,4,8,16,32,1,128,256,512,272,2048,772,813,1,560,516,22,644,516,561,772,648,23,517,176,786,302,6,1,2614,800,802,257,17,16,276]

theorem envBound41703 : H12AffineFastState.Bounded env41703 := by
  intro p hp
  have h : env41703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41698_41703 : H12AffineEnvironment.transform 12 813 env41698 = env41703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 813 env41698 == env41703) = true)

def env41704 : List Nat := [2,4,8,16,32,1,128,256,512,272,908,772,813,1,560,516,22,644,516,561,772,648,23,517,176,786,302,6,1,442,800,802,257,17,16,276]

theorem envBound41704 : H12AffineFastState.Bounded env41704 := by
  intro p hp
  have h : env41704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41703_41704 : H12AffineEnvironment.transform 10 908 env41703 = env41704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 908 env41703 == env41704) = true)

theorem identity41704 : scanCanonicalize (H12AffineFastState.compose env41704 (packedSelected [3,8,10,13,17] rootPS)) = affineNative (2^(8+1) ^^^ 443) := by decide +kernel

theorem selectedBound41704 : packedSelected [3,8,10,13,17] rootPS < 2^1333 := by decide +kernel

def env41705 : List Nat := [2,4,8,16,32,1,128,256,443,272,55,191,150,1,395,447,22,319,447,394,191,307,23,446,176,169,302,6,1,442,155,153,257,17,16,276]

theorem envBound41705 : H12AffineFastState.Bounded env41705 := by
  intro p hp
  have h : env41705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41704_41705 : H12AffineEnvironment.transform 8 443 env41704 = env41705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 443 env41704 == env41705) = true)

theorem identity41705 : scanCanonicalize (H12AffineFastState.compose env41705 (packedSelected [3,5,13,15,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 187) := by decide +kernel

theorem selectedBound41705 : packedSelected [3,5,13,15,16,18] rootPS < 2^1333 := by decide +kernel

def env41706 : List Nat := [2,4,8,16,32,1,128,187,0,171,55,191,150,1,48,4,22,132,4,49,191,136,23,5,176,169,149,6,1,1,155,153,186,17,16,175]

theorem envBound41706 : H12AffineFastState.Bounded env41706 := by
  intro p hp
  have h : env41706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41705_41706 : H12AffineEnvironment.transform 7 187 env41705 = env41706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 187 env41705 == env41706) = true)

theorem identity41706 : scanCanonicalize (H12AffineFastState.compose env41706 (packedSelected [0,1,5,7,10,12] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound41706 : packedSelected [0,1,5,7,10,12] rootPS < 2^1333 := by decide +kernel

def env41707 : List Nat := [2,4,8,16,32,1,15,52,0,36,55,48,25,1,48,4,22,11,4,49,48,7,23,5,63,38,26,6,1,1,20,22,53,17,16,32]

theorem envBound41707 : H12AffineFastState.Bounded env41707 := by
  intro p hp
  have h : env41707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41706_41707 : H12AffineEnvironment.transform 6 15 env41706 = env41707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env41706 == env41707) = true)

theorem identity41707 : scanCanonicalize (H12AffineFastState.compose env41707 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound41707 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41708 : List Nat := [2,4,8,1,32,1,15,37,0,36,38,33,8,1,33,4,7,11,4,32,33,7,6,5,46,38,11,6,1,1,5,7,36,0,1,32]

theorem envBound41708 : H12AffineFastState.Bounded env41708 := by
  intro p hp
  have h : env41708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41707_41708 : H12AffineEnvironment.transform 3 1 env41707 = env41708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env41707 == env41708) = true)

theorem identity41708 : scanCanonicalize (H12AffineFastState.compose env41708 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound41708 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env41709 : List Nat := [2,4,8,1,6,1,15,3,0,2,0,7,8,1,7,4,7,11,4,6,7,7,6,5,8,0,11,6,1,1,5,7,2,0,1,6]

theorem envBound41709 : H12AffineFastState.Bounded env41709 := by
  intro p hp
  have h : env41709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41708_41709 : H12AffineEnvironment.transform 4 6 env41708 = env41709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env41708 == env41709) = true)

theorem identity41709 : scanCanonicalize (H12AffineFastState.compose env41709 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound41709 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env41710 : List Nat := [2,4,2,1,6,1,5,3,0,2,0,7,2,1,7,4,7,1,4,6,7,7,6,5,2,0,1,6,1,1,5,7,2,0,1,6]

theorem envBound41710 : H12AffineFastState.Bounded env41710 := by
  intro p hp
  have h : env41710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41709_41710 : H12AffineEnvironment.transform 2 2 env41709 = env41710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env41709 == env41710) = true)

def env41711 : List Nat := [2,4,8,16,32,1,128,256,512,272,909,772,813,1,560,516,22,644,516,561,772,648,23,517,176,786,302,6,1,443,800,802,257,17,16,276]

theorem envBound41711 : H12AffineFastState.Bounded env41711 := by
  intro p hp
  have h : env41711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41703_41711 : H12AffineEnvironment.transform 10 909 env41703 = env41711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 909 env41703 == env41711) = true)

theorem identity41711 : scanCanonicalize (H12AffineFastState.compose env41711 (packedSelected [3,8,10,13,17] rootPS)) = affineNative (2^(8+1) ^^^ 445) := by decide +kernel

theorem selectedBound41711 : packedSelected [3,8,10,13,17] rootPS < 2^1333 := by decide +kernel

def env41712 : List Nat := [2,4,8,16,32,1,128,256,445,272,48,185,144,1,397,441,22,313,441,396,185,309,23,440,176,175,302,6,1,443,157,159,257,17,16,276]

theorem envBound41712 : H12AffineFastState.Bounded env41712 := by
  intro p hp
  have h : env41712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41711_41712 : H12AffineEnvironment.transform 8 445 env41711 = env41712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 445 env41711 == env41712) = true)

theorem identity41712 : scanCanonicalize (H12AffineFastState.compose env41712 (packedSelected [1,2,4,5,7,16,18,19] rootPS)) = affineNative (2^(7+1) ^^^ 176) := by decide +kernel

theorem selectedBound41712 : packedSelected [1,2,4,5,7,16,18,19] rootPS < 2^1333 := by decide +kernel

def env41713 : List Nat := [2,4,8,16,32,1,128,176,13,160,48,185,144,1,61,9,22,137,9,60,185,133,23,8,176,175,158,6,1,11,157,159,177,17,16,164]

theorem envBound41713 : H12AffineFastState.Bounded env41713 := by
  intro p hp
  have h : env41713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41712_41713 : H12AffineEnvironment.transform 7 176 env41712 = env41713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 176 env41712 == env41713) = true)

theorem identity41713 : scanCanonicalize (H12AffineFastState.compose env41713 (packedSelected [10,12] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound41713 : packedSelected [10,12] rootPS < 2^1333 := by decide +kernel

def env41714 : List Nat := [2,4,8,16,13,1,128,157,13,141,29,148,144,1,16,9,22,137,9,17,148,133,23,8,157,130,158,6,1,11,157,159,156,17,16,137]

theorem envBound41714 : H12AffineFastState.Bounded env41714 := by
  intro p hp
  have h : env41714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41713_41714 : H12AffineEnvironment.transform 4 13 env41713 = env41714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env41713 == env41714) = true)

theorem identity41714 : scanCanonicalize (H12AffineFastState.compose env41714 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 31) := by decide +kernel

theorem selectedBound41714 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env41715 : List Nat := [2,4,8,16,13,1,31,2,13,18,29,11,15,1,16,9,22,22,9,17,11,26,23,8,2,29,1,6,1,11,2,0,3,17,16,22]

theorem envBound41715 : H12AffineFastState.Bounded env41715 := by
  intro p hp
  have h : env41715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41714_41715 : H12AffineEnvironment.transform 6 31 env41714 = env41715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 31 env41714 == env41715) = true)

theorem identity41715 : scanCanonicalize (H12AffineFastState.compose env41715 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound41715 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env41716 : List Nat := [2,4,8,7,13,1,8,2,13,5,10,11,15,1,7,9,1,1,9,6,11,13,0,8,2,10,1,6,1,11,2,0,3,6,7,1]

theorem envBound41716 : H12AffineFastState.Bounded env41716 := by
  intro p hp
  have h : env41716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41715_41716 : H12AffineEnvironment.transform 3 7 env41715 = env41716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env41715 == env41716) = true)

def env41717 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,773,8192,1,8540,65536,74110,65664,580,8541,773,649,74046,65600,9181,74298,367,74031,1,76639,8205,65830,257,17,81,340]

theorem envBound41717 : H12AffineFastState.Bounded env41717 := by
  intro p hp
  have h : env41717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41677_41717 : H12AffineEnvironment.transform 11 773 env41677 = env41717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 773 env41677 == env41717) = true)

def env41718 : List Nat := [2,4,8,16,32,0,128,256,512,272,2048,773,8192,1,8476,65536,74046,65664,516,8477,773,649,74046,65536,9117,74298,303,74031,1,76575,8205,65830,257,17,17,276]

theorem envBound41718 : H12AffineFastState.Bounded env41718 := by
  intro p hp
  have h : env41718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41717_41718 : H12AffineEnvironment.transform 5 0 env41717 = env41718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env41717 == env41718) = true)

theorem identity41718 : scanCanonicalize (H12AffineFastState.compose env41718 (packedSelected [1,8,28] rootPS)) = affineNative (2^(8+1) ^^^ 307) := by decide +kernel

theorem selectedBound41718 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env41719 : List Nat := [2,4,8,16,32,0,128,256,307,272,2048,54,8192,1,8476,65536,74046,65664,311,8477,54,442,74046,65536,8366,73993,303,74031,1,75820,8205,65830,257,17,17,276]

theorem envBound41719 : H12AffineFastState.Bounded env41719 := by
  intro p hp
  have h : env41719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41718_41719 : H12AffineEnvironment.transform 8 307 env41718 = env41719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 307 env41718 == env41719) = true)

def env41720 : List Nat := [2,4,8,16,32,0,128,256,307,272,2048,54,8192,1,8476,8488,22,8616,311,8477,54,442,22,8488,8366,33,303,7,1,2308,8205,8206,257,17,17,276]

theorem envBound41720 : H12AffineFastState.Bounded env41720 := by
  intro p hp
  have h : env41720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41719_41720 : H12AffineEnvironment.transform 15 8488 env41719 = env41720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8488 env41719 == env41720) = true)

theorem identity41720 : scanCanonicalize (H12AffineFastState.compose env41720 (packedSelected [0,4,5,9,12,13,16,17,27,38] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound41720 : packedSelected [0,4,5,9,12,13,16,17,27,38] rootPS < 2^1333 := by decide +kernel

def env41721 : List Nat := [2,4,8,16,32,0,128,4,55,20,2048,54,8192,1,8216,8236,22,8364,51,8217,54,190,22,8236,8366,33,43,7,1,2048,8205,8206,5,17,17,16]

theorem envBound41721 : H12AffineFastState.Bounded env41721 := by
  intro p hp
  have h : env41721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41720_41721 : H12AffineEnvironment.transform 7 4 env41720 = env41721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env41720 == env41721) = true)

theorem identity41721 : scanCanonicalize (H12AffineFastState.compose env41721 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound41721 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env41722 : List Nat := [2,4,8,16,32,0,128,4,55,20,2048,54,25,1,1,53,22,181,51,0,54,190,22,53,183,33,43,7,1,2048,20,23,5,17,17,16]

theorem envBound41722 : H12AffineFastState.Bounded env41722 := by
  intro p hp
  have h : env41722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41721_41722 : H12AffineEnvironment.transform 12 25 env41721 = env41722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env41721 == env41722) = true)

theorem identity41722 : scanCanonicalize (H12AffineFastState.compose env41722 (packedSelected [2,3,5,13,15] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound41722 : packedSelected [2,3,5,13,15] rootPS < 2^1333 := by decide +kernel

def env41723 : List Nat := [2,4,8,16,23,0,128,4,0,20,2048,1,25,1,1,2,22,130,4,0,1,137,22,2,128,22,28,7,1,2048,20,23,5,17,17,16]

theorem envBound41723 : H12AffineFastState.Bounded env41723 := by
  intro p hp
  have h : env41723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41722_41723 : H12AffineEnvironment.transform 4 23 env41722 = env41723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env41722 == env41723) = true)

theorem identity41723 : scanCanonicalize (H12AffineFastState.compose env41723 (packedSelected [3,12] rootPS)) = affineNative (2^(10+1) ^^^ 7) := by decide +kernel

theorem selectedBound41723 : packedSelected [3,12] rootPS < 2^1333 := by decide +kernel

def env41724 : List Nat := [2,4,8,16,23,0,128,4,0,20,7,1,25,1,1,2,22,130,4,0,1,137,22,2,128,22,28,7,1,7,20,23,5,17,17,16]

theorem envBound41724 : H12AffineFastState.Bounded env41724 := by
  intro p hp
  have h : env41724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41723_41724 : H12AffineEnvironment.transform 10 7 env41723 = env41724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 7 env41723 == env41724) = true)

theorem identity41724 : scanCanonicalize (H12AffineFastState.compose env41724 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 14) := by decide +kernel

theorem selectedBound41724 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env41725 : List Nat := [2,4,8,16,23,0,14,4,0,20,7,1,25,1,1,2,22,12,4,0,1,7,22,2,14,22,28,7,1,7,20,23,5,17,17,16]

theorem envBound41725 : H12AffineFastState.Bounded env41725 := by
  intro p hp
  have h : env41725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41724_41725 : H12AffineEnvironment.transform 6 14 env41724 = env41725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 14 env41724 == env41725) = true)

theorem identity41725 : scanCanonicalize (H12AffineFastState.compose env41725 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound41725 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41726 : List Nat := [2,4,8,6,1,0,14,4,0,2,7,1,15,1,1,2,0,12,4,0,1,7,0,2,14,0,10,7,1,7,2,1,5,7,7,6]

theorem envBound41726 : H12AffineFastState.Bounded env41726 := by
  intro p hp
  have h : env41726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41725_41726 : H12AffineEnvironment.transform 3 6 env41725 = env41726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env41725 == env41726) = true)

theorem identity41726 : scanCanonicalize (H12AffineFastState.compose env41726 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound41726 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41727 : List Nat := [2,4,4,6,1,0,2,4,0,2,7,1,3,1,1,2,0,0,4,0,1,7,0,2,2,0,6,7,1,7,2,1,5,7,7,6]

theorem envBound41727 : H12AffineFastState.Bounded env41727 := by
  intro p hp
  have h : env41727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41726_41727 : H12AffineEnvironment.transform 2 4 env41726 = env41727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env41726 == env41727) = true)

def env41728 : List Nat := [2,4,8,16,32,0,128,256,307,272,2048,54,8192,1,8476,8489,23,8617,311,8477,54,442,23,8489,8366,32,303,6,1,2309,8205,8207,257,17,17,276]

theorem envBound41728 : H12AffineFastState.Bounded env41728 := by
  intro p hp
  have h : env41728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41719_41728 : H12AffineEnvironment.transform 15 8489 env41719 = env41728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8489 env41719 == env41728) = true)

theorem identity41728 : scanCanonicalize (H12AffineFastState.compose env41728 (packedSelected [0,4,5,9,12,13,16,17,27,38] rootPS)) = affineNative (2^(7+1) ^^^ 3) := by decide +kernel

theorem selectedBound41728 : packedSelected [0,4,5,9,12,13,16,17,27,38] rootPS < 2^1333 := by decide +kernel

def env41729 : List Nat := [2,4,8,16,32,0,128,3,48,19,2048,54,8192,1,8223,8234,23,8362,52,8222,54,185,23,8234,8366,32,44,6,1,2054,8205,8207,2,17,17,23]

theorem envBound41729 : H12AffineFastState.Bounded env41729 := by
  intro p hp
  have h : env41729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41728_41729 : H12AffineEnvironment.transform 7 3 env41728 = env41729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 3 env41728 == env41729) = true)

theorem identity41729 : scanCanonicalize (H12AffineFastState.compose env41729 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound41729 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env41730 : List Nat := [2,4,8,16,32,0,128,3,48,19,2048,54,41,1,54,3,23,131,52,55,54,185,23,3,135,32,44,6,1,2054,36,38,2,17,17,23]

theorem envBound41730 : H12AffineFastState.Bounded env41730 := by
  intro p hp
  have h : env41730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41729_41730 : H12AffineEnvironment.transform 12 41 env41729 = env41730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env41729 == env41730) = true)

theorem identity41730 : scanCanonicalize (H12AffineFastState.compose env41730 (packedSelected [0,2,4,7,8,9,10,11,16] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound41730 : packedSelected [0,2,4,7,8,9,10,11,16] rootPS < 2^1333 := by decide +kernel

def env41731 : List Nat := [2,4,8,16,0,0,128,3,16,19,2048,22,9,1,22,3,23,131,20,23,22,153,23,3,135,0,12,6,1,2054,4,6,2,17,17,23]

theorem envBound41731 : H12AffineFastState.Bounded env41731 := by
  intro p hp
  have h : env41731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41730_41731 : H12AffineEnvironment.transform 4 0 env41730 = env41731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env41730 == env41731) = true)

theorem identity41731 : scanCanonicalize (H12AffineFastState.compose env41731 (packedSelected [2,5] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound41731 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env41732 : List Nat := [2,4,8,16,0,0,19,3,16,19,2048,22,9,1,22,3,23,16,20,23,22,10,23,3,20,0,12,6,1,2054,4,6,2,17,17,23]

theorem envBound41732 : H12AffineFastState.Bounded env41732 := by
  intro p hp
  have h : env41732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41731_41732 : H12AffineEnvironment.transform 6 19 env41731 = env41732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env41731 == env41732) = true)

theorem identity41732 : scanCanonicalize (H12AffineFastState.compose env41732 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 22) := by decide +kernel

theorem selectedBound41732 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env41733 : List Nat := [2,4,8,16,0,0,19,3,16,19,22,22,9,1,22,3,23,16,20,23,22,10,23,3,20,0,12,6,1,16,4,6,2,17,17,23]

theorem envBound41733 : H12AffineFastState.Bounded env41733 := by
  intro p hp
  have h : env41733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41732_41733 : H12AffineEnvironment.transform 10 22 env41732 = env41733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 22 env41732 == env41733) = true)

theorem identity41733 : scanCanonicalize (H12AffineFastState.compose env41733 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound41733 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env41734 : List Nat := [2,4,8,1,0,0,2,3,1,2,7,7,9,1,7,3,6,1,5,6,7,10,6,3,5,0,12,6,1,1,4,6,2,0,0,6]

theorem envBound41734 : H12AffineFastState.Bounded env41734 := by
  intro p hp
  have h : env41734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41733_41734 : H12AffineEnvironment.transform 3 1 env41733 = env41734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env41733 == env41734) = true)

theorem identity41734 : scanCanonicalize (H12AffineFastState.compose env41734 (packedSelected [1,2] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound41734 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env41735 : List Nat := [2,4,5,1,0,0,2,3,1,2,7,7,4,1,7,3,6,1,5,6,7,7,6,3,5,0,1,6,1,1,4,6,2,0,0,6]

theorem envBound41735 : H12AffineFastState.Bounded env41735 := by
  intro p hp
  have h : env41735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41734_41735 : H12AffineEnvironment.transform 2 5 env41734 = env41735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env41734 == env41735) = true)

def env41736 : List Nat := [2,4,8,16,32,1,128,256,512,272,2048,773,8192,1,8477,65536,74047,65664,517,8476,773,649,74046,65537,9116,74298,302,74031,1,76574,8205,65830,257,17,16,277]

theorem envBound41736 : H12AffineFastState.Bounded env41736 := by
  intro p hp
  have h : env41736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41717_41736 : H12AffineEnvironment.transform 5 1 env41717 = env41736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env41717 == env41736) = true)

theorem identity41736 : scanCanonicalize (H12AffineFastState.compose env41736 (packedSelected [1,8,28] rootPS)) = affineNative (2^(12+1) ^^^ 811) := by decide +kernel

theorem selectedBound41736 : packedSelected [1,8,28] rootPS < 2^1333 := by decide +kernel

def env41737 : List Nat := [2,4,8,16,32,1,128,256,512,272,2048,773,811,1,566,65536,66068,65664,517,567,773,649,66069,65537,183,65809,302,66052,1,67637,806,65830,257,17,16,277]

theorem envBound41737 : H12AffineFastState.Bounded env41737 := by
  intro p hp
  have h : env41737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41736_41737 : H12AffineEnvironment.transform 12 811 env41736 = env41737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 811 env41736 == env41737) = true)

def env41738 : List Nat := [2,4,8,16,32,1,128,256,512,272,2048,773,811,1,566,516,16,644,517,567,773,649,17,517,183,789,302,0,1,2609,806,802,257,17,16,277]

theorem envBound41738 : H12AffineFastState.Bounded env41738 := by
  intro p hp
  have h : env41738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41737_41738 : H12AffineEnvironment.transform 15 516 env41737 = env41738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 516 env41737 == env41738) = true)

theorem identity41738 : scanCanonicalize (H12AffineFastState.compose env41738 (packedSelected [13,21] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound41738 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env41739 : List Nat := [2,4,8,16,23,1,128,256,512,272,2048,773,796,1,513,516,16,644,517,512,773,649,17,517,128,789,281,0,1,2566,785,789,257,17,16,277]

theorem envBound41739 : H12AffineFastState.Bounded env41739 := by
  intro p hp
  have h : env41739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41738_41739 : H12AffineEnvironment.transform 4 23 env41738 = env41739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env41738 == env41739) = true)

theorem identity41739 : scanCanonicalize (H12AffineFastState.compose env41739 (packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS)) = affineNative (2^(6+1) ^^^ 25) := by decide +kernel

theorem selectedBound41739 : packedSelected [0,2,3,5,7,10,11,12,13,15,18,20] rootPS < 2^1333 := by decide +kernel

def env41740 : List Nat := [2,4,8,16,23,1,25,256,512,272,2048,773,796,1,513,516,16,541,517,512,773,528,17,517,25,789,281,0,1,2566,785,789,257,17,16,277]

theorem envBound41740 : H12AffineFastState.Bounded env41740 := by
  intro p hp
  have h : env41740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41739_41740 : H12AffineEnvironment.transform 6 25 env41739 = env41740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 25 env41739 == env41740) = true)

theorem identity41740 : scanCanonicalize (H12AffineFastState.compose env41740 (packedSelected [3,5,10,15] rootPS)) = affineNative (2^(10+1) ^^^ 541) := by decide +kernel

theorem selectedBound41740 : packedSelected [3,5,10,15] rootPS < 2^1333 := by decide +kernel

def env41741 : List Nat := [2,4,8,16,23,1,25,256,512,272,541,773,796,1,513,516,16,541,517,512,773,528,17,517,25,789,281,0,1,27,785,789,257,17,16,277]

theorem envBound41741 : H12AffineFastState.Bounded env41741 := by
  intro p hp
  have h : env41741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41740_41741 : H12AffineEnvironment.transform 10 541 env41740 = env41741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 541 env41740 == env41741) = true)

theorem identity41741 : scanCanonicalize (H12AffineFastState.compose env41741 (packedSelected [0,3,5,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 31) := by decide +kernel

theorem selectedBound41741 : packedSelected [0,3,5,7,11] rootPS < 2^1333 := by decide +kernel

def env41742 : List Nat := [2,4,8,16,23,1,25,31,512,15,541,538,515,1,513,516,16,541,517,512,538,528,17,517,25,522,6,0,1,27,526,522,30,17,16,10]

theorem envBound41742 : H12AffineFastState.Bounded env41742 := by
  intro p hp
  have h : env41742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41741_41742 : H12AffineEnvironment.transform 7 31 env41741 = env41742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 31 env41741 == env41742) = true)

theorem identity41742 : scanCanonicalize (H12AffineFastState.compose env41742 (packedSelected [1,2,3,4,5,7] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound41742 : packedSelected [1,2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env41743 : List Nat := [2,4,8,6,1,1,15,9,512,15,523,524,515,1,513,516,6,523,517,512,524,518,7,517,15,522,6,0,1,13,526,522,8,7,6,10]

theorem envBound41743 : H12AffineFastState.Bounded env41743 := by
  intro p hp
  have h : env41743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41742_41743 : H12AffineEnvironment.transform 3 6 env41742 = env41743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env41742 == env41743) = true)

theorem identity41743 : scanCanonicalize (H12AffineFastState.compose env41743 (packedSelected [1,2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound41743 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env41744 : List Nat := [2,3,8,1,1,1,8,9,512,8,523,523,515,1,513,515,1,523,514,512,523,513,0,514,8,522,1,0,1,10,521,522,8,0,1,10]

theorem envBound41744 : H12AffineFastState.Bounded env41744 := by
  intro p hp
  have h : env41744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41743_41744 : H12AffineEnvironment.transform 1 3 env41743 = env41744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env41743 == env41744) = true)

theorem identity41744 : scanCanonicalize (H12AffineFastState.compose env41744 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound41744 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env41745 : List Nat := [2,3,8,1,1,1,8,9,10,8,1,1,9,1,11,9,1,1,8,10,1,11,0,8,8,0,1,0,1,10,3,0,8,0,1,10]

theorem envBound41745 : H12AffineFastState.Bounded env41745 := by
  intro p hp
  have h : env41745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41744_41745 : H12AffineEnvironment.transform 8 10 env41744 = env41745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env41744 == env41745) = true)

def env41746 : List Nat := [2,4,8,16,32,1,128,256,512,272,2048,773,811,1,566,517,17,645,517,567,773,649,16,516,183,788,302,1,1,2608,806,803,257,17,16,277]

theorem envBound41746 : H12AffineFastState.Bounded env41746 := by
  intro p hp
  have h : env41746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41737_41746 : H12AffineEnvironment.transform 15 517 env41737 = env41746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 517 env41737 == env41746) = true)

theorem identity41746 : scanCanonicalize (H12AffineFastState.compose env41746 (packedSelected [13,21] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound41746 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env41747 : List Nat := [2,4,8,16,32,1,128,256,1,272,2048,260,298,1,55,4,17,132,4,54,260,136,16,5,183,277,302,1,1,2097,295,290,257,17,16,277]

theorem envBound41747 : H12AffineFastState.Bounded env41747 := by
  intro p hp
  have h : env41747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41746_41747 : H12AffineEnvironment.transform 8 1 env41746 = env41747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env41746 == env41747) = true)

theorem identity41747 : scanCanonicalize (H12AffineFastState.compose env41747 (packedSelected [0,1,3,4,7,8,9,10,16,17,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 51) := by decide +kernel

theorem selectedBound41747 : packedSelected [0,1,3,4,7,8,9,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env41748 : List Nat := [2,4,8,16,32,1,128,51,1,35,2048,55,25,1,55,4,17,132,4,54,55,136,16,5,183,38,29,1,1,2097,20,17,50,17,16,38]

theorem envBound41748 : H12AffineFastState.Bounded env41748 := by
  intro p hp
  have h : env41748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41747_41748 : H12AffineEnvironment.transform 7 51 env41747 = env41748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 51 env41747 == env41748) = true)

theorem identity41748 : scanCanonicalize (H12AffineFastState.compose env41748 (packedSelected [1,8,12] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound41748 : packedSelected [1,8,12] rootPS < 2^1333 := by decide +kernel

def env41749 : List Nat := [2,4,8,6,32,1,128,37,1,35,2048,33,15,1,33,4,7,132,4,32,33,136,6,5,161,38,11,1,1,2087,2,7,36,7,6,38]

theorem envBound41749 : H12AffineFastState.Bounded env41749 := by
  intro p hp
  have h : env41749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41748_41749 : H12AffineEnvironment.transform 3 6 env41748 = env41749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env41748 == env41749) = true)

theorem identity41749 : scanCanonicalize (H12AffineFastState.compose env41749 (packedSelected [0,1,2,3,7,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 7) := by decide +kernel

theorem selectedBound41749 : packedSelected [0,1,2,3,7,10,11] rootPS < 2^1333 := by decide +kernel

def env41750 : List Nat := [2,4,8,6,32,1,128,37,1,35,7,33,15,1,33,4,7,132,4,32,33,136,6,5,161,38,11,1,1,32,2,7,36,7,6,38]

theorem envBound41750 : H12AffineFastState.Bounded env41750 := by
  intro p hp
  have h : env41750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41749_41750 : H12AffineEnvironment.transform 10 7 env41749 = env41750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 7 env41749 == env41750) = true)

theorem identity41750 : scanCanonicalize (H12AffineFastState.compose env41750 (packedSelected [0,2,3,4,8] rootPS)) = affineNative (2^(6+1) ^^^ 15) := by decide +kernel

theorem selectedBound41750 : packedSelected [0,2,3,4,8] rootPS < 2^1333 := by decide +kernel

def env41751 : List Nat := [2,4,8,6,32,1,15,37,1,35,7,33,15,1,33,4,7,11,4,32,33,7,6,5,46,38,11,1,1,32,2,7,36,7,6,38]

theorem envBound41751 : H12AffineFastState.Bounded env41751 := by
  intro p hp
  have h : env41751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41750_41751 : H12AffineEnvironment.transform 6 15 env41750 = env41751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 15 env41750 == env41751) = true)

theorem identity41751 : scanCanonicalize (H12AffineFastState.compose env41751 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound41751 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41752 : List Nat := [2,4,8,6,0,1,15,5,1,3,7,1,15,1,1,4,7,11,4,0,1,7,6,5,14,6,11,1,1,0,2,7,4,7,6,6]

theorem envBound41752 : H12AffineFastState.Bounded env41752 := by
  intro p hp
  have h : env41752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41751_41752 : H12AffineEnvironment.transform 4 0 env41751 = env41752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env41751 == env41752) = true)

theorem identity41752 : scanCanonicalize (H12AffineFastState.compose env41752 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound41752 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41753 : List Nat := [2,4,3,6,0,1,4,5,1,3,7,1,4,1,1,4,7,0,4,0,1,7,6,5,5,6,0,1,1,0,2,7,4,7,6,6]

theorem envBound41753 : H12AffineFastState.Bounded env41753 := by
  intro p hp
  have h : env41753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41752_41753 : H12AffineEnvironment.transform 2 3 env41752 = env41753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env41752 == env41753) = true)

theorem identity41753 : scanCanonicalize (H12AffineFastState.compose env41753 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound41753 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41754 : List Nat := [2,3,3,1,0,1,3,2,1,3,0,1,3,1,1,3,0,0,3,0,1,0,1,2,2,1,0,1,1,0,2,0,3,0,1,1]

theorem envBound41754 : H12AffineFastState.Bounded env41754 := by
  intro p hp
  have h : env41754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41753_41754 : H12AffineEnvironment.transform 1 3 env41753 = env41754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env41753 == env41754) = true)

def env41755 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1297,8540,65536,74862,65665,4417,8541,4096,5276,74046,66896,13768,78895,1150,74815,1297,81226,8205,65830,257,1281,1345,5953]

theorem envBound41755 : H12AffineFastState.Bounded env41755 := by
  intro p hp
  have h : env41755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41675_41755 : H12AffineEnvironment.transform 17 65665 env41675 = env41755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65665 env41675 == env41755) = true)

theorem identity41755 : scanCanonicalize (H12AffineFastState.compose env41755 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound41755 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env41756 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,80,8192,1297,8540,65536,74862,65665,273,8541,80,1228,74046,66896,9624,74879,1150,74815,1297,77082,8205,65830,257,1281,1345,1809]

theorem envBound41756 : H12AffineFastState.Bounded env41756 := by
  intro p hp
  have h : env41756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41755_41756 : H12AffineEnvironment.transform 11 80 env41755 = env41756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env41755 == env41756) = true)

def env41757 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,80,8192,81,8540,65536,74030,65665,273,8541,80,396,74046,65552,8408,74047,318,74111,81,75866,8205,65830,257,65,1,593]

theorem envBound41757 : H12AffineFastState.Bounded env41757 := by
  intro p hp
  have h : env41757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41756_41757 : H12AffineEnvironment.transform 9 320 env41756 = env41757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env41756 == env41757) = true)

theorem identity41757 : scanCanonicalize (H12AffineFastState.compose env41757 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 8298) := by decide +kernel

theorem selectedBound41757 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env41758 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,80,8192,81,8540,8298,324,8427,273,8541,80,396,340,8314,8408,341,318,277,81,2096,8205,8524,257,65,1,593]

theorem envBound41758 : H12AffineFastState.Bounded env41758 := by
  intro p hp
  have h : env41758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41757_41758 : H12AffineEnvironment.transform 15 8298 env41757 = env41758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8298 env41757 == env41758) = true)

theorem identity41758 : scanCanonicalize (H12AffineFastState.compose env41758 (packedSelected [2,4,9,13,16,21,23,32] rootPS)) = affineNative (2^(12+1) ^^^ 656) := by decide +kernel

theorem selectedBound41758 : packedSelected [2,4,9,13,16,21,23,32] rootPS < 2^1333 := by decide +kernel

def env41759 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,80,656,81,972,762,324,635,273,973,80,396,340,746,584,341,318,277,81,2096,669,988,257,65,1,593]

theorem envBound41759 : H12AffineFastState.Bounded env41759 := by
  intro p hp
  have h : env41759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41758_41759 : H12AffineEnvironment.transform 12 656 env41758 = env41759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 656 env41758 == env41759) = true)

theorem identity41759 : scanCanonicalize (H12AffineFastState.compose env41759 (packedSelected [1,2,3,4,5,8,9,10,11,13,16,18,19,24,28] rootPS)) = affineNative (2^(10+1) ^^^ 587) := by decide +kernel

theorem selectedBound41759 : packedSelected [1,2,3,4,5,8,9,10,11,13,16,18,19,24,28] rootPS < 2^1333 := by decide +kernel

def env41760 : List Nat := [2,4,8,16,32,64,128,256,512,320,587,80,656,81,972,762,324,635,273,973,80,396,340,746,584,341,318,277,81,635,669,988,257,65,1,593]

theorem envBound41760 : H12AffineFastState.Bounded env41760 := by
  intro p hp
  have h : env41760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41759_41760 : H12AffineEnvironment.transform 10 587 env41759 = env41760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 587 env41759 == env41760) = true)

theorem identity41760 : scanCanonicalize (H12AffineFastState.compose env41760 (packedSelected [0,3,5,7,10,16] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound41760 : packedSelected [0,3,5,7,10,16] rootPS < 2^1333 := by decide +kernel

def env41761 : List Nat := [2,4,8,16,32,64,128,172,512,236,587,80,656,81,608,762,232,635,189,609,80,32,248,746,584,249,146,185,81,635,669,624,173,65,1,593]

theorem envBound41761 : H12AffineFastState.Bounded env41761 := by
  intro p hp
  have h : env41761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41760_41761 : H12AffineEnvironment.transform 7 172 env41760 = env41761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env41760 == env41761) = true)

theorem identity41761 : scanCanonicalize (H12AffineFastState.compose env41761 (packedSelected [0,1,3,5,7,8,12] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound41761 : packedSelected [0,1,3,5,7,8,12] rootPS < 2^1333 := by decide +kernel

def env41762 : List Nat := [2,4,8,16,17,64,128,157,512,221,587,80,656,81,593,715,217,586,140,592,80,17,201,731,584,200,146,136,81,586,669,577,156,65,1,593]

theorem envBound41762 : H12AffineFastState.Bounded env41762 := by
  intro p hp
  have h : env41762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41761_41762 : H12AffineEnvironment.transform 4 17 env41761 = env41762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env41761 == env41762) = true)

theorem identity41762 : scanCanonicalize (H12AffineFastState.compose env41762 (packedSelected [1,7,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound41762 : packedSelected [1,7,8,9] rootPS < 2^1333 := by decide +kernel

def env41763 : List Nat := [2,4,8,16,17,64,128,157,136,221,195,80,24,81,217,67,217,194,140,216,80,17,201,83,192,200,146,136,81,194,21,201,156,65,1,217]

theorem envBound41763 : H12AffineFastState.Bounded env41763 := by
  intro p hp
  have h : env41763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41762_41763 : H12AffineEnvironment.transform 8 136 env41762 = env41763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env41762 == env41763) = true)

theorem identity41763 : scanCanonicalize (H12AffineFastState.compose env41763 (packedSelected [4,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound41763 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env41764 : List Nat := [2,4,8,10,11,64,128,135,136,199,195,74,2,75,195,67,195,194,140,194,74,11,201,73,192,200,136,136,75,194,15,201,134,65,1,195]

theorem envBound41764 : H12AffineFastState.Bounded env41764 := by
  intro p hp
  have h : env41764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41763_41764 : H12AffineEnvironment.transform 3 10 env41763 = env41764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env41763 == env41764) = true)

theorem identity41764 : scanCanonicalize (H12AffineFastState.compose env41764 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 66) := by decide +kernel

theorem selectedBound41764 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41765 : List Nat := [2,4,8,10,11,64,66,69,74,5,1,74,2,75,1,67,1,0,78,0,74,11,11,73,2,10,74,74,75,0,15,11,68,65,1,1]

theorem envBound41765 : H12AffineFastState.Bounded env41765 := by
  intro p hp
  have h : env41765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41764_41765 : H12AffineEnvironment.transform 6 66 env41764 = env41765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 66 env41764 == env41765) = true)

theorem identity41765 : scanCanonicalize (H12AffineFastState.compose env41765 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound41765 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41766 : List Nat := [2,4,8,10,11,11,9,14,1,5,1,1,2,0,1,8,1,0,5,0,1,11,11,2,2,10,1,1,0,0,15,11,15,10,1,1]

theorem envBound41766 : H12AffineFastState.Bounded env41766 := by
  intro p hp
  have h : env41766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41765_41766 : H12AffineEnvironment.transform 5 11 env41765 = env41766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env41765 == env41766) = true)

theorem identity41766 : scanCanonicalize (H12AffineFastState.compose env41766 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound41766 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41767 : List Nat := [2,2,8,10,11,11,9,8,1,3,1,1,2,0,1,8,1,0,3,0,1,11,11,2,2,10,1,1,0,0,9,11,9,10,1,1]

theorem envBound41767 : H12AffineFastState.Bounded env41767 := by
  intro p hp
  have h : env41767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41766_41767 : H12AffineEnvironment.transform 1 2 env41766 = env41767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env41766 == env41767) = true)

def env41768 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,80,8192,80,8540,65536,74031,65665,273,8541,80,397,74046,65553,8409,74046,319,74110,80,75867,8205,65830,257,64,0,592]

theorem envBound41768 : H12AffineFastState.Bounded env41768 := by
  intro p hp
  have h : env41768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41756_41768 : H12AffineEnvironment.transform 9 321 env41756 = env41768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env41756 == env41768) = true)

theorem identity41768 : scanCanonicalize (H12AffineFastState.compose env41768 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 8250) := by decide +kernel

end H12CloudChart2