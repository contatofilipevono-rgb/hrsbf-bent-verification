import H12CloudChart2Data036

namespace H12CloudChart2

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans9025_9026 : H12AffineEnvironment.transform 3 1 env9025 = env9026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env9025 == env9026) = true)

theorem identity9026 : scanCanonicalize (H12AffineFastState.compose env9026 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound9026 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9027 : List Nat := [2,4,2,1,1,0,2,4,0,5,1,0,2,0,0,3,0,1,5,0,1,0,1,3,3,0,0,0,0,0,5,0,5,0,1,1]

theorem envBound9027 : H12AffineFastState.Bounded env9027 := by
  intro p hp
  have h : env9027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9026_9027 : H12AffineEnvironment.transform 2 2 env9026 = env9027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env9026 == env9027) = true)

def env9028 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4097,262144,1024,32768,1345,4194304,17664,98564,33554432,5377,4473876,16384,4176,4315355,1284,4294967296,257,4332843382,4096,33563272]

theorem envBound9028 : H12AffineFastState.Bounded env9028 := by
  intro p hp
  have h : env9028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8990_9028 : H12AffineEnvironment.transform 16 4097 env8990 = env9028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4097 env8990 == env9028) = true)

def env9029 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,16384,32768,65536,1345,262144,1024,32768,1345,4194304,17664,98564,33554432,65,4473876,16384,1296,4312475,1284,4294967296,257,4332839990,1344,33563272]

theorem envBound9029 : H12AffineFastState.Bounded env9029 := by
  intro p hp
  have h : env9029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9028_9029 : H12AffineEnvironment.transform 11 1344 env9028 = env9029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1344 env9028 == env9029) = true)

theorem identity9029 : scanCanonicalize (H12AffineFastState.compose env9029 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(24+1) ^^^ 26008) := by decide +kernel

theorem selectedBound9029 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env9030 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,16384,32768,65536,1345,262144,1024,32768,1345,4194304,17664,98564,26008,65,4473876,16384,1296,4312475,1284,4294967296,257,4299260334,1344,18192]

theorem envBound9030 : H12AffineFastState.Bounded env9030 := by
  intro p hp
  have h : env9030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9029_9030 : H12AffineEnvironment.transform 24 26008 env9029 = env9030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 26008 env9029 == env9030) = true)

theorem identity9030 : scanCanonicalize (H12AffineFastState.compose env9030 (packedSelected [0,1,3,4,5,7,8,12,13,15,16,20,21,22] rootPS)) = affineNative (2^(14+1) ^^^ 19776) := by decide +kernel

theorem selectedBound9030 : packedSelected [0,1,3,4,5,7,8,12,13,15,16,20,21,22] rootPS < 2^1333 := by decide +kernel

def env9031 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,16384,19776,65536,1345,262144,1024,19776,1345,4194304,17664,85060,26008,65,4473876,16384,1296,4260059,1284,4294967296,257,4299246830,1344,18192]

theorem envBound9031 : H12AffineFastState.Bounded env9031 := by
  intro p hp
  have h : env9031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9030_9031 : H12AffineEnvironment.transform 14 19776 env9030 = env9031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 19776 env9030 == env9031) = true)

theorem identity9031 : scanCanonicalize (H12AffineFastState.compose env9031 (packedSelected [3,10,13,15,17,21,24] rootPS)) = affineNative (2^(21+1) ^^^ 74482) := by decide +kernel

theorem selectedBound9031 : packedSelected [3,10,13,15,17,21,24] rootPS < 2^1333 := by decide +kernel

def env9032 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,16384,19776,65536,1345,262144,1024,19776,1345,74482,17664,85060,26008,65,354022,16384,1296,8745,1284,4294967296,257,4294995484,1344,18192]

theorem envBound9032 : H12AffineFastState.Bounded env9032 := by
  intro p hp
  have h : env9032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9031_9032 : H12AffineEnvironment.transform 21 74482 env9031 = env9032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 74482 env9031 == env9032) = true)

theorem identity9032 : scanCanonicalize (H12AffineFastState.compose env9032 (packedSelected [6,25] rootPS)) = affineNative (2^(13+1) ^^^ 1297) := by decide +kernel

theorem selectedBound9032 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env9033 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,2129,65536,1345,262144,1024,2129,1345,74482,17,67925,8329,65,336887,1297,1296,8745,1284,4294967296,257,4294978317,1344,513]

theorem envBound9033 : H12AffineFastState.Bounded env9033 := by
  intro p hp
  have h : env9033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9032_9033 : H12AffineEnvironment.transform 13 1297 env9032 = env9033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env9032 == env9033) = true)

theorem identity9033 : scanCanonicalize (H12AffineFastState.compose env9033 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 2730) := by decide +kernel

theorem selectedBound9033 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9034 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,2129,2730,1345,262144,1024,2129,1345,10328,17,1023,8329,65,272733,1297,1296,8745,1284,4294967296,257,4294978317,1344,513]

theorem envBound9034 : H12AffineFastState.Bounded env9034 := by
  intro p hp
  have h : env9034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9033_9034 : H12AffineEnvironment.transform 15 2730 env9033 = env9034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2730 env9033 == env9034) = true)

theorem identity9034 : scanCanonicalize (H12AffineFastState.compose env9034 (packedSelected [1,12,13] rootPS)) = affineNative (2^(31+1) ^^^ 8623) := by decide +kernel

theorem selectedBound9034 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env9035 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1344,8192,1297,2129,2730,1345,262144,1024,2129,1345,10328,17,1023,8329,65,272733,1297,1296,8745,1284,8623,257,2722,1344,513]

theorem envBound9035 : H12AffineFastState.Bounded env9035 := by
  intro p hp
  have h : env9035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9034_9035 : H12AffineEnvironment.transform 31 8623 env9034 = env9035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 8623 env9034 == env9035) = true)

theorem identity9035 : scanCanonicalize (H12AffineFastState.compose env9035 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 423) := by decide +kernel

theorem selectedBound9035 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env9036 : List Nat := [2,4,8,16,32,64,128,256,512,1024,423,1344,8192,1297,502,781,1345,262144,1024,502,1345,8703,17,1023,8329,65,270586,1297,1296,8745,1284,8623,257,773,1344,513]

theorem envBound9036 : H12AffineFastState.Bounded env9036 := by
  intro p hp
  have h : env9036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9035_9036 : H12AffineEnvironment.transform 10 423 env9035 = env9036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 423 env9035 == env9036) = true)

theorem identity9036 : scanCanonicalize (H12AffineFastState.compose env9036 (packedSelected [1,5,8,12,17] rootPS)) = affineNative (2^(12+1) ^^^ 763) := by decide +kernel

theorem selectedBound9036 : packedSelected [1,5,8,12,17] rootPS < 2^1333 := by decide +kernel

def env9037 : List Nat := [2,4,8,16,32,64,128,256,512,1024,423,1344,763,1297,502,781,1345,262144,1024,502,1345,772,17,1023,626,65,262657,1297,1296,210,1284,852,257,773,1344,513]

theorem envBound9037 : H12AffineFastState.Bounded env9037 := by
  intro p hp
  have h : env9037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9036_9037 : H12AffineEnvironment.transform 12 763 env9036 = env9037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 763 env9036 == env9037) = true)

theorem identity9037 : scanCanonicalize (H12AffineFastState.compose env9037 (packedSelected [0,6,11,18] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound9037 : packedSelected [0,6,11,18] rootPS < 2^1333 := by decide +kernel

def env9038 : List Nat := [2,4,8,16,32,17,128,256,512,1024,423,1297,682,1297,423,781,1296,262144,1024,423,1296,772,17,942,547,16,262657,1297,1296,131,1284,773,257,773,1297,513]

theorem envBound9038 : H12AffineFastState.Bounded env9038 := by
  intro p hp
  have h : env9038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9037_9038 : H12AffineEnvironment.transform 5 17 env9037 = env9038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env9037 == env9038) = true)

theorem identity9038 : scanCanonicalize (H12AffineFastState.compose env9038 (packedSelected [1,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound9038 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env9039 : List Nat := [2,4,8,16,32,17,128,36,512,1024,131,1077,682,1077,131,553,1076,262144,1024,131,1076,544,17,650,547,16,262657,1077,1076,131,1056,545,37,545,1077,513]

theorem envBound9039 : H12AffineFastState.Bounded env9039 := by
  intro p hp
  have h : env9039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9038_9039 : H12AffineEnvironment.transform 7 36 env9038 = env9039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env9038 == env9039) = true)

theorem identity9039 : scanCanonicalize (H12AffineFastState.compose env9039 (packedSelected [0,2,6] rootPS)) = affineNative (2^(17+1) ^^^ 147) := by decide +kernel

theorem selectedBound9039 : packedSelected [0,2,6] rootPS < 2^1333 := by decide +kernel

def env9040 : List Nat := [2,4,8,16,32,17,128,36,512,1024,131,1077,682,1077,131,553,1076,147,1024,131,1076,544,17,650,547,16,658,1077,1076,131,1056,545,37,545,1077,513]

theorem envBound9040 : H12AffineFastState.Bounded env9040 := by
  intro p hp
  have h : env9040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9039_9040 : H12AffineEnvironment.transform 17 147 env9039 = env9040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 147 env9039 == env9040) = true)

theorem identity9040 : scanCanonicalize (H12AffineFastState.compose env9040 (packedSelected [1,3,8] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound9040 : packedSelected [1,3,8] rootPS < 2^1333 := by decide +kernel

def env9041 : List Nat := [2,4,8,16,32,17,128,36,1,1024,131,1077,171,1077,131,40,1076,147,1024,131,1076,33,17,139,34,16,147,1077,1076,131,1056,32,37,32,1077,0]

theorem envBound9041 : H12AffineFastState.Bounded env9041 := by
  intro p hp
  have h : env9041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9040_9041 : H12AffineEnvironment.transform 8 1 env9040 = env9041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env9040 == env9041) = true)

theorem identity9041 : scanCanonicalize (H12AffineFastState.compose env9041 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 51) := by decide +kernel

theorem selectedBound9041 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9042 : List Nat := [2,4,8,16,32,17,51,36,1,1024,48,1077,24,1077,48,40,1076,32,1024,48,1076,33,17,56,34,16,32,1077,1076,48,1056,32,37,32,1077,0]

theorem envBound9042 : H12AffineFastState.Bounded env9042 := by
  intro p hp
  have h : env9042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9041_9042 : H12AffineEnvironment.transform 6 51 env9041 = env9042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 51 env9041 == env9042) = true)

theorem identity9042 : scanCanonicalize (H12AffineFastState.compose env9042 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound9042 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9043 : List Nat := [2,4,8,16,32,17,51,36,1,20,48,33,24,33,48,40,32,32,20,48,32,33,17,56,34,16,32,33,32,48,52,32,37,32,33,0]

theorem envBound9043 : H12AffineFastState.Bounded env9043 := by
  intro p hp
  have h : env9043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9042_9043 : H12AffineEnvironment.transform 9 20 env9042 = env9043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env9042 == env9043) = true)

theorem identity9043 : scanCanonicalize (H12AffineFastState.compose env9043 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound9043 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env9044 : List Nat := [2,4,8,16,27,17,8,31,1,20,11,26,24,26,11,19,27,27,20,11,27,26,17,3,25,16,27,26,27,11,15,27,30,27,26,0]

theorem envBound9044 : H12AffineFastState.Bounded env9044 := by
  intro p hp
  have h : env9044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9043_9044 : H12AffineEnvironment.transform 4 27 env9043 = env9044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env9043 == env9044) = true)

def env9045 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,16384,32768,65536,1344,262144,1024,32768,1345,4194304,17664,98564,33554432,64,4473876,16384,1297,4312474,1284,4294967296,257,4332839991,1345,33563272]

theorem envBound9045 : H12AffineFastState.Bounded env9045 := by
  intro p hp
  have h : env9045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9028_9045 : H12AffineEnvironment.transform 11 1345 env9028 = env9045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env9028 == env9045) = true)

theorem identity9045 : scanCanonicalize (H12AffineFastState.compose env9045 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(24+1) ^^^ 8328) := by decide +kernel

theorem selectedBound9045 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env9046 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,16384,32768,65536,1344,262144,1024,32768,1345,4194304,17664,98564,8328,64,4473876,16384,1297,4312474,1284,4294967296,257,4299277503,1345,512]

theorem envBound9046 : H12AffineFastState.Bounded env9046 := by
  intro p hp
  have h : env9046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9045_9046 : H12AffineEnvironment.transform 24 8328 env9045 = env9046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8328 env9045 == env9046) = true)

theorem identity9046 : scanCanonicalize (H12AffineFastState.compose env9046 (packedSelected [4,9,16] rootPS)) = affineNative (2^(21+1) ^^^ 17565) := by decide +kernel

theorem selectedBound9046 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env9047 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,16384,32768,65536,1344,262144,1024,32768,1345,17565,17664,98564,8328,64,262281,16384,1297,100615,1284,4294967296,257,4295065634,1345,512]

theorem envBound9047 : H12AffineFastState.Bounded env9047 := by
  intro p hp
  have h : env9047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9046_9047 : H12AffineEnvironment.transform 21 17565 env9046 = env9047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 17565 env9046 == env9047) = true)

theorem identity9047 : scanCanonicalize (H12AffineFastState.compose env9047 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 106538) := by decide +kernel

theorem selectedBound9047 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env9048 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,16384,32768,65536,1344,262144,1024,32768,1345,17565,17664,98564,8328,64,262281,16384,1297,100615,1284,106538,257,8200,1345,512]

theorem envBound9048 : H12AffineFastState.Bounded env9048 := by
  intro p hp
  have h : env9048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9047_9048 : H12AffineEnvironment.transform 31 106538 env9047 = env9048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 106538 env9047 == env9048) = true)

theorem identity9048 : scanCanonicalize (H12AffineFastState.compose env9048 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 1962) := by decide +kernel

theorem selectedBound9048 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9049 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,16384,32768,1962,1344,262144,1024,32768,1345,17565,17664,34478,8328,64,262281,16384,1297,36525,1284,42880,257,8200,1345,512]

theorem envBound9049 : H12AffineFastState.Bounded env9049 := by
  intro p hp
  have h : env9049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9048_9049 : H12AffineEnvironment.transform 15 1962 env9048 = env9049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1962 env9048 == env9049) = true)

theorem identity9049 : scanCanonicalize (H12AffineFastState.compose env9049 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 17429) := by decide +kernel

theorem selectedBound9049 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env9050 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8192,16384,17429,1962,1344,262144,1024,17429,1345,17565,17664,17083,8328,64,262281,16384,1297,19128,1284,25493,257,8200,1345,512]

theorem envBound9050 : H12AffineFastState.Bounded env9050 := by
  intro p hp
  have h : env9050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9049_9050 : H12AffineEnvironment.transform 14 17429 env9049 = env9050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 17429 env9049 == env9050) = true)

theorem identity9050 : scanCanonicalize (H12AffineFastState.compose env9050 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound9050 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env9051 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8,16384,17429,1962,1344,262144,1024,17429,1345,17565,17664,17083,128,64,262281,16384,1297,19128,1284,17309,257,0,1345,512]

theorem envBound9051 : H12AffineFastState.Bounded env9051 := by
  intro p hp
  have h : env9051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9050_9051 : H12AffineEnvironment.transform 12 8 env9050 = env9051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env9050 == env9051) = true)

theorem identity9051 : scanCanonicalize (H12AffineFastState.compose env9051 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound9051 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env9052 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8,16384,17429,1962,1344,2341,1024,17429,1345,17565,17664,17083,128,64,2476,16384,1297,19128,1284,17309,257,0,1345,512]

theorem envBound9052 : H12AffineFastState.Bounded env9052 := by
  intro p hp
  have h : env9052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9051_9052 : H12AffineEnvironment.transform 17 2341 env9051 = env9052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env9051 == env9052) = true)

theorem identity9052 : scanCanonicalize (H12AffineFastState.compose env9052 (packedSelected [1,3,8,12,17,24] rootPS)) = affineNative (2^(13+1) ^^^ 185) := by decide +kernel

theorem selectedBound9052 : packedSelected [1,3,8,12,17,24] rootPS < 2^1333 := by decide +kernel

def env9053 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1345,8,185,1196,1962,1344,2341,1024,1196,1345,1060,1465,514,128,64,2476,185,1297,2561,1284,804,257,0,1345,512]

theorem envBound9053 : H12AffineFastState.Bounded env9053 := by
  intro p hp
  have h : env9053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9052_9053 : H12AffineEnvironment.transform 13 185 env9052 = env9053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 185 env9052 == env9053) = true)

theorem identity9053 : scanCanonicalize (H12AffineFastState.compose env9053 (packedSelected [8,12,13,28] rootPS)) = affineNative (2^(9+1) ^^^ 425) := by decide +kernel

theorem selectedBound9053 : packedSelected [8,12,13,28] rootPS < 2^1333 := by decide +kernel

def env9054 : List Nat := [2,4,8,16,32,64,128,256,512,425,2048,232,8,185,261,515,233,2341,425,261,232,397,16,514,128,64,2476,185,184,2561,173,804,257,0,232,512]

theorem envBound9054 : H12AffineFastState.Bounded env9054 := by
  intro p hp
  have h : env9054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9053_9054 : H12AffineEnvironment.transform 9 425 env9053 = env9054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 425 env9053 == env9054) = true)

theorem identity9054 : scanCanonicalize (H12AffineFastState.compose env9054 (packedSelected [1,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 940) := by decide +kernel

theorem selectedBound9054 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env9055 : List Nat := [2,4,8,16,32,64,128,256,512,425,940,232,8,185,261,515,233,649,425,261,232,397,16,514,128,64,512,185,184,429,173,804,257,0,232,512]

theorem envBound9055 : H12AffineFastState.Bounded env9055 := by
  intro p hp
  have h : env9055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9054_9055 : H12AffineEnvironment.transform 10 940 env9054 = env9055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 940 env9054 == env9055) = true)

theorem identity9055 : scanCanonicalize (H12AffineFastState.compose env9055 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound9055 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env9056 : List Nat := [2,4,8,16,32,64,128,172,512,5,512,232,8,185,169,515,233,649,5,169,232,33,16,514,128,64,512,185,184,1,173,648,173,0,232,512]

theorem envBound9056 : H12AffineFastState.Bounded env9056 := by
  intro p hp
  have h : env9056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9055_9056 : H12AffineEnvironment.transform 7 172 env9055 = env9056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env9055 == env9056) = true)

theorem identity9056 : scanCanonicalize (H12AffineFastState.compose env9056 (packedSelected [0,2,7] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound9056 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env9057 : List Nat := [2,4,8,16,32,64,41,5,512,5,512,65,8,16,0,515,64,544,5,0,65,33,16,514,41,64,512,16,17,1,4,545,4,0,65,512]

theorem envBound9057 : H12AffineFastState.Bounded env9057 := by
  intro p hp
  have h : env9057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9056_9057 : H12AffineEnvironment.transform 6 41 env9056 = env9057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env9056 == env9057) = true)

theorem identity9057 : scanCanonicalize (H12AffineFastState.compose env9057 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 35) := by decide +kernel

theorem selectedBound9057 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9058 : List Nat := [2,4,8,16,32,35,41,5,512,5,512,34,8,16,0,515,35,544,5,0,34,33,16,514,41,35,512,16,17,1,4,545,4,0,34,512]

theorem envBound9058 : H12AffineFastState.Bounded env9058 := by
  intro p hp
  have h : env9058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9057_9058 : H12AffineEnvironment.transform 5 35 env9057 = env9058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 35 env9057 == env9058) = true)

theorem identity9058 : scanCanonicalize (H12AffineFastState.compose env9058 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound9058 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env9059 : List Nat := [2,4,8,16,32,35,41,5,11,5,11,34,8,16,0,8,35,43,5,0,34,33,16,9,41,35,11,16,17,1,4,42,4,0,34,11]

theorem envBound9059 : H12AffineFastState.Bounded env9059 := by
  intro p hp
  have h : env9059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9058_9059 : H12AffineEnvironment.transform 8 11 env9058 = env9059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env9058 == env9059) = true)

theorem identity9059 : scanCanonicalize (H12AffineFastState.compose env9059 (packedSelected [3,8] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound9059 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env9060 : List Nat := [2,4,8,2,32,35,41,5,11,5,11,34,8,2,0,8,35,43,5,0,34,33,2,9,41,35,11,2,3,1,4,42,4,0,34,11]

theorem envBound9060 : H12AffineFastState.Bounded env9060 := by
  intro p hp
  have h : env9060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9059_9060 : H12AffineEnvironment.transform 3 2 env9059 = env9060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env9059 == env9060) = true)

theorem identity9060 : scanCanonicalize (H12AffineFastState.compose env9060 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound9060 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env9061 : List Nat := [2,4,8,2,10,9,3,5,11,5,11,8,8,2,0,8,9,1,5,0,8,11,2,9,3,9,11,2,3,1,4,0,4,0,8,11]

theorem envBound9061 : H12AffineFastState.Bounded env9061 := by
  intro p hp
  have h : env9061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9060_9061 : H12AffineEnvironment.transform 4 10 env9060 = env9061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env9060 == env9061) = true)

def env9062 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,136513,4194304,17664,16777216,33554432,67108864,21484817,67130625,131152,71421403,16876545,4294967296,256,4416628082,131073,33563272]

theorem envBound9062 : H12AffineFastState.Bounded env9062 := by
  intro p hp
  have h : env9062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8960_9062 : H12AffineEnvironment.transform 18 1025 env8960 = env9062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env8960 == env9062) = true)

def env9063 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,136513,4194304,17664,16777216,33554432,5376,21484817,16385,131152,4315355,16876545,4294967296,256,4349522034,131073,33563272]

theorem envBound9063 : H12AffineFastState.Bounded env9063 := by
  intro p hp
  have h : env9063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9062_9063 : H12AffineEnvironment.transform 25 5376 env9062 = env9063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 5376 env9062 == env9063) = true)

def env9064 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,136513,4194304,17664,16777216,33554432,5377,21484817,16384,131152,4315354,16876545,4294967296,256,4349522035,131073,33563272]

theorem envBound9064 : H12AffineFastState.Bounded env9064 := by
  intro p hp
  have h : env9064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9062_9064 : H12AffineEnvironment.transform 25 5377 env9062 = env9064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 5377 env9062 == env9064) = true)

theorem identity9064 : scanCanonicalize (H12AffineFastState.compose env9064 (packedSelected [4,6,7,9,16,20,25,27] rootPS)) = affineNative (2^(16+1) ^^^ 1344) := by decide +kernel

theorem selectedBound9064 : packedSelected [4,6,7,9,16,20,25,27] rootPS < 2^1333 := by decide +kernel

def env9065 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,1025,32768,4097,4194304,17664,16777216,33554432,5377,21352529,16384,1296,4315354,16876545,4294967296,256,4349522035,1345,33563272]

theorem envBound9065 : H12AffineFastState.Bounded env9065 := by
  intro p hp
  have h : env9065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9064_9065 : H12AffineEnvironment.transform 16 1344 env9064 = env9065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env9064 == env9065) = true)

theorem identity9065 : scanCanonicalize (H12AffineFastState.compose env9065 (packedSelected [6,25] rootPS)) = affineNative (2^(24+1) ^^^ 8329) := by decide +kernel

theorem selectedBound9065 : packedSelected [6,25] rootPS < 2^1333 := by decide +kernel

def env9066 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,1025,32768,4097,4194304,17664,16777216,8329,5377,21352529,16384,1296,4315354,16876545,4294967296,256,4315959546,1345,513]

theorem envBound9066 : H12AffineFastState.Bounded env9066 := by
  intro p hp
  have h : env9066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9065_9066 : H12AffineEnvironment.transform 24 8329 env9065 = env9066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8329 env9065 == env9066) = true)

theorem identity9066 : scanCanonicalize (H12AffineFastState.compose env9066 (packedSelected [4,9,16] rootPS)) = affineNative (2^(23+1) ^^^ 98565) := by decide +kernel

theorem selectedBound9066 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env9067 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,1025,32768,4097,4194304,17664,98565,8329,5377,4477268,16384,1296,4315354,1284,4294967296,256,4299280895,1345,513]

theorem envBound9067 : H12AffineFastState.Bounded env9067 := by
  intro p hp
  have h : env9067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9066_9067 : H12AffineEnvironment.transform 23 98565 env9066 = env9067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98565 env9066 == env9067) = true)

theorem identity9067 : scanCanonicalize (H12AffineFastState.compose env9067 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound9067 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env9068 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,1344,262144,1025,32768,4097,4194304,5457,98565,8329,5377,4456709,4177,1296,4294795,1284,4294967296,256,4299260334,1345,513]

theorem envBound9068 : H12AffineFastState.Bounded env9068 := by
  intro p hp
  have h : env9068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9067_9068 : H12AffineEnvironment.transform 13 4177 env9067 = env9068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env9067 == env9068) = true)

theorem identity9068 : scanCanonicalize (H12AffineFastState.compose env9068 (packedSelected [3,5,10] rootPS)) = affineNative (2^(31+1) ^^^ 4236125) := by decide +kernel

theorem selectedBound9068 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9069 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,1344,262144,1025,32768,4097,4194304,5457,98565,8329,5377,4456709,4177,1296,4294795,1284,4236125,256,74483,1345,513]

theorem envBound9069 : H12AffineFastState.Bounded env9069 := by
  intro p hp
  have h : env9069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9068_9069 : H12AffineEnvironment.transform 31 4236125 env9068 = env9069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 4236125 env9068 == env9069) = true)

theorem identity9069 : scanCanonicalize (H12AffineFastState.compose env9069 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(21+1) ^^^ 79674) := by decide +kernel

theorem selectedBound9069 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env9070 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,1344,262144,1025,32768,4097,79674,5457,98565,8329,5377,341567,4177,1296,49073,1284,103527,256,74483,1345,513]

theorem envBound9070 : H12AffineFastState.Bounded env9070 := by
  intro p hp
  have h : env9070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9069_9070 : H12AffineEnvironment.transform 21 79674 env9069 = env9070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 79674 env9069 == env9070) = true)

theorem identity9070 : scanCanonicalize (H12AffineFastState.compose env9070 (packedSelected [0,7,20] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound9070 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env9071 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,4177,32768,65536,1344,262144,1025,32768,4097,79283,5457,98565,8329,5377,341174,4177,1296,48440,1284,103527,256,73850,1345,136]

theorem envBound9071 : H12AffineFastState.Bounded env9071 := by
  intro p hp
  have h : env9071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9070_9071 : H12AffineEnvironment.transform 8 137 env9070 = env9071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env9070 == env9071) = true)

theorem identity9071 : scanCanonicalize (H12AffineFastState.compose env9071 (packedSelected [1,12,13] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound9071 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env9072 : List Nat := [2,4,8,16,32,64,128,5,137,1024,2048,4096,8192,4177,32768,65536,1093,262144,1025,32768,4097,79030,5204,98304,8329,5124,341174,4177,1045,48189,1025,103527,5,73850,1092,136]

theorem envBound9072 : H12AffineFastState.Bounded env9072 := by
  intro p hp
  have h : env9072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9071_9072 : H12AffineEnvironment.transform 7 5 env9071 = env9072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env9071 == env9072) = true)

def env9073 : List Nat := [2,4,8,16,32,64,128,5,137,1024,2048,4096,8192,4177,8200,65536,1093,262144,1025,8200,4097,79030,5204,73736,8329,5124,341174,4177,1045,7221,1025,78959,5,73850,1092,136]

theorem envBound9073 : H12AffineFastState.Bounded env9073 := by
  intro p hp
  have h : env9073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9072_9073 : H12AffineEnvironment.transform 14 8200 env9072 = env9073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8200 env9072 == env9073) = true)

theorem identity9073 : scanCanonicalize (H12AffineFastState.compose env9073 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 74893) := by decide +kernel

theorem selectedBound9073 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env9074 : List Nat := [2,4,8,16,32,64,128,5,137,1024,2048,4096,8192,4177,8200,65536,1093,74893,1025,8200,4097,79030,5204,73736,8329,5124,4155,4177,1045,7221,1025,78959,5,73850,1092,136]

theorem envBound9074 : H12AffineFastState.Bounded env9074 := by
  intro p hp
  have h : env9074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9073_9074 : H12AffineEnvironment.transform 17 74893 env9073 = env9074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 74893 env9073 == env9074) = true)

def env9075 : List Nat := [2,4,8,16,32,64,128,5,137,1024,2048,4096,8192,4177,8200,1156,1093,8201,1025,8200,4097,12338,5204,9356,8329,5124,4155,4177,1045,7221,1025,12523,5,9470,1092,136]

theorem envBound9075 : H12AffineFastState.Bounded env9075 := by
  intro p hp
  have h : env9075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9074_9075 : H12AffineEnvironment.transform 15 1156 env9074 = env9075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1156 env9074 == env9075) = true)

theorem identity9075 : scanCanonicalize (H12AffineFastState.compose env9075 (packedSelected [7] rootPS)) = affineNative (2^(12+1) ^^^ 4147) := by decide +kernel

theorem selectedBound9075 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env9076 : List Nat := [2,4,8,16,32,64,128,5,137,1024,2048,4096,4147,4177,4155,1156,1093,4154,1025,4155,4097,1,5204,5311,4282,5124,4155,4177,1045,7221,1025,216,5,5325,1092,136]

theorem envBound9076 : H12AffineFastState.Bounded env9076 := by
  intro p hp
  have h : env9076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9075_9076 : H12AffineEnvironment.transform 12 4147 env9075 = env9076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4147 env9075 == env9076) = true)

def env9077 : List Nat := [2,4,8,16,32,64,128,5,137,1024,0,4096,4147,4177,4155,1156,1093,4154,1025,4155,4097,1,5204,5311,4282,5124,4155,4177,1045,5173,1025,216,5,5325,1092,136]

theorem envBound9077 : H12AffineFastState.Bounded env9077 := by
  intro p hp
  have h : env9077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9076_9077 : H12AffineEnvironment.transform 10 0 env9076 = env9077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env9076 == env9077) = true)

theorem identity9077 : scanCanonicalize (H12AffineFastState.compose env9077 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound9077 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9078 : List Nat := [2,4,8,16,32,64,128,5,137,47,0,4096,4147,4177,4155,171,106,4154,46,4155,4097,1,4219,4240,4282,4139,4155,4177,58,4122,46,216,5,4322,107,136]

theorem envBound9078 : H12AffineFastState.Bounded env9078 := by
  intro p hp
  have h : env9078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9077_9078 : H12AffineEnvironment.transform 9 47 env9077 = env9078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env9077 == env9078) = true)

theorem identity9078 : scanCanonicalize (H12AffineFastState.compose env9078 (packedSelected [2,4] rootPS)) = affineNative (2^(11+1) ^^^ 26) := by decide +kernel

theorem selectedBound9078 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env9079 : List Nat := [2,4,8,16,32,64,128,5,137,47,0,26,41,75,33,171,106,32,46,33,27,1,97,138,160,49,33,75,58,0,46,216,5,248,107,136]

theorem envBound9079 : H12AffineFastState.Bounded env9079 := by
  intro p hp
  have h : env9079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9078_9079 : H12AffineEnvironment.transform 11 26 env9078 = env9079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 26 env9078 == env9079) = true)

def env9080 : List Nat := [2,4,8,16,0,64,128,5,137,15,0,26,9,75,1,139,74,0,14,1,27,1,65,138,128,17,1,75,26,0,14,216,5,216,75,136]

theorem envBound9080 : H12AffineFastState.Bounded env9080 := by
  intro p hp
  have h : env9080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9079_9080 : H12AffineEnvironment.transform 4 0 env9079 = env9080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env9079 == env9080) = true)

theorem identity9080 : scanCanonicalize (H12AffineFastState.compose env9080 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound9080 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9081 : List Nat := [2,4,8,16,0,16,128,5,137,15,0,26,9,27,1,139,26,0,14,1,27,1,17,138,128,17,1,27,26,0,14,136,5,136,27,136]

theorem envBound9081 : H12AffineFastState.Bounded env9081 := by
  intro p hp
  have h : env9081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9080_9081 : H12AffineEnvironment.transform 5 16 env9080 = env9081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env9080 == env9081) = true)

def leafEnv9081 : List Nat := [2,4,8,16,0,16,128,5,137,15,0,26,9,27,1,139,26,0,14,1,27,1,17,138,14,128,1,17,1,27,26,0,14,136,5,136,5,2,27,136,0,26,1]

def active9081 : List Nat := [0,1,2,3,6]

def tree9081 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9081 : H12WitnessSearch.Good tree9081 := H12GlobalWitnessIndex.good

theorem leafIdentity9081 : H12AffineFastState.composeSystem env9081 rootObs = leafEnv9081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9081 rootObs == leafEnv9081) = true)

theorem terminalChecked9081 : H12PackedTerminal.terminalCheckFast leafEnv9081 active9081 tree9081 = true := by decide +kernel

def env9082 : List Nat := [2,4,8,16,1,64,128,5,137,14,0,26,8,75,0,138,75,1,15,0,27,1,64,138,129,16,0,75,27,0,15,216,5,217,74,136]

theorem envBound9082 : H12AffineFastState.Bounded env9082 := by
  intro p hp
  have h : env9082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9079_9082 : H12AffineEnvironment.transform 4 1 env9079 = env9082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env9079 == env9082) = true)

theorem identity9082 : scanCanonicalize (H12AffineFastState.compose env9082 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound9082 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9083 : List Nat := [2,4,8,16,1,64,89,5,80,14,0,26,8,75,0,83,75,1,15,0,27,1,64,83,88,16,0,75,27,0,15,1,5,0,74,81]

theorem envBound9083 : H12AffineFastState.Bounded env9083 := by
  intro p hp
  have h : env9083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9082_9083 : H12AffineEnvironment.transform 6 89 env9082 = env9083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env9082 == env9083) = true)

def leafEnv9083 : List Nat := [2,4,8,16,1,64,89,5,80,14,0,26,8,75,0,83,75,1,15,0,27,1,64,83,15,88,1,16,0,75,27,0,15,1,5,0,5,3,74,81,0,27,1]

def active9083 : List Nat := [0,1,2,3,5]

def tree9083 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9083 : H12WitnessSearch.Good tree9083 := H12GlobalWitnessIndex.good

theorem leafIdentity9083 : H12AffineFastState.composeSystem env9083 rootObs = leafEnv9083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9083 rootObs == leafEnv9083) = true)

theorem terminalChecked9083 : H12PackedTerminal.terminalCheckFast leafEnv9083 active9083 tree9083 = true := by decide +kernel

def env9084 : List Nat := [2,4,8,16,32,64,128,5,137,1024,1,4096,4147,4177,4155,1156,1093,4154,1025,4155,4097,1,5204,5311,4282,5124,4155,4177,1045,5172,1025,216,5,5325,1092,136]

theorem envBound9084 : H12AffineFastState.Bounded env9084 := by
  intro p hp
  have h : env9084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9076_9084 : H12AffineEnvironment.transform 10 1 env9076 = env9084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env9076 == env9084) = true)

theorem identity9084 : scanCanonicalize (H12AffineFastState.compose env9084 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 27) := by decide +kernel

theorem selectedBound9084 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9085 : List Nat := [2,4,8,16,32,64,128,5,137,1024,1,27,40,74,32,1156,1093,33,1025,32,26,1,1103,1188,161,1055,32,74,1045,1071,1025,216,5,1238,1092,136]

theorem envBound9085 : H12AffineFastState.Bounded env9085 := by
  intro p hp
  have h : env9085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9084_9085 : H12AffineEnvironment.transform 11 27 env9084 = env9085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 27 env9084 == env9085) = true)

theorem identity9085 : scanCanonicalize (H12AffineFastState.compose env9085 (packedSelected [1,3,5] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound9085 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env9086 : List Nat := [2,4,8,16,32,64,128,5,137,46,1,27,40,74,32,170,107,33,47,32,26,1,97,138,161,49,32,74,59,1,47,216,5,248,106,136]

theorem envBound9086 : H12AffineFastState.Bounded env9086 := by
  intro p hp
  have h : env9086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9085_9086 : H12AffineEnvironment.transform 9 46 env9085 = env9086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env9085 == env9086) = true)

def env9087 : List Nat := [2,4,8,16,0,64,128,5,137,14,1,27,8,74,0,138,75,1,15,0,26,1,65,138,129,17,0,74,27,1,15,216,5,216,74,136]

theorem envBound9087 : H12AffineFastState.Bounded env9087 := by
  intro p hp
  have h : env9087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9086_9087 : H12AffineEnvironment.transform 4 0 env9086 = env9087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env9086 == env9087) = true)

theorem identity9087 : scanCanonicalize (H12AffineFastState.compose env9087 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound9087 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9088 : List Nat := [2,4,8,16,0,16,128,5,137,14,1,27,8,26,0,138,27,1,15,0,26,1,17,138,129,17,0,26,27,1,15,136,5,136,26,136]

theorem envBound9088 : H12AffineFastState.Bounded env9088 := by
  intro p hp
  have h : env9088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9087_9088 : H12AffineEnvironment.transform 5 16 env9087 = env9088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env9087 == env9088) = true)

def leafEnv9088 : List Nat := [2,4,8,16,0,16,128,5,137,14,1,27,8,26,0,138,27,1,15,0,26,1,17,138,15,129,1,17,0,26,27,1,15,136,5,136,5,3,26,136,0,27,1]

def active9088 : List Nat := [0,1,2,3,6]

def tree9088 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9088 : H12WitnessSearch.Good tree9088 := H12GlobalWitnessIndex.good

theorem leafIdentity9088 : H12AffineFastState.composeSystem env9088 rootObs = leafEnv9088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9088 rootObs == leafEnv9088) = true)

theorem terminalChecked9088 : H12PackedTerminal.terminalCheckFast leafEnv9088 active9088 tree9088 = true := by decide +kernel

def env9089 : List Nat := [2,4,8,16,1,64,128,5,137,15,1,27,9,74,1,139,74,0,14,1,26,1,64,138,128,16,1,74,26,1,14,216,5,217,75,136]

theorem envBound9089 : H12AffineFastState.Bounded env9089 := by
  intro p hp
  have h : env9089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9086_9089 : H12AffineEnvironment.transform 4 1 env9086 = env9089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env9086 == env9089) = true)

theorem identity9089 : scanCanonicalize (H12AffineFastState.compose env9089 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound9089 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9090 : List Nat := [2,4,8,16,1,64,89,5,80,15,1,27,9,74,1,82,74,0,14,1,26,1,64,83,89,16,1,74,26,1,14,1,5,0,75,81]

theorem envBound9090 : H12AffineFastState.Bounded env9090 := by
  intro p hp
  have h : env9090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9089_9090 : H12AffineEnvironment.transform 6 89 env9089 = env9090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env9089 == env9090) = true)

def leafEnv9090 : List Nat := [2,4,8,16,1,64,89,5,80,15,1,27,9,74,1,82,74,0,14,1,26,1,64,83,14,89,1,16,1,74,26,1,14,1,5,0,5,2,75,81,0,26,1]

def active9090 : List Nat := [0,1,2,3,5]

def tree9090 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9090 : H12WitnessSearch.Good tree9090 := H12GlobalWitnessIndex.good

theorem leafIdentity9090 : H12AffineFastState.composeSystem env9090 rootObs = leafEnv9090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9090 rootObs == leafEnv9090) = true)

theorem terminalChecked9090 : H12PackedTerminal.terminalCheckFast leafEnv9090 active9090 tree9090 = true := by decide +kernel

def env9091 : List Nat := [2,4,8,16,32,64,128,5,137,1024,2048,4096,8192,4177,8200,1157,1093,8200,1025,8200,4097,12339,5204,9357,8329,5124,4155,4177,1045,7221,1025,12522,5,9471,1092,136]

theorem envBound9091 : H12AffineFastState.Bounded env9091 := by
  intro p hp
  have h : env9091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9074_9091 : H12AffineEnvironment.transform 15 1157 env9074 = env9091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1157 env9074 == env9091) = true)

def env9092 : List Nat := [2,4,8,16,32,64,128,5,137,1024,2048,4096,8192,4177,8201,65536,1093,262144,1025,8201,4097,79030,5204,73737,8329,5124,341174,4177,1045,7220,1025,78958,5,73850,1092,136]

theorem envBound9092 : H12AffineFastState.Bounded env9092 := by
  intro p hp
  have h : env9092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9072_9092 : H12AffineEnvironment.transform 14 8201 env9072 = env9092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8201 env9072 == env9092) = true)

theorem identity9092 : scanCanonicalize (H12AffineFastState.compose env9092 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 4274) := by decide +kernel

theorem selectedBound9092 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env9093 : List Nat := [2,4,8,16,32,64,128,5,137,1024,2048,4096,8192,4177,8201,65536,1093,4274,1025,8201,4097,79030,5204,73737,8329,5124,74756,4177,1045,7220,1025,78958,5,73850,1092,136]

theorem envBound9093 : H12AffineFastState.Bounded env9093 := by
  intro p hp
  have h : env9093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9092_9093 : H12AffineEnvironment.transform 17 4274 env9092 = env9093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4274 env9092 == env9093) = true)

def env9094 : List Nat := [2,4,8,16,32,64,128,5,137,1024,2048,4096,8192,4177,8201,1036,1093,4274,1025,8201,4097,12474,5204,9221,8329,5124,8200,4177,1045,7220,1025,12386,5,9334,1092,136]

theorem envBound9094 : H12AffineFastState.Bounded env9094 := by
  intro p hp
  have h : env9094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9093_9094 : H12AffineEnvironment.transform 15 1036 env9093 = env9094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1036 env9093 == env9094) = true)

theorem identity9094 : scanCanonicalize (H12AffineFastState.compose env9094 (packedSelected [7] rootPS)) = affineNative (2^(12+1) ^^^ 4283) := by decide +kernel

theorem selectedBound9094 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env9095 : List Nat := [2,4,8,16,32,64,128,5,137,1024,2048,4096,4283,4177,4274,1036,1093,4274,1025,4274,4097,1,5204,5310,4146,5124,4275,4177,1045,7220,1025,217,5,5325,1092,136]

theorem envBound9095 : H12AffineFastState.Bounded env9095 := by
  intro p hp
  have h : env9095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9094_9095 : H12AffineEnvironment.transform 12 4283 env9094 = env9095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4283 env9094 == env9095) = true)

def env9096 : List Nat := [2,4,8,16,32,64,128,5,137,1024,0,4096,4283,4177,4274,1036,1093,4274,1025,4274,4097,1,5204,5310,4146,5124,4275,4177,1045,5172,1025,217,5,5325,1092,136]

theorem envBound9096 : H12AffineFastState.Bounded env9096 := by
  intro p hp
  have h : env9096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9095_9096 : H12AffineEnvironment.transform 10 0 env9095 = env9096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env9095 == env9096) = true)

theorem identity9096 : scanCanonicalize (H12AffineFastState.compose env9096 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 167) := by decide +kernel

theorem selectedBound9096 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9097 : List Nat := [2,4,8,16,32,64,128,5,137,167,0,4096,4283,4177,4274,171,226,4274,166,4274,4097,1,4339,4121,4146,4259,4275,4177,178,4243,166,217,5,4202,227,136]

theorem envBound9097 : H12AffineFastState.Bounded env9097 := by
  intro p hp
  have h : env9097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9096_9097 : H12AffineEnvironment.transform 9 167 env9096 = env9097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 167 env9096 == env9097) = true)

theorem identity9097 : scanCanonicalize (H12AffineFastState.compose env9097 (packedSelected [2,4] rootPS)) = affineNative (2^(11+1) ^^^ 147) := by decide +kernel

theorem selectedBound9097 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env9098 : List Nat := [2,4,8,16,32,64,128,5,137,167,0,147,40,194,33,171,226,33,166,33,146,1,96,138,161,48,32,194,178,0,166,217,5,249,227,136]

theorem envBound9098 : H12AffineFastState.Bounded env9098 := by
  intro p hp
  have h : env9098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9097_9098 : H12AffineEnvironment.transform 11 147 env9097 = env9098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 147 env9097 == env9098) = true)

def env9099 : List Nat := [2,4,8,16,0,64,128,5,137,135,0,147,8,194,1,139,194,1,134,1,146,1,64,138,129,16,0,194,146,0,134,217,5,217,195,136]

theorem envBound9099 : H12AffineFastState.Bounded env9099 := by
  intro p hp
  have h : env9099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9098_9099 : H12AffineEnvironment.transform 4 0 env9098 = env9099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env9098 == env9099) = true)

def leafEnv9099 : List Nat := [2,4,8,16,0,64,128,5,137,135,0,147,8,194,1,139,194,1,134,1,146,1,64,138,134,129,1,16,0,194,146,0,134,217,5,217,5,2,195,136,0,146,1]

def active9099 : List Nat := [0,1,2,3,5,6]

def tree9099 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9099 : H12WitnessSearch.Good tree9099 := H12GlobalWitnessIndex.good

theorem leafIdentity9099 : H12AffineFastState.composeSystem env9099 rootObs = leafEnv9099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9099 rootObs == leafEnv9099) = true)

theorem terminalChecked9099 : H12PackedTerminal.terminalCheckFast leafEnv9099 active9099 tree9099 = true := by decide +kernel

def env9100 : List Nat := [2,4,8,16,1,64,128,5,137,134,0,147,9,194,0,138,195,0,135,0,146,1,65,138,128,17,1,194,147,0,135,217,5,216,194,136]

theorem envBound9100 : H12AffineFastState.Bounded env9100 := by
  intro p hp
  have h : env9100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9098_9100 : H12AffineEnvironment.transform 4 1 env9098 = env9100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env9098 == env9100) = true)

theorem identity9100 : scanCanonicalize (H12AffineFastState.compose env9100 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound9100 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9101 : List Nat := [2,4,8,16,1,64,8,5,1,14,0,27,9,74,0,2,75,0,15,0,26,1,65,2,8,17,1,74,27,0,15,81,5,80,74,0]

theorem envBound9101 : H12AffineFastState.Bounded env9101 := by
  intro p hp
  have h : env9101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9100_9101 : H12AffineEnvironment.transform 6 8 env9100 = env9101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env9100 == env9101) = true)

def leafEnv9101 : List Nat := [2,4,8,16,1,64,8,5,1,14,0,27,9,74,0,2,75,0,15,0,26,1,65,2,15,8,1,17,1,74,27,0,15,81,5,80,5,3,74,0,0,27,1]

def active9101 : List Nat := [0,1,2,3,5]

def tree9101 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9101 : H12WitnessSearch.Good tree9101 := H12GlobalWitnessIndex.good

theorem leafIdentity9101 : H12AffineFastState.composeSystem env9101 rootObs = leafEnv9101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9101 rootObs == leafEnv9101) = true)

theorem terminalChecked9101 : H12PackedTerminal.terminalCheckFast leafEnv9101 active9101 tree9101 = true := by decide +kernel

def env9102 : List Nat := [2,4,8,16,32,64,128,5,137,1024,1,4096,4283,4177,4274,1036,1093,4274,1025,4274,4097,1,5204,5310,4146,5124,4275,4177,1045,5173,1025,217,5,5325,1092,136]

theorem envBound9102 : H12AffineFastState.Bounded env9102 := by
  intro p hp
  have h : env9102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9095_9102 : H12AffineEnvironment.transform 10 1 env9095 = env9102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env9095 == env9102) = true)

theorem identity9102 : scanCanonicalize (H12AffineFastState.compose env9102 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 146) := by decide +kernel

theorem selectedBound9102 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9103 : List Nat := [2,4,8,16,32,64,128,5,137,1024,1,146,41,195,32,1036,1093,32,1025,32,147,1,1222,1068,160,1174,33,195,1045,1191,1025,217,5,1119,1092,136]

theorem envBound9103 : H12AffineFastState.Bounded env9103 := by
  intro p hp
  have h : env9103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9102_9103 : H12AffineEnvironment.transform 11 146 env9102 = env9103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 146 env9102 == env9103) = true)

theorem identity9103 : scanCanonicalize (H12AffineFastState.compose env9103 (packedSelected [1,3,5] rootPS)) = affineNative (2^(9+1) ^^^ 166) := by decide +kernel

theorem selectedBound9103 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env9104 : List Nat := [2,4,8,16,32,64,128,5,137,166,1,146,41,195,32,170,227,32,167,32,147,1,96,138,160,48,33,195,179,1,167,217,5,249,226,136]

theorem envBound9104 : H12AffineFastState.Bounded env9104 := by
  intro p hp
  have h : env9104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9103_9104 : H12AffineEnvironment.transform 9 166 env9103 = env9104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 166 env9103 == env9104) = true)

def env9105 : List Nat := [2,4,8,16,0,64,128,5,137,134,1,146,9,195,0,138,195,0,135,0,147,1,64,138,128,16,1,195,147,1,135,217,5,217,194,136]

theorem envBound9105 : H12AffineFastState.Bounded env9105 := by
  intro p hp
  have h : env9105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9104_9105 : H12AffineEnvironment.transform 4 0 env9104 = env9105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env9104 == env9105) = true)

def leafEnv9105 : List Nat := [2,4,8,16,0,64,128,5,137,134,1,146,9,195,0,138,195,0,135,0,147,1,64,138,135,128,1,16,1,195,147,1,135,217,5,217,5,3,194,136,0,147,1]

def active9105 : List Nat := [0,1,2,3,5,6]

def tree9105 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9105 : H12WitnessSearch.Good tree9105 := H12GlobalWitnessIndex.good

theorem leafIdentity9105 : H12AffineFastState.composeSystem env9105 rootObs = leafEnv9105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9105 rootObs == leafEnv9105) = true)

theorem terminalChecked9105 : H12PackedTerminal.terminalCheckFast leafEnv9105 active9105 tree9105 = true := by decide +kernel

def env9106 : List Nat := [2,4,8,16,1,64,128,5,137,135,1,146,8,195,1,139,194,1,134,1,147,1,65,138,129,17,0,195,146,1,134,217,5,216,195,136]

theorem envBound9106 : H12AffineFastState.Bounded env9106 := by
  intro p hp
  have h : env9106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9104_9106 : H12AffineEnvironment.transform 4 1 env9104 = env9106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env9104 == env9106) = true)

theorem identity9106 : scanCanonicalize (H12AffineFastState.compose env9106 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound9106 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9107 : List Nat := [2,4,8,16,1,64,8,5,1,15,1,26,8,75,1,3,74,1,14,1,27,1,65,2,9,17,0,75,26,1,14,81,5,80,75,0]

theorem envBound9107 : H12AffineFastState.Bounded env9107 := by
  intro p hp
  have h : env9107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9106_9107 : H12AffineEnvironment.transform 6 8 env9106 = env9107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env9106 == env9107) = true)

def leafEnv9107 : List Nat := [2,4,8,16,1,64,8,5,1,15,1,26,8,75,1,3,74,1,14,1,27,1,65,2,14,9,1,17,0,75,26,1,14,81,5,80,5,2,75,0,0,26,1]

def active9107 : List Nat := [0,1,2,3,5]

def tree9107 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9107 : H12WitnessSearch.Good tree9107 := H12GlobalWitnessIndex.good

theorem leafIdentity9107 : H12AffineFastState.composeSystem env9107 rootObs = leafEnv9107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9107 rootObs == leafEnv9107) = true)

theorem terminalChecked9107 : H12PackedTerminal.terminalCheckFast leafEnv9107 active9107 tree9107 = true := by decide +kernel

def env9108 : List Nat := [2,4,8,16,32,64,128,5,137,1024,2048,4096,8192,4177,8201,1037,1093,4274,1025,8201,4097,12475,5204,9220,8329,5124,8201,4177,1045,7220,1025,12387,5,9335,1092,136]

theorem envBound9108 : H12AffineFastState.Bounded env9108 := by
  intro p hp
  have h : env9108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9093_9108 : H12AffineEnvironment.transform 15 1037 env9093 = env9108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1037 env9093 == env9108) = true)

def env9109 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,659777,4194304,17664,16777216,33554432,67108864,21484817,67130625,656464,1073741824,17399809,4294967296,525568,4417151347,131073,33563272]

theorem envBound9109 : H12AffineFastState.Bounded env9109 := by
  intro p hp
  have h : env9109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8958_9109 : H12AffineEnvironment.transform 20 659777 env8958 = env9109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 659777 env8958 == env9109) = true)

theorem identity9109 : scanCanonicalize (H12AffineFastState.compose env9109 (packedSelected [4,6,7,9,16,20,25,27,35] rootPS)) = affineNative (2^(29+1) ^^^ 72064202) := by decide +kernel

theorem selectedBound9109 : packedSelected [4,6,7,9,16,20,25,27,35] rootPS < 2^1333 := by decide +kernel

def env9110 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,659777,4194304,17664,16777216,33554432,67108864,21484817,67130625,656464,72064202,17399809,4294967296,525568,4417151347,131073,33563272]

theorem envBound9110 : H12AffineFastState.Bounded env9110 := by
  intro p hp
  have h : env9110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9109_9110 : H12AffineEnvironment.transform 29 72064202 env9109 = env9110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 72064202 env9109 == env9110) = true)

def env9111 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,136513,4194304,17664,16777216,33554432,67108864,21484817,67130625,131152,71538890,16876545,4294967296,256,4416628083,131073,33563272]

theorem envBound9111 : H12AffineFastState.Bounded env9111 := by
  intro p hp
  have h : env9111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9110_9111 : H12AffineEnvironment.transform 18 1024 env9110 = env9111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env9110 == env9111) = true)

def env9112 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,136513,4194304,17664,16777216,33554432,5376,21484817,16385,131152,4427210,16876545,4294967296,256,4349522035,131073,33563272]

theorem envBound9112 : H12AffineFastState.Bounded env9112 := by
  intro p hp
  have h : env9112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9111_9112 : H12AffineEnvironment.transform 25 5376 env9111 = env9112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 5376 env9111 == env9112) = true)

def env9113 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,136513,4194304,17664,16777216,33554432,5377,21484817,16384,131152,4427211,16876545,4294967296,256,4349522034,131073,33563272]

theorem envBound9113 : H12AffineFastState.Bounded env9113 := by
  intro p hp
  have h : env9113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9111_9113 : H12AffineEnvironment.transform 25 5377 env9111 = env9113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 5377 env9111 == env9113) = true)

theorem identity9113 : scanCanonicalize (H12AffineFastState.compose env9113 (packedSelected [4,6,7,9,16,20,25,27] rootPS)) = affineNative (2^(16+1) ^^^ 1344) := by decide +kernel

theorem selectedBound9113 : packedSelected [4,6,7,9,16,20,25,27] rootPS < 2^1333 := by decide +kernel

def env9114 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,1024,32768,4097,4194304,17664,16777216,33554432,5377,21352529,16384,1296,4294795,16876545,4294967296,256,4349522034,1345,33563272]

theorem envBound9114 : H12AffineFastState.Bounded env9114 := by
  intro p hp
  have h : env9114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9113_9114 : H12AffineEnvironment.transform 16 1344 env9113 = env9114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1344 env9113 == env9114) = true)

theorem identity9114 : scanCanonicalize (H12AffineFastState.compose env9114 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(24+1) ^^^ 8329) := by decide +kernel

theorem selectedBound9114 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env9115 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,1024,32768,4097,4194304,17664,16777216,8329,5377,21352529,16384,1296,4294795,16876545,4294967296,256,4315959547,1345,513]

theorem envBound9115 : H12AffineFastState.Bounded env9115 := by
  intro p hp
  have h : env9115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9114_9115 : H12AffineEnvironment.transform 24 8329 env9114 = env9115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8329 env9114 == env9115) = true)

theorem identity9115 : scanCanonicalize (H12AffineFastState.compose env9115 (packedSelected [0,1,3,5,7,8,9,10,19,20,22] rootPS)) = affineNative (2^(23+1) ^^^ 119124) := by decide +kernel

theorem selectedBound9115 : packedSelected [0,1,3,5,7,8,9,10,19,20,22] rootPS < 2^1333 := by decide +kernel

def env9116 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1344,262144,1024,32768,4097,4194304,17664,119124,8329,5377,4456709,16384,1296,4294795,21845,4294967296,256,4299260335,1345,513]

theorem envBound9116 : H12AffineFastState.Bounded env9116 := by
  intro p hp
  have h : env9116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9115_9116 : H12AffineEnvironment.transform 23 119124 env9115 = env9116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 119124 env9115 == env9116) = true)

theorem identity9116 : scanCanonicalize (H12AffineFastState.compose env9116 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 4177) := by decide +kernel

theorem selectedBound9116 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env9117 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,1344,262144,1024,32768,4097,4194304,5457,98565,8329,5377,4456709,4177,1296,4294795,1284,4294967296,256,4299260335,1345,513]

theorem envBound9117 : H12AffineFastState.Bounded env9117 := by
  intro p hp
  have h : env9117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9116_9117 : H12AffineEnvironment.transform 13 4177 env9116 = env9117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4177 env9116 == env9117) = true)

theorem identity9117 : scanCanonicalize (H12AffineFastState.compose env9117 (packedSelected [3,5,10] rootPS)) = affineNative (2^(31+1) ^^^ 340) := by decide +kernel

theorem selectedBound9117 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9118 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,1344,262144,1024,32768,4097,4194304,5457,98565,8329,5377,4456709,4177,1296,4294795,1284,340,256,4292859,1345,513]

theorem envBound9118 : H12AffineFastState.Bounded env9118 := by
  intro p hp
  have h : env9118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9117_9118 : H12AffineEnvironment.transform 31 340 env9117 = env9118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 340 env9117 == env9118) = true)

theorem identity9118 : scanCanonicalize (H12AffineFastState.compose env9118 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(21+1) ^^^ 103615) := by decide +kernel

theorem selectedBound9118 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env9119 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4177,32768,65536,1344,262144,1024,32768,4097,103615,5457,98565,8329,5377,366010,4177,1296,7220,1284,340,256,5188,1345,513]

theorem envBound9119 : H12AffineFastState.Bounded env9119 := by
  intro p hp
  have h : env9119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9118_9119 : H12AffineEnvironment.transform 21 103615 env9118 = env9119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 103615 env9118 == env9119) = true)

theorem identity9119 : scanCanonicalize (H12AffineFastState.compose env9119 (packedSelected [0,7,20] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound9119 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env9120 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,4177,32768,65536,1344,262144,1024,32768,4097,103615,5457,98565,8329,5377,366010,4177,1296,7220,1284,340,256,5188,1345,136]

theorem envBound9120 : H12AffineFastState.Bounded env9120 := by
  intro p hp
  have h : env9120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9119_9120 : H12AffineEnvironment.transform 8 137 env9119 = env9120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env9119 == env9120) = true)

theorem identity9120 : scanCanonicalize (H12AffineFastState.compose env9120 (packedSelected [2,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 37942) := by decide +kernel

theorem selectedBound9120 : packedSelected [2,23,32] rootPS < 2^1333 := by decide +kernel

def env9121 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,4177,32768,37942,1344,262144,1024,32768,4097,137,5457,5427,8329,5377,262540,4177,1296,7220,1284,340,256,5188,1345,136]

theorem envBound9121 : H12AffineFastState.Bounded env9121 := by
  intro p hp
  have h : env9121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9120_9121 : H12AffineEnvironment.transform 15 37942 env9120 = env9121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 37942 env9120 == env9121) = true)

def env9122 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,4177,8200,13374,1344,262144,1024,8200,4097,137,5457,5427,8329,5377,262540,4177,1296,7220,1284,340,256,5188,1345,136]

theorem envBound9122 : H12AffineFastState.Bounded env9122 := by
  intro p hp
  have h : env9122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9121_9122 : H12AffineEnvironment.transform 14 8200 env9121 = env9122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8200 env9121 == env9122) = true)

theorem identity9122 : scanCanonicalize (H12AffineFastState.compose env9122 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 4275) := by decide +kernel

theorem selectedBound9122 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env9123 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,4177,8200,13374,1344,4275,1024,8200,4097,137,5457,5427,8329,5377,4415,4177,1296,7220,1284,340,256,5188,1345,136]

theorem envBound9123 : H12AffineFastState.Bounded env9123 := by
  intro p hp
  have h : env9123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9122_9123 : H12AffineEnvironment.transform 17 4275 env9122 = env9123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4275 env9122 == env9123) = true)

def env9124 : List Nat := [2,4,8,16,32,64,128,140,137,1024,2048,4096,8192,4177,8200,13374,1228,4275,1024,8200,4097,137,5341,5311,8329,5261,4275,4177,1180,7220,1160,216,140,5188,1229,136]

theorem envBound9124 : H12AffineFastState.Bounded env9124 := by
  intro p hp
  have h : env9124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9123_9124 : H12AffineEnvironment.transform 7 140 env9123 = env9124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env9123 == env9124) = true)

theorem identity9124 : scanCanonicalize (H12AffineFastState.compose env9124 (packedSelected [7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound9124 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env9125 : List Nat := [2,4,8,16,32,64,8,4,1,1024,2048,4096,8192,4177,8200,13374,1092,4155,1024,8200,4097,1,5205,5175,8193,5125,4155,4177,1044,7220,1024,80,4,5188,1093,0]

theorem envBound9125 : H12AffineFastState.Bounded env9125 := by
  intro p hp
  have h : env9125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9124_9125 : H12AffineEnvironment.transform 6 8 env9124 = env9125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env9124 == env9125) = true)

theorem identity9125 : scanCanonicalize (H12AffineFastState.compose env9125 (packedSelected [1,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 1044) := by decide +kernel

theorem selectedBound9125 : packedSelected [1,8,12] rootPS < 2^1333 := by decide +kernel

def env9126 : List Nat := [2,4,8,16,32,64,8,4,1,1024,2048,1044,8192,1093,8200,8234,1092,1071,1024,8200,1045,1,65,35,8193,17,1071,1093,1044,2080,1024,80,4,80,1093,0]

theorem envBound9126 : H12AffineFastState.Bounded env9126 := by
  intro p hp
  have h : env9126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9125_9126 : H12AffineEnvironment.transform 11 1044 env9125 = env9126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env9125 == env9126) = true)

theorem identity9126 : scanCanonicalize (H12AffineFastState.compose env9126 (packedSelected [1,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound9126 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env9127 : List Nat := [2,4,8,16,1,64,8,4,1,1024,2048,1044,8192,1093,8200,8203,1092,1038,1024,8200,1045,1,65,2,8193,17,1038,1093,1044,2049,1024,80,4,80,1093,0]

theorem envBound9127 : H12AffineFastState.Bounded env9127 := by
  intro p hp
  have h : env9127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9126_9127 : H12AffineEnvironment.transform 4 1 env9126 = env9127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env9126 == env9127) = true)

theorem identity9127 : scanCanonicalize (H12AffineFastState.compose env9127 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 1030) := by decide +kernel

theorem selectedBound9127 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9128 : List Nat := [2,4,8,16,1,64,8,4,1,1024,2048,1044,1030,1093,1038,1037,1092,1038,1024,1038,1045,1,65,2,1031,17,1038,1093,1044,2049,1024,80,4,80,1093,0]

theorem envBound9128 : H12AffineFastState.Bounded env9128 := by
  intro p hp
  have h : env9128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9127_9128 : H12AffineEnvironment.transform 12 1030 env9127 = env9128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1030 env9127 == env9128) = true)

theorem identity9128 : scanCanonicalize (H12AffineFastState.compose env9128 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1039) := by decide +kernel

theorem selectedBound9128 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9129 : List Nat := [2,4,8,16,1,64,8,4,1,1024,1039,1044,1030,1093,1038,1037,1092,1038,1024,1038,1045,1,65,2,1031,17,1038,1093,1044,1038,1024,80,4,80,1093,0]

theorem envBound9129 : H12AffineFastState.Bounded env9129 := by
  intro p hp
  have h : env9129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9128_9129 : H12AffineEnvironment.transform 10 1039 env9128 = env9129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1039 env9128 == env9129) = true)

def env9130 : List Nat := [2,4,8,16,32,64,128,141,137,1024,2048,4096,8192,4177,8200,13374,1229,4275,1024,8200,4097,137,5340,5310,8329,5260,4274,4177,1181,7220,1161,217,141,5188,1228,136]

theorem envBound9130 : H12AffineFastState.Bounded env9130 := by
  intro p hp
  have h : env9130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9123_9130 : H12AffineEnvironment.transform 7 141 env9123 = env9130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env9123 == env9130) = true)

theorem identity9130 : scanCanonicalize (H12AffineFastState.compose env9130 (packedSelected [7] rootPS)) = affineNative (2^(12+1) ^^^ 4282) := by decide +kernel

theorem selectedBound9130 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env9131 : List Nat := [2,4,8,16,32,64,128,141,137,1024,2048,4096,4282,4177,4274,1156,1229,4275,1024,4274,4097,137,5340,5310,4147,5260,4274,4177,1181,7220,1161,217,141,5188,1228,136]

theorem envBound9131 : H12AffineFastState.Bounded env9131 := by
  intro p hp
  have h : env9131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9130_9131 : H12AffineEnvironment.transform 12 4282 env9130 = env9131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4282 env9130 == env9131) = true)

theorem identity9131 : scanCanonicalize (H12AffineFastState.compose env9131 (packedSelected [0,1,2,3,4,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 1191) := by decide +kernel

theorem selectedBound9131 : packedSelected [0,1,2,3,4,8,11] rootPS < 2^1333 := by decide +kernel

def env9132 : List Nat := [2,4,8,16,32,64,128,141,137,1024,1191,4096,4282,4177,4274,1156,1229,4275,1024,4274,4097,137,5340,5310,4147,5260,4274,4177,1181,4243,1161,217,141,5188,1228,136]

theorem envBound9132 : H12AffineFastState.Bounded env9132 := by
  intro p hp
  have h : env9132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9131_9132 : H12AffineEnvironment.transform 10 1191 env9131 = env9132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1191 env9131 == env9132) = true)

theorem identity9132 : scanCanonicalize (H12AffineFastState.compose env9132 (packedSelected [0,1,2,3,5] rootPS)) = affineNative (2^(11+1) ^^^ 1076) := by decide +kernel

theorem selectedBound9132 : packedSelected [0,1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env9133 : List Nat := [2,4,8,16,32,64,128,141,137,1024,1191,1076,1166,1125,1158,1156,1229,1159,1024,1158,1077,137,232,138,1031,184,1158,1125,1181,1191,1161,217,141,112,1228,136]

theorem envBound9133 : H12AffineFastState.Bounded env9133 := by
  intro p hp
  have h : env9133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9132_9133 : H12AffineEnvironment.transform 11 1076 env9132 = env9133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1076 env9132 == env9133) = true)

theorem identity9133 : scanCanonicalize (H12AffineFastState.compose env9133 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound9133 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9134 : List Nat := [2,4,8,16,32,64,8,5,1,1024,1071,1076,1030,1125,1038,1036,1093,1039,1024,1038,1077,1,96,2,1031,48,1038,1125,1045,1071,1025,81,5,112,1092,0]

theorem envBound9134 : H12AffineFastState.Bounded env9134 := by
  intro p hp
  have h : env9134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9133_9134 : H12AffineEnvironment.transform 6 8 env9133 = env9134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env9133 == env9134) = true)

theorem identity9134 : scanCanonicalize (H12AffineFastState.compose env9134 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound9134 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9135 : List Nat := [2,4,8,16,32,48,8,5,1,1024,1071,1076,1030,1045,1038,1036,1077,1039,1024,1038,1077,1,16,2,1031,48,1038,1045,1045,1071,1025,33,5,0,1076,0]

theorem envBound9135 : H12AffineFastState.Bounded env9135 := by
  intro p hp
  have h : env9135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9134_9135 : H12AffineEnvironment.transform 5 48 env9134 = env9135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env9134 == env9135) = true)

def leafEnv9135 : List Nat := [2,4,8,16,32,48,8,5,1,1024,1071,1076,1030,1045,1038,1036,1077,1039,1024,1038,1077,1,16,2,1024,1031,1,48,1038,1045,1045,1071,1025,33,5,0,5,1037,1076,0,0,1045,1]

def active9135 : List Nat := [0,1,2,3,4,9]

def tree9135 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9135 : H12WitnessSearch.Good tree9135 := H12GlobalWitnessIndex.good

theorem leafIdentity9135 : H12AffineFastState.composeSystem env9135 rootObs = leafEnv9135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9135 rootObs == leafEnv9135) = true)

theorem terminalChecked9135 : H12PackedTerminal.terminalCheckFast leafEnv9135 active9135 tree9135 = true := by decide +kernel

def env9136 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,4177,8201,13375,1344,262144,1024,8201,4097,137,5457,5427,8329,5377,262540,4177,1296,7220,1284,340,256,5188,1345,136]

theorem envBound9136 : H12AffineFastState.Bounded env9136 := by
  intro p hp
  have h : env9136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9121_9136 : H12AffineEnvironment.transform 14 8201 env9121 = env9136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8201 env9121 == env9136) = true)

theorem identity9136 : scanCanonicalize (H12AffineFastState.compose env9136 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 4535) := by decide +kernel

theorem selectedBound9136 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env9137 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,4177,8201,13375,1344,4535,1024,8201,4097,137,5457,5427,8329,5377,4155,4177,1296,7220,1284,340,256,5188,1345,136]

theorem envBound9137 : H12AffineFastState.Bounded env9137 := by
  intro p hp
  have h : env9137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9136_9137 : H12AffineEnvironment.transform 17 4535 env9136 = env9137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4535 env9136 == env9137) = true)

def env9138 : List Nat := [2,4,8,16,32,64,128,140,137,1024,2048,4096,8192,4177,8201,13375,1228,4155,1024,8201,4097,137,5341,5311,8329,5261,4155,4177,1180,7220,1160,216,140,5188,1229,136]

theorem envBound9138 : H12AffineFastState.Bounded env9138 := by
  intro p hp
  have h : env9138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9137_9138 : H12AffineEnvironment.transform 7 140 env9137 = env9138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env9137 == env9138) = true)

theorem identity9138 : scanCanonicalize (H12AffineFastState.compose env9138 (packedSelected [7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound9138 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env9139 : List Nat := [2,4,8,16,32,64,8,4,1,1024,2048,4096,8192,4177,8201,13375,1092,4155,1024,8201,4097,1,5205,5175,8193,5125,4155,4177,1044,7220,1024,80,4,5188,1093,0]

theorem envBound9139 : H12AffineFastState.Bounded env9139 := by
  intro p hp
  have h : env9139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9138_9139 : H12AffineEnvironment.transform 6 8 env9138 = env9139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env9138 == env9139) = true)

theorem identity9139 : scanCanonicalize (H12AffineFastState.compose env9139 (packedSelected [1,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound9139 : packedSelected [1,8,12] rootPS < 2^1333 := by decide +kernel

def env9140 : List Nat := [2,4,8,16,32,17,8,4,1,1024,2048,4096,8192,4096,8201,13375,1045,4155,1024,8201,4097,1,5124,5175,8193,5125,4155,4096,1044,7220,1024,1,4,5141,1044,0]

theorem envBound9140 : H12AffineFastState.Bounded env9140 := by
  intro p hp
  have h : env9140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9139_9140 : H12AffineEnvironment.transform 5 17 env9139 = env9140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env9139 == env9140) = true)

theorem identity9140 : scanCanonicalize (H12AffineFastState.compose env9140 (packedSelected [2,5,8,11,18] rootPS)) = affineNative (2^(11+1) ^^^ 1077) := by decide +kernel

theorem selectedBound9140 : packedSelected [2,5,8,11,18] rootPS < 2^1333 := by decide +kernel

def env9141 : List Nat := [2,4,8,16,32,17,8,4,1,1024,2048,1077,8192,1077,8201,8202,1045,1038,1024,8201,1076,1,49,2,8193,48,1038,1077,1044,2049,1024,1,4,32,1044,0]

theorem envBound9141 : H12AffineFastState.Bounded env9141 := by
  intro p hp
  have h : env9141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9140_9141 : H12AffineEnvironment.transform 11 1077 env9140 = env9141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1077 env9140 == env9141) = true)

theorem identity9141 : scanCanonicalize (H12AffineFastState.compose env9141 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 1062) := by decide +kernel

theorem selectedBound9141 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9142 : List Nat := [2,4,8,16,32,17,8,4,1,1024,2048,1077,1062,1077,1071,1068,1045,1038,1024,1071,1076,1,49,2,1063,48,1038,1077,1044,2049,1024,1,4,32,1044,0]

theorem envBound9142 : H12AffineFastState.Bounded env9142 := by
  intro p hp
  have h : env9142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9141_9142 : H12AffineEnvironment.transform 12 1062 env9141 = env9142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1062 env9141 == env9142) = true)

theorem identity9142 : scanCanonicalize (H12AffineFastState.compose env9142 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1071) := by decide +kernel

theorem selectedBound9142 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9143 : List Nat := [2,4,8,16,32,17,8,4,1,1024,1071,1077,1062,1077,1071,1068,1045,1038,1024,1071,1076,1,49,2,1063,48,1038,1077,1044,1070,1024,1,4,32,1044,0]

theorem envBound9143 : H12AffineFastState.Bounded env9143 := by
  intro p hp
  have h : env9143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9142_9143 : H12AffineEnvironment.transform 10 1071 env9142 = env9143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1071 env9142 == env9143) = true)

def env9144 : List Nat := [2,4,8,16,32,64,128,141,137,1024,2048,4096,8192,4177,8201,13375,1229,4154,1024,8201,4097,137,5340,5310,8329,5260,4155,4177,1181,7220,1161,217,141,5188,1228,136]

theorem envBound9144 : H12AffineFastState.Bounded env9144 := by
  intro p hp
  have h : env9144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9137_9144 : H12AffineEnvironment.transform 7 141 env9137 = env9144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env9137 == env9144) = true)

theorem identity9144 : scanCanonicalize (H12AffineFastState.compose env9144 (packedSelected [7] rootPS)) = affineNative (2^(12+1) ^^^ 4147) := by decide +kernel

theorem selectedBound9144 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env9145 : List Nat := [2,4,8,16,32,64,128,141,137,1024,2048,4096,4147,4177,4154,1036,1229,4154,1024,4154,4097,137,5340,5310,4282,5260,4155,4177,1181,7220,1161,217,141,5188,1228,136]

theorem envBound9145 : H12AffineFastState.Bounded env9145 := by
  intro p hp
  have h : env9145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9144_9145 : H12AffineEnvironment.transform 12 4147 env9144 = env9145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4147 env9144 == env9145) = true)

def env9146 : List Nat := [2,4,8,16,32,64,128,141,137,1024,0,4096,4147,4177,4154,1036,1229,4154,1024,4154,4097,137,5340,5310,4282,5260,4155,4177,1181,5172,1161,217,141,5188,1228,136]

theorem envBound9146 : H12AffineFastState.Bounded env9146 := by
  intro p hp
  have h : env9146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9145_9146 : H12AffineEnvironment.transform 10 0 env9145 = env9146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env9145 == env9146) = true)

theorem identity9146 : scanCanonicalize (H12AffineFastState.compose env9146 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 167) := by decide +kernel

theorem selectedBound9146 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9147 : List Nat := [2,4,8,16,32,64,128,141,137,167,0,4096,4147,4177,4154,171,106,4154,167,4154,4097,137,4219,4121,4282,4139,4155,4177,58,4243,46,217,141,4323,107,136]

theorem envBound9147 : H12AffineFastState.Bounded env9147 := by
  intro p hp
  have h : env9147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9146_9147 : H12AffineEnvironment.transform 9 167 env9146 = env9147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 167 env9146 == env9147) = true)

theorem identity9147 : scanCanonicalize (H12AffineFastState.compose env9147 (packedSelected [2,4] rootPS)) = affineNative (2^(11+1) ^^^ 27) := by decide +kernel

theorem selectedBound9147 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env9148 : List Nat := [2,4,8,16,32,64,128,141,137,167,0,27,40,74,33,171,106,33,167,33,26,137,96,2,161,48,32,74,58,136,46,217,141,248,107,136]

theorem envBound9148 : H12AffineFastState.Bounded env9148 := by
  intro p hp
  have h : env9148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9147_9148 : H12AffineEnvironment.transform 11 27 env9147 = env9148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 27 env9147 == env9148) = true)

theorem identity9148 : scanCanonicalize (H12AffineFastState.compose env9148 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound9148 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9149 : List Nat := [2,4,8,16,32,64,8,5,1,47,0,27,40,74,33,35,106,33,47,33,26,1,96,2,41,48,32,74,58,0,46,81,5,112,107,0]

theorem envBound9149 : H12AffineFastState.Bounded env9149 := by
  intro p hp
  have h : env9149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9148_9149 : H12AffineEnvironment.transform 6 8 env9148 = env9149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env9148 == env9149) = true)

def leafEnv9149 : List Nat := [2,4,8,16,32,64,8,5,1,47,0,27,40,74,33,35,106,33,47,33,26,1,96,2,47,41,1,48,32,74,58,0,46,81,5,112,5,34,107,0,0,58,1]

def active9149 : List Nat := [0,1,2,3,4,5]

def tree9149 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9149 : H12WitnessSearch.Good tree9149 := H12GlobalWitnessIndex.good

theorem leafIdentity9149 : H12AffineFastState.composeSystem env9149 rootObs = leafEnv9149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9149 rootObs == leafEnv9149) = true)

theorem terminalChecked9149 : H12PackedTerminal.terminalCheckFast leafEnv9149 active9149 tree9149 = true := by decide +kernel

def env9150 : List Nat := [2,4,8,16,32,64,128,141,137,1024,1,4096,4147,4177,4154,1036,1229,4154,1024,4154,4097,137,5340,5310,4282,5260,4155,4177,1181,5173,1161,217,141,5188,1228,136]

theorem envBound9150 : H12AffineFastState.Bounded env9150 := by
  intro p hp
  have h : env9150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9145_9150 : H12AffineEnvironment.transform 10 1 env9145 = env9150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env9145 == env9150) = true)

theorem identity9150 : scanCanonicalize (H12AffineFastState.compose env9150 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 146) := by decide +kernel

theorem selectedBound9150 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9151 : List Nat := [2,4,8,16,32,64,128,141,137,1024,1,146,161,195,168,1036,1229,168,1024,168,147,137,1102,1068,40,1054,169,195,1181,1191,1161,217,141,1238,1228,136]

theorem envBound9151 : H12AffineFastState.Bounded env9151 := by
  intro p hp
  have h : env9151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9150_9151 : H12AffineEnvironment.transform 11 146 env9150 = env9151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 146 env9150 == env9151) = true)

theorem identity9151 : scanCanonicalize (H12AffineFastState.compose env9151 (packedSelected [4] rootPS)) = affineNative (2^(9+1) ^^^ 166) := by decide +kernel

theorem selectedBound9151 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env9152 : List Nat := [2,4,8,16,32,64,128,141,137,166,1,146,161,195,168,170,107,168,166,168,147,137,232,138,40,184,169,195,59,1,47,217,141,112,106,136]

theorem envBound9152 : H12AffineFastState.Bounded env9152 := by
  intro p hp
  have h : env9152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9151_9152 : H12AffineEnvironment.transform 9 166 env9151 = env9152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 166 env9151 == env9152) = true)

theorem identity9152 : scanCanonicalize (H12AffineFastState.compose env9152 (packedSelected [5,8] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound9152 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env9153 : List Nat := [2,4,8,16,32,64,8,5,1,46,1,26,41,75,32,34,107,32,46,32,27,1,96,2,40,48,33,75,59,1,47,81,5,112,106,0]

theorem envBound9153 : H12AffineFastState.Bounded env9153 := by
  intro p hp
  have h : env9153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9152_9153 : H12AffineEnvironment.transform 6 8 env9152 = env9153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env9152 == env9153) = true)

def leafEnv9153 : List Nat := [2,4,8,16,32,64,8,5,1,46,1,26,41,75,32,34,107,32,46,32,27,1,96,2,46,40,1,48,33,75,59,1,47,81,5,112,5,35,106,0,0,59,1]

def active9153 : List Nat := [0,1,2,3,4,5]

def tree9153 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9153 : H12WitnessSearch.Good tree9153 := H12GlobalWitnessIndex.good

theorem leafIdentity9153 : H12AffineFastState.composeSystem env9153 rootObs = leafEnv9153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9153 rootObs == leafEnv9153) = true)

theorem terminalChecked9153 : H12PackedTerminal.terminalCheckFast leafEnv9153 active9153 tree9153 = true := by decide +kernel

def env9154 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,136512,4194304,17664,16777216,33554432,67108864,21484817,67130625,131153,71538891,16876544,4294967296,257,4416628082,131073,33563272]

theorem envBound9154 : H12AffineFastState.Bounded env9154 := by
  intro p hp
  have h : env9154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9110_9154 : H12AffineEnvironment.transform 18 1025 env9110 = env9154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env9110 == env9154) = true)

def env9155 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,136512,4194304,17664,16777216,33554432,5376,21484817,16385,131153,4427211,16876544,4294967296,257,4349522034,131073,33563272]

theorem envBound9155 : H12AffineFastState.Bounded env9155 := by
  intro p hp
  have h : env9155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9154_9155 : H12AffineEnvironment.transform 25 5376 env9154 = env9155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 5376 env9154 == env9155) = true)

theorem identity9155 : scanCanonicalize (H12AffineFastState.compose env9155 (packedSelected [4,6,7,9,16,20,25,27] rootPS)) = affineNative (2^(23+1) ^^^ 230468) := by decide +kernel

theorem selectedBound9155 : packedSelected [4,6,7,9,16,20,25,27] rootPS < 2^1333 := by decide +kernel

def env9156 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,136512,4194304,17664,230468,33554432,5376,4477269,16385,131153,4427211,131140,4294967296,257,4332975158,131073,33563272]

theorem envBound9156 : H12AffineFastState.Bounded env9156 := by
  intro p hp
  have h : env9156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9155_9156 : H12AffineEnvironment.transform 23 230468 env9155 = env9156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 230468 env9155 == env9156) = true)

theorem identity9156 : scanCanonicalize (H12AffineFastState.compose env9156 (packedSelected [3,5,8,10,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 1345) := by decide +kernel

theorem selectedBound9156 : packedSelected [3,5,8,10,28,31] rootPS < 2^1333 := by decide +kernel

def env9157 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,1025,32768,4097,4194304,17664,98565,33554432,5376,4477269,16385,1296,4294794,1285,4294967296,257,4332843383,1344,33563272]

theorem envBound9157 : H12AffineFastState.Bounded env9157 := by
  intro p hp
  have h : env9157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9156_9157 : H12AffineEnvironment.transform 16 1345 env9156 = env9157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 1345 env9156 == env9157) = true)

theorem identity9157 : scanCanonicalize (H12AffineFastState.compose env9157 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(24+1) ^^^ 8329) := by decide +kernel

theorem selectedBound9157 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env9158 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,1345,262144,1025,32768,4097,4194304,17664,98565,8329,5376,4477269,16385,1296,4294794,1285,4294967296,257,4299280894,1344,513]

theorem envBound9158 : H12AffineFastState.Bounded env9158 := by
  intro p hp
  have h : env9158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9157_9158 : H12AffineEnvironment.transform 24 8329 env9157 = env9158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 8329 env9157 == env9158) = true)

theorem identity9158 : scanCanonicalize (H12AffineFastState.compose env9158 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 4825) := by decide +kernel

theorem selectedBound9158 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env9159 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4825,32768,65536,1345,262144,1025,32768,4097,4194304,6105,98565,8329,5376,4457356,4824,1296,4294794,1285,4294967296,257,4299260711,1344,513]

theorem envBound9159 : H12AffineFastState.Bounded env9159 := by
  intro p hp
  have h : env9159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9158_9159 : H12AffineEnvironment.transform 13 4825 env9158 = env9159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4825 env9158 == env9159) = true)

def env9160 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,4177,32768,65536,1345,262144,1025,32768,4097,4194304,5457,98565,8329,5376,4456708,4176,1296,4294794,1285,4294967296,257,4299260335,1344,137]

theorem envBound9160 : H12AffineFastState.Bounded env9160 := by
  intro p hp
  have h : env9160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9159_9160 : H12AffineEnvironment.transform 8 136 env9159 = env9160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env9159 == env9160) = true)

theorem identity9160 : scanCanonicalize (H12AffineFastState.compose env9160 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 477) := by decide +kernel

theorem selectedBound9160 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9161 : List Nat := [2,4,8,16,32,64,128,256,136,1024,2048,4096,8192,4177,32768,65536,1345,262144,1025,32768,4097,477,5457,98565,8329,5376,262361,4176,1296,100695,1285,4294967296,257,4295065714,1344,137]

theorem envBound9161 : H12AffineFastState.Bounded env9161 := by
  intro p hp
  have h : env9161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9160_9161 : H12AffineEnvironment.transform 21 477 env9160 = env9161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 477 env9160 == env9161) = true)

theorem identity9161 : scanCanonicalize (H12AffineFastState.compose env9161 (packedSelected [1,12,13] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound9161 : packedSelected [1,12,13] rootPS < 2^1333 := by decide +kernel

def env9162 : List Nat := [2,4,8,16,32,64,128,5,136,1024,2048,4096,8192,4177,32768,65536,1092,262144,1025,32768,4097,216,5204,98304,8329,5125,262361,4176,1045,100434,1024,4294967296,4,4295065714,1093,137]

theorem envBound9162 : H12AffineFastState.Bounded env9162 := by
  intro p hp
  have h : env9162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9161_9162 : H12AffineEnvironment.transform 7 5 env9161 = env9162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env9161 == env9162) = true)

theorem identity9162 : scanCanonicalize (H12AffineFastState.compose env9162 (packedSelected [1,3,5,8,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 13341) := by decide +kernel

theorem selectedBound9162 : packedSelected [1,3,5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env9163 : List Nat := [2,4,8,16,32,64,128,5,136,1024,2048,4096,8192,4177,13341,65536,1092,262144,1025,13341,4097,216,5204,78877,8329,5125,262361,4176,1045,80975,1024,4294967296,4,4295046255,1093,137]

theorem envBound9163 : H12AffineFastState.Bounded env9163 := by
  intro p hp
  have h : env9163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9162_9163 : H12AffineEnvironment.transform 14 13341 env9162 = env9163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13341 env9162 == env9163) = true)

theorem identity9163 : scanCanonicalize (H12AffineFastState.compose env9163 (packedSelected [1,8,12] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound9163 : packedSelected [1,8,12] rootPS < 2^1333 := by decide +kernel

def env9164 : List Nat := [2,4,8,16,32,64,128,5,136,1024,2048,4096,8192,4177,13341,114,1092,262144,1025,13341,4097,216,5204,13423,8329,5125,262361,4176,1045,15421,1024,4294967296,4,4294980637,1093,137]

theorem envBound9164 : H12AffineFastState.Bounded env9164 := by
  intro p hp
  have h : env9164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9163_9164 : H12AffineEnvironment.transform 15 114 env9163 = env9164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env9163 == env9164) = true)

def env9165 : List Nat := [2,4,8,16,32,16,128,5,136,1024,2048,4096,8192,4097,13341,34,1044,262144,1025,13341,4097,136,5124,13375,8329,5125,262281,4096,1045,15421,1024,4294967296,4,4294980637,1045,137]

theorem envBound9165 : H12AffineFastState.Bounded env9165 := by
  intro p hp
  have h : env9165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9164_9165 : H12AffineEnvironment.transform 5 16 env9164 = env9165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env9164 == env9165) = true)

theorem identity9165 : scanCanonicalize (H12AffineFastState.compose env9165 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 267447) := by decide +kernel

theorem selectedBound9165 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env9166 : List Nat := [2,4,8,16,32,16,128,5,136,1024,2048,4096,8192,4097,13341,34,1044,262144,1025,13341,4097,136,5124,13375,8329,5125,262281,4096,1045,15421,1024,267447,4,270506,1045,137]

theorem envBound9166 : H12AffineFastState.Bounded env9166 := by
  intro p hp
  have h : env9166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9165_9166 : H12AffineEnvironment.transform 31 267447 env9165 = env9166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 267447 env9165 == env9166) = true)

def env9167 : List Nat := [2,4,8,16,32,16,128,5,136,1024,2048,4096,8192,4097,13341,34,1044,8320,1025,13341,4097,136,5124,13375,8329,5125,8201,4096,1045,15421,1024,13367,4,42,1045,137]

theorem envBound9167 : H12AffineFastState.Bounded env9167 := by
  intro p hp
  have h : env9167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9166_9167 : H12AffineEnvironment.transform 17 8320 env9166 = env9167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8320 env9166 == env9167) = true)

theorem identity9167 : scanCanonicalize (H12AffineFastState.compose env9167 (packedSelected [7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound9167 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env9168 : List Nat := [2,4,8,16,32,16,8,5,0,1024,2048,4096,8192,4097,13341,34,1044,8200,1025,13341,4097,0,5124,13375,8193,5125,8201,4096,1045,15421,1024,13367,4,42,1045,1]

theorem envBound9168 : H12AffineFastState.Bounded env9168 := by
  intro p hp
  have h : env9168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9167_9168 : H12AffineEnvironment.transform 6 8 env9167 = env9168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env9167 == env9168) = true)

def env9169 : List Nat := [2,4,8,16,32,16,8,5,0,1024,0,4096,8192,4097,13341,34,1044,8200,1025,13341,4097,0,5124,13375,8193,5125,8201,4096,1045,13373,1024,13367,4,42,1045,1]

theorem envBound9169 : H12AffineFastState.Bounded env9169 := by
  intro p hp
  have h : env9169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9168_9169 : H12AffineEnvironment.transform 10 0 env9168 = env9169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env9168 == env9169) = true)

def env9170 : List Nat := [2,4,8,16,32,16,8,5,0,1024,1,4096,8192,4097,13341,34,1044,8200,1025,13341,4097,0,5124,13375,8193,5125,8201,4096,1045,13372,1024,13367,4,42,1045,1]

theorem envBound9170 : H12AffineFastState.Bounded env9170 := by
  intro p hp
  have h : env9170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9168_9170 : H12AffineEnvironment.transform 10 1 env9168 = env9170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env9168 == env9170) = true)

theorem identity9170 : scanCanonicalize (H12AffineFastState.compose env9170 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 5181) := by decide +kernel

theorem selectedBound9170 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9171 : List Nat := [2,4,8,16,32,16,8,5,0,1024,1,4096,5181,4097,32,34,1044,5173,1025,32,4097,0,5124,2,5180,5125,5172,4096,1045,1,1024,10,4,42,1045,1]

theorem envBound9171 : H12AffineFastState.Bounded env9171 := by
  intro p hp
  have h : env9171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9170_9171 : H12AffineEnvironment.transform 12 5181 env9170 = env9171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5181 env9170 == env9171) = true)

def env9172 : List Nat := [2,4,8,16,0,16,8,5,0,1024,1,4096,5149,4097,0,2,1044,5141,1025,0,4097,0,5124,2,5148,5125,5140,4096,1045,1,1024,10,4,10,1045,1]

theorem envBound9172 : H12AffineFastState.Bounded env9172 := by
  intro p hp
  have h : env9172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9171_9172 : H12AffineEnvironment.transform 4 0 env9171 = env9172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env9171 == env9172) = true)

theorem identity9172 : scanCanonicalize (H12AffineFastState.compose env9172 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound9172 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9173 : List Nat := [2,4,8,11,0,11,8,5,0,1024,1,4096,5126,4097,0,2,1039,5134,1025,0,4097,0,5124,2,5127,5125,5135,4096,1038,1,1024,10,4,10,1038,1]

theorem envBound9173 : H12AffineFastState.Bounded env9173 := by
  intro p hp
  have h : env9173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9172_9173 : H12AffineEnvironment.transform 3 11 env9172 = env9173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env9172 == env9173) = true)

def leafEnv9173 : List Nat := [2,4,8,11,0,11,8,5,0,1024,1,4096,5126,4097,0,2,1039,5134,1025,0,4097,0,5124,2,1025,5127,1,5125,5135,4096,1038,1,1024,10,4,10,5,3,1038,1,0,1039,1]

def active9173 : List Nat := [0,1,2,9,11]

def tree9173 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9173 : H12WitnessSearch.Good tree9173 := H12GlobalWitnessIndex.good

theorem leafIdentity9173 : H12AffineFastState.composeSystem env9173 rootObs = leafEnv9173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9173 rootObs == leafEnv9173) = true)

theorem terminalChecked9173 : H12PackedTerminal.terminalCheckFast leafEnv9173 active9173 tree9173 = true := by decide +kernel

def env9174 : List Nat := [2,4,8,16,1,16,8,5,0,1024,1,4096,5148,4097,1,3,1044,5140,1025,1,4097,0,5124,2,5149,5125,5141,4096,1045,1,1024,10,4,11,1045,1]

theorem envBound9174 : H12AffineFastState.Bounded env9174 := by
  intro p hp
  have h : env9174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9171_9174 : H12AffineEnvironment.transform 4 1 env9171 = env9174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env9171 == env9174) = true)

theorem identity9174 : scanCanonicalize (H12AffineFastState.compose env9174 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound9174 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9175 : List Nat := [2,4,8,0,1,0,8,5,0,1024,1,4096,5132,4097,1,3,1028,5124,1025,1,4097,0,5124,2,5133,5125,5125,4096,1029,1,1024,10,4,11,1029,1]

theorem envBound9175 : H12AffineFastState.Bounded env9175 := by
  intro p hp
  have h : env9175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9174_9175 : H12AffineEnvironment.transform 3 0 env9174 = env9175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env9174 == env9175) = true)

def leafEnv9175 : List Nat := [2,4,8,0,1,0,8,5,0,1024,1,4096,5132,4097,1,3,1028,5124,1025,1,4097,0,5124,2,1025,5133,1,5125,5125,4096,1029,1,1024,10,4,11,5,2,1029,1,0,1028,1]

def active9175 : List Nat := [0,1,2,9,11]

def tree9175 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9175 : H12WitnessSearch.Good tree9175 := H12GlobalWitnessIndex.good

theorem leafIdentity9175 : H12AffineFastState.composeSystem env9175 rootObs = leafEnv9175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9175 rootObs == leafEnv9175) = true)

theorem terminalChecked9175 : H12PackedTerminal.terminalCheckFast leafEnv9175 active9175 tree9175 = true := by decide +kernel

def env9176 : List Nat := [2,4,8,16,32,16,128,5,136,1024,2048,4096,8192,4097,13341,34,1044,8321,1025,13341,4097,136,5124,13375,8329,5125,8200,4096,1045,15421,1024,13366,4,43,1045,137]

theorem envBound9176 : H12AffineFastState.Bounded env9176 := by
  intro p hp
  have h : env9176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9166_9176 : H12AffineEnvironment.transform 17 8321 env9166 = env9176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8321 env9166 == env9176) = true)

def env9177 : List Nat := [2,4,8,16,32,17,128,5,136,1024,2048,4096,8192,4096,13341,35,1045,262144,1025,13341,4097,137,5125,13374,8329,5125,262280,4097,1045,15421,1024,4294967296,4,4294980637,1044,137]

theorem envBound9177 : H12AffineFastState.Bounded env9177 := by
  intro p hp
  have h : env9177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9164_9177 : H12AffineEnvironment.transform 5 17 env9164 = env9177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env9164 == env9177) = true)

theorem identity9177 : scanCanonicalize (H12AffineFastState.compose env9177 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 262306) := by decide +kernel

theorem selectedBound9177 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env9178 : List Nat := [2,4,8,16,32,17,128,5,136,1024,2048,4096,8192,4096,13341,35,1045,262144,1025,13341,4097,137,5125,13374,8329,5125,262280,4097,1045,15421,1024,262306,4,275647,1044,137]

theorem envBound9178 : H12AffineFastState.Bounded env9178 := by
  intro p hp
  have h : env9178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9177_9178 : H12AffineEnvironment.transform 31 262306 env9177 = env9178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 262306 env9177 == env9178) = true)

def env9179 : List Nat := [2,4,8,16,32,17,128,5,136,1024,2048,4096,8192,4096,13341,35,1045,8320,1025,13341,4097,137,5125,13374,8329,5125,8200,4097,1045,15421,1024,8226,4,5183,1044,137]

theorem envBound9179 : H12AffineFastState.Bounded env9179 := by
  intro p hp
  have h : env9179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9178_9179 : H12AffineEnvironment.transform 17 8320 env9178 = env9179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8320 env9178 == env9179) = true)

def env9180 : List Nat := [2,4,8,16,32,17,128,5,136,1024,2048,4096,8192,4096,13341,35,1045,8321,1025,13341,4097,137,5125,13374,8329,5125,8201,4097,1045,15421,1024,8227,4,5182,1044,137]

theorem envBound9180 : H12AffineFastState.Bounded env9180 := by
  intro p hp
  have h : env9180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9178_9180 : H12AffineEnvironment.transform 17 8321 env9178 = env9180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8321 env9178 == env9180) = true)

theorem identity9180 : scanCanonicalize (H12AffineFastState.compose env9180 (packedSelected [7] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound9180 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env9181 : List Nat := [2,4,8,16,32,17,9,5,1,1024,2048,4096,8192,4096,13341,35,1045,8200,1025,13341,4097,0,5125,13374,8192,5125,8201,4097,1045,15421,1024,8227,4,5182,1044,0]

theorem envBound9181 : H12AffineFastState.Bounded env9181 := by
  intro p hp
  have h : env9181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9180_9181 : H12AffineEnvironment.transform 6 9 env9180 = env9181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env9180 == env9181) = true)

def env9182 : List Nat := [2,4,8,16,32,17,9,5,1,1024,0,4096,8192,4096,13341,35,1045,8200,1025,13341,4097,0,5125,13374,8192,5125,8201,4097,1045,13373,1024,8227,4,5182,1044,0]

theorem envBound9182 : H12AffineFastState.Bounded env9182 := by
  intro p hp
  have h : env9182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9181_9182 : H12AffineEnvironment.transform 10 0 env9181 = env9182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env9181 == env9182) = true)

def env9183 : List Nat := [2,4,8,16,32,17,9,5,1,1024,1,4096,8192,4096,13341,35,1045,8200,1025,13341,4097,0,5125,13374,8192,5125,8201,4097,1045,13372,1024,8227,4,5182,1044,0]

theorem envBound9183 : H12AffineFastState.Bounded env9183 := by
  intro p hp
  have h : env9183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9181_9183 : H12AffineEnvironment.transform 10 1 env9181 = env9183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env9181 == env9183) = true)

theorem identity9183 : scanCanonicalize (H12AffineFastState.compose env9183 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 5181) := by decide +kernel

theorem selectedBound9183 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9184 : List Nat := [2,4,8,16,32,17,9,5,1,1024,1,4096,5181,4096,32,35,1045,5173,1025,32,4097,0,5125,3,5181,5125,5172,4097,1045,1,1024,5150,4,5182,1044,0]

theorem envBound9184 : H12AffineFastState.Bounded env9184 := by
  intro p hp
  have h : env9184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9183_9184 : H12AffineEnvironment.transform 12 5181 env9183 = env9184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5181 env9183 == env9184) = true)

def env9185 : List Nat := [2,4,8,16,0,17,9,5,1,1024,1,4096,5149,4096,0,3,1045,5141,1025,0,4097,0,5125,3,5149,5125,5140,4097,1045,1,1024,5150,4,5150,1044,0]

theorem envBound9185 : H12AffineFastState.Bounded env9185 := by
  intro p hp
  have h : env9185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9184_9185 : H12AffineEnvironment.transform 4 0 env9184 = env9185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env9184 == env9185) = true)

theorem identity9185 : scanCanonicalize (H12AffineFastState.compose env9185 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound9185 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9186 : List Nat := [2,4,8,10,0,11,9,5,1,1024,1,4096,5127,4096,0,3,1039,5135,1025,0,4097,0,5125,3,5127,5125,5134,4097,1039,1,1024,5124,4,5124,1038,0]

theorem envBound9186 : H12AffineFastState.Bounded env9186 := by
  intro p hp
  have h : env9186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9185_9186 : H12AffineEnvironment.transform 3 10 env9185 = env9186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env9185 == env9186) = true)

def leafEnv9186 : List Nat := [2,4,8,10,0,11,9,5,1,1024,1,4096,5127,4096,0,3,1039,5135,1025,0,4097,0,5125,3,1025,5127,1,5125,5134,4097,1039,1,1024,5124,4,5124,5,3,1038,0,0,1038,1]

def active9186 : List Nat := [0,1,2,9,11]

def tree9186 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9186 : H12WitnessSearch.Good tree9186 := H12GlobalWitnessIndex.good

theorem leafIdentity9186 : H12AffineFastState.composeSystem env9186 rootObs = leafEnv9186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9186 rootObs == leafEnv9186) = true)

theorem terminalChecked9186 : H12PackedTerminal.terminalCheckFast leafEnv9186 active9186 tree9186 = true := by decide +kernel

def env9187 : List Nat := [2,4,8,16,1,17,9,5,1,1024,1,4096,5148,4096,1,2,1045,5140,1025,1,4097,0,5125,3,5148,5125,5141,4097,1045,1,1024,5150,4,5151,1044,0]

theorem envBound9187 : H12AffineFastState.Bounded env9187 := by
  intro p hp
  have h : env9187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9184_9187 : H12AffineEnvironment.transform 4 1 env9184 = env9187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env9184 == env9187) = true)

theorem identity9187 : scanCanonicalize (H12AffineFastState.compose env9187 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound9187 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9188 : List Nat := [2,4,8,16,1,17,9,5,1,1024,1,1029,25,1029,1,2,1045,17,1025,1,1028,0,0,3,25,0,16,1028,1045,1,1024,27,4,26,1044,0]

theorem envBound9188 : H12AffineFastState.Bounded env9188 := by
  intro p hp
  have h : env9188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9187_9188 : H12AffineEnvironment.transform 11 1029 env9187 = env9188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env9187 == env9188) = true)

def leafEnv9188 : List Nat := [2,4,8,16,1,17,9,5,1,1024,1,1029,25,1029,1,2,1045,17,1025,1,1028,0,0,3,1025,25,1,0,16,1028,1045,1,1024,27,4,26,5,2,1044,0,0,1044,1]

def active9188 : List Nat := [0,1,2,3,9]

def tree9188 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9188 : H12WitnessSearch.Good tree9188 := H12GlobalWitnessIndex.good

theorem leafIdentity9188 : H12AffineFastState.composeSystem env9188 rootObs = leafEnv9188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9188 rootObs == leafEnv9188) = true)

theorem terminalChecked9188 : H12PackedTerminal.terminalCheckFast leafEnv9188 active9188 tree9188 = true := by decide +kernel

def env9189 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,4096,8192,4176,32768,65536,1345,262144,1025,32768,4097,4194304,5456,98565,8329,5376,4456709,4177,1296,4294794,1285,4294967296,257,4299260334,1344,136]

theorem envBound9189 : H12AffineFastState.Bounded env9189 := by
  intro p hp
  have h : env9189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9159_9189 : H12AffineEnvironment.transform 8 137 env9159 = env9189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env9159 == env9189) = true)

theorem identity9189 : scanCanonicalize (H12AffineFastState.compose env9189 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound9189 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env9190 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1296,8192,1344,32768,65536,1345,262144,1025,32768,1297,4194304,64,98565,8329,16,4456709,1345,1296,4294794,1285,4294967296,257,4299260334,1344,136]

theorem envBound9190 : H12AffineFastState.Bounded env9190 := by
  intro p hp
  have h : env9190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9189_9190 : H12AffineEnvironment.transform 11 1296 env9189 = env9190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env9189 == env9190) = true)

def env9191 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1296,8192,1344,32768,65536,1345,262144,1025,32768,1297,41088,64,98565,8329,16,303493,1345,1296,75786,1285,4294967296,257,4295041326,1344,136]

theorem envBound9191 : H12AffineFastState.Bounded env9191 := by
  intro p hp
  have h : env9191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9190_9191 : H12AffineEnvironment.transform 21 41088 env9190 = env9191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env9190 == env9191) = true)

theorem identity9191 : scanCanonicalize (H12AffineFastState.compose env9191 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 270846) := by decide +kernel

theorem selectedBound9191 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env9192 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1296,8192,1344,32768,65536,1345,262144,1025,32768,1297,41088,64,98565,8329,16,303493,1345,1296,75786,1285,270846,257,327888,1344,136]

theorem envBound9192 : H12AffineFastState.Bounded env9192 := by
  intro p hp
  have h : env9192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9191_9192 : H12AffineEnvironment.transform 31 270846 env9191 = env9192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 270846 env9191 == env9192) = true)

def env9193 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1296,8192,1344,32768,65536,1345,32904,1025,32768,1297,41088,64,98565,8329,16,8461,1345,1296,75786,1285,41334,257,98392,1344,136]

theorem envBound9193 : H12AffineFastState.Bounded env9193 := by
  intro p hp
  have h : env9193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9192_9193 : H12AffineEnvironment.transform 17 32904 env9192 = env9193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32904 env9192 == env9193) = true)

theorem identity9193 : scanCanonicalize (H12AffineFastState.compose env9193 (packedSelected [7] rootPS)) = affineNative (2^(14+1) ^^^ 8580) := by decide +kernel

theorem selectedBound9193 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env9194 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1296,8192,1344,8580,65536,1345,8460,1025,8580,1297,260,64,73857,8329,16,8461,1345,1296,75786,1285,242,257,74204,1344,136]

theorem envBound9194 : H12AffineFastState.Bounded env9194 := by
  intro p hp
  have h : env9194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9193_9194 : H12AffineEnvironment.transform 14 8580 env9193 = env9194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8580 env9193 == env9194) = true)

def env9195 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,1296,8192,1344,8580,65536,1345,8460,1025,8580,1297,260,64,73857,8329,16,8461,1345,1296,73738,1285,242,257,74204,1344,136]

theorem envBound9195 : H12AffineFastState.Bounded env9195 := by
  intro p hp
  have h : env9195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9194_9195 : H12AffineEnvironment.transform 10 0 env9194 = env9195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env9194 == env9195) = true)

theorem identity9195 : scanCanonicalize (H12AffineFastState.compose env9195 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound9195 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9196 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,1296,8192,1344,8580,170,1345,8460,1025,8580,1297,260,64,8235,8329,16,8461,1345,1296,8352,1285,242,257,8566,1344,136]

theorem envBound9196 : H12AffineFastState.Bounded env9196 := by
  intro p hp
  have h : env9196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9195_9196 : H12AffineEnvironment.transform 15 170 env9195 = env9196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env9195 == env9196) = true)

theorem identity9196 : scanCanonicalize (H12AffineFastState.compose env9196 (packedSelected [2,4] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound9196 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env9197 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,1296,160,1344,292,170,1345,428,1025,292,1297,260,64,139,41,16,429,1345,1296,0,1285,242,257,470,1344,136]

theorem envBound9197 : H12AffineFastState.Bounded env9197 := by
  intro p hp
  have h : env9197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9196_9197 : H12AffineEnvironment.transform 12 160 env9196 = env9197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env9196 == env9197) = true)

def env9198 : List Nat := [2,4,8,16,32,16,128,256,137,1024,0,1296,160,1296,292,170,1297,428,1025,292,1297,260,16,139,41,16,429,1297,1296,0,1285,162,257,390,1296,136]

theorem envBound9198 : H12AffineFastState.Bounded env9198 := by
  intro p hp
  have h : env9198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9197_9198 : H12AffineEnvironment.transform 5 16 env9197 = env9198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env9197 == env9198) = true)

theorem identity9198 : scanCanonicalize (H12AffineFastState.compose env9198 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound9198 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9199 : List Nat := [2,4,8,16,16,16,128,256,137,1024,0,1296,144,1296,276,154,1297,412,1025,276,1297,260,16,139,25,16,413,1297,1296,0,1285,146,257,390,1296,136]

theorem envBound9199 : H12AffineFastState.Bounded env9199 := by
  intro p hp
  have h : env9199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9198_9199 : H12AffineEnvironment.transform 4 16 env9198 = env9199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env9198 == env9199) = true)

def env9200 : List Nat := [2,4,8,16,16,16,128,20,137,1024,0,1028,144,1028,0,154,1029,136,1025,0,1029,16,16,139,25,16,137,1029,1028,0,1041,146,21,146,1028,136]

theorem envBound9200 : H12AffineFastState.Bounded env9200 := by
  intro p hp
  have h : env9200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9199_9200 : H12AffineEnvironment.transform 7 20 env9199 = env9200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env9199 == env9200) = true)

theorem identity9200 : scanCanonicalize (H12AffineFastState.compose env9200 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound9200 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9201 : List Nat := [2,4,8,16,16,16,18,20,27,1024,0,1028,2,1028,0,8,1029,26,1025,0,1029,16,16,25,25,16,27,1029,1028,0,1041,0,21,0,1028,26]

theorem envBound9201 : H12AffineFastState.Bounded env9201 := by
  intro p hp
  have h : env9201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9200_9201 : H12AffineEnvironment.transform 6 18 env9200 = env9201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env9200 == env9201) = true)

def leafEnv9201 : List Nat := [2,4,8,16,16,16,18,20,27,1024,0,1028,2,1028,0,8,1029,26,1025,0,1029,16,16,25,1040,25,1,16,27,1029,1028,0,1041,0,21,0,5,18,1028,26,0,1029,1]

def active9201 : List Nat := [0,1,2,3,9]

def tree9201 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9201 : H12WitnessSearch.Good tree9201 := H12GlobalWitnessIndex.good

theorem leafIdentity9201 : H12AffineFastState.composeSystem env9201 rootObs = leafEnv9201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9201 rootObs == leafEnv9201) = true)

theorem terminalChecked9201 : H12PackedTerminal.terminalCheckFast leafEnv9201 active9201 tree9201 = true := by decide +kernel

def env9202 : List Nat := [2,4,8,16,16,16,128,21,137,1024,0,1029,144,1029,1,154,1028,137,1025,1,1028,17,16,139,25,16,136,1028,1029,0,1040,146,20,147,1029,136]

theorem envBound9202 : H12AffineFastState.Bounded env9202 := by
  intro p hp
  have h : env9202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9199_9202 : H12AffineEnvironment.transform 7 21 env9199 = env9202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env9199 == env9202) = true)

theorem identity9202 : scanCanonicalize (H12AffineFastState.compose env9202 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound9202 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9203 : List Nat := [2,4,8,0,0,0,128,5,137,1024,0,1029,128,1029,1,138,1028,137,1025,1,1028,1,0,139,9,0,136,1028,1029,0,1024,130,4,131,1029,136]

theorem envBound9203 : H12AffineFastState.Bounded env9203 := by
  intro p hp
  have h : env9203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9202_9203 : H12AffineEnvironment.transform 3 0 env9202 = env9203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env9202 == env9203) = true)

def leafEnv9203 : List Nat := [2,4,8,0,0,0,128,5,137,1024,0,1029,128,1029,1,138,1028,137,1025,1,1028,1,0,139,1025,9,1,0,136,1028,1029,0,1024,130,4,131,5,2,1029,136,0,1028,1]

def active9203 : List Nat := [0,1,2,6,9]

def tree9203 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9203 : H12WitnessSearch.Good tree9203 := H12GlobalWitnessIndex.good

theorem leafIdentity9203 : H12AffineFastState.composeSystem env9203 rootObs = leafEnv9203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9203 rootObs == leafEnv9203) = true)

theorem terminalChecked9203 : H12PackedTerminal.terminalCheckFast leafEnv9203 active9203 tree9203 = true := by decide +kernel

def env9204 : List Nat := [2,4,8,16,32,17,128,256,137,1024,0,1296,160,1297,292,170,1296,428,1025,292,1297,260,17,139,41,16,429,1296,1296,0,1285,163,257,391,1297,136]

theorem envBound9204 : H12AffineFastState.Bounded env9204 := by
  intro p hp
  have h : env9204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9197_9204 : H12AffineEnvironment.transform 5 17 env9197 = env9204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env9197 == env9204) = true)

theorem identity9204 : scanCanonicalize (H12AffineFastState.compose env9204 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound9204 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9205 : List Nat := [2,4,8,16,32,17,57,256,48,1024,0,1296,25,1297,292,19,1296,277,1025,292,1297,260,17,50,41,16,276,1296,1296,0,1285,26,257,318,1297,49]

theorem envBound9205 : H12AffineFastState.Bounded env9205 := by
  intro p hp
  have h : env9205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9204_9205 : H12AffineEnvironment.transform 6 57 env9204 = env9205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env9204 == env9205) = true)

def env9206 : List Nat := [2,4,8,16,32,17,57,36,48,1024,0,1076,25,1077,0,19,1076,49,1025,0,1077,32,17,50,41,16,48,1076,1076,0,1057,26,37,26,1077,49]

theorem envBound9206 : H12AffineFastState.Bounded env9206 := by
  intro p hp
  have h : env9206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9205_9206 : H12AffineEnvironment.transform 7 36 env9205 = env9206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env9205 == env9206) = true)

theorem identity9206 : scanCanonicalize (H12AffineFastState.compose env9206 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound9206 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9207 : List Nat := [2,4,8,11,32,10,34,36,43,1024,0,1071,2,1070,0,8,1071,42,1025,0,1070,32,10,41,41,11,43,1071,1071,0,1057,1,37,1,1070,42]

theorem envBound9207 : H12AffineFastState.Bounded env9207 := by
  intro p hp
  have h : env9207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9206_9207 : H12AffineEnvironment.transform 3 11 env9206 = env9207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env9206 == env9207) = true)

def leafEnv9207 : List Nat := [2,4,8,11,32,10,34,36,43,1024,0,1071,2,1070,0,8,1071,42,1025,0,1070,32,10,41,1056,41,1,11,43,1071,1071,0,1057,1,37,1,5,34,1070,42,0,1070,1]

def active9207 : List Nat := [0,1,2,4,9]

def tree9207 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9207 : H12WitnessSearch.Good tree9207 := H12GlobalWitnessIndex.good

theorem leafIdentity9207 : H12AffineFastState.composeSystem env9207 rootObs = leafEnv9207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9207 rootObs == leafEnv9207) = true)

theorem terminalChecked9207 : H12PackedTerminal.terminalCheckFast leafEnv9207 active9207 tree9207 = true := by decide +kernel

def env9208 : List Nat := [2,4,8,16,32,17,57,37,48,1024,0,1077,25,1076,1,19,1077,48,1025,1,1076,33,17,50,41,16,49,1077,1077,0,1056,26,36,27,1076,49]

theorem envBound9208 : H12AffineFastState.Bounded env9208 := by
  intro p hp
  have h : env9208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9205_9208 : H12AffineEnvironment.transform 7 37 env9205 = env9208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env9205 == env9208) = true)

theorem identity9208 : scanCanonicalize (H12AffineFastState.compose env9208 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound9208 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9209 : List Nat := [2,4,8,16,1,17,24,4,17,1024,0,1044,25,1045,1,19,1044,17,1025,1,1045,0,17,19,8,16,16,1044,1044,0,1025,26,5,27,1045,16]

theorem envBound9209 : H12AffineFastState.Bounded env9209 := by
  intro p hp
  have h : env9209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9208_9209 : H12AffineEnvironment.transform 4 1 env9208 = env9209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env9208 == env9209) = true)

def leafEnv9209 : List Nat := [2,4,8,16,1,17,24,4,17,1024,0,1044,25,1045,1,19,1044,17,1025,1,1045,0,17,19,1024,8,1,16,16,1044,1044,0,1025,26,5,27,5,3,1045,16,0,1045,1]

def active9209 : List Nat := [0,1,2,3,9]

def tree9209 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9209 : H12WitnessSearch.Good tree9209 := H12GlobalWitnessIndex.good

theorem leafIdentity9209 : H12AffineFastState.composeSystem env9209 rootObs = leafEnv9209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9209 rootObs == leafEnv9209) = true)

theorem terminalChecked9209 : H12PackedTerminal.terminalCheckFast leafEnv9209 active9209 tree9209 = true := by decide +kernel

def env9210 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,1296,8192,1344,8580,65536,1345,8460,1025,8580,1297,260,64,73857,8329,16,8461,1345,1296,73739,1285,242,257,74204,1344,136]

theorem envBound9210 : H12AffineFastState.Bounded env9210 := by
  intro p hp
  have h : env9210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9194_9210 : H12AffineEnvironment.transform 10 1 env9194 = env9210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env9194 == env9210) = true)

theorem identity9210 : scanCanonicalize (H12AffineFastState.compose env9210 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound9210 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9211 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,1296,161,1344,293,65536,1345,429,1025,293,1297,260,64,65568,40,16,428,1345,1296,65706,1285,242,257,65917,1344,136]

theorem envBound9211 : H12AffineFastState.Bounded env9211 := by
  intro p hp
  have h : env9211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9210_9211 : H12AffineEnvironment.transform 12 161 env9210 = env9211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env9210 == env9211) = true)

theorem identity9211 : scanCanonicalize (H12AffineFastState.compose env9211 (packedSelected [2,9] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound9211 : packedSelected [2,9] rootPS < 2^1333 := by decide +kernel

def env9212 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,1296,161,1344,293,171,1345,429,1025,293,1297,260,64,139,40,16,428,1345,1296,1,1285,242,257,470,1344,136]

theorem envBound9212 : H12AffineFastState.Bounded env9212 := by
  intro p hp
  have h : env9212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9211_9212 : H12AffineEnvironment.transform 15 171 env9211 = env9212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env9211 == env9212) = true)

def env9213 : List Nat := [2,4,8,16,32,16,128,256,137,1024,1,1296,161,1296,293,171,1297,429,1025,293,1297,260,16,139,40,16,428,1297,1296,1,1285,162,257,390,1296,136]

theorem envBound9213 : H12AffineFastState.Bounded env9213 := by
  intro p hp
  have h : env9213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9212_9213 : H12AffineEnvironment.transform 5 16 env9212 = env9213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env9212 == env9213) = true)

theorem identity9213 : scanCanonicalize (H12AffineFastState.compose env9213 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound9213 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9214 : List Nat := [2,4,8,16,16,16,128,256,137,1024,1,1296,145,1296,277,155,1297,413,1025,277,1297,260,16,139,24,16,412,1297,1296,1,1285,146,257,390,1296,136]

theorem envBound9214 : H12AffineFastState.Bounded env9214 := by
  intro p hp
  have h : env9214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9213_9214 : H12AffineEnvironment.transform 4 16 env9213 = env9214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env9213 == env9214) = true)

def env9215 : List Nat := [2,4,8,16,16,16,128,20,137,1024,1,1028,145,1028,1,155,1029,137,1025,1,1029,16,16,139,24,16,136,1029,1028,1,1041,146,21,146,1028,136]

theorem envBound9215 : H12AffineFastState.Bounded env9215 := by
  intro p hp
  have h : env9215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9214_9215 : H12AffineEnvironment.transform 7 20 env9214 = env9215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env9214 == env9215) = true)

theorem identity9215 : scanCanonicalize (H12AffineFastState.compose env9215 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound9215 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9216 : List Nat := [2,4,8,16,16,16,18,20,27,1024,1,1028,3,1028,1,9,1029,27,1025,1,1029,16,16,25,24,16,26,1029,1028,1,1041,0,21,0,1028,26]

theorem envBound9216 : H12AffineFastState.Bounded env9216 := by
  intro p hp
  have h : env9216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9215_9216 : H12AffineEnvironment.transform 6 18 env9215 = env9216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env9215 == env9216) = true)

def leafEnv9216 : List Nat := [2,4,8,16,16,16,18,20,27,1024,1,1028,3,1028,1,9,1029,27,1025,1,1029,16,16,25,1040,24,1,16,26,1029,1028,1,1041,0,21,0,5,19,1028,26,0,1029,1]

def active9216 : List Nat := [0,1,2,3,9]

def tree9216 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9216 : H12WitnessSearch.Good tree9216 := H12GlobalWitnessIndex.good

theorem leafIdentity9216 : H12AffineFastState.composeSystem env9216 rootObs = leafEnv9216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9216 rootObs == leafEnv9216) = true)

theorem terminalChecked9216 : H12PackedTerminal.terminalCheckFast leafEnv9216 active9216 tree9216 = true := by decide +kernel

def env9217 : List Nat := [2,4,8,16,16,16,128,21,137,1024,1,1029,145,1029,0,155,1028,136,1025,0,1028,17,16,139,24,16,137,1028,1029,1,1040,146,20,147,1029,136]

theorem envBound9217 : H12AffineFastState.Bounded env9217 := by
  intro p hp
  have h : env9217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9214_9217 : H12AffineEnvironment.transform 7 21 env9214 = env9217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env9214 == env9217) = true)

theorem identity9217 : scanCanonicalize (H12AffineFastState.compose env9217 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound9217 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9218 : List Nat := [2,4,8,0,0,0,128,5,137,1024,1,1029,129,1029,0,139,1028,136,1025,0,1028,1,0,139,8,0,137,1028,1029,1,1024,130,4,131,1029,136]

theorem envBound9218 : H12AffineFastState.Bounded env9218 := by
  intro p hp
  have h : env9218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9217_9218 : H12AffineEnvironment.transform 3 0 env9217 = env9218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env9217 == env9218) = true)

def leafEnv9218 : List Nat := [2,4,8,0,0,0,128,5,137,1024,1,1029,129,1029,0,139,1028,136,1025,0,1028,1,0,139,1025,8,1,0,137,1028,1029,1,1024,130,4,131,5,3,1029,136,0,1028,1]

def active9218 : List Nat := [0,1,2,6,9]

def tree9218 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9218 : H12WitnessSearch.Good tree9218 := H12GlobalWitnessIndex.good

theorem leafIdentity9218 : H12AffineFastState.composeSystem env9218 rootObs = leafEnv9218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9218 rootObs == leafEnv9218) = true)

theorem terminalChecked9218 : H12PackedTerminal.terminalCheckFast leafEnv9218 active9218 tree9218 = true := by decide +kernel

def env9219 : List Nat := [2,4,8,16,32,17,128,256,137,1024,1,1296,161,1297,293,171,1296,429,1025,293,1297,260,17,139,40,16,428,1296,1296,1,1285,163,257,391,1297,136]

theorem envBound9219 : H12AffineFastState.Bounded env9219 := by
  intro p hp
  have h : env9219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9212_9219 : H12AffineEnvironment.transform 5 17 env9212 = env9219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env9212 == env9219) = true)

theorem identity9219 : scanCanonicalize (H12AffineFastState.compose env9219 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound9219 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9220 : List Nat := [2,4,8,16,32,17,57,256,48,1024,1,1296,24,1297,293,18,1296,276,1025,293,1297,260,17,50,40,16,277,1296,1296,1,1285,26,257,318,1297,49]

theorem envBound9220 : H12AffineFastState.Bounded env9220 := by
  intro p hp
  have h : env9220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9219_9220 : H12AffineEnvironment.transform 6 57 env9219 = env9220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env9219 == env9220) = true)

def env9221 : List Nat := [2,4,8,16,32,17,57,36,48,1024,1,1076,24,1077,1,18,1076,48,1025,1,1077,32,17,50,40,16,49,1076,1076,1,1057,26,37,26,1077,49]

theorem envBound9221 : H12AffineFastState.Bounded env9221 := by
  intro p hp
  have h : env9221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9220_9221 : H12AffineEnvironment.transform 7 36 env9220 = env9221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env9220 == env9221) = true)

theorem identity9221 : scanCanonicalize (H12AffineFastState.compose env9221 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound9221 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9222 : List Nat := [2,4,8,11,32,10,34,36,43,1024,1,1071,3,1070,1,9,1071,43,1025,1,1070,32,10,41,40,11,42,1071,1071,1,1057,1,37,1,1070,42]

theorem envBound9222 : H12AffineFastState.Bounded env9222 := by
  intro p hp
  have h : env9222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9221_9222 : H12AffineEnvironment.transform 3 11 env9221 = env9222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env9221 == env9222) = true)

def leafEnv9222 : List Nat := [2,4,8,11,32,10,34,36,43,1024,1,1071,3,1070,1,9,1071,43,1025,1,1070,32,10,41,1056,40,1,11,42,1071,1071,1,1057,1,37,1,5,35,1070,42,0,1070,1]

def active9222 : List Nat := [0,1,2,4,9]

def tree9222 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9222 : H12WitnessSearch.Good tree9222 := H12GlobalWitnessIndex.good

theorem leafIdentity9222 : H12AffineFastState.composeSystem env9222 rootObs = leafEnv9222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9222 rootObs == leafEnv9222) = true)

theorem terminalChecked9222 : H12PackedTerminal.terminalCheckFast leafEnv9222 active9222 tree9222 = true := by decide +kernel

def env9223 : List Nat := [2,4,8,16,32,17,57,37,48,1024,1,1077,24,1076,0,18,1077,49,1025,0,1076,33,17,50,40,16,48,1077,1077,1,1056,26,36,27,1076,49]

theorem envBound9223 : H12AffineFastState.Bounded env9223 := by
  intro p hp
  have h : env9223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9220_9223 : H12AffineEnvironment.transform 7 37 env9220 = env9223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env9220 == env9223) = true)

theorem identity9223 : scanCanonicalize (H12AffineFastState.compose env9223 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound9223 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9224 : List Nat := [2,4,8,16,1,17,24,4,17,1024,1,1044,24,1045,0,18,1044,16,1025,0,1045,0,17,19,9,16,17,1044,1044,1,1025,26,5,27,1045,16]

theorem envBound9224 : H12AffineFastState.Bounded env9224 := by
  intro p hp
  have h : env9224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9223_9224 : H12AffineEnvironment.transform 4 1 env9223 = env9224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env9223 == env9224) = true)

def leafEnv9224 : List Nat := [2,4,8,16,1,17,24,4,17,1024,1,1044,24,1045,0,18,1044,16,1025,0,1045,0,17,19,1024,9,1,16,17,1044,1044,1,1025,26,5,27,5,2,1045,16,0,1045,1]

def active9224 : List Nat := [0,1,2,3,9]

def tree9224 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9224 : H12WitnessSearch.Good tree9224 := H12GlobalWitnessIndex.good

theorem leafIdentity9224 : H12AffineFastState.composeSystem env9224 rootObs = leafEnv9224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9224 rootObs == leafEnv9224) = true)

theorem terminalChecked9224 : H12PackedTerminal.terminalCheckFast leafEnv9224 active9224 tree9224 = true := by decide +kernel

def env9225 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1296,8192,1344,32768,65536,1345,32905,1025,32768,1297,41088,64,98565,8329,16,8460,1345,1296,75786,1285,41335,257,98393,1344,136]

theorem envBound9225 : H12AffineFastState.Bounded env9225 := by
  intro p hp
  have h : env9225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9192_9225 : H12AffineEnvironment.transform 17 32905 env9192 = env9225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32905 env9192 == env9225) = true)

def env9226 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1296,8192,1344,32768,65536,1345,262144,1025,32768,1297,41089,64,98565,8329,16,303492,1345,1296,75787,1285,4294967296,257,4295041327,1344,136]

theorem envBound9226 : H12AffineFastState.Bounded env9226 := by
  intro p hp
  have h : env9226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9190_9226 : H12AffineEnvironment.transform 21 41089 env9190 = env9226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env9190 == env9226) = true)

theorem identity9226 : scanCanonicalize (H12AffineFastState.compose env9226 (packedSelected [6] rootPS)) = affineNative (2^(31+1) ^^^ 295155) := by decide +kernel

theorem selectedBound9226 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env9227 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1296,8192,1344,32768,65536,1345,262144,1025,32768,1297,41089,64,98565,8329,16,303492,1345,1296,75787,1285,295155,257,369116,1344,136]

theorem envBound9227 : H12AffineFastState.Bounded env9227 := by
  intro p hp
  have h : env9227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9226_9227 : H12AffineEnvironment.transform 31 295155 env9226 = env9227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 295155 env9226 == env9227) = true)

def env9228 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1296,8192,1344,32768,65536,1345,32904,1025,32768,1297,41089,64,98565,8329,16,8460,1345,1296,75787,1285,123,257,74068,1344,136]

theorem envBound9228 : H12AffineFastState.Bounded env9228 := by
  intro p hp
  have h : env9228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9227_9228 : H12AffineEnvironment.transform 17 32904 env9227 = env9228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32904 env9227 == env9228) = true)

def env9229 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1296,8192,1344,32768,65536,1345,32905,1025,32768,1297,41089,64,98565,8329,16,8461,1345,1296,75787,1285,122,257,74069,1344,136]

theorem envBound9229 : H12AffineFastState.Bounded env9229 := by
  intro p hp
  have h : env9229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9227_9229 : H12AffineEnvironment.transform 17 32905 env9227 = env9229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32905 env9227 == env9229) = true)

theorem identity9229 : scanCanonicalize (H12AffineFastState.compose env9229 (packedSelected [7] rootPS)) = affineNative (2^(14+1) ^^^ 8581) := by decide +kernel

theorem selectedBound9229 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env9230 : List Nat := [2,4,8,16,32,64,128,256,137,1024,2048,1296,8192,1344,8581,65536,1345,8460,1025,8581,1297,260,64,73856,8329,16,8461,1345,1296,75787,1285,122,257,74069,1344,136]

theorem envBound9230 : H12AffineFastState.Bounded env9230 := by
  intro p hp
  have h : env9230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9229_9230 : H12AffineEnvironment.transform 14 8581 env9229 = env9230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8581 env9229 == env9230) = true)

def env9231 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,1296,8192,1344,8581,65536,1345,8460,1025,8581,1297,260,64,73856,8329,16,8461,1345,1296,73739,1285,122,257,74069,1344,136]

theorem envBound9231 : H12AffineFastState.Bounded env9231 := by
  intro p hp
  have h : env9231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9230_9231 : H12AffineEnvironment.transform 10 0 env9230 = env9231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env9230 == env9231) = true)

theorem identity9231 : scanCanonicalize (H12AffineFastState.compose env9231 (packedSelected [0] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound9231 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9232 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,1296,8192,1344,8581,170,1345,8460,1025,8581,1297,260,64,8234,8329,16,8461,1345,1296,8353,1285,122,257,8703,1344,136]

theorem envBound9232 : H12AffineFastState.Bounded env9232 := by
  intro p hp
  have h : env9232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9231_9232 : H12AffineEnvironment.transform 15 170 env9231 = env9232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env9231 == env9232) = true)

theorem identity9232 : scanCanonicalize (H12AffineFastState.compose env9232 (packedSelected [2,4] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound9232 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env9233 : List Nat := [2,4,8,16,32,64,128,256,137,1024,0,1296,161,1344,292,170,1345,429,1025,292,1297,260,64,139,40,16,428,1345,1296,0,1285,122,257,350,1344,136]

theorem envBound9233 : H12AffineFastState.Bounded env9233 := by
  intro p hp
  have h : env9233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9232_9233 : H12AffineEnvironment.transform 12 161 env9232 = env9233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env9232 == env9233) = true)

def env9234 : List Nat := [2,4,8,16,32,16,128,256,137,1024,0,1296,161,1296,292,170,1297,429,1025,292,1297,260,16,139,40,16,428,1297,1296,0,1285,42,257,270,1296,136]

theorem envBound9234 : H12AffineFastState.Bounded env9234 := by
  intro p hp
  have h : env9234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9233_9234 : H12AffineEnvironment.transform 5 16 env9233 = env9234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env9233 == env9234) = true)

theorem identity9234 : scanCanonicalize (H12AffineFastState.compose env9234 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound9234 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9235 : List Nat := [2,4,8,16,16,16,128,256,137,1024,0,1296,145,1296,276,154,1297,413,1025,276,1297,260,16,139,24,16,412,1297,1296,0,1285,26,257,270,1296,136]

theorem envBound9235 : H12AffineFastState.Bounded env9235 := by
  intro p hp
  have h : env9235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9234_9235 : H12AffineEnvironment.transform 4 16 env9234 = env9235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env9234 == env9235) = true)

def env9236 : List Nat := [2,4,8,16,16,16,128,20,137,1024,0,1028,145,1028,0,154,1029,137,1025,0,1029,16,16,139,24,16,136,1029,1028,0,1041,26,21,26,1028,136]

theorem envBound9236 : H12AffineFastState.Bounded env9236 := by
  intro p hp
  have h : env9236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9235_9236 : H12AffineEnvironment.transform 7 20 env9235 = env9236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env9235 == env9236) = true)

theorem identity9236 : scanCanonicalize (H12AffineFastState.compose env9236 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound9236 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9237 : List Nat := [2,4,8,10,10,10,128,14,137,1024,0,1028,139,1028,0,128,1029,137,1025,0,1029,10,10,139,2,10,136,1029,1028,0,1035,0,15,0,1028,136]

theorem envBound9237 : H12AffineFastState.Bounded env9237 := by
  intro p hp
  have h : env9237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9236_9237 : H12AffineEnvironment.transform 3 10 env9236 = env9237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env9236 == env9237) = true)

def leafEnv9237 : List Nat := [2,4,8,10,10,10,128,14,137,1024,0,1028,139,1028,0,128,1029,137,1025,0,1029,10,10,139,1034,2,1,10,136,1029,1028,0,1035,0,15,0,5,8,1028,136,0,1029,1]

def active9237 : List Nat := [0,1,2,6,9]

def tree9237 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9237 : H12WitnessSearch.Good tree9237 := H12GlobalWitnessIndex.good

theorem leafIdentity9237 : H12AffineFastState.composeSystem env9237 rootObs = leafEnv9237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9237 rootObs == leafEnv9237) = true)

theorem terminalChecked9237 : H12PackedTerminal.terminalCheckFast leafEnv9237 active9237 tree9237 = true := by decide +kernel

def env9238 : List Nat := [2,4,8,16,16,16,128,21,137,1024,0,1029,145,1029,1,154,1028,136,1025,1,1028,17,16,139,24,16,137,1028,1029,0,1040,26,20,27,1029,136]

theorem envBound9238 : H12AffineFastState.Bounded env9238 := by
  intro p hp
  have h : env9238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9235_9238 : H12AffineEnvironment.transform 7 21 env9235 = env9238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env9235 == env9238) = true)

theorem identity9238 : scanCanonicalize (H12AffineFastState.compose env9238 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound9238 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9239 : List Nat := [2,4,8,0,0,0,128,5,137,1024,0,1029,129,1029,1,138,1028,136,1025,1,1028,1,0,139,8,0,137,1028,1029,0,1024,10,4,11,1029,136]

theorem envBound9239 : H12AffineFastState.Bounded env9239 := by
  intro p hp
  have h : env9239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9238_9239 : H12AffineEnvironment.transform 3 0 env9238 = env9239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env9238 == env9239) = true)

def leafEnv9239 : List Nat := [2,4,8,0,0,0,128,5,137,1024,0,1029,129,1029,1,138,1028,136,1025,1,1028,1,0,139,1025,8,1,0,137,1028,1029,0,1024,10,4,11,5,2,1029,136,0,1028,1]

def active9239 : List Nat := [0,1,2,6,9]

def tree9239 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9239 : H12WitnessSearch.Good tree9239 := H12GlobalWitnessIndex.good

theorem leafIdentity9239 : H12AffineFastState.composeSystem env9239 rootObs = leafEnv9239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9239 rootObs == leafEnv9239) = true)

theorem terminalChecked9239 : H12PackedTerminal.terminalCheckFast leafEnv9239 active9239 tree9239 = true := by decide +kernel

def env9240 : List Nat := [2,4,8,16,32,17,128,256,137,1024,0,1296,161,1297,292,170,1296,429,1025,292,1297,260,17,139,40,16,428,1296,1296,0,1285,43,257,271,1297,136]

theorem envBound9240 : H12AffineFastState.Bounded env9240 := by
  intro p hp
  have h : env9240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9233_9240 : H12AffineEnvironment.transform 5 17 env9233 = env9240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env9233 == env9240) = true)

theorem identity9240 : scanCanonicalize (H12AffineFastState.compose env9240 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound9240 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9241 : List Nat := [2,4,8,16,32,17,56,256,49,1024,0,1296,25,1297,292,18,1296,277,1025,292,1297,260,17,51,40,16,276,1296,1296,0,1285,43,257,271,1297,48]

theorem envBound9241 : H12AffineFastState.Bounded env9241 := by
  intro p hp
  have h : env9241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9240_9241 : H12AffineEnvironment.transform 6 56 env9240 = env9241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env9240 == env9241) = true)

def env9242 : List Nat := [2,4,8,16,32,17,56,36,49,1024,0,1076,25,1077,0,18,1076,49,1025,0,1077,32,17,51,40,16,48,1076,1076,0,1057,43,37,43,1077,48]

theorem envBound9242 : H12AffineFastState.Bounded env9242 := by
  intro p hp
  have h : env9242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9241_9242 : H12AffineEnvironment.transform 7 36 env9241 = env9242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env9241 == env9242) = true)

theorem identity9242 : scanCanonicalize (H12AffineFastState.compose env9242 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound9242 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9243 : List Nat := [2,4,8,16,10,17,18,14,27,1024,0,1054,25,1055,0,18,1054,27,1025,0,1055,10,17,25,2,16,26,1054,1054,0,1035,1,15,1,1055,26]

theorem envBound9243 : H12AffineFastState.Bounded env9243 := by
  intro p hp
  have h : env9243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9242_9243 : H12AffineEnvironment.transform 4 10 env9242 = env9243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env9242 == env9243) = true)

def leafEnv9243 : List Nat := [2,4,8,16,10,17,18,14,27,1024,0,1054,25,1055,0,18,1054,27,1025,0,1055,10,17,25,1034,2,1,16,26,1054,1054,0,1035,1,15,1,5,8,1055,26,0,1055,1]

def active9243 : List Nat := [0,1,2,3,9]

def tree9243 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9243 : H12WitnessSearch.Good tree9243 := H12GlobalWitnessIndex.good

theorem leafIdentity9243 : H12AffineFastState.composeSystem env9243 rootObs = leafEnv9243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9243 rootObs == leafEnv9243) = true)

theorem terminalChecked9243 : H12PackedTerminal.terminalCheckFast leafEnv9243 active9243 tree9243 = true := by decide +kernel

def env9244 : List Nat := [2,4,8,16,32,17,56,37,49,1024,0,1077,25,1076,1,18,1077,48,1025,1,1076,33,17,51,40,16,49,1077,1077,0,1056,43,36,42,1076,48]

theorem envBound9244 : H12AffineFastState.Bounded env9244 := by
  intro p hp
  have h : env9244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9241_9244 : H12AffineEnvironment.transform 7 37 env9241 = env9244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env9241 == env9244) = true)

theorem identity9244 : scanCanonicalize (H12AffineFastState.compose env9244 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound9244 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9245 : List Nat := [2,4,8,16,1,17,25,4,16,1024,0,1044,25,1045,1,18,1044,17,1025,1,1045,0,17,18,9,16,16,1044,1044,0,1025,10,5,11,1045,17]

theorem envBound9245 : H12AffineFastState.Bounded env9245 := by
  intro p hp
  have h : env9245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9244_9245 : H12AffineEnvironment.transform 4 1 env9244 = env9245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env9244 == env9245) = true)

def leafEnv9245 : List Nat := [2,4,8,16,1,17,25,4,16,1024,0,1044,25,1045,1,18,1044,17,1025,1,1045,0,17,18,1024,9,1,16,16,1044,1044,0,1025,10,5,11,5,3,1045,17,0,1045,1]

def active9245 : List Nat := [0,1,2,3,9]

def tree9245 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9245 : H12WitnessSearch.Good tree9245 := H12GlobalWitnessIndex.good

theorem leafIdentity9245 : H12AffineFastState.composeSystem env9245 rootObs = leafEnv9245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9245 rootObs == leafEnv9245) = true)

theorem terminalChecked9245 : H12PackedTerminal.terminalCheckFast leafEnv9245 active9245 tree9245 = true := by decide +kernel

def env9246 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,1296,8192,1344,8581,65536,1345,8460,1025,8581,1297,260,64,73856,8329,16,8461,1345,1296,73738,1285,122,257,74069,1344,136]

theorem envBound9246 : H12AffineFastState.Bounded env9246 := by
  intro p hp
  have h : env9246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9230_9246 : H12AffineEnvironment.transform 10 1 env9230 = env9246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env9230 == env9246) = true)

theorem identity9246 : scanCanonicalize (H12AffineFastState.compose env9246 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound9246 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env9247 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,1296,160,1344,293,65536,1345,428,1025,293,1297,260,64,65568,41,16,429,1345,1296,65706,1285,122,257,66037,1344,136]

theorem envBound9247 : H12AffineFastState.Bounded env9247 := by
  intro p hp
  have h : env9247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9246_9247 : H12AffineEnvironment.transform 12 160 env9246 = env9247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env9246 == env9247) = true)

theorem identity9247 : scanCanonicalize (H12AffineFastState.compose env9247 (packedSelected [2,9] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound9247 : packedSelected [2,9] rootPS < 2^1333 := by decide +kernel

def env9248 : List Nat := [2,4,8,16,32,64,128,256,137,1024,1,1296,160,1344,293,171,1345,428,1025,293,1297,260,64,139,41,16,429,1345,1296,1,1285,122,257,350,1344,136]

theorem envBound9248 : H12AffineFastState.Bounded env9248 := by
  intro p hp
  have h : env9248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9247_9248 : H12AffineEnvironment.transform 15 171 env9247 = env9248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env9247 == env9248) = true)

def env9249 : List Nat := [2,4,8,16,32,16,128,256,137,1024,1,1296,160,1296,293,171,1297,428,1025,293,1297,260,16,139,41,16,429,1297,1296,1,1285,42,257,270,1296,136]

theorem envBound9249 : H12AffineFastState.Bounded env9249 := by
  intro p hp
  have h : env9249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9248_9249 : H12AffineEnvironment.transform 5 16 env9248 = env9249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env9248 == env9249) = true)

theorem identity9249 : scanCanonicalize (H12AffineFastState.compose env9249 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound9249 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9250 : List Nat := [2,4,8,16,16,16,128,256,137,1024,1,1296,144,1296,277,155,1297,412,1025,277,1297,260,16,139,25,16,413,1297,1296,1,1285,26,257,270,1296,136]

theorem envBound9250 : H12AffineFastState.Bounded env9250 := by
  intro p hp
  have h : env9250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9249_9250 : H12AffineEnvironment.transform 4 16 env9249 = env9250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env9249 == env9250) = true)

def env9251 : List Nat := [2,4,8,16,16,16,128,20,137,1024,1,1028,144,1028,1,155,1029,136,1025,1,1029,16,16,139,25,16,137,1029,1028,1,1041,26,21,26,1028,136]

theorem envBound9251 : H12AffineFastState.Bounded env9251 := by
  intro p hp
  have h : env9251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9250_9251 : H12AffineEnvironment.transform 7 20 env9250 = env9251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env9250 == env9251) = true)

theorem identity9251 : scanCanonicalize (H12AffineFastState.compose env9251 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound9251 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9252 : List Nat := [2,4,8,10,10,10,128,14,137,1024,1,1028,138,1028,1,129,1029,136,1025,1,1029,10,10,139,3,10,137,1029,1028,1,1035,0,15,0,1028,136]

theorem envBound9252 : H12AffineFastState.Bounded env9252 := by
  intro p hp
  have h : env9252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9251_9252 : H12AffineEnvironment.transform 3 10 env9251 = env9252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env9251 == env9252) = true)

def leafEnv9252 : List Nat := [2,4,8,10,10,10,128,14,137,1024,1,1028,138,1028,1,129,1029,136,1025,1,1029,10,10,139,1034,3,1,10,137,1029,1028,1,1035,0,15,0,5,9,1028,136,0,1029,1]

def active9252 : List Nat := [0,1,2,6,9]

def tree9252 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9252 : H12WitnessSearch.Good tree9252 := H12GlobalWitnessIndex.good

theorem leafIdentity9252 : H12AffineFastState.composeSystem env9252 rootObs = leafEnv9252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9252 rootObs == leafEnv9252) = true)

theorem terminalChecked9252 : H12PackedTerminal.terminalCheckFast leafEnv9252 active9252 tree9252 = true := by decide +kernel

def env9253 : List Nat := [2,4,8,16,16,16,128,21,137,1024,1,1029,144,1029,0,155,1028,137,1025,0,1028,17,16,139,25,16,136,1028,1029,1,1040,26,20,27,1029,136]

theorem envBound9253 : H12AffineFastState.Bounded env9253 := by
  intro p hp
  have h : env9253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9250_9253 : H12AffineEnvironment.transform 7 21 env9250 = env9253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env9250 == env9253) = true)

theorem identity9253 : scanCanonicalize (H12AffineFastState.compose env9253 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound9253 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9254 : List Nat := [2,4,8,0,0,0,128,5,137,1024,1,1029,128,1029,0,139,1028,137,1025,0,1028,1,0,139,9,0,136,1028,1029,1,1024,10,4,11,1029,136]

theorem envBound9254 : H12AffineFastState.Bounded env9254 := by
  intro p hp
  have h : env9254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9253_9254 : H12AffineEnvironment.transform 3 0 env9253 = env9254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env9253 == env9254) = true)

def leafEnv9254 : List Nat := [2,4,8,0,0,0,128,5,137,1024,1,1029,128,1029,0,139,1028,137,1025,0,1028,1,0,139,1025,9,1,0,136,1028,1029,1,1024,10,4,11,5,3,1029,136,0,1028,1]

def active9254 : List Nat := [0,1,2,6,9]

def tree9254 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9254 : H12WitnessSearch.Good tree9254 := H12GlobalWitnessIndex.good

theorem leafIdentity9254 : H12AffineFastState.composeSystem env9254 rootObs = leafEnv9254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9254 rootObs == leafEnv9254) = true)

theorem terminalChecked9254 : H12PackedTerminal.terminalCheckFast leafEnv9254 active9254 tree9254 = true := by decide +kernel

def env9255 : List Nat := [2,4,8,16,32,17,128,256,137,1024,1,1296,160,1297,293,171,1296,428,1025,293,1297,260,17,139,41,16,429,1296,1296,1,1285,43,257,271,1297,136]

theorem envBound9255 : H12AffineFastState.Bounded env9255 := by
  intro p hp
  have h : env9255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9248_9255 : H12AffineEnvironment.transform 5 17 env9248 = env9255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env9248 == env9255) = true)

theorem identity9255 : scanCanonicalize (H12AffineFastState.compose env9255 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound9255 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env9256 : List Nat := [2,4,8,16,32,17,56,256,49,1024,1,1296,24,1297,293,19,1296,276,1025,293,1297,260,17,51,41,16,277,1296,1296,1,1285,43,257,271,1297,48]

theorem envBound9256 : H12AffineFastState.Bounded env9256 := by
  intro p hp
  have h : env9256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9255_9256 : H12AffineEnvironment.transform 6 56 env9255 = env9256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env9255 == env9256) = true)

def env9257 : List Nat := [2,4,8,16,32,17,56,36,49,1024,1,1076,24,1077,1,19,1076,48,1025,1,1077,32,17,51,41,16,49,1076,1076,1,1057,43,37,43,1077,48]

theorem envBound9257 : H12AffineFastState.Bounded env9257 := by
  intro p hp
  have h : env9257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9256_9257 : H12AffineEnvironment.transform 7 36 env9256 = env9257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env9256 == env9257) = true)

theorem identity9257 : scanCanonicalize (H12AffineFastState.compose env9257 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound9257 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9258 : List Nat := [2,4,8,16,10,17,18,14,27,1024,1,1054,24,1055,1,19,1054,26,1025,1,1055,10,17,25,3,16,27,1054,1054,1,1035,1,15,1,1055,26]

theorem envBound9258 : H12AffineFastState.Bounded env9258 := by
  intro p hp
  have h : env9258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9257_9258 : H12AffineEnvironment.transform 4 10 env9257 = env9258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env9257 == env9258) = true)

def leafEnv9258 : List Nat := [2,4,8,16,10,17,18,14,27,1024,1,1054,24,1055,1,19,1054,26,1025,1,1055,10,17,25,1034,3,1,16,27,1054,1054,1,1035,1,15,1,5,9,1055,26,0,1055,1]

def active9258 : List Nat := [0,1,2,3,9]

def tree9258 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9258 : H12WitnessSearch.Good tree9258 := H12GlobalWitnessIndex.good

theorem leafIdentity9258 : H12AffineFastState.composeSystem env9258 rootObs = leafEnv9258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9258 rootObs == leafEnv9258) = true)

theorem terminalChecked9258 : H12PackedTerminal.terminalCheckFast leafEnv9258 active9258 tree9258 = true := by decide +kernel

def env9259 : List Nat := [2,4,8,16,32,17,56,37,49,1024,1,1077,24,1076,0,19,1077,49,1025,0,1076,33,17,51,41,16,48,1077,1077,1,1056,43,36,42,1076,48]

theorem envBound9259 : H12AffineFastState.Bounded env9259 := by
  intro p hp
  have h : env9259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9256_9259 : H12AffineEnvironment.transform 7 37 env9256 = env9259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env9256 == env9259) = true)

theorem identity9259 : scanCanonicalize (H12AffineFastState.compose env9259 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound9259 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env9260 : List Nat := [2,4,8,16,1,17,25,4,16,1024,1,1044,24,1045,0,19,1044,16,1025,0,1045,0,17,18,8,16,17,1044,1044,1,1025,10,5,11,1045,17]

theorem envBound9260 : H12AffineFastState.Bounded env9260 := by
  intro p hp
  have h : env9260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9259_9260 : H12AffineEnvironment.transform 4 1 env9259 = env9260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env9259 == env9260) = true)

def leafEnv9260 : List Nat := [2,4,8,16,1,17,25,4,16,1024,1,1044,24,1045,0,19,1044,16,1025,0,1045,0,17,18,1024,8,1,16,17,1044,1044,1,1025,10,5,11,5,2,1045,17,0,1045,1]

def active9260 : List Nat := [0,1,2,3,9]

def tree9260 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood9260 : H12WitnessSearch.Good tree9260 := H12GlobalWitnessIndex.good

theorem leafIdentity9260 : H12AffineFastState.composeSystem env9260 rootObs = leafEnv9260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env9260 rootObs == leafEnv9260) = true)

theorem terminalChecked9260 : H12PackedTerminal.terminalCheckFast leafEnv9260 active9260 tree9260 = true := by decide +kernel

def env9261 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,136512,4194304,17664,16777216,33554432,5377,21484817,16384,131153,4427210,16876544,4294967296,257,4349522035,131073,33563272]

theorem envBound9261 : H12AffineFastState.Bounded env9261 := by
  intro p hp
  have h : env9261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9154_9261 : H12AffineEnvironment.transform 25 5377 env9154 = env9261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 5377 env9154 == env9261) = true)

theorem identity9261 : scanCanonicalize (H12AffineFastState.compose env9261 (packedSelected [4,6,7,9,16,20,25,27] rootPS)) = affineNative (2^(23+1) ^^^ 98564) := by decide +kernel

theorem selectedBound9261 : packedSelected [4,6,7,9,16,20,25,27] rootPS < 2^1333 := by decide +kernel

def env9262 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32768,136512,4194304,17664,98564,33554432,5377,4609045,16384,131153,4427210,1284,4294967296,257,4332843383,131073,33563272]

theorem envBound9262 : H12AffineFastState.Bounded env9262 := by
  intro p hp
  have h : env9262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9261_9262 : H12AffineEnvironment.transform 23 98564 env9261 = env9262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98564 env9261 == env9262) = true)

theorem identity9262 : scanCanonicalize (H12AffineFastState.compose env9262 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 21776) := by decide +kernel

theorem selectedBound9262 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env9263 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,21776,262144,1025,32768,16464,4194304,17664,98564,33554432,5377,4456709,16384,21825,4315354,1284,4294967296,257,4332843383,21777,33563272]

theorem envBound9263 : H12AffineFastState.Bounded env9263 := by
  intro p hp
  have h : env9263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9262_9263 : H12AffineEnvironment.transform 16 21776 env9262 = env9263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 21776 env9262 == env9263) = true)

def env9264 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,17664,16777216,33554432,67108864,134217728,67130625,157794305,1073741824,140788816,4294967296,157663569,4417151347,131072,33563272]

theorem envBound9264 : H12AffineFastState.Bounded env9264 := by
  intro p hp
  have h : env9264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8956_9264 : H12AffineEnvironment.transform 28 157794305 env8956 = env9264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 157794305 env8956 == env9264) = true)

theorem identity9264 : scanCanonicalize (H12AffineFastState.compose env9264 (packedSelected [14] rootPS)) = affineNative (2^(26+1) ^^^ 23577872) := by decide +kernel

theorem selectedBound9264 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env9265 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,17664,16777216,33554432,67108864,23577872,67130625,1297,1073741824,17006912,4294967296,132161,4417151347,131072,33563272]

end H12CloudChart2